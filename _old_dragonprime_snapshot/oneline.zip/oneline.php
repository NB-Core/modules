<?php

// -----------------
// One Liners V1.1
// Written by Lurch
// www.taf.co.nz
// -----------------
// Displays One liners on your LotGD index page.
// Please read the readme

function oneline_getmoduleinfo(){
	$info = array(
		"name"=>"Oneliners",
		"author"=>"Lurch",
		"version"=>"1.0",
		"category"=>"General",
		"download"=>"http://dragonprime.net/users/Lurch/oneline.zip",
		"allowanonymous" => 1,
		cccc);
	return $info;
}
function oneline_install(){
	module_addhook("index");
	return true;
}
function oneline_uninstall(){
	return true;
}
function oneline_dohook($hookname,$args){
	global $session;
	define("ALLOWANONYMOUS", true);
	switch ($hookname){
			case "index":
// Setup
			$textfile ="oneline.txt"; 
			$quotes = file("$textfile");
			$quote = rand(0, sizeof($quotes)-1);
// Display One liners	        	
			output("`n`n");
			output("`b`#Oneliner: `0`b". $quotes[$quote]);
			output("`n`n");
			break;
}
return $args;
}	
function oneline_run(){
}
?>



