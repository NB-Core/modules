Legend of the Green Dragon v0.9.8 Module

One liners v1.0
Written by Lurch

http://www.taf.co.nz

Install:

oneline.txt goes in the root dir of your LotGD.
oneline.php goes in the modules folder.

Instructions:

You can add more one liners by editing the oneline.txt file. Each new
one liner must be on a new line.

Thanks goes to:

The gang @ http://dragonprime.net 
