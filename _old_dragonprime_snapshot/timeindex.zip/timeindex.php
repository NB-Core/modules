<?php

function timeindex_getmoduleinfo(){
	$info = array(
		"name"=>"Date Display on Index",
		"author"=>"Chris Vorndran",
		"version"=>"0.11",
		"category"=>"General",
		"download"=>"http://dragonprime.net/index.php?module=Downloads;sa=dlview;id=81",
		"vertxtloc"=>"http://dragonprime.net/users/Sichae/",
		"description"=>"This module displays the current date on the Index Page. Selectable Color.",
		"settings"=>array(
			"Date Display Settings,title",
			"hook"=>"Where does this display on Index page,enum,1,Above Login,2,Below Template Selector|1",
			"color"=>"Color of Text,enum,1,Dark Blue,!,Bright Blue,2,Dark Green,@,Bright Green,3,Dark Cyan,3,Bright Cyan,4,Dark Red,$,Bright Red,5,Dark Purple,%,Bright Purple,6,Dark Yellow,^,Bright Yellow,7,Gray,),Dark Grey,&,White,Q,Orange,q,Brown|3",
		),
		);
	return $info;
}
function timeindex_install(){
	module_addhook("index");
	module_addhook("footer-home");
	return true;
}
function timeindex_uninstall(){
	return true;
	
}
function timeindex_dohook($hookname,$args){
	global $session;
	$c = get_module_setting("color");
	switch ($hookname){
		case "index":
			if (get_module_setting("hook") == 1){
			$d = translate_inline(date("l \\t\h\e jS of F, Y"));
			rawoutput("<big>");
			output("`$c Today is: `b%s`b`n`0",$d);
			rawoutput("</big>");
			}
			break;
		case "footer-home":
			if (get_module_setting("hook") == 2){
			$d = translate_inline(date("l \\t\h\e jS of F, Y"));
			rawoutput("<big>");
			output("`c`$c Today is: `b%s`b`c`0",$d);
			rawoutput("</big>");
			}
			break;
		}
	return $args;
}
function timeindex_run(){
}
?>