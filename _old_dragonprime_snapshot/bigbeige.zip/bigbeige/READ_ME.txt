Big-Beige skin for Legend of the Green Dragon v1x
By Robert of maddrio.com
based on Ben Wongs Amber skin

The Big Biege skin is with light pastels and large fonts.
It was specifically was designed for those with low vision or other vision problems.

Place both files:

bigbeige.css
bigbeige.htm

IN YOUR TEMPLATES FOLDER

-> Do NOT place the folder or this readme in your templates folder!!!

More of Roberts modules for the LotGD game is found at:

http://dragonprime.net/index.php?topic=2215.0