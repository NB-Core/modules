<?php
// first released for 0.9.7 ger: 22062004
// re-released as module for 0.9.8 prerelease.4: 25082004
// (Note: This module release works in german and english language
// with prerelease.4 but it is possible that it won't work in
// english with future releases!)
//
// Another work from that stupid german guy anpera who lives for LoGD by Eric Stevens
//
// Escape from death, or haunt the world of the living from beyond your grave
// or do other things you wouldn't have thought to be possible at all.
//
// Have fun!

if ($_GET['op']=="download"){ // this offers the module for download directly from the server
	$dl=join("",file("styx.php"));
	echo $dl;
}else{
//require_once("lib/http.php");
require_once("lib/commentary.php");
//require_once("lib/e_rand.php");

function styx_getmoduleinfo(){
	$info = array(
		"name"=>"River of Souls",
		"author"=>"A. Rauch (anpera)",
		"version"=>"25082004ger",
		"category"=>"Graveyard Specials",
		"download"=>"modules/styx.php?op=download",
	);
	return $info;
}

function styx_install(){
	debug("Installing River of Souls.");
	// adding english translation into database if needed
	if (db_num_rows(db_query("SELECT uri FROM ".db_prefix("translations")." WHERE uri LIKE 'module-styx'"))>0){
		debug("Translation already exists");
	}else{
		$sqls = array(
			"INSERT INTO ".db_prefix("translations")." VALUES (0, 'en', 'module-styx', 'Zur�ck zum Friedhof', 'Back to graveyard', 0, 'anpera', '0.9.8-prer')",
			"INSERT INTO ".db_prefix("translations")." VALUES (0, 'en', 'module-styx', 'Fluchtversuch', 'Try to escape', 0, 'anpera', '0.9.8-prer')",
			"INSERT INTO ".db_prefix("translations")." VALUES (0, 'en', 'module-styx', 'Ort untersuchen', 'Examine this place', 0, 'anpera', '0.9.8-prer')",
			"INSERT INTO ".db_prefix("translations")." VALUES (0, 'en', 'module-styx', '`7Du bemerkst einen seltsamen Schimmer und wandelst darauf zu.`nDu hast den `bFluss der Seelen`b gefunden! Jenen merkw�rdigen Ort, ', '`7You note a strange glimmer and wander over to it.`nYou found `bThe River Of Souls`b! This very strange place, ', 0, 'anpera', '0.9.8-prer')",
			"INSERT INTO ".db_prefix("translations")." VALUES (0, 'en', 'module-styx', 'der angeblich das Reich der Toten und die Welt der Lebenden verbindet und wo all die toten Kreaturen herkommen, die einst den Wald und jetzt den Friedhof bev�lkern. Du witterst eine Chance, dem Totenreich zu entfliehen, aber du wei�t auch um die ', 'that connects the land of the living with the land of the dead and where all those graveyard creatures come from, after they died in the forest. You scent a chance to escape from death, but you also know the ', 0, 'anpera', '0.9.8-prer')",
			"INSERT INTO ".db_prefix("translations")." VALUES (0, 'en', 'module-styx', 'Gefahren einer solchen Unternehmung bescheid.`n`nWirst du den Fluchtversuch wagen? Oder willst du diesen sagenhaft Ort n�her untersuchen?', 'dangers of such a trip.`n`nDo you want to dare this escape? Or do you want to examine this place closer?', 0, 'anpera', '0.9.8-prer')",
			"INSERT INTO ".db_prefix("translations")." VALUES (0, 'en', 'module-styx', '`n`nDein Fluchtversuch ist gescheitert.', '`n`nYour escape failed.', 0, 'anpera', '0.9.8-prer')",
			"INSERT INTO ".db_prefix("translations")." VALUES (0, 'en', 'module-styx', 'Spuken f�r Gefallen', 'Use favor for a spook', 0, 'anpera', '0.9.8-prer')",
			"INSERT INTO ".db_prefix("translations")." VALUES (0, 'en', 'module-styx', 'Zum Friedhof', 'Back to Graveyard', 0, 'anpera', '0.9.8-prer')",
			"INSERT INTO ".db_prefix("translations")." VALUES (0, 'en', 'module-styx', '`7Du entdeckst eine M�glichkeit, mit der Welt der Lebenden in Verbindung zu treten! Allerdings wird dich dieses Unternehmen einiges ', '`7You find a way to contact the word of the living! But it will cost you some favor ', 0, 'anpera', '0.9.8-prer')",
			"INSERT INTO ".db_prefix("translations")." VALUES (0, 'en', 'module-styx', 'an Gefallen kosten und wer und ob dich jemand h�ren wird, wissen nicht einmal die G�tter.', 'and only the gods know if somebody will hear you up there.', 0, 'anpera', '0.9.8-prer')",
			"INSERT INTO ".db_prefix("translations")." VALUES (0, 'en', 'module-styx', '`7Du verl�sst den Flu� der Seelen und kehrst zum Friedhof zur�ck.', '`7You leave the River of Souls and return to the graveyard.', 0, 'anpera', '0.9.8-prer')",
			"INSERT INTO ".db_prefix("translations")." VALUES (0, 'en', 'module-styx', 'der tote H�ndler, der nie gestorben ist, immer auf dem Sprung und schon ewig hier. Ich tausche hier meine Waren, die mir nie geh�rten. Sie bringen dir sowohl im Totenreich, wie auch', 'the dead merchant who never died. Always on my way and still never away. I trade things that don\'t belong to me. They can bring you forward or backwards in live or in death.', 0, 'anpera', '0.9.8-prer')",
			"INSERT INTO ".db_prefix("translations")." VALUES (0, 'en', 'module-styx', ' im Reich der Lebenden einen Vorteil, der keiner ist. Also, kann ich dir materiellen oder spirituellen Besitz anbieten oder abkn�pfen?`7\"', ' So, may I offer or take some things?`7\"', 0, 'anpera', '0.9.8-prer')",
			"INSERT INTO ".db_prefix("translations")." VALUES (0, 'en', 'module-styx', '`7\"`!Sei gegr�sst!`7\", spricht dich eine alte Seele an, die schon seit Ewigkeiten hier zu sein scheint, \"`!Ich bin `4Hatetepe`!, ', '`7\"`!Greetings!`7\" A very old soul, obviously trapped down here for a long time, is talking to you. \"`!I am `4Hatetepe`!,', 0, 'anpera', '0.9.8-prer')",
			"INSERT INTO ".db_prefix("translations")." VALUES (0, 'en', 'module-styx', '1 Grabkampf  f�r 1 Edelstein', '1 gravefight costs 1 gem', 0, 'anpera', '0.9.8-prer')",
			"INSERT INTO ".db_prefix("translations")." VALUES (0, 'en', 'module-styx', '3 Grabk�mpfe f�r 5 Edelsteine', '3 gravefights cost 5 gems', 0, 'anpera', '0.9.8-prer')",
			"INSERT INTO ".db_prefix("translations")." VALUES (0, 'en', 'module-styx', '10 Gefallen f�r 2 Edelsteine', '10 favor cost 2 gems', 0, 'anpera', '0.9.8-prer')",
			"INSERT INTO ".db_prefix("translations")." VALUES (0, 'en', 'module-styx', '1 Edelstein f�r 5 Gefallen', '1 gem costs 5 favor', 0, 'anpera', '0.9.8-prer')",
			"INSERT INTO ".db_prefix("translations")." VALUES (0, 'en', 'module-styx', 'Sonstige', 'Others', 0, 'anpera', '0.9.8-prer')",
			"INSERT INTO ".db_prefix("translations")." VALUES (0, 'en', 'module-styx', 'Zum Friedhof', 'Back to Graveyard', 0, 'anpera', '0.9.8-prer')",
			"INSERT INTO ".db_prefix("translations")." VALUES (0, 'en', 'module-styx', '`7Du verlierst einen Gefallen und nimmst mit der Welt der Lebenden Kontakt auf.`n Du hast noch `b`4%s`b`7 Gefallen.`n`n', '`7You lose one favor and contact the world of the living.`nYou have `b`4%s`b`7 favor left.`n`n', 0, 'anpera', '0.9.8-prer')",
			"INSERT INTO ".db_prefix("translations")." VALUES (0, 'en', 'module-styx', '`7F�r einen Moment dachtest du, etwas gesehen zu haben, aber du entdeckst hier absolut nichts besonderes.', '`7For a moment you thought you have seen something. But there is absolutely nothing.', 0, 'anpera', '0.9.8-prer')",
			"INSERT INTO ".db_prefix("translations")." VALUES (0, 'en', 'module-styx', '`7Deine Seele folgt dem Fluss der Toten aufw�rts. Du siehst viele Seelen, die im Fluss mitgerissen werden, einige werden auf Booten von toten F�hrm�nnern gefahren und andere versuchen wie du die Flucht.', '`7Your soul follows the river of souls upstream. You see a lot of souls on their unintended way to `\$Ramius`7. Some of them try to escape just like you.', 0, 'anpera', '0.9.8-prer')",
			"INSERT INTO ".db_prefix("translations")." VALUES (0, 'en', 'module-styx', '`7 Die vielen H�nde, die aus dem Fluss nach dir greifen, lassen dich nur langsam vorankommen. Schlie�lich zerren sie dich ganz in den Fluss. Du wirst zur�ck ins Totenreich geschwemmt - direkt vor `\$Ramius`7\' F�sse.', '`7 A lot of hands grap after you and slow down your escape. Finally they drad you down completely. You are flushed back into the world of the dead - directly to `\$Ramius\'`7 feet. ', 0, 'anpera', '0.9.8-prer')",
			"INSERT INTO ".db_prefix("translations")." VALUES (0, 'en', 'module-styx', 'Kaufen', 'Buy', 0, 'anpera', '0.9.8-pre4')",
			"INSERT INTO ".db_prefix("translations")." VALUES (0, 'en', 'module-styx', '`7Du versprichst `4Hatetepe`7 f�nf deiner hier unten v�llig wertlosen Edelsteine und findest dich pl�tzlich auf dem Friedhof wieder...', '`7You promise `4Hatetepe`7 five of your gems, which are absolutely worthless down here and in the same moment you find yourself back on graveyard...', 0, 'anpera', '0.9.8-pre4')",
			"INSERT INTO ".db_prefix("translations")." VALUES (0, 'en', 'module-styx', '`7Du versprichst `4Hatetepe`7 einen deiner hier unten v�llig wertlosen Edelsteine und findest dich pl�tzlich auf dem Friedhof wieder...', '`7You promise `4Hatetepe`7 one of your gems, which are absolutely worthless down here and in the same moment you find yourself back on graveyard...', 0, 'anpera', '0.9.8-pre4')",
			"INSERT INTO ".db_prefix("translations")." VALUES (0, 'en', 'module-styx', 'Sonstiges', 'Others', 0, 'anpera', '0.9.8-pre4')",
			"INSERT INTO ".db_prefix("translations")." VALUES (0, 'en', 'module-styx', '`7F�r ein paar mehr Gefallen bei `\$Ramius`7 w�rdest du sogar deine Seele verkaufen. Ups! Lieber doch nicht. So versprichst du dieser trotteligen Seele', '`7For just a few more favor with `\$Ramius`7 you would even sell you soul. Ooops - this could be taken literally down here. Well, you promise this stupid soul', 0, 'anpera', '0.9.8-pre4')",
			"INSERT INTO ".db_prefix("translations")." VALUES (0, 'en', 'module-styx', ' ein paar deiner Edelsteine, die dir hier unten ja sonst wirklich nichts n�tzen. Wie du `4Hatetepe`7 die Steinchen �bergeben sollst, ist dir in dem Moment egal - dir ', 'a few of your gems that are absolutely wothless here for you and for him for sure. You don\'t know how you should give `4Hatetepe`7 what you promised him but you don\'t even care about this at the moment.', 0, 'anpera', '0.9.8-pre4')",
			"INSERT INTO ".db_prefix("translations")." VALUES (0, 'en', 'module-styx', 'w�re es sogar recht, wenn er die Steine nie einfordern w�rde.`n', 'It would be the best for you if he\'ll never ask for the gems.`n', 0, 'anpera', '0.9.8-pre4')",
			"INSERT INTO ".db_prefix("translations")." VALUES (0, 'en', 'module-styx', '`4Hatetepe`7 verspricht, ein gutes Wort f�r dich bei `\$Ramius`7 einzulegen. Gerade als du ihn fragen willst, was er hier unten �berhaupt mit Edelsteinen anfangen will, ', '`4Hatetepe`7 promises you to talk with `\$Ramius`7 for you. You just wanted to ask what in Ramius\' name he can do with gems down here ', 0, 'anpera', '0.9.8-pre4')",
			"INSERT INTO ".db_prefix("translations")." VALUES (0, 'en', 'module-styx', ' findest du dich auf dem Friedhof wieder...', ' but in that very moment you find yourself back on graveyard...', 0, 'anpera', '0.9.8-pre4')",
			"INSERT INTO ".db_prefix("translations")." VALUES (0, 'en', 'module-styx', '`4Hatetepe`7 verspricht dir, einen Edelstein f�r dich im Dorf bereit zu legen. Gerade als du ihn fragen willst, wie er das schaffen will, ', '`4Hatetepe`7 promises you one gem. You are about to ask him, how he will do that without ever wandering in the world of the living, ', 0, 'anpera', '0.9.8-pre4')",
			"INSERT INTO ".db_prefix("translations")." VALUES (0, 'en', 'news', '`&%s`& gelang die Flucht aus dem Totenreich.', '`&%s`& managed to escape from the shades.', 0, 'anpera', '0.9.8-pre4')",
			"INSERT INTO ".db_prefix("translations")." VALUES (0, 'en', 'module-styx', '`n`n`#Dir gelingt die Flucht aus dem Totenreich!`n`n`7Ersch�pft �ffnest du die Augen. Dein K�rper ben�tigt dringend Heilung, wenn du ihn nicht sofort wieder verlieren willst. Wie lange du tot warst, kannst du nicht sagen, aber sehr lange kann es nicht gewesen sein.', '`n`n`#You manage to escape from Death!`n`n`7Exhausted you open your eyes. Your body needs a healer at once, if you don\'t want to return to `\$Ramius`7. You can\'t tell how long you were dead, but it couldn\'t have been very long.', 0, 'anpera', '0.9.8-pre4')",
			"INSERT INTO ".db_prefix("translations")." VALUES (0, 'en', 'module-styx', '`7 Schlie�lich siehst du ein Licht am Horizont, aus dem der Fluss zu entspringen scheint. Eilig bewegst du dich darauf zu.', 'Finally you can see a light in front of you, where the river seems to come from. Quickly you move towards it.', 0, 'anpera', '0.9.8-pre4')",
			"INSERT INTO ".db_prefix("translations")." VALUES (0, 'en', 'module-styx', 'Nach %s', 'Go to %s', 0, 'anpera', '0.9.8-pre4')"
		);
		debug("Trying to insert english  translation into database");
		while (list($key,$sql)=each($sqls)){
			db_query($sql);
		}
	}
	// end translation 
	debug("adding eventhook");
	module_addeventhook("graveyard", "return 100;");
	return true;
}

function styx_uninstall(){
	output("Uninstalling River of Souls.`n");
	debug("Uninstalled River of Souls.");
	db_query("DELETE FROM ".db_prefix("translations")." WHERE uri LIKE 'module-styx'");
	return true;
}

function styx_runevent($type){
	global $session;
	$op = httpget('op');
	$subop = httpget('subop');
	$session['user']['specialinc'] = "module:styx";
	checkday();
	tlschema("module-styx"); // this is rude, but it still seems to be necessary with 0.9.8-prerelease.4 and should work with future releases as well

	if ($op=="enterdead"){ // try to escape from death
		$was=e_rand(1,4);
		if ($session['user']['gravefights']<=0) $was=4;
		output("`7Deine Seele folgt dem Fluss der Toten aufw�rts. Du siehst viele Seelen, die im Fluss mitgerissen werden, einige werden auf Booten von toten F�hrm�nnern gefahren und andere versuchen wie du die Flucht.");
		if($was==2){ // luckily escapes
			output("`7 Schlie�lich siehst du ein Licht am Horizont, aus dem der Fluss zu entspringen scheint. Eilig bewegst du dich darauf zu.");
			output("`n`n`#Dir gelingt die Flucht aus dem Totenreich!`n`n`7Ersch�pft �ffnest du die Augen. Dein K�rper ben�tigt dringend Heilung, wenn du ihn nicht sofort wieder verlieren willst. Wie lange du tot warst, kannst du nicht sagen, aber sehr lange kann es nicht gewesen sein.");
			$session['user']['alive']=1;
			$session['user']['hitpoints']=1;
			$session['user']['spirits']=-6;
			if ($session['user']['turns']>2) $session['user']['turns']-=2;
			addnav(array("Nach %s",$session['user']['location']),"village.php");
			addnews("`&%s`& gelang die Flucht aus dem Totenreich.",$session['user']['name']);
		}else{ // escape fails
			output("`7 Die vielen H�nde, die aus dem Fluss nach dir greifen, lassen dich nur langsam vorankommen. Schlie�lich zerren sie dich ganz in den Fluss. Du wirst zur�ck ins Totenreich geschwemmt - direkt vor `\$Ramius`7' F�sse.");
			output("`n`nDein Fluchtversuch ist gescheitert.");
		}
		$session['user']['specialinc']="";

	}elseif ($op=="leave"){ // leave special
		output("`7Du verl�sst den Flu� der Seelen und kehrst zum Friedhof zur�ck.");
		$session['user']['specialinc']="";
		$session['user']['specialmisc']="";

	}elseif ($op=="explore"){ // explore this place
		if ($subop=="favor"){ // buy a good word for favor by promising hatetepe 2 gems
			output("`7F�r ein paar mehr Gefallen bei `\$Ramius`7 w�rdest du sogar deine Seele verkaufen. Ups! Lieber doch nicht. So versprichst du dieser trotteligen Seele");
			output(" ein paar deiner Edelsteine, die dir hier unten ja sonst wirklich nichts n�tzen. Wie du `4Hatetepe`7 die Steinchen �bergeben sollst, ist dir in dem Moment egal - dir ");
			output("w�re es sogar recht, wenn er die Steine nie einfordern w�rde.`n");
			output("`4Hatetepe`7 verspricht, ein gutes Wort f�r dich bei `\$Ramius`7 einzulegen. Gerade als du ihn fragen willst, was er hier unten �berhaupt mit Edelsteinen anfangen will, ");
			output(" findest du dich auf dem Friedhof wieder...");
			$session['user']['deathpower']+=10;
			$session['user']['gems']-=2;
			$session['user']['specialinc']="";
			debuglog("spent 2 gems for 10 deathpower in graveyard");
		}elseif ($subop=="gem"){ // spend 5 favor to gain 1 gem
			output("`4Hatetepe`7 verspricht dir, einen Edelstein f�r dich im Dorf bereit zu legen. Gerade als du ihn fragen willst, wie er das schaffen will, ");
			output(" findest du dich auf dem Friedhof wieder...");
			$session['user']['gems']++;
			$session['user']['deathpower']-=5;
			$session['user']['specialinc']="";
			debuglog("bought 1 gem with 5 deathpower in graveyard");
		}elseif ($subop=="gf"){ // buy a grave fight
			output("`7Du versprichst `4Hatetepe`7 einen deiner hier unten v�llig wertlosen Edelsteine und findest dich pl�tzlich auf dem Friedhof wieder...");
			$session['user']['gravefights']++;
			$session['user']['gems']--;
			$session['user']['specialinc']="";
			debuglog("spent 1 gem for 1 gravefight in graveyard");
		}elseif ($subop=="gf3"){ // buy 3 grave fights
			output("`7Du versprichst `4Hatetepe`7 f�nf deiner hier unten v�llig wertlosen Edelsteine und findest dich pl�tzlich auf dem Friedhof wieder...");
			$session['user']['gravefights']+=3;
			$session['user']['gems']-=5;
			$session['user']['specialinc']="";
			debuglog("spent 5 gems for 3 gravefight in graveyard");
		}elseif ($subop=="spuken"){ // spooky messages on random place
			if ($session['user']['deathpower']<=0){ // not enough favor
				output("`7Du hast keine Gefallen mehr �brig, die du auf diese Weise verspielen k�nntest. Traurig dar�ber, dass du wohl gerade deine Chance, ");
				output(" heute noch aus dem Totenreich zu kommen, verspielt hast, machst du dich auf den Weg zur�ck zum Friedhof. ");
				$session['user']['specialinc']="";
				$session['user']['specialmisc']="";
			}else{ // chat with the world of the living
				$where=$session['user']['specialmisc'];
				output("`7Du verlierst einen Gefallen und nimmst mit der Welt der Lebenden Kontakt auf.`n Du hast noch `b`4%s`b`7 Gefallen.`n`n",$session['user']['deathpower']);
				addcommentary();
				viewcommentary("$where","Spuke",10,"seufzt von irgendwo her");
				addnav("Zum Friedhof","graveyard.php?op=leave");
				$session['user']['deathpower']--;
			}
		}else{ // what you find
			$what=e_rand(1,3);
			if ($session['user']['gravefights']<=0) $what=4;
			$result=db_fetch_assoc(db_query("SELECT section FROM ".db_prefix("commentary")." WHERE 1 ORDER BY rand(".e_rand().") LIMIT 1"));
			$where=$result['section'];
			if ($where=="" || $where=="shade" || $where=="superuser") $what=100; // if no result or result graveyard or admin don't offer chat
			$session['user']['specialmisc']=$where;
			if ($what==2){ // introduce hatetepe
				output("`7\"`!Sei gegr�sst!`7\", spricht dich eine alte Seele an, die schon seit Ewigkeiten hier zu sein scheint, \"`!Ich bin `4Hatetepe`!, ");
				output("der tote H�ndler, der nie gestorben ist, immer auf dem Sprung und schon ewig hier. Ich tausche hier meine Waren, die mir nie geh�rten. Sie bringen dir sowohl im Totenreich, wie auch");
				output(" im Reich der Lebenden einen Vorteil, der keiner ist. Also, kann ich dir materiellen oder spirituellen Besitz anbieten oder abkn�pfen?`7\"");
				addnav("Kaufen");
				if ($session['user']['gems']>0) addnav("1 Grabkampf  f�r 1 Edelstein","graveyard.php?op=explore&subop=gf");
				if ($session['user']['gems']>4) addnav("3 Grabk�mpfe f�r 5 Edelsteine","graveyard.php?op=explore&subop=gf3");
				if ($session['user']['deathpower']>4) addnav("1 Edelstein f�r 5 Gefallen","graveyard.php?op=explore&subop=gem");
				if ($session['user']['gems']>1) addnav("10 Gefallen f�r 2 Edelsteine","graveyard.php?op=explore&subop=favor");
				if ($session['user']['deathpower']>0) addnav("Spuken f�r Gefallen","graveyard.php?op=explore&subop=spuken");
				addnav("Sonstiges");
				modulehook("styx");
				addnav("Zum Friedhof","graveyard.php?op=leave");
			}elseif ($what==3 || $what==1){ // enable chat
				output("`7Du entdeckst eine M�glichkeit, mit der Welt der Lebenden in Verbindung zu treten! Allerdings wird dich dieses Unternehmen einiges ");
				output("an Gefallen kosten und wer und ob dich jemand h�ren wird, wissen nicht einmal die G�tter.");
				addnav("Spuken f�r Gefallen","graveyard.php?op=explore&subop=spuken");
				addnav("Zum Friedhof","graveyard.php?op=leave");
			}else{ // nothing can be found
				output("`7F�r einen Moment dachtest du, etwas gesehen zu haben, aber du entdeckst hier absolut nichts besonderes.");
				$session['user']['specialinc']="";
			}
		}
	}else{ // River of Souls intro
		if (!$session['user']['alive']){
			output("`7Du bemerkst einen seltsamen Schimmer und wandelst darauf zu.`nDu hast den `bFluss der Seelen`b gefunden! Jenen merkw�rdigen Ort, ");
			output("der angeblich das Reich der Toten und die Welt der Lebenden verbindet und wo all die toten Kreaturen herkommen, die einst den Wald und jetzt den Friedhof bev�lkern. Du witterst eine Chance, dem Totenreich zu entfliehen, aber du wei�t auch um die ");
			output("Gefahren einer solchen Unternehmung bescheid.`n`nWirst du den Fluchtversuch wagen? Oder willst du diesen sagenhaft Ort n�her untersuchen?"); 
			addnav("Fluchtversuch","graveyard.php?op=enterdead");
			addnav("Ort untersuchen","graveyard.php?op=explore");
			addnav("Zur�ck zum Friedhof","graveyard.php?op=leave");
		}else{
			redirect("village.php");
		}
	}
}
function styx_run(){
}
}
?>