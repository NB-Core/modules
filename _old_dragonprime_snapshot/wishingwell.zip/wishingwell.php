<?php
// A forest Special that i came up with, got alot of help from other modules.
function wishingWell_getmoduleinfo(){
	$info = array(
		"name"=>"Wishingwell",
		"version"=>"1.3",
		"author"=>"`@DaFish",
		"category"=>"Forest Specials",
		"download"=>"http://dragonprime.net/users/DaFish/wishingwell.zip",
		"vertxtloc"=>"http://dragonprime.net/users/DaFish/",
				);
				return $info;
}
function wishingwell_install(){
	module_addeventhook("forest", "return 100;");
	return true;
}

function wishingwell_uninstall(){
	return true;

}


function wishingwell_runevent($type)
{
	global $session;
	// We assume this event only shows up in the forest currently.
	$from = "forest.php?";
	$session['user']['specialinc'] = "module:wishingwell";

	$op = httpget('op');
	switch($op){
	case "search":
	case "":
		output("`n`3While you are traveling in the forest you have spotted an old well, a well that is almost hidden from view. As you approach the well you can sense a magical aura surrounding it, you then realise that the well is a `^wishingwell`3!`n`n");
		output("`3Curious about this `^wishingwell `3you decide to take a closer look. In it you can see a slide that leads to the bottom of the well.`n`n");
		output("Do you take a ride on the slide and make a wish?`n");
		addnav("Ride the slide and wish for Power",$from."op=power");
		addnav("Ride the slide and wish for Speed",$from."op=speed");
		addnav("Ride the slide and wish for Experience",$from."op=experience");
		addnav("Ride the slide and wish for Wealth",$from."op=wealth");
		addnav("Leave the wishingwell alone",$from."op=leave");
		break;
	case "power":
		output("`3You slide down the well screaming `^Powerrr...!`n`n");
		$rand = e_rand(1,5);
		switch ($rand) {
		case 1:
		case 2:
		case 3:
			output("As you hit the bottom of the slide you feel more powerful!`n`n");
			$wishingwellbuffrounds = e_rand(15,25);
						$wishingwellbuff = array(
							"name"=>"`&Well Power",
							"rounds"=>$wishingwellbuffrounds,
							"wearoff"=>"`7The effects of the Well Power has faded.",
							"defmod"=>1.0,
							"atkmod"=>1.2,
							"roundmsg"=>"`7You feel powerful as a aura surrounds you!",
							"schema"=>"module-wishingwell"
						);
						apply_buff("Well Power",$wishingwellbuff);
						$session['user']['specialinc']="";
			break;
		case 4:
		case 5:
			$loss = round ($session['user']['hitpoints'] * .7, 0);
			if ($loss > 0 && $session['user']['hitpoints'] > $loss) {
				output("`3The slide have left you with a burned bottom!`n`n");
				output("You `\$lose `^%s `6hitpoints!", $loss);
				$session['user']['hitpoints'] -= $loss;
			}else{
				output("It turns out to be one of those slides that don't work and you sit at the top waiting and waiting.");
				output("`n`nOh well.`n`n");
			}
			break;
		}
		$session['user']['specialinc']="";
		break;

	case "speed":
		$rand = e_rand(1,7);
		switch ($rand) {
		case 1:
			output("`3You slide down the well screaming `^Speeddd...!`n`n");
			output("`3You hit the bottom of the well unexpectedly! That was a super fast ride!`n`n");
			output("`^You have gained 2 turns!`n");
			$session['user']['turns'] += 2;
			break;
		case 2:
			output("`3You slide down the well screaming `^Speeddd...!`n`n");
			output("`3You hit the bottom of the well unexpectedly! That was a fast ride!`n`n");
			output("`^You have gained 1 turn!`n");
			$session['user']['turns'] += 1;
			break;
		case 3:
			output("`3Too excited about the possible rewards you forgot about making your wish. You hit the slide screaming `^weeee...`3!`n`n");
			output("`3You hit the bottom of the well with a `^SPLASH!`n`n");
			output("`^You are all drenched!`n`n");
			break;
		case 4:
		case 5:
			output("`3You slide down the well screaming `^Speeddd...!`n`n");
			output("`3You had fun riding down the slide.`n");
			output("`3You wish you could have another go!`n");
			break;
		case 6:
		case 7:
			output("`3You slide down the well screaming `^Speeddd...!`n`n");
			output("`3As you hit the bottom of the well, you realise that you can't get out of the well!`n`n");
			if($session['user']['turns'] >= 1){
				output("`^You lose 1 turn trying to get out of the well!`n");
				$session['user']['turns'] -= 1;
			}
			break;
		}
		$session['user']['specialinc']="";
		break;
	case "experience":

		$rand = e_rand(1,10);
		switch ($rand) {
			case 1:
			case 2:
			case 3:
				output("`3You slide down the well screaming `^Experienceee...!`n`n");
				output("`3You hit the bottom of the well only to be greeted by a mob of monsters!`n`n");
				output("`3You dispose of them easily.`n`n");
				$expgain = round($session['user']['experience'] * .02, 0);
				if ($expgain < 10) $expgain = 10;
				$session['user']['experience'] += $expgain;
				output ("`6You gain `^%s experience`6!`n", $expgain);
				break;
			case 4:
				output("`3You slide down the well screaming `^Experienceee...!`n`n");
				output("`3You hit the bottom of the well only to be greeted by a mob of monsters!`n`n");
				output("`3You almost lost your life as you killed the last of the monsters!`n`n");
				$expgain = round($session['user']['experience'] * .05, 0);
				if ($expgain < 10) $expgain = 10;
				$session['user']['experience'] += $expgain;
				output ("`6You gain `^%s experience`6!`n", $expgain);
				$loss = round ($session['user']['hitpoints'] * .7, 0);
				if ($loss > 0 && $session['user']['hitpoints'] > $loss) {
					output("You `\$lose `^%s `6hitpoints!", $loss);
					$session['user']['hitpoints'] -= $loss;
				}
				break;
			case 5:
				output("`3Too excited about the possible rewards you forgot about making your wish. You hit the slide screaming `^weeee...`3!`n`n");
				output("`3You hit the bottom of the well with a `^SPLASH`3!`n`n");
				output("`^You are all drenched!`n`n");
				break;
			case 6:
			case 7:
			case 8:
			case 9:
			case 10:
				output("`3You slide down the well screaming `^Experienceee...!`n`n");
				output("`3You hit the bottom of the well only to be greeted by a mob of monsters!`n`n");
				output("`3You were mobbed by the monsters!`n`n");
				$loss = round ($session['user']['hitpoints'] * .7, 0);
					if ($loss > 0 && $session['user']['hitpoints'] > $loss) {
						output("You `\$lose `^%s `6hitpoints!", $loss);
						$session['user']['hitpoints'] -= $loss;
					}
				break;
		}
		$session['user']['specialinc']="";
		break;
	case "wealth":
		$rand = e_rand(1,6);
		switch ($rand) {
			case 1:
			case 2:
			case 3:
				output("`3You slide down the well screaming `^Wealtthh...!`n`n");
				output("`3You hit the bottom of the well with a clank, the sound of Gold!`n`n");
				$rewardgold = $session['user']['level']*50;
				$session['user']['gold'] += $rewardgold;
				$rewardamt = e_rand(1,3);
				$session['user']['gems'] += $rewardamt;
				output("`3 You have gained %s `6gold `3and %s `%gem`3.`n", $rewardgold, $rewardamt);
				break;
			case 4:
			case 5:
				output("`3You slide down the well screaming `^Wealtthh...!`n`n");
				output("`3You hit the bottom of the well with hundreds of books around you.`n");
				output("`3Disappointed, you mutter to your self about this is not the wealth that you had in mind.`n`n");
				break;
			case 6:
				output("`3You slide down the well screaming `^Wealtthh...!`n`n");
				output("`3You hit the bottom of the well with nothing.`n`n");
				output("`3Greed never comes to any good`n");
				break;
		}
		$session['user']['specialinc']="";
		break;

	case "leave":
			output("`^You stare at the well for a few more moments trying to get the courage to explore it. Suddenly the well emits a crimson glow that sends a cold chill down your spine.  At this point you have decided to stay on the main trail.  You quickly move away from the mysterious well.");
			$session['user']['specialinc']="";
			break;
	}
	output_notl("`0");


}

//function waterfall_run(){
//}
?>
