<?

function multichecker_getmoduleinfo(){
$info = array(
	"name"=>"Multichecker",
	"version"=>"1.0",
	"author"=>"`2Oliver Brendel",
	"override_forced_nav"=>true,
	"category"=>"Multichecker",
	"download"=>"http://dragonprime.net/dls/multichecker.zip",
	);
	return $info;
}

function multichecker_install(){
	if (!is_module_active('multichecker')){
		output_notl("`n`c`b`QMulti-Checker Module - Installed`0`b`c");
	}else{
		output_notl("`n`c`b`QMulti-Checker Module - Updated`0`b`c");
	}
	module_addhook("superuser");
	return true;
}

function multichecker_uninstall(){
	output_notl("`n`c`b`QMultichecker Module - Uninstalled`0`b`c");
	return true;
}

function multichecker_dohook($hookname, $args){
	global $session;
	switch ($hookname) {
		case "superuser":
			if ($session['user']['superuser'] & SU_MEGAUSER) { //only access for megausers
				addnav("Mechanics");
				addnav("Multichecker","runmodule.php?module=multichecker&op=selfID");
			}
			break;
	}
	return $args;
}

function multichecker_run(){
	global $session;
	$op = httpget('op');
	require_once("./lib/superusernav.php");
	superusernav();
	page_header("Multichecker");
	addnav("Check by IP","runmodule.php?module=multichecker&op=IP");
	addnav("Check for self-referral by IP","runmodule.php?module=multichecker&op=selfIP");	
	addnav("Check by Cookie ID","runmodule.php?module=multichecker&op=ID");
	addnav("Check for self-referral by ID","runmodule.php?module=multichecker&op=selfID");		

	switch ($op) {
		case "IP":
			$sql="SELECT a.login as UserA, a.acctid as AcctidA,b.login as UserB,b.acctid as AcctidB,
				a.lastip as IP, b.referer as referer, a.emailaddress as emailA, b.emailaddress as emailB
				FROM  ".db_prefix("accounts")."  AS b
				LEFT JOIN  ".db_prefix("accounts")." AS a
				ON b.lastip = a.lastip WHERE b.login <> a.login
				ORDER BY a.acctid";
			output("Note: AOL proxys have always the same IP, AOL users are therefore treated as multis.");
			output_notl("`n`n");
			output("University and other nets who have one proxy IP will also appear here, please check them carefully.");
			break;
		case "ID":
			$sql="SELECT a.login as UserA, a.acctid as AcctidA,b.login as UserB,b.acctid as AcctidB,
				a.uniqueid as IP, b.referer as referer,	a.emailaddress as emailA, b.emailaddress as emailB
				FROM  ".db_prefix("accounts")."  AS b
				LEFT JOIN  ".db_prefix("accounts")." AS a
				ON b.uniqueid = a.uniqueid WHERE b.login <> a.login
				ORDER BY a.acctid";
			output("Note: The ID is the cookie ID stored on the users machine.");
			output(" If he uses another browser, you won't be able to track him down.");
			output(" This check should be used WITH the IP check, because here you won't have to care for proxies like AOL, University nets and the like.");
			break;
		case "selfIP":
			$sql="SELECT a.login as UserA, a.acctid as AcctidA,b.login as UserB,b.acctid as AcctidB,
				a.lastip as IP, b.referer as referer, a.emailaddress as emailA, b.emailaddress as emailB
				FROM  ".db_prefix("accounts")."  AS b
				LEFT JOIN  ".db_prefix("accounts")." AS a
				ON b.lastip = a.lastip WHERE b.login <> a.login 
				AND b.referer=a.acctid 
				ORDER BY a.acctid";
			output("Note: AOL proxys have always the same IP, AOL users are therefore treated as multis.");
			output_notl("`n`n");
			output("University and other nets who have one proxy IP will also appear here, please check them carefully.");
			break;
		case "selfID":
			$sql="SELECT a.login as UserA, a.acctid as AcctidA,b.login as UserB,b.acctid as AcctidB,
				a.uniqueid as IP, b.referer as referer,	a.emailaddress as emailA, b.emailaddress as emailB
				FROM  ".db_prefix("accounts")."  AS b
				LEFT JOIN  ".db_prefix("accounts")." AS a
				ON b.uniqueid = a.uniqueid WHERE b.login <> a.login
				AND b.referer=a.acctid
				ORDER BY a.acctid";
			output("Note: The ID is the cookie ID stored on the users machine.");
			output(" If he uses another browser, you won't be able to track him down.");
			output(" This check should be used WITH the IP check, because here you won't have to care for proxies like AOL, University nets and the like.");
			break;
	}
	$result=db_query($sql);
	$i=0;
	rawoutput("<table border='0' cellpadding='2' cellspacing='0'>");
	rawoutput("<tr class='trhead'><td>". translate_inline("Name A")."</td><td>".translate_inline("Acctid")."</td><td>". translate_inline("Name B")."</td><td>".translate_inline("Acctid")."</td><td>".translate_inline("Referer")."</td><td>".translate_inline("IP/ID")."</td><td>".translate_inline("Email A")."</td><td>".translate_inline("Email B")."</td></tr>");
	$old=array();
	while ($row=db_fetch_assoc($result)) {
		if (!in_array($row['AcctidB'],$old)) {
			$i++;
			rawoutput("<tr class='".($i%2?"trlight":"trdark")."'><td>");
			output_notl($row['UserA']);
			rawoutput("</td><td>");
			if ($row['AcctidA']==$row['referer']) output_notl("`\$");
			output_notl($row['AcctidA']);
			rawoutput("</td><td>");
			if ($row['AcctidA']==$row['referer']) output_notl("`\$");
			output_notl($row['UserB']);
			rawoutput("</td><td>");
			if ($row['AcctidA']==$row['referer']) output_notl("`\$");
			output_notl($row['AcctidB']);
			rawoutput("</td><td>");
			if ($row['AcctidA']==$row['referer']) output_notl("`\$");
			output_notl($row['referer']);
			rawoutput("</td><td>");
			output_notl($row['IP']);
			rawoutput("</td><td>");
			output_notl($row['emailA']);
			rawoutput("</td><td>");
			output_notl($row['emailB']);
			rawoutput("</td></tr>");
			array_push($old,$row['AcctidA']);
			array_push($old,$row['AcctidB']);
		}
	}
	rawoutput("</table>");
	page_footer();

}
?>