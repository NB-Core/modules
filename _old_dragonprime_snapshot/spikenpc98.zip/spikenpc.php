<?php
function spikenpc_getmoduleinfo(){
	$info = array(
		"name"=>"NPC Characters - Spike",
		"version"=>"1.21",
		"author"=>"`3Original code by `#Lonny Luberts `3modified by `%Jim Lunsford",
		"category"=>"NPCs",
		"download"=>"http://dragonprime.net/users/Jim/spikenpc98.zip",
		"settings"=>array(
			"NPC Characters - Spike Module Settings,title",
			"npcloc"=>"Where does Spike Hang Out?,location|".getsetting("villagename", LOCATION_FIELDS),
			"howmuch"=>"How much does Spike say?,enum,1500,A Lot,2000,Quite a Bit,2500,Less,3000,Seldom",
			"comment1"=>"Custom commentary 1,text|I am insane. Whats your excuse?",
			"comment2"=>"Custom commentary 2,text|I love syphilis more than you.",
			"comment3"=>"Custom commentary 3,text|I know you haven't been in the game for awhile mate, but we still do kill people.",
			"npcid"=>"NPC User id,int",
			"sex"=>"NPC Sex,enum,0,Male,1,Female",
			"name"=>"NPC Name,text|`!Vampire `1Spike",
		),
	);
	return $info;
}

function spikenpc_install(){
	$password=$_POST['pw'];
	if (!is_module_active('spikenpc')){
		output("`4Installing NPC Characters - Spike Module.`n");
		if ($password){
		$sqlz = "INSERT INTO ".db_prefix("accounts")." (login,name,sex,specialty,level,defense,attack,alive,laston,hitpoints,maxhitpoints,gems,password,emailvalidation,title,weapon,armor,race) VALUES ('spikenpc','`!Vampire `1Spike','0','1','15','1000','1000','1','".date("Y-m-d H:i:s")."','1000','1000','10','".md5(md5("$password"))."','','`!Vampire','`#Ale Mug','`!Bar Tray','Human')";
		db_query($sqlz) or die(db_error(LINK));
			if (db_affected_rows(LINK)>0){
				output("`2Installed Spike!`n");
			}else{
				output("`4Spike install failed!`n");
			}
			$sqlz = "SELECT acctid FROM ".db_prefix("accounts")." where login = 'spikenpc'";
			$resultz = mysql_query($sqlz) or die(db_error(LINK));
			$rowz = db_fetch_assoc($resultz);
			if ($rowz['acctid'] > 0){
				set_module_setting("npcid",$rowz['acctid']);
				output("`2Set Accout ID for Spike to ".$rowz['acctid'].".`n");
			}else{
				output("`4Failed to Set Account ID for Spike!`n");
			}
		}else{
			$sqlz = "SELECT acctid FROM ".db_prefix("accounts")." where login = 'spikenpc'";
			$resultz = mysql_query($sqlz) or die(db_error(LINK));
			$rowz = db_fetch_assoc($resultz);
			if ($rowz['acctid'] > 0){
			}else{
				output("Spike's Login will be spikenpc.`n");
				output("What would you like the password for Spike's account to be?`n");
				$linkcode="<form action='modules.php?op=install&module=spikenpc' method='POST'>";
				output("%s",$linkcode,true);
				$linkcode="<p><input type=\"text\" name=\"pw\" size=\"37\"></p>";
				output("%s",$linkcode,true);
				$linkcode="<p><input type=\"submit\" value=\"Submit\" name=\"B1\"><input type=\"reset\" value=\"Reset\" name=\"B2\"></p>";
				output("%s",$linkcode,true);
				$linkcode="</form>";
				output("%s",$linkcode,true);
				addnav("","modules.php?op=install&module=spikenpc");
			}
		}
	}else{
		output("`4Updating NPC Characters - Spike Module.`n");
	}
	module_addhook("village");
	return true;
}

function spikenpc_uninstall(){
	output("`4Un-Installing NPC Characters - Spike Module.`n");
	$sqlz = "DELETE FROM ".db_prefix("accounts")." where acctid='".get_module_setting('npcid')."'";
	mysql_query($sqlz) or die(db_error(LINK));
	output("Spike deleted.`n");
	return true;
}

function spikenpc_dohook($hookname,$args){
	global $session,$texts;
			if (get_module_setting('lastupdate') < date("Y-m-d H:i:s")){
				set_module_setting('lastupdate',date("Y-m-d H:i:s",strtotime("+ 300 seconds")));
				$sqlz2="UPDATE ".db_prefix("accounts")." SET laston = '".date("Y-m-d H:i:s",strtotime("+ 300 seconds"))."', alive = '1', loggedin = '1', lasthit = '".date("Y-m-d H:i:s",strtotime("+ 300 seconds"))."', location = '".get_module_setting('npcloc')."', hitpoints = '1000' WHERE acctid = '".get_module_setting('npcid')."'";
				mysql_query($sqlz2) or die(db_error(LINK));
				$sqlz2 = "DELETE FROM ".db_prefix("mail")." WHERE msgto='".get_module_setting('npcid')."'";
				mysql_query($sqlz2) or die(db_error(LINK));
			}
			//now lets say something
			$howmuch = e_rand(1,get_module_setting('howmuch'));
			if (get_module_setting('npcloc') == $session['user']['location'] AND $howmuch < 100){
			//set smilies
			$j = e_rand(1,20);
			$smile = array(1=>"*grin*",2=>"*happy*",3=>"*laugh*",4=>"*wink*",5=>"*slimer*",6=>"*biggrin*",7=>"*tongue*",8=>"*wink2*",9=>"*wink3*",10=>"",11=>"",12=>"",13=>"",14=>"",15=>"",16=>"",17=>"",18=>"",19=>"",20=>"");
			//end set smilies
						
			//setup commentary array
			$k = e_rand(1,51);
			$sayit = array(
						1=>get_module_setting('comment1'),
						2=>get_module_setting('comment1'),
						3=>get_module_setting('comment2'),
						4=>get_module_setting('comment2'),
						5=>get_module_setting('comment3'),
						6=>get_module_setting('comment3'),
						7=>"Hello everyone. ".$smile[$j]." ",
						8=>"Have you seen Buffy? ",
						9=>"You want me to leave, you can put your hands on my hot tight little body and make me! ",
						10=>"Blood is life, lackbrain. Why do you think we eat it? It's what keeps you going, makes you warm, makes you hard, makes you other than dead. ",
						11=>"What is it with you people? ",
						12=>"What can I tell you, baby? I've always been bad. ",
						13=>"::gives ".$session['user']['name']." a hug and inspects the neck ",
						14=>"What has one got to do to get a little attention around here? ",
						15=>"Ack....",
						16=>"::sits around waiting for words or wisdom to come from SOMEONE. ",
						17=>"Beat it mate! ",
						18=>"Oh, I'm sorry baby. I'm a bad, rude man. ",
						19=>"Bloody hell! ",
						20=>"Where is the Scooby Gang?",
						21=>":: slams an Ale ".$smile[$j]." ",
						22=>":: falls asleep ".$smile[$j]." ",
						23=>":: slaps ".$session['user']['name']." ".$smile[$j]." ",
						24=>":: wishes ".(get_module_setting('sex')?"she":"he")." were a real person ".$smile[$j]." ",
						25=>"What? ".$smile[$j]." ",
						26=>"Yeah, o.k. Sorry. ".$smile[$j]." ",
						27=>"Are you crazy? ".$smile[$j]." ",
						28=>"Someone let me out of this game! ".$smile[$j]." ",
						29=>"Mark my words: the Slayer is going to kick your skanky, lopsided ass back to whatever place would take a cheap, whorish, fashion-victim, ex-god like you. ".$smile[$j]." ",
						30=>"Huh? ".$smile[$j]." ",
						31=>"Hi ".$session['user']['name']." ".$smile[$j]." ",
						32=>"Hey ".$session['user']['name']." ".$smile[$j]." ",
						33=>"*news*".get_module_setting('name')." `7has fallen and can't get up.",
						34=>"*news*".$session['user']['name']." `7has fallen and can't get up.",
						35=>"*news*".get_module_setting('name')." `7has a few too many ale's at the inn.",
						36=>"::pokes ".$session['user']['name'],
						37=>":: kicks ".$session['user']['name']." ".$smile[$j]." ",
						38=>":: Gives ".$session['user']['name']." `&a wedgie. ".$smile[$j]." ",
						39=>":: puts a kick-me sign on ".$session['user']['name']."'s `&back ".$smile[$j]." ",
						40=>":: takes ".$session['user']['name']."'s ".$session['user']['weapon']." `&and shoves it up their nose. ".$smile[$j]." ",
						41=>"You want a piece of me ".$session['user']['name']."\? ".$smile[$j]." ",
						42=>"Do you smell something bad?  Oh it's just ".$session['user']['name']."\. ".$smile[$j]." ",
						43=>$session['user']['name']." may look like an idiot and talk like an idiot but don't let that fool you. ".($session['user']['sex']?"She":"He")." really is an idiot. ".$smile[$j]." ",
						44=>$session['user']['name']."  Are you always this stupid or are you making a special effort today? ".$smile[$j]." ",
						45=>$session['user']['name']."  Don't let you mind wander - it's far too small to be let out on its own ".$smile[$j]." ",
						46=>$session['user']['name']."  doesn't know the meaning of the word fear - but then again ".($session['user']['sex']?"she":"he")." doesn't know the meaning of most words. ".$smile[$j]." ",
						47=>$session['user']['name']."  I'm gonna destroy the world! Wanna Help? ".$smile[$j]." ",
						48=>"Hey ".$session['user']['name']." That's right, I'm back and I'm a bloody animal! Yeah! ".$smile[$j]." ",
						49=>"Hey ".$session['user']['name']." Let's kill something.  ".$smile[$j]." ",
						50=>"Hey ".$session['user']['name']." Get up, get out, get drunk. Repeat as needed.  ".$smile[$j]." ",
						51=>"Hey ".$session['user']['name']." This place which has witnessed some truly spectacular kickings of my ass.  ".$smile[$j]." ",
						);
			//end setup commentary array
			if (strchr($sayit[$k],"*news*")){
				addnews(str_replace("*news*","",$sayit[$k]));
			}else{
				mysql_query("INSERT INTO ".db_prefix("commentary")." (postdate,section,author,comment) VALUES (now(),'".$texts['section']."','".get_module_setting('npcid')."',\"".$sayit[$k]."\")");
			}
	}
}
?>