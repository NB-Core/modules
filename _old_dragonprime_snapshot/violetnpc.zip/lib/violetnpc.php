<?php
function violetnpc_update(){
	set_module_setting('lastupdate',date("Y-m-d H:i:s",strtotime("+ 300 seconds")));
	$sqlz2="UPDATE ".db_prefix("accounts")." SET laston = '".date("Y-m-d H:i:s",strtotime("+ 300 seconds"))."', alive = '1', loggedin = '1', lasthit = '".date("Y-m-d H:i:s",strtotime("+ 300 seconds"))."', location = '".get_module_setting('npcloc')."', hitpoints = '1000' WHERE acctid = '".get_module_setting('npcid')."'";
	db_query($sqlz2);
	$sqlz2 = "DELETE FROM ".db_prefix("mail")." WHERE msgto='".get_module_setting('npcid')."'";
	db_query($sqlz2);
}

function violetnpc_comment(){
			global $session,$texts;
			//set smilies
			$j = e_rand(1,20);
			$smile = array(1=>"*grin*",2=>"*happy*",3=>"*laugh*",4=>"*wink*",5=>"*slimer*",6=>"*biggrin*",7=>"*tongue*",8=>"*wink2*",9=>"*wink3*",10=>"",11=>"",12=>"",13=>"",14=>"",15=>"",16=>"",17=>"",18=>"",19=>"",20=>"");
			//end set smilies
			
			//set comments for installed modules
			if (is_module_active('weather')){
				$comm9 = "How bout that weather? I see it's ".get_module_setting('weather','weather')." *biggrin*";
			}else{
				$comm9 = "How bout that weather?";
			}
			if (is_module_active('lonnycastle')){
				$sqlz4 = "SELECT name,acctid,value FROM ".db_prefix("accounts")." LEFT JOIN ".db_prefix("module_userprefs")." ON (acctid = userid) WHERE modulename = 'lonnycastle' and setting = 'evil' ORDER BY RAND(".e_rand().") LIMIT 1";
				$resultz4 = db_query($sqlz4);
			    $rowz4 = db_fetch_assoc($resultz4);
				if ($rowz4['value']>=33) $evil="Evil";
				if ($rowz4['value']<33 and $rowz4['value']>-32) $evil="Neutral";
				if ($rowz4['value']<=-32) $evil="Good";
				$comm10 = "I hear that ".$rowz4['name']." is ".$evil.". *shocked*";
				db_free_result($resultz4);
			}else{
				$comm10 = "What's up?";
			}
			if (is_module_active('jobs')){
				$sqlz4 = "SELECT name,value FROM ".db_prefix("accounts")." LEFT JOIN ".db_prefix("module_userprefs")." ON (acctid = userid) WHERE modulename = 'jobs' and setting = 'job' ORDER BY RAND(".e_rand().") LIMIT 1";
				$resultz4 = db_query($sqlz4);
			    $rowz4 = db_fetch_assoc($resultz4);
				if ($rowz4['value']==0) $job="Slacker";	
				if ($rowz4['value']==1) $job="Farmer";
				if ($rowz4['value']==2) $job="Miller";
				if ($rowz4['value']==3) $job="Textile Miller";
				if ($rowz4['value']==4) $job="Brewer";
				if ($rowz4['value']==5) $job="Foundry Worker";
				if ($rowz4['value']==6) $job="Farm Manager";
				if ($rowz4['value']==7) $job="Mill Manager";
				if ($rowz4['value']==8) $job="Textile Mill Manager";
				if ($rowz4['value']==9) $job="Brewery Manager";
				if ($rowz4['value']==10) $job="Foundry Manager";
				$comm11 = "I hear that ".$rowz4['name']." is a ".$job.". *wink*";
				db_free_result($resultz4);
			}else{
				$comm11 = "What has one got to do to get a little attention around here?";
			}
			$sqlz4 = "SELECT name,charm FROM ".db_prefix("accounts")." ORDER BY RAND(".e_rand().") LIMIT 1";
			$resultz4 = db_query($sqlz4);
		    $rowz4 = db_fetch_assoc($resultz4);
			if ($rowz4['charm'] > -1 and $rowz4['charm'] < 4) $charm="pretty darn ugly";
			if ($rowz4['charm'] > 3 and $rowz4['charm'] < 7) $charm="ugly";
			if ($rowz4['charm'] > 6 and $rowz4['charm'] < 11) $charm="average";
			if ($rowz4['charm'] > 10 and $rowz4['charm'] < 14) $charm="cute";
			if ($rowz4['charm'] > 13 and $rowz4['charm'] < 17) $charm="looking good";
			if ($rowz4['charm'] > 16 and $rowz4['charm'] < 20) $charm="Beautiful";
			if ($rowz4['charm'] > 19 and $rowz4['charm'] < 23) $charm="Hot`n";
			if ($rowz4['charm'] > 22 and $rowz4['charm'] < 27) $charm="Smokin' Hot";
			if ($rowz4['charm'] > 26 and $rowz4['charm'] < 30) $charm="Dreamy";
			if ($rowz4['charm'] > 29) $charm="one of the fairest in the land";
			$comm12 = "I hear that ".$rowz4['name']." is ".$charm.". *wink2*";
			db_free_result($resultz4);
			if (is_module_active('garlandstable')){
				$comm13 = "I hear that Garland's Stables offer a really unique mount. ".$smile[$j]." ";
			}else{
				$comm13 = "Ack....";
			}
			if (is_module_active('lonnycastle')){
				$comm14 = "I've heard tales of ghosts in ".get_module_setting('castleloc','lonnycastle')." Castle. ".$smile[$j]." ";
			}else{
				$comm14 = "::sits around waiting for words or wisdom to come from SOMEONE.";
			}
			if (is_module_active('voodoopriestess')){
				$comm15 = "You can cast a spell on someone at the Voodoo Priestess. ".$smile[$j]." ";
			}else{
				$comm15 = "Beat it loser!";
			}
			if (is_module_active('potions')){
				$comm16 = "The Village Healer sells potions that you can carry along with you. ".$smile[$j]." ";
			}else{
				$comm16 = "Stop by the healers huts to heal them there wounds.";
			}
			if (is_module_active('vesa')){
				$comm17 = "Gems are sometimes available at the Gem Store. ".$smile[$j]." ";
			}else{
				$comm17 = "Gems are most often found in the forest.";
			}
			if (is_module_active('petra')){
				$comm18 = "One can get tatooed at Petra's. ".$smile[$j]." ";
			}else{
				$comm18 = "Is there anyone here with and IQ larger than their shoe size?";
			}
			if (is_module_active('pqgiftshop')){
				$comm19 = "Buy gifts for me or someone else at the giftshop. ".$smile[$j]." ";
			}else{
				$comm19 = "I think not.";
			}
			if (is_module_active('trading')){
				$comm20 = "Earn Gems and Gold trading at the various Trading Posts! ".$smile[$j]." ";
			}else{
				$comm20 = "Doh!";
			}
			//end set comments for installed modules
			
			//setup commentary array
			$k = e_rand(1,51);
			$sayit = array(
						1=>get_module_setting('comment1'),
						2=>get_module_setting('comment1'),
						3=>get_module_setting('comment2'),
						4=>get_module_setting('comment2'),
						5=>get_module_setting('comment3'),
						6=>get_module_setting('comment3'),
						7=>"Hello everyone. ".$smile[$j]." ",
						8=>"What's up? *biggrin*",
						9=>$comm9,
						10=>$comm10,
						11=>$comm11,
						12=>$comm12,
						13=>$comm13,
						14=>$comm14,
						15=>$comm15,
						16=>$comm16,
						17=>$comm17,
						18=>$comm18,
						19=>$comm19,
						20=>$comm20,
						21=>":: slams an Ale ".$smile[$j]." ",
						22=>":: falls asleep ".$smile[$j]." ",
						23=>":: slaps ".$session['user']['name']." ".$smile[$j]." ",
						24=>":: wishes ".(get_module_setting('sex')?"she":"he")." were a real person ".$smile[$j]." ",
						25=>"What? ".$smile[$j]." ",
						26=>"Are you nuts? ".$smile[$j]." ",
						27=>"Are you crazy? ".$smile[$j]." ",
						28=>"Someone let me out of this game! ".$smile[$j]." ",
						29=>"This one time at Band Camp.... ".$smile[$j]." ",
						30=>"Huh? ".$smile[$j]." ",
						31=>"Hi ".$session['user']['name']." ".$smile[$j]." ",
						32=>"Hey ".$session['user']['name']." ".$smile[$j]." ",
						33=>"*news*".get_module_setting('name')." `7has fallen and can't get up.",
						34=>"*news*".$session['user']['name']." `7has fallen and can't get up.",
						35=>"*news*".get_module_setting('name')." `7has a few too many ale's at the inn.",
						36=>"::pokes ".$session['user']['name'],
						37=>":: kicks ".$session['user']['name']." ".$smile[$j]." ",
						38=>":: Gives ".$session['user']['name']." `&a wedgie. ".$smile[$j]." ",
						39=>":: puts a kick-me sign on ".$session['user']['name']."'s `&back ".$smile[$j]." ",
						40=>":: takes ".$session['user']['name']."'s ".$session['user']['weapon']." `&and shoves it up their nose. ".$smile[$j]." ",
						41=>"You want a piece of me ".$session['user']['name']."\? ".$smile[$j]." ",
						42=>"Do you smell something bad?  Oh it's just ".$session['user']['name']."\. ".$smile[$j]." ",
						43=>$session['user']['name']." may look like an idiot and talk like an idiot but don't let that fool you. ".($session['user']['sex']?"She":"He")." really is an idiot. ".$smile[$j]." ",
						44=>$session['user']['name']."  Are you always this stupid or are you making a special effort today? ".$smile[$j]." ",
						45=>$session['user']['name']."  Don't let you mind wander - it's far too small to be let out on its own ".$smile[$j]." ",
						46=>$session['user']['name']."  doesn't know the meaning of the word fear - but then again ".($session['user']['sex']?"she":"he")." doesn't know the meaning of most words. ".$smile[$j]." ",
						47=>$session['user']['name']."  Oh my God, look at you. Anyone else hurt in the accident? ".$smile[$j]." ",
						48=>"Hey ".$session['user']['name']." do you still love nature, despite what it did to you? ".$smile[$j]." ",
						49=>"Hey ".$session['user']['name']." I've seen people like you before, but I had to pay admission!  ".$smile[$j]." ",
						50=>"Hey ".$session['user']['name']." how did you get here? Did someone leave your cage open?  ".$smile[$j]." ",
						51=>"Hey ".$session['user']['name']." you've got the perfect weapon - yer face.  ".$smile[$j]." ",
						);
			//end setup commentary array
			if (strchr($sayit[$k],"*news*")){
				addnews(str_replace("*news*","",$sayit[$k]));
			}else{
				db_query("INSERT INTO ".db_prefix("commentary")." (postdate,section,author,comment) VALUES (now(),'".$texts['section']."','".get_module_setting('npcid')."',\"".$sayit[$k]."\")");
			}
}
?>