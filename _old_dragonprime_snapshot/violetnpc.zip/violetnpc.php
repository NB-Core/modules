<?php
function violetnpc_getmoduleinfo(){
	$info = array(
		"name"=>"NPC Characters - Violet",
		"version"=>"2.0",
		"author"=>"`#Lonny Luberts",
		"category"=>"NPCs",
		"download"=>"http://www.pqcomp.com/modules/mydownloads/visit.php?cid=3&lid=24",
		"vertxtloc"=>"http://www.pqcomp.com/",
		"settings"=>array(
			"NPC Characters - Violet Module Settings,title",
			"npcloc"=>"Where does Violet Hang Out?,location|".getsetting("villagename", LOCATION_FIELDS),
			"howmuch"=>"How much does Violet say?,enum,1500,A Lot,2000,Quite a Bit,2500,Less,3000,Seldom",
			"comment1"=>"Custom commentary 1,text|A Barmaid's Work is never done.",
			"comment2"=>"Custom commentary 2,text|Come over to the Inn... I will get you a refreshment.",
			"comment3"=>"Custom commentary 3,text|So many warriors - so little time.",
			"npcid"=>"NPC User id,int",
			"sex"=>"NPC Sex,enum,1,Female,0,Male",
			"name"=>"NPC Name,text|`%Barmaid `5Violet",
		),
	);
	return $info;
}

function violetnpc_install(){
	$password=$_POST['pw'];
	if (!is_module_active('violetnpc')){
		output("`4Installing NPC Characters - Violet Module.`n");
		if ($password){
		$sqlz = "INSERT INTO ".db_prefix("accounts")." (login,name,sex,specialty,level,defense,attack,alive,laston,hitpoints,maxhitpoints,gems,password,emailvalidation,title,weapon,armor,race) VALUES ('violetnpc','`%Barmaid `5Violet','1','1','15','1000','1000','1','".date("Y-m-d H:i:s")."','1000','1000','10','".md5(md5("$password"))."','','`%Barmaid','`#Ale Mug','`!Bar Tray','Human')";
		db_query($sqlz);
			if (db_affected_rows(LINK)>0){
				output("`2Installed Violet!`n");
			}else{
				output("`4Violet install failed!`n");
			}
			db_free_result($resultz);
			$sqlz = "SELECT acctid FROM ".db_prefix("accounts")." where login = 'violetnpc'";
			$resultz = db_query($sqlz);
			$rowz = db_fetch_assoc($resultz);
			if ($rowz['acctid'] > 0){
				set_module_setting("npcid",$rowz['acctid']);
				output("`2Set Accout ID for Violet to ".$rowz['acctid'].".`n");
			}else{
				output("`4Failed to Set Account ID for Violet!`n");
			}
			db_free_result($resultz);
		}else{
			$sqlz = "SELECT acctid FROM ".db_prefix("accounts")." where login = 'violetnpc'";
			$resultz = db_query($sqlz);
			$rowz = db_fetch_assoc($resultz);
			if ($rowz['acctid'] > 0){
			}else{
				output("Violet's Login will be violetnpc.`n");
				output("What would you like the password for violets account to be?`n");
				$linkcode="<form action='modules.php?op=install&module=violetnpc' method='POST'>";
				output("%s",$linkcode,true);
				$linkcode="<p><input type=\"text\" name=\"pw\" size=\"37\"></p>";
				output("%s",$linkcode,true);
				$linkcode="<p><input type=\"submit\" value=\"Submit\" name=\"B1\"><input type=\"reset\" value=\"Reset\" name=\"B2\"></p>";
				output("%s",$linkcode,true);
				$linkcode="</form>";
				output("%s",$linkcode,true);
				addnav("","modules.php?op=install&module=violetnpc");
			}
			db_free_result($resultz);
		}
	}else{
		output("`4Updating NPC Characters - Violet Module.`n");
	}
	if (is_module_active('whoshere')){
		set_module_pref('playerloc',"village.php",'whoshere',get_module_setting('npcid'));
	}
	module_addhook("village");
	return true;
}

function violetnpc_uninstall(){
	output("`4Un-Installing NPC Characters - Violet Module.`n");
	$sqlz = "DELETE FROM ".db_prefix("accounts")." where acctid='".get_module_setting('npcid')."'";
	db_query($sqlz);
	output("Violet deleted.`n");
	return true;
}

function violetnpc_dohook($hookname,$args){
	global $session;
	if (get_module_setting('lastupdate') < date("Y-m-d H:i:s")){
		require_once("modules/lib/violetnpc.php");
		violetnpc_update();
	}
	if (get_module_setting('npcloc') == $session['user']['location'] AND e_rand(1,get_module_setting('howmuch')) < 21){
		require_once("modules/lib/violetnpc.php");
		violetnpc_comment();
	}
	return $args;
}


?>