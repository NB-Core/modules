<?php
//Made by
//Morpheus aka Apollon
//2005 for logd.at (LoGD 0.9.7 +jt ext (GER) 3)
//Mail to Morpheus@magic.ms or Apollon@magic.ms
//Don`t forget to change the name of the city and the addnavs
require_once "common.php";
page_header("The city wall");
if($HTTP_GET_VARS['op']=="")
	{
    page_header("The city wall");
	output("`n`gYou walk from the city place to the `7city wall`g, cause you have something to hide before the `%city guards`g. You know a secret `Tdoor `gin the `7city wall`g, which you can use. Now you stand before the `7city wall`g, which is over grown by `2shrubs `gand `2ivy�, and you can see the place of the `Tdoor`g, which is not always watched by the `%guards`g.`n`n");
	output("`gWhat will you do know?`n`n");
	addnav("The city wall");
	addnav("Try to sneak out of town","citywall1.php?op=sneak");
	addnav("Maybe i'll get through the city gates","citygate.php");
	addnav("Hm, back to the city","village.php");
	}
if ($_GET[op]=="sneak")
{
output("`c`b`7The city wall`0`b`c`n");
output("`gCarefully you walk forward to the `7wall `gan pull some thick `2ivy `gaside.Now you can see a massiv `Tdoor`g with `7ironnails`g on it.");
output("`gAnxiously you look around that nobody's watching you.");
	if ($session[user][bounty]>100)
	{
	output("`gYou press down the handle, open the `Tdoor`g, ");
    switch(e_rand(1,20))
		{
		case 1:
		case 2:
		case 3:
		case 4:
		case 5:
		case 6:
		case 7:
		case 8:
		case 9:
		case 10:
		case 11:
		case 12:
		case 13:
	   	case 14:
	   	case 15:
	   	case 16:
		case 17:
		case 18:
	   	output("`gand pass ist.Standing outside the `7wall `gyou shut the `Tdoor `gand walk to the `2forest `gas fast as you can. Uhh, that's it! ");
		addnav("To the forest","forest.php");
	   	break;
		case 19:
		output("`gand pass ist.Standing outside the `7wall `gyou shut the `Tdoor `gand want to walk to the `2forest, when a `%guard`g, that stood in the shadows, attakcks you: `v\"Hey, I know you, ther's a high bounty on your head!\"");
		output("`gYou pull your weapon and knock the `5guard `gout, which fall`s unconcious to the ground.After that you walk to the `2forest, but lost some `\$hitpoints`g!");
		$session['user']['hitpoints']*=0.9;
		addnews($session['user']['name']." was badly hurt when ".($session[user][sex]?"she":"he")." sneaked out of town.");
		addnav("To the forest","forest.php");
		break;
		case 20: 
		output("`gand pass ist.Standing outside the `7wall `gyou shut the `Tdoor `gand want to walk to the `2forest, when a `%guard`g, that stood in the shadows, attakcks you: `v\"Hey, I know you, ther's a high bounty on your head!\"");
		output("`gYou pull your weapon but the `%guard`g is faster! With one struck of his `7sword `ghe `\$kills`g you.");
		$session['user']['alive']=false;
		$session['user']['deathpower']+=15;
		$session['user']['hitpoints']=0;
		$session['user']['gold']=0;
		$session['user']['experience']*0.97;
		$session[user][bounty]=0;
		addnews($session['user']['name']." died when he tryed to sneak out of town");
		addnav("Daily News","news.php");
		break;
		}
	}
	else
	{
		output("`gYou press down the handle, open the `Tdoor`g, and pass ist.Standing outside the `7wall `gyou shut the `Tdoor `gand walk gigling to the `2forest. That was a nice, little adventure! ");
		addnav("To the forest","forest.php");
	}
}
page_footer();
?>