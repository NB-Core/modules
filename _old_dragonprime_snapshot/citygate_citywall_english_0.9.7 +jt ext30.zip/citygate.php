<?php
//Made by
//Morpheus aka Apollon
//2005 for logd.at (LoGD 0.9.7 +jt ext (GER) 3)
//Mail to Morpheus@magic.ms or Apollon@magic.ms
//Don`t forget to change the name of the city and the addnavs
//The castle and the shop are not inclouded
require_once "common.php";
addcommentary();
page_header("Stadttor");
if($HTTP_GET_VARS['op']=="")
{
output("`c`b`6The city gate of Tetharions`0`b`c`n");
output("`3You come to the city gate of the nice small town `6Tetharion`3. Inside the `7city wall `glies the town,you can see people rushing around, `7fume`g comes from some `4chimneys`3 and the noises of work gets throug you. Outside the `7wall `gsome `vwarriors `gand `vadventurers `ghave made a little camp and build up their tends.`n");
output("`3Inside the `7wall `g ther's a small `7mountain path `gleading to `7castle `6Tetharion`g, where the `^gods`g life that rule over this `2land`g, and a wide street leading to town. Outside the `7wall `gthere's a wide path leading directly in the `2forest`g, where all kind of `4dangers `gawait you`n");
output("`3Some big `5troll warriors `3of the `%city guard`3, which is commanded by the `6sheriff`3, stand at the `7city gate`3, watching everyone passing the `7gate`3, no matter if in or out.");

	if ($session[user][bounty]>100) //make your own high bounty
	{
	output("`3`n`nYou walk through the `7gate ");
    switch(e_rand(1,20))
		{
		case 1:
		case 2:
		case 3:
		case 4:
		case 5:
		case 6:
		case 7:
		case 8:
		case 9:
		case 10:
		case 11:
		case 12:
		case 13:
	   	case 14:
	   	case 15:
	   	case 16:
	   	output("`3and nod at the `%city guards`3, but they simply stare around and watch the scene.");
		addnav("Inside the city wall");
		addnav("To the city","village.php");
		//addnav("To the castle","burgthetarion.php");
		addnav("Shops"); //put in your own shops or just erase it
		//addnav("Garros kleiner Torshop","garro.php");
		addnav("Outside the city gate");
		$session['user']['specialinc']="";
		$session['user']['specialmisc']="";
		addnav("To the fields","citygate.php?op=fields");
		addnav("To the forest","forest.php");
	   	break;
		case 17:
		case 18:
		output("``3and nod at the `%city guards`3when suddenly one jumps at you:`v\"Hey, I know you, ther's a high bounty on your head!\"");
		output("`3You struggle and fight and can escape, before the other `%guards `3can catch you but you lose some hitpoints.");
		$session['user']['hitpoints']*=0.9;
		addnav("Inside the city wall");
		addnav("To the city","village.php");
		//addnav("To the castle","burgthetarion.php");
		addnav("Shops"); //put in your own shops or just erase it
		//addnav("Garros kleiner Torshop","garro.php");
		addnav("Outside the city gate");
		$session['user']['specialinc']="";
		$session['user']['specialmisc']="";
		addnav("To the fields","citygate.php?op=fields");
		addnav("To the forest","forest.php");
		break;
		case 19:
		case 20: 
		output("``3and nod at the `%city guards`3when suddenly one jumps at you:`v\"Hey, I know you, ther's a high bounty on your head!\"");
		output("`3You struggle and fight and pull your weapon, but the other `%guards `3take their bows and shoot their arrows");
		output("`3The last thing you hear befor you die is the laughing of the `5guards`3, who look forward to get the `6bounty.");
		$session['user']['alive']=false;
		$session['user']['deathpower']+=15;
		$session['user']['hitpoints']=0;
		$session['user']['gold']=0;
		$session['user']['experience']*0.97;
		$session[user][bounty]=0;
		addnews($session['user']['name']." died trying to escape the city guards.");
		addnav("Daily News","news.php");
		break;
		}
	}
	else
	{
		output("`3`n`nYou walk throug the gate, nod at the `5guards `3and tey nod back, befor they go on watching the scene.");
		addnav("Inside the city wall");
		addnav("To the city","village.php");
		//addnav("To the castle","burgthetarion.php");
		addnav("Shops"); //put in your own shops or just erase it
		//addnav("Garros kleiner Torshop","garro.php");
		addnav("Outside the city gate");
		$session['user']['specialinc']="";
		$session['user']['specialmisc']="";
		addnav("To the fields","citygate.php?op=fields");
		addnav("To the forest","forest.php");
	}
}
if ($_GET[op]=="fields")
	{
    page_header("The fields");
	output("`n`3You walk through the fields passing many tends. Some `vwarriors `3even don't notice you, some want you to come to their `\$fires`3.`n`n");
	output("`gYou listen to the storys of some `vwarriors `3at their `\$fire`3:`n`n");
    viewcommentary("fields","`gtalk to others:",20);
	addnav("Back to the city gate","citygate.php");
	addnav("The fields");
		if (getsetting("pvp",1))
		{
		addnav("Kill others","pvp.php");
		}
	addnav("Build your tend (Logout)","login.php?op=logout",true);
	}
page_footer();
?>