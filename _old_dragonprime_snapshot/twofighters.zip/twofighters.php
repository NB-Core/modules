<?php
/*	This is a forest special moduel.
	This module was made with some help by FlashDragon.
*/


function twofighters_getmoduleinfo(){
	$info = array(
		"name"=>"Two Fighters",
		"version"=>"1.1",
		"author"=>"`@DaFish",
		"category"=>"Forest Specials",
		"prefs"=>array(
			"Forest Duel Preferences,title",
            "status"=>"Had traveller been killed?,int|0",
        ),
        'rnd'=>array("The value to obfuscate links,int|0",), // must be zero or else something is wrong or we are in the middle of a battle
        "requires"=>array(
	       "alignment"=>"1.7| by WebPixie<br> `#Lonny Luberts<br>`^and Chris Vorndran",
	       "dag"=>"1.3| by Darrel Morrone<br>Updates by Andrew Senger, JT Traub, and Eric Stevens"
		),
	);
	return $info;
}


function twofighters_install(){
	module_addeventhook("forest", "return 100;");
	return true;
}

function twofighters_uninstall(){
	return true;
}

function twofighters_dohook($hookname,$args){
	return $args;
}

function twofighters_travellerfight($from,$travellerfight,$banditfight) { // This has to be passed.
	$op = httpget("op");
	global $session;


	$badguylevel = $session['user']['level'];
	$badguyhp = $session['user']['maxhitpoints'] * 1.05;
	$badguyatt = $session['user']['attack']*0.80;
	$badguydef = $session['user']['defense'];
	if ($session['user']['level'] > 9) {
		$badguyhp *= 1.05;
	}
	if ($session['user']['level'] < 4) {
		$badguyhp *= .9;
		$badguyatt *= .9;
		$badguydef *= .9;
	}

	if ($op==$travellerfight){
		$badguy = array(
			"creaturename"=>translate_inline("`^Fighter"),
			"creaturelevel"=>$badguylevel,
			"creatureweapon"=>translate_inline("Long Sword"),
			"creatureattack"=>$badguyatt,
			"creaturedefense"=>$badguydef,
			"creaturehealth"=>round($badguyhp,0), 
			"diddamage"=>0,
			"noadjust"=>1, // This is a pre-generated monster
			"type"=>"traveller");
		$session['user']['badguy']=createstring($badguy);
		$op="fight";
		httpset('op', "fight");
	}
	
	if ($op=="fight"){
		$battle=true;
	}
	if ($battle){
		require_once("battle.php");
		if ($victory){
			output("`b`&The fighter collapses from it's wounds.`b`n");
			output("`b`$ You have slain a fighter!`b`n");

			if ($session['user']['hitpoints'] <= 0) {
				output("`n`n`^Your staunch your own wounds with a small bit of moss from the ground nearby, stopping your blood loss before you are completely dead.");
				$session['user']['hitpoints'] = 1;
			}
			$expgain=round($session['user']['experience']*(e_rand(2,4)*0.007), 0);
			$session['user']['experience']+=$expgain;
			output("`n`#You gain `^%s `#experience from this fight!`n`n",$expgain);
			output("`2To your surprise, you found the fight to be easy, a little too easy...");
			output("`2but before you can react, the other fighter lunges at you with his sword!");
			set_module_pref('status', 1);
			addnav("Fight bandit", $from."op=".$banditfight);
		} elseif ($defeat) {
			output("`b`$ You were defeated by a traveller!`b`n`n");
			output("`2Your vision blacks out. You wake up with a splitting headache.`n`n");
			output("`2Next to you there is a note from the traveller! It says that you you helped out the wrong person.");
			output("`2But luckily the traveller was able to defeat the bandit as well!`n`n");
			output("`2As you try to get up, you realise just how foolish you were!`n`n");
			set_module_pref('alignment',(get_module_pref('alignment','alignment')-1),'alignment');
			output("`#You `\$lose `^1 `#alignment for trying to slay an innocent traveller!`n ");
			$session['user']['turns'] -= 1;
			output("`#You `\$lose a turn as you regain your strength.");
			$session['user']['hitpoints']=1;
			$badguy=array();
			$session['user']['badguy'] = "";
			$session['user']['specialinc'] = "";
			set_module_pref('rnd', 0);
		}else{
			fightnav(true,true);
		}
	}
}

function twofighters_banditfight($banditfight,$travellerfight) {
	$op = httpget("op");
	global $session;


	$badguylevel = $session['user']['level']+1;
	$badguyhp = $session['user']['maxhitpoints'];
	$badguyatt = $session['user']['attack']*1.15;
	$badguydef = $session['user']['defense']*1.05;
	if ($session['user']['level'] > 9) {
		$badguyhp *= 1.05; 
	}
	if ($session['user']['level'] < 4) {
		$badguyhp *= .9;
		$badguyatt *= .9;
		$badguydef *= .9;
		$badguylevel--;
	}

	if ($op==$banditfight || $op==$travellerfight){
		$badguy = array(
			"creaturename"=>translate_inline("`^Fighter"),
			"creaturelevel"=>$badguylevel,
			"creatureweapon"=>translate_inline("Mithril Sword"),
			"creatureattack"=>$badguyatt,
			"creaturedefense"=>$badguydef,
			"creaturehealth"=>round($badguyhp,0), 
			"diddamage"=>0,
			"noadjust"=>1,
			"type"=>"bandit");
		$session['user']['badguy']=createstring($badguy);
		$op="fight";
		httpset('op', "fight");
	}
	
	if ($op=="fight"){
		$battle=true;
	}
	if ($battle){
		require_once("battle.php");
		if ($victory || $defeat)
		{
		  set_module_pref('rnd', 0);
    }
		if ($victory){
			output("`b`&The fighter collapses as you finish him off.`n`b");
			output("`b`$ You have slain a fighter!`b`n`n");
			if ($session['user']['hitpoints'] <= 0) {
				output("`n`n`^Your staunch your own wounds with a bit of cloth torn from the bandit's clothing, stopping your bloodloss before you are completely dead.`n");
				$session['user']['hitpoints'] = 1;
			}
			$expgain=round($session['user']['experience']*(e_rand(2,4)*0.01), 0);
			$session['user']['experience']+=$expgain;
			output("`#You gain `^%s `#experience from this fight!`n",$expgain);
			if (get_module_pref('status')==1 && $session['user']['level'] >= get_module_pref('bountylevel', 'dag')){
				//set bounty on player
				set_module_pref("bounties",get_module_pref("bounties", "dag/run")+1, "dag/run");
				$amt = $session['user']['level']*e_rand(50,200);
				$setdate = time();
				// random set date up to 4 hours in the future.
				$setdate += e_rand(0,14400);
				$sql = "INSERT INTO ". db_prefix("bounty") . " (amount, target, setter, setdate) VALUES (".$amt.", ".(int)$session['user']['acctid'].", 0, '".date("Y-m-d H:i:s",$setdate)."')";
				db_query($sql);
				// ***END ADD***
				output("`&Your too exhaulsted from the fights to check the bodies for loot.`n");
				output("`#Your head is placed on the bounty list for killing an innocent traveller!");
			}
			elseif (get_module_pref('status')==1){
				set_module_pref('alignment',(get_module_pref('alignment','alignment')-1),'alignment');
				output("`&Your too exhaulsted from the fights to check the bodies for loot.`n");
				output("`#You `\$lose `^1 `#alignment for slaying an innocent traveller! ");
			}
			else {
				$rewardgold = $session['user']['level']*e_rand(35, 50);
				$session['user']['gold'] += $rewardgold;
				$rewardgems = e_rand(1, 4);
				$session['user']['gems'] += $rewardgems;
				if ($rewardgems == 1){
					output("`#You have found `^%s `#gold and `^%s `#gem on the bandit's body!`n", $rewardgold, $rewardgems);
				}
				else {
					output("`#You have found `^%s `#gold and `^%s `#gems on the bandit's body!`n", $rewardgold, $rewardgems);
				}
				set_module_pref('alignment',(get_module_pref('alignment','alignment')+1),'alignment');
				output("`#You gain `^1 `#alignment for saving the traveller's life! ");
			}
			set_module_pref('status', 0);
			$badguy=array();
			$session['user']['badguy'] = "";
			$session['user']['specialinc'] = "";
		} elseif ($defeat) {
			set_module_pref('status', 0);
			output("`b`$ You were slain by a bandit!`b`n`n");
			output("`2Your vision blacks out as the bandit slices your throat open and you collapse, gagging, to the ground.`n`n");
			output("`2As you lay there lifeless, the bandit helps himself to some of your gold and gems!`n");
			$lostgems = e_rand(1, 4);
			$lostgold = $session['user']['gold'];
			if ($session['user']['gems'] <= $lostgems){
				output("`7The bandit has taken all of your gold and gems!");
				$session['user']['gems']=0;
			}
			elseif ($lostgems == 1){
				output("`7The bandit has taken all of your gold and `^%s `7gem from your lifeless body!", $lostgems);
				$session['user']['gems'] -= $lostgems;
			}
			else {
				output("`7The bandit has taken all of your gold and `^%s `7gems from your lifeless body!`n", $lostgems);
				$session['user']['gems'] -= $lostgems;
			}
			output("`%You have died!");
			output("You lose 10% of your experience.");
			output("Your soul drifts to the shades.");
			$session['user']['gold']=0;
			$session['user']['experience']*=0.9;
			$session['user']['alive']=false;
			addnav("Return to the News","news.php");
			debuglog("was killed by a fighter in the Forest."); // Why not log every death?
			addnews("%s was slain by a bandit in the forest!", $session['user']['name']);
			$badguy=array();
			$session['user']['badguy'] = "";
			$session['user']['specialinc'] = "";
		}else{
			fightnav(true,true);
		}
	}
}

function twofighters_runevent($type)
{
	require_once("lib/buffs.php");
	global $session;
 
	// We assume this event only shows up in the forest currently.
	$from = "forest.php?";
	$session['user']['specialinc'] = "module:twofighters";

	$baddie = createarray($session['user']['badguy']); // The easiest way to get the name of the monster.
	$op = httpget('op');

  switch (get_module_pref('rnd')) // the "obfuscator" by FlashDragon
  {
  case 0:
  
    $rand = e_rand(1,2);
    if ( $rand == 1)
    {
      $banditfight = "fightl";
      $travellerfight = "fightI";
    } else {
      $banditfight = "fightI";
      $travellerfight = "fightl";
    }
    set_module_pref('rnd', $rand);
    break;
   
  case 1:
  
    $banditfight = "fightl";
    $travellerfight = "fightI";
    break;
  
  case 2:
  
    $banditfight = "fightI";
    $travellerfight = "fightl";
  }

	if ($op=="" || $op=="search"){
		$count = 0;
		if (is_module_active("alignment"))
			$count = get_module_pref("alignment","alignment");
			$evilalign = get_module_setting("evilalign", "alignment");
		output("`2As you travel along a well worned path, you could hear clashes of steel in the distance.");
		output("`2When you round a bend along the path, you begin to see the faint outline of two figures locked in close combat!`n`n");
		output("`2When you move closer to the fighters, they were able to catch your approach from the corner of their eye.`n");
		output("`2The fighter on the far left calls out, \"`#I could use a little help here! I was waylaid by this lone bandit while travelling along this path.`2\"`n");
		output("`2The other fighter quickly counters, \"`#He's lying! He's the bandit! I'm the one who is in need of help.`2\"`n`n");
		output("`2The fighting has blocked the path, your unable to travel any further.`n`n");
		output("`2What will you do?");
		if ($count > $evilalign){
			addnav("Wait awhile and see (1 turn)",$from."op=wait");
		}

		if (e_rand(1,2) == 1) { // re-added by FlashDragon
			$left = $banditfight;
			$right = $travellerfight;
    } else {
			$left = $travellerfight;
			$right = $banditfight;
		}

		addnav("Help far left fighter",$from."op=$right");
		addnav("Help far right fighter",$from."op=$left");
	}elseif ($op=="wait"){
		$rand = e_rand(1,2);
		output("`2You stand there and watch as the two fighters continue on with their fight.`n`n");
		switch ($rand) {
		case 1:
			$bandit = "far left";
			$traveler = "far right";
			break;
		case 2:
			$bandit = "far right";
			$traveler = "far left";
			break;
		}
		output("`2Slowly but surely the %s `2fighter begins to gain the upper hand.`n", $bandit);
		output("`2Soon the %s `2fighter is pinned to the ground with a sword resting on his neck.`n`n", $traveler);
		output("`2The %s `2fighter smirks, \"`#Now, hand over all your gold and gems!`#\"`n`n", $bandit);
		output("`2You can't just stand there and watch the bandit kill an innocent traveller, so you decides to fight the bandit.");
		$session['user']['turns'] -= 1;
		addnav("Fight the bandit", $from."op=".$banditfight);
	} elseif ($op==$banditfight || ($op=="fight" && $baddie['type']=='bandit')){
		  twofighters_banditfight($banditfight,$travellerfight);
	} elseif ($op==$travellerfight || ($op=="fight" && $baddie['type']=='traveller')) {
			twofighters_travellerfight($from,$travellerfight,$banditfight); // Parameter must be passed.
	} elseif ($op=="run") // Added to make sure you don't get an empty screen when running away.
	{
    output("`\$Your ran away from the fight with the %s. Violence never solved anything anyway.", $baddie['type']);
    set_module_pref('rnd', 0);
  }
	output("`0");
}

function twofighters_run(){
}
?>
