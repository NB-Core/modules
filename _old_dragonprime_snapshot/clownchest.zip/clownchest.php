<?php

/*
Please note, that the original idea behind this was created by
(or at least, where I saw it first)
Level-5 Inc.
I don't believe they should be getting mad, because this is non-commercial.
Thought I should just point it out, in case anyone recognizes it.
*/

function clownchest_getmoduleinfo(){
	$info = array(
		"name"=>"Magic Clown Chest",
		"author"=>"Chris Vorndran",
		"version"=>"1.0",
		"category"=>"Forest Specials",
		"download"=>"http://dragonprime.net/index.php?module=Downloads;sa=dlview;id=86",
		"vertxtloc"=>"http://dragonprime.net/users/Sichae/",
		"settings"=>array(
			"Magic Clown Chest Settings,title",
				"success"=>"What is the rate of success (%)?,range,1,100,1|40",
				"clown"=>"What is the rate that the Clown will show up (%)?,range,1,100,1|25",
		),
	);
	return $info;
}
function clownchest_install(){
	module_addeventhook("forest","return 100;");
	return true;
}
function clownchest_uninstall(){
	return true;
}
function clownchest_runevent($type){
	global $session;
	$op = httpget('op');
	$choice = httpget('choice');
	$link = "forest.php?op=";
	$session['user']['specialinc'] = "module:clownchest";
	$success = get_module_setting("success");
	$clown = get_module_setting("clown");
	
	switch ($op){
		case "": case "search":
			output("`2You stumble into a clearing, seeing nothing around you but trees, shrubs and a chest.");
			output("Thinking that you could score a lot of loot from this chest, you wander up to it.");
			output("Upon reaching the chest, you realize that there is a charm lock on it.");
			output("Would you like to guess the charm?");
			addnav("Guess");
			addnav("Poison Charm?",$link."guess&choice=poison");
			addnav("Explosion Charm?",$link."guess&choice=explode");
			addnav("Decrepify Charm?",$link."guess&choice=decrep");
			addnav("Leave");
			addnav("Leave it alone",$link."leave");
			break;
		case "guess":
			// Select Trap or Clown
			if (e_rand(1,100) > $clown){
				$session['user']['specialinc'] = "";
				switch ($choice){
					case "poison":
						output("`2Not fearing any illness, you guess `%Poison`2.");
						if (e_rand(1,100) < $success){
							clownchest_boon();
						}else{
							output("`2You try to crack open the chest, but a cloud of `%purple gas `2begins to leak from the sides of it.");
							output("Trying to quickly cover your mouth is futile, as you can already feel sick.");
							$poison = array(
								"name"=>"`%Poisonous Cloud",
								"rounds"=>25,
								"roundmsg"=>"`2A cloud of `%poison `2hangs around your head.",
								"wearoff"=>"The cloud begins to disappear, and you don't feel sick anymore.",
								"minioncount"=>1,
								"mingoodguydamage"=>1,
								"maxgoodguydamage"=>2,
								"effectmsg"=>"`2Trying to fight, you inhale another wiff of the `%gas `2and it causes `\${damage} `2damage!",
							);
							apply_buff('poison',$poison);
						}
						break;
					case "explode":
						output("`2Not fearing any blodily harm, you guess `\$Explosion.");
						if (e_rand(1,100) < $success){
							clownchest_boon();
						}else{
							output("`2The chest `\$explodes`2, throwing millions of shards of wood and metal towards you.");
							output("You are able to dodge the bulk of them, but some of them are standing in your skin.");
							output("You are `\$severely `2damaged!");
							$session['user']['hitpoints'] = 1;
						}
						break;
					case "decrep":
						output("`2What is the worst that could happen? You guess `6Decrepify.");
						if (e_rand(1,100) < $success){
							clownchest_boon();
						}else{
							output("`2You try to pry open the chest, but one of the bands of the chest wraps itself around you.");
							output("The `4rust `2cutting into your skin, you begin to feel `6weaker `2and `6weaker`2.");
							$decrep = array(
								"name"=>"`6Decrepfiy Charm",
								"rounds"=>25,
								"wearoff"=>"`2The `6charm `2breaks, leaving you free to attack at your full strength.",
								"atkmod"=>.75,
								"defmod"=>.75,
								"roundmsg"=>"`2The `6charm `2has a hold of your arms, making you weak.",
							);
							apply_buff('decrepify',$decrep);
						}
						break;			
				}
			}else{
				output("`2Turns out, there was no curse on the chest.");
				output("You realize this, once you open the chest and a clown pops out, hovering over the chest.");
				output("\"`%Hello there!");
				output("Here two boxes be, one yellow and one red.");
				output("Pick one and a prize shall come to thee.`2\"");
				addnav("Which Box?");
				addnav("Red Box",$link."box&choice=red");
				addnav("Yellow Box",$link."box&choice=yellow");
			}
			break;
		case "box":
			$session['user']['specialinc'] = "";
			switch ($choice){
				case "red":
					output("`2The `^Yellow `2Box disappears, leaving the `\$Red `2Box in front of the clown.");
					if (e_rand(1,100) < $success){
						output("`2It disappears around the object inside, revealing a `\$new `2weapon!");
						if (substr($session['user']['weapon'],-1,1) != "+")
							$session['user']['weapon'] = $session['user']['weapon']." +";
						$session['user']['attack']++;
						$session['user']['weapondmg']++;
					}else{
						output("`2The box disappears, and a few coins drop onto the ground.");
						$gain = e_rand(2,200);
						output("You quickly count the coins and see `^%s `2coins there.",$gain);
						$session['user']['gold']+=$gain;
					}
					break;
				case "yellow":
					output("`2The `\$Red `2Box disappears, leaving the `^Yellow `2Box floating in front of the clown.");
					if (e_rand(1,100) < $success){
						output("`2It disappears around the object inside, revealing a `^new `2piece of armor");
						if (substr($session['user']['armor'],-1,1) != "+")
							$session['user']['armor'] = $session['user']['armor']." +";
						$session['user']['defense']++;
						$session['user']['armordef']++;
					}else{
						output("`2The box disappears, and a few `^coins `2drop onto the ground.");
						$gain = e_rand(2,200);
						output("You quickly count the coins and see `^%s `2coins there.",$gain);
						$session['user']['gold']+=$gain;
					}
					break;
			}
			break;
		case "leave":
			$session['user']['specialinc'] = "";
			output("`2Not wanting to risk any chances, you decide to leave the chest alone.");
			output("You hear the small squeaking of a horn, but disregard.");
			break;
	}
}
function clownchest_boon(){
	global $session;
	$rand = e_rand(1,10);
	switch ($rand){
		case 1: case 2: case 3:
			output("`2Peering into the bottom of the chest, you discover a `%Gem`2.");
			output("As you reach for it, a mark comes out of no where and writes on your forehead, \"`#Greedy!`2\"");
			output("Not wishing to feel the shame of jeers and scowls, you wash it off and you are more `5charming `2than before.");
			$session['user']['charm']+=e_rand(1,5);
			break;
		case 4: case 5: case 6:
			output("`2You fumble through the chest looking for something, but finding nothing.");
			output("You realize that the chest was empty all along.");
			output("Shrugging it off, you kick it and a `%Gem `2flies out.");
			$session['user']['gems']++;
			break;
		case 7: case 8:
			output("`2Reaching for the bottom, you accidently fall into the chest.");
			output("As you are tumbling downwards, a refreshing breeze strikes you and you feel `\$healty`2!");
			$session['user']['hitpoints'] = $session['user']['maxhitpoints'];
			break;
		case 9: case 10:
			$favor = e_rand(1,25);
			output("`2As you reach inside, `\$Ramius `2jumps up behind you and taps you on the shoulder.");
			output("\"`)I see ye hath found my chest.");
			output("Thank you very much... you have my favor now.`2\"");
			output("As `\$Ramius `2disappears into the trees, you find a burning `\$%s `2dangling in the air.",$favor);
			$session['user']['deathpower']+=$favor;
			break;
	}
}
?>