<?
/**********************************************
/ A village addition by Spider
/ 
/ inspiration from the original fortune teller
/ author unkown
/
/ Nerwen will tell your fortune, and depending
/ on how much money you offer her, you have a
/ chance at a "better" fortune.
**********************************************/
require_once "common.php";
page_header("Nerwen's House");
output("`c`bNerwen's House`b`c");

if ($HTTP_GET_VARS[op]==""){
	output("Nerwen Loss�helin looks up as you enter, elves are known for their beauty but even by elvish standards Nerwen is beautiful, her deep blue eyes look straight into your own and you feel as though she is looking straight into your heart.`n`n");
	output("`3\"Ah, dear ".$session[user][name].", I trust you are well today.  I wonder if you could tell me something, has my brother Golradir arrived yet, the building work is nearly complete and his little sanctuary will be opening once he gets here.\" `0Nerwen pauses for a moment, ever staring into your eyes. `3\"No, I see that he has not.  I do expect him to arrive any day now though.\"`n`n");
	output("\"Anyway, enough talk of my dear misguided brother, I suppose you would like to know a little more about yourself?  I can reveal a little of your future to you if you part with a little gold for me.\"");
	addnav("Learn of your Future","nerwen.php?op=future");
}
else if($HTTP_GET_VARS[op]=="future"){
	output("Eager to hear about your future you ask Nerwen how much a little gold is.`n`n");
	output("`3\"My child, a little is as much as you feel you can part with, the question is, how generous do you feel today?\"`0`n`n");
	output("How much gold will you offer Nerwen?`n");
	output("<form action='nerwen.php?op=future2' method='POST'><input id='input' name='amount' width=5 accesskey='h'> <input type='submit' class='button' value='Offer'></form>",true);
	output("<script language='javascript'>document.getElementById('input').focus();</script>",true);
	addnav("","nerwen.php?op=future2");
}
else if($HTTP_GET_VARS[op]=="future2"){
	$offer=abs((int)$_POST[amount]);
	if ($offer==0){
		output("Nerwen looks at you sternly`n`n");
		output("`3\"Are you trying to make a fool of me, or perhaps you think this is some kind of joke, get out of my house now and don't come back until you learn some manners!\"");
	}
	else if ($offer<100){
		output("Nerwen looks at your meager offering and shakes her head sadly.`n`n");
		output("`3\"Sorry my child, but that simply is not enough, this is how I earn my living, and I cannot do it for so little.\"");
	}
	if ($offer>$session[user][gold]){
		output("Nerwen looks at you sternly`n`n");
		output("`3\"I think maybe you need to take some basic arithmetic lessons rather than have your fortune read, how can you give me what you do not have?\"");
		addnav("Learn of your Future","nerwen.php?op=future");
	}
	else{
		$max=round(($offer/100)+1);
		if ($max>15) $max=15;
		$session[user][gold]-=$offer;
		output("Nerwen takes your gold, smiling and looks up into your eyes again.`n`n");
		$fortune = e_rand(1,$max);
		debuglog("offered $offer to Nerwen, giving a max of: $max and the roll gave: $fortune");
		switch ($fortune){
			case 1:
				output("`3\"Today does not look good for you, I'm terribly sorry.\"");
				$session[user][hitpoints]=1;
				$session[user][gold]-=100;
				$session[user][charm]-=1;
				$session[user][gems]-=1;
				if ($session[user][gold] < 0){
					$session[user][gold] = 0;
				}
				if ($session[user][gems] < 0){
					$session[user][gems] = 0;
				}
				break;
			case 2:
				output("`3\"My child, you seem unusually tired today.\"");
				$session[user][turns]-=2;
				if ($session[user][turns] < 0){
					$session[user][turns] = 0;
				}
				break;
			case 3: case 11:
				output("`3\"Today your confidence will grow greatly, perhaps you should go and say hi to ".($session['user']['sex']?"Seth":"`5Violet`")."\"");
				$session[user][charm]+=1;
					break;
			case 4:
				output("`3\"I'm afraid you seem to have lost something today, although I cannot tell quite what it is.\"");
				$session[user][goldinbank]-=500;
				break;
			case 5:
				output("`3\"It seems that somebody mistook your safety deposit box for their own.\"");
				$session[user][gemsinbank]-=1;
				if ($session[user][gemsinbank] < 0){
					$session[user][gemsinbank] = 0;
				}
				break;
			case 7:
				output("`3\"You will be pleasantly surprised later on today.\"");
				$session[user][goldinbank]+=1000;
				break;
			case 8: case 20:
				output("`3\"The strength flowing through you is great today, your day will be long and productive.\"");
				$session[user][turns]+=2;
				break;
			case 9:
				output("`3\"It seems that somebody mistook your safety deposit box for their own.\"");
				$session[user][gemsinbank]+=1;
				break;
			case 10:
				output("`3\"I see that today you will feel a new strength in your body.\"");
				$session[user][hitpoints]+=200;
				break;
			case 12:
				output("`3\"I see that you aren't feeling at all well today, I hope you feel better soon.\"");
				$session[user][hitpoints]-=($session[user][maxhitpoints]*0.5);
				if ($session[user][hitpoints] < 0){
					$session[user][hitpoints] = 1;
				}
				break;
			case 13:
				output("`3\"I suggest you stay clear of the inn today, you will not be very welcome there in your present state.\"");
				$session[user][drunkeness]=80;
				break;
			case 14:
				output("`3\"Today you are blessed, enjoy it while it lasts.\"");
				$session[user][hitpoints]+=50;
				break;
			case 15:
				output("`3\"Today is looking most promising for you, you should go out and make the most of it.\"");
				$session[user][hitpoints]+=10;
				$session[user][gold]+=100;
				$session[user][charm]+=1;
				$session[user][gems]+=1;
				break;
			default:
				output("`3\"I'm afraid your future is a little cloudy today, there is nothing more I can tell you.\"");
		}
	}
}
addnav("Return to the Village","village.php");

page_footer();
?>