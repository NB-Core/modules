<?php

/*****************************************************
PvP-Arena by anpera 2004 (english version)

Version: 12.04.2004

For "Legend of the Green Dragon" 0.9.7 by Eric Stevens

This gives players the possibility to fight against other players with all
their specialties, mounts and buffs. The first non-automated PvP
system for LoGD that comes pretty close to real online PvP. :)

(Quite rough by now but Im still working on it.)

Fully compatible with lonnyl's battle-arena and battlepoint system!

Needs modifications on several files and in database!
SEE INSTALLATION INSTRUCTIONS AT:
http://www.anpera.net/forum/viewtopic.php?t=369

ToDo:
- systemmail on interrupted battles
- bet system (place bets on winner as long as both players have
  at least half of their maxhitpoints
*****************************************************/

require_once "common.php";
page_header("The Arena!");

function stats($row){  // Shows player stats
	global $session;
	output("<table align='center' border='0' cellpadding='2' cellspacing='0' class='vitalinfo'><tr><td class='charhead' colspan='4'>`^`bVital Info`b for this fight</td><tr><td class='charinfo'>`&Level: `^`b",true);
	if ($row[bufflist1]) $row[bufflist1]=unserialize($row[bufflist1]);
	if ($row[bufflist2]) $row[bufflist2]=unserialize($row[bufflist2]);
	if ($row[bufflist1]) reset($row[bufflist1]);
	if ($row[bufflist2]) reset($row[bufflist2]);
	if ($row[acctid1]==$session[user][acctid]){
		$atk=$row[att1];
		$def=$row[def1];
		while (list($key,$val)=each($row[bufflist1])){
			//output(" $val[name]/$val[badguyatkmod]/$val[atkmod]/$val[badguydefmod]/$val[defmod]`n");
			$buffs.=appoencode("`#$val[name] `7($val[rounds] rounds left)`n",true);
			if (isset($val[atkmod])) $atk *= $val[atkmod];
			if (isset($val[defmod])) $def *= $val[defmod];
		}
		if ($row[bufflist2]){
			while (list($key,$val)=each($row[bufflist2])){
				//output(" $val[name]/$val[badguyatkmod]/$val[atkmod]/$val[badguydefmod]/$val[defmod]`n");
				if (isset($val[badguyatkmod])) $atk *= $val[badguyatkmod];
				if (isset($val[badguydefmod])) $def *= $val[badguydefmod];
			}
		}
		$atk = round($atk, 2);
		$def = round($def, 2);
		$atk = ($atk == $row[att1] ? "`^" : ($atk > $row[att1] ? "`@" : "`$")) . "`b$atk`b`0";
		$def = ($def == $row[def1] ? "`^" : ($def > $row[def1] ? "`@" : "`$")) . "`b$def`b`0";
		if (count($row[bufflist1])==0){
			$buffs.=appoencode("`^none`0",true);
		}
		output("$row[lvl1]`b</td><td class='charinfo'>`&Hitpoints: `^$row[hp1]/`0$row[maxhp1]</td><td class='charinfo'>`&Attack: `^`b$atk`b</td><td class='charinfo'>`&Defense: `^`b$def`b</td>",true);
		output("</tr><tr><td class='charinfo' colspan='2'>`&Weapon: `^$row[weapon1]</td><td class='charinfo' colspan='2'>`&Armor: `^$row[armor1]</td>",true);
		output("</tr><tr><td colspan='4' class='charinfo'>`&Buffs:`n$buffs",true);
		output("</td>",true);
	}
	if ($row[acctid2]==$session[user][acctid]){
		$atk=$row[att2];
		$def=$row[def2];
		while (list($key,$val)=each($row[bufflist2])){
			$buffs.=appoencode("`#$val[name] `7($val[rounds] rounds left)`n",true);
			if (isset($val[atkmod])) $atk *= $val[atkmod];
			if (isset($val[defmod])) $def *= $val[defmod];
		}
		if ($row[bufflist1]){
			while (list($key,$val)=each($row[bufflist1])){
				if (isset($val[badguyatkmod])) $atk *= $val[badguyatkmod];
				if (isset($val[badguydefmod])) $def *= $val[badguydefmod];
			}
		}
		$atk = round($atk, 2);
		$def = round($def, 2);
		$atk = ($atk == $row[att2] ? "`^" : ($atk > $row[att2] ? "`@" : "`$")) . "`b$atk`b`0";
		$def = ($def == $row[def2] ? "`^" : ($def > $row[def2] ? "`@" : "`$")) . "`b$def`b`0";
		if (count($row[bufflist2])==0){
			$buffs.=appoencode("`^none`0",true);
		}
		output("$row[lvl2]`b</td><td class='charinfo'>`&Hitpoints: `^$row[hp2]/`0$row[maxhp2]</td><td class='charinfo'>`&Attack: `^`b$atk`b</td><td class='charinfo'>`&Defense: `^`b$def`b</td>",true);
		output("</tr><tr><td class='charinfo' colspan='2'>`&Weapon: `^$row[weapon2]</td><td class='charinfo' colspan='2'>`&Armor: `^$row[armor2]</td>",true);
		output("</tr><tr><td class='charinfo' colspan='4'>`&Buffs:`n$buffs",true);
		output("</td>",true);
	}
	output("</tr></table>`n",true);
	if ($row[bufflist1]) $row[bufflist1]=serialize($row[bufflist1]);
	if ($row[bufflist2]) $row[bufflist2]=serialize($row[bufflist2]);
}
function arenanav($row){ // Navigation during fight
	if ($row[turn]==1){
 		$badguy = array("acctid"=>$row[acctid2],"name"=>$row[name2],"level"=>$row[lvl2],"hitpoints"=>$row[hp2],"attack"=>$row[att2],"defense"=>$row[def2],"weapon"=>$row[weapon2],"armor"=>$row[armor2],"bufflist"=>$row[bufflist2]);
 		$goodguy = array("name"=>$row[name1],"level"=>$row[lvl1],"hitpoints"=>$row[hp1],"maxhitpoints"=>$row[maxhp1],"attack"=>$row[att1],"defense"=>$row[def1],"weapon"=>$row[weapon1],"armor"=>$row[armor1],"darkartuses"=>$row[darkartuses1],"magicuses"=>$row[magicuses1],"thieveryuses"=>$row[thieveryuses1],"bufflist"=>$row[bufflist1]);
	}
	if ($row[turn]==2){
 		$badguy = array("acctid"=>$row[acctid1],"name"=>$row[name1],"level"=>$row[lvl1],"hitpoints"=>$row[hp1],"attack"=>$row[att1],"defense"=>$row[def1],"weapon"=>$row[weapon1],"armor"=>$row[armor1],"bufflist"=>$row[bufflist1]);
 		$goodguy = array("name"=>$row[name2],"level"=>$row[lvl2],"hitpoints"=>$row[hp2],"maxhitpoints"=>$row[maxhp2],"attack"=>$row[att2],"defense"=>$row[def2],"weapon"=>$row[weapon2],"armor"=>$row[armor2],"darkartuses"=>$row[darkartuses2],"magicuses"=>$row[magicuses2],"thieveryuses"=>$row[thieveryuses2],"bufflist"=>$row[bufflist2]);
	}
	if ($goodguy[hitpoints]>0 && $badguy[hitpoints]>0) {
		output ("`\$`c`b~ ~ ~ Fight ~ ~ ~`b`c`0");
		output("`@You have encountered `^$badguy[name]`@ which lunges at you with `%$badguy[weapon]`@");
		// Let's display what buffs the opponent is using - oh yeah
		$buffs="";
		$disp[bufflist]=unserialize($badguy[bufflist]);
		reset($disp[bufflist]);
		while (list($key,$val)=each($disp[bufflist])){
			$buffs.=" `@and `#$val[name] `7($val[rounds] rounds)";
		}
		if (count($disp[bufflist])==0){
			$buffs.=appoencode("",true);
		}
		output("$buffs");
		output(" `@!`0`n`n");
		output("`2Level: `6$badguy[level]`0`n");
		output("`2`bResult of last round:`b`n");
		output("`2$badguy[name]`2's Hitpoints: `6$badguy[hitpoints]`0`n");
		output("`2YOUR Hitppoints: `6$goodguy[hitpoints]`0`n");
		output("$row[lastmsg]");
	}
	addnav("Fight");
	addnav("Fight","pvparena.php?op=fight&act=fight");
	addnav("`bSpecial Abilities`b");
	if ($goodguy[darkartuses]>0) {
		addnav("`\$Dark Arts`0", "");
		addnav("`\$&#149; Skeleton Crew`7 (1/".$goodguy[darkartuses].")`0","pvparena.php?op=fight&skill=DA&l=1",true);
	}
	if ($goodguy[darkartuses]>1)
		addnav("`\$&#149; Voodoo`7 (2/".$goodguy[darkartuses].")`0","pvparena.php?op=fight&skill=DA&l=2",true);
	if ($goodguy[darkartuses]>2)
		addnav("`\$&#149; Curse Spirit`7 (3/".$goodguy[darkartuses].")`0","pvparena.php?op=fight&skill=DA&l=3",true);
	if ($goodguy[darkartuses]>4)
		addnav("`\$&#149; Wither Soul`7 (5/".$goodguy[darkartuses].")`0","pvparena.php?op=fight&skill=DA&l=5",true);
	if ($goodguy[thieveryuses]>0) {
		addnav("`^Thieving Skills`0","");
		addnav("`^&#149; Insult`7 (1/".$goodguy[thieveryuses].")`0","pvparena.php?op=fight&skill=TS&l=1",true);
	}
	if ($goodguy[thieveryuses]>1)
		addnav("`^&#149; Poison Blade`7 (2/".$goodguy[thieveryuses].")`0","pvparena.php?op=fight&skill=TS&l=2",true);
	if ($goodguy[thieveryuses]>2)
		addnav("`^&#149; Hidden Attack`7 (3/".$goodguy[thieveryuses].")`0","pvparena.php?op=fight&skill=TS&l=3",true);
	if ($goodguy[thieveryuses]>4)
		addnav("`^&#149; Backstab`7 (5/".$goodguy[thieveryuses].")`0","pvparena.php?op=fight&skill=TS&l=5",true);
	if ($goodguy[magicuses]>0) {
		addnav("`%Mystical Powers`0","");
		//disagree with making this 'n', players shouldn't have their behavior dictated by convenience of god mode, hehe
		addnav("g?`%&#149; Regeneration`7 (1/".$goodguy[magicuses].")`0","pvparena.php?op=fight&skill=MP&l=1",true);
	}
	if ($goodguy[magicuses]>1)
		addnav("`%&#149; Earth Fist`7 (2/".$goodguy[magicuses].")`0","pvparena.php?op=fight&skill=MP&l=2",true);
	if ($goodguy[magicuses]>2)
		addnav("L?`%&#149; Siphon Life`7 (3/".$goodguy[magicuses].")`0","pvparena.php?op=fight&skill=MP&l=3",true);
	if ($goodguy[magicuses]>4)
		addnav("A?`%&#149; Lightning Aura`7 (5/".$goodguy[magicuses].")`0","pvparena.php?op=fight&skill=MP&l=5",true);	
}
function activate_buffs($tag) { // activate buffs (from battle.php with modifications for multiplayer battle)
	global $goodguy,$badguy,$message;
	reset($goodguy['bufflist']);
	reset($badguy['bufflist']);
	$result = array();
	$result['invulnerable'] = 0; // not in use
	$result['dmgmod'] = 1;
	$result['badguydmgmod'] = 1; // not in use
	$result['atkmod'] = 1;
	$result['badguyatkmod'] = 1; // not in use
	$result['defmod'] = 1;
	$result['badguydefmod'] = 1;
	$result['lifetap'] = array();
	$result['dmgshield'] = array();
	while(list($key,$buff) = each($goodguy['bufflist'])) {
		if (isset($buff['startmsg'])) {
			$msg = $buff['startmsg'];
			$msg = str_replace("{badguy}", $badguy[name], $msg);
			output("`%$msg`0");
			$message=$message.$goodguy[name].": \"`i$msg`i\"`n";
			unset($goodguy['bufflist'][$key]['startmsg']);
		}
		$activate = strpos($buff['activate'], $tag);
		if ($activate !== false) $activate = true; // handle strpos == 0;
		// If this should activate now and it hasn't already activated,
		// do the round message and mark it.
		if ($activate && !$buff['used']) {
			// mark it used.
			$goodguy['bufflist'][$key]['used'] = 1;
			// if it has a 'round message', run it.
			if (isset($buff['roundmsg'])) {
				$msg = $buff['roundmsg'];
				$msg = str_replace("{badguy}", $badguy[name], $msg);
				output("`)$msg`0`n");
				$message=$message.$goodguy[name].": \"`i$msg`i\"`n";
			}
		}
		// Now, calculate any effects and run them if needed.
		if (isset($buff['invulnerable'])) {
			$result['invulnerable'] = 1;
		}
		if (isset($buff['atkmod'])) {
			$result['atkmod'] *= $buff['atkmod'];
		}
		if (isset($buff['badguyatkmod'])) {
			$result['badguyatkmod'] *= $buff['badguyatkmod'];
		}
		if (isset($buff['defmod'])) {
			$result['defmod'] *= $buff['defmod'];
		}
		if (isset($buff['badguydefmod'])) {
			$result['badguydefmod'] *= $buff['badguydefmod'];
		}
		if (isset($buff['dmgmod'])) {
			$result['dmgmod'] *= $buff['dmgmod'];
		}
		if (isset($buff['badguydmgmod'])) {
			$result['badguydmgmod'] *= $buff['badguydmgmod'];
		}
		if (isset($buff['lifetap'])) {
			array_push($result['lifetap'], $buff);
		}
		if (isset($buff['damageshield'])) {
			array_push($result['dmgshield'], $buff);
		}
		if (isset($buff['regen']) && $activate) {
			$hptoregen = (int)$buff['regen'];
			$hpdiff = $goodguy['maxhitpoints'] -
			$goodguy['hitpoints'];
			// Don't regen if we are above max hp
			if ($hpdiff < 0) $hpdiff = 0;
			if ($hpdiff < $hptoregen) $hptoregen = $hpdiff;
			$goodguy['hitpoints'] += $hptoregen;
			// Now, take abs value just incase this was a damaging buff
			$hptoregen = abs($hptoregen);
			if ($hptoregen == 0) $msg = $buff['effectnodmgmsg'];
			else $msg = $buff['effectmsg'];
			$msg = str_replace("{badguy}", $badguy[name], $msg);
			$msg = str_replace("{damage}", $hptoregen, $msg);
			output("`)$msg`0`n");
			$message=$message.$goodguy[name].": \"`i$msg`i\"`n";
		}
		if (isset($buff['minioncount']) && $activate) {
			$who = -1;
			if (isset($buff['maxbadguydamage'])) {
				if (isset($buff['maxbadguydamage'])) {
					$buff['maxbadguydamage'] = stripslashes($buff['maxbadguydamage']);
					eval("\$buff['maxbadguydamage'] = $buff[maxbadguydamage];");
				}
				$max = $buff['maxbadguydamage'];

				if (isset($buff['minbadguydamage'])) {
					$buff['minbadguydamage'] = stripslashes($buff['minbadguydamage']);
					eval("\$buff['minbadguydamage'] = $buff[minbadguydamage];");
				}
				$min = $buff['minbadguydamage'];

				$who = 0;
			} else {
				$max = $buff['maxgoodguydamage'];
				$min = $buff['mingoodguydamage'];
				$who = 1;
			}
			for ($i = 0; $who >= 0 && $i < $buff['minioncount']; $i++) {
				$damage = e_rand($min, $max);
				if ($who == 0) {
					$badguy[hitpoints] -= $damage;
				} else if ($who == 1) {
					$goodguy[hitpoints] -= $damage;
				}
				if ($damage < 0) {
					$msg = $buff['effectfailmsg'];
				} else if ($damage == 0) {
					$msg = $buff['effectnodmgmsg'];
				} else if ($damage > 0) {
					$msg = $buff['effectmsg'];
				}
				if ($msg>"") {
					$msg = str_replace("{badguy}", $badguy['name'], $msg);
					$msg = str_replace("{goodguy}", $session['user']['name'], $msg);
					$msg = str_replace("{damage}", $damage, $msg);
					output("`)$msg`0`n");
					$message=$message.$goodguy[name].": \"`i$msg`i\"`n";
				}
			}
		}
	}
	while(list($key,$buff) = each($badguy['bufflist'])) { // check badguy buffs
		$activate = strpos($buff['activate'], $tag);
		if ($activate !== false) $activate = true;
		if ($activate && !$buff['used']) {
			$badguy['bufflist'][$key]['used'] = 1;
		}
		if (isset($buff['atkmod'])) {
			$result['badguyatkmod'] *= $buff['atkmod'];
		}
		if (isset($buff['defmod'])) {
			$result['badguydefmod'] *= $buff['defmod'];
		}
		if (isset($buff['badguyatkmod'])) {
			$result['atkmod'] *= $buff['badguyatkmod'];
		}
		if (isset($buff['badguydefmod'])) {
			$result['defmod'] *= $buff['badguydefmod'];
		}
		if (isset($buff['badguydmgmod'])) {
			$result['dmgmod'] *= $buff['badguydmgmod'];
		}
	}
	return $result;
}
function process_lifetaps($ltaps, $damage) {
	global $goodguy,$badguy,$message;
	reset($ltaps);
	while(list($key,$buff) = each($ltaps)) {
		$healhp = $goodguy['maxhitpoints'] -
			$goodguy['hitpoints'];
		if ($healhp < 0) $healhp = 0;
		if ($healhp == 0) {
			$msg = $buff['effectnodmgmsg'];
		} else {
			if ($healhp > $damage * $buff['lifetap'])
				$healhp = $damage * $buff['lifetap'];
			if ($healhp < 0) $healhp = 0;
			if ($damage > 0) {
				$msg = $buff['effectmsg'];
			} else if ($damage == 0) {
				$msg = $buff['effectfailmsg'];
			} else if ($damage < 0) {
				$msg = $buff['effectfailmsg'];
			}
		}
		$goodguy['hitpoints'] += $healhp;
		$msg = str_replace("{badguy}",$badguy['name'], $msg);
		$msg = str_replace("{damage}",$healhp, $msg);
		if ($msg > ""){
			output("`)$msg`n");
			$message=$message.$goodguy[name].": \"`i$msg`i\"`n";
		}
	}
}

function process_dmgshield($dshield, $damage) {
	global $session,$badguy,$message;
	reset($dshield);
	while(list($key,$buff) = each($dshield)) {
		$realdamage = $damage * $buff['damageshield'];
		if ($realdamage < 0) $realdamage = 0;
		if ($realdamage > 0) {
			$msg = $buff['effectmsg'];
		} else if ($realdamage == 0) {
			$msg = $buff['effectnodmgmsg'];
		} else if ($realdamage < 0) {
			$msg = $buff['effectfailmsg'];
		}
		$badguy[hitpoints] -= $realdamage;
		$msg = str_replace("{badguy}",$badguy['name'], $msg);
		$msg = str_replace("{damage}",$realdamage, $msg);
		if ($msg > ""){
			output("`)$msg`n");
			$message=$message.$goodguy[name].": \"`i$msg`i\"`n";
		}
	}
}
function expire_buffs() {
	global $goodguy,$badguy;
	reset($goodguy['bufflist']);
	reset($badguy['bufflist']);
	while (list($key, $buff) = each($goodguy['bufflist'])) {
		if ($buff['used']) {
			$goodguy['bufflist'][$key]['used'] = 0;
			$goodguy['bufflist'][$key]['rounds']--;
			if ($goodguy['bufflist'][$key]['rounds'] <= 0) {
				if ($buff['wearoff']) {
					$msg = $buff['wearoff'];
					$msg = str_replace("{badguy}", $badguy['name'], $msg);
					output("`)$msg`n");
					$message=$message.$goodguy[name].": \"`i$msg`i\"`n";
				}
				unset($goodguy['bufflist'][$key]);
			}
		}
	}
}

$cost=$session[user][level]*20;

if ($HTTP_GET_VARS[op]=="challenge"){
	if($_GET[name]=="" && $session[user][playerfights]>0){
		$ppp=25; // Players Per Page to display
		if (!$_GET[limit]){
			$page=0;
		}else{
			$page=(int)$_GET[limit];
			addnav("Previous Page","pvparena.php?op=challenge&limit=".($page-1)."");
		}
		$limit="".($page*$ppp).",".($ppp+1); // love PHP for this ;)
		pvpwarning();
		$days = getsetting("pvpimmunity", 5);
		$exp = getsetting("pvpminexp", 1500);
		output("`6Who do you want to challenge? Arena fee is `^$cost `6gold. Your opponent will be prepared for this fight.`nYou have `4".$session[user][playerfights]."`6 challenges left for today.`n`n");
	  	$sql = "SELECT name,alive,location,sex,level,laston,loggedin,login,pvpflag FROM accounts WHERE 
		(locked=0) AND 
		(age > $days OR dragonkills > 0 OR pk > 0 OR experience > $exp) AND
		(level >= ".($session[user][level]-1)." AND level <= ".($session[user][level]+2).") AND 
		(acctid <> ".$session[user][acctid].")
		ORDER BY level DESC LIMIT $limit";
	  	$result = db_query($sql) or die(db_error(LINK));

/* from my PvP-Immunity Script -- removed for now
		if ($session['user']['pvpflag']=="2013-10-06 00:42:00"){
			output("`n`&Du hast PvP-Immunit�t gekauft. Diese verf�llt, wenn du jetzt angreifst!`0`n`n");
		}
*/

		if (db_num_rows($result)>$ppp) addnav("Next page","pvparena.php?op=challenge&limit=".($page+1)."");
		output("<table border='0' cellpadding='3' cellspacing='0'><tr><td>Name</td><td>Level</td><td>Status</td><td>Ops</td></tr>",true);
		for ($i=0;$i<db_num_rows($result);$i++){
			$row = db_fetch_assoc($result);

/* PvP-Immunity by anpera -- removed for now
			if ($row[pvpflag]!="2013-10-06 00:42:00"){
*/

		  		$biolink="bio.php?char=".rawurlencode($row[login])."&ret=".urlencode($_SERVER['REQUEST_URI']);
		  		addnav("", $biolink);
				$loggedin=(date("U") - strtotime($row[laston]) < getsetting("LOGINTIMEOUT",900) && $row[loggedin]);
		  		output("<tr class='".($i%2?"trlight":"trdark")."'><td>$row[name]</td><td>$row[level]</td><td>".($loggedin?"`#Online`0":"`3Offline`0")."</td><td>[ <a href='$biolink'>Bio</a> | <a href='pvparena.php?op=challenge&name=".rawurlencode($row[login])."'>Challenge</a> ]</td></tr>",true);
				addnav("","pvparena.php?op=challenge&name=".rawurlencode($row[login]));
//			}
		}
		output("</table>",true);
  		addnav("Back to Arena","pvparena.php");
	}else if ($session[user][playerfights]<=0){
		output("`6You don't have enough power anymore to fight another player.");
		addnav("Back to Arena","pvparena.php");
	}else{
		if ($session[user][gold]>=$cost){
		  	$sql = "SELECT acctid,name,level,sex,hitpoints,maxhitpoints,lastip,emailaddress FROM accounts WHERE login='".$_GET[name]."'"; 
		  	$result = db_query($sql) or die(db_error(LINK));
			$row = db_fetch_assoc($result);

/* Anticheat by anpera -- removed for now
			if ($session[user][lastip]==$row[lastip] || $session[user][emailaddress]==$row[emailaddress]){
				output("`n`4Du kannst deine eigenen oder derart verwandte Spieler nicht zu einem Duell herausfordern!`0`n`n");
			}else{
*/

				$sql = "SELECT * FROM pvp WHERE acctid2=".$session[user][acctid]." OR acctid1=$row[acctid] OR acctid2=$row[acctid]";
		  		$result = db_query($sql) or die(db_error(LINK));
				if (db_num_rows($result)){
					output("`6Someone was faster with this challenge!");
				}else{
					$sql = "INSERT INTO pvp (acctid1,acctid2,name1,name2,lvl1,lvl2,hp1,maxhp1,att1,def1,weapon1,armor1,darkartuses1,magicuses1,thieveryuses1,bufflist1,turn) 
					VALUES (".$session[user][acctid].",$row[acctid],'".addslashes($session[user][name])."','".addslashes($row[name])."',".$session[user][level].",$row[level],".$session[user][hitpoints].",".$session[user][maxhitpoints].",".$session[user][attack].",".$session[user][defence].",'".addslashes($session[user][weapon])."','".addslashes($session[user][armor])."',".$session[user][darkartuses].",".$session[user][magicuses].",".$session[user][thieveryuses].",'".addslashes($session[user][bufflist])."',0)";
					db_query($sql) or die(db_error(LINK));
					if (db_affected_rows(LINK)<=0) redirect("pvparena.php");
					output("`6You challenged`4 $row[name] `6for a one on one fight and are awaiting ".($row[sex]?"her":"his")." response. You could pay the entrances fee for $row[name]`6 by transfering ");
					output("".($row[sex]?"her":"him")." `^".($row[level]*20)."`6 gold.`n");
					if ($session[user][dragonkills]<2) output("`n`n`i(You can go on with your daily business now. As soon as $row[name]`6 answers, you'll get a message.)`i");
 					systemmail($row[acctid],"`2You were challenged!","`2".$session[user][name]."`2 (Level ".$session[user][level].") challenged you for a duell in the arena. As long as your level doesn't change you can accept or decline this challenge.`nPrepare before entering arena!"); 
					$session[user][gold]-=$cost;
				} 
//			}
  			addnav("Back to Arena","pvparena.php");
		}else{
			output("`4You don't have enough gold with you to pay the fee. With a red head you leave arena.");
			addnav("Back to Arena","pvparena.php");
		}
	}
  	addnav("Back to Village","village.php");
}else if ($HTTP_GET_VARS[op]=="deny"){
	$sql = "DELETE FROM pvp WHERE acctid2=".$session[user][acctid];
	db_query($sql) or die(db_error(LINK));
	$sql="SELECT acctid,name FROM accounts WHERE acctid=$_GET[id]";
  	$result = db_query($sql) or die(db_error(LINK));
	$row = db_fetch_assoc($result);
	output("`6You face $row[name] `6and fear gets control of you. With very thin excuses like \"not enough gold\" you decline the challenge.");
	systemmail($row[acctid],"`2Challenge declined","`2".$session[user][name]."`2 declined your challenge. Maybe you should offer ".($session[user][sex]?"her":"him")." something for the fight."); 
  	addnav("Back to Village","village.php");
}else if ($HTTP_GET_VARS[op]=="accept"){
	if($session[user][gold]<$cost){
		output("`4You can't afford the `^$cost`4 gold for arena fee.");
  		addnav("Back to Village","village.php");
	}else if($session[user][playerfights]<=0){
		output("`4You can't fight anymore today. Wait until next day.");
  		addnav("Back to Village","village.php");
	}else{
	 	$sql = "UPDATE pvp SET name2='".addslashes($session[user][name])."',hp2=".$session[user][hitpoints].",maxhp2=".$session[user][maxhitpoints].",att2=".$session[user][attack].",def2=".$session[user][defence].",weapon2='".addslashes($session[user][weapon])."',armor2='".addslashes($session[user][armor])."',darkartuses2=".$session[user][darkartuses].",magicuses2=".$session[user][magicuses].",thieveryuses2=".$session[user][thieveryuses].",bufflist2='".addslashes($session[user][bufflist])."',turn=2 WHERE acctid2=".$session[user][acctid]."";
		db_query($sql) or die(db_error(LINK));
		if (db_affected_rows(LINK)<=0) redirect("pvparena.php");
		$sql="SELECT * FROM pvp WHERE acctid1=".$session[user][acctid]." OR acctid2=".$session[user][acctid]."";
  		$result = db_query($sql) or die(db_error(LINK));
		$row = db_fetch_assoc($result);
		$session[user][gold]-=$cost;
		arenanav($row);
		stats($row);
	}
}else if ($HTTP_GET_VARS[op]=="back"){
	$sql="SELECT acctid,name FROM accounts WHERE acctid=$_GET[id]";
  	$result = db_query($sql) or die(db_error(LINK));
	$row = db_fetch_assoc($result);
	output("`6You can't wait any longer for $row[name]`6`s response and take back your challenge. But you can't convince the arena management to pay back your fee.`n");
	$sql = "DELETE FROM pvp WHERE acctid1=".$session[user][acctid];
	db_query($sql) or die(db_error(LINK));
	systemmail($row[acctid],"`2Challenge canceled","`2".$session[user][name]."`2 took back the challenge."); 
  	addnav("Back to Village","village.php");
}else if ($HTTP_GET_VARS[op]=="fight"){
	$sql="SELECT * FROM pvp WHERE acctid1=".$session[user][acctid]." OR acctid2=".$session[user][acctid]."";
  	$result = db_query($sql) or die(db_error(LINK));
	$row = db_fetch_assoc($result);
	if ($row[turn]==1){
 		$badguy = array("acctid"=>$row[acctid2],"name"=>$row[name2],"level"=>$row[lvl2],"hitpoints"=>$row[hp2],"attack"=>$row[att2],"defense"=>$row[def2],"weapon"=>$row[weapon2],"armor"=>$row[armor2],"bufflist"=>$row[bufflist2]);
 		$goodguy = array("name"=>$row[name1],"level"=>$row[lvl1],"hitpoints"=>$row[hp1],"maxhitpoints"=>$row[maxhp1],"attack"=>$row[att1],"defense"=>$row[def1],"weapon"=>$row[weapon1],"armor"=>$row[armor1],"darkartuses"=>$row[darkartuses1],"magicuses"=>$row[magicuses1],"thieveryuses"=>$row[thieveryuses1],"bufflist"=>$row[bufflist1]);
	}
	if ($row[turn]==2){
 		$badguy = array("acctid"=>$row[acctid1],"name"=>$row[name1],"level"=>$row[lvl1],"hitpoints"=>$row[hp1],"attack"=>$row[att1],"defense"=>$row[def1],"weapon"=>$row[weapon1],"armor"=>$row[armor1],"bufflist"=>$row[bufflist1]);
 		$goodguy = array("name"=>$row[name2],"level"=>$row[lvl2],"hitpoints"=>$row[hp2],"maxhitpoints"=>$row[maxhp2],"attack"=>$row[att2],"defense"=>$row[def2],"weapon"=>$row[weapon2],"armor"=>$row[armor2],"darkartuses"=>$row[darkartuses2],"magicuses"=>$row[magicuses2],"thieveryuses"=>$row[thieveryuses2],"bufflist"=>$row[bufflist2]);
	}
	stats($row);
	$adjustment=1;
	$goodguy[bufflist]=unserialize($goodguy[bufflist]);
	$badguy[bufflist]=unserialize($badguy[bufflist]);
	if ($HTTP_GET_VARS[skill]=="MP"){
		if ($goodguy[magicuses] >= $HTTP_GET_VARS[l]){
			$creaturedmg = 0;
			switch($HTTP_GET_VARS[l]){
			case 1:
				$goodguy[bufflist]['mp1'] = array(
					"startmsg"=>"`n`^You begin to regenerate!`n`n",
					"name"=>"`%Regeneration",
					"rounds"=>5,
					"wearoff"=>"You have stopped regenerating",
					"regen"=>$goodguy['level'],
					"effectmsg"=>"You regenerate for {damage} health.",
					"effectnodmgmsg"=>"You have no wounds to regenerate.",
					"activate"=>"roundstart");
				break;
			case 2:
				$goodguy[bufflist]['mp2'] = array(
					"startmsg"=>"`n`^{badguy}`% is clutched by a fist of earth and slammed to the ground!`n`n",
					"name"=>"`%Earth Fist",
					"rounds"=>5,
					"wearoff"=>"The earthen fist crumbles to dust.",
					"minioncount"=>1,
					"effectmsg"=>"`) A huge fist of earth pummels {badguy} for `^{damage}`) points.",
					"minbadguydamage"=>1,
					"maxbadguydamage"=>$goodguy['level']*3,
					"activate"=>"roundstart"
					);
				break;
			case 3:
				$goodguy[bufflist]['mp3'] = array(
					"startmsg"=>"`n`^Your weapon glows with an unearthly presence.`n`n",
					"name"=>"`%Siphon Life",
					"rounds"=>5,
					"wearoff"=>"Your weapon's aura fades.",
					"lifetap"=>1, //ratio of damage healed to damage dealt
					"effectmsg"=>"You are healed for {damage} health.",
					"effectnodmgmsg"=>"You feel a tingle as your weapon tries to heal your effectivly healthy body.",
					"effectfailmsg"=>"Your weapon wails as you deal no damage to your opponent.",
					"activate"=>"offense,defense",
					);
				break;
			case 5:
				$goodguy[bufflist]['mp5'] = array(
					"startmsg"=>"`n`^Your skin sparkles as you assume an aura of lightning`n`n",
					"name"=>"`%Lightning Aura",
					"rounds"=>5,
					"wearoff"=>"With a fizzle, your skin returns to normal.",
					"damageshield"=>2,
					"effectmsg"=>"{badguy} recoils as lightning arcs out from your skin, hitting for `^{damage}`) damage.",
					"effectnodmg"=>"{badguy} is slightly singed by your lightning, but otherwise unharmed.",
					"effectfailmsg"=>"{badguy} is slightly singed by your lightning, but otherwise unharmed.",
					"activate"=>"offense,defense"
				);
			break;
			}
			$goodguy[magicuses]-=(int)$HTTP_GET_VARS[l];
		}else{
			$goodguy[bufflist]['mp0'] = array(
				"startmsg"=>"`nYou furrow your brow and call on the powers of the elements.  A tiny flame appears.  {badguy} lights a cigarette from it, giving you a word of thanks before swinging at you again.`n`n",
				"rounds"=>1,
				"activate"=>"roundstart"
			);
		}
	}
	if ($HTTP_GET_VARS[skill]=="DA"){
		if ($goodguy[darkartuses] >= $HTTP_GET_VARS[l]){
			$creaturedmg = 0;
			switch($HTTP_GET_VARS[l]){
			case 1:
				$goodguy[bufflist]['da1']=array(
					"startmsg"=>"`n`\$You call on the spirits of the dead, and skeletal hands claw at {badguy} from beyond the grave.`n`n",
					"name"=>"`\$Skeleton Crew",
					"rounds"=>5,
					"wearoff"=>"Your skeleton minions crumble to dust.",
					"minioncount"=>round($goodguy[level]/3)+1,
					"maxbadguydamage"=>round($goodguy[level]/2,0)+1,
					"effectmsg"=>"`)An undead minion hits {badguy} for `^{damage}`) damage.",
					"effectnodmgmsg"=>"`)An undead minion tries to hit {badguy} but `\$MISSES`)!",
					"activate"=>"roundstart"
					);
				break;
			case 2:
				$goodguy[bufflist]['da2']=array(
					"startmsg"=>"`n`\$You pull out a tiny doll that looks like {badguy}`n`n",
					"effectmsg"=>"You thrust a pin into the {badguy} doll hurting it for `^{damage}`) points!",
					"minioncount"=>1,
					"maxbadguydamage"=>round($goodguy[attack]*3,0),
					"minbadguydamage"=>round($goodguy[attack]*1.5,0),
					"activate"=>"roundstart"
					);
				break;
			case 3:
				$goodguy[bufflist]['da3']=array(
					"startmsg"=>"`n`\$You place a curse on {badguy}'s ancestors.`n`n",
					"name"=>"`\$Curse Spirit",
					"rounds"=>5,
					"wearoff"=>"Your curse has faded.",
					"badguydmgmod"=>0.5,
					"roundmsg"=>"{badguy} staggers under the weight of your curse, and deals only half damage.",
					"activate"=>"defense"
					);
				break;
			case 5:
				$goodguy[bufflist]['da5']=array(
					"startmsg"=>"`n`\$You hold out your hand and {badguy} begins to bleed from its ears.`n`n",
					"name"=>"`\$Wither Soul",
					"rounds"=>5,
					"wearoff"=>"Your victim's soul has been restored.",
					"badguyatkmod"=>0,
					"badguydefmod"=>0,
					"roundmsg"=>"{badguy} claws at its eyes, trying to release its own soul, and cannot attack or defend.",
					"activate"=>"offense,defense"
					);
				break;
			}
			$goodguy[darkartuses]-=(int)$HTTP_GET_VARS[l];
		}else{
			$goodguy[bufflist]['da0'] = array(
				"startmsg"=>"`nExhausted, you try your darkest magic, a bad joke.  {badguy} looks at you for a minute, thinking, and finally gets the joke.  Laughing, it swings at you again.`n`n",
				"rounds"=>1,
				"activate"=>"roundstart"
				);
		}
	}
	if ($HTTP_GET_VARS[skill]=="TS"){
		if ($goodguy[thieveryuses] >= $HTTP_GET_VARS[l]){
			$creaturedmg = 0;
			switch($HTTP_GET_VARS[l]){
			case 1:
				$goodguy[bufflist]['ts1']=array(
					"startmsg"=>"`n`^You call {badguy} a bad name, making it cry.`n`n",
					"name"=>"`^Insult",
					"rounds"=>5,
					"wearoff"=>"Your victim stops crying and wipes its nose.",
					"roundmsg"=>"{badguy} feels dejected and cannot attack as well.",
					"badguyatkmod"=>0.5,
					"activate"=>"defense"
					);
				break;
			case 2:
				$goodguy[bufflist]['ts2']=array(
					"startmsg"=>"`n`^You apply some poison to your ".$goodguy[weapon].".`n`n",
					"name"=>"`^Poison Attack",
					"rounds"=>5,
					"wearoff"=>"Your victim's blood has washed the poison from your blade.",
					"atkmod"=>2,
					"roundmsg"=>"Your attack is multiplied!",
					"activate"=>"offense"
					);
				break;
			case 3:
				$goodguy[bufflist]['ts3'] = array(
					"startmsg"=>"`n`^With the skill of an expert thief, you virtually dissapear, and attack {badguy} from a safer vantage point.`n`n",
					"name"=>"`^Hidden Attack",
					"rounds"=>5,
					"wearoff"=>"Your victim has located you.",
					"roundmsg"=>"{badguy} cannot locate you.",
					"badguyatkmod"=>0,
					"activate"=>"defense"
					);
				break;
			case 5:
				$goodguy[bufflist]['ts5']=array(
					"startmsg"=>"`n`^Using your skills as a thief, dissapear behind {badguy} and slide a thin blade between its vertibrae!`n`n",
					"name"=>"`^Backstab",
					"rounds"=>5,
					"wearoff"=>"Your victim won't be so likely to let you get behind it again!",
					"atkmod"=>3,
					"defmod"=>3,
					"roundmsg"=>"Your attack is multiplied, as is your defense!",
					"activate"=>"offense,defense"
					);
				break;
			}
			$goodguy[thieveryuses]-=(int)$HTTP_GET_VARS[l];
		}else{
			$goodguy[bufflist]['ts0'] = array(
				"startmsg"=>"`nYou try to attack {badguy} by putting your best thievery skills in to practice, but instead, you trip over your feet.`n`n",
				"rounds"=>1,
				"activate"=>"roundstart"
				);
		}
	}
	if ($goodguy[hitpoints]>0 && $badguy[hitpoints]>0) {
		output ("`\$`c`b~ ~ ~ Fight ~ ~ ~`b`c`0");
		output("`@You have encountered `^$badguy[name]`@ which lunges at you with `%$badguy[weapon]`@");
		// Let's display what buffs the opponent is using - oh yeah
		$buffs="";
		$disp[bufflist]=$badguy[bufflist];
		reset($disp[bufflist]);
		while (list($key,$val)=each($disp[bufflist])){
			$buffs.=" `@and `#$val[name] `7($val[rounds] rounds)";
		}
		if (count($disp[bufflist])==0){
			$buffs.=appoencode("",true);
		}
		output("$buffs");
		output(" `@!`0`n`n");
		output("`2Level: `6$badguy[level]`0`n");
		output("`2`bStart of round:`b`n");
		output("`2$badguy[name]`2's Hitpoints: `6$badguy[hitpoints]`0`n");
		output("`2YOUR Hitpoints: `6$goodguy[hitpoints]`0`n");
	}
	reset($goodguy[bufflist]);
	while (list($key,$buff)=each($goodguy['bufflist'])){
		$buff[used]=0;
	}
	if ($badguy[hitpoints]>0 && $goodguy[hitpoints]>0){
		$buffset = activate_buffs("roundstart");
		$creaturedefmod=$buffset['badguydefmod'];
		$creatureatkmod=$buffset['badguyatkmod'];
		$atkmod=$buffset['atkmod'];
		$defmod=$buffset['defmod'];
	}
	if ($badguy[hitpoints]>0 && $goodguy[hitpoints]>0){
		$adjustedcreaturedefense = $badguy[defense];
		$creatureattack = $badguy[attack]*$creatureatkmod;
		$adjustedselfdefense = ($goodguy[defense] * $adjustment * $defmod);
		while($creaturedmg==0 && $selfdmg==0){
			$atk = $goodguy[attack]*$atkmod;
			if (e_rand(1,20)==1) $atk*=3;
			$patkroll = e_rand(0,$atk);
			$catkroll = e_rand(0,$adjustedcreaturedefense);
			$creaturedmg = 0-(int)($catkroll - $patkroll);
			if ($creaturedmg<0) {
				$creaturedmg = (int)($creaturedmg/2);
				$creaturedmg = round($buffset[badguydmgmod]*$creaturedmg,0);
			}
			if ($creaturedmg > 0) {
				$creaturedmg = round($buffset[dmgmod]*$creaturedmg,0);
			}
			$pdefroll = e_rand(0,$adjustedselfdefense);
			$catkroll = e_rand(0,$creatureattack);
			$selfdmg = 0-(int)($pdefroll - $catkroll);
			if ($selfdmg<0) {
				$selfdmg=(int)($selfdmg/2);
				$selfdmg = round($selfdmg*$buffset[dmgmod], 0);
			}
			if ($selfdmg > 0) {
				$selfdmg = round($selfdmg*$buffset[badguydmgmod], 0);
			}
		}
	}
	if ($badguy[hitpoints]>0 && $goodguy[hitpoints]>0){
		$buffset = activate_buffs("offense");
		if ($atk > $goodguy[attack]) {
			if ($atk > $goodguy[attack]*3){
				if ($atk>$godguy[attack]*4){
					output("`&`bYou execute a <font size='+1'>MEGA</font> power move!!!`b`n",true);
				}else{
					output("`&`bYou execute a DOUBLE power move!!!`b`n");
				}
			}else{
				if ($atk>$goodguy[attack]*2){
					output("`&`bYou execute a power move!!!`b`0`n");
				}elseif ($atk>$goodguy['attack']*1.25){
					output("`7`bYou execute a minor power move!`b`0`n");
				}
			}
		}
		if ($creaturedmg==0){
			output("`4You try to hit `^$badguy[name]`4 but `\$MISS!`n");
			$message=$message."`^$goodguy[name]`4 tries to hit you but `\$MISSES!`n";
			if ($badguy[hitpoints]>0 && $goodguy[hitpoints]>0) process_dmgshield($buffset[dmgshield], 0);
			if ($badguy[hitpoints]>0 && $goodguy[hitpoints]>0) process_lifetaps($buffset[lifetap], 0);
		}else if ($creaturedmg<0){
			output("`4You try to hit `^$badguy[name]`4 but are `\$RIPOSTED `4for `\$".(0-$creaturedmg)."`4 points of damage!`n");
			$message=$message."`^$goodguy[name]`4 tries to hit you but you `^RIPOSTE`4 for `^".(0-$creaturedmg)."`4 points of damage!`n";
			$badguy['diddamage']=1;
			$goodguy[hitpoints]+=$creaturedmg;
			if ($badguy[hitpoints]>0 && $goodguy[hitpoints]>0) process_dmgshield($buffset[dmgshield],-$creaturedmg);
			if ($badguy[hitpoints]>0 && $goodguy[hitpoints]>0) process_lifetaps($buffset[lifetap],$creaturedmg);
		}else{
			output("`4You hit `^$badguy[creaturename]`4 for `^$creaturedmg`4 points of damage!`n");
			$message=$message."`^$goodguy[name]`4 hits you for `\$$creaturedmg`4 points of damage!`n";
			$badguy[hitpoints]-=$creaturedmg;
			if ($badguy[hitpoints]>0 && $goodguy[hitpoints]>0) process_dmgshield($buffset[dmgshield],-$creaturedmg);
			if ($badguy[hitpoints]>0 && $goodguy[hitpoints]>0) process_lifetaps($buffset[lifetap],$creaturedmg);
		}

	/* from hardest punch mod by anpera -- removed for now
		if ($creaturedmg>$session[user][punch]){
			$session[user][punch]=$creaturedmg;
			output("`@`b`c--- DAS WAR DEIN BISHER H�RTESTER SCHLAG! ---`c`b`n");
		}
	*/

	}
	if ($goodguy[hitpoints]>0 && $badguy[hitpoints]>0) $buffset = activate_buffs("defense");
	expire_buffs();
	if ($goodguy[hitpoints]>0 && $badguy[hitpoints]>0){
		output("`2`bEnd of Round:`b`n");
		output("`2$badguy[name]`2's Hitpoints: `6$badguy[hitpoints]`0`n");
		output("`2YOUR Hitpoints: `6".$goodguy[hitpoints]."`0`n");
	}

	$goodguy[bufflist]=serialize($goodguy[bufflist]);
	$badguy[bufflist]=serialize($badguy[bufflist]);
	if ($row[acctid1]){ // battle still in DB? Result of round:
		if ($badguy[hitpoints]>0 and $goodguy[hitpoints]>0){
			$message=addslashes($message);
			if ($row[turn]==1) $sql = "UPDATE pvp SET hp1=$goodguy[hitpoints],hp2=$badguy[hitpoints],thieveryuses1=$goodguy[thieveryuses],darkartuses1=$goodguy[darkartuses],magicuses1=$goodguy[magicuses],bufflist1='".addslashes($goodguy[bufflist])."',lastmsg='$message',turn=2 WHERE acctid1=".$session[user][acctid]."";
			if ($row[turn]==2) $sql = "UPDATE pvp SET hp1=$badguy[hitpoints],hp2=$goodguy[hitpoints],thieveryuses2=$goodguy[thieveryuses],darkartuses2=$goodguy[darkartuses],magicuses2=$goodguy[magicuses],bufflist2='".addslashes($goodguy[bufflist])."',lastmsg='$message',turn=1 WHERE acctid2=".$session[user][acctid]."";
			db_query($sql) or die(db_error(LINK));
			if (db_affected_rows(LINK)<=0) redirect("pvparena.php");
			output("`n`n`2You are awaiting your opponents move.");
			addnav("Refresh","pvparena.php");
		}else if ($badguy[hitpoints]<=0){
			$win=$badguy[level]*20+$goodguy[level]*20;
			$exp=$badguy[level]*10-(abs($goodguy[level]-$badguy[level])*10);
			if ($badguy[level]<=$goodguy[level]){
				$session[user][battlepoints]+=2;
			}else{
				$session[user][battlepoints]+=3*($badguy[level]-$goodguy[level]);
			}
			output("`n`&Right before your final blow the referee stops the fight and declares your victory!`0`n"); 
			output("`b`\$You have beaten $badguy[name] `\$!`0`b`n");
			output("`#You get the reward of `^$win`# gold and gain some battle points!`n");
			// $session['user']['donation']+=1; // anpera's donation system removed
			output("You gain `^$exp`# experience!`n`0");
			$session['user']['gold']+=$win;
			$session['user']['playerfights']--;
			$session['user']['experience']+=$exp;
			$exp = round(getsetting("pvpdeflose",5)*10,0);
			$sql = "UPDATE accounts SET charm=charm-1,experience=experience-$exp,playerfights=playerfights-1 WHERE acctid=$badguy[acctid]";
			db_query($sql);
			$mailmessage = "`^$goodguy[name]`2 has beaten you with %p `^".$goodguy['weapon']."`2 in the arena!"
				." `n`n%o had `^".$goodguy['hitpoints']."`2 hitpoints left after the fight."
				." `n`nYou lost `\$$exp`2 experience.";
 			$mailmessage = str_replace("%p",($session['user']['sex']?"her":"his"),$mailmessage);
 			$mailmessage = str_replace("%o",($session['user']['sex']?"She":"He"),$mailmessage);
 			systemmail($badguy['acctid'],"`2You were beaten in the arena",$mailmessage); 
			addnews("`\$$goodguy[name]`6 beats `\$$badguy[name]`6 in a duell in `3the Arena`6!");
			$sql = "DELETE FROM pvp WHERE acctid1=".$session[user][acctid]." OR acctid2=".$session[user][acctid];
			db_query($sql) or die(db_error(LINK));
		}else if ($goodguy[hitpoints]<=0){
			$exp=$badguy[level]*10-(abs($goodguy[level]-$badguy[level])*10);
			$win=$badguy[level]*20+$goodguy[level]*20;
			if ($badguy[level]>=$goodguy[level]){
				$points=2;
			}else{
				$points=3*($goodguy[level]-$badguy[level]);
			}
			$sql = "SELECT taunt FROM taunts ORDER BY rand(".e_rand().") LIMIT 1";
			$result = db_query($sql) or die(db_error(LINK));
			$taunt = db_fetch_assoc($result);
			$taunt = str_replace("%s",($session[user][sex]?"her":"him"),$taunt[taunt]);
			$taunt = str_replace("%o",($session[user][sex]?"she":"he"),$taunt);
			$taunt = str_replace("%p",($session[user][sex]?"her":"his"),$taunt);
			$taunt = str_replace("%x",($session[user][weapon]),$taunt);
			$taunt = str_replace("%X",$badguy[weapon],$taunt);
			$taunt = str_replace("%W",$badguy[name],$taunt);
			$taunt = str_replace("%w",$session[user][name],$taunt);
			$badguy[acctid]=(int)$badguy[acctid];
			$badguy[creaturegold]=(int)$badguy[creaturegold];
			systemmail($badguy[acctid],"`2 You were successful in arena! ","`^".$session[user][name]."`2 lost the battle in arena!`n`nYou gained `^$exp`2 experience and won `^$win`2 gold!"); 
			$sql = "UPDATE accounts SET gold=gold+$win,experience=experience+$exp,donation=donation+1,playerfights=playerfights-1,battlepoints=battlepoints+$points WHERE acctid=$badguy[acctid]";
			db_query($sql);
			$exp = round(getsetting("pvpdeflose",5)*10,0);
			$session[user][experience]-=$exp;
			$session['user']['playerfights']--;
			output("`n`b`&You were beaten by `%$badguy[name]`&!!!`n");
			output("$taunt");
			output("`n`4You lost `^$exp experience and some of your proud!`n");
			if ($session[user][charm]>0) $session[user][charm]--;
			addnews("`\$$badguy[name]`6 beatst `\$$goodguy[name]`6 in a duell in `3the Arena`6!");
			$sql = "DELETE FROM pvp WHERE acctid1=".$session[user][acctid]." OR acctid2=".$session[user][acctid];
			db_query($sql) or die(db_error(LINK));
		}
	}else{
		output("`6Your fight was over before it has started. The paid fee will be used to keep the arena in shape.");
	}
  	addnav("Back to Village","village.php");
}else if ($HTTP_GET_VARS[op]==""){
	$sql="SELECT * FROM pvp WHERE acctid1=".$session[user][acctid]." OR acctid2=".$session[user][acctid]."";
  	$result = db_query($sql) or die(db_error(LINK));
	$row = db_fetch_assoc($result);
	$text=0;
	if($row[acctid1]==$session[user][acctid] && $row[turn]==0){
 		$text=1;
		output("`6You remember a challenge with `&$row[name2] `6and walk towards the arena. But your opponent seems not to be around here.`n");
		addnav("Take back challenge","pvparena.php?op=back&id=$row[acctid2]");
		if (@file_exists("battlearena.php")) addnav("Challenge Gladiator","battlearena.php"); // ONE arena for TWO things - if installed ;)
 		addnav("Back to Village","village.php");
		stats($row);
	}else if($row[acctid1]==$session[user][acctid] && $row[turn]==1){
		stats($row);
		arenanav($row);
	}else if($row[acctid1]==$session[user][acctid] && $row[turn]==2){
		stats($row);
		output("`6Your opponent `&$row[name2]`6 has not done his move yet.`n`n");
		$text=1;
		if (@file_exists("battlearena.php")) addnav("Challenge Gladiator","battlearena.php");
 		addnav("Back to Village","village.php");
	}else if($row[acctid2]==$session[user][acctid] && $row[turn]==0){
		output("`6You were challenged by `&$row[name1] `6. If you accept, you must pay `^$cost`6 gold for arena fee.`n");
		addnav("You were challenged by $row[name1]");
		addnav("Accept","pvparena.php?op=accept");
		addnav("Decline","pvparena.php?op=deny&id=$row[acctid1]");
	}else if($row[acctid2]==$session[user][acctid] && $row[turn]==1){
		stats($row);
		output("`6Your opponent `&$row[name2]`6 has not done his move yet.`n`n");
		$text=1;
		if (@file_exists("battlearena.php")) addnav("Challenge Gladiator","battlearena.php");
 		addnav("Back to Village","village.php");
	}else if($row[acctid2]==$session[user][acctid] && $row[turn]==2){
		stats($row);
		arenanav($row);
	}else{
		$text=1;
		addnav("Challenge Player","pvparena.php?op=challenge");
		if (@file_exists("battlearena.php")) addnav("Challenge Gladiator","battlearena.php");
 		addnav("Back to Village","village.php");
	}
	if($text==1){
		checkday();
		addcommentary();
	  	addnav("Refresh","pvparena.php");
		output("`6You enter the huge arena near the training camp. In it some warriors train their special abilities in battles, ");
		output("to find out who is the best. Honor and a good rank in arena ranking is what this fights are about.`n"); 
		$sql="SELECT * FROM pvp WHERE acctid1 AND acctid2 AND turn>0";
  		$result = db_query($sql) or die(db_error(LINK));
		if (db_num_rows($result)){
			output(" You watch the hustle and bustle for a while.`nThe following wariors are fighting right now:`n`n<table border='0' cellpadding='3' cellspacing='0'><tr><td align='center'>`bChallenger`b</td><td align='center'>`bDefender`b</td><td align='center'>`bResult (HP)`b</td></tr>",true);
			for ($i=0;$i<db_num_rows($result);$i++){
				$row = db_fetch_assoc($result);
				output("<tr class='".($i%2?"trlight":"trdark")."'><td>$row[name1]</td><td>$row[name2]</td><td>$row[hp1] : $row[hp2]</td></tr>",true);
			}
			output("</table>`n`n",true);
		}else{
			output("`n`n`6No warriors fighting right now.`n`n");
		}
		viewcommentary("pvparena","scream:",10,"screams");
	}
}

page_footer();

// this is not the end ;)
?>