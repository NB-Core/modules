<?php
// addnews ready
// mail ready
// translator ready

/* Garden of Honor */
/* ver 1.0 by Gilwen */
/* 25 August 2005 */


require_once("lib/villagenav.php");
require_once("lib/http.php");
require_once("common.php");
require_once("lib/commentary.php");

function midgargarden_getmoduleinfo(){
    $info = array(
        "name"=>"Garden of Honor",
        "version"=>"1.0",
        "author"=>"Gilwen",
        "category"=>"Village",
        "download"=>"core_module",
        "settings"=>array(
            "Midgar G�rten - Einstellungen,title",
			"midgargardenloc"=>"Wo erscheinen die G�rten?,location|".getsetting("villagename", LOCATION_FIELDS)
        ),
    );
    return $info;
}

function midgargarden_install(){
	module_addhook("changesetting");
	module_addhook("newday");
	module_addhook("village");
    return true;
}

function midgargarden_uninstall(){
    return true;
}

function midgargarden_dohook($hookname,$args){
    global $session;
    switch($hookname){
   	case "changesetting":
		if ($args['setting'] == "villagename") {
			if ($args['old'] == get_module_setting("midgargardenloc")) {
				set_module_setting("midgargardenloc", $args['new']);
			}
		}
		break;
	case "village":
		if ($session['user']['location'] == get_module_setting("midgargardenloc")) {
            tlschema($args['schemas']['fightnav']);
			addnav($args['fightnav']);
            tlschema();
			addnav("Garden of Honor","runmodule.php?module=midgargarden");
		}
		break;
	}
    return $args;
}


function midgargarden_run() {
    global $session;
	page_header("The Garden of Honor");
	$op = httpget('op');
	$looktoday=get_module_pref("looktoday");
	output("`&`c`bThe Garden of Honor`7`b`c`n");

addcommentary();
checkday();

    if ($op == "") {
		output("`2 You stroll along a small, sandy path, away from the sounds of the village, away from the noise of the warriors.`n`n");
		output("A little archway, overgrown by pretty red roses, shows you the way into a garden.`n`n");
		output("The wrought-iron door opens as if by magic and leads you into the Garden of Honor.`n`n");

			addnav("Enter","runmodule.php?module=midgargarden&op=enter");
	
		addnav("Back to the Village","village.php");
	}elseif($op=="enter"){
		output("`2You enter the Garden of Honor. Many colored flowers, like `^yellow roses`2, `9light blue forget-me-nots`2 and fresh `@green trees`2 are giving peace to this place");
		output("In the middle of the garden, surrounded by roses and tulips, you can see a `&white`2 rock.`n`n");
		output("Beyond the trees are wooden benches, filled with tired warriors, searching for peace.");
		output("Where do you want to go?");
		addnav("`&Go to the white rock","runmodule.php?module=midgargarden&op=rock");
		addnav("`2Go to the benches","runmodule.php?module=midgargarden&op=bank");
		addnav("Back to the village","village.php");


    }elseif($op=="rock"){
		output("`2You walk into the direction of the `&white rock`2, passing by sleepy warriors, resting on the smooth grass.`n Your way leads you to a soft plate within the `&white rock`2. You start to read the inscription: `n`n`c`r This rock is a symbol for peace and friendship, a symbol to honor our friends and allies, to honor our village chief, who made this village, to what it is now:`c `c`5`n`n Enter name of village chief`c");
		output("`&You stay for a while, to think about the work, that is caused by building a town.`n`n");
		addnav("Back to the garden","runmodule.php?module=midgargarden&op=enter");		
		villagenav();
    }elseif($op=="bank"){
		output("`2You arrive the benches. Many warriors are sitting here, resting and talking about forgetten stories and great tales of heros.`n`n");
		addnav("Back to the garden","runmodule.php?module=midgargarden&op=enter");
		
		modulehook("midgargarden", array());

		viewcommentary("midgargarden","Tell",30,"tells");
		villagenav();
    }
	page_footer();
}
?>
