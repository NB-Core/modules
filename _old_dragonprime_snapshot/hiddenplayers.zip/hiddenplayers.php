<?

function hiddenplayers_getmoduleinfo(){
    $info = array(
        "name"=>"Hidden Players",
        "author"=>"Sixf00t4 - edit from XChrisX's onlinelist",
        "version"=>"20050509",
        "category"=>"Administrative",
        "download"=>"http://dragonprime.net/users/sixf00t4/hiddenplayers.zip",
        "vertxtloc"=>"http://dragonprime.net/users/sixf00t4/",
        "allowanonymous" => 1,
        "prefs"=>array(
            "Hidden preferences,title",
            "hidden"=>"Is user hidden?,bool|0",
        ),
    );
    return $info;
}

function hiddenplayers_install(){
    module_addhook("onlinecharlist");
    return true;
}

function hiddenplayers_uninstall(){
    return true;
}

function hiddenplayers_dohook($hookname, $args){
    define("ALLOW_ANONYMOUS",true);
    
    switch($hookname) {
        case "onlinecharlist":
        	$args['handled'] = true;
			$list_players = "";
            $accounts = db_prefix("accounts");
            $module_userprefs = db_prefix("module_userprefs");
            $sql="SELECT name,acctid,alive,location,sex,level,laston,loggedin,lastip,uniqueid FROM " . db_prefix("accounts") . " WHERE locked=0 AND loggedin=1 AND laston > '".date("Y-m-d H:i:s",strtotime("-".getsetting("LOGINTIMEOUT",900)." seconds"))."' ORDER BY level DESC";
			$result = db_query($sql);
			$count = db_num_rows($result);
			$list_players = appoencode(sprintf(translate_inline("`bCharacters Online`n(%s Player):`b`n"),$count));
			for ($i=0;$i<$count;$i++){
				$row = db_fetch_assoc($result);
				if (get_module_pref("hidden", "hiddenplayers", $row['acctid']) == false) {
                $list_players .= appoencode("`^{$row['name']}`n");
                $onlinecount_players++;
                }
			}
			db_free_result($result);
			if ($onlinecount_players == 0)
				$list_players .= appoencode(translate_inline("`inone`i"));

			$args['list'] = $list_players;
			$args['count'] = $onlinecount_players;
            break;
    }
    return $args;
}

function hiddenplayers_run() {
}
?>