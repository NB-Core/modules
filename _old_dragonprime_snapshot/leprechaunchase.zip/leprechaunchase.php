<?php
//=================================================================//
//   Title: The Leprechaun's Pouch                                 //
//   Type: Forest Event                                            //
//   Version: 0.7b                                                 //
//   Tested: LoGD 0.9.7                                            //
//   Dated: August 5, 2004                                         //
//   Author: Czeresthra (czeresthra@elusia.frandt.com)             //
//   Notes: This event was inspired by the leprechauns of          //
//          Irish folklore. Less than 2 hours to create.           //
//=================================================================//

// 8/5/04: Changed the ratios so there's a 1 in 3 chance of the gold being fake, and a 2 in 3 chance of the gem.
// 8/5/04: Added an option to keep chasing if he outruns you. Makes it kinda fun.

if (!isset($session)) exit();

$session[user][specialinc]="leprechaunpouch.php";

switch($HTTP_GET_VARS[op]){
case "black":
	output("`@You snatch the black pouch from the little man's belt. ");
	output("He squirms out of your grip and disappears into the bushes, cackling madly. ");
	output("You carefully open the pouch and examine the contents... `^500`@ gold pieces! ");
	output("Knowing the reputation that the wee folk have for trickery, you pull a coin from the pouch. ");
	$res = e_rand(0,2);
	if($res<=1) {
		output("It turns to ash in your hand. A gentle breeze scatters it across the ground. You've been had!`7");
	} else {
		$session['user']['gold']+=500;
		output("You're in luck! The coin's as real as you are. With a triumphant grin on your face, you return to the forest.`7");
	}
	addnav("(C) Continue","forest.php?op=leave");
	break;
case "white":
	output("`@You snatch the white pouch from the little man's belt. ");
	output("He squirms out of your grip and disappears into the bushes, cackling madly. ");
	output("You carefully open the pouch and examine the contents... `%a shiny gem`@! ");
	output("Knowing the reputation that the wee folk have for trickery, you pull it from the pouch. ");
	$res = e_rand(0,2);
	if($res>=1) {
		output("It turns to ash in your hand. A gentle breeze scatters it across the ground. You've been had!`7");
	} else {
		$session['user']['gems']+=1;
		output("You're in luck! The gem's as real as you are. With a triumphant grin on your face, you return to the forest.`7");
	}
	addnav("(C) Continue","forest.php?op=leave");
	break;
case "chase":
	$session['user']['turns']--;
	output("`^You use up a forest fight in the chase!`7`n`n");
	$res = e_rand(0,1);
	if($res==1) {
	output("`@The slippery little man is fast, but you are faster. ");
	output("You snatch him up by the ear and hold on to him, pinning his little arms to his sides.`n`n");
	output("\"`2Geroff me! Let me go!`@\" he shrieks, but when he realizes that isn't going to work, he starts to cry.`n`n");
	output("\"`2Please let me go,`@\" he sniffles. \"`2I've a wife and seven babes at home! ");
	output("All me wealth is in me pouches, you can take yer pick, just let me go!`@\"`7`n`n");
	addnav("(B) Black Pouch","forest.php?op=black");
	addnav("(W) White Pouch","forest.php?op=white");
	} else {
	output("`@Try as you might, the slippery little man is just too fast for you.`7`n`n");
	addnav("(K) Keep chasing","forest.php?op=chase");
	addnav("(R) Return to the Forest","forest.php?op=leave");
	}
	break;
case "leave":
	$session[user][specialinc]="";
	break;
default:
	output("`@You spy a flash of `2green`@ darting between two bushes. You'd swear it was a `2leprechaun`@! ");
	output("If you could only capture him, he'd share his `b`^gold`b`@ with you in exchange for his freedom.`7`n`n");
	addnav("(C) Chase the little fellow","forest.php?op=chase");
	addnav("(K) Keep moving","forest.php?op=leave");
}
?>