****************************************************************
Name: Hidden Chest
Author: Eth - ethstavern(at)gmail(dot)com 
Version: 1.0
Release Date: 01-06-2006
About: Readme file for hiddenchest.zip
Files: hiddenchest.php
***************************************************************

To install, drop into your modules directory and activate 
via the Modules Manager. 

Players can find a hidden chest via a forest special. They're 
limited in number, and can store gold and gems inbetween DK's.

Via the settings, you can define how many chests are available,
how many dragonkills a user must have to find one, the chance of finding one,
the chance of losing one after a dk, and the amount of gold and gems that can
be stored within in.