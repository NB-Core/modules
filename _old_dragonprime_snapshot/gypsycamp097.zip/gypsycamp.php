<? 
/********************
Gypsy Camp - special 
Written by Robert for Maddnet LoGD
*********************/
if (!isset($session)) exit(); 
if ($HTTP_GET_VARS[op]==""){

addnav("Gypsy camp"); 
addnav("");
addnav("Eat"); 
addnav("(B) Bread","forest.php?op=bread");  
addnav("Drink");  
addnav("(H) Bucket of Water","forest.php?op=water");   
addnav("(W) Goblet of Wine","forest.php?op=wine"); 
addnav("(S) Spanish Fly","forest.php?op=fly"); 
addnav("other");
addnav("(L) Blind Gypsy","forest.php?op=blind"); 
addnav("(G) Gypsy Dancer","forest.php?op=dancer"); 
addnav("(M) Myra the Gypsy","forest.php?op=myra"); 
addnav("(V) Vlad the Gypsy","forest.php?op=vlad"); 
addnav("Leave"); 
addnav("(R) Return to Forest","forest.php?op=leave"); 
$session[user][specialinc] = "gypsycamp.php";

output("`n`3`c`bGypsy Camp`b`c `n `n");
output(" `2You stumble through the Forest, and have come upon a small clearing.`n");
output(" You found a `3Gypsy Camp`2! `n"); 
output(" `2You can see Covered Wagon's and Donkey Carts. The campfire is blazing.`n");
output(" There is a brightly lit torch near every Covered Wagon. `n"); 
output(" The `3Gypsy's `2are now aware of you within their camp, some go into their Wagon, others smile at you. `n"); 
output(" A `3Gypsy woman `2offers you something to drink and eat from the table near the campfire. `n"); 
 
  
}else if ($HTTP_GET_VARS[op]=="bread"){ 
  $session[user][turns]--; 
    if (e_rand(0,1)==0){ 
          output("`2You grab the Bread from the table.  Famished by hunger you eat the whole loaf, and you feel a surge of power enter your body!`n`n  `&You gain 2 uses of Theiving Skills`n`#But you are saddened as you know the power will vanish tommorow."); 
                $session[user][thieveryuses] = $session[user][thieveryuses] + 2; 
    }else{ 
    output(" `2You grab the Bread from the table.  Famished by hunger you eat the whole loaf, and begin to think you ate too much!`n You no longer have the strength to fight so much today!`n`n`&You lose 2 Forest Fights."); 
                $session[user][turns]-=2; 
        
    } 
    addnav("(R) Return to Forest","forest.php"); 
    $session[user][specialinc]=""; 
    
}else if ($HTTP_GET_VARS[op]=="water"){ 
  $session[user][turns]--; 
    if (e_rand(0,1)==0){ 
          output("`#You grab a ladle and drink from the Bucket of Water on the table.  Quenching your thirst, you feel quite refreshed!`n`n  `&Your hitpoints are restored."); 
                $session[user][hitpoints] = $session[user][maxhitpoints];  
    }else{ 
              output("`#You grab a ladle and drink from the Bucket of Water on the table.  Quenching your thirst, you suddenly realize you just drank used Bath Water!`n`n  `&You lost some hitpoints."); 
                $session[user][hitpoints]=8;  
    } 
    addnav("(R) Return to Forest","forest.php"); 
    $session[user][specialinc]="";
    
}else if ($HTTP_GET_VARS[op]=="wine"){ 
  $session[user][turns]--; 
    if (e_rand(0,1)==0){ 
          output("`2You grab the `3Goblet of Wine `2from upon the table.  Quenching your thirst, you feel a sense of power enter your body!`n`n  `&Your hitpoints are increased."); 
                $session[user][hitpoints]+=8;
                $session[user][drunkenness]+=50;  
    }else{ 
          output("`2You grab the `3Goblet of Wine `2from upon the table.  While drinking, you feel something slimy and ALIVE go down your throat! You feel sick.`n`n  `&You lost some hitpoints."); 
                $session[user][hitpoints]-=8;  
    } 
    addnav("(R) Return to Forest","forest.php"); 
    $session[user][specialinc]="";
    
}else if ($HTTP_GET_VARS[op]=="dancer"){ 
  $session[user][turns]--; 
    if (e_rand(0,1)==0){ 
          output("`2You notice and walk over to a beautiful young `3Gypsy Dancer`2.  While dancing about the campfire, she see's you admiring her dance and smiles upon you!`n`n  `&Your charm has increased."); 
          $session[user][charm]+=2;  
    }else{ 
          output("`2You notice and walk over to a beautiful young `3Gypsy Dancer`2.  While she is dancing about the campfire, you carelessly throw your nasty tasting wine upon the campfire which `4burst Flames `2and singe the `3Gypsy Dancer`2, she gives you the `3`iEvil Eye`2!`i `&`n`n You are less charming than before!");
          $session[user][charm]-=2;
    } 
    addnav("(R) Return to Forest","forest.php"); 
    $session[user][specialinc]="";

}else if ($HTTP_GET_VARS[op]=="vlad"){ 
  $session[user][turns]--; 
    if (e_rand(0,1)==0){ 
          output("`3Vlad the Gypsy `2admires the scarf your wearing. He offers you `^20 gold `2for it. `nNot liking the old scarf anyway you accept his offer!`n`n  `&You sold the Scarf for 20 gold."); 
          $session[user][gold]+=20;  
    }else{ 
          output("`3Vlad the Gypsy `2admires the scarf your wearing. He offers you `^20 gold `2for it. `nWhile taking off the scarf, you lose your balance and fall backwards into the campfire!`n`n  `&You are injured and lost hitpoints."); 
          $session[user][hitpoints]-=8;
    } 
    addnav("(R) Return to Forest","forest.php"); 
    $session[user][specialinc]="";
 
}else if ($HTTP_GET_VARS[op]=="myra"){ 
  $session[user][turns]--; 
    if (e_rand(0,1)==0){ 
          output("`3Myra the Gypsy `2offer's you a hot bath. Being in the forest for quite some time, `nyou are in need of one and accept her offer. `nAfter bathing in a wooden bath tub, you feel really refreshed!`n`n  `&You gain 5 hitpoints."); 
          $session[user][hitpoints]+=5;  
    }else{ 
          output("`3Myra the Gypsy `2offer's you a hot bath. Being in the forest for quite some time, `nyou are in need of one and accept her offer. `nWhile getting out of the wooden bath tub, you slip and hurt yourself!`n`n  `&You lose 5 hitpoints."); 
          $session[user][hitpoints]-=5;
    } 
    addnav("(R) Return to Forest","forest.php"); 
    $session[user][specialinc]="";
    
}else if ($HTTP_GET_VARS[op]=="blind"){ 
  $session[user][turns]--; 
    if (e_rand(0,1)==0){ 
          output("`3A Blind Gypsy `2sitting at the table offer's your fortune if he is allowed to touch your face, `nseeing no harm in the old man you accept his offer. `n"); 
          output(" He feels around your face and says `3your a very lucky person`2. `nYou sense something mystical has just happened and feel VERY refreshed and anew!"); 
          $session['user']['hitpoints'] = $session[user][maxhitpoints]; 
          // adjust turns to your realm default max
          $session[user][turns]=35; 
          $session[user][drunkenness]-=20; 
          $session['user']['usedouthouse'] = 0;
          $session['user']['seenmaster'] = 0; 
          $session['user']['seenlover'] = 0;
          $session['user']['seenbard'] = 0;
    }else{ 
          output("`3A Blind Gypsy `2sitting at the table offer's your fortune if he is allowed to touch your face, `nseeing no harm in the old man you accept his offer. `n"); 
          output(" He feels around your face and says `3your having a really bad day`2. `nYou sense something mystical has just happened and feel VERY depressed and tired!"); 
          $session[user][hitpoints]=5; 
          $session[user][turns]=1; 
          $session[user][drunkenness]+=20; 
          $session['user']['usedouthouse'] = 1; 
          $session['user']['seenmaster'] = 1;
          $session['user']['seenlover'] = 1;
          $session['user']['seenbard'] = 1;
    } 
    addnav("(R) Return to Forest","forest.php"); 
    $session[user][specialinc]=""; 
    
}else if ($HTTP_GET_VARS[op]=="fly"){ 
  $session[user][turns]--; 
    if (e_rand(0,1)==0){ 
          output("`n`n`2You wonder over to the table and see a vial of `4Spanish Fly`2, `nyou look around and quickly take the vial and drink the contents!`n"); 
          output("`^OH NO!! - you read the label again and it say's `b Spanish Flu `bnot `i Fly`i, `nYou feel like crap and cannot fight so well!`n"); 
          $session[user][hitpoints] -= 5;
          $session[bufflist][107] = array("name"=>"`4Spanish Flu","rounds"=>25,"wearoff"=>"You feel much better.","defmod"=>0.8,"atkmod"=>0.8,"roundmsg"=>"Your sickness makes you very weak.","activate"=>"defense");
    }else{ 
          output("`n`n`2You wonder over to the table and see a vial of `4Spanish Fly`2, `nyou look around and quickly take the vial and drink the contents!`n"); 
          output("`^WOW! To your amazement - You feel like you can take on the world!`n"); 
          $session[user][hitpoints] += 5;
          $session[bufflist][107] = array("name"=>"`#Spanish Fly","rounds"=>25,"wearoff"=>"You feel mortal again.","defmod"=>1.2,"atkmod"=>1.2,"roundmsg"=>"Your spirit is frenzied in battle.","activate"=>"defense");
    } 
    addnav("(R) Return to Forest","forest.php"); 
    $session[user][specialinc]="";  
        
}else if ($HTTP_GET_VARS[op]=="leave"){ 
    output(" `n`n`2You decide you do not have the time to visit with Gypsys today. `nYou leave the `3Gyspy Camp `2and return to the forest."); 
    addnav("(R) Return to forest","forest.php"); 
    $session[user][specialinc]=""; 
}
?> 