<?php

function ninny_getmoduleinfo(){
    $info = array(
        "name"=>"Prancing Ninny",
        "version"=>"0.8",
        "author"=>"Steve McCorry",
        "category"=>"Forest Specials",
		"download"=>"http://dragonprime.net/index.php?module=Downloads;sa=dlview;id=93",
		"vertxtloc"=>"http://dragonprime.net/users/Sichae/",
		"description"=>"A player encounters a Prancing Ninny in the forest, and certain fates can befall the user.",
    );
    return $info;
}

function ninny_install(){
	module_addeventhook("forest", "return 100;");
	return true;
}

function ninny_uninstall(){
	return true;
}

function ninny_dohook($hookname,$args){
    return $args;		
}

function ninny_runevent($type)
{
	global $session;
    $from = "forest.php?";
	$name=$session['user']['name'];
    $session['user']['specialinc']="module:ninny";    
    $op = httpget('op');
    if ($op=="" || $op=="search"){
        output("`)As you continue through the forest you come across a silly looking fellow, prancing about like a ninny. You now find yourself immersed in a dreadfully important decision. Should I trip the poor sap? Or should I let him continue his ridiculous dance... ");
        addnav("Trip him!", $from . "op=Trip him!");
        addnav("Let him be", $from . "op=Let him be");
    }elseif ($op=="Trip him!"){
		if (is_module_active('alignment')) {
		require_once("./modules/alignment/func.php");
					align("-3");
}
        $session['user']['specialinc']="";
        $rand = e_rand(1,7);
        switch ($rand){
        case 1:
        	output("`)You look the idiot over, and you are overcome with the temptation to watch him plummet. ");
			output("You trip the poor sap, and watch him land flat on his face. ");
            output("`)You start laughing SO hard, that you fail to notice that the lummox landed right on top of you!");
			output("Try as you may, his weight is simply too much for you to move. ");
			output("You shift and wriggle to no avail. ");
			output("His arm slides down, and lands on your neck, cutting off your air supply. `n`n");
            output("`4You start gasping and gasping for air, screaming for him to get off of you, but nothing happens, and you're left to die a silent death.`n`n");
            output("`4You have died due to your temptation to trip an innocent bystander.`n");
            output("`)It's not like he robbed you though..your gold is still nestled safely on your person.`n");
            output("`^Tripping some idiot doesn't exactly make you dumber, so you keep the battle experience you have earned.`n");
            output("You may continue playing again tomorrow.");
            $session['user']['alive']=false;
            $session['user']['hitpoints']=0;
            addnav("Daily News","news.php");
            addnews("%s encountered the prancing ninny in the forest, and was not seen again.",$name);
            break;
        case 2:
        	output("`)You start laughing SO hard, that you fail to notice that the lummox landed right on top of you! ");
			output("Try as you may, his weight is simply too much for you to move. ");
			output("You shift and wriggle to no avail. ");
			output("His arm slides down, and lands on your neck, cutting off your air supply. `n`n");
            output("`4You start gasping and gaping for air, screaming for him to get off of you, finally, the ninny gets up, and prances on his ninny way.`n`n");
            output("`^You narrowly avoid death, you lose a forest fight, and a hefty chunk of your hitpoints.");
            if ($session['user']['turns']>0) $session['user']['turns']--;
            if ($session['user']['hitpoints'] > 
                    ($session['user']['hitpoints']*.1))
                $session['user']['hitpoints'] =
                    round($session['user']['hitpoints']*.1,0);
            if ($session['user']['hitpoints'] < 1)
                $session['user']['hitpoints'] = 1;
            break;
        case 3:
        	output("`)You deftly stick out your foot, and watch the preposterous character fall flat on his face! ");
            output("`&You feel INVIGORATED--What a rush!`n`n");
            output("`^Your hitpoints have been restored to full, and you feel the energy for another turn in the forest.");
            if ($session['user']['hitpoints'] <
                    $session['user']['maxhitpoints'])
                $session['user']['hitpoints'] =
                    $session['user']['maxhitpoints'];
            $session['user']['turns']++;
            break;
        case 4:
            output("`)You knock the poor sap right over, and you watch the gem that he stored in his cheeks fly out of his mouth.`n`n");
            output("`^You find a `%GEM`^!");
            $session['user']['gems']++;
            debuglog("got 1 gem by tripping the ninny");
            break;
        case 5:
        	output("`)You trip the ninny, he spits out some gems as he falls! Yay! ");
        	$reward = round(e_rand(1, 4), 0);
			if ($reward == 4) $rewardn = "FOUR gems";
			else if ($reward == 3) $rewardn = "THREE gems";
			else if ($reward == 2) $rewardn = "TWO gems";
			else if ($reward == 1) $rewardn = "ONE gem";
			output("you notice that there %s `%%s`# lying at your feet!`n`n",
					translate_inline($reward==1?"is":"are"),
					translate_inline($rewardn));
			$session['user']['gems']+=$reward;
            debuglog("got $reward gems from the Prancing Ninny");
            break;

        case 6:
			output("The ninny casts a spell on you, right before he hits the ground.");
			if (isset($session['bufflist']['ninny'])) {
					$session['bufflist']['ninny']['rounds'] += 10;
				} else {
					apply_buff('ninny',
						array(
							"name"=>"`3Pranciful Unicorn",
							"rounds"=>20,
							"wearoff"=>"The Unicorn is dismissed.",
							"atkmod"=>1.2,
							"roundmsg"=>"The ferocity of the Unicorn's Horn helps you!",
											)
								);
							}
							break;
        case 7:
        	output("`)You deftly extend your foot, directly in front of the prancing idiot's path. ");
        	output("`)You giggle softly as he falls flat on his face. ");
        	output("`^Somehow, you feel stronger for doing this... ");
            output("`&you feel HEALTHY!`n`n");
            output("`^Your hitpoints have been restored to full. ");
            output("You trip the ninny, and serve him a hot plate of pavement.");        
            output("You feel Powerful!`n`n");
            output("`^You receive an extra forest fight!");
            $session['user']['turns']++;
			if ($session['user']['hitpoints'] <
                    $session['user']['maxhitpoints'])
                $session['user']['hitpoints'] =
                    $session['user']['maxhitpoints'];
                    break;                 
        }
    }else{
		if (is_module_active('alignment')) {
		require_once("./modules/alignment/func.php");
					align("+3");
}
        $session['user']['specialinc']="";
        output("`)You let your conscience get the best of you, and decide that Ninny-tripping isn't on your list of things to do today.`0");
    }
}

function ninny_run(){
}
?>