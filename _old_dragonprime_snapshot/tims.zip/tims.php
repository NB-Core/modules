<?php
/*
Tim Hortons Coffee Shop
File Name:	tims.php
Author:	Gordo (Bradinn) - based upon coding from modules by Chris Vorndran (Sichae)
Date:	Feb 27 2005
Version:2.0 

Tim Hortons is a module put together from Player requests, looking for a little
home town flavour in their modules. This version incorporates Tim Hortons popular Roll Up
The Rim to Win contest. Various fixes in basic code as well as a new navigation structure.
Thanks to Sichae for his help and suggestions for writing cleaner code.  

*/
require_once("lib/http.php");
require_once("lib/villagenav.php");
function tims_getmoduleinfo(){
	$info = array(
		"name"=>"Tim Hortons",
		"author"=>"Bradinn",
		"version"=>"2.0",
		//Note comments at top of code for credits and version information
		"category"=>"Village",
		"download"=>"http://www.waifsplace.ca/lotgd/mods/tims.zip",
		"vertxtloc"=>"http://www.waifsplace.ca",
		"settings"=>array(
			"Tim Hortons Module Settings,title",
				"allow"=>"Amount of visits to Tims allowed per day,int|2",
				"timsloc"=>"Where does Tim Hortons appear,location|".getsetting("villagename", LOCATION_FIELDS),
				"hook"=>"Hook to a single city?,bool|0",
				"(Select no to have Tim Hortons appear in all cities),note",
			),
			"prefs"=>array(
			"Tim Hortons Module Preferences,title",
				"times"=>"How many times has a coffee or doughnuts been bought today,int|0",
				"rollup"=>"roll up the rim to win,int|0",
			)
		);
	return $info;
}
function tims_install(){
	module_addhook("village");
	module_addhook("changesetting");
	module_addhook("newday");
	return true;
}
function tims_uninstall(){
	return true;
}
function tims_dohook($hookname,$args){
	global $session;
	$times=get_module_pref("times");
	switch($hookname){
	case "changesetting":
    if ($args['setting'] == "villagename") {
    if ($args['old'] == get_module_setting("timsloc")) {
       set_module_setting("timsloc", $args['new']);
       }
    }
    break;
  	case "village":
			tlschema($args['schemas']['marketnav']);
			addnav($args['marketnav']);
			tlschema();
			$timsloc = get_module_setting('timsloc');
			$hook = get_module_setting('hook');
			if (get_module_setting('hook')==0||get_module_setting('timsloc')==$session['user']['location']&&get_module_setting('hook')==1) {
				addnav("Tim Hortons","runmodule.php?module=tims&op=enter");
	}
        break;
    case "newday":
    	if ($times>0){
    output("`n`n`QYou feel the Caffeine of Tim Hortons coffee leave your body...`n");
		$times=get_module_pref("times");
        set_module_pref("times",0);
        break;
   }
}
return $args;
}
function tims_run(){
	global $session;
    $times = get_module_pref("times");
    $allow = get_module_setting("allow");
    $theygold = $session['user']['gold'];
    $theygems = $session['user']['gems'];
    $dbldblcst = 5*$session['user']['level'];
    $blksugcost = 10*$session['user']['level'];
	$icecapcost = 20*$session['user']['level'];
	$lattecost = 5*$session['user']['level'];
	$hafdozcost = 5*$session['user']['level'];
	$dozdgncost = 10*$session['user']['level'];
	$timbitcost = 20*$session['user']['level'];

    $op = httpget("op");
    page_header("Tim Hortons");
    
    if($op=="enter" && $times<$allow){
	   	output("`4You step through the Glass doors of the shop, and immediately the warm intoxicating aromas fill your nose.");
	   	output("`4 Warm soothing smell of coffee brewing in the vats, hot and fresh, and the warm baked goodness of doughnuts wafting through the air. ");
		output("`7In front of you is a large wooden counter, large vats sitting over shimmering mystical flames.`n`n"); 
		output("`7Behind the counter, racks of doughnuts await, frosting glistening in the torchlight.`n`n"); 
		output("`4Behind the counter a number of buxom young elven girls are waiting on customers. You step up t the counter and a lovely young elf approaches.");
		output(" `4Her nametag reads Lynn`\$g`Sachen`4. and she smiles a beaming smile at you.`n`n");
		output("`Q\"How may I help you today?\"`4 She looks positively radiant about the idea of bringing you something from the vast selection.");
		addnav("Browse Tim Hortons Menu","runmodule.php?module=tims&op=browse");
    }elseif ($op=="browse"){
		output("`4On the wall above the counter sits a large menu.");
		output(" `4You Glance up, taking in the vast array of items that await your pallet.");
		output(" `4Lynn`\$g`Sachen`4 Watches you, waiting for your decision.");
		output(" `QWhat Can I get you today? She asks you\"");
		addnav("Coffee");
		addnav(array("C?Extra Large Double Double (`^%s gold`0)",$dbldblcst), "runmodule.php?module=tims&op=dbldbl");
		addnav(array("S?Black/triple sugar (`^%s gold`0)",$blksugcost),"runmodule.php?module=tims&op=blksug");
		addnav(array("L?Ice Cap (`^%s gold`0)",$icecapcost),"runmodule.php?module=tims&op=icecap");
		addnav(array("T?Non dairy, Non Fat Latte (`^%s gold`0)",$lattecost),"runmodule.php?module=tims&op=latte");
		addnav(array("C?1/2 Doz. Doughnuts (`^%s gold`0)",$hafdozcost), "runmodule.php?module=tims&op=hafdoz");
		addnav(array("S?1 Dozen Doughnuts (`^%s gold`0)",$dozdgncost),"runmodule.php?module=tims&op=dozdgn");
		addnav(array("L?Family pack of Timbits (`^%s gold`0)",$timbitcost),"runmodule.php?module=tims&op=timbit");
		addnav("Leave");
		villagenav();
	}elseif ($theygold<$dbldblcost){
		output("`4Lynn looks at you with sympathy in her luminous eyes.`n"); 
		output("\"`QI am so sorry, but you do not have enough Gold to afford the food here. You must have at least `%%s `Qgold for an coffee.",$dbldblcost);
		output(" She smiles sadly at you as she points you towards the door.");
		villagenav();
	}elseif ($times>=$allow){
		output("I'm very sorry, but I am afraid that we have completely run out of Coffee and Doughnuts today.`n");
		output("\"`QPerhaps you should try back tomorrow...`4\"");
		villagenav();
	}elseif ($op=="dbldbl"){
		output("\"`&One Extra Large Doube Double. Enjoy!`7\" `n`n");
		output("`n`nYou Suck back your Extra Large Double Double with pleasure.");
		output("`7You feel ENERGIZED!`n");
		output("`7You feel like you could face a few `@extra`7 monsters in the forest!`n`n");
		output("`7You `@gain`7 THREE turns!");
		debuglog("gained turns from drinking a tim hortons coffee");
		$session['user']['turns']+=3;
		$session['user']['gold']-=$dbldblcost;
		$times=get_module_pref("times")+1;
        set_module_pref("times",$times);
        addnav("Roll up the rim","runmodule.php?module=tims&op=rollup");
        villagenav();
	}elseif ($op=="blksug"){
		output("\"`&One Extra Large Black coffee with triple sugar, this will keep you awake today! Enjoy!`7\" `n`n");
		output("`n`nYou Suck back your Extra Large Black coffee with triple sugar and can feel your heart beating in your chest.");
		output("`7You feel Totally buzzed on caffeine!`n");
		output("`7You feel like you could face a few `@extra`7 monsters in the forest! And with more strength!`n`n");
		output("`7You `@gain`7 FIVE turns, and some hit points!");	
		debuglog("gained bonus from eating at Tim Hortons");
		$session['user']['turns']+=5;
		$session['user']['hitpoints']=($session['user']['hitpoints']*1.15);
		$session['user']['gold']-=$blksugcost;
		$times=get_module_pref("times")+1;
        set_module_pref("times",$times);
        addnav("Roll up the rim","runmodule.php?module=tims&op=rollup");
        villagenav();
	}elseif ($op=="icecap"){
		output("\"`&One Tim Hortons Ice Cappucino, the perfect thing for a hot day of monster bashing! Enjoy!`7\" `n`n");
		output("`n`nSo deliciously cold......so wonderfully chocolatty. This is heaven in a glass!!!!");
		output("`7You feel Like you could take on the world!`n");
		output("`7You feel so refreshed you could face a few `@extra`7 monsters in the forest! And with more strength than ever!`n`n");
		output("`7You `@gain`7 FIVE turns, and some hit points!");
		debuglog("gained bonus from eating at Tim Hortons");
		$session['user']['turns']+=7;
		$session['user']['hitpoints']=($session['user']['hitpoints']*2.15);
		$session['user']['gold']-=$icecapcost;
		$times=get_module_pref("times")+1;
        set_module_pref("times",$times);
        addnav("Roll up the rim","runmodule.php?module=tims&op=rollup");
        villagenav();
   	}elseif ($op=="latte"){
		output("\"`&One Non-Fat, Non Dairy Latte coming up! I huess you can order whatever you want to.`7\" `n`n");
		output("`n`nYou sip your effeminate european coffee like a sandal wearing, tree hugging, dope smoking friend of jesus that you must be, ordering a drink like that......You should be ashamed.");
		debuglog("gained bonus from eating at Tim Hortons");
		$session['user']['gold']-=$lattecost;
		$times=get_module_pref("times")+1;
        set_module_pref("times",$times);
        addnav("Roll up the rim","runmodule.php?module=tims&op=rollup");
        villagenav();
	}elseif ($op=="haldoz"){
		output("\"`&One Half Dozen Doughnuts there Buddy. Enjoy!`7\" `n`n");
		output("`n`nYou nibble your way through your doughnuts with extreme pleasure.");
		output("`7You feel Pleasantly sated`n");
		output("`7You feel like you could face a few `@extra`7 monsters in the forest!`n`n");
		output("`7You `@gain`7 THREE turns!");
		debuglog("gained bonus from eating at Tim Hortons");
		$session['user']['turns']+=3;
		$session['user']['gold']-=$hafdozcost;
		$times=get_module_pref("times")+1;
        set_module_pref("times",$times);
        villagenav();
	}elseif ($op=="dozdgn"){
		output("\"`&One dozen assorted doughnuts, Always fresh at Tim Hortons! Enjoy!`7\" `n`n");
    	output("`n`nYou work your way through the frsh doughnutty goodness with glee.");
		output("`7You are on a complete sugar high!`n");
		output("`7You feel like you could face a few `@extra`7 monsters in the forest! And with more strength!`n`n");
		output("`7You `@gain`7 FIVE turns, and some hit points!");					
		debuglog("gained bonus from eating at Tim Hortons");
		$session['user']['turns']+=5;
		$session['user']['hitpoints']=($session['user']['hitpoints']*1.15);
		$session['user']['gold']-=$dozdgncost;
		$times=get_module_pref("times")+1;
        set_module_pref("times",$times);
        villagenav();
	}elseif ($op=="timbit"){
					output("\"`&One Family pack of Tim Hortons Timbits! Enjoy!`7\" `n`n");
					output("`n`nYou don't know how you manage it, but you get them all down The family pack always looks so small on the shelf, but OOOOHHHH so very good!!!!");
					output("`7You feel imbued with doughnutty goodness!`n");
					output("`7You feel so well fed you could face a few `@extra`7 monsters in the forest! And with more strength than ever!`n`n");
					output("`7You `@gain`7 FIVE turns, and some hit points!");	
		debuglog("gained bonus from eating at Tim Hortons");
		$session['user']['turns']+=5;
		$session['user']['hitpoints']=($session['user']['hitpoints']*2.15);
		$session['user']['gold']-=$timbitcost;
		$times=get_module_pref("times")+1;
        set_module_pref("times",$times);
        villagenav();
	}elseif ($op=="rollup"){
		output("`4Once you finish your coffee, you carefully roll up the cups rim, looking for those happy little words that tell you......");
		debuglog("rolled up the rim to win");
        $rollup=(e_rand(1,10));
    	if ($rollup>=5){
		output("\"`&You are a WINNER!!!!!!!!!!!!!!!`7\" `n`n");
		output(" `4Congratulations, you are a winner in Tim Hortons Roll up the Rim to win contest!");
		output(" `4You receive warm smiles from the counter girls.");
		output(" `4as they hand you your newly acquired winners buff.");
		debuglog("gained coffee buff from drinking Tim Hortons coffee");
        villagenav();        
			apply_buff('Tims',
				array(
					"name"=>"`^Tim Hortons coffee",
					"rounds"=>20,
					"wearoff"=>"The caffeine slowly disappates in your blood...",
					"atkmod"=>.8,
					"defmod"=>1.6,
					"roundmsg"=>"`^You can feel the caffeine from the coffee in your blood and it empowers you!",
									)
						);
    }elseif (rollup<5){
		output("\"`&Sorry, you are not a winner. Better Luck next time`7\" `n`n");
		debuglog("was not a winner in Roll up the rim to win");
        villagenav();
}
}
page_footer();
}
?>		