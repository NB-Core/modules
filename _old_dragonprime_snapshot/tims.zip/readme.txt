This module was coded by:  Gord (Bradinn)
With great assistance, and based on coding originally written by Sichae.......

Thank you to Sichae for his patience and answers. 

Storage of File: http://dragonprime.net/users/Bradinn/

Notes regarding this module.....
Version 2.0:
Tim Hortons currently has all cost and bonus setting hardcoded into the script. The next version will have these as admin settable parameters.  

***BE AWARE*** Current settings are for a specific game server that many would likely find unbalanced, and the rewards are fairly high compared to the costs. These setting should be adjusted by changing the $******cost parameters beginning on line 86 of the code. The individual reward setting can be found within the individual op= groupings to change. Until I am more conversant with coding and can change all of these settings to admin changeable entries.....


Instructions for installation-
+Unzip file tims.php
+Drag/FTP tims.php into your /modules folder, in your LotGD directory
+Go into the Superuser Grotto
+Go to Manage Modules
+Install the Tim Hortons Module
+adjust the settings as you wish
+Activate the Module