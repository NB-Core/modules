<?php
if ($_GET['op']=="download"){ // this offers the module on every server for download
	$dl=join("",file("altar.php"));
	echo $dl;
}else{

// Author: Danilo Stern-Sapad aka Ariadoss (info@ariadoss.com)
// Homepage: www.ariadoss.com LoGD Server: www.hogwartslive.com
//

//corrected grammar and better translation-readiness by Nightborn aka Oliver Brendel

function altar_getmoduleinfo(){
        $info = array(
                "name"=>"Forest Altar",
                "version"=>"1.0",
                "author"=>"Danilo Stern-Sapad",
                "category"=>"Forest Specials",
                "download"=>"modules/altar.php?op=download",
        );
        return $info;
}

function altar_install(){
        module_addeventhook("forest", "return 100;");
        return true;
}

function altar_uninstall(){
        return true;
}

function altar_dohook($hookname,$args){
        return $args;
}

function altar_runevent($type){
        require_once("lib/increment_specialty.php");
        global $session;
        // We assume this event only shows up in the forest currently.
        $from = "forest.php?";


        $op = httpget('op');
        if ($op=="" || $op=="search"){
	  		output("`@Du stolperst �ber eine Lichtung, und bemerkst einen Altar mit 5 Seiten vor Dir. Auf jeder Seite liegt ein anderer Gegenstand.Du siehst`# einen Dolch, `$ einen Sch�del,`% einen mit Juwelen besetzten Stab, `^ ein Rechenbrett, `7 und ein schlicht aussehendes Buch.  `@In der Mitte �ber dem Altar befindet sich ein `& Kristallblitz.`n`n");
	    	output("`@Du wei�t, da� es Dich Zeit f�r einen ganzen Waldkampf kosten wird, einen der Gegenst�nde n�her zu untersuchen.`n`n`n");
	    	addnav("Nimm den Dolch", $from."op=dagger");
	    	addnav("Nimm den Sch�del", $from."op=skull");
	    	addnav("Nimm den juwelenbesetzten Stab", $from."op=wand");
	    	addnav("Nimm das Rechenbrett", $from."op=abacus");
	    	addnav("Nimm das Buch", $from."op=book");
	    	addnav("Nimm den Kristallblitz", $from."op=bolt");
	    	addnav("Verlasse den Altar", $from."op=forgetit");
	    	$session['user']['specialinc'] = "module:altar";

		} else if ($op=="dagger") {
  			$session['user']['turns']--;
  			if (e_rand(0,1)==0){
  	        	output("`#Du nimmst den Dolch von seinem Platz. Der Dolch verschwindet und Du f�hlst eine Woge der Macht durch deinen K�rper str�men!`n`n  `&Du bekommst 5 Anwendungen in den Diebesf�higkeiten.`n`n`#Als Du erkennst, da� diese Macht nur bis zum Morgen anhalten wird, bist Du etwas betr�bt.");
                set_module_pref("uses", get_module_pref("uses", "specialtythiefskills") +5, "specialtythiefskills");
    		}else{
    			output("`@`#Du nimmst den Dolch von seinem Platz.  Der Dolch verschwindet und Du f�hlst eine Woge der Macht durch deinen K�rper str�men!`n`n  `&Du steigst 2 Level in den Diebesfertigkeiten auf!");
                set_module_pref("skill", get_module_pref("skill", "specialtythiefskills") +2, "specialtythiefskills");
                set_module_pref("uses", get_module_pref("uses", "specialtythiefskills") +1, "specialtythiefskills");
    		}
    		addnav("Kehre in den Wald zur�ck","forest.php");
    		$session['user']['specialinc']="";

		}else if ($op=="skull"){
	  		$session['user']['turns']--;
    		if (e_rand(0,1)==0){
    			output("`#Du nimmst den Sch�del von seinem Platz. Der Sch�del verschwindet und Du f�hlst eine Woge der Macht durch deinen K�rper str�men!`n`n  `&Du bekommst 5 Anwendungen in den Dunklen K�nsten.`n`n`#Als Du erkennst, da� diese Macht nur bis zum Morgen anhalten wird, bist Du etwas betr�bt.");
                set_module_pref("uses", get_module_pref("uses", "specialtydarkarts") +5, "specialtydarkarts");
    		}else{
    			output("`@`#Du nimmst den Sch�del von seinem Platz. Der Sch�del verschwindet und Du f�hlst eine Woge der Macht durch deinen K�rper str�men!`n`n  `&Du steigst 2 Level in den Dunklen K�nsten auf!");
                set_module_pref("skill", get_module_pref("skill", "specialtydarkarts") +2, "specialtydarkarts");
                set_module_pref("uses", get_module_pref("uses", "specialtydarkarts") +1, "specialtydarkarts");
    		}
    		addnav("Kehre in den Wald zur�ck","forest.php");
    		$session['user']['specialinc']="";

		}else if ($op=="wand"){
  			$session['user']['turns']--;
    		if (e_rand(0,1)==0){
          		output("`#Du nimmst den Stab von seinem Platz. Der Stab verschwindet und Du f�hlst eine Woge der Macht durch deinen K�rper str�men!`n`n  `&Du bekommst 5 Anwendungen in den Mystischen Kr�ften.`n`n`#Als Du erkennst, da� diese Macht nur bis zum Morgen anhalten wird, bist Du etwas betr�bt.");
                set_module_pref("uses", get_module_pref("uses", "specialtymysticpower") +5, "specialtymysticpower");
    		}else{
    			output("`@`#Du nimmst den Stab von seinem Platz. Der Stab verschwindet und Du f�hlst eine Woge der Macht durch deinen K�rper str�men!`n`n  `&Du steigst 2 Level in den Mystischen Kr�ften auf.");
                set_module_pref("skill", get_module_pref("skill", "specialtymysticpower") +2, "specialtymysticpower");
                set_module_pref("uses", get_module_pref("uses", "specialtymysticpower") +1, "specialtymysticpower");
		    }
		    addnav("Kehre in den Wald zur�ck","forest.php");
		    $session['user']['specialinc']="";

		}else if ($op=="abacus"){
	  		$session['user']['turns']--;
    		if (e_rand(0,1)==0){
      			$gold = e_rand($session['user']['level']*30,$session['user']['level']*90);
      			$gems = e_rand(1,4);
      			output("`#Du nimmst das Rechenbrett von seinem Platz.  Das Rechenbrett verwandelt sich in einen Beutel voller Gold und Edelsteine!`n`n Du erh�lst %s Goldst�cke und %s Edelsteine!",$gold,$gems);
      	  		$session['user']['gold']+=$gold;
        		$session['user']['gems']+=$gems;
    		}else{
        		$gold = $session['user']['gold']+($session['user']['level']*20);
    			output("`@`#Du nimmst das Rechenbrett von seinem Platz. Das Rechenbrett verwandelt sich in einen Beutel voller Gold!`n`nDu erh�lst %s Goldst�cke!",$gold);
        		$session['user']['gold']+=$gold;
        		$session['user']['gems']+=$gems;
        	}
    		addnav("Kehre in den Wald zur�ck","forest.php");
    		$session['user']['specialinc']="";

		}else if ($op=="book"){
  			$session['user']['turns']--;
    		if (e_rand(0,1)==0){
    	  		$exp=$session['user']['experience']*0.2;
    	  		output("`#Du nimmst das Buch von seinem Platz und beginnst darin zu lesen. Das im Buch enthaltene Wissen �bertr�gt sich auf Dich. In der Hoffnung, da� auch andere Reisende ihren Nutzen daraus ziehen k�nnen, legst Du es zur�ck auf den Altar.`n`nDu erh�lst %s Erfahrung!",$exp);
    	    	$session['user']['experience']+=$exp;
    		}else{
    	    	$exp=$session['user']['experience']*0.4;
    			output("`@`#Du nimmst das Buch von seinem Platz und beginnst darin zu lesen. Das Buch enth�lt Geheimnisse die deine heutige Reise durch den Wald profitabler gestalten werden.");
				output(" In der Hoffnung das auch andere Reisende ihren Nutzen daraus ziehen k�nnen, legst Du es zur�ck auf den Altar.`n`nDu erh�lst %s Erfahrung!",$exp);
    	    	$session['user']['experience']+=$exp;
    	    }
    		addnav("Kehre in den Wald zur�ck","forest.php");
    		$session['user']['specialinc']="";

		}else if ($op=="bolt"){
	  		$session['user']['turns']--;
    		$bchance=e_rand(0,7);
    		if ($bchance==0){
    	        output("`#Du greifst nach dem Kristallblitz um ihn von seiner Ruhest�tte zu entfernen. Der Blitz l�st sich in deinen H�nden auf und erstrahlt wieder �ber dem Altar. Nach einigen erfolglosen Versuchen ihn erneut an Dich zu nehmen, entscheidest Du Dich keine Zeit mehr damit zu verschwenden.");
				output(" Es k�nnte ja auch wom�glich die G�tter zu erz�rnen.");
    	        addnav("Kehre in den Wald zur�ck","forest.php");
    	    }elseif ($bchance==1){
    			output("`#Du greifst nach dem Kristallblitz, um ihn von seiner Ruhest�tte zu entfernen. Als Du ihn ber�hrst, wirst Du von einer Woge der Macht zu Boden geschleudert. Wieder auf den Beinen sp�rst Du neue Kr�fte in Dir!`n`n");
				output("Du erh�lst 2 Anwendungen in mystischen Kr�ften, dunklen K�nsten und den Diebesfertigkeiten!");
				output(" Als Du erkennst, da� diese Macht nur bis zum Morgen anhalten wird, bist Du etwas betr�bt.");
                set_module_pref("uses", get_module_pref("uses", "specialtythiefskills") +2, "specialtythiefskills");
                set_module_pref("uses", get_module_pref("uses", "specialtydarkarts") +2, "specialtydarkarts");
                set_module_pref("uses", get_module_pref("uses", "specialtymysticpower") +2, "specialtymysticpower");
	            addnav("Kehre in den Wald zur�ck","forest.php");
	        }elseif($bchance==2){
                output("`#Du greifst nach dem Kristallblitz, um ihn von seiner Ruhest�tte zu entfernen. Als Du ihn ber�hrst, wirst Du von einer Woge der Macht zu Boden geschleudert. Wieder auf den Beinen sp�rst Du neue Kr�fte in Dir!`n`n");
				output("Du erh�lst eine Anwendung in mystischen Kr�ften, dunklen K�nsten und den Diebesfertigkeiten!");
				output(" Als Du erkennst, da� diese Macht nur bis zum Morgen anhalten wird, bist Du etwas betr�bt.");
                set_module_pref("skill", get_module_pref("skill", "specialtythiefskills") +1, "specialtythiefskills");
                set_module_pref("skill", get_module_pref("skill", "specialtydarkarts") +1, "specialtydarkarts");
                set_module_pref("skill", get_module_pref("skill", "specialtymysticpower") +1, "specialtymysticpower");
                set_module_pref("uses", get_module_pref("uses", "specialtythiefskills") +1, "specialtythiefskills");
                set_module_pref("uses", get_module_pref("uses", "specialtydarkarts") +1, "specialtydarkarts");
                set_module_pref("uses", get_module_pref("uses", "specialtymysticpower") +1, "specialtymysticpower");
	            addnav("Kehre in den Wald zur�ck","forest.php");
	        }elseif($bchance==3){
				output("`#Du greifst nach dem Kristallblitz, um ihn von seiner Ruhest�tte zu entfernen. Als Du ihn ber�hrst, wirst Du von einer Woge der Macht zu Boden geschleudert. Wieder auf den Beinen sp�rst Du neue Kr�fte in Dir!`n`nDeine maximale Lebensenergie hat sich um 3 Punkte erh�ht!");
	            $session['user']['maxhitpoints']+=3;
				$session['user']['hitpoints']+=3;
	            addnav("Kehre in den Wald zur�ck","forest.php");
	        }elseif($bchance==4){
				output("`#Du greifst nach dem Kristallblitz, um ihn von seiner Ruhest�tte zu entfernen. Als Du ihn ber�hrst, wirst Du von einer Woge der Macht zu Boden geschleudert. Wieder auf den Beinen sp�rst Du neue Kr�fte in Dir!`n`nDu erh�lst je 1 Punkt Angriff und Verteidigung!");
				$session['user']['attack']+=1;
				$session['user']['defense']+=1;
	            addnav("Kehre in den Wald zur�ck","forest.php");
	        }elseif($bchance==5){
                $exp=$session['user']['experience']*0.15;
	            output("`#Du greifst nach dem Kristallblitz, um ihn von seiner Ruhest�tte zu entfernen. Als Du ihn ber�hrst, wirst Du von einer Woge der Macht zu Boden geschleudert. Wieder auf den Beinen sp�rst Du neue Kr�fte in Dir!`n`n");
				output("Du erh�lst %s Erfahrungspunkte!",$exp);
	            $session['user']['experience']+=$exp;
	            addnav("Kehre in den Wald zur�ck","forest.php");
	        }elseif($bchance==6){
				$exp=$session['user']['experience']*.15;
	            output("`#Dich nach dem Kristallblitz streckend bemerkst Du um Dich herum das aufziehen schwarzer Gewitterwolken. Angst steigt in Dir hoch... Du bef�rchtest, die G�tter erz�rnt zu haben und versuchst zu fliehen. Ein herabkrachender Blitz l�sst Dich niedergestreckt am Boden zur�ck.`n`n");
				output("Du f�hlst Dich irgendwie d�mmer! Du verlierst %s Erfahrungspunkte!",$exp);
	            $session['user']['experience']-=$exp;
	            addnav("Kehre in den Wald zur�ck","forest.php");
	        }else{
	            output("`#Dich nach dem Kristallblitz streckend bemerkst Du um Dich herum das aufziehen schwarzer Gewitterwolken. Angst steigt in Dir hoch und Du bef�rchtest die G�tter erz�rnt zu haben und versuchst zu fliehen. Ein herabkrachender Blitz l�sst Dich niedergestreckt am Boden zur�ck.`n`nDu bist tot!");
	            output("Du verlierst 5% deiner Erfahrung und alles Gold das Du bei Dir tr�gst!`n`n");
	            output("Du kannst morgen weiterspielen");
	            $session['user']['alive']=false;
	            $session['user']['hitpoints']=0;
	            $session['user']['gold']=0;
	            $session['user']['experience']=$session['user']['experience']*0.95;
	            addnav("T�gliche News","news.php");
	            addnews("%s`^ wurde von den G�ttern bestraft, weil %s`^ zu gierig wurde!",$session['user']['name'],translate_inline($session['user']['sex']?"sie":"er"));
	        }
	    $session['user']['specialinc']="";

	}else if ($op=="forgetit"){
		output("`@Du entschliesst Dich, Dein Schicksal nicht herauszufordern... oder gar den Zorn der G�tter! Du verl�sst den Altar unber�hrt.");
    	output("Als Du den Ort verlassen willst, stolperst Du �ber einen kleinen Beutel mit 2 Edelsteinen! Die G�tter scheinen Dir zugetan zu sein!");
    	$session['user']['gems']+=2;
    	addnav("Kehre in den Wald zur�ck","forest.php");
    	$session['user']['specialinc']="";
	}
}

function altar_run(){
}
}
?>