<?php
require_once("common.php");
require_once("lib/http.php");
require_once("lib/villagenav.php");

function funkwagnalls_getmoduleinfo(){
	$info = array(
		"name"=>"Funk & Wagnalls",
		"author"=>"Deedee & Mentaloid",
		"version"=>"1.0",
		"category"=>"Village",
		"download"=>"http://dragonprime.net/index.php?action=viewfiles;user=Deedee",
		"description"=>"Allows a user to be able to spend a configurable amount of gems & gold to buy an enchanted mayo jar.  Fan tribute to Johnny Carson.",
		"settings"=>array(
			"Funk & Wagnalls,title",
			"minlevel"=>"Minimum level to buy,int|15",
			"maxgold"=>"Maximum gold stored,int|3000",
			"costgold"=>"Cost in gold,int|3000",
			"costgems"=>"Cost in gems,int|15"
		),
		"prefs"=>array(
			"Funk & Wagnalls,title",
			"jarexists"=>"Does this person own a jar,int|0",
			"jarvalue"=>"value of jar,int|3000"
		)
		);
	return $info;
}
function funkwagnalls_install(){
	module_addhook("village");
	return true;
}
function funkwagnalls_uninstall(){
	return true;
}
function funkwagnalls_dohook($hookname,$args){
	global $session;
	switch ($hookname){
		case "village":
			tlschema($args['schemas']['marketnav']);
	        addnav($args['marketnav']);
			tlschema();
	        addnav("Funk & Wagnalls","runmodule.php?module=funkwagnalls&op=enter");
			break;
		}
	return $args;
}
function funkwagnalls_run(){
	global $session;
	$op = httpget('op');
	$minlevel = get_module_setting('minlevel');
	$maxgold = get_module_setting('maxgold');
	$costgold = get_module_setting('costgold');
	$costgems = get_module_setting('costgems');
	$jarexists = get_module_pref('jarexists');
	$jarvalue = get_module_pref('jarvalue');
	$reqgold = $costgold + $maxgold;
	page_header("Funk & Wagnalls");
	if (strlen($op) < 1) { $op = 'enter';}
	switch ($op){
		case "enter":
			if ($jarexists > 0) {
				if ($session['user']['level'] >= $minlevel) {	
					// user has jar, but can not redeem.
					output("`#You make your way across a front porch strewn with old mayonnaise jars and in to the shop.  `%Carnac The Magnificent `#is nowhere to be seen, so you go about locating your jar.`n`nTo your relief, you find your jar safe and sound on the front porch, where you placed it at noon today.  The enchantment placed upon it is strong and your attempts to weaken the hermetic seal fail.`n`nSuddenly `%Carnac `#appears and the great sooth sayer bids you come back when you have proven yourself as a village hero, and not before!`0");
					// only option is to return to village.
				} else {
					// user has jar, and is sufficiently low enough to redeem.
					output("`#You make your way across a front porch strewn with old mayonnaise jars and in to the shop.  `%Carnac The Magnificent `#is nowhere to be seen, so you gaze at the jars and the strange writing on them.  `n`nTo your astonishment, you find there is a jar with your name on it!`0");
	                addnav ("Open Jar", "runmodule.php?module=funkwagnalls&op=open");
	                // otherwise there is an option to return to village.
				}
			} else {
				//no jar!
				if ($session['user']['gold'] < $reqgold) {
					// user has not enough gold.
					output("`#You make your way across a front porch strewn with old mayonnaise jars and in to the shop.  `%Carnac The Magnificent `#stands before you in a most ornate headdress and informs you that you are unworthy of a jar today.`n`nCome back when you have more `^gold!`0");
					// only option is to return to village.
				} elseif ($session['user']['gems'] < $costgems) {
					// user has not enough gems.
					output('`#You make your way across a front porch strewn with old mayonnaise jars and in to the shop.  `%Carnac The Magnificent `#stands before you in a most ornate headdress and informs you that you are unworthy of a jar today.`n`nCome back when you have more `$gems!`0');
					// only option is to return to village.
				} elseif ($session['user']['level'] < $minlevel) {
					// user is not high enough level.
					output("`#You make your way across a front porch strewn with old mayonnaise jars and in to the shop.  `%Carnac The Magnificent `#stands before you in a most ornate headdress and informs you that you are unworthy of a jar today.`n`nCome back when you have more `^experience `#as a great warrior!`0");
					// only option is to return to village.
				} else {
					// user meets requirements.
					output("`#You make your way across a front porch strewn with old mayonnaise jars and in to the shop.  `%Carnac The Magnificent `#quickly approaches you from a dark corner of the shop, wearing a most elaborate and ornate headdress.  The great `%sooth sayer `#ushers you through a door in the back of the shop you had previously never noticed.`n`n");
					output("Once inside, it is explained to you that for a sum of`^ %s gold `#and`$ %s gems `#you too may enchant a mayonnaise jar. An enchanted jar holds`^ %s gold `#safely while the realm's bravest warriors seek the `@Green Dragon.`n`n`#Do you choose to enchant a jar at this time warrior?`n",$reqgold,$costgems,$maxgold);
	                addnav ("Enchant Jar", "runmodule.php?module=funkwagnalls&op=enchant");
	                // otherwise there is an option to return to village.
				}
			}
		break;
		case "enchant":
				output("`#As you slowly repeat the chant after `%Carnac `#utters it, the hermetic seal on a mayonnaise jar which has been sealed since noon today on the front porch of this very establishment, pops open with a pop that almost hurts your ears.  You quickly place your gold inside and step away while the jar glows bright for a moment and then all is darkness again.`n`nYou are satisfied that all is well, but just the same make haste to leave this place and return to your mission.`0");
				set_module_pref('jarexists',1);
				set_module_pref('jarvalue',$maxgold);
				$session['user']['gold']-=$reqgold;
				$session['user']['gems']-=$costgems;
				// only option is to return to town.
		break;
		case "open":
				output("`#Although you can not remember from whence it came, you repeat a chant from the dark recesses of your mind... at the end of which you hear the hermetic seal on the mayonnaise jar pop.  A flash of light blinds you for a moment, but as your vision returns, you discover a quantity of gold therein!`n`nYou empty it into your leather pouch and pull closed the draw string as you quickly leave this mysterious place.`0");
				$session['user']['gold']+=get_module_pref('jarvalue');
				set_module_pref('jarexists',0);
				set_module_pref('jarvalue',0);
				// only option is to return to town.
		break;
		default:
		break;
	}
	villagenav();
	page_footer();
}
?>