<?
/*
This is a generic shop, the variables at the start configure the shop prices and quantities.

To use it you just put it in the main folder and link to it from the village, or wherever, then change the relevant bits to suit the shop.

by Spider
*/

// base value, this is how much 1 of this shops commodity costs:
$baseprice=750;
// increase this is the base value is for more than 1 item, i.e. 10 favour with Ramius
$multiplier=5;
// this is the amounts the shop actually sells, each is a multiple of the base amount
// because of how the nav works, you shouldn't put more than 9 values in here.
$quantities=array(1=>1,2,4);
// this bit calculates the prices of the items, giving a discount for buying more at once
// the discount increases the more items you buy at once, so if you put to large a number in the quantities array the discount could be too much.
$x=1;
while($quantities[$x] != $null){
	$prices[$x]=$multiplier * round(($quantities[$x]*$baseprice) *(1-(0.025*($quantities[$x]-1))));
	$x++;
}
// this is the name of the thing the shop is selling (it goes in the navigation) (the plural will work best)
// i.e. gems, or favour
$commodity="commodity";

require_once "common.php";
// change this page header to suit your shop
page_header("Generic Shop");
$x=1;
while($quantities[$x] != $null){
	$q=$multiplier * $quantities[$x];
	addnav("$x?Buy $q $commodity ($prices[$x]gp)","market-genericshop.php?op=buy&level=$x");
	$x++;
}
// return nav, change if it's not the village
addnav("Return to the Village","village.php");
if ($_GET[op]==""){
	// this is the dialog on entry to the shop
	output("The nice shopkeeper wants to sell you something.`n");
}
elseif($_GET[op]=="buy"){
	if ($session[user][gold]>=$prices[$_GET[level]]){
		// this is the dialog when you buy something
		output("The nice shopkeeper takes your ".($prices[$_GET[level]])." gold coins and gives you a commodity.`n`n");
		output("You gain ".$multiplier * $quantities[$_GET[level]]." commodities.`n`n");
		$session[user][gold]-=$prices[$_GET[level]];
		// change this bit to the commodity the shop sells
		$session[user][commodity]+=$quantities[$_GET[level]];
	}
	else{
		// this is the dialog when you can't afford the commodity
		output("The nice shopkeeper is sorry that he can't offer you charity, and instead simply points out that you need more gold.`n`n");
	}
}
page_footer();
?>