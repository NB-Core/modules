<?
/**************************************************/
/* Garden Pond                                    */
/* ------------                                   */
/* Version 1.09                                   */
/* Written by Jake Taft (Zanzaras)                */
/* (Based on the Lily Pond by Shawn Strider)      */
/**************************************************/

/********************************************************************************/
/* Version History                                                              */
/* ---------------                                                              */
/*  1.00 - Original release using a "reworked" version of Strider's "LilyPond"   */
/*        as the framework/core for the mod and adding my own swimming area     */
/*        idea to the mix. Thanks Strider for the use of your code! - Zanzaras  */
/*  1.01 - Cleaned up some of Zan's bad spelling - Elessa                       */
/*  1.02 - Fixed a bug where the player would find elvish gold twice; Fixed a   */
/*         bug where two means of exit were available after falling asleep with */
/*         the frogs. - Zanzaras                                                */
/*  1.03 - Fixed a bug that would allow a player to "relax" as many times as he */
/*         wanted; Also rerouted some of the "return" navs. - Zanzaras          */
/*  1.04 - Fixed a minor bug where the module was not checking to see if a      */
/*         player's turns had been reduced below zero (resulting in showing a   */
/*         player having -2 turns left) - Zanzaras                              */
/*  1.05 - Fixed a bug that was giving players an extra turn when it should     */
/*         have been setting them to 0. - Zanzaras                              */
/*  1.06 - Fixed a bug that was miscalculating the damage a turtle bite does;   */
/*         Modified the whole module to be a little gentler to the players;     */
/*         Modified the wording of some of the relaxation events. - Zanzaras    */
/*  1.07 - Properly hooked the gardenwaterfallcave commentary to the "moderate" */
/*         hook in commentary.php. - Zanzaras                                   */
/*  1.08 - Fixed a bug that would cause the wrong city to display in the news   */
/*         (thanks Excalibur). - Zanzaras                                       */
/*  1.09 - Added a description field to the module. - Zanzaras                  */
/********************************************************************************/


/****************************************************************************/
/* More information regarding LilyPond                                      */
/* -----------------------------------                                      */
/* Shawn Strider's original version of LilyPond can be found at             */
/* http://dragonprime.net/users/Elessa/lilypond.txt                         */
/*                                                                          */
/* Sichae has done a straight .98 conversion of it also.                    */
/* It can be found at http://dragonprime.net/users/Sichae/lilypond.zip      */
/*                                                                          */
/* Excalibur has done a .97 of this module (GardenPond).                    */
/* It can be found at http://dragonprime.net/users/Excalibur/gardenpond.zip */
/****************************************************************************/

/*********************************************************************************/
/* Setup instructions                                                            */
/* ------------------                                                            */
/* Copy this file to the "Module" directory inside the main lotgd directory then */
/* in the game go to Manage modules in the Grotto and Install/Activate it.       */
/*********************************************************************************/

require_once("lib/commentary.php");

function gardenpond_getmoduleinfo()
         {$info = array("name"=>"Garden Pond",
                        "author"=>"Jake Taft (Zanzaras) - Based on Shawn Strider's Lily Pond",
                        "version"=>"1.09",
                        "category"=>"Gardens",
                        "description"=>"A pond found in the garden where players can relax and swim.",
                        "download"=>"http://dragonprime.net/users/Zanzaras/GardenPond%20Module.zip",
                        "vertxtloc"=>"http://dragonprime.net/users/Zanzaras/",
                        "settings"=>array("Garden Pond Settings,title",
                                          "relaxesallowed"=>"How many times per day may a player relax by the Pond?,int|1",
                                          "swimsallowed"=>"How many times per day may a player take a swim in the Pond?,int|1",
                                          "hitpointsgained"=>"Percentage of hitpoints healed in the pond,range,5,50,5|30",
                                          "hitpointslost"=>"Percentage of hitpoints lost due to falling/diving,range,5,50,5|30",
                                          "turtlebite"=>"Percentage of damage a turtle bite does,range,5,30,5|10",
                                          "turnsgained"=>"Turns gained from relaxing,range,1,5,1|2",
                                          "turnslost"=>"Number of turns lost while unconscious,range,1,5,1|2",
                                          "charmlost"=>"How much charm is lost to the frogs?,range,1,5,1|2",
                                          "gemsgained"=>"Number of gems found in cave,int|5",
                                          "goldgained"=>"Amount of gold found in the pond (multiplied by player's level),int|50",
                                         ),
                        "prefs"=>array("Garden Pond Preferences,title",
                                       "relaxes"=>"Number of times the player has relaxed at the pond today,int|0",
                                       "swims"=>"Number of times the player has swam in the pond today,int|0"
                                      )
                       );
          return $info;
         }
         
function gardenpond_install()
         {module_addhook("gardens");
          module_addhook("newday");
          module_addhook("moderate");
          return true;
         }

function gardenpond_uninstall(){return true;}

function gardenpond_dohook($hookname, $args)
         {global $session;
          switch ($hookname)
                 {case "gardens":
                        addnav("Explore the Garden");
                        addnav("P?The Pond","runmodule.php?module=gardenpond&op=enter");
                        break;
                  case "newday":
                        set_module_pref("relaxes",0);
                        set_module_pref("swims",0);
                        break;
                  case "moderate":
                       $args['gardenwaterfallcave'] = translate_inline("Garden Waterfall Cave");
                       break;
                 }
          return $args;
         }

function gardenpond_run()
         {global $session;
          page_header("Garden Pond");
          output("`b`c`2The Garden Pond`0`c`b`n");

          $gemsgained = get_module_setting("gemsgained");
          $goldgained = get_module_setting("goldgained");
          $turnsgained = get_module_setting("turnsgained");
          $turnslost = get_module_setting("turnslost");
          $hitpointsgained = round($session['user']['hitpoints'] * (get_module_setting("hitpointsgained")*.01));
          $hitpointslost = round($session['user']['hitpoints'] * (get_module_setting("hitpointslost")*.01));
          $charmlost = get_module_setting("charmlost");
          $turtlebite = round($session['user']['hitpoints'] * (get_module_setting("turtlebite")*.01));

          $op = httpget('op');
          switch ($op)
                 {case "enter":
                        output("`2You walk over to the edge of the large pond as crickets chirp in harmony and small fish dart about the waters edge.");
                        output("Ahhh... the perfect place for rest and relaxation after a hard day's work in the forest.");
                        addnav("Garden Pond");
                        addnav("Enjoy the Scenery","runmodule.php?module=gardenpond&op=enjoy");
                        addnav("Take a swim","runmodule.php?module=gardenpond&op=swim");
                        addnav("Leave the Pond");
                        addnav("Return to the Gardens","gardens.php");
                        break;

                  case "swim":
                       if (get_module_pref("swims") < get_module_setting("swimsallowed"))
                          {output("`2The crystal clear water looks so tempting, you decide to take a quick swim.");
                           output("Tossing your gear to one side you step out into the water and look around. At the very north end of the pond a small waterfall feeds the pond and looks like it would be fun to go over.");
                           output("Off to your left, you see a large oak with a rope tied to one of its branches. It has obviously been used a lot for swimming fun. Of course you could just wade right in the old fashion way.");
                           output("`n`nYou take a minute to ponder your choices.");
                           addnav("Swimming");
                           addnav("Wade in","runmodule.php?module=gardenpond&op=swimwade");
                           addnav("Rope swing","runmodule.php?module=gardenpond&op=swimrope");
                           addnav("Go over the falls","runmodule.php?module=gardenpond&op=swimwaterfall");
                           addnav("Leave the Water");
                           addnav("s?Return to shore and get your gear","runmodule.php?module=gardenpond&op=enter");
                           addnav("Back to the Gardens","gardens.php");
                          }
                         else
                          {output("`7You'd really like to go swimming again, but you're just too tired. You think you'd better wait and try again tomorrow.");
                           addnav("Return","runmodule.php?module=gardenpond&op=enter");
                          }
                       break;

                  case "swimrope":
                       $numberofswims = get_module_pref("swims")+1;
                       set_module_pref("swims",$numberofswims);
                       Output("`2Since the rope is hanging out over the water, you take a running leap at it, ");
                       $roperesult=e_rand(1,6);
                       switch($roperesult)
                             {case 1:
                                   output("`2but somehow miss the rope entirely!`n`n  You fall hard into the shallow water near the edge of the pond, hurting your legs in the process.`n`n");
                                   output("You decide you've had enough `5fun`2 for today and hobble back to shore.`n`n");
                                   addnav("Return to shore","runmodule.php?module=gardenpond&op=enter");
                                   $session['user']['hitpoints']-=$hitpointslost;
                                   if ($session['user']['hitpoints'] < 1) $session['user']['hitpoints'] = 1;
                                   if ($hitpointslost > 1) output("`6You take `4%s`6 points of damage and will be `4hobbling`6 around for a while until your leg heals.",$hitpointslost);
                                   if ($hitpointslost == 1) output("`6You take `4%s`6 point of damage and will be `4hobbling`6 around for a while until your leg heals.",$hitpointslost);
                                   apply_buff('gardenpond', array("name"=>"`4Wounded Leg",
                                                                  "rounds"=>10,
                                                                  "wearoff"=>"The pain slowly begins to fade.",
                                                                  "atkmod"=>.85,
                                                                  "defmod"=>.85,
                                                                  "roundmsg"=>"You hobble on your wounded leg!")
                                             );

                                   break;
                                   
                              case 2:
                                   output("`2grab it in mid-air and swing out over the pond.`n`n However, as you do, the old rope snaps, plunging you into a not-so-deep section of the water!");
                                   output("You're a little shocked by the ordeal, but not hurt.`n`n Still, you think you've had enough `5\"fun\"`2 for one day.");
                                   addnav("Return to shore","runmodule.php?module=gardenpond&op=enter");
                                   break;

                              case 3:case 4:case 5:
                                   output("`2grab it in mid-air and swing out over the deeper section of the pond.`n`n `%Cannonball!`2 You haven't had this much fun since you were a kid!");
                                   output("You spend some time swimming and splashing around, but after a while your fingers and toes are all wrinkled and you decide you'd better get out.`n`n");
                                   addnav("Return to shore","runmodule.php?module=gardenpond&op=enter");
                                   $session['user']['turns']+=$turnsgained;
                                   $session['user']['spirits']=2;
                                   if ($turnsgained > 1) output("`6Your spirits are lifted and you gain `^%s`6 extra turns!`n",$turnsgained);
                                   if ($turnsgained == 1) output("`6Your spirits are lifted and you gain `^an extra turn`7!`n",$turnsgained);
                                   break;
                                  
                              case 6:
                                   output("`2grab it in mid-air and swing way out over the pond!`n`n As you let go, a glimmer of `6yellow`2 catches your eye.");
                                   output("You hit the water with a splash and swim down to investigate. Half buried in the silt, ");
                                   addnav("Return to shore","runmodule.php?module=gardenpond&op=enter");
                                   if ($goldgained > 1)
                                      {output("`2you find a bag of gold coins! You grab the bag and swim to shore to count your good fortune!`n`n");
                                       output("`6You found `^%s`6 gold coins!",$goldgained);
                                       $session['user']['gold']+=$goldgained;
                                       debuglog("found $goldgained gold in the garden pond.");
                                      }
                                   if ($goldgained == 1)
                                      {output("`2you find a bag of gold coins! You grab the bag and swim to shore to count your good fortune!`n`n");
                                       output("`6You found `^%s`6 gold coin!",$goldgained);
                                       $session['user']['gold']+=$goldgained;
                                       debuglog("found $goldgained gold in the garden pond.");
                                      }
                                   if ($goldgained < 1)
                                      {$goldgained = 0;
                                       output("`2you find a bag of what looks like gold coins! You grab the bag and swim to shore to count your good fortune!`n`n");
                                       output("`2When you open the bag, you're disappointed to find several small, flat rocks painted gold! Angrily, you hurl the bag of rocks back into the pond!");
                                       debuglog("found several a bag of painted rocks in the garden pond.");
                                      }
                                   break;
                             }
                       break;

                  case "swimwaterfall":
                       $numberofswims = get_module_pref("swims")+1;
                       set_module_pref("swims",$numberofswims);
                       output("`2You make your way over to the small cliff and begin climbing.`n`n");
                       $waterfallresult=e_rand(1,12);
                       switch($waterfallresult)
                             {case 1:case 2:case 3:
                                   $session['user']['hitpoints']-=$hitpointslost;
                                   if ($session['user']['hitpoints'] < 1) $session['user']['hitpoints'] = 1;
                                   $session['user']['turns']-=$turnslost;
                                   if ($session['user']['turns'] < 1) $session['user']['turns'] = 0;
                                   output("`2You're about halfway up when you slip on a loose stone and fall several feet to the ground flat on your back.");
                                   output("You lie there for a few minutes in pain before slowly getting up.`n`n");
                                   output("You decide to give up on swimming for today and painfully walk back to your equipment.`n`n");
                                   if ($hitpointslost > 1) output("`6You lost `4%s`6 hitpoints from the fall.",$hitpointslost);
                                   if ($hitpointslost == 1) output("`6You lost `4%s`6 hitpoint from the fall.",$hitpointslost);
                                   addnav("Return to shore","runmodule.php?module=gardenpond&op=enter");
                                   break;

                              case 4:case 5:case 6:
                                   output("`2You make it to the top and find a nice log to ride over the falls.");
                                   output("Just as you're going over the edge, the log hits something and knocks you off balance, throwing you off your ride.");
                                   output("You fall into the white water and rocks below the falls.`n`n You finally manage to swim to the nearest bank and collapse in pain-filled exhaustion.`n`n");
                                   output("You've definitely had enough `5\"fun\"`2 for today. You slowly make your way back to your gear.`n`n");
                                   if ($hitpointslost > 1 and $turnslost > 1) output("`6You lost `4%s`6 hitpoints during the ordeal and spent `4%s`6 turns recovering.",$hitpointslost,$turnslost);
                                   if ($hitpointslost == 1 and $turnslost > 1) output("`6You lost `4%s`6 hitpoint during the ordeal and spent `4%s`6 turns recovering.",$hitpointslost,$turnslost);
                                   if ($hitpointslost > 1 and $turnslost == 1) output("`6You lost `4%s`6 hitpoints during the ordeal and spent `4%s`6 turn recovering.",$hitpointslost,$turnslost);
                                   if ($hitpointslost == 1 and $turnslost == 1) output("`6You lost `4%s`6 hitpoint during the ordeal and spent `4%s`6 turn recovering.",$hitpointslost,$turnslost);
                                   addnav("Return to shore","runmodule.php?module=gardenpond&op=enter");
                                   $session['user']['hitpoints']-=$hitpointslost;
                                   if ($session['user']['hitpoints'] < 1) $session['user']['hitpoints'] = 1;
                                   $session['user']['turns']-=$turnslost;
                                   if ($session['user']['turns'] < 1) $session['user']['turns'] = 0;
                                   break;

                              case 7:case 8:case 9:case 10:
                                   output("`2You make it to the top and find a nice log to ride over the falls.");
                                   output("Just as you go over the edge, you leap free of the log and hit the water below with a large splash!`n`n");
                                   output("That was a `5blast`2! You haven't had that much fun since you were a kid! You're so pumped with adrenaline, you decide to head back into the forest for another round of critter bashing!`n`n");
                                   if ($turnsgained > 1) output("`6You gain `^%s`6 turns from adrenaline!",$turnsgained);
                                   if ($turnsgained == 1) output("`6You gain `^%s`6 turn from adrenaline!",$turnsgained);
                                   addnav("Return to shore","runmodule.php?module=gardenpond&op=enter");
                                   $session['user']['turns']+=$turnsgained;
                                   break;

                              case 11:case 12:
                                   output("`2You make it to the top and find a nice log to ride over the falls.");
                                   output("Just as you're going over the edge, the log hits something and knocks you off balance, throwing you off your ride.`n`n");
                                   output("As you are falling through the water, the log slams into you, knocking you into a hidden cave behind the falls.`n`n");
                                   output("You look around and find an ancient skeleton grasping a tattered leathered bag. ");
                                   if ($gemsgained > 1) output("`6You open it to find `^%s`6 gems!`n`n",$gemsgained);
                                   if ($gemsgained == 1) output("`6You open it to find `^%s`6 gem!`n`n",$gemsgained);
                                   if ($gemsgained < 1)
                                      {$gemsgained = 0;
                                       output("`6You open it to find lots of dirt and bugs!");
                                      }
                                   addnav("Examine the cave wall","runmodule.php?module=gardenpond&op=cavewall");
                                   addnav("Return to shore","runmodule.php?module=gardenpond&op=enter");
                                   $session['user']['gems']+=$gemsgained;
                                   debuglog("found $gemsgained gem(s) in the cave behind the garden pond's waterfall.");
                                   break;
                             }
                       break;
                       
                  case "cavewall":
                        addcommentary();
                        output("`2You spot a piece of chalk by the remains and contemplate leaving a message on the smooth cave walls before leaving.`n`n");
                        viewcommentary("gardenwaterfallcave","Write on the wall",15,"wrote");
                        addnav("Return to shore","runmodule.php?module=gardenpond&op=enter");
                        break;

                  case "swimwade":
                       $numberofswims = get_module_pref("swims")+1;
                       set_module_pref("swims",$numberofswims);
                       $waderesult=e_rand(1,5);
                       switch($waderesult)
                             {case 1:case 2:case 3:
                                   output("`2You wade out into the crystal clear waters and just float there in total relaxation.`n`n");
                                   output("After a while you notice your fingers and toes are getting wrinkled and you decide you better get out.");
                                   output("As you near shore, you discover that some of your wounds have been healed!`n`n`n");
                                   addnav("Return to shore","runmodule.php?module=gardenpond&op=enter");
                                   if ($hitpointsgained > 1) output("`^%s`6 hitpoints have been healed!",$hitpointsgained);
                                   if ($hitpointsgained == 1) output("`^%s`6 hitpoint has been healed!",$hitpointsgained);
                                   $session['user']['hitpoints']+=$hitpointsgained;
                                   if ($session['user']['hitpoints'] > $session['user']['maxhitpoints']) $session['user']['hitpoints'] = $session['user']['maxhitpoints'];
                                   break;
                              case 4:case 5:
                                   output("`2You wade out into the crystal clear waters and just float there in total relaxation.`n`n");
                                   output("In fact, you're so relaxed that you fail to notice the snapping turtle approaching your feet! A few seconds later, your relaxation abruptly ends in lots of pain!");
                                   output("You hurriedly return to shore and inspect your poor toes!`n`n You decide you've had enough swimming for one day.`n`n`n");
                                   addnav("Return to shore","runmodule.php?module=gardenpond&op=enter");
                                   if ($turtlebite < 1) $turtlebite = 1;
                                   if ($turtlebite > 1) output("`6You lose `4%s`6 hitpoints to the jaws of a small snapping turtle!",$turtlebite);
                                   if ($turtlebite == 1) output("`6You lose `4%s`6 hitpoint to the jaws of a small snapping turtle!",$turtlebite);
                                   $session['user']['hitpoints']-=$turtlebite;
                                   if ($session['user']['hitpoints'] < 1) $session['user']['hitpoints'] = 1;
                                   break;
                             }
                       break;

                  case "enjoy":
                       if (get_module_pref("relaxes") >= get_module_setting("relaxesallowed"))
                          {output("`7You sit down by the pond and enjoy the peace and tranquility as the dragonflies skirt over the surface of the water.");
                           output("A fish jumps, the birds sing and the flowers are always so beautiful here. You sit back and relax for several minutes, then with a sigh, you stand up and return to the real world.");
                           addnav("Return","runmodule.php?module=gardenpond&op=enter");
                          }
                         else
                          {$numberofrelaxes = get_module_pref("relaxes")+1;
                           set_module_pref("relaxes",$numberofrelaxes);
                           addnav("Return","runmodule.php?module=gardenpond&op=enter");
                           $rand = e_rand(1,10);
                           switch ($rand)
                                  {case 1: output("`2You lay down in the bed of flowers beside the pond enjoying the sights and smells of the garden, when suddenly a bee lands on your nose.");
                                           output("You quickly try to swat it away, but as you do it `4stings`2 you good!");
                                           output("Small hives start to develop on your cheeks and quickly you pull out the stinger.");
                                           output("`n`n`^OUCH! that bee sting really hurts!");
                                           apply_buff('gardenpond', array("name"=>"`^Stings like a bee!",
                                                                          "rounds"=>5,
                                                                          "wearoff"=>"Ahh, the stinging has faded",
                                                                          "atkmod"=>.9,
                                                                          "roundmsg"=>"You try scratch the hives on your face from the bee sting!")
                                                      );
                                           break;

                                   case 2: output("`2Ahh, the calm, relaxing garden pond.");
                                           output("Who needs to go trumping around in a dark, deadly forest looking for evil creatures to kill?");
                                           output("After a few minutes of relaxation, however, boredom sets in.");
                                           output("Your sword arm is itching for action, so you leave your spot by the pond and go off in search of adventure.");
                                           output("`n`n`^You gain a turn!");
                                           $session['user']['turns']++;
                                           break;

                                   case 3: output("`2Ahh, the calm, relaxing garden pond.");
                                           output("You decide to sit and meditate to clear your mind of the world's noise and confusion.");
                                           output("Somewhere, in the deep forest, an image of distant lands appears in your mind.");
                                           output("Your spirit settles and you hear the songs and whispers of the forest softly upon the breeze.`n`n");
                                           output("You feel rested and focused on the battles ahead!`n`n");
                                           if ($turnsgained > 1) output("`^You gain %s turns!`n",$turnsgained);
                                           if ($turnsgained == 1) output("`^You gain a turn!`n");
                                           apply_buff('gardenpond',array("name"=>"`#Meditation Focus",
                                                                         "rounds"=>5,
                                                                         "wearoff"=>"The world begins to crowd your focus",
                                                                         "atkmod"=>1.1,
                                                                         "roundmsg"=>"With a calm, clear mind, you lash out at the enemy!")
                                                     );
                                           $session['user']['turns']+= $turnsgained;
                                           break;

                                   case 4: output("`2You sit down and take a deep breath and feel `%perceptive`2!");
                                           output("You notice something shiny catching the sunlight in the clear water close by.");
                                           output("You reach down into the water and find a small bag of coins.");
                                           if ($goldgained > 1)
                                              {output("`n`n`^You find `6%s `^gold coins with elvish runes!",$goldgained);
                                               $session['user']['gold']+=$goldgained;
                                               debuglog("found a bag of $goldgained gold in the garden pond.");
                                              }
                                           if ($goldgained == 1)
                                              {output("`n`n`^You find `61 `^gold coin with elvish runes!");
                                               $session['user']['gold']+=$goldgained;
                                               debuglog("found a bag of $goldgained gold in the garden pond.");
                                              }
                                           if ($goldgained < 1)
                                              {$goldgained = 0;
                                               output("`2You open the bag to find several small, flat rocks painted gold! Angrily, you hurl the bag of rocks back into the pond!");
                                               debuglog("found a bag of painted rocks in the garden pond.");
                                              }
                                           break;

                                   case 5: output("`2The tranquil beauty of this place flows over you.");
                                           output("Sitting against birch tree, you fall asleep by the pond to the sound of lapping waves.`n`n");
                                           output("`^You awake from your nap with renewed energy!`n");
                                           apply_buff('gardenpond',array("name"=>"`#Renewed Energy",
                                                                         "rounds"=>5,
                                                                         "wearoff"=>"You begin to feel tired again.",
                                                                         "atkmod"=>1.1,
                                                                         "roundmsg"=>"With renewed energy, you lash out at the enemy!")
                                                     );
                                           break;

                                   case 6: output("`2Walking along the garden pond, you glance up and see a small `@frog `2jump into the water.");
                                           output("You wonder what else might be hidden in those tranquil waters.");
                                           output("Perhaps, you'll find out some day.");
                                           break;

                                   case 7: output("`2Walking along the garden pond, you glance up and see a beautiful young elf maiden staring back at you.");
                                           output("You start to speak but she vanishes without a trace.");
                                           break;

                                   case 8: $city = getsetting("villagename",LOCATION_FIELDS);
                                           output("`2You wander along the banks of the garden pond when, suddenly, you see the `!Master of the Realm `2 walking among the trees!");
                                           output("You've never seen such an imposing, powerful figure before! He turns toward you and your resolve melts away! You flee from the mighty figure walking toward you!");
                                           addnews("`^%s `3ran away like a scared little child after seeing the `!Master of the Realm`3 in the garden of `^%s!",$session['user']['name'],$city = $session['user']['location']);
                                           break;

                                   case 9: output("`2You sit and inhale in the sweet scent of roses, tulips and lillies and stretch your arms. This is indeed very relaxing.");
                                           output("As you stand to leave, you're whole body tingles with enrgy.`n`n");
                                           output("`^You're reflexes have been magically quickened from the scent of the flowers!");
                                           apply_buff('gardenpond',array("name"=>"`#Quick Reflexes",
                                                                         "rounds"=>5,
                                                                         "wearoff"=>"The scent of flowers fades from your memory.",
                                                                         "defmod"=>1.1,
                                                                         "roundmsg"=>"The scent of garden flowers quickens your reflexes!")
                                                     );
                                           break;

                                   case 10: output("`7You stumble at the bank of the pond and fall with a splash into the water.");
                                            output("Grumbling to yourself about your bad luck, you go stand up and take a step toward the shore only to fall and knock yourself out on a rock.");
                                            output("Lying half in and half out of the water, several frogs decide to make themselves at home in your armor. When you awaken they flee their new home, but leave you a few warts as a reminder.`n`n");
                                            output("`4You lose %s charm points due to the warts.",$charmlost);
                                            $session['user']['charm']-= $charmlost;
                                            addnews("`3Poor `^%s `3slept with the frogs and woke up a bit boggy.",$session['user']['name']);
                                            break;
                                  }
                          }
                       break;
                 }
          page_footer();
         }
?>
