<?php
/*
* The Tournament v1.1
* by Excalibur (http://www.ogsi.it)
* excalthesword@fastwebnet.it
* English version by Talisman (http://dragonprime.cawsquad.net)
* Code Optimization: Talisman
* 0.98 updated:  Frederic Hutow (lotgd.togrc.com)
* 0.98 version bug fix: LonnyL (http://www.pqcomp.com)
*/
require_once("lib/systemmail.php");

function tournament_getmoduleinfo(){
    $info = array(
        "name"=>"Tournament",
        "version"=>"1.1",
        "author"=>"Excalibur / Talisman<br />0.98 conv: Frederic Hutow<br />bug fix: LonnyL",
        "category"=>"Village",
        "download"=>"http://dragonprime.net/users/Excalibur/tournament098.zip",
        "prefs"=>array(
            "Tournament Module User Preferences,title",
            "entry"=>"User has paid entry fee,bool|0",
            "points"=>"Tournament Points,int|0",
            "information"=>"User Tournament Information,viewonly",
            "super"=>"Admin/Moderator Control,bool|0",
        ),
        "settings"=>array(
            "Tournament Module Settings,title",
            "leader"=>"Current Tournament Leader (userid),int|0",
            "efeegold"=>"Entry Fee (Gold),int|500",
            "efeegems"=>"Entry Fee (Gems),int|1",
            "r1gold"=>"Reward: 1st Position (Gold),int|10000",
            "r1gems"=>"Reward: 1st Position (Gems),int|10",
            "r2gold"=>"Reward: 2sd Position (Gold),int|8000",
            "r2gems"=>"Reward: 2sd Position (Gems),int|8",
            "r3gold"=>"Reward: 3rd Position (Gold),int|5000",
            "r3gems"=>"Reward: 3rd Position (Gems),int|5",
        )
    );
    return $info;
}

function tournament_install(){
    module_addhook("village");
    module_addhook("charstats");
    module_addhook("superuser");
    module_addhook("index");
    module_addhook("dragonkill");
    module_addhook("namechange");
    return true;
}

function tournament_uninstall(){
    return true;
}

function tournament_dohook($hookname,$args){
    global $session;
    $leader = get_module_setting("leader");

    switch($hookname){
    case "charstats":
        $upoints = get_module_pref("points");
        if ($upoints > 0) {
            addcharstat("Extra Info");
            addcharstat("Tournament Points", number_format($upoints));
        }
        break;
    case "village":
        $display = true;
        if (is_module_active("cities")) {
            $city = getsetting("villagename", LOCATION_FIELDS);
            $home = $session['user']['location']==get_module_pref("homecity", "cities");
            $capital = $session['user']['location']==$city;
            if (!$home && !$capital) {
                $display = false;
            }
        }
        if ($display) {
            addnav('Tournament');
            addnav("Tournament Center","runmodule.php?module=tournament");
            addnav("Tournament Scores","runmodule.php?module=tournament&op=scores");
        }
        break;
    case "index":
        if ($leader != 0) {
            $sql = "SELECT name FROM " . db_prefix("accounts") . " WHERE acctid='$leader'";
            $result = db_query_cached($sql, "tournamentleader");
            $row = db_fetch_assoc($result);
            $leadername = $row['name'];
        }
        if ($leadername) {
            output("`@The current Tournament Leader is: `&%s`@.`0`n",$leadername);
        } else {
            output("`@There is `&no`@ leader in the Tournament. Will you be the first one?`0`n");
        }
        break;
    case "dragonkill":
    case "namechange":
        if ($leader == $session['user']['acctid']) {
            invalidatedatacache("tournamentleader");
        }
        break;
    case "superuser":
        addnav("Module Configurations");
        if (get_module_pref('super')) addnav("Reset Tournament","runmodule.php?module=tournament&op=editor&admin=true");
    }
    return $args;
}

function tournament_run(){
    global $session;

    $uentry  = get_module_pref("entry");
    $upoints = get_module_pref("points");

    $op = httpget('op');
    $action = httpget('action');
    $level = httpget('level');

    if ($op=="editor") tournament_editor();

    page_header("The Tournament");

    if ($op == "") {
        $efeegold = get_module_setting('efeegold');
        $efeegems = get_module_setting('efeegems');
        $r1gold = get_module_setting('r1gold');
        $r1gems = get_module_setting('r1gems');
        $r2gold = get_module_setting('r2gold');
        $r2gems = get_module_setting('r2gems');
        $r3gold = get_module_setting('r3gold');
        $r3gems = get_module_setting('r3gems');
        output("`b`!The LoGD Tournament`0`b`n`n",true);
        if (!$uentry) {
           output("`3You walk into a dimly lit office and peer around at it's sparsely furnished interior. ");
           output("`3As your eyes adjust to the light, you notice a tall warrior appraising you.`n `n ");
           output("`^I am Sir Tristan, Tournament Master, `3he informs you. `^You might not be the mightiest warrior I've seen...but yet...I sense potential within you. ");
           output("`bDo you think you have what it takes to win my `!Grand Tournament`^?`b`n`n");
           output("The entrance fee is `b`^%s Gold pieces`b and `b`&%s Gems`b`^.`n `n",$efeegold,$efeegems);
           output("The mightiest warriors will receive riches in reward for their efforts:`n`n");
           rawoutput("<font size='+1'>");
           output("`b`c`&First Place: %s Gems - %s Gold Pieces`n",$r1gems,number_format($r1gold));
           output("`@Second Place:  %s Gems -  %s Gold Pieces`n",$r2gems,number_format($r2gold));
           output("`^Third Place:  %s Gems -  %s Gold Pieces`b`c`n`n",$r3gems,number_format($r3gold));
           rawoutput("</font>");
           output("`^Why not take a chance and enter? Are ye strong enough? Powerful enough? If ye have what it takes, Victory may be yours!`n ");
           output("`n`3Please note that everybody has an equal chance - it matters not how many dragons ye've slain!`n");
           addnav("Y?`@Yes, Enter the Tournament","runmodule.php?module=tournament&op=enter");
           addnav("N?`\$No, Return to the Village","village.php");
        } else {
           output("`3You walk into a dimly lit office and peer around at it's sparsely furnished interior. ");
           output("`3Sir Tristan welcomes you. `^Welcome, competitor. You have paid the entrance fee and may continue onwards to the Tournament Arena.");
           addnav("T?`@Enter the Tournament Arena","runmodule.php?module=tournament&op=main");
           villagenav();
        }
  } elseif($op == "enter") {
        $efeegold = get_module_setting('efeegold');
        $efeegems = get_module_setting('efeegems');

        output("`b`!The LoGD Tournament`0`b`n`n",true);
        if ($session['user']['gems'] >= $efeegems AND $session['user']['gold'] >= $efeegold) {
            output("`3Sir Tristan breaks into a toothy grin.`n`n `^Excellent! You have chosen to enter the Tournament. You must face a challenge, at each level of your training.`n");
            output("For each challenge, you will receive a number of points.  Whoever attains the highest score at the end of the tournament collects the prizes.`n`n");
            output("`^`bGood Luck to Ye!`b`n ");
            $session['user']['gems'] -= $efeegems;
            $session['user']['gold'] -= $efeegold;
            set_module_pref('entry', true);
            addnav("E?`^Enter the Tournament Arena","runmodule.php?module=tournament&op=main");
        } else {
            output("`3Sir Tristan glares at you.`n`n`^ What do ye think I run here?  A charity?  Ye do not have enough gold and gems for the Entrance Fee.`n");
            output("`^Get out of my office, you dishonourable swine!`n`n ");
            output("`^`bDon't waste my time until you can afford the paltry sum required to enter!`b");
        }
    } elseif ($op == "main") {
        tournament_main($upoints);
    } elseif ($op == "scores") {
        tournament_scores($action, $level);
    }

    if ($op != ""){
        villagenav();
    }
    page_footer();
}

function tournament_main($upoints) {
    global $session;

    $uinformation = unserialize(get_module_pref("information"));
    if (!is_array($uinformation)) {
        $uinformation = array();
        set_module_pref('information', serialize($uinformation));
    }

    $levels['1'] = "one";
    $levels['2'] = "two";
    $levels['3'] = "three";
    $levels['4'] = "four";
    $levels['5'] = "five";
    $levels['6'] = "six";
    $levels['7'] = "seven";
    $levels['8'] = "eight";
    $levels['9'] = "nine";
    $levels['10'] = "ten";
    $levels['11'] = "eleven";
    $levels['12'] = "twelve";
    $levels['13'] = "thirteen";
    $levels['14'] = "fourteen";
    $levels['15'] = "fifteen";

    rawoutput("<font size='+1'>");
    output("`b`c`#THE TOURNAMENT`b`c`n`n");
    rawoutput("</font>");
    $level=$session['user']['level'];
    $flag="";

    addnav("S?`@View Scores","runmodule.php?module=tournament&op=scores");

    if ($session['user']['level'] > 15) {
        output("`3Sir Tristan informs you that you are too powerful for the tournament. There is no opponent that would be a match for you. You can participate in the tournament up to level 15.");
        output("`n`n`^Your current tournament score is `^%s Points.",number_format($upoints));
        return;
    }

    while (list($key, $val) = each($uinformation)) {
        if ($val == $levels[$level])
            $flag="done";
    }

    if ($flag=="done"){
        output("`3Sir Tristan informs you that your challenge for this level has been completed. `n`^`bCome back when you have more experience!!`b`");
    } else {
        $points=e_rand(1,100);
        $resto=100-$points;
        $upoints += $points;
        set_module_pref('points', $upoints);
        $points1=intval($points / 10);
        if ($points1==0) $points1=1;
        array_push($uinformation, $points, $levels[$level]);
        set_module_pref('information', serialize($uinformation));

        // New Leader?
        $currentleader = get_module_setting("leader");
        $sql = "SELECT userid,value FROM " . db_prefix('module_userprefs') . " WHERE modulename='tournament' AND setting='points' AND value <> '' ORDER BY value + 0 DESC LIMIT 1";
        $result = db_query($sql);
        $row = db_fetch_assoc($result);
        if ($row['userid'] != $currentleader) {
            set_module_setting("leader", $row['userid']);
            invalidatedatacache("tournamentleader");
        }

        output("`3Sir Tristan's faithful assistant, Belanthros prepares you for the `^Level %s Challenge.`n`n",$level);

        switch ($level) {
        case 1:
            output("`@Do not underestimate this level, for each is as challenging as the next!! `nBut enough idle chatter, let's get this show on the road!`n`n ");
            output("This challenge is called `%`bDwarf Tossing`b`@. The further ye throw them, the more points ye earn!`n ");
            output("Have at 'em!!!`n`n");

            for ($i=0; $i<$points; $i++){
                output("`% +");
            }

            switch ($points1) {
            case 1:
                output("`n`n`@That must be the worst throw I have seen.  `n`n");
                rawoutput("<font size='+1'>");
                output("`6You have earned a lame %s points!!",$points);
                rawoutput("</font>");
              break;
            case 2: case 3: case 4: case 5:
              output("`n`n`@Not bad, but I've seen better.  `n`n");
              rawoutput("<font size='+1'>");
              output("`6You have earned a paltry %s points!!",$points);
              rawoutput("</font>");
              break;
            case 6: case 7: case 8: case 9:
              output("`n`n`@Nice throw, Warrior.  My compliments to ye.  `n`n");
              rawoutput("<font size='+1'>");
              output("`6You have earned a respectable %s points!!",$points);
              rawoutput("</font>");
              break;
            case 10:
              output("`n`n`@Remarkable! You've bested even `!MightyE`@ with a perfect toss!!!`n`n");
              rawoutput("<font size='+1'>");
              output("`6You have earned the maximum %s points!!", $points);
              rawoutput("</font>");
              output("`n`nYou receive `b1 gem`b as a bonus!!!");
              $session['user']['gems']+=1;
                break;
            }
            break;

        case 2:
            output("`@This challenge will push you to the extremes of your physical endurance.  Do not think this will be simple.`n ");
            output("You must run.  Aye, run.  Ye must run as far as you possibly can!  You will receive 1 point for each kilometre you run.");
            output("`n`nNow get those feet moving!!!`n`n");
            for ($i=0; $i<$points; $i++){
                output_notl("`% + +");
            }
            switch ($points1) {
            case 1:
              output("`n`n`@Such a miserable performance!!! Ye consider yourself worthy of this tournament? HA!`nYou have run barely ");
              rawoutput("<font size='+1'>");
              output("`6%s kilometres`@!!",$points);
              output("`n`^You accumulate a measily %s points!!",$point);
              rawoutput("</font>");
              break;
            case 2: case 3: case 4: case 5:
              output("`n`n`@Ye have failed to impress me, I know ye can do better then this. `nYou ran the moderate distance of ");
              rawoutput("<font size='+1'>");
              output("`6%s kilometers `@!!",$points);
              output("`n`^You merit only %s points!!",$points);
              rawoutput("</font>");
              break;
            case 6: case 7: case 8: case 9:
              output("`n`n`@Mhhh, not bad at all, gratz. `n`@You travelled coast to coast, covering ");
              rawoutput("<font size='+1'>");
              output("`6%s kilometers`@!!",$points);
              output("`n`6I shall award ye %s well deserved points!!",$points);
              rawoutput("</font>");
              break;
            case 10:
              output("`n`n`@Most impressive!!!  Should I call ye Forrest Gump, perchance?`nYou realized the goal of running the full ");
              rawoutput("<font size='+1'>");
              output("`6%s kilometers</font> `@of the Challenge!!",$points,true);
              output("`n<font size='+1'>`6You shall receive a perfect score of %s points!!</font>",$points,true);
              output("`n`^You also gain `b1 gem`b as bonus!!!");
              $session['user']['gems']+=1;
              break;
            }
            break;

        case 3:
            output("`@This challenge is not physically demanding, rather it is a test of your skill at arms and accuracy.`n");
            output("Ye must fire five bolts from this crossbow, hitting the target 100 yards away.  `n");
            output("A Bullseye counts for 20 points. The best possible score is 100 points.`n");
            output("Can ye match the perfect score set by our sharpshooter, `bFarmboy Saruman`b??`n`n");
            for ($z=1; $z<6; $z++){
                output("`!Shot # %s ",$z);
                for ($i=0; $i<e_rand(0,$points1); $i++){
                    output_notl("`% + +");
                }
                output("`n");
            }
            switch ($points1) {
            case 1:
              output("`n`n`@Mark yer target next time, not the cat!!! I've seen goblins shoot better then that!`n");
              output("Only one struck near the right target! `nYou have scored only ");
              rawoutput("<font size='+1'>");
              output("`6%s points!!</font>",$points,true);
              break;
            case 2: case 3: case 4: case 5:
              output("`n`n`@Well, ye've shot 3 arrows in the right direction, but I know ye can do better. `n");
              rawoutput("<font size='+1'>");
              output("`6You receive %s points!!</font>",$points,true);
              break;
            case 6: case 7: case 8: case 9:
              output("`n`n`@Mhhh, not bad at all, compadre. `n`@It looks like one of your 4 accurate shots found the Bullseye. `n");
              rawoutput("<font size='+1'>");
              output("`6I shall give ye %s points!!</font>",$points,true);
              break;
            case 10:
              output("`n`n`@Bravissimo!  A perfect score!!!  Are you related to Robin Hood?`n");
              output("<font size='+1'>`6`bYou shall receive %s points and 1 gem!!!`b</font>",$points,true);
              $session['user']['gems']+=1;
              break;
        }
        break;

        case 4:
            output("`@Mastery of the long bow is a difficult goal to achieve, but ye had best have it if you hope to win this challenge. ");
            output("`nYour accuracy will be judged on how expertly you fire five arrows into yonder target.");
            output("`nYou will receive points for each strike, with the BullsEye worth 20 points. ");
            output("`nGo now, and show me that you are as skilled as `^Aris!!`n`n");

            for ($z=1; $z<6; $z++){
                output("`!Shot # %s ",$z);
                for ($i=0; $i<e_rand(0,$points1); $i++){
                    output_notl("`% + +");
                }
                output("`n");
            }
            switch ($points1) {
            case 1:
              output("`n`n`@What are ye waiting for?  You may begin!!! `nWait...you've already shot?  Pathetic!!!");
              output("`n<font size='+1'>`6These meager %s points will do little for ye!!</font>",$points,true);
              break;
            case 2: case 3: case 4: case 5:
              output("`n`n`@Hardly a noteworthy effort, my friend, but I have seen much worse.`n");
              rawoutput("<font size='+1'>");
              output("`6Be thankful for the %s points you've received!!</font>",$points,true);
              break;
            case 6: case 7: case 8: case 9:
              output("`n`n`@Splendid shooting, amigo!!! `n");
              rawoutput("<font size='+1'>");
              output("`6Including that bullseye, I count %s points for you!!</font>",$points,true);
              break;
            case 10:
              $name=$session['user']['name'];
              output("`n`n`@Ye have truly shown the skill of `#Aris`@!! Are ye sure your name is really %s??`n",$name);
              output("<font size='+1'>`6Five arrows, five Bullseyes!!! %s points and `i`bone bonus Gem`b`i for you!",$points,true);
              $session['user']['gems']+=1;
              break;
            }
            break;

        case 5:
            output("`@You are doing well to make it this far, my friend.  You have worked hard and deserve some refreshment.`n ");
            output("Have a seat...right over there.  Make yourself comfortable.  Would ye care for some ale?`n");
            output("Let me get ye some of Cedrick's finest.`n`nNow...ye didn't think it would be THIS easy, did ye?  ");
            output("Of course ye didn't - ye know me better by now.`nThis is a competition, one which now tests your constitution!  ");
            output("How much of this ale can ye stomach???`nWell, I'll tell ye now ... ye get 5 points for each mug ye down.  ");
            output("Can ye match Cedrick's own record of 20??`n`n`c");
            for ($z=0; $z<5; $z++){
                for ($i=0; $i<e_rand(0,$points1); $i++){
                    output_notl("`6 + +");
                }
                output("`n");
            }
            switch ($points1) {
            case 1:
              output("`c`n`n`@Hey!!! Whatsa matter with you?  Got a hole in your lip?  More ale went on the table than your mouth.`n");
              rawoutput("<font size='+1'>");
              output("`6I can only let ye have %s points for that pathetic performance.",$points);
              rawoutput("</font>");
              break;
            case 2: case 3: case 4: case 5:
              output("`c`n`n`@Nice try, but hardly a worthwhile effort, young friend. That would be but a warmup for Cedrick!`n");
              rawoutput("<font size='+1'>");
              output("`6Ye drank enough mugs to earn %s points!!",$points);
              rawoutput("</font>");
              break;
            case 6: case 7: case 8: case 9:
              output("`c`n`n`@My compliments on a valiant effort, although ye are certainly no competition for Cedrick. `n");
              rawoutput("<font size='+1'>");
              output("`6Eighteen mugs, minus the spillage, adds %s points to your score!!`n",$points);
              rawoutput("</font>");
              break;
            case 10:
              output("`c`n`n`@Amazing!  You must be the %s of Cedrick! `n",$session['user']['sex']?translate_inline("sister"):translate_inline("brother"));
              rawoutput("<font size='+1'>");
              output("`6Ye drank all 20 mugs, and nary spilled a drop! Ye truly deserve these %s points!!",$points);
              rawoutput("</font>");
              output("`n`^Ye also receive `b1 gem`b as a bonus!!!");
              $session['user']['gems']+=1;
              break;
            }
            break;

        case 6:
            output("`@Ye're fast nearing the halfway mark, my friend. It is now that champions begin to separate themselves ");
            output("from the 'also rans', and show their true mettle. ");
            output("Ye must have worked up an appetite after the runs and beer drinking, aye?");
            output("Cedrik suggested some `b`7Smoked Herrings`&`b`@ might now hit the spot.`n`n");
            output("The one who is able to scarf the most herrings will earn points and the title of ");
            output("`\$Smoked Herring Scarfer of the Year`b`@. `nThe champion of our village is `b`#Luke`b`@, ");
            output("who managed to wolf down 99 smoked herring.`n`n");

            for ($z=0; $z<5; $z++){
                for ($i=0; $i<e_rand(0,$points1); $i++){
                    output_notl("`7 + +");
                }
                output("`n");
            }
            switch ($points1) {
            case 1:
              output("`n`n`@Ye should have said ye were allergic to seafood!!! `n");
              rawoutput("<font size='+1'>");
              output("`6You have eaten only %s herrings!!",$points);
              rawoutput("</font>");
              break;
            case 2: case 3: case 4: case 5:
              output("`n`n`@Bah!  I've seen better lately...did the ale fill ye? `n");
              rawoutput("<font size='+1'>");
              output("`6 You have eaten %s smoked herring!!",$points);
              rawoutput("</font>");
              break;
            case 6: case 7: case 8: case 9:
              output("`n`n`@Mhhh, you could give even Luke a run for his money, my compliments. `n");
              output("`@I see you have left only %s herrings on the table.`n",$resto);
              rawoutput("<font size='+1'>");
              output("`6You have earned %s points!!",$points);
              rawoutput("</font>");
              break;
            case 10:
              output("`n`n`@Wow, we have a new champion in the village!! You destroyed `#Luke's`@ record!!`n");
              output("`@You have scarfed all 100 herring, mastering this challenge. `n");
              rawoutput("<font size='+1'>");
              output("`6You have earned %s points!!",$points);
              rawoutput("</font>");
              output("`n`^You also recieve a bonus gem`b!!!");
              $session['user']['gems']+=1;
              break;
            }
            break;

        case 7:
            output("`@Ye've now reached the halfway point in our competition, and are about to meet my favorite challenge.");
            output("With the herring and ale of the last two trials your stomach must be churning. ");
            output("Do you already feel the pressure of the gas trying to escape?  Well don't let it out yet!!`n");
            output("In this challenge, whoever produces the `b`7longest belch`@`b will receive the highest score. ");
            output("But be careful that ALL ye do is belch - I don't wish to see the ale or herring again!!!`n`n");
            output(" The one and only champion of this trial is our quiet fellow-citizen `!`bHutgard`b`@ with 99 seconds.");
            output("Hmmm, that dull rumble I hear tells me I'd better stop talking and let ye start belching!!!`n`n");

            for ($z=0; $z<5; $z++){
                for ($i=0; $i<e_rand(0,$points1); $i++){
                    output_notl("`6 * *");
                }
                output("`n");
            }
            switch ($points1) {
            case 1:
              output("`n`n`@You call that a belch??  That wasn't even a hiccup, let alone a burp!!! `n");
              rawoutput("<font size='+1'>");
              output("`6Your so called belch lasted only %s seconds!!",$points);
              rawoutput("</font>");
              break;
            case 2: case 3: case 4: case 5:
              output("`n`n`@A good start, but no follow through! `n");
              rawoutput("<font size='+1'>");
              output("`6You belched for %s seconds!!!",$points);
              rawoutput("</font>");
              break;
            case 6: case 7: case 8: case 9:
              output("`n`n`@Saaayyyy...not bad...not bad at all!  Ye knocked out 30 farmies with that one!!!.`n");
              rawoutput("<font size='+1'>");
              output("`6Your belch earns ye a total of %s points!!!",$points);
              rawoutput("</font>");
              break;
            case 10:
              output("`n`n`@I would not have thought it possible, but ye've obliterated all traces of `#Hutgard's`@ record!!`n");
              output("`@A full barrack of troops is unconcious, ye've broken every window in the village and neighbouring ");
              output("villages have reported minor earth tremors!!!`n ");
              rawoutput("<font size='+1'>");
              output("`6Your efforts warrant %s points and `b1 gem`b as bonus!!!",$points);
              rawoutput("</font>");
              $session['user']['gems']+=1;
              break;
            }
            break;

        case 8:
            output("`@Ye still walk amongst the living, `b%s`b? Unexpected, but tis grand to see!  ",$session['user']['name']);
            output("Sadly, we are not done with ye yet.`n Between the herring, beer and belches of the last few challenges, ");
            output("how would ye feel about a good rest?  From the look on your face, I suspect you are eager for a good sleep!`n");
            output("Well...I hope we've tired ye enough that ye may win this challenge by sleeping the longest of any competitor.  ");
            output("Ye shall earn one point for each hour of sleep. ");
            output("Your goal should be to beat our friend `!`bDankor's`b`@ record of 99 hours of uninterrupted sleep!! `n`n");

            for ($z=0; $z<5; $z++){
                for ($i=0; $i<e_rand(0,$points1); $i++){
                    output_notl("`7 z z");
                }
                output("`n");
            }
            switch ($points1) {
            case 1:
              output("`n`n`@Terrible, TERRIBLE!!! This is one ocassion where time spent sleeping would not be wasted time.`n");
              rawoutput("<font size='+1'>");
              output("`6Sadly, you slept for only %s hours!!`n",$points);
              rawoutput("</font>");
              break;
            case 2: case 3: case 4: case 5:
              output("`n`n`@Well, I don't think ye need to worry about anyone calling ye 'Sleepy Head'. `n");
              rawoutput("<font size='+1'>");
              output("`6Ye slept for %s hours!!",$points);
              rawoutput("</font>");
              break;
            case 6: case 7: case 8: case 9:
              output("`n`n`@Mhhh, nice, really!  Ye could consider yerself kin to Rumplestiltskin! `n");
              rawoutput("<font size='+1'>");
              output("`6Your nap lasted for %s hours!!",$points);
              rawoutput("</font>");
              break;
            case 10:
              output("`n`n`^Amazing, a new champion in the village!! ");
              output("Your laziness has surpassed even `#Dankor's`@ long sleep with `b100 hours`b!!`n");
              output("`@Your sleeping rivals that of `#Sleeping Beauty`@ ... ");
              output("although I fear ye not be quite as beautiful as she was rumoured to be!!! ");
              rawoutput("<font size='+1'>");
              output("`6You have earned % points!!!",$points);
              rawoutput("</font>");
              output("`nYou also gain `b1 gem`b as bonus!!!");
              $session['user']['gems']+=1;
              break;
            }
            break;

        case 9:
            output("`@This next challenge is directly related to the last one; in fact, you completed it at the same time ");
            output("you were sleeping in the previous challenge. Surprised?  Well, it's quite simple really. Ye see, ");
            output("we measured the decibel level of your snoring, and awarded you one point per decibel.`n");
            output("The loudest snoring in memory was that of `b`!CMT`b`@, at an amazing 99 decibels - louder than the dying ");
            output("dragon's roar!`nNow let me check to see if ye've done better than that...`n`n ");
            for ($z=0; $z<5; $z++){
                for ($i=0; $i<e_rand(0,$points1); $i++){
                    output_notl("`7 Z Z");
                }
                output("`n");
            }
            switch ($points1) {
                case 1:
              output("`n`n`@Noooooo, that is one of the worst performances I've never heard!!! `n");
              rawoutput("<font size='+1'>");
              output("`6You have reached only %s decibels!!!`n",$points);
              rawoutput("</font>");
              output("`@Don't you know that blowing your nose before going to bed makes it harder to get good `isound`i?`n");
              break;

            case 2: case 3: case 4: case 5:
              output("`n`n`@What can I say, you managed to wake your %s from slumber beside you, but made little impact beyond that. `n",$session['user']['sex']?translate_inline("husband"):translate_inline("wife"));
              rawoutput("<font size='+1'>");
              output("`6You peaked at %s decibels!!!",$points);
              rawoutput("</font>");
              break;
            case 6: case 7: case 8: case 9:
              output("`n`n`#Mhhh, not that bad, really. `#You woke the whole neighbourhood with your snoring! `n");
              rawoutput("<font size='+1'>");
              output("`6A measure of %s decibels earns ye %s points!!",$points,$points);
              rawoutput("</font>");
              break;
            case 10:
              output("`n`n`@My goodness! We have a new champion - You smashed the old record held by `#CMT`@ with `b100 decibels`b!!`n");
              output("`@We could use your snoring instead of explosives to demolish enemy fortresses!!!! ");
              rawoutput("`n<font size='+1'>");
              output("`6You have earned %s points and `b1 bonus gem`b!!!",$points);
              rawoutput("</font>");
              $session['user']['gems']+=1;
              break;
            }
            break;


        case 10:
            output("`@H-Hey, `b%s`b!!!  I've got something you need, right here - 100 rubber bands.`n`n",$session['user']['name']);
            output("Now, ye might be wondering why ye might need 100 rubber bads? We-e-ell, I'm glad ye asked!`n");
            output("As you well know, the Garden Gnomes don't keep the forest as tidy as they should, ");
            output("and allow water to stagnate, thus allowing the proliferation of mosquitoes.`n`n");
            output("Your challenge is to wipe out as many mosquitoes as ye can with those rubber bands. ");
            output("A perfect score will see ye crowned as `#King of Rubber Bands'`@ in place of `b`#OberonGloin`b`@, ");
            output("the current 'King'.`n`n");
            for ($z=0; $z<5; $z++){
                for ($i=0; $i<e_rand(0,$points1); $i++){
                    output_notl("`6 o o");
                }
                output("`n");
            }
            switch ($points1) {
            case 1:
              output("`n`n`@Noooooo, ye're a terrible shot with those bands, and the Mosquitos thank you!!!`n");
              rawoutput("<font size='+1'>");
              output("`^You have scored only  points!!`n",$points);
              rawoutput("</font>");
              output("`@As ye seem to be on the mosquito's side, tell me...are ye `\$Nosferatu's`@ relative ???`n");
              break;
            case 2: case 3: case 4:
              output("`n`n`@Ye seem rather fond of those mosquitoes, judging by your low kill ratio.  ");
              output("Don't tell me...is your favorite drink a `\$Bloody Mary`@?`n");
              rawoutput("<font size='+1'>");
              output("`6You have earned only %s points!!",$points);
              rawoutput("</font>");
              break;
            case 5: case 6: case 7: case 8: case 9:
              output("`n`n`@Mhhh, you're a sharpshooter with those elastics! The mosquitos are learning to stay away from ye.");
              rawoutput("`n<font size='+1'>");
              output("`6With %s dead mosquitoes, you earn %s points!!",$points,$points);
              rawoutput("</font>");
              break;
            case 10:
              output("`n`n`@Well now, I think I shall dub thee `3Rubber Hood`@ in recognition of your outstanding aim!! ");
              output("You have beat the record of `#OberonGloin`@ with `b100 hits`b !! ");
              output("`@The adjacent villages are ready to contract you to assassinate all the mosquitos in their shires!!! ");
              rawoutput("`n<font size='+1'>");
              output("`6You have earned %s points and `b1 gem`b!!",$point);
              rawoutput("</font>");
              $session['user']['gems']+=1;
              break;
            }
            break;

        case 11:
            output("`@My good friend `3`bMerick`b`@ has asked of favour of me, and I think it would make for a great challenge. ");
            output("Only `3`bMerick`b`@ can truly tame a centaur, but a strong warrior should be able to ride one for some time. ");
            output(" You will have to ride this powerfull beast for as long as ye can, earning a point for each second of your ");
            output("flight. Our champion is `bPoker`b`@, with 99 seconds on it's back. Can ye beat him?? `n`n");
            for ($z=0; $z<5; $z++){
                for ($i=0; $i<e_rand(0,$points1); $i++){
                    output_notl("`% <^>");
                }
                output("`n");
            }
            switch ($points1) {
                case 1:
              output("`n`n`@You better stick to cleaning the stables!!!  ");
              output("You stuck to that centaur like `6`bGrog`b`@ does to soap!`n");
              rawoutput("<font size='+1'>");
              output("`6Your ride only lasted %s seconds!!`n",$points);
              rawoutput("</font>");
              break;
            case 2: case 3: case 4:
              output("`n`n`@Forget about that career as a wrangler, your ride only lasted %s seconds. `n",$points);
              rawoutput("<font size='+1'>");
              output("`6Anyhow you have earned %s points!!",$points);
              rawoutput("</font>");
              break;
            case 5: case 6: case 7: case 8: case 9:
              output("`n`n`@Outstanding ride, my friend ... ye must have been riding centaurs ");
              output("since ye were knee high to a goblin!!`n");
              rawoutput("<font size='+1'>");
              output("`6You kept hold on his back for %s seconds!!!",$points);
              rawoutput("</font>");
              break;
            case 10:
              output("`n`n`@Wow, not even `!Merick`@ stayed as long as you just did!!! ");
              output("You replace `#Poker`@ as the village champion!!");
              output("`nNow...do ye think ye could tame my wild canary?`n");
              rawoutput("<font size='+1'>");
              output("`6You receive `b100 points`b and a `bbonus gem`b!!`n");
              rawoutput("</font>");
              $session['user']['gems']+=1;
              break;
            }
            break;

        case 12:
            output("`@This next challenge is a test of your agility and dexterity.  ");
            output("I have 100 of my favorite friends, the sprytes, who will enter a room with ye.");
            output("  Your task is to catch as many of them as ye are able, but ye must be careful not to injure them.");
            output("Will you be able to catch as many as did our champion, `%`bKhendra`b`@, who holds the record with 99?`n`n");

            for ($z=0; $z<5; $z++){
                for ($i=0; $i<e_rand(0,$points1); $i++){
                    output_notl("`& * * * *");
                }
                output("`n");
            }
            switch ($points1) {
            case 1:
              output("`n`n`@Need glasses?  Couldn't see them? ");
              output("Or are those mitts you call hands too clumsy to catch such graceful creatures? `n");
              rawoutput("<font size='+1'>");
              output("`6Your pathetic score nets you only %s points!!`n",$points);
              rawoutput("</font>");
              break;
            case 2: case 3: case 4:
              output("`n`n`@Well, you caught %s sprytes.  ",$points);
              output("I guess it could have been worse, but it should have been much better. `n");
              rawoutput("<font size='+1'>");
              output("`6You have earned %s points!!",$points);
              rawoutput("</font>");
              break;
            case 5: case 6: case 7: case 8: case 9:
              output("`n`n`@Mhhh, excellent. A a little more effort, and maybe you may have been able to break the old record.`n");
              rawoutput("<font size='+1'>");
              output("`6You caught %s Sprytes!!!",$points);
              rawoutput("</font>");
              break;
            case 10:
              output("`n`n`@Bravo!!! You surpassed `#Khendra's`@ old record of 99!!! `n");
              rawoutput("<font size='+1'>");
              output("`6Ye captured `b%s Sprytes`b. Your legendary performance also nets you `b1 gem`b!!",$points);
              rawoutput("</font>");
              $session['user']['gems']+=1;
              break;
            }
            break;

        case 13:
            output("`@I wonder, as I look at ye...how do ye like your eggs?  Sunnyside up?...Poached?...Scrambled maybe?  ");
            output("But wait!  Don't tell me...I'll let ye show me.  Here is a bucket of 100 fresh eggs. ");
            output("Ye must toss them, one at a time, into that large frying pan 20 feet away.  ");
            output("Ye shall receive one point for each egg that lands in the pan unbroken.  Careful now!!!`n`n");
            for ($z=0; $z<5; $z++){
                for ($i=0; $i<e_rand(0,$points1); $i++){
                    output_notl(" `&(`^0`&) `&(`^X`&)");
                }
                output("`n");
            }
            switch ($points1) {
            case 1:
              output("`n`n`@Remind me not to send you for eggs!! I guess you must like yours scrambled and crunchy.`n");
              rawoutput("<font size='+1'>");
              output("`6You broke all but %s eggs!!!`n",$points);
              rawoutput("</font>");
              break;
            case 2: case 3: case 4:
              output("`n`n`@If ye help anybody cook a steak and eggs breakfast, ");
              output("I'd recommend you cook the steak and leave the eggs to somebody more skilled.  ");
              output("You broke %s eggs. `n",$resto);
              rawoutput("<font size='+1'>");
              output("`6Your egg throwing earned you %s points!!!",$points);
              rawoutput("</font>");
              break;
            case 5: case 6: case 7: case 8: case 9:
              output("`n`n`@Congratulations, except for the %s broken eggs, you were perfect.  ",$resto);
              output("Ok, not quite perfect, but not too bad, either.  `n");
              rawoutput("<font size='+1'>");
              output("`6You landed %s unbroken eggs!!!",$points);
              rawoutput("</font>");
              break;
            case 10:
              output("`n`n`@Well done!!! `#Nulla`@ should take some lesson from ye - ");
              output("your perfect score unseated him as village champion!!! `n");
              rawoutput("<font size='+1'>");
              output("`6Your reward is `b%s points`b and `bone bonus gem`b!!`n",$points);
              rawoutput("</font>");
              $session['user']['gems']+=1;
              break;
            }
            break;

        case 14:
            output("`@You will now face one of the most difficult challenges of the tournament, that of sword twirling.  ");
            output("I see your arms are strong, as is your desire to win.  Ye are to take this greatsword, and singlehandedly ");
            output("throw it in the air, allowing it to rotate one full revolution before catching it by it's handle.  ");
            output("Ye shall receive one point for each successful catch.`n`n");

            for ($z=0; $z<5; $z++){
                for ($i=0; $i<e_rand(0,$points1); $i++){
                    output_notl(" `^-{`7--- `s`s`s`s`s`s   ---`^}-`s`s`s`s`s`s");
                }
                output("`n`n");
            }
            switch ($points1) {
            case 1:
              output("`n`n`@Your arms would not be so scarred if ye listened to my instructions - ");
              output("catch by the handle, not by the blade.  `n");
              rawoutput("<font size='+1'>");
              output("`6You get credit for just  catches!!`n",$points);
              rawoutput("</font>");
              break;
            case 2: case 3: case 4:
              output("`n`n`@Ye're sure not any ".($session['user']['sex']?"Xena":"Conan").", ");
              output("but ye do get the job done out in the forest.  I'd suggest ye stick to the normal methods of swordhandling.`n");
              rawoutput("<font size='+1'>");
              output("`6You earn  points for your catches!!",$points);
              rawoutput("</font>");
              break;
            case 5: case 6: case 7: case 8: case 9:
              output("`n`n`@A good effort, I think ye're our local `#%s`@!!`n",$session['user']['sex']?translate_inline("Xena the Warrior Princess"):translate_inline("Conan the Barbarian"));
              rawoutput("<font size='+1'>");
              output("`6You completed %s sword catches!!",$points);
              rawoutput("</font>");
              break;
            case 10:
              output("`n`n`@Outstanding! Ye beat `bMightyE`b`@'s old record of 99 catches!!! `n");
              rawoutput("<font size='+1'>");
              output("`6You have earned %s points and `b1 gem`b as bonus!!!",$points);
              rawoutput("</font>");
              $session['user']['gems']+=1;
              break;
            }
            break;

        case 15:
            output("`@My friend, you have arrived at the most challenging portion of this competition.  ");
            output("I know not that ye have the strength and endurance to survive this trial alive, ");
            output("yet ye have come this far and it would be unfair to stop ye now.  ");
            output("We have managed to acquire, just for this competition, a rare `\$Red Dragon`@.  ");
            output("All ye need to do is withstand the blast of his flames for as long as ye can.`n");
            output("Good luck to ye.`n`n");
            for ($z=0; $z<5; $z++){
                for ($i=0; $i<e_rand(0,$points1); $i++){
                    output_notl(" `4w`$ Y `4w`$ Y ");
                }
                output("`n");
            }
            switch ($points1) {
            case 1:
              output("`n`@Couldn't stand the heat?  Get out of the frying pan!!! `n");
              rawoutput("<font size='+1'>");
              output("`6Your pathetic effort earned you a mere %s points!!`n",$points);
              rawoutput("</font>");
              break;
            case 2: case 3: case 4:
              output("`n`n`@Hmmmm...I see some 3rd degree burns on ye...what are ye?  A fool?  ");
              output("Ye shouldn't push your luck so.  Maybe next time you'll wear some heat resistant clothing!`n");
              rawoutput("<font size='+1'>");
              output("`6You survived %s seconds in the company of that `\$Red Dragon`@!!",$points);
              rawoutput("</font>");
              break;
            case 5: case 6: case 7: case 8: case 9:
              output("`n`n`@I swear ye must be at home in the desert, and firewalk for fun.  ");
              output("The `\$Red Dragon`@'s flame barely singed ye, but ye were still ");
              output("%s seconds short of beating `bExcalibur`b's`@ record.`n",$resto);
              rawoutput("<font size='+1'>");
              output("`6You gain %s points!!!",$points);
              break;
            case 10:
              output("`n`n`@Amazing!!! Ye have beaten `2`bExcalibur`b`@'s record!!! ");
              output("Ye spent `b%s seconds`b`@ with the `\$Red Dragon`@'s flames ",$points);
              output("trying to turn ye into a walking torch, and you don't even have a hair out of place!!!!`n");
              rawoutput("<font size='+1'>");
              output("`6You have earned %s points and also gain `b1 gem`b!!!",$points);
              rawoutput("</font>");
              $session['user']['gems']+=1;
              break;
            }
            break;
        }
    }

    output("`n`n`^Your current tournament score is `^%s Points.",number_format($upoints));
}

function tournament_scores($action, $level) {
    global $session;

    $levels['1'] = "one";
    $levels['2'] = "two";
    $levels['3'] = "three";
    $levels['4'] = "four";
    $levels['5'] = "five";
    $levels['6'] = "six";
    $levels['7'] = "seven";
    $levels['8'] = "eight";
    $levels['9'] = "nine";
    $levels['10'] = "ten";
    $levels['11'] = "eleven";
    $levels['12'] = "twelve";
    $levels['13'] = "thirteen";
    $levels['14'] = "fourteen";
    $levels['15'] = "fifteen";

    addnav("G?`#General Score","runmodule.php?module=tournament&op=scores&action=general");
    addnav("L?`%Score for each Level","runmodule.php?module=tournament&op=scores&action=scorelevel");
    addnav("Y?`^Your Score/Level","runmodule.php?module=tournament&op=scores&action=level");

    if ($action == "") {
        rawoutput("<font size='+1'>");
        output("`c`b`!Great LoGD Tournament's Classifications`b`c`n`n");
        rawoutput("</font>");
        output("`6Welcome to `@Great LoGD Tournament's 'Classification's`6. This is the place where ");
        output("you can view different kind of tables. One of this is the `@General Classication`6, ");
        output("where are shown players actually busy to reach the first places with shown their ");
        output("total points and the number of trial played till now, or you can choose to view the ");
        output("classification for every single trial played, where you can see who's best scored in that trial. ");
        output("Choose a Classification`n");
    }

    if ($action == "general") {
        rawoutput("<font size='+1'>");
        output("`c`b`!LoGD Tournament's General Classification`b`c`n`n");
        rawoutput("</font>");
        $sql = "SELECT userid,name,value FROM " . db_prefix('module_userprefs') . "
        LEFT JOIN " . db_prefix('accounts') . " ON (acctid = userid)
        WHERE modulename='tournament'
        AND setting='points'
        AND value <> '' ORDER BY value + 0 DESC";
        output("`c`b`&LoGD Tournament's General Classification`b`c`n");
        rawoutput("<table border=0 cellpadding=2 cellspacing=1 bgcolor='#999999' align='center'><tr class='trhead' align='center'><td></td><td>");
        output("Name");
        rawoutput("</td><td>");
        output("Score");
        rawoutput("</td><td>");
        output("N� of Trials");
        rawoutput("</td></tr>");
        $result = db_query($sql) or die(db_error(LINK));
        if (db_num_rows($result) == 0) {
            rawoutput("<tr><td colspan=4 align='center'>`&");
            output("Nobody has signed for the Tournament`0");
            rawoutput("</td></tr>");
        }
        for ($i = 0;$i < db_num_rows($result);$i++) {
            $row = db_fetch_assoc($result);
            $row['information'] = unserialize(get_module_pref('information', 'tournament', $row['userid']));
            if ($row['name'] == $session['user']['name']) {
                rawoutput("<tr bgcolor='#007700'>");
            } else {
                rawoutput("<tr class='" . ($i % 2?"trlight":"trdark") . "'>");
            }
            $prove=count($row['information'])/2;
            if ($prove < 1) $prove = 0;
          if ($prove > 0) {
             rawoutput("<td>".($i + 1).".</td><td>");
             output_notl($row['name']);
             rawoutput("</td><td align='right'>".($row['value'])."</td><td align='center'>$prove</td></tr>",true);
          }
        }
        rawoutput("</table>");
    }
    if ($action == "scorelevel") {
        if (!$level)
            rawoutput("<font size='+1'>");
            output("`c`b`!Level Classification of LoGD Tournament`b`c`n`n");
            rawoutput("</font>");
        addnav("Choose Level");
        for ($i=1; $i<16; $i++){
            addnav("`\$Level $i","runmodule.php?module=tournament&op=scores&action=scorelevel&level=".$i);
        }
    }
    if ($action == "scorelevel" && $level) {
        $arr=array();
        $sql = "SELECT userid, name, value FROM " . db_prefix('module_userprefs') . "
        LEFT JOIN " . db_prefix('accounts') . " ON (acctid = userid)
        WHERE modulename='tournament'
        AND setting='points'
        AND value <> '' ORDER BY value + 0 DESC";
        $result = db_query($sql) or die(db_error(LINK));
        $k=1;
        $z=db_num_rows($result);
        for ($i = 0;$i < $z ;$i++){
            $row = db_fetch_assoc($result);
            $row['information'] = unserialize(get_module_pref('information', 'tournament', $row['userid']));
            $convers=array();
            for ($ii = 0; $ii < count ($row['information']); $ii += 2) {
                if (isset ($row['information'][$ii]) && isset ($row['information'][$ii + 1])) {
                    $convers[] = array ("punteggio" => $row['information'][$ii],"livello" => $row['information'][$ii + 1]);
                }
            }
            reset($convers);
            $nome=$row['name'];
            foreach ($convers as $key => $row){
                if ($convers[$key]['livello'] == $levels[$level]){
                    $arr[$k]['punteggio'] = $convers[$key]['punteggio'];
                    $arr[$k]['nome'] = $nome;
                    $k++;
                }
            }
        }
        arsort($arr);
        reset($arr);
        rawoutput("<font size='+1'>");
        output("`c`b`!Level %s Classification of LoGD Tournament`b`c`n`n",$level);
        rawoutput("</font>");
        rawoutput("<table border=0 cellpadding=2 cellspacing=1 bgcolor='#999999' align='center'><tr class='trhead' align='center'><td></td><td>");
        output("Name");
        rawoutput("</td><td>");
        output("Score");
        rawoutput("</td></tr>");

        foreach ($arr as $key => $row) {
            if ($arr[$key]['nome'] == $session['user']['name']) {
                rawoutput("<tr bgcolor='#007700'>");
            } else {
                rawoutput("<tr class='".(($key+1) % 2?"trlight":"trdark")."'>");
            }
            rawoutput("<td>".($key).".</td><td>");
            output_notl($arr[$key]['nome']);
            rawoutput("</td><td align='right'>{$arr[$key]['punteggio']}</td></tr>");
            $flag=1;
        }
        if (!$flag) {
            rawoutput("<tr><td colspan=3 align='center' bgcolor='#000000'>");
            output("`&Nobody has played this level yet`0");
            rawoutput("</td></tr>");
        }
        rawoutput("</table>");
    }
    if ($action == "level") {
        rawoutput("<font size='+1'>");
        output("`c`b`!Levels Completed by %s`b`c`n`n",$session['user']['name']);
        rawoutput("</font>");
        $uinformation = unserialize(get_module_pref("information"));
        rawoutput("<table border=0 cellpadding=2 cellspacing=1 bgcolor='#999999' align='center'><tr class='trhead' align='center'><td>");
        output("Level");
        rawoutput("</td><td>");
        output("Score");
        rawoutput("</td></tr>");
        for ($k = 1; $k < 16; $k++){
            for ($i = 0; $i < count ($uinformation); $i += 2){
                if ($levels[$k]==$uinformation[$i + 1]){
                    rawoutput("<tr class='".(($pippo) % 2?"trlight":"trdark")."'>");
                    rawoutput("<td align='center'>");
                    output("`@{$levels[$k]}");
                    rawoutput("</td><td align='right'>");
                    output_notl("`^{$uinformation[$i]}");
                    rawoutput("</td></tr>");
                    $pippo++;
                    $totale += $uinformation[$i];
                }
            }
        }
        rawoutput("<tr bgcolor='#005599'>");
        rawoutput("<td align='center'>");
        output("`\$`bTotal`b");
        rawoutput("</td><td align='right'>");
        output_notl("`^`b$totale`b");
        rawoutput("</td></tr></table>");
    }
}

function tournament_editor() {
    global $session;

    $action = httpget('action');

    page_header("Reset Tournament");

    if ($action==""){
        output("`\$`n`n`c`4`bWARNING`b`0 !!! You are about to reset the Tournament.`n");
        output("Are you 100% sure ?`c");
        addnav("G?Return to the Grotto","superuser.php");
        addnav("M?Return to the Mundane","village.php");
        addnav("R?`\$Reset Tournament","runmodule.php?module=tournament&op=editor&action=reset");
        addnav("P?`^Give Prizes","runmodule.php?module=tournament&op=editor&action=prizes");
    }

    if ($action=="reset"){
        rawoutput("`@<font size='+1'>");
        output("`c`n`nThis is your last chance. `nAfter this point you can't go back.`n");
        output("`\$Are you REALLY sure to reset the Tournament ?`c");
        rawoutput("</font>");
        addnav("G?Return to the Grotto","superuser.php");
        addnav("M?Return to the Mundane","village.php");
        addnav("R?`\$Reset Tournament","runmodule.php?module=tournament&op=editor&action=resetconfirm");
    }

    if ($action=="resetconfirm"){
        $sql = "DELETE FROM " . db_prefix("module_userprefs") . " WHERE modulename='tournament' AND setting <> 'super'";
        db_query($sql);
        set_module_setting("leader", 0);
        invalidatedatacache("tournamentleader");
        addnav("G?Return to the Grotto","superuser.php");
        addnav("M?Return to the Mundane","village.php");
        output("`n`@Tournament's resetted !!");
    }

    if ($action=="prizes"){

        output("`c`b`&The Giveaways of Prizes of the Big Tourney of LoGD`b`c`n");
        $sql = "SELECT acctid,name,gems,goldinbank,value FROM " . db_prefix('module_userprefs') . "
        LEFT JOIN " . db_prefix('accounts') . " ON (acctid = userid)
        WHERE modulename='tournament'
        AND setting='points'
        AND value <> ''
        ORDER BY value + 0 DESC LIMIT 3";
        $result = db_query($sql) or die(db_error(LINK));
    if (db_num_rows($result) == 0) {
            output("`c`&No Player has joined the Tourney`0`c");
        }
    for ($i = 0;$i < db_num_rows($result);$i++) {
            $row = db_fetch_assoc($result);
            if ($i==0){
                $oro1 = get_module_setting('r1gold');
                $gemme1 = get_module_setting('r1gems');
                $account=$row['acctid'];
                $oro=$row['goldinbank'] + $oro1;
                $gemme=$row['gems']+ $gemme1;
                $mailmessage = "`@You have won the First Prize at The Tournament!!! You have gained $gemme1 Gems and $oro1 Gold !!!";
                systemmail($row['acctid'],"`%Congratulation !!! You have won the Tournament!",$mailmessage);
                output("`^%s has %s gems and %s gold in bank `n",$row['name'],$row['gems'],$row['goldinbank']);
                addnews("`#%s `#has finished in `^1st place`# in the `@Tournament`# and `#has gained `^%s gems`# and `^%s gold`# !!`0",$row['name'],get_module_setting('r1gems'),number_format(get_module_setting('r1gold')));
            } else if ($i==1) {
                $oro2 = get_module_setting('r2gold');
                $gemme2 = get_module_setting('r2gems');
                $account=$row['acctid'];
                $oro=$row['goldinbank'] + $oro2;
                $gemme=$row['gems']+ $gemme2;
                $mailmessage = "`@You have won the Second Prize at The Tournament!!! You have gained $gemme2 Gems and $oro2 Gold !!!";
                systemmail($row['acctid'],"`%Congratulation !!! You have placed 2nd at the Tournament!",$mailmessage);
                output("`^%s has %s gems and %s gold in bank `n",$row['name'],$row['gems'],$row['goldinbank']);
                addnews("`#%s `#has finished in `^2nd place`# in the `@Tournament`# and `#has gained `^%s gems`# and `^%s gold`# !!`0",$row['name'],get_module_setting('r2gems'),number_format(get_module_setting('r2gold')));
            } else if ($i==2) {
                $oro3 = get_module_setting('r3gold');
                $gemme3 = get_module_setting('r3gems');
                $account=$row['acctid'];
                $oro=$row['goldinbank'] + $oro3;
                $gemme=$row['gems']+ $gemme3;
                $mailmessage = "`@You have won the Third Prize at The Tournament!!! You have gained $gemme3 Gems and $oro3 Gold !!!";
                systemmail($row['acctid'],"`%Congratulation !!! You have placed 3nd at the Tournament!",$mailmessage);
                output("`^%s has %s gems and %s gold in bank `n",$row['name'],$row['gems'],$row['goldinbank']);
                addnews("`#%s `#has finished in `^3rd place`# in the `@Tournament`# and `#has gained `^%s gems`# and `^%s gold`# !!`0",$row['name'],get_module_setting('r3gems'),number_format(get_module_setting('r3gold')));
            }
            $sql = "UPDATE " . db_prefix('accounts') . " SET `gems` = $gemme, `goldinbank` = $oro WHERE `acctid` = $account";
            $result1=db_query($sql) or die(db_error(LINK));
            output("%s now has %s gemme and %s gold.`n`n",$row['name'],$gemme,$oro);
        }

        $sql = "DELETE FROM " . db_prefix("module_userprefs") . " WHERE modulename='tournament' and setting <> 'super'";
        db_query($sql);
        set_module_setting("leader", 0);
        invalidatedatacache("tournamentleader");

        addnav("G?Return to the Grotto","superuser.php");
        addnav("M?Return to the Mundane","village.php");
        addnav("R?`\$Reset Tournament","runmodule.php?module=tournament&op=editor&action=reset");
        output("`n`\$`bPrizes given !!`b");
    }

    page_footer();
    die;
}

?>