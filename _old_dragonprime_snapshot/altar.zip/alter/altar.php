<?
function altar_getmoduleinfo(){
        $info = array(
                "name"=>"Altar",
                "version"=>"2.4",
                "author"=>"Unknown;<br>Converted for vers. 1.x.x<br>and modified by ShadowRaven",
                "category"=>"Forest Specials",
                "download"=>"http://dragonprime.net/users/ShadowRaven/altar.zip",
                
        "settings"=>array(

                "Leaving Altar,title",
                "leave"=>"Do they get any gems for ignoring the altar?,bool|1",
                "lgems"=>"If yes how many do they find?,int|2",
                "Dagger,title",
                "daggergain"=>"How many Max Hitpoint do they gain?,int|3",
                "daggerlose"=>"How many Max Hitpoints do they lose?,int|2",
                "Skull,title",
                "skullgain"=>"how much favor do they gain?,int|5",
                "The setting below is favor*x. Example: favor of 100 *.75 leaves them with 75 favor,note",
                "skulllose"=>"How much favor do they lose?(favor multiplied by ->),int|.90",
                "Wand,title",
                "wandgain"=>"How much Charm do they gain?,int|5",
                "wandlose"=>"How much Charm do they lose?,int|3",
                "Abacus,title",
                "abacusgold1"=>"How much gold do they gain in outcome 1? level multiplied by->,int|10",
                "abacusgold2"=>"How much gold do they gain in outcome 2? level multiplied by->,int|10",
                "abacusgems"=>"Max amount of gems they can gain. random 1 through ->,int|3",
                "abacusgold3"=>"How much gold do they gain in outcome 3?level multiplied by->,int|10",
                "Book,title",
                "bookexp"=>"what percentage of players exp to add?,int|.02",
                "bookff"=>"Max number of forest fights gained. random 1 through ->,int|3",
                "Crystal Lightning Bolt,title",
                "fgain"=>"How much favor do they gain?,int|20",
                "flose"=>"How much favor do they lose?(favor multiplied by ->),int|.75",
                "hpgain"=>"How many Max Hitpoint do they gain?,int|5",
                "attdef"=>"How many att/def do they gain?,int|2",
                "expgain"=>"How much exp do they gain?(percentage of players exp to add),int|.15",
                "explose"=>"How much exp to they lose?(percentage of players exp to subtract),int|.15",
                "death"=>"Can players die?,bool|1",
                
                ),
        );
        return $info;
}

function altar_install(){
if (!is_module_active('altar')){
    output("`^Installing Altar Module.`n");
}else{
    output("`^Updating Altar Module.`n");
        }
module_addeventhook("forest", "return 100;");
        return true;
}

function altar_uninstall(){
output("`^Uninstalling Altar Module.`n");
        return true;
}

function altar_dohook($hookname,$args){
        return $args;
}

function altar_runevent($type){
global $session;
        $from = "forest.php?";
        $session['user']['specialinc'] = "module:altar";
        $op = httpget('op');


if ($op=="" || $op=="search"){

      output("`@You stumble accross a clearing.  You notice an altar with 5 sides sitting infront of you.  Each side contains a different Item.  ");
      output("You see `#A Dagger, `4A Skull,`% A Jeweled Wand, `^An Abacus, `7and A Plain looking Book.  `@Sitting on top of the altar in the center is a `&Crystal Lightning Bolt.`n`n");
    output("`n`@You know that if you take the time to pick up one of the items,  it will cost you the time for one forest fight.  But you know it will be worth the loss.`n`n`n");
    addnav("Grab the Dagger",$from."op=dagger");       //maxhitpoints
    addnav("Grab the Skull",$from."op=skull");         // favor
    addnav("Grab the Jeweled Wand",$from."op=wand");   // charm
    addnav("Grab the Abacus",$from."op=abacus");       //gold/gems
    addnav("Grab the Book",$from."op=book");           //exp/ff
    addnav("Grab the Crystal Lightning Bolt",$from."op=bolt");  //favor/maxHP/att/def/exp/DEATH
    addnav("Leave");
    addnav("Leave the Altar undisturbed",$from."op=forgetit");
  

}elseif ($op== "dagger"){
     $session['user']['turns']--;
     if (e_rand(0,1)==0){
     $daggergain = get_module_setting("daggergain");
              output("`#You grab the Dagger from its resting place.  The dagger vanishes, and you feel a surge of power enter your body!`n`n  `&You gain %s max hitpoints!",$daggergain);
              $session['user']['maxhitpoints'] = $session['user']['maxhitpoints'] + $daggergain;
      }else{
      $daggerlose = get_module_setting("daggerlose");
              output("`@`#You grab the Dagger from its resting place.  The dagger vanishes, but not before it cuts you!`n`n  `&You lose %s max hitpoints!",$daggerlose);
              $session['user']['maxhitpoints'] = $session['user']['maxhitpoints'] - $daggerlose;

}
    $session['user']['specialinc']="";
    
}elseif ($op== "skull"){
     $session['user']['turns']--;
     if (e_rand(0,1)==0){
     $skullgain = get_module_setting("skullgain");
              output("`#You grab the Skull from its resting place.  The Skull vanishes, and you feel a surge of power enter your body!`n`n  `&You gain %s favor!",$skullgain);
              $session['user']['deathpower'] = $session['user']['deathpower'] + $skullgain;
           }else{
           $skulllose = get_module_setting("skulllose");
              output("`@`#You grab the Skull from its resting place.  The Skull vanishes, and you feel a surge despair through your body!`n`n  `&You lose some favor!");
              $session['user']['deathpower'] = $session['user']['deathpower'] * $skulllose;
  }
              $session['user']['specialinc']="";
              
}elseif ($op== "wand"){
     $session['user']['turns']--;
    if (e_rand(0,1)==0){
    $wandgain = get_module_setting("wandgain");
              output("`#You grab the Wand from its resting place.  The Wand vanishes, and you feel a surge of power enter your body!`n`n  `&You realize its a wand of youth! you gain %s charm!",$wandgain);
              $session['user']['charm'] = $session['user']['charm'] + $wandgain;
          }else{
          $wandlose = get_module_setting("wandlose");
              output("`@`#You grab the Wand from its resting place.  The Wand vanishes, and you feel a surge of power enter your body!`n`n  `&To your horror, you realize this is a wand of aging! You feel a few wrinkles form and lose %s Charm!",$wandlose);
             $session['user']['charm'] = $session['user']['charm'] - $wandlose;

    }
             $session['user']['specialinc']="";
             
}elseif ($op== "abacus"){
     $session['user']['turns']--;
     if (e_rand(0,1)==0){
     $abacusgold1 = get_module_setting("abacusgold1");
     $abacusgold2 = get_module_setting("abacusgold2");
     $abacusgems =  get_module_setting("abacusgems");
            $gold = e_rand($session['user']['level']*$abacusgold1,$session['user']['level']*$abacusgold2);
            $gems = e_rand(1,$abacusgems);
              output("`#You grab the abacus from its resting place.  The abacus turns into a pouch filled with gold and gems!`n`n You gain %s gold coins and %s gems!",$gold,$gems);
              $session['user']['gold']+=$gold;
              $session['user']['gems']+=$gems;
           }else{
           $abacusgold3 = get_module_setting("abacusgold3");
            $gold = ($session['user']['level']*$abacusgold3);
              output("`@`#You grab the abacus from its resting place.  The abacus turns into a sack filled with gold!`n`nYou gain %s gold coins!",$gold);
              $session['user']['gold']+=$gold;
 }
              $session['user']['specialinc']="";
              
}elseif ($op== "book"){
     $session['user']['turns']--;
     if (e_rand(0,1)==0){
     $bookexp = get_module_setting("bookexp");
            $exp=$session['user']['experience']*$bookexp;
              output("`#You grab the book from its resting place and procede to read it.  The knowledge contiain in the book passes on to you.  You place the book back on the altar, hoping someone else will find it and make use of its knowledge.`n`nYou gain %s experiance!",$exp);
              $session['user']['experience']+=$exp;
          }else{
          $bookff = get_module_setting("bookff");
            $ffights = e_rand(1,$bookff);
              output("`@`#You grab the book from its resting place and procede to read it.  The book contains secrets to help you make todays journey into the forest more profitable.  You place the book back on the altar, thinking that someone else might make use of it.`n`nYou Gain %s forest fights!",$ffights);
              $session['user']['turns']+=$ffights;
 }
              $session['user']['specialinc']="";
              
}elseif ($op== "bolt"){
     $session['user']['specialinc']="";
     $session['user']['turns']--;
     $bchance=e_rand(0,7);
if ($bchance==0){
            output("`#You grab the Crystal Lightning Bolt from its resting place.  The Bolt vanishes from your hand and reappears back at the top of the altar.  After several tries at grabbing the Bolt, you decide not to waste any more time on it, fearfull of upsetting the gods");
        }elseif ($bchance==1){
        $fgain =  get_module_setting("fgain");
            output("`#You grab the Crystal Lightning Bolt from its resting place. Upon touching the bolt you are knocked backwards to the ground.  You get to your feet, and feel like even death cannot stop you!`n`nYou gain %s favor!",$fgain);
                     $session['user']['deathpower'] = $session['user']['deathpower'] + $fgain;
        }elseif($bchance==2){
            $flose =  get_module_setting("flose");
            output("`#You grab the Crystal Lightning Bolt from its resting place. Upon touching the bolt you are knocked backwards to the ground.  You get to your feet, and feel very vulnerable!`n`nYou lose some favor!");
                     $session['user']['deathpower'] = $session['user']['deathpower'] *$flose;
        }elseif($bchance==3){
           $hpgain = get_module_setting("hpgain");

                output("`#You grab the Crystal Lightning Bolt from its resting place. Upon touching the bolt you are knocked backwards to the ground.  You get to your feet, and feel very powerfull!`n`nYou gain %s Max HP, and feel fully refreshed!",$hpgain);
                $session['user']['maxhitpoints']+=$hpgain;
                debuglog("reached for the Crystal Lightning Bolt and gained ".$hpgain." max hit points");
                $session['user']['hitpoints'] = $session['user']['maxhitpoints'];
        }elseif($bchance==4){
        $attdef = get_module_setting("attdef");
            output("`#You grab the Crystal Lightning Bolt from its resting place. Upon touching the bolt you are knocked backwards to the ground.  You get to your feet, and feel very powerfull!`n`nYou gain %s Attack and Defense Points!",$attdef);
            $session['user']['attack']+=$attdef;
            $session['user']['defense']+=$attdef;
        }elseif($bchance==5){
        $expgain = get_module_setting("expgain");
            $exp=round($session['user']['experience']*$expgain);
            output("`#You grab the Crystal Lightning Bolt from its resting place. Upon touching the bolt you are knocked backwards to the ground.  You get to your feet, and feel very powerfull!`n`nYou gain %s experience points!",$exp);
            $session['user']['experience']+=$exp;
        }elseif($bchance==6){
        $explose = get_module_setting("explose");
            $exp=round($session['user']['experience']*$explose,0);
            output("`#You reach for the Crystal Lightning Bolt when the skys suddenly boil over with clouds.  You fear you have angered the gods, and start to run, before you get clear of the area a bolt of lightning strikes you.`n`nYou Feel Dumber!  You loose %s experience points!",$exp);
            $session['user']['experience']-=$exp;
        }else{
            $death = get_module_setting("death");
            if ($death == 1){
            output("`#You reach for the Crystal Lightning Bolt when the skys suddenly boil over with clouds.  You fear you have angered the gods, and start to run, before you get clear of the area a bolt of lightning strikes you.`n`nYou are dead!");
            output("You loose 5% of your Experience and  all of your gold on hand!`n`n");
            output("You may continue to play tommorow.");
            $session['user']['alive']=false;
            $session['user']['hitpoints']=0;
            $session['user']['gold']=0;
            $session['user']['experience']=$session['user']['experience']*0.95;
            addnav("Daily News","news.php");
            addnews($session['user']['name']." was slain by the gods because ".($session['user']['sex']?"she":"he")." was filled with greed!");
            }else{
             output("`#You grab the Crystal Lightning Bolt from its resting place.  The Bolt vanishes from your hand and reappears back at the top of the altar.  After several tries at grabbing the Bolt, you decide not to waste any more time on it, fearfull of upsetting the gods");
        }
        }

}elseif ($op== "forgetit"){
            $leave = get_module_setting("leave");
            if ($leave == 0){
            output("`@You decide not to temp fate and anger the gods.  You leave the altars alone.");
            }else{
            $lgems = get_module_setting("lgems");
            output("`@You decide not to temp fate and anger the gods.  You leave the altars alone.");
            output("As you leave you stumble across a pouch containing %s gems!  The gods must be smiling on you!",$lgems);
            $session['user']['gems']+=$lgems;
            addnav("Return to Forest","forest.php");
            $session['user']['specialinc']="";
}
}
}

function altar_run(){
}
?>
