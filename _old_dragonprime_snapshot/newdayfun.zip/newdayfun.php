<?php
/**
* Version:      1.1
* Date:         November 19, 2005
* Author:       Kevin Hatfield - Arune http://www.dragonprime.net
* LOGD VER:     Module for 0.9.8
*
*/
require_once("lib/http.php");
function newdayfun_getmoduleinfo(){
        $info = array(
                "name"=>"NewDAY! Module",
                "author"=>"<a href=\"http://logd.ecsportal.com\" target=_new>Arune - Kevin Hatfield</a>",
                "version"=>"1.1",
                "category"=>"Administrative",
				"vertxtloc"=>"http://www.dragonprime.net/users/khatfield/",
				"description"=>"Allows for the ability to award players with newdays",
                "download"=>"http://dragonprime.net/users/khatfield/newdayfun.zip",
				"settings"=>array(
                "newdaypriv"=>"Turn this module on?,bool|0",
                ), 
		);
        return $info;
}
function newdayfun_install(){
        if (!is_module_active('newdayfun')){
                output("`4Installing NewDayFUN Module.`n");
        }else{
                output("`4Updating NewDayFUN Module.`n");
        }
        module_addhook("village");
	module_addhook("footer-shades");
	module_addhook("footer-graveyard");
	module_addhook("news-intercept");
        return true;
}
function newdayfun_uninstall(){
        return true;
}
function newdayfun_dohook($hookname, $args){
        global $session;
        switch($hookname){
        case "village": case "footer-shades": case "footer-graveyard": case "news-intercept":
                 if (get_module_setting("newdaypriv")) {
	         if ($session['user']['superuser']<1) addnav("New Day","newday.php");
        	 }		 
		break;
        }
		return $args;
}
function newdayfun_run(){
}
?>
