<?php

function trogdor_getmoduleinfo(){
	$info = array(
		"name"=>"Trogdor the Burninator",
		"author"=>"Chris Vorndran",
		"version"=>"1.01",
		"category"=>"Forest Specials",
		"download"=>"http://dragonprime.net/index.php?module=Downloads;sa=dlview;id=1043",
		"prefs"=>array(
			"Trogdor the Burninator Prefs,title",
				"burn"=>"How many times has this player been Burninated?,int|0",
			),
	);
	return $info;
}
function trogdor_install(){
	module_addeventhook("forest","return 100;");
	module_addhook("footer-hof");
	return true;
}
function trogdor_uninstall(){
	return true;
}
function trogdor_dohook($hookname,$args){
	global $session;
	switch ($hookname){
		case "footer-hof":
			addnav("Warrior Rankings");
			addnav("BURNiNATiON Ranks","runmodule.php?module=trogdor&op=hof");
			break;
	}
	return $args;
}
function trogdor_run(){
	global $session;
	$op = httpget('op');
	
	page_header("BURNiNATiON Ranks");
	
	switch ($op){
		case "hof":
			$sql = "SELECT name, value FROM ".db_prefix("accounts")." 
					INNER JOIN ".db_prefix("module_userprefs")."
					ON acctid=userid 
					WHERE modulename='trogdor' 
					AND setting='burn' 
					AND value > 0
					ORDER BY (value+0) DESC LIMIT 25";
			$res = db_query($sql);
			$rank = translate_inline("Rank");
			$name = translate_inline("Name");
			$val = translate_inline("# of BURNiNATiONs");
			rawoutput("<big>");
			output("`c`b`^ Top 25 BURNiNATED`b`c`0`n");
			rawoutput("</big>");
			rawoutput("<table border='0' cellpadding='2' width='50%' cellspacing='1' align='center' bgcolor='#999999'>");
			rawoutput("<tr class='trhead'><td>$rank</td><td>$name</td><td>$val</td></tr>");
			$i = 0;
			while($row = db_fetch_assoc($res)){
				$i++;
				if ($row['name']==$session['user']['name']){
					rawoutput("<tr class='trhilight'><td align='center'>");
				}else{
					rawoutput("<tr class='".($i%2?"trdark":"trlight")."'><td align='center'>");
				}
				output_notl($i);
				rawoutput("</td><td align='center'>");
				output_notl("`b{$row['name']}`b`0");
				rawoutput("</td><td align='center'>");
				output_notl("`b{$row['value']}`b`0");
				rawoutput("</td></tr>");
			}
			rawoutput("</table>");
			addnav("Return to HoF","hof.php");
			break;
	}
	page_footer();
}
function trogdor_runevent($type){
	global $session;
	$from = "forest.php?";
	$op = httpget('op');
	$session['user']['specialinc'] = "module:trogdor";
	
	switch ($op){
		case "": case "search":
			output("`@Wandering far off the beaten path, you find yourself in a clearing.");
			output("A shimmering light passes by you and lands on the ground in front of you.");
			output("What are you going to do?");
			addnav("Investigate",$from."op=investigate");
			addnav("Walk Away",$from."op=leave");
			break;
		case "investigate":
			$session['user']['specialinc'] = "";
			output("`@You take a step forward, only to met with a brilliant light emitted from the ground.");
			output("Watching the light, you see that an '`\$S`@' is drawn and then a more different '`\$S`@'.");
			output("The two '`\$S`@'s are closed at the top and then, using consummate '`\$V`@'s, teeth are drawn in, spinities and angry eyebrows.");
			output("Next, some smoke is drawn out of the snout and then some fire.");
			output("Wings are then formed, seeing as how it is a wing-a-ling dragon.");
			output("Out of nowhere, a beefy arm shoots out the back and `\$TROGDOR THE BURNiNATOR`@ springs into action.`n`n");
			switch (e_rand(1,6)){
				case 1: case 2:
					output("Immediately, Trogdor begins to burninate the countryside, the peasants and their thatch-roofed cottages.");
					output("He sets his sights on you and in an instant, you have flames spurting out of your head.");
					output("The fire spreads to the rest of your body.");
					debuglog("died by BURNiNATION.");
					output("Trogdor grins and roars, \"`\$Ye 'ave been BURNiNATED!`@\"");
					$session['user']['alive'] = FALSE;
					$session['user']['hitpoints'] = 0;
					addnav("Return to the Shades","shades.php");
					increment_module_pref("burn",1);
					addnews("%s has been BURNiNATED by TROGDOR.",$session['user']['name']);
					break;
				case 3: case 4: case 5: case 6:
					output("As it turns out, today happens to be Trogdor's birthday, so he doesn't BURNiNATE you.");
					output("Instead, he hands you a `%gem `@from his vast stores of gems and stuff.");
					$session['user']['gems']++;
					break;
			}
			break;
		case "leave":
			output("`@Not wishing to bring forth anything unfortunate, you head on out of the clearing and back into the forest.");
			$session['user']['specialinc'] = "";
			break;
	}
}
?>