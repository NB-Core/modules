<?php
function battlepotions_getmoduleinfo(){
	$modsettings = array("Battlepoints Module Settings,title",
				"shoploc"=>"Where does the Battle Potion Shop appear,location|".getsetting("villagename", LOCATION_FIELDS),
				"shopowner"=>"Name of the Battle Potion Shop owner,text|Woody",
				"shopsex"=>"Sex of Battle Potion Shop Owner,enum,his,Male,her,Female",
				"shopopen"=>"Is the shop open?,bool|0"
			); //i love you <--- My Wonderful wife typed that... thought I would leave it there.
	$modprefs = array("Battle Potions user prefs,title",
					"seenshop"=>"Has user been in the shop?,bool|0",
					);
		if (is_module_active('altcurrency')){
			require_once("modules/altcurrency.php");
			$currencylist = altcurrency_buildlist();
			for ($i=1;$i<21;$i++){
				$p="p".$i;
				$pcurr = "p".$i."curr";
				$pcost = "p".$i."cost";
				$peffect = "p".$i."effect";
				$pval = "p".$i."val";
				$pmsg = "p".$i."msg";
				$modsettings[] = "Potion ".$i.",title";
				$modsettings[$p] = "Potion ".$i." Name,text|unset";
				$modsettings[$pcurr] = "Potion ".$i." Currency.,enum".$currencylist;
				$modsettings[$pcost] = "Potion ".$i." Cost.,int|0";
				$modsettings[$peffect] = "Potion ".$i." Effects.,enum,def,Defence,atk,Attack,heal,Healing";
				$modsettings[$pval] = "Potion ".$i." Value.,enum,0,Useless,1,Extremely Low,2,Very Low,3,Low,4,Medium Low,5,Medium,6,Medium High,7,High,8,Very High,9,Extremely High,10 Unreal!";
				$modsettings[$pmsg] = "Potion ".$i." Effect Message.,text|none";
				
			}
			for ($i=1;$i < 21;$i++){
					$pquan = "p".$i."quan";
					$modprefs[$pquan] = "Potion".$i." Quantity,int|0";
			}
		}
	$info = array(
		"name"=>"Battle Potions",
		"version"=>"2.1",
		"author"=>"`#Lonny Luberts",
		"category"=>"PQcomp",
		"download"=>"http://www.pqcomp.com/modules/mydownloads/visit.php?cid=3&lid=89",
		"vertxtloc"=>"http://www.pqcomp.com/",
		"requires"=>array(
	       "altcurrency"=>"1.11|By Lonny Luberts",
	       ),
	    "prefs"=>$modprefs,
	    "settings"=>$modsettings,
	);
	return $info;
}

function battlepotions_install(){
	if (!is_module_active('battlepotions')){
		output("`4Installing Battle Potions Module.`n");
	}else{
		output("`4Updating Battle Potions Module.`n");
	}
	module_addhook("fightnav");
	module_addhook("apply-specialties");
	module_addhook("village");
	module_addhook("charstats");
	return true;
}

function battlepotions_uninstall(){
	output("`4Un-Installing Battle Potions Module.`n");
	return true;
}

function battlepotions_dohook($hookname,$args){
	global $session;
	switch($hookname){
	case "charstats":
		addcharstat("Equipment Info");
		for ($i=1;$i < 21;$i++){
			$howmany = get_module_pref("p".$i."quan");
			if ($howmany > 0){
				addcharstat(get_module_setting("p".$i), $howmany);
			}
		}
	break;
	case "fightnav":
		global $badguy;
		if ($badguy['type']<>'pvp' and $badguy['type']<>'train'){	
			$script = $args['script'];
			for ($i=1;$i<21;$i++){
				if (get_module_pref("p".$i."quan") > 0){
					addnav("Battle Potions");
					addnav(get_module_setting("p".$i)." (".get_module_pref("p".$i."quan").")",$script."op=fight&battlepotion=p".$i, true);
				}
			}
		}
	break;
	case "apply-specialties":
		$battlepotion = httpget('battlepotion');
		if ($battlepotion <> ""){
		set_module_pref($battlepotion."quan",get_module_pref($battlepotion."quan") - 1);
		$type = get_module_setting($battlepotion."effect");
		$bpname = get_module_setting($battlepotion);
		$bpval = get_module_setting($battlepotion."val");
		if ($type == "atk"){
			apply_buff('atkbattlepotion',array(
						 "startmsg"=>"`n`^You use a ".$bpname." potion!",
                   		 "name"=>"`%".$bpname,
                  		 "rounds"=>1,
                  		 "minioncount"=>1,
                  		 "effectmsg"=>"`@".get_module_setting($battlepotion."msg")."`nYour ".$bpname." does ".$session['user']['level'] * $bpval." damage!",
			 			 "minbadguydamage"=>$session['user']['level'] * $bpval,
                   		 "maxbadguydamage"=>$session['user']['level'] * $bpval,
                   		 "effectnodmgmsg"=>"`4Your ".$bpname." `\$HAS NO EFFECT`)!",
                   		 "activate"=>"offense"
					));
		}elseif ($type == "def"){
			global $badguy;
			apply_buff('defbattlepotion',array(
						 "startmsg"=>"`n`^You use a ".$bpname." potion!",
                   		 "name"=>"`%".$bpname,
                  		 "rounds"=>1,
                  		 "roundmsg"=>"`#".get_module_setting($battlepotion."msg"),
			 			 "badguyatkmod"=>$badguy['creatureattack'] - (($session['user']['level'] * $bpval) * 2),
                   		 "activate"=>"defence"
					));
		}elseif ($type == "heal"){
			apply_buff('healbattlepotion',array(
						 "startmsg"=>"`n`^You use a ".$bpname." potion!",
                   		 "name"=>"`%".$bpname,
                  		 "rounds"=>1,
                  		 "minioncount"=>1,
                  		 "regen"=>$session['user']['level'] * $bpval,
                  		 "effectmsg"=>"`!".get_module_setting($battlepotion."msg")."`n You heal for ".$session['user']['level'] * $bpval." hitpoints!",
                   		 "activate"=>"offense"
					));
		}
		}
	break;
	case "village":
		if (get_module_setting('shoploc') == $session['user']['location'] and get_module_setting('shopopen')){
			tlschema($args['schemas']['marketnav']);
    		addnav($args['marketnav']);
    		tlschema();
			addnav(array("%s's Battle Potions",get_module_setting('shopowner')),"runmodule.php?module=battlepotions");
		}
	break;
	}
	return $args;
}

function battlepotions__runevent($type){
	//not used!
}

function battlepotions_run(){
	global $SCRIPT_NAME;
	if ($SCRIPT_NAME == "runmodule.php"){
		include("modules/lib/battlepotions.php");
	}
}
?>