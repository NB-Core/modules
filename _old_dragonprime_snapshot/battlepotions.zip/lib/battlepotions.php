<?php
global $session;
$op = httpget('op');
page_header("Battle Potions");
if ($op == ""){
	if (get_module_pref("seenshop") == 1){
		$beenhere = "back";
	}else{
		$beenhere = "";
		set_module_pref("seenshop",1);
	}
	output("`2%s welcomes you %s to %s Battle Potion Shop.`n",get_module_setting("shopowner"),$beenhere,get_module_setting("shopsex"));
	output("`2%s sells potions that can be used in battle.  Offensive potions are used to attack your ",get_module_setting("shopowner"));
	output("Opponents, Defensive potions will help protect you in battle, and Healing Potions will heal ");
	output("you while you are in a battle.`n");
}
if ($op <> "buy"){
	output("`2%s flashes you a ",get_module_setting("shopowner"));
	switch(e_rand(1,12)){
		case 1:
		output("big grin.`n");
		break;
		case 2:
		output("sheepish smile.`n");
		break;
		case 3:
		output("wry grin.`n");
		break;
		case 4:
		output("blank stare.`n");
		break;
		case 5:
		output("dazed look.`n");
		break;
		case 6:
		output("small frown.`n");
		break;
		case 7:
		output("confused look.`n");
		break;
		case 8:
		output("crooked smile.`n");
		break;
		case 9:
		output("dirty look.`n");
		break;
		case 10:
		output("evil glare.`n");
		break;
		case 11:
		output("quick glance.`n");
		break;
		case 12:
		output("harried look.`n");
		break;
	}
output("`2You see the following items for sale.`n`n");
addnav("Buy");
for ($i=1;$i<21;$i++){
	$pname = get_module_setting("p".$i);
	if ($pname <> "unset"){
		$effects = get_module_setting("p".$i."effect");
		switch($effects){
			case "atk":
				$effects = "Offensive Potion";
			break;
			case "def":
				$effects = "Defensive Potion";
			break;
			case "heal":
				$effects = "Healing Potion";
			break;
		}
		output("`@%s (%s) - %s %s`n",$pname,$effects,get_module_setting("p".$i."cost"),get_module_setting("p".$i."curr"));
		addnav(array("Buy %ss",$pname),"runmodule.php?module=battlepotions&op=buy&potion=p".$i);
	}
}
}else{
	$potion = httpget('potion');
	$howmany = httppost('howmany');
	if ($howmany < 1){
		output("`%How many %ss would you like to buy?`n",get_module_setting($potion)); 
	    rawoutput("<form action='runmodule.php?module=battlepotions&op=buy&potion=".$potion."' method='POST'><input name='howmany' id='howmany'><input type='submit' class='button' value='buy'></form>");
	    rawoutput("<script language='JavaScript'>document.getElementById('howmany').focus();</script>");
	    addnav("","runmodule.php?module=battlepotions&op=buy&potion=".$potion);
	    addnav("Other");
	    addnav("Cancel Transaction","runmodule.php?module=battlepotions");
	}else{
		$howmany = httppost('howmany');
		$howmany = abs($howmany);
		if ($howmany < 1){
			output("`4`b`cWhat are you trying to do CHEAT?`b`c`0");
			//this should never be shown due to check up higher
		}else{
			if ($potion == "") redirect("runmodule.php?module=battlepotions&op=none");
			$potionname = get_module_setting($potion);
			$potioncurr = get_module_setting($potion."curr");
			$potioncost = get_module_setting($potion."cost");
			$potioncost = $potioncost * $howmany;
			$userhas = get_module_pref($potioncurr,'altcurrency');
			if ($userhas < $potioncost){
				output("I am sorry but you don't have enough %s to purchace that many %s.`n",$potioncurr,$potionname);
				addnav("Continue","runmodule.php?module=battlepotions&op=none");
			}else{
				set_module_pref($potion."quan",get_module_pref($potion."quan") + $howmany);
				set_module_pref($potioncurr,get_module_pref($potioncurr,'altcurrency') - $potioncost,'altcurrency');
				output("%s hands you %s %s potions and takes %s %s from you.`n",get_module_setting("shopowner"),$howmany,$potionname,$potioncost,$potioncurr);
				addnav("Continue","runmodule.php?module=battlepotions&op=none");
			}
		}
	}
}
addnav("Other");
villagenav();
page_footer();
?>