<?php
/***********************************************
* labirinto.php - The Labyrinth v0.2
* Originally by Excalibur (www.ogsi.it)
* 27 April 2004
*    
* Modified and re-written by .................
* Additions ....................

----install-instructions--------------------------------------------------
	-SS-SCALE: * :easy: -
* Quest for LotGD 0.9.7
* You need to add a field to 'accounts' table:

ALTER TABLE accounts ADD labi tinyint(4) unsigned not null default '0';

* 
* If you have already installed eslotto.php (Author: bwatford)
* you don't need further modifications to DB. Otherwise you need to execute this on your SQL:

ALTER TABLE accounts ADD lotto1 int(1) unsigned not null default '0';
ALTER TABLE accounts ADD lotto2 int(1) unsigned not null default '0';
ALTER TABLE accounts ADD lotto3 int(1) unsigned not null default '0';
ALTER TABLE accounts ADD lotto4 int(1) unsigned not null default '0';
ALTER TABLE accounts ADD win1 int(1) unsigned not null default '0';
ALTER TABLE accounts ADD win2 int(1) unsigned not null default '0';

* Just drop into main dir and drop a link somewhere in the village
* You can add it to Curious Looking Rock, adding a check for a certain
* DK or player level, I've done it this way:
 if ($session['user']['level']==5){    //This quest if for lvl5 players
 page_header("The Old Man");
 output("`n`b`c`2The Old Man`0`c`b");
 output("`2You see an old man that holds you an ancient map. What will you do ? ");
 addnav("Get the Map","labirinto.php");
 addnav("Back to Village","village.php");
 }
--------------------------------------------------------------------------

* Version History:
* Ver. Alpha Created by Excalibur (www.ogsi.it)                       
* Original Version posted to DragonPrime
**xx**************************ss************
* - Originally by: Excalibur
* - Contributors: Excalibur,
* 
*/
require_once "common.php";   
checkday(); 
if (!isset($session)) exit(); 
//Dimension of labirynth, that is square 
$dimensione=5;
//Turns for each player, it should be about half of $dimensione*$dimensione
$turniplayer=12;
unset($session['user']['bio']);
$session['user']['bio']="";
page_header("Teseo's Labirynth");
output("`c<font size='+2'>`^Teseo's Labirynth</font>`c`n`n",true); 
if ($session['user']['turns']<1 and $HTTP_GET_VARS[op]==""){
output("`5You are too tired to face the labirynth today. Try again tomorrow.`n");
addnav("Back to the Village","village.php");
}
else if ($session['user']['labi']>$turniplayer and $HTTP_GET_VARS[op]!="") {
output("`2Unluckily you have ended your turns to find the treasure. Till the next dragon kill you can't face ");
output("the terrible labirynth, that this time has tamed you. Suddendly a mistycal force transport you ");
output("at the entrance of the Labirynth and the only choice given you is to go back to village. ");
addnav("Back to the Village","village.php");
}
else if ($HTTP_GET_VARS[op]=="") {
	if ($ori==0 and $vert==0 and $ori1==0 and $vert1==0){
	output("`2You find yourself at the entrance of what it seems an intricated labirynth. What the old man in the village ");
	output("told you was accurate enough. The path you have done through the forest has take you to the final goal. ");
	output("Now it's up to you. What do you want to do ?`n");
	}
	// let's generate the treasure's coordinate
	$ori=(e_rand(1,$dimensione));
	$vert=(e_rand(1,$dimensione));
	// let's generate the player's coordinate
	$ori1=(e_rand(1,$dimensione));
	$vert1=(e_rand(1,$dimensione));
	// let's generate the ravine's coordinate
	$ori2=(e_rand(1,$dimensione));
	$vert2=(e_rand(1,$dimensione));
	// Check if Player's coordinate is equal to treasure or ravine's coordinate
	if (($ori1==$ori and $vert1==$vert) or ($ori1==$ori2 and $vert1==$vert2)) redirect("labirinto.php");
	// Check to see if Treasure's coordinate is equal to Ravine's coordinate
	if ($ori==$ori2 and $vert==$vert2) redirect("labirinto.php");
	//$session['user']['bio'] = array();
	$session['user']['lotto1']= $ori; //tesoro
	$session['user']['lotto2']= $vert; //tesoro
	$session['user']['lotto3']= $ori1; //player
	$session['user']['lotto4']= $vert1; //player
	$session['user']['win1']= $ori2; //burrone
	$session['user']['win2']= $vert2; //burrone
	//Per usi di debug
	//output("`6Pos.Player {$session['user']['lotto3']} {$session['user']['lotto4']}  `2Pos.Tesoro {$session['user']['lotto1']} 
	//{$session['user']['lotto2']}  `%Pos.Trappola {$session['user']['win1']} {$session['user']['win2']}`n");
	addnav("Enter the Labirynth","labirinto.php?op=labirinto");
	addnav("Back to Village","village.php");
}
else if ($HTTP_GET_VARS[op]=="labirinto") {

output("`2You enter the labirinth, with convinction to tame it. But as you turn the first corner all your sureties ");
output("start to dither ... walls are all the same, and you have already lost your sense of direction. But at this ");
output("point it's too late to get back, you must face it and find the treasure hidden within, or die in the attempt. `n");
$session['user']['turns']-=1;
//Per usi di debug
//output("`6Pos.Player {$session['user']['lotto3']} {$session['user']['lotto4']}  `2Pos.Tesoro {$session['user']['lotto1']} 
//{$session['user']['lotto2']}  `%Pos.Trappola {$session['user']['win1']} {$session['user']['win2']}`n");
addnav("Find the Treasure","labirinto.php?op=cerca");
}
else if ($HTTP_GET_VARS[op]=="cerca") {
	if ($session['user']['labi']>$turniplayer) {
		redirect("labirinto.php?op=fineturni");
	}
// For debug use only
//output("`6Pos.Player {$session['user']['lotto3']} {$session['user']['lotto4']}  `2Pos.Tesoro {$session['user']['lotto1']} 
//{$session['user']['lotto2']}  `%Pos.Trappola {$session['user']['win1']} {$session['user']['win2']}`n");
output("`!Where do u want to go ? North, South, East or West ?`n ");
addnav("North","labirinto.php?op=nord");
addnav("South","labirinto.php?op=sud");
addnav("East","labirinto.php?op=est");
addnav("West","labirinto.php?op=ovest");
}
else if ($HTTP_GET_VARS[op]=="nord"){
$session['user']['lotto4']+=1;
if ($session['user']['lotto4']>$dimensione) {
	redirect("labirinto.php?op=margine");
}
if ($session['user']['lotto3']==$session['user']['lotto1'] and $session['user']['lotto4']==$session['user']['lotto2']) redirect("labirinto.php?op=tesoro");
if ($session['user']['lotto3']==$session['user']['win1'] and $session['user']['lotto4']==$session['user']['win2']) redirect("labirinto.php?op=burrone");
$session['user']['labi']+=1;
movimento("North");
addnav("Search again","labirinto.php?op=cerca");
}
else if ($HTTP_GET_VARS[op]=="sud"){
$session['user']['lotto4']-=1;
if ($session['user']['lotto4']==0) {
	redirect("labirinto.php?op=margine");
}
if ($session['user']['lotto1']==$session['user']['lotto3'] and $session['user']['lotto2']==$session['user']['lotto4']) redirect("labirinto.php?op=tesoro");
if ($session['user']['lotto3']==$session['user']['win1'] and $session['user']['lotto4']==$session['user']['win2']) redirect("labirinto.php?op=burrone");
$session['user']['labi']+=1;
movimento("South");
addnav("Search again","labirinto.php?op=cerca");
}
else if ($HTTP_GET_VARS[op]=="est"){
$session['user']['lotto3']+=1;
if ($session['user']['lotto3']>$dimensione){
	redirect("labirinto.php?op=margine");
}
if ($session['user']['lotto1']==$session['user']['lotto3'] and $session['user']['lotto2']==$session['user']['lotto4']) redirect("labirinto.php?op=tesoro");
if ($session['user']['lotto3']==$session['user']['win1'] and $session['user']['lotto4']==$session['user']['win2']) redirect("labirinto.php?op=burrone");
$session['user']['labi']+=1;
movimento("East");
addnav("Search again","labirinto.php?op=cerca");
}
else if ($HTTP_GET_VARS[op]=="ovest"){
$session['user']['lotto3']-=1;
if ($session['user']['lotto3']==0) {
	redirect("labirinto.php?op=margine");
}
if ($session['user']['lotto1']==$session['user']['lotto3'] and $session['user']['lotto2']==$session['user']['lotto4']) redirect("labirinto.php?op=tesoro");
if ($session['user']['lotto3']==$session['user']['win1'] and $session['user']['lotto4']==$session['user']['win2']) redirect("labirinto.php?op=burrone");
$session['user']['labi']+=1;
movimento("West");
addnav("Search again","labirinto.php?op=cerca");
}
else if ($HTTP_GET_VARS[op]=="fineturni") {
output("`2I'm sorry but you have exausted all the turns you had to find the treasure. Until next dragonkill ");
output("you won't be able to enter again in the labirinth, that has tamed you this time. Suddendly ");
output("a mistycal force transport you at the entrance of the Labirynth and the only choice given you is to ");
output("follow the path that leads you back to the village.`n");
addnav("Back to Village","village.php");
}
else if ($HTTP_GET_VARS[op]=="margine") {
if ($session['user']['lotto3']>$dimensione){
	$z="eastern";
	$session['user']['lotto3']-=1;
}
if ($session['user']['lotto3']==0){
	$z="western";
	$session['user']['lotto3']+=1;
}	
if ($session['user']['lotto4']>$dimensione){
	$z="northern";
	$session['user']['lotto4']-=1;
}
if ($session['user']['lotto4']==0){
	$z="southern";
	$session['user']['lotto4']+=1;
}
output("`$ You can't go this way, you have reached the `3`b".$z."`b`$ margin og the labirynth. `n");
output("`2Try another direction. `n");
addnav("Look for Treasure","labirinto.php?op=cerca");
}
else if ($HTTP_GET_VARS[op]=="tesoro") {
page_header("The Treasure");
output("`c<font size='+2'>`4The TREASURE of the Labirynt !!!</font>`c`n`n",true); 
output("`5`bI can't believe it'!!!`b`n `2You have found the Labirynth's Treasure!!! `n");
output("`1In front of you stands an `6`bAmazing Treasure`b`1, made of gold and gems!!!`n`n");
$gembonus=e_rand(2,3);
$goldbonus=e_rand(500,2000);
$session['user']['gold']+=$goldbonus;
$session['user']['gems']+=$gembonus;
output("`#You have found `7`b".$gembonus." gems`b `#and `b`7".$goldbonus." `b`#gold!!!`n");
addnews("`6".$session['user']['name']." `2has found the Labirynth's Treasure!!");
debuglog("has found $gembonus gems and $goldbonus gold in labirynth");
addnav("Back to Village","village.php");
}
else if ($HTTP_GET_VARS[op]="burrone"){
page_header("The Ravine");
output("`c<font size='+2'>`5The Ravine !!!</font>`c`n`n",true); 
output("`2Regrettably your gold fever hasn't let you notice a ravine on the ground in front of your feet, and you've ");
output("fallen down into it. While you fall deeper into the ravine, getting darker each meter, you have time to think ");
output("at your greediness, and you promise yourself to be more cautious next time. `n`n");
output("`4`bYou're DEAD!!!`b`n");
output("`5`bYou have lost all your gold!!!`b`n");
output("`1`bYou have lost 10% of your experience!!!`b`n");
switch(e_rand(1,8)){
case 1:
if ($session['user']['gems']>0){
output("`5`bRegrettably while you fall down into the ravine you lose 1 gem!!!`b`n");
$session['user']['gems']-=1;
}
case 2: case 3: case 4: case 5: case 6: case 7: case 8:

}
$session['user']['alive']=false;
$session['user']['hitpoints']=0;
$goldbonus=$session['user']['gold'];
$session['user']['gold']=0;
$session['user']['experience']*=0.9;
addnews("`2".$session['user']['name']." `4is dead trying to find the Treasure of the Labirynth!!");
debuglog("has lost $goldbonus gold when is dead into labirynth");
addnav("Land of Shades","shades.php");
}
// To change a little the msg when player moves around
function movimento($type) 
  {
   switch(e_rand(1,7)){
   case 1:
   output("`%You walk in $type direction till next crossing, but you find nothing. `n`2Go on with your research.`n");
   break;
   case 2:
   output("`%You make some steps in $type direction till next crossing, without any result. `n`2Go on with your research.`n");
   break;
   case 3:
   output("`%You tend into $type direction, but you notice nothing of any interest. `n`2Go on with your research.`n");
   break;
   case 4:
   output("`%You walk in $type direction, with the hope to find the treasure, but you're unlucky. `n`2Go on with your research.`n");
   break;
   case 5:
   output("`%You go into $type direction, but you find yourself at a crossing identical to the one you've leaved. `n`2Go on with your research.`n");
   break;
   case 6:
   output("`%You proceed to $type direction, with hope to find the treasure, with no luck. `n`2Go on with your research.`n");
   break;
   case 7:
   output("`%You move to $type direction, and when you arrive to the next crossing you look around without hope. `n`2Go on with your research.`n");
   }
  }
page_footer();
?>