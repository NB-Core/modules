Installation of amulets is very simple.  

Copy to your modules folder.
Install the module from Manage Modules
Activate the Module.

This module has been tested on Versions 1.0.0 and up....
