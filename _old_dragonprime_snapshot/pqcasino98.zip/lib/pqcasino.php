<?php
global $session;
$op = httpget('op');
$do = httpget('do');
$bet = httpget('bet');
$texts = array();
require_once("lib/commentary.php");
addcommentary();
page_header("Casino");
output("`c`b`&Casino`0`b`c");
rawoutput("<marquee height=\"15\" width=\"100%\" onMouseover=\"this.stop()\" onMouseout=\"this.start()\" direction=left scrollamount=\"5\" style=\"Filter:Alpha(Opacity=0, FinishOpacity=100, Style=1, StartX=0, StartY=100, FinishX=0, FinishY=0); text-align:center\"><font class=body><font color=00FFFF>Welcome to the Casino </font><font color=FF0000>Have Fun!</font><br></marquee>");
if ($op==""){
    output("`7You stroll into the casino.. it's a busy place.  You look for a place to loose your gold.`n`n");
    viewcommentary("casino", "Converse here", 10, "converse");
    addnav("High Card Table", "runmodule.php?module=pqcasino&op=highcard");
    modulehook("pqcasino",$texts);
    villagenav();
}
if ($op=="highcard"){
    $go = 1;
    if($bet > $session['user']['gold']){
    output("`@You do not have enough money to bet.  Try Betting less");
    $go = 0;
    }
    
    if($do=="play" && !$bet){
    if (get_module_setting('bet1') > 0) addnav(array("Bet %s",get_module_setting('bet1')), "runmodule.php?module=pqcasino&op=highcard&do=play&bet=".get_module_setting('bet1'));
    if (get_module_setting('bet2') > 0) addnav(array("Bet %s",get_module_setting('bet2')), "runmodule.php?module=pqcasino&op=highcard&do=play&bet=".get_module_setting('bet2'));
    if (get_module_setting('bet3') > 0) addnav(array("Bet %s",get_module_setting('bet3')), "runmodule.php?module=pqcasino&op=highcard&do=play&bet=".get_module_setting('bet3'));
    if (get_module_setting('bet4') > 0) addnav(array("Bet %s",get_module_setting('bet4')), "runmodule.php?module=pqcasino&op=highcard&do=play&bet=".get_module_setting('bet4'));
    //lets get an inputable bet here....
    }
    if($do == "play" && $bet && $go){
    addnav("Play Again", "runmodule.php?module=pqcasino&op=highcard&do=play");
    $yourcard = e_rand(2,14);
    $yoursuit = e_rand(0,3);
    $mycard = e_rand(2,14);
    $mysuit = e_rand(0,3);
    if ($yourcard==$mycard and $yoursuit==$mysuit){
	    if ($mysuit == 3) $yoursuit = 0;
	    if ($mysuit == 2) $yoursuit = 1;
	    if ($mysuit == 1) $yoursuit = 2;
	    if ($mysuit == 0) $yoursuit = 3;
    }
    $suitName = array("diamonds", "hearts", "spades", "clubs");
    $specialCard = array("jack", "queen", "king", "ace");
    if($yourcard == $mycard) $result = 0;
    if($yourcard > $mycard) $result = 1;
    if($yourcard < $mycard) $result = -1;
    if($yourcard > 10) $yourcard = $specialCard[$yourcard - 11];
    if($mycard > 10) $mycard = $specialCard[$mycard - 11];
    output("`2You bet: `#$bet`2");
    output("`n`nMy Card is: ");
    $mycard.="of";
    $mycard.=$suitName[$mysuit];
    $mycard.=".gif";
    rawoutput("<IMG SRC=\"./images/$mycard\"><BR>\n");
    output("`n`nYour Card is: ");
    $yourcard.="of";
    $yourcard.=$suitName[$yoursuit];
    $yourcard.=".gif";
    rawoutput("<IMG SRC=\"./images/$yourcard\"><BR>\n");
     switch($result){
     case 1:
        output("`n`n`^You win!!!");
        $session['user']['gold']+=$bet;
        break;
     case 0:
        output("`n`n`^Push.  Keep your money");
        break;
     case -1:
        output("`n`n`^I win, I'm taking your money");
        $session['user']['gold']-=$bet;
        break;    
    }
    }
    if($do==""){
    output("`4You stroll over to a dirty wooden table.  You can see ale spilled all over the table and there's broken glass all over the floor.`n`n");
    output("`%There is one bit of good news, the woman standing in front of you is holding a deck of cards and a stack of gold that could be yours `n`n");
    addnav("Play", "runmodule.php?module=pqcasino&op=highcard&do=play");
    addnav("or");
    }
    addnav("Play Something Else","runmodule.php?module=pqcasino");
    villagenav();
}
//I cannot make you keep this line here but would appreciate it left in.
rawoutput("<div style=\"text-align: left;\"><a href=\"http://www.pqcomp.com\" target=\"_blank\">Casino by Lonny @ http://www.pqcomp.com</a><br>");
page_footer();
?>