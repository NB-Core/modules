<?php
function pqcasino_getmoduleinfo(){
	$info = array(
		"name"=>"Casino",
		"version"=>"2.0",
		"author"=>"`#Lonny Luberts",
		"category"=>"PQcomp",
		"download"=>"http://www.pqcomp.com/modules/mydownloads/visit.php?cid=3&lid=13",
		"vertxtloc"=>"http://www.pqcomp.com/",
		"settings"=>array(
			"Casino Module Settings,title",
			"casinoloc"=>"Where does the Casino appear,location|".getsetting("villagename", LOCATION_FIELDS),
			"bet1"=>"Hi-Low bet amount 1,int|25",
			"bet2"=>"Hi-Low bet amount 2,int|50",
			"bet3"=>"Hi-Low bet amount 3,int|75",
			"bet4"=>"Hi-Low bet amount 4,int|100",
		),
	);
	return $info;
}

function pqcasino_install(){
	if (!is_module_active('pqcasino')){
		output("`4Installing Casino Module.`n");
	}else{
		output("`4Updating Casino Module.`n");
	}
	module_addhook("village");
	return true;
}

function pqcasino_uninstall(){
	output("`4Un-Installing Casino Module.`n");
	return true;
}

function pqcasino_dohook($hookname,$args){
	global $session;
	$town=$session['user']['location'];
			if ($session['user']['location'] == get_module_setting("casinoloc")){
			tlschema($args['schemas']['tavernnav']);
    		addnav($args['tavernnav']);
    		tlschema();
			addnav(array("%s Casino",$town),"runmodule.php?module=pqcasino");
			}
	return $args;
}

function pqcasino_run(){
	global $SCRIPT_NAME;
	if ($SCRIPT_NAME == "runmodule.php"){
		$module=httpget("module");
		if ($module == "pqcasino"){
			include("modules/lib/pqcasino.php");
		}
	}
}
?>