<?php

function pilze_hooks_dohook_pdvnavsonstiges_private($args=false){
		addnav("K�chenhaus","runmodule.php?module=pilze&op=khaus");
	return $args;
}
