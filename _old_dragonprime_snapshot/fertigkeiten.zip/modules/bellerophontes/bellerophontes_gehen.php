<?php
	output("`@Du verl�sst diesen seltsamen Ort und kehrst in den Wald zur�ck. Eine vern�nftige Entscheidung! Aber "
		  ."Dein Entdeckerherz fragt sich, ob `bVernunft`b f�r einen Abenteurer die Beste aller Eigenschaften ist ...");
    $session['user']['specialinc']="";
?>
