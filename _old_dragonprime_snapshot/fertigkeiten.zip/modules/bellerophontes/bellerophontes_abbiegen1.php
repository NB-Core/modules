<?php
    output("`@Du biegst an der Kreuzung ab und verl�sst den Weg.");
    $session['user']['specialinc']="";
?>
