<?php
		$werte = array(    "name"=>"T�towierer",        // Text der im Link erscheinen soll
		"appear"=>get_module_setting("appear","pdvtaet"));    // Abfrage ob anwesend oder nicht
		$args['pdvtaet'] = $werte;	
	return $args;
?>
