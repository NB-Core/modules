<?php
				$werte = array(	"name"=>"Missionar",		// Text der im Link erscheinen soll
				"appear"=>get_module_setting("appear","pdvmissionar"));	// Abfrage ob anwesend oder nicht
				$args['pdvmissionar'] = $werte;
	return $args;
?>
