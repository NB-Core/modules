<?php
		addnav("Der Platz der V�lker");
			addnav("Bogenschie�en","runmodule.php?module=wettkampf&op1=aufruf&subop1=best&subop2=wbogenbest&op2=wbogen3&subop=most&page=1");
			addnav("Klettern","runmodule.php?module=wettkampf&op1=aufruf&subop1=best&subop2=wkletternbest&op2=wklettern0&subop=most&page=1");
			addnav("Kochen","runmodule.php?module=wettkampf&op1=aufruf&subop1=best&subop2=wkochenbest&op2=wkochen&subop=most&page=1");
			addnav("Musik und Gesang","runmodule.php?module=wettkampf&op1=aufruf&subop1=best&subop2=wmusikbest&op2=wmusik2&subop=most&page=1");
			addnav("Reiten","runmodule.php?module=wettkampf&op1=aufruf&subop1=best&subop2=wreitenbest&op2=wreiten2&subop=most&page=1");
			addnav("Schleichen und Verstecken","runmodule.php?module=wettkampf&op1=aufruf&subop1=best&subop2=wschleichenbest&op2=wschleichen0&subop=most&page=1");
			addnav("Schwimmen und Tauchen","runmodule.php?module=wettkampf&op1=aufruf&subop1=best&subop2=wschwimmenbest&op2=wschwimm2&subop=most&page=1");
	return $args;
?>
