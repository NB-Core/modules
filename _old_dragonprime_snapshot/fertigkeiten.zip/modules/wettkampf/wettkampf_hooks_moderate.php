<?php
	global $session;
			$args['wettkampf'] = "Der Platz der V�lker";
	return $args;
?>
