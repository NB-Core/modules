<?php

function wettkampf_main_run_private($op){
	global $session;
	page_header("Der Platz der V�lker");

	switch($op){
	case "tuer":
		require_once("lib/commentary.php");
		output("`2Du n�herst Dich der seltsamen T�r, die Du hier noch nie zuvor gesehen hast ... und sp�rst, dass Dein seltsamer Schl�ssel hei�er wird. An der kleinen, grauen T�r angekommen, die sich kaum von der Mauer unterscheidet, die den Garten umgibt, holst Du ihn hervor. Nat�rlich, er passt ...`n`n");	
		output("`2Vorsichtig schiebst Du sie auf und betrittst einen dunklen Raum, der nur durch einen schwachen, aber dennoch blendenden Schein erleuchtet wird. Du n�herst Dich dem Licht und erkennst eine Person ... `n`n");
		output("`2Sie sitzt auf einen Stuhl gekauert und tippt mit den Fingern auf einem schmalen, grauen Kasten herum ... Du gehst noch n�her heran und siehst, dass die Lampe rechteckig ist ... Aber es ist keine Lampe, denn wie durch ein Wunder ist eine Art Schrift darauf zu erkennen ...`n`n");	
		output("`2Pl�tzlich dreht sich die fremde Gestalt herum - offenbar ist ihr Stuhl drehbar: `#'Wer zum --'`2`n`n");	
		output("`2Sie starrt Dich an - und Du starrst ... `bDich`b selbst an! Wie ist das ... m�glich ... Erschrocken gehst Du einen Schritt zur�ck ... ein Doppelg�nger?`n`n");	
		output("`2Dir schwinden die Sinne. Als Du wieder aufwachst, stehen einige B�rger um Dich herum. Du befindest Dich auf dem Gemeindeplatz und der Schrecken sitzt noch immer tief. Fast m�chtest Du weinen ...`n`n");
		$exp_bonus=round($session[user][experience]*0.2);
		$session[user][experience]+=$exp_bonus;
		output("`2Wenngleich die Erinnerung nur vage ist, hast Du durch diese Begegnung `^%s`2 Erfahrungspunkte hinzugewonnen!", $exp_bonus);	
		set_module_setting("bgegenstand5", "");
		$comment=translate_inline("/me `\$sitzt vor einer kahlen Wand und wacht gerade aus einer Ohnmacht auf. Seltsam, alle Anwesenden k�nnten schw�ren, dass dort schon seit geraumer Zeit niemand gesessen hatte ...");
		injectcommentary(village, "", $comment, $schema=false);
		addnav("Zur�ck","village.php");	
	break;
	case "statue":
		$fest=get_module_setting("fest");
		$blumen=get_module_setting("statueblumen");
		$blumentext="";
			if ($blumen!=0 && $blumen <=5) $blumentext=translate_inline("Einige wenige Blumenstr�u�e sind der Vermittlerin zu Ehren darauf niedergelegt worden.");
			if ($blumen>5 && $blumen <=15) $blumentext=translate_inline("Ein paar Blumenstr�u�e sind der Vermittlerin zu Ehren darauf niedergelegt worden.");
			if ($blumen>15 && $blumen <=50) $blumentext=translate_inline("Eine gro�e Zahl Blumenstr�u�e ist der Vermittlerin zu Ehren darauf niedergelegt worden.");
			if ($blumen>50 && $blumen <=100) $blumentext=translate_inline("Viel ist von dem Rasen aber nicht zu erkennen, angesichts der vielen Blumenstr�u�e, die der Vermittlerin zu Ehren darauf niedergelegt worden sind.");
			if ($blumen>100 && $blumen <=200) $blumentext=translate_inline("Der Rasen l�sst sich aber nur erahnen, angesichts der unheimlich vielen Blumenstr�u�e, die der Vermittlerin zu Ehren darauf niedergelegt worden sind.");
			if ($blumen>200) $blumentext=translate_inline("Der Rasen l�sst sich aber nur vage erahnen - ein pr�chtiges Meer von Blumenstr�u�en, die der Vermittlerin zu Ehren darauf niedergelegt worden sind, bedeckt die gesamte Fl�che!");
		
			$sch�nheit=translate_inline("deren Anblick Dir den Atem nimmt; so unvergleichlich sch�n ist diese junge Frau noch in Stein gemei�elt, dass Du es bedauerst, selbst so vergleichsweise wenig f�r Dein Aussehen zu tun");
			if ($session[user][charm]>240) $sch�nheit=translate_inline("deren Anblick Dir ein L�cheln ins Gesicht zaubert. Sie ist Deiner eigenen, �berm��igen Sch�nheit mehr als ebenb�rtig");
			
		output ("`@`bDie Statue der Vermittlerin`@`b`n`n");
		output ("`@Du bist direkt vom Haupttor zur Mitte des Platzes gegangen, wo sich die gro�e Marmorstatue der Frau befindet, auf die das Fest der V�lker zur�ckgeht. Um den Sockel, der Dir bis zum Hals reicht, herum ist eine gro�e, kreisrunde Rasenfl�che angelegt, die man aber nicht betreten muss, um bis an ihn heranzugehen. %s`n`n Aus jeder der vier Himmelsrichtungen f�hrt ein gerader, gepflasterter Pfad bis zur Statue, %s. Die gro�e Vermittlerin ist in einer Pose dargestellt, wie viele sie kennen, die ihr schon einmal begegnet sind: Sie tr�gt ein langes, �rmelloses Sommerkleid und sitzt gedankenverloren l�chelnd am Rande eines Brunnens. Ihre linke Hand l�sst sie langsam durchs Wasser gleiten, w�hrend ihre rechte auf dem Scho� ruht. Die Statue wirkt so echt, als w�re die Vermittlerin tats�chlich hier bei Dir ...", $blumentext, $sch�nheit);
	
		addnav("Die Statue");
		addnav("Gedenktafel lesen","runmodule.php?module=wettkampf&op1=statue-tafel");
		addnav("Blumen niederlegen (50 GS)","runmodule.php?module=wettkampf&op1=statue-blumen");
		addnav("Zur�ck","runmodule.php?module=wettkampf&op1=");
	break;
	case "statue-blumen":
		$wieoft=get_module_pref("blumenniederlegen");
		if ($wieoft==5){
	 		output ("`@Du willst gerade zum Blumenh�ndler gehen, als Dir auff�llt, dass Du schon sehr viele Blumen niedergelegt hast. Das f�hrt nur zu Sozialneid - also l�sst Du es bleiben. Aus Erfahrung wei�t Du, dass die Blumen am Ende eines Festes eingesammelt werden.");
		}else if ($session[user][gold]<50){
			output ("`@Du z�hlst Dein Geld und musst leider feststellen, dass Du Dir keine Blumen leisten kannst."); 
		}else{
			output ("`@Du gehst zu einem Blumenh�ndler, der einen dauerhaften Stand im unteren Marktbereich hat und kaufst einen sch�nen Strau� Blumen, um ihn auf dem Rasenplatz vor der Statue niederzulegen.`n`n");
			output ("`@Dabei wirst Du von einigen B�rgern beobachtet.");
			$session[user][gold]-=50;
			$blumen=get_module_setting("statueblumen");
			$blumenneu=$blumen+1;
			set_module_setting("statueblumen", $blumenneu);
			$wieoftneu=$wieoft+1;
			set_module_pref("blumenniederlegen", $wieoftneu);
			
			$ereignis=e_rand(-1,2);
			if ($ereignis >= 1){
				if ($wieoftneu==2){
					output ("`@Sie nicken anerkennend, weil Du schon einmal Blumen hergebracht hast. Irgendwie f�hlst Du Dich dadurch ... `igut`i.");
					if (is_module_active('alignment')) align("2");
				}else if ($wieoftneu>3 && $wieoftneu<5){
					output ("`@Sie nicken anerkennend, weil Du schon �fter Blumen hergebracht hast. Irgendwie f�hlst Du Dich dadurch ... `igut`i.");
					if (is_module_active('alignment')) align("1");
				}else if ($wieoftneu==5){
					output ("`@Einige von ihnen sch�tteln emp�rt den Kopf, weil Du anscheinend zuviel Geld hast, dass Du soviele Blumen hierherbringst. `#'Ein klarer Fall von Sozialneid'`@, denkst Du Dir - und gehst mit einer abf�lligen Geste davon ...");
					if (is_module_active('alignment')) align("-2");
				}
			}
		}
	
		addnav("Zur�ck","runmodule.php?module=wettkampf&op1=statue");
	break;
	case "statue-tafel":
		output ("`@Du trittst n�her an den gro�en Sockel heran und liest die Inschrift:`n`n`n`n`n`n`n`c`^Ich erinnere mich noch gut daran, wie unvollkommen und fehlbar mir die Sterblichen`n erschienen waren, als ich noch kein Mensch war. Doch nun, da ich selbst auf diesen`n Zustand zur�ckgeworfen bin, habe ich viel �ber ihr Leben gelernt.`n`nGerade ihre Fehlbarkeit ist es, die sie zu etwas Besonderem macht: Die Zwerge, die Elfen,`n die Echsen, die Menschen, die Vanthira, die Trolle, aber auch jene, die jedem Volke`n angeh�ren und keinem, die Kinder der Nacht. Ihre Unvollkommenheit ist der Keim`n ihrer Gemeinschaftlichkeit, das habe ich nun erkannt, und ihre Gemeinschaftlichkeit`n ist der Keim dessen, wof�r ich mit meinem Leben einstehe: F�r die Liebe.`n`nDieser Platz sei dem friedlichen Miteinander der V�lker gewidmet. `n`nMein Dank gilt MarkAurel und insbesondere Nathan, die mir geholfen haben, diesen Traum zu verwirklichen,`n und allen Sterblichen wie Unsterblichen, die in friedlicher Absicht hierherkommen.`n`nDie Vermittlerin`c`n`n`@Darunter steht etwas kleiner:`n`n`c`^`iDiese Statue der gro�en Vermittlerin bereits zu Lebzeiten,`nwenngleich dies ihrer wesenseigenen Bescheidenheit widerspricht `n`nDie F�rsten der V�lker`i`c");
		addnav("Zur�ck","runmodule.php?module=wettkampf&op1=statue");
	break;
	case "werte":
	//Fertigkeiten und Mods aufrufen
		require_once("lib/fert.php");
		require_once("modules/wettkampf/wettkampf_lib.php");
		
		$array=get_fertigkeiten_array();
		
		$bogen=$array["bogen"];
		$schwimmen=$array["schwimmen"];
		$kochen=$array["kochen"];
		$klettern=$array["klettern"];
		$musik=$array["musik"];
		$reiten=$array["reiten"];
		$schleichen=$array["schleichen"];
		
		$modbogentext=set_modtext(bogen);
		$modschwimmentext=set_modtext(schwimmen);
		$modkochentext=set_modtext(kochen);
		$modkletterntext=set_modtext(klettern);
		$modmusiktext=set_modtext(musik);
		$modreitentext=set_modtext(reiten);
		$modschleichentext=set_modtext(schleichen);
	
	//Wettkampfergebnisse aufrufen
		$wbogen0=get_module_pref("wbogen0");
		$wbogen1=get_module_pref("wbogen1");
		$wbogen2=get_module_pref("wbogen2");
		$wbogen3=get_module_pref("wbogen3");
		$bestbogen0=get_module_pref("bestbogen0");
		$bestbogen1=get_module_pref("bestbogen1");
		$bestbogen2=get_module_pref("bestbogen2");
		$bestbogen3=get_module_pref("bestbogen3");
		
		$wschwimm0=get_module_pref("wschwimm0");
		$wschwimm1=get_module_pref("wschwimm1");
		$wschwimm2=get_module_pref("wschwimm2");
		$bestschwimm0=get_module_pref("bestschwimm0");
		$bestschwimm1=get_module_pref("bestschwimm1");
		$bestschwimm2=get_module_pref("bestschwimm2");
		
		$wmusik0=get_module_pref("wmusik0");
		$wmusik1=get_module_pref("wmusik1");
		$wmusik2=get_module_pref("wmusik2");
		$bestmusik0=get_module_pref("bestmusik0");
		$bestmusik1=get_module_pref("bestmusik1");
		$bestmusik2=get_module_pref("bestmusik2");
		
		$wreiten0=get_module_pref("wreiten0");
		$wreiten1=get_module_pref("wreiten1");
		$wreiten2=get_module_pref("wreiten2");
		$bestreiten0=get_module_pref("bestreiten0");
		$bestreiten1=get_module_pref("bestreiten1");
		$bestreiten2=get_module_pref("bestreiten2");
		
		$wkochen=get_module_pref("wkochen");
		$bestkochen=get_module_pref("bestkochen");
		$bestespeise=get_module_pref("bestespeise");
		
		$wklettern0=get_module_pref("wklettern0");
		$bestklettern0=get_module_pref("bestklettern0");
		
		$wschleichen0=get_module_pref("wschleichen0");
		$bestschleichen0=get_module_pref("bestschleichen0");
	
		//Werte
		output ("`@`bI. Deine Fertigkeitswerte`b`n`n");
		output("`@Bogenschie�en: `^%s/100%s`@`n", $bogen, $modbogentext);
		if ($bogen<25) output("`2--> Rang: %s.", ($session[user][sex]?"Anf�ngerin":"Anf�nger"));
		else if ($bogen>=25 && $bogen <50) output("`2--> Rang: %s.", ($session[user][sex]?"Sch�lerin":"Sch�ler"));
		else if ($bogen>=50 && $bogen < 75) output("`2--> Rang: %s.", ($session[user][sex]?"Fortgeschrittene":"Fortgeschrittener"));
		else if ($bogen>=75 && $bogen <= 95) output("`2--> Rang: %s.", ($session[user][sex]?"Meisterin":"Meister"));
		else if ($bogen>95) output("`2--> Rang: %s.", ($session[user][sex]?"Gro�meisterin":"Gro�meister"));
		
		output("`@`n`nKlettern: `^%s/100%s`@`n", $klettern, $modkletterntext);
		if ($klettern<25) output("`2--> Rang: %s.", ($session[user][sex]?"Anf�ngerin":"Anf�nger"));
		else if ($klettern>=25 && $klettern <50) output("`2--> Rang: %s.", ($session[user][sex]?"Sch�lerin":"Sch�ler"));
		else if ($klettern>=50 && $klettern < 75) output("`2--> Rang: %s.", ($session[user][sex]?"Fortgeschrittene":"Fortgeschrittener"));
		else if ($klettern>=75 && $klettern <= 95) output("`2--> Rang: %s.", ($session[user][sex]?"Meisterin":"Meister"));
		else if ($klettern>95) output("`2--> Rang: %s.", ($session[user][sex]?"Gro�meisterin":"Gro�meister"));
		
		output("`n`n`@Kochen und Pflanzenkunde: `^%s/100%s`@`n", $kochen, $modkochentext);
		if ($bestespeise!="")output("`2--> Als bislang beste Speise hast Du der Jury `i%s`i pr�sentiert.`n", $bestespeise);
		if ($kochen<25) output("`2--> Rang: %s.", ($session[user][sex]?"Anf�ngerin":"Anf�nger"));
		else if ($kochen>=25 && $kochen <50) output("`2--> Rang: %s.", ($session[user][sex]?"Sch�lerin":"Sch�ler"));
		else if ($kochen>=50 && $kochen < 75) output("`2--> Rang: %s.", ($session[user][sex]?"Fortgeschrittene":"Fortgeschrittener"));
		else if ($kochen>=75 && $kochen <= 95) output("`2--> Rang: %s.", ($session[user][sex]?"Meisterin":"Meister"));
		else if ($kochen>95) output("`2--> Rang: %s.", ($session[user][sex]?"Gro�meisterin":"Gro�meister"));
		
		output("`@`n`nMusik und Gesang: `^%s/100%s`@`n", $musik, $modmusiktext);
		if ($musik<25) output("`2--> Rang: %s.", ($session[user][sex]?"Anf�ngerin":"Anf�nger"));
		else if ($musik>=25 && $musik <50) output("`2--> Rang: %s.", ($session[user][sex]?"Sch�lerin":"Sch�ler"));
		else if ($musik>=50 && $musik < 75) output("`2--> Rang: %s.", ($session[user][sex]?"Fortgeschrittene":"Fortgeschrittener"));
		else if ($musik>=75 && $musik <= 95) output("`2--> Rang: %s.", ($session[user][sex]?"Meisterin":"Meister"));
		else if ($musik>95) output("`2--> Rang: %s.", ($session[user][sex]?"Gro�meisterin":"Gro�meister"));
		
		output("`@`n`nReiten und Kutschefahren: `^%s/100%s`@`n", $reiten, $modreitentext);
		if ($reiten<25) output("`2--> Rang: %s.", ($session[user][sex]?"Anf�ngerin":"Anf�nger"));
		else if ($reiten>=25 && $reiten <50) output("`2--> Rang: %s.", ($session[user][sex]?"Sch�lerin":"Sch�ler"));
		else if ($reiten>=50 && $reiten < 75) output("`2--> Rang: %s.", ($session[user][sex]?"Fortgeschrittene":"Fortgeschrittener"));
		else if ($reiten>=75 && $reiten <= 95) output("`2--> Rang: %s.", ($session[user][sex]?"Meisterin":"Meister"));
		else if ($reiten>95) output("`2--> Rang: %s.", ($session[user][sex]?"Gro�meisterin":"Gro�meister"));
		
		output("`@`n`nSchleichen und Verstecken: `^%s/100%s`@`n", $schleichen, $modschleichentext);
		if ($schleichen<25) output("`2--> Rang: %s.", ($session[user][sex]?"Anf�ngerin":"Anf�nger"));
		else if ($schleichen>=25 && $schleichen <50) output("`2--> Rang: %s.", ($session[user][sex]?"Sch�lerin":"Sch�ler"));
		else if ($schleichen>=50 && $schleichen < 75) output("`2--> Rang: %s.", ($session[user][sex]?"Fortgeschrittene":"Fortgeschrittener"));
		else if ($schleichen>=75 && $schleichen <= 95) output("`2--> Rang: %s.", ($session[user][sex]?"Meisterin":"Meister"));
		else if ($schleichen>95) output("`2--> Rang: %s.", ($session[user][sex]?"Gro�meisterin":"Gro�meister"));
		
		output("`n`n`@Schwimmen und Tauchen: `^%s/100%s`@`n", $schwimmen, $modschwimmentext);
		if ($schwimmen<25) output("`2--> Rang: %s.", ($session[user][sex]?"Anf�ngerin":"Anf�nger"));
		else if ($schwimmen>=25 && $schwimmen <50) output("`2--> Rang: %s.", ($session[user][sex]?"Sch�lerin":"Sch�ler"));
		else if ($schwimmen>=50 && $schwimmen < 75) output("`2--> Rang: %s.", ($session[user][sex]?"Fortgeschrittene":"Fortgeschrittener"));
		else if ($schwimmen>=75 && $schwimmen <= 95) output("`2--> Rang: %s.", ($session[user][sex]?"Meisterin":"Meister"));
		else if ($schwimmen>95) output("`2--> Rang: %s.", ($session[user][sex]?"Gro�meisterin":"Gro�meister"));
		
		output("`n`n`i`2`bAnmerkungen:`b`n Der Startwert betr�gt 5, kann jedoch durch einen Rassenmalus (-5) auf den Minimalwert 0 gesetzt sein.`n Der Maximalwert von 95 kann nur mit einem Rassenbonus (+5) �berschritten werden.`n Achtung: W�ge bei Deinen Steigerungen gut ab, welchen zuk�nftigen Nutzen Du Dir von der jeweiligen Fertigkeit versprichst.`i");
		addnav("Zur�ck","runmodule.php?module=wettkampf&op1=");
	
		//Ergebnisse
		$fest=get_module_setting("fest");
		$festtext=translate_inline("bei diesem");
		$festtext2=translate_inline("Du f�hrst bei diesem Wettbewerb!"); 
		$standardwhere = "(locked=0)";
		if ($fest==0){
			$festtext=translate_inline("beim letzten");
			$festtext2=translate_inline("Du hast diesen Wettbewerb gewonnen!");
		}
		$siegerbogen=sieger(bogen);
		$siegerklettern=sieger(klettern);
		$siegerkochen=sieger(kochen);
		$siegerreiten=sieger(reiten);
		$siegerschleichen=sieger(schleichen);
		$siegerschwimmen=sieger(schwimmen);
		$siegermusik=sieger(musik);
	
		if ($wbogen3 != 10000 || $wschwimm2 != 10000 || $wkochen != 10000 || $wklettern0 != 10000 || $wschleichen0 != 10000 || $wreiten2 != 10000 || $wmusik2 != -1) output ("`@`b`n`n`nII. Deine Ergebnisse %s Fest der V�lker`b`n`n", $festtext);
		if ($wbogen3!=10000) output("`@Bogenschie�en: %s.`n", ($wbogen3==0?"`\$Kein einziger Treffer`2":($wbogen3==1?"`^$wbogen3`2 Punkt":"`^$wbogen3`2 Punkte")));
		if ($siegerbogen[acctid]==$session[user][acctid])output("`2--> %s`n", $festtext2);
	
		if ($wklettern0!=10000) output("`@`nKlettern: %s.`n", ($wklettern0==0?"`\$Disqualifiziert`2":"`^$wklettern0`2 Meter"));
		if ($siegerklettern[acctid]==$session[user][acctid])output("`2--> %s`n", $festtext2);
	
		if ($wkochen!=10000) output("`@`nKochen: %s.`n", ($wkochen==0?"`\$Disqualifiziert`2":($wkochen==1?"`^$wkochen `2Punkt":"`^$wkochen `2Punkte")));
		if ($siegerkochen[acctid]==$session[user][acctid])output("`2--> %s`n", $festtext2);
	
		if ($wmusik2!=-1) output("`@`nMusik und Gesang: %s.`n", ($wmusik2==0?"`\$Disqualifiziert`2":($wmusik2==1?"`^$wmusik2`2 Punkt":"`^$wmusik2`2 Punkte")));
		if ($siegermusik[acctid]==$session[user][acctid])output("`2--> %s`n", $festtext2);
			
		if ($wreiten2!=10000) output("`@`nReiten und Kutschefahren: %s.`n", ($wreiten2==0?"`\$Null Punkte`2":($wreiten2==1?"`^$wreiten2`2 Punkt":"`^$wreiten2`2 Punkte")));
		if ($siegerreiten[acctid]==$session[user][acctid])output("`2--> %s`n", $festtext2);
		
		if ($wschleichen0!=10000) output("`@`nSchleichen und Verstecken: %s.`n", ($wschleichen0==9999?"`\$Disqualifiziert`2":($wschleichen0==1?"`^$wschleichen0`2 Minute":"`^$wschleichen0`2 Minuten")));
		if ($siegerschleichen[acctid]==$session[user][acctid])output("`2--> %s`n", $festtext2);
		
		if ($wschwimm2!=10000) output("`@`nSchwimmen und Tauchen: `^%s`2 Punkte.`n", $wschwimm2);
		if ($siegerschwimmen[acctid]==$session[user][acctid])output("`2--> %s`n", $festtext2);
	break;
}

page_footer();
}
?>