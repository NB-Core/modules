<?php
/*
Letzte �nderung am 01.05.05 von Michael Jandke

*********************************************************
*	Diese Datei sollte aus fertigkeiten.zip stammen.	*
*														*
*	Achtung: Wer diese Dateien benutzt, verpflichtet	*
*	sich, alle Module, die er f�r das Fertigkeiten-		*
*	system entwickelt frei und �ffentlich zug�nglich	*
*	zu machen! Jegliche Ver�nderungen an diesen Dateien *
*	m�ssen ebenfalls ver�ffentlicht werden!				*
*														*
*	N�heres siehe: dokumentation.txt					*
*														*
*	Wir entwickeln f�r Euch - Ihr entwickelt f�r uns.	*
*														*
*	Jegliche Ver�nderungen an diesen Dateien 			*
*	m�ssen ebenfalls ver�ffentlicht werden - so sieht 	*
*	es die Lizenz vor, unter der LOTGD ver�ffentlicht	*
*	wurde!												*
*														*
*	Zuwiderhandlungen k�nnen empfindliche Strafen		*
*	nach sich ziehen!									*
*														*
*	Zudem bitten wir darum, dass Ihr uns eine kurze		*
*	Mail an folgende Adresse zukommen lasst, in der		*
*	Ihr	uns die Adresse des Servers nennt, auf dem das	*
*	Fertigkeitensystem verwendet wird:					*
*	cern AT quantentunnel.de							*
*	(Spamschutz " AT " durch "@" ersetzen)				*
*														*
*	Das komplette Fertigkeitensystem ist zuerst auf		*
*	http://www.green-dragon.info erschienen.			*
*														*
*********************************************************

H�ndler f�r den PdV, der Items zur permanenten Verbesserung der Fertigkeitswerte anbietet
Die Chance auf sein Erscheinen sollte niedrig angesetzt werden, die Preise f�r die Items dagegen sehr hoch!

To Do:	- alternative currencies?
		- Option f�r Verlieren nach Dk einbauen? (w�re nur sinnvoll im Zusammenhang mit niedrigeren Preisen)
		- Textausarbeitung, Textformatierung, Rechtschreibung, Namen etc.
		- alles anders machen: er hat eine bestimmte, zuf�llige Auswahl aus allen Items dabei, diese werden alle angezeigt
		- am besten bei newday-runonce diese Auswahl treffen
		- noch eine begrenzte St�ckzahl einbauen?
		- bei Items die �ber dem erlaubten Bonuswert liegen [Anschauen] machen, ansonsten [Kaufen]
*/

function fertitemhaendler_getmoduleinfo(){
	$info = array(
		"name"=>"PdV - Spezialh�ndler, Fertigkeitenitems",
		"version"=>"0.1",
		"author"=>"Michael Jandke",
		"category"=>"Der Platz der Voelker",
		"download"=>"",
		"requires"=>array(
			"wettkampf"=>"1.0|Platz der V�lker von Oliver Wellinghoff",
			"fertigkeiten"=>"1.0|Grundmodul f�r Fertigkeitswerte von Oliver Wellinghoff und Michael Jandke",
		),
		"settings"=>array(
			"fertitemhaendler Einstellungen,title",
			"goldcost"=>"Wieviel Gold kostet ein Gegenstand (* Bonuslevel),int|12000",
			"gemcost"=>"Wieviele Edelsteine kostet ein Gegenstand (* Bonuslevel)?,int|12",
			
			"chance"=>"Wie gro� ist die Chance dass er w�hrend des Festes erscheint (in Prozent)?,range,0,100,1|40",
			"appear"=>"Ist der Stand gerade anwesend (nur w�hrend Fest)?,bool|0",
		),
		"prefs"=>array(
			"fertitemhaendler Spielereinstellungen,title",// Warum mache ich das ganze nicht in ein Array?
			"bogen"=>"Modifikator auf Bogenschie�en durch hier gekaufte Items,int|0",
			"klettern"=>"Modifikator auf Klettern durch hier gekaufte Items,int|0",
			"kochen"=>"Modifikator auf Kochen durch hier gekaufte Items,int|0",
			"musik"=>"Modifikator auf Musik und Gesang durch hier gekaufte Items,int|0",
			"reiten"=>"Modifikator auf Reiten durch hier gekaufte Items,int|0",
			"schleichen"=>"Modifikator auf Schleichen und Verstecken durch hier gekaufte Items,int|0",
			"schwimmen"=>"Modifikator auf Schwimmen und Tauchen durch hier gekaufte Items,int|0",
			
			""=>"Array mit den Fertigkeitsmodifikatoren durch dieses Modul,viewonly|{a:7:}",
		),
	);
	return $info;
}

function fertitemhaendler_install(){
	module_addhook("pdvst�nde");
	module_addhook("newday-runonce");
	module_addhook("fert-mod");
	return true;
}

function fertitemhaendler_uninstall(){
	return true;
}

function fertitemhaendler_dohook($hookname,$args){
	
	switch ($hookname) {
	case "newday-runonce":
		if (get_module_setting("fest","wettkampf")==1) {
			$chance = get_module_setting("chance","fertitemhaendler");
			if (e_rand(1,100)<=$chance) set_module_setting("appear",1,"fertitemhaendler");
			else set_module_setting("appear",0,"fertitemhaendler");
			debug("fertitemhaendler appear = ".get_module_setting("appear"));
		}
		break;
	case "pdvst�nde":
		$werte = array(	"name"=>"xyz, der Spezialit�tenh�ndler",		// Text der im Link erscheinen soll
						"appear"=>get_module_setting("appear","fertitemhaendler"));	// Abfrage ob anwesend oder nicht
		$args['fertitemhaendler'] = $werte;
		break;
	case "fert-mod":
		$modarray = array("bogen"=>0,"klettern"=>0,"kochen"=>0,"musik"=>0,"reiten"=>0,"schleichen"=>0,"schwimmen"=>0);
		foreach ($modarray as $key=>$val) {
			$val = get_module_pref($key,"fertitemhaendler");
			$modarray[$key]=$val;
		}
		$args['fertitemhaendler'] = $modarray;
		//debug("Fertitemhaendler Args = ");
		//debug($modarray);
		break;
	}
	return $args;
}

function fertitemhaendler_runevent($type, $link) {
}

function fertitemhaendler_run(){
	global $session;
	checkday();
	$from = "runmodule.php?module=fertitemhaendler&";
	$op = httpget('op');
	$bonus = min(5,floor($session['user']['dragonkills']/20)+1);	// das ist der maximal erlaubte Bonus f�r den Spieler, z.Z. 0-19 +1, 20-39 +2, 40-59 +3, 60-79 +4, ab 80 +5
	debug("Bonus = ".$bonus);
	//$bonus = -alternative Formel hier-
	$goldcost = get_module_setting("goldcost");// * $bonus;
	$gemcost = get_module_setting("gemcost");
	$alleitems = array(
		1=>array(
			"bogen"=>"Kurzbogen +1",
			"klettern"=>"klettern +1",
			"kochen"=>"kochen +1",
			"musik"=>"musik +1",
			"reiten"=>"reiten +1",
			"schleichen"=>"schleichen +1",
			"schwimmen"=>"schwimmen +1"
		),
		2=>array(
			"bogen"=>"Bogen +2",
			"klettern"=>"klettern +2",
			"kochen"=>"kochen +2",
			"musik"=>"musik +2",
			"reiten"=>"reiten +2",
			"schleichen"=>"schleichen +2",
			"schwimmen"=>"schwimmen +2"
		),
		3=>array(
			"bogen"=>"Langbogen +3",
			"klettern"=>"klettern +3",
			"kochen"=>"kochen +3",
			"musik"=>"musik +3",
			"reiten"=>"reiten +3",
			"schleichen"=>"schleichen +3",
			"schwimmen"=>"schwimmen +3"
		),
		4=>array(
			"bogen"=>"Komposit-Langbogen +4",
			"klettern"=>"klettern +4",
			"kochen"=>"kochen +4",
			"musik"=>"musik +4",
			"reiten"=>"reiten +4",
			"schleichen"=>"schleichen +4",
			"schwimmen"=>"schwimmen +4"
		),
		5=>array(
			"bogen"=>"`2Waldelfen`@-K`2om`@po`2sit`@-`7Langbogen `&+`^5",
			"klettern"=>"klettern +5",
			"kochen"=>"kochen +5",
			"musik"=>"musik +5",
			"reiten"=>"reiten +5",
			"schleichen"=>"schleichen +5",
			"schwimmen"=>"schwimmen +5"
		)
	);
	//debug($alleitems);
	$items = array("bogen"=>0,"klettern"=>0,"kochen"=>0,"musik"=>0,"reiten"=>0,"schleichen"=>0,"schwimmen"=>0);
	foreach ($items as $key => $val) {
		$items[$key] = get_module_pref($key);
	}
	debug("Fertitemhaendler Items am Mann = ");
	debug($items);
	
	page_header("Der sowieso H�ndler");
	
	if ($op=="") {
		output("Ganz seltener H�ndler aus fernen Landen, Spezialit�ten von allen V�lker dabei, nat�rlich haben die auch ihren Preis...");
		
		output_notl("`n`n<table border=0 cellpadding=2 cellspacing=1 align='center' bgcolor='#999999'>", true);
		rawoutput("<colgroup><col width=250><col width=180><col width=70></colgroup>");
		$a = translate_inline("`bName`b");
		$s = translate_inline("`bPreis`b");
		$ac = translate_inline("`bAktion`b");
		$buy = translate_inline("Kaufen");
		$sell = translate_inline("Verkaufen");
		rawoutput("<tr align='center' class='trhead'><td>");
		output_notl($a);
		rawoutput("</td><td>");
		output_notl($s);
		rawoutput("</td><td>");
		output_notl($ac);
		rawoutput("</td></tr>");
		for ($i=1;$i<=$bonus;$i++) {
			//debug("Test");
			//debug($alleitems[$i]);
			foreach ($alleitems[$i] as $art => $name) {
				//debug("Item Art = ".$items[$art]);
				if ($items[$art]<$i) {
					rawoutput("<tr align='center' class='".($i%2==1?"trlight":"trdark")."'><td>");	// f�r eine ordentliche abwechselnde Ausgabe m��te man erst ein "Ergebnisarray" erstellen und das dann einfach nur ausgeben
					output_notl("`&%s</td><td>`^%s `7Gold, `5%s `7Edelsteine</td><td>", $name, $goldcost*$i, $gemcost *$i, true);
					output_notl("<a href=\"".$from."op=buy&art=$art&key=".$i."\">[ $buy ]</a>", true);
					addnav("",$from."op=buy&art=$art&key=".$i);
					rawoutput("</td></tr>");
				}
			}
		}
		rawoutput("</table>");
		addnav("Verlassen");
		addnav("Zur�ck zum Platz der V�lker", "runmodule.php?module=wettkampf");
	
	}elseif ($op=="buy") {
		$art = httpget('art');
		$key = httpget('key');
		$preis = $goldcost * $key;
		
		if ($preis<=$session['user']['gold']) {
			output("Herzlichen Gl�ckwunsch zu diesem Kauf!`n`nDu bist nun stolzer Besitzer von %s.", $alleitems[$key][$art]);
			
			set_module_pref($art, $key);
			
			$session['user']['gold'] -= $preis;
			addnav("Mehr kaufen", $from);
			addnav("Verlassen");
			addnav("Zur�ck zum Platz der V�lker", "runmodule.php?module=wettkampf");
		} else {
			output("Du hast nicht genug genug Gold dabei, willst du dir etwas anderes aussuchen?");
			addnav("Anderes aussuchen", $from);
			addnav("Verlassen");
			addnav("Zur�ck zum Platz der V�lker", "runmodule.php?module=wettkampf");
		}
		
	}
	page_footer();
}
?>