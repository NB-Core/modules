<?php
$args[$spec] = "specialtywaffenmeister";
?>
