<?php
$args[$spec] = $ccode;
?>
