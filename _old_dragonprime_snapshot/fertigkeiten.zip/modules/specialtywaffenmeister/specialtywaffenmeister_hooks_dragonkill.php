<?php
set_module_pref("uses", 0);
		set_module_pref("skill", 0);
?>
