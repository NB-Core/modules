<?php
$args[$spec] = translate_inline($name);
?>
