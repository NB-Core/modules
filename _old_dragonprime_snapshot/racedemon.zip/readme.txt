Race - Demon

Version 2.03
Written by RPGSL
Download: http://rpgsl.com/lotgd/racedemon.zip
Mirror: http://rpdragon.com/lotgd/racedemon.zip

Game: http://rpdragon.com/


Installation
 
1) Copy racedemon.php into your LotGD modules folder
2) Log in to LotGD with your admin account
4) Enter the Superuser Grotto
5) Click Manage Modules
6) Install racedemon.php (Race - Demon)
7) Configure settings and save
8) Activate


Questions/Comments?

alex@rpgsl.com


Visit www.rpgsl.com today for your RPG needs.