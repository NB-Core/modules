<?php
function stonesgame_getmoduleinfo(){
	$info = array(
		"name"=>"Stones",
		"version"=>"2.0",
		"author"=>"`#Lonny Luberts",
		"category"=>"PQcomp",
		"download"=>"http://www.pqcomp.com/modules/mydownloads/visit.php?cid=3&lid=18",
		"vertxtloc"=>"http://www.pqcomp.com/",
	);
	return $info;
}

function stonesgame_install(){
	if (is_module_active('pqcasino')){
	if (!is_module_active('stonesgame')){
		output("`4Installing Stones Module.`n");
	}else{
		output("`4Updating Stones Module.`n");
	}
	module_addhook("pqcasino");
	}else{
		output("`4Casino Module Not Installed NOT Hooking!`n");
	}
	return true;
}

function stonesgame_uninstall(){
	output("`4Un-Installing Stones Module.`n");
	return true;
}

function stonesgame_dohook($hookname,$args){
	addnav("Stones","runmodule.php?module=stonesgame");
	return $args;
}

function stonesgame_run(){
	global $SCRIPT_NAME;
	if ($SCRIPT_NAME == "runmodule.php"){
		$module=httpget("module");
		if ($module == "stonesgame"){
			include("modules/lib/stonesgame.php");
		}
	}
}
?>