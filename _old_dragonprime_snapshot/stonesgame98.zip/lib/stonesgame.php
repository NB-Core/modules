<?php
global $session;
$op = httpget('op');
page_header("Casino");
output("`c`b`&Stones`0`b`c`n`n");
if ($op == ""){
	output("`2You step up the the Stones table, there is an old woman here with a bag of stones.`n");
	output("The old Woman deals only in Gems.`n");
	output("She stares at you not saying a word.`n");
	output("She will dispense 3 stones from her bag, winnings are as follows.`n");
	output("<IMG SRC=\"images/stone1.gif\"><IMG SRC=\"images/stone1.gif\"> = 1 Gem.`n",true);
	output("<IMG SRC=\"images/stone2.gif\"><IMG SRC=\"images/stone2.gif\"> = 2 Gems.`n",true);
	output("<IMG SRC=\"images/stone1.gif\"><IMG SRC=\"images/stone1.gif\"><IMG SRC=\"images/stone1.gif\"> = 4 Gems.`n",true);
	output("<IMG SRC=\"images/stone2.gif\"><IMG SRC=\"images/stone2.gif\"><IMG SRC=\"images/stone2.gif\"> = 8 Gems.`n",true);
	addnav("Bet a Gem","runmodule.php?module=stonesgame&op=play");
}
if ($op == "play"){
	if ($session['user']['gems'] > 0){
	output("`2You toss your gem on the table and the old woman procedes to drop stones from her bag.`n");
	$session['user']['gems']-=1;
	$stoneone=e_rand(1,3000);
	$stonetwo=e_rand(1,4000);
	$stonethr=e_rand(1,5000);
	$stoneone=round($stoneone/1000);
	$stonetwo=round($stonetwo/1000);
	if ($stonetwo == 4) $stonetwo = 3;
	$stonethr=round($stonethr/1000);
	if ($stonethr > 3) $stonethr = 3;
	if ($stoneone == 0) $stoneone = 3;
	if ($stonetwo == 0) $stonetwo = 3;
	if ($stonethr == 0) $stonethr = 3;
	output("<IMG SRC=\"images/stone".$stoneone.".gif\"><IMG SRC=\"images/stone".$stonetwo.".gif\"><IMG SRC=\"images/stone".$stonethr.".gif\">`n",true);
	if ($stoneone == 3) $stoneone = 0;
	if ($stonetwo == 3) $stonetwo = 0;
	if ($stonethr == 3) $stonethr = 0;
	if ($stoneone == 2) $stoneone = 5;
	if ($stonetwo == 2) $stonetwo = 5;
	if ($stonethr == 2) $stonethr = 5;
	$stonetotal=($stoneone+$stonetwo+$stonethr);
	if ($stonetotal == 2 or $stonetotal == 7){
		//push
		$session['user']['gems']+=1;
		output("`2Without saying a word the old woman pushes your gem back to you, which you quickly snatch and place in your pouch.`n");
	}elseif ($stonetotal == 10 or $stonetotal == 11){
		//double
		$session['user']['gems']+=2;
		output("`2Without saying a word the old woman tosses 2 gems on the table, which you quickly snatch and place in your pouch.`n");
	}elseif ($stonetotal == 3 or $stonetotal == 8){
		//triple
		$session['user']['gems']+=4;
		output("`2Without saying a word the old woman tosses 4 gems on the table, which you quickly snatch and place in your pouch.`n");
	}elseif ($stonetotal == 15 or $stonetotal == 16){
		//quad
		$session['user']['gems']+=8;
		output("`2Without saying a word the old woman tosses 8 gems on the table, which you quickly snatch and place in your pouch.`n");
	}else{
		output("`2The old woman pockets your gem and looks at you expectantly.`n");
	}
	addnav("Bet again","runmodule.php?module=stonesgame&op=play");
	}else{
		output("You don't have any gems to bet!`n");
	}
}
addnav("Play Something Else","runmodule.php?module=pqcasino");
//I cannot make you keep this line here but would appreciate it left in.
rawoutput("<div style=\"text-align: left;\"><a href=\"http://www.pqcomp.com\" target=\"_blank\">Stones by Lonny @ http://www.pqcomp.com</a><br>");
page_footer();
?>