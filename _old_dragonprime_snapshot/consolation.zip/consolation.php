<?php

// this is a module that should offer a consolation prize
// to players that have exactly 99 favor with ramius

// credit goes to atrus    for feedback and minor text improvements
// credit goes to jt traub for feedback and final touches

function consolation_getmoduleinfo()
{
	$info = array(
		"name"=>"Consolation Prize",
		"category"=>"Graveyard",
		"author"=>"dying",
		"version"=>"0.1",
		"download"=>"http://www.dragonprime.net/users/dying",
		"settings"=>array(
			"Consolation Prize Settings, title",
			"tormentsgiven"=>"Number of torments player is given after being awarded with the consolation prize,range,1,50,1|10"
		)
	);
	return $info;
}

function consolation_install()
{
	module_addhook("ramiusfavors");

	return true;
}

function consolation_uninstall()
{
	return true;
}

function consolation_dohook($hookname, $args)
{
	global $session;

	switch ($hookname) {
	case "ramiusfavors":
		if (($session['user']['deathpower']==99) && ($session['user']['gravefights']==0)) {
			addnav("Ramius Favors");
			addnav("Ask for a Consolation Prize", "runmodule.php?module=consolation");
		}
		break;
	}
	return $args;
}

function consolation_run()
{
	global $session;

	page_header("Consolation Prize");

	output("`)Frustrated with your inability to amass a mere 100 favor with all the chances you had to torment the creatures of the graveyard, you ask `\$Ramius`) for a consolation prize.`n`n");

	output("`\$Ramius`)' face hardens as he examines your worthless soul.");
	output("His icy stare runs shivers over your body as you become painfully aware of the sheer boldness of your request.");
	output("Indeed, with your inexcusable ineptitude, you should have considered yourself lucky that `\$Ramius`) even granted you an audience.`n`n");

	output("`)After a long pause, `\$Ramius`) takes in a deep breath, and mutters his decision.");
	output("\"`7Alright, you pathetic fool, a consolation prize I shall grant you.");
	output("However, know that, after this, you shall have no more favor with me.`)\"`n`n");

	output("`)You wait in eager anticipation as `\$Ramius`) reaches deep into his midnight cloak and pulls out a little stuffed bunny with pristine white fur.");
	output("He tosses the plushie to you nonchalantly, and with a stern tone in his rumbling voice, he commands you to leave his presence.`n`n");

	output("`)Feeling uplifted with the awarding of your new prize, you contentedly walk back into the dreary graveyard, your new stuffed bunny wrapped in your arms.");
	output("As you are too tired to feel like doing anything else, you wander towards the nearest tombstone and curl yourself behind it.");
	output("After giving your new little bunny a gentle pat on the head, you quickly fall asleep.`n`n");

	output("`)Hours later, as you wake up happy and refreshed, you find yourself surrounded by a group of young forlorn faces.");
	output("Apparently, the poor spirits of the dead children of the graveyard discovered your newfound toy while you were asleep, and their expressions are making it clear that your consolation prize is something they greatly desire to have.`n`n");

	output("`)Taking pity on the unfortunate souls, you hand over your stuffed bunny to the children, and their faces all light up in joy and appreciation of your generosity.");
	output("Watching the children run away with their new plaything, you smile in empathy.`n`n");

	output("`)As you turn to head back to tormenting the creatures of the graveyard, you catch sight of `\$Ramius`), who was apparently watching you as he was making his rounds.");
	output("Although he quickly turns away, you feel certain that you caught a glimpse of what may have been a rare smile, if but only for an instant.");

	addnav("Continue", "graveyard.php");

	debuglog("`&is awarded a consolation prize by `\$Ramius`&.");

	$session['user']['deathpower'] = 0;
	$session['user']['gravefights'] = get_module_setting("tormentsgiven");
	$session['user']['soulpoints'] = 5 * $session['user']['level'] + 50;

	page_footer();
}

?>
