-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
Speciality - Barbarian - A module for Legend of the Green Dragon 1.0.3

Legend of the Green Dragon
by  Eric "MightyE" Stevens (http://www.mightye.org)
and JT "Kendaer" Traub (http://www.dragoncat.net)

Software Project Page:
http://sourceforge.net/projects/lotgd

Modification Community Page:
http://dragonprime.net

Author of this Module:
Enderandrew (enderandrew@gmail.com)

Enderandrew's LoGD game:
http://enderandrew.com/lotgd/

Download the latest version of this module from:
http://dragonprime.net/index.php?action=viewfiles&user=enderwiggin

----------------------------------------------
-- STATUS: -----------------------------------
----------------------------------------------
This module is STABLE.

----------------------------------------------
-- INFORMATION: ------------------------------
----------------------------------------------
This is part of a series of specialties I'm making to recreate the core D&D classes in LoGD.
This also works well as a basic drop-in specialty because the core specialties are basically
a thief, and two magic users.  The game could use a few basic fighter-types, IMO.

It should be noted that the buffs in this particular specialty are just a tad weaker than in
other specialties I've seen.  I've offset that with a fairly significant advantage.  At each
level-up (each time you beat your master), Barbarians receive one bonus max-hitpoint.  You
don't get uber-powerful buffs when you use your points, but you're a little more resilient all
of the time.  Is it perfectly balanced?  That's a matter of opinion, and only extensive play-
testing will really say.

This module requires version 1.0.3 or later of LotGD.

----------------------------------------------
-- INSTALLATION: -----------------------------
----------------------------------------------
Copy specialtybarbarian.php within this zip into your modules directory.

Login to the Superuser Grotto and Install / Activate it.

-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-