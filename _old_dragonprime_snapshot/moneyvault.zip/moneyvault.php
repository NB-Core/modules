<?php
function moneyvault_getmoduleinfo(){
	$info = array(
		"name"=>"Money Vault",
		"author"=>"`%kickme`0`nIdea by Stick",
		"category"=>"Bank",
		"version"=>"1.1.0",
		"vertxtloc"=>"http://simon.geek.nz/",
		"download"=>"http://dragonprime.net/index.php?module=Downloads;sa=dlview;id=672",
		"settings"=>array(
			"Money Vault Settings,title",
			"maxgold"=>"Max amount of gold allowed in vault?,int|0",
			"maxgems"=>"Max amount of gems allowed in vault?,int|0",
			"Set to 0 to ignore,note",
			"overgold"=>"Max amount of gold user can borrow?,int|1000",
			"overgems"=>"Max amount of gems user can borrow?,int|1000",
			"Set to 0 to ignore,note",
			"gold"=>"Gold in vault,int|0",
			"gems"=>"Gems in vault,int|0",
			"hp"=>"% of HP to lose if player attempts to withdraw more gold/gems them they are allowed to?,range,0,100,1|50"
			),
		"prefs"=>array(
			"Money Vault User Preferences,title",
			"gold"=>"Gold put in vault,int|0",
			"gems"=>"Gems put in vault,int|0",
			"goldout"=>"Gold taken from the vault,int|0",
			"gemsout"=>"Gems taken from the vault,int|0"
			)
	);
	return $info;
}
function moneyvault_install(){
	module_addhook("footer-bank");
	return true;
}
function moneyvault_dohook($where,$args){
	$op = httpget(op);
	switch($where){
		case "footer-bank":
			$op = httpget("op");
			if(!$op) output("`n`nAlong a wall you see a giant vault`n");
			$gold = get_module_setting("gold");
			$gems = get_module_setting("gems");
			if(!$op) output("A sign next to the vault says that there is `^%s gold`0 and `%%s %s`0 in the vault.",$gold,$gems,translate_inline(($gems==1)?"gem":"gems"));
			addnav("Giant vault","runmodule.php?module=moneyvault");
			break;
	}
	return $args;
}
function moneyvault_run(){
	global $session;
	page_header("The Giant Vault");
	$op = httpget(op);
	$gold = get_module_setting("gold");
	$gems = get_module_setting("gems");
	$overgold = get_module_setting("overgold");
	$overgems = get_module_setting("overgems");
	if($overgold != 0) $allowedgold = get_module_pref("gold") + $overgold - get_module_pref("goldout");
	else $allowedgold = $gold;
	if($overgems != 0) $allowedgems = get_module_pref("gems") + $overgems - get_module_pref("gemsout");
	else $allowedgems = $gems;
	if($allowedgold > $gold) $allowedgold = $gold;
	if($allowedgems > $gems) $allowedgems = $gems;
	if($gold == 0) $goldm = "no";
	elseif($gold <= 100) $goldm = "a tiny amount of";
	elseif($gold > 100 && $gold <= 1000) $goldm = "an average amount of";
	else $goldm = "piles upon piles of";
	if($gems == 0) $gemsm = "no";
	elseif($gems <= 100) $gemsn = "a tiny amount of";
	elseif($gems > 100 && $gems <= 1000) $gemsm = "an average amount of";
	else $gemsm = "piles upon piles of";
	addnav("B?Ye Olde Bank","bank.php");
	addnav("Gold");
	if($allowedgold != 0 && $gold != 0) addnav("Withdraw gold","runmodule.php?module=moneyvault&op=wgold1");
	addnav("Deposit gold","runmodule.php?module=moneyvault&op=dgold1");
	addnav("Gems");
	if($allowedgems != 0 && $gems != 0) addnav("Withdraw gems","runmodule.php?module=moneyvault&op=wgems1");
	addnav("Deposit gems","runmodule.php?module=moneyvault&op=dgems1");
	if(!$op) {
		output("You walk into the vault and see %s `^gold`0 and %s `%gems`0 stacked around the walls.`n",$goldm,$gemsm);
		output("A counter of jet black marble stops you from getting at the gold and gems.`n");
		output("Behind the counter, sits a tall man, wielding two deadly looking contraptions. He introduces himself as `%kickme`0 and warns you not to try stealing, or`$ death`0 will be swift.");
		output("`n`nYou have put `^%s gold`0 and `%%s %s`0 into the vault.",get_module_pref("gold"),get_module_pref("gems"),translate_inline((get_module_pref("gems")==1)?"gem":"gems"));
		output("`nYou are `^%s gold`0 and `%%s %s`0 in debt to the vault.",get_module_pref("goldout"),get_module_pref("gemsout"),translate_inline((get_module_pref("gems")==1)?"gem":"gems"));
		output("`nYou are allowed to take out `^%s gold`0 and `%%s %s`0.",$allowedgold,$allowedgems,translate_inline(($allowedgems==1)?"gem":"gems"));
		output("`nThere is `^%s gold`0 and `%%s %s`0 in the vault.",$gold,$gems,translate_inline(($gems==1)?"gem":"gems"));
	}elseif($op=="wgold1"){
		output("You tell `%kickme`0 that you want to withdraw some gold.");
		output("He informs you that you can withdraw `^%s gold`0.",$allowedgold);
		rawoutput("<form action='runmodule.php?op=wgold2&module=moneyvault' method='POST'>");
// 		Copied from bank.php
		output("`6\"`4How much would you like to withdraw `&%s`4?`6\" `%kickme`0 asks`n`n",$session['user']['name']);
		rawoutput("<input id='input' name='amount' width=5 > <input type='submit' class='button' value='Withdraw'>");
		output("`n`iEnter 0 or nothing to withdraw all you can`i");
		rawoutput("</form>");
		rawoutput("<script language='javascript'>document.getElementById('input').focus();</script>");
		addnav("","runmodule.php?op=wgold2&module=moneyvault");
//		end copy
	}elseif($op=="wgold2"){
		$amount = httppost("amount");
		if($amount == 0 || !$amount) $amount = $allowedgold;
		output("`%kickme`0 listens to your request for `^%s gold`0.`n",$amount);
		if($amount < 0){
			output("`%kickme`0 cracks up laughing, `6\"`4You want to withdraw a negative amount??? You're crazy");
		}
		elseif($amount > $allowedgold) {
			$gold2 = $session['user']['gold'];
			output("`6\"`4Do you think I'm stupid???");
			$hp = get_module_setting("hp");
			$lose = round($session['user']['maxhitpoints'] * $hp / 100);
			$session['user']['hitpoints'] -= $lose;
			blocknav("runmodule.php?module=moneyvault&op=wgold1");
			blocknav("runmodule.php?module=moneyvault&op=dgold1");
			blocknav("runmodule.php?module=moneyvault&op=wgems1");
			blocknav("runmodule.php?module=moneyvault&op=dgems1");
			$gender = ($session['user']['sex']==1)?"hers":"his";
			if($session['user']['hitpoints'] <= 0) {
				$session['user']['hitpoints'] = 0;
				$session['user']['alive'] = false;
				output("`6\"`0 `%kickme`0 points one of his contractions at you.`n");
				output("You hear a small *puff*`n");
				output("You have died!");
				output("Your gold was added to the vault.");
				$gold += $gold2;
				set_module_setting("gold",$gold);
				$session['user']['gold'] = 0;
				addnews("%s was killed when trying to borrow money that wasn't %s!!",$session['user']['name'],$gender);
				addnav("You're Dead");
				addnav("To the Shades","shades.php");
				blocknav("bank.php");
			}else{
				if($lose == 0){
					output("You're lucky I'm such a nice guy or you'll be dead.`6\"`0");
				}else{
					output("`%kickme`0 points one of his contractions at you.`n");
					output("You hear a small *puff*`n");
					output("You feel a searing pain in your leg!");
					output("`n`nYou`$ lose`0 %s hitpoints",$lose);
					addnews("%s was seen limping from the bank with a hole in %s leg!",$session['user']['name'],$gender);
				}
			}
		}else{
			output("`%kickme`0 walks over to the gold at the back of the vault and counts out `^%s gold`0.",$amount);
			output("He hands you `^%s gold`0",$amount);
			$session['user']['gold'] += $amount;
			set_module_setting("gold",$gold-$amount);
			if(get_module_pref("gold") == 0) increment_module_pref("goldout",$amount);
			else{
				$gold2 = get_module_pref("gold");
				if($amount > $gold2) {
					set_module_pref("gold",0);
					$amount -= $gold2;
					increment_module_pref("goldout",$amount);
				}else set_module_pref("gold",$gold2-$amount);
			}
		}
	}elseif($op == "dgold1"){
		output("`%kickme`0 tells you that there is %s gold currently in the vault.",$gold);
		output("`nSearching through all your pockets and pouches, you calculate that you currently have `^%s gold`0 on hand.",$session['user']['gold']);
		rawoutput("<form action='runmodule.php?op=dgold2&module=moneyvault' method='POST'>");
// 		Copied from bank.php
		output("`n`6\"`4How much would you like to deposit `&%s`4?`6\" `%kickme`0 asks`n`n",$session['user']['name']);
		rawoutput("<input id='input' name='amount' width=5 > <input type='submit' class='button' value='Deposit'>");
		output("`n`iEnter 0 or nothing to deposit it all`i");
		rawoutput("</form>");
		rawoutput("<script language='javascript'>document.getElementById('input').focus();</script>");
		addnav("","runmodule.php?op=dgold2&module=moneyvault");
//		end copy
	}elseif($op == "dgold2"){
		$amount = httppost("amount");
		if($gold+$amount > get_module_setting("maxgold") && get_module_setting("maxgold") != 0) $amount -= (get_module_setting("maxgold") - $gold); 
		if($amount == 0 || !$amount) $amount = $session['user']['gold'];
		if($amount > $session['user']['gold']) $amount = $session['user']['gold'];
		$session['user']['gold'] -= $amount;
		increment_module_setting("gold",$amount);
		if($amount < 0){
			output("`%kickme`0 cracks up laughing, `6\"`4You want to deposit a negative amount??? You're crazy");
		}else{
			output("`%kickme`0 notes your deposit of `^%s gold`0 in his ledger.",$amount);
			if(get_module_pref("goldout") == 0)	increment_module_pref("gold",$amount);
			elseif($amount > get_module_pref("goldout")){
				$amount -= get_module_pref("goldout");
				set_module_pref("goldout",0);
				increment_module_pref("gold",$amount);
			}else set_module_pref("goldout",get_module_pref("goldout")-$amount);
			output("`n`nYou have put a total of `^%s gold`0 into the vault.",get_module_pref("gold"));
			output("`nYou have a debt of `^%s gold`0.",get_module_pref("goldout"));
			output("`nYou have `^%s gold`0 in hand.",$session['user']['gold']);
			output("`nThere is now `^%s gold`0 in the vault",get_module_setting("gold"));
		}
	}elseif($op=="wgems1"){
		output("You tell `%kickme`0 that you want to withdraw some gems.");
		output("He informs you that you can withdraw `%%s %s`0.",$allowedgems,translate_inline(($gems==1)?"gem":"gems"));
		rawoutput("<form action='runmodule.php?op=wgems2&module=moneyvault' method='POST'>");
// 		Copied from bank.php
		output("`6\"`4How much would you like to withdraw `&%s`4?`6\" `%kickme`0 asks`n`n",$session['user']['name']);
		rawoutput("<input id='input' name='amount' width=5 > <input type='submit' class='button' value='Withdraw'>");
		output("`n`iEnter 0 or nothing to withdraw all you can`i");
		rawoutput("</form>");
		rawoutput("<script language='javascript'>document.getElementById('input').focus();</script>");
		addnav("","runmodule.php?op=wgems2&module=moneyvault");
//		end copy
	}elseif($op=="wgems2"){
		$amount = httppost("amount");
		if($amount == 0 || !$amount) $amount = $allowedgems;
		output("`%kickme`0 listens to your request for `%%s %s`0.`n",$amount,translate_inline(($amount==1)?"gem":"gems"));
		if($amount < 0){
			output("`%kickme`0 cracks up laughing, `6\"`4You want to deposit a negative amount??? You're crazy");
		}elseif($amount > $allowedgems) {
			$gems2 = $session['user']['gems'];
			output("`6\"`4Do you think I'm stupid???");
			$hp = get_module_setting("hp");
			$lose = round($session['user']['maxhitpoints'] * $hp / 100);
			$session['user']['hitpoints'] -= $lose;
			blocknav("runmodule.php?module=moneyvault&op=wgold1");
			blocknav("runmodule.php?module=moneyvault&op=dgold1");
			blocknav("runmodule.php?module=moneyvault&op=wgems1");
			blocknav("runmodule.php?module=moneyvault&op=dgems1");
			$gender = ($session['user']['sex']==1)?"hers":"his";
			if($session['user']['hitpoints'] <= 0) {
				$session['user']['hitpoints'] = 0;
				$session['user']['alive'] = false;
				output("`%kickme`0 points one of his contractions at you.`n");
				output("You hear a small *puff*`n");
				output("You have died!");
				output("Your %s was added to the vault.",translate_inline(($session['user']['gems']==1)?"gem":"gems"));
				$gems += $gems2;
				set_module_setting("gems",$gems);
				$session['user']['gems'] = 0;
				addnews("%s was killed when trying to borrow gems that weren't %s!!",$session['user']['name'],$gender);
				addnav("You're Dead");
				addnav("To the Shades","shades.php");
				blocknav("bank.php");
			}else{
				if($lose == 0){
					output("You're lucky I'm such a nice guy or you'll be dead.`6\"`0");
				}else{
					output("`%kickme`0 points one of his contractions at you.`n");
					output("You hear a small *puff*`n");
					output("You feel a searing pain in your leg!");
					output("`n`nYou`$ lose`0 %s hitpoints",$lose);
					addnews("%s was seen limping from the bank with a hole in %s leg!",$session['user']['name'],$gender);
				}
			}
		}else{
			output("`%kickme`0 walks over to the gems at the back of the vault and counts out `%%s %s`0.",$amount,translate_inline(($amount==1)?"gem":"gems"));
			output("He hands you `%%s %s`0",$amount,translate_inline(($amount==1)?"gem":"gems"));
			$session['user']['gems'] += $amount;
			set_module_setting("gems",$gems-$amount);
			if(get_module_pref("gems") == 0) increment_module_pref("gemsout",$amount);
			else{
				$gems2 = get_module_pref("gems");
				if($amount > $gems2) {
					set_module_pref("gems",0);
					$amount -= $gems2;
					increment_module_pref("gemsout",$amount);
				}else set_module_pref("gems",$gems2-$amount);
			}
		}
	}elseif($op == "dgems1"){
		output("`%kickme`0 tells you that there is %s %s currently in the vault.",$gems,translate_inline(($gems==1)?"gem":"gems"));
		output("`nSearching through all your pockets and pouches, you calculate that you currently have `%%s %s`0 on hand.",$session['user']['gems'],translate_inline(($session['user']['gems']==1)?"gem":"gems"));
		rawoutput("<form action='runmodule.php?op=dgems2&module=moneyvault' method='POST'>");
// 		Copied from bank.php
		output("`n`6\"`4How much would you like to deposit `&%s`4?`6\" `%kickme`0 asks`n`n",$session['user']['name']);
		rawoutput("<input id='input' name='amount' width=5 > <input type='submit' class='button' value='Deposit'>");
		output("`n`iEnter 0 or nothing to deposit it all`i");
		rawoutput("</form>");
		rawoutput("<script language='javascript'>document.getElementById('input').focus();</script>");
		addnav("","runmodule.php?op=dgems2&module=moneyvault");
//		end copy
	}elseif($op == "dgems2"){
		$amount = httppost("amount");
		if($amount < 0){
			output("`%kickme`0 cracks up laughing, `6\"`4You want to deposit a negative amount??? You're crazy");
		}else{
			if($gems+$amount > get_module_setting("maxgems") && get_module_setting("maxgems") != 0) $amount -= (get_module_setting("maxgems") - $gems); 
			if($amount == 0 || !$amount) $amount = $session['user']['gems'];
			if($amount > $session['user']['gems']) $amount = $session['user']['gems'];
			$session['user']['gems'] -= $amount;
			increment_module_setting("gems",$amount);
			output("`%kickme`0 notes your deposit of `%%s %s`0 in his ledger.",$amount,translate_inline(($amount==1)?"gem":"gems"));
			if(get_module_pref("gemsout") == 0)	increment_module_pref("gems",$amount);
			elseif($amount > get_module_pref("gemsout")){
				$amount -= get_module_pref("gemsout");
				set_module_pref("gemsout",0);
				increment_module_pref("gems",$amount);
			}else set_module_pref("gemsout",get_module_pref("gemsout")-$amount);
			output("`n`nYou have put a total of `%%s %s`0 into the vault.",get_module_pref("gems"),translate_inline((get_module_pref("gems")==1)?"gem":"gems"));
			output("`nYou have a debt of `%%s %s`0.",get_module_pref("gemsout"),translate_inline((get_module_pref("gemsout")==1)?"gem":"gems"));
			output("`nYou have `%%s %s`0 in hand.",$session['user']['gems'],translate_inline(($session['user']['gems']==1)?"gem":"gems"));
			output("`nThere is now `%%s %s`0 in the vault",get_module_setting("gems"),translate_inline((get_module_setting("gems")==1)?"gem":"gems"));
		}
	}
	page_footer();
}
?>