<?php

//1.10 Improved fail-safe to never allow players to fall below level*10 hitpoints
//1.11 The newday counter was missing two vital lines of code. I must have been drunk...
//1.12 Code cleanup by Maeher

require_once("common.php");
require_once("lib/http.php");

function cirrhosis_getmoduleinfo(){
	$info = array(
		"name"=>"Liver Cirrhosis",
		"version"=>"1.12",
		"author"=>"SexyCook",
		"category"=>"General",
		"download"=>"http://www.carloscm.de/prog/lotgd/cirrhosis.zip",
		"settings"=>array(
			"Cirrhosis Settings,title",
			"getcirrhosis"=>"Minimum amount of drinking to get liver cirrhosis,int|1000",
			"Pick a value that allows players to get wasted for a couple of days,note",
			"randomcirr"=>"Probability someone will get cirrhosis on a new day after reaching minimum amount,range,0,100,10|50",
			"selfheal"=>"By how much will the liver repair itself?,int|25",
			"This is pretty much a value for an acceptable daily wine glas,note",
			"minmaxhp"=>"What is the multiplicator for the amount of max HPs under which a donor will be found on a new day,int|10",
			"formula = (level * X) + (dragonkills * 5),note",
			"goldcost"=>"What is the price of a new liver by Louis (gold * player level),int|1000",
			"gemcost"=>"What is the price of a new liver by Louis (gems * player level),int|2",
		),
		"prefs"=>array(
			"cirrhosis"=>"Counter for cirrhosis,int|0",
			"suffered"=>"Has the player started suffering from cirrhosis?,bool|0",
			"3 states: 0 means no - 1 means yes - 2 means the player just caught it,note",
			"metlouis"=>"Has the player met Louis the gangster today,bool|0",
		),
		"requires"=>array(
			"drinks" => "1.1|by John J. Collins, heavily modified by JT Traub",
		),
	);
	return $info;
}

function cirrhosis_install(){
	module_addhook_priority("newday",1);
	module_addhook("forest");
	return true;
}

function cirrhosis_uninstall(){
	return true;
}

function cirrhosis_dohook($hookname,$args){
	global $session;
	
	switch($hookname){
		case "newday":
			if(get_module_pref("metlouis")==1)
				set_module_pref("metlouis",0);
			$newcirr = get_module_pref("drunkeness","drinks") - get_module_setting("selfheal");
			if($newcirr > 0){
				$newcirr+=get_module_pref("cirrhosis");
				set_module_pref("cirrhosis",$newcirr);
				debug("cirrhosis: ".get_module_pref("cirrhosis"));
			}
			
			if(!get_module_pref("suffered")){
				if(get_module_pref("cirrhosis") >= get_module_setting("getcirrhosis") && e_rand(0,100) < get_module_setting("randomcirr")){
					output("`n`n`4You wake up to heavy pains in your lower abdomen. You can barely take it and lose one permanent hitpoint");
					output("Oh, dreaded youth, when you thought you could drink anything in the world, with or without salt or worms!!!");
					output("The only cure for you is to find a liver donor. But will you find one in time?");
					if($session['user']['maxhitpoints'] > $session['user']['level']*10){
						$session['user']['maxhitpoints']--;
						$session['user']['hitpoints']=$session['user']['maxhitpoints'];
					}
					set_module_pref("suffered",1);
				}
			}else{
				output("`4`nYou are still in severe pain. Find a donor quickly!");
				output("`n`nYou lose 1 permanent hitpoint.`n");
				if($session['user']['maxhitpoints'] > $session['user']['level']*10){
					$session['user']['maxhitpoints']--;
					$session['user']['hitpoints']=$session['user']['maxhitpoints'];
				}
				if($session['user']['maxhitpoints']<=($session['user']['level']*get_module_setting("minmaxhp"))+($session['user']['dragonkills']*5)){
					output("`nA liver donor has been found. You stay a whole day in surgery and rehab.`n");
					$session['user']['turns']=0;
					set_module_pref("cirrhosis",0);
					set_module_pref("suffered",0);
				}
			}
			break;
		
		case "forest":
			if(get_module_pref("suffered") == 1 && get_module_pref("metlouis")==0){
				$goldcost=get_module_setting("goldcost")*$session['user']['level'];
				$gemcost=get_module_setting("gemcost")*$session['user']['level'];
				output("`7`nUnder a the shadow of a nearby tree you spot Louis, a rather suspicious man in a black suit, dark glasses and a pony tail haircut. He might help you find a donor, as long as you don't ask too many questions about it's origin and if the donor was really willing to give up the organ.");
				output("`n`nHe usually charges %s gold and %s gems for an organ. You might want to pick up that kind of cash before you talk to him.`n",$goldcost,$gemcost);
				addnav("`7Talk to Louis, the gangster","runmodule.php?module=cirrhosis&op=talk");
			}
			break;
	}
	return $args;
}

function cirrhosis_run(){
	global $session;
	$op = httpget("op");
	$type = httpget("type");
	
	page_header("Louis the gangster");
	switch($op){
		case "talk":
			set_module_pref("metlouis",1);
			$nresult=e_rand(1,5);
			switch($nresult){
				case 1:
					$goldcost=get_module_setting("goldcost")*$session['user']['level'];
					$gemcost=get_module_setting("gemcost")*$session['user']['level'];
					output("`2Louis the gangster greets you with a smile on his face. 'Boy are you lucky' he says 'I just managed to get my fingers in a fresh liver'. He points to a box filled with ice, under which something pinkish seems to waiting for a new body.");
					output("`2`n`n'Buddy, this is a one time offer, the person who was waiting for this met... with an unfortunate accident. If you have %s gold and %s gems here and now, I'll not only let you have it, but will implant it at my own cost. So, what do you say?'",$goldcost,$gemcost);
					if($session['user']['gold']>=$goldcost && $session['user']['gems']>=$gemcost)
						addnav("Take the liver!","runmodule.php?module=cirrhosis&op=operate&type=1");
					else
						output("You don't have that kind of cash with you.");
					break;
				case 2:
					$goldcost=round(get_module_setting("goldcost")*$session['user']['level']*1.3);
					$gemcost=round(get_module_setting("gemcost")*$session['user']['level']*1.3);
					output("`2Louis the gangster greets you as you approach. 'Hia there, mate' he says 'I do have a fresh liver with me'. He points to a box filled with ice, under which something pinkish seems to waiting for a new body.");
					output("`2`n`n'Unfortunatly for you, getting a liver implanted seems to be the newest fad and the waiting list is two miles long. I could let you have this one, but it will cost you. If you have %s gold and %s gems here and now, which includes operation, I'll be kind and let you have it, as you actzally seem to need it. So, what do you say?'",$goldcost,$gemcost);
					if($session['user']['gold']>=$goldcost && $session['user']['gems']>=$gemcost)
						addnav("Take the liver!","runmodule.php?module=cirrhosis&op=operate&type=2");
					else
						output("You don't have that kind of cash with you.");
					break;
				case 3:
					$goldcost=round(get_module_setting("goldcost")*$session['user']['level']*0.6);
					$gemcost=round(get_module_setting("gemcost")*$session['user']['level']*0.6);
					output("`2Louis the gangster greets you with a smile on his lips and a desperate look on his face. 'Boy, am I lucky to find you here' he says 'I managed to get my hands on a liver a while ago, but now nobody wants it anymore'. He points to a box only half-filled with ice, under which something pinkish slowly rottens.");
					output("`2`n`n'I have to get rid of it, so I'm prepared to give you a sweet deal. If you have %s gold and %s gems here and now, I'll not only let you have it, but will implant it at my own cost. So, what do you say?'",$goldcost,$gemcost);
					if($session['user']['gold']>=$goldcost && $session['user']['gems']>=$gemcost)
						addnav("Take the liver!","runmodule.php?module=cirrhosis&op=operate&type=3");
					else
						output("You don't have that kind of cash with you.");
					break;
				case 4:
					output("`2Louis the gangster greets you from afar. 'Sorry mate, you're having bad luck' he says 'I just sold my last liver for today'. He points to an empty box in which some ice cubes slowly melt in the bottom.");
					output("`2`n`n'Try again tomorrow, I might have something new and fresh then.'");
					break;
				case 5:
					output("`2Louis the gangster looks at you puzzled, than smiles. 'Hey boys, the fish are starting to jump out of the water.' he says. Before you can think about what he may mean or who he might be talking to, a cloth covers your mouth and you breath the sweet smell of chloroform for a couple of seconds, before you pass away.");
					output("`2During your troubled sleep you seem to hear the words 'Damn, this liver is no good, look at it, it's close to failure as it is!'. A while after you wake up alone in the middle of the forest, a fresh scar can be seen across your naked abdomen and new pains strike your body.");
					output("`7You lose all your gold and gems and suffer futher hitpoint reduction.");
					$session['user']['gold']=0;
					$session['user']['gems']=0;
					if($session['user']['maxhitpoints'] > $session['user']['level']*10)
						$session['user']['maxhitpoints']--;
					$session['user']['hitpoints']=1;
					break;
			}
			addnav("Back to the forest!","forest.php");
			break;
		
		case "operate":
			output("`4Louis takes you to a small secluded hut in the middle of the forest. Inside you see blood red walls, on the few windows there are red curtains, in the middle of the room is a red table dripping something you'd rather not think about, nearby lay some medical instruments, which might, at some point in the past, have been metal colored but are now red to the handle.");
			output("`n`n`4A distracted looking little man, which may be a very good butcher or a very bad surgeon, comes to greet you with a huge red cleaver in his right hand, clothed in phisician's clothes which are, interestingly enough, neither white, nor green or blue.");
			output("`n`n`2Without thinking too much about it you undress, lay on the table and wait for the sweet bliss anasthesia will bring you.`n`n");
			
			$operation=e_rand(1,10);
			switch($operation){
			case 1:
				output("When you wake up, you feel no pain. You can't actually feel anything. And you don't appear to be in the hut anymore. The mausoleum to Ramius in the distance gives you the final hint. I guess you never woke up at all.");
				$session['user']['gold']=0;
				$session['user']['gems']=0;
				$session['user']['hitpoints']=0;
				addnav("Walk to the shades","shades.php");
				break;
			default:
				output("You wake up later on to the sound of sharpering objects. You can't feel your body yet, but a smiling face comes up to you and tells you that the operation was a success. You close your eyes and sleep the rest of the day, hoping next day you'll be recovered enough to fight once more.");
				switch($type){
					case 1:
						$session['user']['gold']-=get_module_setting("goldcost")*$session['user']['level'];
						$session['user']['gems']-=get_module_setting("gemcost")*$session['user']['level'];
						break;
					case 1:
						$session['user']['gold']-=round(get_module_setting("goldcost")*$session['user']['level']*1.3);
						$session['user']['gems']-=round(get_module_setting("gemcost")*$session['user']['level']*1.3);
						break;
					case 1:
						$session['user']['gold']-=round(get_module_setting("goldcost")*$session['user']['level']*0.6);
						$session['user']['gems']-=round(get_module_setting("gemcost")*$session['user']['level']*0.6);
						break;
					}
					addnav("Back to the forest","forest.php");
					break;
			}
			$session['user']['turns']=0;   
			set_module_pref("cirrhosis",0);
			set_module_pref("suffered",0); 
			break;
	}   
	page_footer();
}
?>
