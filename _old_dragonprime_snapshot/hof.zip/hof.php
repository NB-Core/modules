<?php
require_once "common.php";
page_header("Hall of Fame");
checkday();

if ($_GET[op]=="attack"){
    $sql = "SELECT name,attack FROM accounts WHERE locked = 0 ORDER BY attack DESC";
    output("`c`b`oAttack Points`b`c`0`n");
    output("<table cellspacing=0 cellpadding=2 align='center'><tr><td>`bRank`b</td><td>`bName`b</td><td>`bAttack Points`b</tr>",true);
    $result = db_query($sql) or die(db_error(LINK));
    if (db_num_rows($result)==0){
        output("<tr><td colspan=4 align='center'>`&No players found`0</td></tr>",true);
    }
    for ($i=0;$i<db_num_rows($result) && $i<25;$i++){
        $row = db_fetch_assoc($result);
        $amt = $row[attack];
        if ($row[name]==$session[user][name]){
          output("<tr bgcolor='#007700'>",true);
        } else {
          output("<tr class='".($i%2?"trlight":"trdark")."'>",true);
        }
          output("<td>".($i+1).".</td><td>$row[name]</td><td align='right'>$amt points</td></tr>",true);
    }
    output("</table>`n(Amount +/- 5%)",true);
    addnav("(H) to Hall of Fame","hof.php");
}
else if ($_GET[op]=="defence"){
    $sql = "SELECT name,defence FROM accounts WHERE locked = 0 ORDER BY defence DESC";
    output("`c`b`oAttack Points`b`c`0`n");
    output("<table cellspacing=0 cellpadding=2 align='center'><tr><td>`bRank`b</td><td>`bName`b</td><td>`bDefence Points`b</tr>",true);
    $result = db_query($sql) or die(db_error(LINK));
    if (db_num_rows($result)==0){
        output("<tr><td colspan=4 align='center'>`&No players found`0</td></tr>",true);
    }
    for ($i=0;$i<db_num_rows($result) && $i<25;$i++){
        $row = db_fetch_assoc($result);
        $amt = $row[defence];
        if ($row[name]==$session[user][name]){
          output("<tr bgcolor='#007700'>",true);
        } else {
          output("<tr class='".($i%2?"trlight":"trdark")."'>",true);
        }
          output("<td>".($i+1).".</td><td>$row[name]</td><td align='right'>$amt points</td></tr>",true);
    }
    output("</table>`n(Amount +/- 5%)",true);
    addnav("(H) to Hall of Fame","hof.php");
} else if ($_GET[op]=="richest"){
    $sql = "SELECT name,goldinbank,gold FROM accounts WHERE locked = 0 ORDER BY goldinbank+gold DESC";
    output("`c`b`^The richest Warriors of this land`b`c`0`n");
    output("<table cellspacing=0 cellpadding=2 align='center'><tr><td>`bRank`b</td><td>`bName`b</td><td>`bEstimated Gold`b</tr>",true);
    $result = db_query($sql) or die(db_error(LINK));
    if (db_num_rows($result)==0){
        output("<tr><td colspan=4 align='center'>`&No players found`0</td></tr>",true);
    }
    for ($i=0;$i<db_num_rows($result) && $i<20;$i++){
        $row = db_fetch_assoc($result);
        $amt = $row[goldinbank]+$row[gold]+e_rand(0-round($row[goldinbank]*0.05),round($row[goldinbank]*0.05));
        if ($row[name]==$session[user][name]){
           output("<tr bgcolor='#007700'>",true);
        } else {
           output("<tr class='".($i%2?"trlight":"trdark")."'>",true);
        }
          output("<td>".($i+1).".</td><td>$row[name]</td><td align='right'>$amt gold</td></tr>",true);
    }
    output("</table>`n(Amount +/- 5%)",true);
    addnav("(H) to Hall of Fame","hof.php");
} else if ($_GET[op]=="gems"){    
    $sql = "SELECT name FROM accounts WHERE locked = 0 ORDER BY gems DESC";
    output("`n`n`c`b`#Top 10 Gem owners`b`c`0`n");
    output("<table cellspacing=0 cellpadding=2 align='center'><tr><td>`bRank`b</td><td>`bName`b</td></tr>",true);
    $result = db_query($sql) or die(db_error(LINK));
    if (db_num_rows($result)==0){
        output("<tr><td colspan=4 align='center'>`&No players found`0</td></tr>",true);
    }
    for ($i=0;$i<db_num_rows($result) && $i<10;$i++){
        $row = db_fetch_assoc($result);
        if ($row[name]==$session[user][name]){
           output("<tr bgcolor='#007700'>",true);
        } else {
           output("<tr class='".($i%2?"trlight":"trdark")."'>",true);
        }
          output("<td>".($i+1).".</td><td>$row[name]</td></tr>",true);
    }
    output("</table>",true);
    addnav("(H) to Hall of Fame","hof.php");
} else if ($_GET[op]=="poor"){
    $sql = "SELECT name,goldinbank,gold FROM accounts WHERE locked = 0 ORDER BY goldinbank+gold ASC";
    output("`c`b`^The poorest Warriors of this land`b`c`0`n");
    output("<table cellspacing=0 cellpadding=2 align='center'><tr><td>`bRank`b</td><td>`bName`b</td><td>`bEstimated Gold`b</tr>",true);
    $result = db_query($sql) or die(db_error(LINK));
    if (db_num_rows($result)==0){
        output("<tr><td colspan=4 align='center'>`&No players found`0</td></tr>",true);
    }
    for ($i=0;$i<db_num_rows($result) && $i<20;$i++){
        $tma=$amt;
        $row = db_fetch_assoc($result);
        $amt = $row[goldinbank]+$row[gold]+e_rand(0-round($row[goldinbank]*0.05),round($row[goldinbank]*0.05));
        if ($amt<0) $amt="`\$".$amt;
        if ($amt==$tma && $tma=="0") $i--;
        if ($row[name]==$session[user][name]){
           output("<tr bgcolor='#007700'>",true);
        } else {
           output("<tr class='".($i%2?"trlight":"trdark")."'>",true);
        }
          output("<td>".($i+1).".</td><td>$row[name]</td><td align='right'>$amt gold`0</td></tr>",true);
    }
    output("</table>`n(Amount +/- 5%)",true);
    addnav("(H) to Hall of Fame","hof.php");
} else if ($_GET[op]=="nice"){
    $sql = "SELECT name,sex,race FROM accounts WHERE locked = 0 ORDER BY charm DESC";
    output("`c`b`%Most beautiful Warriors`b`c`0`n");
    output("<table cellspacing=0 cellpadding=2 align='center'><tr><td>`bRank`b</td><td>`bName`b</td><td>`bGender`b</td><td>`bRace`b</td></tr>",true);
    $result = db_query($sql) or die(db_error(LINK));
    if (db_num_rows($result)==0){
        output("<tr><td colspan=4 align='center'>`&No players found`0</td></tr>",true);
    }
    for ($i=0;$i<db_num_rows($result) && $i<20;$i++){
        $row = db_fetch_assoc($result);
        if ($row[name]==$session[user][name]){
           output("<tr bgcolor='#007700'>",true);
        } else {
           output("<tr class='".($i%2?"trlight":"trdark")."'>",true);
        }
        output("<td>".($i+1).".</td><td>$row[name]</td><td align='center'>".($row[sex]?"`8Female`0":"`!Male`0")."</td><td>",true);
        switch($row['race']){
            case 0: output("`7Unknown`0"); break;
            case 1: output("`2Troll`0"); break;
            case 2: output("`^Elf`0"); break;
            case 3: output("`&Human`0"); break;
            case 4: output("`#Dwarf`0"); break;
        }
        output("</td></tr>",true);
    }
    output("</table>",true);
    addnav("(H) to Hall of Fame","hof.php");
} else if ($_GET[op]=="stark"){
    $sql = "SELECT name,level,race FROM accounts WHERE locked = 0 ORDER BY maxhitpoints DESC";
    output("`c`b`\$The strongest Warriors of this world`b`c`0`n");
    output("<table cellspacing=0 cellpadding=2 align='center'><tr><td>`bRank`b</td><td>`bName`b</td><td>`bRace`b</td><td>`bLevel`b</td></tr>",true);
    $result = db_query($sql) or die(db_error(LINK));
    if (db_num_rows($result)==0){
       output("<tr><td colspan=4 align='center'>`&No players found`0</td></tr>",true);
    }
    for ($i=0;$i<db_num_rows($result) && $i<20;$i++){
        $row = db_fetch_assoc($result);
        if ($row[name]==$session[user][name]){
           output("<tr bgcolor='#007700'>",true);
        } else {
           output("<tr class='".($i%2?"trlight":"trdark")."'>",true);
        }
          output("<td>".($i+1).".</td><td>$row[name]</td><td>",true);
        switch($row['race']){
            case 0: output("`7Unknown`0"); break;
            case 1: output("`2Troll`0"); break;
            case 2: output("`^Elf`0"); break;
            case 3: output("`&Human`0"); break;
            case 4: output("`#Dwarf`0"); break;
        }
        output("</td><td>$row[level]</td></tr>",true);
    }
    output("</table>",true);
    addnav("(H) to Hall of Fame","hof.php");
} else if ($_GET[op]=="tot"){
    $sql = "SELECT name,level FROM accounts WHERE locked = 0 ORDER BY resurrections DESC";
    output("`c`b`)The clumsiest Warriors of this land`b`c`0`n");
    output("<table cellspacing=0 cellpadding=2 align='center'><tr><td>`bRank`b</td><td>`bName`b</td><td>`bLevel`b</td></tr>",true);
    $result = db_query($sql) or die(db_error(LINK));
    if (db_num_rows($result)==0){
       output("<tr><td colspan=4 align='center'>`&No players found`0</td></tr>",true);
    }
    for ($i=0;$i<db_num_rows($result) && $i<20;$i++){
        $row = db_fetch_assoc($result);
        if ($row[name]==$session[user][name]){
           output("<tr bgcolor='#007700'>",true);
        } else {
           output("<tr class='".($i%2?"trlight":"trdark")."'>",true);
        }
          output("<td>".($i+1).".</td><td>$row[name]</td><td>$row[level]</td></tr>",true);
    }
    output("</table>",true);
    addnav("(H) to Hall of Fame","hof.php");
}else{
    $sql = "SELECT name,dragonkills,level,dragonage,bestdragonage FROM accounts WHERE dragonkills > 0 ORDER BY dragonkills DESC,level DESC,experience DESC";
    output("`c`b`&Heros of this world`b`c`n");
    output("<table cellspacing=0 cellpadding=2 align='center'><tr><td>`bRank`b</td><td>`bName`b</td><td>`bKills`b</td><td>`bLevel`b</td><td>&nbsp;</td><td>`bDays`b</td><td>&nbsp;</td><td>`bBest Days`b</td><td>&nbsp;</td><td>`bCreature Kills`b</td></tr>",true);
    $result = db_query($sql) or die(db_error(LINK));
    if (db_num_rows($result)==0){
       output("<tr><td colspan=4 align='center'>`&No heros in this world`0</td></tr>",true);
    }
    for ($i=0;$i<db_num_rows($result);$i++){
        $row = db_fetch_assoc($result);
        if ($row[name]==$session[user][name]){
           output("<tr bgcolor='#007700'>",true);
        } else {
           output("<tr class='".($i%2?"trlight":"trdark")."'>",true);
        }
          output("<td>".($i+1).".</td><td>$row[name]</td><td>$row[dragonkills]</td><td>{$row['level']}</td><td>&nbsp;</td><td>".($row[dragonage]?$row[dragonage]:"unknown")."</td><td>&nbsp;</td><td>".($row[bestdragonage]?$row[bestdragonage]:"unknown")."</td><td>&nbsp;</td><td>".($row[monsterwin]?$row[monsterwin]:"unknown")."</td></tr>",true);
    }
    output("</table>",true);
    addnav("Top 20");
    addnav("(1) Gems","hof.php?op=gems");
    addnav("(2) Richest","hof.php?op=richest");
    addnav("(3) Poorest","hof.php?op=poor");
    addnav("(4) Strongest","hof.php?op=stark");
    addnav("(5) Most beautiful","hof.php?op=nice");
    addnav("(6) Clumsiest","hof.php?op=tot");
// admin see only:
    if ($session['user']['superuser']==3){
	addnav("(K) Attack","hof.php?op=attack");
	addnav("(D) Defense","hof.php?op=defence");
    }
}
addnav("exit HoF");
addnav("(V) to the Village","village.php");
page_footer();
?>