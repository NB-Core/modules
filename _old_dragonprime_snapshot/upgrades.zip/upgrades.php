<?
require_once "common.php";

//--------------------------------------------------------------------------------------------------------
//| Written by:  Auron 
//| Version:    1.0 - 05/15/2004
//|
//| About:  Adds some upgrades to housing.... make sure you add a link to the housing
//| file.....  if ($session[user][partyroom]==1){ 
//| adddnav("Start a Party","houseu.php?op=startparty");}
//| also add a link in the village...
//| addnav("Upgrades"."houseu.php");
//|
//| Databse:
//| Add to Accounts:
//| party int 4 unsigned default 0
//| partyroom int 4 unsigned default 0
//|
//|
//--------------------------------------------------------------------------------------------------------

page_header("Upgrades");
addcommentary();
switch($HTTP_GET_VARS[op])
    {

case "":
  output("Buy Upgrades Here");
if ($session[user][partyroom]==0)
{
addnav("Buy a Partyroom","houseu.php?op=proom");
}
addnav("Return to Village","village.php");
break;

case "proom":
output("You now have a partyroom!");
$session[user][partyroom]+=1;
addnav("Back to Village","village.php");
break;

case "startparty":
$session[user][party]=1;
output("You set up your party and get ready for guests to come!`n`n`7Your party is ready for guests, just invite them into your home and they have access! Parties are cleared up on new days, and they use all your turns to start. Keep that in mind the next time you start one!");
$session[user][turns]=0;
addnav("Enter Party","houseu.php?op=partyroom");
break;


case "partyroom":

output("You enter the partyroom. You see alot of interesting things around you. You see many people gathered around a giant Keg of Ale while some are seated on couches talking with one another. You also see a pinata in the corner and many warriors taking a swing at knocking whatever is inside out. Others are dancing crazily on a small Dance Floor.`n`n");
viewcommentary("party","Talk",20);}

addnav("Hit the Pinata","houseu.php?op=pinata");
addnav("Dance","houseu.php?op=dance");
addnav("The Keg","houseu.php?op=keg");
addnav("Spin the Bottle","houseu.php?op=spinbottle");
addnav("Back to Estate","houses.php?op=inside"); 

break;

case "keg":
if ($session[user][drunkenness]>75){
                                
                                        output("`9 You have had enough there buddy!");
                                            addnav("Back to Pary","houseu.php?op=partyroom");
                                }else{
                                          $session[user][drunkenness]+=25;
                                                addnav("Back to Party","houseu.php?op=partyroom");
                                                output("You grab a glass, and pour yourself a nice frosty ale.`n  ");
                                                output("You gulp it down easily.`n`n  ");
                                                          output("`&You feel vigorous, but also a bit sober!");
                                                                $session[user][turns]++;
                                                                $session[user][hitpoints]+=round($session[user][maxhitpoints]*.1,0);
                                                $session[bufflist][101] = array("name"=>"`#Buzz","rounds"=>10,"wearoff"=>"Your buzz fades.","atkmod"=>1.25,"roundmsg"=>"You've got a nice buzz going.","activate"=>"offense");
                                                break;
                                        }


break;

case "pinata":
    output("`n`n`9You swing at the Pinata with a blindfold on, when you take your blindfold off you find....`n`n");
        $rand1 = e_rand(1,12);
        switch ($rand1){
        case 1:
            output("`9Nothing!");
            break;
        case 2:
            output("`^1 A small bag of gems!!");
            $session[user][gems]+=7;
            break;
        case 3:
            output("`^ Nothing!");
            break;
        case 4:
            output("`^ Nothing!");
            break;
        case 5:
            output("4 A small bag of gold pieces!!");
            $session[user][gold]+=200;
            break;
        case 6:
            output("`^ A voucher for 40 free inn stays!");
            $config['innstays'] += 40;
            $config['coupon'] += 40;
            output("`n`n`2You currently have `^".$config['innstays']."`2 coupons left!");
            break;
            case 7:
            output("`^ Nothing!");
            break;
            case 8:
            output("`^ Nothing!");
            break;
            case 9:
            output("`^ A voucher for 60 free days with Golinda!");
            $config['healer'] += 60;
            output("`n`n`2You currently have `^".$config['healer']."`2 days left!");
            break;
            case 10:
            output("`^ Nothing!");
            break;
            case 11:
            output("`^ Nothing!");
            break;
            case 12:
            output("`^ 20 Gems!!!");
                        $session[user][gems]+=20;
            break;
        }
                $session['user']['donationconfig']=serialize($config);
    addnav("Back to Party","houseu.php?op=partyroom"); 
break;

case "dance":
        $rand1 = e_rand(1,5);
        switch ($rand1){
        case 1:
            output("`4You dance horribly!! You lose 4 charm!");
        $session[user][charm]-=4;
            break;
        case 2:
            output("`6Everyone enjoys your dancing! You gain 5 charm!");
            $session[user][charm]+=5;
            break;
        case 3:
            output("`2 Noone even glances at your dancing...you get..nothing..your too plain");
            break;
        case 4:
            output("`^ You dance very well and gain 150 charm!");
            $session[user][charm]+=150;
            break;
        case 5:
            output("`3YOU CALL THAT A DANCE?");
            break;

case "spinbottle":
    output("`n`n`9You sit at a table with some friends and play spin the bottle....`n`n");
        $rand1 = e_rand(1,12);
        switch ($rand1){
        case 1:
            output("`9It points to yourself!");
            break;
        case 2:
            output("`^1 The bottle points to a hot girl across the table!!");
output("She thinks your hot and decides to give you 7 gems!!");
            $session[user][gems]+=7;
            break;
        case 3:
            output("`^ It points to yourself!");
            break;
        case 4:
            output("`^ It points to yourself!");
            break;
        case 5:
            output("`4 The bottle points to your mom, she gives you 200 gold instead of having to kiss her!!!");
            $session[user][gold]+=200;
            break;
        case 6:
            output("`^ The bottle points to Cedrick, so he gives you 40 free inn stays instead!!");
            $config['innstays'] += 40;
            $config['coupon'] += 40;
            output("`n`n`2You currently have `^".$config['innstays']."`2 coupons left!");
            break;
            case 7:
            output("`^ It points to yourself!");
            break;
            case 8:
            output("`^ It points to yourself!");
            break;
            case 9:
            output("`^ The bottle points to Golinda, she says she is currently taken so you get 60 free days with Golinda instead!");
            $config['healer'] += 60;
            output("`n`n`2You currently have `^".$config['healer']."`2 days left!");
            break;
            case 10:
            output("`^ The bottle points to yourself!");
            break;
            case 11:
            output("`^ The bottle points to yourself!");
            break;
            case 12:
            output("`^ The bottle points to Pamela Anderson, she says no, so you give her 20 gems, after kissing her you decide it was worth it!!!");
                        $session[user][gems]-=20;
break;
          }
                $session['user']['donationconfig']=serialize($config);
    addnav("Back to Party","houseu.php?op=partyroom"); 
break;

}
page_footer();
?>