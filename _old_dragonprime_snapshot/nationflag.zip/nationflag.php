<?php
function nationflag_getmoduleinfo(){
	$info = array(
		"name"=>"National Flags",
		"author"=>"Chris Vorndran<br>`6Idea: `2Robert`0",
		"category"=>"Stat Display",
		"version"=>"1.0",
		"download"=>"http://dragonprime.net/index.php?module=Downloads;sa=dlview;id=68",
		"vertxtloc"=>"http://dragonprime.net/users/Sichae/",
		"settings"=>array(
			"National Flags - Settings,title",
				"where"=>"Where to display the flag?,enum,0,In Nav,1,Amongst Bio|0",
		),
		"prefs"=>array(
			"National Flags - Prefs,title",
				"user_nationality"=>"What is your nationality?,enum".nationflag_list()."|none",
		),
	);
	return $info;
}
function nationflag_install(){
	module_addhook("biotop");
	module_addhook_priority("biostat",100);
	return true;
}
function nationflag_uninstall(){
	return true;
}
function nationflag_dohook($hookname,$args){
	global $session;
	switch ($hookname){
		case "biotop":
			if (get_module_setting("where")) break;
			$grab = get_module_pref("user_nationality","nationflag",$args['acctid']);
			if ($grab != "none"){
				$splice = explode(".",$grab);
				$img = "<center><img src='./modules/nationflag/$grab'></center>".ucfirst($splice[0]);
				addnavheader("Nationality");
				addnav("$img","!!!addraw!!!",true);
			}
			break;
		case "biostat":
			if (!get_module_setting("where")) break;
			$grab = get_module_pref("user_nationality","nationflag",$args['acctid']);
			if ($grab != "none"){
				$splice = explode(".",$grab);
				$splice = str_replace("_"," ",$splice);
				output("`^Nationality: ");
				rawoutput("<img src='./modules/nationflag/$grab'>");
				output("`@(%s)`n",ucwords($splice[0]));
			}
			break;
		}
	return $args;
}
function nationflag_getlist($dir){
	$no = array(".","..","Thumbs.db");
	$files = array();
	if ($handle = opendir($dir)){
		while (false !== ($file = readdir($handle))){
			if (!in_array($file,$no)) array_push($files, $file);
		}
	}
	closedir($handle);
	return $files;
}
function nationflag_list(){
	$list = ",none,None";
	$grab = nationflag_getlist("./modules/nationflag/");
	foreach($grab AS $id => $nationality){
		$split = explode(".",$nationality);
		$list .= ",".$nationality.",".ucfirst($split[0])."";
	}
	return $list;
}
?>