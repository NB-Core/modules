<?php

function usechow_bathroom_getmoduleinfo()
{
	$info = array
	(
   		"name"			=> "Usechow Bathroom Module",
   		"author"		=> "RPGSL",
    	"version"		=> "1.02",
    	"category"		=> "RPGSL",
		"vertxtloc"		=> "http://www.rpdragon.com",
		"download"		=> "http://www.rpdragon.com/lotgd/usechow_bathroom.zip",
		"description"	=> "Adds a bathroom at Dracos Diner (usechow.php) module. Characters can gain extra turns using this bathroom.",
        "settings"		=> array
        (
            "Usechow Bathroom - Settings,title",
			"cost"			=> "What is the cost to use the bathroom per level?,int|10",
			"maxtimes"		=> "How many times can this bathroom be used per day?,int|2",
			"cangainturns"	=> "Can characters gain turns when using this bathroom?,bool|1",
			"dkadjust"		=> "Divide characters DKs by this amount for chance of gaining an extra turn.,int|5",
			"minchance"		=> "What is the minimum chance of getting an extra turn?,int|5",
			"maxchance"		=> "What is the maximimum chance of getting an extra turn?,int|25",
			"numberturns"	=> "How many turns are gained if the above is set to yes?,int|1",		
        ),
		"prefs"			=> array
		(
			"Usechow Bathroom - Prefs,title",
			"usedtoday"		=> "How many times did the user use this today?,int|0",
		),
		"requires"		=> array
		(
			"usechow"		=> "1.53|`#Lonny Luberts, http://www.pqcomp.com/modules/mydownloads/visit.php?cid=3&lid=38",
		),
	);
	return $info;
}

function usechow_bathroom_install()
{
	if (!is_module_installed('usechow_bathroom'))
	{
		output("Installing `bUse Chow Bathroom`b (usechow_bathroom.php) module by Role Play Game Story Lines (www.rpgsl.com)`n`n");
    }
    else
    {
		output("Updating `bUse Chow Bathroom`b (usechow_bathroom.php) module by Role Play Game Story Lines (www.rpgsl.com)`n`n");
    }
    module_addhook("usechow");
    module_addhook("newday");
    return true;
}

function usechow_bathroom_uninstall()
{
	output("Uninstalling `bUse Chow Bathroom`b (usechow_bathroom.php) module by Role Play Game Story Lines (www.rpgsl.com)`n");
	return true;
}

function usechow_bathroom_dohook($hookname, $args)
{
	global $session;
    switch($hookname)
    {
    	case "usechow":
			$cost = get_module_setting("cost") * $session['user']['level'];
			if (get_module_pref("usedtoday") < get_module_setting("maxtimes") && $session['user']['gold'] >= $cost)
			{
				addnav(array("Use the Bathroom (%s gold)", $cost), "runmodule.php?module=usechow_bathroom&op=use");
			}			
			break;
		case "newday":
			set_module_pref("usedtoday", 0);
			break;
	}
    return $args;
}

function usechow_bathroom_run()
{
	global $session;
	page_header("The Water Closet");
	$op = httpget("op");
	if ($op == "use")
	{
		$cost = get_module_setting("cost") * $session['user']['level'];	
		if ($session['user']['gold'] >= $cost)
		{
			output("Ah, what a relief! You feel much better now. Maybe it was that 50 bean salad you had yesterday...");
			$session['user']['gold'] -= $cost;
			set_module_pref("usedtoday", get_module_pref("usedtoday") + 1);
			set_module_pref("bladder", 0, "bladder");
			if (get_module_setting("cangainturns") <> 0)
			{
				$turnchance = round($session['user']['dragonkills'] / get_module_setting("dkadjust"));
				if ($turnchance < get_module_setting("minchance"))
				{
					$turnchance = get_module_setting("minchance");
				}
				if ($turnchance > get_module_setting("maxchance"))
				{
					$turnchance = get_module_setting("maxchance");
				}
				if (e_rand(1,100) <= $turnchance)
				{
					$numberturns = get_module_setting("numberturns");
					output("Feeling so refreshed, you're ready to take on another forest fight and gain %s turns!", $numberturns);
					$session['user']['turns'] += $numberturns;
					debuglog("gained $numberturns turns using the bathroom addition to the usechow module.");
				}
			}
		}
		else
		{
			output("Sorry, you don't have enough gold to use the bathroom. You need %s gold and you only have %s.", $cost, $session['user']['gold']);
		}
		addnav("Back to the Diner", "runmodule.php?module=usechow&op=inn");
		villagenav();
	}
	page_footer();
}

?>