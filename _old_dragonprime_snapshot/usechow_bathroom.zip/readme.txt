Usechow Bathroom

Version 1.01
Written by RPGSL
Download: http://dragon.com/lotgd/usechow_bathroom.zip
Mirror: http://rpgsl.com/lotgd/usechow_bathroom.zip

Requires: usechow.php 1.53 by Lonny Luberts
Download: http://www.pqcomp.com/modules/mydownloads/visit.php?cid=3&lid=38

Game: http://rpdragon.com

Installation

1) Copy usechow_bathroom.php into your LotGD modules folder
2) Log in to LotGD with your admin account
3) Enter the Superuser Grotto
4) Click Manage Modules
5) Install usechow_bathroom.php (Forest Labrynth)
6) Configure settings and save
7) Activate

Questions/Comments?

alex@rpgsl.com


Visit www.rpgsl.com today for your RPG needs