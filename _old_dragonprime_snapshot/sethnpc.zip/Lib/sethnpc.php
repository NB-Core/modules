<?php
function sethnpc_update(){
	set_module_setting('lastupdate',date("Y-m-d H:i:s",strtotime("+ 300 seconds")));
	$sqlz2="UPDATE ".db_prefix("accounts")." SET laston = '".date("Y-m-d H:i:s",strtotime("+ 300 seconds"))."', alive = '1', loggedin = '1', lasthit = '".date("Y-m-d H:i:s",strtotime("+ 300 seconds"))."', location = '".get_module_setting('npcloc')."', hitpoints = '1000' WHERE acctid = '".get_module_setting('npcid')."'";
	db_query($sqlz2);
	$sqlz2 = "DELETE FROM ".db_prefix("mail")." WHERE msgto='".get_module_setting('npcid')."'";
	db_query($sqlz2);
}

function sethnpc_comment(){
			global $session,$texts;
			//set smilies
			$j = e_rand(1,20);
			$smile = array(1=>"*grins*",2=>"*strahl*",3=>"*lol*",4=>"*wink*",5=>"*schleim*",6=>"*breitgrins*",7=>"*zungerausstreck*",8=>"*fuchtel*",9=>"*zwinker*",10=>"",11=>"",12=>"",13=>"",14=>"",15=>"",16=>"",17=>"",18=>"",19=>"",20=>"");
			//end set smilies
			
			//set comments for installed modules
			if (is_module_active('weather')){
				$comm9 = "Wie das Wetter ist? Ich finde es ist ".get_module_setting('weather','weather')." *glotz*";
			}else{
				$comm9 = "Was haltet ihr von DEM Wetter?";
			}
			if (is_module_active('lonnycastle')){
				$sqlz4 = "SELECT name,acctid,value FROM ".db_prefix("accounts")." LEFT JOIN ".db_prefix("module_userprefs")." ON (acctid = userid) WHERE modulename = 'lonnycastle' and setting = 'evil' ORDER BY RAND(".e_rand().") LIMIT 1";
				$resultz4 = db_query($sqlz4);
			    $rowz4 = db_fetch_assoc($resultz4);
				if ($rowz4['value']>=33) $evil="b�se";
				if ($rowz4['value']<33 and $rowz4['value']>-32) $evil="noch nett";
				if ($rowz4['value']<=-32) $evil="sehr anst�ndig";
				$comm10 = "Hab l�uten h�ren dass ".$rowz4['name']." eigentlich ".$evil." sei. *l�ster*";
				db_free_result($resultz4);
			}else{
				$comm10 = "Was geht ab, Leute?";
			}
			
			$sqlz4 = "SELECT name,charm FROM ".db_prefix("accounts")." ORDER BY RAND(".e_rand().") LIMIT 1";
			$resultz4 = db_query($sqlz4);
		    $rowz4 = db_fetch_assoc($resultz4);
			if ($rowz4['charm'] > -1 and $rowz4['charm'] < 4) $charm="dermassen h�sslich dass es in den Augen schmerzt";
			if ($rowz4['charm'] > 3 and $rowz4['charm'] < 7) $charm="h�sslich wie die Nacht";
			if ($rowz4['charm'] > 6 and $rowz4['charm'] < 11) $charm="unh�bsch";
			if ($rowz4['charm'] > 10 and $rowz4['charm'] < 14) $charm="ansehnlich wie ein Wellblech";
			if ($rowz4['charm'] > 13 and $rowz4['charm'] < 17) $charm="gutaussehend, aber dumm";
			if ($rowz4['charm'] > 16 and $rowz4['charm'] < 20) $charm="ne ganz geile Erscheinung, mal den K�rper ausgenommen";
			if ($rowz4['charm'] > 19 and $rowz4['charm'] < 23) $charm="ne ganz prima Partie, vorausgesetzt man hat keinen Geschmack";
			if ($rowz4['charm'] > 22 and $rowz4['charm'] < 27) $charm="eine sehr gute Partie, so rein vom optischen Standpunkt her!!";
			if ($rowz4['charm'] > 26 and $rowz4['charm'] < 30) $charm="... hm... nein, ich sags doch nicht... ";
			if ($rowz4['charm'] > 29) $charm="wohl die beste Partie, die hierzulande zu machen ist.";
			$comm12 = "Ich hab geh�rt, ".$rowz4['name']." sei ".$charm.". *grins*";
			db_free_result($resultz4);
			if (is_module_active('garlandstable')){
				$comm13 = "Ich hab geh�rt, in den St�llen gibts die schr�gsten Viecher zu kaufen.... ".$smile[$j]." ";
			}else{
				$comm13 = "Och, neeee....";
			}
			if (is_module_active('lonnycastle')){
				$comm14 = "Hab geh�rt dass es im ".get_module_setting('castleloc','lonnycastle')."'s Schloss Geister gibt. ".$smile[$j]." ";
			}else{
				$comm14 = "::hockt hier rum und wartet bis Spinnweben ansetzen.";
			}
			if (is_module_active('voodoopriestess')){
				$comm15 = "Bei der Voodoopriesterin k�nnt ihr jemand mit einem Fluch belegen. ".$smile[$j]." ";
			}else{
				$comm15 = "Schlag dich selbst, du Verlierer!";
			}
			if (is_module_active('potions')){
				$comm16 = "Im Magische-Tr�nke-Laden k�nnt ihr so einiges an Wunderw�sserchen erstehen. ".$smile[$j]." ";
			}else{
				$comm16 = "In der H�tte des Heilers k�nnt ihr eure Wunden heilen lassen.";
			}
			if (is_module_active('vesa')){
				$comm17 = "Manchmal kann man Edelsteine im Steinchenshop kaufen...  ".$smile[$j]." ";
			}else{
				$comm17 = "Die meisten Edelsteine findet man im Wald.";
			}
			if (is_module_active('petra')){
				$comm18 = "Wenn du n Tattoo willst, nur zu... geh zum Tattooshop. ".$smile[$j]." ";
			}else{
				$comm18 = "Ey, ein IQ Punkt mehr, und du bist 'ne Pflanze.";
			}
			if (is_module_active('pqgiftshop')){
				$comm19 = "Kaufe Geschenke im Geschenkeshop. ".$smile[$j]." ";
			}else{
				$comm19 = "Ey, ein IQ Punkt mehr, und du bist 'ne Pflanze.";
			}
			if (is_module_active('trading')){
				$comm20 = "Verdiene Gold indem du handeln gehst! ".$smile[$j]." ";
			}else{
				$comm20 = "Ey, du hast die Ausstrahlung eines Wellblechs!";
			}
			//end set comments for installed modules
			
			//setup commentary array
			$k = e_rand(1,51);
			$sayit = array(
						1=>get_module_setting('comment1'),
						2=>get_module_setting('comment1'),
						3=>get_module_setting('comment2'),
						4=>get_module_setting('comment2'),
						5=>get_module_setting('comment3'),
						6=>get_module_setting('comment3'),
						7=>"Hallo zusammen. ".$smile[$j]." ",
						8=>"Was geht ab? *breitgrins*",
						9=>$comm9,
						10=>$comm10,
						11=>$comm11,
						12=>$comm12,
						13=>$comm13,
						14=>$comm14,
						15=>$comm15,
						16=>$comm16,
						17=>$comm17,
						18=>$comm18,
						19=>$comm19,
						20=>$comm20,
						21=>":: kippt sich einen hinter die Binde ".$smile[$j]." ",
						22=>":: schl�ft so langsam ein ".$smile[$j]." ",
						23=>":: schl�gt ".$session['user']['name']." ".$smile[$j]." und grinst bl�d.",
						24=>":: w�nscht, ".(get_module_setting('sex')?"sie":"er")." w�re eine reale Person ".$smile[$j]." ",
						25=>"Was? ".$smile[$j]." ",
						26=>"Hast du Gehirnwasserabsenkung? ".$smile[$j]." ",
						27=>"Bist du irgendwie bl�d? ".$smile[$j]." ",
						28=>"Ich bin ein Star... HOLT MICH HIER RAUS! ".$smile[$j]." ",
						29=>"Soll ich mich jetzt etwa dar�ber aufregen?.... ".$smile[$j]." ",
						30=>"Ja, genau, das wollte ich auch immer sagen? ".$smile[$j]." ",
						31=>"Hallo ".$session['user']['name']." ".$smile[$j]." ",
						32=>"Hey ".$session['user']['name']." ".$smile[$j].",`# willsch es D��fi?? ",
						33=>"*news*".get_module_setting('name')." `7fiel auf die Fresse und kann nimmer aufstehn.",
						34=>"*news*".$session['user']['name']." `7fiel auf die Fresse und kann nimmer aufstehn.",
						35=>"*news*".get_module_setting('name')." `7hatte etwas zuviele Ales im Eberkopf.",
						36=>"::stubbst ".$session['user']['name'],
						37=>":: kickt ".$session['user']['name']." ".$smile[$j]." in den Allerwertesten.",
						38=>":: steckt ".$session['user']['name']." `&ein Str�usschen Petersilie ins Ohr.".$smile[$j]." ",
						39=>":: Klebt ein Kick-Mich-Schild auf ".$session['user']['name']."'s `&R�cken ".$smile[$j]." ",
						40=>":: entreisst ".$session['user']['name']." Waffe ".$session['user']['weapon']." `& und fuchtelt damit vor der Nase rum. ".$smile[$j]." ",
						41=>"M�chtest du dass ich ein Lied f�r dich schreibe, ".$session['user']['name']."\? ".$smile[$j]." ",
						42=>"Was stinkt hier denn so?  Ach, das ist ja bloss ".$session['user']['name']."\. ".$smile[$j]." ",
						43=>$session['user']['name']."`# sieht idiotisch aus und spricht wohl auch idiotisch. ".($session['user']['sex']?"Sie":"Er")." ist auch ein Idiot. ".$smile[$j]." ",
						44=>$session['user']['name']."`#  Bist du immer so doof, oder gibst du dir heute besonders M�he? ".$smile[$j]." ",
						45=>$session['user']['name']."`#  Denke nicht zuviel, das ist sch�dlich f�r solche Kleinhirne wie deines.".$smile[$j]." ",
						46=>$session['user']['name']."`#  ist etwas unterbelichtet. ".($session['user']['sex']?"Sie":"Er")." weiss gar nichts. ".$smile[$j]." ",
						47=>$session['user']['name']."`#  Oh, mein Gott, guck dich an.. wurde sonst noch jemand verletzt bei diesem Unfall? ".$smile[$j]." ",
						48=>"Hey ".$session['user']['name']."`# du musst das Leben hassen, so wie DU aussiehst? ".$smile[$j]." ",
						49=>"Hey ".$session['user']['name']."`# Ich habe schon viele solche Leute wie dich gesehen, da musste ich aber Eintritt bezahlen!  ".$smile[$j]." ",
						50=>"Hey ".$session['user']['name']."`# Wie kommst denn DU hierher? Hat jemand den K�fig offen gelassen?  ".$smile[$j]." ",
						51=>"Hey ".$session['user']['name']."`# du hast die Perfekte Waffe: Dein Gesicht!  ".$smile[$j]." ",
						);
			//end setup commentary array
			if (strchr($sayit[$k],"*news*")){
				addnews(str_replace("*news*","",$sayit[$k]));
			}else{
				db_query("INSERT INTO ".db_prefix("commentary")." (postdate,section,author,comment) VALUES (now(),'".$texts['section']."','".get_module_setting('npcid')."',\"".$sayit[$k]."\")");
			}
}
?>