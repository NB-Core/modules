<?php

require_once("lib/http.php");

function darkden_getmoduleinfo() {
    $info = array(
        "name"=>"The Dark Den",
        "version"=>"1.0",
        "author"=>"Sneakabout",
        "category"=>"Graveyard",
        "download"=>"http://dragonprime.net/users/Sneakabout/darkden.txt",
        "settings"=>array(
            "Dark Den - Settings,title",
            "traintimes"=>"How many times can you train each day?,int|3",
			"traincost"=>"How much does it cost to train per specialty level?,int|200",
			"favourcost"=>"How many gems does 10 favour cost?,int|5",
			"darkness"=>"Do players gain darkness when they use these items?,bool|1",
			"cursing"=>"Can players curse other players?,bool|1",
			"cursecost"=>"How much does a curse cost (per level)?,int|1000",
			"redelixir"=>"Can players gain more PvPs by quaffing red elixirs?,bool|1",
			"redelixircost"=>"How much do the red elixirs cost? (HP, thousands of gold and tenths of turns lost on newday),int|3",
			"redelixiramount"=>"How many red elixirs can they quaff?,range,0,3|1",
			"darkdeal"=>"Can players make a dark deal?,bool|1",
			"darkdealcost"=>"How much does a dark bargain cost each day?,int|3",
			"darkdealevil"=>"Can the player break the deal easily?,bool|1",
			"darkaidcost"=>"How much does the dark aid cost?,int|8",
			"dragonteethcost"=>"How much do Dragon's Teeth cost?,int|11",
			"bindingsigilcost"=>"How much does the Sigil of Binding cost?,int|10",
			"dkclear"=>"Do dark items clear on DK?,bool|1",
			"dkdealclear"=>"Do dark deals clear on DK?,bool|0",
			"dkdarkclear"=>"Does the player's darkness value clear on DK?,bool|0",
        ),
        "prefs"=>array(
            "Dark Den - User Preferences,title",
			"hastrained"=>"How many times has this person trained today?,int|0",
			"redelixirs"=>"How many elixirs have they burnt today?,int|0",
			"hascursed"=>"Has this player cursed someone?,bool|0",
			"hasbeencursed"=>"Has this player been cursed?,bool|0",
			"darktoken"=>"Does this person have the dark token?,bool|0",
			"darkdeal"=>"Has this player entered into a dark deal?,bool|0",
			"darkaid"=>"How many times can this person call on dark aid?,int|0",
			"dragonteeth"=>"How many sets of Dragon's Teeth has this player got?,int|0",
			"bindingsigil"=>"How many Sigils of Binding does this player have?,int|0",
			"darkness"=>"How much darkness has entered the player?,int|0",
        )
    );
    return $info;
}

function darkden_install(){
	module_addhook("footer-runmodule");
	module_addhook("footer-forest");
	module_addhook("newday");
	module_addhook("mausoleum");
	module_addhook("dragonkilltext");
	module_addhook("fightnav-specialties");
	module_addhook("apply-specialties");
    return true;
}

function darkden_uninstall(){
    return true;
}

function darkden_dohook($hookname,$args){
    global $session;
    switch($hookname){
		case "newday":
		set_module_pref("hastrained",0);
		set_module_pref("hascursed",0);
		set_module_pref("favourbought",0);
		if (get_module_setting("darkness")) {
			$darkness=get_module_pref("darkness");
			if ($darkness>50) {
				output("`n`\$Your soul rebels at the memory of the darklife you have chosen, and you find it nearly impossible to get up!`n");
				output("`nYour corruption shows in your twisted frame and deformed features!`0`n");
				$session['user']['charm']-=2;
				$session['user']['hitpoints']*=0.75;
				apply_buff('baddarkpath',array(
					"name"=>"`)Blackened Soul",
					"rounds"=>5,
					"wearoff"=>"Your conscience stops screaming.",
					"defmod"=>0.8,
					"roundmsg"=>"You feel disgusted at your actions!", 
					"schema"=>"darkden"
				));
				$darkness-=5;
			} elseif ($darkness>20) {
				output("`n`7The darkness of your life makes it harder to get up in the morning!`0`n");
				$session['user']['charm']--;
				apply_buff('baddarkchoice',array(
					"name"=>"`)Tarnished Soul",
					"rounds"=>5,
					"wearoff"=>"You forget your past misdeeds.",
					"defmod"=>0.95,
					"roundmsg"=>"You feel terrible!", 
					"schema"=>"darkden"
				));
				$darkness-=2;
			} elseif ($darkness>10) {
				output("`n`&You think briefly about the bad things you have done, but ignore the guilt.`0`n");
				$darkness-=1;
			}
			set_module_pref("darkness",$darkness);
		}
		if (get_module_pref("darkdeal")) {
			$rand=e_rand(1,7);
			$cost=get_module_setting("darkdealcost");
			if ($session['user']['maxhitpoints']>($session['user']['level']*10 + $cost)) {
				output("`n`7After you make the blood sacrifice, ignoring the scars, you feel the dark energy of your master suffusing you! Your blood boils with unholy power!");
				$session['user']['maxhitpoints']-=$cost;
				$session['user']['charm']-=$cost;
				$session['user']['deathpower']+=10;
				$session['user']['turns']++;
				switch($rand){
					case 1:
					case 2:
					case 3:
					apply_buff('darkdealbuff',array(
						"name"=>"`\$Unholy Power",
						"rounds"=>25,
						"wearoff"=>"Your Master's power fades from you.",
						"atkmod"=>1.15,
						"defmod"=>1.15,
						"roundmsg"=>"Your blood boils!", 
						"schema"=>"darkden"
					));
					output("The master blesses you with abnormal strength and toughness!`n");
					break;
					case 4:
					apply_buff('darkdealgoodbuff',array(
						"name"=>"`\$Unholy Power",
						"rounds"=>35,
						"wearoff"=>"Your Master's power fades from you.",
						"atkmod"=>1.2,
						"defmod"=>1.2,
						"roundmsg"=>"Your blood boils!", 
						"schema"=>"darkden"
					));
					output("The master blesses you with abnormal strength and toughness!`n");
					$session['user']['hitpoints']*=1.5;
					break;
					case 5:
					output("The master blesses you with a burst of dark energy!`n");
					$session['user']['turns']+=2;
					$session['user']['hitpoints']*=2;
					break;
					case 6:
					case 7:
					output("The master blesses you with a gift of a Dark Skull of Ramius!`n");
					set_module_pref("darkaid",(get_module_pref("darkaid")+1));
					break;
				}
			} else {
				output("`n`7You attempt to make the blood sacrifice, but your hand shakes, you do not have the strength.");
				output("Ramius is angry with your failure! He curses your name!`0`n");
				set_module_pref("hasbeencursed",1);
			}
			set_module_pref("darkness",(get_module_pref("darkness")+2));
			if ($session['user']['specialty']!="DA") {
				output("`n`7You can feel the disapproval of your Master on your new path bearing down on you.`0`n");
			}
		}
		if (get_module_pref("redelixirs")) {
			output("`n`%While you try to open your eyes, your body feels like it has been beaten several times, and it is an effort to move.");
			output("You curse the Necromancer's elixirs, knowing that they have caused this unnatural fatigue.`0`n");
			set_module_pref("darkness",(get_module_pref("darkness")+3));
			$session['user']['turns']*=(1-(get_module_setting("redelixircost")/10));
			apply_buff('redelixirbuff',array(
				"name"=>"`%Aching Limbs",
				"rounds"=>10,
				"wearoff"=>"Your joints stop screaming.",
				"defmod"=>0.9,
				"roundmsg"=>"Your muscles protest your movement!", 
				"schema"=>"darkden"
			));
			set_module_pref("redelixirs",0);
		}
		if (get_module_pref("hasbeencursed")) {
			output("`n`7As you get up, a sudden darkness clutches your soul... you choke, and nearly fall over. You eventually recover, weakened and shaking.`0`n");
			$session['user']['hitpoints']*=0.5;
			$session['user']['turns']-=2;
			set_module_pref("hasbeencursed",0);
		}
		break;
		case "mausoleum":
		if (get_module_pref("darkden")) {
			output("You look upon your Master and your soul shivers. Will you try to break your deal?");
			addnav("Break Your Deal","runmodule.php?module=darkden&op=breakdeal");
		}
		break;
		case "dragonkilltext":
		if (get_module_setting("dkclear")) {
			set_module_pref("darkaid",0);
			set_module_pref("dragonteeth",0);
			set_module_pref("bindingsigil",0);
			set_module_pref("hasbeencursed",0);
			set_module_pref("darktoken",0);
		}
		if (get_module_setting("dkdealclear")) {
			set_module_pref("darkdeal",0);
		}
		if (get_module_setting("dkdarkclear")) {
			set_module_pref("darkness",0);
		}
		break;
	    case "fightnav-specialties":
		$script = $args['script'];
		if ((get_module_pref("darkdeal") > 0)&&($session['user']['maxhitpoints']>($session['user']['level']*10 + 5))) {
			addnav("`\$Gifts of Ramius`0");
			addnav("`\$Dark Call`0", 
					$script."op=fight&skill=darkden&l=darkcall", true);
		}
		if (get_module_pref("darkaid") > 0) {
			addnav("`\$Gifts of Ramius`0");
			addnav(array("`7Dark Aid (%s)`0", get_module_pref("darkaid")),
					$script."op=fight&skill=darkden&l=darkaid",true);
		}
		if (get_module_pref("dragonteeth") > 0) {
			addnav("`7Necromancer's Goods`0");
			addnav(array("`&Dragon's Teeth`7 (%s)`0", get_module_pref("dragonteeth")),
					$script."op=fight&skill=darkden&l=dragonteeth",true);
		}
		if (get_module_pref("bindingsigil") > 0) {
			addnav("`7Necromancer's Goods`0");
			addnav(array("`!Sigil of Binding`7 (%s)`0", get_module_pref("bindingsigil")),
					$script."op=fight&skill=darkden&l=bindingsigil",true);
		}
		break;
		case "apply-specialties":
		$skill = httpget('skill');
		$l = httpget('l');
		if ($skill=="darkden"){
			switch($l){
				case "darkcall":
				$session['user']['hitpoints']=($session['user']['maxhitpoints']*1.1);
				apply_buff('darkcall',array(
					"startmsg"=>"`\$Calling on spirits beyond the grave, you sacrifice your blood for power!",
					"name"=>"`\$Dark Calling",
					"rounds"=>5,
					"wearoff"=>"Your strength abandons you.",
					"atkmod"=>1.2,
					"roundmsg"=>"Dark strength flows through your veins!", 
					"schema"=>"darkden"
				));
				$session['user']['maxhitpoints']-=5;
				set_module_pref("darkness",(get_module_pref("darkness")+5));
				break;
				case "darkaid":
				apply_buff('darkaid',array(
					"startmsg"=>"`7The {badguy} shudders in pain as you crush the Skull of Ramius in your hand.",
					"name"=>"`\$Dark Aid",
					"effectmsg"=>"Spears of darkness fly through the {badguy}, hurting it for `^{damage}`) points!",
					"minioncount"=>1,
					"maxbadguydamage"=>round($session['user']['attack']*3,0),
					"minbadguydamage"=>round($session['user']['attack']*1,0),
					"schema"=>"darkden"
				));
				set_module_pref("darkaid",(get_module_pref("darkaid")-1));
				set_module_pref("darkness",(get_module_pref("darkness")+2));
				break;
				case "dragonteeth":
				apply_buff('dragonteeth',array(
					"startmsg"=>"`&You sow the teeth in the ground, and watch amazed as skeletal warriors rise up!",
					"name"=>"`&Bone Warriors",
					"effectmsg"=>"`)A skeletal warrior hits {badguy}`) for `^{damage}`) damage.",
					"effectnodmgmsg"=>"`)A skeletal warrior tries to hit {badguy}`) but `\$MISSES`)!",
					"rounds"=>4,
					"wearoff"=>"The dark magics animating the warriors fades, and they collapse to the ground, forming piles of bones.",
					"minioncount"=>$session['user']['level'],
					"maxbadguydamage"=>round($session['user']['level']/2,0)+1,
					"schema"=>"darkden"
				));
				set_module_pref("dragonteeth",(get_module_pref("dragonteeth")-1));
				break;
				case "bindingsigil":
				require_once("lib/buffs.php");
				if (has_buff("da3")) {
					output("`n`7You cast the sigil, and it winds around the ancestral spirits you cursed, prolonging their torment!");
					$session['bufflist']['da3']['rounds'] += 6;
					set_module_pref("darkness",(get_module_pref("darkness")+1));
				} elseif (has_buff("da5")) {
					output("`n`\$You cast the sigil, and it winds around the poor victim's soul, sending it into spasms of pain!");
					apply_buff('bindingsigil',array(
						"effectmsg"=>"The {badguy} screams as its soul is further bound, hurting it for `^{damage}`) points!",
						"minioncount"=>1,
						"maxbadguydamage"=>round($session['user']['attack']*2,0),
						"minbadguydamage"=>round($session['user']['attack']*1,0),
						"schema"=>"darkden"
					));
					$session['bufflist']['da5']['rounds'] += 2;
					set_module_pref("darkness",(get_module_pref("darkness")+2));
				} else {
					output("`n`\$You cast the sigil, but with no other soul already bound, your own is trapped!`n");
					apply_buff('boundself',array(
						"startmsg"=>"`7You shudder in pain, your soul constrained.",
						"name"=>"`\$Bound Soul",
						"rounds"=>4,
						"wearoff"=>"Your soul is eventually freed, allowing you to fight again.",
						"atkmod"=>0.8,
						"defmod"=>0.8,
						"roundmsg"=>"Your soul is bound! You cannot fight properly in such pain!", 
						"schema"=>"darkden"
					));
				}
				set_module_pref("bindingsigil",(get_module_pref("bindingsigil")-1));
				break;
			}
		}
		break;
		case "footer-runmodule":
		$op=httpget("op");
		$module=httpget("module");
		switch($module){
			case "cemetery":
			if ($op=="deadspeak") {
				output("`)To one side a sepulcher which had seemed insignificant before, covered in weeds and brambles, seems to loom large.");
				addnav("Examine the Sepulcher","runmodule.php?module=darkden&op=sepulcher");
			}
			break;
		}
		break;
		case "footer-forest":
		$op=httpget("op");
		if (($op=="tables")&&(get_module_pref("darktoken"))&&($session['user']['specialinc']="module:darkhorse")) {
			output("`n`nOne carving in particular seems familiar, and you realise it is a match to the dark token in your pouch.");
			addnav("Use the Token","runmodule.php?module=darkden&op=entershop");
		}
		break;
	}
    return $args;
}

function darkden_run() {
    global $session;
	$op = httpget('op');
	
	switch($op){
		case "sepulcher":
		page_header("Dark Sepulcher");
		output("`)You drift over to the tomb, and as you get closer you can see that the sides are ornate, and studded with gems gleaming with some inner light.");
		output("The name of the person who was buried here has long since faded, but you can feel some kind of lost power here.");
		addnav("Dark Sepulcher");
		if (($session['user']['specialty']=="DA")&&(!get_module_pref("darktoken"))) {
			output("As you look closer at the patterns, you think you can make out some kind of glyph, damaged, but perhaps possible to restore with time.");
			if ($session['user']['gravefights']) addnav("Work on the Glyph","runmodule.php?module=darkden&op=tokenglyph");
		}
		if ($session['user']['gravefights']) {
			addnav("Pray at the Tomb","runmodule.php?module=darkden&op=tombpray");
			addnav("Steal the Gems","runmodule.php?module=darkden&op=gemsteal");
		}
		$cemeteryloc=get_module_setting("cemeteryloc","cemetery");
		addnav("Return to $cemeteryloc","runmodule.php?module=cemetery&op=deadspeak&area=village-ghosttown&village=$cemeteryloc");
		break;
		case "tokenglyph":
		page_header("Dark Sepulcher");
		$rand=e_rand(3,20);
		$session['user']['gravefights']--;
		addnav("Dark Sepulcher");
		if (get_module_pref("skill","specialtydarkarts")<$rand) {
			output("`7Though you spend some time working at it, you just can't get the pieces to fit together correctly.");
			output("Cursing at your wasted time, you kick the thing and walk away as it crumbles.");
		} elseif (!$session['user']['gems']) {
			output("`7Though you spend some time working at it, there seems to be a gem missing from the glyph.");
			output("Search as you might, it doesn't appear to be on the ground around you.");
			output("Cursing at your wasted time, you kick the thing and walk away as it crumbles.");
		} else {
			output("`7Though you spend some time working at it, there seems to be a gem missing from the glyph.");
			output("Search as you might, it doesn't appear to be on the ground around you.");
			output("Do you wish to use one of your own gems to complete the symbol?");
			addnav("Complete the Glyph","runmodule.php?module=darkden&op=gettoken");
		}
		$cemeteryloc=get_module_setting("cemeteryloc","cemetery");
		addnav("Return to $cemeteryloc","runmodule.php?module=cemetery&op=deadspeak&area=village-ghosttown&village=$cemeteryloc");
		break;
		case "gettoken":
		page_header("Dark Sepulcher");
		addnav("Dark Sepulcher");
		$session['user']['gems']--;
		debuglog("used a gem to gain a Dark Token");
		output("`7As you place the gem into the gap in the glyph, it begins to glow a deep red, and the tomb shakes, releasing clouds of dust.");
		output("As you go to flee, the shaking dies down, and the glyph darkens once more.");
		output("Examining the sepulcher again, you find a strange token with a shadowy horse imprinted on one side, and an elaborate \"R\" on the other.");
		output("`n`nYou walk away as the glyph collapses again behind you, intrigued at the thing you have discovered.");
		set_module_pref("darktoken",1);
		$cemeteryloc=get_module_setting("cemeteryloc","cemetery");
		addnav("Return to $cemeteryloc","runmodule.php?module=cemetery&op=deadspeak&area=village-ghosttown&village=$cemeteryloc");
		break;
		case "tombpray":
		page_header("Dark Sepulcher");
		$session['user']['gravefights']--;
		$rand=e_rand(1,11);
		output("`)You bow your head in reflection next to the tomb, and think about the world and it's nature.");
		switch($rand){
			case 1:
			case 2:
			output("After some time of paying your respects, you leave, and feel that someone has approved of your actions towards this place.");
			output("`n`nYou gain 10 favour!");
			$session['user']['deathpower']+=10;
			break;
			case 3:
			case 4:
			output("After some time of paying your respects, you leave, and feel your soul slightly healed.");
			$session['user']['soulpoints']*=1.2;
			break;
			case 5:
			case 6:
			case 7:
			case 8:
			case 9:
			case 10:
			output("After some time of paying your respects, you leave, tired of this waste of time.");
			break;
			case 11:
			output("After some time of paying your respects, you start to feel dizzy, and in a haze you black out.");
			output("`n`nEventually you wake, groggy and barely able to move. You drift slowly away from the tomb, shattered.");
			$session['user']['soulpoints']=0;
			$session['user']['gravefights']=0;
			break;
		}
		addnav("Dark Sepulcher");
		$cemeteryloc=get_module_setting("cemeteryloc","cemetery");
		addnav("Return to $cemeteryloc","runmodule.php?module=cemetery&op=deadspeak&area=village-ghosttown&village=$cemeteryloc");
		break;
		case "gemsteal":
		page_header("Dark Sepulcher");
		$session['user']['gravefights']--;
		$rand=e_rand(1,11);
		output("`&After glancing around to see if there are any other spirits nearby, you start to work on prying some of the gems loose.");
		switch($rand){
			case 1:
			case 2:
			$gems=e_rand(2,3);
			output("Working away at them, you manage to steal `%%s gems`& before you feel a darkness surround you.",$gems);
			output("Despite the fact you cannot see anyone, you can feel a great tension in the air, and you quit while you're ahead.");
			output("`n`nFrom behind you, you get the feeling someone is angry at your actions!");
			$session['user']['gems']+=$gems;
			$session['user']['deathpower']*=0.8;
			debuglog("stole $gems gems from a sepulcher.");
			break;
			case 3:
			case 4:
			$gems=e_rand(2,4);
			output("Working away at them, you manage to steal `%%s gems`& before you feel a darkness surround you.",$gems);
			output("Despite the fact you cannot see anyone, you can feel a great tension in the air, but you decide to keep going anyway.");
			output("Suddenly a great bolt of darkness thrusts through your soul, contorting you in agony.");
			output("Wounded and terrified, you flee the scene, still clutching your ill-gotten gains.");
			$session['user']['gems']+=$gems;
			$session['user']['soulpoints']*=0.2;
			debuglog("stole $gems gems from a sepulcher.");
			break;
			case 5:
			case 6:
			case 7:
			output("Working away at them, you have barely started before you feel a darkness surround you.");
			output("Despite the fact you cannot see anyone, you can feel a great tension in the air, and you quit while you're ahead.");
			output("`n`nFrom behind you, you get the feeling someone is angry at your actions!");
			$session['user']['deathpower']*=0.8;
			break;
			case 8:
			case 9:
			case 10:
			output("Working away at them, you manage to steal a `%gem`& before you feel a darkness surround you.");
			output("Despite the fact you cannot see anyone, you can feel a great tension in the air, but you decide to keep going anyway.");
			output("Suddenly a great bolt of darkness thrusts through your soul, contorting you in agony.");
			output("Wounded and shattered, you flee the scene, still clutching your ill-gotten gains.");
			$session['user']['gems']++;
			$session['user']['soulpoints']*=0.2;
			$session['user']['gravefights']--;
			debuglog("stole a gem from a sepulcher.");
			break;
			case 11:
			output("Working away at them, you have barely started before you feel a darkness surround you.");
			output("Despite the fact you cannot see anyone, you can feel a great tension in the air, but you decide to keep going anyway.");
			output("Suddenly a great bolt of darkness thrusts through your soul, destroying your form.");
			output("Dispirited, you float back to the cemetary.");
			$session['user']['soulpoints']=0;
			$session['user']['gravefights']=0;
			break;
		}
		addnav("Dark Sepulcher");
		$cemeteryloc=get_module_setting("cemeteryloc","cemetery");
		addnav("Return to $cemeteryloc","runmodule.php?module=cemetery&op=deadspeak&area=village-ghosttown&village=$cemeteryloc");
		break;
		case "entershop":
		page_header("Necromancer's Shop");
		$skill=get_module_pref("skill","specialtydarkarts");
		$traincost=get_module_setting("traincost")*$skill;
		$redelixir=get_module_setting("redelixir");
		$redelixircost=get_module_setting("redelixircost");
		$cursing=get_module_setting("cursing");
		$cursecost=get_module_setting("cursecost");
		$darkness=get_module_setting("darkness");
		$darkdeal=get_module_setting("darkdeal");
		$darkaidcost=get_module_setting("darkaidcost");
		$dragonteethcost=get_module_setting("dragonteethcost");
		$bindingsigilcost=get_module_setting("bindingsigilcost");
		output("`\$You press the token to the table, and are blinded as a flash of light bursts from the letter on the other side.");
		output("When you can see again, you are holding the token and standing in some kind of arched dungeon, stone-walled and dripping with oozes and slimes with no visible way out.");
		output("However, what holds your attention is the old man watching you from a corner, his hands stained dark red from working on something mercifully hidden behind a stack of powerful leather bound grimoirs, one of the many stacks in the corner which is well-furnished with cabinets, desks and occult paraphernalia.");
		output("As he watches you he mutters some magical phrase, and the fluid on his hands slides off into a dish which he carefully places in a cabinet nearby.");
		output("`n`n\"`4Greetings, dark acolyte... the journey here was difficult I trust? I value my privacy highly.... although I will naturally aid others of the Art in duty to my Master.");
		output("Whilst I do not normally train such as you, %s gold might change my mind... and some gems might make me put in a good word with my master for you.",$traincost);
		if ($cursing) output("If you have enemies, as those of our profession always do, I can lay an incapacitating dweomer on them for a mere %s gold  for each level of power they have achieved.",$cursecost);
		if ($redelixir) output("If revenge of a more... physical kind... interests you, you may quaff a.... `\$red`4... elixir to attack more of your enemies. You'll be providing the materials, %s marks of blood and %s gold, and don't plan on doing anything the day after.",$redelixircost,$redelixircost*1000);
		if ($darkdeal) output("However... I can see that you are ambitious.... serving the Master directly would bring you great power, if you are willing to make the necessary sacrifices....");
		output("To enhance your curses, I have constructed Sigils of Binding, useful if you have already snared part of the soul of your enemy for a mere %s gems each.",$bindingsigilcost);
		output("For those unwilling or unready to further themselves in the Dark Arts, I have items which may be useful, Dragon's Teeth for %s gems, or a Skull of Ramius, to call upon his aid, for %s gems.... though I can only sell such an item to those he favours.",$dragonteethcost,$darkaidcost);
		output("`\$\".`n`nOnce he finishes speaking he watches you like a hawk, his hands caressing a dagger in an ominous way while he watches you.");
		addnav("Shop Options");
		modulehook("darkshop");
		if (get_module_pref("hastrained")<=get_module_setting("traintimes") && $session['user']['gold']>$traincost) addnav("Purchase Training","runmodule.php?module=darkden&op=train");
		if ($session['user']['gems']) addnav("Ramius' Favour","runmodule.php?module=darkden&op=ramiusfavourentry");
		if ($session['user']['gold']>$cursecost && $cursing && !get_module_pref("hascursed")) addnav("Cursing","runmodule.php?module=darkden&op=cursechoose");
		if ($redelixir && get_module_pref("redelixirs")<get_module_setting("redelixiramount")) addnav("Red Elixir","runmodule.php?module=darkden&op=redelixir");
		if ($darkdeal && !get_module_pref("darkdeal")) addnav("Dark Pact","runmodule.php?module=darkden&op=darkdealconfirm");
		if ($session['user']['gems']>$bindingsigilcost) addnav("Sigil of Binding","runmodule.php?module=darkden&op=bindingsigil");
		if ($session['user']['gems']>$dragonteethcost) addnav("Dragon's Teeth","runmodule.php?module=darkden&op=dragonteeth");
		if ($session['user']['gems']>$darkaidcost) addnav("Skull of Ramius","runmodule.php?module=darkden&op=darkaid");
		break;
		case "shop":
		page_header("Necromancer's Shop");
		$skill=get_module_pref("skill","specialtydarkarts");
		$traincost=get_module_setting("traincost")*$skill;
		$redelixir=get_module_setting("redelixir");
		$redelixircost=get_module_setting("redelixircost");
		$cursing=get_module_setting("cursing");
		$cursecost=get_module_setting("cursecost");
		$darkness=get_module_setting("darkness");
		$darkdeal=get_module_setting("darkdeal");
		$darkaidcost=get_module_setting("darkaidcost");
		$dragonteethcost=get_module_setting("dragonteethcost");
		$bindingsigilcost=get_module_setting("bindingsigilcost");
		output("`\$After you back away from the Necromancer, you look around once again, still finding no exits that you can see.");
		output("He himself looks at you hungrily, still caressing that dagger and looking somewhat distracted at the thought of killing you.");
		output("You think back on what he said, and remember that you can purchase training for %s gold, favour with Ramius for gems, Dragon's Teeth for %s gems, a Sigil of Binding for %s gems and a Skull of Ramius for %s gems, though you'll have to be in Ramius' favour for that one...",$traincost,$dragonteethcost,$bindingsigilcost,$darkaidcost);
		if ($cursing) output("He also mentioned punishing your enemies, though at the cost of %s gold per level of power....",$cursecost);
		if ($redelixir) output("If revenge of a more... physical kind... interests you, you may quaff a.... `\$red`4... elixir to attack more of your enemies. You'll be providing the materials, %s marks of blood and %s gold, and don't plan on doing anything the day after.",$redelixircost,$redelixircost*1000);
		if ($darkdeal) output("And a Dark Pact with Ramius which you could engage in, though it could be perilous.");
		addnav("Shop Options");
		modulehook("darkshop");
		if (get_module_pref("hastrained")<=get_module_setting("traintimes") && $session['user']['gold']>$traincost) addnav("Purchase Training","runmodule.php?module=darkden&op=train");
		if ($session['user']['gems']) addnav("Ramius' Favour","runmodule.php?module=darkden&op=ramiusfavourentry");
		if ($session['user']['gold']>$cursecost && $cursing && !get_module_pref("hascursed")) addnav("Cursing","runmodule.php?module=darkden&op=cursechoose");
		if ($redelixir && get_module_pref("redelixirs")<get_module_setting("redelixiramount")) addnav("Red Elixir","runmodule.php?module=darkden&op=redelixir");
		if ($darkdeal && !get_module_pref("darkdeal")) addnav("Dark Pact","runmodule.php?module=darkden&op=darkdealconfirm");
		if ($session['user']['gems']>$bindingsigilcost) addnav("Sigil of Binding","runmodule.php?module=darkden&op=bindingsigil");
		if ($session['user']['gems']>$dragonteethcost) addnav("Dragon's Teeth","runmodule.php?module=darkden&op=dragonteeth");
		if ($session['user']['gems']>$darkaidcost) addnav("Skull of Ramius","runmodule.php?module=darkden&op=darkaid");
		addnav("Ask How to Leave","runmodule.php?module=darkden&op=leaveshop");
		break;
		case "train":
		page_header("Necromancer's Shop");
		require_once("lib/increment_specialty.php");
		$oldskill=$session['user']['specialty'];
		$session['user']['specialty']="DA";
		$skill=get_module_pref("skill","specialtydarkarts");
		$cost=get_module_setting("traincost")*$skill;
		if (!$session['user']['gold']) {
			output("`\$The Necromancer sneers at you as you approach and takes a firm grip on the dagger. Checking yourself, you notice you have no gold, and beat a hasty retreat from him.");
		} elseif ($session['user']['gold']<$cost) {
			output("`\$The Necromancer sneers at you as you approach and takes a firm grip on the dagger. Following his eyes, you see that you do not have enough gold, and beat a hasty retreat from him.");
		} else {
			output("`\$The Necromancer sneers at you as you approach and takes a firm grip on the dagger. Despite your full payment, he remains hostile and eyes you suspiciously when you ask to be granted his secrets.");
			$session['user']['gold']-=$cost;
			debuglog("spent $cost gold training the Dark Arts.");
			if ($skill<8) {
				output("`n`nHe looks you up and down, then relaxes his grip on the dagger, realising that you are no threat. He talks for a while on your inferiority before letting you read a page of one of the less-powerful tomes.");
				increment_specialty("`\$");
				set_module_pref("hastrained",(get_module_pref("hastrained")+1));
				output("Despite his terrible teaching and his constant threats to kill you, you really feel you learned something, and quickly conceal that, faking ignorance once more.");
			} elseif ($skill>35) {
				output("`n`nHe glares at you as you approach, and his knuckles turn white on his dagger as he takes your gold, his hands shaking with barely-contained fury.");
				output("He speaks to you at length on his superiority to you, but you sense a certain desperation in his voice as he boasts of hollow triumphs and meaningless feats in the past.");
				output("Eventually, he spits at you and says that you have heard enough. You have the good sense to back off before he attempts to gut you, and you learn nothing from this.");
			} else {
				output("`n`nHe looks at you slowly before looking at the gold again, as if evaluating the risks. He lectures you on your weakness and ineffectual grasp on the Dark, but keeps a firm grip on his dagger.");
				output("After a while of that, he eventually shows you some of his apparatus and the methods of cursing he utilises, though he conceals the source of most of his powers.");
				increment_specialty("`\$");
				set_module_pref("hastrained",(get_module_pref("hastrained")+1));
				output("Despite his terrible teaching and his constant threats to kill you, you really feel you learned something, and quickly conceal that, faking ignorance once more.");
			}
		}
		$session['user']['specialty']=$oldskill;
		addnav("Back Away","runmodule.php?module=darkden&op=shop");
		break;
		case "ramiusfavourentry":
		page_header("Necromancer's Shop");
		$cost=get_module_setting("favourcost");
		output("`\$The Necromancer smirks as you approach him about gaining favour with Ramius.... \"`4So ye want to have the ear of the Master, aye? Well, the heavier my gem pouch, the friendlier he might get... not that I can work miracles, but for, say, %s gems I'd be able to get ye 10 marks in his good books....`\$\"",$cost);
		output("`n`nHow many gems do you wish to spend on his favour?");
		$give = translate_inline("Give him the Gems");
		addnav("","runmodule.php?module=darkden&op=ramiusfavour");
		rawoutput("<form action='runmodule.php?module=darkden&op=ramiusfavour' method='POST'>");
		rawoutput("<input name='gemcount' value='0'>");
		rawoutput("<input type='submit' class='button' value='$give'>");
		rawoutput("</form>");
		addnav("Back Away","runmodule.php?module=darkden&op=shop");
		break;
		case "ramiusfavour":
		page_header("Necromancer's Shop");
		$reply=httppost('gemcount');
		$cost=get_module_setting("favourcost");
		$bought=get_module_pref("favourbought");
		if (($reply/$cost + $bought/10)>5) {
			output("`\$The Necromancer spits and laughs in your face, \"`4I'm not his mistress you fool! I'll only be able to get you about %s more marks in his books, no matter what ye pay me!`\$\"",(50-$bought));
		} elseif ($reply>$session['user']['gems']) {
			output("`\$The Necromancer spits and snarls at you, and you realise you do not have that many gems to offer. You quickly back away.");
		} elseif (!$reply) {
			output("`\$The Necromancer spits and snarls at you, and you realise you did not offer him anything. You quickly back away.");
		} else {
			$favour=($reply/$cost * 10);
			output("`\$The Necromancer chuckles as you reluctantly hand him the gems and swiftly pockets them. \"`4I'm sure the master will appreciate your generosity.... %s marks next time you're at his mercy, so to speak.`\$\"",$favour);
			$session['user']['deathpower']+=$favour;
			$session['user']['gems']-=$reply;
			set_module_pref("favourbought",($bought+$favour));
			debuglog("spent $reply gems on gaining favour from Ramius.");
		}
		addnav("Back Away","runmodule.php?module=darkden&op=shop");
		break;
		case "cursechoose":
		page_header("Necromancer's Shop");
		output("`\$A wicked smile makes its way across the Necromancer's face as you tell him of your intention to curse one of your enemies.");
		output("\"`4Very well, very well.... who be the unlucky target then....?`\$\"");
		output("<form action='runmodule.php?module=darkden&op=cursecheck' method='POST'>",true);
		output("`&Name: <input name='cursename'>`n", true);
		output("<input type='submit' class='button' value='Tell the Name'></form>",true);
		addnav("","runmodule.php?module=darkden&op=cursecheck");
		addnav("Back Away","runmodule.php?module=darkden&op=shop");
		break;
		case "cursecheck":
		page_header("Necromancer's Shop");
		$cursename = stripslashes(rawurldecode(httppost('cursename')));
		$name="%";
		for ($x=0;$x<strlen($cursename);$x++){
			$name.=substr($cursename,$x,1)."%";
		}
		$sql = "SELECT acctid,name,login,level,locked FROM " . db_prefix("accounts") . " WHERE name LIKE '".addslashes($name)."' AND locked=0";
		$result = db_query($sql);
		if (db_num_rows($result) == 0) {
			output("`\$The Necromancer spits at you and says, \"`4Nobody called that in this realm, fool... do not waste my time.`\$\"");
		} elseif(db_num_rows($result) > 25) {
			output("`\$The Necromancer spits at you and says, \"`4You can't curse half the realm, you idiot... do not waste my time.`\$\"");
		} elseif(db_num_rows($result) > 1) {
			output("`\$The Necromancer spits and says, \"`4I'm sure an incompetent adventurer like you can't have made this many enemies... choose one to curse.`\$\"");
			output("<form action='runmodule.php?module=darkden&op=cursecast' method='POST'>",true);
			output("`^Name: <select name='name'>",true);
			for ($i=0;$i<db_num_rows($result);$i++){
				$row = db_fetch_assoc($result);
				output("<option value=\"".rawurlencode($row['name'])."\">".full_sanitize($row['name'])."</option>",true);
			}
			output("</select>`n`n",true);
			$amount = httppost('amount');
			output("<input type='submit' class='button' value='Curse This One'></form>",true);
			addnav("","runmodule.php?module=darkden&op=cursecast");
		} else {
			$row = db_fetch_assoc($result);
			output("`\$The Necromancer nods and spits as you say the name, and begins to prepare the curse.");
			output("He looks to you for confirmation of %s`\$'s name.",$row['name']);
			addnav("Cast the Curse","runmodule.php?module=darkden&op=cursecast&name=$name");
		}
		addnav("Back Away","runmodule.php?module=darkden&op=shop");
		break;
		case "cursecast":
		page_header("Necromancer's Shop");
		require_once("lib/systemmail.php");
		$name=httpget('name');
		if ($name=="") {
			$sql = "SELECT acctid,name,login,level,locked FROM " . db_prefix("accounts") . " WHERE name='".addslashes(rawurldecode(stripslashes(httppost('name'))))."' AND locked=0";
		} else {
			$sql = "SELECT acctid,name,login,level,locked FROM " . db_prefix("accounts") . " WHERE name LIKE '".addslashes($name)."' AND locked=0";
		}
		$result = db_query($sql);
		$row  = db_fetch_assoc($result);
		if ($row['locked']) {
			output("`\$The Necromancer looks in the scrying pool, and cannot see %s`\$. He spits and tells you to go away, that person cannot be cursed.",$row['name']);
		} elseif ($row['login']==$session['user']['login']) {
			output("`\$The Necromancer snarls at you and says, \"`4Truly, your stupidity astounds even me. I'm tempted to carry through your request, but I don't really think you wish to curse yourself, yes?`\$\"");
		} elseif (get_module_pref("hasbeencursed",false,$row['acctid'])) {
			output("`\$The Necromancer grins at you and says, \"`4This one has a lot of enemies, aye? Someone else has gotten there first, a curse is laid upon %s `4already.`\$\"",$row['name']);
		} elseif (($row['level']*1000)>$session['user']['gold']) {
			output("`\$The Necromancer snarls at you and says, \"`4Truly, your stupidity astounds even me. You do not have the gold to curse this person. Do not dare waste my time.`\$\"");
		} else {
			$cursegold=$row['level']*1000;
			$session['user']['gold']-=$cursegold;
			debuglog("spent $cursegold cursing {$row['name']}.");
			output("`\$The Necromancer takes your gold then mutters a dark incantation over the scrying bowl, scattering something unmentionable on the surface of the liquid in the meantime.");
			output("Before long the surface is boiling, and he turns to you and grins before saying, \"`4They shall suffer on the next new day... my magics are strong.`\$\"");
			set_module_pref("hasbeencursed",1,false,$row['acctid']);
			set_module_pref("hascursed",1);
			systemmail($row['acctid'],"`\$You have been cursed!",array("%s`7 has paid a necromancer to lay a curse on you!",$session['user']['name']));
		}
		addnav("Back Away","runmodule.php?module=darkden&op=shop");
		break;
		case "redelixir":
		page_header("Necromander's Shop");
		$redelixircost=get_module_setting("redelixircost");
		if ($session['user']['maxhitpoints']<($session['user']['level']*10 + $redelixirscost)) {
			output("`\$The Necromancer takes one look at you and sneers, \"`4The blood I would drain would kill you, fool.`\$\"");
			output("Realising the truth of his words, you back away.");
		} elseif ($session['user']['gold']<($redelixirscost*1000)) {
			output("`\$The Necromancer takes one look at you and sneers, \"`4I don't make elixirs for charity, fool. Do not dare waste my time.`\$\"");
			output("Realising you do not have enough gold, you back away.");
		} else {
			output("`\$The Necromancer looks at you and nods, before taking your gold and motioning you towards a disturbingly stained bowl.");
			output("You feel light-headed as the blood is drained from you, and sit down as the Necromancer constructs the elixir.");
			output("`n`nYou quaff it and jump up, filled with aggression, if not energy. You gain a player verses player fight!");
			$session['user']['maxhitpoints']-=$redelixircost;
			$session['user']['gold']-=$redelixircost*1000;
			$session['user']['playerfights']++;
			debuglog("spent ($redelixircost*1000) on a Red Elixir and gained a PvP.");
			set_module_pref("redelixirs",(get_module_pref("redelixirs")+1));
		}
		addnav("Back Away","runmodule.php?module=darkden&op=shop");
		break;
		case "bindingsigil":
		page_header("Necromancer's Shop");
		$cost=get_module_setting("bindingsigilcost");
		if ($session['user']['gems']<$cost) {
			output("`\$The Necromancer sneers at you as you approach and takes a firm grip on the dagger. Following his eyes, you see that you do not have enough gems, and beat a hasty retreat from him.");
		} else {
			output("`\$The Necromancer sneers at you as you approach and takes a firm grip on the dagger. When you produce the gems, his expression lightens a little, and he thrusts the Sigil into your hands, muttering something about not using it on its own while pocketing the gems.");
			output("You feel a little bewildered, and he snarls at you when you stand there, too close to his items. You return to a safe distance before thinking again about what you just bought and pocketing it.");
			set_module_pref("bindingsigil",(get_module_pref("bindingsigil")+1));
			$session['user']['gems']-=$cost;
			debuglog("spent $cost gems buying a Sigil of Binding.");
		}
		addnav("Back Away","runmodule.php?module=darkden&op=shop");
		break;
		case "dragonteeth":
		page_header("Anyanka's Shop");
		$cost=get_module_setting("dragonteethcost");
		if ($session['user']['gems']<$cost) {
			output("`\$The Necromancer sneers at you as you approach and takes a firm grip on the dagger. Following his eyes, you see that you do not have enough gems, and beat a hasty retreat from him.");
		} else {
			output("`\$The Necromancer sneers at you as you approach and takes a firm grip on the dagger. Even when you produce the gems, he keeps a hold of the dagger, his eyes flickering only to snatch the gems from you.");
			output("`n`nHe throws a pouch filled with somewhat gory Dragon's Teeth, obviously from one killed recently. Wincing a little, you back away as you carefully pocket the pouch.");
			set_module_pref("dragonteeth",(get_module_pref("dragonteeth")+1));
			$session['user']['gems']-=$cost;
			debuglog("spent $cost gems buying a pouch of Dragon's Teeth.");
		}
		addnav("Back Away","runmodule.php?module=darkden&op=shop");
		break;
		case "darkaid":
		page_header("Necromancer's Shop");
		$darkaidcost=get_module_setting("darkaidcost");
		if ($session['user']['gems']<$darkaidcost) {
			output("`\$The Necromancer sneers at you as you approach and takes a firm grip on the dagger. Following his eyes, you see that you do not have enough gems, and beat a hasty retreat from him.");
		} elseif (($session['user']['deathpower']<50)&&(!get_module_pref("darkdeal"))) {
			output("`\$The Necromancer sneers at you as you approach and takes a firm grip on the dagger. After going into a trance for a moment, he spits at you and mutters that you are not worthy to gain such an item.");
		} else {
			output("`\$The Necromancer sneers at you as you approach and takes a firm grip on the dagger. After going into a trance for a moment, he snatches the gems from you and thrusts the Skull towards you, only muttering something about your being favoured beyond your merits.");
			output("After looking at his expression, you back away to look around once more.");
			debuglog("spent $darkaidcost gems on a Skull of Ramius.");
			set_module_pref("darkaid",(get_module_pref("darkaid")+1));
			$session['user']['gems']-=$darkaidcost;
		}
		addnav("Back Away","runmodule.php?module=darkden&op=shop");
		break;
		case "breakdeal":
		page_header("The Mausoleum");
		if (get_module_setting("darkdealevil")) {
			output("`)The gaze of Ramius fixes upon, you, pitiful soul that you are, and calmly says, \"`7You wish to be free of me then, slave? Then go free.... and curse your soul!`)\"");
			output("`n`nA great wind seizes you, and you are blasted out of the mausoleum, the dark power you were granted gone, the gifts destroyed. Once again a lone soul, you drift back to the shades, alone.");
			$session['user']['deathpower']=0;
			$session['user']['gravefights']=0;
			$session['user']['soulpoints']=0;
			set_module_pref("darkaid",0);
			set_module_pref("dragonteeth",0);
			set_module_pref("bindingsigil",0);
			set_module_pref("hasbeencursed",1);
			set_module_pref("darktoken",0);
			set_module_pref("darkdeal",0);
			set_module_pref("darkness",(get_module_pref("darkness")*0.5));
		} else {
			$session['user']['deathpower']=0;
			set_module_pref("darkaid",0);
			set_module_pref("hasbeencursed",1);
			set_module_pref("darktoken",0);
			set_module_pref("darkness",(get_module_pref("darkness")*0.8));
			output("`)The gaze of Ramius fixes upon, you, pitiful soul that you are, and calmly says, \"`7You wish to be free of me then, slave? Then go free of all I have given you - your soul is mine for eternity!`)\"");
			output("`n`nA great wind seizes you, and you are blasted out of the mausoleum, the gifts destroyed. As you drift back to the shades, you desperately think of your only chance of redemption - Anyanka the Mystic might be able to heal you, if you learn her art.");
		}
		addnav("Return to the Shades","shades.php");
		break;
		case "darkdealconfirm":
		page_header("Necromancer's Shop");
		$cost=get_module_setting("darkdealcost");
		output("`\$The Necromancer sneers at you as you approach and takes a firm grip on the dagger. However, when you state your intentions, he turns slightly paler than he was, if that's possible, and turns away.");
		output("`n`n\"`4You wish to serve the Master directly then.... you should be aware that this is not a commitment to be entered into lightly; You shall pay in blood, and I cannot say if you will be able to back out if your decision is foolish.");
		output("There is a tithe of blood each day that you serve the Master.... %s marks every day in exchange for power each day and on demand, although for a cost, and the favour of the Master.",$cost);
		if (($session['user']['gems']<($cost*2))OR($session['user']['gold']<($cost*10000))) {
			output("`\$\", here he licks his lips nervously before continuing, \"`4Naturally there is a material commitment you must also make, a mere %s gold and %s gems..... but I see that you lack the funds for this. Do not dare waste my time.`\$\"",$cost*10000,$cost*2);
			output("`n`nHe turns away snarling, but seems slightly relieved.");
		} elseif ($session['user']['maxhitpoints']<($session['user']['level']*10 + $cost)) {
			output("`\$\", here he licks his lips nervously before continuing, \"`4Naturally there is a material commitment you must also make, a mere %s gold and %s gems..... but I see that you lack the strength for the ritual. Do not dare waste my time.`\$\"",$cost*10000,$cost*2);
			output("`n`nHe turns away snarling, but seems slightly relieved.");
		} elseif (get_module_pref("skill","specialtydarkarts")<16) {
			output("`\$\", here he licks his lips nervously before continuing, \"`4Naturally there is a material commitment you must also make, a mere %s gold and %s gems..... but I see that you lack the skill for the ritual. Do not dare waste my time.`\$\"",$cost*10000,$cost*2);
			output("`n`nHe turns away snarling, but seems slightly relieved.");
		} else {
			output("`\$\", here he licks his lips nervously before continuing, \"`4Naturally there is a material commitment you must also make, a mere %s gold and %s gems..... and I see that you have the skill, funds and strength for the ritual. Do not dare waste my time. If you wish to back out, say so now.`\$\"",$cost*10000,$cost*2);
			output("`n`nHe turns away snarling, but seems slightly scared. If you wish to take the ritual, do not choose to do so lightly - the consequences may be severe.");
			addnav("Perform the Ritual","runmodule.php?module=darkden&op=darkdeal");
		}
		addnav("Back Away","runmodule.php?module=darkden&op=shop");
		break;
		case "darkdeal":
		page_header("Necromancer's Shop");
		$cost=get_module_setting("darkdealcost");
		$goldcost=$cost*10000;
		$gemscost=$cost*2;
		if ($session['user']['gold']<$goldcost) {
			output("`\$As you step forward to perform the ritual, the necromancer points to your gold pouch, which has magically emptied itself. How on earth did that happen! You back away, embarrassed.");
		} else {
			output("`\$As you step forward to perform the ritual, the necromancer grabs your gold and gems before counting them quickly, throwing glances in your direction before pocketing the lot.");
			output("You spend hours together preparing the ritual, inscribing runes and glyphs of warding around the chamber. Part of your blood is drained, and made into some hideous elixir by the Necromancer in a secret ritual while you meditate.");
			output("Drinking the elixir, you taste poisons burning your throat as you collapse, your vision fading, your last sight the sneering face of the Necromancer.");
			output("`n`n`)After what seems like an eternity, you wake, drifting as a greyish soul in the Mausoleum of `\$Ramius`).");
			output("His great eyes fix on you, and he says, \"`7You shall serve me well... and be rewarded in turn. But be aware, to stray from this Dark Path now you have committed yourself shall bring my wrath upon you.... now go, back to my servant in the realm above.`)\"");
			output("`n`n`&You wake up, seemingly much later, on the cold stone floor, the Necromncer's eyes burning into you. A Dark energy suffuses your soul, and you feel great powers!");
			$session['user']['gold']-=$goldcost;
			$session['user']['gems']-=$gemscost;
			$session['user']['maxhitpoints']-=$cost;
			$session['user']['deathpower']+=50;
			set_module_pref("darkdeal",1);
			debuglog("spent $gemscost gems, $goldcost gold and $cost permanant hitpoints entering into a dark deal with Ramius.");
		}
		addnav("Look Around","runmodule.php?module=darkden&op=shop");
		break;
		case "leaveshop":
		page_header("Necromancer's Shop");
		output("`\$Feeling a little closed in by the oppressive atmosphere in the single chamber, you ask, as nicely as you can, where the way out is.");
		output("The Necromancer makes a sickly grin, and you feel rather than see the presence of something behind you. As you go to turn, blackness engulfs you, and you see no more.");
		output("`n`n`&You come to behind a bush somewhere, surrounded by a strange mist. Gathering yourself, you get up and check your stuff.");
		addnav("Look Around","forest.php");
		break;
		default:
		page_header("How did you get here?");
		output("`@In a shower of sparks and cheap-looking special effects Sneakabout appears before you in a somwehat tatty wizards robe.");
		output("\"`^What are you doing here? Don't you know that you're meant to be shopping at the Necromancer's store? Stop lazing around!`@\"");
		output("With that he disappears back to wherever he came from with a wave of his cloak, obviously through a trapdoor pathetically concealed in the floor.");
		output("`n`nThere is nothing interesting here. Why not go back to the village?");
		addnav("Return to the Village","village.php");
		break;
	}
	page_footer();
}

?>