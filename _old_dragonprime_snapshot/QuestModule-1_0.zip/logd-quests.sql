# phpMyAdmin MySQL-Dump
# version 2.2.7-pl1
# http://phpwizard.net/phpMyAdmin/
# http://www.phpmyadmin.net/ (download page)
#
# Host: localhost
# Generation Time: May 17, 2004 at 05:00 PM
# Server version: 3.23.58
# PHP Version: 4.2.3
# Database : `logd`
# --------------------------------------------------------
#
# Table structure for table `quests`
#
CREATE TABLE quests (
  qid int(11) NOT NULL auto_increment,
  title tinytext NOT NULL,
  filename tinytext NOT NULL,
  dks tinyint(4) NOT NULL default '0',
  level tinyint(4) NOT NULL default '0',
  ff tinyint(4) NOT NULL default '0',
  challenge tinytext NOT NULL,
  retry int(1) NOT NULL default '0',
  PRIMARY KEY  (qid)
) TYPE=MyISAM;