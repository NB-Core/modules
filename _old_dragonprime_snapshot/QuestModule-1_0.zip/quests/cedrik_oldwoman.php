<?php
require_once "common.php";
//  -------------------------------------------------------------------------
//  | Title:  Cedrik's Delivery:  Old Womand in the Forest
//  | Written By:  Brian Austin
//  | Version:  1.0
//  | 
//  | Description:  
//  |   Cedrik needs your help!   Deliever some supplies to the old lady
//  |   who lives deep in the forest.   But beware the path is fraught
//  |   with danger, and grizzly bears!
//  |   
//  -------------------------------------------------------------------------

define(MAXACT, 7);

page_header($questInfo[title]);
addnav("Special Adventure");

//Make sure you always start with Act 0 (default)
if($HTTP_GET_VARS[act]>=0)
	$act = $HTTP_GET_VARS[act];
else	
	$act = 0; 

//---------------------------------
//       Standard Messages:
//---------------------------------
$standardFailMessage = "`c`b`&You run off screaming like a little girl!`0`b`c`n`n`7As your father once said you've got to know when to walk away, and know when to run.  You decide that now is as good a time as any and make tracks back to the village.  Unfortunately, because of your failure the `5Old Woman in the Forest`7 will be eating only goat tonight.   Cedrik has lost some faith you.";
		
$standardDefeatMessage = $session[user][name]."`5 was killed by a ".$badguy['creaturename']."`5 while trying to make a delivery for Cedrik.";


if ($HTTP_GET_VARS[op]==""){	
	//Intro text
	output("`n`n`^`c`bCedrik needs you to run an errand`b`c");
	output("`7`n`nOne afternoon while sitting in the tavern, Cedrik walks over to you and asks, \"`&Hey kid, how would you like to earn a little extra money?`7\"`n`nNot being one to turn down a quick buck, you say yes and Cedrik sits down across from you and begins whispering.`n`n`&There is an old woman who lives outside of town.   Now this old lady is kinda odd, and most folks in the town don't talk kindly of her.   But she is one of my best customers, and I'm willing to go a little bit out of my way for her.   What I need you to do is take this load of supplies out to the old woman's cottage.   Now be warned, the cottage is in a dark and remote part of the forest.   You can never really be to sure what lurks about in the shadows, so I suggest you take caution.     If you can deliverer the supplies to the old lady, and return to the tavern in one piece, I will give you 300 gold for the effort.`7`n`nWhat do you say?`n`n");
		
	addnav("Yes", "quests.php?quest=load&questnum=".$questInfo[qid]."&op=continue&act=1", true);
	addnav("No", "quests.php?quest=load&questnum=".$questInfo[qid]."&op=decline", true);

}else if ($HTTP_GET_VARS[op]=="continue" ){	
	//This is where all the dialog goes
	if ($act==1){
		//Act 1 - Get lost in the forest
		output("`7`n`nYou grab the box full of supplies and head off into the forest.  As you make your way down the trail you notice a massive pile of bodies, most from forest fights of previous warriors.   You look around on the ground for any spare change that might have been dropped, but fail find anything.`n`nAfter a few miles, you pull out the directions that Cedrik gave you and start reading them over again to yourself.   `n`n\"`&Hmm� take a right at the granite boulder, then down the hill to where the old oak tree with an owl living in it is� `7\"  You raise your head and realize that you're no where near where you're supposed to be, and worse you are `4LOST`7!!  Panic begins to sink in as you recall the words Cedrik spoke to you, \"`&Remember the 3 magic words: Klaatu, Barrada, Nikto`7\".`n`n", true);   

		output("\"`&Hmm, that doesn't seem right`7\" you think to yourself.  \"`&Didn't he say something about horrible monsters?`7\"`n`nThe trail you were following disappears, and you find yourself in the thick underbrush of the forest.   As you stager around with the box in your hand, small tree limbs start smacking you in the face, and you get really annoyed.   So you drop the box of supplies with a loud clank and wander off looking for some sort of landmark.`n`nAfter a few minutes, you come to a deep gorge.   There doesn't appear to be any way across it at this point, but in the distance, you can see an old wooden bridge.   You decide to give that a try, and quickly grab the orphaned box and head toward the bridge.`n`nWhen you arrive, you realize that it hasn't been used in years, and could be very dangerous.`n`nDo you attempt to cross here, or walk on further and find another way around?", true);
		debuglog("began the quest to make a delievery to the old woman in the forest");
		addnav("Cross the bridge", "quests.php?quest=load&questnum=".$questInfo[qid]."&op=continue&act=2", true);
		
		if($session[user][turns] < 6)
			output("`n`nYou are too tired to find another way across`n`n");
		else
			addnav("Find another way around", "quests.php?quest=load&questnum=".$questInfo[qid]."&op=continue&act=3", true);




	}else if ($HTTP_GET_VARS[act]=="2" ){
		//Walk across the bridge
		output("`7`n`nYou make your way on to the bridge.   As you carefully step on each plank, you hear a loud creaking sound.   The bridge sways from side to side in the breeze.   You close your eyes and start praying that the bridge will hold your weight.`n`nAs you step on a plank, it cracks and gives way beneath you.  You deftly juggle the box of supplies and keep yourself from falling through the hole.   You keep repeating to yourself \"`&There's no place like home, there's no place like home`7\".   Suddenly you hear a bird cry and peak open you eyes to see, just then the support lines snap and the bridge drop a few inches.     You notice that the lines have become frayed over the years and probably aren't as strong as they used to be.`n`n", true);

		//20% chance of dying on the bridge
		$chance = e_rand(1, 100);		
		if($chance > 20){
			//Success
			output("You take another step forward and are surprise to find that the bridge holds your weight.  You quickly and smoothly make your way to the other side.   As you wipe the sweat from your brow, you find yourself finally able to breathe again.`n`n", true);
			addnav("Continue", "quests.php?quest=load&questnum=".$questInfo[qid]."&op=continue&act=4", true);
			debuglog("managed to make it across the treacherous bridge");
		}else{		
			//Failure
			output("You take another step forward and the right most support line snaps in two.   The bridge pitches over on its side and you drop the box of supplies.   As the box goes sailing of into the gorge, you hang on with your free hand for dear life.    As your hand begins to burn and sting, you start to lose your grip.   With all your might you try to hang on, but the strain is too much.   Your hand slips and you fall into the gorge to your death.`n`n", true);
			output("`^`c`b(You have died!)`b`c`7");
			addnews($session[user][name]."`5 fell to ".($session[user][sex]?"her":"his")." death while trying to make a delivery for Cedrik!");
			$session[user][alive] = 0;
			$session[user][hitpoints] = 0;
			addnav("Daily News", "news.php", true);
			debuglog("died on the bridge, trying to deliver to the old woman");
		}

	}else if ($HTTP_GET_VARS[act]=="3" ){
		//Find another way around
		debuglog("decided not to cross the bridge and find another way around");
		$chance = e_rand(1, 100);		
		if($chance <= 20){
			output("`7`n`nYou decide that it's too dangerous to try and cross the bridge here, so you walk on down the trail further until you find an old cable running across the gorge.   You figure that this must have been left over from some earlier mining operation, and hop inside the ore bucket hanging from the cable.`n`nWith a huge push, you propel yourself over the gorge.   When you reach the other side, you quickly hop out and head on your way.", true);

			addnav("Continue", "quests.php?quest=load&questnum=".$questInfo[qid]."&op=continue&act=4", true);

		}else if($chance > 20 && $chance <= 40){
			output("`7`n`nYou decide that it's too dangerous to try and cross the bridge here, so you walk on down the trail further until you find an old abandoned mine car.   You hop inside the mine car and try to release the brake, but it's too rusty.  You pull out your {weapon} and give it a good smack.   Suddenly the mine car lurches forward and you head down into the mine.    As you fly past the large timbers supporting the mine, you can hear low hanging objects whizzing over you head.   You duck down and hope that nothing hits you.", true);   

			output("`n`nThe mine car flies off the tracks and you are hurled forward into a stone wall head first.   As you lie on the ground, head bleeding profusely, you wonder why you ever bothered to help Cedrik in the first place.  Soon you feel your vision grow dim as you slip in to unconciousness.",true);

			output("`^`c`b(You have died!)`b`c`7");
			addnews($session[user][name]."`5 went on a delivery for Cedrik and never returned!");
			$session[user][alive] = 0;
			$session[user][hitpoints] = 0;
			addnav("Daily News", "news.php", true);
			debuglog("died in the mine car, trying to deliver to the old woman");

		}else if($chance > 40 && $chance <= 60){
			output("`7`n`nYou decide that it's too dangerous to try and cross the bridge here, so you walk on down the trail further until you find an old abandoned mine car.   You hop inside the mine car and try to release the brake, but it's too rusty.  You pull out your {weapon} and give it a good smack.   Suddenly the mine car lurches forward and you head down into the mine.    As you fly past the large timbers supporting the mine, you can hear low hanging objects whizzing over you head.   You duck down and hope that nothing hits you.", true); 

			output("`n`nThe mine car burst out of the tunnel, across a rickety trestle bridge and down a hill to the end of the tracks.   As the mine car slams to a halt, you are thrown from it and into a large oak tree sitting nearby.   After you regain consciousness, you dust yourself off and grab your things.   Miraculously the box of supplies is not damaged.    You also notice that you have somehow managed to make it to the other side of the gorge.",true);

			addnav("Continue", "quests.php?quest=load&questnum=".$questInfo[qid]."&op=continue&act=4", true);

		}else if($chance > 60 && $chance <= 80){
			output("`7`n`nYou decide that it's too dangerous to try and cross the bridge here, so you walk on down the trail further until you find a large rope swing, unbelievably placed by the edge of the gorge.    Knowing that no one in their right mind would put such a thing in such a place you surmise only two explainations.   Either someone was careless and left this here, or it's a trick.    Seeing no other alternative you grab hold of the rope and attempt to swing across the gorge like Tarzan.", true);

			output("`n`nAs you swing across the gorge, you are careful not to look down.    Once you're close enough to the other side you release the rope and land safely on the other side.    \"`&Hmm, well I guess that worked out`7\" you think to yourself.",true);

			addnav("Continue", "quests.php?quest=load&questnum=".$questInfo[qid]."&op=continue&act=4", true);

		}else if($chance > 80 && $chance <= 100){
			output("`7`n`nYou decide that it's too dangerous to try and cross the bridge here, so you walk on down the trail further until you find a large rope swing, unbelievably placed by the edge of the gorge.    Knowing that no one in their right mind would put such a thing in such a place you surmise only two explainations.   Either someone was careless and left this here, or it's a trick.    Seeing no other alternative you grab hold of the rope and attempt to swing across the gorge like Tarzan.", true);

			output("`n`nAs you swing across the gorge, you carelessly look down.   You're so overcome by how deep the gorge is that you fail to see the tree heading straight for you.   Will all the gusto of a medieval warrior you do a face plant into the tree.    You are knocked unconscious for a while, and when you wake up you still feel a bit woozy.",true);

			$session[user][hitpoints] = round(($session[user][hitpoints]/2));
			output("`^`c`b(You have lost hit points!)`b`c`7");
			addnav("Continue", "quests.php?quest=load&questnum=".$questInfo[qid]."&op=continue&act=4", true);
		}

		//lose 3 turns for avoiding danger
		$session[user][turns] -= 3;		

	}else if ($HTTP_GET_VARS[act]=="4" ){
		//Mr Bear
		output("`7`n`nThe forest on the other side of the gorge is even thicker and darker than the previous one.   You carefully check to make sure your weapon is still on your back, and head deeper into the forest.   As you walk along you hear the faint grunts and groans of some creature.  As the noises get louder, your pulse quickens in anticipation of what could be certain death.`n`nSuddenly you emerge from the forest in a small clearing and see a large grizzly bear munching on a blueberry bush.   The grizzly raises his head and looks at you.    You carefully stand your ground and the grizzly bear sniffs at your body.", true);

		//20% chance of the bear will leave you alone
		$chance = e_rand(1, 100);		
		if($chance > 20){
			output("The grizzly bear loses interest in you and goes back to his blueberry bush.   You carefully back away, out into the forest.   Then you head on your way.`n`n", true);
			addnav("Continue", "quests.php?quest=load&questnum=".$questInfo[qid]."&op=continue&act=5", true);
			debuglog("was spared by the Grizzly Bear");
		}else{
			output("The grizzly bear smells fear on your body and takes a swipe at you with his razor sharp claws.`n`n", true);
			//Clear badguy array	
			$session['user']['badguy']=array();
			//Set badguy values
			$badguy['creaturename']    = "Grizzly Bear";
			$badguy['creaturelevel']   = 4;
			$badguy['creatureweapon']  = "Razor Sharp Claws";
			$badguy['creaturelose']    = "I like bears on unicycles better";
			$badguy['creaturewin']     = "Roawrrrr!!!!!";
			$badguy['creaturegold']    = 162;
			$badguy['creatureexp']     = 45;
			$badguy['creaturehealth']  = 47;
			$badguy['creatureattack']  = 8;
			$badguy['creaturedefense'] = 7;
			$badguy['playerstarthp']   = $session['user']['hitpoints'];

			calcHandicap($questInfo[level]);
			//Set other values for battle
			$session['user']['badguy']=createstring($badguy);
			$badguy['diddamage']=0;
			$battle=true;
			debuglog("had to fight the grizzly, while trying to deliver to the old woman");
		}

	}else if ($HTTP_GET_VARS[act]=="5" ){
		//The Woodsman

		output("`7`n`nQuickly you move away from the forest clearing and find another path running through the woods.   You can't imagine your luck as it appears to be the trail you were supposed to follow.    As you head down the trail you come upon a woodsman.`n`nThe woodsman is carrying an ax, and appears to have found a wounded deer in the forest.  He is startled by your sudden appearance, but then calls out to you \"`&Hail friend, what brings you around these parts?`7\".`n`nYou explain to him that you are on a delivery mission for Cedrik, and are supposed to take this load of supplies to the old woman in the forest.   He tells you that your nearly there, and that the old woman's cottage is just a few miles up the road.`n`n\"`&Before you leave`7\", he quickly adds.    \"`&I was wondering if you would do me a favor and hold this deer while I slaughter him.   He will feed my family for a week!`7\" he exclaims.   But then you look into the deer's eyes and see the sadness.  It's almost as if the deer is begging you to set it free.`n`nWhat do you do?", true);

		addnav("Slay the deer", "quests.php?quest=load&questnum=".$questInfo[qid]."&op=continue&act=6", true);
		addnav("Set the deer free", "quests.php?quest=load&questnum=".$questInfo[qid]."&op=continue&act=7", true);

	}else if ($HTTP_GET_VARS[act]=="6" ){
		//Kill Bambi
		output("`7`n`nYou do as the woodsman asked, and hold the dear while he chops off its head.   The woodsman then takes his knife and carves up the deer.   He offers you some of the venison which you gladly accept (hey, your kinda hungry).`n`nYou as you walk off with your box and deer meat, you munch happily on the venison and whistle a merry tune.   You feel invigorated, and ready to take on anything.`n`n", true);
		output("`^`c`b(You have gained +5 MaxHitPoints!)`b`c`7");
		$session[user][maxhitpoints] += 5;
		$session[user][hitpoints] += 5;
		addnav("Continue", "quests.php?quest=load&questnum=".$questInfo[qid]."&op=continue&act=9", true);
		debuglog("gained 5 HPs by chosing to slay the deer, trying to deliver to the old woman");

	}else if ($HTTP_GET_VARS[act]=="7" ){
		//Save Bambi
		debuglog("chose to fight the woodsman in the forest");
		output("`7`n`nYou reach down to free the deer, but the woodsman stops you and says \"`&I'm afraid I can't let you do that, friend`7\".  You draw your ".$session[user][weapon]." and politely insist that he let the poor creature go.   He mumbles something about a tree huger and charges at you with his axe!`n`n", true);

		//Clear badguy array	
		$session['user']['badguy']=array();
		//Set badguy values
		$badguy['creaturename']    = "Angry Woodsman";
		$badguy['creaturelevel']   = 3;
		$badguy['creatureweapon']  = "Wood Chopping Axe";
		$badguy['creaturelose']    = "Man that guy really needed a shower";
		$badguy['creaturewin']     = "Ha Ha!  Now all the delicious venison will be mine!";
		$badguy['creaturegold']    = 148;
		$badguy['creatureexp']     = 32;
		$badguy['creaturehealth']  = 34;
		$badguy['creatureattack']  = 5;
		$badguy['creaturedefense'] = 4;
		$badguy['playerstarthp']   = $session['user']['hitpoints'];

		calcHandicap($questInfo[level]);
		//Set other values for battle
		$session['user']['badguy']=createstring($badguy);
		$badguy['diddamage']=0;
		$battle=true;

	}else if ($HTTP_GET_VARS[act]=="8" ){
		//Bambi Saved
		output("`7`n`nYou walk past the woodsman's dead body and over the frightened deer.   As you untie the rope around its neck, the beast speaks to you in a soft and soothing tone.`n`n\"`&Thank you for freeing me from the woodsman.   For your kindness I will give you this special potion which will help you avoid harm in the forest.`7\"`n`nYou thank the deer, and quickly quaff the vial.    You feel better able to defend yourself.`n`nAs the deer runs off, you quickly gather your things and head toward the old woman's cottage.`n`n", true);
		output("`^`c`b(You have gained +1 Defence Point!)`b`c`7");
		$session[user][defence] ++;	
		addnav("Continue", "quests.php?quest=load&questnum=".$questInfo[qid]."&op=continue&act=9", true);
		debuglog("gained 1 defence point by saving the deer, while trying to deliver to the old woman");
	
	}else if ($HTTP_GET_VARS[act]=="9" ){
		//Success!!
		output("`n`n`7The path to the cottage is lined with small white stones, and on either side is a pleasant looking garden.   By the door, you see several small goats tied to a post, and the old woman is standing in front of the door waiting on you.`n`n\"`&It's about time you got here`7\", she screeches. \"`&Cedrik promised me those pickle jars and magic goat weed weeks ago.`7\"`n`n Until now you hadn't noticed what was in the box, but sure enough it's filled with pickle jars, some awful smelling yellow grass, a few spools of yarn, a tin funnel and a couple of boxes of odds and ends.`n`n\"`&I can't believe I risked my life for this crap,`7\" you blurt out! \"`&What are you going to do with all this junk anyway?`7\" you ask the woman.`n`n\"`&Never you mind sonny,`7\" she coos.   \"`&Here's you a nice shiny quarter for your trouble.`7\" She says as she drops the metal coin in your hand.", output);

		if($session[user][armordef] >= 6){
			output("`n`nYou're tempted to do something drastic with the coin, but you calm yourself down and put the coin in your pocket.    The old lady shows you a short cut back through the forest, and soon enough you are back in the village.", true);
			//Add a blurb to the news
			debuglog("had good armour so they didn't anything from the old woman in the forest");
			addnews($session[user][name]."`5 has successfully delievered supplies to the `5Old Woman in the Forest`5!");
		}else{
			output("`n`n\"`&What the heck is this crap!`7\" You scream at the old lady.`n`n\"`&Now, now son, it's not nice to scream at your elders. I tell you what, for your bravery will give you this fine new goat skinned cloak that I made.   It's a strong and dependable, and will provide you with a defense level of 6.   All for the low, low price of free.`7\"`n`nGrudgingly you accept the goat skinned coat and head back to the village.   Luckily, the old lady shows you a short cut and before long you are back in front of the inn.`n`n", true);
			output("`^`c`b(You have the goat skin cloak!)`b`c`7");
			addnews($session[user][name]."`5 has returned from the forest with the foul smell of goat covering ".($session[user][sex]?"her":"him").".");

			debuglog("player recieved the goat skin cloak from the old woman");	
			$session[user][armor] = "Goat Skin Cloak";			
			$session[user][armorvalue] = "2250";
			$session[user][defence]-=$session[user][armordef];
			$session[user][armordef] = 6;
			$session[user][defence] += $session[user][armordef];
		}

		addnav("Continue", "quests.php?quest=load&questnum=".$questInfo[qid]."&op=continue&act=10", true);

	}else if ($HTTP_GET_VARS[act]=="10" ){
		output("`7`n`nYou head over to the inn and go see Cedrik.   He laughs at your story about the forest and warns you that it's not nice to make up tall tales.    Then he takes the coin and carefully places it on a huge placard over the bar.`n`n\"`&What's all that about you ask?`7\"`n`n\"`&Oh that's just my Legend of the Green Dragon Official Quarter Collection.  That was the last one I needed to have a complete set.`7\"`n`nDumbfounded you stick out your hand and ask for payment.    Cedrik forks over the 300 gold and you head out the door, disgusted with the entire affair.`n`n", true);		
		
		
		//Update the user's quest history
		updateQuest($questInfo[qid]);		
		//Give the user some gold 
		output("`^`c`b(You received your payment of 300 gold!)`b`c`7");
		$session[user][gold]+= 300;	
		$session[user]['turns'] = $session[user]['turns'] - $questInfo[ff];
		addnav("Back to Village", "village.php", true);	
		debuglog("got 300 gold for their trouble");

	}else{
		//Otherwise go back to intro screen
		output("`7`n`nAn unknown error ocurred.  Please try again.`n`n");	
		addnav("Continue", "quests.php?quest=load&questnum=".$questInfo[qid], true);
	}
}else if ($HTTP_GET_VARS[op]=="decline"){
	output("`7`n`nYou decide that this delivery business is too dangerous for you, so you thank Cedrik for the offer and tell him maybe some other time.", true);
	debuglog("declined to deliver to the old woman");
	addnav("Back to Village", "village.php", true);	
}

if ($HTTP_GET_VARS[op]=="fight" || $HTTP_GET_VARS[op]=="run") $battle=true;

if ($HTTP_GET_VARS[op]=="run"){
	if (e_rand()%3 == 0){
		output ($standardFailMessage, true);
		output ("`n`n`c`b`^(You have failed to complete the quest)`c`b`7");
		$HTTP_GET_VARS[op]="";
		$battle = false;
		addnav("Go home", "quests.php", true);
		debuglog("ran away and failed to deliver to the old woman");
	}else{
		output("`c`b`\$You failed to flee your opponent!`0`b`c");
	}
}

//Standard battle routines.  Edit only if you need to change battle sequence.
if ($battle){
  include("battle.php");
	if ($victory){
		//Calculate bonus/penalties and gold
		calcBonus();
		$act++;
		addnav("Continue","quests.php?quest=load&questnum=".$questInfo[qid]."&op=continue&act=".$act);
	}else if($defeat){							
		output("`b`&You have been slain by `%$badguy[creaturename]`&!!!`n");
		output("`4All gold on hand has been lost!`n");
		output("`410% of experience has been lost!`n");
		output("You may begin fighting again tomorrow.");

		addnews($standardDefeatMessage);
		addnav("Daily news","news.php");
		
		//Update player can not retry, set the quest history
		if(!$questInfo[retry])
			updateQuest($questInfo[qid]);
	}else{
		questfightnav($questInfo[qid], $act);			
	}
	
}

//Emergency Escape - Take this out when your done
//addnav("Back", "quests.php");
page_footer();
?>