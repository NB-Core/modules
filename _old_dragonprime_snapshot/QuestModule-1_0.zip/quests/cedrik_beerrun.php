<?php
require_once "common.php";
//  -------------------------------------------------------------------------
//  | Title:  Cedrik's Beer Run
//  | Written By:  Brian Austin
//  | Version:  1.0
//  | 
//  | Description:   
//  |   Cedrik's tavern is out of ale!   Help him keep the booze flowing
//  |   and help keep a riot from breaking out in the village.
//  |  
//  -------------------------------------------------------------------------
define(MAXACT, 7);

$query = "SELECT * FROM quests WHERE qid=".$questInfo[qid];
$result = db_query($query);
$questInfo = db_fetch_assoc($result);

if($HTTP_GET_VARS[act]>=0)
	$act = $HTTP_GET_VARS[act];
else	
	$act = 0; //start with this act

//echo "act is ".$act;

page_header($questInfo[title]);
addnav("Special Adventure");


if ($HTTP_GET_VARS[op]=="" ){	
	//Intro text
	output("`n`n`^`c`bThe tavern is out of ale!`b`c");
	output("`7`n`nAfter a long day, hard at work in the forest, you head into `b`5Cedrik`7`b's tavern to have one of his refreshing brews.  As `b`5Cedrik`7`b pulls out a glass and pours it half full.`n`n\"`&Hey!  This glass is half empty`7\" you cry.`n`n\"`&No it's not`7\" `b`5Cedrik`7`b says, insisting that it's half full.`n`n");
	output("Discouraged, you sigh and ask `b`5Cedrik`7`b what gives.`n`n\"`&Well it seems that the last few deliveries of hops and barley have never arrived.   If I don't get some ingredients soon, I won't be able to keep selling my ale.`7\" he sadly tells you.`n`n\"`&Egads`7\" you cry!  We have real situation on our hands.  You realize that if this happens the entire realm will be in uproar.  So you give your assurance to Cedrik that you will go and find out what the problem is, and if possible bring him a wagon load of supplies.");
	output("`n`n`b`5Cedrik`7`b thanks you, and tells you to go to the next village over and talk to a man named `4Lord Budweiser`7.  He will know what to do.  So you strap your ".$session[user][weapon]." to your back and head out of the village. ");
	debuglog("began the quest to deliever brewery supplies");
	addnav("Continue", "quests.php?quest=load&questnum=".$questInfo[qid]."&op=continue&act=1", true);

}else if ($HTTP_GET_VARS[op]=="continue" ){	
	//This is where all the dialog goes
	if ($act==1){
		//Act 1 - Highwayman
		output("`7`n`nYou head out of the town an across the wide and rolling hills that separate your village from its closest neighbor.   As you travel down the road, you notice several burnt out wagons resting by the side of the road.   You chuckle and assure yourself that you are in no danger.`n`nSuddenly a man in a dark outfit springs forth from behind a rock.   He points his rapier at you and demands that you \"stand and deliver\".    Not wanting to disappoint, you reach into your bag and produce your ".$session[user][weapon].".`n`n", true);   

		$session['user']['badguy']=array();

		$badguy['creaturename']    = "Highwayman";
		$badguy['creaturelevel']   = 10;
		$badguy['creatureweapon']  = "Silver Rapier";
		$badguy['creaturelose']    = "Pilfer this! You scream at his bleeding corpse.";
		$badguy['creaturewin']     = "Stand and deliever!";
		$badguy['creaturegold']    = 300;
		$badguy['creatureexp']     = 114;
		$badguy['creaturehealth']  = 105;
		$badguy['creatureattack']  = 19;
		$badguy['creaturedefense'] = 14;
		$badguy['playerstarthp']   = $session['user']['hitpoints'];

		calcHandicap($questInfo[level]);
		$badguy['diddamage']=0;
		$battle=true;
		$session[user][badguy]=createstring($badguy);		
	
	}else if ($HTTP_GET_VARS[act]=="2" ){
		//Act 2 - Keep Guard
		output("`7`n`nAfter that brush with danger, you vow to become more aware of your surroundings.   These highways are probably teeming with thieves.   You make haste and quickly arrive in the neighboring town.`n`nYou ask around and people in the village tell you that `4Lord Budweiser`7 lives in keep near the middle of town.  You head that way, and soon you come upon the large stone keep.  You inform the guard that you are here to see Lord Budweiser.   He asks if you have an appointment, and truthfully, you say that, you don't.  He tells you to take a hike.`n`nHe does mention that he will let you in for a small fee of `^`b400 gold`b`7");   
		output("`n`nDo you:`n`nBribe him`nFight your way past", true);
		addnav("Bribe", "quests.php?quest=load&questnum=".$questInfo[qid]."&op=continue&act=3", true);
		addnav("Fight", "quests.php?quest=load&questnum=".$questInfo[qid]."&op=continue&act=4", true);
	
	}else if ($HTTP_GET_VARS[act]=="3" ){
		//Act 3 - Bribe the Guard		
		output("`7`n`nYou reach into your money pouch for some gold to pay off this rascal.`n`n", true);
		if($session[user][gold] >= 400){
			output("`7You pull out the bribe and hand it to the guard.   He promptly steps aside and opens the door for you.`n`n"); 
			$session[user][gold] =- 400;
			addnav("Enter the Keep", "quests.php?quest=load&questnum=".$questInfo[qid]."&op=continue&act=5", true);
			debuglog("attempted to bribe the guard and succeeded");
		}else{
			output("`7You pull out a few coins and a handful of pocket lint (don't all adventurer's pockets have that?).   The guard shakes his head at you and tells you to get lost.`n`n"); 
			addnav("Fight", "quests.php?quest=load&questnum=".$questInfo[qid]."&op=continue&act=4", true);
			debuglog("attempted to bribe the guard but didn't have enough money");
		}
	}else if ($HTTP_GET_VARS[act]=="4" ){
		output("`7`n`nYou say to yourself \"`&I'm not paying this joker!  Prepare to die!!`7\".`n`n", true);
		$session['user']['badguy']=array();
		$badguy['creaturename']    = "Keep Guard";
		$badguy['creaturelevel']   = 7;
		$badguy['creatureweapon']  = "Decorative Sword";
		$badguy['creaturelose']    = "Oh alright, I'll let you in!";
		$badguy['creaturewin']     = "And stay out!!";
		$badguy['creaturegold']    = 600;
		$badguy['creatureexp']     = 250;
		$badguy['creaturehealth']  = 84;
		$badguy['creatureattack']  = 15;
		$badguy['creaturedefense'] = 11;
		$badguy['playerstarthp']   = $session['user']['hitpoints'];

		calcHandicap($questInfo[level]);
		$badguy['diddamage']=0;
		$battle=true;
		$session[user][badguy]=createstring($badguy);
		
	}else if ($HTTP_GET_VARS[act]=="5" ){
		//Act 4	- Fight Guard	
		output("`7`n`nOnce inside `4Lord Budweiser`7's keep, you quickly make your way up the stairs and into his chambers.    You notice that no one is in the main room, so you quickly make your way through all the rooms searching for him, until you come upon the bathroom.  You peak your head inside and spy and portly man sitting in a bath tub, sipping a tankard of ale, and wearing his hat.  He almost looks like Dom Deluise, you think to yourself.`n`nYou shield your eyes and walk inside the room, excusing yourself for barging in. You explain the situation in the village.    `4Lord Budweiser`7 is sympathetic to your cause and listens carefully about Cedrik's problem.`n`n\"`&Old Cedrik, we'll I'll be!  Why we fought together against the `2Green Dragon`& 20 years ago.  If he needs my help, then I will give him whatever he requires`7\"`4Lord Budweiser`7 explains.`n`nHe instructs you to go down to the stable and take one of his best wagons, and load if full of whatever you need.  But he warns you to be careful about the highway on the way back.`n`n\"`&There are many thieves and they will think your wagon  is easy prey.   Be brave, and be fierce, and you just may survive.`7\", he warns.`n`nYou thank `4Lord Budweiser`7 for his help, and make your way down to the stables.", true);
		addnav("Continue", "quests.php?quest=load&questnum=".$questInfo[qid]."&op=continue&act=6", true);
	
	}else if ($HTTP_GET_VARS[act]=="6" ){
		//Act 2		
		output("`7`n`nYou find the best wagon in the stable, and load it full of hops, barley, and malts.   Then you snap the reigns and make your way back to the road.    As you travel down the road, you notice that the sun is setting, and it will soon be dark.   It's unlikely you will make it back to the village before nightfall, so you draw your ".$session[user][weapon]." and prepare for the inevitable.`n`nNot more than a mile from the town, you come to a small stone bridge.   As you approach, you see three figures jump in front of the bridge.   Behind you, two more spring for from the bushes.  You realize that you are outnumbered, but put faith in your skills as a warrior that you will be victorious.    That's when you notice the troll clamoring onto the bridge.    He beats his chest in a fury and begins walking toward the wagon.`n`n\"`&Troll hungry`7\" be belts out as he pulls out his gigantic club.`n`n", true);
		
		$session['user']['badguy']=array();
		$badguy['creaturename']    = "Bridge Troll";
		$badguy['creaturelevel']   = 14;
		$badguy['creatureweapon']  = "Tree Trunk";
		$badguy['creaturelose']    = "Arrrrgh!!! cries the troll as he slams face-first into the dirt.";
		$badguy['creaturewin']     = "Mmmm....  tasty warrior";
		$badguy['creaturegold']    = 449;
		$badguy['creatureexp']     = 172;
		$badguy['creaturehealth']  = 145;
		$badguy['creatureattack']  = 27;
		$badguy['creaturedefense'] = 20;		
		$badguy['playerstarthp']   = $session['user']['hitpoints'];

		calcHandicap($questInfo[level]);
		$badguy['diddamage']=0;
		$battle=true;
		$session[user][badguy]=createstring($badguy);

	}else if ($HTTP_GET_VARS[act]=="7" ){
		//Act 2		
		output("`7`n`nAfter the troll goes down the other bandits split.  You climb back atop the wagon and continue on your way.    By sunrise, you've reached the village and droves of peasants come out to greet you.   You pull the wagon in behind Cedrik's tavern and hop off and present the goods to him.`n`nCedrik looks at you and smiles, \"`&I knew you could do it!  Because of you, the beer will continue to flow at Cedrik's Tavern.`7\".  He thanks you profusely and offers you some of his special ale for your good deed.`n`n", true);

		output("`^`c`b(You drink the ale and gain an attack point!)`b`c`7");
		$session[user][attack] ++;
		addnews($session[user][name]."`5 has successfully delivered brewery supplies to `b`%Cedrik`7`b.`n`5The people of the village rejoice!!");
		$session[user]['turns'] = $session[user]['turns'] - $questInfo[ff];
		debuglog("succeeded in deliverying brewery supplies to Cedrik and gained an attack point");
		addnav("Back to Village", "village.php", true);
		updateQuest($questInfo[qid]);
	
	}else if ($HTTP_GET_VARS[act]=="8" ){
		//Act 2		
		output("`7You have saved the beer!  The people rejoice!!`n`n  The troll is pretty tough, but if they beat him they will gain a special weapon (troll's axe, which is their current weapon +3)`n`n", true);
		addnav("Continue", "quests.php?quest=load&questnum=".$questInfo[qid]."&op=continue&act=7", true);
	
	}else if ($HTTP_GET_VARS[act]=="9" ){
		//Act 2		
		output("`7You have saved the beer!  The people rejoice!!`n`n  The troll is pretty tough, but if they beat him they will gain a special weapon (troll's axe, which is their current weapon +3)`n`n", true);
		addnav("Continue", "quests.php?quest=load&questnum=".$questInfo[qid]."&op=continue&act=1", true);
	}


}else if ($HTTP_GET_VARS[op]=="search" ){
	//Generic find a monster routine
	$sql = "SELECT * FROM creatures WHERE creaturelevel = 7 ORDER BY rand(".e_rand().") LIMIT 1";
	$result = db_query($sql) or die(db_error(LINK));
	$badguy = db_fetch_assoc($result);

	$badguy['playerstarthp']=$session['user']['hitpoints'];
	$badguy['diddamage']=0;
	$session['user']['badguy']=createstring($badguy);
	$battle=true;

}

if ($HTTP_GET_VARS[op]=="fight" || $HTTP_GET_VARS[op]=="run") $battle=true;

if ($HTTP_GET_VARS[op]=="run"){
	if (e_rand()%3 == 0){
		output ("`c`b`&You run off screaming like a little girl!`0`b`c`n");
		output ("`n`n`7As your father once said you've got to know when to walk away, and know when to run.  You decide that now is as good a time as any and make tracks back to the village.  Unfortunately, because of your failure there will be little beer in Cedrik's tavern.   The townspeople grow angry with you.", true);
		output ("`n`n`c`b`^(You have failed to complete the quest)`c`b`7", true);
		$HTTP_GET_VARS[op]="";
		$battle = false;
		addnav("Go home", "quests.php", true);
		debuglog("got scared and ran away from Cedrik's Brewery Quest like a coward!");
	}else{
		output("`c`b`\$You failed to flee your opponent!`0`b`c");
	}
}

//All the battle routines
if ($battle){
  include("battle.php");
	if ($victory){		
		//Calculate bonus/penalties and gold
		calcBonus();		
		$act++;
		addnav("Continue","quests.php?quest=load&questnum=".$questInfo[qid]."&op=continue&act=".$act);
	}else if($defeat){							
		output("`b`&You have been slain by `%$badguy[creaturename]`&!!!`n");
		output("`4All gold on hand has been lost!`n");
		output("`410% of experience has been lost!`n");
		output("You may begin fighting again tomorrow.");
		debuglog("was killed trying to deliever brewery supplies for Cedrik");
		addnews($session[user][name]."`5 was killed by a ".$badguy['creaturename']."`5 while trying to deliver brewery supplies to `b`%Cedrik`7`b");
		addnav("Daily news","news.php");		
	
		//Update player can not retry, set the quest history
		if(!$questInfo[retry])
			updateQuest($questInfo[qid]);		
	}else{
		questfightnav($questInfo[qid], $act);			
	}	
}

//Emergency Escape - Take this out when your done
if($session[user][superuser] >=3)
	addnav("Back", "quests.php");
page_footer();
?>