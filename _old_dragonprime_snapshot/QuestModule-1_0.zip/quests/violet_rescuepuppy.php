<?php
require_once "common.php";
//  -------------------------------------------------------------------------
//  | Title:  Violet's Lost Puppy
//  | Written By:  Brian Austin
//  | Version:  1.0
//  | 
//  | Description:   Violet has lost her puppy.   In order to gain favor
//  |   with her you must go into the forest and find the little critter.
//  |   But beware, certain unscrupulous parties may be waiting for you.
//  |
//  -------------------------------------------------------------------------
define(MAXACT, 9);

$character = ($session[user][sex]?"`^Seth":"`&Violet");
$sexP = ($session[user][sex]?"his":"her");
$sexI = ($session[user][sex]?"him":"her");
$sex = ($session[user][sex]?"he":"she");

page_header($questInfo[title]);
addnav("Special Adventure");

//Make sure you always start with Act 0 (default)
if($HTTP_GET_VARS[act]>=0)
	$act = $HTTP_GET_VARS[act];
else	
	$act = 0; 

//---------------------------------
//       Standard Messages:
//---------------------------------
$standardFailMessage = "`c`b`&You run off screaming like a little girl!`0`b`c`n`n`7As your father once said you've got to know when to walk away, and know when to run.  You decide that now is as good a time as any and make tracks back to the village.  Unfortunately, because of your failure there ".$character."'s`7 little puppy may never be found.   Your pretty sure this will cost you some charm with ".$character."`7";
		
$standardDefeatMessage = $session[user][name]."`5 was killed by a ".$badguy['creaturename']."`5 while trying to rescue ".$character."'s`7 puppy.";


if ($HTTP_GET_VARS[op]=="" ){	
	//Intro text
	output("`n`n`^`c`b".$character."`^ has lost ".$sexP." dog!`b`c");
	output("`n`n`7One night while sitting in the Inn, you see ".$character."`7 crying off in a corner.  Being the kind soul that you are, you slowly walk over and ask what's the matter.`n`n\"`&Oh, my darling little puppy is gone`7\" cries ".$character."`7. \"`&Yesterday he was playing outside my front door, and then when I went out to pick him up he was GONE`7\", ".$sex." sobs.`n`nOvercome with grief for ".$character."'s`7 loss, you vow to find the lost puppy and return it to ".$sexI.".  ".$sexP." tears stop momentarily and ".$sex." looks at you with big, sad eyes.  You figure it's best if you get on the case, otherwise you might start crying too.", true);	
	debuglog("began the quest to rescue Violet/Seth's puppy");
	addnav("Continue", "quests.php?quest=load&questnum=".$questInfo[qid]."&op=continue&act=1", true);

}else if ($HTTP_GET_VARS[op]=="continue" ){	
	//This is where all the dialog goes
	if ($act==1){
		//Act 1 - Violet's Cottage		
		output("`n`n`7You head over to ".$character."'s`7 cottage and start looking around in the front yard.  As you snoop around several villagers walk by, and whispering to themselves about your stalking around ".$character."'s`7 place.    You pay no attention to their suspicious wonderings and continue your hunt.    You notice the large footprint beside the stone walkway in front of the door.  You follow the footprints around the house and to the edge of the yard.`n`nApparently, whoever decided to take ".$character."'s`7 puppy went out this way, over the wall.   You hop the wall and continue following the trail.  Eventually the trail leads into the woods, and you carefully make your way down the narrow trail until you come to a small encampment of orcs.",true);    

		addnav("Continue", "quests.php?quest=load&questnum=".$questInfo[qid]."&op=continue&act=2", true);


}else if ($HTTP_GET_VARS[act]=="2" ){
		//Act 2 - orc encampment
		output("`n`n`7You stoop behind a rock and start watching the orcs.  After a few minutes you see ".$character."'s`7 little puppy on the table beside a large spread of cabbage, and other vegetables.  Fearing the worst, you surmise that the orcs are going to cook the little guy!`n`nDo you:`n`nSneak in to the camp`nFight your way in", true); 
		
		addnav("Fight", "quests.php?quest=load&questnum=".$questInfo[qid]."&op=continue&act=4", true);
		addnav("Sneak", "quests.php?quest=load&questnum=".$questInfo[qid]."&op=continue&act=3", true);		

}else if ($HTTP_GET_VARS[act]=="3" ){
		//Act 2 - orc encampment
		output("`n`n`7You attempt to use your stealth skills to sneak into the encampment.", true);

		$chance = ($session[user][thievery] * 5)+5;
		$eresult = e_rand(1,100);
		if($eresult <= $chance){
			output("`n`n`7You are successful!   You sneak past the two orcs guarding the camp.  Quietly you draw your ".$session[user][weapon]." and head deep into the camp.", true);
			addnav("Continue", "quests.php?quest=load&questnum=".$questInfo[qid]."&op=continue&act=7", true);
			debuglog("was able to sneak into the orc encampment");
		}else{
			output("`n`n`7You try to sneak into the camp, but you get caught in ropes for the tents.   As you try to free yourself you yank the rope and the entire tent colapses.  The orc standing guard looks at you and then charges with his weapon drawn.", true);
			addnav("Continue", "quests.php?quest=load&questnum=".$questInfo[qid]."&op=continue&act=5", true);
			debuglog("failed to sneak into the orc encampment");
		}

}else if ($HTTP_GET_VARS[act]=="4" ){		
		//Act 2 - orc encampment
		output("`n`nFeeling rather heroic you spring forth from behind the rock, much to the surprise of the orcs.   You race toward the table and a large female orc with her face buried in a cookbook.`n`nBut before you can get there, several orcs step in your way and start yelling at you.   Since you don't understand orc, you figure your ".$session[user][weapon]." will have to do the talking for you!`n`n", true);
		addnav("Continue", "quests.php?quest=load&questnum=".$questInfo[qid]."&op=continue&act=5", true);
		debuglog("decided to barge right into the orc encampment");
		
}else if ($HTTP_GET_VARS[act]=="5" ){
		//Clear badguy array	
		$session['user']['badguy']=array();
		//Set badguy values
		$badguy['creaturename']    = "Angry Orc";
		$badguy['creaturelevel']   = 7;
		$badguy['creatureweapon']  = "Iron pick-axe";
		$badguy['creaturelose']    = "`&Nobody steals ".$character."'s`& dog!";
		$badguy['creaturewin']     = "I think this is a bad sign..";
		$badguy['creaturegold']    = 268;
		$badguy['creatureexp']     = 77;
		$badguy['creaturehealth']  = 74;
		$badguy['creatureattack']  = 13;
		$badguy['creaturedefense'] = 10;
		$badguy['playerstarthp']   = $session['user']['hitpoints'];

		calcHandicap($questInfo[level]);
		//Set other values for battle
		$session['user']['badguy']=createstring($badguy);
		$badguy['diddamage']=0;
		$battle=true;


}else if ($HTTP_GET_VARS[act]=="6" ){
		//Act 2 - Sample Success Message
		output("`n`n`7No sooner than you down the first orc, than another jumps up in his pajamas (I didn't know orcs wore pajamas), and runs at you carrying a half-eaten-hatrack.`n`n", true);

		//Clear badguy array	
		$session['user']['badguy']=array();
		//Set badguy values
		$badguy['creaturename']    = "Sleepy Orc";
		$badguy['creaturelevel']   = 7;
		$badguy['creatureweapon']  = "Half Eaten Hatrack";
		$badguy['creaturelose']    = "A face no mother could love";
		$badguy['creaturewin']     = "I think this is a bad sign..";
		$badguy['creaturegold']    = 268;
		$badguy['creatureexp']     = 77;
		$badguy['creaturehealth']  = 74;
		$badguy['creatureattack']  = 13;
		$badguy['creaturedefense'] = 10;
		$badguy['playerstarthp']   = $session['user']['hitpoints'];

		calcHandicap($questInfo[level]);
		//Set other values for battle
		$session['user']['badguy']=createstring($badguy);
		$badguy['diddamage']=0;
		$battle=true;

}else if ($HTTP_GET_VARS[act]=="7" ){
		//Act 3 - Sample Success Message
		output("`n`n`7Seeing a clear path to the puppy through all the confusion, you make a beeline for the table where the little dog is sitting.  Just then, the mamma orc raises her head from the cookbook, looks at you, then looks at the puppy, and then looks at you again.   She then charges at you screaming something in orc. (it doesn't matter, you learned to tune out a mother years ago)`n`n", true);

		//Clear badguy array	
		$session['user']['badguy']=array();
		//Set badguy values
		$badguy['creaturename']    = "Mamma Orc";
		$badguy['creaturelevel']   = 8;
		$badguy['creatureweapon']  = "Spiked Rolling Pin";
		$badguy['creaturelose']    = "Put him in the stew?  I think not!";
		$badguy['creaturewin']     = "I think this is a bad sign..";
		$badguy['creaturegold']    = 302;
		$badguy['creatureexp']     = 88;
		$badguy['creaturehealth']  = 84;
		$badguy['creatureattack']  = 15;
		$badguy['creaturedefense'] = 11;
		$badguy['playerstarthp']   = $session['user']['hitpoints'];

		calcHandicap($questInfo[level]);

		//Set other values for battle
		$session['user']['badguy']=createstring($badguy);
		$badguy['diddamage']=0;
		$battle=true;
}else if ($HTTP_GET_VARS[act]=="8" ){
		output("`n`n`7After you dispatch the huge mother orc you snatch up ".$character."'s`7 puppy and put him in your bag for safe keeping.    Needing a diversion, you pull a large hock of dried meat from your sack and toss it into the middle of the camp.   The orcs hungrily pounce on it and you slip out of the camp into the woods.`n`nOnce you're back in the village you make your way back to ".$character."'s`7 cottage.   Knowing ".$character."`7 will be happy to see the puppy, you sneak inside and put the puppy right in front of the door.   You then wait until ".$character."`7 comes home.`n`n", true);		

		addnav("Continue", "quests.php?quest=load&questnum=".$questInfo[qid]."&op=continue&act=".MAXACT, true);

}else if ($HTTP_GET_VARS[act]==MAXACT ){

		output("`n`n`7Several hours later, ".$character."`7 comes walking up the path to ".$sexP." cottage, ".$sexP." outfit soaked with beer from tavern.   ".$sex." looks in a horrible mood, so you brace yourself for ".$sexP." fury, forgetting that the little puppy is asleep in front of the door.   When ".$character."`7 opens the door, ".$sex." stops dead in ".$sexP." tracks.   ".$sex." doesn't even notice your sitting inside ".$sexP." house (kinda creepy) and fixes ".$sexP." gaze directly on the little puppy.`n`nThe puppy stirs and starts barking as he runs awkwardly along the floor toward them.   ".$sex." bends down and scoops him up into ".$sexP." arms.    As ".$character."`7 coos him softly, you clear your throat to get ".$sexP." attention.     Startled, ".$sex." looks at you and then realizes you're the one from the Tavern who said you'd go look for the little puppy.   ".$sexP." surprise turns into huge smile and ".$sex." pulls you close and gives you a kiss of gratitude.`n`nOverwhelmed by it all, you try to say something but begin stuttering like an idiot.   As your face turns red you quickly excuse yourself and head down the path, sure that your heroic deeds have garnered you a little favor with ".$character."`7.`n`n", true);		
		
		output("`^`c`b(You receive some charm!)`b`c`7");

		//Update the user's quest history
		updateQuest($questInfo[qid]);
		//Give the user some gold and a gem
		$session[user][charm]+5;

		$session[user]['turns'] = $session[user]['turns'] - $questInfo[ff];

		//Add a blurb to the news
		addnews($session[user][name]."`5 has rescued ".$character."'s`5 puppy from a band of hungry orcs!");
		addnav("Back to Village", "village.php", true);
		debuglog("rescued Violet/Seth's puppy and gained 5 charm");
		

	}else{
		//Otherwise go back to intro screen
		output("`7`n`nAn unknown error ocurred.  Please try again.`n`n");	
		addnav("Continue", "quests.php?quest=load&questnum=".$questInfo[qid], true);
	}
}

if ($HTTP_GET_VARS[op]=="fight" || $HTTP_GET_VARS[op]=="run") $battle=true;

if ($HTTP_GET_VARS[op]=="run"){
	if (e_rand()%3 == 0){
		output ($standardFailMessage, true);
		output ("`n`n`c`b`^(You have failed to complete the quest)`c`b`7");
		$HTTP_GET_VARS[op]="";
		$battle = false;
		addnav("Go home", "quests.php", true);
	}else{
		output("`c`b`\$You failed to flee your opponent!`0`b`c");
	}
}

//Standard battle routines.  Edit only if you need to change battle sequence.
if ($battle){
  include("battle.php");
	if ($victory){
		//Calculate bonus/penalties and gold
		calcBonus();
		$act++;
		addnav("Continue","quests.php?quest=load&questnum=".$questInfo[qid]."&op=continue&act=".$act);
	}else if($defeat){							
		output("`b`&You have been slain by `%$badguy[creaturename]`&!!!`n");
		output("`4All gold on hand has been lost!`n");
		output("`410% of experience has been lost!`n");
		output("You may begin fighting again tomorrow.");

		addnews($standardDefeatMessage);
		addnav("Daily news","news.php");
		debuglog("failed to rescue Violet/Seth's puppy");
		//Update player can not retry, set the quest history
		if(!$questInfo[retry])
			updateQuest($questInfo[qid]);
	}else{
		questfightnav($questInfo[qid], $act);			
	}
	
}

//Emergency Escape - Take this out when your done
if($session[user][superuser] >=3)
	addnav("Back", "quests.php");
page_footer();
?>