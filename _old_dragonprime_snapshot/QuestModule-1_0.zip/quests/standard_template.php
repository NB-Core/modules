<?php
require_once "common.php";
//  -------------------------------------------------------------------------
//  | Title:  Quest Template
//  | Written By:  Brian Austin
//  | Version:  1.0
//  | 
//  | Description:   
//  |   Use this to create your own quest files!
//  |   
//  |  
//  |
//  -------------------------------------------------------------------------
define(MAXACT, 7);  //Maximum number of acts in your quest

page_header($questInfo[title]);
addnav("Special Adventure");

//Make sure you always start with Act 0 (default)
if($HTTP_GET_VARS[act]>=0)
	$act = $HTTP_GET_VARS[act];
else	
	$act = 0; 

//---------------------------------
//       Standard Messages:
//---------------------------------
$standardFailMessage = "`c`b`&You decide that this business is too dangerous and flee for your life!`0`b`c`n`n`7You have failed to complete the LOGD Quest template.";
		
$standardDefeatMessage = $session[user][name]."`5 was killed by a ".$badguy['creaturename']."`5 while trying to complete the LOGD Quest template.`7";


if ($HTTP_GET_VARS[op]=="" ){	
	//Intro text
	output("`7`n`nThis where the into text goes.   Set up the story here and then proceed with the various acts.`n`n");	
	
	debuglog("began the standard quest template");
	addnav("Continue", "quests.php?quest=load&questnum=".QUESTNUM."&op=continue&act=1", true);

}else if ($HTTP_GET_VARS[op]=="continue" ){	
	//This is where all the dialog goes
	if ($act==1){
		//Act 1 - Sample BadGuy
		
		//Clear badguy array	
		$session['user']['badguy']=array();
		//Set badguy values
		$badguy['creaturename']    = "Grizzly Bear";
		$badguy['creaturelevel']   = 4;
		$badguy['creatureweapon']  = "Razor Sharp Claws";
		$badguy['creaturelose']    = "I like bears on unicycles better";
		$badguy['creaturewin']     = "Roawrrrr!!!!!";
		$badguy['creaturegold']    = 162;
		$badguy['creatureexp']     = 45;
		$badguy['creaturehealth']  = 47;
		$badguy['creatureattack']  = 8;
		$badguy['creaturedefense'] = 7;
		$badguy['playerstarthp']   = $session['user']['hitpoints'];

		calcHandicap($questInfo[level]);
		//Set other values for battle
		$session['user']['badguy']=createstring($badguy);
		$badguy['diddamage']=0;
		$battle=true;


	}else if ($HTTP_GET_VARS[act]=="2" ){
		//Act 2 - Sample Success Message
		output("`n`n`7You have beaten the Grizzly Bear!  You rejoice at your first custom written quest.`n`n", true);
		output("`^`c`b(You receive some gold and gems!)`b`c`7");

		//Update the user's quest history
		updateQuest(QUESTNUM);
		//Give the user some gold and a gem
		$session[user][gems]++;
		$session[user][gold]+= 100;

		//Add a blurb to the news
		addnews($session[user][name]."`5 rejoices for having beaten the Quest of the LOGD template!");
		addnav("Back to Village", "village.php", true);
		debuglog("has beaten the Grizzly Bear and the standard quest template");
		

	}else{
		//Otherwise go back to intro screen
		output("`7`n`nAn unknown error ocurred.  Please try again.`n`n");	
		debuglog("an unknown error has occured in the standard quest template and could not continue.");
		addnav("Continue", "quests.php?quest=load&questnum=".$questInfo[qid], true);
	}
}

if ($HTTP_GET_VARS[op]=="fight" || $HTTP_GET_VARS[op]=="run") $battle=true;

if ($HTTP_GET_VARS[op]=="run"){
	if (e_rand()%3 == 0){
		output ($standardFailMessage, true);
		output ("`n`n`c`b`^(You have failed to complete the quest)`c`b`7");
		$HTTP_GET_VARS[op]="";
		$battle = false;
		addnav("Go home", "quests.php", true);
		debuglog("failed ot complete the standard quest template, and fled");
	}else{
		output("`c`b`\$You failed to flee your opponent!`0`b`c");
	}
}

//Standard battle routines.  Edit only if you need to change battle sequence.
if ($battle){
  include("battle.php");
	if ($victory){
		//Calculate bonus/penalties and gold
		calcBonus();
		$act++;
		addnav("Continue","quests.php?quest=load&questnum=".$questInfo[qid]."&op=continue&act=".$act);
	}else if($defeat){							
		output("`b`&You have been slain by `%$badguy[creaturename]`&!!!`n");
		output("`4All gold on hand has been lost!`n");
		output("`410% of experience has been lost!`n");
		output("You may begin fighting again tomorrow.");

		addnews($standardDefeatMessage);
		addnav("Daily news","news.php");
		debuglog("was killed trying to complete the standard quest template");

		//Update player can not retry, set the quest history
		if(!$questInfo[retry])
			updateQuest($questInfo[qid]);
	}else{
		questfightnav($questInfo[qid], $act);			
	}
	
}

//Emergency Escape - Take this out when your done
addnav("Emergency", "");
addnav("Back", "quests.php");
page_footer();
?>