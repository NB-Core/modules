<?php
require_once "common.php";
//--------------------------------------------------------------------------------------------------------
//| Written by:  rax (rax@sourceforge.net)
//| Get the latest code at: logd.raxhaven.com
//| Version: 1.0 - 05/17/2004
//|
//| About:   Allows players to go on quests
//|
//| Description:
//|			This mod allows players to go on quests.   It also provides a simple framework
//|     for content authors to write quests (although no interface has been developed yet).
//|     Each quest can only be completed once, which is an important feature and makes this
//|     mod different from an IGM.
//|
//|	Please read the readme.txt file available in the zip file on dragonprime. 
//| http://dragonprime.cawsquad.net/users/rax/QuestModule-1_0.zip
//|
//--------------------------------------------------------------------------------------------------------



page_header("Quests");	

if ($HTTP_GET_VARS[quest]==""){
	$quests = $session[user][quests];
	addnav("Quests", "quests.php");
	addnav("Return to Village","village.php");

	//output("`n`n2^4 ". pow(2,4) ." ", true);
	$query = "SELECT * FROM quests ORDER BY dks ASC, level ASC, ff ASC";
	$result = db_query($query);
	$rowAlternate = 1;
	output("`n`n`c`b`^You have the following quests available`b`c`7`n", true);
	output("`c<table border=0 cellpadding=4 cellspacing=1 bgcolor='#999999'>",true);
	output("<tr class='trhead'><td style='width:200px'><b>Quests</b></td><td><b>Dragon Kills</b></td><td><b>Level</b></td><td><b>Turns</b></td><td><b>Challenge</b></td><td><b>Retry</b></td><td><b>Status</b></tr>",true);

	while ($row = db_fetch_assoc($result)) {

		if(!($quests & pow(2,$row[qid]))){
			if($session[user][dragonkills] >= $row[dks] &&
				     $session[user][level] >= $row[level] &&
				$session[user]['turns'] >= $row[ff]){
				$status = "`b`2Available`b`7";
				$target = "<a href=\"quests.php?quest=load&questnum=".$row[qid]."\">".$row[title]."</a>";
			}else{
				$status = "`b`6Unavailable`b`7";
				$target = "`b`7".$row[title]."`b";
			}
		}else{
			$status = "`b`4Complete`b`7";
			$target = "`b`7".$row[title]."`b";
		}
		addnav("", "quests.php?quest=load&questnum=".$row[qid]);
		output("<tr class='".($rowAlternate%2?"trdark":"trlight")."'><td>",true);
		output("`&".$target."</td><td style='text-align:center'>`&".$row[dks]."</td><td style='text-align:center'>`&".$row[level]."</td><td style='text-align:center'>`&".$row[ff]."</td><td style='text-align:center'>`&".$row[challenge]."</td><td style='text-align:center'>`&".($row[retry]?"`2Yes`7":"`4No`7")."</td><td style='text-align:center'>`&".$status."</td></tr>", true);	
		$rowAlternate++;
	}
	output("</table>`c`n`n", true);
}else if($HTTP_GET_VARS[quest]=="load"){

	$query = "SELECT * FROM quests WHERE qid =".$HTTP_GET_VARS[questnum];
	$result = db_query($query);
	$questInfo = db_fetch_assoc($result);

	include("quests/".$questInfo["filename"]);

}

function questfightnav($questnum, $actnum, $allowspecial=true, $allowflee=true){
  global $PHP_SELF,$session;

	//$return = preg_replace("'[&?]c=[[:digit:]-]+'","",$_GET[ret]);
	//$return = substr($return,strrpos($return,"/")+1);
	//output("getret: ".$_GET[ret]."`nreturn detected as: ".$return, true);

	//$script = str_replace("/","",$PHP_SELF);
	$script = substr($PHP_SELF,strrpos($PHP_SELF,"/")+1);
	addnav("Fight","$script?quest=load&questnum=".$questnum."&act=".$actnum."&op=fight");
	if ($allowflee) {
		addnav("Run","$script?quest=load&questnum=".$questnum."&act=".$actnum."&op=run");
	}
	if ($allowspecial) {
		addnav("`bSpecial Abilities`b");
		if ($session[user][darkartuses]>0) {
			addnav("`\$Dark Arts`0", "");
			addnav("`\$&#149; Skeleton Crew`7 (1/".$session[user][darkartuses].")`0","$script?quest=load&questnum=".$questnum."&act=".$actnum."&op=fight&skill=DA&l=1",true);
		}
		if ($session[user][darkartuses]>1)
			addnav("`\$&#149; Voodoo`7 (2/".$session[user][darkartuses].")`0","$script?quest=load&questnum=".$questnum."&act=".$actnum."&op=fight&skill=DA&l=2",true);
		if ($session[user][darkartuses]>2)
			addnav("`\$&#149; Curse Spirit`7 (3/".$session[user][darkartuses].")`0","$script?quest=load&questnum=".$questnum."&act=".$actnum."&op=fight&skill=DA&l=3",true);
		if ($session[user][darkartuses]>4)
			addnav("`\$&#149; Wither Soul`7 (5/".$session[user][darkartuses].")`0","$script?quest=load&questnum=".$questnum."&act=".$actnum."&op=fight&skill=DA&l=5",true);
	
		if ($session[user][thieveryuses]>0) {
			addnav("`^Thieving Skills`0","");
			addnav("`^&#149; Insult`7 (1/".$session[user][thieveryuses].")`0","$script?quest=load&questnum=".$questnum."&act=".$actnum."&op=fight&skill=TS&l=1",true);
		}
		if ($session[user][thieveryuses]>1)
			addnav("`^&#149; Poison Blade`7 (2/".$session[user][thieveryuses].")`0","$script?quest=load&questnum=".$questnum."&act=".$actnum."&op=fight&skill=TS&l=2",true);
		if ($session[user][thieveryuses]>2)
			addnav("`^&#149; Hidden Attack`7 (3/".$session[user][thieveryuses].")`0","$script?quest=load&questnum=".$questnum."&act=".$actnum."&op=fight&skill=TS&l=3",true);
		if ($session[user][thieveryuses]>4)
			addnav("`^&#149; Backstab`7 (5/".$session[user][thieveryuses].")`0","$script?quest=load&questnum=".$questnum."&act=".$actnum."&op=fight&skill=TS&l=5",true);
	
		if ($session[user][magicuses]>0) {
			addnav("`%Mystical Powers`0","");
			//disagree with making this 'n', players shouldn't have their behavior dictated by convenience of god mode, hehe
			addnav("g?`%&#149; Regeneration`7 (1/".$session[user][magicuses].")`0","$script?quest=load&questnum=".$questnum."&act=".$actnum."&op=fight&skill=MP&l=1",true);
		}
		if ($session[user][magicuses]>1)
			addnav("`%&#149; Earth Fist`7 (2/".$session[user][magicuses].")`0","$script?quest=load&questnum=".$questnum."&act=".$actnum."&op=fight&skill=MP&l=2",true);
		if ($session[user][magicuses]>2)
			addnav("L?`%&#149; Siphon Life`7 (3/".$session[user][magicuses].")`0","$script?quest=load&questnum=".$questnum."&act=".$actnum."&op=fight&skill=MP&l=3",true);
		if ($session[user][magicuses]>4)
			addnav("A?`%&#149; Lightning Aura`7 (5/".$session[user][magicuses].")`0","$script?quest=load&questnum=".$questnum."&act=".$actnum."&op=fight&skill=MP&l=5",true);

		if ($session[user][superuser]>=3) {
			addnav("`&Super user`0","");
			addnav("!?`&&#149; __GOD MODE","$script?quest=load&questnum=".$questnum."&act=".$actnum."&op=fight&skill=godmode",true);
		}
	}
}

function updateQuest($questnum){
	global $session;
	//$questnum++; //account for 0 based list
	$questUpdate = (pow(2,$questnum) | $session[user][quests]);
	//echo "questUpdate = ".$questUpdate;
	$sql = "UPDATE accounts SET quests=".$questUpdate." WHERE acctid=".$session[user][acctid];
	db_query($sql);

	$session[user][quests] = $questUpdate;
}

function calcHandicap($questLvl){
	//Calculate handicap factor (for higher levels)
	global $session, $badguy, $beta;

	$dk = 0;
	while(list($key, $val)=each($session[user][dragonpoints])) {
		if ($val=="at" || $val=="de") $dk++;
	}
	//$dk += (int)(($session['user']['maxhitpoints']-
		//($session['user']['level']*10))/5);
	$dk = round($dk,0);

	$lvl = $session['user']['level']-$questLvl;			
	$atkflux = e_rand(0, ($lvl*2)) + e_rand(0, $dk);		
	$defflux = e_rand(0, $lvl) + e_rand(0, $dk);		
	$hpflux = (8*$lvl)+(($atkflux+$defflux) * 5);
	$badguy['creatureattack']+=$atkflux;
	$badguy['creaturedefense']+=$defflux;
	$badguy['creaturehealth']+=$hpflux;

	if ($session['user']['race']==4) $badguy['creaturegold']*=1.2;
	$badguy['creaturelevel'] =$badguy['creaturelevel'] + $lvl;
	//Display information for playtesting
	if ($beta) {
		if ($session['user']['superuser']>=1){
			output("Debug: Quest Level $questLvl`n");
			output("Debug: $dk dks.`n");
			output("Debug: +$lvl level.`n");
			output("Debug: +$atkflux attack.`n");
			output("Debug: +$defflux defense.`n");
			output("Debug: +$hpflux health.`n");
		} 
	}

}

function calcBonus(){
	global $session, $badguy, $beta;

	if (getsetting("dropmingold",0)){
		$badguy[creaturegold]=e_rand($badguy[creaturegold]/4,3*$badguy[creaturegold]/4);
	}else{
		$badguy[creaturegold]=e_rand(0,$badguy[creaturegold]);
	}
	$expbonus = round(
			($badguy[creatureexp] *
				(1 + .25 *
					($badguy[creaturelevel]-$session[user][level])
				)
			) - $badguy[creatureexp],0
		);
	output("`b`&$badguy[creaturelose]`0`b`n"); 
	output("`b`\$You have slain $badguy[creaturename]!`0`b`n");		
	if (e_rand(1,25) == 1) {
	  output("`&You find A GEM!`n`#");
	  $session['user']['gems']++;
	  debuglog("found a gem when slaying a monster.");
	}
	if ($expbonus>0){
	  output("`#***Because of the difficult nature of this fight, you are awarded an additional `^".abs($expbonus)."`# experience and `^".abs($expbonus*2)."`# gold! `n($badguy[creatureexp] + ".abs($expbonus)." = ".($badguy[creatureexp]+$expbonus).") `n($badguy[creaturegold] + ".abs(($expbonus*2))." = ".($badguy[creaturegold]+($expbonus*2)).")");		  
	  $badguy[creaturegold] = $badguy[creaturegold]+($expbonus*2);
	}else if ($expbonus<0){
	  output("`#***Because of the simplistic nature of this fight, you are penalized `^".abs($expbonus)."`# experience and `^".abs($expbonus*2)."`# gold! `n($badguy[creatureexp] - ".abs($expbonus)." = ".($badguy[creatureexp]+$expbonus).") `n($badguy[creaturegold] - ".abs(($expbonus*2))." = ".($badguy[creaturegold]+($expbonus*2)).")");
	  $badguy[creaturegold] = $badguy[creaturegold]+($expbonus*2);
	}

	//Keep warriors from being penalized negative gold and experience
	$badguy[creatureexp] = $badguy[creatureexp]+$expbonus;
	if($badguy[creaturegold] < 0) $badguy[creaturegold] = 0;
	if($badguy[creatureexp] < 0) $badguy[creatureexp] = 0;

	output("`nYou receive `^".($badguy[creatureexp])."`# total experience!`n`0");
	output("`#You receive `^".$badguy[creaturegold]."`# gold!`n");
	if ($badguy['creaturegold']) {
		debuglog("received {$badguy['creaturegold']} gold for slaying a monster.");
	}
	$session[user][gold]+=$badguy[creaturegold];
	$session[user][experience]+=($badguy[creatureexp]+$expbonus);
	$creaturelevel = $badguy[creaturelevel];
	$HTTP_GET_VARS[op]="";
	$dontdisplayforestmessage=true;
	$badguy=array();

}

page_footer();	
?>