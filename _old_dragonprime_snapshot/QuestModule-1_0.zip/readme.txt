--------------------------------------------------------------------------------------------------------
| Written by:  rax (rax@sourceforge.net)
| Get the latest code at: logd.raxhaven.com
| Version: 1.0 - 05/17/2004
|
| About:   Allows players to go on quests
|
| Description:
|			This mod allows players to go on quests.   It also provides a simple framework
|     for content authors to write quests (although no interface has been developed yet).
|     Each quest can only be completed once, which is an important feature and makes this
|     mod different from an IGM.
|
| Available at:
| http://dragonprime.cawsquad.net/users/rax/QuestModule-1_0.zip
|
--------------------------------------------------------------------------------------------------------

INSTALL:

Create the quest table using the logd-quests.sql file provided.   You will also need to add an 
int(11) field in the "accounts" table called "quests".  This field is how the quest module
keeps track of which quests the players have completed.

To install the quest managment console, open up superuser.php and add:

if ($session[user][superuser]>=3)addnav("Quest Editor","questeditor.php");

at about line 94.  This will allow you to access the managment console from the superuser menu.

-------

More instructions and automation to come...

CREATE QUESTS:

Use the standard_template.php file as a guide for creating a custom quest.  You will need to set the 
MAXACT to the maximum number of "Acts" you will have in your quest.   Next edit the standard messages 
as needed.  

The quest will should follow linearly through the acts, but you can skip and act if you need to.   When
you set up a monster, and the player defeats it, the quest will continue with next act.  Example:  monster
is in act 7, then when the player defeats it they will proceed to act 8.   You will need to keep track
of this in order to make your quests flow properly.   For more examples check the three quests included
in this file.



