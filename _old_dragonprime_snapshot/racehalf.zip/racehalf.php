<?php


function racehalf_getmoduleinfo(){
	$info = array(
		"name"=>"Race - Halfling",
		"version"=>"1.0",
		"author"=>"Jonathan Newton",
        "download"=>"http://dragonprime.net/users/Ender/racehalf.zip",
		"vertxtloc"=>"http://dragonprime.net/users/Ender/",
		"category"=>"Races",
		"download"=>"core_module",
		"settings"=>array(
			"Halfling Race Settings,title",
			"villagename"=>"Name for the Halfling village|Overthere",
			"minedeathchance"=>"Chance for Halflings to die in the mine,range,0,100,1|90",
		),

	);
	return $info;
}

function racehalf_install(){
	module_addhook("chooserace");
	module_addhook("setrace");
	module_addhook("creatureencounter");
	module_addhook("villagetext");
	module_addhook("travel");
	module_addhook("charstats");
	module_addhook("village");
	module_addhook("validlocation");
	module_addhook("validforestloc");
	module_addhook("moderate");
	module_addhook("changesetting");
	module_addhook("raceminedeath");
	module_addhook("racenames");
	return true;
}

function racehalf_uninstall(){
	global $session;
	$vname = getsetting("villagename", LOCATION_FIELDS);
	$gname = get_module_setting("villagename");
	$sql = "UPDATE " . db_prefix("accounts") . " SET location='$vname' WHERE location = '$gname'";
	db_query($sql);
	if ($session['user']['location'] == $gname)
		$session['user']['location'] = $vname;
	// Force anyone who was a Halfling to rechoose race
	$sql = "UPDATE  " . db_prefix("accounts") . " SET race='" . RACE_UNKNOWN . "' WHERE race='Halfling'";
	db_query($sql);
	if ($session['user']['race'] == 'Halfling')
		$session['user']['race'] = RACE_UNKNOWN;
	
	return true;
}

function racehalf_dohook($hookname,$args){
	//yeah, the $resline thing is a hack.  Sorry, not sure of a better way
	//to handle this.
	// It could be passed as a hook arg?
	global $session,$resline;
	$city = get_module_setting("villagename");
	$race = "Halfling";
	switch($hookname){
	case "racenames":
		$args[$race] = $race;
		break;
    case "raceminedeath":
        if ($session['user']['race'] == $race) {
            $args['chance'] = get_module_setting("minedeathchance");
        }
        break;
	case "changesetting":
		// Ignore anything other than villagename setting changes for myself
		if ($args['setting'] == "villagename" && $args['module']=="racehalfling") {
			if ($session['user']['location'] == $args['old'])
				$session['user']['location'] = $args['new'];
			$sql = "UPDATE " . db_prefix("accounts") .
				" SET location='" . addslashes($args['new']) .
				"' WHERE location='" . addslashes($args['old']) . "'";
			db_query($sql);
			if (is_module_active("cities")) {
				$sql = "UPDATE " . db_prefix("module_userprefs") .
					" SET value='" . addslashes($args['new']) .
					"' WHERE modulename='cities' AND setting='homecity'" .
					"AND value='" . addslashes($args['old']) . "'";
				db_query($sql);
			}
		}
		break;
	case "charstats":
		if ($session['user']['race']==$race){
			addcharstat("Vital Info");
			addcharstat("Race", translate_inline($race));
		}
		break;
	case "chooserace":
		output("<a href='newday.php?setrace=$race$resline'>Far in the west in the city of %s</a>, you grew up thinking Adventure was bad for you and likely to end your life early, yet you grew up curious so headed out to see the world. `n`n", $city, true);
		addnav("`#Halfling`0","newday.php?setrace=$race$resline");
		addnav("","newday.php?setrace=$race$resline");
		break;
	case "setrace":
		if ($session['user']['race']==$race){
			output("`#As a halfling, you are closer to the ground and more likely to spot gold.`n");
			output("`^You gain extra gold from forest fights!");
			if (is_module_active("cities")) {
				if ($session['user']['dragonkills']==0 &&
						$session['user']['age']==0){
					//new farmthing, set them to wandering around this city.
					set_module_setting("newest-$city",
							$session['user']['acctid'],"cities");
				}
				set_module_pref("homecity",$city,"cities");
				if ($session['user']['age'] == 0)
					$session['user']['location']=$city;
			}
		}
		break;
	case "validforestloc":
	case "validlocation":
		if (is_module_active("cities"))
			$args[$city] = "village-$race";
		break;
	case "moderate":
		if (is_module_active("cities")) {
			tlschema("commentary");
			$args["village-$race"]=sprintf_translate("City of %s", $city);
			tlschema();
		}
		break;
	case "creatureencounter":
		if ($session['user']['race']==$race){
			//get those folks who haven't manually chosen a race
			racehalf_checkcity();
			$args['creaturegold']=round($args['creaturegold']*1.2,0);
		}
		break;
	case "travel":
		$capital = getsetting("villagename", LOCATION_FIELDS);
		$hotkey = substr($city, 0, 1);
		tlschema("module-cities");
		if ($session['user']['location']==$capital){
			addnav("Safer Travel");
			addnav(array("%s?Go to %s", $hotkey, $city),"runmodule.php?module=cities&op=travel&city=$city");
		}elseif ($session['user']['location']!=$city){
			addnav("More Dangerous Travel");
			addnav(array("%s?Go to %s", $hotkey, $city),"runmodule.php?module=cities&op=travel&city=$city&d=1");
		}
		if ($session['user']['superuser'] & SU_EDIT_USERS){
			addnav("Superuser");
			addnav(array("%s?Go to %s", $hotkey, $city),"runmodule.php?module=cities&op=travel&city=$city&su=1");
		}
		tlschema();
		break;	
	case "villagetext":
		racehalf_checkcity();
		if ($session['user']['location'] == $city){
			// Do this differently
			$args['text']=array("`#`c`bWestern %s, home of the Halflings`b`c`n`3Far in the west lies %s the home of a very peaceful people, the town is so far west not many adventurers have been through here, and as such the small people who live here have not got into many adventures themselves.`n", $city, $city);
			$args['schemas']['text'] = "module-racehalf";
   	$args['clock']="`n`3A massive antique tower clock stands high showing the time to be `#%s`3.`n";
			$args['schemas']['clock'] = "module-racehalf";
			if (is_module_active("calendar")) {
				$args['calendar'] = "`n`3You hear a paper boy going past proclaiming the date to be `#Year %4\$s`3, `#%3\$s %2\$s`3.`nand then realise the day of the week is `#%1\$s`3.`n`n";
				$args['schemas']['calendar'] = "module-racehalf";
			}
			$args['title']= array("The Village of %s", $city);
			$args['schemas']['title'] = "module-racehalf";
			$args['sayline']="gossips";
			$args['schemas']['sayline'] = "module-racehalf";
			$args['talk']="`n`#Nearby some villagers gossip:`n";
            			$args['schemas']['talk'] = "module-racehalf";
			$new = get_module_setting("newest-$city", "cities");
			if ($new != 0) {
				$sql =  "SELECT name FROM " . db_prefix("accounts") .
					" WHERE acctid='$new'";
				$result = db_query_cached($sql, "newest-$city");
				$row = db_fetch_assoc($result);
				$args['newestplayer'] = $row['name'];
				$args['newestid']=$new;
			} else {
				$args['newestplayer'] = $new;
				$args['newestid']="";
			}
			if ($new == $session['user']['acctid']) {
				$args['newest']="`n`3Being rather new to this life, you pound an empty stein against an ale keg in an attempt to get some of the fabulous ale therein.";
			} else {
				$args['newest']="`n`3Pounding an empty stein against a yet unopened barrel of ale, wondering how to get to the sweet nectar inside is `#%s`3.";
			}
			$args['schemas']['newest'] = "module-racehalf";
			$args['gatenav']="UnderBridge";
			$args['schemas']['gatenav'] = "module-racehalf";
			$args['fightnav']="Battles";
			$args['schemas']['fightnav'] = "module-racehalf";
			$args['marketnav']="Market";
			$args['schemas']['marketnav'] = "module-racehalf";
			$args['tavernnav']="The Hovel";
			$args['schemas']['tavernnav'] = "module-racehalf";
			$args['section']="village-$race";
		}
		break;


	}
	return $args;
}

function racehalf_checkcity(){
	global $session;
	$race="Halfling";
	$city= get_module_setting("villagename");
	
	if ($session['user']['race']==$race && is_module_active("cities")){
		//if they're this race and their home city isn't right, set it up.
		if (get_module_pref("homecity","cities")!=$city){ //home city is wrong
			set_module_pref("homecity",$city,"cities");
		}
	}	
	return true;
}

function racehalf_run(){

	}
?>
