<?php

// Based on Felyne - thanks Saucy!

function racelich_getmoduleinfo(){
	$info = array(
		"name"=>"Race - Lich",
		"version"=>"1.0",
		"author"=>"Sneakabout",
		"category"=>"Races",
		"download"=>"Ask Nicely!",
		"settings"=>array(
			"Lich Race Settings,title",
			"minedeathchance"=>"Percent chance for Lichs to die in the mine,range,0,100,1|20",
			"mindk"=>"How many DKs do you need before the race is available?,int|10",
		),
		"prefs"=>array(
			"Lich Race Preferences,title",
			"darkpotential"=>"Is this person good enough to become a Lich?,bool|0",
		),
	);
	return $info;
}

function racelich_install(){
	if (!is_module_installed("racehuman")) {
		output("Lichs only develop out of the greed of humans. You must install that race module.");
		return false;
	}
	module_addhook("chooserace");
	module_addhook("setrace");
	module_addhook("newday");
	module_addhook("charstats");
	module_addhook("raceminedeath");
	module_addhook("header-dragon");
	module_addhook("pvpadjust");
	module_addhook("training-victory");
	return true;
}

function racelich_uninstall(){
	global $session;
	$sql = "UPDATE  " . db_prefix("accounts") . " SET race='" . RACE_UNKNOWN . "' WHERE race='Lich'";
	db_query($sql);
	if ($session['user']['race'] == 'Lich')
		$session['user']['race'] = RACE_UNKNOWN;
	return true;
}

function racelich_dohook($hookname,$args){
	global $session,$resline;

	if (is_module_active("racehuman")) {
		$city = get_module_setting("villagename", "racehuman");
	} else {
		$city = getsetting("villagename", LOCATION_FIELDS);
	}
	$race = "Lich";
	switch($hookname){
	case "pvpadjust":
		if ($args['race'] == $race) {
			$args['creaturedefense']-=(2+floor($args['creaturelevel']/5));
			$args['creaturehealth']-= round($args['creaturehealth']*.1, 0);
		}
		break;
	case "raceminedeath":
		if ($session['user']['race'] == $race) {
			$args['chance'] = get_module_setting("minedeathchance");
			$args['racesave'] = "Despite your weak frame, you escape unscathed.`n";
			$args['schema']="module-racelich";
		}
		break;
	case "charstats":
		if ($session['user']['race']==$race){
			addcharstat("Vital Info");
			addcharstat("Race", translate_inline($race));
		}
		break;
	case "chooserace":
		if ($session['user']['dragonkills'] < get_module_setting("mindk")) break;
		if (!get_module_pref("darkpotential")) break;
		output("<a href='newday.php?setrace=Lich$resline'>In the city of %s</a>, where the darkest of arcane arts are studied, a rare few have the potential to transcend life itself and \"Ascend\" to the ranks of the undead. These rare beings have incredible knowledge of the arcane arts, but are weak from the dark rituals needed to sustain their \"life\".`n`n",$city, true);
		addnav("`\$Lich`0","newday.php?setrace=$race$resline");
		addnav("","newday.php?setrace=$race$resline");
		break;
	case "setrace":
		if ($session['user']['race']==$race){
			output("`&With the dark ritual complete, you rise again to life!.`n");
			output("You are weak and lose defense!`n");
			output("You know of dark secrets beyond the knowledge of mortals!`n");
			$session['user']['specialty']="DA";
			if (is_module_active("cities")) {
				set_module_pref("homecity",$city,"cities");
				if ($session['user']['age'] == 0)
					$session['user']['location']=$city;
			}
		}
		break;
	case "header-dragon":
		if ($session['user']['race'] == $race) {
			set_module_pref("darkpotential",1);
			break;
		}
		if (get_module_pref("skill","specialtydarkarts")>=20 && $session['user']['race']=="Human") {
			set_module_pref("darkpotential",1);
		} else {
			set_module_pref("darkpotential",0);
		}
		break;
	case "newday":
		if ($session['user']['race']==$race){
			racelich_checkcity();
			apply_buff("racialbenefit",array(
				"name"=>"`\$Lich's Weakness`0",
				"defmod"=>0.85,
				"badguydmgmod"=>1.05,
				"allowinpvp"=>1,
				"allowintrain"=>1,
				"rounds"=>-1,
				"schema"=>"module-racelich",
				)
			);
		}
		break;
	case "training-victory";
		if ($session['user']['race']==$race){
			output("`7You remember more forbidden lore from your days of life!");
			$oldskill=$session['user']['specialty'];
			$session['user']['specialty']="DA";
			require_once("lib/increment_specialty.php");
			increment_specialty("`7");
			$session['user']['specialty']=$oldskill;
		}
		break;
	}

	return $args;
}

function racelich_checkcity(){
	global $session;
	$race="Lich";
	if (is_module_active("racehuman")) {
		$city = get_module_setting("villagename", "racehuman");
	} else {
		$city = getsetting("villagename", LOCATION_FIELDS);
	}
	
	if ($session['user']['race']==$race && is_module_active("cities")){
		//if they're this race and their home city isn't right, set it up.
		if (get_module_pref("homecity","cities")!=$city){ //home city is wrong
			set_module_pref("homecity",$city,"cities");
		}
	}	
	return true;
}

function racelich_run(){
}
?>
