<?php

/*
 * Title:       Charm Display
 * Date:	Aug 01, 2004
 * Version:	1.11
 * Author:      Joshua Ecklund
 * Email:       m.prowler@cox.net
 * Purpose:     Add charm to the charstats display bar.
 *
 * --Change Log--
 *
 * Date:    	Jul 30, 2004
 * Version:	1.0
 * Purpose:     Initial Release
 *
 * Date:        Jul 31, 2004
 * Version:     1.1
 * Purpose:     Various changes/fixes suggested by JT Traub (jtraub@dragoncat.net)
 *
 * Date:        Aug 01, 2004
 * Version:     1.11
 * Purpose:     Fix suggested by JT Traub (jtraub@dragoncat.net)
 *
 */

function showcharm_getmoduleinfo(){
	$info = array(
		"name"=>"Charm Display",
		"version"=>"1.11",
		"author"=>"Joshua Ecklund",
                "download"=>"http://dragonprime.net/users/mProwler/showcharm.zip",
		"category"=>"Stat Display"
	);
	return $info;
}

function showcharm_install(){
	module_addhook("charstats");
    return true;
}

function showcharm_uninstall(){
	return true;
}


function showcharm_dohook($hookname,$args){
	global $session;

	switch($hookname){
		case "charstats":

	        	$ccode = "`^";
	                $stat = "Charm";
			$new = $ccode . $session["user"]["charm"];

			setcharstat("Vital Info", $stat, $new);
		break;
	}
	return $args;
}

function showcharm_run(){

}
?>
