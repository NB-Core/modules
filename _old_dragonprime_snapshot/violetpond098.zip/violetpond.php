<?php
/*
violet pond 
Written by Robert of MaddRio dot com
*/
function violetpond_getmoduleinfo(){
        $info = array(
        "name"=>"Violet Pond",
        "version"=>"1.0",
        "author"=>"`2Robert",
        "download"=>"http://dragonprime.net/users/Robert/violetpond098.zip",
        "category"=>"Forest Specials",
        "settings"=>array(
		"Violet Pond Settings,title",
		"male"=>"Name of person Female player will see in pond? ,|Seth",
		"female"=>"Name of person Male players will see in pond? ,|Violet"
		),
        );
        return $info;
}

function violetpond_install(){
        module_addeventhook("forest", "return 100;");
        return true;
}

function violetpond_uninstall(){
        return true;
}

function violetpond_dohook($hookname,$args){
        return $args;
}

function violetpond_runevent($type){
global $session;
$male = get_module_setting("male");
$female = get_module_setting("female");

if ($session[user][sex]==0){
output("`n`n`^You come across %s `^skinny dipping in a Pond, . . you continue to watch her. `n`n",$female);
output("You are seen peeking at her, while hiding behind a tree.`n`n");
output("`&You lose some of your charm");
$session[user][charm]--;
}else{
output(" `n`^You come across %s `^skinny dipping in a Pond, . . you continue to watch him. `n`n",$male);
output("You are seen peeking at him, while hiding behind a tree.`n`n");
output("`&You lose some of your charm");
$session[user][charm]--;
}
}
function violetpond_run(){
}
?>