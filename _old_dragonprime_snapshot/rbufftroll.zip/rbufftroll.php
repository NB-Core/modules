<?php
//This is my second module.  it is another racial buff.  I plan to give these to my "core" races
//in my game.  They are meant to be used together.  This one will give the selected race a bonus to   
//attack for their PvP Kills.  I have intended for Trolls, but race will be selectable.

function rbufftroll_getmoduleinfo(){
	$info = array(
		"name"=>"Bloodlust",
		"version"=>"1.0",
		"author"=>"Jason Tomlinson",
		"category"=>"Racial Buff",
		"download"=>"http://myweb.cableone.net/jtomlins/",
		"settings"=>array(
			"Bloodlust,title",
			//Use can increase or decrease the att award. 
			"pksperattgained"=>"Number of Player Kills for each Attack Point,int|3",
			"availablerace1"=>"Which Race?,float|Troll",
		),
		"prefs"=>array(
			"Bloodlust Preferences,title",
			"attgained"=>"Attack Points Gained from Bloodlust,int|0",
		), 
	);
	return $info;
}

//Calculates in the village
function rbufftroll_install(){

	module_addhook("village");
	
return true;
}

function rbufftroll_uninstall(){
	return true;
}

function rbufftroll_dohook($hookname,$args){
	global $session;
	switch($hookname){
		default:
		//only works for race selected in settings
		$avrace = get_module_setting ("availablerace1");
		if ($session['user']['race'] == $avrace) {
		
			//change is made here
			$id = $session['user']['acctid'];
			$cpk = get_module_pref("count","pktrack",$id);
			$oldattgained = get_module_pref ("attgained");
			$newattgained = round($cpk/get_module_setting ("pksperattgained"));
			$cpk = get_module_pref("count","pktrack",$id);
			$currentattack = $session['user']['attack'];
			$newattack = $currentattack + $newattgained - $oldattgained;
			$session['user']['attack'] = $newattack;
			set_module_pref ("attgained", $newattgained, "rbufftroll"); 			

			//create a buff so player knows what's going on.  Buff is visual only.
			$name1 = "`$ Bloodlust `4(+";
			$name2 = " Attack)`n";
			$name3 = $name1.$newattgained.$name2;
			apply_buff("rbufftrollSTAT",
				array(
					"name"=>$name3,
					"rounds"=>"-1",
					"schema"=>"module-rbufftroll",
				)
			);
		}
	}
	return $args;
}
?>
