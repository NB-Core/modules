<?php
// mail ready
// addnews ready
// translator ready

// Based on Fairy module code
// Thanks to Peter Corcoran for some bugfixes
// Thanks to the Fairy, Ferryman, and Salesman modules, I couldn't have done this without them
function wellenutorf_getmoduleinfo(){
	$info = array(
		"name"=>"Well of Enutorf",
		"version"=>"1.3",
		"author"=>"Enhas, Bugfixed and Enhanced by Peter Corcoran",
		"category"=>"Forest Specials",
            "download"=>"http://dragonprime.net/users/Enhas/wellenutorf.txt",
            "settings"=>array(
		"Well of Enutorf Settings,title",
            "buff1"=>"Does the Happiness Vibes buff survive newday,bool|0",
            "buff2"=>"Does the Golden Dust buff survive newday,bool|1",
            "buff3"=>"Does the Dark Dust buff survive newday,bool|1",
		"donorpoints"=>"How many donor points can the player earn from throwing gems,range,5,100,5|25",
            "donorpoints2"=>"How many donor points can the player earn from throwing the rare gold coin,range,50,300,5|100",
            "donorenabled"=>"Can donor points be earned from this event,bool|1",
            "battle"=>"Does the battle event happen?,bool|1",
            "badguyname"=>"The name of the {badguy} in the battle event?|Troll",            
            "badguyweapon"=>"The name of the {badguy}'s weapon in the battle event?|A Huge Club",                        
		),
	);
	return $info;
}

function wellenutorf_install(){
	module_addeventhook("forest", "return 100;");
	return true;
}

function wellenutorf_uninstall(){
	return true;
}

function wellenutorf_dohook($hookname,$args){
	return $args;
}
function wellenutorf_run(){
	$badguyname = get_module_setting("badguyname");
	$badguyweapon = get_module_setting("badguyweapon");	
	include("wellenutorf/battle.php");
}
function wellenutorf_runevent($type)
{
	global $session;
	// We assume this event only shows up in the forest currently.
	$from = "forest.php?";
	$session['user']['specialinc'] = "module:wellenutorf";
      $donorpoints = get_module_setting("donorpoints");
      $donorpoints2 = get_module_setting("donorpoints2");
      $buff1 = get_module_setting("buff1");
      $buff2 = get_module_setting("buff2");
      $buff3 = get_module_setting("buff3");
      $rarecoin = 0;
      if (is_module_active("salesman")){
      $rarecoin=get_module_pref("hascoin","salesman");
      }
      // The next line is for testing purposes, do not enable in game
      //$rarecoin = 1;
      page_header("Well of Enutorf");
      output("`^`c`bWell of Enutorf`b`c`n");
	$op = httpget('op');
	if ($op=="" || $op=="search"){
		output("`2While making your way along a rugged trail, you catch a glimmer in your eye in the distance.");
		output("Moving closer, you are astonished to have found the mythical golden `^Well of Enutorf`2!");
            output("Stories of your childhood tell of great luck or fortune that may result of throwing gems into the well, but you are unsure.");
            output("An empty pedestal stands in front of the well, cracked but strong.`n`n");
            if ($rarecoin==1){
            output("`^Reaching into a hidden pocket, you pull out the rare gold coin you bought from the salesman.  You ponder if the well would appreciate this fine offering.`n`n");
            }
		output("`^What do you do?");
            // More and sometimes better results with more gems given.
            addnav("Throw Gems?");
		addnav("Throw 1 Gem", $from."op=onegem");
            addnav("Throw 2 Gems", $from."op=twogems");
            addnav("Throw 3 Gems", $from."op=threegems");
            $coinnavs = array();
            if(is_module_active("coins")){
                if(get_module_pref("magicalcoin","coins")){
            	 $coinnavs["Throw Magical Coin"] = $from."op=magicalcoin";
            	}
            	if(get_module_pref("goldcoin","coins")){
            	 $coinnavs["Throw Gold Coin"] = $from."op=goldcoin";
            	}
            	if(get_module_pref("silvercoin","coins")){
            	 $coinnavs["Throw Silver Coin"] = $from."op=silvercoin";
            	}
            	if(get_module_pref("bronzecoin","coins")){
            	 $coinnavs["Throw Bronze Coin"] = $from."op=bronzecoin";
            	}
            	if(get_module_pref("tarnishedcoin","coins")){
            	 $coinnavs["Throw Tarnished Coin"] = $from."op=tarnishedcoin";
            	}
            }
            if($rarecoin){
             $coinnavs["Throw Rare Coin"] =$from."op=throwcoin";
            }
            if ($coinnavs){
            addnav("Throw Coins?");
            foreach ($coinnavs as $name => $page){
             addnav($name, $page);
            }
            }
            addnav("Leave");
		addnav("Leave", $from."op=leave");
            }elseif ($op=="magicalcoin"){
                  $session['user']['specialinc'] = "";
                  $chancefortune=e_rand(56,66);
                  set_module_pref("magicalcoin",0,"coins");
                  output("`2You toss the rare magical coin into the well, and ... `n`n");
                  $gemsthrown = -1;   		
            }elseif ($op=="goldcoin"){
                  $session['user']['specialinc'] = "";
                  $chancefortune=e_rand(67,77);
                  set_module_pref("goldcoin",0,"coins");
                  output("`2You toss the gold coin into the well, and ... `n`n");
                  $gemsthrown = -1;   		
            }elseif ($op=="silvercoin"){
                  $session['user']['specialinc'] = "";
                  $chancefortune=e_rand(78,88);
                  set_module_pref("silvercoin",0,"coins");
                  output("`2You toss the silver coin into the well, and ... `n`n");
                  $gemsthrown = -1;   		
            }elseif ($op=="bronzecoin"){
                  $session['user']['specialinc'] = "";
                  $chancefortune=e_rand(89,99);
                  set_module_pref("bronzecoin",0,"coins");
                  output("`2You toss the bronze coin into the well, and ... `n`n");
                  $gemsthrown = -1;   		
            }elseif ($op=="tarnishedcoin"){
                  $session['user']['specialinc'] = "";
                  $chancefortune=100;
                  set_module_pref("tarnishedcoin",0,"coins");
                  output("`2You toss the tarnished coin into the well, and ... `n`n");
                  $gemsthrown = -1;   		                                                                        
            }elseif ($op=="onegem" && $session['user']['gems']>0) {
                  $session['user']['specialinc'] = "";
			$chancefortune=(e_rand(1,14));
			$session['user']['gems']--;
			debuglog("spent 1 gem at the Well of Enutorf.");
			output("`2You toss a gem into the well, and ...`n`n");
			$gemsthrown = 1;
            }elseif ($op=="twogems" && $session['user']['gems']>1){
                  $session['user']['specialinc'] = "";
			$chancefortune=(e_rand(15,32));
			$session['user']['gems']-=2;
			debuglog("spent 2 gems at the Well of Enutorf.");
			output("`2You toss two gems into the well, and ...`n`n");
			$gemsthrown = 2;
            }elseif ($op=="threegems" && $session['user']['gems']>2){
                  $session['user']['specialinc'] = "";
                  $chancefortune=e_rand(33,get_module_setting("donorenabled")?50:49);
			$session['user']['gems']-=3;
			debuglog("spent 3 gems at the Well of Enutorf.");
			output("`2You toss three gems into the well, and ...`n`n");
			$gemsthrown = 3;
            }elseif ($op=="throwcoin"){
                  $session['user']['specialinc'] = "";
                  $chancefortune=e_rand(51,get_module_setting("donorenabled")?55:53);
                  set_module_pref("hascoin",0,"salesman");
                  output("`2You toss the rare gold coin into the well, and ... `n`n");
                  $gemsthrown = -1;
            }elseif ($op=="leave" && $session['user']['gems']>0){
                  output("`2Not willing to part with any of your hard earned gems, you go on your way.");
                  $session['user']['specialinc']= "";
            }else{
		output("`2Not having enough gems to give, you sadly walk away, wondering if you'll ever find this place again.");
	      }
            output("`0");
      
if($chancefortune){
	switch($chancefortune){
                  case 1:
                  case 2:
                  case 15:
                  	if(get_module_setting("battle")){
                  		output("`2Ooops... There was a ".get_module_setting("badguyname")." down the well`n");
                  		output("`2It jumps out and attacks you`n");                  
                  		addnav("Fight");
                  		addnav("Fight the ".get_module_setting("badguyname"),"runmodule.php?module=wellenutorf&step=battle");
                  	} else {
                  		output("`2You hear a horrible hissing noise, like pressure building up.`n"); 
                  		output("`2All of a sudden you hear a large bang.`n"); 
                 		output("`2You trip over backwards while your gems come flying out 30 foot into the air.`n"); 
                 		$amount = e_rand(1,$gemsthrown);
                 		switch($amount){
                   			case 1:
                   				$amountn = "`7only 1";
                   				break;
                   			case 2:
                   				$amountn = "`7only 2";
                   				break;
                   			case 3:
                   				$amountn = "`7all of them!";
	                   			break;				
                   		}
                   		if($amount == $gemsthrown){
                   			$amountn = "`7all of them!";
                   		}
                   		output("`2`nYou scramble around trying to collect them all, you manage to collect ".$amountn);
                   		$session['user']['gems'] += $amount;
                   		output("`2`n`nYou collect `7%s`2 gems`n",$amount);
                   		$amount = random(1, $session['user']['hitpoints']);
                   		if($amount > 1000){
                   			$amount = 1000;
                   		}
                   		$session['user']['hitpoints'] -= $amount;
                   		output("`2`n`nYou lost `7%s`2 hitpoints when you fell over`n",$amount);
                   	}
                  case 33:
                  case 58:
                        output("`2You hear a small splash from the bottom of the well.`n");
                        output("Waiting for a few moments, nothing happens!`n");
                        output("You wander away in a bad mood, sad that your childhood story wasn't true..`n`n");
                        output("`\$You lose a turn because of your mood!");
                        $session['user']['turns']--;
                        if ($session['user']['turns']<0)
			      $session['user']['turns']=0;
				break;
                  case 3:
                  case 4:
                  case 59:
                       output("`2A small flask suddenly appears on the pedestal!`n");
                       output("You take it into your hands, pop the cork, and drink the contents down.`n");
                       output("Mmm!  Tastes peachy!`n`n");
                       output("`^You gain a forest fight!");
			     $session['user']['turns']++;
			     break;
                  case 16:
                  case 20:
                  case 22:
                  case 60:
				output("`2A small flask suddenly appears on the pedestal!`n");
                        output("You take it into your hands, pop the cork, and drink the contents down.`n");
                        output("You are delighted at the flavor!`n`n");
                        output("`^You gain a charm point!");
				$session['user']['charm']++;
				break;
                  case 17:
                  case 23:
                  case 61:
				output("`2A small flask suddenly appears on the pedestal!`n");
                        output("You take it into your hands, pop the cork, and drink the contents down.`n");
                        output("You are disgusted at the flavor!`n`n");
                        output("`\$You lose a charm point!");
				$session['user']['charm']--;
                        if ($session['user']['charm']<0)
			      $session['user']['charm']=0;
				break;
                  case 18:
                  case 21:
                  case 24:
                  case 62:
                  case 80:
                  case 81:
                  case 87:
                  case 88:
                  case 89:
				output("`2A small leather pouch suddenly appears on the pedestal!`n");
                        output("You turn it upside down in order to dump the contents out.`n`n");
                        $goldgained = $session['user']['level'] * (e_rand(25,135));
                        output("`^You gain `7%s`^ gold!", $goldgained);
                        $session['user']['gold'] += $goldgained;
				break;
                  case 19:
                  case 25:
                  case 63:
                        output("`2A small leather pouch suddenly appears on the pedestal!`n");
                        output("You turn it upside down in order to dump the contents out.`n");
                        output("The pouch is empty except for a bee, which quickly stings your hand!`n`n");
                        $hploss = round($session['user']['hitpoints'] * 0.1 ,0);
                        output("`\$You have lost some hitpoints!");
                        $session['user']['hitpoints'] -= $hploss;
                        if ($session['user']['hitpoints']<1)
			      $session['user']['hitpoints']=1;
				break;
                  case 9:
                  case 10:
                  case 11:
                  case 12:
                  case 13:
                  case 14:
                  case 56:
                  case 64:
                  case 99:
                  case 83:
                       output("`2A vapor of gas emerges from the well and forms itself into the shape of a man.`n");
                       output("You seem to be frozen in place!`n");
                       output("The being glides towards you, and everything quickly goes black.`n`n");
                  $deathchance = e_rand(1,4);
                       if ($deathchance == 1){
                       output("`2When you come to, you notice you are surrounded by the souls of those who have fallen in battle, in old age, and in grievous accidents!`n");
                       output("You realize you are in the land of the dead!`n");
                       output("Not far away, you see `\$Ramius `2 thanking the gas being for bringing you to his realm!`n`n");
                       output("`b`4You discover that all your gold is missing!`n");
			     output("You lose 5% of your experience.`n");
			     output("You may continue playing again tomorrow.");
			     $session['user']['alive']=false;
			     $session['user']['hitpoints']=0;
			     $session['user']['experience']*=0.95;
                       $gold = $session['user']['gold'];
			     $session['user']['gold'] = 0;
			     addnav("Daily News","news.php");
			     addnews("%s was last seen along a rugged trail deep in the forest.",$session['user']['name']);
                       debuglog("lost $gold from the Well of Enutorf.");
                       }else{
                       output("`2When you come to, the gas being is standing over you!`n");
                       output("The gas being looks at you for a moment, in thanks for freeing it from the confines of the well.`n");
                       output("You give it a wave as it fades away.`n`n");
                       output("`^You feel happy at having freed the lost spirit!");
                       $wellbuffrounds = e_rand(10,15);
                       $atkresult1 = e_rand(5,15);
			     $wellbuff = array(
				"name"=>"`5Happiness Vibes",
				"rounds"=>$wellbuffrounds,
				"wearoff"=>"`7You don't feel very happy anymore..",
				"atkmod"=>(1+($atkresult1 / 100)),
                        "survivenewday"=>$buff1,
				"roundmsg"=>"`7Your happiness allows you to strike your enemies harder!",
				"schema"=>"module-wellenutorf"
			      );
			      apply_buff("wellbuff",$wellbuff);
			      $session['user']['specialinc']="";
			}
                        break;
                  case 34:
                  case 38:
                  case 46:
                  case 65:
                  case 75:
                  case 85:
                        output("`2A small flask suddenly appears on the pedestal!`n");
                        output("You take it into your hands, pop the cork, and drink the contents down.`n");
                        output("This is the best thing you have ever tasted!`n`n");
                        output("`^You gain three forest fights!");
				$session['user']['turns']+=3;
				break;
                  case 35:
                  case 47:
                        output("`2A small flask suddenly appears on the pedestal!`n");
                        output("You take it into your hands, pop the cork, and drink the contents down.`n");
                        output("This is the most disgusting thing you have ever tasted!`n`n");
                        if ($session['user']['turns']<2){
                        output("`\$You LOSE a forest fight!");
                        $session['user']['turns']=0;
			      }else{
                        output("`\$You LOSE two forest fights!");
				$session['user']['turns']-=2;
				}
				break;
                  case 36:
                  case 39:
                        output("`2A small flask suddenly appears on the pedestal!`n");
                        output("You take it into your hands, pop the cork, and drink the contents down.`n");
                        output("It tastes a bit sour, but you feel more experienced than before!`n`n");
                        $expgain = round($session['user']['experience'] * 0.1, 0);
                        if ($expgain < 50){
                        $expgain = 50;}
                        output("`^You have gained `7%s`^ experience!", $expgain);
			      $session['user']['experience'] += $expgain;
				break;
                  case 37:
                        output("`2A small flask suddenly appears on the pedestal!`n");
                        output("You take it into your hands, pop the cork, and drink the contents down.`n");
                        $exploss = round($session['user']['experience'] * 0.05, 0);
                        if ($exploss < 25){
                        output("It tastes sweet, but you feel no different than before!`n`n");
                        output("Angered at having wasted your gems, you stomp away.");
                        }else{
                        output("It tastes sweet, but you feel a little bit less experienced than before!`n`n");
                        output("`\$You have lost `7%s`\$ experience!", $exploss);
			     $session['user']['experience'] -= $exploss;
                        }
			break;
                  case 29:
                  case 30:
                  case 31:
                  	if(get_module_setting("battle")){
                  		output("`2Ooops... There was a ".get_module_setting("badguyname")." down the well`n");
                  		output("`2It jumps out and attacks you`n");                  
                  		addnav("Fight");
                  		addnav("Fight the ".get_module_setting("badguyname"),"runmodule.php?module=wellenutorf&step=battle");
                  	} else {
                  		output("`2You hear a horrible hissing noise, like pressure building up.`n"); 
                  		output("`2All of a sudden you hear a large bang.`n"); 
                 		output("`2You trip over backwards while your gems come flying out 30 foot into the air.`n"); 
                 		$amount = e_rand(1,$gemsthrown);
                 		switch($amount){
                   			case 1:
                   				$amountn = "`7only 1";
                   				break;
                   			case 2:
                   				$amountn = "`7only 2";
                   				break;
                   			case 3:
                   				$amountn = "`7all of them!";
	                   			break;				
                   		}
                   		if($amount == $gemsthrown){
                   			$amountn = "`7all of them!";
                   		}
                   		output("`2`nYou scramble around trying to collect them all, you manage to collect ".$amountn);
                   		$session['user']['gems'] += $amount;
                   		output("`2`n`nYou collect `7%s`2 gems`n",$amount);
                   		$amount = random(1, $session['user']['hitpoints']);
                   		if($amount > 1000){
                   			$amount = 1000;
                   		}
                   		$session['user']['hitpoints'] -= $amount;
                   		output("`2`n`nYou lost `7%s`2 hitpoints when you fell over`n",$amount);
                   	}
                  case 32:
                  case 66:
                  case 98:
                  case 97:
                  case 96:
                  case 95:
                       output("`2A gold ring suddenly appears on the pedestal!`n");
                       output("You quickly take it and place it upon your finger.`n");
                       output("A sharp pain quickly covers your entire body!`n`n");
                       $ringdeathchance = e_rand(1,5);
                       if ($ringdeathchance == 5){
                       output("`2You grasp the ring with all your might, trying to pull the ring off.`n");
                       output("The pain is tearing your body apart!`n");
                       output("Soon, you are far too weak to stand, and as you draw your last breath you can hear faint laughter coming from within the ring itself!`n`n");
                       output("`b`4You have died!`n");
			     output("Your gold is looted from your corpse by other travellers!`n");
			     output("10% of your experience has been lost!`n");
			     output("You may continue playing again tomorrow.");
			     $session['user']['alive']=false;
			     $session['user']['hitpoints']=0;
			     $session['user']['experience']*=0.9;
			     $gold = $session['user']['gold'];
			     $session['user']['gold'] = 0;
			     addnav("Daily News","news.php");
			     addnews("%s was last seen along a rugged trail deep in the forest.",$session['user']['name']);
			     debuglog("lost $gold from the Well of Enutorf.");
                       }elseif ($ringdeathchance == 1  ||  $ringdeathchance == 2  ||  $ringdeathchance == 3){
                       output("The pain quickly subsides however, and you feel more confident than ever!`n`n");
                       $charmgain = e_rand(2,4);
                       output("`^You have gained `7%s`^ charm!", $charmgain);
			     $session['user']['charm'] += $charmgain;
                       }else{
                       output("`2You grasp the ring with all your might, trying to pull the ring off.`n");
                       output("The pain is tearing your body apart!`n");
                       output("You are able to pry the ring off your finger just in time, and watch as it bursts into flames on the ground.`n");
                       output("You feel weakened from this horrible experience!`n`n");
                       output("`\$You lose a turn and most of your hitpoints!");
                       $hploss2 = round($session['user']['hitpoints'] * 0.9 ,0);
                       $session['user']['hitpoints'] -= $hploss2;
                       if ($session['user']['hitpoints']<1){
			     $session['user']['hitpoints']=1;}
                       $session['user']['turns']--;
                       if ($session['user']['turns']<0){
			     $session['user']['turns']=0;
			     }
			     }
                       break;
                  case 40:
                  case 41:
                        output("`2A small leather pouch suddenly appears on the pedestal!`n");
                        output("You turn it upside down in order to dump the contents out.`n`n");
                        $gemsgained =(e_rand(4,6));
                        $realgems = ($gemsgained - 3);
                        output("`^You find the three gems you donated to the well, plus `7%s`^ more!`n", $realgems);
                        output("`^You gain `7%s`^ gems!", $gemsgained);
                        $session['user']['gems'] += $gemsgained;
                        break;
                  case 42:
                  case 66:
                  case 78:
                        output("`2A small leather pouch suddenly appears on the pedestal!`n");
                        output("You turn it upside down in order to dump the contents out.`n");
                        output("A single gem falls out!  The well has ripped you off!`n`n");
                        output("`\$You gain `71`\$ gem...");
                        $session['user']['gems']++;
                        break;
                  case 43:
                  case 44:
                  case 67:
                  case 68:
                       output("`2A small glass bottle suddenly appears on the pedestal!`n");
                       output("Within, you see a small winged creature trapped.`n");
                       output("Taking pity, you uncork the bottle to set the creature free.`n");
                       output("The creature flies out and showers golden dust on you!`n`n");
                       output("`^Holy energy flows through your body!");
                       $golddustrounds = e_rand(15,25);
                       $atkresult2 = e_rand(15,25);
			     $goldbuff = array(
				"name"=>"`^Golden Dust",
				"rounds"=>$golddustrounds,
				"wearoff"=>"`7The holy magic fades.",
				"atkmod"=>(1+($atkresult2 / 100)),
                        "defmod"=>(1+($atkresult2 / 100)),
                        "survivenewday"=>$buff2,
				"roundmsg"=>"`7Your senses are more defined!",
				"schema"=>"module-wellenutorf"
			      );
			      apply_buff("goldbuff",$goldbuff);
			      $session['user']['specialinc']="";
                        break;
                  case 45:
                       output("`2A small glass bottle suddenly appears on the pedestal!`n");
                       output("Within, you see a small winged creature trapped.`n");
                       output("Taking pity, you uncork the bottle to set the creature free.`n");
                       output("The creature flies out and showers dark dust on you!`n`n");
                       output("`\$Dark energy flows through your body!");
                       $darkdustrounds = e_rand(15,20);
                       $atkresult3 = e_rand(10,20);
			     $darkbuff = array(
				"name"=>"`\$Dark Dust",
				"rounds"=>$darkdustrounds,
				"wearoff"=>"`7The dark magic leaves your body.",
				"atkmod"=>(1-($atkresult3 / 100)),
                        "defmod"=>(1-($atkresult3 / 100)),
                        "survivenewday"=>$buff3,
				"roundmsg"=>"`7Your mind is in a daze!",
				"schema"=>"module-wellenutorf"
			      );
			      apply_buff("darkbuff",$darkbuff);
			      $session['user']['specialinc']="";
                        break;
                  case 50:
                  case 69:
                  case 71:
                  case 72:
                       output("`2Something small suddenly appears on the pedestal!`n");
                       output("Upon closer inspection, you notice that it is a membership card to the Hunter's Lodge, with `7%s`2 Lodge Points on the card!`n`n", $donorpoints);
                       output("`^You have gained `7%s`^ Lodge Points!", $donorpoints);
                       $session['user']['donation'] += $donorpoints;
                       break;
                  case 51:
                  case 52:
                  case 74:
                  case 77:
                  case 79:
                       output("`2A bright light suddenly encompases the area!`n");
                       output("It quickly fades away however, and you notice something on the pedestal that wasn't there before!`n`n");
                       $previously_upgradedweapon = strpos($session['user']['weapon']," +1")!==false ? true : false;
                       $previously_upgradedarmor = strpos($session['user']['armor']," +1")!==false ? true : false;
                       $previously_downgradedarmor = strpos($session['user']['armor']," -1")!==false ? true : false;
                       $previously_downgradedweapon = strpos($session['user']['weapon']," -1")!==false ? true : false;
			     if (!$previously_upgradedweapon && !$previously_upgradedarmor && !$previously_downgradedarmor && !$previously_downgradedweapon){
			     $session['user']['weapon'] = $session['user']['weapon']." +1";
			     $session['user']['weapondmg']++;
			     $session['user']['attack']++;
			     $session['user']['weaponvalue']*=1.33;
                       $session['user']['armor'] = $session['user']['armor']." +1";
			     $session['user']['armordef']++;
			     $session['user']['defense']++;
			     $session['user']['armorvalue']*=1.33;
			     output("`^You find a `7%s`^ and a `7%s`^ on the pedestal!  You toss your old gear away in the bushes, and hastily take the new equipment!", $session['user']['weapon'], $session['user']['armor']);
			     }else{
                       $goldfind = $session['user']['level'] * (e_rand(200,300));
                       $gemfind = e_rand(2,3);
			     output("`^You find `7%s `^gold and `7%s`^ gems!", $goldfind, $gemfind);
                       $session['user']['gold'] += $goldfind;
                       $session['user']['gems'] += $gemfind;
                       }
			     break;
                  case 53:
                       output("`2The gold coin is ejected out of the well at frightening speed!`n");
                       output("It lands on the ground near the well, and you quickly run to pick it up.`n`n");
                       output("Not willing to test your luck against the unknown powers of the well again, you depart.");
                       set_module_pref("hascoin",1,"salesman");  
                       break;
                  case 54:
                  	if(get_module_setting("battle")){
                  		output("`2Ooops... There was a ".get_module_setting("badguyname")." down the well`n");
                  		output("`2It jumps out and attacks you`n");                  
                  		addnav("Fight");
                  		addnav("Fight the ".get_module_setting("badguyname"),"runmodule.php?module=wellenutorf&step=battle");
                  	} else {
                  		output("`2You hear a horrible hissing noise, like pressure building up.`n"); 
                  		output("`2All of a sudden you hear a large bang.`n"); 
                 		output("`2You trip over backwards while your gems come flying out 30 foot into the air.`n"); 
                 		$amount = e_rand(1,$gemsthrown);
                 		switch($amount){
                   			case 1:
                   				$amountn = "`7only 1";
                   				break;
                   			case 2:
                   				$amountn = "`7only 2";
                   				break;
                   			case 3:
                   				$amountn = "`7all of them!";
	                   			break;				
                   		}
                   		if($amount == $gemsthrown){
                   			$amountn = "`7all of them!";
                   		}
                   		output("`2`nYou scramble around trying to collect them all, you manage to collect ".$amountn);
                   		$session['user']['gems'] += $amount;
                   		output("`2`n`nYou collect `7%s`2 gems`n",$amount);
                   		$amount = random(1, $session['user']['hitpoints']);
                   		if($amount > 1000){
                   			$amount = 1000;
                   		}
                   		$session['user']['hitpoints'] -= $amount;
                   		output("`2`n`nYou lost `7%s`2 hitpoints when you fell over`n",$amount);
                   	}
                  case 55:
                       output("`2Something small suddenly appears on the pedestal!`n");
                       output("Upon closer inspection, you notice that it is a membership card to the Hunter's Lodge, with `7%s`2 Lodge Points on the card!`n`n", $donorpoints2);
                       output("`^You have gained `7%s`^ Lodge Points!", $donorpoints2);
                       $session['user']['donation'] += $donorpoints2;
                       break;
                  case 57:
                  case 67:
                  case 78:
                  case 89:
                  	output("`2A small thing flys towards you and screams, \"`3Watch out!! Gem storm!!!`2\"`n");
                  	output("`2You wonder what it was on about...`n");
                  	output("`2Suddenly you see... thousands of gems falling out of the sky!`n");
                  	output("`2You scramble around trying to grab them all`n");
                  	$amount = e_rand(100,200);
                  	output("`2You manage to grab `7%s`2 of the gems!`n",$amount);
                  	output("`2As you stand up you notice a few gems have become lodged in your head.`n");
                  	output("`2You pull the `7%s`2 gems out of you skull.`n",e_rand(1,3));
                  	if(e_rand(1,100) == 50){
                       output("`2As soon as you pull them out blood starts spurting out everywhere`n");
                       output("`b`4At was just a case of time.... You have died!`n");
			     output("Your gold is looted from your corpse by other travellers!`n");
			     output("10% of your experience has been lost!`n");
			     output("You may continue playing again tomorrow.");
			     $session['user']['alive']=false;
			     $session['user']['hitpoints']=0;
			     $session['user']['experience']*=0.9;
			     $gold = $session['user']['gold'];
			     $session['user']['gold'] = 0;
			     addnav("Daily News","news.php");
			     addnews("%s was last seen along a rugged trail deep in the forest.",$session['user']['name']);
			     debuglog("lost $gold from the Well of Enutorf.");                  	
                  	} else {
                  	  output("`2You quickly heal the wounds with a potion on the side of the well`n");
                  	}
                  	break;
                 case 100:
                     output("`2You feel a slight rumble under your feet.`n");
                     output("`2Suddenly a huge alien like creature jumps out from the well`n");
                     output("`2\"`7You have angered the gods with such a worthless gift! You will pay with your life!`2\", it states.");
                     output("`2Suddenly it raises its arm and brings it down on your head.`n");
                       output("`b`4You have died!`n");
			     output("Your gold is looted from your corpse by other travellers!`n");
			     output("10% of your experience has been lost!`n");
			     output("You may continue playing again tomorrow.");
			     output("The monster throws the tarnished coin onto your corpse.");
			     set_module_pref("tarnishedcoin",1,"coins");
			     $session['user']['alive']=false;
			     $session['user']['hitpoints']=0;
			     $session['user']['experience']*=0.9;
			     $gold = $session['user']['gold'];
			     $session['user']['gold'] = 0;
			     addnav("Daily News","news.php");
			     addnews("%s was last seen along a rugged trail deep in the forest.",$session['user']['name']);
			     debuglog("lost $gold from the Well of Enutorf.");
			     break;

              default:
               output("`2Nothing happens!`n");
               output("What a shame!`n`n");
               output("You walk away, wondering if your luck will be better another day.");


	     }
}
}


?>