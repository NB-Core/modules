<?php
/*
* Name:    Butter Cup - April 18, 2005
* Author:  Robert of Maddrio dot com
* History: Converted to 1.0 from ver097
* Note:    No settings needed
*/
function buttercup_getmoduleinfo(){
	$info = array(
	"name"=>"Butter Cup",
	"version"=>"1.1",
	"author"=>"`2Robert",
	"category"=>"Forest Specials",
	"download"=>"http://dragonprime.net/users/Robert/buttercup098.zip",
	);
	return $info;
}

function buttercup_install(){
	module_addeventhook("forest", "return 100;");
	return true;
}

function buttercup_uninstall(){
	return true;
}

function buttercup_dohook($hookname,$args){
	return $args;
}

function buttercup_runevent($type){
global $session;
output("`n`n`2 You discover a patch of `6honeysuckle `2and `^buttercups`2. `n`n");
output(" You admire the beauty of the flowers, and savor the sweet smell. `n`n");
output(" As you breath in the heavenly scent, you sit down next to a shade tree and doze off. `n`n");
if ($session['user']['hitpoints'] < $session['user']['maxhitpoints']){
	output("`6 When you awake, you feel refreshed!");
	$session['user']['hitpoints']+=5;
}else{
	output("`6 Your little nap has cost you time for 1 forest fight.");
	$session['user']['turns']--;
}
}

function buttercup_run(){
}
?>