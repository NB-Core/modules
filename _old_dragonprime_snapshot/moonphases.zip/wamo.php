<?php
//Idea and programming
//Morpheus for www.morpheus-lotgd.de.vu
//Mail to Morpheus@magic.ms
//Dedicated to my beloved, little flower
//Change Mond1 and Mond2 to the name of your moons
require_once "common.php";
$m1=$settings['mond1'];
$m2=$settings['mond2'];
if ($session['user']['alive']){ 
}else{
	redirect("shades.php");
}
page_header("The moons");
if($_GET_VARS['op']==""){
	output("`c`b`6The moons`0`b`c");
	output("`3You wlak to a place, where you can have a look through the thick `2tree tops `3up to the sky, where the `^2 moons `3 are standing.`n");
	output("`6Mond1 `9is `^$m1`9, `6Mond2 `9is `^$m2`9 seen on the sky.`0`n");
	addnav("Back","forest.php");
}
page_footer();
?>