<?php
//addnews ready
// mail ready
// translator ready

/*******************************************
This specialty, and those of the White and Grey Knights are meant to have alignment restrictions
but, I can't seem to get those restrictions to happen for some reason, so they're currently not
part of the specialties.
*******************************************/
function specialtyblackknight_getmoduleinfo(){
    $info = array(
        "name" => "Specialty - Black Knight",
        "author" => "`6Admin Lexington, `2Alignment Ready Fixed by `4Zelion",
        "version" => "1.0",
        "download" => "http://dragonprime.net/users/zelion/specialtyblackknight.zip",
        "category" => "Specialties",
        "settings"=> array(
             "Specialty - Black Knight Settings,title",
             "alignment"=>"What is the alignment requirement for this specialty?,int|33",
             "mindk"=>"How many DKs do you need before the specialty is available?,int|25",
             "cost"=>"How many points do you need before the specialty is available?,int|0",
             "loss"=>"How much Alignment is lost when specialty is chosen,int|5",
      ),
        "prefs" => array(
            "Specialty - Black Knight User Prefs,title",
            "skill"=>"Skill points in Black Knight,int|0",
            "uses"=>"Uses of Black Knight allowed,int|0",
        ),
    );
    return $info;
}

function specialtyblackknight_install(){
    $sql = "DESCRIBE " . db_prefix("accounts");
    $result = db_query($sql);
    $specialty="BK";
    while($row = db_fetch_assoc($result)) {
        // Convert the user over
        if ($row['Field'] == "blackknight") {
            debug("Migrating blackknight field");
            $sql = "INSERT INTO " . db_prefix("module_userprefs") . " (modulename,setting,userid,value) SELECT 'specialtyblackknight', 'skill', acctid, blackknight FROM " . db_prefix("accounts");
            db_query($sql);
            debug("Dropping blackknight field from accounts table");
            $sql = "ALTER TABLE " . db_prefix("accounts") . " DROP blackknight";
            db_query($sql);
        } elseif ($row['Field']=="blackknightuses") {
            debug("Migrating blackknight uses field");
            $sql = "INSERT INTO " . db_prefix("module_userprefs") . " (modulename,setting,userid,value) SELECT 'specialtyblackknight', 'uses', acctid, blackknightuses FROM " . db_prefix("accounts");
            db_query($sql);
            debug("Dropping blackknightuses field from accounts table");
            $sql = "ALTER TABLE " . db_prefix("accounts") . " DROP blackknightuses";
            db_query($sql);
        }
    }
    debug("Migrating Blackknight Specialty");
    $sql = "UPDATE " . db_prefix("accounts") . " SET specialty='$specialty' WHERE specialty='1'";
    db_query($sql);

    module_addhook("choose-specialty");
    module_addhook("set-specialty");
    module_addhook("fightnav-specialties");
    module_addhook("apply-specialties");
    module_addhook("newday");
    module_addhook("incrementspecialty");
    module_addhook("specialtynames");
    module_addhook("specialtymodules");
    module_addhook("specialtycolor");
    module_addhook("dragonkill");
    return true;
}

function specialtyblackknight_uninstall(){
    // Reset the specialty of anyone who had this specialty so they get to
    // rechoose at new day
    $sql = "UPDATE " . db_prefix("accounts") . " SET specialty='' WHERE specialty='BK'";
    db_query($sql);
    return true;
}

function specialtyblackknight_dohook($hookname,$args){
    global $session,$resline;

    $spec = "BK";
    $name = "Black Knight";
    $ccode = "`)";
    $cost = get_module_setting("cost");
    $loss = get_module_setting("gain");

    switch ($hookname) {
        case "pointsdesc":
            $args['count']++;
            $format = $args['format'];
            $str = translate("The White Knight Specialty is availiable upon reaching %s Dragon Kills and %s points.");
            $str = sprintf($str, get_module_setting("mindk"), $cost);
            output($format, $str, true);
        break;

        case "newday":
            $bonus = getsetting("specialtybonus", 1);

            if($session['user']['specialty'] == $spec) {
                if ($bonus == 1) {
                    output("`n`3For being interested in %s%s`3, you gain `^1`3 extra use of `&%s%s`3 for today.`n",$ccode,$name,$ccode,$name);
                }

                else {
                    output("`n`3For being interested in %s%s`3, you gain `^%s`3 extra uses of `&%s%s`3 for today.`n",$ccode,$name,$bonus,$ccode,$name);
                }
            }

            $amt = (int)(get_module_pref("skill") / 3);
            if ($session['user']['specialty'] == $spec) $amt++;
                set_module_pref("uses", $amt);
            if (is_module_active('alignment') && $session['user']['specialty'] == 'BK') {
                output("`nYour unholy calling has lowered your alignment.`n");
                align("-1");
            }
        break;

        case "dragonkill":
            set_module_pref("uses", 0);
            set_module_pref("skill", 0);
        break;

   case "choose-specialty":
	if (get_module_pref("alignment","alignment") <= get_module_setting("alignment")) {
    if ($session['user']['specialty'] == "" || $session['user']['specialty'] == '0') {
                $pointsavailable = $session['user']['donation'] - $session['user']['donationspent'];
                if ($session['user']['dragonkills'] < get_module_setting("mindk") || get_module_setting("cost") > $pointsavailable) break;
                addnav("$ccode$name`0","newday.php?setspecialty=".$spec."$resline");
                $t1 = translate_inline("Killing, because you like it.");
                $t2 = appoencode(translate_inline("$ccode$name`0"));
                rawoutput("<a href='newday.php?setspecialty=$spec$resline'>$t1 ($t2)</a><br>");
                addnav("","newday.php?setspecialty=$spec$resline");
            }
	}
    break;

    case "set-specialty":
        if($session['user']['specialty'] == $spec) {
            page_header($name);
            $session['user']['donationspent'] = $session['user']['donationspent'] - $cost;
            output("`)The Black Knights, legendary foes of old, were believed to be have been wiped out by the Whites.");
            output(" You proved them wrong when you found the abandoned temple, guarded by the last of their order.");
            output(" Knowing that his end was near, he offered to teach you the secrets of Darkness.");
            output(" And just before his death, he dubbed you a Black Knight.");
            output(" Little did you know, that you were destined for so much more...");
            if (is_module_active('alignment')) {
                set_module_pref('alignment',get_module_pref('alignment','alignment') - $loss,'alignment');
                }
        }
    break;

    case "specialtycolor":
            $args[$spec] = $ccode;
    break;

    case "specialtynames":
        $pointsavailable = $session['user']['donation'] - $session['user']['donationspent'];
        if ($session['user']['superuser'] & SU_EDIT_USERS || $session['user']['dragonkills'] >= get_module_setting("mindk") || get_module_setting("cost") <= $pointsavailable){
            $args[$spec] = translate_inline($name);
        }
    break;

    case "specialtymodules":
        $args[$spec] = "specialtyblackknight";
    break;

    case "incrementspecialty":
        if($session['user']['specialty'] == $spec) {
            $new = get_module_pref("skill") + 1;
            set_module_pref("skill", $new);
            $c = $args['color'];
            $name = translate_inline($name);
            output("`n%sYou gain a level in `&%s%s to `#%s%s!",
            $c, $name, $c, $new, $c);
            $x = $new % 3;
            if ($x == 0){
                output("`n`^You gain an extra use point!`n");
                set_module_pref("uses", get_module_pref("uses") + 1);
            }
            else{
                if (3-$x == 1) {
                    output("`n`^Only 1 more skill level until you gain an extra use point!`n");
                }
                else {
                    output("`n`^Only %s more skill levels until you gain an extra use point!`n", (3-$x));
                }
            }
        output_notl("`0");
        }
    break;

    case "fightnav-specialties":
        $uses = get_module_pref("uses");
        $script = $args['script'];
        if ($uses > 0) {
            addnav(array("$ccode$name (%s points)`0", $uses),"");
            addnav(array("$ccode &#149; Dark Death`7 (%s)`0", 1),
            $script."op=fight&skill=$spec&l=1", true);
        }
        if ($uses > 1) {
            addnav(array("$ccode &#149; Cleave`7 (%s)`0", 2),
            $script."op=fight&skill=$spec&l=2",true);
        }
        if ($uses > 2) {
            addnav(array("$ccode &#149; Withering Disease`7 (%s)`0", 3),
            $script."op=fight&skill=$spec&l=3",true);
        }
        if ($uses > 4) {
            addnav(array("$ccode &#149; Smite`7 (%s)`0", 5),
            $script."op=fight&skill=$spec&l=5",true);
        }
        break;
    case "apply-specialties":
        $skill = httpget('skill');
        $l = httpget('l');
        if ($skill==$spec){
            if (get_module_pref("uses") >= $l){
                switch($l){
                case 1:
                    apply_buff('Bk1',array(
                        "startmsg"=>"`5You hold out your hand and a cloud of darkness consumes the {badguy}.",
                        "name"=>"`5Dark Death",
                        "rounds"=>round($session['user']['level']+5),
                        "minioncount"=>1,
                        "maxbadguydamage"=>round($session['user']['level']),
                        "minbadguydamage"=>round($session['user']['level']),
                        "effectmsg"=>"You can't see the {badguy}, but you can sure hear them scream as they take `^{damage}`) points!",
                        "schema"=>"specialtyblackknight"
                    ));
                    break;
                case 2:
                    apply_buff('Bk2',array(
                        "startmsg"=>"`5You repeatedly strike powerful blows at the {badguy} `5with all the strength you can summon. ",
                        "name"=>"`5Cleave",
                        "rounds"=>10,
                        "wearoff"=>"You can't help but smile at the amount of destruction you've caused.",
                        "minioncount"=>round($session['user']['level']/3)+1,
                        "maxbadguydamage"=>round($session['user']['level']*1.5,0),
                        "effectmsg"=>"`5You hit {badguy}`5 with your {weapon} for `\${damage}`5 damage.",
                        "effectnodmgmsg"=>"`5You swing your {weapon} at {badguy}`5 but `\$MISS`)!",
                        "schema"=>"specialtyblackknight"
                    ));
                    break;
                case 3:
                    apply_buff('Bk3',array(
                        "startmsg"=>"`5You call upon the filth of darkness to envelope and cripple the {badguy}.",
                        "name"=>"`5Withering Disease",
                        "rounds"=>10,
                        "wearoff"=>"`)The disease finally wears off, and the {badguy} regain his strength.",
                        "badguyatkmod"=>0,
                        "badguydefmod"=>0,
                        "roundmsg"=>"`5The {badguy} `5tries to lift his weapon to attack, but can barely move even a fraction of an inch.",
                        "schema"=>"specialtyblackknight"
                    ));
                    break;
                case 5:
                    apply_buff('Bk5',array(
                             "startmsg"=>"`5You call upon the strength of the Darkness and use it to smite the {badguy}.",
                            "name"=>"`5Smite",
                            "rounds"=>10,
                            "wearoff"=>"`)You release the dark powers, unable to control them any longer without destroying yourself.",
                            "badguyatkmod"=>.1,
                            "badguydefmod"=>.1,
                            "atkmod"=>2,
                            "defmod"=>2,
                            "effectmsg"=>"`5Your `b`5Smite`b`5 hits {badguy}`5 for `\${damage}`) damage.",
                            "roundmsg"=>"`5{badguy} `5stands motionless, taking the beating that only a Black Knight could give him.",
                            "schema"=>"specialtyblackknight"
                    ));
                    break;
                }
                set_module_pref("uses", get_module_pref("uses") - $l);
                }else{
                    apply_buff('Bk0', array(
                        "startmsg"=>"Lacking the strength to continue, you try to raise your sword to attack and defend yourself, but the {badguy} only laughs and lunges forward to attack!",
                        "rounds"=>1,
                        "schema"=>"specialtyblackknight"
                    ));
                }
        }
        break;
    }
    return $args;
}

function specialtyblackknight_run(){
}
?>