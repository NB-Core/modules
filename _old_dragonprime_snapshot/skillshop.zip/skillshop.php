<?php
//skillshop.php
//2.0 updated nav, preference and cost - Thanks to Kendaer
function skillshop_getmoduleinfo(){
    $info = array(
        "name"=>"Minzer's Skill Shop",
        "version"=>"2.3",
        "author"=>"Reznarth<br>Updated by: Chris Vorndran",
        "category"=>"Village",
        "download"=>"http://dragonprime.net/index.php?module=Downloads;sa=dlview;id=30",
		"vertxtloc"=>"http://dragonprime.net/users/Sichae/",
		"description"=>"User can pay to have their specialty usage points refreshed.",
		"settings"=>array(
			"Skillshop Settings,title",
	            "cost"=>"Gold needed to refresh skills `ibased on level`i,int|1000",
				"max"=>"Max refreshes per day,int|1",
			"Minzer Specifications,title",
				"race"=>"What Race is Minzer,text|Elf",
				"descrip"=>"What does Minzer look like,textarea|Minzer is a tall male, about six feet. His ears are quite rigid and perk at the slightest noise. He has a long flowing mane of blonde hair, with a blue glint to his eyes.",
			"Minzer's Location,title",
				"mindk"=>"What is the minimum DK before this shop will appear to a user?,int|0",
				"shoploc"=>"Where does Minzer appear,location|".getsetting("villagename", LOCATION_FIELDS)
		),
		"prefs"=>array(
			"Skillshop User Preferences,title",
			"refresh"=>"How many times did they refresh skills today,int|0",
		),
    );
    return $info;
}
function skillshop_install(){
    module_addhook("village");
    module_addhook("newday");
	module_addhook("changesetting");
    return true;
}

function skillshop_uninstall(){
    return true;
}

function skillshop_dohook($hookname,$args){
	global $session;
	switch($hookname){
	case "newday":
		set_module_pref("refresh",0);
		break;
	case "changesetting":
    if ($args['setting'] == "villagename") {
    if ($args['old'] == get_module_setting("shoploc")) {
       set_module_setting("shoploc", $args['new']);
       }
    }
    break;
  	case "village":
		if ($session['user']['location'] == get_module_setting("shoploc")
		&& $session['user']['dragonkills'] >= get_module_setting("mindk")) {
		tlschema($args['schemas']['marketnav']);
        addnav($args['marketnav']);
		tlschema();
		addnav("Minzer's Skill Shop","runmodule.php?module=skillshop&op=enter");
	}
		break;
	}
	return $args;
}
function skillshop_run(){
	global $session;
	$specialties = modulehook("specialtymodules");
	$spec = $specialties[$session['user']['specialty']];
	$uses =  get_module_pref("uses", $spec);
	$amt = get_module_pref("skill", $spec) / 3;
	$op = httpget('op');
	$refresh = get_module_pref("refresh");
	$max = get_module_setting("max");
	$cost = (get_module_setting("cost")*$session['user']['level']);
	$gold = $session['user']['gold'];
	tlschema("list"); 
	$race = translate_inline(get_module_setting("race")); 
	tlschema();
	$descrip = get_module_setting("descrip");
	page_header("Minzer's Skill Shop");
	
	switch ($op){
		case "enter":
			if ($refresh < $max){
				output("`)You wander into a small alley, noticing the flickering lights from the old abandoned shoppes.");
				output(" On the ground, you find a small puzzle box.");
				output(" You poke at it with your `&%s`), hoping to jar some kind of spirit.",$session['user']['weapon']);
				output(" A blinding light lifts you off of your feet and tosses you through a window.");
				output(" You hit the ground with a thud and see a tall %s.",$race);
				if ($descrip <> "")	output_notl("`n`n%s.",$descrip);
				output(" He takes your hand and lifts you effortlessly.`n`n");
				output("\"`2Hello, my name is Minzer... how may I be of service to you?`)\" he asks.");
				output(" You see a small pamphlet and see that Minzer will refresh your magic.");
				output(" Cost is only `^%s `)gold.`n", $cost);
				if ($session['user']['gold']>=$cost) {
					addnav(array("Refresh Skills - %s Gold",$cost),"runmodule.php?module=skillshop&op=refresh"); 
				}else{
					output("`n`@You need `^%s `@more gold to do this.",$cost - $gold); 
				}
				if ($uses >= $amt){
					output("`n`)Minzer stares at the magical aura about you.");
					output("\"`2You do not need to refresh today...`)\"");
					blocknav("runmodule.php?module=skillshop&op=refresh");
				}
			}else{
				output("`)Minzer stares at you, \"`2You need to come back at the newday... my powers are weak now from helping you earlier...`)\"");
			}
			break;
		case "refresh":
			$specialties = modulehook("specialtymodules");
			foreach ($specialties as $key=>$name) {
				if ($session['user']['specialty'] == $key){
					$amt = (int)(get_module_pref("skill", $name) / 3); 
					$amt++;
					set_module_pref("uses", $amt, $name);
				}
			}
			$session['user']['gold']-=$cost;
			set_module_pref("refresh",1);
			output("`)Minzer smiles and takes your `^%s `)gold.",$cost);
			output("\"`2Your skills have been refreshed.`)\"");
			break;
		}
villagenav();
page_footer(); 
}
?>