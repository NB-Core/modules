<?php

function mushstrength_getmoduleinfo()
{
	$info = array(
		"name"=>"Mushroom Strength",
		"version"=>"1.01",
		"author"=>"RPGSL",
		"category"=>"RPGSL",
		"download"=>"http://www.rpdragon.com/lotgd/mushstrength.zip",
	);
	return $info;
}

function mushstrength_install()
{
	module_addeventhook("forest", "return 100;");
	module_addhook("changesetting");

	return true;
}

function mushstrength_uninstall()
{
	return true;
}

function mushstrength_dohook($hookname,$args)
{
	return $args;
}

function mushstrength_runevent($type)
{
	global $session;
	$from = "forest.php?";
	$session['user']['specialinc']="module:mushstrength";

	$op = httpget('op');
	if ($op=="" || $op=="search")
	{
		output("`#Having been wandering in the Forest for as long as you have, you collapse to your knees, unable to think of anything else except how much you are in need of some energy.`n");
		output("`nYour head feels heavy, and your eyes lids feel even heavier, but just when you're about to rest them, you spot a Mushroom Patch, just off to your right.`n");
		output("`nYou've heard of mystical mushrooms out in the forest, but have also heard of poisonous ones as well.`n");
		output("`nYou strain to remember which ones looked like which, but in your tired state, your memory fails you.`n");
		output("`nThese mushrooms could help you ... or ... could make things worse`n");
		output("`nDo you wish to take a bite?");
		addnav("Take a bite", $from . "op=bite");
		addnav("Leave them be", $from . "op=nobite");
	}
	elseif ($op=="bite")
	{
		$session['user']['attack']=$session['user']['attack'];
		$rand = e_rand(1,2);
		//output("Unknowing if you'd find your way out of the Forest in time to assuage your lack of energy, you decided to take the chance...`n`n`n");
		switch ($rand)
		{
		case 1:
			output("Crawling over to the Mushroom Patch, you pluck one of the mushrooms up from the earth and raise it to your mouth for a nice, big, healthy bite!");
			output("Almost as soon as you do, you feel a tingling kind of force begin twirling about inside of you, and for just a moment, you feel dizzy, but when it fade only a second later, you jump up to your feet, feeling as good as new! Your health is fully restored and you feel stronger !`n`n");
			if ($session['user']['turns']>0) $session['user']['turns']--;
			$session['user']['hitpoints']=$session['user']['maxhitpoints'];
			$session['user']['attack']++;
			break;			
		case 2:
			output("Unknowing if you'd find your way out of the forest in time to assuage your lack of energy, you decided to take the chance!`n`n");
			output("Crawling over to the Mushroom Patch, you pluck one of the mushrooms up from the earth and gaze at it for a moment, thinking that they were rather ugly mushrooms, but then ... when have mushrooms ever been pretty? Shrugging, you close your eyes, and take something that could hardly be considered a bite, out of it. `n`n");
			output("Almost as soon as you do, you feel a sudden tightness in your chest, and you clutch at your chest, the mushroom falling forgotten back into the grass. A second later, your eyes roll back into your head, and you fall to the ground like a ton of bricks ...`n`n");
			output("You feel all the weaker and even now your weapon seems heavier. What have you done?!`n");
			if ($session['user']['turns']>0) $session['user']['turns']--;
			$session['user']['attack']--;
			break;				
		}
	}
	else
	{
		$session['user']['specialinc']="";
		output("`#Deciding it might not be best, you let it be, and return to the forest.`0");
	}
}

function mushstrength_run()
{
}

?>