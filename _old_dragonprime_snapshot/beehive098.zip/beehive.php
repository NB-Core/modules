<?php
// Based off of a 097 forest event I use, holytree.php

function beehive_getmoduleinfo(){
	$info = array(
	"name"=>"Bee Hive",
	"version"=>"1.1",
	"author"=>"`2Robert",
	"category"=>"Forest Specials",
	"download"=>"http://dragonprime.net/users/robert/beehive098.zip",
	"settings"=>array(
	"Bee Hive Settings,title",
	"percentage"=>"Chance player gains or loses 2 turns,range,0,100,1|50"
	),
	);
	return $info;
}

function beehive_install(){
	module_addeventhook("forest","return 100;");
	return true;
}

function beehive_uninstall(){
	return true;
}

function beehive_dohook($hookname,$args){
	return $args;
}

function beehive_runevent($type){
	global $session;
	$chance = get_module_setting("percentage");
	$rand = e_rand(1,100);
	if ($rand <= $chance) {
	output("`n`n`2 You discover a bee hive hanging from a low branch of a tree. ");
	output(" Seeing it is no longer active, you decide to see if there is any honey inside. ");
	output(" Breaking it open, you see some honey and decide to taste it. ");
	output(" The honey is sweet and gives you a burst of energy! `n`n");
	output(" You `^receive 2 extra turns`2! ");
	$session['user']['turns']+=2;
	}else{
	output("`n`n`2 You discover a bee hive hanging from a low branch of a tree. ");
	output(" Seeing no bee's flying around, you decide to see if there is any honey inside. ");
	output(" As you break open the hive, several angry bee's chase after you. ");
	output(" You run as swiftly as you can! `n`n ");
	if ($session['user']['turns'] >=2 ) {
		output(" You run till you're exhausted and `^lose 2 `2 turns! ");
		$session['user']['turns']-=2;
		}
	}
}

function beehive_run(){
}
?>