<?php
/*
Module Name:  Strigoi Tower
Category:  Forest Specials
Worktitle:  strigoitower
Author:  DaveS
Date: November 15, 2005
Additional Modules for full function:
potions.php
Module should function without its installation

Description:
Another "multi-visit" forest special involving at least 6 visits to search through a Vampire's tower, ending with
the obvious confrontation with Strigoi the Vampire.

v3.01 tried to improve "translation readiness"
v3.02 More translation readiness
v3.03 Changed exp loss from Obliviax to a setting
v3.05 Hof fixes

*/
function strigoitower_getmoduleinfo(){
	$info = array(
		"name"=>"Strigoi Tower",
		"version"=>"3.05",
		"author"=>"DaveS, HoF by Arieswind",
		"category"=>"Forest Specials",
		"download"=>"http://dragonprime.net/index.php?module=Downloads;sa=dlview;id=185",
		"vertxtloc"=>"",
		"description"=>"An adventure into a Vampire's Tower.",
		"settings"=>array(
			"Strigoi Tower Settings, title",
			"dksneeeded"=>"How many dks needed before encountering this forest special?,int|0",
			"percentloss"=>"What percentage of experience lost if killed by Obliviax?,range,1,100,1|7",
			"usepics"=>"Use images?,bool|1",
			"bio"=>"Show title in Bio?,bool|0",
			"hof"=>"Use HoF?,bool|0",
			"pp"=>"Number of players to show per page on the HoF?,int|25",
			"translation"=>"Make translation ready for non-English?,bool|0",
			"Change to Yes for any Non-English server to use,note",
		),
		"prefs"=>array(
			"Strigoi Tower Preferences,title",
			"towercheck"=>"Been to the tower in the forest this newday?,bool|0",
			"visitnum"=>"What phase are they currently on?,enum,0,The Tower,1,The Stake,2,The Library,3,The Bedroom,4,The Basement,5,Vampire's Den|0",
			"monsternum"=>"What monster did they fight last?,enum,1,Obliviax,2,Hellhound,3,Bookcase,4,Bear,5,Wolf,6,Bats,7,Vampire|1",
			"completednum"=>"How many times did they complete the quest?,int|0",
			"The Library,title",
			"goodlib"=>"Where is the key to the master bedroom hidden?,enum,0,Nowhere,1,Bookcase,2,Desk,3,Bear Rug,4,Wine Bottle|0",
			"badlib"=>"What location is booby-trapped?,enum,0,Nowhere,1,Bookcase,2,Desk,3,Bear Rug,4,Wine Bottle|0",
			"gotkey"=>"Has player found the key?,bool|0",
			"The Bedroom,title",
			"bedroom"=>"What area did they search last?,enum,0,None,1,Window,2,Bed,3,Dresser,4,Closet|0",
			"searchbed"=>"Have they killed the wolf under the bed without getting the key?,bool|0",
			"searchdresser"=>"Have they searched the dresser?,bool|0",
			"searchcloset"=>"Have they searched the closet?,bool|0",
			"The Closet,title",
			"pushheart"=>"How many times did they decline pushing the heart?,int|0",
		),
	);
	return $info;
}

function strigoitower_chance() {
	global $session;
	if (get_module_pref('towercheck','strigoitower',$session['user']['acctid'])==1 || (($session['user']['dragonkills']<get_module_setting('dksneeeded','strigoitower',$session['user']['acctid'])) && get_module_pref('towercheck','strigoitower',$session['user']['acctid'])==0)) return 0;
	else return 100;
}

function strigoitower_install(){
	module_addeventhook('forest','require_once(\'modules/strigoitower.php\'); return strigoitower_chance();');
	module_addhook("newday");
	module_addhook("footer-hof");
	module_addhook("bioinfo");
	if (is_module_active("potions")) module_addhook("potions");
	return true;
}

function strigoitower_uninstall(){
	return true;
}

function strigoitower_dohook($hookname,$args){
	global $session;
	switch ($hookname) {
		case "newday":
		set_module_pref("towercheck",0);
		break;
		case "footer-hof":
		if (get_module_setting("hof")==1){
			addnav("Warrior Rankings");
			addnav("Vampire Slayers","runmodule.php?module=strigoitower&op=hof");
			addnav("Vampire Quest Status","runmodule.php?module=strigoitower&op=hof2");
		}
		break;
		case "bioinfo":
		if (get_module_setting("bio")==1){
			$completednum = get_module_pref("completednum","strigoitower",$args['acctid']);
			if ($completednum>=1) {
				$titlearray = array(
					1=>translate_inline("`^Ghoul Vanquisher"),
					2=>translate_inline("`@Cadaver Exorciser"),
					3=>translate_inline("`#Revenant Slayer"),
					4=>translate_inline("`1Defiler Abolisher"),
					5=>translate_inline("`6Bane of Strigoi"),
					6=>translate_inline("`3Feared by Undead"),
					7=>translate_inline("`QVampire Hunter"),
					8=>translate_inline("`!Nosferatu Slayer"),
					9=>translate_inline("`\$Lich Slayer"),
					10=>translate_inline("`%Slayer of the Damned"),
					11=>translate_inline("`^`bDestroyer of Elder Vampires`b")
				);
				output("`^Vampire Slayer Title: %s`n", $titlearray[$completednum]);
			}
		}
		break;
	}
	return $args;
}

function strigoitower_runevent($type) {
	global $session;
	$session['user']['specialinc']="module:strigoitower";
	$op = httpget('op');
	addnav("What do you do?");
	set_module_pref("towercheck",1);
	output("`n`)");
	//The Tower
	if (get_module_pref("visitnum")==0){
		if (get_module_setting("translation")==0){
			output("`^A strange <FONT COLOR=#ABABAB>f</FONT><FONT COLOR=#707070>o</FONT><FONT COLOR=#ABABAB>g</FONT>`^ engulfs the surrounding `@forest`^.  As you take several steps forward and end up stubbing your toe against a `)stone`^.",true);
			output("`n`nYou look carefully around and notice a spiralling staircase leading up a tall tower.  Your mind wanders back to the rumors spreading around the village about a new evil in the `@forest`^.`n`nPerhaps this is your chance to become a hero and slay...`n`n`c");
			rawoutput("<font size='+1'><span style=\"width: 150; height: 30; color: #000000; filter: glow(color=#FF3333, strength=7)\">The Vampire!</span>");
			output("`c");
			}else{
			output("`^A strange `)fog`^ engulfs the surrounding `@forest`^.");
			output("As you take several steps forward and end up stubbing your toe against a `)stone`^.");
			output("`n`nYou look carefully around and notice a spiralling staircase leading up a tall tower.");
			output("Your mind wanders back to the rumors spreading around the village about a new evil in the `@forest`^.");
			output("`n`nPerhaps this is your chance to become a hero and slay...`n`n`c`b`Q");
			output("The Vampire!`b`c");
		}
		if (get_module_setting("usepics")==1) rawoutput("<br><center><table><tr><td align=center><img src=modules/strigoitower/eviltower.jpg></td></tr></table></center><br></font>");
		addnav("Find a Wooden Stake","runmodule.php?module=strigoitower&op=thestake");
		addnav("Return to the Forest","runmodule.php?module=strigoitower&op=forest");
	}
	//The Stake
	if (get_module_pref("visitnum")==1){
		output("The trees become more dense as you travel through the forest.");
		output("Your muscles start to ache as the terrain becomes too difficult to traverse.");
		output("There's not much more you can do but rest.");
		output("`n`nYou lean against a tree for a moment.");
		output("A cold chill runs through you as feel the tree moving.");
		output("`n`nAn earthquake?");
		output("`n`nQuicksand?`n`n");
		output("Or perhaps something even more menacing.");
		output("`n`nYou turn to the tree and realize that it's alive!");
		output("You have come face to face with an unnatural evil.`n`n");
		output("It's an `b`QO`qbliviax`)`b!!");
		if (get_module_setting("usepics")==1) rawoutput("<br><center><table><tr><td align=center><img src=modules/strigoitower/obliviax.gif></td></tr></table></center><br>");
		set_module_pref("monsternum",1);
		addnav("Fight the `QO`qbliviax","runmodule.php?module=strigoitower&op=attack");
	}
	//The Library
	if (get_module_pref("visitnum")==2){
		output("You arrive again at the footsteps of the `\$Vampire's Tower`) and gather your `6wooden stakes`).");
		output("It's time to resume the adventure.`n`n");
		if (get_module_setting("usepics")==1) rawoutput("<br><center><table><tr><td align=center><img src=modules/strigoitower/eviltower.jpg></td></tr></table></center><br>");
		addnav("Travel to the Tower","runmodule.php?module=strigoitower&op=thetower");
		addnav("Return to the Forest","runmodule.php?module=strigoitower&op=forest");
	}
	//The Bedroom or The Closet
	if (get_module_pref("visitnum")==3 || get_module_pref("visitnum")==4){
		output("Back to the `QVampire's Tower`)!");
		output("You do an inventory check:");
		output("`n`n`c`6Wooden Stakes`n");
		output("`%Bedroom Key");
		if (get_module_pref("visitnum")==4)	output("`n`\$The Secret to the Closet");
		output("`n`n`c`)It's time to resume the adventure.`n`n");
		if (get_module_pref("visitnum")==3) addnav("Travel to the Tower","runmodule.php?module=strigoitower&op=tothebedroom");
		if (get_module_pref("visitnum")==4) addnav("Travel to the Tower","runmodule.php?module=strigoitower&op=upthestairs");
		addnav("Return to the Forest","runmodule.php?module=strigoitower&op=forest");
	}
	//The Final Battle
	if (get_module_pref("visitnum")==5){
		output("You find the way back to the `QVampire's Tower`).");
		output("This is going to be the final battle, so you need to be ready.");
		output("This is your chance to decide.");
		output("Are you ready?");
		addnav("Go to find the Vampire","runmodule.php?module=strigoitower&op=finalfight");
		addnav("Return to the Forest","runmodule.php?module=strigoitower&op=forest");
	}
}
function strigoitower_run(){
	global $SCRIPT_NAME;
	if ($SCRIPT_NAME == 'runmodule.php'){
		$module=httpget('module');
		if ($module == 'strigoitower'){
			$op = httpget('op');
			if ($op=='hof' || $op=='hof2') include('modules/strigoitower/strigoitower_hof.php');
			else include('modules/strigoitower/strigoitower.php');
		}
	}
}
?>