<?php
page_header("Strigoi Tower");
global $session;
$session['user']['specialinc']="module:strigoitower";
$op = httpget('op');
require_once("lib/titles.php");
require_once("lib/names.php");
addnav("What do you do?");
if (get_module_setting("translation")==0){
	output("`n`c");
	rawoutput("<font size='+1'>");
	rawoutput("<span style=\"width: 150; height: 30; color: #000000; filter: glow(color=#FF3333, strength=10)\">Strigoi Tower</span>");
	output("`c`n`)");
	rawoutput("</font>");
}else{
	output("`n`c`b`\$Strigoi Tower`b`c`n");
}

if ($op=="thestake"){
	output("Every quality `b`\$Vampire`b`) hunt begins with securing the right equipment.");
	output("You better make sure you are armed with some `6wooden stakes`) before attempting to conquer the undead.`n`n");
	output("Inspired by the plan, you'll have to head back to the forest to find a `6wooden stake`).");
	output("`n`nAh, inspiration! You gain `@one forest fight`) as you plan your attack.`n");
	$session['user']['turns']++;
	set_module_pref("visitnum",1);
	strigoitower_tbc();
}
if ($op=="thetower"){
	output("It seems like a never ending walk up the stairs to the tower, but you persevere.`n`n");
	output("At the top is a tall door with ancient words written across the header:");
	output("`n`n`c`b`qSanctum `)of `qStrigoi`c`b`n`)");
	output("After a quick `6'stake check'`) you push the door open.");
	output("A loud creeking sound echos into the foyer.");
	output("The mansion is huge, and you realize that this is going to take a while to explore.");
	output("If only there was a map.`n`n");
	output("You look around at the front door and notice a strange sign with a map of the mansion on it.`n`n");
	output("The map simply states 'In case of Fire, please identify all exits'.`n`nWell, that's pretty cool.");
	output("The vampire is fire-safety oriented.`n");
	if (get_module_setting("usepics")==1) {
		rawoutput("<br><center><table><tr><td align=center><img src=modules/strigoitower/mansionmap.gif></td></tr></table></center><br>"); 
	}else{
		output("The map clearly shows your current position with a little dot and an arrow with the words 'You are Here' pointing at the entrance.");
		output("Although the map doesn't show every detail of the mansion, it's clear that the first floor's main room is the library located around the back.`n`n");
	}
	output("Since the library always has very useful books and clues about your current adventure, it's a safe bet that that's where you need to go now.");
	addnav("To the Library","runmodule.php?module=strigoitower&op=library");
	addnav("Return to the Forest","runmodule.php?module=strigoitower&op=forest");
}
if ($op=="library"){
	output("You carefully follow the map to the library at the back of the mansion.");
	output("After a quick `#'Hello'`) you enter into the dusty hall of literature.");
	output("It's actually an impressive array of old books.");
	output("The room appears deserted.");
	output("You look around for a window but you don't see any.");
	output("You sit down at the desk and peruse the papers scattered about.");
	output("What would you like to do?");
	output("`n`n1.  Read the papers on the desk, in particular the one that says `\$`bREAD ME BEFORE DOING ANYTHING IN THE LIBRARY`b`).");
	output("`n`n2.  Search the bookcases for a book that will open a secret passageway.");
	output("`n`n3.  Look through the drawers of the desk for clues.");
	output("`n`n4.  Examine the curious bear-shaped rug.");
	output("`n`n5.  Drink that bottle of bright red wine.");
	addnav("Read the Papers","runmodule.php?module=strigoitower&op=readpapers");
	addnav("Search Bookcases","runmodule.php?module=strigoitower&op=searchbooks");
	addnav("Look through the Desk","runmodule.php?module=strigoitower&op=lookdesk");
	addnav("Examine the Bear Rug","runmodule.php?module=strigoitower&op=examinebear");
	addnav("Drink some Fine Wine","runmodule.php?module=strigoitower&op=drinkwine");
}
if ($op=="readpapers"){
	$good=e_rand(1,4);
	$bad=e_rand(1,4);
	if ($good==$bad) $bad=$good+1;
	if ($bad>4) $bad=1;
	set_module_pref("goodlib",$good);
	set_module_pref("badlib",$bad);
	$dontdo=array("","search the bookcases","look through the desk","examine the bear rug","drink the fine wine");
	$dontwant=array("","set them up so they will collapse on anyone searching through them","put a poison needle in the drawer to prick anyone searching through it","actually have a living bear trained to lie very still on the floor","replaced the wine with crappy grape juice");
	$dowant=array("","bookcase in the book titled 'How to Cook 40 Humans'","top desk drawer behind the bunny rabbit figurine","mouth of the bear rug","bottom of the bottle of fine wine");
	output("Thinking that it's best not to ignore a piece of paper that is begging to be read, you pick up the one marked `\$`b'READ ME BEFORE DOING ANYTHING IN THE LIBRARY'`b`) and read it.`n`n");
	output("`n`4Note to self:`n`nWhatever you do, do not %s.  Remember, you %s.  The key to the upstairs bedroom is stored in the %s.`n`nSigned,`n`nStrigoi`n`n",$dontdo[$bad],$dontwant[$bad],$dowant[$good]);
	output("`n`)Wow! Lucky you read that! What would you like to do?");
	//number 1
	addnav("Search Bookcases","runmodule.php?module=strigoitower&op=searchbooks");
	//number 2
	addnav("Look through the Desk","runmodule.php?module=strigoitower&op=lookdesk");
	//number 3
	addnav("Examine the Bear Rug","runmodule.php?module=strigoitower&op=examinebear");
	//number 4
	addnav("Drink some Fine Wine","runmodule.php?module=strigoitower&op=drinkwine");
}
if ($op=="searchbooks"){
	if (get_module_pref("goodlib")==1){
		output("You pull the book labeled 'How to Cook 40 Humans' and start to page through it.");
		output("Despite the fact that there seem to be some really good recipes, you focus your attention on finding the key to the upstairs bedroom.");
		output("`n`nThere it is!");
		output("You grasp the key and smile.");
		output("This is easy as pie!");
		output("`n`nThen you hear a low growl behind you...");
		output("You turn to find a `\$Hell Hound`) with teeth bared and saliva dripping from its lips.");
		output("Looks like you're in for a fight!");
		addnav("`\$Fight the Hellhound!","runmodule.php?module=strigoitower&op=attack");
		set_module_pref("monsternum",2);
		set_module_pref("gotkey",1);
	}else{
		output("You start pulling random books out of the book case.");
		output("You hear a loud creaking noise and notice that the bookcases are falling!");
		output("You'll have to dodge the falling books to get to safety!`n`n");
		addnav("`\$Dodge the Books!","runmodule.php?module=strigoitower&op=attack");
		set_module_pref("monsternum",3);
	}
	if (get_module_pref("badlib")==1){
		output("Before you get a chance to defend yourself, a particularly large book falls onto your left foot causing you to `\$lose 1/4 or your hitpoints`)!`n`n");
		output("A quick glance at the title of the book and you suddenly understand why it was so painful... The book is titled `\#My Left Foot Hurts Now`).");
		$session['user']['hitpoints']*=.75;
	}
}
if ($op=="lookdesk"){
	set_module_pref("monsternum",2);
	if (get_module_pref("goodlib")==2){
		output("You open the top drawer and notice several very cute figurines.");
		output("You move aside the `Qkitty cat`) one, the `#little bird`) one, and the figurine of the `qbaby `&deer`).");
		output("Then, behind the `&bunny `%rabbit`) figurine, you find the key you're looking for.");
		output("You accidentally knock over the `%bunny`) figurine and it shatters!");
		output("You notice a `%gem`)!`n`n");
		output("When you stand up to leave, you	hear growling sounds and look up to find a `\$Hellhound`) drooling at the door.`n`n");
		addnav("`\$Fight the Hellhound!","runmodule.php?module=strigoitower&op=attack");
		set_module_pref("gotkey",1);
	}else{
		output("You start going through the drawers but don't find much.");
		output("Oh wait!");
		output("You find a `%gem`) which you pocket happily.");
		output("You get ready to finish searching through the desk when you hear a deep growling sound at the doorway.");
		output("You look up to find a `\$Hellhound`) drooling at the door.`n`n");
		$session['user']['gems']++;
		addnav("`\$Fight the Hellhound!","runmodule.php?module=strigoitower&op=attack");
	}
	if (get_module_pref("badlib")==2){
		output("You stand up quickly and feel a needle jab into your leg.");
		output("The desk was booby-trapped!");
		output("The `@poison`) surges through your body and you `\$lose 1/4 of your hitpoints`)!");
		output("`n`nThis is just horrible timing because you have a very upset `\$Hellhound`) staring at you...");
		$session['user']['hitpoints']*=.75;
	}
}
if ($op=="examinebear"){
	if (get_module_pref("badlib")==3){
		output("You take a close look at the bear and see something shiny in its mouth.");
		output("You grab for what looks like a `%gem`) and feel razor sharp teeth bite down on you hand!`n`n");
		output("You `\$lose 1/4 of your hitpoints`)!`n`n");
		$session['user']['hitpoints']*=.75;
	}
	if (get_module_pref("goodlib")==3){
		output("With a quick examination of the `b`qG`^reat `qB`^ig `qB`^ear`b`) rug, you find a key strategically placed in its mouth.");
		output("Then the rug starts to growl!");
		output("`n`nYou look again and realize it wasn't the rug making the noise... it was the glowing red dog at the door.");
		output("`n`n`\$GLOWING RED DOG?!?!?!`)");
		output("`n`nIt's a `\$Hellhound`)!`n`n");
		addnav("`\$Fight the Hellhound!","runmodule.php?module=strigoitower&op=attack");
		set_module_pref("monsternum",2);
		set_module_pref("gotkey",1);
	}else{
		output("The bear rug isn't a rug! It's a real `qB`^ear`)!`n`n");
		set_module_pref("monsternum",4);
		addnav("`\$Fight the Bear!","runmodule.php?module=strigoitower&op=attack");
	}
}
if ($op=="drinkwine"){
	set_module_pref("monsternum",2);
	if (get_module_pref("goodlib")==4){
		output("You go over to the pretty bottle of wine and uncork it.");
		output("Hmmm...  You probably shouldn't let a quality bottle of wine go to waste!");
		output("`n`nYou take a sip.");
		output("`n`nYum! tasty!");
		output("`n`nThen another!");
		output("`n`nOh, even better!");
		output("`n`nBefore you know it, a little key comes tumbling out of the empty bottle.");
		output("You grab the key and slip it into your pocket.");
		output("You take a look at the wine bottle in order to possibly order more in the future...");
		if (get_module_setting("usepics")==1) {
			rawoutput("<br><center><table><tr><td align=center><img src=modules/strigoitower/vampirewine.jpg></td></tr></table></center><br>"); 
		}else{		
			output("`n`n`\$`c<font size='+2'>Vampire Wine</font>`nPrivate Reserve`n`nA Product of Transylvania`c`)",true);
		}
		output("`n`n`)Maybe you won't be able to get another bottle quite like this anytime soon.");
		output("When you stand up to leave (a little tipsy, mind you), you hear growling sounds and look up to find a `\$Hellhound`) drooling at the door.`n`n");
		addnav("`\$Fight the Hellhound!","runmodule.php?module=strigoitower&op=attack");
		increment_module_pref("drunkeness",+10,"drinks");
		apply_buff('vampirewine',array(
			"name"=>"`\$Vampire Wine Buzz",
			"rounds"=>10,
			"wearoff"=>"`\$The Vampire Wine leaves your system",
			"atkmod"=>1.1,
			"defmod"=>1.1,
			"roundmsg"=>"`&The wine courses through your body giving you strength!",
		));
		set_module_pref("gotkey",1);
	}else{
		if (get_module_setting("usepics")==1) {
			rawoutput("<br><center><table><tr><td align=center><img src=modules/strigoitower/vampirewine.jpg></td></tr></table></center><br>"); 
		}else{		
			output("`\$`c<font size='+2'>Vampire Wine</font>`nPrivate Reserve`n`nA Product of Transylvania`c`)",true);
		}
		output("`n`n`)You wander over to the bottle of wine and take a quick sip.");
		output("It seems to be okay, but then the aftertaste hits you!");
		output("`n`nEWWWW!!! It's... it's... You can't believe it!");
		output("`n`nIt's not really wine!");
		output("`n`nIt's...`n`n`n`n");
		output("Non-Alcoholic Grape Juice!!!!!");
		output("`n`n How horrible!");
		output("And just when you think things couldn't get any worse, you look up to find a `\$Hellhound`) drooling at the door.`n`n");
		$session['user']['gems']++;
		addnav("`\$Fight the Hellhound!","runmodule.php?module=strigoitower&op=attack");
		apply_buff('vampirewine',array(
			"name"=>"`%Grape Juice Buzzkill",
			"rounds"=>10,
			"wearoff"=>"`%The crummy aftertaste dissolves off your palate.",
			"atkmod"=>0.9,
			"defmod"=>0.95,
			"roundmsg"=>"`%Blah! crummy grape juice aftertaste!!",
		));
	}
	if (get_module_pref("badlib")==2){
		output("You get ready to duel and drop the bottle on your foot.");
		output("Oh crud!");
		output("That hurts!");
		output("You `\$lose 1/4 of your hitpoints`)!");
		output("`n`nThis is just horrible timing because you have a very upset `\$Hellhound`) staring at you...");
		$session['user']['hitpoints']*=.75;
	}
}
if ($op=="tothebedroom"){
	output("You take the long walk up the stairway of the tower up to the front door of the mansion.");
	output("You pause and rest for a moment to read the pamphlet you picked up titled  `Q'What you need to know about `bVampires`b'`Q.");
	output("`n`n`\$1. They like long walks in the moonlight");
	output("`n`^2. They don't like Garlic Bread");
	output("`n`\$3. `QVampires`\$ like flowers");
	output("`n`n`)What the Heck?!?!");
	output("`n`nYou turn over the pamphlet over to see who wrote this stupid thing...");
	output("`n`n`c`b`5Written by Sir Edmund the Not So Bright`)`b`c`n");
	output("Wow... okay... enough goofing around.");
	output("Up to the 2nd floor bedroom!");
	addnav("Up the Stairs","runmodule.php?module=strigoitower&op=upthestairs");
}
if ($op=="upthestairs"){
	if (get_module_pref("visitnum")==4) output("You travel to the front door, then go up the stairs to the 2nd floor... you remember where you're going!`n`n");
	output("You're halfway up the stairs... you notice a little sign next to a lever... `^'Pull for Super Fun Slide!'`)`n`nWould you like to pull the lever?");
	addnav("Pull The Lever","runmodule.php?module=strigoitower&op=pulllever");
	addnav("Keep Going","runmodule.php?module=strigoitower&op=bedroomdoor");
}
if ($op=="pulllever"){
	output("Suddenly, the stairs all collapse to form a huge slide!");
	output("`n`n`@Weeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee!!`)`n`n");
	if (get_module_pref("visitnum")==3){
		output("You gain `@One Extra Turn`) from the adrenaline rush.");
		$session['user']['turns']++;
	}elseif (get_module_pref("visitnum")==4){
		output("No, it really wasn't that much fun.");
		output("You were faking it.");
		output("Honestly, it was kinda boring.");		
	}
	output("`n`nOkay, time to get back to work.");
	output("You push a button that says `^'Make slide into stairs'`) and head up to the bedroom.");
	addnav("To the Bedroom","runmodule.php?module=strigoitower&op=bedroomdoor");
}
if ($op=="bedroomdoor"){
	if (get_module_pref("visitnum")==3){
		output("You get to the masterbedroom and take out the precious key.");
		output("You put the key into the door, open the door, and slowly enter the room...");
		output("`n`nIt's simple and dusty.");
		output("The windows are all barred and the bed looks like it has never been used.");
		output("It seems like this would be a good time to do some exploring.`n`n");
		if(get_module_pref("bedroom")<3 && get_module_pref("searchdresser")==0) addnav("Search the Dresser","runmodule.php?module=strigoitower&op=dresser");
		if(get_module_pref("bedroom")<3 && get_module_pref("searchdresser")==1) addnav("Search the Dresser","runmodule.php?module=strigoitower&op=redresser");
		if(get_module_pref("bedroom")<2 && get_module_pref("searchbed")==0) addnav("Look under the Bed","runmodule.php?module=strigoitower&op=bed");
		if(get_module_pref("bedroom")<2 && get_module_pref("searchbed")==1) addnav("Look under the Bed","runmodule.php?module=strigoitower&op=underbed");
		if(get_module_pref("searchcloset")==0) addnav("Check the Closet","runmodule.php?module=strigoitower&op=closet");
		if(get_module_pref("searchcloset")==1) addnav("Check the Closet","runmodule.php?module=strigoitower&op=recloset");
		if(get_module_pref("bedroom")<1) addnav("Examine the Windows","runmodule.php?module=strigoitower&op=windows");
		addnav("Return to the Forest","runmodule.php?module=strigoitower&op=forest");
	}elseif (get_module_pref("visitnum")==4){
		output("You walk over to the closet and examine the little heart once again.");
		output("Do you push the heart?");
		addnav("Push the Heart","runmodule.php?module=strigoitower&op=yespush");
		addnav("Don't Push the Heart","runmodule.php?module=strigoitower&op=nopush");
		addnav("Return to the Forest","runmodule.php?module=strigoitower&op=forest");
	}
}
if ($op=="dresser"){
	output("You search through the drawers but they are all empty.");
	output("The only item on the dresser is a beautiful porcelain music box.");
	output("When you try to open it, you realize it's locked.");
	if(get_module_pref("bedroom")==2) {
		strigoitower_dresser();
	}else{
		set_module_pref("searchdresser",1);
		strigoitower_dressernav();
	}
}
if ($op=="redresser"){
	if(get_module_pref("bedroom")==2) {
		strigoitower_dresser();
	}else{
		output("Nope, the dresser is STILL empty and there is STILL a locked music box on top of it.`n`n");
		strigoitower_dressernav();
	}
}
if ($op=="bed"){
	set_module_pref("monsternum",5);
	addnav("`\$Fight the Wolf!","runmodule.php?module=strigoitower&op=attack");
	if(get_module_pref("bedroom")==1){
		output("You turn to look around the room and hear scratching under the bed.");
		output("You are about to take a look when you drop your crystal.");
		output("`n`nA reflection in the crystal reveals a fierce wolf hiding under the bed waiting to strike.");
		output("You grab your weapon and take a defensive posture.");
		output("`n`nThe wolf doesn't move until you call out `@'Come here little puppy!'`).");
		output("`n`n`\$The fight is on!");
	}else{
		output("You decide that the best place to look for clues is probably under the bed.");
		output("You lean over and suddenly you feel a sharp sting!");
		output("You've been bitten by a wolf.`n`n");
		$hitpointslost=round($session['user']['hitpoints']*.1);
		$session['user']['hitpoints']*=.9;
		if ($session['user']['hitpoints']<=1){
			$session['user']['hitpoints']=1;
			output("You lose `\$all your hitpoints except one");
		}else{
			output("You `\$lose %s hitpoints",$hitpointslost);
		}
		output("`)from the bite. The fight is on!");
	}
}
if ($op=="underbed"){
	if(get_module_pref("bedroom")==1){
		output("You turn to look around the room and hear scratching under the bed.");
		output("You are about to take a look when you drop your crystal.");
		output("`n`nA reflection in the crystal reveals a fierce wolf hiding under the bed waiting to strike.");
		output("You grab your weapon and take a defensive posture.");
		output("`n`nThe wolf doesn't move until you call out `@'Come here little puppy!'`).");
		output("`n`n`\$The fight is on!");
		set_module_pref("monsternum",5);
		addnav("`\$Fight the Wolf!","runmodule.php?module=strigoitower&op=attack");	
	}else{
		output("You hear a growl from under the bed, but it's too dangerous to stick your head under there.");
		output("You'll need some way of detecting if there's something hiding in ambush.");
		output("But what will work?!?!");
		if(get_module_pref("bedroom")<3 && get_module_pref("searchdresser")==0) addnav("Search the Dresser","runmodule.php?module=strigoitower&op=dresser");
		if(get_module_pref("bedroom")<3 && get_module_pref("searchdresser")==1) addnav("Search the Dresser","runmodule.php?module=strigoitower&op=redresser");
		if(get_module_pref("searchcloset")==0) addnav("Check the Closet","runmodule.php?module=strigoitower&op=closet");
		if(get_module_pref("searchcloset")==1) addnav("Check the Closet","runmodule.php?module=strigoitower&op=recloset");
		if(get_module_pref("bedroom")<1) addnav("Examine the Windows","runmodule.php?module=strigoitower&op=windows");
		addnav("Return to the Forest","runmodule.php?module=strigoitower&op=forest");
	}
}		
if ($op=="closet"){
	if(get_module_pref("bedroom")==3) {
		strigoitower_closet();
		strigoitower_tbc();
	}else{
		output("You search through the closet but, to be honest, it's empty.");
		output("What did you expect?");
		output("A black cape?`n`n");
		set_module_pref("searchcloset",1);
		strigoitower_closetnav();
	}
}
if ($op=="recloset"){
	if(get_module_pref("bedroom")==3) {
		strigoitower_closet();
		strigoitower_tbc();
	}else{
		output("No.  The closet is STILL empty, and there's STILL no cape.`n`n");
		strigoitower_closetnav();
	}
}
if ($op=="windows"){
	output("You look closely at the window and notice 10 deep scratches with drops of crimson surrounding each one.");
	output("`n`nIt doesn't take long for the story to evolve in your mind.");
	output("`n`nSomeone was trapped here in this room with doom approaching.");
	output("The desperate scratches of a dying soul became the epitaph left on a forgotten window sill.");
	output("Will you leave the same marks?`n`n");
	output("You run your fingers across the scratches and you absorb a touch of the fear of the person lost to their dark fate.");
	output("`n`nA sliver pierces your finger and a drop of your `\$blood`) falls to the ground.");
	output("Steam rises from the drop of `\$blood`) like the smoke of `\$H`^e`Ql`\$l`) licking the flesh of the newly damned.`n`n");
	output("Your eyes lose focus for a moment until they catch they glimmer of a crystal hanging in the window.");
	output("You quickly grab the precious quartz.");
	output("`n`nThere must be some use for this!`n`n");
	set_module_pref("bedroom",1);
	if(get_module_pref("bedroom")<3 && get_module_pref("searchdresser")==0) addnav("Search the Dresser","runmodule.php?module=strigoitower&op=dresser");
	if(get_module_pref("bedroom")<3 && get_module_pref("searchdresser")==1) addnav("Search the Dresser","runmodule.php?module=strigoitower&op=redresser");
	if(get_module_pref("bedroom")<2 && get_module_pref("searchbed")==0) addnav("Look under the Bed","runmodule.php?module=strigoitower&op=bed");
	if(get_module_pref("bedroom")<2 && get_module_pref("searchbed")==1) addnav("Look under the Bed","runmodule.php?module=strigoitower&op=underbed");
	if(get_module_pref("searchcloset")==0) addnav("Check the Closet","runmodule.php?module=strigoitower&op=closet");
	if(get_module_pref("searchcloset")==1) addnav("Check the Closet","runmodule.php?module=strigoitower&op=recloset");
	addnav("Return to the Forest","runmodule.php?module=strigoitower&op=forest");
}
if ($op=="nopush"){
	increment_module_pref("pushheart",1);
	if (get_module_pref("pushheart")>8){
		output("That's it. Are you ready to push that heart?");
		addnav("Push the Heart","runmodule.php?module=strigoitower&op=yespush");
		addnav("Return to the Forest","runmodule.php?module=strigoitower&op=forest");	
	}elseif (get_module_pref("pushheart")==8){
		output("Congratulations!!!");
		output("You've found an Easter Egg.");
		output("`n`nThe reward for this Egg is that you get `^1000 gold`) and you may choose to accept a new title.");
		output("`n`nWould you like the title of `^'Persistent'`)?");
		$session['user']['gold']+=1000;
		addnav("Accept Title","runmodule.php?module=strigoitower&op=accepttitle");
		addnav("Decline Title","runmodule.php?module=strigoitower&op=declinetitle");		
	}else{
		$randpush=e_rand(1,2);
		if($randpush==1){
			addnav("Push the Heart","runmodule.php?module=strigoitower&op=yespush");
			addnav("Don't Push the Heart","runmodule.php?module=strigoitower&op=nopush");		
		}else{
			addnav("Don't Push the Heart","runmodule.php?module=strigoitower&op=nopush");		
			addnav("Push the Heart","runmodule.php?module=strigoitower&op=yespush");	
		}
		output("Okay, so you stand around looking at the closet.  Ready to push the heart yet?");
		addnav("Return to the Forest","runmodule.php?module=strigoitower&op=forest");		
	}
}
if ($op=="yespush"){
	output("You close your eyes and push the button... and the floor drops out!");
	output("You find yourself falling...`n`n");
	output("Soon your riding a slide down, but your speed seems controlled.");
	output("After what feels like a never-ending fall, your feet touch the ground.");
	output("You must be quite a ways underground.");
	if ($session['user']['race']== 'Elf' || $session['user']['race']== 'Drow'|| $session['user']['race']== 'Dwarf' || $session['user']['race']== 'DarkElf' || $session['user']['race']== 'Vampire' || $session['user']['race']== 'Felyne'  || $session['user']['race']== 'Lich'){
		output("There is an overwhelming darkness.");
		output("`n`nSoon enough, your %s eyes adjust to the darkness.",$session['user']['race']);
	}else{
		output("A small torch glows on the wall.`n`n");
	}
	output("You look around, feeling a sticky substance on the floor.");
	output("You look up to see the ceiling full of bats!`n`n");
	output("Looks like you're going to have to fight your way out of here!`n");
	addnav("`\$Fight the Bats!","runmodule.php?module=strigoitower&op=attack");
	set_module_pref("monsternum",6);
}
if ($op=="basement"){
	output("You discover the door to the `QVampire's Inner Sanctum`).");
	output("`n`nHowever, instead of barging in with `6stakes`) flying, you search around for an exit route and find a secret door leading up a flight of stairs and opening right by the library corridor.`n`n");
	output("The smart decision at this point is to make sure you heal up and come back at full strength before attacking the `QVampire`).");
	output("However, now that you know how to find his `QInner Sanctum`), you will be able to attack with swift decision next time.`n");
	strigoitower_tbc();
}
if ($op=="accepttitle"){
	$newtitle = "Persistent";
	$newname = change_player_title($newtitle);
	$session['user']['title'] = $newtitle;
	$session['user']['name'] = $newname;
	output("Excellent! Your title has been changed.  Now, are you ready to push that heart?");
	addnav("Push the Heart","runmodule.php?module=strigoitower&op=yespush");
	addnav("Return to the Forest","runmodule.php?module=strigoitower&op=forest");
}
if ($op=="declinetitle"){
	output("Very Well.  Now, are you ready to push that heart?");
	addnav("Push the Heart","runmodule.php?module=strigoitower&op=yespush");
	addnav("Return to the Forest","runmodule.php?module=strigoitower&op=forest");
}
if ($op=="finalfight"){
	output("You walk up to the tower, enter through the front door, and find the secret entrance to the basement.");
	output("`n`nYou walk through the bat carcasses.");
	output("Soon you find yourself standing before a large door.");
	output("It opens without resistance.`n`n");
	addnav("Enter the Chamber","runmodule.php?module=strigoitower&op=vchamber");	
	addnav("Run Back to the Forest","runmodule.php?module=strigoitower&op=forest");
}
if ($op=="vchamber"){
	output("You walk into the chamber.");
	output("It's empty except the solitary coffin in the middle of the room.");
	output("This looks easy enough.");
	output("All you have to do is go over to the coffin, open it, and `6stake`) the `QVampire`).");
	addnav("Open the Casket","runmodule.php?module=strigoitower&op=casket");	
	addnav("Run Away!","runmodule.php?module=strigoitower&op=runaway");	
}
if ($op=="casket"){
	output("You prepare your `6stake`) and open the coffin!");
	output("`n`nWith a quick strike you sink the `6stake`) deep into the...");
	output("`n`nWait!");
	output("The coffin is empty!");
	output("`n`nYou suddenly become very nervous.");
	output("A chill runs down your neck.");
	output("You turn around to find yourself standing before a creature dressed in black.");
	strigoitower_vampireattack();
}
if ($op=="runaway"){
	$hploss=round($session['user']['hitpoints']*.05);
	$session['user']['hitpoints']-=$hploss;
	output("You turn to run away and feel a sharp slash across your face.");
	output("You lose %s hitpoints... and look at what just hit you.`n`n",$hploss);
	output("You find yourself standing before a creature dressed in black.");
	strigoitower_vampireattack();
}
if ($op=="finale"){
	$gold= e_rand(500,1000);
	$session['user']['gold']+=$gold;
	$gems= e_rand(2,4);
	$session['user']['gems']+=$gems;
	output("You stand above the executed body of the `Qvampire`) and chop off it's head.");
	output("The veil of darkness lifts slowly and you have a chance to examine the corpse.");
	output("The first thing you do is remove the amazing `\$o`Qr`^n`@a`#t`!e`^ necklace `)which you find to be worth `%%s gems`).",$gems);
	output("`n`nA more diligent search reveals a pouch containing `^%s gold`) which you also pocket.",$gold);
	output("`n`nYou pause to look around more, but the magic of the `QVampire`) was also tied to the tower.");
	output("If you don't get out soon, it's going to collapse around you!");
	addnav("Continue Looking","runmodule.php?module=strigoitower&op=lookmore");
	addnav("Run Away!","runmodule.php?module=strigoitower&op=collapse");	
}
if ($op=="lookmore"){
	output("No, seriously, the place is collapsing.");
	output("You don't have time to look anymore.");
	output("`n`nRUN AWAY!!!");	
	addnav("Run Away!","runmodule.php?module=strigoitower&op=collapse");
}
if ($op=="collapse"){
	output("You exit the tower and run down the stairs.");
	output("Shards of rocks hit you as you run... but you're able to make it out safely.");
	output("`n`nBy the time you finish escaping, you find that you only have `\$One Hitpoint`) left.`n`n");
	output("You turn around to look at the rubble as a smile crosses your lips.");
	output("You've saved the kingdom from the unspeakable evil of `b`\$Strigoi the Vampire`)`b!`n`n`c");
	$session['user']['hitpoints']=1;
	if (get_module_setting("translation")==0){
		rawoutput("<font size='+1'>");
		rawoutput("<span style=\"width: 150; height: 30; color: #00FF00; filter: glow(color=#2554C7, strength=10)\">Congratulations!</span>");
		rawoutput("</font>");
	}else{
		output("`b`QCongratulations!`b");
	}
	output("`c");
	$session['user']['specialinc'] = "";
	addnav("Back to the Forest","forest.php");
}
if ($op=="forest"){
	output("You realize that it's time to return back to the forest.");
	addnav("Back to the Forest","forest.php");
	$session['user']['specialinc'] = "";
}	
if ($op=="attack") {
	$rand=e_rand(95,107)/100;
	if (get_module_pref("monsternum")==1){
		$dkb = round($session['user']['dragonkills']*.1);
		$badguy = array(
			"creaturename"=>"`QO`qbliviax",
			"creaturelevel"=>$session['user']['level'],
			"creatureweapon"=>"Vine-like appendages",
			"creatureattack"=>$session['user']['attack'],
			"creaturedefense"=>$session['user']['defense']+$dkb,
			"creaturehealth"=>round($session['user']['maxhitpoints']*1.1),
			"diddamage"=>0,
			"type"=>"obliviax");
		$session['user']['badguy']=createstring($badguy);
	}
	if (get_module_pref("monsternum")==2){
		$badguy = array(
			"creaturename"=>"Hellhound",
			"creaturelevel"=>$session['user']['level']+1,
			"creatureweapon"=>"burning claws",
			"creatureattack"=>$session['user']['attack']-1,
			"creaturedefense"=>$session['user']['defense']-1,
			"creaturehealth"=>round($session['user']['maxhitpoints']*.75),
			"diddamage"=>0,
			"type"=>"hellhound");
		$session['user']['badguy']=createstring($badguy);
	}
	if (get_module_pref("monsternum")==3){
		$badguy = array(
			"creaturename"=>"Falling books",
			"creaturelevel"=>$session['user']['level'],
			"creatureweapon"=>"pages of boring poetry",
			"creatureattack"=>round($session['user']['attack']*.5),
			"creaturedefense"=>round($session['user']['defense']*.5),
			"creaturehealth"=>round($session['user']['hitpoints']*.7),
			"diddamage"=>0,
			"type"=>"fallingbooks");
		$session['user']['badguy']=createstring($badguy);
	}
	if (get_module_pref("monsternum")==4){
		$level = $session['user']['level']-1;
		if ($level<=0) $level=1;
		$badguy = array(
			"creaturename"=>"`qG`^reat `qB`^ig `qB`^ear",
			"creaturelevel"=>$level,
			"creatureweapon"=>" `@its`% Claws",
			"creatureattack"=>round($session['user']['attack']),
			"creaturedefense"=>round($session['user']['defense']),
			"creaturehealth"=>round($session['user']['maxhitpoints']*$rand),
			"diddamage"=>0,
			"type"=>"bear");
		$session['user']['badguy']=createstring($badguy);
	}
	if (get_module_pref("monsternum")==5){
		$badguy = array(
			"creaturename"=>"`0W`)olf",
			"creaturelevel"=> $session['user']['level'],
			"creatureweapon"=>"`\$bloody fangs",
			"creatureattack"=>$session['user']['attack'],
			"creaturedefense"=>$session['user']['defense'],
			"creaturehealth"=>round($session['user']['maxhitpoints']*$rand),
			"diddamage"=>0,
			"type"=>"vampwolf");
		$session['user']['badguy']=createstring($badguy);
	}
	if (get_module_pref("monsternum")==6){
		$badguy = array(
			"creaturename"=>"`0Bats",
			"creaturelevel"=> $session['user']['level'],
			"creatureweapon"=>"`\$blood draining bites",
			"creatureattack"=>$session['user']['attack'],
			"creaturedefense"=>$session['user']['defense'],
			"creaturehealth"=>round($session['user']['maxhitpoints']*$rand),
			"diddamage"=>0,
			"type"=>"vampbats");
		$session['user']['badguy']=createstring($badguy);
	}
	if (get_module_pref("monsternum")==7){
		$dkb = round($session['user']['dragonkills']*.1);
		$badguy = array(
			"creaturename"=>"`b`\$Strigoi the Vampire`b",
			"creaturelevel"=> $session['user']['level']+1,
			"creatureweapon"=>"`b`\$viscious slashing nails`b",
			"creatureattack"=>$session['user']['attack']+2+$dkb,
			"creaturedefense"=>$session['user']['defense']+2+$dkb,
			"creaturehealth"=>round($session['user']['maxhitpoints']*1.3),
			"diddamage"=>0,
			"type"=>"strigoi");
		$session['user']['badguy']=createstring($badguy);
	}
	$op="fight";
}
if ($op=="fight"){
	if (get_module_pref("monsternum")==6 || get_module_pref("monsternum")==7){
		blocknav("runmodule.php?module=strigoitower&op=fight&auto=five");
		blocknav("runmodule.php?module=strigoitower&op=fight&auto=ten");
		blocknav("runmodule.php?module=strigoitower&op=fight&auto=full");
	}	
	if (get_module_pref("monsternum")==6){
		$bite=e_rand(1,3);
		$damage=round($session['user']['level']*.5);
		if ($bite==3){
			apply_buff('vampiredrain', array(
				"startmsg"=>"`QA bat attaches to your neck and bites!",
				"name"=>"Vampire Bite",
				"rounds"=>1,
				"minioncount"=>1,
				"mingoodguydamage"=>1,
				"maxgoodguydamage"=>$damage+2,
				"effectmsg"=>"`QYou are drained for `\${damage} hitpoints`Q by the vampire bat on your neck!",
			));
		}
	}
	if (get_module_pref("monsternum")==7){
		$vamptalk=array("Your blood will be mine!","I will feast on your blood!","I will make you one of my thralls!","You will rot in your own coffin!","Your feeble attempts are for naught!",
			"You realize I'm just fiddling with you.  I like to play with my food","You will be forgotten.","Who will miss you when you are gone?","Shall I feast on the blood of the rest of your family?",
			"You didn't really think you could defeat me, did you?");
		$phrase=e_rand(0,9);
		output("`c`i`b`QThe Vampire Cries out `\$'%s'`i`c`b`n",$vamptalk[$phrase]);
		$bite=e_rand(1,3);
		$damage=round($session['user']['level']*.5);
		if ($bite==3){
			apply_buff('vampiredrain', array(
				"startmsg"=>"`QThe Vampire gets close enough to bite you!",
				"name"=>"Vampire Bite",
				"rounds"=>1,
				"minioncount"=>1,
				"mingoodguydamage"=>$damage,
				"maxgoodguydamage"=>$damage,
				"effectmsg"=>"`QYou are drained for `\${damage} hitpoints`Q while the Vampire gains that many!",
			));
			apply_buff('vampiregain', array(
				"name"=>"Vampire Bite",
				"rounds"=>1,
				"minioncount"=>1,
				"minbadguydamage"=>-$damage,
				"maxbadguydamage"=>-$damage,
			));
		}
	}	
	$battle=true; 
}
if ($battle){       
	include("battle.php");  
	if ($victory){
		if (get_module_pref("monsternum")==1){
			$gold= e_rand(200,400);
			$session['user']['gold']+=$gold;
			$gems= e_rand(1,2);
			$session['user']['gems']+=$gems;
			output("`n`^The battle ends with you victorious!");
			output("The `QO`qbliviax`^ is chopped to pieces.");
			output("You stop and look at the splinters.");
			output("Some of these pieces will make some very useful stakes.");
			output("You take a couple with you.");
			output("Next time you come to the `\$Vampire Tower`^ you'll be ready to enter!`n`n");
			output("You sit down in for a second to catch your breath and eat a little of the moss from the `QO`qbliviax`^.");
			output("Suddenly, you 'remember' things that were previously unknown to you.");
			output("In particular, you realize there's treasure lying around at your feet.");
			output("You search around and discover a nice cache of `bgold`b and `%gems`^.");
			output("`n`nYou find`b %s gold`b and `%",$gold);	
			if ($gems==1) output ("a gem`^!");
			else output("2 gems`^!");
			$expbonus=$session['user']['dragonkills']*4;
			$expgain =($session['user']['level']*e_rand(25,45)+$expbonus);
			$session['user']['experience']+=$expgain;
			output("`n`n`@You gain `#%s experience`@.`n",$expgain);
			set_module_pref("visitnum",2);
			addnews("%s `^defeated the tree-like `QO`qbliviax`^ in the forest",$session['user']['name']);
			strigoitower_tbc();
		}
		if (get_module_pref("monsternum")==2){
			output("`n`^The `\$Hellhound`^ falls dead at your feet with a stake driven into its heart just to be safe.");
			output("You look around after all this noise and think it's better that you leave the mansion now rather than wait to see if you've awoken the dead.");
			output("Or maybe the undead?`n`n");
			if (get_module_pref("gotkey")==1) {
				output("You make sure that the key is safe.");
				output("You'll have to come back another time to find out what's in the upstairs bedroom!");
				set_module_pref("visitnum",3);
			}else{
				output("You'll have to come back to the library another time.");
			}
			$expbonus=$session['user']['dragonkills']*4;
			$expgain =($session['user']['level']*e_rand(45,55)+$expbonus);
			$session['user']['experience']+=$expgain;
			output("`n`n`@You gain `#%s experience`@.`n`n",$expgain);
			addnews("%s `^defeated a `\$hellhound`^ in the Vampire's Tower.",$session['user']['name']);
			strigoitower_tbc();
			set_module_pref("goodlib",0);
			set_module_pref("badlib",0);
		}
		if (get_module_pref("monsternum")==3){
			$expbonus=$session['user']['dragonkills']*3;
			$expgain =($session['user']['level']*e_rand(10,20)+$expbonus);
			$session['user']['experience']+=$expgain;
			output("`%`nYou dodge the final book and notice that the title of it was 'The Arftul Dodger'.  Cool!`n");
			output("`n`#You gain %s experience from dodging literature!`n",$expgain);
			output("`@Suddenly you hear a deep growl!");
			output("A demon dog guards the exit to the library!`n`n");
			output("It looks like you'll need to conquer a `\$Hellhound`@ before you can get out of the library safely!`n`n");
			if (($session['user']['hitpoints']*1.25)<$session['user']['maxhitpoints']) {
				$healing=($session['user']['maxhitpoints']-$session['user']['hitpoints']*1.25);
				$session['user']['hitpoints']+=$healing;
				output("A quick quaff of a healing potion helps restore some of your hitpoints for the battle.`n`n");
				if (is_module_active("potions")) {
					if (get_module_pref('potion','potions')>=1) increment_module_pref('potion',-1,'potions');
				}
			}
			set_module_pref("monsternum",2);
			addnav("`\$Fight the Hellhound!","runmodule.php?module=strigoitower&op=attack");
		}
		if (get_module_pref("monsternum")==4){
			$expbonus=$session['user']['dragonkills']*7;
			$expgain =($session['user']['level']*50+$expbonus);
			$session['user']['experience']+=$expgain;
			output("`#With a final thrust, you finally make that `qB`^ear`# into a rug.`n");
			output("`n`@`bYou've gained `#%s experience`@.`b`n`n",$expgain);
			if (($session['user']['hitpoints']*1.15)<$session['user']['maxhitpoints']) {
				$healing=($session['user']['maxhitpoints']-$session['user']['hitpoints']*1.15);
				$session['user']['hitpoints']+=$healing;
				output("A quick quaff of a healing potion helps restore some of your hitpoints for the battle.`n`n");
				if (is_module_active("potions")) {
					if (get_module_pref('potion','potions')>=1) increment_module_pref('potion',-1,'potions');
				}
			}
			set_module_pref("monsternum",2);
			addnav("`\$Fight the Hellhound!","runmodule.php?module=strigoitower&op=attack");
		}
		if (get_module_pref("monsternum")==5){
			output("`n`^The wolf lies dead at your feet with a stake in its heart for 'safety's sake'.`n`n");
			$expbonus=$session['user']['dragonkills']*6;
			$expgain =($session['user']['level']*e_rand(22,27)+$expbonus);
			$session['user']['experience']+=$expgain;
			output("`@You gain `#%s experience`@.`n`n",$expgain);
			if (get_module_pref("bedroom")==1){
				output("You drag the carcass of the beast out from under the bed to finish your survey.");
				output("You notice a rusted old key just within reach and grab it.");
				output("`n`nBut what good is the key?");
				set_module_pref("bedroom",2);
				addnav("Search the Dresser","runmodule.php?module=strigoitower&op=dresser");
				if(get_module_pref("searchcloset")==0) addnav("Check the Closet","runmodule.php?module=strigoitower&op=closet");
				if(get_module_pref("searchcloset")==1) addnav("Check the Closet","runmodule.php?module=strigoitower&op=recloset");
				addnav("Return to the Forest","runmodule.php?module=strigoitower&op=forest");		
			}else{
				output("The battle has caused quite a ruckus.");
				output("It's probably not the best idea for you to linger.");
				output("You'll have to finish searching the room another day.");
				output("`n`nAs you leave, you hear another growl come from under the bed.");
				output("Is there another monster under there?!?`n");
				set_module_pref("searchbed",1);	
				strigoitower_tbc();
			}
		}	
		if (get_module_pref("monsternum")==6){
			$expbonus=$session['user']['dragonkills']*4;
			$expgain =($session['user']['level']*e_rand(35,45)+$expbonus);
			$session['user']['experience']+=$expgain;
			output("`n`@You gain `#%s experience`@.`n`n",$expgain);
			addnews("%s `^defeated a `QColony of Vampire Bats`^ in the `\$Vampire's Tower`^.",$session['user']['name']);
			set_module_pref("pushheart",0);
			set_module_pref("visitnum",5);
			output("You kill the last bat and look around at the carnage...");
			output("Well done!");
			output("Time to do some more exploring...");
			addnav("Search the Basement","runmodule.php?module=strigoitower&op=basement");
		}
		if (get_module_pref("monsternum")==7){
			$titlearray = array(1=>translate_inline("`^Ghoul Vanquisher"),2=>translate_inline("`@Cadaver Exorciser"),3=>translate_inline("`#Revenant Slayer"),
                             4=>translate_inline("`1Defiler Abolisher"),5=>translate_inline("`6Bane of Strigoi"),6=>translate_inline("`3Feared by Undead"),
                             7=>translate_inline("`QVampire Hunter"),8=>translate_inline("`!Nosferatu Slayer"),9=>translate_inline("`\$Lich Slayer"),
                            10=>translate_inline("`%Slayer of the Damned"),11=>translate_inline("`^`bDestroyer of Elder Vampires`b"));

			$completednum=get_module_pref("completednum")+1;
			set_module_pref("completednum",$completednum);
			if ($completednum>10) $completednum=11;
			$expbonus=$session['user']['dragonkills']*7;
			$expgain =($session['user']['level']*e_rand(60,65)+$expbonus);
			$session['user']['experience']+=$expgain;
			output("`nWith a final thrust of your stake, you drive the wood deep into the `QVampire's`\$ heart.`n");
			output("`n`@You gain `#%s experience`@.`n`n",$expgain);
			output("`n`@You have earned the title `b`#%s`@.`n`n",$titlearray[$completednum]);
			addnav("Complete the Adventure","runmodule.php?module=strigoitower&op=finale");
			addnews("`b%s `^defeated `\$Strigoi the Vampire`^ in the `\$Vampire's Tower`^ and earned the title of `#%s`^.`b",$session['user']['name'],$titlearray[$completednum]);
			set_module_pref("visitnum",0);
		}
	}elseif($defeat){
		require_once("lib/taunt.php");
		$taunt = select_taunt_array();
		$session['user']['specialinc'] = "";
		$session['user']['alive'] = false;
		$session['user']['hitpoints'] = 0;
		if (get_module_pref("monsternum")==1){
			$loss=get_module_setting("percentloss")/100;
			$exploss = round($session['user']['experience']*$loss);
			output("`n`^The `QO`qbliviax`^ pulls you close for a deadly embrace.");
			output("He wipes your memory and you forget the name of your armor.");
			output("For now, you'll think that your `&%s`^ is really just a `&T-shirt`^.`n",$session['user']['armor']);
			output("`n`\$You lose all your `^gold`\$!`n");
			output(" You lose `#%s experience`\$.`b`0`n",$exploss);
			output("`@`n`c`bYou may begin your adventures again tomorrow.`c`b");
			addnav("Daily news","news.php");
			$session['user']['experience']-=$exploss;
			$session['user']['gold']=0;
			$session['user']['armor']="T-Shirt";
			addnews("%s `@was defeated by a huge tree-like `QO`qbliviax`@ in the forest.",$session['user']['name'],$taunt);
		}
		if (get_module_pref("monsternum")==2){
			$exploss = round($session['user']['experience']*.04);
			output("`\$`nThe Hellhound takes a deadly bite!`n`n");
			output("`^All your gold is carried away by the `\$Hellhound`^ for its master's treasury.`n");
			output(" `\$You lose `#%s experience`\$.`b`0`n",$exploss);
			output("`@`n`c`bYou may begin your adventures again tomorrow.`c`b");
			addnav("Daily news","news.php");
			$session['user']['experience']-=$exploss;
			$session['user']['gold']=0;
			addnews("%s `^was defeated by a `\$Hellhound`^.",$session['user']['name'],$taunt);
			set_module_pref("goodlib",0);
			set_module_pref("badlib",0);
		}
		if (get_module_pref("monsternum")==3){
			$exploss = round($session['user']['experience']*.03);
			output("`nThe final chapter falls onto your head.");
			output("You see your life start to fade before your very eyes.");
			output("Alas! The pen IS mightier than the sword!`n`n");
			output("`^You lose all your gold`n`\$You lose `#%s experience`\$.`b`0`n",$exploss);
			output("`@`n`c`bYou may begin your adventures again tomorrow.`c`b");
			addnav("Daily news","news.php");
			$session['user']['experience']-=$exploss;
			$session['user']['gold']=0;
			addnews("%s `^was smooshed under some rather boring literature.  Word!",$session['user']['name']);
		}
		if (get_module_pref("monsternum")==4){
			$exploss = round($session['user']['experience']*.04);
			output("`n`#You are killed by the `qB`^ear`#.");
			output("The `qB`^ear`# smiles happily and makes your body into a very nice rug and places it in the middle of the room.`n`n");
			output("`\$You lose `#%s experience`\$.`b`0`n",$exploss);
			output("`^You lose all your gold.`n");
			output("`@`n`c`bYou may begin your adventures again tomorrow.`c`b");
			addnav("Daily news","news.php");
			$session['user']['experience']-=$exploss;
			$session['user']['gold']=0;
			addnews("%s`# became a rug in the Library of the `\$Vampire's Tower`#.",$session['user']['name']);
		}
		if (get_module_pref("monsternum")==5){
			$exploss = round($session['user']['experience']*.1);
			output("`n`\$`bThe wolf gets a deadly hold on your neck and bites.");
			output("The last sound you hear is snapping of the cervical vertebrae of your neck.`b`n`n");
			output(" `\$You lose `#%s experience`\$.`0`n",$exploss);
			output("`@You lose `^all your gold`@.`n");
			output("`n`c`bYou may begin your adventures again tomorrow.`c`b");
			addnav("Daily news","news.php");
			$session['user']['experience']-=$exploss;
			$session['user']['gold']=0;
			addnews("%s `#was killed by a wolf in the `\$Vampire's Tower`#.",$session['user']['name'],$taunt);
		}
		if (get_module_pref("monsternum")==6){
			$exploss = round($session['user']['experience']*.1);
			output("`n`\$`bThe bats swarm and thrive on your fresh blood.");
			output("The flurry of wings is the last site you see.`b`n`n");
			output(" `\$You lose `#%s experience`\$.`0`n",$exploss);
			output("`@You lose `^all your gold`@.`n");
			output("`n`c`bYou may begin your adventures again tomorrow.`c`b");
			addnav("Daily news","news.php");
			$session['user']['experience']-=$exploss;
			$session['user']['gold']=0;
			addnews("%s `#was killed by a `QColony of Bats`# in the `\$Vampire's Tower`#.",$session['user']['name']);
		}
		if (get_module_pref("monsternum")==7){
			$exploss = round($session['user']['experience']*.1);
			output("`n`\$`bThe `QVampire`\$ leans in for a final bite, draining your body of blood.");
			output("You fall to the ground as your life force ebbs out of your carcass.");
			output("Strigoi smiles and goes to sleep in his coffin, feeling very safe and comfortable. `b`n`n");
			output(" `\$You lose `#%s experience`\$.`n",$exploss);
			output("You lose `^all your gold`\$.`n");
			output("`n`c`bYou may begin your adventures again tomorrow.`c`b");
			addnav("Daily news","news.php");
			$session['user']['experience']-=$exploss;
			$session['user']['gold']=0;
			addnews("%s `#was killed by `\$Strigoi the Vampire`# in the `\$Vampire's Tower`#.",$session['user']['name']);
		}
	}else{
		require_once("lib/fightnav.php");
		fightnav(true,false,"runmodule.php?module=strigoitower");
	}
}

page_footer();
function strigoitower_tbc(){
	global $session;
	output("`n`c");
	if (get_module_setting("translation")==0){	
		rawoutput("<font size='+1'><span style=\"width: 200; height: 30; color: #000000; filter: glow(color=#FF3333, strength=7)\">To Be Continued...</span></font>");
	}else{
		output("`b`\$To Be Continued...`b");
	}
	output("`c");
	$session['user']['specialinc'] = "";
	addnav("Back to the Forest","forest.php");
}
function strigoitower_dresser(){
	set_module_pref("bedroom",3);
	output("You decide to try using the key from under the bed to open the music box.");
	output("`n`nYou slowly slide the key into the lock and hear a click.");
	output("`n`nWhen you open the box, a gentle music starts playing.");
	output("You listen to the song and look through the box until you find a piece of parchment.");
	output("It reads very simply:");
	output("`n`n`c`^For the love of eternity,");
	output("`nFor the memory of my heart,");
	output("`nIf we life forever,");
	output("`nWe shall never be apart.`)`c`n");
	output("You're not sure what to make of this, but perhaps it's a clue.");
	output("With quiet reverence, you put the note back in the box and lock it, leaving the key next to the box.");
	addnav("Check the Closet","runmodule.php?module=strigoitower&op=closet");
	addnav("Return to the Forest","runmodule.php?module=strigoitower&op=forest");
}
function strigoitower_closet(){
	set_module_pref("visitnum",4);
	set_module_pref("bedroom",0);
	set_module_pref("searchbed",0);
	set_module_pref("searchdresser",0);
	set_module_pref("searchcloset",0);
	set_module_pref("gotkey",0);
	output("You take a look in the closet and notice it's completely empty.");
	output("Suddenly, you recall the message from in the music box...");
	output("`n`n`c`^For the love of eternity,");
	output("`nFor the memory of my heart,");
	output("`nIf we life forever,");
	output("`nWe shall never be apart.`)`c`n");
	output("Suddenly, you notice a knot of wood in the shape of a heart in the upper corner of the closet.");
	output("You reach out to touch it, but atiny voice in your head warns you that you better not.");
	output("The sun is starting to set, and this may be a bad idea.");
	output("You will have to come back another time.`n");
}
function strigoitower_closetnav(){
	if(get_module_pref("bedroom")<3 && get_module_pref("searchdresser")==0) addnav("Search the Dresser","runmodule.php?module=strigoitower&op=dresser");
	if(get_module_pref("bedroom")<3 && get_module_pref("searchdresser")==1) addnav("Search the Dresser","runmodule.php?module=strigoitower&op=redresser");
	if(get_module_pref("bedroom")<2 && get_module_pref("searchbed")==0) addnav("Look under the Bed","runmodule.php?module=strigoitower&op=bed");
	if(get_module_pref("bedroom")<2 && get_module_pref("searchbed")==1) addnav("Look under the Bed","runmodule.php?module=strigoitower&op=underbed");
	if(get_module_pref("bedroom")<1) addnav("Examine the Windows","runmodule.php?module=strigoitower&op=windows");
	addnav("Return to the Forest","runmodule.php?module=strigoitower&op=forest");
}
function strigoitower_dressernav(){
	if(get_module_pref("bedroom")<2 && get_module_pref("searchbed")==0) addnav("Look under the Bed","runmodule.php?module=strigoitower&op=bed");
	if(get_module_pref("bedroom")<2 && get_module_pref("searchbed")==1) addnav("Look under the Bed","runmodule.php?module=strigoitower&op=underbed");
	if(get_module_pref("bedroom")<4 && get_module_pref("searchcloset")==0)addnav("Check the Closet","runmodule.php?module=strigoitower&op=closet");
	if(get_module_pref("bedroom")<4 && get_module_pref("searchcloset")==1)addnav("Check the Closet","runmodule.php?module=strigoitower&op=recloset");
	if(get_module_pref("bedroom")<1) addnav("Examine the Windows","runmodule.php?module=strigoitower&op=windows");
	addnav("Return to the Forest","runmodule.php?module=strigoitower&op=forest");
}
function strigoitower_vampireattack(){
	output("A cloak hangs from his shoulders giving him the appearance of having wings.");
	output("An `\$o`Qr`^n`@a`#t`!e`) necklace fastens the cloak around his neck.");
	output("You're face to face with...`n`n`c");
	if (get_module_setting("translation")==0){
		rawoutput("<font size='+1'>");
		rawoutput("<span style=\"width: 150; height: 30; color: #000000; filter: glow(color=#FF3333, strength=10)\">Strigoi The Vampire!!</span>");
		rawoutput("</font>");
	}else{
		output("`b`\$Strigoi the Vampire`b");
	}
	output("`c");
	addnav("`\$Fight Strigoi the Vampire!","runmodule.php?module=strigoitower&op=attack");
	set_module_pref("monsternum",7);
}
?>
