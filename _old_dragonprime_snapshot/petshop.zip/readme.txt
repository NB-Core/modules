****************************************************************
Name: Pet Shop
Author: Eth - ethstavern(at)gmail(dot)com 
Version: 3.8
Release Date: 12-25-2005
About: Readme file for petshop.zip
Files: petshop.php
***************************************************************

To install, drop into your modules directory and activate 
via the Modules Manager. To add new pets, use the provided
editor. 
