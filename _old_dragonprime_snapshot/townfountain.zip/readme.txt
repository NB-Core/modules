****************************************************************
Name: Town Fountain
Author: Eth - ethstavern(at)gmail(dot)com 
Version: 1.1
Release Date: 02-19-2005
About: Readme file for townfountain.zip
Files: townfountain.php
This is for Version .98 only!!
***************************************************************

To install, drop into your modules directory and activate 
via the Modules Manager. 

Town Fountain will all be found under the Village category afterwards.

Enjoy!

End of Readme