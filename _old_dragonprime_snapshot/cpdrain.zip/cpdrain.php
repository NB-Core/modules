<?php

require_once("lib/commentary.php");

function CPdrain_getmoduleinfo(){
	$info = array(
		"name"=>"Charm Drain",
		"author"=>"Christian Rutsch<br>Translation by Enderandrew",
		"version"=>"1.01",
		"category"=>"RPG",
		"download"=>"http://dragonprime.net/users/enderwiggin/cpdrain.zip"
	);
	return $info;
}

function CPdrain_install(){
	module_addhook("footer-village");
	return true;
}

function CPdrain_uninstall(){
	return true;
}

function CPdrain_dohook($hookname, $args){
	global $session;
	switch ($hookname) {
		case "footer-village":
			if ($session['user']['superuser'] > 0 && $session['user']['specialinc'] == "") {
				output("`)`n`nRemove charm and respect for roleplaying poorly: ");
				rawoutput("<form action='runmodule.php?module=CPdrain&op=drain' method='POST'>",true);
				rawoutput("<input name='name' id='name'> <input type='submit' class='button' value='Search'>",true);
				rawoutput("</form>",true);
				addnav("","runmodule.php?module=CPdrain&op=drain");
			}
			break;
	}
	return $args;
}

function CPdrain_run() {
	global $session;
	$op = httpget('op');
	$victim = httppost('name');
	$sql = "SELECT charm FROM accounts WHERE login='".$victim."'";
	$result = db_query($sql);
	if (db_num_rows($result) == 1) {
		$row = db_fetch_assoc($result);
		$newcharm = $row['charm'] - 1;
		$sql_neu = "UPDATE accounts SET charm = ".$newcharm." WHERE login='".$victim."'";
		db_query($sql_neu);
		addnews("%s punished %s for posting out of character!", $session[user][name], $victim);
		injectcommentary("village", "", ":cast a killing glance on $victim! `^$victim looses some charm for begging on the village square!");
	}
	redirect("village.php");
}
?>
