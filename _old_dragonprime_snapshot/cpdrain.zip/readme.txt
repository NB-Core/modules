-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
Race - CPDRIN - A module for Legend of the Green Dragon 1.0.3

Legend of the Green Dragon
by  Eric "MightyE" Stevens (http://www.mightye.org)
and JT "Kendaer" Traub (http://www.dragoncat.net)

Software Project Page:
http://sourceforge.net/projects/lotgd

Modification Community Page:
http://dragonprime.net

Author of this Module:
Christian Rutsch http://www.lotgd.de

Enderandrew's LoGD game:
http://enderandrew.com/lotgd/

Download the latest version of this module from:
http://dragonprime.net/index.php?action=viewfiles&user=enderwiggin

----------------------------------------------
-- STATUS: -----------------------------------
----------------------------------------------
This module is STABLE.

----------------------------------------------
-- INFORMATION: ------------------------------
----------------------------------------------
This module was written in German, and I translated this poorly.  I doubt any-
one else will use this, but if you really want to, go ahead.  This is a simple
module that gives Superusers an option to slap down people who are posting OOC
in commentary areas.  This module is obviously intended for role-play heavy
games.

----------------------------------------------
-- INSTALLATION: -----------------------------
----------------------------------------------
Copy the version of cpdrain.php you prefer from within this zip into your
modules directory.

Login to the Superuser Grotto and Install / Activate it.

-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-