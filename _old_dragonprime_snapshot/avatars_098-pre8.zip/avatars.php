<?php
// translator ready
// addnews ready
// mail ready

/* Avatars module by anpera

Version for LoGD 0.9.8 prerelease.8

Allows users to enter an external URL to an avatar which is displayed in their bio.
All players can decide if they want to see the avatars of others by changing their
preferences.

Requires PHP module GD2 to be installed and running to work properly.

Installation:
Just drop avatars.php in your /modules folder, then install and activate via module manager
*/

if ($_GET['op']=="download"){ // this offers the module on every server for download
	$dl=join("",file("avatars.php"));
	echo $dl;
}else{
function avatars_getmoduleinfo(){
	$info = array(
		"name"=>"Avatars",
		"version"=>"14102004",
		"author"=>"A. Rauch (anpera)",
		"category"=>"General",
		"download"=>"modules/avatars.php?op=download",
		"settings"=>array(
			"Avatars Settings,title",
			"maxwidth"=>"Max. width of Avatars (Pixel),range,20,400,20|200",
			"maxheight"=>"Max. height of Avatars (Pixel),range,20,400,20|200",
		),
		"prefs"=>array(
			"Avatars User Prefs, title",
			"user_showavatar"=>"Display avatars in bios?,bool|1",
			"user_avatar"=>"URL of your avatar (.jpg)|",
		),
	);
	return $info;
}

function avatars_install(){
	debug("Installing Avatars Module.");
	// adding german translation into database if needed
	if (db_num_rows(db_query("SELECT uri FROM ".db_prefix("translations")." WHERE uri='module-avatars'"))>0){
		debug("Translation already exists");
	}else{
		$sqls = array(
			"INSERT INTO ".db_prefix("translations")." VALUES (0, 'de', 'mail', '`$Avatar deleted!`0', '`$Avatar gel�scht!`0', 0, 'anpera', '0.9.8-prerelease.9')",
			"INSERT INTO ".db_prefix("translations")." VALUES (0, 'de', 'mail', '`QThe URL of your avatar was corrupt or was no picture and has been deleted automatically. Please check the following URL and enter a new URL in your preferences:`n`$%s', '`QDie Adresse deines Avatars war entweder ung�ltig, oder hat nicht auf ein Bild gezeigt und wurde deshalb automatisch gel�scht. Bitte �berpr�fe die folgende Adresse und gib eine neue URL in deinen Einstellungen ein:`n`$%s', 0, 'anpera', '0.9.8-prerelease.9')",
			"INSERT INTO ".db_prefix("translations")." VALUES (0, 'de', 'module-avatars', 'Are you sure you wish to delete this avatar?', 'Bist du sicher, dass du diesen Avatar l�schen willst?', 0, 'anpera', '0.9.8-prerelease.9')",
			"INSERT INTO ".db_prefix("translations")." VALUES (0, 'de', 'module-avatars', 'Avatar deleted', 'Avatar gel�scht', 0, 'anpera', '0.9.8-prerelease.9')",
			"INSERT INTO ".db_prefix("translations")." VALUES (0, 'de', 'mail', '`QThe URL of your avatar was deleted by an admin. If you want to discuss it, please use the Petition link.', '`QDie Adresse deines Avatars wurde von einem Admin gel�scht. Wenn du dar�ber diskutieren willst, benutze bitte den Link zum Hilfe anfordern.', 0, 'anpera', '0.9.8-prerelease.9')",
			"INSERT INTO ".db_prefix("translations")." VALUES (0, 'de', 'module-avatars', 'Return to bio', 'Zur�ck zur Bio', 0, 'anpera', '0.9.8-prerelease.9')",
			"INSERT INTO ".db_prefix("translations")." VALUES (0, 'de', 'module-avatars', '`$Avatar of %s deleted.', '`$Avatar von %s gel�scht.', 0, 'anpera', '0.9.8-prerelease.9')",
		);
		debug("Trying to insert german  translation into database");
		while (list($key,$sql)=each($sqls)){
			db_query($sql);
		}
	}
	// end translation 
	module_addhook("bioinfo");
	module_addhook("footer-prefs");
	return true;
}

function avatars_uninstall(){
	debug("Uninstalled Avatars.");
	db_query("DELETE FROM ".db_prefix("translations")." WHERE uri='module-avatars'");
	db_query("DELETE FROM ".db_prefix("translations")." WHERE uri='mail' AND intext='`$Avatar deleted!`0'");
	db_query("DELETE FROM ".db_prefix("translations")." WHERE uri='mail' AND intext='`QThe URL of your avatar was corrupt or was no picture and has been deleted automatically. Please check the following URL and enter a new URL in your preferences:`n`$%s'");
	db_query("DELETE FROM ".db_prefix("translations")." WHERE uri='mail' AND intext='`QThe URL of your avatar was deleted by an admin. If you want to discuss it, please use the Petition link.'");
	return true;
}

function avatars_dohook($hookname,$args){
	global $session;
	switch($hookname){
	case "bioinfo":
		if (get_module_pref("user_showavatar")==1){
			$avatar = get_module_pref("user_avatar","avatars",$args['acctid']);
			$avatar = stripslashes(preg_replace("'[\"\'\\><@?*&#; ]'","",$avatar));
			if ($avatar>"" && strpos($avatar,".gif")<1 && strpos($avatar,".GIF")<1 && strpos($avatar,".jpg")<1 && strpos($avatar,".JPG")<1 && strpos($avatar,".png")<1 && strpos($avatar,".PNG")<1){
				require_once("lib/systemmail.php");
				set_module_pref("user_avatar","","avatars",$args['acctid']);
				$subj = array("`\$Avatar deleted!`0");
				$body = array("`QThe URL of your avatar was corrupt or was no picture and has been deleted automatically. Please check the following URL and enter a new URL in your preferences:`n`\$%s",$avatar);
				systemmail($args['acctid'],$subj,$body);
			}else if ($avatar>""){
				$maxwidth = get_module_setting("maxwidth");
				$maxheight = get_module_setting("maxheight");
				$pic_size = @getimagesize($avatar); // GD2 required here - else size always is recognized as 0
				$pic_width = $pic_size[0];
				$pic_height = $pic_size[1];
				// we could check here if the file is a jpeg picture but without GD2 (and for gifs) this always would be true
				/*
				if ($pic_size[0]==0 || $pic_size[1]==0){
					// file not readable so ...
					$avatar="";
				}
				*/
				rawoutput("<table><tr><td valign='top'>");
				output("`^Avatar:`0`n");
				if ($session['user']['superuser'] & SU_EDIT_USERS) {
					$ret = httpget('ret');
					$del = translate_inline("Del");
					$conf = translate_inline("Are you sure you wish to delete this avatar?");
					rawoutput("[ <a href='runmodule.php?module=avatars&act=del&who={$args['acctid']}&ret=$ret' onClick=\"return confirm('$conf');\">$del</a> ]");
					addnav("","runmodule.php?module=avatars&act=del&who={$args['acctid']}&ret=$ret");
				}
				rawoutput("</td><td valign='top'><img src=\"$avatar\" ");
				if ($pic_width > $maxwidth) rawoutput("width=\"$maxwidth\" ");
				if ($pic_height > $maxheight) output("height=\"$maxheight\" ");
				rawoutput("alt=\"".preg_replace("'[`].'","",$args['name'])."\"></td></tr></table>");
			}
			// else do nothing and do it quick
		}
		break;
		case "footer-prefs":
			addnav("Bio","bio.php?char=".rawurlencode($session['user']['login'])."&ret=pprefs.php");
		break;
	}
}

function avatars_run(){
	global $session;
	$act = httpget('act');
	$who = httpget('who');
	$ret = httpget('ret');
	if ($act=="del" && ($session['user']['superuser'] & SU_EDIT_USERS)){
		page_header("Avatar deleted");
		require_once("lib/systemmail.php");
		set_module_pref("user_avatar","","avatars",$who);
		$subj = array("`\$Avatar deleted!`0");
		$body = array("`QThe URL of your avatar was deleted by an admin. If you want to discuss it, please use the Petition link.");
		systemmail($who,$subj,$body);
		$sql = "SELECT login FROM " . db_prefix("accounts") . " WHERE acctid=$who";
		$result = db_query($sql);
		$row = db_fetch_assoc($result);
		$row['login'] = rawurlencode($row['login']);
		addnav("Return to bio","bio.php?char={$row['login']}&ret=$ret");
		if ($ret==""){
			tlschema("nav");
			addnav("Return to the warrior list","list.php");
			tlschema();
		}else{
			$return = cmd_sanitize($ret);
			$return = substr($return,strrpos($return,"/")+1);
			tlschema("nav");
			addnav("Return whence you came",$return);
			tlschema();
		}
		output("`\$Avatar of %s deleted.",$row['login']);
		page_footer();
	}else{
		// let them suffer if they get here
	}
}
}
?>