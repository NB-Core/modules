<?php
function align($val,$user=FALSE){
	global $session;
	if ($user === FALSE) $user = $session['user']['acctid'];
	$amnt = get_align($user);
	set_module_pref('alignment',($amnt + $val),'alignment',$user);
}
function get_align($user=false){
	global $session;
	if ($user === FALSE) $user = $session['user']['acctid'];
		
	$val = get_module_pref('alignment','alignment',$user);
	return $val;
}
function set_align($val,$user=false){
	global $session;
	if ($user === FALSE) $user = $session['user']['acctid'];
	
	set_module_pref('alignment',$val,'alignment',$user);
}
?>