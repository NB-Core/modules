<?php 

//Idee und Umsetzung
//Morpheus aka Apollon
//2005 f�r logd.at(LoGD 0.9.7 +jt ext (GER) 3)
//Umsetzung f�r 1.0.X BansheeElhayn
//Mail to Morpheus@magic.ms or Apollon@magic.ms or Agent.Herby@web.de

function rittersaal_getmoduleinfo() {
	$info = array(
		"name"=>"Der Rittersaal",
		"version"=>"1.1",
		"author"=>"Apollon und <a href='http://www.dailyzone.selfhost.de/lotgd' target=_new>BansheeElhayn</a>",
		"category"=>"Stadttor",
		"download"=>"http://dragonprime.net/users/Apollon/stadttor-pack.zip",
		"requires"=>array(
		"stadttor"=>"1.7 by Apollon und BansheeElhayn",
		"burg"=>"1.0 by Apollon und BansheeElhayn",
		),
        "settings"=>array(
			"Rittersaal Einstellungen,title",
			"wiegold"=>"Wieviel Gold findet der Spieler?,int|1000",
			"wiegems"=>"Wieviel Gems findet der Spieler?,int|5",
		),
		"prefs"=>array(
			"Rittersaal Pr�ferenzen,title",	
			"kamin"=>"War der Spieler heute schon am Kamin?,bool|0",
		),
	);
	return $info;
}

function rittersaal_install(){
		if (!is_module_active("rittersaal")) output("Der Rittersaal wird installiert.");
		module_addhook("burg");
		module_addhook("burg_beschreibung");
		return true;
}

function rittersaal_uninstall(){
	output("Der Rittersaal wird deinstalliert.");
	return true;
}

function rittersaal_dohook($hookname, $args){
	global $session;
	switch($hookname){
		
		case ("burg"):
		addnav("In den Rittersaal","runmodule.php?module=rittersaal");
		break;
		
		case ("burg_beschreibung"):
		output("Eine gro�e, breite Treppe f�hrt in den linken Geb�udefl�gel. Ritter stolzieren durch ein gro�e Eichent�r ein und aus");
		output("und Knechte und M�gde tragen riesige Tabletts mit feinsten Speisen und Getr�nken. Insgesamt herrscht emsiges Treiben");
		output("auf der Treppe und Frauen in den schillerndsten Gew�ndern stehen lachend am Treppenabgang.`n");
		break;
		
		case "newday":
		set_module_pref("kamin",0);
		break;

	}
	return $args;
}

function rittersaal_run() {
	global $session;
	$op=httpget('op');
	$gold=get_module_setting("wiegold");
	$gems=get_module_setting("wiegems");
	$kam=get_module_pref("kamin");
	require_once("lib/commentary.php"); 
	page_header("Der Rittersaal"); 
	  
	if ($op=="") { 
		output("`^`c`bDer Rittersaal`b`c`n"); 
		output("`3Du gehst eine Treppe empor in das linke Geb�ude, die recht steil nach oben f�hrt und gelangst an eine massive `qEichent�r`3, deren T�rrahmen mit Ornamenten verziert ist."); 
		output("`3Vorsichtig �ffnest Du die T�r und trittst ein in einen gro�en Saal. An den W�nden sind die `7Schilde `3m�chtiger `4Krieger `3vergangener Zeiten und `7Waffen `3zu sehen, dazwischen immer wieder `2Wandteppiche `3aus edlen `6Stoffen`3, die Motive aus dem `\$Kampf `3gegen den `@GR�NEN DRACHEN `3zeigen.`n");
		output("`3An der hinteren Wand ist ein gro�er `4Kamin`3, in dem ein `\$Feuer `3brennt und wohlige `qW�rme `3verstr�mt. `qTische `3und `qSt�hle `3stehen in U-Form zu einer gro�en `qTafel `3zusammen, an der bereits einige tapfere `4Recken `3sitzen. In der Mitte befindet sich eine offene `\$Feuerstelle `3, �ber der ein gro�er `7Rost `3h�ngt, auf dem so manche Leckerei brutzelt.`n`n");
		output("`@Dies m�ssen die Reichsritter der `^G�tter `@sein `3denkst Du und verbeugst Dich ehrf�rchtig, worauf einer der `4Recken `3Dich heran winkt und Dir einen Platz an der Tafel anbietet.`n`n"); 
		addcommentary();
		viewcommentary("rittersaal","`3Hinzuf�gen:`0",25,"spricht"); 
		addnav("Zum Thronsaal","runmodule.php?module=rittersaal&op=thron"); 
		addnav("Zum Kamin","runmodule.php?module=rittersaal&op=kamin");
		addnav("Zur�ck in den Burghof","runmodule.php?module=burg"); 
	}
	 
	if ($op=="thron") { 
		page_header("Der Thronsaal"); 
		output("`^`c`bDer Thronsaal`b`c`n"); 
		output("`3Ehrfurchtsvoll betrittst Du einen gro�en Saal, der pr�chtig ausgeschm�ckt ist."); 
		output("An der rechten und linken Seite sind pr�chtige `\$Wandteppiche `3aus den edelsten Stoffen, die Motive aus dem `2Leben `3in unserer Welt zeigen sowie `4Kampfszenen`3. An der hinteren Seite kannst Du drei gro�e, `6pr�chtige `^Throne `3erkennen, auf denen die `^G�tter `3zu sitzen pflegen.");
		output("Rechts und links dieser `6pr�chtigen `^Throne `3erkennst Du `7Waffen `3und `7R�stungen`3, wie Du sie noch nie zuvor gesehen hast und die eine unheimliche Macht ausstrahlen, die Dir in Erinnerung ruft, da� Du Dich hier im `^Thronsaal der G�tter `3befindest.`n");
		output("In der Mitte des Raumes steht ein gro�er, prachtvoll gekleideter `@Elf `3von muskul�ser Gestalt, der Dich n�her winkt.`n`n");
		output("`6H�re, oh Sterblicher, dies ist der Thronsaal der G�tter. Ich bin `!Hermes`6, der Bote der G�tter.");
		output("`6\"Wenn Du den `^G�ttern `6etwas mit zu teilen w�nschst, sei es ein Lob oder eine Kritik an unserer Welt, so kannst Du dies hier tun, ich werde Deine Worte aufschreiben und den `^G�ttern `6zutragen.`n");
		output("`6Auch werden die`^ G�tter`6, oder einer der `^Ihren`6, hier Audienzen abhalten, die rechtzeitig bekannt gegeben werden. Dann kannst Du es `^Ihnen `6pers�nlich mitteilen, so Du dies w�nschst.\"`n`n");
		addcommentary();
		viewcommentary("thronsaal","`3Hinzuf�gen:`0",25,"verk�ndet");
		addnav("Zur�ck zum Rittersaal","runmodule.php?module=rittersaal");
	} 

	if ($op=="kamin") { 
		page_header("Der Kamin"); 
		output("`^`c`bDer Kamin`b`c`n"); 
		if ($kam<2) {
			output("`3 Du trittst n�her an den `4Kamin`3, der sich im hinteren Teil des Saales befindet, und beginnst ihn n�her zu betrachten."); 
			output("`3 Sein Rahmen wurde errichtet aus m�chtigen, behauenen `&Granitbl�cken`3, die mit Ornamenten, Schilden  und `@Drachenmotiven `3 geschm�ckt sind, wobei Dir ins Auge sticht, dass 2 der Schilde, die im oberen der drei `&Granitbl�cke`3 gemei�elt sind, leicht hervor zu treten scheinen."); 
 			output("`3 Je mehr Du sie betrachtest, um so komischer erscheinen sie Dir. Ob das wohl ausl�sende Steine f�r etwas Besonderes sind?"); 
			output("`3 Nachdenklich blickst Du in die `4Fl`6am`4men `3des knisternden `\$Feuers`3 und �berlegst, was Du tun sollst..."); 
			addnav("Am Feuer aufw�rmen","runmodule.php?module=rittersaal&op=feuer"); 
			addnav("Rechten Schild dr�cken","runmodule.php?module=rittersaal&op=rechter");
			addnav("Linken Schild dr�cken","runmodule.php?module=rittersaal&op=linker"); 
			addnav("Beide Schilde dr�cken","runmodule.php?module=rittersaal&op=beide");
			addnav("Zur�ck zum Rittersaal","runmodule.php?module=rittersaal"); 
		}else{ 
			output("`3 Mitlerweile ist es Dir so angenehm warm geworden, dass ein Besuch am Kamin nur dazu f�hren w�rde, dass es Dir zu hei� wird."); 
			addnav("Zur�ck zum Rittersaal","runmodule.php?module=rittersaal"); 
		}
	} 
	if ($op=="feuer") { 
		page_header("Der Kamin"); 
		set_module_pref("kamin",1);
		output("`^`c`bDas Feuer`b`c`n"); 
		output("`3 Du fr�stelst ein wenig, da es in diesem alten Gem�uer mit dicken W�nden doch recht k�hl werden kann, und gehst n�her zum Feuer, um Dich etwas auf zu w�rmen."); 
			switch(e_rand(1,12)){
				case 1:
				case 2:
				case 3:
				output("`3 Du trittst nah ans `\$Feuer `3und die wohlige W�rme, die es vestr�mt, tut Deinem K�rper `6gut`3."); 
				$session['user']['hitpoints']*=1.1;
				addnav("Zur�ck zum Rittersaal","runmodule.php?module=rittersaal");
				break;
				case 4:
				case 5:
				case 6:
				output("`3 Du trittst nah ans `\$Feuer `3um die wohlige W�rme zu sp�ren, doch kommst Du dem Feuer dabei etwas zu nah und `\$verbrennst`3 Dich."); 
					if ($session['user']['hitpoints']<51){
						$session['user']['hitpoints']=1;
					}else{
						$session['user']['hitpoints']-=50;
					}
			
				addnav("Zur�ck zum Rittersaal","runmodule.php?module=rittersaal");
				break;
				case 7:
				case 8:
				case 9:
				output("`3 Du trittst nah ans `\$Feuer `3und die wohlige W�rme, die es vestr�mt, tut Deinem K�rper sehr gut, Du f�hlst Dich phantastisch"); 
					if ($session['user']['hitpoints']<($session['user']['maxhitpoints'])){
						$session['user']['hitpoints']=($session['user']['maxhitpoints']*=1.1);
						$session['user']['turns']+=1;
					}else{
						$session['user']['hitpoints']*=1.1;
						$session['user']['turns']+=1;
					}
				addnav("Zur�ck zum Rittersaal","runmodule.php?module=rittersaal");
				break;
				case 10:
				case 11:
				case 12:
				output("`3 Du trittst nah ans `\$Feuer `3um die wohlige W�rme zu sp�ren, doch kommst Du dem Feuer dabei viel zu nah, Deine Kleidung f�ngt `QFe`6u`Qer `3und noch ehe Dir jemand zu Hilfe eilen kann, `\$verbrennst`3 Du."); 
				$session['user']['alive']=false;
				$session['user']['deathpower']+=15;
				$session['user']['hitpoints']=0;
				$session['user']['gold']=0;
				$session['user']['experience']*0.97;
				addnews("`2%s `4verbrannte qualvoll.",$session['user']['name']);
				addnav("T�gliche News","news.php");
				break;
		}
	} 
	if ($op=="rechter") { 
		page_header("Der Kamin"); 
		set_module_pref("kamin",1);
		output("`^`c`bDer rechte Schild`b`c`n"); 
		output("`3 Du dr�ckst den rechten Schild, der so auff�llig aus dem Stein hervor steht und es tut sich etwas am Kamin...."); 
			switch(e_rand(1,13)){
				case 1:
				case 2:
				case 3:
				output("`3 Aus dem rechten Stein tritt ein Drachenkopf hervor, in dem sich ein Beutel befindet."); 
				output("`3Du nimmst ihn heraus, greifst hinein und findest `6%s Gold`3.",$gold); 
				$session['user']['gold']+=$gold;
				addnav("Zur�ck zum Rittersaal","runmodule.php?module=rittersaal");
				break;
				case 4:
				case 5:
				case 6:
				output("`3 Aus dem rechten Stein tritt ein Drachenkopf hervor, in dem sich ein Beutel befindet."); 
				output("`3Du nimmst ihn heraus, greifst hinein und in einen Haufen scharfkantiger `5Scherben`3.");
					if ($session['user']['hitpoints']<51){
						$session['user']['hitpoints']=1;
					}else{
						$session['user']['hitpoints']-=50;
					}
				addnav("Zur�ck zum Rittersaal","runmodule.php?module=rittersaal");
				break;
				case 7:
				case 8:
				case 9:
				output("`3 Aus dem rechten Stein tritt ein Drachenkopf hervor, in dem sich ein Beutel befindet."); 
				output("`3Du nimmst ihn heraus, greifst hinein und findest `@%s Edelsteine`3.",$gems); 
				$session['user']['gems']+=$gems;
				addnav("Zur�ck zum Rittersaal","runmodule.php?module=rittersaal");
				break;
				case 10:
				case 11:
				case 12:
				output("`3Aus der Decke, genau �ber dem Kamin, �ffnet sich eine Kammer und ein langes `4Pendel `3kommt zum Vorschein, an dessen Ende sich eine Sense befindet, die auf Dich zu rast, Deinen Kopf vom Rumpf trennt und wieder in der Decke verschwindet. Du bist `\$TOT`3!"); 
				$session['user']['alive']=false;
				$session['user']['deathpower']+=15;
				$session['user']['hitpoints']=0;
				$session['user']['gold']=0;
				$session['user']['experience']*0.97;
				addnews("`2%s `4wurde bei der Schatzsuche enthauptet.",$session['user']['name']);
				addnav("T�gliche News","news.php");
				break;
				case 13:
				output("`3 Aus dem rechten Stein tritt ein Drachenkopf hervor, in dem sich eine `2Phiole `3mit einem `6Trank `3befindet."); 
				output("`3Du �ffnest sie, trinkst und"); 
					switch(e_rand(1,5)){ 
						case 1:
						output("`3verlierst `^1 permanenten Lebenspunkt`3."); 
						$session['user']['maxhitpoints']--;
						break;
						case 2:
						output("`3gewinnst `^1 permanenten Lebenspunkt`3."); 
						$session['user']['maxhitpoints']++;
						break;
						case 3:
						output("`3f�hlst Dich `6gro�artig`3!"); 
						$session['user']['hitpoints']*=1.2;
						break;
						case 4:
						output("`3f�hlst Dich `4schlecht`3."); 
						$session['user']['hitpoints']*=0.8;
						break;
						case 5:
						output("`3stirbst! Du bist `4TOT"); 
						$session['user']['alive']=false;
						$session['user']['hitpoints']=0;
						$session['user']['gold']=0;
						$session['user']['experience']*0.95;
						addnews("`2%s `4starb aus Neugierde.",$session['user']['name']);
						addnav("T�gliche News","news.php");
						break;
					}
				addnav("Zur�ck zum Rittersaal","runmodule.php?module=rittersaal");
				break;
		}
	} 
	if ($op=="linker") { 
		page_header("Der Kamin"); 
		set_module_pref("kamin",1);
		output("`^`c`bDer linke Schild`b`c`n"); 
		output("`3 Du dr�ckst den linken Schild, der so auff�llig aus dem Stein hervor steht und es tut sich etwas am Kamin...."); 
			switch(e_rand(1,13)){
				case 1:
				case 2:
				case 3:
				output("`3 Aus dem linken Stein tritt ein Drachenkopf hervor, in dem sich ein Beutel befindet."); 
				output("`3Du nimmst ihn heraus, greifst hinein und findest `6%s Gold`3.",$gold); 
				$session['user']['gold']+=$gold;
				addnav("Zur�ck zum Rittersaal","runmodule.php?module=rittersaal");
				break;
				case 4:
				case 5:
				case 6:
				output("`3 Aus dem linken Stein tritt ein Drachenkopf hervor, in dem sich ein Beutel befindet."); 
				output("`3Du nimmst ihn heraus, greifst hinein und in einen Haufen scharfkantiger `5Scherben`3."); 
					if ($session['user']['hitpoints']<51){
						$session['user']['hitpoints']=1;
					}else{
						$session['user']['hitpoints']-=50;
					}
				addnav("Zur�ck zum Rittersaal","runmodule.php?module=rittersaal");
				break;
				case 7:
				case 8:
				case 9:
				output("`3 Aus dem linken Stein tritt ein Drachenkopf hervor, in dem sich ein Beutel befindet."); 
				output("`3Du nimmst ihn heraus, greifst hinein und findest `@%s Gems`3.",$gems); 
				$session['user']['gems']+=$gems;
				addnav("Zur�ck zum Rittersaal","runmodule.php?module=rittersaal");
				break;
				case 10:
				case 11:
				case 12:
				output("`3Aus der Decke, genau �ber dem Kamin, �ffnet sich eine Kammer und ein langes `4Pendel `3kommt zum Vorschein, an dessen Ende sich eine Sense befindet, die auf Dich zu rast, Deinen Kopf vom Rumpf trennt und wieder in der Decke verschwindet. Du bist `\$TOT`3!"); 
				$session['user']['alive']=false;
				$session['user']['deathpower']+=15;
				$session['user']['hitpoints']=0;
				$session['user']['gold']=0;
				$session['user']['experience']*0.97;
				addnews("`2%s `4wurde bei der Schatzsuche enthauptet.",$session['user']['name']);
				addnav("T�gliche News","news.php");
				break;
				case 13:
				output("`3 Aus dem linken Stein tritt ein Drachenkopf hervor, in dem sich eine `2Phiole `3mit einem `6Trank `3befindet."); 
				output("`3Du �ffnest sie, trinkst und"); 
					switch(e_rand(1,5)){ 
						case 1:
						output("`3verlierst `^1 Angriffspunkt`3!"); 
						$session['user']['attack']--;
						break;
						case 2:
						output("`3gewinnst `^1 Angriffspunkt`3!"); 
						$session['user']['attack']++;
						break;
						case 3:
						output("`3verlierst `^1 Verteidigungspunkt`3!"); 
						$session['user']['defense']--;
						break;
						case 4:
						output("`3gewinnst einen Verteidigungspunkt`3!"); 
						$session['user']['defense']++;
						break;
						case 5:
						output("`3stirbst! Du bist `4TOT"); 
						$session['user']['alive']=false;
						$session['user']['hitpoints']=0;
						$session['user']['gold']=0;
						$session['user']['experience']*0.95;
						addnews("`2%s `4starb aus Neugierde.",$session['user']['name']);
						addnav("T�gliche News","news.php");
						break;
					}
				addnav("Zur�ck zum Rittersaal","runmodule.php?module=rittersaal");
				break;
		}
	} 
	if ($op=="beide") { 
		page_header("Der Kamin"); 
		set_module_pref("kamin",1);
		output("`^`c`bDie Schilde`b`c`n"); 
		output("`3 Du dr�ckst die beiden Schilde, die so auff�llig aus dem Stein hervor steht und es tut sich etwas am Kamin....");
			switch(e_rand(1,12)){
				case 1:
				case 2:
				case 3:
				output("`3Ein `5Nebel `3schie�t aus einem `@Drachenkopf`3, der sich in der Mitte des oberen Steins befindet und Du f�llst in Ohnmacht.`3."); 
				output("`3Als Du wieder erwachst, findest Du Dich in `6Cedriks Kneipe `3wieder, all Dein Gold ist verschwunden und hast aber keine Ahnung, wie Du dahin gelangt bist....`3.");
				$session['user']['gold']=0;
				addnav("Weiter","inn.php");
				break;
				case 4:
				case 5:
				case 6:
				output("`3Ein `5Nebel `3schie�t aus einem `@Drachenkopf`3, der sich in der Mitte des oberen Steins befindet. Du f�llst in Ohnmacht und als Du erwachst, findest Du Dich auf dem `%Burghof `3in einer Ecke liegend wieder.`3."); 
				output("`3Als Du Dich erhebst, merkst Du, da� Dein `6Goldbeutel `3und Dein S�ckchen mit den `@Edelsteinen `3schwerer geworden sind`3.");
				$session['user']['gold']+=$gold;
				$session['user']['gems']+=$gems;
				addnav("Weiter","runmodule.php?module=burg");
				break;
				case 7:
				case 8:
				case 9:
				if ($session['user']['location'] != getsetting("villagename", LOCATION_FIELDS) && $session['user']['location'] != get_module_setting("villagename","ghosttown") && $session['user']['location'] != get_module_setting("villagename","icetown")) {
				output("`3Ein `5Nebel `3schie�t aus einem `@Drachenkopf`3, der sich in der Mitte des oberen Steins befindet und Du f�llst in Ohnmacht.`3."); 
				output("`3Als Du wieder erwachst, findest Du Dich mitten im `2Wald`3 wieder. Dein `6Gold `3ist verschwunden aber Du f�hlst Dich `^gro�artig`3!");
				$session['user']['gold']=0;
					if ($session['user']['hitpoints']<($session['user']['maxhitpoints'])){
						$session['user']['hitpoints']=($session['user']['maxhitpoints']*=1.1);
						$session['user']['turns']+=1;
					}else{
						$session['user']['hitpoints']*=1.1;
						$session['user']['turns']+=1;
					}
				$session['user']['specialinc']="";
				$session['user']['specialmisc']="";
				addnav("In den Wald","forest.php");
				}else{
				output("`3Ein `5Nebel `3schie�t aus einem `@Drachenkopf`3, der sich in der Mitte des oberen Steins befindet, Du f�llst in Ohnmacht und als Du erwachst, findest Du Dich auf dem `%Burghof `3in einer Ecke liegend wieder.`3."); 
				output("`3Als Du Dich erhebst, merkst Du, da� Dein `6Gold`3 verschwunden ist, aber Du f�hlst Dich `^gro�artig`3!.");
				$session['user']['gold']=0;
					if ($session['user']['hitpoints']<($session['user']['maxhitpoints'])){
						$session['user']['hitpoints']=($session['user']['maxhitpoints']*=1.1);
						$session['user']['turns']+=1;
					}else{
						$session['user']['hitpoints']*=1.1;
						$session['user']['turns']+=1;
					}
				}
				addnav("Weiter","runmodule.php?module=burg");
				break;
				case 10:
				case 11:
				case 12:
				output("`3Ein `5Nebel `3schie�t aus einem `@Drachenkopf`3, der sich in der Mitte des oberen Steins befindet, der Dir den Atem nimmt und Du `4erstickst`3!");
				$session['user']['alive']=false;
				$session['user']['deathpower']+=15;
				$session['user']['hitpoints']=0;
				$session['user']['gold']=0;
				$session['user']['experience']*0.97;
				addnews("`2%s `4erstickte `2qualvoll.",$session['user']['name']);
				addnav("T�gliche News","news.php");
				break;
		}
	}

page_footer(); 

}
?> 