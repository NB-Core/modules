===============================================================================================================================

*** Kurzbeschreibung: ***

Diese zip-Datei beinhaltet die Umsetzung von Apollons Rittersaal aus 0.9.7 f�r 1.0.X Server

===============================================================================================================================

*** Installation: ***

Die Datei ins Modulverzeichnis kopieren.
Anschlie�end in die Grotte wechseln und das Modul "rittersaal.php" installieren.
Modul aktivieren.

===============================================================================================================================

*** Erweiterungen: ***

Der Rittersaal ist eine kleine Erweiterung der Burg und geh�rt ebenfalls in die Kategorie "Stadtmauer".

===============================================================================================================================


Viel Spa�! :)
Apollon und BansheeElhayn.


**************************

Versionshistorie:

21.12.2005  --  Version 1.0, Umsetzung der 0.9.7 Version f�r 1.0.X, erste Ver�ffentlichung


06.01.2006  --  Version 1.1, Erweiterung und Ver�ffentlichung by Apollon