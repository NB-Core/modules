<?php
/*	This specialty was created using the specialty- hand technique created by Chris Vorndran, as a template.

*/

function specialtyjuggle_getmoduleinfo(){
	$info = array(
		"name" => "Specialty - Juggling Act",
		"author" => "`@DaFish",
		"version" => "1.0",
		"download"=>"http://dragonprime.net/users/DaFish/specialtyjuggle.zip",
		"vertxtloc"=>"http://dragonprime.net/users/DaFish/",
		"category" => "Specialties",
		"settings"=> array(
			"Specialty - Juggling Act Settings,title",
			"mindk"=>"The number of DKs needed before the specialty is available.,int|10",
      	),
		"prefs" => array(
			"Specialty - Juggling Act User Prefs,title",
			"skill"=>"Skill points in Juggling Act,int|0",
			"uses"=>"Uses of Juggling Act allowed,int|0",
		),
	);
	return $info;
}

function specialtyjuggle_install(){

	module_addhook("choose-specialty");
	module_addhook("set-specialty");
	module_addhook("fightnav-specialties");
	module_addhook("apply-specialties");
	module_addhook("newday");
	module_addhook("incrementspecialty");
	module_addhook("specialtynames");
	module_addhook("specialtymodules");
	module_addhook("specialtycolor");
	module_addhook("dragonkill");
	return true;
}

function specialtyjuggle_uninstall(){
	// Reset the specialty of anyone who had this specialty so they get to
	// rechoose at new day
	$sql = "UPDATE " . db_prefix("accounts") . " SET specialty='' WHERE specialty='JA'";
	db_query($sql);
	return true;
}

function specialtyjuggle_dohook($hookname,$args){
	global $session,$resline;
	
	$spec = "JA";
	$name = translate_inline("`^J`@u`!g`\$g`Ql`^i`@n`%g `#A`\$c`@t`7");
	$name1 = translate_inline("Juggling Act");
	$ccode = "`6";
	
	switch ($hookname){
		case "dragonkill":
			set_module_pref("uses", 0);
			set_module_pref("skill", 0);
			break;
		case "choose-specialty":
			if ($session['user']['specialty'] == "" || $session['user']['specialty'] == '0') {
				if ($session['user']['dragonkills'] < get_module_setting("mindk")) break;
				addnav("$ccode$name`0","newday.php?setspecialty=".$spec."$resline");
				$t1 = translate_inline("Learnt as a party trick. This skill comes in handy when your trying to get out of a tight spot.");
				$t2 = appoencode(translate_inline("$ccode$name`0"));
				rawoutput("<a href='newday.php?setspecialty=$spec$resline'>$t1 ($t2)</a><br>");
				addnav("","newday.php?setspecialty=$spec$resline");
			}
			break;
		case "set-specialty":
			if($session['user']['specialty'] == $spec) {
				page_header("$name1");
				output("`6Growing up, you were continually mesmerised by a gleeman's 'tricks'.");
				output("During spring festivals you always hung around the visitng gleeman.");
				output("Year by year, slowly but surely you managed to master a few of these 'tricks'.");
				output("Juggling, in particular, was the area that you excelled at. Eventually, you were able to juggle all sorts of things.");
				output("And pretty soon you learned that, if thrown properly, any object can be a deadly weapon.");
			}
			break;
		case "specialtycolor":
			$args[$spec] = $ccode;
			break;
		case "specialtynames":
			if ($session['user']['superuser'] & SU_EDIT_USERS 
				|| $session['user']['dragonkills'] >= get_module_setting("mindk")) 
					$args[$spec] = $name1;
			break;
		case "specialtymodules":
			$args[$spec] = "specialtyjuggle";
			break;
		case "incrementspecialty":
			if($session['user']['specialty'] == $spec) {
				$new = get_module_pref("skill") + 1;
				set_module_pref("skill", $new);
				$c = $args['color'];
				output("`n%sYou gain a level in `&%s%s to `#%s%s!", $c, $name, $c, $new, $c);
				$x = $new % 3;
				
				if ($x == 0){
					output("`n`^You gain an extra use point!`n");
					set_module_pref("uses", get_module_pref("uses") + 1);
				}else{
					if (3-$x == 1) {
						output("`n`^Only 1 more skill level until you gain an extra use point!`n");
					}else{
						output("`n`^Only %s more skill levels until you gain an extra use point!`n", (3-$x));
					}
				}
				output_notl("`0");
			}
			break;
		case "newday":
			$bonus = getsetting("specialtybonus", 1);
			if($session['user']['specialty'] == $spec) {
				if ($bonus){
					output("`n`3For being interested in %s%s`3, you gain `^1`3 extra use of `&%s%s`3 for today.`n",
						$ccode,$name,$ccode,$name);
				}else{
					output("`n`3For being interested in %s%s`3, you gain `^%s`3 extra uses of `&%s%s`3 for today.`n",
						$ccode,$name,$bonus,$ccode,$name);
				}
			}		
			$amt = (int)(get_module_pref("skill") / 3);
			if ($session['user']['specialty'] == $spec) $amt++;
			set_module_pref("uses", $amt);
			break;
		case "fightnav-specialties":
			$uses = get_module_pref("uses");
			$script = $args['script'];

			if ($uses > 0) {
				addnav(array("%s%s (%s points)`0",$ccode,$name,$uses), "");
				addnav(array("%s &#149; %s`7 (%s)`0", $ccode, translate_inline("Coin Toss"), 1), 
				$script."op=fight&skill=$spec&l=1", true);
			}		
			if ($uses > 1) {
				addnav(array("%s &#149; %s`7 (%s)`0", $ccode, translate_inline("Catch"), 2),
				$script."op=fight&skill=$spec&l=2",true);
			}		
			if ($uses > 2) {
				addnav(array("%s &#149; %s`7 (%s)`0", $ccode, translate_inline("Gold Guard"), 3),
				$script."op=fight&skill=$spec&l=3",true);
			}		
			if ($uses > 4) {
				addnav(array("%s &#149; %s`7 (%s)`0", $ccode, translate_inline("Hurl"), 5), 
				$script."op=fight&skill=$spec&l=5",true);
			}
			break;
		case "apply-specialties":
			$skill = httpget('skill');
			$l = httpget('l');
			
			if ($skill == $spec){
				if (get_module_pref("uses") >= $l){
					switch($l){
						case 1:
							apply_buff('ja1',
								array(
									"startmsg"=>"`6You take some gold out of your pouch, and start tossing them at `\${badguy}`).",
									"name"=>"`6Coin Toss",
									"rounds"=>min((2 + floor($session['user']['gold']/150)), 10),
									"wearoff"=>"`6You have tossed all the coins.",
									"minioncount"=>round($session['user']['level']/5)+2,
									"maxbadguydamage"=>max(min(round(($session['user']['gold'])/80,0), 15), 5),
									"effectmsg"=>"`6The coins hits `\${badguy}`6 for `^{damage}`6 damage.",
									"effectnodmgmsg"=>"`6You toss some coins at `\${badguy}`6 but `\$MISSES`6!",
									"schema"=>"module-specialtyjuggle"
								)
							);
							//Coin Toss needs player's gold in hand to increase the number of rounds.
							$goldtoss = min(floor($session['user']['gold']/150), 8)*150;
							$session['user']['gold'] -= $goldtoss;
							break;
						case 2:
							apply_buff('ja2',
								array(
									"startmsg"=>"`6You managed to catch `\${badguy}'s`6 attack!",
									"name"=>"`6Catch",
									"rounds"=>5,
									"wearoff"=>"`6You are no longer able to catch `\${badguy}'s `6attacks.",
									"badguyatkmod"=>0,
									"roundmsg"=>"`\${badguy}'s`6 attack was caught by you!", 
									"schema"=>"module-specialtyjuggle"
								)
							);
							break;
						case 3:
							apply_buff('ja3',
								array(
									"startmsg"=>"`6With the gold coins that you have, you create an impenetrable wall.",
									"name"=>"`6Gold Guard",
									"rounds"=>min(1 + floor($session['user']['gold']/400), 6),
									"wearoff"=>"`6The wall collapses.",
									"defmod"=>1.3,
									"badguydmgmod"=>0,
									"roundmsg"=>"`6You are well guarded against `\${badguy}'s `6attack.",
									"schema"=>"module-specialtyjuggle"
								)
							);
							//Gold guard needs player's gold in hand to increase the number of rounds.
							$goldguard = min(floor($session['user']['gold']/400), 5)*400;
							$session['user']['gold'] -= $goldguard;
							break;
						case 5:
							apply_buff('ja5',
								array(
									"startmsg"=>"`6You start hurling your weapons and armors at `\${badguy}`6.",
									"name"=>"`6Hurl",
									"rounds"=>5,
									"wearoff"=>"`6You have run out of items to throw!",
									"minioncount"=>round(($session['user']['weapondmg']+$session['user']['armordef'])/5),
									"maxbadguydamage"=>$session['user']['weapondmg']+$session['user']['armordef'],
									"effectmsg"=>"`6The items hits `\${badguy}`6 for `^{damage}`6 damage.",
									"effectnodmgmsg"=>"`6You hurl items at `\${badguy}`6 but `\$MISSES`6!",
									"atkmod"=>2,
									"badguyatkmod"=>0.5,
									"roundmsg"=>"`6Your barrage of items makes it difficult for `\${badguy}`6 to attack.",
									"schema"=>"module-specialtyjuggle"
								)
							);
							//The player must sacrifice their weapons and armors to use this ability.
							$session['user']['attack'] -= $session['user']['weapondmg'];
							$session['user']['defense'] -= $session['user']['armordef'];
							$session['user']['armor'] = "Singlet";
							$session['user']['weapondmg']=0;
							$session['user']['weaponvalue']=0;
							$session['user']['weapon'] = "Bare Hands";
							$session['user']['armordef']=0;
							$session['user']['armorvalue']=0;
						break;
					}
					set_module_pref("uses", get_module_pref("uses") - $l);
				}else{
					apply_buff('ja0',
						array(
							"startmsg"=>"`6You fail to juggle even two gold coins!",
							"rounds"=>1,
							"schema"=>"specialtyjuggle"
						)
					);
				}
			}
			break;
		}
	return $args;
}
?>