<?php
//just did this mod to let users have more text
//yes,I like British English, but for users I will comply


function additionalbioinfos_getmoduleinfo(){
	$info = array(
	    "name"=>"Additional Bioinfos",
		"description"=>"This module offers more text to add to your bioinfos... in an extra box of course",
		"version"=>"1.0",
		"author"=>"`2Oliver Brendel",
		"category"=>"General",
		"download"=>"http://dragonprime.net/dls/additionalbioinfos0.zip",
		"settings"=>array(
		"Additional Bioinformations - Settings,title",
		"Note: This restrictions can be up to 65000 Chars,note",
		"charlimit"=>"How many chars may the user enter?,int|400",
		"physicalstats"=>"Let them enter physical stats?,bool|1",
		"additional"=>"Enable additional text,bool|1",
		),
		"prefs"=>array(
		    "Additional Bioinfos,title",
			"user_showbioinfo"=>"Do you want to display this info in your bio?,bool|0",
			"user_additionalbioinfo"=>"Enter your additional Bioinformation here,textarea",
			"0 equals not-set,note",
			"user_age"=>"Your Age:,floatrange,0,120,1|0",
			"80 equals not-set,note",
			"user_height"=>"Your height (in cm):,floatrange,80,215,1|120",
			"0 equals not-set,note",
			"user_eyecolour"=>"Your eyecolor (color codes allowed):,text",
			"user_haircolour"=>"Your haircolor (color codes allowed):,text",
		),
		);
    return $info;
}

function additionalbioinfos_install(){
	output_notl ("Performing Install on Additional Bioinfo Module.`n`n");
	module_addhook_priority("bioinfo",75);
	module_addhook_priority("footer-prefs",75);
	return true;
}

function additionalbioinfos_uninstall()
{
	output_notl ("Performing Uninstall on Additional Bioinfo Module. Thank you for using!`n`n");
	return true;
}


function additionalbioinfos_dohook($hookname, $args){
	global $session;
	switch ($hookname)
	{
	case "bioinfo":
		if (get_module_pref("user_showbioinfo","additionalbioinfos",$args['acctid'])) {
			if (get_module_setting("physicalstats")) {
				$age=get_module_pref("user_age","additionalbioinfos",$args['acctid']);
				if ($age>0) output_notl("`^Age: `@%s`@ Years`n",$age);
				$height=get_module_pref("user_height","additionalbioinfos",$args['acctid']);
				if ($height>80) output_notl("`^Height: `@%s`@ cm`n",$height);
				$eyes=get_module_pref("user_eyecolour","additionalbioinfos",$args['acctid']);
				if ($eyes!='') output_notl("`^Eyecolor: `@%s`@`n",$eyes);
				$hairs=get_module_pref("user_haircolour","additionalbioinfos",$args['acctid']);
				if ($hairs!='') output_notl("`^Haircolor: `@%s`@`n",$hairs);
			}
			if (get_module_setting("additional")) {
				$bio=get_module_pref("user_additionalbioinfo","additionalbioinfos",$args['acctid']);
				$bio=str_replace(chr(13),"`n",$bio);
				output_notl("`^Bio: `@`n%s`@`n",$bio);
			}
		}
		break;
	case "footer-prefs":
		$bio=get_module_pref("user_additionalbioinfo");
		$maxlength=get_module_setting("charlimit");
		output("Note: `^Charlimit for additional bioinfos is %s chars.",$maxlength);
		output(" This additional text is turned `\$%s`^ by your admin.",(get_module_setting("additional")?"on":"off"));
		output(" This additional physical informations are turned `\$%s`^ by your admin.",(get_module_setting("physicalstats")?"on":"off"));
		output_notl("`n");
		if (strlen($bio)>$maxlength) {
			output("Sorry, your description was too long, it has been cut to the proper size!");
			output_notl("`n");
			output("You entered %s more chars than allowed!",strlen($bio)-$maxlength);
			output_notl("`n");
			output("Please edit your entered text if you don't want to have it cut (the original text is still displayed).");
			$bio=substr($bio,0,$maxlength);
		}
		set_module_pref("user_additionalbioinfo",$bio);
		break;
	default:

	break;
	}
	return $args;
}

function additionalbioinfos_run(){
}

?>
