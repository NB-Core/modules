<?php
//addnews ready
// mail ready
// translator ready

/*******************************************
This specialty, and those of the Black and Grey Knights are meant to have alignment restrictions
but, I can't seem to get those restrictions to happen for some reason, so they're currently not
part of the specialties.
*******************************************/

function specialtywhiteknight_getmoduleinfo(){
    $info = array(
        "name" => "Specialty - White Knight",
        "author" => "`6Admin Lexington, `2Alignment Ready Fixed by `4Zelion",
        "version" => "1.0",
        "download" => "http://dragonprime.net/users/zelion/specialtywhiteknight.zip",
        "category" => "Specialties",
        "settings"=> array(
             "Specialty - White Knight Settings,title",
             "alignment"=>"What is the alignment requirement for this specialty?,int|66",
             "mindk"=>"How many DKs do you need before the specialty is available?,int|10",
             "cost"=>"How many points do you need before the specialty is available?,int|0",
             "gain"=>"How much Alignment is gained when specialty is chosen,int|5",
      ),
        "prefs" => array(
            "Specialty - White Knight User Prefs,title",
            "skill"=>"Skill points in White Knight,int|0",
            "uses"=>"Uses of White Knight allowed,int|0",
        ),
    );
    return $info;
}

function specialtywhiteknight_install(){
    $sql = "DESCRIBE " . db_prefix("accounts");
    $result = db_query($sql);
    $specialty="WK";
    while($row = db_fetch_assoc($result)) {
        // Convert the user over
        if ($row['Field'] == "whiteknight") {
            debug("Migrating whiteknight field");
            $sql = "INSERT INTO " . db_prefix("module_userprefs") . " (modulename,setting,userid,value) SELECT 'specialtywhiteknight', 'skill', acctid, whiteknight FROM " . db_prefix("accounts");
            db_query($sql);
            debug("Dropping whiteknight field from accounts table");
            $sql = "ALTER TABLE " . db_prefix("accounts") . " DROP whiteknight";
            db_query($sql);
        } elseif ($row['Field']=="whiteknightuses") {
            debug("Migrating whiteknight uses field");
            $sql = "INSERT INTO " . db_prefix("module_userprefs") . " (modulename,setting,userid,value) SELECT 'specialtywhiteknight', 'uses', acctid, whiteknightuses FROM " . db_prefix("accounts");
            db_query($sql);
            debug("Dropping whiteknightuses field from accounts table");
            $sql = "ALTER TABLE " . db_prefix("accounts") . " DROP whiteknightuses";
            db_query($sql);
        }
    }
    debug("Migrating Whiteknight Specialty");
    $sql = "UPDATE " . db_prefix("accounts") . " SET specialty='$specialty' WHERE specialty='1'";
    db_query($sql);

    module_addhook("choose-specialty");
    module_addhook("set-specialty");
    module_addhook("fightnav-specialties");
    module_addhook("apply-specialties");
    module_addhook("newday");
    module_addhook("incrementspecialty");
    module_addhook("specialtynames");
    module_addhook("specialtymodules");
    module_addhook("specialtycolor");
    module_addhook("dragonkill");
    module_addhook("pointsdesc");
    module_addhook("newday");
    return true;
}

function specialtywhiteknight_uninstall(){
    // Reset the specialty of anyone who had this specialty so they get to
    // rechoose at new day
    $sql = "UPDATE " . db_prefix("accounts") . " SET specialty='' WHERE specialty='WK'";
    db_query($sql);
    return true;
}

function specialtywhiteknight_dohook($hookname,$args){
    global $session,$resline;

    $spec = "WK";
    $name = "White Knight";
    $ccode = "`&";
    $cost = get_module_setting("cost");
    $loss = get_module_setting("gain");

    switch ($hookname) {
        case "pointsdesc":
            $args['count']++;
            $format = $args['format'];
            $str = translate("The White Knight Specialty is availiable upon reaching %s Dragon Kills and %s points.");
            $str = sprintf($str, get_module_setting("mindk"), $cost);
            output($format, $str, true);
        break;

        case "newday":
        $bonus = getsetting("specialtybonus", 1);

        if($session['user']['specialty'] == $spec) {
            if ($bonus == 1) {
                output("`n`3For being interested in %s%s`3, you gain `^1`3 extra use of `&%s%s`3 for today.`n",$ccode,$name,$ccode,$name);
            }

            else {
                output("`n`3For being interested in %s%s`3, you gain `^%s`3 extra uses of `&%s%s`3 for today.`n",$ccode,$name,$bonus,$ccode,$name);
            }
        }

        $amt = (int)(get_module_pref("skill") / 3);
        if ($session['user']['specialty'] == $spec) $amt++;
        set_module_pref("uses", $amt);
        if (is_module_active('alignment') && $session['user']['specialty'] == 'WK') {
                output("`nYour holy calling has raised your alignment.`n");
                align("+2");
        }
        break;

        case "dragonkill":
            set_module_pref("uses", 0);
            set_module_pref("skill", 0);
        break;

        case "choose-specialty":
	if (get_module_pref("alignment","alignment") >= get_module_setting("alignment")) {
            if ($session['user']['specialty'] == "" || $session['user']['specialty'] == '0') {
                $pointsavailable = $session['user']['donation'] - $session['user']['donationspent'];
                if ($session['user']['dragonkills'] < get_module_setting("mindk") || get_module_setting("cost") > $pointsavailable) break;
                addnav("$ccode$name`0","newday.php?setspecialty=".$spec."$resline");
                $t1 = translate_inline("A noble and valient warrior, bent on removing the stain of evil from the world.");
                $t2 = appoencode(translate_inline("$ccode$name`0"));
                rawoutput("<a href='newday.php?setspecialty=$spec$resline'>$t1 ($t2)</a><br>");
                addnav("","newday.php?setspecialty=$spec$resline");
            }
	}
        break;

        case "set-specialty":
            if($session['user']['specialty'] == $spec) {
                page_header($name);
                $session['user']['donationspent'] = $session['user']['donationspent'] - $cost;
                output("`7The White Knights, legendary heroes of old, were believed to be no more.");
                output(" You proved them wrong when you found the abandoned temple, guarded by the last of their order.");
                output(" Knowing that his end was near, he offered to teach you the secrets of the Light.");
                output(" You accepted his offer, and did you best to learn. And then, just before his death, he dubbed you a White Knight.");
                output(" Little did you know, just how much your life was about to change.");
                if (is_module_active('alignment')) {
                    set_module_pref('alignment',get_module_pref('alignment','alignment') + $gain,'alignment');
                }
            }
        break;

        case "specialtycolor":
            $args[$spec] = $ccode;
        break;

    case "specialtynames":
        $pointsavailable = $session['user']['donation'] - $session['user']['donationspent'];
		if ($session['user']['superuser'] & SU_EDIT_USERS || $session['user']['dragonkills'] >= get_module_setting("mindk") || get_module_setting("cost") <= $pointsavailable){
		    $args[$spec] = translate_inline($name);
		}
	break;

    case "specialtymodules":
        $args[$spec] = "specialtywhiteknight";
    break;

    case "incrementspecialty":
        if($session['user']['specialty'] == $spec) {
            $new = get_module_pref("skill") + 1;
            set_module_pref("skill", $new);
            $c = $args['color'];
            //$name = translate_inline($name);
            output("`n%sYou gain a level in `&%s%s to `#%s%s!", $c, $name, $c, $new, $c);
            $x = $new % 3;
            if ($x == 0) {
                output("`n`^You gain an extra use point!`n");
                set_module_pref("uses", get_module_pref("uses") + 1);
            }
            else{
                if (3-$x == 1) {
                    output("`n`^Only 1 more skill level until you gain an extra use point!`n");
                }
                else {
                    output("`n`^Only %s more skill levels until you gain an extra use point!`n", (3-$x));
                }
            }
            output_notl("`0");
        }
    break;

    case "fightnav-specialties":
        $uses = get_module_pref("uses");
        $script = $args['script'];
        if ($uses > 0) {
            addnav(array("$ccode$name (%s points)`0", $uses), "");
            addnav(array("$ccode &#149; `6Healing Light`7 (%s)`0", 1),
                $script."op=fight&skill=$spec&l=1", true);
        }
        if ($uses > 1) {
            addnav(array("$ccode &#149; `6Sword of Sunder`7 (%s)`0", 2),
                $script."op=fight&skill=$spec&l=2",true);
        }
        if ($uses > 2) {
            addnav(array("$ccode &#149; `6Retribution`7 (%s)`0", 3),
                $script."op=fight&skill=$spec&l=3",true);
        }
        if ($uses > 4) {
            addnav(array("$ccode &#149; `6Smite`7 (%s)`0", 5),
                $script."op=fight&skill=$spec&l=5",true);
        }
        break;

    case "apply-specialties":
        $skill = httpget('skill');
        $l = httpget('l');
        if ($skill==$spec){
            if (get_module_pref("uses") >= $l){
                switch($l){
                    case 1:
                        apply_buff('Wk1',
                        array(
                            "startmsg"=>"`6You call on the healing powers of the Light, wrapping yourself in its protective warmth.",
                            "name"=>"`^Healing Light",
                            "rounds"=>round($session['user']['level']+5),
                            "wearoff"=>"`)The Light slowly begins to fade as you step out of its holy protection.",
                            "regen"=>round($session['user']['level']),
                            "effectmsg"=>"You regenerate for {damage} health.",
                            "effectnodmgmsg"=>"You have no wounds to heal, but the light still protects you.",
                            "badguyatkmod"=>0.75,
                            "schema"=>"specialtywhiteknight"
                            )
                        );
                    break;
                    case 2:
                        apply_buff('Wk2',array(
                            "startmsg"=>"`6You strike at the {badguy}'s armor and and weapons, cutting and destroying as you go. ",
                            "name"=>"`^Sunder",
                            "rounds"=>10,
                            "effectmsg"=>"`6You strike with all your might at {badguy}  hurting it for `\${damage}`6 points!",
                            "wearoff"=>"`6The {badguy} won't be so likely to harm you again!",
                            "atkmod"=>1.5,
                            "defmod"=>1.5,
                            "schema"=>"specialtywhiteknight"
                            )
                        );
                    break;
                case 3:
                    apply_buff('Wk3',
                        array(
                            "startmsg"=>"`6You've had quite enough of this {badguy}, and your sword lets him know it!",
                            "name"=>"`^Retribution",
                            "rounds"=>10,
                            "wearoff"=>"`6Feeling as though you've gotten your message across, you clean your blade and slide it home in its sheath.",
                            "effectmsg"=>"`6An angel strikes with a flaming sword at the same time as you, hitting {badguy}`6 for `\${damage}`6 damage.",
                            "badguydmgmod"=>.5,
                            "badguydefmod"=>.5,
                            "atkmod"=>2,
                            "defmod"=>2,
                            "roundmsg"=>"`6{badguy} staggers at the sight of the angel, and deals only one quarter damage.",
                            "schema"=>"specialtywhiteknight"
                        )
                    );
                break;
                case 5:
                    apply_buff('Wk5',
                        array(
                            "startmsg"=>"`6You call upon the strength of your deity, plegding to rid the forest of evil, starting with {badguy}.",
                            "name"=>"`^Smite",
                            "rounds"=>10,
                            "wearoff"=>"`)Feeling that you've met your pledge, you release the deity's strength.",
                            "badguyatkmod"=>.1,
                            "badguydefmod"=>.1,
                            "atkmod"=>3,
                            "defmod"=>3,
                            "effectmsg"=>"`6Your `b`^Smite`b`6 hits {badguy}`6 for `\${damage}`6 damage.",
                            "roundmsg"=>"`6{badguy} `6stands motionless, taking the beating that his evil deeds have earned him.",
                            "schema"=>"specialtywhiteknight"
                            )
                        );
                break;
                }
            set_module_pref("uses", get_module_pref("uses") - $l);
            }
            else{
                apply_buff('Wk0',
                    array(
                        "startmsg"=>"Lacking the strength to continue, you try to raise your sword to attack and defend yourself, but the {badguy} only laughs and lunges forward to attack!",
                        "rounds"=>1,
                        "schema"=>"specialtywhiteknight"
                        )
                );
            }
        }
        break;
    }
    return $args;
}

function specialtywhiteknight_run(){
}
?>