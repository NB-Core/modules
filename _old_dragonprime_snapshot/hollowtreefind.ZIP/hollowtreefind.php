<?php
// translator ready
// mail ready
// addnews ready
function hollowtreefind_getmoduleinfo(){
	$info = array(
		"name"=>"Hollow Tree Finds",
		"version"=>"1.0",
		"author"=>"Jeffrey Riddle",
		"category"=>"Forest Specials",
		"download"=>"http://jeffriddle.info/gamedownloads/logd/hollowtreefind.zip",
		"settings"=>array(
			"Hollow Tree Finds Event Settings,title",
			"gemsgain"=>"Chance to gain a gem (otherwise lose a turn),range,0,100,1|55"
		),
	);
	return $info;
}

function hollowtreefind_install(){
	module_addeventhook("forest", "return 100;");
	return true;
}

function hollowtreefind_uninstall(){
	return true;
}

function hollowtreefind_dohook($hookname,$args){
	return $args;
}

function hollowtreefind_runevent($type)
{
	global $session;
	// The only type of event we care about are the forest.
	$chance = get_module_setting("gemsgain");
	$roll = e_rand(1, 100);
	if ($roll <= $chance) {
		output("`^You discover a hole in a hollow tree.");
		output("As you fell around the tree, you touch something hard.`n`n`n");
		output("You pull your hand out to discover...");
		output("you hold 1 shiny gem`^.`n`n");
		output("You `%receive 1`^ gem!`0");
		$session['user']['gems']++;
	} else {
		output("`^Walking along a path in the forest, you come upon a hollow tree.");
		output("Curious as to what might be in it, you decide to stick your hand inside the hole in the tree.`n`n");
		output("`\$Suddenly you hear a hiss, and relize a poisonous snake is in the tree!");
		output("`^The snake bits your hand before you pull it out, and sinks it's venom into you.");
		output("You sudenly collapse to the forest ground, asleep.Luckly another adventurer killed the snake beofre it killed you.`n`n");
		if ($session['user']['turns'] > 0) {
			output("You `%lose one `^turn!`0");
			$session['user']['turns']--;
		}
	}
}

function hollowtreefind_run(){
}
?>
