<?php
// addnews ready
// mail ready
// translator ready
function titlechange2_getmoduleinfo(){
	$info = array(
		"name"=>"Title Change",
		"author"=>"Billie Kennedy based off of module by JT Traub",
		"version"=>"1.0",
		"download"=>"http://orpgs.com/modules.php?name=Downloads&d_op=viewdownload&cid=6",
		"vertxtloc"=>"http://www.orpgs.com/downloads",
		"category"=>"Administrative",
		"settings"=>array(
			"Title Change Module Settings,title",
			"bold"=>"Allow bold?,bool|1",
			"italics"=>"Allow italics?,bool|1",
			"blank"=>"Allow blank titles?,bool|1",
			"dk"=>"Allow user to choose new title after how many Dragon Kills?,int|0",
		),
	);
	return $info;
}

function titlechange2_install(){
	module_addhook("village");
	return true;
}
function titlechange2_uninstall(){
	return true;
}

function titlechange2_dohook($hookname,$args){
	global $session;
	$dk = get_module_setting('dk');
	
	switch($hookname){
		case "village":
			if ($session['user']['dragonkills'] >= $dk){
				addnav("Other");
				addnav("Customize Title","runmodule.php?module=titlechange2&op=titlechange");			
			}
		break;
	}
	return $args;
}

function titlechange2_run(){
	require_once("lib/sanitize.php");
	require_once("lib/names.php");
	require_once("lib/villagenav.php");
	global $session;
	$op = httpget("op");

	page_header("Customize Title");
	if ($op=="titlechange"){
		output("`3`bCustomize Title`b`0`n`n");
		output("`7The title must be appropriate, and the admin of the game can reset if it isn't (as well as penalize you for abusing the game).");
		output("The title may not be more than 25 characters long including any characters used for colorization!.`n`n");
		$otitle = get_player_title();
		if ($otitle=="`0") $otitle="";
		output("`7Your title is currently`^ ");
		rawoutput($otitle);
		output_notl("`0`n");
		output("`7which looks like %s`n`n", $otitle);
		if (httpget("err")==1) output("`\$Please enter a title.`n");
		output("`7How would you like your title to look?`n");
		rawoutput("<form action='runmodule.php?module=titlechange&op=titlepreview' method='POST'>");
		rawoutput("<input id='input' name='newname' width='25' maxlength='25' value='".htmlentities($otitle)."'>");
		rawoutput("<input type='submit' class='button' value='Preview'>");
		rawoutput("</form>");
		addnav("", "runmodule.php?module=titlechange&op=titlepreview");
	}elseif ($op=="titlepreview"){
		$ntitle = rawurldecode(httppost('newname'));
		$ntitle=newline_sanitize($ntitle);

		if ($ntitle=="") {
			if (get_module_setting("blank")) {
				$ntitle = "`0";
			}
			else{
				redirect("runmodule.php?module=titlechange&op=titlechange&err=1");
			}
		}
		if (!get_module_setting("bold")) $ntitle = str_replace("`b", "", $ntitle);
		if (!get_module_setting("italics")) $ntitle = str_replace("`i", "", $ntitle);
		$ntitle = preg_replace("/[`][cHw]/", "", $ntitle);
		$ntitle = sanitize_html($ntitle);

		$nname = get_player_basename();
		output("`7Your new title will look like this: %s`0`n", $ntitle);
		output("`7Your entire name will look like: %s %s`0`n`n",
				$ntitle, $nname);
		output("`7Is this how you wish it to look?");
		addnav("`bConfirm Custom Title`b");
		addnav("Yes", "runmodule.php?module=titlechange&op=changetitle&newname=".rawurlencode($ntitle));
		addnav("No", "runmodule.php?module=titlechange&op=titlechange");
	}elseif ($op=="changetitle"){
		$ntitle=rawurldecode(httpget('newname'));
		$fromname = $session['user']['name'];
		$newname = change_player_ctitle($ntitle);
		$session['user']['ctitle'] = $ntitle;
		$session['user']['name'] = $newname;
		addnews("%s`^ has become known as %s.",$fromname,$session['user']['name']);
		output("Your custom title has been set.");
	}
	villagenav();
	page_footer();
}
?>