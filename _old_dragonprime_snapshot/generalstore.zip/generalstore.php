<?php

/***************************************************************************/
/* Name: generalstore                                                      */
/* ver 1.1                                                                 */
/* Billie Kennedy => dannic06@gmail.com                                    */
/*                                                                         */
/*4-3-2005                                                                 */
/*  Fixed an undefined array problem                                       */
/*  Added Checkmodule support                                              */
/***************************************************************************/

require_once("lib/villagenav.php");
require_once("lib/http.php");

function generalstore_getmoduleinfo(){
    $info = array(
        "name"=>"General Store",
        "version"=>"1.1",
        "author"=>"Billie Kennedy",
        "category"=>"Bkobjects",
        "download"=>"http://dragonprime.net/users/Dannic/generalstore.zip",
        "vertxtloc"=>"http://dragonprime.net/users/Dannic/",
        "settings"=>array(
            "General Store - Settings,title",
			"storename"=>"Name of the Store,text|General Store",
			"storelocation"=>"Where does the Store appear,location|".getsetting("villagename", LOCATION_FIELDS),
			"buytype"=>"What type of items does the store buy?,text|general",
			"selltype"=>"What type of items does the store sell?,text|general",
			"ownername"=>"What is the name of the owner?,text|Galdon",
			"storedescription"=>"What is the description of the store?,memo|",
        ),
    );
    return $info;
}

function generalstore_install(){
	module_addhook("village");
	module_addhook("changesetting");
    return true;
}

function generalstore_uninstall(){
    return true;
}

function generalstore_dohook($hookname,$args){
    global $session;
	
    switch($hookname){
		case "changesetting":
			if ($args['setting'] == "villagename") {
				if ($args['old'] == get_module_setting("storelocation")) {
					set_module_setting("storelocation", $args['new']);
				}
			}
			break;
		case "village":
			if ($session['user']['location'] == get_module_setting("storelocation")) {
				tlschema($args['schemas']['marketnav']);
				addnav($args['marketnav']);
				tlschema();
				addnav("G?The General Store","runmodule.php?module=generalstore");
			}
		break;   	
		case "devtest":
			addnav("The General Store","runmodule.php?module=generalstore"); 	
		break;
	}
    return $args;
}

function generalstore_run(){

	global $session;
	$op = httpget('op');
	$op2 = httpget('op2');
	$op3 = httpget('op3');
	$texts = array();
	$storename = get_module_setting("storename");
	$ownername = get_module_setting("ownername");
	$storedesc = get_module_setting("storedescription");
	
	page_header($storename);
	
	if ($op == ''){
	addnav("Return to Village","village.php");
	addnav("Buy Items");
	addnav("Sell Items");
	output("`b`c`!$storename`0`c`b`n");
	output("$storedesc");

	modulehook("generalstore",$texts);
	}
	
		
	page_footer();
}
?>