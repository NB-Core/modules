<?php
// translator ready
// addnews ready

function racehorse_getmoduleinfo(){
	$info = array(
		"name"=>"Race - Equine (no city)",
		"version"=>"1.31",
		"author"=>"Rowne Mastaile<br>Redone by `!Enderandrew",
		"category"=>"Races",
		"description"=>"This adds an Equine/Horse race to the game.",
		"download"=>"http://dragonprime.net/users/enderwiggin/racehorse.zip",
		"vertxtloc"=>"http://dragonprime.net/users/enderwiggin/",
		"requires"=>array(
			"racebunny" => "1.3|Billie Kennedy, http://nuketemplate.com/modules.php?name=Downloads&d_op=getit&lid=108",
		),
		"settings"=>array(
			"Equine Race Settings,title",
			"minedeathchance"=>"Chance for Equines to die in the mine,range,0,100,1|50",
			"mindk"=>"How many DKs do you need before the race is available?,int|5",
			"cost"=>"How many Donation points do you need before the race is available?,int|0",
		),
	);
	return $info;
}

function racehorse_install(){
	if (!is_module_installed("racebunny")) {
		output("This module requires the Toki race to be installed.");
    return false;
	}
	else {
		module_addhook("charstats");
		module_addhook("chooserace");
		module_addhook("equinetravel");
		module_addhook("newday");
		module_addhook("pointsdesc");
		module_addhook("pvpadjust");
		module_addhook("raceminedeath");
		module_addhook("setrace");
		module_addhook("stablelocs");
		module_addhook("stabletext");
	  return true;
	}
}

function racehorse_uninstall(){
	global $session;
	$vname = getsetting("villagename", LOCATION_FIELDS);
	$gname = get_module_setting("villagename");
	$sql = "UPDATE " . db_prefix("accounts") . " SET location='$vname' WHERE location = '$gname'";
	db_query($sql);
	if ($session['user']['location'] == $gname)
		$session['user']['location'] = $vname;
	// Force anyone who was a Equine to rechoose race
	$sql = "UPDATE  " . db_prefix("accounts") . " SET race='" . RACE_UNKNOWN . "' WHERE race='Equine'";
	db_query($sql);
	if ($session['user']['race'] == 'Equine')
		$session['user']['race'] = RACE_UNKNOWN;
	return true;
}

function racehorse_dohook($hookname,$args){
	//yeah, the $resline thing is a hack.  Sorry, not sure of a better way
	// to handle this.
	// Pass it as an arg?
	global $badguy,$session,$resline;
	if (is_module_active("racebunny")) {
		$city = get_module_setting("villagename", "racebunny");
	} else {
		$city = getsetting("villagename", LOCATION_FIELDS);
	}
	$cost = get_module_setting("cost");
	$race = "Equine";
	switch($hookname){
		
	case "charstats":
		if ($session['user']['race']==$race){
			addcharstat("Vital Info");
			addcharstat("Race", translate_inline($race));
		}
		break;
		
	case "chooserace":
		$pointsavailable = $session['user']['donation'] - $session['user']['donationspent'];
		if ($session['user']['dragonkills'] < get_module_setting("mindk") || get_module_setting("cost") > $pointsavailable)
			break;
		output("`0<a href='newday.php?setrace=$race$resline'>On the rolling hills surrounding the city of %s</a>, the gathering of `&Equines`0; you were always praised for being one of the fastest of the herd and because of this, you were entrusted with many important tasks and even awarded the oppurtunity for trade, being so swift.`n`n", $city, true);
		addnav("`&Equine`0","newday.php?setrace=$race$resline");
		addnav("","newday.php?setrace=$race$resline");
		break;
		
	case "equinetravel":
		if ($session['user']['race'] == "Equine") $args['available'] += 20;		
		break;
		
	case "newday":
		if ($session['user']['race']==$race){
			racehorse_checkcity();
			$args['turnstoday'] .= ", Race (Equine): 1";
			output("`n`&Because you are an Equine you gain `^20 `&extra travel points for today!`n`0");
		}
		break;
		
	case "pointsdesc":
		if (get_module_setting("mindk")>0 || $cost>0)
		{
			$args['count']++;
			$format = $args['format'];
			$str = translate("The Equine race is availiable upon reaching %s Dragon Kills and %s Donation points.");
			$str = sprintf($str, get_module_setting("mindk"),
					get_module_setting("cost"));
			output($format, $str, true);
		}
		break;

	case "pvpadjust":
		if ($args['race'] == $race) {
			$badguy['stats']['attack']*=(0.9);
		}
		break;

	case "raceminedeath":
		if ($session['user']['race'] == $race) {
			$args['chance'] = get_module_setting("minedeathchance");
		}
		break;
		
	case "setrace":
		if ($session['user']['race']==$race){
			output("`&As an Equine, your speed and swiftness cannot be matched, you can travel greater distances than any other race.`n`^You gain more travel points!");
			if (is_module_active("cities")) {
				if ($session['user']['dragonkills']==0 &&
						$session['user']['age']==0){
					//new farmthing, set them to wandering around this city.
					set_module_setting("newest-$city",
							$session['user']['acctid'],"cities");
				}
				set_module_pref("homecity",$city,"cities");
				$session['user']['location']=$city;
			}
		}
		break;
		
	case "stablelocs":
		tlschema("mounts");
		$args[$city]=sprintf_translate("The Village of %s", $city);
		tlschema();
		break;
		
	case "stabletext":
		if ($session['user']['location'] != $city) break;
		$args['title'] = "Swifthoof's Irrelevancies";
		$args['schemas']['title'] = "module-racehorse";
		$args['desc'] = "`6One of the larger huts of the grasslands holds a number of pens containing creatures of all shapes and sizes, which might be attributed as mounts.  Of course, these Equines being what they are they probably don't actually require mounts but they might be good for sale ... quite why this trader is doing that here however instead of in one of the other cities is not quite conceivable.  As you approach, Swifthoof shnorts, \"`^Ehhh, another slow one, so what do you need, %s?`6\", he asks in condescending, whickered tones.";
		$args['schemas']['desc'] = "module-racehorse";
		$args['lad']="friend";
		$args['schemas']['lad'] = "module-racehorse";
		$args['lass']="friend";
		$args['schemas']['lass'] = "module-racehorse";
		$args['nosuchbeast']="`6\"`^I don't gots one of those, whatever `ithat`i is.`6\", Swifthoof mutters.";
		$args['schemas']['nosuchbeast'] = "module-racehorse";
		$args['finebeast']=array(
			"`6\"`^That beast is pretty fast.  It's almost as fast as I am.  ... but not quite.`6\", explains Swifthoof.`n`n",
			"`6\"`^Merrick thinks he knows it all but he has no idea how to bring the potential of speed from his mounts.  None at all.`6\", Swifthoof boasts.`n`n",
			"`6\"`^This one's a beefy brute, it might not help its speed but it could probably take more of a beating ...`6\". he comments in passing.`n`n",
			"`6\"`^Whilst I dislike reliance on mounts, I can assure you that I care deeply for my creatures and I'm sure that none could share the level of bond that I do with some of them.`6\". explains Swifthoof.`n`n",
			"`6\"`^No matter what the price, we Equine are too proud to swindle, it will be an honest price`6\", notes Swifthoof adamantly.`n`n",
			);
		$args['schemas']['finebeast'] = "module-racehorse";
		$args['toolittle']="`6Swifthoof looks over the gold and gems you offer and snorts loudly, \"`^Obviously you misheard my price.  This %s will cost you `&%s `^gold  and `%%s`^ gems and not a penny less.`6\"";
		$args['schemas']['toolittle'] = "module-racehorse";
		$args['replacemount']="`6Patting %s`6 on the rump, you hand the reins as well as the money for your new creature, and Swifthoof hands you the reins of a `&%s`6.";
		$args['schemas']['replacemount'] = "module-racehorse";
		$args['newmount']="`6You hand over the money for your new creature, and Swifthoof hands you the reins of a new `&%s`6.";
		$args['schemas']['newmount'] = "module-racehorse";
		$args['nofeed']="`6\"`^No %s, I don't stock feed here.  I will not explain myself.  Perhaps you should look elsewhere to feed your creature.`6\"";
		$args['schemas']['nofeed'] = "module-racehorse";
		$args['nothungry']="`&%s`6 picks briefly at the food and then ignores it.  Swifthoof, being the honest Equine that he is, shakes his head and hands you back your gold.";
		$args['schemas']['nothungry'] = "module-racehorse";
		$args['halfhungry']="`&%s`6dives into the provided food and gets through about half of it before stopping.  \"`^Well, it wasn't as hungry as you thought.`6\" says Swifthoof as he hands you back all but %s gold.";
		$args['schemas']['halfhungry'] = "module-racehorse";
		$args['hungry']="`6%s`6 seems to inhale the food provided.  %s`6, the greedy creature that it is, then goes snuffling at Swifthoof's pockets for more food.`nSwifthoof shakes his head in disbelief and collects `&%s`6 gold from you.";
		$args['schemas']['hungry'] = "module-racehorse";
		$args['mountfull']="`n`6\"`^Well, %s, your %s`^ was truly hungry today, but we've got it full up now.  Come back tomorrow if it hungers again, and I shall see to your beast's needs.`6\", states Swifthoof flatly.";
		$args['schemas']['mountfull'] = "module-racehorse";
		$args['nofeedgold']="`6\"`^No, there is just not enough money to pay for food here.`6\"  Swifthoof turns his back on you, and you lead %s away to find other places for feeding.";
		$args['schemas']['nofeedgold'] = "module-racehorse";
		$args['confirmsale']="`n`n`6Swifthoof eyes your mount up and down, checking it over carefully.  \"`^Are you quite sure you wish to part ways with your companion?  It seems to have formed a strong bond with you.`6\"";
		$args['schemas']['confirmsale'] = "module-racehorse";
		$args['mountsold']="`6With but a single tear, you hand over the reins to your %s`6 to Swifthoof.  The tear dries quickly, and the %s in hand helps you quickly overcome your sorrow.";
		$args['schemas']['mountsold'] = "module-racehorse";
		$args['offer']="`n`n`6Swifthoof strokes your creature's flank and offers you `&%s`6 gold and `%%s`6 gems for %s`6.";
		$args['schemas']['offer'] = "module-racehorse";
		break;
		
	}
	return $args;
}

function racehorse_checkcity(){
	global $session;
	$race="Equine";
    if (is_module_active("racebunny")) {
		$city = get_module_setting("villagename", "racebunny");
	} else {
		$city = getsetting("villagename", LOCATION_FIELDS);
	}	
	if ($session['user']['race']==$race && is_module_active("cities")){
		//if they're this race and their home city isn't right, set it up.
		if (get_module_pref("homecity","cities")!=$city){ //home city is wrong
			set_module_pref("homecity",$city,"cities");
		}
	}	
	return true;
}

function racehorse_run(){

}
?>