-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
Race - Equine - A module for Legend of the Green Dragon 1.0.3

Legend of the Green Dragon
by  Eric "MightyE" Stevens (http://www.mightye.org)
and JT "Kendaer" Traub (http://www.dragoncat.net)

Software Project Page:
http://sourceforge.net/projects/lotgd

Modification Community Page:
http://dragonprime.net

Author of this Module:
Original - Rowne (wuffxiii@gmail.com)
Alterered by - Enderandrew (enderandrew@gmail.com)

Enderandrew's LoGD game:
http://enderandrew.com/lotgd/

Download the latest version of this module from:
http://dragonprime.net/index.php?action=viewfiles&user=enderwiggin

----------------------------------------------
-- STATUS: -----------------------------------
----------------------------------------------
This module is STABLE.

----------------------------------------------
-- INFORMATION: ------------------------------
----------------------------------------------
This was originally a module by Rowne.  I liked the idea, and the unique
nature of the race.  However, the module lacked settings to allow me to
set how many DK's or donation points one would need to unlock this race.
Secondly, I have quite a few cities in my game as is.  I plan on taking
the Toki (Bunnies), Equines (Horses) and Lupines (Wolves) and lumping them
in one anthromoporphic city, which in my game I'm calling El Goonish Shive.
It's a reference to a webcomic where there are some characters who shape-
shift into animal forms.  I digress.

There are two versions of this module, and I will likely release all race
modules like this.  The first gives the Equines their own city.  The second
version has the Equines sharing a city with the Toki, and thusly they need
to be installed and active for the second version to work.  The choice is
yours on which to use.  I was considering creating a setting in the module
to allow you to change whether or not there was a city.  However, this is
the easiest way to go.  If someone has a better method of handling the option
of city versus shared city, please drop me a line on the Dragonprime forums
or at enderandrew@gmail.com

This module requires version 1.0.3 or later of LotGD!

Hope you enjoy!

----------------------------------------------
-- INSTALLATION: -----------------------------
----------------------------------------------
Copy the version of raceequine.php you prefer from within this zip into your
modules directory.

Login to the Superuser Grotto and Install / Activate it.

-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-