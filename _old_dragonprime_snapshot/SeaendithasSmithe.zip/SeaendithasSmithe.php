<?php
// SeaendithasSmithe.php
/* ver 1.0 by Jeremy Darling => jdarling -at- eonclash -dot- com
	 Aug 30th - 1st Release
	 ver 1.1
	 Aug 31st - Bug fix release and fixes for translation engine
*/
  
require_once("lib/http.php");

function SeaendithasSmithe_getmoduleinfo(){
	$info = array(
		"name"=>"Seaendithas Smithe",
		"author"=>"Jeremy Darling",
		"version"=>"1.1",
		"category"=>"Village",
		"download"=>"http://dragonprime.net/users/Kermit/SeaendithasSmithe.zip",
		"settings"=>array(
			"Seaendithas The Smith Settings,title",
			"normalnuggetchance"=>"Chance for a mob to drop a normal nugget,range,0,100,1|15",
			"silvernuggetchance"=>"Chance for a mob to drop a silver nugget,range,0,100,1|15",
			"goldnuggetchance"=>"Chance for a mob to drop a gold nugget,range,0,100,1|10",
			"attacknuggetchance"=>"Chance for a mob to drop an enchanged attack nugget,range,0,100,1|5",
			"defensenuggetchance"=>"Chance for a mob to drop an enchanged defense nugget,range,0,100,1|5",
			"nonuggetchance"=>"Chance of no nugget at all being dropped,range,0,100,1|50",
			"maxattack"=>"Maxium attack value that a weapon can recieve,range,0,50,1|30",
			"maxdefense"=>"Maxium defense value that a piece of armour can recieve,range,0,50,1|30",
		),
		"prefs"=>array(
			"Seaendithas Smithe User Prefences,title",
			"nuggets"=>"Normal Nuggets,int",
			"silvernuggets"=>"Normal Nuggets,int",
			"goldnuggets"=>"Gold Nuggets,int",
			"attacknuggets"=>"Attack Nuggets,int",
			"defensenuggets"=>"Defense Nuggets,int",
		)
	);
	return $info;
}

function SeaendithasSmithe_install(){
	//module_addeventhook("forest", "return 100;");
	module_addhook("battle-victory");
	module_addhook("village");
  return true;
}

function SeaendithasSmithe_uninstall(){
	return true;
}

function SeaendithasSmithe_TableItem($ItemType, $FieldName, $Description, $AtLeast1 = false)
{
	rawoutput("      <tr>");
	rawoutput("        <td>");
	output("          %s", $ItemType);
	rawoutput("        </td>");
	rawoutput("        <td>");
  if (get_module_pref($FieldName) > 0)
	{
    rawoutput("<select name='$FieldName'>");
    if ($AtLeast1) 
    {
      $min = 1;
    }
    else
    {
      $min = 0;
    }
    for ($i = $min; $i <= get_module_pref($FieldName); $i++)
    {
      rawoutput("<option>$i</option>");
    }
    rawoutput("</select>");
	} 
	else 
	{
  	rawoutput("          N/A");
  	rawoutput("          <input type='hidden' name='$FieldName' value='0'>");
	}
	rawoutput("        </td>");
	rawoutput("        <td>");
	output("          %s", $Description);
	rawoutput("        </td>");
	rawoutput("      </tr>");
}

function SeaendithasSmithe_ShowBuildWeapon()
{
	$from = "runmodule.php?module=SeaendithasSmithe&";

  output("You request a weapons template.  Seaendithas enters the hut and soon returns ");
  output("with piece of paper.  He hands it to you stating \"This be the prices and requirements, fill in the form and give it to me when your done.\"`n");
  output("`n");
	rawoutput("<form action='".$from."op=weapon&subop=order' method='POST'>");

	rawoutput("    <table>");
	rawoutput("      <tr>");
	rawoutput("        <td>");
	output("          Item Type");
	rawoutput("        </td>");
	rawoutput("        <td>");
	rawoutput("          Qty");
	rawoutput("        </td>");
	rawoutput("        <td>");
	output("          Description");
	rawoutput("        </td>");
	rawoutput("      </tr>");

  SeaendithasSmithe_TableItem("Normal Nuggets", "nuggets", "This is a base building item, requires at least 1", true);
  SeaendithasSmithe_TableItem("Silver Nuggets", "silvernuggets", "If used will up the chance of an exceptional item");
  SeaendithasSmithe_TableItem("Gold Nuggets", "goldnuggets", "If used will up the chance of an exceptional item");
  SeaendithasSmithe_TableItem("Attack Nuggets", "attacknuggets", "If used will up attack an item produces");
//  SeaendithasSmithe_TableItem("Defense Nuggets", "defensenuggets", "If used will up defense an item produces");

	rawoutput("      <tr>");
	rawoutput("        <td>");
	output("          Gold");
	rawoutput("        </td>");
	rawoutput("        <td>");
	rawoutput("          <input name=gold value=10000>");
	rawoutput("        </td>");
	rawoutput("        <td>");
	output("          My pay for building your item.  The higher the happier I am.");
	rawoutput("        </td>");
	rawoutput("      </tr>");

	rawoutput("      <tr>");
	rawoutput("        <td>");
	output("          Gems");
	rawoutput("        </td>");
	rawoutput("        <td>");
	rawoutput("          <input name=gems value=10>");
	rawoutput("        </td>");
	rawoutput("        <td>");
	output("          My pay for building your item.  The higher the happier I am.");
	rawoutput("        </td>");
	rawoutput("      </tr>");

	rawoutput("    </table>");
	rawoutput("<input type='hidden' name=itype value=weapon>");
	rawoutput("<input type='submit' class='button' value='Order'>");
	rawoutput("</form>");
	addnav("",$from."op=weapon&subop=order");
}

function SeaendithasSmithe_ShowBuildArmour()
{
	$from = "runmodule.php?module=SeaendithasSmithe&";

  output("You request a armour template.  Seaendithas enters the hut and soon returns ");
  output("with piece of paper.  He hands it to you stating \"This be the prices and requirements, fill in the form and give it to me when your done.\"`n");

  output("`n");
	rawoutput("<form action='".$from."op=weapon&subop=order' method='POST'>");

	rawoutput("    <table>");
	rawoutput("      <tr>");
	rawoutput("        <td>");
	output("          Item Type");
	rawoutput("        </td>");
	rawoutput("        <td>");
	output("          Qty");
	rawoutput("        </td>");
	rawoutput("        <td>");
	output("          Description");
	rawoutput("        </td>");
	rawoutput("      </tr>");

  SeaendithasSmithe_TableItem("Normal Nuggets", "nuggets", "This is a base building item, requires at least 1", true);
  SeaendithasSmithe_TableItem("Silver Nuggets", "silvernuggets", "If used will up the chance of an exceptional item");
  SeaendithasSmithe_TableItem("Gold Nuggets", "goldnuggets", "If used will up the chance of an exceptional item");
//  SeaendithasSmithe_TableItem("Attack Nuggets", "attacknuggets", "If used will up attack an item produces");
  SeaendithasSmithe_TableItem("Defense Nuggets", "defensenuggets", "If used will up defense an item produces");

	rawoutput("      <tr>");
	rawoutput("        <td>");
	output("          Gold");
	rawoutput("        </td>");
	rawoutput("        <td>");
	rawoutput("          <input name=gold value=10000>");
	rawoutput("        </td>");
	rawoutput("        <td>");
	output("          My pay for building your item.  The higher the happier I am.");
	rawoutput("        </td>");
	rawoutput("      </tr>");

	rawoutput("      <tr>");
	rawoutput("        <td>");
	output("          Gems");
	rawoutput("        </td>");
	rawoutput("        <td>");
	rawoutput("          <input name=gems value=10>");
	rawoutput("        </td>");
	rawoutput("        <td>");
	output("          My pay for building your item.  The higher the happier I am.");
	rawoutput("        </td>");
	rawoutput("      </tr>");

	rawoutput("    </table>");
	rawoutput("<input type='hidden' name=itype value=weapon>");
	rawoutput("<input type='submit' class='button' value='Order'>");
	rawoutput("</form>");
	addnav("",$from."op=weapon&subop=order");
}

function PlaceOrder($OrderType)
{
  $nuggets = $_POST['nuggets'];
  $silvernuggets = $_POST['silvernuggets'];
  $goldnuggets = $_POST['goldnuggets'];
  $attacknuggets = $_POST['attacknuggets'];
  $defensenuggets = $_POST['defensenuggets'];
  $gold = $_POST['gold'];
  $gems = $_POST['gems'];

	if (($nuggets>0)&&($gold>10000))
	{	
	  $chance = 10 + $goldnuggets + $silvernuggets + floor(($gold - 10000)/1000) + ceil($gems/20);
	  if ($chance > 100)
	    $chance = 90;
	  $attackbonus = $attacknuggets + $session['user']['attack'];
	  if (IsSet($session['user']['defense']))
	  {
	    $defensebonus = $defensenuggets + $session['user']['defense'];
	  }
	  else
	  {
	    $defensebonus = $defensenuggets + $session['user']['defence'];
	  }

		$exceptional = e_rand(1, 100) < $chance;
		
		$mod = "";
		if ($exceptional)
		{
		  $attackbonus += e_rand(1, $attackbonus + 5);
		  $defensebonus+= e_rand(1, $defensebonus + 5);
		  if ($attackbonus > get_module_pref("maxattack"))
		    $attackbonus = get_module_pref("maxattack");
		  if ($defensebonus > get_module_pref("maxdefense"))
		    $defensebonus = get_module_pref("maxdefense");
  		$mod = "Exceptional ";
		}
	  
	  switch($OrderType)
	  {
	    case "weapon":
	      $origname = $session['user']['weapon'];
	      $newname	= "Seaendithas ".$mod.$session['user']['weapon'];
	      $session['user']['weapon'] = $newname;
    	  $session['user']['attack'] = $attackbonus;
	      break;
	    case "armour":
	      $origname = $session['user']['armour'];
	      $newname	= "Seaendithas ".$mod.$session['user']['armour'];
	      $session['user']['armour'] = $newname;

			  if (IsSet($session['user']['defense']))
			  {
    	    $session['user']['defense'] = $defensebonus;
			  }
			  else
			  {
    	    $session['user']['defence'] = $defensebonus;
			  }

	      break;
	  }
		output("Seaendithas takes your %s and hands you back a %s.`n", $origname, $newname);
		output("`n\"You recived what you asked for, now be gone unless you have more business to conduct.\"`n");
		addnav("Weapon Template","runmodule.php?module=SeaendithasSmithe&op=weapon");
		addnav("Armour Template","runmodule.php?module=SeaendithasSmithe&op=armour");
	}
	else
	{
	  if ($nuggets>0)
	  {
	    output("I should expect such an offer.  Be gone, I'll do no work for you.  I do think I'll take 1/2 your offering for the insult.");
	    global $session;
	    $goldtaken = ceil($gold / 2);
	    if ($goldtaken > $session['user']['gold'])
	    {
	      $session['user']['gold'] = 0;
	    }
	    else
	    {
	      $session['user']['gold'] = $session['user']['gold'] - $goldtaken;
	    }
	  }
	  else
	  {
	    output("Try reading the form before you hand it back.  I care not for these annoiances.");
	  }
		require_once("lib/villagenav.php");
		villagenav();
	}
}

function SeaendithasSmithe_run()
{
	global $session;
	$op = httpget('op');
	$subop = httpget('subop');
	checkday();
  
  $smitheowner = "Seaendithas Falconsflight";

  page_header("Seaendithas the Smithe");
  global $session;
  switch ($op)
  {
    case "weapon":
        switch($subop)
        {
          case "order":
            if (strpos($session['user']['weapon'], "Seaendithas") === false)
            {
              PlaceOrder("weapon");
            }
            else
            {
              output("I can aid no more in the advancement of your weapon.  You may purchase a different item and bring it back if you wish.");
            }
            break;
          default:
            SeaendithasSmithe_ShowBuildWeapon();
						require_once("lib/villagenav.php");
						villagenav();
            break;
        }
      break;
    case "armour":
        switch($subop)
        {
          case "order":
            if (strpos($session['user']['armour'], "Seaendithas") === false)
            {
              PlaceOrder("armour");
            }
            else
            {
              output("I can aid no more in the advancement of your armour.  You may purchase a different item and bring it back if you wish.");
            }
            break;
          default:
        	  SeaendithasSmithe_ShowBuildArmour();
						require_once("lib/villagenav.php");
						villagenav();
            break;
        }
      break;
    default:
		  output("`0You walk up to a little hut with a rather large fire pit off to one side.  ");
		  output("In the pit you can see lots of little glowing pieces of metal.`n`n");
		  output("A rather large Dwarf covered in suite walks over to where you are standing.");
		  output("\"I be %s.  Given the right materials I can craft you a superior weapon or piece of armor.\"", $smitheowner);
		  output("`n`nYou currently have the following materials in your inventory:`n");
			if ($op=="")
			{
			  if (get_module_pref("nuggets") > 0)
			    output("`7You have %s normal nuggets.`n", get_module_pref("nuggets"));
			  if (get_module_pref("silvernuggets") > 0)
				  output("`0You have %s silver nuggets.`n", get_module_pref("silvernuggets"));
			  if (get_module_pref("goldnuggets") > 0)
				  output("`6You have %s gold nuggets.`n", get_module_pref("goldnuggets"));
			  if (get_module_pref("attacknuggets") > 0)
				  output("`4You have %s attack nuggets.`n", get_module_pref("attacknuggets"));
			  if (get_module_pref("defensenuggets") > 0)
				  output("`5You have %s defense nuggets.`n", get_module_pref("defensenuggets"));
			}
			output("`n`0In order to have Seaendithas build you an item select it from the list to the left.");
			require_once("lib/villagenav.php");
			addnav("Weapon Template","runmodule.php?module=SeaendithasSmithe&op=weapon");
			addnav("Armour Template","runmodule.php?module=SeaendithasSmithe&op=armour");
			villagenav();
	}
	page_footer();
}

function SeaendithasSmithe_dohook($hookname,$args){
	switch ($hookname) {
	case "village":
	  addnav("Market Street");
	  addnav("Seaendithas the Smithe", "runmodule.php?module=SeaendithasSmithe");
	  break;
	case "validatesettings":
		if ($args['normalnuggetchance'] + $args['silvernuggetchance'] + 
		    $args['goldnuggetchance'] + $args['attacknuggetchance'] + 
				$args['defensenuggetchance'] + $args['nonuggetchance'] <> 100) {
			$args['validation_error'] = "The chances of a drop must add up to 100.";
		}
		break;
	case "battle-victory":
	  $idropped  = e_rand(1, 100);
	  $nonug     = get_module_setting('nonuggetchance');
	  $silvnug   = get_module_setting('silvernuggetchance') + $nonug;
	  $normalnug = get_module_setting('normalnuggetchance') + $silvnug;
	  $goldnug   = get_module_setting('goldnuggetchance') + $normalnug;
	  $attnug    = get_module_setting('attacknuggetchance') + $goldnug;
	  $defnug    = get_module_setting('defensenuggetchance') + $attnug;
	  $badguyname= $args['creaturename'];
	  global $session;
	  if ($idropped < $nonug)
	  {
	  }
	  elseif ($idropped < $silvnug)
	  {
	    output("%s dropped a silver nugget.`n", $badguyname);
	    set_module_pref("silvernuggets",get_module_pref("silvernuggets")+1);
	  }
	  elseif ($idropped < $normalnug)
	  {
	    output("%s dropped a nugget.`n", $badguyname);
	    set_module_pref("nuggets",get_module_pref("nuggets")+1);
	  }
	  elseif ($idropped < $goldnug)
	  {
	    output("%s dropped a gold nugget.`n", $badguyname);
	    set_module_pref("goldnuggets",get_module_pref("goldnuggets")+1);
	  }
	  elseif ($idropped < $attnug)
	  {
	    output("%s dropped an enchanged attack nugget.`n", $badguyname);
	    set_module_pref("attacknuggets",get_module_pref("attacknuggets")+1);
	  }
	  else
	  {
	    output("%s dropped an enchanged defense nugget.`n", $badguyname);
	    set_module_pref("defensenuggets",get_module_pref("defensenuggets")+1);
	  }
	  break;
	}
	return $args;
}

?>
