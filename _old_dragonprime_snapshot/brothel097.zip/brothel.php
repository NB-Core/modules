<?php

//Created by Kallell for www.phofire.com/logd
//
//Special thanks to the Members of Dragon Prime
//version 0.9
//A Brothel which offers rewards at a cost along with the only
//way to get access to a certain specialty - case 10 - substituted with charm

require_once "common.php";
page_header("Ge'Mah's Relaxation Respite");
addnav("Go to Town Square","village.php");
if ($HTTP_GET_VARS[op]==""){
   addnav("Spend time With . . .");
   if ($session[user][sex]==0){ 
      addnav("Brandi","brothel.php?op=brandi");
      addnav("Alanna","brothel.php?op=alanna");
      addnav("Juliel","brothel.php?op=juliel");
      addnav("Elissa","brothel.php?op=elissa");
   }else{ 
      addnav("Vincent","brothel.php?op=vincent");
      addnav("Willaim","brothel.php?op=william");
      addnav("Edward","brothel.php?op=edward");
      addnav("Caramon","brothel.php?op=caramon");
   }
   output("`c`b `^Ge'Mah's Relaxation Respite`b`c");

   output("`2As you walk into a Large home behind thick foilage you are greeted by `5Ge'Mah, `2 an elf of incredible beauty. Behind her a number of Men and Woman bustle about. `5 Please come in and rest while one of my staff sees to your needs for only 2 gems`2 she says");


}else{
   if ($HTTP_GET_VARS[op]=="brandi"){
      output ("`%Brandi Leads you to a private room where you spend");
      output ("much time enraptured by her eyes, she coaxes many stories");
      output ("of your bravery from you. It's as if you could talk for");
      output ("hours, and you do! Eventually you know you have to leave");
      output ("but feel quite energized. You feel like a new man `n `n `6");

   }else if ($HTTP_GET_VARS[op]=="alanna"){
      output ("`%After being lead to an upstairs chamber, Alanna");
      output ("pours you a drink. The first sip makes you feel warm"); 
      output ("but not as warm as the first sip of her lips");
      output ("The world becomes a blurr in her arms, When you wake up");
      output ("she is gone. You are left feeling incredible `n `n `6");
      
   }else if ($HTTP_GET_VARS[op]=="juliel"){
      output ("`% You're not sure if it's a mere woman or and Angel that");
      output ("lead you to her private chambers. Her hands are extacy as");
      output ("she massages your tired muscles, her fingertips caress");
      output ("and excite your scars. Your body relaxes and eventually");
      output ("you fade off to sleep. She wakes you later and with a ");
      output ("sly smile says you have a forest to clean up. You have");
      output ("never felt better`n `n `6");

   }else if ($HTTP_GET_VARS[op]=="elissa"){
      output ("She gives you a coy smile then leads you to her private");
      output ("room. Upon closing the door however, the smile changes");
      output ("to something much different. she comes close while she bites");
      output ("and claws at your skin. The entire time you experience pain");
      output ("greater then any battle, yet sweeter. You leave not quite");
      output (" sure what has happened. But looking forward to it again`n `n `6");
    
   }else if ($HTTP_GET_VARS[op]=="vincent"){
      output ("`$The light of the setting sun shines into the window of one of");
      output ("the upstairs chambers. You study his muscular chest defined in"); 
      output ("the light and you cannot help yourself as you surrender to him."); 
      output ("You wake up feeling energized and ready to take on the world once");
      output ("more. `n `n `6");
     
   }else if ($HTTP_GET_VARS[op]=="william"){
      output ("`$You are led to a small yet ornate room by William who looks into your");
      output ("eyes until you it seems he can read your innermost thoughts. Although");
      output (" you are a fearless warrior who has seen many battles you feel"); 
      output ("vulnerable, yet at the same time you share your deepest secrets with");
      output ("him. You talk until daylight and before you leave, he takes your hand");
      output ("and kisses it and says the time he shared just chatting with you was");
      output ("just as good as any other woman he has been with. You leave feeling beautiful `n `n `6");      

   }else if ($HTTP_GET_VARS[op]=="edward"){
      output ("`$You are lying on satin sheets in one of the secluded boudoirs while");
      output ("Edward admires your body, worshiping you as if you were a goddess of"); 
      output ("some sort. You completely forget about the wounds you suffered that"); 
      output ("day as he whispers words of love and adoration. You engage in romance");
      output ("that leaves you happier than you've been in a long time.`n `n `6");
      
   }else if ($HTTP_GET_VARS[op]=="caramon"){
      output ("`$You ascend the stairs behind Caramon until you both come to a curtained");
      output ("off room. He sits you down on a pile of luxurious pillows and cushions."); 
      output ("He pulls out a piece of parchment and  begins to recite a sonnet. You are");               output ("immediately touched by his words. He folds the parchment away and in doing");
      output (" so he leans in and whispers that he wrote it long ago as a young lad,");
      output ("never knowing he'd actually find a woman that would fit the essence of the poem.`n `n `6");
      
     }
   
   //rewards for all the above
   switch(e_rand(1,10)){ 

      case 1:
      case 2:
      case 3:
      case 4:
      output("You now feel fully refreshed, ready to face the world. `n `n");
      output("`6 `bYou Gain 2 forest fights!`b");
      $session[user][turns]+=2;
      $session[user][gems]-=2;
      break;

      case 5:
      output("Your realize you have fallen asleep, upon gathering your articles your purse is a little light");
      output("`6 `bYou have been robbed!`b");
      $session[user][gems]=0;
      $session[user][gold]=0;
      break;

      case 6:
      case 7:
      case 8:      
      output("`6 `bIn your delightful mood you leave whistling a slight tune, you also arent watching where you are going and trip ofor something. looking down you find a small pouch with 500gold.`b");
      $session[user][gems]-=2;
      $session[user][gold]+=500;
      break;

      case 9:
      case 10:
      output("`6`b You feel proud and alive,  your absolutely glowing! You Gain 5 charm");
      //output("`6`b Your experience was enlightening, so enlighting you gain use point in a long forgotten art`b");
      $session[user][charm]+=5;
      //$session[user][gems]-=2;
      $session[user][gems]-=2;
   }
}
page_footer();
?>