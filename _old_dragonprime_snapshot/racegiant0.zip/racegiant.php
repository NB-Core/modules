<?php
/* Giant Race */
/* ver 1.0 */
/* Based on Races by Shannon Brown => SaucyWench -at- gmail -dot- com */
/* concept by JC Petersen */

function racegiant_getmoduleinfo(){
	$info = array(
		"name"=>"Race - Giant",
		"version"=>"1.0",
		"author"=>"Keith",
		"category"=>"Races",
		"download"=>"",
		"settings"=>array(
			"Giant Race Settings,title",
			"minedeathchance"=>"Percent chance for Giants to die in the mine,range,0,100,1|25",
			"gemchance"=>"Percent chance for Giants to find a gem on battle victory,range,0,100,1|10",
			"mindk"=>"How many DKs do you need before the race is available?,int|0",
		),
	);
	return $info;
}

function racegiant_install(){
	// The giants share the city with trolls, so..
	if (!is_module_installed("racetroll")) {
		output("The Giants only choose to live with Trolls.   You must install that race module.");
		return false;
	}

	module_addhook("chooserace");
	module_addhook("setrace");
	module_addhook("newday");
	module_addhook("charstats");
	module_addhook("raceminedeath");
	module_addhook("battle-victory");
	module_addhook("creatureencounter");
	module_addhook("pvpadjust");
	return true;
}

function racegiant_uninstall(){
	global $session;
	// Force anyone who was a Giant to rechoose race
	$sql = "UPDATE  " . db_prefix("accounts") . " SET race='" . RACE_UNKNOWN . "' WHERE race='Giant'";
	db_query($sql);
	if ($session['user']['race'] == 'Giant')
		$session['user']['race'] = RACE_UNKNOWN;
	return true;
}

function racegiant_dohook($hookname,$args){
	//yeah, the $resline thing is a hack.  Sorry, not sure of a better way
	//to handle this.
	// It could be passed as a hook arg?
	global $session,$resline;

	if (is_module_active("racetroll")) {
		$city = get_module_setting("villagename", "racetroll");
	} else {
		$city = getsetting("villagename", LOCATION_FIELDS);
	}
	$race = "Giant";
	switch($hookname){
	case "pvpadjust":
		if ($args['race'] == $race) {
			$args['creaturedefense']-=(1+floor($args['creaturelevel']/5));
			$args['creatureattack']-=(1+floor($args['creaturelevel']/5));
		}
		break;
	case "raceminedeath":
		if ($session['user']['race'] == $race) {
			$args['chance'] = get_module_setting("minedeathchance");
			$args['racesave'] = "Fortunately your gigantic strength lets you escape unscathed.`n";
			$args['schema']="module-racecat";
		}
		break;
	case "charstats":
		if ($session['user']['race']==$race){
			addcharstat("Vital Info");
			addcharstat("Race", translate_inline($race));
		}
		break;
	case "chooserace":
		if ($session['user']['dragonkills'] < get_module_setting("mindk"))
			break;
		output("<a href='newday.php?setrace=Giant$resline'>As a young child you never remember looking up to anyone.</a> You stood with your head as high as the trees for hourse watching the clouds go by. Never feeling totaly accepted you often spent most of your time allone wading in the river bed. You are one of the few remaining Giants in %s.`n`n",$city, true);
		addnav("`5Giant`0","newday.php?setrace=$race$resline");
		addnav("","newday.php?setrace=$race$resline");
		break;
	case "setrace":
		if ($session['user']['race']==$race){ // it helps if you capitalize correctly
			output("`&As a Giant, your size makes you much stronger, and can effortlessly wield weapons, but giants are aslo a little clumsy.`n");
			output("You gain extra attack!`n");
			output("You lose some defense!`n");
			if (is_module_active("cities")) {
				if ($session['user']['dragonkills']==0 &&
						$session['user']['age']==0){
					//new farmthing, set them to wandering around this city.
					set_module_setting("newest-$city",
							$session['user']['acctid'],"cities");
				}
				set_module_pref("homecity",$city,"cities");
				if ($session['user']['age'] == 0)
					$session['user']['location']=$city;
			}
		}
		break;
	case "newday":
		if ($session['user']['race']==$race){
			racecat_checkcity();
			$session['user']['turns']++;
			output("`n`&Because you are giant, you gain `^an extra`& forest fight for today!`n`0");
			apply_buff("racialbenefit",array(
				"name"=>"`@Giant Abilitys`0",
	 			"atkmod"=>"(<attack>?(1+((1+floor(<level>/5))/<attack>)):0)",
				"defmod"=>"(<defense>?(-1+((2+floor(<level>/5))/<defense>)):0)",
				"allowinpvp"=>1,
				"allowintrain"=>1,
				"rounds"=>-1,
				"schema"=>"module-racegiant",
				)
			);
		}
		break;
	}

	return $args;
}

function racegiant_checkcity(){
	global $session;
	$race="Giant";
	if (is_module_active("racehuman")) {
		$city = get_module_setting("villagename", "racehuman");
	} else {
		$city = getsetting("villagename", LOCATION_FIELDS);
	}
	
	if ($session['user']['race']==$race && is_module_active("cities")){
		//if they're this race and their home city isn't right, set it up.
		if (get_module_pref("homecity","cities")!=$city){ //home city is wrong
			set_module_pref("homecity",$city,"cities");
		}
	}	
	return true;
}

function racegiant_run(){
}
?>
