<?php

require_once ("lib/names.php");

function namechange_getmoduleinfo(){
        $info = array(
                "name"=>"User Rename",
                "version"=>"beta",
                "author"=>"`%H`La`vk`Lu`0/`%C`Lh`vi`Lc`%u`0, Big thanks to XChrisXs & Nightborns help and support",
                "category"=>"Lodge",
                "settings"=>array(
                    "User Rename - Settings,title",
                    "cost"=>"Wie viel DP's soll eine Umbenennung kosten?,int|1000",
                    "allowcolor"=>"Farben bei der Namens�nderung erlauben,bool|1",
                ),
                "prefs"=>array(
                    "tempnname"=>"Name der best�tigt werden muss,hidden|null",
                    "nocolorname"=>"Name der best�tigt werden muss (ohne Farbe),hidden|null",
                    "oldname"=>"Alter Name des Users,hidden|null",
                ),
        );
        return $info;
}

function namechange_install(){
	module_addhook("lodge");
	module_addhook("pointsdesc");
	return true;
}

function namechange_uninstall(){
	return true;
}

function namechange_dohook($hookname,$args){
	global $session;
	$preis = get_module_setting("cost","namechange");
	switch($hookname){
    case "pointsdesc":
		output("`7F�r den Preis von %s Punkten, kannst du deinen Namen �ndern.",$preis);
		break;
    case "lodge":
        addnav(array("Namen �ndern (%s Punkte)", $preis),"runmodule.php?module=namechange");
        break;
	}
	return $args;
}

function namechange_run(){
	global $session;
    $op = httpget("op");
    page_header();

   switch($op){
        case "";
            if($session['user']['donation']>=1000){
			rawoutput("<form action='runmodule.php?module=namechange&op=setname1' method='POST'>");
			output("Nun, ihr wollt einen neuen Namen?");
			output("So dann gebt ihn ein! Was auch immer dies zu bedeuten hat");
            output("BEIDES AUSF�LLEN!");
            if(get_module_setting("allowcolor")){
            output("`3`cNeuer Name(Farben erlaubt):");
			rawoutput("<input name='nname'>");
			output("`n`n");
            }
            $name = translate_inline("Best�tigen");
            output("`3`cNeuer Name(OHNE FARBEN!!):");
            rawoutput("<input name='nocolorname'>");
			output("`n`n");
			rawoutput("<input type='submit' class='button' value='$name'>");
			rawoutput("</form>");
			addnav("","runmodule.php?module=namechange&op=setname1");
            addnav("zur Lodge","lodge.php");
            }else{
            output("Du hast leider nicht genug Donationpunkte");
            addnav("Dorfplatz","village.php");
            }
			break;
            break;
		case "setname1";
            $eingabe==httppost('nocolorname');
            if ($eingabe==sanitize($eingabe)){
            output("Leider NUR ohne Farben");
            addnav("zur�ck","runmodule.php?module=namechange");
            }else{
            set_module_pref("oldname",$session['user']['name']);
            set_module_pref("tempnname",httppost('nname'));
            set_module_pref("nocolorname",httppost('nocolorname'));
			$nname = get_module_pref('tempnname');
			output("`3Sicher das du ab heute %s hei�en willst?",$nname);
			addnav("Entscheidung");
			addnav("Ja","runmodule.php?module=namechange&op=setname2");
			addnav("Nein","runmodule.php?module=namechange");
            }
  		    break;
		case "setname2";
            $tempnname ==get_module_pref('tempnname');
            $sql = "SELECT name FROM " . db_prefix("accounts") . " WHERE login='$tempnname'";
			$result = db_query($sql);
			if (db_num_rows($result)>0){
            output("Sorry, diesen Namen giebt es bereits!");
            addnav("Nochmal","runmodule.php?module=namechange&op=setname1");
            }else{
            $title1 = $session['user']['ctitle'];
            $title2 = $session['user']['title'];
            if(get_module_setting("allowcolor")){
            $newname = get_module_pref("tempnname");
            }else{
            $newname = get_module_pref("nocolorname");
            }
            $cost = get_module_setting("cost");
            if ($session['user']['ctitle']){
            $new = $session['user']['ctitle'] . " " . $newname;
            }else{
            $new = $session['user']['title'] . " " . $newname;
            }
            $session['user']['name']=$new;
		    $session['user']['login'] = get_module_pref("nocolorname");
            $session['user']['donationspent']+=$cost;
            output("`3Ab heute bist du als %s%s bekannt!",$session['user']['name'],$session['user']['ctitle']);
            output("`^ Und bewahre das du dich ab nun immer als %s einloggen MUSST!",$session['user']['login']);
            $oldname=get_module_pref("oldname");
            addnews("$oldname hat uns verlassen, hun giebt es einen neuen Krieger,sein Name ist $new");
            villagenav();
            }
			break;
	}
page_footer();
}
?>