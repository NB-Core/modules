Forest Labyrinth

Version 1.02
Written by RPGSL
Download: http://dragon.com/lotgd/forest_labyrinth.zip
Mirror: http://rpgsl.com/lotgd/forest_labyrinth.zip

Game: http://rpdragon.com/


Installation

1) Copy forest_labyrinth.php into your LotGD modules folder
2) Log in to LotGD with your admin account
3) Enter the Superuser Grotto
4) Click Manage Modules
5) Install forest_labyrinth.php (Forest Labrynth)
6) Configure settings and save
7) Activate


Questions/Comments?

alex@rpgsl.com


Visit www.rpgsl.com today for your RPG needs