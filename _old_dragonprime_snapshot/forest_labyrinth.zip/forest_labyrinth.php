<?php

function forest_labyrinth_getmoduleinfo()
{
	$info = array
	(
		"name"		=> "Forest Labyrinth",
		"version"	=> "1.02",
		"author"	=> "RPGSL and Joker",
		"category"	=> "RPGSL",
		"download"	=> "http://www.rpdragon.com/lotgd/forest_labyrinth.zip",
		"vertxtloc" => "http://www.rpdragon.com/",
		"description"=>"A Labyrinth found in the forest, which will reduce max hitpoints of characters if they have too much. You set the limit in the Module Manager.",
		"settings"	=> array
		(
			"Forest Labyrinth Settings,title",
			"maxhpperdk"		=> "What is the maximum amount of hit points per DK that is allowed?,int|20",
			"hpperlevel"		=> "How many hit points are added to the allowed amount per level?,int|10",
			"maxpercentlost"	=> "What is the maximum percentage of max HP (above the max allowed for their DK) lost?,int|25",
			"lostchance"		=> "What is chance the character will get lost if they have above the max hit points?,int|25",
			"dkzero"			=> "Allow characters with 0 DK to lose max hitpoints?,bool|0",
		),
	);
	return $info;
}

function forest_labyrinth_install()
{
	if (!is_module_installed("forest_labyrinth"))
	{
		output("Installing `bForest Labrynth`b (forest_labyrinth.php) module by Role Play Game Story Lines (www.rpgsl.com)`n`n");
	}
	else
	{
		output("Updating `bForest Labrynth`b (forest_labyrinth.php) module by Role Play Game Story Lines (www.rpgsl.com)`n`n");
	}
	module_addeventhook("forest", "return 85;");
	return true;
}

function forest_labyrinth_uninstall()
{
	output("Uninstalling `bForest Labrynth`b (forest_labyrinth.php) module by Role Play Game Story Lines (www.rpgsl.com)`n");
	return true;
}

function forest_labyrinth_dohook($hookname, $args)
{
	return $args;
}

function forest_labyrinth_runevent($type)
{
	global $session;
	$op = httpget('op');
	$from = "forest.php?";
	$session['user']['specialinc'] = "module:forest_labyrinth";
	if ($op == "" || $op == "search")
	{
		output("Exploring the murky forest you have become tangled in a web of thick roots, and vines. Spiders, evil fairies, and muppet-like goblins are seen looming through the thick forest.");
		output("As you turn to come back the way you came, you notice it is no longer there. You have entered a maze of sorts � a Labyrinth.`n`n");
		addnav("Run back the way you came", $from . "op=run");
	}
	elseif ($op == "run")
	{
		output("Turning you run back the way you came...");
		if ($session['user']['maxhitpoints'] > $session['user']['dragonkills'] * get_module_setting("maxhpperdk") + $session['user']['level'] * get_module_setting("hpperlevel"))
		{
			if (e_rand(1,100) <= get_module_setting("lostchance") && get_module_setting("dkzero"))
			{
				output("`n`nUnfortunately, you can�t find a way out of the forest. Every twist, and turn leads you back to the middle of the forest where you became lost.");
				$hploss = ceil(($session['user']['maxhitpoints'] - ($session['user']['dragonkills'] * get_module_setting("maxhpperdk") + $session['user']['level'] * get_module_setting("hpperlevel"))) * e_rand(1,get_module_setting("maxpercentlost")) / 100);
				$session['user']['maxhitpoints'] -= $hploss;
				$session['user']['hitpoints'] -= $hploss;
				output("`n`nYou trip over a vine in the Labyrinth, and fall forward busting your head on a sharp rock. You lose %s max hitpoints!!", $hploss);
				addnews("%s became lost in the Labyrinth and fell busting their head on a rock.", $session['user']['name']); 
				debuglog("lost $hploss max hit points when busting their head on a rock in the forest labyrinth.");
				$session['user']['specialinc']="";
				addnav("Continue", "forest.php");				
			}
			else
			{
				output("`n`nWalking through the Labyrinth near tears, and cold you encounter Haggerd who shows you the way out of the horrid maze.");
				$session['user']['specialinc']="";
				addnav("Continue", "forest.php");
			}
		}
		else
		{
			output("`n`nYou're lucky this time and manage to find your own way out of the Labyrinth. The Troll King would be proud.");
			$session['user']['specialinc']="";
			addnav("Continue", "forest.php");
		}
	}

//Below is added in case something funky happens with the $op variable.
	else
	{
		output("`n`nYou're lucky this time and manage to find your own way out of the Labyrinth. The Troll King would be proud.");
		$session['user']['specialinc']="";
		addnav("Continue", "forest.php");
	}
}

function forest_labyrinth_run()
{
}
?>