<?php
/*
Module Name:  treeguard.php
Category:  Village - Hooks into the Orchard
Worktitle:  Treeguard
Author:  DaveS
Date:  March 3, 2006

Requires:
Lumberyard (at least version 3.2)
The Orchard by Spider, Billie Kennedy (modified by Lonnyl)

Description:
The Lumberyard can cause a lot of destruction of the orchard trees. This module was a result of
a request by Capricorn.  Players can build a fence and/or hire a guard to protect their fruit
tree.  Both forms of protection wear out after a setting number of days and can be repurchased.
V3.1 Oops! Forgot to reset payments when you pay for the fence!
v3.5 Improved Integration with the Fruit Orchard XL
v3.51 extra turn deduction removed... thanks Kala!
v3.52 Oops! Forgot to reset payments when you pay for the fence (AGAIN... must've been lost somewhere)!
*/
require_once("lib/systemmail.php"); 
function treeguard_getmoduleinfo(){
    $info = array(
        "name"=>"Treeguard",
        "version"=>"3.52",
        "author"=>"DaveS",
        "category"=>"Village",
		"download"=>"http://dragonprime.net/index.php?module=Downloads;sa=dlview;id=148",
		"vertxtloc"=>"",
        "settings"=>array(
			"makefence"=>"Allow player to build a fence for additional protection?,bool|1",
			"fencegold"=>"How much does the fence cost to build in gold?,int|300",
			"fencewood"=>"If lumberyard installed how much wood do they need for the fence?,int|4",
			"fenceturn"=>"How many turns do they need to use to make the fence?,int|3",
			"fencetime"=>"How many new days will the fence last?,int|100",
			"treeguard"=>"Allow player to buy a guard for additional protection?,bool|1",
			"guardgold"=>"How much does it cost to hire a guard for their tree?,int|1000",
			"guardtime"=>"How many new days will the guard work for?,int|30",
        ),
        "prefs"=>array(
            "fgold"=>"How much gold have they put towards their fence?,int|0",
            "fwood"=>"How many squares of wood have they put towards their fence?,int|0",
            "fturn"=>"How many turns have they spent building the fence?,int|0",
            "ftime"=>"How many turns left for the fence to protect their tree?,int|0",
            "tguard"=>"How many turns left for the guard to protect their tree?,int|0",
        ),
		"requires"=>array(
			"lumberyard"=>"The Lumberyard by DaveS",
			"orchard"=>"Orchard by Spider, Billie Kennedy",
		),
    );
    return $info;
}
function treeguard_install(){
    module_addhook("newday");
    module_addhook("orchard-hollowtree");
	module_addhook("footer-runmodule");
    return true;
}
function treeguard_uninstall(){
    return true;
}
function treeguard_dohook($hookname,$args){
	global $session;
	switch($hookname){
	case "newday":
		if (get_module_pref("ftime")==1){
			$subj = sprintf("`^Orchard Notice from `!Elendir`^ about your Fence");
			$body = sprintf("`n`!Dear %s`!,`n`nUnfortunately your fence is no longer strong enough to protect your fruit tree.  Please stop by if you want to rebuild it.`n`nSincerely,`n`nElendir`n",$session['user']['name']);
			systemmail($session['user']['acctid'],$subj,$body);
			set_module_pref("ftime",0);
		}
		if (get_module_pref("tguard")==1){
			$subj = sprintf("`^Orchard Notice from `!Elendir`^ about your Guard");
			$body = sprintf("`n`!Dear %s`!,`n`nUnfortunately your guard is no longer protecting your fruit tree.  Please stop by if you want to hire another one.`n`nSincerely,`n`nElendir`n",$session['user']['name']);
			systemmail($session['user']['acctid'],$subj,$body);
			set_module_pref("tguard",0);
		}
		if (get_module_pref("ftime")>1) increment_module_pref("ftime",-1);
		if (get_module_pref("tguard")>1) increment_module_pref("tguard",-1);
	break;
	case "orchard-hollowtree":
		if (get_module_setting("version","orchard")==1 && get_module_pref("tree","orchard")>0) addnav("Fruit Tree Protection","runmodule.php?module=treeguard&op=enter");
	break;
	case "footer-runmodule":
		$module = httpget('module');
		$op=httpget('op');
		if ($module=='orchard' && $op=='hollowtree' && get_module_pref("tree","orchard")>0 && get_module_setting("version","orchard")==0){
			addnav("Fruit Tree Protection","runmodule.php?module=treeguard&op=enter");
		}
	break;
	}
	return $args;
}

function treeguard_run(){
	global $session;
	$op = httpget("op");
	page_header("Orchard Treeguard");
	blocknav("runmodule.php?module=treeguard&op=enter");
	$makefence=get_module_setting("makefence");
	$fencegold=get_module_setting("fencegold");
	if (is_module_active("lumberyard")) $fencewood=get_module_setting("fencewood");
	$fenceturn=get_module_setting("fenceturn");
	$fencetime=get_module_setting("fencetime");
	$treeguard=get_module_setting("treeguard");
	$guardgold=get_module_setting("guardgold");
	$guardtime=get_module_setting("guardtime");
	$makefence=get_module_setting("makefence");
	$treeguard=get_module_setting("treeguard");
    $fgold=get_module_pref("fgold");
    $fwood=get_module_pref("fwood");
    $fturn=get_module_pref("fturn");
    $ftime=get_module_pref("ftime");
    $tguard=get_module_pref("tguard");
    $fgleft=$fencegold-$fgold;
    $fwleft=$fencewood-$fwood;
    $ftleft=$fenceturn-$fturn;
    $ftimeleft=$fencetime-$ftime;
    $gtleft=$guardtime-$tguard;
	villagenav();	
	addnav("Return to the entrance","runmodule.php?module=orchard");
if ($op=="enter"){
	output("`!Elendir`0 explains the plan for helping protect your fruit tree:");
	if ($treeguard==1 && $makefence==1){
		output("`n`n`!'You can protect your tree with two different methods:'");
		output("`n`n`^1. Build a Fence");
		output("`n2.  Hire a Guard");
		output("`n`n`!'Which method would you like to learn more about?'");
	}
	if ($treeguard==1 && $makefence==0){
		output("`n`n`!'You can protect your tree by hiring a guard to protect it.");
		output("Would you like to learn more?'");
	}
	if ($treeguard==0 && $makefence==1){
		output("`n`n`!'You can protect your tree by building a fence to protect it.");
		output("Would you like to learn more?'");
	}
	if ($makefence==1){
		if ($ftime<=0) addnav("Discuss Building a Fence","runmodule.php?module=treeguard&op=fence");
		else addnav("Check on Your Fence","runmodule.php?module=treeguard&op=fencecheck");
	}
	if ($treeguard==1){
		if ($tguard<=0) addnav("Discuss Hiring a Guard","runmodule.php?module=treeguard&op=guard");
		else addnav("Check on Your Guard","runmodule.php?module=treeguard&op=guardcheck");
	}
}
if ($op=="guard"){
	output("`!'A guard will watch over your fruit tree and make it about 5 times less likely that some wayward lumberjack will accidentally chop down your tree.'");
	output("`n`nGuards can be expensive to hire, but they do an excellent job at guarding your tree.");
	output("Unfortunately, they do not stay at their post for very long.  Currently, a guard will protect your tree for `^%s game days`!.'",$guardtime);
	output("`n`n'You can always check back here to see how much longer your guard will stay at their post.'");
	output("`n`n'Currently, you need to pay `^%s gold`! to hire a guard.",$guardgold);
	output("Guards do not accept installment plans and therefore must be paid in full at the time of their hire.'");
	output("`n`n'Oh, and one last thing. You may have both a guard and a fence protecting your tree.'");
	if ($makefence==1){
		if ($ftime<=0) addnav("Discuss Building a Fence","runmodule.php?module=treeguard&op=fence");
		else addnav("Check on Your Fence","runmodule.php?module=treeguard&op=fencecheck");
	}
	addnav("Hire a Guard","runmodule.php?module=treeguard&op=hireguard");
}
if ($op=="hireguard"){
	$gold = $session['user']['gold'];
	if ($gold<$guardgold){
		output("`!'I'm sorry, but you don't have enough `^gold`! to hire a guard right now.  Please come back when you have more `^gold`!.'");
	}else{
		set_module_pref("tguard",get_module_setting("guardtime"));
		output("`!'Excellent. A guard will be posted to watch over your tree for `^%s days`!.'",$guardtime);
		output("You can always check back on your guard to see how more days of protection you have remaining.'");
		output("`n`n'I will send you a message by YoM when your tree is no longer guarded.'");
		$session['user']['gold']-=$guardgold;
		$tguard=get_module_setting("guardtime");
	}
	if ($makefence==1){
		if ($ftime<=0) addnav("Discuss Building a Fence","runmodule.php?module=treeguard&op=fence");
		else addnav("Check on Your Fence","runmodule.php?module=treeguard&op=fencecheck");
	}
}
if ($op=="guardcheck"){
	output("`!'Your guard will watch over your tree for `^%s days`! more.'",$tguard);
	output("`n`n'I will send you a message by YoM when your tree is no longer guarded.'");
	if ($makefence==1){
		if ($ftime<=0) addnav("Discuss Building a Fence","runmodule.php?module=treeguard&op=fence");
		else addnav("Check on Your Fence","runmodule.php?module=treeguard&op=fencecheck");
	}
}
if ($op=="fence"){
	output("`!'A fence will help protect your fruit tree and make it about 2 times less likely that some wayward lumberjack will accidentally chop down your tree.'");
	output("`n`n'Although a fence is kind of expensive to make, it will last quite a while.");
	output("With current technology, a new fence will last `^%s game days`!.",$fencetime);
	output("You can always check back here to see how much longer your fence will last once you finish it.'");
	if ($fgleft<=0 && $fwleft<=0 && $ftleft<=0) {
		output("`n`n'It looks like your fence is complete.'");
		addnav("Check over the Fence","runmodule.php?module=treeguard&op=finishfence");
		blocknav("village.php");	
		blocknav("runmodule.php?module=orchard");
	}else{
		if ($treeguard==1){
			if ($tguard<=0) addnav("Discuss Hiring a Guard","runmodule.php?module=treeguard&op=guard");
			else addnav("Check on Your Guard","runmodule.php?module=treeguard&op=guardcheck");
		}
		output("`n`n'Currently, you need the following to make a fence:'`n`n");
		if ($fgleft>0) output("`c`^%s Gold`c",$fgleft);
		if ($fwleft>0) output("`c`&%s Squares of Wood`c",$fwleft);
		if ($ftleft>0) output("`c`@%s Turns Building the Fence`c",$ftleft);
		output("`n`!'You may have both a guard and a fence protecting your tree.'");
		output("`n`n'Work and payment on your fence can be done in installments. Would you like to work on your fence?'");
	}
	if ($fgleft>0) addnav("Pay `^Gold","runmodule.php?module=treeguard&op=fgold");
	if ($fwleft>0) addnav("Pay `&Squares of Wood","runmodule.php?module=treeguard&op=fsquares");
	if ($ftleft>0) addnav("Work `@Turns","runmodule.php?module=treeguard&op=fturns");
}
if ($op=="fgold"){
	output("`!'You will have to pay `^%s gold`! to make the fence. How much would you like to pay?'",$fgleft);
	output("<form action='runmodule.php?module=treeguard&op=payoffgold' method='POST'><input name='goldp' id='goldp'><input type='submit' class='button' value='Pay Gold'></form>",true);
	addnav("","runmodule.php?module=treeguard&op=payoffgold");
	if ($treeguard==1){
		if ($tguard<=0) addnav("Discuss Hiring a Guard","runmodule.php?module=treeguard&op=guard");
		else addnav("Check on Your Guard","runmodule.php?module=treeguard&op=guardcheck");
	}
	if ($fwleft>0) addnav("Pay `&Squares of Wood","runmodule.php?module=treeguard&op=fsquares");
	if ($ftleft>0) addnav("Work `@Turns","runmodule.php?module=treeguard&op=fturns");
}
if ($op=="payoffgold"){
	$gold = httppost('goldp');
	$max = $session['user']['gold'];
	if ($gold < 0) $gold = 0;
	if ($gold >= $max) $gold = $max;
	if ($gold>$fgleft) {
		output("`!'Actually, I don't expect you to pay that much for the fence.");
		output("You only need to pay `^%s gold`!.'`n`n",$fgleft);
		$gold=$fgleft;
	}
	if ($gold>=$fgleft) {
		output("`0You hand over `^%s gold`0 and he counts it out carefully.",$fgleft);
		output("`n`n`!'Looks like that's enough `^gold`!.'");
	}elseif ($gold==0){
		output("`!'Actually, I meant that you have to give me gold, not air.'");
	}else{
		output("`0You hand over the `^%s gold`0 and he counts it out carefully.`n`n",$gold);
	}
	$session['user']['gold']-=$gold;
	increment_module_pref("fgold",$gold);
	$fgold=get_module_pref("fgold");
	$fgleft=$fencegold-$fgold;
	if ($fgleft>0){
		output("`!'You will need `^%s gold`! more before you're paid in full for gold.'",$fgleft);
	}
	$session['user']['gold']-=$gold;
	if ($fgleft<=0 && $fwleft<=0 && $ftleft<=0) {
		addnav("Check over the Fence","runmodule.php?module=treeguard&op=finishfence");
		blocknav("village.php");	
		blocknav("runmodule.php?module=orchard");
	}elseif ($treeguard==1){
		if ($tguard<=0) addnav("Discuss Hiring a Guard","runmodule.php?module=treeguard&op=guard");
		else addnav("Check on Your Guard","runmodule.php?module=treeguard&op=guardcheck");
	}
	if ($fgleft>0) addnav("Pay More `^Gold","runmodule.php?module=treeguard&op=fgold");
	if ($fwleft>0) addnav("Pay `&Squares of Wood","runmodule.php?module=treeguard&op=fsquares");
	if ($ftleft>0) addnav("Work `@Turns","runmodule.php?module=treeguard&op=fturns");
}
if ($op=="fsquares"){
	output("`!'You will have to spend `&%s squares of wood`! to make the fence. How many would you like to use?'",$fwleft);
	output("<form action='runmodule.php?module=treeguard&op=payoffsquares' method='POST'><input name='squarep' id='squarep'><input type='submit' class='button' value='Use Wood'></form>",true);
	addnav("","runmodule.php?module=treeguard&op=payoffsquares");
	if ($treeguard==1){
		if ($tguard<=0) addnav("Discuss Hiring a Guard","runmodule.php?module=treeguard&op=guard");
		else addnav("Check on Your Guard","runmodule.php?module=treeguard&op=guardcheck");
	}
	if ($fgleft>0) addnav("Pay `^Gold","runmodule.php?module=treeguard&op=fgold");
	if ($ftleft>0) addnav("Work `@Turns","runmodule.php?module=treeguard&op=fturns");
}
if ($op=="payoffsquares"){
	$squares = httppost('squarep');
	$max = get_module_pref("squares","lumberyard");
	if ($squares< 0) $squares= 0;
	if ($squares>= $max) $squares= $max;
	if ($squares>$fwleft) {
		output("`!'Actually, you don't need to use that much wood to make the fence.");
		output("You only need to use `&%s squares`!.'`n`n",$fwleft);
		$squares=$fwleft;
	}
	if ($squares>=$fwleft) {
		output("`0You give `!Elendir `&%s wood`0 for building the fence.",$fwleft);
		output("`n`n`!'Looks like that's enough `&wood`!.'");
	}elseif ($squares==0){
		output("`!'Actually, I meant that you have to give me wood, not air.'");
	}else{
		output("`0You give `!Elendir `&%s squares of wood`0.`n`n",$squares);
	}
	increment_module_pref("squares",-$squares,"lumberyard");
	increment_module_pref("fwood",$squares);
	$fwood=get_module_pref("fwood");
	$fwleft=$fencewood-$fwood;
	if ($fwleft>0){
		output("`!'You will need `&%s squares of wood`! more before you've got enough wood for the fence.'",$fwleft);
	}
	increment_module_pref("squares","lumberyard",-$squares);
	if ($fgleft<=0 && $fwleft<=0 && $ftleft<=0) {
		addnav("Check over the Fence","runmodule.php?module=treeguard&op=finishfence");
		blocknav("village.php");	
		blocknav("runmodule.php?module=orchard");
	}elseif ($treeguard==1){
		if ($tguard<=0) addnav("Discuss Hiring a Guard","runmodule.php?module=treeguard&op=guard");
		else addnav("Check on Your Guard","runmodule.php?module=treeguard&op=guardcheck");
	}
	if ($fwleft>0) addnav("Pay More `&Squares of Wood","runmodule.php?module=treeguard&op=fsquares");
	if ($fgleft>0) addnav("Pay `^Gold","runmodule.php?module=treeguard&op=fgold");
	if ($ftleft>0) addnav("Work `@Turns","runmodule.php?module=treeguard&op=fturns");
}
if ($op=="fturns"){
	output("`!'You will have to spend `@%s turns`! to make the fence. How many would you like to spend?'",$ftleft);
	output("<form action='runmodule.php?module=treeguard&op=payoffturns' method='POST'><input name='turnp' id='turnp'><input type='submit' class='button' value='Spend Turns'></form>",true);
	addnav("","runmodule.php?module=treeguard&op=payoffturns");
	if ($treeguard==1){
		if ($tguard<=0) addnav("Discuss Hiring a Guard","runmodule.php?module=treeguard&op=guard");
		else addnav("Check on Your Guard","runmodule.php?module=treeguard&op=guardcheck");
	}
	if ($fgleft>0) addnav("Pay `^Gold","runmodule.php?module=treeguard&op=fgold");
	if ($fwleft>0) addnav("Pay `&Squares of Wood","runmodule.php?module=treeguard&op=fsquares");
}
if ($op=="payoffturns"){
	$turns = httppost('turnp');
	$max = $session['user']['turns'];
	if ($turns < 0) $turns = 0;
	if ($turns >= $max) $turns = $max;
	if ($turns>$ftleft) {
		output("`!'Actually, you don't have to spend that much time on the fence.");
		output("You only need to pay spend `@%s turns`!.'`n`n",$fgleft);
		$turns=$ftleft;
	}
	if ($turns>=$ftleft) {
		output("`0You spend `@%s turns`0 working on the fence.",$ftleft);
		output("`n`n`!'That's enough `@turns`!.'");
	}elseif ($turns==0){
		output("`!'Actually, I meant that you have to spend time, not use up space.'");
	}else{
		output("`0You spend `@%s turns`0 working on the fence.",$turns);
	}
	$session['user']['turns']-=$turns;
	increment_module_pref("fturn",$turns);
	$fturn=get_module_pref("fturn");
	$ftleft=$fenceturn-$fturn;
	if ($ftleft>0){
		output("`!'You will need to spend `@%s turns`! more before finishing your work.'",$ftleft);
	}
	if ($fgleft<=0 && $fwleft<=0 && $ftleft<=0) {
		addnav("Check over the Fence","runmodule.php?module=treeguard&op=finishfence");
		blocknav("village.php");	
		blocknav("runmodule.php?module=orchard");
	}elseif ($treeguard==1){
		if ($tguard<=0) addnav("Discuss Hiring a Guard","runmodule.php?module=treeguard&op=guard");
		else addnav("Check on Your Guard","runmodule.php?module=treeguard&op=guardcheck");
	}
	if ($fgleft>0) addnav("Pay More `^Gold","runmodule.php?module=treeguard&op=fgold");
	if ($fwleft>0) addnav("Pay `&Squares of Wood","runmodule.php?module=treeguard&op=fsquares");
	if ($ftleft>0) addnav("Work `@Turns","runmodule.php?module=treeguard&op=fturns");
}
if ($op=="finishfence"){
	output("`!'Excellent work.  You're fence will last for `^%s days`!.",$fencetime);
	output("You can always check back on your fence to see how much longer it will last.'");
	output("`n`n'I will send you a message by YoM when your fence is no longer protecting your tree.'");
	set_module_pref("ftime",get_module_setting("fencetime"));
	$ftime=get_module_setting("fencetime");
	if ($treeguard==1){
		if ($tguard<=0) addnav("Discuss Hiring a Guard","runmodule.php?module=treeguard&op=guard");
		else addnav("Check on Your Guard","runmodule.php?module=treeguard&op=guardcheck");
	}
	set_module_pref("fgold",0);
	set_module_pref("fwood",0);
	set_module_pref("fturn",0);
}
if ($op=="fencecheck"){
	output("`!'Your fence will last for `^%s days`! more.'",$ftime);
	output("`n`n'I will send you a message by YoM when your fence is no longer protecting your tree.'");
	if ($treeguard==1){
		if ($tguard<=0) addnav("Discuss Hiring a Guard","runmodule.php?module=treeguard&op=guard");
		else addnav("Check on Your Guard","runmodule.php?module=treeguard&op=guardcheck");
	}
}
page_footer();
}
?>