<?php
function newday_getmoduleinfo(){
	$info = array(
		"name"=>"Allow Newday Purchasing",
		"author"=>"`%kickme`#<br />Coding correction by BansheeElhayn<br />`^Based on idea by Iscariot `0",
		"version"=>"1.0.2",
		"vertxtloc"=>"http://dragonprime.net/users/kickme/",
		"category"=>"Village",
		"download"=>"http://dragonprime.net/users/kickme/newday.zip",
		"settings"=>array(
			"Allow Newday Purchasing - Settings,title",
			"cost"=>"Base Cost of machine,int|1000"
		),
		"prefs"=>array(
			"Allow Newday Purchasing - Prefs,title",
			"allow"=>"Allow user to purchase Newdays?,bool|1",
		),
	);
	return $info;
}
function newday_install(){
	module_addhook("village");
	return true;
}
function newday_uninstall(){
	debug("Uninstalling module.");
	return true;
}
function newday_dohook($hookname, $args) {
	global $session;
	global $REQUEST_URI;
	$see = get_module_pref("allow");
	if($see == 1) {																								//corrects the bug for players
		if ($session['user']['dragonkills']==0) $gold=500 + $session['user']['level'] * 100;					//with NO dragonkills
		else {
			//to get a newday for free but less epensive like players with 1 DK and makes it more expensive for each level players get in
			$cost = get_module_setting("cost");
			$gold = $cost * $session['user']['dragonkills'] + $session['user']['level'] * 100;
		}
		if($gold < get_module_setting("cost")) $gold = get_module_setting("cost");
		switch($hookname){
		case "village":
			tlschema($args['schemas']['marketnav']);
			addnav($args["marketnav"]);
			tlschema();
			addnav(array("Newday machine (`^%s gold`0)",$gold),"runmodule.php?module=newday&gold=$gold");
			break;
		}
	}
	return $args;
}
function newday_run(){
	global $session;
	$gold = httpget("gold");
	page_header("Newday Machine");
	if($session['user']['gold'] < $gold) {
		output("`@You put `^%s gold`@ into the slot labeled \"`^GOLD`@\" and pull the lever.`nYou are surrounded by gas.`nYou fall asleep.`n",$session['user']['gold']);
		output("When you wake up, you find that all your gold and gems have been stolen!");
		$session['user']['gold'] = 0;
		$session['user']['gems'] = 0;
		$session['user']['hitpoints'] /= 2;
		addnav("Continue","village.php");
	} else {
		output("`@You put `^%s gold`@ into the slot labeled \"`^GOLD`@\" and pull the lever.`nYou are surrounded by gas.`nYou fall asleep.`n",$gold);
		output("When you wake up, you find that it is a new day");
		$session['user']['gold'] -= $gold;
		addnav("Continue","newday.php");
	}
	page_footer();
}	
?>