<?php

/*
 * Title:       Recent Players List
 * Date:	Sep 06, 2004
 * Version:	1.2
 * Author:      Joshua Ecklund
 * Email:       m.prowler@cox.net
 * Purpose:     Add a list of most recent players to the village and
 *              login screen, listing various information about each user.
 *
 * --Change Log--
 *
 * Date:    	Aug 01, 2004
 * Version:	1.0
 * Purpose:     Initial Release
 *
 * Date:    	Aug 02, 2004
 * Version:	1.1
 * Purpose:     Translation tool features added/fixed
 *
 * Date:        Sep 06, 2004
 * Version:     1.2
 * Purpose:     Various changes, updated to use datetime.php, added
 *              new hook to add link to player listing.
 *
 */

require_once("lib/http.php");
require_once("lib/datetime.php");
require_once("lib/villagenav.php");

function recentplayers_getmoduleinfo(){
	$info = array(
		"name"=>"Recent Players List",
		"version"=>"1.2",
		"author"=>"Joshua Ecklund",
		"category"=>"Village",
                "download"=>"http://dragonprime.net/users/mProwler/recentplayers.zip",
                "allowanonymous"=>"1",
		"settings"=>array(
			"Recent Players List Settings,title",
                        "howmany"=>"How many players on list?,range,0,25,1|10",
                        "showalive"=>"Show whether players are alive?,bool|0",
                        "showadmin"=>"Show super-users on list?,bool|1",
                )
	);
	return $info;
}

function recentplayers_install() {
        module_addhook("village");
        module_addhook("index");
        module_addhook("footer-list");
        return(true);
}

function recentplayers_uninstall(){
	return(true);
}

function recentplayers_dohook($hookname, $args){
	if ($hookname=="village") {
                addnav("Info");
                addnav(".?Most Recent Players","runmodule.php?module=recentplayers");
        } elseif ($hookname=="index") {
                addnav("Game Functions");
                addnav("Most Recent Players","runmodule.php?module=recentplayers");
        } elseif ($hookname=="footer-list") {
                addnav("");
                addnav("Most Recent Players","runmodule.php?module=recentplayers");
        }

        return($args);
}

function recentplayers_run(){
	global $session;

        $howmany = get_module_setting("howmany");
        $showalive = get_module_setting("showalive");

        if (!get_module_setting("showadmin")) $extra = " AND superuser=0";
        else $extra = "";

        $sql = "SELECT name,login,race,sex,level,laston,lasthit,loggedin,alive FROM " . db_prefix("accounts") . " WHERE locked=0 $extra ORDER BY laston DESC, loggedin DESC LIMIT 0,$howmany";
	$result = db_query($sql);
        $max = db_num_rows($result);

        page_header("Most Recent Players");
	output("`c`bMost Recent Players `b`n`n");
	rawoutput("<table border=0 cellpadding=2 cellspacing=1 bgcolor='#999999'>");

        if ($showalive) $alive = "<td>" . translate_inline("Alive") . "</td>";
        else $alive = "";

        if ($session['user']['superuser']) $extra = "<td>" . translate_inline("Last Hit") . "</td>";
        else $extra = "";

        $num = translate_inline("Num");
        $name = translate_inline("Name");
        $level = translate_inline("Level");
        $race = translate_inline("Race");
        $sex = translate_inline("Sex");
        $laston = translate_inline("Last On");

	rawoutput("<tr class='trhead'><td>$num</td><td>$name</td><td>$level</td><td>$race</td><td>$sex</td>$alive<td>$laston</td>$extra</tr>");

        for($i=0;$i<$max;$i++){
		$row = db_fetch_assoc($result);
	        rawoutput("<tr class='".($i%2?"trdark":"trlight")."'><td>");

                output($i+1);
                rawoutput("</td><td>");

                if ($session['user']['loggedin']) {
                        $writemail = translate_inline("Write Mail");
                 	rawoutput("<a href=\"mail.php?op=write&to=".rawurlencode($row['login'])."\" target=\"_blank\" onClick=\"".popup("mail.php?op=write&to=".rawurlencode($row['login'])."").";return false;\"><img src='images/newscroll.GIF' width='16' height='16' alt='$writemail' border='0'></a>");
			rawoutput("<a href='bio.php?char=".rawurlencode($row['login'])."'>");
			addnav("","bio.php?char=".rawurlencode($row['login'])."");
                }

                $timedout = !($row['laston'] > date("Y-m-d H:i:s",strtotime("-".getsetting("LOGINTIMEOUT",900)." seconds")));
                if ($row['loggedin'] && !$timedout) $laston = "`bNow`b";
                else $laston = relativedate($row['laston']);

		output("`&{$row['name']}`0");
		if ($session['user']['loggedin']) rawoutput("</a>");
	        rawoutput("</td><td>");
                output_notl("`^{$row['level']}`0");
		rawoutput("</td><td>");
		output($row['race']);
		rawoutput("</td><td>");
		output($row['sex']?"`%F`0":"`!M`0");
		rawoutput("</td><td>");

                if ($showalive) {
	                $alive = translate_inline($row['alive']?"`1Yes`0":"`4No`0") . "</td><td>";
                	rawoutput($alive);
                }

                output($laston);

                if ($session['user']['superuser']) {
		        rawoutput("</td><td>");
                        $lasthit = strtotime($row['laston']);
                        $lasthit = reltime($lasthit,true);
                        output("$lasthit ago");
                }

		rawoutput("</td></tr>");
        }

	rawoutput("</table>");
	output("`c");
	if ($session['user']['loggedin']) {
		if ($session['user']['alive']) {
			villagenav();
		} else {
			addnav("Return to the graveyard", "graveyard.php");
		}
	} else {
		addnav("Login Screen","index.php");
        }

      	addnav("Currently Online","list.php");
        addnav("Refresh","runmodule.php?module=recentplayers");

	page_footer();
}

?>
