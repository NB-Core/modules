<?php
/*******************************************
/ gnomogemme.php - The Gem's Gnome V1.0
/ Originally by Excalibur (www.ogsi.it)
/ 14 October 2004

----install-instructions--------------------
DIFFICULTY SCALE: extremely easy

Forest Event originally for LotGD 0.9.7
Conversion for 0.9.8
--------------------------------------------
Version History:
Ver. 1.0 created by Excalibur (www.ogsi.it)
Original Version posted to DragonPrime
********************************************
Originally by: Excalibur
English clean-up:XChrisX
31 October 2004
*/
function gnomogemme_getmoduleinfo() {
    $info = array(
        "name"=>"Gem's Gnome",
        "version"=>"1.10",
        "author"=>"`@Excalibur",
        "category"=>"Forest Specials",
        "download"=>"http://dragonprime.net/users/Excalibur/gnomogemme098.zip",
        "settings"=>array(
            "Gem's Gnome Settings,title",
            "basegemgnome"=>"Minumum number of gems owned by gnome,int|50",
            "basedice"=>"lower number of dice's faces,int|6",
        ),
    );
    return $info;
}
function gnomogemme_install() {
    module_addeventhook("forest", "return 100;");
    return true;
}

function gnomogemme_uninstall() {
    return true;
}

function gnomogemme_dohook($hookname,$args){
    return $args;
}

function gnomogemme_runevent($type) {
   global $session;
   $basegemgnome = get_module_setting('basegemgnome');
   $basedice = get_module_setting('basedice');
   $gnomogemme = get_module_setting('gnomogemme');
   if ($gnomogemme < $basegemgnome) {
      set_module_setting('gnomogemme',$basegemgnome);
      $gnomogemme = $basegemgnome;
   }
   page_header("The Gnome of Gems");
   output("`c<font size='+2'>`%The Gnome of Gems</font>`c`n`n",true);
   srand ((double) microtime() * 10000000);
   $op = httpget('op');
   if ($op=="") {
      $session['gemwin'] = 0;
      $session['gemtopay'] = 0;
      output("`2Wandering through the forest you meet a gnome that is looking at you with a clever gaze from high above a rock.`n");
      output("Tied to his belt you notice a bag full of precious gems.`n");
      output("Your eyes glare at seeing all those gems  and some spittle drops from the sides of your mouth.`n");
      output("The gnome, noticing your greediness, jumps off the rock and magically takes a table from nowhere, ");
      output("placing it in front of you, and shows you a series of dice that differ from 6 faces dice and says to you: `n");
      output("\"`#Aye, hello mi young uarrior, I've noticed you gaze when ya sin mi prescious gems, ");
      output("and I want too give ya the chance to ya to win a rilly biggest amount.`2\"`n`n");
      addnav("`@Continue","forest.php?op=goon");
      addnav("`\$Nah, not interested","forest.php?op=leave");
      $session['user']['specialinc']="module:gnomogemme";
   }else if ($op=="leave") {
      output("`5You wont waste your time, so you tell the gnome it's a long time since you last believed in fairy-tales. ");
      output("You leave him behind going back to the forest, ");
      output("knowing that you've lost a forest fight listening to gnome's tale.`n");
      $session['user']['turns'] -= 1;
      $session['user']['specialinc']="";
      addnav("Return to forest","forest.php");
   }else if ($op=="goon") {
      output("`2The small gnome continues: `n\"`#Ach well, ya be a mighty warrior for sure !! ");
      output("I rilly admire ya. The game is simple much, I have a series of dice much very special. ");
      output("They have from %s to %s faces. Ya begin with the %s faces dice, then ya continue with ",$basedice,($basedice+5),$basedice);
      output("%s faces dice in the following turn and again then with one more face to conclude with ty %s faces dice.`n",($basedice+1),($basedice+5));
      output("Before to roll my dice you have to give me a nice gem, you choose a number and if after the drop your number equal to ");
      output("dice number ya multiply the stake by three but if your number is adjacent to dice's number ya double it, else I win ");
      output("and yooo lose hihihihi.`2\"`n`n");
      output("The gnome take a pause and then again starts to talk before you can do or say anything: `n\"`#");
      output("Forgetting I was, the first 2 rolls are mandatory, ya do not withdraw. After roll following ya can ");
      output("decide to continue or to stop. I don't give ya gems immediatly, I put gems in a stake and ya can see in lower ");
      output("right corner gems I have in my bag and gems ya win if ya stop after two rolls.`n");
      output("Verrry importantest thing I can't give ya more gems then I have in my bag, even if ya should win more. `n");
      output("If ya lose you can ter ... ryt ... retry again and test your luck more times, but for each more try my cost will ");
      output("increase by one gem.`2\"`n`n");
      output("`^What do ya wanna do?");
      addnav("`@I wanna play","forest.php?op=anothergem");
      addnav("`\$Nah, I'm not interested","forest.php?op=exit");
      $session['user']['specialinc']="module:gnomogemme";
   }else if ($op=="anothergem") {
      $session['gemtopay'] +=1;
      if ($session['user']['gems'] < $session['gemtopay']){
         output("`2\"`#Ya don't have no more gems, you don't breil up me ! I small gnome but big brain!`2\"`n");
         output("Saying this he cast a spell on you and run away like a lightning into the forest!!`n");
         $loseturn = e_rand(2,4);
         if ($loseturn > $session['user']['turns']) $loseturns = $session['user']['turns'];
         $session['user']['turns'] -= $loseturn;
         output("You feel weak and you realize you've lost %s forest fights because of the spell.",$loseturn);
         $session['user']['specialinc']="";
         addnav("Back to Forest","forest.php");
      }else{
         $session['user']['gems'] -= $session['gemtopay'];
         debuglog("pay {$session['gemtopay']} gems to play with the gnome");
         $newgem = get_module_setting('gnomogemme') + $session['gemtopay'];
         set_module_setting('gnomogemme',$newgem);
         output("`2The gnome's eyes laugh looking the gems and he tells: `n\"`#Well-well-well, begin the game we do. Take ");
         output("this %s faces dice, you choose lucky number before.`2\".`n",$basedice);
         $session['user']['specialinc']="module:gnomogemme";
         addnav(array("Choose number between 1 - %s",$basedice),"forest.php?op=number6");
      }
// First try with 6 faces dice
   }else if ($op=="number6") {
      output("`2Write in the box your guess, choose a number between 1 - %s`n",$basedice);
      $choosenum = translate_inline("Choose Number");
      rawoutput("<form action='forest.php?op=number6bis' method='POST'><input name='number' value='0'><input type='submit' class='button' value='$choosenumber'>");
      //output("<form action='forest.php?op=number6bis' method='POST'><input name='number' value='0'><input type='submit' class='button' value='Choose Number'>`n",true);
      $session['user']['specialinc']="module:gnomogemme";
      addnav("","forest.php?op=number6bis");
   }else if ($op=="number6bis") {
      $number = httppost('number');
      if ($number < 1 OR $number > $basedice){
         output("`2The gnome looks angrily at you and say \"`#Number between 1 and %s choose ya must. Ya choosen `b`%%s`b`# that is wrong number!`2\"`n",$basedice,$number);
         $session['user']['specialinc']="module:gnomogemme";
         addnav(array("Choose number between 1 - %s",$basedice),"forest.php?op=number6");
      }else{
         output("`2\"`#Choosen ya had `b`%%s`b`#, now ya roll the dice and we see if won ya have.`2\"`n`n",$number);
         $match = rand(1,$basedice);
         dot($match);
         output("`6The dice stop his run and shows the number `\$%s `6on the upper face.`n`n",$match);
         if ($match == $number) {
            $session['gemwin'] += 3;
            output("`\$Arghhh !! `#Won you have. I give ya %s gems you have won, but you must do another round mandatory, only after retire you can.`n",$session['gemwin']);
            $session['user']['specialinc']="module:gnomogemme";
            addnav(array("Choose number between 1 - %s",($basedice+1)),"forest.php?op=number7");
         }else if (($number-1) == $match OR ($number+1) == $match) {
            $session['gemwin'] += 2;
            output("`\$Arghhh !! `#Your number is adjacent to dice's number. I give ya %s you won have, but you must do another round mandatory, only after retire you can.`n",$session['gemwin']);
            $session['user']['specialinc']="module:gnomogemme";
            addnav(array("Choose number between 1 - %s",($basedice+1)),"forest.php?op=number7");
         }else {
            output("`#Eh eh eh, lose you have! I give ya another possibility if ya wanna try again, or ya can go back to forest if ya hate game! Ya must give me `b`^%s gems`b`# to try luck again.`n`n",($session['gemtopay']+1));
            output("`2What do ya wanna do?`n");
            $session['gemwin'] = 0;
            $session['user']['specialinc']="module:gnomogemme";
            addnav("Let me try again","forest.php?op=anothergem");
            addnav("You're a cheater, I leave!","forest.php?op=exit");
         }
      }
//Second try with 7 faces dice
   }else if ($op=="number7") {
      output("`2Write in the box your guess, choose a number between 1 - %s`n",($basedice+1));
      $choosenum = translate_inline("Choose Number");
      rawoutput("<form action='forest.php?op=number7bis' method='POST'><input name='number' value='0'><input type='submit' class='button' value='$choosenumber'>");
      //output("<form action='forest.php?op=number7bis' method='POST'><input name='number' value='0'><input type='submit' class='button' value='Choose Number'>`n",true);
      $session['user']['specialinc']="module:gnomogemme";
      addnav("","forest.php?op=number7bis");
   }else if ($op=="number7bis") {
      $number = httppost('number');
      if ($number < 1 OR $number > ($basedice+1)){
         output("`2The gnome looks angrily at you and says \"`#Number between 1 and %s choose ya must. Ya choosen `b`%%s`b`# that is wrong number!`2\"`n",($basedice+1),$number);
         $session['user']['specialinc']="module:gnomogemme";
         addnav(array("Choose number between 1 - %s",($basedice+1)),"forest.php?op=number7");
      }else{
         output("`2\"`#Choosen ya had `b`%%s`b`#, now ya roll the dice and we see if won ya have.`2\"`n`n",$number);
         $match = rand(1,($basedice+1));
         dot($match);
         output("`6The dice stops his run and shows the number `\$%s `6on the upper face.`n`n",$match);
         if ($match == $number) {
            $session['gemwin'] *= 3;
            output("`\$Arghhh !! `#Won you have. I give ya %s you won have, if ya want you can continue to play or retire from game and grab the gems ya won.`n",$session['gemwin']);
            $session['user']['specialinc']="module:gnomogemme";
            addnav("I retire, I've won enough","forest.php?op=exit");
            addnav("I feel lucky, go on","forest.php?op=number8");
         }else if (($number-1) == $match OR ($number+1) == $match) {
            $session['gemwin'] *= 2;
            output("`\$Arghhh !! `#Your number is adjacent to dice's number. I give ya %s you won have, if ya want you can continue to play or retire from game and grab the gems ya won.`n",$session['gemwin']);
            $session['user']['specialinc']="module:gnomogemme";
            addnav("I retire, I've won enough","forest.php?op=exit");
            addnav("I feel lucky, go on","forest.php?op=number8");
         }else {
            output("`#Eh eh eh, lose you have! I give ya another possibility if ya wanna try again, or ya can go back to forest if ya hate game! Ya must give me `b`^%s gems`b`# to try luck again.`n`n",($session['gemtopay']+1));
            output("`2What do ya wanna do?`n");
            $session['gemwin'] = 0;
            $session['user']['specialinc']="module:gnomogemme";
            addnav("Let me try again","forest.php?op=anothergem");
            addnav("You're a cheater, I leave!","forest.php?op=exit");
         }
      }
//Third try with 8 faces dice
   }else if ($op=="number8") {
         output("`2Write in the box your guess, choose a number between 1 and %s`n",($basedice+2));
         $choosenum = translate_inline("Choose Number");
         rawoutput("<form action='forest.php?op=number8bis' method='POST'><input name='number' value='0'><input type='submit' class='button' value='$choosenumber'>");
         //output("<form action='forest.php?op=number8bis' method='POST'><input name='number' value='0'><input type='submit' class='button' value='Choose Number'>`n",true);
         $session['user']['specialinc']="module:gnomogemme";
         addnav("","forest.php?op=number8bis");
   }else if ($op=="number8bis") {
      $number = httppost('number');
      if ($number < 1 OR $number > ($basedice+2)){
         output("`2`2The gnome looks angrily at you and says \"`#Number between 1 and %s choose ya must. Ya choosen `b`%%s`b`# that is wrong number!`2\"`n",($basedice+2),$number);
         $session['user']['specialinc']="module:gnomogemme";
         addnav(array("Choose number between 1 - %s",($basedice+2)),"forest.php?op=number8");
      }else{
         output("`2\"`#Choosen ya had `b`%%s`b`#, now ya roll the dice and we see if won ya have.`2\"`n`n",$number);
         $match = rand(1,($basedice+2));
         dot($match);
         output("`6The dice stops his run and shows the number `\$%s `6on the upper face.`n`n",$match);
         if ($match == $number) {
            $session['gemwin'] *= 3;
            output("`\$Arghhh !! `#Won you have. I give ya %s you won have, if ya want you can continue to play or retire from game and grab the gems ya won.`n",$session['gemwin']);
            $session['user']['specialinc']="module:gnomogemme";
            addnav("I retire, I've won enough","forest.php?op=exit");
            addnav("I feel lucky, go on","forest.php?op=number9");
         }else if (($number-1) == $match OR ($number+1) == $match) {
            $session['gemwin'] *= 2;
            output("`\$Arghhh !! `#Your number is adjacent to dice's number. I give ya %s you won have, if ya want you can continue to play or retire from game and grab the gems ya won.`n",$session['gemwin']);
            $session['user']['specialinc']="module:gnomogemme";
            addnav("I retire, I've won enough","forest.php?op=exit");
            addnav("I feel lucky, go on","forest.php?op=number9");
         }else {
            output("`#Eh eh eh, lose you have! I give ya another possibility if ya wanna try again, or ya can go back to forest if ya hate game! Ya must give me `b`^%s gems`b`# to try luck again.`n`n",($session['gemtopay']+1));
            output("`2What do ya wanna do?`n");
            $session['gemwin'] = 0;
            $session['user']['specialinc']="module:gnomogemme";
            addnav("Let me try again","forest.php?op=anothergem");
            addnav("You're a cheater, I leave!","forest.php?op=exit");
         }
      }
//Forth try with 9 faces dice
   }else if ($op=="number9") {
      output("`2Write in the box your guess, choose a number between 1 and %s`n",($basedice+3));
      $choosenum = translate_inline("Choose Number");
      rawoutput("<form action='forest.php?op=number9bis' method='POST'><input name='number' value='0'><input type='submit' class='button' value='$choosenumber'>");
      //output("<form action='forest.php?op=number9bis' method='POST'><input name='number' value='0'><input type='submit' class='button' value='Choose Number'>`n",true);
      $session['user']['specialinc']="module:gnomogemme";
      addnav("","forest.php?op=number9bis");
   }else if ($op=="number9bis") {
      $number = httppost('number');
      if ($number < 1 OR $number > ($basedice+3)){
         output("`2`2The gnome looks angrily at you and says \"`#Number between 1 and %s choose ya must. Ya choosen `b`%%s`b`# that is wrong number!`2\"`n",($basedice+3),$number);
         $session['user']['specialinc']="module:gnomogemme";
         addnav(array("Choose number between 1 - %s",($basedice+3)),"forest.php?op=number9");
      }else{
         output("`2\"`#Choosen ya had `b`%%s`b`#, now ya roll the dice and we see if won ya have.`2\"`n`n",$number);
         $match = rand(1,($basedice+3));
         dot($match);
         output("`6The dice stops his run and shows the number `\$%s `6on the upper face.`n`n",$match);
         if ($match == $number) {
            $session['gemwin'] *= 3;
            output("`\$Arghhh !! `#Won you have. I give ya %s you won have, if ya want you can continue to play or retire from game and grab the gems ya won.`n",$session['gemwin']);
            $session['user']['specialinc']="module:gnomogemme";
            addnav("I retire, I've won enough","forest.php?op=exit");
            addnav("I feel lucky, go on","forest.php?op=number10");
         }else if (($number-1) == $match OR ($number+1) == $match) {
            $session['gemwin'] *= 2;
            output("`\$Arghhh !! `#Your number is adjacent to dice's number. I give ya %s you won have, if ya want you can continue to play or retire from game and grab the gems ya won.`n",$session['gemwin']);
            $session['user']['specialinc']="module:gnomogemme";
            addnav("I retire, I've won enough","forest.php?op=exit");
            addnav("I feel lucky, go on","forest.php?op=number10");
         }else {
            output("`#Eh eh eh, lose you have! I give ya another possibility if ya wanna try again, or ya can go back to forest if ya hate game! Ya must give me `b`^%s gems`b`# to try luck again.`n`n",($session['gemtopay']+1));
            output("`2What do ya wanna do?`n");
            $session['gemwin'] = 0;
            $session['user']['specialinc']="module:gnomogemme";
            addnav("Let me try again","forest.php?op=anothergem");
            addnav("You're a cheater, I leave!","forest.php?op=exit");
         }
      }
//Fifth try with 10 faces dice
   }else if ($op=="number10") {
         output("`2Write in the box your guess, choose a number between 1 and %s`n",($basedice+4));
         $choosenum = translate_inline("Choose Number");
         rawoutput("<form action='forest.php?op=number10bis' method='POST'><input name='number' value='0'><input type='submit' class='button' value='$choosenumber'>");
         //output("<form action='forest.php?op=number10bis' method='POST'><input name='number' value='0'><input type='submit' class='button' value='Choose Number'>`n",true);
         $session['user']['specialinc']="module:gnomogemme";
         addnav("","forest.php?op=number10bis");
   }else if ($op=="number10bis") {
      $number = httppost('number');
      if ($number < 1 OR $number > ($basedice+4)){
         output("`2`2The gnome looks angrily at you and says \"`#Number between 1 and %s choose ya must. Ya choosen `b`%%s`b`# that is wrong number!`2\"`n",($basedice+4),$number);
         $session['user']['specialinc']="module:gnomogemme";
         addnav(array("Choose number between 1 - %s",($basedice+4)),"forest.php?op=number10");
      }else{
         output("`2\"`#Choosen ya had `b`%%s`b`#, now ya roll the dice and we see if won ya have.`2\"`n`n",$number);
         $match = rand(1,($basedice+4));
         dot($match);
         output("`6The dice stop his run and shows the number `\$%s `6on the upper face.`n`n",$match);
         if ($match == $number) {
            $session['gemwin'] *= 3;
            output("`\$Arghhh !! `#Won you have. I give ya %s you won have, if ya want you can continue to play or retire from game and grab the gems ya won.`n",$session['gemwin']);
            $session['user']['specialinc']="module:gnomogemme";
            addnav("I retire, I've won enough","forest.php?op=exit");
            addnav("I feel lucky, go on","forest.php?op=number11");
         }else if (($number-1) == $match OR ($number+1) == $match) {
            $session['gemwin'] *= 2;
            output("`\$Arghhh !! `#Your number is adjacent to dice's number. I give ya %s you won have, if ya want you can continue to play or retire from game and grab the gems ya won.`n",$session['gemwin']);
            $session['user']['specialinc']="module:gnomogemme";
            addnav("I retire, I've won enough","forest.php?op=exit");
            addnav("I feel lucky, go on","forest.php?op=number11");
         }else {
            output("`#Eh eh eh, lose you have! I give ya another possibility if ya wanna try again, or ya can go back to forest if ya hate game! Ya must give me `b`^%s gems`b`# to try luck again.`n`n",($session['gemtopay']+1));
            output("`2What do ya wanna do?`n");
            $session['gemwin'] = 0;
            $session['user']['specialinc']="module:gnomogemme";
            addnav("Let me try again","forest.php?op=anothergem");
            addnav("You're a cheater, I leave!","forest.php?op=exit");
         }
      }
// Sixth try with 11 faces dice
   }else if ($op=="number11") {
      output("`2Write in the box your guess, choose a number between 1 and %s`n",($basedice+5));
      $choosenum = translate_inline("Choose Number");
      rawoutput("<form action='forest.php?op=number11bis' method='POST'><input name='number' value='0'><input type='submit' class='button' value='$choosenumber'>");
      //output("<form action='forest.php?op=number11bis' method='POST'><input name='number' value='0'><input type='submit' class='button' value='Choose Number'>`n",true);
      $session['user']['specialinc']="module:gnomogemme";
      addnav("","forest.php?op=number11bis");
   }else if ($op=="number11bis") {
      $number = httppost('number');
      if ($number < 1 OR $number > ($basedice+5)){
         output("`2The gnome looks angrily at you and says \"`#Number between 1 and %s choose ya must. Ya choosen `b`%%s`b`# that is wrong number!`2\"`n",($basedice+5),$number);
         $session['user']['specialinc']="module:gnomogemme";
         addnav(array("Choose number between 1 - %s",($basedice+5)),"forest.php?op=number11");
      }else{
         output("`2\"`#Choosen ya had `b`%%s`b`#, now ya roll the dice and we see if won ya have.`2\"`n`n",$number);
         $match = rand(1,($basedice+5));
         dot($match);
         output("`6The dice stop his run and shows the number `\$%s `6on the upper face.`n`n",$match);
         if ($match == $number) {
            $session['gemwin'] *= 3;
            output("`\$Arghhh !! `#Won you have. I give ya %s you won have, if ya want you can continue to play or retire from game and grab the gems ya won.`n",$session['gemwin']);
            $session['user']['specialinc']="module:gnomogemme";
            addnav("Grab Gems","forest.php?op=exit");
         }else if (($number-1) == $match OR ($number+1) == $match) {
            $session['gemwin'] *= 2;
            output("`\$Arghhh !! `#Your number is adjacent to dice's number. I give ya %s you won have, if ya want you can continue to play or retire from game and grab the gems ya won.`n",$session['gemwin']);
            $session['user']['specialinc']="module:gnomogemme";
            addnav("Grab Gems","forest.php?op=exit");
         }else {
            output("`#Eh eh eh, lose you have! I give ya another possibility if ya wanna try again, or ya can go back to forest if ya hate game! Ya must give me `b`^%s gems`b`# to try luck again.`n`n",($session['gemtopay']+1));
            output("`2What do ya wanna do?`n");
            $session['gemwin'] = 0;
            $session['user']['specialinc']="module:gnomogemme";
            addnav("Let me try again","forest.php?op=anothergem");
            addnav("You're a cheater, I leave!","forest.php?op=exit");
         }
      }
   }else if ($op=="exit") {
      if ($session['gemwin'] == 0) {
         output("`%Feeling sad for the defeat, you turn back to forest and slowly walk away, while the gnome laughs loudly looking at the gems that he has stolen from you!`n");
      } else {
         output("`@Feeling happy for the glorious victory over such tiny creature, you turn back to forest and walk away. ");
         output("You hear the screams of the gnome for a long time while you enter deeply in the forest.`n");
         if ($session['gemwin'] > get_module_setting('gnomogemme')) {
            $session['gemwin'] = get_module_setting('gnomogemme');
         }
         $session['user']['gems'] += $session['gemwin'];
         debuglog("win {$session['gemwin']} gems from the Gem's Gnome");
         $newgem = get_module_setting('gnomogemme') - $session['gemwin'];
         set_module_setting('gnomogemme',$newgem);
      }
      $session['user']['specialinc']="";
      addnav("F?Back to Forest","forest.php");
   }

   if ($op!="") {
      rawoutput("<big><div align=right>");
      output("`n`n`b`QGnome's Gems`b:`#%s`n",get_module_setting('gnomogemme'));
      rawoutput("</big></div>");
      rawoutput("<big><div align=right>");
      output("`b`QStack`b:`#%s`n",$session['gemwin']);
      rawoutput("</big></div>");
   }else {
      rawoutput("<big><div align=right>");
      output("`n`n`b`QGnome's Gems`b:`#%s`n",get_module_setting('gnomogemme'));
      rawoutput("</big></div>");
   }
//I cannot make you keep this line here but would appreciate it left in.
   rawoutput("<br><div style=\"text-align: right ;\"><a href=\"http://www.ogsi.it\" target=\"_blank\"><font color=\"#33FF33\">Gem's Gnome by Excalibur @ http://www.ogsi.it</font></a><br>");
   page_footer();
}

function dot($match){
    for ($i = 0; $i < $match;$i++) {
        output("`\$...........`%...........`!...........`#...........`@...........`^...........`n`n");
   }
}
function gnomogemme_run(){
}

?>