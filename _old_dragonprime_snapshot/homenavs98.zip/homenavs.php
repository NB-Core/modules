<?php

function homenavs_getmoduleinfo(){
	$info = array(
		"name"=>"Home Navs",
		"version"=>"1.12",
		"author"=>"`#Lonny Luberts",
		"category"=>"PQcomp",
		"download"=>"http://www.pqcomp.com/modules/mydownloads/visit.php?cid=3&lid=46",
		"vertxtloc"=>"http://www.pqcomp.com/",
		"settings"=>array(
			"Home Navs Module Settings,title",
			"nav1heading"=>"Nav 1 Heading,text",
			"nav1name"=>"Nav 1 Name,text",
			"nav1link"=>"Nav 1 Link,text",
			"nav2heading"=>"Nav 2 Heading,text",
			"nav2name"=>"Nav 2 Name,text",
			"nav2link"=>"Nav 2 Link,text",
			"nav3heading"=>"Nav 3 Heading,text",
			"nav3name"=>"Nav 3 Name,text",
			"nav3link"=>"Nav 3 Link,text",
			"nav4heading"=>"Nav 4 Heading,text",
			"nav4name"=>"Nav 4 Name,text",
			"nav4link"=>"Nav 4 Link,text",
			"nav5heading"=>"Nav 5 Heading,text",
			"nav5name"=>"Nav 5 Name,text",
			"nav5link"=>"Nav 5 Link,text",
			"nav6heading"=>"Nav 6 Heading,text",
			"nav6name"=>"Nav 6 Name,text",
			"nav6link"=>"Nav 6 Link,text",
			"nav7heading"=>"Nav 7 Heading,text",
			"nav7name"=>"Nav 7 Name,text",
			"nav7link"=>"Nav 7 Link,text",
			"nav8heading"=>"Nav 8 Heading,text",
			"nav8name"=>"Nav 8 Name,text",
			"nav8link"=>"Nav 8 Link,text",
			"nav9heading"=>"Nav 9 Heading,text",
			"nav9name"=>"Nav 9 Name,text",
			"nav9link"=>"Nav 9 Link,text",
			"nav10heading"=>"Nav 10 Heading,text",
			"nav10name"=>"Nav 10 Name,text",
			"nav10link"=>"Nav 10 Link,text",
		),
	);
	return $info;
}

function homenavs_install(){
	if (!is_module_active('homenavs')){
		output("`4Installing Home Navs Module.`n");
	}else{
		output("`4Updating Home Navs Module.`n");
	}
	module_addhook("index");
	return true;
}

function homenavs_uninstall(){
	output("`4Installing Home Navs Module.`n");
	return true;
}

function homenavs_dohook($hookname,$args){
	global $session;
	for ($i=0;$i<10;$i++){
	$heading = "nav".$i."heading";
	$name = "nav".$i."name";
	$link = "nav".$i."link";
	if (get_module_setting($heading) and get_module_setting($name) and get_module_setting($link)){
		addnav(array("%s",get_module_setting($heading)));
		addnav(array("%s",get_module_setting($name)),get_module_setting($link),false,true);
	}
	}
	return $args;
}

?>