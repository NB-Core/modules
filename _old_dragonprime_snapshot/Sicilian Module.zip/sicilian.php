<?
/**************************************************/
/* The Sicilian                                   */
/* ------------                                   */
/* Version 1.81                                    */
/* Written by Jake Taft (Zanzaras)                */
/* A small tribute/parody to "The Princess Bride" */
/**************************************************/

/***************************************************************************************/
/* Version History                                                                     */
/* ---------------                                                                     */
/* 1.0 - Original release. - Zanzaras                                                  */
/* 1.1 - Added more outcomes and balanced them & Fixed minor debug problem. - Zanzaras */
/* 1.2 - Fixed some minor grammar errors and a mathematical error when awarding        */
/*       treasure and losing turns. Also added a check to set turns to zero if they    */
/*       drop below zero. - Zanzaras                                                   */
/* 1.3 - Modified code to work with LotGD .98 - Zanzaras                               */
/* 1.31 - Fixed a copy/paste bug in the code - Zanzaras                                */
/* 1.4 - Made translator ready & made user variables conform to standard - Zanzaras    */
/* 1.41 - Fixed a tiny mathematical error when awarding treasure. - Zanzaras           */
/* 1.42 - Added support for Lonny's Module Update checker.                             */
/* 1.5 - Added admin settings for amount of gold and gems found and how many gold/gems */
/*       the player loses if he is defeated. - Zanzaras                                */
/* 1.51 - Fixed some spelling errors that slipped by me. Thanks to DaveS for pointing  */
/*        them out.                                                                    */
/* 1.6 - Added a description field to the module. - Zanzaras                           */
/* 1.7 - Fixed a bug that would remove all the player's gems regardless of setting.    */
/*                                                                         - Zanzaras  */
/* 1.71 - Found another spot where all the player's gems would be taken regardless of  */
/*        the setting. This SHOULD be totally fixed now.  - Zanzaras                   */
/* 1.72 - Changed the chance of player death, to 1/5 instead of 1/3. - Zanzaras        */
/* 1.8 - The player's choice to help or leave now affects their alignment. By how much */
/*       is an admin setting. - Zanzaras                                               */
/* 1.81 - Updated to work with the latest alignment changes.                           */
/***************************************************************************************/

/*********************************************************************************/
/* Setup instructions                                                            */
/* ------------------                                                            */
/* Copy this file to the "Module" directory inside the main lotgd directory then */
/* in the game go to the Manage modules in the Grotto and Install/activate it.   */
/*********************************************************************************/

if (is_module_active("alignment")){
        require_once("./modules/alignment/func.php");}

function sicilian_getmoduleinfo(){
         $info = array(
                 "name"=>"Sicilian Encounter (a PrincessBride Parody)",
                 "author"=>"Jake Taft (Zanzaras)",
                 "version"=>"1.81",
                 "category"=>"Forest Specials",
                 "description"=>"The players encounter a princess that has been kidnapped by a Sicilian.",
                 "download"=>"http://www.dragonprime.net/users/Zanzaras/Sicilian%20Module.zip",
                 "vertxtloc"=>"http://www.dragonprime.net/users/Zanzaras/",
                 "settings"=>array("Sicilian - Settings,title",
                                   "sicilianwingold"=>"Amount of gold a player finds if he wins. (player level * value),int|50",
                                   "sicilianwingems"=>"Number of gems a player finds if he wins.,int|3",
                                   "sicilianlosegold"=>"Amount of gold a player loses if he is defeated. (-1 = all),int|-1",
                                   "sicilianlosegems"=>"Number of gems a player loses if he is defeated. (-1 = all),int|3",
                                   "sicilianloseturns"=>"Number of turns a player loses due to poison. (-1 = all),int|4",
                                   "The following settings are only used if the \"Basic Alignment\" module has been activated.,note",
                                   "siciliangood"=>"Alignment points gained for rescuing the princess,range,0,10,1|5",
                                   "sicilianevil"=>"Alignment points lost for not trying to help the princess,range,0,10,1|5"));
         return $info;}

function sicilian_install(){
         module_addeventhook("forest", "return 100;");
         return true;}

function sicilian_uninstall(){
         return true;}

function sicilian_dohook($hookname,$args){
         return $args;}


function sicilian_runevent($type)
{global $session;
 $from = "forest.php?";
 $session['user']['specialinc'] = "module:sicilian";
 $op = httpget('op');
 $wingold = get_module_setting("sicilianwingold");
 if ($wingold >= 0) $wingold = $wingold * $session['user']['level'];
 $wingems = get_module_setting("sicilianwingems");
 $losegold = get_module_setting("sicilianlosegold");
 $losegems = get_module_setting("sicilianlosegems");
 $loseturns = get_module_setting("sicilianloseturns");
 $addevil = (get_module_setting("sicilianevil")*-1);
 $addgood = get_module_setting("siciliangood");

 switch($op){
  case "search":
  case "":
    output("`n`#As you wander through the forest, you come upon a small clearing.");
    output("In the center of the clearing you see an odd balding little man sitting at a table");
    output("with 2 glasses of wine. Tied up and blindfolded beside him with a knife to her throat is the most beautiful girl in the world ");
    output("(obviously his captive). He watches you, smirking confidently as you approach, then speaks.`n`n");
    output("`%\"You are not the Man in Black, as one can clearly see. Since no one else knew we were out here,");
    output("it must be concluded that he sent you and that he is a coward.\"`n`n");
    output("`#You try to interrupt the man to point out that you're just out hunting evil creatures and have no idea what he's talking about, but he pompously chatters on, refusing to let you get a word in edge-wise.`n`n");
    output("`%\"So, since I have what you want, the princess, and you have what I want, the freedom to leave and carry out my kidnapping; we seem to be at an impasse. Luckily for you, I have the solution.");
    output("Sitting here on this table are 2 glasses of wine. In one of the glasses of wine is a deadly poison, Iocaine powder to be exact.");
    output("You have two choices. You may turn and leave, thereby allowing me to carry out my kidnapping or engage in a battle of wits by drinking the glass of wine which you believe to not be poisoned. Make your choice.\"");
    addnav("Drink the wine on");
    addnav("His side of the table",$from."op=hiswine");
    addnav("Your side of the table",$from."op=yourwine");
    addnav("Leave");
    addnav("Leave",$from."op=leave");
    break;

  case "hiswine":
        $rand = e_rand(1,5);
        switch ($rand)
         {case 1:
                output("`n`#You take the wine in front of him and confidently drink it as the Sicilian does the same with the wine in front of you. You both smirk at each other waiting for the other person to die.`n`nThe last thought you have before dropping dead is `%\"I wonder how long it takes this poison to work, I'm in a hurry.\"`n`n");
                output("`4You are dead.`n");
                output("`4All your gold has been lost.`n");
                $session['user']['gold']=0;
                $session['user']['hitpoints']=0;
                $session['user']['alive']=false;
                if (is_module_active('alignment')){align($addgood);}
                addnav("Daily news","news.php");
                addnews("%s was outwitted by a Sicilian in the forest.",$session['user']['name']);
                $session['user']['specialinc']="";
                break;
          case 2:case 3:
                output("`n`#You take the wine glass in front of him and confidently drink it as the Sicilian does the same with the wine in front of you. You both smirk at each other waiting for the other person to die. `%\"Haha.. you fool! You fell victim to one of the classic blunders. The most famous is: Never get involved in a land war in Asia. Only slightly less well know is this: Never go in against a Sicilian when death is on the line!\" `#Thankfully, the Sicilian falls over dead before he can launch another tirade.`n`n");
                output("`#You go over and untie the princess and take off her blindfold. She looks at you and says `%\"You're not my Westley!\" `#and immediately runs off.`n`nYou stand there for a few moments utterly confused, then decide to rifle through the dead man's belongings.`n`n");
                $TreasureType = e_rand(1,5);
                switch ($TreasureType)
                 {case 1:case 2:
                          output("`^You find %s gold!`n`n",$wingold);
                          $session['user']['gold']+=$wingold;
                          debuglog("found $wingold gold on a Sicilian who had kidnapped a princess.");
                          break;
                  case 3:case 4:
                          output("`^You find %s gems!`n`n",$wingems);
                          $session['user']['gems']+=$wingems;
                          debuglog("found $wingems gems on a Sicilian who had kidnapped a princess.");
                          break;
                  case 5: output("`^You find %s gold and %s gems!`n`n",$wingold,$wingems);
                          $session['user']['gold']+=$wingold;
                          $session['user']['gems']+=$wingems;
                          debuglog("found $wingold gold and $wingems gems on a Sicilian who had kidnapped a princess.");
                          break;
                 }
                if (is_module_active('alignment')){align($addgood);}
                addnews("`#Inconceivable! `^%s `#outwitted a Sicilian kidnapper in the forest and freed the princess.",$session['user']['name']);
                break;
          case 4:case 5:
                output("`n`#You take the wine in front of him and confidently drink it as the Sicilian does the same with the wine in front of you. You both smirk at each other waiting for the other person to die.`n`nYou're last conscience thought is `%\"How did I get suckered into this?\"`n`n");
                output("`#You regain consciousness several hours later. The Sicilian and the princess are gone and to top it off you hurt all over. You make a mental note to get an Iocaine powder booster shot, since your immunity to that poison is obviously almost gone.");
                output("`#You spend a few more minutes recovering, then head out into the forest.`n`n");
                output("`4 You've lost most of your hitpoints...`n");
                if ($loseturns < 0)
                   {output("and all of your turns...`n");
                    $session['user']['turns']=0;
                   }
                if ($loseturns > 0)
                   {$session['user']['turns']-=$loseturns;
                    if ($session['user']['turns'] < 0) $session['user']['turns'] = 0;
                    if ($session['user']['turns'] = 0) output("and all of your turns...`n");
                    if ($session['user']['turns'] > 0) output("and %s turns...`n",$loseturns);
                   }
                if ($losegold < 0)
                   {output("and all of your gold...`n");
                    $session['user']['gold']=0;
                   }
                if ($losegold > 0)
                   {$session['user']['gold']-=$losegold;
                    if ($session['user']['gold'] < 0) $session['user']['gold'] = 0;
                    if ($session['user']['gold'] = 0) output("and all of your gold...`n");
                    if ($session['user']['gold'] > 0) output("and %s gold...`n",$losegold);
                   }
                if ($losegems < 0)
                   {output("and all the gems you were carrying...`n");
                    $session['user']['gems']=0;
                   }
                if ($losegems > 0)
                   {$session['user']['gems']-=$losegems;
                    if ($session['user']['gems'] < 0) $session['user']['gems'] = 0;
                    if ($session['user']['gems'] == 0) output("and all the gems you were carrying...`n");
                    if ($session['user']['gems'] > 0) output("and %s gems...`n",$losegems);
                   }
                output("`n...but at least you're still alive!`n`n");
                if (is_module_active('alignment')){align($addgood);}
                $session['user']['hitpoints']=round($session['user']['hitpoints']*.1);
                if ($session['user']['hitpoints']<1) $session['user']['hitpoints']=1;
                break;
         }
       $session['user']['specialinc']="";
       break;

  case "yourwine":
        $rand = e_rand(1,5);
        switch ($rand)
         {case 1:
                output("`n`#You take the wine in front of you and confidently drink it as the Sicilian does the same with the wine in front of him. You both smirk at each other waiting for the other person to die.`n`nThe last thought you have before dropping dead is `%\"I wonder how long it takes this poison to work, I'm in a hurry.\"`n`n");
                output("`4You are dead.`n");
                output("`4All your gold has been lost.`n");
                $session['user']['gold']=0;
                $session['user']['hitpoints']=0;
                $session['user']['alive']=false;
                if (is_module_active('alignment')){align($addgood);}
                addnav("Daily news","news.php");
                addnews("%s was outwitted by a Sicilian in the forest.",$session['user']['name']);
                $session['user']['specialinc']="";
                break;
          case 2:case 3:
                output("`n`#You take the wine glass in front of you and confidently drink it as the Sicilian does the same with the wine in front of him. You both smirk at each other waiting for the other person to die. `%\"Haha.. you fool! You fell victim to one of the classic blunders. The most famous is: Never get involved in a land war in Asia. Only slightly less well know is this: Never go in against a Sicilian when death is on the line!\" `#Thankfully, the Sicilian falls over dead before he can launch another tirade.`n`n");
                output("`#You go over and untie the princess and take off her blindfold. She looks at you and says `%\"You're not my Westley!\" `#and immediately runs off.`n`nYou stand there for a few moments utterly confused, then decide to rifle through the dead man's belongings.`n`n");
                $TreasureType = e_rand(1,5);
                switch ($TreasureType)
                 {case 1:case 2:
                          output("`^You find %s gold!`n`n",$wingold);
                          $session['user']['gold']+=$wingold;
                          debuglog("found $wingold gold on a Sicilian who had kidnapped a princess.");
                          break;
                  case 3:case 4:
                          output("`^You find %s gems!`n`n",$wingems);
                          $session['user']['gems']+=$wingems;
                          debuglog("found $wingems gems on a Sicilian who had kidnapped a princess.");
                          break;
                  case 5: output("`^You find %s gold and %s gems!`n`n",$wingold,$wingems);
                          $session['user']['gold']+=$wingold;
                          $session['user']['gems']+=$wingems;
                          debuglog("found $wingold gold and $wingems gems on a Sicilian who had kidnapped a princess.");
                          break;
                 }
                if (is_module_active('alignment')){align($addgood);}
                addnews("`#Inconceivable! `^%s `#outwitted a Sicilian kidnapper in the forest and freed the princess.",$session['user']['name']);
                break;
          case 4:case 5:
                output("`n`#You take the wine in front of you and confidently drink it as the Sicilian does the same with the wine in front of him. You both smirk at each other waiting for the other person to die.`n`nYou're last conscience thought is `%\"How did I get suckered into this?\"`n`n");
                output("`#You regain consciousness several hours later. The Sicilian and the princess are gone and to top it off you hurt all over. You make a mental note to get an Iocaine powder booster shot, since your immunity to that poison is obviously almost gone.");
                output("`#You spend a few more minutes recovering, then head out into the forest.`n`n");
                output("`4 You've lost most of your hitpoints...`n");
                if ($loseturns < 0)
                   {output("and all of your turns...`n");
                    $session['user']['turns']=0;
                   }
                if ($loseturns > 0)
                   {$session['user']['turns']-=$loseturns;
                    if ($session['user']['turns'] < 0) $session['user']['turns'] = 0;
                    if ($session['user']['turns'] = 0) output("and all of your turns...`n");
                    if ($session['user']['turns'] > 0) output("and %s turns...`n",$loseturns);
                   }
                if ($losegold < 0)
                   {output("and all of your gold...`n");
                    $session['user']['gold']=0;
                   }
                if ($losegold > 0)
                   {$session['user']['gold']-=$losegold;
                    if ($session['user']['gold'] < 0) $session['user']['gold'] = 0;
                    if ($session['user']['gold'] = 0) output("and all of your gold...`n");
                    if ($session['user']['gold'] > 0) output("and %s gold...`n",$losegold);
                   }
                if ($losegems < 0)
                   {output("and all the gems you were carrying...`n");
                    $session['user']['gems']=0;
                   }
                if ($losegems > 0)
                   {$session['user']['gems']-=$losegems;
                    if ($session['user']['gems'] < 0) $session['user']['gems'] = 0;
                    if ($session['user']['gems'] == 0) output("and all the gems you were carrying...`n");
                    if ($session['user']['gems'] > 0) output("and %s gems...`n",$losegems);
                   }
                output("`n...but at least you're still alive!`n`n");
                if (is_module_active('alignment')){align($addgood);}
                $session['user']['hitpoints']=round($session['user']['hitpoints']*.1);
                if ($session['user']['hitpoints']<1) $session['user']['hitpoints']=1;
                break;
         }
       $session['user']['specialinc']="";
       break;

  case "leave":
        output("`n`#You are obviously no match for this man's staggering intelligence, so you leave. The Sicilian's laughter follows you back to the forest.`n");
        $session['user']['specialinc']="";
        if (is_module_active('alignment')){align($addevil);}
        break;
  }
}

function sicilian_run(){}

?>
