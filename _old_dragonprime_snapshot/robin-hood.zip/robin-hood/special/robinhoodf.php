<?
//robin hood and his band of merry men forest event
//this is the forest call file please place in special folder
//Created by Lonny Luberts of http://www.pqcomp.com/logd e-mail logd@pqcomp.com

require_once "common.php";
checkday();
page_header("Robin Hood");
redirect("robinhood.php");
page_footer();
?>