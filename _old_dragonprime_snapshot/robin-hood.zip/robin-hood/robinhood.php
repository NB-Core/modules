<?
//robin hood and his band of merry men forest event
//Created by Lonny Luberts of http://www.pqcomp.com/logd e-mail logd@pqcomp.com
//place this file in the main(logd) folder
//Translated to German by the13th of http://logd.dunkelwald.org - mail: team@dunkelwald.org
//
//Translated Header:
//Robin Hood und seine treuen Gesellen Waldkampf-Event
//Erstellt von Lonny Luberts (http://www.pqcomp.com/logd - logd@pqcomp.com)
//Deutsche �bersetzung: the13th (http://logd.dunkelwald.org - team@dukelwald.org)
//Datei "robinhood.php" (diese Datei) in den LoGD Hauptordner kopieren, "robinhoodf.php" in den
//Ordner "special" kopieren.
//�bersetzungsversion 0.9[28102004]

require_once "common.php";
checkday();
page_header("Robin Hood");
output("`c`b`&Something Special`0`b`c`n`n");
//checkevent();
if ($HTTP_GET_VARS[op] == ""){
	$totalgold = $session[user][goldinbank] + $session[user][gold];
	if ($session[user][gold] <1) $totalgold = 0;
output("`7W�hrend du durch den Wald wanderst st�sst du auf Robin Hood und seine treuen Gesellen.`n");
if ($totalgold > 499) output("`7Robin Hood erkl�rt dir, das er vorhat, dein Gold an sich zu nehmen und es unter den Armen zu verteilen.`n");
if ($totalgold < 499) output("`7Sie gr�ssen dich und gehen dan weiter.");
if ($totalgold > 499) output("`4Robin Hood verlangt, das du ihm dein Gold freiwillig aush�ndigst.`n");
if ($totalgold > 499) output("`7Was wirst du tun?  Den armen helfen oder versuchen, dein Gold zu behalten?");
if ($totalgold > 499) addnav("Gebe ihm dein Gold","robinhood.php?op=loose&op2=give");
if ($totalgold > 499) addnav("K�mpfe mit ihm","robinhood.php?op=fight1");
if ($totalgold < 499) addnav("Weiter","forest.php");
}

if ($HTTP_GET_VARS[op] == "loose"){

	if ($session[user][hitpoints] < 1) $session[user][hitpoints] = 1;
	$loot = $session[user][gold];
	$session[user][gold] = 0;
	$sql = "SELECT acctid,name,goldinbank,gold,login FROM accounts";
	$result = db_query($sql);
	for ($i=0;$i<db_num_rows($result);$i++){
    $row = db_fetch_assoc($result);
	if ($row[goldinbank] < 1 and $row[gold] < 1){
		$num++;
	}
}
if ($num == 0){
	for ($i=0;$i<db_num_rows($result);$i++){
    $row = db_fetch_assoc($result);
	if ($row[goldinbank] < 1 and $row[gold] < 10000 and $row[name] <> $session[user][name]){
		$num++;
	}
}	
}
$dist = ($loot/$num);
// if there is no one to give the gold to never worry.... robin hood keeps it. hehe
$result = db_query($sql);
	for ($i=0;$i<db_num_rows($result);$i++){
    $row = db_fetch_assoc($result);
	if ($row[goldinbank] < 1 ){
		$give = $row[goldinbank] + $dist;
		if ($row[name] <> $session[user][name]){
		$sql2 = ("UPDATE accounts SET goldinbank=$give WHERE login = '{$row['login']}'");
		db_query($sql2);
		$mailmessage = $session[user][name];
		$mailmessage .= " wurde von Robin Hood und seinen treuen Gesellen ausgeraubt.  Sie nahmen ";
		$mailmessage .= $loot;
		$mailmessage .= " Gold an sich und verteilten es unter ";
		$mailmessage .= $num;
		$mailmessage .= " Leuten.  Jeder von euch erhielt ";
		$mailmessage .= $dist;
		$mailmessage .= " Gold.  Das Gold wurde in euer Bankfach gelegt.";
		systemmail($row[acctid],"`2Robin Hood hat dir etwas Gold gegeben!`2",$mailmessage);
		}
	}
}

	if ($num > 0) addnews("Robin Hood stahl $loot Gold von ".$session[user][name]."`7 und verteilte es unter den Armen.");
	if ($num < 1) addnews("Robin Hood stahl $loot Gold von ".$session[user][name]."`7 und beh�lt die Beute");
	if ($HTTP_GET_VARS[op2] <> "give") output("`4Du hast verloren!`n");
	if ($HTTP_GET_VARS[op2] == "give") output("`7Du reichst Robin Hood dein Gold!");
	if ($HTTP_GET_VARS[op2] <> "give") output("`7Robin Hood und seine Gesellen sind doch nicht so b�se... Auch wenn sie dich ganz sch�n aufgemischt haben - aber sie haben dich am Leben gelassen.`n"); 
	output("`3Robin Hood nimmt dein Gold und verteilt es unter den �rmsten im Reich.");
	addnav("Weiter","forest.php");
	if ($session[user][hitpoints] == 1){
	output("Bevor sie weiterziehen, wirft dir Robin Hood noch ein kleines Fl�schchen zu.  Du trinkst es aus und... ");
	switch(e_rand(1,10)){
		case 1:
		$session[user][hitpoints] = $session[user][maxhitpoints] * .1;
		output("der Trank erneuert 10% deiner Lebenskraft.`n");
		break;
		case 2:
		$session[user][hitpoints] = $session[user][maxhitpoints] * .2;
		output("der Trank erneuert 20% deiner Lebenskraft.`n");
		break;
		case 3:
		$session[user][hitpoints] = $session[user][maxhitpoints] * .3;
		output("der Trank erneuert 30% deiner Lebenskraft.`n");
		break;
		case 4:
		$session[user][hitpoints] = $session[user][maxhitpoints] * .4;
		output("der Trank erneuert 40% deiner Lebenskraft.`n");
		break;
		case 5:
		$session[user][hitpoints] = $session[user][maxhitpoints] * .5;
		output("der Trank erneuert 50% deiner Lebenskraft.`n");
		break;
		case 6:
		$session[user][hitpoints] = $session[user][maxhitpoints] * .6;
		output("der Trank erneuert 60% deiner Lebenskraft.`n");
		break;
		case 7:
		$session[user][hitpoints] = $session[user][maxhitpoints] * .7;
		output("der Trank erneuert 70% deiner Lebenskraft.`n");
		break;
		case 8:
		$session[user][hitpoints] = $session[user][maxhitpoints] * .8;
		output("der Trank erneuert 80% deiner Lebenskraft.`n");
		break;
		case 9:
		$session[user][hitpoints] = $session[user][maxhitpoints] * .9;
		output("der Trank erneuert 90% deiner Lebenskraft.`n");
		break;
		case 10:
		$session[user][hitpoints] = $session[user][maxhitpoints];
		output("der Trank erneuert deine vollst�ndige Lebenskraft.`n");
		break;
	}
}
}
if ($HTTP_GET_VARS[op] == "win"){
	output("Du hast Robin Hood und seine treuen Gesellen besiegt!");
	addnews("Robin Hood und seine treuen Gesellen sind im Wald von ".$session[user][name]."`7besiegt worden!");
	output("Du denkst, das es sicherlich schlauer ist, zu verschwinden, bevor sie wieder aufstehen.");
	//addnews
	addnav("Weiter","forest.php");
}
if ($HTTP_GET_VARS[op] == "fight1"){
$badguy = array(        "creaturename"=>"`@Bruder Tuck`0"
                                ,"creaturelevel"=>0
                                ,"creatureweapon"=>"Bierbauch"
                                ,"creatureattack"=>0
                                ,"creaturedefense"=>1
                                ,"creaturehealth"=>2
                                ,"creaturegold"=>0
                                ,"diddamage"=>0);

                                $userlevel=$session[user][level];
                                $userattack=e_rand(2,$session[user][atack])+2;
                                $userhealth=e_rand(30,110)+$session[user][level];
                                $userdefense=e_rand(2,$session[user][defence])+2;
                                $badguy[creaturelevel]+=$userlevel;
                                $badguy[creatureattack]+=$userattack;
                                $badguy[creaturehealth]=$userhealth;
                                $badguy[creaturedefense]+=$userdefense;
                                $badguy[creaturegold]=0;
                                $session[user][badguy]=createstring($badguy);
                                $HTTP_GET_VARS[op]="fight";
                            }
if ($HTTP_GET_VARS[op] == "fight2"){
$badguy = array(        "creaturename"=>"`@Will Scarlet`0"
                                ,"creaturelevel"=>0
                                ,"creatureweapon"=>"Schwert"
                                ,"creatureattack"=>1
                                ,"creaturedefense"=>2
                                ,"creaturehealth"=>2
                                ,"creaturegold"=>0
                                ,"diddamage"=>0);

                                $userlevel=$session[user][level];
                                $userattack=e_rand(2,$session[user][atack])+4;
                                $userhealth=e_rand(40,120)+$session[user][level];
                                $userdefense=e_rand(2,$session[user][defence])+4;
                                $badguy[creaturelevel]+=$userlevel;
                                $badguy[creatureattack]+=$userattack;
                                $badguy[creaturehealth]=$userhealth;
                                $badguy[creaturedefense]+=$userdefense;
                                $badguy[creaturegold]=0;
                                $session[user][badguy]=createstring($badguy);
                                $HTTP_GET_VARS[op]="fight";
                            } 
if ($HTTP_GET_VARS[op] == "fight3"){
$badguy = array(        "creaturename"=>"`@Little John`0"
                                ,"creaturelevel"=>1
                                ,"creatureweapon"=>"Stab"
                                ,"creatureattack"=>2
                                ,"creaturedefense"=>3
                                ,"creaturehealth"=>2
                                ,"creaturegold"=>0
                                ,"diddamage"=>0);

                                $userlevel=$session[user][level];
                                $userattack=e_rand(2,$session[user][atack])+6;
                                $userhealth=e_rand(50,130)+$session[user][level];
                                $userdefense=e_rand(2,$session[user][defence])+6;
                                $badguy[creaturelevel]+=$userlevel;
                                $badguy[creatureattack]+=$userattack;
                                $badguy[creaturehealth]=$userhealth;
                                $badguy[creaturedefense]+=$userdefense;
                                $badguy[creaturegold]=0;
                                $session[user][badguy]=createstring($badguy);
                                $HTTP_GET_VARS[op]="fight";
                            }

if ($HTTP_GET_VARS[op] == "fight4"){
$badguy = array(        "creaturename"=>"`@Robin Hood`0"
                                ,"creaturelevel"=>2
                                ,"creatureweapon"=>"Fliegenden Pfeilen"
                                ,"creatureattack"=>3
                                ,"creaturedefense"=>4
                                ,"creaturehealth"=>2
                                ,"creaturegold"=>0
                                ,"diddamage"=>0);

                                $userlevel=$session[user][level];
                                $$userattack=e_rand(2,$session[user][atack])+8;
                                $userhealth=e_rand(60,140)+$session[user][level];
                                $userdefense=e_rand(2,$session[user][defence])+8;
                                $badguy[creaturelevel]+=$userlevel;
                                $badguy[creatureattack]+=$userattack;
                                $badguy[creaturehealth]=$userhealth;
                                $badguy[creaturedefense]+=$userdefense;
                                $badguy[creaturegold]=0;
                                $session[user][badguy]=createstring($badguy);
                                $HTTP_GET_VARS[op]="fight";
                            }
                                            
if ($HTTP_GET_VARS[op] == "fight"){
$battle=true;                               
}
if ($battle){
        include_once("battle.php");                              
      
	if ($victory){
                output("You have beaten `^".$badguy['creaturename'].".");
                if ($badguy['creaturename']=="`@Bruder Tuck`0") addnav("Weiter","robinhood.php?op=fight2");
                if ($badguy['creaturename']=="`@Will Scarlet`0") addnav("Weiter","robinhood.php?op=fight3");
                if ($badguy['creaturename']=="`@Little John`0") addnav("Weiter","robinhood.php?op=fight4");
                if ($badguy['creaturename']=="`@Robin Hood`0") addnav("Weiter","robinhood.php?op=win");
                $badguy=array();
                $session[user][badguy]="";
	}
	elseif ($defeat){
                output("Als du unsanft auf dem Bodem schl�gst nimmt `^".$badguy['creaturename']." und der Rest von Robin Hood's Gesellen dein Gold an sich.");
                addnews("`%".$session[user][name]."`5 wurde besiegt als ".($session[user][sex]?"sie":"er")." von Robin Hood und seinen treuen Gesellen angegriffen worden ist.");
                $session[user][hitpoints]=1;
                addnav("Weiter","robinhood.php?op=loose");
	}
	else{
                fightnav(true,false);
	}
}else{

}



page_footer();
?>