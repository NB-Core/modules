<?

require_once("common.php");
require_once("lib/commentary.php");
require_once("lib/http.php");
require_once("lib/villagenav.php");

function arcadia_getmoduleinfo(){
        $info = array(
                "name"=>"Arcadia Village",
                "version"=>"2.1",
                "author"=>"`4D`)hampir `4K`)ampf",
                "category"=>"Village",
                "download"=>"http://dragonprime.net/users/Dhampir/arcadia.zip",
                "vertxtloc"=>"http://dragonprime.net/users/Dhampir/",
                "settings"=>array(
                        "Aracadia Settings,title",

                        "adks"=>"How many DKs is required to visit Arcadia?,int|31",
                        "nav1"=>"What is the title of Nav1?|MightyE's Weaponry",
                        "nav1url"=>"What is the url of Nav1?|weapons.php",
                        "nav2"=>"What is the title of Nav2?|Pegasus Armor",
                        "nav2url"=>"What is the url of Nav2 ?|armor.php",
                        "nav3"=>"What is the title of Nav3?|Ye Olde Bank",
                        "nav3url"=>"What is the url of Nav3?|bank.php",
                        "nav4"=>"What is the title of Nav4?|Merick's Stables",
                        "nav4url"=>"What is the url of Nav4?|stables.php",
                        "nav5"=>"What is the title of Nav5?|The Inn",
                        "nav5url"=>"What is the url of Nav5?|inn.php",
                        "nav6"=>"What is the title of Nav6?",
                        "nav6url"=>"What is the url of Nav6?",
                        "nav7"=>"What is the title of Nav7?",
                        "nav7url"=>"What is the url of Nav7?",
                        "nav8"=>"What is the title of Nav8?",
                        "nav8url"=>"What is the url of Nav8?",
                        "nav9"=>"What is the title of Nav9?",
                        "nav9url"=>"What is the url of Nav9?",
                        "nav10"=>"What is the title of Nav10?",
                        "nav10url"=>"What is the url of Nav10?",
                        ),
                "prefs"=>array(
                        "Arcadia Prefs,title",

						"banned"=>"Is user banned from Arcadia?,bool|0",
                        "allowed"=>"Is user allowed to visit Arcadia?,bool|0",
                        ),
                );

        return $info;
}

function arcadia_install(){
        module_addhook("village");
        module_addhook("moderate");
        return true;
}

function arcadia_uninstall(){
        return true;
}

function arcadia_dohook($hookname,$args){
        global $session;
        switch($hookname){
        case "village":
				if(get_module_pref("banned")==1){}else{
                if($session['user']['dragonkills']>=get_module_setting("adks")){
                tlschema($args['schemas']['gatenav']);
                addnav($args["gatenav"]);
                tlschema();
                addnav("`@`iArcadia`i `#- `^City of Gods","runmodule.php?module=arcadia");
                }else{}
                }
                
                if(get_module_pref("allowed") == 1){
                tlschema($args['schemas']['gatenav']);
                addnav($args["gatenav"]);
                tlschema();
                addnav("`@`iArcadia`i `#- `^City of Gods","runmodule.php?module=arcadia");}else{}
                break;
        case "moderate":
                $args['arcadia'] = "Arcadia";
                break;
                }

        return $args;
}

function arcadia_run(){
        global $session;
        $op = httpget('op');
        
        if($op==""){
        page_header("Arcadia - City of Gods");
        
				rawoutput("<font style='font-size: 14pt;'>");
                output("`n`c`b`i`@Arcadia`i `7- `^City of Gods`c`b`n`n");
                rawoutput("</font>");
                
                output("`7Seeing how you are currently in `@`iArcadia`i`7, you should give yourself a pat on the back! Why?
                because you're a god/goddess! This area is just an area for god/goddess to have a place to come to get away from
                the hectic newbs, and have a place to chat amongst the other gods/goddesses. So have fun!`n`n`n");
                
                addcommentary();
                viewcommentary ("arcadia","Speak", 25, "says");

                addnav("Travel");
                addnav("Forest","forest.php");
                villagenav();
                
                $nav1 = get_module_setting("nav1");
                $tnav1=translate_inline("$nav1");
				$nav1url = get_module_setting("nav1url");
				$tnav1url=translate_inline("$nav1url");
				$nav2 = get_module_setting("nav2");
				$tnav2=translate_inline("$nav2");
				$nav2url = get_module_setting("nav2url");
				$tnav2url=translate_inline("$nav2url");
				$nav3 = get_module_setting("nav3");
				$tnav3=translate_inline("$nav3");
				$nav3url = get_module_setting("nav3url");
				$tnav3url=translate_inline("$nav3url");
				$nav4 = get_module_setting("nav4");
				$tnav4=translate_inline("$nav4");
				$nav4url = get_module_setting("nav4url");
				$tnav4url=translate_inline("$nav4url");
				$nav5 = get_module_setting("nav5");
				$tnav5=translate_inline("$nav5");
				$nav5url = get_module_setting("nav5url");
				$tnav5url=translate_inline("$nav5url");
				$nav6 = get_module_setting("nav6");
				$tnav6=translate_inline("$nav6");
				$nav6url = get_module_setting("nav6url");
				$tnav6url=translate_inline("$nav6url");
				$nav7 = get_module_setting("nav7");
				$tnav7=translate_inline("$nav7");
				$nav7url = get_module_setting("nav7url");
				$tnav7url=translate_inline("$nav7url");
				$nav8 = get_module_setting("nav8");
				$tnav8=translate_inline("$nav8");
				$nav8url = get_module_setting("nav8url");
				$tnav8url=translate_inline("$nav8url");
				$nav9 = get_module_setting("nav9");
				$tnav9=translate_inline("$nav9");
				$nav9url = get_module_setting("nav9url");
				$tnav9url=translate_inline("$nav9url");
				$nav10 = get_module_setting("nav10");
				$tnav10=translate_inline("$nav10");
				$nav10url = get_module_setting("nav10url");
				$tnav10url=translate_inline("$nav10url");
                
                addnav("Other");
                addnav("$tnav1","$tnav1url");
                addnav("$tnav2","$tnav2url");
                addnav("$tnav3","$tnav3url");
                addnav("$tnav4","$tnav4url");
                addnav("$tnav5","$tnav5url");
                addnav("$tnav6","$tnav6url");
                addnav("$tnav7","$tnav7url");
                addnav("$tnav8","$tnav8url");
				addnav("$tnav9","$tnav9url");
				addnav("$tnav10","$tnav10url");
        page_footer();
       
        }
}
?>
