<?php

// this module presents a big red button to slay the dragon
// once the player hits either the "village" or "forest" module hooks

function bigredbutton_getmoduleinfo(){
	$info = array(
		"name"=>"Big Red Button",
		"version"=>"0.1",
		"author"=>"dying",
		"category"=>"Joke",
		"download"=>"http://www.dragonprime.net/users/dying"
	);
	return $info;
}

function bigredbutton_install(){
	// only these two hooks are added because there really isn't any need
	// to add more load to the server when the vast majority of users will
	// have to hit one of these hooks in order to do anything constructive
	module_addhook("village");
	module_addhook("forest");
	return true;
}

function bigredbutton_uninstall(){
	return true;
}

function bigredbutton_dohook($hookname,$args){
	switch($hookname){
	case "village":
	case "forest":
		output("`b`c`%OMGWTFBBQ, its teh `@GREEN DRAGON!!I1li`c`b");
		blocknav("", true);   // block all navs
		unblocknav("runmodule.php?module=bigredbutton");
		addnav("`b`\$SLAY DRAGON`b", "runmodule.php?module=bigredbutton");
		// intentionally prematurely cut rest of page off
		page_footer();
	}
	return $args;
}

function bigredbutton_run()
{
	page_header("The Dragon is Slain!");

	output("`b`c`i`#You have slain `@the dragon`#!`i  `#Gheer!`c`b`n`n");
	output("`b`c`^YOUR`nWINNER!`c`b");

	addnav("I want to my winner again", "village.php");

	page_footer();
}

?>
