<?php

function raceadony_getmoduleinfo(){
	$info = array(
		"name"=>"Race - Adony",
		"version"=>"1.02",
		"author"=>"Enhas, based on racecat by Shannon Brown",
		"category"=>"Races",
		"download"=>"http://dragonprime.net/users/Enhas/raceadony.txt",
            "requires"=>array(
			"racehuman"=>"1.0|By Eric Stevens,part of core download",
		),
		"settings"=>array(
			"Adonys Race Settings,title",
			"minedeathchance"=>"Percent chance for Adonys to die in the mine,range,0,100,1|35",
                  "mindk"=>"How many dragonkills are needed to use this race?,int|3",
                  "mincharmgain"=>"Min charm to gain on newday,range,1,3,1|1",
                  "maxcharmgain"=>"Max charm to gain on newday,range,1,3,1|3",
		),
	);
	return $info;
}

function raceadony_install(){
	if (!is_module_installed("racehuman")) {
		output("The Adonys only choose to live with humans.   You must install that race module.");
		return false;
	}

	module_addhook("chooserace");
	module_addhook("setrace");
	module_addhook("newday");
	module_addhook("charstats");
	module_addhook("raceminedeath");
	module_addhook("pvpadjust");
	module_addhook("racenames");
      module_addhook("adjuststats");
	return true;
}

function raceadony_uninstall(){
	global $session;
	// Force anyone who was a Adony to rechoose race
	$sql = "UPDATE  " . db_prefix("accounts") . " SET race='" . RACE_UNKNOWN . "' WHERE race='Adony'";
	db_query($sql);
	if ($session['user']['race'] == 'Adony')
		$session['user']['race'] = RACE_UNKNOWN;
	return true;
}

function raceadony_dohook($hookname,$args){
	//yeah, the $resline thing is a hack.  Sorry, not sure of a better way
	//to handle this.
	// It could be passed as a hook arg?
	global $session,$resline;

	if (is_module_active("racehuman")) {
		$city = get_module_setting("villagename", "racehuman");
	} else {
		$city = getsetting("villagename", LOCATION_FIELDS);
	}
	$race = "Adony";
	switch($hookname){
	case "racenames":
		$args[$race] = $race;
		break;
	case "pvpadjust":
            if ($args['race'] == $race) {
                  $args['creaturehealth']+= round($args['creaturehealth']*.1, 0);
		}
		break;
            case "adjuststats":
		if ($args['race'] == $race) {
                  $args['maxhitpoints'] += round($args['maxhitpoints']*.1, 0);
		}
		break;
	case "raceminedeath":
		if ($session['user']['race'] == $race) {
			$args['chance'] = get_module_setting("minedeathchance");
			$args['racesave'] = "Your Adony charm helps you escape unharmed!`n";
			$args['schema']="module-raceadony";
		}
		break;
	case "charstats":
		if ($session['user']['race']==$race){
			addcharstat("Vital Info");
			addcharstat("Race", translate_inline($race));
		}
		break;
	case "chooserace":
		if ($session['user']['dragonkills'] < get_module_setting("mindk"))
			break;
		output("<a href='newday.php?setrace=Adony$resline'>Dwelling within the city of %s</a>, your vain, human offshoot race known as `%Adonys`0 are known for their lust for beauty, and charm.  You decide that bringing in the head of `@The Green Dragon`0 would make you even more popular in the eyes of your peers.`n`n",$city, true);
		addnav("`%Adony`0","newday.php?setrace=$race$resline");
		addnav("","newday.php?setrace=$race$resline");
		break;
	case "setrace":
		if ($session['user']['race']==$race){ // it helps if you capitalize correctly
			output("`3As an `%Adony`3, you often take the time to make yourself look your best.`n");
			output("After all, you want to be admired!`n`n");
                  output("Because of this, you gain `%charm`3 each day, but lose `@forest fights`3 because of your hard work!`n`n");
                  output("However, this does not go unrewarded!  Your good looks help to protect you in battle!`");
			if (is_module_active("cities")) {
				if ($session['user']['dragonkills']==0 &&
						$session['user']['age']==0){
					//new farmthing, set them to wandering around this city.
					set_module_setting("newest-$city",
							$session['user']['acctid'],"cities");
				}
				set_module_pref("homecity",$city,"cities");
				if ($session['user']['age'] == 0)
					$session['user']['location']=$city;
			}
		}
		break;
	case "newday":
		if ($session['user']['race']==$race){
			raceadony_checkcity();
                  $mincharmgain = get_module_setting("mincharmgain");
                  $maxcharmgain = get_module_setting("maxcharmgain");
                  $charmgain = e_rand($mincharmgain, $maxcharmgain);
                  $session['user']['charm'] += $charmgain;
                  $session['user']['turns'] -= $charmgain;
                  output("`n`&Looking into the mirror today, you are sure that few could resist your good looks!`n");
                  output("You feel `%charming`& and you take so much time admiring yourself that you lose `\$%s`& of your forest fights for today!`0`n", $charmgain);
			apply_buff("racialbenefit",array(
				"name"=>"`%Adony's Charm`0",
                        "badguydmgmod"=>(0.95-($charmgain / 20)),
				"allowinpvp"=>1,
				"allowintrain"=>1,
				"rounds"=>-1,
				"schema"=>"module-raceadony",
				)
			);
		}
		break;
     
	}

	return $args;
}

function raceadony_checkcity(){
	global $session;
	$race="Adony";
	if (is_module_active("racehuman")) {
		$city = get_module_setting("villagename", "racehuman");
	} else {
		$city = getsetting("villagename", LOCATION_FIELDS);
	}
	
	if ($session['user']['race']==$race && is_module_active("cities")){
		//if they're this race and their home city isn't right, set it up.
		if (get_module_pref("homecity","cities")!=$city){ //home city is wrong
			set_module_pref("homecity",$city,"cities");
		}
	}	
	return true;
}

function raceadony_run(){
}
?>
