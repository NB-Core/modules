<?php
/////// BY PETER CORCORAN \\\\\\\\
	global $session;
	$step = httpget('step');
	$op = httpget('op');
	if ($step=="battle"){
		require_once("lib/forestoutcomes.php");
		restore_buff_fields();
		$badguy = array();
		$badguy['creaturename']="An angry troll";
		$badguy['creatureweapon']="Huge Club";
		$badguy['creaturelevel']= $session['user']['level'];
		$badguy['creaturegold']=1000;
		$badguy['creatureexp'] = round($session['user']['experience']/10, 0);
		$badguy['creaturehealth']=$session['user']['maxhitpoints']-2;
		$badguy['creatureattack']=$session['user']['attack']-2;
		$badguy['creaturedefense']=$session['user']['defense']-2;
		calculate_buff_fields();
		$badguy['playerstarthp']=$session['user']['hitpoints'];
		$badguy['diddamage']=0;
		$badguy['type'] = 'quest';
		$session['user']['badguy']=createstring($badguy);
		$battle = true;
	} elseif ($op=="fight" || $op=="run"){
		$skill = httpget('skill');
		$f = httpget('f');
		if ($op == "run" && e_rand(1, 5) < 3) {
			// They managed to get away.
			page_header("Escape");
			output("You set off running through the forest at a breakneck pace heading back the way you came.`n`n");
			output("In your terror, you lose your way and become lost, losing time for a forest fight.`n`n");
			if ($session['user']['turns']>0) { $session['user']['turns']--; }
			output("After running for what seems like hours, you finally arrive back at %s.", $session['user']['location']);
			addnav(array("Enter %s",$session['user']['location']), "village.php");
        		$battle=false;
		} else {
			$battle = true;
		}
	}
	if ($battle){
		page_header("Clown Battle!");
		require_once("battle.php");
		if ($victory){
			require_once("lib/forestoutcomes.php");
			forestvictory($badguy,false);
			addnav("Well of Enutorf");
			addnav("Return to the forest","forest.php");
		}elseif ($defeat){
			output("`n`n`^It ate your Gold...`)");
			$session['user']['gold']=0;
			require_once("lib/forestoutcomes.php");
			forestdefeat($badguy,"in the deep dark forest");
		}else{
			require_once("lib/fightnav.php");
			fightnav(true,true,"runmodule.php?module=wellenutorf");
		}
	}
	page_footer();
?>