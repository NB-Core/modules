<?php
function blackjack_getmoduleinfo(){
	$info = array(
		"name"=>"BlackJack",
		"version"=>"2.0",
		"author"=>"`#Lonny Luberts",
		"category"=>"PQcomp",
		"download"=>"http://www.pqcomp.com/modules/mydownloads/visit.php?cid=3&lid=35",
		"vertxtloc"=>"http://www.pqcomp.com/",
		"prefs"=>array(
			"BlackJack User Preferences,title",
			"cards"=>"Cards,text",
			"dealt"=>"Cards Dealt,int",
			),
	);
	return $info;
}

function blackjack_install(){
	if (is_module_active('pqcasino')){
	if (!is_module_active('blackjack')){
		output("`4Installing BlackJack Module.`n");
		output("`4Card Images Distributed with Casino Module!`n");
	}else{
		output("`4Updating BlackJack Module.`n");
	}
	module_addhook("pqcasino");
	}else{
		output("`4Casino Module Not Installed NOT Hooking!`n");
		output("`4Card Images Distributed with Casino Module!`n");
	}
	return true;
}

function blackjack_uninstall(){
	output("`4Un-Installing BlackJack Module.`n");
	return true;
}

function blackjack_dohook($hookname,$args){
	addnav("BlackJack","runmodule.php?module=blackjack");
	return $args;
}

function blackjack_run(){
	global $SCRIPT_NAME;
	if ($SCRIPT_NAME == "runmodule.php"){
		$module=httpget("module");
		if ($module == "blackjack"){
			include("modules/lib/blackjack.php");
		}
	}
}
?>