<?php

//16092005
/* *******************
Codierung von Ray
Ideen von Ray
ICQ:230406044
******************* */

require_once "common.php";
addcommentary();


if ($_GET['op']==""){
    output("`#Du siehst einen gro�es Geb�ude das 5 eing�nge hat. Du gehst n�her heran um zu gucken was das f�r ein geb�ude ist jede t�r hat ihren eigene T�rsteher, die 5 T�ren sind f�r die 5 Rasseng�rten man darf nur in den Garten der f�r seine Rasse bestimmt ist.");

   if($session['user']['race']==1 || $session['user']['superuser']>=2) addnav("Garten der Trolle","racegarden.php?op=troll");
    if($session['user']['race']==2 || $session['user']['superuser']>=2) addnav("Garten der Elfe","racegarden.php?op=elf");
    if($session['user']['race']==3 || $session['user']['superuser']>=2) addnav("Garten der Menschen","racegarden.php?op=mensch");
    if($session['user']['race']==4 || $session['user']['superuser']>=2) addnav("Garten der Zwerge","racegarden.php?op=zwerg");
    if($session['user']['race']==5 || $session['user']['superuser']>=2) addnav("Garten der Echsen","racegarden.php?op=echse");

}else if ($_GET['op']=="troll"){
    output("Du betritts den Garten der Trolle und begr��t so gleich deine Kameraden.");

page_header("Sammelplatz der Trolle");

output("`n`n`%`@In der N�he reden einige Trolle:`n");
viewcommentary("trollgarden","Hinzuf�gen",25);


}else if ($_GET['op']=="elf"){
    output("Du betritts den Garten der Elfe und begr��t so gleich deine Kameraden.");

page_header("Sammelplatz der Elfen");

output("`n`n`%`@In der N�he reden einige Elfen:`n");
viewcommentary("elfgarden","Hinzuf�gen",25);


}else if ($_GET['op']=="mensch"){
      output("Du betritts den Garten der Menschen und begr��t so gleich deine Kameraden.");

page_header("Sammelplatz der Menschen");

output("`n`n`%`@In der N�he reden einige Menschen:`n");
viewcommentary("menschgarden","Hinzuf�gen",25);


}else if ($_GET['op']=="zwerg"){
      output("Du betritts den Garten der Zwerge und begr��t so gleich deine Kameraden.");

page_header("Sammelplatz der Zwerge");

output("`n`n`%`@In der N�he reden einige Zwerge:`n");
viewcommentary("zwerggarden","Hinzuf�gen",25);


}else if ($_GET['op']=="echse"){
      output("Du betritts den Garten der Echse und begr��t so gleich deine Kameraden.");

page_header("Sammelplatz der Echsen");

output("`n`n`%`@In der N�he reden einige Echsen:`n");
viewcommentary("echsengarden","Hinzuf�gen",25);

}
addnav("Zur�ck ins Dorf","village.php");
page_footer();
?>