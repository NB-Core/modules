<?php
/*
Module Name:  Alignment Events
Category:  Forest Specials
Worktitle:  alignmentevents
Author:  CortalUX, modified by DaveS
*/

function alignmentevents_getmoduleinfo(){
    $info = array(
        "name"=>"Alignment Events",
        "version"=>"2.0",
        "author"=>"`@CortalUX`7, modified by DaveS",
        "category"=>"Forest Specials",
	"download"=>"http://dragonprime.net/users/DaveS/alignmentevents.txt",
        "settings"=>array(
            "alignbad"=>"Alignment points lost being evil, int|1",
            "aligngood"=>"Alignment points gained for being good, int|1",
             ),
        "prefs"=>array(
        "Alignment Events - Preferences,title",
            "aligntried"=>"Had a chance to help someone this newday?,bool|0",
            "action"=>"Last Event seen,int|0",
            ),
        "requires"=>array(
            "alignment" => "1.13|WebPixie<br> `#Lonny Luberts<br>`^and Chris Vorndran, http://dragonprime.net/users/WebPixie/alignment98.zip",
            ),
    );
    return $info;
}

function alignmentevents_chance() {
    global $session;
    if (get_module_pref('aligntried','alignmentevents',$session['user']['acctid'])==1) return 0;
    return 100;
}

function alignmentevents_install(){
    module_addeventhook("forest","require_once(\"modules/alignmentevents.php\"); 
    return alignmentevents_chance();");
    module_addhook("newday");
    return true;
}

function alignmentevents_uninstall(){
    return true;
}

function alignmentevents_dohook($hookname,$args){
    global $session;
    switch ($hookname) {
        case "newday":
            set_module_pref("aligntried",0);
            break;
    }
    return $args;
}

function alignmentevents_runevent($type) {
    global $session;
    $op = httpget('op');

if ($op==""){
        global $session;
        $session['user']['specialinc']="module:alignmentevents";
        set_module_pref("action",0);
        addnav("Actions");
        addnav("Help","forest.php?op=help");
        addnav("Hinder","forest.php?op=hinder");
        addnav("Ignore","forest.php?op=ignore");

    switch(e_rand(1,5)){

        case 1:
            set_module_pref("action",1);
                    output("`n`@Walking around in the forest you rest in a convenient tree... waking up a bit later, you notice a clingy
                substance clinging to your face... feeling it, you realize it to be spider silk.`n`nAn enchanted spider
                approaches you, and explains that it didn't mean to scare you, but it and it's friends are trying to learn 
                to spin thread, and it is `%not`@ going well.`n");
                break;
        case 2:
            set_module_pref("action",2);
                    output("`n`^You stumble upon a frothing, raging, running river, and see a stranded fishing boat sinking slowly, yet
                held up slightly by a pile of rocks!`n`nThe boat is full of a worried looking crew, and they seem to notice
                you!`n`n`3 \"`&Help! Help!`3\"`^ they yell.`n");
                break;
        case 3:
            set_module_pref("action",3);
                    output("`n`#You wander across a group of children playing in a tree.  They cry out in fear as a branch begins to
                break.  It looks like one of them will fall!`n");
                break;
        case 4:
            set_module_pref("action",4);
                    output("`n`QA huge lion comes crashing through the forest. You notice he's limping! Since you've never seen a limping lion
                before, you find this quite amazing.  He comes to within a couple of feet and raises his front foot
                and you see a large thorn sticking out of it.`n");
                break;
        case 5:
            set_module_pref("action",5);
                    output("`n`%You come up to an open patch in the forest and see a young explorer yelling for help.  He's caught in
                quicksand and he's going down fast.`n");
                break;
        }
}
if ($op=="help"){
    output("`n`c`^You feel `@`bGOOD`b`^!`c`n");
       if (is_module_active('alignment')) {
          $align = get_module_setting("aligngood");
          set_module_pref("alignment",get_module_pref("alignment","alignment")+$align,"alignment");
          }
       if (get_module_pref("action")==1) {
          output("`@You walk around a bit more, seeking help for your spidery chums.`nEventually, you walk to the village, and buy them a knitting magazine!`n");
          }
       if (get_module_pref("action")==2) {
          output("`^You paddle across the raging river, with a rope- one end tied around you, the other upon the shore. When you land on the boat, 
          you tie your rope to it, and help the crew pull the boat to sure, by using their weight to stay in the boat, and pull the boat over.`n");
          }
       if (get_module_pref("action")==3) {
          output("`#With amazing agility, you run to capture the child as he falls from the tree and lands in your arms.  He runs off without saying 
          anything, but you know you saved him from a nasty injury!`n");
          }
       if (get_module_pref("action")==4) {
          output("`QFor some reason you feel a little mousy when you do this, but you pull out the thorn without any problems!  The lion smiles and walks away.`n");
          }
       if (get_module_pref("action")==5) {
          output("`%Using a long branch you safely pull the explorer to shore.  He shakes your hand gratefully and walks off into the forest.`n");
          }
}

if ($op=="hinder") {
   output("`n`c`^You feel more `\$`bEVIL`b`^!`c`n");
       if (is_module_active('alignment')) {
          $align = get_module_setting("alignbad");
          set_module_pref("alignment",get_module_pref("alignment","alignment")-$align,"alignment");
          }
       if (get_module_pref("action")==1) {
          output("`@You `%`ihate`i`@ spiders, and squash them!`n");
          }
       if (get_module_pref("action")==2) {
          output("`^You find it funny, and decide to sink the boat yourself!`n`nFinding a convenient rock, you lob it over the river, hitting one of
          the rocks beneath the boat, lowering it imperceptibly.`n");
          }
       if (get_module_pref("action")==3) {
          output("`#You start throwing rocks at the child.  You laugh as he falls and think about how sticks AND stones can break bones!`n");
          }
       if (get_module_pref("action")==4) {
          output("`QYou look at the poor lion and get an evil glint in your eyes.  You quickly jam the thorn deeper into his paw and run off
          to the forest looking for even MORE fun!`n");
          }
       if (get_module_pref("action")==5) {
          output("`%You tell him he can survive if he tries to swim really fast to you.  He sinks because of your bad advice and you smirk and wander off.`n");
          }
}
if ($op=="ignore"){
    output("`n`c`^You feel kinda `&`bNeutral`b`^ about the world.`n`n`%`c");
        if (get_module_pref("action")==1) {
           output("`@You ignore these freaky creatures, and walk off.`n");
           }
        if (get_module_pref("action")==2) {
           output("`^You ignore the yelling and walk off.`n");
           }  
        if (get_module_pref("action")==3) {
           output("`#Thinking that children have to learn from their mistakes, you walk off.`n");
           }
        if (get_module_pref("action")==4) {
           output("`QYou decide you don't even want to get involved in this fable and walk off.`n");
           }
        if (get_module_pref("action")==5) {
           output("`%Figuring that at least you know how to identify quicksand now, you walk off.`n");
           } 
}
}
function alignmentevents_leave(){

}
?>