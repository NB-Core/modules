<? 
/********************
Gorlock - 
Written by Robert for Maddnet LoGD
Gorlock trades possessions for favor
original:Feb2004
modified: June2004
***modified to make cheating no longer possible
You will need to create a Devils Imp via your mount editor: 
attk=1.02 def=1.02, rounds=40, fight message=The Devils Imp watches you as you fight! - 
Then deactivate the mount and get mount ID # for $session [user][hashorse] = ? ; 
replace the ? with your Devils Imp ID number OR you can replace the ? with a 0 for no mount. 
Devils Imp mount was added to give humor.

You need to add a link to gorlock.php in your graveyard.php:
Line 120 or near there find: addnav("Return to the shades","shades.php");
ADD THIS: under it ->	addnav("Talk to Gorlock","gorlock.php");
// If you use Gems in Bank Add: $session[user][goldinbank] = 0; to the list
*********************/
require_once "common.php";  
checkday();
page_header("Graveyard");
output("`c<font size='+1'>`4Gorlock - Lord of Death</font>`c`n`n",true);
if ($HTTP_GET_VARS[op]==""){ 
      output("`7You approach `4Gorlock `7before a pedestal of brimestone.`n");
      output(" Sad and desperate, you're willing to make a deal with . . .`i the devil`i. `n"); 
      output(" `4Gorlock `7will grant you `&Life `7but you must pay with ALL your possessions. `n"); 
      output(" `bYou will lose ALL your gold, gems, weapons and armor -`i you will start a new day with nothing!`i`b `n`n"); 
      output(" You now think about waiting for a new day, deal with `4Ramius `7or `blose everything to `4Gorlock`b`7. `n"); 
      output(" The choice is yours. `n"); 
      addnav("Sell your Soul"); 
      addnav("(M) Make the deal","gorlock.php?op=agree"); 
      addnav("Leave");
      addnav("(R) Never mind","graveyard.php"); 
      
}else if ($HTTP_GET_VARS[op]=="agree"){ 
 
      output(" `n`7You made a deal with the Devil, `4Gorlock`7!.`n"); 
      output(" `n`b`7You agreed to give `4Gorlock `7ALL of your worldly possessions.`b`n"); 
      output(" You lose ALL your Gems, Gold, Gold in Bank, Weapon and Armor. `n`n "); 
      output(" `bFor making a deal with the `4Devil`7, you also lost ALL your charm.`b`n`n"); 
      output(" `4Gorlock `7makes an arrangement with `4Ramius `7to have you resurected.`n`n"); 
      output(" You will get resurected by `4Ramius `7- you will have NO possessions but you'll be alive!.`n`n"); 
      addnav("Start the New Day");
      addnav("(R) Resurrection","newday.php?resurrection=true");
        $newweapon = "Fists";
        $newarmor = "T-Shirt";
        $session[user][gems] = 0; 
        $session[user][gold] = 1; 
        $session[user][charm] = 1; 
        $session[user][defence] = 1; 
        $session[user][attack] = 1; 
        $session[user][goldinbank] = 0; 
        $session[user][armordef] = 0;
        $session[user][armor]= $newarmor;
        $session[user][armorvalue] = 0;
        $session[user][weapondmg] = 0;
        $session[user][weapon]= $newweapon;
        $session[user][weaponvalue] = 0;
        $session[user][hashorse] = 41;
        debuglog("gave ALL possessions, gems and gold to Gorlock"); 
        addnews("`4Not cool!, " . ($session['user']['name']) . " `7gives ALL gems, gold and possessions to `4Gorlock`7.`0 "); 

    }
page_footer();
?>