<?php

function gravegem_getmoduleinfo(){
	$info = array(
		"name"=>"Grave Gem",
		"version"=>"1.0",
		"author"=>"`^Harry Balzitch",
		"category"=>"Graveyard Specials",
		"download"=>"http://dragonprime.net/users/Harry%20B/gravegem.zip",
	);
	return $info;
}

function gravegem_install(){
	module_addeventhook("graveyard", "return 100;");
	return true;
}

function gravegem_uninstall(){
	return true;
}

function gravegem_dohook($hookname,$args){
	return $args;
}

function gravegem_runevent($type)
{
	global $session;
	output("`^As you travel through the graveyard, you spot shiny stones on the ground ahead.`n");
	output(" Walking towards it, you pick up a few gems.`n");
	$session['user']['gems']+=6;
}

function gravegem_run(){
}
?>