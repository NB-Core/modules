<?php

function advcf_getmoduleinfo(){
	$info = array(
		"name"=>"Advanced Commentary Functions",
		"author"=>"Chris Vorndran",
		"version"=>"0.12",
		"category"=>"Administrative",
		"download"=>"http://dragonprime.net/index.php?module=Downloads;sa=dlview;id=49",
		"vertxtloc"=>"http://dragonprime.net/users/Sichae/",
		"description"=>"Allows users that have access to it, to be able to wipe entire sections of Commentary.",
			"settings"=>array(
				"Adv. Commentary Functions Settings,title",
				"access"=>"User preffed characters have access?,bool|1",
				"delall"=>"Can all comments be deleted?,bool|0",
			),
			"prefs"=>array(
				"Adv. Commentary Functions Pref,title",
				"boo"=>"Has access to Advanced Commentary Functions?,bool|0",
			),
		);
	return $info;
}
function advcf_install(){
	module_addhook("superuser");
	return true;
	}
function advcf_uninstall(){
	return true;
}
function advcf_dohook($hookname,$args){
	global $session;
	switch ($hookname){
		case "superuser":
			if ($session['user']['superuser'] & SU_MEGAUSER || (get_module_setting("access") == 1 && get_module_pref("boo") == 1)){
				addnav("Mechanics");
				addnav("Adv. Commentary Functions","runmodule.php?module=advcf&op=enter");
			}
			break;
		}
	return $args;
}
function advcf_run(){
	global $session;
	$op = httpget('op');
	$extra = httpget('extra');
	$section = httppost('section');
	page_header("Advanced Commentary Functions");

	switch ($op){
		case "enter":
			if ($section != ""){
				$sql = "DELETE FROM ".db_prefix("commentary")." WHERE section='$section'";
				db_query($sql);
				rawoutput("<big>");
				output("`c`^`bAll commentary in the section: `#%s`^, has been deleted.",$section);
				output("Have a good day.`b`c`0`n`n");
				rawoutput("</big>");
			}
			if ($extra == "all") db_query("DELETE FROM ".db_prefix("commentary")."");
			$sql = "SELECT DISTINCT section FROM ".db_prefix("commentary")."";
			$res = db_query($sql);
			$msg = translate_inline("Select");
			if (db_num_rows($res) >= 1){
				rawoutput("<center>");
				rawoutput("<big>");
				output("`b`#Select the area of commentary, to which you wish to delete all entries in the database.");
				output("Please note, these changes are irreversable.`b`n`n`0");
				rawoutput("</big>");
				rawoutput("<form action='runmodule.php?module=advcf&op=enter' method='POST'>");
				rawoutput("<select name='section' class='input'>");
				while($row = db_fetch_assoc($res)){
					$sec = $row['section'];
					rawoutput("<option value=\"".HTMLEntities($sec)."\">".full_sanitize($sec)."</option>");
				}
				rawoutput("</select><input type='submit' class='button' value='$msg'></form>",true);
				rawoutput("</center>");
			}else{
				rawoutput("<big>");
				output("`b`@I am sorry, but all commentary has been deleted from all areas.`b`0");
				rawoutput("</big>");
			}
		if (get_module_setting("delall")) addnav("Delete All Commentary","runmodule.php?module=advcf&op=enter&extra=all");
		addnav("Return to the Grotto","superuser.php");
		addnav("","runmodule.php?module=advcf&op=enter");
		break;
	}
page_footer();
}
?>