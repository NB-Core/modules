<?php
/*
Des is mein Haus. Modul Idee von Landfloh

Versions-History

0.1 		erster Versuchsballon
1.0		ok, ganz so schlimm musses ja nicht sein. waldkampfplus eingebaut. 
1.1		Schreibfehler entfernt ;-)))

*/
if (is_module_active('alignment')) require_once("modules/alignment.php");
require_once('lib/e_rand.php');
require_once("lib/http.php");
$from = "forest.php?";
$op = httpget('op');

function vonrohr_getmoduleinfo(){
	$info = array(
		"name"=>"vonrohr",
		"author"=>"`)Landfloh",
		"version"=>"1.0",
		"category"=>"Lenny's Modules",
		"download"=>"nur auf Anfrage",
	);
	return $info;
}

function vonrohr_install(){
	module_addeventhook("forest", "return 100;");
	return true;
}
function vonrohr_uninstall(){
	return true;
}

function vonrohr_dohook($hookname,$args){
	return $args;
}

function vonrohr_runevent($type){


	global $session;
	$loose = e_rand(1,100);
	
	
	
	output("`^Wie du so durch den Wald streifst - nichtsahnend - triffst du auf zwei idiotisch herumh�pfende Gestalten. Es handelt sich um Roman Kilchsperger und Chris vonRohr. `n`n");
	output("`^Sie entdecken dich und kommen auf dich zugeh�pft. `n`n\"D�rfen wir dir unser Programm vorf�hren?`^\" fragen sie dich, und glotzen dich erwartungsvoll mit hoffnungsvollem Blick an.");
	output("Du hast jedoch bereits von deren Kunstfertigkeit, das Publikum einzuschl�fern, geh�rt - denn nichts verbreitet sich so schnell wie schlechte Schlagzeile im `2Hinterzimmer K�sblatt`^ - und hast nicht die geringste Lust, dir sowas anzutun.");
	output("Jedoch ist dein Herz auch nicht aus Stein, du setzt dich hin, und wartest darauf, dass die zwei mit ihrer Darbietung beginnen.");
	output("`n`nEs kommt was du erwartet hast. Die schlechteste Darbietung aller Zeiten. Innerlich weinend ringst du dich jedoch dazu durch, alles bis ans Ende anzusehen.");
	
	addnav("Akzeptiere dein Schicksal...");
	

	
	if ($loose >= 1 && $loose <= 10) {
		$session['user']['gold']=0;
		output("`6`n`nNEIN!!! Sowas h�lt kein Schwein aus, findest du, und fl�chtest so schnell wie du kannst in den tiefen Wald zur�ck. Du stolperst, rappelst dich wieder auf, und bemerkst nicht, dass du deinen Beutel mit Dukaten verloren hast.");
	}
	if ($loose >= 11 && $loose <= 20) {
		$session['user']['charm']=round($session['user']['charm']*0.75);
		output("`6`n`nErfolglosigkeit macht unattraktiv, und die Erfolglosigkeit der zweien f�rbt auch auf dich ab. Du verlierst an Charme.");
		
	}
	if ($loose >= 21 && $loose <= 30) {
		$session['user']['alive']=false;
		$session['user']['hitpoints']=0;
		output("`6`n`nW�hrend der Darbietung langweilst du dich zu tode. Du stirbst den G�hntod...");
		output("`4`n`nDu bist Tot.");
		addnav("T�gliche News","news.php");
		addnews("%s ist vor Langeweile gestorben und weilt nun unter den Toten!",$session['user']['name']);
	}
	if ($loose >= 31 && $loose <= 40) {
		$session['user']['turns']=0;
		output("`6`n`nDas Programm der zweien frustriert dich zu sehr. Du bist deprimiert, gelangweilt, ange�det, und hast deswegen keine Lust mehr, heute auch nur irgendeinen Waldkampf noch zu bestreiten.");
	}
	if ($loose >= 41 && $loose <= 50) {
		$session['user']['hitpoints']=1;
		output("`6`n`nDie Darbietung nervt dich dermassen, dass du beginnst, Vogelbeeren zu pfl�cken und diese zu essen. Sogar der Tod ist sch�ner als dieses idiotische Getue anzugucken, und du w�nschst dir, dass du stirbst.");
		output("`6Jedoch reicht es nicht ganz, aber du handelst dir eine geh�rige Vergiftung ein.");
		output("`6Du verlierst fast alle Lebenspunkte.");
		output("`6`n`nMit h�llischen Magenschmerzen kriechst du davon....`n`n");
		
	}
	if ($loose >= 51 && $loose <= 60) {
		$session['user']['turns']=$session['user']['turns']+2;
		output("`6`n`nEin Mitbewohner des Waldes - der w�tende Oger - wird Zeuge des Geschehens. Der l�sst sich dieses herumgenerve aber nicht gefallen und erschl�gt die beiden kurzerhand.");
		output("`6Du schaust vergn�gt zu. Spass ist immer noch der beste Motivationsfaktor - du erh�ltst zwei Waldk�mpfe.");
		
	}
	if ($loose >= 61 && $loose <= 70) {
		$session['user']['experience']*=0.8;
		output("`6`n`nTraumatisierende Erlebnisse haben stets etwas neurotisches an sich.");
		output("`6Du verlierst einige Erfahrungspunkte, da du diesen Tag - nein die ganze Woche - aus deinem Ged�chtnis streichen willst.");
	}
	if ($loose >= 71 && $loose <= 80) {
		$session['user']['deathpower']=0;
		output("`6`n`nDir ist zum heulen zumute. In deiner Verzweiflung versuchst du, die zwei umzubringen. Du willst gerade mit deiner Waffe zuschlagen, als");
		output("`6`4Ramius`6 h�chstpers�nlich erscheint, in einer dunkelroten, beissenden Wolke. Er spricht mit donnernder Stimme:");
		output("^\$Hast du etwa das Gef�hl, ich will die zwei bei mir unten? Nein, ich weiss das zu verhindern, sowas kommt mir nicht in meine H�hlen!`n Du missf�llst mir aufs �usserste, und das werd ich dir nicht vergessen, duuu...\"");
		output("`6`n`nRamius rauscht wieder ab, und du weisst... deine Gefallen bei ihm sind soeben verfallen...");
	}
	if ($loose >= 81 && $loose <= 90) {
		if (is_module_active('alignment')) align("-5");
		output("`6`n`nNein, nein, und nochmals nein. Dich packt eine Wut, und du beginnst, auf die zwei einzupr�geln.");
		output("`6Wie du dich an ihren Gesichtern v�llig verausgabt hast, f�hlst du dich zwar zufrieden und gl�cklich, jedoch deine Gesinnung leidet... ");
		output("`6Du bist `\$B�se.");
	}
	if ($loose >= 91 && $loose <= 95) {
		$session['user']['turns']-=2;
		output("`6`n`nNach kurzer Zeit ist es auch schon dabei. Die zwei gucken dich erneut erwartungsvoll an, wohl solltest du Beifall spenden.");
		output("`6`n`nFast heulend vor Verzweiflung hast du jedoch das Ende der Darbietung sehnlichst erwartet. Du springst auf, und rennst schreiend davon in den Wald zur�ck...");
		output("`6`nDie zwei Dorfdeppen haben dich deine Nerven und zwei Waldk�mpfe gekostet.");
	}
	if ($loose >= 96 && $loose <= 100) {
		$session['user']['hitpoints']-=$session['user']['hitpoints']*0.5;
		output("`6`n`nDu raufst dir die Haare. Das ist ja kaum auszuhalten, was die zwei da umherstussen.");
		output("`6`n`nLeider gilt Haareraufen als eine der anstrengenderen T�tigkeiten, und du wirst sehr m�de.");
	}	

	return $args;
}	
function vonrohr_run(){
}
?>