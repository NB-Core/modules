<?php
/********************************************************
Additional quests for Sneakabout's awesome quest module
Originating author - Sneakabout (core module)
Additional quests - Lightbringer
********************************************************/

//Requires - necessary for ensuring functionality of the module
require_once("lib/http.php");
require_once("lib/villagenav.php");
//Module Information - this is the info about the module - eg Module name, author, version etc
function dagquests_getmoduleinfo(){
//Declaring the array and storing it as $info
	$info = array(
		"name"=>"Dag's Quests",
		"version"=>"1.0",
		"author"=>"Sneakabout - additional quests by Lightbringer",
		"category"=>"Quest",
		"download"=>"core_module",
//Module Settings - listed in an array and parsed with the return $info at the end
                "settings"=>array(
//Admin Settings for quest one
                        "Minotaur Quest Settings,title",
			"qonerewardgold"=>"What is the gold reward for the Minotaur Quest?,int|1000",
			"qonerewardgems"=>"What is the gem reward for the Minotaur Quest?,int|2",
			"qoneexperience"=>"What is the quest experience multiplier for the Minotaur Quest?,floatrange,1.01,1.1,0.01|1.04",
			"qoneminlevel"=>"What is the minimum level for this quest?,range,1,15|5",
			"qonemaxlevel"=>"What is the maximum level for this quest?,range,1,15|9",
//Admin Settings for quest two
                        "Manticore Quest Settings,title",
			"qtworewardgold"=>"What is the gold reward for the Manticore Quest?,int|2000",
			"qtworewardgems"=>"What is the gem reward for the Manticore Quest?,int|3",
			"qtwoexperience"=>"What is the quest experience multiplier for the Manticore Quest?,floatrange,1.01,1.2,0.01|1.1",
			"qtwominlevel"=>"What is the minimum level for this quest?,range,1,15|10",
			"qtwomaxlevel"=>"What is the maximum level for this quest?,range,1,15|14",
//Admin Settings for quest three (Lightbringer)
                        "Dracolich Quest Settings,tile",
                        "qthreerewardgold"=>"What is the gold reward for the Dracolich Quest?,int|3000",
                        "qthreerewardgems"=>"What is the gem reward for the Dracolich Quest?,int|4",
                        "qthreeexperience"=>"What is the quest experience multiplier for the Dracolich Quest?,floatrange,1.01,1.3,0.01|1.2",
                        "qthreeminlevel"=>"What is the minimum level for this quest?,range,1,15|12",
                        "qthreemaxlevel"=>"What is the maximum level for this quest?,range,1,15|14",
		),
//Now here is where we set the prefs
		"prefs"=>array(
//Prefs for quest one - setting the qonestatus and qtwostatus up on the DB
            "qonestatus"=>"How far in the Minotaur Quest has the player got?,int|0",
            "qtwostatus"=>"How far in the Manticore Quest has the player got?,int|0",
            "qthreestatus"=>"How far in the Dracolich Quest has the player got?,int|0",
        ),
	);
//Now we need to return the string '$info'
	return $info;
}

//This is where the quest is installed - and the module hooks added
function dagquests_install(){
	module_addhook("village");
	module_addhook("dragonkilltext");
	module_addhook("newday");
	module_addhook("footer-runmodule");
	return true;
}

//This is pretty self-explanatory
function dagquests_uninstall(){
	return true;
}

//The do hooks - all of the hooks that have been added in the install are dealt with here
function dagquests_dohook($hookname,$args){
	global $session;
	switch ($hookname) {

//module_addhook("village");
	case "village":
		if ($session['user']['location']==
				getsetting("villagename", LOCATION_FIELDS)) {
			tlschema($args['schemas']['gatenav']);
			addnav($args['gatenav']);
			tlschema();
                        //Quest one status check
                        if (get_module_pref("qonestatus")==1 &&
					$session['user']['turns'] >= 1) {
				addnav("Search the Caves (1 turn)",
						"runmodule.php?module=dagquests&op=searchone");
                        //Quest two status check
                        } elseif (get_module_pref("qtwostatus")==1 &&
					$session['user']['turns'] >= 1) {
				addnav("Search the Trails (1 turn)",
						"runmodule.php?module=dagquests&op=searchtwo");
                        //Quest three status check
                        } elseif (get_module_pref("qthreestatus")==1 &&
                                        $session['user']['turns'] >=1   {
                                addnav("Scour the Aerie (1 turn)",
                                                "runmodule.php?module=dagquests&op=searchthree");
		}
		break;

//module_addhook("dragonkilltext");
	case "dragonkilltext":
                //Set the prefs for quests on DK here
                set_module_pref("qonestatus",0);
		set_module_pref("qtwostatus",0);
		set_module_pref("qthreestatus",0);
		break;

//module_addhook("newday");
        case "newday":
                //Check for player level cross-referencing admin settings...quest one
                if (get_module_pref("qonestatus")==1 &&
				$session['user']['level']>get_module_setting("qonemaxlevel")) {
			set_module_pref("qonestatus",4);
			output("`n`6You hear that another adventurer defeated the Minotaur plaguing the Caves.`0`n");
		}
                //Check for player level cross-referencing admin settings...quest two
                if (get_module_pref("qtwostatus")==1 &&
				$session['user']['level']>get_module_setting("qtwomaxlevel")) {
			set_module_pref("qtwostatus",4);
			output("`n`6You hear that another adventurer defeated the Manticore which had slaughtered the travellers.`0`n");
		}
		if (get_module_pref("qthreestatus")==1 &&
				$session['user']['level']>get_module_setting("qthreemaxlevel")) {
			set_module_pref("qthreestatus",4);
			output("`n`6You hear that another adventurer defeated the Dracolich that had been snatching up the villagers.`0`n");
		break;

//module_addhook("footer-runmodule");
        case "footer-runmodule":
		$op=httpget("op");
		$module=httpget("module");
		if (!$op &&  $module=="dag" &&
				httpget("manage")!="true") {
			addnav("Ask About Special Bounties",
					"runmodule.php?module=dagquests&op=askquest");
		}
		break;
	}
        //Parse the do hooks
        return $args;
}

//Use this if you need to...
function dagquests_runevent($type) {
}

//Here is the nitty gritty of the entire quest module - this is where it all goes down - first is the acknowledgement of the quest
function dagquests_run(){
//Lets make the session global
	global $session;
        //Declare an operation
        $op = httpget('op');
	//Declare that there are multiple ops which require further info to continue - hence the cases
	switch($op){
        //Here is where the user enquires about the quest/s
        case "askquest":
                //Retrieve and parse the inn name and location
                $iname = getsetting("innname", LOCATION_INN);
                //Use the inn name as the page title
                page_header($iname);
                //Set span style color to #9900FF
                rawoutput("<span style='color: #9900FF'>");
                //Unsure of the following - will need to enquire regarding the following few lines
                output_notl("`c`b");
		output($iname);
		output_notl("`b`c");
                //Store the module settings of quest one min and max level in strings ($onemin, $onemax)
                $onemin=get_module_setting("qoneminlevel");
		$onemax=get_module_setting("qonemaxlevel");
                //Store the module settings of quest two min and max level in strings ($twomin, $twomax)
                $twomin=get_module_setting("qtwominlevel");
		$twomax=get_module_setting("qtwomaxlevel");
		//Store the module settings of quest three min and max level in strings ($threemin, $threemax)
		$threemin=get_module_setting("qthreeminlevel");
                $threemax=get_module_setting("qthreemaxlevel");
                //This is the user asking about the job - handy for sense of involvement
                output("`3You lean over the table to Dag to inquire if there are any jobs for you to do.");
                //Conditions checked for ($onemin, $twomin and $threemin) and in this case failing
                if ($session['user']['level']<$onemin &&
		$session['user']['level']<$twomin) &&
                $session['user']['level']<$threemin{
			output("He seems very busy, and when you ask him about work, he simply shakes his head and explains that his current problems are too tough for you.");
                //Conditions for $onemin and $twomin are met - now check for $onemax
                } elseif ($onemin<=$session['user']['level'] &&
				$session['user']['level']<=$onemax &&
                                //Conditions for $onemax met
                		!get_module_pref("qonestatus")) {
			output("He seems very busy, but when you ask him about work, he looks at you carefully and motions you closer.`n`n");
			output("\"Aye, there be something ye might be helpin' me wit'.... there be rumours of a half-man beast that be preyin' on adventurers. It be operatin' from a nearby cave. It seems t' be reasonably smart, and the normal guards ain't bein' the sort to take the thing on. Ye look like ye can handle yerself, and there be a bounty from one o' the relatives if'n yer interested.  Do ye be takin' the job?\"`n`n");
			output("It almost crosses your mind to wonder why Dag would be offering this to you, but the caves aren't that far away after all.");
			output("It shouldn't be any problem to search them.");
                        //Success! The user can progress on quest 1
                        addnav("Take the Job",
					"runmodule.php?module=dagquests&op=qonetake");
                //Conditions for $onemin and $twomin are met - now check for $twomax
                } elseif ($twomin<=$session['user']['level'] &&
				$session['user']['level']<=$twomax &&
                                //Conditions for $twomax met
                                !get_module_pref("qtwostatus")) {
			output("He seems very busy, but when you ask him about work, he nods and leans in closer.`n`n");
			output("\"Yer just the person I be needin'. There be a wagon found destroyed, the sides filled with spikes. The survivor be tellin' the tale o' the trouble. I figger one manticore, maybe more, t' be claimin' that trail fer their territory. They be very aggressive, so ye should be havin' no trouble findin' the beasts, and yer trained well enough that I be willin' t' trust this t' ye. There be no bounty though 'cause we ain't let the information get out, but the wagon owner be killed in th' attack, so whatever ye find at the scene ye can keep.  Do ye be wantin' t' take on the beast?\"");
			output("You almost take a full second to consider how mean this creature might be, but you're a hero after all.");
			output("How hard could killing some small monster blocking the trails be?");
                        //Success! The user can progress on quest 2
                        addnav("Take the Job",
					"runmodule.php?module=dagquests&op=qtwotake");
                //Conditions for $onemin and $twomin are met - now check for $threemax
                } elseif ($threemin<=$session['user']['level'] &&
				$session['user']['level']<=$threemax &&
                                //Conditions for $threemax met
                                !get_module_pref("qthreestatus")) {
			output("He seems very busy, but when you ask him about work, he nods and leans in closer.`n`n");
			output("\"Mayhaps there is, my good friend...If'n yer interested in facin' a rather vicious-like foe which - in death - is meaner and nastier than it was in life\"");
			output("A shiver runs down at the implications of his words but you consider the idea of a reward appealing.");
			output("Heh...what doesn't kill you only makes you stronger..");
                        //Success! The user can progress on quest 3
                        addnav("Take the Job",
					"runmodule.php?module=dagquests&op=qthreetake");
                //Just in case
                } else {
			output("He seems very busy, and says he has no special bounties available at the moment.");
		}
		addnav("I?Return to the Inn","inn.php");
		rawoutput("</span>");
		break;
        //Progress the user to the first stage of quest one
        case "qonetake":
                //Once again, we need to retrieve the inn information
                $iname = getsetting("innname", LOCATION_INN);
		page_header($iname);
		rawoutput("<span style='color: #9900FF'>");
		output_notl("`c`b");
		output($iname);
		output_notl("`b`c");
                //Dag tells the user a little about the quest
                output("`3Dag nods, and gives you directions to the rough area the beast has been seen in, as well as a description of a bull-headed humanoid, tough and strong.");
		output("You leave the table, ready to seek out the beast.");
                //Set the user's pref 'qonestatus' to 1
                set_module_pref("qonestatus",1);
                //Let em out ;)
                addnav("I?Return to the Inn","inn.php");
		rawoutput("</span>");
		break;
        //Progress the user to the first stage of quest 2
        case "qtwotake":
                //Retrieve inn information
                $iname = getsetting("innname", LOCATION_INN);
		page_header($iname);
		rawoutput("<span style='color: #9900FF'>");
		output_notl("`c`b");
		output($iname);
		output_notl("`b`c");
                //Dag tells the user a little about the quest
                output("`3Dag nods, and tells you which trail the caravan was lost down.");
		output("He advises you to prepare before you go for the monster.");
                ////Set the user's pref 'qtwostatus' to 1
                set_module_pref("qtwostatus",1);
                //Let em out
                addnav("I?Return to the Inn","inn.php");
		rawoutput("</span>");
        	break;
        	//Progress the user to the first stage of quest 3
        case "qthreetake":
                //Retrieve inn information
                $iname = getsetting("innname", LOCATION_INN);
		page_header($iname);
		rawoutput("<span style='color: #9900FF'>");
		output_notl("`c`b");
		output($iname);
		output_notl("`b`c");
                //Dag tells the user a little about the quest
                output("`3Dag nods, and tells you how to find the mountain aerie lair of the hideous undead creature.");
		output("You nod briefly and gather your equipment for a mission to the mountains.");
                ////Set the user's pref 'qthreetatus' to 1
                set_module_pref("qthreestatus",1);
                //Let em out
                addnav("I?Return to the Inn","inn.php");
		rawoutput("</span>");
        	break;
        //Searching for quest 1
        case "searchone":
                //Title the page 'The Caves'
                page_header("The Caves");
                //User needs to know what the hell is going on ;)
                output("`2You hike up to the area riddled with caves, and start to check them out individually for traces of the beast.`n`n");
		$session['user']['turns']--;
                //There is multiple events for this area - they need to be randomised
                $rand=e_rand(1,10);
		switch($rand){
                //The first two cases are pretty much non-events
                case 1:
                case 2:
			output("You search through the caves for a while, finding nothing but bleached bones and dust.");
			output("Dispirited after a few hours, you trudge back to the town and look for something else to do.");
			villagenav();
			break;
                //Following two cases are an injured traveller
                case 3:
		case 4:
			output("You wander through the caves for a while, eventually hearing some cries for help from a distance.");
			output("You rush over, and find and injured traveller who had been attempting to travel across the countryside.");
			output("Spikes protude from his chest, and he is obviously mortally wounded - you do your best, but he dies after choking something about an attack from a powerful monster.");
			output("You hurry back to town, watching your back for whatever attacked the traveller.");
			villagenav();
			break;
                //This one is a 'find gem' event
                case 5:
			output("You wander through the caves for a while, finding that tracking something across rock is extremely difficult.");
			output("While looking in vain through an empty cave, you discover intricate patterns carved into the rock!");
			output("However, you're more interested in the gem embedded in the rock, and you pry it our as a souvenir before returning to town.");
			debuglog("gained a gem from an ancient cave");
			$session['user']['gems']++;
			villagenav();
			break;
                //A lion fight (dealt with later)
                case 6:
			output("You wander through the caves for a while before hearing a roar from the top of a nearby outcropping!");
			output("A mountain lion has spotted you, and bounds towards you, snarling.");
			output("You have nowhere to run to, so you ready your %s`2 to fight!",$session['user']['weapon']);
			addnav("Fight the Lion","runmodule.php?module=dagquests&fight=lionfight");
			break;
                //Minotaur fight (dealt with later)
                case 7:
		case 8:
		case 9:
		case 10:
			output("You wander through the caves for a while before finding a trail of blood from a dropped backpack.");
			output("You rush following the trail across the rocks to a sandy outcrop where you can see the minotaur, gorging on the body of the dead traveller in front of a small cave.");
			output("The beast sniffs the air, and you know you have been detected - you draw your %s`2 and charge down as the beast prepares with it's club, snarling all the while.",$session['user']['weapon']);
			addnav("Fight the Minotaur","runmodule.php?module=dagquests&fight=minotaurfight");
			break;
		}
		break;
        //Searching for quest two
        case "searchtwo":
                //Title the page 'The Trails' - mainly to differentiate between the two quests
                page_header("The Trails");
                //Let the user know what is going on
                output("`2You hitch a ride with a wagon, and they drop you off at the start of the trail, leaving you to walk the remaining distance on your own.");
		$session['user']['turns']--;
		output("You start down the trail, looking for the remains of the wagon.");
                //There is multiple events for this area - they need to be randomised
                $rand=e_rand(1,7);
		switch($rand){
                //First two cases are non-events as such
                case 1:
		case 2:
			output("You walk down the trail, eyes peeled, strung tight for ages, until you spot a wagon travelling towards you.");
			output("Confused, as you thought this part of the trail was closed until the threat had been dealt with, you hail the driver, only to find that you were left at the wrong trail!`n`n");
			output("Fortunately he is kind enough to give you a lift back to town and you return, your time wasted.");
			villagenav();
			break;
                //Wolf fight (dealt with later)
                case 3:
		case 4:
			output("You walk down the trail, eyes peeled, strung tight for ages, until you spot what seems to be the caravan in the distance.");
			output("However, as you drop your guard to move closer you hear a howl to your left and you back away as a grey wolf stalks towards you!");
			output("You must ready your %s`2 to defend yourself!",$session['user']['weapon']);
			addnav("Fight the Wolf","runmodule.php?module=dagquests&fight=wolffight");
			break;
                //Manticore fight (dealt with later)
                case 5:
		case 6:
		case 7:
			output("You walk down the trail, eyes peeled, strung tight for ages, until you spot what seems to be the wagon in the distance.");
			output("Remaining careful, you circle round, and spot the hideous creature lying in wait by the side of the road, spiked tail waving as it awaits its prey.");
			output("You charge the monster, which whips around to face you and hisses before pouncing with its terrible claws!");
			addnav("Fight the Manticore","runmodule.php?module=dagquests&fight=manticorefight");
			break;
		}
		break;
	//Searching for quest three
	case "searchthree":
                //Title the page 'The Trails' - mainly to differentiate between the two quests
                page_header("The Mountain Aerie");
                //Let the user know what is going on
                output("`2You trek deep into the mountaiun range and attempt to locate the fell beast.");
		$session['user']['turns']--;
		output("You start up the mountain, looking for the particular aerie that was made home by the beast.");
                //There is multiple events for this area - they need to be randomised
                $rand=e_rand(1,7);
		switch($rand){
                //First two cases are non-events as such
                case 1:
		case 2:
			output("You climb to the peak of a large mountain. The strenuous task of climbing has left you panting.");
			output("Peering around, you are unable to locate the aerie in question...`n`n");
			output("Dejected, you head back down to the village, upset at the wasting of so much of your time.");
			villagenav();
			break;
                //Basilisk fight (dealt with later)
                case 3:
		case 4:
			output("You climb to the peak of a large mountain. The strenuous task of climbing has left you panting.");
			output("However, as you fail to locate what you seek and start to turn back towards the village - an eerie hiss quickly draws your attention...");
			output("You must ready your %s`2 to defend yourself!",$session['user']['weapon']);
			addnav("Fight the Basilisk","runmodule.php?module=dagquests&fight=basiliskfight");
			break;
                //Dracolich fight (dealt with later)
                case 5:
		case 6:
		case 7:
			output("You climb to the peak of a large mountain. The strenuous task of climbing has left you panting.");
			output("Ever vigilant - you feel more than see the presence of a hideous and grotesque undead dragon.");
			output("You charge the monster, which regards you with its vacant orbs and howls superenaturally before belching forth its destructive breath weapon!");
			addnav("Fight the Dracolich","runmodule.php?module=dagquests&fight=dracolichfight");
			break;
		}
		break;
	}
        //Now for setting up the aforementioned fights
        $fight=httpget("fight");
	switch($fight){
        //Lion fight - quest one
        case "lionfight":
                //This sets the lion's abilities, fighting prowess, etc
                $badguy = array(
			"creaturename"=>"Lion",
			"creaturelevel"=>$session['user']['level']-1,
			"creatureweapon"=>"Savage Claws",
			"creatureattack"=>$session['user']['attack'],
			"creaturedefense"=>round($session['user']['defense']*0.8, 0),
			"creaturehealth"=>round($session['user']['maxhitpoints']*0.9, 0), 
			"diddamage"=>0,
			"type"=>"quest"
		);
		$session['user']['badguy']=createstring($badguy);
		$battle=true;
		// Drop through
	case "lionfighting":
                //Lion fight venue
                page_header("The Caves");
                //Let the game know this is a fight
                require_once("lib/fightnav.php");
		include("battle.php");
                //Effect of victory
                if ($victory) {
			output("`2The lion collapses on the ground, bleeding from its wounds.");
			output("You quickly flee the scene, hoping that there are not more of them around.");
			$expgain=round($session['user']['experience']*(e_rand(1,2)*0.01));
			$session['user']['experience']+=$expgain;
			output("`n`n`&You gain %s experience from this fight!",$expgain);
			output("`2You return to town, shaken by your experience.");
			villagenav();
                //Effect of defeat
                } elseif ($defeat) {
			output("`2Your vision blacks out as the lion tears the throat out of your already badly injured body.");
			output("`n`n`%You have died! You lose 10% of your experience, and your gold is stolen by scavengers!");
			output("Your soul drifts to the shades.");
			debuglog("was killed by a lion and lost ".$session['user']['gold']." gold.");
			$session['user']['gold']=0;
			$session['user']['experience']*=0.9;
			$session['user']['alive'] = false;
			addnews("%s was slain by a Lion in the Caves!",$session['user']['name']);
			addnav("Return to the News","news.php");
		} else {
			fightnav(true,true,"runmodule.php?module=dagquests&fight=lionfighting");
		}
		break;
        //Minotaur fight - quest one
        case "minotaurfight":
                //Setting up the minotaur's abilities, fighting prowess, etc (note: the creature level is considerably higher than the lion's)
                $badguy = array(
			"creaturename"=>"Minotaur",
			"creaturelevel"=>$session['user']['level']+1,
			"creatureweapon"=>"Bone Club",
			"creatureattack"=>round($session['user']['attack']*1.15, 0),
			"creaturedefense"=>round($session['user']['defense']*0.9, 0),
			"creaturehealth"=>round($session['user']['maxhitpoints']*1.2, 0), 
			"diddamage"=>0,
			"type"=>"quest"
		);
		$session['user']['badguy']=createstring($badguy);
		$battle=true;
		// drop through
	case "minotaurfighting":
                //Minotaur fight venue
                page_header("The Caves");
                //Let the game know there should be a fight here
                require_once("lib/fightnav.php");
		include("battle.php");
                //Effects of victory
                if ($victory) {
			output("`2The minotaur collapses to the ground with a thud, sending up a cloud of dust!");
			output("You have avenged the deaths of many travellers!");
			$expgain=round($session['user']['experience']*(get_module_setting("qoneexperience")-1), 0);
			$session['user']['experience']+=$expgain;
			output("`n`n`&You gain %s experience from this fight!",$expgain);
			$goldgain=get_module_setting("qonerewardgold");
			$gemgain=get_module_setting("qonerewardgems");
			$session['user']['gold']+=$goldgain;
			$session['user']['gems']+=$gemgain;
			debuglog("got a reward of $goldgain gold and $gemgain gems for slaying a minotaur.");
			if ($goldgain && $gemgain) {
				output("`2You return to the Inn carrying the beast's head, and Dag pays you the bounty of `^%s gold`2 and a pouch of `%%s %s`2!",$goldgain,$gemgain,translate_inline(($gemgain==1)?"gems":"gem"));
			} elseif ($gemgain) {
				output("`2You return to the Inn carrying the beast's head, and Dag pays you the bounty of a pouch of `%%s %s`2!",$gemgain,translate_inline(($gemgain==1)?"gems":"gem"));
			} elseif ($goldgain) {
				output("`2You return to the Inn carrying the beast's head, and Dag pays you the bounty of `^%s gold`2!",$goldgain);
			} else {
				output("`2You return to the Inn carrying the beast's head, but Dag cannot find the bounty to pay you!");
			}
                        //Set the user's quest status to 2
                        set_module_pref("qonestatus",2);
			addnews("%s defeated a Minotaur in the Caves! The deaths of many travellers have been avenged!",$session['user']['name']);
			addnav("I?Return to the Inn","inn.php");
                //Effects of defeat
                } elseif ($defeat) {
			output("`2Your vision blacks out as the minotaur clubs you to the ground.");
			output("You have failed your task to avenge the travellers!");
			output("`n`n`%You have died! You lose 10% of your experience, and your gold is stolen by the minotaur!");
			output("Your soul drifts to the shades.");
			debuglog("was killed by a minotaur in the Caves and lost ".$session['user']['gold']." gold.");
			$session['user']['gold']=0;
			$session['user']['experience']*=0.9;
			$session['user']['alive'] = false;
                        //Set the user's quest status to 3
                        set_module_pref("qonestatus",3);
			addnews("%s was slain by a Minotaur in the Caves!",
					$session['user']['name']);
			addnav("Return to the News","news.php");
		} else {
			fightnav(true,true,"runmodule.php?module=dagquests&fight=minotaurfighting");
		}
		break;
        //Wolf fight - quest two
        case "wolffight":
                //Setting up the wolf - abilities, fighting prowess, etc
                $badguy = array(
			"creaturename"=>"Grey Wolf",
			"creaturelevel"=>$session['user']['level']-1,
			"creatureweapon"=>"Hungry Jaws",
			"creatureattack"=>$session['user']['attack'],
			"creaturedefense"=>round($session['user']['defense']*0.75, 0),
			"creaturehealth"=>round($session['user']['maxhitpoints']*1.1, 0), 
			"diddamage"=>0,
			"type"=>"quest"
		);
		$session['user']['badguy']=createstring($badguy);
		$battle=true;
		// drop through
	case "wolffighting":
                //Wolf fight venue
                page_header("The Trails");
                //Let the game know that a fight will occur here
                require_once("lib/fightnav.php");
		include("battle.php");
                //Effects of victory
                if ($victory) {
			output("`2The wolf collapses on the ground, bleeding from its wounds.");
			output("You quickly flee the scene, hoping to avoid the rest of the pack.");
			$expgain=round($session['user']['experience']*(e_rand(1,2)*0.01));
			$session['user']['experience']+=$expgain;
			output("`n`n`&You gain %s experience from this fight!",$expgain);
			output("`2You return to town, shaken by the attack.");
			villagenav();
                //Effects of defeat
                } elseif ($defeat) {
			output("`6Your vision blacks out as the wolf tears the throat out of your already badly injured body.");
			output("`n`n`%You have died!");
			output("You lose 10% of your experience, and your gold is stolen by scavengers!");
			output("Your soul drifts to the shades.");
			$session['user']['gold']=0;
			$session['user']['experience']*=0.9;
			$session['user']['alive'] = false;
			debuglog("was killed by a wolf on a trail.");
			addnews("%s's body turned up, torn to shreds!",$session['user']['name']);
			addnav("Return to the News","news.php");
		} else {
			fightnav(true,true,"runmodule.php?module=dagquests&fight=wolffighting");
		}
		break;
        //Manticore fight - quest two
        case "manticorefight":
                //Set up the manticore - abilities, fighting prowess and this one has buffs!
                $badguy = array(
			"creaturename"=>"Manticore",
			"creaturelevel"=>$session['user']['level']+2,  //huge creature level compared to the others
			"creatureweapon"=>"Terrible Claws",
			"creatureattack"=>round($session['user']['attack']*1.15, 0),
			"creaturedefense"=>round($session['user']['defense']*1.1, 0),
			"creaturehealth"=>round($session['user']['maxhitpoints']*1.4, 0), 
			"diddamage"=>0,
			"type"=>"quest"
		);
                //Manticore buffs follow
                apply_buff('manticorespike',array(
			"name"=>"`\$Manticore Spikes",
			"roundmsg"=>"The manticore flicks its tail over its head and sends a volley of spikes at you!",
			"effectmsg"=>"You are hit by one of the spikes for `4{damage}`) points!",
			"effectnodmgmsg"=>"You dodge one of the spikes!",
			"rounds"=>20,
			"wearoff"=>"The monster runs out of spikes!",
			"minioncount"=>3,
			"maxgoodguydamage"=>$session['user']['level'],
			"schema"=>"dagquests"
		));
		$session['user']['badguy']=createstring($badguy);
		$battle=true;
		// drop through
	case "manticorefighting":
                //Manticore fight venue
                page_header("The Trails");
                //Battle prep
                require_once("lib/fightnav.php");
		include("battle.php");
                //Effects of victory
                if ($victory) {
			output("`2The manticore falls to the ground with a scream which resonates over the hills, mortally wounded by your blows!");
			output("You have avenged the deaths of the wagon!");
			$expgain=round($session['user']['experience']*(get_module_setting("qtwoexperience")-1), 0);
			$session['user']['experience']+=$expgain;
			output("`n`n`&You gain %s experience from this fight!",$expgain);
			$goldgain=get_module_setting("qtworewardgold");
			$gemgain=get_module_setting("qtworewardgems");
			$session['user']['gold']+=$goldgain;
			$session['user']['gems']+=$gemgain;
			debuglog("found $goldgain gold and $gemgain gems after slaying a manticore.");
			output("`n`n`2With the monster dead, you search through the wagon, but most of the goods are missing!");
			output("Someone else has already been here and looted it without killing the manticore!");
			if ($goldgain && $gemgain) {
				output("All you can find is `^%s gold`2 lying around and `%%s %s`2 which were hidden by the wagon master.",$goldgain,$gemgain,translate_inline(($gemgain==1)?"gems":"gem"));
			} elseif ($gemgain) {
				output("All you can find is `%%s %s`2 which were hidden by the wagon master.",$gemgain,translate_inline(($gemgain==1)?"gems":"gem"));
			} elseif ($goldgain) {
				output("All you can find is `^%s gold`2 lying around.",$goldgain);
			} else {
				output("You don't find anything!");
			}
			output("You make your way back to the fork in the trail, and tell the next wagon the news on the way back to town.");
                        //User's quest two status is set to 2
                        set_module_pref("qtwostatus",2);
			addnews("%s defeated a Manticore on the trails! The victims have been avenged!",$session['user']['name']);
			villagenav();
                        //The manticore loses its buffs
                        strip_buff("manticorespike");
                //Effect of failure
                } elseif ($defeat) {
			output("`2You fall backwards to the ground as the final volley of spikes from the manticore pierces your skull.");
			output("You have failed in your mission to kill this monster!");
			output("`n`n`%You have died!");
			output("You lose 10% of your experience, and your gold is stolen by scavengers!");
			output("Your soul drifts to the shades.");
			debuglog("was killed by a manticore on a trail and lost ".$session['user']['gold']." gold.");
			$session['user']['gold']=0;
			$session['user']['experience']*=0.9;
			$session['user']['alive'] = false;
                        //User's quest two status is set to 3
                        set_module_pref("qtwostatus",3);
			addnews("%s was slain by a Manticore on a trail!",$session['user']['name']);
			addnav("Return to the News","news.php");
                        //Manticore loses the buff
                        strip_buff("manticorespike");
		} else {
			fightnav(true,true,"runmodule.php?module=dagquests&fight=manticorefighting");
		}
		break;
		//Basilisk fight - quest three
        case "basiliskfight":
                //This sets the lion's abilities, fighting prowess, etc
                $badguy = array(
			"creaturename"=>"Basilisk",
			"creaturelevel"=>$session['user']['level']+1,
			"creatureweapon"=>"Petrifying Gaze",
			"creatureattack"=>$session['user']['attack']+2,
			"creaturedefense"=>round($session['user']['defense']*0.9, 0),
			"creaturehealth"=>round($session['user']['maxhitpoints']*1.1, 0),
			"diddamage"=>0,
			"type"=>"quest"
		);
                //Basilisk buffs follow
                apply_buff('petrifygaze',array(
			"name"=>"`\$Petrifying Bite",
			"roundmsg"=>"The basilisk bites at you - its malevolent gaze and unholy power transfixing you!",
			"effectmsg"=>"You are petrified by the foul creature!",
			"effectnodmgmsg"=>"You have managed to avert disaster just in time!",
			"rounds"=>3,
			"wearoff"=>"The petrification ends!",
                        "maxgoodguydamage"=>0,
			"schema"=>"dagquests"
		));
                $session['user']['badguy']=createstring($badguy);
		$battle=true;
		// Drop through
	case "basiliskfighting":
                //Basilisk fight venue
                page_header("The Mountain Aerie");
                //Let the game know this is a fight
                require_once("lib/fightnav.php");
		include("battle.php");
                //Effect of victory
                if ($victory) {
			output("`2The basilisk collapses on the ground, bleeding from its wounds.");
			output("You quickly flee the scene, hoping that there are not more of them around.");
			$expgain=round($session['user']['experience']*(e_rand(1,2)*0.02));
			$session['user']['experience']+=$expgain;
			output("`n`n`&You gain %s experience from this fight!",$expgain);
			output("`2You return to town, shaken by your experience.");
			villagenav();
			//Basilisk loses the buff
                        strip_buff("petrifygaze");
                //Effect of defeat
                } elseif ($defeat) {
			output("`2You stand transfixed - and watch in wonder as you are slowly devoured by the creature - unable to prevent it.");
			output("`n`n`%You have died! You lose 10% of your experience, and your gold is stolen by scavengers!");
			output("Your soul drifts to the shades.");
			debuglog("was killed by a basilisk and lost ".$session['user']['gold']." gold.");
			$session['user']['gold']=0;
			$session['user']['experience']*=0.9;
			$session['user']['alive'] = false;
			addnews("%s was slain by a basilisk on a mountain aerie!",$session['user']['name']);
			addnav("Return to the News","news.php");
                         //Manticore loses the buff
                        strip_buff("petrifygaze");
		} else {
			fightnav(true,true,"runmodule.php?module=dagquests&fight=manticorefighting");
		}
                //Dracolich fight - quest three
        case "dracolichfight":
                //Set up the manticore - abilities, fighting prowess and this one has buffs!
                $badguy = array(
			"creaturename"=>"Dracolich",
			"creaturelevel"=>$session['user']['level']+3,  //huge creature level compared to the others
			"creatureweapon"=>"Negative Energy Breath Weapon",
			"creatureattack"=>round($session['user']['attack']*1.25, 0),
			"creaturedefense"=>round($session['user']['defense']*1.2, 0),
			"creaturehealth"=>round($session['user']['maxhitpoints']*1.5, 0),
			"diddamage"=>0,
			"type"=>"quest"
		);
                //Dracolich buffs follow
                apply_buff('breathweapon',array(
			"name"=>"`\$Negative Energy Breath Weapon",
			"roundmsg"=>"The Dracolich belches forth a wave of negative energy rays at you!",
			"effectmsg"=>"You are hit by the cone for `4{damage}`) points!",
			"effectnodmgmsg"=>"You evade the first wave!",
			"rounds"=>20,
			"wearoff"=>"The monster runs out of uses!",
			"minioncount"=>4,
			"maxgoodguydamage"=>$session['user']['level'],
			"schema"=>"dagquests"
		));
		$session['user']['badguy']=createstring($badguy);
		$battle=true;
		// drop through
	case "dracolichfighting":
                //Dracolich fight venue
                page_header("The Mountain Aerie");
                //Battle prep
                require_once("lib/fightnav.php");
		include("battle.php");
                //Effects of victory
                if ($victory) {
			output("`2The dracolich falls to the ground with a scream which resonates over the hills, mortally wounded by your blows!");
			output("You have slain the Dracolich!");
			$expgain=round($session['user']['experience']*(get_module_setting("qthreeexperience")-1), 0);
			$session['user']['experience']+=$expgain;
			output("`n`n`&You gain %s experience from this fight!",$expgain);
			$goldgain=get_module_setting("qthreerewardgold");
			$gemgain=get_module_setting("qthreerewardgems");
			$session['user']['gold']+=$goldgain;
			$session['user']['gems']+=$gemgain;
			debuglog("found $goldgain gold and $gemgain gems after slaying the dracolich.");
			output("`n`n`2With the monster dead, you search through the lair, but most of the goods are missing!");
			output("Someone else has already been here and looted it without killing the Dracolich!");
			if ($goldgain && $gemgain) {
				output("All you can find is `^%s gold`2 lying around and `%%s %s`2 which were hidden by the dracolich.",$goldgain,$gemgain,translate_inline(($gemgain==1)?"gems":"gem"));
			} elseif ($gemgain) {
				output("All you can find is `%%s %s`2 which were hidden by the dracolich.",$gemgain,translate_inline(($gemgain==1)?"gems":"gem"));
			} elseif ($goldgain) {
				output("All you can find is `^%s gold`2 lying around.",$goldgain);
			} else {
				output("You don't find anything!");
			}
			output("You make your way back to the fork in the trail, and tell the next wagon the news on the way back to town.");
                        //User's quest three status is set to 2
                        set_module_pref("qthreestatus",2);
			addnews("%s defeated the cursed Dracolich on a high mountain aerie! The victims have been avenged!",$session['user']['name']);
			villagenav();
                        //The dracolich loses its buffs
                        strip_buff("breathweapon");
                //Effect of failure
                } elseif ($defeat) {
			output("`2.The negative energy courses through your body - halting the function of your internal organs");
			output("You have failed in your mission to kill this monster!");
			output("`n`n`%You have died!");
			output("You lose 10% of your experience, and your gold is stolen by scavengers!");
			output("Your soul drifts to the shades.");
			debuglog("was killed by a dracolich on a high mountain aerie and lost ".$session['user']['gold']." gold.");
			$session['user']['gold']=0;
			$session['user']['experience']*=0.9;
			$session['user']['alive'] = false;
                        //User's quest three status is set to 3
                        set_module_pref("qthreestatus",3);
			addnews("%s was slain by a dracolich on a high mountain aerie!",$session['user']['name']);
			addnav("Return to the News","news.php");
                        //Manticore loses the buff
                        strip_buff("breathweapon");
		} else {
			fightnav(true,true,"runmodule.php?module=dagquests&fight=dracolichfighting");
		}
		break;

	}
	page_footer();
}
?>
