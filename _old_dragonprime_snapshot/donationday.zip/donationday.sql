INSERT INTO `translations` ( `tid` , `language` , `uri` , `intext` , `outtext` , `author` , `version` )
VALUES (
'', 'de', 'module-donationday', '`^`nBecause you suceeded in killing the `@Green Dragon`^, you are awarded %s donation points', '`^`nWeil Du den `@Gr�nen Drachen`^ besiegt hast, erh�lst Du %s Donation Punkte.', 'Lord Oliver', '1.0.3'
);