Legend of the Green Dragon
by  Eric "MightyE" Stevens (http://www.mightye.org)
and JT "Kendaer" Traub (http://www.dragoncat.net)

Software Project Page:
http://sourceforge.net/projects/lotgd

Modification Community Page:
http://dragonprime.net

Author of this Module:
CortalUX (cortalux@gmail.com)

Download the latest version of this module from:
http://dragonprime.net/index.php?action=viewfiles&user=CortalUX

----------------------------------------------
-- STATUS: -----------------------------------
----------------------------------------------
This module is STABLE.

----------------------------------------------
-- INFORMATION: ------------------------------
----------------------------------------------
This is a potion pack for LotGD 0.9.8.
Every single potion module created by CortalUX
will be packaged in this. This is the most
up to date version.

----------------------------------------------
-- INSTALLATION: -----------------------------
----------------------------------------------
Copy every 'healpotions.php' in this zip into
your 'modules' folder.
Login to the Superuser Grotto and Install it.
Set up the settings.
Login to the Superuser Grotto and Activate it.