<?
//
//  Clock Tower by Robert
//  Maddnet LoGD:  http://logd.maddnet.com/
//  April 2004
//  for LoGD V0.97
//  A tower that players can visit - search and explore IF they have a backpack
//  based on Lonny Castle and uses Lonny's FIND FUNCTION
//
//  You can find Lonny's Castle with find() function at:
//  Dragon Prime:  http://dragonprime.cawsquad.net/
//
// Note: 
// Lonny's Castle is a large castle with a ton of explore functions.  
// It also uses a find function that is tailored to the trading module so you 
// will also need this or you will have to remove the items found and switch to other items.
//
// INSTALL DIFFICULTY: medium 
// *** this is NOT a drop into folder type mod ***
// *** access to db required ***
// *** editing: clocktower.php, common.php, newday.php, user.php, village.php required ***
// *** creation of shop or vendor: to sell candle and backpack to players required ***
//
// REQUIRED:  
// 1 - Lonny's FIND Function installed in your common.php
// 2 - db field added to accounts:  backpack  tinyint 1 unsigned not null  default 0
// 3 - db field added to accounts:  candle  int 11  not null  default 0
// 4 - db field added to accounts:  searches  int 11  not null  default (enter default #)
//     default number = however many you allow players to start off with
//     Lonny's Castle also uses 'searches' - you should already have it, if not, add it.
// 5 - A place or vendor that will sell backpack and candles to the players - easy to create your own
//     ** Dont know how? Visit: DragonPrime > Code Guild Hall > Modder's Area > Generic Shop
// Notes:
//     ** player only needs 1 backpack and 1 candle to venture the Clock Tower
//     ** RETURN nav links default to village.php - change to wherever you choose
//     ** Add a name to Clock Tower, such as "Village Clock Tower" - optional
//     ** Clock Tower can be used without Lonny's Castle installed BUT you must have
//        Lonny's find() function installed !! and make use of the items found.
//        The find() function can be altered to suite your realm and items found as we have done.
//
// add to newday.php:   $session['user']['searches'] = ?;  
//                  *** ( ?= the amount of searches you set for each new day) ***
//                  *** if you have Lonny's Castle 'searches' should already be there, if not add it ***
//
// add to user.php:     "backpack"=>"Has a Backpack?,bool",
//                      "candle"=>"Has how many candles?,int",
//                      "searches"=>"How many Searches today,int",
//                      *** if you have Lonny's Castle 'searches' should already be there, if not add it ***
//
// add to village or wherever:   addnav("Clock Tower","clocktower.php");
//
// Robert thanks Lonny for sharing his find() function
// This is one function that has proved very useful in creating numerous opportunities
// and inspiration for other mods that make playing LoGD a lot of fun for the players.
//
//
require_once "common.php"; 
checkday(); 
page_header("Clock Tower"); 

if ($session['user']['searches']< 1) {
    output("`c`b`3Clock Tower`b`c`n");
	output("`n`&As you near the doorway of the `3Clock Tower`&, you hear a commotion from within, ");
	output("`nthe `3Clock Keep `&is speaking with the `3Sheriff `&reporting that some stuff is missing, `nyou decide that now is a good time to leave quietly and unnoticed. ");
	addnav("(R) Leave","village.php");}
else{

page_header("The Clock Tower");
output("`c`b`3Clock Tower`b`c`n");
$tablefind=e_rand(1,100);
$bedfind=e_rand(1,100);
$boardsfind=e_rand(1,100);
$garbagefind=e_rand(1,100);
$shelffind=e_rand(1,100);
$cabinetfind=e_rand(1,100);

if ($HTTP_GET_VARS[op] == ""){
    if ($session[user][backpack]==1){
	output("`3You enter the Clock Tower and find yourself on the First Floor.`n"); 
	output("The Clock Tower is huge, 4 levels high.`n"); 
	addnav("(D) Go Downstairs","clocktower.php?op=cellar"); 
	addnav("(U) Go Upstairs","clocktower.php?op=2ndfl"); 
	addnav("(O) Search Office","clocktower.php?op=office"); 
	addnav("Leave"); 
	addnav("(L) Leave Clock Tower","village.php");
	}else{
	 output("`3You enter the Clock Tower ready to explore, when the Clock Keep see's you, he scoffs, `n");
	 output("`^What do ye think this is, a tourist attraction, now be gone with ye!`0`n");
	 addnav("Leave"); 
     addnav("(L) Leave Clock Tower","village.php");
}
}
if ($HTTP_GET_VARS[op] == "cellar"){
	output("`c`b`&The Clock Tower Cellar`3`b`c`n`n");
	output("`nYou head down the long winding stairs, it gets darker and darker til you can see no more");
	addnav("leave");
	addnav("(U) Go Upstairs","clocktower.php?op=office");
	if ($session[user][candle]>0){ 
	output("`nYou take out one of your candles and use it to go further down the winding staircase.`n");
	output("You come to door which is not locked. `n What will you do?");
    addnav("(O) Open the door","clocktower.php?op=cellar2");
    $session[user][candle]--;
}
}
if ($HTTP_GET_VARS[op] == "office"){
	output("`c`b`&The Office`3`b`c`n`n");
	output("Within the bare Office you can see a Desk, `na large trash bin under the picture window,");
	output("and a staircase. `nOne leading up and the other leading down.`n`n");
	addnav("Leave"); 
    addnav("(L) Leave Clock Tower","village.php");
    addnav("staircase");
    addnav("(D) Go Downstairs","clocktower.php?op=cellar");
	addnav("(U) Go Upstairs","clocktower.php?op=2ndfl");
    if ($session[user][searches]>=1){
	addnav("search");
	addnav("(G) Search Garbage","clocktower.php?op=garbage");
	addnav("(S) Search Desk","clocktower.php?op=tab");
    }else{
	output("`4You are too tired to search anymore today.`n");
	addnav("(L) leave Clock Tower","village.php");
}
}
if ($HTTP_GET_VARS[op] == "tab" ){
	output("`c`b`&The Office`3`b`c`n`n");
	output("You walk over to the Desk and find ");
	addnav("(C) Continue Searching","clocktower.php?op=office");
	$session[user][searches]-=1;
	if ($tablefind > 80){
		find();
	}else{
		output("nothing.`n");
}
}
else if ($HTTP_GET_VARS[op] == "2ndfl"){
	output("`c`b`&The 2nd floor - Clock Keeps Bedroom`3`b`c`n`n");
	output("The bedroom is simple with just a bed, table and a chair.`n`n");
	addnav("leave");
	addnav("(D) Go Downstairs","clocktower.php?op=office"); 
	addnav("(U) Go Upstairs","clocktower.php?op=3rdfl"); 
	if ($session[user][searches]> 0){
	addnav("search");
    addnav("(T) Check the Table","clocktower.php?op=table");
    addnav("(B) Look under the Bed","clocktower.php?op=bed");
    }else{
	output("`4You are too tired to search the 2nd floor today.`n");
}
}
if ($HTTP_GET_VARS[op] == "table" ){
	output("`c`b`&The 2nd floor - Clock Keeps Bedroom`3`b`c`n`n");
	output("You walk over to the Table and find ");
	addnav("(C) Continue Searching","clocktower.php?op=2ndfl");
	$session[user][searches]-=1;
	if ($tablefind > 82){
		find();
	}else{
		output("nothing.`n");
}
}
if ($HTTP_GET_VARS[op] == "bed" ){
	output("`c`b`&The 2nd floor - Clock Keeps Bedroom`3`b`c`n`n");
	output("You go to the bed in the corner. You look under the bed and find ");
	addnav("(C) Continue Searching","clocktower.php?op=2ndfl");
	$session[user][searches]-=1;
	if ($bedfind > 65){
		find();	
	}else{
		output("nothing.`n");
}
}
else if ($HTTP_GET_VARS[op] == "3rdfl"){
	output("`c`b`&The 3rd floor - Clock Tower Workshop`3`b`c`n`n");
	output("Here upon the 3rd level, you find the Clock Keeps workshop.`n");
	addnav("leave");
	addnav("(D) Go Downstairs","clocktower.php?op=2ndfl");
	addnav("(U) Go Upstairs","clocktower.php?op=4thfl");
	if ($session[user][searches]> 0){
	addnav("search");
	addnav("(W) Check the work bench","clocktower.php?op=bench");
    addnav("(B) Look under floor boards","clocktower.php?op=boards");
    }else{
	output("`4You are too tired to search the 3rd floor today.`n");
}
}
if ($HTTP_GET_VARS[op] == "bench" ){
	output("`c`b`&The 3rd floor - Clock Tower Workshop`3`b`c`n`n");
	output("You carefully look over the large work bench and find ");
	addnav("(C) Continue Searching","clocktower.php?op=3rdfl");
	$session[user][searches]-=1;
	if ($tablefind > 82){
		find();
	}else{
		output("nothing.`n");
}
}
if ($HTTP_GET_VARS[op] == "boards" ){
	output("`c`b`&The 3rd floor - Clock Tower Workshop`3`b`c`n`n");
	output("You notice several loose floor boards. You pull one up and find ");
	addnav("(C) Continue Searching","clocktower.php?op=3rdfl");
	$session[user][searches]-=1;
	if ($boardsfind > 75){
		find();	
	}else{
		output("nothing.`n");
}
}
else if ($HTTP_GET_VARS[op] == "4thfl"){
	output("`c`b`&The 4th floor - Clock Tower's Clock`3`b`c`n`n");
	output("Here you see the workings of a very, very large clock.`n");
	addnav("leave");
	addnav("(D) Go Downstairs","clocktower.php?op=3rdfl");
	addnav("(J) Jump","clocktower.php?op=jump");

}
else if ($HTTP_GET_VARS[op] == "jump"){ 
    output("`nYou open one of the faces of the clock outward, it reveals an awesome landscape!`n`n");
    output("`nYou hop onto the ledge and jump off!`n`n");
    output("`n`^What did you think, you could fly?  That was not so smart.`n`n");
    $name=$session[user][name];    
    switch(e_rand(1,5)){ 
    case 1:
        output(" $name `^You broke one leg!"); 
        $session[user][hitpoints]*=.5; 
        addnav("(C) Continue","village.php"); 
        break; 
     case 2:     
        output(" $name `^You broke both legs!"); 
        $session[user][hitpoints]*=.25; 
        addnav("(C) Continue","village.php");
        break; 
    case 3:
        output(" $name `^You broke one arm!"); 
        $session[user][hitpoints]*=.75; 
        addnav("(C) Continue","village.php");
        break; 
    case 4:
        output(" $name `^You broke a leg, an arm and some ribs!");  
        $session[user][hitpoints]=1; 
        addnav("(C) Continue","village.php"); 
        break; 
    case 5:  
        output(" $name jumps from the 4th level of the Clock Tower and splatters everywhere! `n`n `\$You are dead`^!`n"); 
        addnews("$name `6jumped from the Clock Tower today, not so smart!`0 ");
        $session[user][hitpoints]=0; 
        addnav("(C) Continue","shades.php"); 
        break; 
}
}
if ($HTTP_GET_VARS[op] == "garbage"){
	    output("`c`b`&The Office`3`b`c`n`n");
	    output("You walk over to the large trash bin under the picture window.`n");
	    addnav("Continue","clocktower.php?op=office");  
    if (e_rand(1,100) > 90){ 
        output("The town gossip is standing outside and see's you digging through the garbage!`n"); 
        output("`&Now everyone is going to know!`n"); 
        output("`4You lose 1 Charm!`n"); 
        $session[user][charm]-=1; 
        $name = $session[user][name]; 
        addnews("$name `6was seen going through the garbage at the Clock Tower!`0"); 
    } 
    output("`7You dig through the garbage and find "); 
    $session[user][searches]-=1; 
    if (e_rand(1,100) > 74){ 
        find();        
    }else{ 
        output("nothing.`n");
}
}
else if ($HTTP_GET_VARS[op] == "cellar2"){
	output("`c`b`&The cellar`3`b`c`n`n");
	output("Deep within the Clock Tower cellar you come upon some shelves, a cabinet,`n");
	output("and a large wicker chest.`n");
	addnav("leave");
	addnav("(U) Go Upstairs","clocktower.php?op=office");
	if ($session[user][searches]> 0){
	addnav("search");
	addnav("(S) Check the shelves","clocktower.php?op=shelf");
    addnav("(L) Look in the cabinets","clocktower.php?op=cabinet");
    addnav("(O) Open the chest","clocktower.php?op=chest");
    }else{
	output("`4You are too tired to search the cellar today.`n");
}
}
if ($HTTP_GET_VARS[op] == "shelf" ){
	output("`c`b`&The cellar`3`b`c`n`n");
	output("You see a few shelves, you go to one and find  ");
	addnav("(C) Continue Searching","clocktower.php?op=cellar2");
	$session[user][searches]-=1;
	if ($shelffind > 80){
		find();	
	}else{
		output("nothing.`n");
}
}
if ($HTTP_GET_VARS[op] == "cabinet" ){
	output("`c`b`&The cellar`3`b`c`n`n");
	output("You notice several cabinets. You open one up and find ");
	addnav("(C) Continue Searching","clocktower.php?op=cellar2");
	$session[user][searches]-=1;
	if ($cabinetfind > 70){
		find();	
	}else{
		output("nothing.`n");
}
}
if ($HTTP_GET_VARS[op] == "chest" ){
	output("`c`b`&The cellar`3`b`c`n`n");
	output("You pry open the large wicker chest, You find dirty underwear and smelly socks. ");
	addnav("(C) Continue Searching","clocktower.php?op=cellar2");
	$session[user][searches]-=1;
}

}
page_footer(); 
?>