-------------------------------------------------------------------------------
== Force level 15 to fight Dragon Mod Version 0.1
== Written by thegleek
== 1 June 2004
== The latest version is always available at: http://dragonprime.cawsquad.net/
-------------------------------------------------------------------------------
DESCRIPTION

- This mod will force a player who is GOLD/GEM hungry at level 15 and ignores
  killing the dragon...
- pretty much took the concept from the master and being truant from the 
  village.php script

-------------------------------------------------------------------------------
INSTALLATION

-none needed-

File Changes:
=============

In forest.php, find:

    if ($session[user][superuser]>1 && $HTTP_GET_VARS[specialinc]!=""){
      $session[user][specialinc] = $HTTP_GET_VARS[specialinc];
    }

Insert AFTER:

/*
 *  special mod added by thegleek 6-1-04 @ 11:07am
 *  dragons hunt down GOLD/GEM/EXP-greedy warriors
 */

if ($session[user][level]>=15) {
        if (getsetting("automaster",1) && $session[user][seendragon]!=1) {
                // levels 1 thru 14 are pretty much useless in this array, but for simplicity, i have left
                // them in and rounded all the EXP goals. feel free to change as necessary
                $exparray=array(1=>100,500,1000,2000,3000,5000,7000,10000,12000,15000,20000,25000,30000,40000,50000,60000);
                while (list($key,$val)=each($exparray)) {
                        $exparray[$key]=round($val+($session['user']['dragonkills']/4)*$session['user']['level']*100,0);
                }
                $expreqd=$exparray[$session['user']['level']+1];
                if ($session[user][experience]>$expreqd) { $session[user][seendragon]=1; redirect("dragon.php?op=autochallenge"); }
        }
}

// end mod

===================================================================================

In dragon.php, find:

   if ($HTTP_GET_VARS[op]==""){

Replace with:

   if ($HTTP_GET_VARS[op]=="" || $HTTP_GET_VARS[op]=="challenge") {

Find:

   if ($HTTP_GET_VARS[op]=="run"){

Insert before:

else if ($HTTP_GET_VARS[op]=="autochallenge") {
                addnav("Fight the Green Dragon","dragon.php?op=challenge");
                output("`^The Green Dragon`0 has heard of your cowardness as a warrior, and heard of rumors that you think
                        you are so much more powerful then himself,`nand so `^The Green Dragon`0 magically bringss you to
                        the entrance of his cave, and your own pride prevents you from refusing his demand.");
                if ($session['user']['hitpoints']<$session['user']['maxhitpoints']){
                        output("`n`nLuckily for you, the Green Dragon gives you a healing potion before the fight begins.");
                        $session['user']['hitpoints']=$session['user']['maxhitpoints'];
                }
                addnews("`3{$session['user']['name']}`3 was hunted down by `^The Green Dragon`3 for being a coward.");
}

===================================================================================

thats all! :)
