<?php
// Dead Cat
// by Robert Riochas of maddrio dot com
// for LotGD v1.x
// 1.3 adds admin settings 25Jan2006
// 1.2 adds additional outcome
// 1.1 adds additional outcome

function deadcat_getmoduleinfo(){
	$info = array(
	"name"=>"Dead Cat",
	"version"=>"1.3",
	"author"=>"`2Robert",
	"category"=>"Graveyard Specials",
	"download"=>"http://dragonprime.net/users/robert/deadcat_v1x.zip",
		"settings"=>array(
		"Dead Cat - Settings,title",
		"lordname"=>"Name of the underworld Lord?,|Ramius",
		"minfavor"=>"Minimum favor to gain,range,1,10,1|5",
		"maxfavor"=>"Maximum favor to gain,range,1,25,1|10",
		"gfight"=>"Number of Graveyard Fights to gain,range,1,10,1|1"
		),
	);
	return $info;
}

function deadcat_install(){
	module_addeventhook("graveyard","return 100;");
	return true;
}

function deadcat_uninstall(){
	output("Uninstalling Dead Cat `n");
	return true;
}

function deadcat_dohook($hookname,$args){
	return $args;
}

function deadcat_runevent($type){
	global $session;
	$lordname = get_module_setting("lordname");
	$min = get_module_setting("minfavor");
	$max = get_module_setting("maxfavor");
	$gf = get_module_setting("gfight");
	$sum = e_rand($min,$max);
	output("`n`n`7 As you wander the graveyard, you see something running toward you. `n");
	output("You quickly step off to the side and toss a tombstone upon it. `n`n");
	switch(e_rand(1,6)){
		case 1: case 4:
		output("`7 Upon lifting the tombstone, you find out it was only a cat! `n`n");
		output("`& You know that `\$ %s `& is `i very pleased `i with you! `n`n",$lordname);
		output(" You have gained %s favor with `\$ %s `&! ",$sum,$lordname);
		$session['user']['gravefights']+=$gf;
		$session['user']['deathpower']+= $sum;
		break;
		case 2: case 5:
		output("`7 Upon lifting the tombstone, you find nothing. `n`n Maybe you were seeing things?");
		break;
		case 3: case 6:
		output("`7 Upon lifting the tombstone, you find it was only a `b big hairy bug `b, silly you!");
		break;
	}
}

function deadcat_run(){
}
?>