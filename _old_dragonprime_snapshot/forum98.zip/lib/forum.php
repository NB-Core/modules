<?php
function donothing($start=0){
    global $session;
    set_module_pref('lastthread','');
    $sqlcount = "SELECT id FROM ".db_prefix("logdforum")." WHERE parent='0'";
    $result = db_query($sqlcount);
    $totalmess=db_num_rows($result);
    $sql = db_query("SELECT * FROM ".db_prefix("logdforum")." WHERE parent='0' ORDER BY newpostdate DESC LIMIT $start,15");
    if ($session['user']['dragonkills'] >= get_module_setting("dks") or get_module_pref('forum')){
        $page = "<table width=\"100%\"><tr><td style=\"padding:1px; background-color:black;\"><table width=\"100%\" style=\"margins:0px;\" cellspacing=\"1\" cellpadding=\"3\"><tr class='trhead'><th colspan=\"3\"><center><a href=\"runmodule.php?module=forum&op=new\">New Thread</a></center></th></tr><tr class='trhead'><th width=\"50%\">Thread</th><th width=\"10%\">Replies</th><th>Last Post</th></tr>\n";
        addnav("","runmodule.php?module=forum&op=new");
        addnav("New Thread","runmodule.php?module=forum&op=new");
    }else{
        $page = "<table width=\"100%\"><tr><td style=\"padding:1px; background-color:black;\"><table width=\"100%\" style=\"margins:0px;\" cellspacing=\"1\" cellpadding=\"3\"><tr class='trhead'><th colspan=\"3\"></th></tr><tr class='trhead'><th width=\"50%\">Thread</th><th width=\"10%\">Replies</th><th>Last Post</th></tr>\n";
    }
    //add catagory info here
    $count = 1;
    if (mysql_num_rows($sql) == 0){
        $page .= "<table width=\"100%\"><tr><td style=\"padding:1px; background-color:black;\"><table width=\"100%\" style=\"margins:0px;\" cellspacing=\"1\" cellpadding=\"3\"><tr class='trlight'><th colspan=\"3\"><b>No threads in forum.</b></td></tr>\n";
    }else{
        while ($row = mysql_fetch_array($sql)){
            if (get_module_setting('usesmiley')) $row['content'] = emoticon($row['content']);
            if ($count == 1){
                $page .= "<tr class='trlight'><td><a href=\"runmodule.php?module=forum&op=thread:".$row["id"].":0\">`3`b<big>".str_replace("*apost*","'",$row["title"])."</big>`b`n`7</a>By: ".str_replace("*apost*","'",$row["author"])."`n".str_replace("*apost*","'",substr($row["content"],0,150))."</td><td>`3".$row["replies"]."</td><td>`3".$row["newpostdate"]."`nBy: ".str_replace("*apost*","'",lastpostauth($row["id"]))."</td></tr>\n";
                addnav("","runmodule.php?module=forum&op=thread:".$row["id"].":0");
                $count = 2;
            }else{
                $page .= "<tr class='trdark'><td><a href=\"runmodule.php?module=forum&op=thread:".$row["id"].":0\">`#`b<big>".str_replace("*apost*","'",$row["title"])."</big>`b`n`7</a>By: ".str_replace("*apost*","'",$row["author"])."`n".str_replace("*apost*","'",substr($row["content"],0,150))."</td><td>`#".$row["replies"]."</td><td>`#".$row["newpostdate"]."`nBy: ".str_replace("*apost*","'",lastpostauth($row["id"]))."</td></tr>\n";
                addnav("","runmodule.php?module=forum&op=thread:".$row["id"].":0");
                $count = 1;
            }
        }
    }
    $page .= "</table></td></tr></table>";
    if ($start > 1){
        $previous=$start-15;
        if ($previous < 0) $previous=0;
        rawoutput("<a href=\"runmodule.php?module=forum&op=list:".$previous."\">&lt;---Previous  </a>");
        addnav("","runmodule.php?module=forum&op=list:".$previous);
    }
    $j=0;
    output("Pages (");
    for ($i=0;$i<$totalmess;$i+=15){
        $j++;
        if ($i==$start){
            output_notl("$j");
        }else{
            rawoutput("<a href=\"runmodule.php?module=forum&op=list:".$i."\">".$j."</a>");
            addnav("","runmodule.php?module=forum&op=list:".$i."\">".$j);
        }
    }
    output(")  ");
    if ($totalmess > $start+15){
        $next=$start+15;
        rawoutput("<a href=\"runmodule.php?module=forum&op=list:".$next."\">Next ---&gt;  </a>");
        addnav("","runmodule.php?module=forum&op=list:".$next);
    }
    rawoutput("<br>");
    output_notl($page,true);
    if ($start > 1){
        $previous=$start-15;
        if ($previous < 0) $previous=0;
        rawoutput("<a href=\"runmodule.php?module=forum&op=list:".$previous."\">&lt;---Previous  </a>");
        addnav("","runmodule.php?module=forum&op=list:".$previous);
    }
    $j=0;
    output("Pages (");
    for ($i=0;$i<$totalmess;$i+=15){
        $j++;
        if ($i==$start){
            output_notl("$j");
        }else{
            rawoutput("<a href=\"runmodule.php?module=forum&op=list:".$i."\">".$j."</a>");
            addnav("","runmodule.php?module=forum&op=list:".$i."\">".$j);
        }
    }
    output(")  ");
    if ($totalmess > $start+15){
        $next=$start+15;
        rawoutput("<a href=\"runmodule.php?module=forum&op=list:".$next."\">Next ---&gt;  </a>");
        addnav("","runmodule.php?module=forum&op=list:".$next);
    }
    rawoutput("<br>");
}

function lastpostauth($id){
    $sql2 = "SELECT author FROM ".db_prefix("logdforum")." WHERE parent='$id' ORDER BY id DESC";
    $result2 = db_query($sql2);
    $row2 = db_fetch_assoc($result2);
    $text = $row2['author'];
    return $text;
}

function delmess($id){
    $sql = "SELECT parent FROM ".db_prefix("logdforum")." WHERE id = '$id'";
    $result = db_query($sql);
    $row = db_fetch_assoc($result);
    if ($row['parent']) db_query("UPDATE ".db_prefix("logdforum")." SET replies = replies-1 WHERE id='".$row['parent']."'");
    db_query("DELETE FROM ".db_prefix("logdforum")." WHERE parent='$id'");
    db_query("DELETE FROM ".db_prefix("logdforum")." WHERE id='$id'");
    output("Message Deleted");
    addnav("Return to thread","runmodule.php?module=forum&op=thread:".get_module_pref('lastthread'));
}

function newthread(){
    global $session;
    if ($session['user']['dragonkills'] > get_module_setting("dks") or get_module_pref('forum')){
        if (isset($_POST["submit"])){
            extract($_POST);
            if ($title<>"" and $content<>""){
                $title=soap($title);
                $title=str_replace("'","*apost*",$title);
                $title=htmlentities($title);
                $content=get_module_pref("user_color").$content;
                $content=soap($content);
                $content=htmlentities($content);
                $content=str_replace("'","*apost*",$content);
                if (get_module_setting('savebio')){
                    $sql = db_query("INSERT INTO ".db_prefix("logdforum")." SET id='',postdate=NOW(),newpostdate=NOW(),userid=".$session['user']['acctid'].",author='".$session['user']['name']."\n<br>".str_replace("'","*apost*",substr($session['user']['bio'],0,100))."`n',parent='0',replies='0',title='$title',content='$content'");
                }else{
                    $sql = db_query("INSERT INTO ".db_prefix("logdforum")." SET id='',postdate=NOW(),newpostdate=NOW(),userid=".$session['user']['acctid'].",author='".$session['user']['name']."\n`n',parent='0',replies='0',title='$title',content='$content'");
                }
                set_module_setting('newestpostdate',date("Y-m-d H:i:s"));
                redirect("runmodule.php?module=forum");
            }else{
                output("You need to input a title and message!`n");
                addnav("Ooops");
                addnav("Continue","runmodule.php?module=forum&op=new");
                addnav("Other Options");
            }
    }else{
        $page = "<table width=\"100%\"><tr><td><b>Make A New Post:</b><br /><br/ ><form action=\"runmodule.php?module=forum&op=new\" method=\"post\" name=\"form\">Title:<br /><input type=\"text\" name=\"title\" size=\"50\" maxlength=\"50\" /><br /><br />Message:<br /><textarea name=\"content\" rows=\"7\" cols=\"40\" class=\"input\"></textarea><br /><br /><input type=\"submit\" name=\"submit\" value=\"Submit\" /> <input type=\"reset\" name=\"reset\" value=\"Reset\" /></form></td></tr></table>";
        output_notl($page,true);
        clickables("form","content");
        addnav("","runmodule.php?module=forum&op=new");
    }
}else{
    output("You are not authorized to start a new thread!");
    addnav("Forum Main","runmodule.php?module=forum");
}
}
function quote($messnum,$start){
    $sql = "SELECT * FROM ".db_prefix("logdforum")." WHERE id = '".$messnum."'";
    $result = db_query($sql);
    $row = db_fetch_assoc($result);
    $parent = $row['parent'];
    $content = "`i`bQuote:`b`n*begin*`n`iAuthor: ".$row["author"]."`n".$row["content"]."`i*end*";
    $content = str_replace("<br><br>","`n",$content);
    $content = str_replace("</span><span class='colDkBlue'>","`1",$content);
    $content = str_replace("</span><span class='colLtBlue'>","`!",$content);
    $content = str_replace("</span><span class='colDkGreen'>","`2",$content);
    $content = str_replace("</span><span class='colLtGreen'>","`@",$content);
    $content = str_replace("</span><span class='colDkCyan'>","`3",$content);
    $content = str_replace("</span><span class='colLtCyan'>","`#",$content);
    $content = str_replace("</span><span class='colDkRed'>","`4",$content);
    $content = str_replace("</span><span class='colLtRed'>","`$",$content);
    $content = str_replace("</span><span class='colDkMagenta'>","`5",$content);
    $content = str_replace("</span><span class='colLtMagenta'>","`%",$content);
    $content = str_replace("</span><span class='colDkYellow'>","`6",$content);
    $content = str_replace("</span><span class='colLtYellow'>","`^",$content);
    $content = str_replace("</span><span class='colDkWhite'>","`7",$content);
    $content = str_replace("</span><span class='colLtWhite'>","`&",$content);
    $content = str_replace("</span><span class='colDkOrange'>","`q",$content);
    $content = str_replace("</span><span class='colLtOrange'>","`Q",$content);
    $content = str_replace("<b>","`b",$content);
    $content = str_replace("</b>","`b",$content);
    $content = str_replace("<i>","`i",$content);
    $content = str_replace("</i>","`i",$content);
    $content = str_replace("*apost*","'",$content);
    $content = str_replace("<br>","`n",$content);
    $page = "<table width=\"100%\"><tr><td><b>Reply To This Message:</b><br /><form action=\"runmodule.php?module=forum&op=reply&op2=$start\" method=\"post\" name=\"form\"><input type=\"hidden\" name=\"parent\" value=\"$parent\" /><input type=\"hidden\" name=\"title\" value=\"Re: ".$row2["title"]."\" /><br /><textarea name=\"content\" rows=\"10\" cols=\"60\" class=\"input\">".$content."</textarea><br /><input type=\"submit\" name=\"submit\" value=\"Submit\" /> <input type=\"reset\" name=\"reset\" value=\"Reset\" /></form></td></tr></table>";
    rawoutput($page);
    clickables("form","content");
    addnav("","runmodule.php?module=forum&op=reply&op2=$start");
    addnav("Return to thread","runmodule.php?module=forum&op=thread:".get_module_pref('lastthread'));
}
function reply($start){
    global $session;
    extract($_POST);
    if ($content<>""){
        $content=get_module_pref("user_color").$content;
        $content=soap($content);
        $content=htmlentities($content);
        $content=str_replace("'","*apost*",$content);
        if (strstr($content,"`i`bQuote:`b`n") != ""){
            $content = str_replace("*begin*","<div align=\"left\"><table border=\"1\" cellpadding=\"0\" cellspacing=\"0\" width=\"90%\" bordercolor=\"#000000\"><tr><td width=\"90%\">",$content);
            $content = str_replace("*end*","</td></tr></table></div>",$content);
        }
        if (get_module_setting('savebio')){
            db_query("INSERT INTO ".db_prefix("logdforum")." SET id='',postdate=NOW(),newpostdate=NOW(),userid=".$session['user']['acctid'].",author='".$session['user']['name']."\n<br>".str_replace("'","*apost*",substr($session['user']['bio'],0,100))."`n',parent='$parent',replies='0',title='$title',content='$content'");
        }else{
            db_query("INSERT INTO ".db_prefix("logdforum")." SET id='',postdate=NOW(),newpostdate=NOW(),userid=".$session['user']['acctid'].",author='".$session['user']['name']."\n`n',parent='$parent',replies='0',title='$title',content='$content'");
        }
        db_query("UPDATE ".db_prefix("logdforum")." SET newpostdate=NOW(),replies=replies+1 WHERE id='$parent' LIMIT 1");
        set_module_setting('newestpostdate',date("Y-m-d H:i:s"));
        redirect("runmodule.php?module=forum&op=thread:$parent:$start");
    }else{
        output("You must enter something to post it!");
        addnav("Oooops");
        addnav("Continue","runmodule.php?module=forum");
        addnav("Other Options");    
    }
}

function forumdate($uglydate){
    return date("F j, Y", mktime(0,0,0,substr($uglydate, 5, 2),substr($uglydate, 8, 2),substr($uglydate, 0, 4)));
}

function showthread($id, $start){
global $session;
set_module_pref('lastthread',$id.':'.$start);
$sql = "SELECT title from ".db_prefix("logdforum")." WHERE id='$id'";
$result = db_query($sql);
$row = db_fetch_assoc($result);
output("`c`b`2-`@=`2-`@=".str_replace("*apost*","'",$row["title"])."`@=`2-`@=`2-`b`c");
if (get_module_pref('forum')) output("`4`c`bDeleting the FIRST message in a thread deletes the ENTIRE thread!`b`c`7");
$sqlcount = "SELECT author FROM ".db_prefix("logdforum")." WHERE parent='$id'";
    $result = db_query($sqlcount);
    $totalmess=db_num_rows($result)+1;
    $sql = db_query("SELECT * FROM ".db_prefix("logdforum")." WHERE id='$id' OR parent='$id' ORDER BY id LIMIT $start,15");
    $sql2 = db_query("SELECT title FROM ".db_prefix("logdforum")." WHERE id='$id' LIMIT 1");
    $row2 = mysql_fetch_array($sql2);
    $page = "<table width=\"100%\"><tr class='trhead'><td style=\"padding:1px; background-color:black;\"><table width=\"100%\" style=\"margins:0px;\" cellspacing=\"1\" cellpadding=\"3\"><tr class='trhead'><td colspan=\"2\"><b><a href=\"runmodule.php?module=forum\">Forum</a> :: ".$row2["title"]."</b></td></tr>\n";
    addnav("","runmodule.php?module=forum");
    $count = 1;
    while ($row = mysql_fetch_array($sql)){
        if (get_module_setting('usesmiley')) $row['content'] = emoticon($row['content']);
        if ($count == 1){
            $page .= "<tr class='trlight'><td width=\"25%\" vertical-align:top;\"><span class=\"small\"><b>";
            $count = 2;
        }else{
            $page .= "<tr class='trdark'><td width=\"25%\" vertical-align:top;\"><span class=\"small\"><b>";
            $count = 1;
        }
            if (get_module_pref('forum')){
                $page .= "<a class='colLtGreen' href=\"runmodule.php?module=forum&op=delete:".$row["id"]."\" onClick=\"return confirm('Are you sure you wish to delete this Message?');\">[del] </a>";
                addnav("","runmodule.php?module=forum&op=delete:".$row["id"]);
            }
            if (get_module_pref('forum') or $row['userid'] == $session['user']['acctid']){
                $page .= "<a class='colLtCyan' href=\"runmodule.php?module=forum&op=edit:".$row["id"]."\">[edit] </a>";
                addnav("","runmodule.php?module=forum&op=edit:".$row["id"]);
            }
            if (strstr($row['content'],"`i`bQuote:`b`n") == ""){
                $page .= "<a class='colLtBlue' href=\"runmodule.php?module=forum&op=quote:".$row["id"]."&op2=$start\">[quote] </a>";
                addnav("","runmodule.php?module=forum&op=quote:".$row["id"]."&op2=$start");
            }
            $page .= "<br>";
            $page .= "`3".str_replace("*apost*","'",$row["author"])."</b><br /><br />";
            if (is_module_active('avatars')) $page .= show_avatar($row['userid']);
            $page .= "`3".forumdate($row["postdate"])."</td><td vertical-align:top;\">`3".nl2br(str_replace("*apost*","'",$row["content"]))."</td></tr>\n";
    }
    $page .= "</table></td></tr></table><br />";
    if ($start > 1){
        $previous=$start-15;
        if ($previous < 0) $previous=0;
        rawoutput("<a href=\"runmodule.php?module=forum&op=thread:".$id.":".$previous."\">&lt;---Previous  </a>");
        addnav("","runmodule.php?module=forum&op=thread:".$id.":".$previous);
    }
    $j=0;
    output("Pages (");
    for ($i=0;$i<$totalmess;$i+=15){
        $j++;
        if ($i==$start){
            output_notl("$j");
        }else{
        rawoutput("<a href=\"runmodule.php?module=forum&op=thread:".$id.":".$i."\">".$j."</a>");
        addnav("","runmodule.php?module=forum&op=thread:".$id.":".$i);
        }
    }
    output(")  ");
    if ($totalmess > $start+15){
        $next=$start+15;
        rawoutput("<a href=\"runmodule.php?module=forum&op=thread:".$id.":".$next."\">Next ---&gt;  </a>");
        addnav("","runmodule.php?module=forum&op=thread:".$id.":".$next);
    }
    rawoutput("<br>");
    output_notl($page,true);
    if ($start > 1){
        $previous=$start-15;
        if ($previous < 0) $previous=0;
        rawoutput("<a href=\"runmodule.php?module=forum&op=thread:".$id.":".$previous."\">&lt;---Previous  </a>");
        addnav("","runmodule.php?module=forum&op=thread:".$id.":".$previous);
    }
    $j=0;
    output("Pages (");
        for ($i=0;$i<$totalmess;$i+=15){
        $j++;
        if ($i==$start){
            output_notl("$j");
        }else{
            rawoutput("<a href=\"runmodule.php?module=forum&op=thread:".$id.":".$i."\">".$j."</a>");
            addnav("","runmodule.php?module=forum&op=thread:".$id.":".$i."\">".$j);
        }
    }
    output(")  ");
    if ($totalmess > $start+15){
        $next=$start+15;
        rawoutput("<a href=\"runmodule.php?module=forum&op=thread:".$id.":".$next."\">Next ---&gt;</a>");
        addnav("","runmodule.php?module=forum&op=thread:".$id.":".$next);
    }
    rawoutput("<br>");
    if (($start+15) >= $totalmess){
        $page2 = "<table width=\"100%\"><tr><td><b>Reply To This Thread:</b><br /><form action=\"runmodule.php?module=forum&op=reply&op2=$start\" method=\"post\" name=\"form\"><input type=\"hidden\" name=\"parent\" value=\"$id\" /><input type=\"hidden\" name=\"title\" value=\"Re: ".$row2["title"]."\" /><br /><textarea name=\"content\" rows=\"10\" cols=\"60\" class=\"input\"></textarea><br /><input type=\"submit\" name=\"submit\" value=\"Submit\" /> <input type=\"reset\" name=\"reset\" value=\"Reset\" /></form></td></tr></table>";
        output_notl($page2,true);
        clickables("form","content");
        addnav("","runmodule.php?module=forum&op=reply&op2=$start");
    }
}

function emoticon($content){
        if (get_module_setting("usesmiley")){
            $content = str_replace("*frown*","<IMG SRC=\"images/frown.gif\">",$content);
            $content = str_replace("*grin*","<IMG SRC=\"images/grin.gif\">",$content);
            $content = str_replace("*biggrin*","<IMG SRC=\"images/grin2.gif\">",$content);
            $content = str_replace("*happy*","<IMG SRC=\"images/happy.gif\">",$content);
            $content = str_replace("*laugh*","<IMG SRC=\"images/laugh.gif\">",$content);
            $content = str_replace("*love*","<IMG SRC=\"images/loveface.gif\">",$content);
            $content = str_replace("*angry*","<IMG SRC=\"images/mad.gif\">",$content);
            $content = str_replace("*mad*","<IMG SRC=\"images/mad2.gif\">",$content);
            $content = str_replace("*music*","<IMG SRC=\"images/musicface.gif\">",$content);
            $content = str_replace("*order*","<IMG SRC=\"images/order.gif\">",$content);
            $content = str_replace("*purple*","<IMG SRC=\"images/purpleface.gif\">",$content);
            $content = str_replace("*red*","<IMG SRC=\"images/redface.gif\">",$content);
            $content = str_replace("*rofl*","<IMG SRC=\"images/rofl.gif\">",$content);
            $content = str_replace("*rolleyes*","<IMG SRC=\"images/rolleyes.gif\">",$content);
            $content = str_replace("*shock*","<IMG SRC=\"images/shock.gif\">",$content);
            $content = str_replace("*shocked*","<IMG SRC=\"images/shocked.gif\">",$content);
            $content = str_replace("*slimer*","<IMG SRC=\"images/slimer.gif\">",$content);
            $content = str_replace("*spineyes*","<IMG SRC=\"images/spineyes.gif\">",$content);
            $content = str_replace("*sarcastic*","<IMG SRC=\"images/srcstic.gif\">",$content);
            $content = str_replace("*tongue*","<IMG SRC=\"images/tongue.gif\">",$content);
            $content = str_replace("*tongue2*","<IMG SRC=\"images/tongue2.gif\">",$content);
            $content = str_replace("*wink*","<IMG SRC=\"images/wink.gif\">",$content);
            $content = str_replace("*wink2*","<IMG SRC=\"images/wink2.gif\">",$content);
            $content = str_replace("*wink3*","<IMG SRC=\"images/wink3.gif\">",$content);
            $content = str_replace("*confused*","<IMG SRC=\"images/confused.gif\">",$content);
            $content = str_replace("*embarassed*","<IMG SRC=\"images/embarassed.gif\">",$content);
            $content = str_replace("*rose*","<IMG SRC=\"images/rose.gif\">",$content);
            $content = str_replace("*drool*","<IMG SRC=\"images/drool.gif\">",$content);
            $content = str_replace("*sick*","<IMG SRC=\"images/sick.gif\">",$content);
            $content = str_replace("*kiss*","<IMG SRC=\"images/kiss.gif\">",$content);
            $content = str_replace("*brokeheart*","<IMG SRC=\"images/brokeheart.gif\">",$content);
            $content = str_replace("*wimper*","<IMG SRC=\"images/wimper.gif\">",$content);
            $content = str_replace("*whew*","<IMG SRC=\"images/whew.gif\">",$content);
            $content = str_replace("*cry*","<IMG SRC=\"images/cry.gif\">",$content);
            $content = str_replace("*angel*","<IMG SRC=\"images/angel.gif\">",$content);
            $content = str_replace("*nerd*","<IMG SRC=\"images/nerd.gif\">",$content);
            $content = str_replace("*stop*","<IMG SRC=\"images/stop.gif\">",$content);
            $content = str_replace("*zzz*","<IMG SRC=\"images/zzz.gif\">",$content);
            $content = str_replace("*shhh*","<IMG SRC=\"images/shhh.gif\">",$content);
            $content = str_replace("*nottalking*","<IMG SRC=\"images/nottalking.gif\">",$content);
            $content = str_replace("*party*","<IMG SRC=\"images/party.gif\">",$content);
            $content = str_replace("*yawn*","<IMG SRC=\"images/yawn.gif\">",$content);
            $content = str_replace("*doh*","<IMG SRC=\"images/doh.gif\">",$content);
            $content = str_replace("*clap*","<IMG SRC=\"images/clap.gif\">",$content);
            $content = str_replace("*lie*","<IMG SRC=\"images/lie.gif\">",$content);
            $content = str_replace("*bateyes*","<IMG SRC=\"images/bateyes.gif\">",$content);
            $content = str_replace("*pray*","<IMG SRC=\"images/pray.gif\">",$content);
            $content = str_replace("*peace*","<IMG SRC=\"images/peace.gif\">",$content);
            $content = str_replace("*nono*","<IMG SRC=\"images/nono.gif\">",$content);
            $content = str_replace("*bow*","<IMG SRC=\"images/bow.gif\">",$content);
            $content = str_replace("*groove*","<IMG SRC=\"images/groove.gif\">",$content);
            $content = str_replace("*giggle*","<IMG SRC=\"images/giggle.gif\">",$content);
            $content = str_replace("*yakyak*","<IMG SRC=\"images/yakyak.gif\">",$content);
        }
    return $content;
}

function editmess($messid){
    $sql = "SELECT * FROM ".db_prefix("logdforum")." WHERE id = '".$messid."'";
    $result = db_query($sql);
    $row = db_fetch_assoc($result);
    //for backwards compatibility
    $content = $row['content'];
    if (strstr($content,"`i`bQuote:`b`n") != ""){
            $content = str_replace("<div align=\"left\"><table border=\"1\" cellpadding=\"0\" cellspacing=\"0\" width=\"90%\" bordercolor=\"#000000\"><tr><td width=\"90%\">","*begin*",$content);
            $content = str_replace("</td></tr></table></div>","*end*",$content);
        }
    $content = str_replace("</span><span class='colDkBlue'>","`1",$content);
    $content = str_replace("</span><span class='colLtBlue'>","`!",$content);
    $content = str_replace("</span><span class='colDkGreen'>","`2",$content);
    $content = str_replace("</span><span class='colLtGreen'>","`@",$content);
    $content = str_replace("</span><span class='colDkCyan'>","`3",$content);
    $content = str_replace("</span><span class='colLtCyan'>","`#",$content);
    $content = str_replace("</span><span class='colDkRed'>","`4",$content);
    $content = str_replace("</span><span class='colLtRed'>","`$",$content);
    $content = str_replace("</span><span class='colDkMagenta'>","`5",$content);
    $content = str_replace("</span><span class='colLtMagenta'>","`%",$content);
    $content = str_replace("</span><span class='colDkYellow'>","`6",$content);
    $content = str_replace("</span><span class='colLtYellow'>","`^",$content);
    $content = str_replace("</span><span class='colDkWhite'>","`7",$content);
    $content = str_replace("</span><span class='colLtWhite'>","`&",$content);
    $content = str_replace("</span><span class='colDkOrange'>","`q",$content);
    $content = str_replace("</span><span class='colLtOrange'>","`Q",$content);
    $content = str_replace("<b>","`b",$content);
    $content = str_replace("</b>","`b",$content);
    $content = str_replace("<i>","`i",$content);
    $content = str_replace("</i>","`i",$content);
    $content = str_replace("*apost*","'",$content);
    //end backwards compatibility
    $page = "<table width=\"100%\"><tr><td><b>Edit This Message:</b><br /><form action=\"runmodule.php?module=forum&op=saveedit:$messid\" method=\"post\" name=\"form\"><input type=\"hidden\" name=\"parent\" value=\"".$row['id']."\" /><input type=\"text\" name=\"title\" value=\"".$row['title']."\" /><br /><textarea name=\"content\" rows=\"10\" cols=\"60\" class=\"input\">".$content."</textarea><br /><input type=\"submit\" name=\"submit\" value=\"Save\" /> <input type=\"reset\" name=\"reset\" value=\"Reset\" /></form></td></tr></table>";
    addnav("","runmodule.php?module=forum&op=saveedit:$messid");
    addnav("Return to thread","runmodule.php?module=forum&op=thread:".get_module_pref('lastthread'));
    rawoutput($page);
    clickables("form","content");
}

function saveedit($messid){
    extract($_POST);
    $title=soap($title);
    $title=str_replace("'","*apost*",$title);
    $content=soap($content);
    $content=htmlentities($content);
    $content=str_replace("'","*apost*",$content);
    if (strstr($content,"`i`bQuote:`b`n") != ""){
            $content = str_replace("*begin*","<div align=\"left\"><table border=\"1\" cellpadding=\"0\" cellspacing=\"0\" width=\"90%\" bordercolor=\"#000000\"><tr><td width=\"90%\">",$content);
            $content = str_replace("*end*","</td></tr></table></div>",$content);
        }
    if ($content <> "" and $title <> ""){
        db_query("UPDATE ".db_prefix("logdforum")." SET title = '$title' WHERE id = '$messid'");
        db_query("UPDATE ".db_prefix("logdforum")." SET content = '$content' WHERE id = '$messid'");
        set_module_setting('newestpostdate',date("Y-m-d H:i:s"));
        output("Edit Saved!");
    }else{
        output("Edit Failed!");
    }
    addnav("Return to thread","runmodule.php?module=forum&op=thread:".get_module_pref('lastthread'));
}

function clickables($formname,$areaname){
    if (get_module_setting("showkey")){
        output("`n`c`2-=-=Clickable Colors=-=-`n");
        rawoutput("<a class='colDkBlue' onClick=\"addSmiley('`1')\">Click</a> ");
        output("`&,  ");
        rawoutput("<a class='colLtBlue' onClick=\"addSmiley('`!')\">Click</a> ");
        output("`&,  ");
        rawoutput("<a class='colDkGreen' onClick=\"addSmiley('`2')\">Click</a> ");
        output("`&,  ");
        rawoutput("<a class='colLtGreen' onClick=\"addSmiley('`@')\">Click</a> ");
        output("`&,  ");
        rawoutput("<a class='colDkCyan' onClick=\"addSmiley('`3')\">Click</a> ");
        output("`&,  ");
        rawoutput("<a class='colLtCyan' onClick=\"addSmiley('`#')\">Click</a> ");
        output("`&,  ");
        rawoutput("<a class='colDkRed' onClick=\"addSmiley('`4')\">Click</a> ");
        output("`&,  ");
        rawoutput("<a class='colLtRed' onClick=\"addSmiley('`$')\">Click</a> ");
        output("`&,  ");
        rawoutput("<a class='colDkMagenta' onClick=\"addSmiley('`5')\">Click</a> ");
        output("`&,  ");
        rawoutput("<a class='colLtMagenta' onClick=\"addSmiley('`%')\">Click</a> ");
        output("`&,  ");
        rawoutput("<a class='colDkYellow' onClick=\"addSmiley('`6')\">Click</a> ");
        output("`&,  ");
        rawoutput("<a class='colDLtYellow' onClick=\"addSmiley('`^')\">Click</a> ");
        output("`&,  ");
        rawoutput("<a class='colDkWhite' onClick=\"addSmiley('`7')\">Click</a> ");
        output("`&,  ");
        rawoutput("<a class='colLtWhite' onClick=\"addSmiley('`&')\">Click</a> ");
        output("`&,  ");
        rawoutput("<a class='colDkOrange' onClick=\"addSmiley('`q')\">Click</a> ");
        output("`&,  ");
        rawoutput("<a class='colLtOrange' onClick=\"addSmiley('`Q')\">Click</a> ");
        output("`c");
        output("`c`2-=-=Clickable Codes=-=-`n");
        rawoutput("<a onClick=\"addSmiley('`b')\">(Bold)</a> ");
        rawoutput("<a onClick=\"addSmiley('`i')\">(Italics)</a> ");
        output("`c");
    }
    if (get_module_setting("usesmiley")){
        output("`c`2-=-=Clickable Smilies=-=-`n");
           rawoutput("<a onClick=\"addSmiley(' *frown* ')\"><img src='./images/frown.gif'></a> ");
           rawoutput("<a onClick=\"addSmiley(' *grin* ')\"><img src='./images/grin.gif'></a> ");
           rawoutput("<a onClick=\"addSmiley(' *biggrin* ')\"><img src='./images/grin2.gif'></a> ");
           rawoutput("<a onClick=\"addSmiley(' *happy* ')\"><img src='./images/happy.gif'></a> ");
           rawoutput("<a onClick=\"addSmiley(' *laugh* ')\"><img src='./images/laugh.gif'></a> ");
           rawoutput("<a onClick=\"addSmiley(' *love* ')\"><img src='./images/loveface.gif'></a> ");
           rawoutput("<a onClick=\"addSmiley(' *angry* ')\"><img src='./images/mad.gif'></a> ");
           rawoutput("<a onClick=\"addSmiley(' *mad* ')\"><img src='./images/mad2.gif'></a> ");
           rawoutput("<a onClick=\"addSmiley(' *music* ')\"><img src='./images/musicface.gif'></a> ");
           rawoutput("<a onClick=\"addSmiley(' *order* ')\"><img src='./images/order.gif'></a> ");
           rawoutput("<a onClick=\"addSmiley(' *purple* ')\"><img src='./images/purpleface.gif'></a> ");
           rawoutput("<a onClick=\"addSmiley(' *red* ')\"><img src='./images/redface.gif'></a> ");
           rawoutput("<a onClick=\"addSmiley(' *rofl* ')\"><img src='./images/rofl.gif'></a> ");
           rawoutput("<a onClick=\"addSmiley(' *rolleyes* ')\"><img src='./images/rolleyes.gif'></a> ");
           rawoutput("<a onClick=\"addSmiley(' *shock* ')\"><img src='./images/shock.gif'></a> ");
           rawoutput("<a onClick=\"addSmiley(' *shocked* ')\"><img src='./images/shocked.gif'></a> ");
           rawoutput("<a onClick=\"addSmiley(' *slimer* ')\"><img src='./images/slimer.gif'></a> ");
           rawoutput("<a onClick=\"addSmiley(' *spineyes* ')\"><img src='./images/spineyes.gif'></a> ");
           rawoutput("<a onClick=\"addSmiley(' *sarcastic* ')\"><img src='./images/srcstic.gif'></a> ");
           rawoutput("<a onClick=\"addSmiley(' *tongue* ')\"><img src='./images/tongue.gif'></a> ");
           rawoutput("<a onClick=\"addSmiley(' *tongue2* ')\"><img src='./images/tongue2.gif'></a> ");
           rawoutput("<a onClick=\"addSmiley(' *wink* ')\"><img src='./images/wink.gif'></a> ");
           rawoutput("<a onClick=\"addSmiley(' *wink2* ')\"><img src='./images/wink2.gif'></a> ");
           rawoutput("<a onClick=\"addSmiley(' *wink3* ')\"><img src='./images/wink3.gif'></a> ");
           rawoutput("<a onClick=\"addSmiley(' *confused* ')\"><img src='./images/confused.gif'></a> ");
           rawoutput("<a onClick=\"addSmiley(' *embarassed* ')\"><img src='./images/embarassed.gif'></a> ");
           rawoutput("<a onClick=\"addSmiley(' *rose* ')\"><img src='./images/rose.gif'></a> ");
           rawoutput("<a onClick=\"addSmiley(' *drool* ')\"><img src='./images/drool.gif'></a> ");
           rawoutput("<a onClick=\"addSmiley(' *sick* ')\"><img src='./images/sick.gif'></a> ");
           rawoutput("<a onClick=\"addSmiley(' *bow* ')\"><img src='./images/bow.gif'></a> ");
           rawoutput("<a onClick=\"addSmiley(' *kiss* ')\"><img src='./images/kiss.gif'></a> ");
           rawoutput("<a onClick=\"addSmiley(' *brokeheart* ')\"><img src='./images/brokeheart.gif'></a> ");
           rawoutput("<a onClick=\"addSmiley(' *wimper* ')\"><img src='./images/wimper.gif'></a> ");
           rawoutput("<a onClick=\"addSmiley(' *whew* ')\"><img src='./images/whew.gif'></a> ");
           rawoutput("<a onClick=\"addSmiley(' *cry* ')\"><img src='./images/cry.gif'></a> ");
           rawoutput("<a onClick=\"addSmiley(' *angel* ')\"><img src='./images/angel.gif'></a> ");
           rawoutput("<a onClick=\"addSmiley(' *nerd* ')\"><img src='./images/nerd.gif'></a> ");
           rawoutput("<a onClick=\"addSmiley(' *stop* ')\"><img src='./images/stop.gif'></a> ");
           rawoutput("<a onClick=\"addSmiley(' *zzz* ')\"><img src='./images/zzz.gif'></a> ");
           rawoutput("<a onClick=\"addSmiley(' *yakyak* ')\"><img src='./images/yakyak.gif'></a> ");
           rawoutput("<a onClick=\"addSmiley(' *shhh* ')\"><img src='./images/shhh.gif'></a> ");
           rawoutput("<a onClick=\"addSmiley(' *nottalking* ')\"><img src='./images/nottalking.gif'></a> ");
           rawoutput("<a onClick=\"addSmiley(' *party* ')\"><img src='./images/party.gif'></a> ");
           rawoutput("<a onClick=\"addSmiley(' *yawn* ')\"><img src='./images/yawn.gif'></a> ");
           rawoutput("<a onClick=\"addSmiley(' *doh* ')\"><img src='./images/doh.gif'></a> ");
           rawoutput("<a onClick=\"addSmiley(' *clap* ')\"><img src='./images/clap.gif'></a> ");
           rawoutput("<a onClick=\"addSmiley(' *lie* ')\"><img src='./images/lie.gif'></a> ");
           rawoutput("<a onClick=\"addSmiley(' *bateyes* ')\"><img src='./images/bateyes.gif'></a> ");
           rawoutput("<a onClick=\"addSmiley(' *pray* ')\"><img src='./images/pray.gif'></a> ");
           rawoutput("<a onClick=\"addSmiley(' *peace* ')\"><img src='./images/peace.gif'></a> ");
           rawoutput("<a onClick=\"addSmiley(' *nono* ')\"><img src='./images/nono.gif'></a> ");
           rawoutput("<a onClick=\"addSmiley(' *groove* ')\"><img src='./images/groove.gif'></a> ");
           rawoutput("<a onClick=\"addSmiley(' *giggle* ')\"><img src='./images/giggle.gif'></a> ");
           output("`c");
    }
    rawoutput("<script language=\"JavaScript\" type=\"text/javascript\">\n");
    rawoutput("function addSmiley(textToAdd)\n");
    rawoutput("{\n");
    rawoutput("document.$formname.$areaname.value += textToAdd;");
    rawoutput("document.$formname.$areaname.focus();\n");
    rawoutput("}\n");
    rawoutput("</script>\n");
}

function show_avatar($id){
    //thanks to anpera for the avatar module... altered copy and paste code from avatars.php below
    if (is_module_active('avatars')){
    if (get_module_pref('user_showavatar','avatars')==1){
            $avatar = get_module_pref("user_avatar","avatars",$id);
            $avatar = stripslashes(preg_replace("'[\"\'\\><@?*&#; ]'","",$avatar));
            if ($avatar <> ""){
                $maxwidth = (get_module_setting("maxwidth","avatars") * .5);
                $maxheight = (get_module_setting("maxheight","avatars") * .5);
                $pic_size = @getimagesize($avatar);
                $pic_width = ($pic_size[0] * .5);
                $pic_height = ($pic_size[1] * .5);
                if ($pic_width > $maxwidth) $pic_width = $maxwidth;
                if ($pic_height > $maxheigt) $pic_height = $maxheight;
                $av .= "`c<IMG SRC=\"".$avatar."\"";
                if ($pic_size[0] > 0) $av .= "title=\"\" alt=\"\" style=\"width: ".$pic_width."px; height: ".$pic_height."px;\"";
                $av .= ">`c<BR>\n";
            }
        }
    }
    return $av;
}

function forumhelp(){
       output("`c`b`2-`@=`2-`@=Help`@=`2-`@=`2-`b`c");
       output("<html><head><meta content=\"text/html; charset=ISO-8859-1\" http-equiv=\"content-type\"><title></title></head><body><strong>`#Index</strong><br>",true);
       output("<a href=\"#post\">`#Posting a new Thread</a><br>",true);
       output("<a href=\"#reply\">`#Replying to a thread or message</a><br>",true);
       output("<a href=\"#quote\">`#Quoting a message</a><br>",true);
       output("<a href=\"#click\">`#Clickables</a><br>",true);
       output("<a href=\"#edit\">`#Edit</a><br>",true);
       if (get_module_pref('forum')){
          output("<a href=\"#delete\">`#Deleting</a><br>",true);
       }
    output ("<br><strong><a name=\"post\"></a>Posting a New Thread </strong><br>",true);
    output ("You may post a new thread after %s dragon kills.&nbsp; The new thread link will appear when you acheive this level.&nbsp; You need to enter a title and message to post the new thread.&nbsp; Make sure your title is descriptive of what the thread is about.&nbsp; The message again should describe the new thread's purpose.&nbsp; Color codes do work for the title of the message and clickables work on the message section. <br>",get_module_setting('dks'),true);
    rawoutput ("<br>",true);
    output ("<strong><a name=\"reply\"></a>Replying to a thread or message </strong><br>",true);
    output ("After the last message in a thread the reply box will appear.&nbsp; You simply need to type your message in this area and select reply.&nbsp; Clickables work on the reply section. <br>",true);
    rawoutput ("<br>",true);
    output ("<strong><a name=\"quote\"></a>Quoting a message </strong><br>",true);
    output ("The quote link will appear by messages that can be quoted (one cannot quote a quoted message as this could get rather confusing).&nbsp; Quoting works just like replying except the quote text is entered for you.&nbsp; Clickables work on the quote section.&nbsp; Quoting is useful in addressing a specific statement by another person, and can reduce confusion as to what or whom you are addressing. <br>",true);
    rawoutput ("<br>",true);
    output ("<strong><a name=\"click\"></a>Clickables </strong><br>",true);
    output ("There are clickable color, bold/italics, and smileys in the New Thread, Reply and Quote sections.&nbsp; The clickables will insert the correct code at the END of the current comment section.&nbsp; <br>",true);
    rawoutput ("<br>",true);
    output ("<strong><a name=\"edit\"></a>Edit </strong><br>",true);
    output ("You may edit the messages that you have posted to fix grammar and mistakes.&nbsp; Click the edit link and you will be taken to the message editor where you can make the needed changes.&nbsp; Moderators can edit ALL messages for the purpose of removing inappropriate material ONLY. </strong>",true);
    if (get_module_pref('forum')){
        rawoutput ("<br>",true);
        output ("<strong><a name=\"delete\"></a>Deleting</strong> <br>",true);
        output ("Deleting messages is an admin/moderator only privilege.&nbsp; Deleting the first message of a thread will delete the ENTIRE thread.",true);
    }
    rawoutput ("<br>",true);
    rawoutput ("</body></html>",true);
}
?>