<?php
//special thanks to Ariadoss for all the input and the revamped help code.
//do catagories with module settings..... add field to forum table for catagory info
//category in forum table should be a number indicating which category it is in
//module setting should be the Name the setting should be saved as cat1,cat2, etc with
//that number corresponding with the numbers stored in the tables.... General catagory being 0
function forum_getmoduleinfo(){
    $info = array(
        "name"=>"LotGD Forum",
        "version"=>"2.1",
        "author"=>"`#Lonny Luberts",
        "category"=>"PQcomp",
        "download"=>"http://www.pqcomp.com/modules/mydownloads/visit.php?cid=3&lid=44",
        "vertxtloc"=>"http://www.pqcomp.com/",
        "prefs"=>array(
            "Forum Module User Preferences,title",
            "forum"=>"Forum Moderator,bool|0",
            "user_color"=>"Default Forum text Color,enum,`7,DkWhite,`1,DkBlue,`!,LtBlue,`2,DkGreen,`@,LtGreen,`3,DkCyan,`#,LtCyan,`4,DkRed,`$,LtRed,`5,DkMagenta,`%,LtMagenta,`6,DkYellow,`^,LtYellow,`&,LtWhite,`q,DkOrange,`Q,LtOrange",
            "dateread"=>"Date/time last entered forum,text|2005-01-01 01:00:00",
            "lastthread"=>"Last Thread Viewed,text|",
        ),
        "settings"=>array(
            "Forum Settings,title",
            "dks"=>"How many DK's before a player can post?,int|5",
            "showkey"=>"Show color Key?,bool|1",
            "usesmiley"=>"Use Smileys?,bool|1",
            "savebio"=>"Save Bio with user name?,bool|1",
            "newestpostdate"=>"Most recent post,text|2005-01-01 01:00:00",
        ),
    );
    return $info;
}

function forum_install(){
    global $session;
    if (!is_module_active('forum')){
        if ($session['user']['superuser']&~SU_DOESNT_GIVE_GROTTO) output("`4Installing Forum Module.`n");
    }else{
        if ($session['user']['superuser']&~SU_DOESNT_GIVE_GROTTO) output("`4Updating Forum Module.`n");
    }
    //database install
    if (!db_table_exists(db_prefix("logdforum"))){
	    $sql = "CREATE TABLE ".db_prefix("logdforum")." (";
	    $sql .= "`id` int(11) NOT NULL auto_increment,";
	    $sql .= "`postdate` datetime NOT NULL default '0000-00-00 00:00:00',";
	    $sql .= "`newpostdate` datetime NOT NULL default '0000-00-00 00:00:00',";
	    $sql .= "`author` text NOT NULL,";
	    $sql .= "`parent` int(11) NOT NULL default '0',";
	    $sql .= "`replies` int(11) NOT NULL default '0',";
	    $sql .= "`userid` int(11) NOT NULL default '0',";
	    $sql .= "`title` varchar(100) NOT NULL default '',";
	    $sql .= "`category` int(11) NOT NULL default '0',";
	    $sql .= "`content` text NOT NULL,";
	    $sql .= "PRIMARY KEY  (`id`)";
	    $sql .= ") TYPE=MyISAM;";
	    db_query($sql);
    }
    //database upgrade
    $sql = "Select userid FROM ".db_prefix("logdforum")." LIMIT 1";
    $result = mysql_query($sql);
    if (!$result) db_query("ALTER TABLE ".db_prefix("logdforum")." ADD `userid` int(11) NOT NULL default '0'");
    $sql = "Select category FROM ".db_prefix("logdforum")." LIMIT 1";
    $result = mysql_query($sql);
    if (!$result) db_query("ALTER TABLE ".db_prefix("logdforum")." ADD `category` int(11) NOT NULL default '0'");
    //end database upgrade
    module_addhook("village");
    module_addhook("footer-shades");
    return true;
}

function forum_uninstall(){
    output("`4Un-Installing Forum Module.`n");
    $sql = "DROP TABLE ".db_prefix("logdforum");
    db_query($sql);
    return true;
}

function forum_dohook($hookname,$args){
    addnav("Other");
    if (get_module_pref('dateread') < get_module_setting('newestpostdate')){
        addnav("`2`bLotGD Forum - `4NEW`b`0","runmodule.php?module=forum");
    }else{
        addnav("`2`bLotGD Forum`b`0","runmodule.php?module=forum");
    }
    return $args;
}

function forum_run(){
global $session,$SCRIPT_NAME;
if ($SCRIPT_NAME == "runmodule.php"){
	require_once("modules/lib/forum.php");
}
page_header("LotGD Forum");
output("`c`b`2-`@=`2-`@=LotGD Forum`@=`2-`@=`2-`b`c");
$start=httpget('op2');
set_module_pref('dateread',date("Y-m-d H:i:s"));
if (isset($_GET["op"])){
    $op = explode(":",$_GET["op"]);
    if ($op[0] == "thread"){
        showthread($op[1], $op[2]);
    }elseif ($op[0] == "new"){
        newthread();
    }elseif ($op[0] == "reply"){
        reply($start);
    }elseif ($op[0] == "list"){
        donothing($op[1]);
    }elseif ($op[0] == "delete"){
        delmess($op[1]);
    }elseif ($op[0] == "edit"){
        editmess($op[1]);
    }elseif ($op[0] == "saveedit"){
        saveedit($op[1]);
    }elseif ($op[0] == "quote"){
        quote($op[1],$start);
    }elseif ($op[0] == "help"){
        forumhelp();
    }
}else{
    donothing(0);
}

if ($_GET["op"]<>"") addnav("Forum Main","runmodule.php?module=forum");
//set refresh nav
$currentpage=$SCRIPT_NAME."?";
$args = $_SERVER['argv'];
for ($i=0;$i<$_SERVER['argc'];$i+=1){
    if (strchr($args[$i],"&c=")) $args[$i] = str_replace(strstr($args[$i],"&c="),"",$args[$i]);
    $currentpage.=$args[$i];
}
addnav("Refresh","$currentpage");
addnav("Forum Help","runmodule.php?module=forum&op=help");
//end set refresh nav
if ($session['user']['alive']==1){
    villagenav();
}else{
    addnav("Return to the Shades","shades.php");
}
//I cannot make you keep this line here but would appreciate it left in.
//especially since I never intended to release this! 8)
output("`n`n");
rawoutput("<div style=\"text-align: left;\"><a href=\"http://www.pqcomp.com\" target=\"_blank\">LotGD Forum by Lonny @ http://www.pqcomp.com</a><br>");
page_footer();    
}
?>