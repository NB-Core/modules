<?
// Terronville - last modified 2004.05.21, Craig Stimmel
if (!isset($session)) exit();

// tname allows Terronville to become Craugville or whatever :)
$tname = "Terron";

if ($HTTP_GET_VARS[op]==""){
	output("`^You wander out of the forest into a clearing with a single ");
	output("tent standing in the middle of it. A hand-scrawled sign stuck in ");
	output("the ground in front of the tent reads '`%$tname`%ville`^'. ");
	switch(e_rand(1,2)){
		case 1:
			output("`%$tname `^rises from the tree stump he was sitting on ");
			output("and says, \"`%Would you like to buy a monkey? Only 50 ");
			output("gold!`^\" ");
			addnav("Buy a monkey", "forest.php?op=buymonkey");
			addnav("Don't buy a monkey", "forest.php?op=nomonkey");
			$session[user][specialinc]="terronville.php";
			break;
		case 2:
			output("`%$tname `^and a sneaky looking co-conspirator rise from ");
			output("the tree stumps they were sitting on, plotting. `%$tname ");
			output("`^says, \"`%Welcome to $tname`%ville! Would you like to ");
			output("come in?`^\" ");
			addnav("Enter $tnameville", "forest.php?op=enter");
			addnav("Return to the forest", "forest.php?op=dont");
			$session[user][specialinc]="terronville.php";
			break;
	}
}else if ($HTTP_GET_VARS[op]=="buymonkey"){
	if ($session[user][gold]>=50){
		$session[user][gold]-=50;
		switch(e_rand(1,2)){
			case 1:
				output("`%$tname `^frees one of the monkeys and leads it ");
				output("over to you. It climbs onto your shoulder and ");
				output("perches there obediently. However, as soon as you ");
				output("are out of sight of `%$tnameville `^the monkey ");
				output("screeches loudly and scrambles off into the forest. ");
				output("When you return to the clearing to question `%$tname ");
				output("`^about this, `%$tname `^denies that he ever sold ");
				output("you a monkey.`n`n `^You lose your 50 gold!");
				break;
			case 2:
				output("`^You sit down and play with your monkey for awhile, ");
				output("but realize that it being a forest creature, it ");
				output("would probably be happier living in the forest, so ");
				output("you set it free. ");
				switch(e_rand(1,2)){
					case 1:
						output("`^The monkey looks at you for a moment, then ");
						output("runs off and clambers up a nearby tree. The ");
						output("monkey causes some branches to shake and ");
						output("something falls to the ground.`n`nYou find a ");
						output("gem!");
						$session[user][gems]+=1;
						break;
					case 2:
						output("`^The time spent playing with the monkey and ");
						output("the warm fuzzy feeling you get from your ");
						output("good deed energize you.`n`nYou gain a forest ");
						output("fight!");
						$session[user][turns]+=1;
						break;
				}
		}
	}else{
		output("`^\"`%You don't have enough money for a monkey! Get 'im!`^\" ");
		output("`%$tname`^ sets loose all of the monkeys. They leap on you, ");
		output("screeching and pulling your hair. You spin around trying to ");
		output("get them off and fall flat on your face.`n`n");
		output("You lose a forest fight! ");
		$session[user][turns]--;
	}
}else if ($HTTP_GET_VARS[op]=="nomonkey"){
	output("`^Not really wanting a pet to care for, you politely decline ");
	output("`%$tname`^'s offer and return to the forest. ");
}else if ($HTTP_GET_VARS[op]=="enter"){
	output("`%$tname `^holds aside the tent flap for you, allowing you to ");
	output("enter first. ");
	switch(e_rand(1,2)){
		case 1:
			output("`^Upon entering and seeing the pile of unconscious ");
			output("warriors on the ground you realize your error and ");
			output("quickly turn to face `%$tname`^, your weapon drawn. ");
			output("`%$tname `^raises his hands and says \"`%There, now... I ");
			output("can see ye're no fool. I'll not harm you. Let me tell ");
			output("you a story about an epic battle I once fought...`^\" ");
			output("`^You sit down and listen to his tale.`n`n");
			output("`^You learn from his story and gain experience!");
			$session[user][experience] *= 1.1;
			break;
		case 2:
			$stolen = e_rand(0,$session[user][gold]);
			output("`^You enter the tent and see a pile of unconscious ");
			output("warriors on the ground. You begin to turn to face ");
			output("`%Terrron `^but `%THUMP`^...`n`n");
			output("`^You awaken hours later to disover $stolen gold is ");
			output("missing from your pockets!");
			$session[user][gold]-=$stolen;
	}
}else if ($HTTP_GET_VARS[op]=="dont"){
	$stolen = e_rand(0,$session[user][gold]);
	output("`^You choose not to enter, and head back to the forest. Before ");
	output("you reach the edge of the clearing, you feel a `%THUMP `^on the ");
	output("back of your head...`n`n");
	output("`^You awaken to find the tent taken down and gone with `%$tname ");
	output("`^nowhere to be found. You check your pockets and find that ");
	output("$stolen gold is missing.");
	$session[user][gold]-=$stolen;
}else{
	output("`\$Well that was odd. You return to the forest. ");
}
?>