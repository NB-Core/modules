<?php
/*
Details:
 * This is a module to allow admin to create... disasters!
*/
function disaster_getmoduleinfo(){
	 $info = array(
		"name"=>"Disaster Strikes",
		"author"=>"`@CortalUX",
		"version"=>"1.6",
		"category"=>"General",
		"download"=>"http://dragonprime.net/users/CortalUX/disaster.zip",
		"vertxtloc"=>"http://dragonprime.net/users/CortalUX/",
		"settings"=>array(
			"Disaster Strikes - Settings,title",
			"worktoday"=>"Turns for working during a disaster?,range,1,30,1|20",
			"gold"=>"Gold per turn?,int|10",
			"gems"=>"Gems per turn?,float|0.2",
			"(please coordinate things from the Grotto),note",
			"Disaster Strikes - Penalties,title",
			"loseHealth"=>"Can users lose health?,bool|1",
			"healthChance"=>"Percentage change out of 100 to lose health?,range,1,100,5|25",
			"loseMax"=>"Maximum percentage to lose?,range,1,100,5|25",
			"Disaster Strikes - View Only,title",
			"location"=>"Which location has the disaster?,hidden|".getsetting("villagename", LOCATION_FIELDS),
			"prog"=>"Is a Disaster in progress?,hidden|0",
			"disa"=>"Which Disaster is in progress?,hidden|volcano",
			"who"=>"Who is helping?,hidden|",
			"Disasater Strikes - Automation Settings,title",
			"enablestart"=>"Enable automatic disaster start?,bool|1",
			"enableend"=>"Enable automatic disaster end?,bool|1",
			"rawchance"=>"1 in this number chance (cumulative) that a disaster will strike each server generated new day,int|1000",
			"Day 1 has 1 in this number chance of a disaster striking. If day 1 does not create disaster then second day will have a 2 in this number chance of a disaster striking., note",				
			"minturn"=>"What is the minimum amount of turns worked needed to end the disaster?,int|100",
			"maxturn"=>"What is the maximum amount of turns worked needed to end the disaster?,int|500",
			"totalworked"=>"Total turns worked,int|0",
			"totalend"=>"Turns needed to end disaster,int|0",
			"disturn"=>"How many game days has is been since the last disaster?,int|0",
		),
		"prefs"=>array(
			"Disaster Strikes - Preferences,title",
			"worked"=>"Turns can work today?,int|20",
			"worked2"=>"Turns worked?,int|0",
			"disasterm"=>"Can make disasters?,bool|0",
		),
		"requires"=>array(
			"cities"=>"1.0|By Eric Stevens, part of the core download",
		),
	 );
	return $info;
}

function disaster_install(){
	global $session;
	if (!is_module_active('disaster')){
		output("`n`c`b`QDisaster Module - Installed`0`b`c");
	}else{
		output("`n`c`b`QDisaster Module - Updated`0`b`c");
	}
	if ($session['user']['superuser']&SU_MANAGE_MODULES){
		set_module_pref('disasterm',1);
		output("`n`c`b`#PERFORM ALL OPERATIONS FROM THE GROTTO- NOT THE SETTINGS!`b`c");
	}
	module_addhook("pvpstart");
	module_addhook("newday-runonce");
	module_addhook("newday");
	module_addhook("village");
	module_addhook("superuser");
	return true;
}

function disaster_uninstall(){
	output("`n`c`b`QDisaster Module - Uninstalled`0`b`c");
	return true;
}

function disaster_dohook($hookname,$args){
	global $session;
	switch ($hookname){
		case "pvpstart":
			if ($session['user']['location']==get_module_setting('location')&&get_module_setting('prog')==1) {
				$d=disaster_array();
				$x=get_module_setting("disa");
				$x=$d[$x];
				$args['atkmsg']="`4".$x['atkmsg']."`n`nYou have `^%s`4 PvP fights left for today.`n`n";
				$args['schemas']['atkmsg']="module-disaster";
			}
		break;
		case "newday-runonce":
			if (get_module_setting('enablestart')) {
				$disturn = get_module_setting('disturn') + 1;
				if (e_rand(1, get_module_setting('rawchance')) <= $disturn && !get_module_setting('prog')) {
					$vloc=array();
					$vname=getsetting("villagename", LOCATION_FIELDS);
					$vloc[$vname]="village";
					$vloc=modulehook("validlocation", $vloc);
					$key=array_rand($vloc);
					set_module_setting("location", $key);
					set_module_setting("prog", 1);
					if (e_rand(1,2)==1){
						set_module_setting("disa", "volcano");
					} else {
						set_module_setting("disa", "tornado");
					}
					set_module_setting('totalend', e_rand(get_module_setting('minturn'),get_module_setting('maxturn')));
					set_module_setting('totalworked', 0);
					require_once('lib/addnews.php');
					addnews("`b`%A %s has struck %s!! Villagers scramble to rebuild their town!`b", get_module_setting('disa'), get_module_setting('location'));
				} elseif (!get_module_setting('prog') && get_module_setting('enablestart')) {
					set_module_setting('disturn', $disturn);
				}
			}
			$vloc = array();
			$vloc = modulehook("validlocation", $vloc);
			$vname = getsetting("villagename", LOCATION_FIELDS);
			$vloc[$vname]="village";
			$y=get_module_setting('location');
			if (!isset($vloc[$y])) {
				$key = array_rand($vloc);
				set_module_pref("location",$key);
			}
		break;
		case "newday":
			set_module_pref("worked",get_module_setting("worktoday"));
		break;
		case "village":
			if (get_module_setting('prog')==1&&$session['user']['location']==get_module_setting('location')) {
				redirect("runmodule.php?module=disaster&op=village");
			}
			if ($session['user']['superuser']&SU_DOESNT_GIVE_GROTTO&&get_module_pref('disasterm')==1){
			  addnav("Disasters");
			  addnav("Disaster!","runmodule.php?module=disaster&op=admin");
			}
		break;
		case "superuser":
			addnav("Module Configurations");
			if (get_module_pref('disasterm')==1) addnav("Disaster!","runmodule.php?module=disaster&op=admin");
		break;
	}
	return $args;
}

function disaster_run(){
	global $session;
	$op=httpget('op');
	if (get_module_setting('enableend')){
		$totalworked = get_module_setting('totalworked');
		$totalend = get_module_setting('totalend');
		if ($totalworked >= $totalend) {
			$op = "admin";
		}
	}
	switch ($op) {
		case "admin":
			page_header("Disaster!");
			$ty=httpget('ty');
			if (get_module_setting('prog')==1) {
				addnav("Actions");
				switch ($ty) {
					case "end":
						$d=disaster_array();
						$x=get_module_setting("disa");
						$x=$d[$x];
						require_once('lib/addnews.php');
						addnews($x['safe'],get_module_setting('location'),true);
						$who=get_module_setting("who");
						$who=explode(",",$who);
						$gold=get_module_setting("gold");
						$gems=get_module_setting("gems");
						$str="";
						if ($gold>0) {
							$str.=str_replace('%s',$gold,translate_inline("%s gold per turn you worked, "));
						}
						if ($gems>0) {
							if ($gems==1) $word=translate_inline("a gem");
							if ($gems>0&&$gems!=1) $word=str_replace('%s',$gems,translate_inline("%s gems"));
							$str.=$word.translate_inline(" per turn you worked, ");
						}
						require_once('lib/systemmail.php');
						foreach ($who as $val) {
							if ($val!='') {
								$turn=get_module_pref('worked2','disaster',$val);
								if ($turn>0) {
									$str.=translate_inline("and that makes ");
									if ($gold>0) {
										$goldi=$gold*$turn;
										$str.=str_replace('%s',$goldi,translate_inline("%s gold"));
									}
									if ($gems>0) {
										$gemsi=round($gems*$turn);
										if ($gemsi==1) $str.=translate_inline(" and a gem");
										if ($gemsi>0&&$gemsi!=1) $str.=str_replace('%s',$gemsi,translate_inline(" and %s gems"));
									}
									$mail=str_replace('%s',$str,translate_inline($x['pay']));
									$title=translate_inline("The end of the disaster!");
									systemmail($val,$title,$mail);
									$sql="UPDATE `".db_prefix("accounts")."` SET ";
									$x=false;
									if ($gemsi>0&&$gemsi!='') {
										$x=true;
										$sql.="gems=gems+$gemsi";
									}
									if ($goldi>0&&$goldi!='') {
										if ($x) $sql.=",";
										$sql.="gold=gold+$goldi";
									}
									$sql.=" WHERE acctid=$val";
									db_query($sql);
								}
							}
						}
						set_module_setting('who','');
						set_module_setting('prog',0);
						if (get_module_setting('enableend')){
							set_module_setting('totalworked', 0);
							set_module_setting('disturn', 0);
							set_module_setting('totalend', 0);
						}
						output("The Disaster has finished. All users have been paid, and notified.");
					break;
					default:
						addnav("End the Disaster","runmodule.php?module=disaster&op=admin&ty=end");
					break;
				}
			} else {
				if (httpget('stage')=='') {
					addnav("Start a Disaster","runmodule.php?module=disaster&op=admin&stage=1");
				} elseif (httpget('stage')==1) {
					if (get_module_setting('enableend')){
						set_module_setting('totalend', e_rand(get_module_setting('minturn'),get_module_setting('maxturn')));
					}
					$vloc = array();
					$vloc = modulehook("validlocation", $vloc);
					$vname = getsetting("villagename", LOCATION_FIELDS);
					$vloc[$vname]="village";
					$str="";
					foreach ($vloc as $name=>$area) {
						$str.=",$name,$name";
					}
					$d=disaster_array();
					$strd="";
					foreach ($d as $name=>$val) {
						$strd.=",$name,$name";
					}
					$form=array(
						"Disaster Creation,title",
						"town"=>"Town?,enum$str",
						"disaster"=>"Disaster?,enum$strd",
						"worktoday"=>"Max Turns for helping to fix a disaster?,range,1,30,1",
						"gold"=>"Gold paid per turn?,int",
						"gems"=>"Gems paid per turn?,float",
					);
					$empty=array('town'=>$vname,'disaster'=>'volcano','worktoday'=>20,'gold'=>10,'gems'=>0.2);
					rawoutput("<form action='runmodule.php?module=disaster&op=admin&stage=2' method='post'>");
					addnav("","runmodule.php?module=disaster&op=admin&stage=2");
					require_once('lib/showform.php');
					showform($form,$empty);
					rawoutput("</form>");
				} else {
					$l=httppost('town');
					set_module_setting('location',$l);
					$d=httppost('disaster');
					set_module_setting('disa',$d);
					set_module_setting('worktoday',httppost('worktoday'));
					$gold=httppost('gold');
					if ($gold<=0) $gold=1;
					set_module_setting('gold',$gold);
					set_module_setting('gems',$gems);
					set_module_setting('prog',1);
					set_module_setting('who','');
					$x=disaster_array();
					$x=$x[$d];
					require_once('lib/addnews.php');
					addnews($x['news'],$l,true);
					output("The disaster has begun!");
				}
			}
			require_once('lib/superusernav.php');
			superusernav();
			if (get_module_setting('enableend')){
				if ($session['user']['superuser'] &~ SU_DOESNT_GIVE_GROTTO){
					require_once('lib/superusernav.php');
					superusernav();
				}else{
					villagenav();
				}
			}else{
				require_once('lib/superusernav.php');
				superusernav();
			}
			page_footer();
		break;
		case "help":
			disaster_desc(get_module_setting("disa"),"help");
		break;
		case "village":
			disaster_desc(get_module_setting("disa"),"village");
		break;
		case "journey":
			$d=disaster_array();
			$x=get_module_setting("disa");
			$d=$d[$x];
			page_header($d['jnav']);
			output($d['jdesc']);
			addnav("Navigation");
			addnav("Continue","runmodule.php?module=disaster&op=journeyend");
			page_footer();
		break;
		case "journeyend":
			$d=disaster_array();
			$x=get_module_setting("disa");
			$d=$d[$x];
			page_header($d['jnav']);
			$vloc = array();
			$vloc = modulehook("validlocation", $vloc);
			$vname = getsetting("villagename", LOCATION_FIELDS);
			$vloc[$vname]="village";
			$l=$session['user']['location'];
			unset($vloc[$l]);
			if (is_module_active('newbieisland')) {
				$l=get_module_setting('villagename','newbieisland');
				unset($l);
			}
			$key = array_rand($vloc);
			$session['user']['location']=$key;
			output($d['jend'],$session['user']['location']);
			addnav("Navigation");
			addnav(array("Enter %s",$session['user']['location']),"village.php");
			page_footer();
		break;
		case "place":
			disaster_desc(get_module_setting("disa"),"place");
		break;
		case "helpstart":
			disaster_desc(get_module_setting("disa"),"helpstart");
		break;
	}
}

function disaster_desc($area="volcano",$type="") {
	global $session;
	$d=disaster_array();
	$x=$d[$area];
	switch ($type) {
		case "village":
			page_header(array($x['vname'],$session['user']['location']));
			if (file_exists($x['pico'])&&file_exists($x['pict'])&&file_exists($x['pich'])) {
				$o=$x['pico'];
				$t=$x['pict'];
				$h=$x['pich'];
				$s=$x['speed'];
				$n=$x['number'];
				disaster_script($o,$t,$h,$s,$n);
			}
			output($x['desc']);
			addnav("Navigation");
			if (getsetting("pvp",1)){
				addnav("S?Slay Other Players","pvp.php");
			}
			addnav($x['quit']." (Quit)","login.php?op=logout",true);
			addnav($x['jnav'],"runmodule.php?module=disaster&op=journey");
			addnav($x['nav'],"runmodule.php?module=disaster&op=place");
			$who=get_module_setting("who");
			$who=explode(",",$who);
			if (in_array($session['user']['acctid'],$who)) {
				$b=$x['work'];
				$nav=array_rand($b,1);
				addnav("Actions");
				addnav($nav,"runmodule.php?module=disaster&op=help&ty=".urlencode($nav));
			}
			$vloc = array();
			$vloc = modulehook("validlocation", $vloc);
			$vname = getsetting("villagename", LOCATION_FIELDS);
			$vloc[$vname]="village";
			rawoutput("<br/><br/><hr width='80%'>");
			output("`n`^You can hear the moans of the dead and wounded... and those that are helping...`n");
			$loc=$session['user']['location'];
			require_once('lib/commentary.php');
			addcommentary();
			viewcommentary($vloc[$loc],"`#Talk?`@",16,"talks");
			addnav("Superuser");
			if ($session['user']['superuser'] & SU_EDIT_COMMENTS){
				addnav(",?Comment Moderation","moderate.php");
			}
			if ($session['user']['superuser']&~SU_DOESNT_GIVE_GROTTO){
			  addnav("X?`bSuperuser Grotto`b","superuser.php");
			}
			if ($session['user']['superuser'] & SU_INFINITE_DAYS){
			  addnav("/?New Day","newday.php");
			}
			modulehook("disaster-footer",array('disa'=>$area));
			page_footer();
		break;
		case "help":
			page_header(array($x['vname'],$session['user']['location']));
			if ($session['user']['turns']>0&&get_module_pref("worked")>0) {
				$session['user']['turns']--;
				set_module_pref('worked',(get_module_pref('worked')-1));
				set_module_pref('worked2',(get_module_pref('worked2')+1));
				if (get_module_setting('enableend')){			
					set_module_setting('totalworked', get_module_setting('totalworked') + 1);
				}
				$t=httpget('ty');
				$b=$x['work'][$t];
				output_notl("`^");
				output($b);
				output("`n`^You use up one turn. Your money will be paid once the disaster finishes.`nYou have `@%s`^ turns left, but you'll be too tired to work in `@%s`^ turns..",$session['user']['turns'],get_module_pref('worked'));
				if (get_module_setting("loseHealth")==1) {
					if (e_rand(1,100)<=get_module_setting("healthChance")) {
						$health=$session['user']['hitpoints'];
						$amount=e_rand(1,get_module_setting("loseMax"));
						$health=($health/100)*$amount;
						$health=round($health);
						$session['user']['hitpoints']-=$health;
						if ($session['user']['hitpoints']<=0) $session['user']['hitpoints']=0;
						output("`n`\$".$x['hurt'],$health);
					}
				}
			}
			if ($session['user']['hitpoints']<=0) {
				$session['user']['alive']=false;
				$session['user']['experience']=round($session['user']['experience']*.9,0);
				addnews("`^%s`4 died helping the inhabitants of `@%s`4.",$session['user']['name'],str_replace("%s",$session['user']['location'],translate_inline($x['vname'])));
				addnav("`\$Death!!!");
				addnav("Daily news","news.php");
				output("`n`4`c`bYou have died.`b`c");
				output("`n`4`c`b10% of experience has been lost.`b`c");
			} else {
				addnav("Navigation");
				addnav("Look at the Place","runmodule.php?module=disaster&op=village");
				addnav($x['jnav'],"runmodule.php?module=disaster&op=journey");
				if ($session['user']['turns']>0&&get_module_pref("worked")>0) {
					disaster_helpnav($area);
				} else {
					output("`^You can't work any more today.");
				}
				modulehook("disaster-footer",array('disa'=>$area));
			}
			page_footer();
		break;
		case "place":
			page_header($x['title']);
			output($x['navd']);
			addnav("Navigation");
			addnav($x['nave'],"runmodule.php?module=disaster&op=village");
			addnav($x['jnav'],"runmodule.php?module=disaster&op=journey");
			disaster_helpnav($area);
			rawoutput("<br/><br/><hr width='80%'>");
			output("`n`^You can talk to others in this time of crisis...`n");
			require_once('lib/commentary.php');
			addcommentary();
			viewcommentary("disaster-$area","`#Talk?`@",25,"talks");
			modulehook("disaster-footer",array('disa'=>$area));
			page_footer();
		break;
		case "helpstart":
			page_header($x['title']);
			$who=get_module_setting("who");
			$who=explode(",",$who);
			$who[]=$session['user']['acctid'];
			$who=implode(",",$who);
			set_module_setting("who",$who);
			set_module_pref('worked',get_module_setting('worktoday'));
			require_once('lib/addnews.php');
			addnews($x['hnews'],$session['user']['name']);
			output($x['help']);
			output("`n`^Helping will take up one turn each time. You can help for a maximum of %s turns.",get_module_setting("worktoday"));
			addnav("Navigation");
			addnav($x['nave'],"runmodule.php?module=disaster&op=village");
			addnav($x['jnav'],"runmodule.php?module=disaster&op=journey");
			disaster_helpnav($area);
			modulehook("disaster-footer",array('disa'=>$area));
			page_footer();
		break;
	}
}

function disaster_helpnav($disa="") {
	global $session;
	$d=disaster_array();
	$x=$d[$disa]['work'];
	addnav("Navigation");
	$who=get_module_setting("who");
	$who=explode(",",$who);
	if (in_array($session['user']['acctid'],$who)) {
		$nav=array_rand($x,1);
		$w=$x[$nav];
		addnav("Actions");
		addnav($nav,"runmodule.php?module=disaster&op=help&ty=".urlencode($nav));
	} else {
		addnav("Sign up to Help","runmodule.php?module=disaster&op=helpstart");
	}
}

function disaster_array() {
	$array=array(
		"volcano"=>array(
			"pico"=>"images/disaster/lava1.png",
			"pict"=>"images/disaster/lava2.png",
			"pich"=>"images/disaster/lava3.png",
			"speed"=>6,
			"number"=>6,
			"atkmsg"=>"Looking behind the tent, you see some sleeping warriors... maybe they thought no-one would callously attack them during a disaster... ha.",
			"vname"=>"The Volcanic Desolation of %s",
			"desc"=>"`\$Lava and `Qash`\$ covers the ground... nothing of this former location can be seen, buried under many tonnes of fine dust.`nA yellow cloud hovers above, as the poison from the volcanic gas dissipates...",
			"news"=>"`\$A volcano has erupted, covering `^%s`\$ with ash, dust, and gas!!!",
			"nav"=>"A Tent",
			"quit"=>"Sleep behind the tent",
			"title"=>"GVT Tent",
			"navd"=>"`^At the side of the desolation is a small tent- entering it, you find the GVT (Geographic Volcano Trust) with plans underway for clearing away parts of the town. Maybe you could sign up... for a fee.",
			"nave"=>"Outside",
			"help"=>"Hearing of these efforts, you offer to help... for a fee.",
			"jnav"=>"Journey",
			"jdesc"=>"`\$Having seen the desolation of this place, you decide to move away as quickly as possible before another eruption occurs- so you pick a destination, and begin to run...",
			"jend"=>"`\$Having run like a cowardly cat, you sight %s.",
			"pay"=>"`@The GVT, Geographic Volcano Trust, has paid you your wage... you have earnt %s.",
			"hnews"=>"%s`\$ has signed up to help with clearing the volcanic dust...",
			"safe"=>"%s`@ has been restored, and it is as if the volcano was never there...",
			"hurt"=>"You trip and fall on a pile of ash! You lose %s hitpoints.",
			"work"=>array(
				"Shovel Dust"=>"You spend some time shovelling still-warm dust... the reward had better be worth it!",
				"Suck up Gas"=>"You 'borrow' some bagpipes from a weirdo in the GVT... and begin to suck up the deadly gas... you didn't think he played well anyway...",
				"Excavate Buildings"=>"You begin to excavate some buildings, before leaving the experts to it.",
			),
		),
		"tornado"=>array(
			"pico"=>"images/disaster/tornado1.png",
			"pict"=>"images/disaster/tornado2.png",
			"pich"=>"images/disaster/tornado3.png",
			"speed"=>525,
			"number"=>8,
			"atkmsg"=>"You look in the blown-out shell... hehehe. People sleeping...",
			"vname"=>"The Tornado-Stricken Village of %s",
			"desc"=>"`#Pieces of housing, carts, and planking litter the ground... Tornados still approach, but it should be safe to rebuild... it will never completely approach it's former glory, and will be a village for the time-being.",
			"news"=>"`#A Tornado has stricken `^%s`#, and it needs to be rebuilt!!!",
			"nav"=>"Blown-out Husk of a Building",
			"quit"=>"Sleep in the Husk",
			"title"=>"The Husk",
			"navd"=>"`^A small blown-out husk of a building has survived, and the rescue operations are being overseen from here. Maybe you could help... for a price.",
			"nave"=>"Outside",
			"help"=>"Hearing of these efforts, you offer to help... for a small price.",
			"jnav"=>"Run",
			"jdesc"=>"`^Seeing a Tornado approach, you decide to move away- so you pick a destination, and begin to run...",
			"jend"=>"`^Having saved your own wimpy skin, you sight %s.",
			"pay"=>"`@The VOBTSPT (Village of Bereaved Thingies, Sentient People Trust), has paid you your wage... you have earnt %s.",
			"hnews"=>"%s`# has signed up to help with the Tornado Rebuilding...",
			"safe"=>"%s`# has been restored, and Tornado prevention centres have been erected...",
			"hurt"=>"You trip and fall on a roofing tile! You lose %s hitpoints.",
			"work"=>array(
				"Salvage Tiles"=>"You salvage roofing tiles.",
				"Look for someone to Rescue"=>"You scout around, and search for someone to rescue.",
				"Watch for Tornadoes"=>"You watch for Tornadoes.... zzz....",
				"Comfort Survivors"=>"You comfort the survivors...",
			),
		),
	);
	$dis=modulehook("disaster-disasters",$array);
	return $dis;
}

function disaster_script($move1="",$move2="",$move3="",$speed=3,$number=15) {
	$script="<script language=\"JavaScript1.2\">
	<"."!-- Begin
	
	var no = $number; // image number or falling rate
	var speed = $speed; // the lower the number the faster the image moves
	var disasterimage = new Array();
	disasterimage[0] = \"$move1\"
	disasterimage[1] = \"$move2\"
	disasterimage[2] = \"$move3\"
	
	var ns4up = (document.layers) ? 1 : 0;  // browser sniffer
	var ie4up = (document.all) ? 1 : 0;
	var ns6up = (document.getElementById&&!document.all) ? 1 : 0;
	var dx, xp, yp;    // coordinate and position variables
	var am, stx, sty;  // amplitude and step variables
	var i, doc_width = 800, doc_height = 1800;
	
	if (ns4up||ns6up) {
	        doc_width = self.innerWidth;
	        doc_height = self.innerHeight;
	} else if (ie4up) {
	        doc_width = document.body.clientWidth;
	        doc_height = document.body.clientHeight;
	}
	
	dx = new Array();
	xp = new Array();
	yp = new Array();
	am = new Array();
	stx = new Array();
	sty = new Array();
	j = 0;
	
	for (i = 0; i < no; ++ i) {
	        dx[i] = 0;                        // set coordinate variables
	        xp[i] = Math.random()*(doc_width-50);  // set position variables
	        yp[i] = Math.random()*doc_height;
	        am[i] = Math.random()*20;         // set amplitude variables
	        stx[i] = 0.02 + Math.random()/10; // set step variables
	        sty[i] = 0.7 + Math.random();     // set step variables
	        if (ns4up) {                      // set layers
	                if (i == 0) {
	                        document.write(\"<layer name=\\\"dot\"+ i +\"\\\" left=\\\"15\\\" top=\\\"15\\\" visibility=\\\"show\\\"><img src=\\\"\"+ disasterimage[j] + \"\\\" border=\\\"0\\\"></layer>\");
	                } else {
	                        document.write(\"<layer name=\\\"dot\"+ i +\"\\\" left=\\\"15\\\" top=\\\"15\\\" visibility=\\\"show\\\"><img src=\\\"\"+ disasterimage[j] + \"\\\" border=\\\"0\\\"></layer>\");
	                }        } else if (ie4up||ns6up) {                if (i == 0) 
	{
	                        document.write(\"<div id=\\\"dot\"+ i +\"\\\" style=\\\"POSITION: absolute; Z-INDEX: \"+ i +\"VISIBILITY: visible; TOP: 15px; LEFT: 15px; width:1;\\\"><img src=\\\"\" + disasterimage[j] + \"\\\" border=\\\"0\\\"></div>\");
	                } else {
	                        document.write(\"<div id=\\\"dot\"+ i +\"\\\" style=\\\"POSITION: absolute; Z-INDEX: \"+ i +\"VISIBILITY: visible; TOP: 15px; LEFT: 15px; width:1;\\\"><img src=\\\"\" + disasterimage[j] + \"\\\" border=\\\"0\\\"></div>\");
	                }
	        }
	        if (j == (disasterimage.length-1)) { j = 0; } else { j += 1; }
	}
	
	function disasterimageNS() {  // Netscape main animation function
	        for (i = 0; i < no; ++ i) {  // iterate for every dot
	                yp[i] -= sty[i];                if (yp[i] < -50) {
	                        xp[i] = Math.random()*(doc_width-am[i]-30);
	                        yp[i] = doc_height;
	                        stx[i] = 0.02 + Math.random()/10;
	                        sty[i] = 0.7 + Math.random();
	                        doc_width = self.innerWidth;
	                        doc_height = self.innerHeight;                }
	                dx[i] += stx[i];
	                document.layers[\"dot\"+i].top = yp[i]+pageYOffset;
	                document.layers[\"dot\"+i].left = xp[i] + 
	am[i]*Math.sin(dx[i]);
	        }
	        setTimeout(\"disasterimageNS()\", speed);
	}
	
	function disasterimageIE_NS6() {  // IE main animation function
	        for (i = 0; i < no; ++ i) {  // iterate for every dot
	                yp[i] -= sty[i];
	                if (yp[i] < -50) {
	                        xp[i] = Math.random()*(doc_width-am[i]-30);
	                        yp[i] = doc_height;
	                        stx[i] = 0.02 + Math.random()/10;
	                        sty[i] = 0.7 + Math.random();
	                        doc_width = ns6up?window.innerWidth-5:document.body.clientWidth;
	                        doc_height = ns6up?window.innerHeight-5:document.body.clientHeight;
	                }
	                dx[i] += stx[i];
	                if (ie4up){
	                document.all[\"dot\"+i].style.pixelTop = yp[i]+document.body.scrollTop;
	                document.all[\"dot\"+i].style.pixelLeft = xp[i] + am[i]*Math.sin(dx[i]);
	                }
	                else if (ns6up){
	                document.getElementById(\"dot\"+i).style.top=yp[i]+pageYOffset;
	                document.getElementById(\"dot\"+i).style.left=xp[i] + am[i]*Math.sin(dx[i]);
	                }
	        }
	        setTimeout(\"disasterimageIE_NS6()\", speed);
	}
	
	if (ns4up) {
	        disasterimageNS();
	} else if (ie4up||ns6up) {
	        disasterimageIE_NS6();
	}
	/"."/ End -->
	</script>";
	rawoutput($script);
}
?>