<?
/**************************************************/
/* Gem Giant                                      */
/* ---------                                      */
/* Version 1.11                                   */
/* Written by Jake Taft (Zanzaras)                */
/**************************************************/

/************************************************/
/* Version History                              */
/* ---------------                              */
/* 1.0 - Original release. - Zanzaras           */
/* 1.01 - Added an addnews line. - Zanzaras     */
/* 1.02 - Fixed a bug that was not subtracting  */
/*        turns from the players. - Zanzaras    */
/* 1.03 - Reworked some of the code. - Zanzaras */
/* 1.04 - Fixed a spelling error. - Zanzaras    */
/* 1.05 - Added a description field to the      */
/*        module. - Zanzaras                    */
/* 1.1 - Added an option to allow the Gem Giant */
/*       to not attack other giants. - Zanzaras */
/* 1.11 - Small bug fix involving the GemGiant  */
/*        attacking other giants; Tweaked the   */
/*        verbage & code a bit. - Zanzaras      */
/************************************************/

/*********************************************************************************/
/* Setup instructions                                                            */
/* ------------------                                                            */
/* Copy this file to the "Module" directory inside the main lotgd directory then */
/* in the game go to Manage modules in the Grotto and Install/Activate it.       */
/*********************************************************************************/

function gemgiant_getmoduleinfo()
         {$info = array("name"=>"Gem Giant",
                        "author"=>"Jake Taft (Zanzaras)",
                        "version"=>"1.11",
                        "category"=>"Forest Specials",
                        "description"=>"The players encounter a giant in the forest that robs them of gems and gold.",
                        "download"=>"http://dragonprime.net/users/Zanzaras/GemGiant%20Module.zip",
                        "vertxtloc"=>"http://dragonprime.net/users/Zanzaras/",
                        "settings"=>array("Gem Giant Settings,title",
                                          "meangiant"=>"Does the Gem Giant attack other giants,bool|1",
                                          "gianttakesgold"=>"Will the Gem Giant take the player's gold,bool|1",
                                          "goldlost"=>"Percentage of gold lost to the Gem Giant,range,10,100,10|50",
                                          "gemslost"=>"Percentage of gems lost to the Gem Giant,range,10,100,10|50",
                                          "turnslost"=>"Number of turns non-giants lose while gathering their equipment,int|1",
                                          "This is also the number of turns a giant loses while talking to the Gem Giant.,note"
                                         )
                       );
          return $info;
         }

function gemgiant_install()
         {module_addeventhook("forest", "return 100;");
          return true;}

function gemgiant_uninstall(){return true;}

function gemgiant_dohook($hookname, $args){return $args;}

function gemgiant_runevent($type)
         {global $session;
          $from = "forest.php?";
          $session['user']['specialinc'] = "module:gemgiant";
          $op = httpget('op');

          $goldlost = round($session['user']['gold'] * (get_module_setting("goldlost")*.01));
          $gemslost = round($session['user']['gems'] * (get_module_setting("gemslost")*.01));
          $turnslost = get_module_setting("turnslost");
          $gianttakesgold = get_module_setting("gianttakesgold");
          if ($session['user']['race'] == 'Storm Giant' or $session['user']['race'] == 'Giant')
             $isplayeragiant = true;
            else $isplayeragiant = false;

          if ($isplayeragiant == true and get_module_setting("meangiant") == false)
             {output("`7You hear a horrendous crashing noise and suddenly you're face to face with another very angry giant!");
              output("You ready yourself for combat, when suddenly the other giant's expression changes to one of surprise and glee.");
              output("`n`n\"`QWell slap me down! How ya doin' `#%s`Q? It's been ages since I've seen you!`7\"",$session['user']['name']);
              output("`n`n`7As he yammers on, you stare dumbfounded trying to remember who this guy is.");
              output("After a while, you think you remember taking a dwarf-tossing class with him back in giant school.");
              output("`n`nHe goes on talking for what seems like hours without stopping to draw a breath.");
              output("You eventually find a way to ungracefully extract yourself from the conversation and quickly leave...");
              output("`n`nbut not before losing `4%s`7 turns!`n",$turnslost);
              $session['user']['turns']-= $turnslost;
              addnews("%s talked for hours with an old \"friend\" in the forest!",$session['user']['name']);
             }

          if ($isplayeragiant == true and get_module_setting("meangiant") == true)
             {if ($gianttakesgold == true)
                 {$session['user']['gold']-=$goldlost;
                  $session['user']['gems']-=$gemslost;
                  $session['user']['turns']-=$turnslost;
                 }
              output("`7You hear a horrendous crashing noise and suddenly you're face to face with another very angry giant!");
              output("You don't recognize him as being from your clan. He gives you a quick once over, snarls wickedly and promptly attacks!");
              output("`n`nYou're holding your own until he smacks you with the large, heavy sack he's carrying. As you stagger back, dazed,");
              if ($gianttakesgold==true) output("he rips your gem and gold pouches from you and dumps their contents hurriedly into his sack and runs off.`n");
                else output("he rips your gem pouch from you and dumps it's contents hurriedly into his sack and runs off.`n");
              output("`nIt only takes a few seconds to recover, but your assailant has too much of a headstart.");
              if ($gianttakesgold==true) output("You retrieve your pouches on the trail and vow to track down this thief and make him pay!`n`n");
                else output("You retrieve your gem pouch on the trail and vow to track down this thief and make him pay!`n`n");

              if ($gianttakesgold == true)
                 {if ($gemslost > 1)
                     {if ($goldlost > 0) output("You lost `4%s gold`7 and `4%s`7 gems to that thief and spent `4%s`7 turns fuming about it!`n",$goldlost,$gemslost,$turnslost);
                        else output("You lost `4%s`7 gems to that thief and spent `4%s`7 turns fuming about it!`n",$gemslost,$turnslost);
                     }
                  if ($gemslost == 1)
                     {if ($goldlost > 0) output("You lost `4%s gold`7 and `41`7 gem to that thief and spent `4%s`7 turns fuming about it!`n",$goldlost,$turnslost);
                        else output("You lost `41`7 gem to that thief and spent `4%s`7 turns fuming about it!`n",$turnslost);
                     }
                  if ($gemslost < 1)
                     {if ($goldlost > 0) output("You lost `4%s gold`7 and spent `4%s`7 turns fuming about it!`n",$goldlost,$turnslost);
                        else output("Luckily nothing of value was lost but you spent `4%s`7 turns fuming about the attack!`n",$turnslost);
                     }
                 }
                 
              if ($gianttakesgold == false)
                 {if ($gemslost > 1) output("You lost `4%s`7 gems to that thief and spent `4%s`7 turns fuming about it!`n",$gemslost,$turnslost);
                  if ($gemslost == 1) output("You lost 1 gem to that thief and spent `4%s`7 turns fuming about it!`n",$turnslost);
                  if ($gemslost < 1) output("Luckily nothing of value was lost but you spent `4%s`7 turns fuming about the attack!`n",$turnslost);
                 }
              if ($session['user']['gold'] < 0) $session['user']['gold'] = 0;
              if ($session['user']['gems'] < 0) $session['user']['gems'] = 0;
              if ($session['user']['turns'] < 0) $session['user']['turns'] = 0;
              addnews("%s was sucker punched and mugged in the forest by a huge giant!",$session['user']['name']);
             }

          if ($isplayeragiant == false)
             {output("`7Suddenly, a horrible crashing noise startles you and a huge giant grabs your legs, turns you upside down and begins shaking you vigorously over an open bag.");
              output("All of your equipment and valuables go flying everywhere! After everything stops falling, the giant holds you up, looks you over and shakes you one last time. When nothing falls out, he tosses you off to the side like a rag doll, hefts his bag over his shoulder and leaves.`n`n");

              if ($gianttakesgold == true)
                 {$session['user']['gold']-=$goldlost;
                  $session['user']['gems']-=$gemslost;
                  $session['user']['turns']-=$turnslost;

                  if ($gemslost > 1)
                     {output("Once your head stops spinning, you look around and see equipment, gold coins and gems scattered everywhere.");
                      if ($goldlost > 0) output("It takes you a while to gather everything up, but once you do, you discovered you've lost `4%s gold`7 and `4%s gems`7!`n`n",$goldlost,$gemslost);
                        else output("It takes you a while to gather everything up, but once you do, you discovered you've lost `4%s gems`7!`n`n",$gemslost);
                      if ($turnslost > 1) output("In addition to your valuables, you lost `4%s`7 turns gathering up your stuff.",$turnslost);
                      if ($turnslost == 1) output("In addition to your valuables, you lost `4%s`7 turn gathering up your stuff.",$turnslost);
                     }
                  if ($gemslost == 1)
                     {output("Once your head stops spinning, you look around and see equipment and gems scattered everywhere.");
                      if ($goldlost > 0) output("It takes you a while to gather everything up, but once you do, you discovered you've lost `4%s gold`7 and `4%s gem`7!`n`n",$goldlost,$gemslost);
                        else output("It takes you a while to gather everything up, but once you do, you discovered you've lost `4%s gem`7!`n`n",$gemslost);
                      if ($turnslost > 1) output("In addition to your valuables, you lost `4%s`7 turns gathering up your stuff.",$turnslost);
                      if ($turnslost == 1) output("In addition to your valuables, you lost `4%s`7 turn gathering up your stuff.",$turnslost);
                     }
                  if ($gemslost < 1)
                     {output("Once your head stops spinning, you look around and see equipment and gold coins scattered everywhere.");
                      if ($goldlost > 0) output("It takes you a while to gather everything up, but once you do, you discovered you've lost `4%s gold`7!`n`n",$goldlost,$gemslost);
                        else output("It takes you a while to gather everything up, but luckily you didn't have anything of real value on you.`n`n");
                      if ($turnslost > 1) output("In addition to your valuables, you lost `4%s`7 turns gathering up your stuff.",$turnslost);
                      if ($turnslost == 1) output("In addition to your valuables, you lost `4%s`7 turn gathering up your stuff.",$turnslost);
                     }
                 }

              if ($gianttakesgold == false)
                 {$session['user']['gems']-=$gemslost;
                  $session['user']['turns']-=$turnslost;
                  if ($gemslost > 1)
                     {output("Once your head stops spinning, you look around and see equipment and gems scattered everywhere.");
                      output("It takes you a while to gather everything up, but once you do, you discovered you've lost 4%s gems`7!`n`n",$gemslost);
                      if ($turnslost > 1) output("In addition to your valuables, you lost `4%s`7 turns gathering up your stuff.",$turnslost);
                      if ($turnslost == 1) output("In addition to your valuables, you lost `4%s`7 turn gathering up your stuff.",$turnslost);
                     }
                  if ($gemslost == 1)
                     {output("Once your head stops spinning, you look around and see equipment and gems scattered everywhere.");
                      output("It takes you a while to gather everything up, but once you do, you discovered you've lost 4%s gem`7!`n`n",$gemslost);
                      if ($turnslost > 1) output("In addition to your valuables, you lost `4%s`7 turns gathering up your stuff.",$turnslost);
                      if ($turnslost == 1) output("In addition to your valuables, you lost `4%s`7 turn gathering up your stuff.",$turnslost);
                     }
                  if ($gemslost < 1)
                     {output("Once your head stops spinning, you look around and see your gear scattered everywhere.");
                      output("It takes you a while to gather everything up, but luckily you didn't have anything of real value on you.`n`n");
                      if ($turnslost > 1) output("You lost `4%s`7 turns gathering up your stuff.",$turnslost);
                      if ($turnslost == 1) output("You lost `4%s`7 turn gathering up your stuff.",$turnslost);
                     }
                 }
              if ($session['user']['gold'] < 0) $session['user']['gold'] = 0;
              if ($session['user']['gems'] < 0) $session['user']['gems'] = 0;
              if ($session['user']['turns'] < 0) $session['user']['turns'] = 0;
              addnews("%s was tossed around like a sack of potatoes in the forest by a huge giant!",$session['user']['name']);
             }
          $session['user']['specialinc'] = "";
         }
?>
