<?php
/**
* Version:      1.0
* Date:         November 26, 2004
* Author:       Kevin Hatfield - Arune http://www.dragonprime.net
* LOGD VER:     Module for 0.9.8
*
*/
require_once("lib/http.php");
function supriv_getmoduleinfo(){
        $info = array(
                "name"=>"SU-Priv Module",
                "author"=>"Kevin Hatfield - Arune<br>Modified by `!Hex",
                "version"=>"1.0",
                "category"=>"Administrative",
		    "download"=>"http://dragonprime.net/users/Hex/supriv.zip",
                "prefs"=>array(
                "noincrement"=>"Reset hunger/bladder/odor every newday for this user?,bool|0",
                ), 
		);
        return $info;
}
function supriv_install(){
        if (!is_module_active('supriv')){
                output("`4Installing SU-Priv Module.`n");
        }else{
                output("`4Updating SU-Priv Module.`n");
        }
        module_addhook("newday");
        return true;
}
function supriv_uninstall(){
        return true;
}
function supriv_dohook($hookname, $args){
        global $session;
        switch($hookname){
        case "newday":
        	if (get_module_pref('noincrement')){
        		if(is_module_active('bladder')){
            		set_module_pref('bladder',0,'bladder');
            	}
            	if(is_module_active('odor')){
		 			set_module_pref('odor',0,'odor');
		 		}
		 		if(is_module_active('usechow')){
		 			set_module_pref('hunger',0,'usechow');
		 		}
		 }		 
		break;
             return $args;
        }
}
function supriv_run(){
}
?>
