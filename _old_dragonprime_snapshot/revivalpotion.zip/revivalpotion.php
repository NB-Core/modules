<?php

// this module is based on Revive Serum - Rejuvenation
// from the Tourney Lock set
// SaucyWench -at- gmail -dot- com
// 17th January 2006

function revivalpotion_getmoduleinfo(){
	$info = array(
		"name"=>"Revival Potion",
		"author"=>"Shannon Brown",
		"version"=>"1.0",
		"category"=>"Lodge",
		"download"=>"http://gemdust.com/module_download",
		"settings"=>array(
			"Revival Potion Module Settings,title",
			"serumcost"=>"Potion cost in points?,int|100"
		),
		"prefs"=>array(
			"Revival Potion User Preferences,title",
			"serum"=>"Does a player own one?,bool|0"
		),
	);
	return $info;
}

function revivalpotion_install(){
	module_addhook("lodge");
	module_addhook("pointsdesc");
	module_addhook("shades");
	return true;
}
function revivalpotion_uninstall(){
	return true;
}

function revivalpotion_dohook($hookname,$args){
	global $session;
	$serumcost = get_module_setting("serumcost");
	switch($hookname){
	case "pointsdesc":
		$args['count']++;
		$format = $args['format'];
		$str = translate("A vial of Revival Potion costs %s points, and will grant you another chance, if you find yourself in the Shades unexpectedly.",$serumcost);
		$str = sprintf($str, $serumcost);
		output($format, $str, true);
		break;
	case "lodge":
		addnav(array("Revival Potion (%s points)", $serumcost),"runmodule.php?module=revivalpotion&op=purchase");
		break;
	case "shades":
		if (get_module_pref("serum") == 1) addnav("U?Use Revival Potion","runmodule.php?module=revivalpotion&op=use");
		break;
	}
	return $args;
}

function revivalpotion_runevent() {
}

function revivalpotion_run(){
	global $session;
	$op = httpget("op");

	$serumcost = get_module_setting("serumcost");
	if ($op == "use") {
		page_header("Revival Potion");
		output("`%Your skeletal hands remove the cork from the vial of Revival Potion and you sniff the vapour.");
		output("As you do, you feel a searing pain within your those bones, your skin materializes with a zing, and you reawaken into life!`n`n`^");
		set_module_pref("serum",0);
		debuglog("used Revival Potion");
		addnav("It is a new day!","newday.php");
		blocknav("lodge.php");
	} elseif ($op=="purchase"){
		page_header("Hunter's Lodge");
		output("`7The hunter regards you with interest. \"`&Each vial of Revival Potion costs %s points,`7\" he says.  \"`&Is this what you want to buy?`7\"`n`n", $serumcost);
		addnav("Confirm Purchase");
		addnav("Purchase", "runmodule.php?module=revivalpotion&op=confirm");
	} elseif ($op=="confirm"){
		page_header("Hunter's Lodge");
		$pointsavailable = $session['user']['donation'] - $session['user']['donationspent'];
		if($pointsavailable >= $serumcost && get_module_pref("serum")==0){
			output("`7J. C. Petersen hands you a yellow vial of Revival Potion.");
			set_module_pref("serum",1);
			$session['user']['donationspent'] += $serumcost;
		} elseif(get_module_pref("serum")==1){
			output("`7J. C. Petersen points at the potion you already carry, and explains that you can't have another at this point.");
		} else {
			if ($pointsavailable < $serumcost) {
				output("`7J. C. Petersen looks down his nose at you. \"`&You need enough points to buy this stuff. It's too valuable to give away.`7\"", $serumcost);
			}
		}
	}
	addnav("L?Return to the Lodge","lodge.php");
	page_footer();
}
?>