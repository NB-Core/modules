<?php


// V1.0 --  The Dragoons have an increased chance that the player will have first hit in a forest fight
//          This race does 0 to 5 damage to player each round so it can kill the player if they have low hp.
//			Dragoons have a atk buff.
//			Dragoons receives less gold in forest fights.
function racedragoon_getmoduleinfo(){
	$info = array(
		"name"=>"Race - Dragoon",
		"version"=>"1.2",
		"author"=>"`@DaFish",
		"category"=>"Races",
		"download"=>"http://dragonprime.net/users/DaFish/racedragoon.zip",
		"vertxtloc"=>"http://dragonprime.net/users/DaFish/",
		"requires"=>array(
			"raceelf"=>"1.0|By Eric Stevens,part of core download",
		),
		"settings"=>array(
			"Dragoon Race Settings,title",
			"minedeathchance"=>"Percent chance for a Dragoon to die in the mine,range,0,100,1|10",
			"cost"=>"Cost of Race in Lodge Points,int|1000",
			"mindk"=>"How many DKs do you need before the race is available?,int|15",
		),
		"prefs"=>array(
			"Dragoon Preferences,title",
			"bought"=>"Has Dragoon race been bought,bool|0",
		)
	);
	return $info;
}

function racedragoon_install(){
	module_addhook("chooserace");
	module_addhook("setrace");
	module_addhook("newday");
	module_addhook("charstats");
	module_addhook("raceminedeath");
	module_addhook("pvpadjust");
	module_addhook("adjuststats");
	module_addhook("pointsdesc");
	module_addhook("lodge");
	module_addhook("racenames");
	module_addhook("creatureencounter");
	return true;
}

function racedragoon_uninstall(){
	global $session;
	$sql = "UPDATE  " . db_prefix("accounts") . " SET race='" . RACE_UNKNOWN . "' WHERE race='Dragoon'";
	db_query($sql);
	if ($session['user']['race'] == 'Dragoon')
		$session['user']['race'] = RACE_UNKNOWN;
	return true;
}


function racedragoon_dohook($hookname,$args){
	global $session,$resline;

	if (is_module_active("racedwarf")) {
		$city = get_module_setting("villagename", "raceelf");
	} else {
		$city = getsetting("villagename", LOCATION_FIELDS);
	}
	$race = "Dragoon";
	$cost = get_module_setting("cost");
	$bought = get_module_pref("bought");
	switch($hookname){
	case "racenames":
		$args[$race] = $race;
		break;
	case "pointsdesc":
		$args['count']++;
		$format = $args['format'];
		$str = translate("The race: Dragoon; The Slayer of Dragons.  This costs %s points");
		$str = sprintf($str, $cost);
		output($format, $str, true);
		break;
	case "pvpadjust":
		if ($args['race'] == $race) {
			$args['creatureattack']+=(1+floor($args['creaturelevel']/5));
		}
		break;
	case "adjuststats":
		if ($args['race'] == $race) {
			$args['attack'] += (2 + floor($args['level']/5));
		}
		break;
	case "creatureencounter":
		if ($session['user']['race']==$race){
			//get those folks who haven't manually chosen a race
			racedragoon_checkcity();
			$loss = (100 - get_module_setting("goldloss"))/100;
			$args['creaturegold']=round($args['creaturegold']*$loss,0);
			//If this is true then it'll skip lines 89-113 of battle.php
			//Otherwise battle.php will set the vaule for didpurprise
			if (e_rand(1,5) > 3){
				$args['didsurprise'] = 1;
				}
			}
		break;
	case "raceminedeath":
		if ($session['user']['race'] == $race) {
			$args['chance'] = get_module_setting("minedeathchance");
			$args['racesave'] = "The inert ability of the Dragoons to detect danger have saved you from certain death..`n";
			$args['schema']="module-racedragoon";
		}
		break;
	case "charstats":
		if ($session['user']['race']==$race){
			addcharstat("Vital Info");
			addcharstat("Race", translate_inline($race));
		}
		break;
	case "chooserace":
		if ($bought == 1 && $session['user']['dragonkills'] >= get_module_setting("mindk")){
		output("<a href='newday.php?setrace=$race$resline'>Residing in the dense forest of %s</a>, the city of elfs, your race of `@Dargoons `7dwell in the caves.",$city, true);
		output("Having slayed the Dragon countless number of times, your body begins to feel strange, this strange power grows with each dragon slaying as more black dragon blood is soaked into your skin.");
		output("The `@Dragoons `7are the masters of Mystical creatures, they command the forest with absolute power.`n`n");
		addnav("`2Dragoon`0","newday.php?setrace=$race$resline");
		addnav("","newday.php?setrace=$race$resline");
		}
		break;
	case "lodge":
		if (!$bought) {
			addnav(array("Acquire the secrets of Dragoon (%s points)",$cost),
					"runmodule.php?module=racedragoon&op=start");
		}
		break;
	case "setrace":
		if ($session['user']['race']==$race){
			output("`@Dragoons `2are known for their superb combat skills, they are able to strike the enemy with lightning speed.`n");
			output("`2Your `@Scale`2 glisten in the sunlight as you ready for battle!`n");
			if (is_module_active("cities")) {
				if ($session['user']['dragonkills']==0 &&
						$session['user']['age']==0){
					set_module_setting("newest-$city",
							$session['user']['acctid'],"cities");
				}
				set_module_pref("homecity",$city,"cities");
				if ($session['user']['age'] == 0)
					$session['user']['location']=$city;
			}
		}
		break;
	case "newday":
		if ($session['user']['race']==$race){
			racedragoon_checkcity();
			apply_buff("racialbenefit",array(
				"name"=>"`2Dragon Strike`0",
				"minioncount"=>1,
				"mingoodguydamage"=>0,
				"maxgoodguydamage"=>5,
				"effectmsg"=>"`@Dragon blood flows within you and burns you for `^{damage} `@damage.",
				"effectnodmgmsg"=>"`@Dragon blood flows within you and you can feel the power!",
				"atkmod"=>"(<attack>?(1+((2+floor(<level>/5))/<attack>)):0)",
				"allowintrain"=>1,
				"rounds"=>-1,
				"schema"=>"module-racedragoon",

				)
			);
		}
		break;
	}

	return $args;
}
function racedragoon_checkcity(){
	global $session;
	$race = "Dragoon";
	if (is_module_active("raceelf")) {
		$city = get_module_setting("villagename", "raceelf");
	} else {
		$city = getsetting("villagename", LOCATION_FIELDS);
	}

	if ($session['user']['race']==$race && is_module_active("cities")){
		if (get_module_pref("homecity","cities")!=$city){
			set_module_pref("homecity",$city,"cities");
		}
	}
	return true;
}
function racedragoon_run(){
	global $session;
	page_header("Hunter's Lodge");
	$race = 'Dragoon';
	$cost = get_module_setting("cost");
	$bought = get_module_pref("bought");
	$op = httpget('op');

	switch ($op){
		case "start":
			$pointsavailable = $session['user']['donation'] -
			$session['user']['donationspent'];
			if ($pointsavailable >= $cost && $bought == 0){
				output("`3J. C. Petersen looks upon you with a caustic grin.`n`n");
				output("\"`\$So, you wish to learn the secrets of `^Dragoon`\$?`3\" he says with a smile.");
				addnav("Choices");
				addnav("Yes","runmodule.php?module=racedragoon&op=yes");
				addnav("No","runmodule.php?module=racedragoon&op=no");
			} else {
				output("`3J. C. Petersen stares at you for a moment then looks away as you realize that you don't have enough points to purchase this item.");
			}
			break;
		case "yes":
			output("`3J. C. Petersen whispers into your ear on how to transform into a `^Dragoon, `3as you gain the knowledge your heart race with anticipation. You can't wait to transform!`n`n");
			output("\"`\$Take good care of the secret of the `^Dragoons`\$.");
			output("Now, the knowledge is in your head!`3\"`n`n");
			output("You feel an incredible power that engulfs you as you try to perform the transformation.`n`n");
			if(get_module_setting("mindk") > $session['user']['dragonkills']){
				output("J. C. Petersen grins, \"`\$I see that you don't have the required dragon kills to transform into this race yet, but you'll be able to when you gain enough dragon kills.`3\"");
				}
			else{
				output("J. C. Petersen grins, \"`\$Your body shall change when the time is right... I suggest you rest.`3\"`n`n");
				$session['user']['race'] = $race;
				}
			$session['user']['donationspent'] += $cost;
			set_module_pref("bought",1);
			break;
		case "no":
			output("`3J. C. Petersen shrugs and leave you.");
			break;
	}
	addnav("Return");
	addnav("L?Return to the Lodge","lodge.php");
	page_footer();
}
?>





