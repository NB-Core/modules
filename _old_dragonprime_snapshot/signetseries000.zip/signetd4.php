<?php
/*
Module Name: signetd4.php
Category: Signet Series
Worktitle: Signet Maze 4: Fiamma's Fortress
Author: DaveS
Date:  April 2, 2006
Based on the code for Abandoned Castle by Lonnyl

Requires:
signetsale.php

Additional Modules for full function:
signetd1.php, signetd2.php, signetd3.php, and signetd5.php

Description:
Fourth of the Signet Elemental Dungeons series.
The dungeons are based on a game from 1985 called Phantasie.
Enter the Fortress of the Dark Master's Top Servant, Fiamma.  Defeat the monsters in the arena,
steal Fiamma's weapon, and try to avoid that pesky poisoned gas! The adventure continues as players
try to collect the powerful Fire Signet before going against the Dark Lord. It's getting much
more dangerous though... let this be fair warning!

*/
require_once("lib/fightnav.php");
function signetd4_getmoduleinfo(){
	$info = array(
		"name"=>"Signet Maze 4: `\$Fiamma's Fortress",
		"version"=>"4.14",
		"author"=>"DaveS",
		"category"=>"Signet Series",
		"download"=>"http://dragonprime.net/index.php?module=Downloads;sa=dlview;id=972",
		"vertxtloc"=>"",
		"settings"=>array(
			"Fiamma's Fortress Settings,title",
			"random"=>"How many random monsters can be encountered in the fortress?,range,0,40,1|5",
			"randenc"=>"Likelihood of random encounter,enum,1,Common,5,Uncommon,10,Rare,15,Very Rare,20,Extremely Rare|10",
			"healing"=>"Allow for players to have a chance to find a partial healing potion after fights?,bool|1",
			"firemaploc"=>"Where does the Fire Fortress appear?,location|".getsetting("villagename", LOCATION_FIELDS),
			"exitsave"=>"Allow users to return to the dungeon from an emergency exit?,enum,0,No,1,Yes,2,Require|0",
			"`\$Note: If you chose 'Require' then players MUST come back in at the same location that they leave from; otherwise players will have a choice to come back through the main entrance or the exit location,note",
		),
		"prefs"=>array(
			"Fiamma's Fortress Preferences,title",
			"complete"=>"Has player completed the fortress?,bool|0",
			"reset"=>"Have the preferences been reset by visiting The Dark Lair?,bool|0",
			"super"=>"Does player have superuser access to the fortress?,bool|0",
			"Encounters,title",
			"randomp"=>"How many random monsters has player encountered so far?,range,0,40,1|0",
			"firesignet"=>"*`\$Received the Fire Signet?,bool|0",
			"loc182"=>"*Defeated Fiamma?,enum,0,No,1,Yes,2,In Process|0",
			"scroll7"=>"*Obtained scroll 7?,bool|0",
			"* Finish these points and the fortress will be closed to this player,note",
			"scroll6"=>"Obtained scroll 6?,bool|0",
			"loc12"=>"Passed Location 12?,bool|0",
			"loc18"=>"Passed Location 18?,enum,0,No,1,Yes,2,In Process|0",
			"loc27"=>"Passed Location 27?,bool|0",
			"loc29"=>"Passed Location 29?,enum,0,No,1,Yes,2,In Process|0",
			"loc83"=>"Passed Location 83?,bool|0",
			"loc87"=>"Passed Location 87?,enum,0,No,1,Yes,2,In Process|0",
			"loc90"=>"Passed Location 90?,enum,0,No,1,Yes,2,In Process|0",
			"loc93"=>"Passed Location 93?,bool|0",
			"loc138"=>"Passed Location 138?,bool|0",
			"loc152"=>"Passed Location 152?,bool|0",
			"loc177"=>"Passed Location 177?,bool|0",
			"loc178"=>"Passed Location 178?,bool|0",
			"loc198"=>"Passed Location 198?,enum,0,No,1,Yes,2,In Process|0",
			"loc250"=>"Passed Location 250?,bool|0",
			"loc312"=>"Passed Location 312?,enum,0,No,1,Yes,2,In Process|0",
			"loc328"=>"Passed Location 328?,bool|0",
			"loc343"=>"Passed Location 343?,bool|0",
			"loc362"=>"Passed Location 362?,enum,0,No,1,Yes,2,In Process|0",
			"loc377"=>"Passed Location 377?,bool|0",
			"loc383"=>"Passed Location 383?,bool|0",
			"loc386"=>"Passed Location 386?,enum,0,No,1,Yes,2,In Process|0",
			"loc394"=>"Passed Location 394?,bool|0",
			"loc459"=>"Passed Location 459?,enum,0,No,1,Yes,2,In Process|0",
			"loc463"=>"Passed Location 463?,bool|0",
			"loc467"=>"Passed Location 467?,enum,0,No,1,Yes,2,In Process|0",
			"loc485"=>"Passed Location 485?,enum,0,No,1,Yes,2,In Process|0",
			"loc506"=>"Passed Location 506?,bool|0",
			"loc513"=>"Passed Location 513?,enum,0,No,1,Yes,2,In Process|0",
			"loc561"=>"Passed Location 561?,enum,0,No,1,Yes,2,In Process|0",
			"loc587"=>"Passed Location 587?,bool|0",
			"loc635"=>"Passed Location 635?,bool|0",
			"loc655"=>"Passed Location 655?,enum,0,No,1,Yes,2,In Process|0",
			"loc683"=>"Passed Location 683?,bool|0",
			"loc689"=>"Passed Location 689?,enum,0,No,1,Yes,2,In Process|0",
			"loc717"=>"Passed Location 717?,bool|0",
			"loc726"=>"Passed Location 726?,bool|0",
			"loc840"=>"Passed Location 840?,bool|0",
			"loc853"=>"Passed Location 853?,enum,0,No,1,Yes,2,In Process|0",
			"loc868"=>"Passed Location 868?,enum,0,No,1,Yes,2,In Process|0",
			"loc874"=>"Passed Location 874?,enum,0,No,1,Yes,2,In Process|0",
			"loc931"=>"Passed Location 931?,bool|0",
			"loc931b"=>"Passed Location 931b?,bool|0",
			"loc934"=>"Passed Location 934?,bool|0",
			"loc934b"=>"Passed Location 934b?,bool|0",
			"loc948"=>"Passed Location 948?,enum,0,No,1,Yes,2,In Process|0",
			"loc1057"=>"Passed Location 1057?,enum,0,No,1,Yes,2,In Process|0",
			"loc1059"=>"Passed Location 1059?,bool|0",
			"loc1099"=>"Passed Location 1099?,bool|0",
			"loc1104"=>"Passed Location 1104?,bool|0",
			"loc1143"=>"Passed Location 1143?,bool|0",
			"loc1177"=>"Passed Location 1177?,bool|0",
			"loc1177count"=>"Number of times passed Location 1177?,int|0",
			"Maze View Only,title",
			"maze"=>"Maze,viewonly",
			"mazeturn"=>"Maze Return,viewonly",
			"pqtemp"=>"Temporary Information,int|",
			"startloc"=>"Starting location,int|1279",
			"header"=>"Which header array is the player at?,viewonly|0",
		),
		"requires"=>array(
			"signetsale" => "4.14| by DaveS, http://dragonprime.net/index.php?module=Downloads;sa=dlview;id=972",
		),
	);
	return $info;
}

function signetd4_install(){
	module_addhook("village");
	module_addhook("scrolls-signetsale");
	return true;
}

function signetd4_uninstall(){
	return true;
}

function signetd4_dohook($hookname,$args){
	global $session;
	$userid = $session['user']['acctid'];
	switch($hookname){
	case "village":
		if ($session['user']['location'] == get_module_setting("firemaploc") && get_module_pref("firesigmap","signetsale")==1 && get_module_pref("complete")==0){
			tlschema($args['schemas']['tavernnav']);
			addnav($args['tavernnav']);
    		tlschema();
			addnav("Fiamma's Fortress","runmodule.php?module=signetd4");
		}
	break;
	case "scrolls-signetsale":
		$userid2 = httpget("user");
		if ($userid2==$userid){
			if (get_module_pref("scroll6","signetd4")==1) addnav("Scroll 6","runmodule.php?module=signetd4&op=scroll6&user=$userid");		
			if (get_module_pref("scroll7","signetd4")==1) addnav("Scroll 7","runmodule.php?module=signetd4&op=scroll7&user=$userid");		
		}
	break;
	}
	return $args;
}
function signetd4_run(){
	global $SCRIPT_NAME;
	if ($SCRIPT_NAME == "runmodule.php"){
		$module=httpget("module");
		if ($module == "signetd4") {
			require_once("modules/signet/signetd4_func.php");
			include("modules/signet/signetd4.php");
		}
	}
}
?>