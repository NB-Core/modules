<?php
/*
Module Name: signetd3.php
Category: Signet Series
Worktitle: Signet Maze 3: Wasser's Castle
Author: DaveS
Date:  March 8, 2006

Based on the code for Abandoned Castle by Lonnyl

Dedicated in memory of my brother Bill.

Requires:
signetsale.php

Additional Modules for full function:
signetd1.php, signetd2.php, signetd4.php, and signetd5.php

Description:
Third of the Signet Elemental Dungeons series.
The dungeons are based on a game from 1985 called Phantasie.
Something's wrong at Wasser's Castle!  Help free the innocent from wrongful 
imprisonment while attempting to obtain the Water Signet from William the Wise and 
get one step closer to solving the mystery of the Elemental Signets!

*/
require_once("lib/fightnav.php");
function signetd3_getmoduleinfo(){
	$info = array(
		"name"=>"Signet Maze 3: `!Wasser's Castle",
		"version"=>"4.14",
		"author"=>"DaveS",
		"category"=>"Signet Series",
		"download"=>"http://dragonprime.net/index.php?module=Downloads;sa=dlview;id=972",
		"vertxtloc"=>"",
		"settings"=>array(
			"Wasser's Castle Settings,title",
			"random"=>"How many random monsters can be encountered in the castle?,int|5",
			"randenc"=>"Likelihood of random encounter,enum,1,Common,5,Uncommon,10,Rare,15,Very Rare,20,Extremely Rare|10",
			"healing"=>"Allow for players to have a chance to find a partial healing potion after fights?,bool|1",
			"watermaploc"=>"Where does the Water Castle appear,location|".getsetting("villagename", LOCATION_FIELDS),
			"exitsave"=>"Allow users to return to the dungeon from an emergency exit?,enum,0,No,1,Yes,2,Require|0",
			"`\$Note: If you chose 'Require' then players MUST come back in at the same location that they leave from; otherwise players will have a choice to come back through the main entrance or the exit location,note",
		),
		"prefs"=>array(
			"Wasser's Castle Preferences,title",
			"complete"=>"Has player completed the castle?,bool|0",
			"reset"=>"Have the preferences been reset by visiting Fiamma's Fortress?,bool|0",
			"super"=>"Does player have superuser access to the castle?,bool|0",
			"Encounters,title",
			"randomp"=>"How many random monsters has player encountered so far?,range,0,15,1|0",
			"watersignet"=>"*`!Received the Water Signet?,bool|0",
			"scroll5"=>"*Found Scroll 5?,bool|0",
			"loc159"=>"*Passed Location 159?,bool|0",
			"* Finish these points and the castle will be closed to this player,note",
			"prisonkey"=>"Does the player have the prison key?,bool|0",
			"loc11"=>"Passed Location 11?,bool|0",
			"loc11b"=>"Passed Location 11b?,bool|0",
			"loc11c"=>"Passed Location 11c?,bool|0",
			"loc29"=>"Passed Location 29?,enum,0,No,1,Yes,2,In Process|0",
			"loc48"=>"Passed Location 48?,bool|0",
			"loc53"=>"Passed Location 53?,bool|0",
			"loc65"=>"Passed Location 65?,enum,0,No,1,Yes,2,In Process|0",
			"loc66"=>"Passed Location 66?,enum,0,No,1,Yes,2,In Process|0",
			"loc82"=>"Passed Location 82?,enum,0,No,1,Yes,2,In Process|0",
			"loc87"=>"Passed Location 87?,enum,0,No,1,Yes,2,In Process|0",
			"loc94"=>"Passed Location 94?,enum,0,No,1,Yes,2,In Process|0",
			"loc148"=>"Passed Location 148?,enum,0,No,1,Yes,2,In Process|0",
			"loc157"=>"Passed Location 157?,bool|0",
			"loc164"=>"Passed Location 164?,enum,0,No,1,Yes,2,In Process|0",
			"loc221"=>"Passed Location 221?,enum,0,No,1,Yes,2,In Process|0",
			"loc331"=>"Passed Location 331?,bool|0",
			"loc352"=>"Passed Location 352?,bool|0",
			"loc354"=>"Passed Location 354?,bool|0",
			"loc358"=>"Passed Location 358?,enum,0,No,1,Yes,2,In Process|0",
			"loc401"=>"Passed Location 401?,enum,0,No,1,Yes,2,In Process|0",
			"loc483"=>"Passed Location 483?,enum,0,No,1,Yes,2,In Process|0",
			"loc499"=>"Passed Location 499?,enum,0,No,1,Yes,2,In Process|0",
			"loc537"=>"Passed Location 537?,int|0",
			"loc561"=>"Passed Location 561?,bool|0",
			"loc591"=>"Passed Location 591?,enum,0,No,1,Yes,2,In Process|0",
			"loc619"=>"Passed Location 619?,enum,0,No,1,Yes,2,In Process|0",
			"loc625"=>"Passed Location 625?,enum,0,No,1,Yes,2,In Process|0",
			"loc635"=>"Passed Location 635?,bool|0",
			"loc745"=>"Passed Location 745?,enum,0,No,1,Yes,2,In Process|0",
			"loc746"=>"Passed Location 746?,bool|0",
			"loc839"=>"Passed Location 839?,bool|0",
			"loc931"=>"Passed Location 931?,bool|0",
			"loc939"=>"Passed Location 939?,enum,0,No,1,Yes,2,In Process|0",
			"loc1071"=>"Passed Location 1071?,bool|0",
			"loc1079"=>"Passed Location 1079?,bool|0",
			"loc1097"=>"Passed Location 1097?,enum,0,No,1,Yes,2,In Process|0",
			"loc1206"=>"Passed Location 1206?,bool|0",
			"Maze View Only,title",
			"maze"=>"Maze,viewonly",
			"mazeturn"=>"Maze Return,viewonly",
			"pqtemp"=>"Temporary Information,int|",
			"startloc"=>"Starting location,int|1275",
			"header"=>"Which header array is the player at?,viewonly|0",
		),
		"requires"=>array(
			"signetsale" => "4.14| by DaveS, http://dragonprime.net/index.php?module=Downloads;sa=dlview;id=972",
		),
	);
	return $info;
}

function signetd3_install(){
	module_addhook("village");
	module_addhook("scrolls-signetsale");
	return true;
}

function signetd3_uninstall(){
	return true;
}

function signetd3_dohook($hookname,$args){
	global $session;
	$userid = $session['user']['acctid'];
	switch($hookname){
	case "village":
		if ($session['user']['location'] == get_module_setting("watermaploc") && get_module_pref("watersigmap","signetsale")==1 && get_module_pref("complete")==0){
			tlschema($args['schemas']['tavernnav']);
			addnav($args['tavernnav']);
    		tlschema();
			addnav("Wasser's Castle","runmodule.php?module=signetd3");
		}
	break;
	case "scrolls-signetsale":
		$userid2 = httpget("user");
		if ($userid2==$userid){
			if (get_module_pref("scroll5","signetd3")==1) addnav("Scroll 5","runmodule.php?module=signetd3&op=scroll5&user=$userid");		
		}
	break;
	}
	return $args;
}
function signetd3_run(){
	global $SCRIPT_NAME;
	if ($SCRIPT_NAME == "runmodule.php"){
		$module=httpget("module");
		if ($module == "signetd3") {
			require_once("modules/signet/signetd3_func.php");
			include("modules/signet/signetd3.php");
		}
	}
}
?>