<?php
global $session, $REQUEST_URI;
$op = httpget('op');
$page = httpget('page');
page_header("Unique Map Sales");
if ($op != 'hof' && $op != 'hof2' && $op != 'signetnotes') villagenav();
if (is_module_active("mapmaker") && get_module_setting("mapmaker")==1) addnav("Look at Other Maps","runmodule.php?module=mapmaker");
if (is_module_active("cartographer") && get_module_setting("mapmaker")==1) addnav("Look at Other Maps","runmodule.php?module=cartographer");
if (get_module_pref("airsigmap")==0){
	$current=1;
	$map=get_module_pref("airsigmap");
	$costturn=get_module_setting("costturna");
	$paidturn=get_module_pref("paidturna");
	$costgold=get_module_setting("costgolda");
	$paidgold=get_module_pref("paidgolda");
	$costgem=get_module_setting("costgema");
	$paidgem=get_module_pref("paidgema");
}elseif (get_module_pref("earthsigmap")==0 && get_module_pref("airsignet","signetd1")==1){
	$current=2;
	$map=get_module_pref("earthsigmap");
	$costturn=get_module_setting("costturne");
	$paidturn=get_module_pref("paidturne");
	$costgold=get_module_setting("costgolde");
	$paidgold=get_module_pref("paidgolde");
	$costgem=get_module_setting("costgeme");
	$paidgem=get_module_pref("paidgeme");
}elseif (get_module_pref("watersigmap")==0 && get_module_pref("earthsignet","signetd2")==1){
	$current=3;
	$map=get_module_pref("watersigmap");
	$costturn=get_module_setting("costturnw");
	$paidturn=get_module_pref("paidturnw");
	$costgold=get_module_setting("costgoldw");
	$paidgold=get_module_pref("paidgoldw");
	$costgem=get_module_setting("costgemw");
	$paidgem=get_module_pref("paidgemw");
}elseif (get_module_pref("firesigmap")==0 && get_module_pref("watersignet","signetd3")==1){
	$current=4;
	$map=get_module_pref("firesigmap");
	$costturn=get_module_setting("costturnf");
	$paidturn=get_module_pref("paidturnf");	
	$costgold=get_module_setting("costgoldf");
	$paidgold=get_module_pref("paidgoldf");
	$costgem=get_module_setting("costgemf");
	$paidgem=get_module_pref("paidgemf");
}elseif (get_module_pref("finalsigmap")==0 && get_module_pref("firesignet","signetd4")==1){
	$current=5;
	$map=get_module_pref("finalsigmap");
	$costturn=get_module_setting("costturnm");
	$paidturn=get_module_pref("paidturnm");
	$costgold=get_module_setting("costgoldm");
	$paidgold=get_module_pref("paidgoldm");
	$costgem=get_module_setting("costgemm");
	$paidgem=get_module_pref("paidgemm");
}
$dks=$session['user']['dragonkills'];
$dksincewin=get_module_setting("dksincewin");
if (get_module_pref("completednum")==0) $dksincewin=0;
$cn=get_module_setting("dkfinal")*get_module_pref("completednum")+$dksincewin;
//I know this next line is a hack but it works if you don't want players to replay the series
if (get_module_pref("dksincewin")<0) $cn=1000000;
if ($costturn<0) $costturn==0;
$topayturn=$costturn-$paidturn;
if ($costgold<0) $costgold==0;
$topaygold=$costgold-$paidgold;
if ($costgem<0) $costgem==0;
$topaygem=$costgem-$paidgem;
$dungeonnames=array("","Aria Dungeon","Aarde Temple","Wasser's Castle","Fiamma's Castle","Mierscri's Lair");

if ($op=="enter"){

	//Player is in process of purchasing their map
	if (($current==1 && get_module_pref("dkopena")==1) || ($current==2 && get_module_pref("dkopene")==1) ||($current==3 && get_module_pref("dkopenw")==1) ||($current==4 && get_module_pref("dkopenf")==1) ||($current==5 && get_module_pref("dkopenm")==1)){
		redirect("runmodule.php?module=signetsale&op=sales");
	//Player completed last map but not enough dks to get the next map
	}elseif (($current==2 && get_module_pref("dkopene")==0 && $dks<(get_module_setting("dkearth")+$cn)) ||($current==3 && get_module_pref("dkopenw")==0 && $dks<(get_module_setting("dkearth")+$cn)) ||($current==4 && get_module_pref("dkopenf")==0 && $dks<(get_module_setting("dkfire")+$cn)) ||($current==5 && get_module_pref("dkopenm")==0 && ($dks<get_module_setting("dkfinal")+$cn))){
		output("`#'I see you've completed the `&%s`#. Unfortunately, I do not think you have the strength to complete the next map.'`n`n",$dungeonnames[$current-1]);
		output("`#'Please check back after you've killed the `@Green Dragon`# again.'");
	//Player completed last map and now for first time strong enough to get the next map
	}elseif (($current==2 && get_module_pref("dkopene")==0 && $dks>=(get_module_setting("dkearth")+$cn)) ||($current==3 && get_module_pref("dkopenw")==0 && $dks>=(get_module_setting("dkearth")+$cn)) ||($current==4 && get_module_pref("dkopenf")==0 && $dks>=(get_module_setting("dkfire")+$cn)) ||($current==5 && get_module_pref("dkopenm")==0 && $dks>=(get_module_setting("dkfinal")+$cn))){
		output("`#'Congratulations on completing `&%s`#.  I see you've grown a bit since we last met.  Very well, I think I may have another map that will suit your fancy.'",$dungeonnames[$current-1]);
		addnav("Continue","runmodule.php?module=signetsale&op=sales");
		if ($current==2) set_module_pref("dkopene",1);
		if ($current==3) set_module_pref("dkopenw",1);
		if ($current==4) set_module_pref("dkopenf",1);
		if ($current==5) set_module_pref("dkopenm",1);
	//Player coming back but still not enough dks to get the first map
	}elseif(get_module_pref("nodkopen")==1 && $dks<get_module_setting("dkair")+$cn){
		output("`#'Listen, I don't need you coming around here belittling my products and wasting my time.  I have nothing to offer you right now.");
		output("Come back when you've shown the world that you've got some real talent.'");
	//Player coming back and now for first time strong enough to get the first map
	}elseif(get_module_pref("nodkopen")==1 && $dks>=get_module_setting("dkair")+$cn){
		output("`#'Ah, I see you've grown a bit since the last time I saw you.");
		output("Well, perhaps I have something a great warrior such as yourself may be interested in.`n`n");
		output("'You see, I have some maps... very unique maps.  They will lead you to new adventures that perhaps you have never dreamed of.'");
		output("`n`n`0You notice that there's a change in the man's voice. This isn't talk of the drivel that's on display.  There may actually be something to his offer.");
		output("`#'Come around to the back of my cart and we can talk more privately.'");
		set_module_pref("dkopena",1);
		set_module_pref("nodkopen",0);
		addnav("Continue","runmodule.php?module=signetsale&op=newsales");
	//These statements are needed if all the dungeons haven't been installed/written yet
	}elseif(get_module_pref("incomplete")==1){
		if (get_module_pref("finalsigmap")==1){
			if (is_module_active("signetd3")){
				output("`#'Ah, welcome back.  I'm sorry about the delay.  It appears that `&Mierscri's Lair`# is located in %s.",get_module_setting("finalmaploc","signetd5"));
				output("`n`n`#Once you've finished it, please come back and visit.'");
				set_module_pref("incomplete",0);
			}else{
				output("`#'I'm sorry, `&Mierscri's Lair`# is not quite ready for you to explore.  Please come back soon.'");
			}
		}elseif (get_module_pref("firesigmap")==1){
			if (is_module_active("signetd3")){
				output("`#'Ah, welcome back.  I'm sorry about the delay.  It appears that `&Fiamma's Castle`# is located in %s.",get_module_setting("firemaploc","signetd4"));
				output("`n`n`#Once you've finished it, please come back and visit.'");
				set_module_pref("incomplete",0);
			}else{
				output("`#'I'm sorry, `&Fiamma's Castle`# is not quite ready for you to explore.  Please come back soon.'");
			}
		}elseif (get_module_pref("watersigmap")==1){
			if (is_module_active("signetd3")){
				output("`#'Ah, welcome back.  I'm sorry about the delay.  It appears that `&Wasser's Castle`# is located in %s.",get_module_setting("watermaploc","signetd3"));
				output("`n`n`#Once you've finished it, please come back and visit.'");
				set_module_pref("incomplete",0);
			}else{
				output("`#'I'm sorry, `&Wasser's Castle`# is not quite ready for you to explore.  Please come back soon.'");
			}
		}elseif (get_module_pref("earthsigmap")==1){
			if (is_module_active("signetd2")){
				output("`#'Ah, welcome back.  I'm sorry about the delay.  It appears that `&Aarde Temple`# is located in %s.",get_module_setting("earthmaploc","signetd2"));
				output("`n`n`#Once you've finished it, please come back and visit.'");
				set_module_pref("incomplete",0);
			}else{
				output("`#'I'm sorry, `&Aarde Temple`# is not quite ready for you to explore.  Please come back soon.'");
			}
		}
	//Player hasn't completed their current dungeon 
	}elseif($current==0){
		output("`#'I'm sorry, but you'll have to complete the dungeon for the last map I gave you before we can talk about another of these precious maps.'`0");
	//First visit to the Mapmaker Shop (already checked to see if they have enough DKs at the mapshop nav)
	}elseif(get_module_pref("nodkopen")==0 && (is_module_active("mapmaker")||is_module_active("cartographer")) && get_module_setting("mapmaker")==1){
		output("You lean up to the counter and whisper `@'special maps'`0.");
		output("`n`nThe mapmaker takes little notice of your whispering and continues to organize the shop.");
		output("`n`n`@'Psssssst... SPECIAL Maps...'");
		output("`0The mapmaker looks up at you and looks at you as if you're a 3 headed snake trying to share a dead rat.`n`n");
		output("`#'Listen,'`0 says the mapmaker, `#'I may have something more unique...  maps that could lead you to new adventures that perhaps you have never dreamed of.");
		output("However, the price isn't cheap and I don't offer these maps to just anyone.'");
		output("`n`n`#'Come around to the back of my store and we can talk more privately.'");
		addnav("Continue","runmodule.php?module=signetsale&op=newsales");	
	//First visit to the Antiquities Shop 
	}elseif (get_module_pref("nodkopen")==0){
		output("`c`b`^Antiquities For Sale`c`b`0");
		output("`nYou walk up to the shabby little cart and take a look at the so-called `^'Antiquities'`0 available for sale.");
		output("`n`nYou give a quiet snicker as you peruse the selection of great artifacts:");
		output("A `Q'tooth'`0 (which seems rather more like a river-polished piece of granite) supposedly from `@Grand Cthuton`0; the most evil dragon the land has ever known.");
		output("`n`n`#'Special price for that... it has magical powers I tell you.  Only `^10 gold`#.'");
		output("`n`n`0You pick up a piece of wood in the shape of the letter `q'Y'`0 and your curiosity gets the best of you.  You look up at the old man.");
		output("`n`n`#'That's the sling that slayed Grogron the Awful Two Headed Giant.  Selling fast for only `^7 gold`#.'");
		output("`n`n`0It's pretty much all junk and the little snicker that escapes from your lips does not go unnoticed.");
		//Enough Dks to get the first map
		if ($dks>=get_module_setting("dkair")+$cn && $current==1){
			output("`n`n`#'Ah... a discriminating connoisseur.  I understand.  Well, perhaps I have something a great warrior such as yourself may be interested in.");
			output("You see, I have some maps... very unique maps.  They will lead you to new adventures that perhaps you have never dreamed of.'");
			output("`n`n`0You notice that there's a change in the man's voice. This isn't talk of the drivel that's on display.  There may actually be something to his offer.");
			output("`#'Come around to the back of my cart and we can talk more privately.'");
			addnav("Continue","runmodule.php?module=signetsale&op=newsales");
		// Not enough dks to get the first map
		}elseif ($dks<get_module_setting("dkair")+$cn && $current==1){
			output("`#'Listen, that's all I have available for a small fish like you.  Perhaps when you've grown a little stronger I'll have something worth your time.'");
			output("`n`n'Good day to you, sir.'");
			output("`n`n`0You don't find anything worth purchasing quite yet.  After you've killed the `@Green Dragon`0 a couple of times you may find something worthwhile here.");
			set_module_pref("nodkopen",1);
		}
	}
}
//First visit to the shop and Reviewing the price of the first map
if ($op=="newsales"){
	set_module_pref("dkopena",1);
	output("`c`b`^Elemental Signet Maps`b`c`0");
	output("`n'`#Okay, here's the deal.  I have five very unique maps for sale. But I cannot even begin to tell you how much work they were to obtain.");
	output("As I'm sure you can understand, my price, therefore, is proportionally shocking.");
	output("However, I do offer a guaranty.  If my maps aren't satisfying to you, I offer a full apology.  Your payment, however, is not refundable.'");
	output("`n`n'Let's see what I have available for someone of your prowess.'");
	output("`n`n`0After shuffling through some papers, the vendor holds up a rather shaggy-looking map.");
	output("`n`n`#'Yes, this one may interest you.  It's a map to a very ancient dungeon.  Unfortunately, the individual that made it wasn't able to finish mapping out all the details.'");
	output("`n`n'I'm pretty sure it's full of danger and traps and treasure and all that.'");
	//I don't recommend setting all the prices to zero, but if they are...
	if ($costturn==0 && $costgold==0 && $costgem==0) {
		output("`n`n'In fact, on second thought, this thing looks like a death trap.  I'd feel better just giving it to you.'");
		addnav("Free Map","runmodule.php?module=signetsale&op=getmap");
	}else{
		output("`n`n'Here's my price:'`c`n");
		if ($topayturn>1) {
			output("`@%s turns working for me`n",$topayturn);
			addnav("Spend Turns","runmodule.php?module=signetsale&op=payturn");
		}elseif ($topayturn==1){
			output("`@One turn working for me`n");
			addnav("Spend Turns","runmodule.php?module=signetsale&op=payturn");
		}
		if ($topaygold>1) {
			output("`^%s gold`n",$topaygold);
			addnav("Pay gold","runmodule.php?module=signetsale&op=paygold");
		}elseif ($topaygold==1) {
			output("`^One gold`n");
			addnav("Pay Gold","runmodule.php?module=signetsale&op=paygold");		
		}
		if ($topaygem>1) {
			output("`%%s gems`n",$topaygem);
			addnav("Pay gems","runmodule.php?module=signetsale&op=paygems");
		}elseif ($topaygem==1){
			output("`%One gem`n",$topaygem);
			addnav("Pay Gems","runmodule.php?module=signetsale&op=paygems");
		}
		output("`c");
	}
}
if ($op=="sales"){
	if ($topayturn<=0 && $topaygold<=0 && $topaygem<=0){
		addnav("Collect Your Map","runmodule.php?module=signetsale&op=getmap");
		output("`#'Well, it seems like you've paid me in full.  If you're ready, I can get you your map.'");
	}else{
		$dungeonnames=array("","Aria Dungeon","Aarde Temple","Wasser's Castle","Fiamma's Castle","Mierscri's Lair");
		output("`#'Would you like to pay for the map to `&%s`#? This is what it will cost you:'`c`n",$dungeonnames[$current]);
		if ($topayturn>1) {
			output("`@%s turns working for me`n",$topayturn);
			addnav("Spend Turns","runmodule.php?module=signetsale&op=payturn");
		}elseif ($topayturn==1){
			output("`@One turn working for me`n");
			addnav("Spend Turns","runmodule.php?module=signetsale&op=payturn");
		}
		if ($topaygold>1) {
			output("`^%s gold`n",$topaygold);
			addnav("Pay gold","runmodule.php?module=signetsale&op=paygold");
		}elseif ($topaygold==1) {
			output("`^One gold`n");
			addnav("Pay Gold","runmodule.php?module=signetsale&op=paygold");		
		}
		if ($topaygem>1) {
			output("`%%s gems`n",$topaygem);
			addnav("Pay gems","runmodule.php?module=signetsale&op=paygems");
		}elseif ($topaygem==1){
			output("`%One gem`n",$topaygem);
			addnav("Pay Gems","runmodule.php?module=signetsale&op=paygems");
		}
		output("`c");
	}
}
if ($op=="payturn"){
	output("`#'You have to work `@%s turns`# for me for the map. How many turns would you like to work for me today?'",$topayturn);
	output("<form action='runmodule.php?module=signetsale&op=payoffturn' method='POST'><input name='turnp' id='turnp'><input type='submit' class='button' value='Spend Turns'></form>",true);
	addnav("","runmodule.php?module=signetsale&op=payoffturn");
	if ($topaygold>0) addnav("Pay Gold","runmodule.php?module=signetsale&op=paygold");
	if ($topaygem>0) addnav("Pay Gems","runmodule.php?module=signetsale&op=paygems");
}
if ($op=="payoffturn"){
	$turn = httppost('turnp');
	$max = $session['user']['turns'];
	if ($turn < 0) $turn = 0;
	if ($turn >= $max) $turn = $max;
	if ($turn>$topayturn) {
		output("`#'Actually, I don't expect you to work that hard for the map.");
		output("You only need to work");
		if ($turn>1) output("`@%s turns`#.'`n`n",$topayturn);
		else output("`@one turn`#.'`n`n");
		$turn=$topayturn;
	}
	if ($turn>=$topayturn) {
		output("`0Before you know it you're arranging items for sale and doing what you believe are menial tasks.");
		output("`n`nSoon enough,`@");
		if ($turn>1) output("%s turns`0 have",$turn);
		else output("a turn`0 has");
		output("passed and the work is done.`n`n`#");
		signetsale_work();
		output("You've fulfilled that part of our bargain.'");
	}elseif ($turn==0){
		output("`#'Umm, well, thanks for nothing.'`n`n");
		output("'Perhaps you would actually like to do some work instead of wasting my time?");
	}else{
		output("`0Before you know it you're arranging items for sale and doing what you believe are menial tasks.");
		output("`n`nSoon enough,`@");
		if ($turn>1) output("%s turns`0 have",$turn);
		else output("a turn`0 has");
		output("passed and the work is done.`n`n`#");
		signetsale_work();
	}
	if ($current==1){
		increment_module_pref("paidturna",$turn);
		$paidturn=get_module_pref("paidturna");
	}
	if ($current==2){
		increment_module_pref("paidturne",$turn);
		$paidturn=get_module_pref("paidturne");
	}
	if ($current==3){
		increment_module_pref("paidturnw",$turn);
		$paidturn=get_module_pref("paidturnw");
	}
	if ($current==4){
		increment_module_pref("paidturnf",$turn);
		$paidturn=get_module_pref("paidturnf");
	}
	if ($current==5){
		increment_module_pref("paidturnm",$turn);
		$paidturn=get_module_pref("paidturnm");
	}
	$topayturn=$costturn-$paidturn;
	if ($topayturn>0){
		output("You still have to work`@");
		if ($topayturn==1) output("one more turn");
		else output("%s more turns",$topayturn);
		output("`#before you've fulfilled your obligation of working for me.'");
	}
	$session['user']['turns']-=$turn;
	if ($topayturn>0) addnav("Spend More Turns","runmodule.php?module=signetsale&op=payturn");
	if ($topaygold>0) addnav("Pay Gold","runmodule.php?module=signetsale&op=paygold");
	if ($topaygem>0) addnav("Pay Gems","runmodule.php?module=signetsale&op=paygems");
	if ($topayturn<=0 && $topaygold<=0 && $topaygem<=0) addnav("Collect Your Map","runmodule.php?module=signetsale&op=getmap");
}
if ($op=="paygold"){
	output("`#'You will have to pay `^%s gold`# for the map. How much would you like to give me?'",$topaygold);
	output("<form action='runmodule.php?module=signetsale&op=payoffgold' method='POST'><input name='goldp' id='goldp'><input type='submit' class='button' value='Pay Gold'></form>",true);
	addnav("","runmodule.php?module=signetsale&op=payoffgold");
	if ($topayturn>0) addnav("Spend Turns","runmodule.php?module=signetsale&op=payturn");
	if ($topaygem>0) addnav("Pay Gems","runmodule.php?module=signetsale&op=paygems");
}
if ($op=="payoffgold"){
	$gold = httppost('goldp');
	$max = $session['user']['gold'];
	if ($gold < 0) $gold = 0;
	if ($gold >= $max) $gold = $max;
	if ($gold>$topaygold) {
		output("`#'Actually, I don't expect you to pay that much for the map.");
		output("You only need to pay `^%s gold`#.'`n`n",$topaygold);
		$gold=$topaygold;
	}
	if ($gold>=$topaygold) {
		output("`0You hand over `^%s gold`0 and he counts it out carefully.",$gold);
		output("`n`n`#'Looks like that's enough `^gold`# to make me happy.'");
	}elseif ($gold==0){
		output("`#'Umm, well, thanks for nothing.'`n`n");
		output("'Maybe you should actually give me some gold instead of wasting my time.'`n`n");
	}else{
		output("`0You hand over the `^%s gold`0 and he counts it out carefully.`n`n",$gold);
	}
	if ($current==1){
		increment_module_pref("paidgolda",$gold);
		$paidgold=get_module_pref("paidgolda");
	}
	if ($current==2){
		increment_module_pref("paidgolde",$gold);
		$paidgold=get_module_pref("paidgolde");
	}
	if ($current==3){
		increment_module_pref("paidgoldw",$gold);
		$paidgold=get_module_pref("paidgoldw");
	}
	if ($current==4){
		increment_module_pref("paidgoldf",$gold);
		$paidgold=get_module_pref("paidgoldf");
	}
	if ($current==5){
		increment_module_pref("paidgoldm",$gold);
		$paidgold=get_module_pref("paidgoldm");
	}
	$topaygold=$costgold-$paidgold;
	if ($topaygold>0){
		output("`#'You will need `^%s gold`# more before you're paid in full for gold.'",$topaygold);
	}
	$session['user']['gold']-=$gold;
	if ($topaygold>0) addnav("Pay More Gold","runmodule.php?module=signetsale&op=paygold");
	if ($topayturn>0) addnav("Spend Turns","runmodule.php?module=signetsale&op=payturn");
	if ($topaygem>0) addnav("Pay Gems","runmodule.php?module=signetsale&op=paygems");
	if ($topayturn<=0 && $topaygold<=0 && $topaygem<=0) addnav("Collect Your Map","runmodule.php?module=signetsale&op=getmap");
}
if ($op=="paygems"){
	output("`#'You will have to pay `%%s gems`# for the map. How much would you like to give me?'",$topaygem);
	output("<form action='runmodule.php?module=signetsale&op=payoffgems' method='POST'><input name='gemp' id='gemp'><input type='submit' class='button' value='Pay Gems'></form>",true);
	addnav("","runmodule.php?module=signetsale&op=payoffgems");
	if ($topayturn>0) addnav("Spend Turns","runmodule.php?module=signetsale&op=payturn");
	if ($topaygold>0) addnav("Pay Gold","runmodule.php?module=signetsale&op=paygold");
}
if ($op=="payoffgems"){
	$gem = httppost('gemp');
	$max = $session['user']['gems'];
	if ($gem < 0) $gem = 0;
	if ($gem >= $max) $gem = $max;
	if ($gem>$topaygem) {
		output("`#'Actually, I don't expect you to pay that much for the map.");
		output("You only need to pay");
		if ($gem==1) output(" `%one gem`#.'`n`n");
		else output("`%%s gems`#.'`n`n",$topaygem);
		$gem=$topaygem;
	}
	if ($gem>=$topaygem) {
		output("`0You hand over`%");
		if ($gem==1) output("one gem`0.");
		else output("%s gems`0 and he counts them out carefully.",$gem);
		output("`n`n`#'Looks like that's enough `%gems`# to make me happy.'");
	}elseif ($gem==0){
		output("`#'Umm, well, thanks for nothing.'`n`n");
		output("'Maybe you should actually give me some gems instead of wasting my time.`n`n");
	}else{
		output("`0You hand over`%");
		if ($gem==1) output("one gem`0.`n`n");
		else output("%s gems`0 and he counts them out carefully.`n`n",$gem);
	}
	if ($current==1){
		increment_module_pref("paidgema",$gem);
		$paidgem=get_module_pref("paidgema");
	}
	if ($current==2){
		increment_module_pref("paidgeme",$gem);
		$paidgem=get_module_pref("paidgeme");
	}
	if ($current==3){
		increment_module_pref("paidgemw",$gem);
		$paidgem=get_module_pref("paidgemw");
	}
	if ($current==4){
		increment_module_pref("paidgemf",$gem);
		$paidgem=get_module_pref("paidgemf");
	}
	if ($current==5){
		increment_module_pref("paidgemm",$gem);
		$paidgem=get_module_pref("paidgemm");
	}
	$topaygem=$costgem-$paidgem;
	if ($topaygem>0){
		output("`#'You will need`%");
		if ($topaygem==1) output("one gem");
		else output("%s gems",$topaygem);
		output("`# more before you're paid in full for gems.'");
	}
	$session['user']['gems']-=$gem;
	if ($topaygem>0) addnav("Pay More Gems","runmodule.php?module=signetsale&op=paygems");
	if ($topaygold>0) addnav("Pay Gold","runmodule.php?module=signetsale&op=paygold");
	if ($topayturn>0) addnav("Spend Turns","runmodule.php?module=signetsale&op=payturn");
	if ($topayturn<=0 && $topaygold<=0 && $topaygem<=0) addnav("Collect Your Map","runmodule.php?module=signetsale&op=getmap");
}
if ($op=="getmap"){
	output("`0You happily take the precious map from the mapmaker.");
	output("`n`nAfter some careful study of the map, you discover that the entrance to the `&%s`0 is located in",$dungeonnames[$current]);
	if ($current==1){
		output("`&%s`0.",get_module_setting("airmaploc","signetd1"));
		output("`n`n`#'Like I said, you've been warned... Do not go there unprepared.  Once you've finished exploring `&%s`#, you can come back and see what else I have to offer you.'",$dungeonnames[$current]);
		output("`n`n`0Almost as an afterthought, the vendor gives you another piece of paper. `#'Maybe this will answer some questions about what these maps are all about.'");
		output("`n`n`0You take the fragile scroll and look at it briefly.");
		output("`n`n`^Would you like to read the scroll?  If you don't want to right now, it will be available in your Bio for review.");
		if (get_module_setting("usepics")==1) {
			output("`n`n`0You decide to take a quick look at the map:`n`n");
			rawoutput("<br><center><table><tr><td align=center><img src=modules/signetimg/d1.gif></td></tr></table></center><br>"); 
		}
		addnav("Read Scroll 1","runmodule.php?module=signetsale&op=scroll1b");
		set_module_pref("scroll1",1);
		set_module_pref("airsigmap",1);	
	}elseif (is_module_active("signetd2") && $current==2){
		output("`&%s`0.",get_module_setting("earthmaploc","signetd2"));
		if (get_module_setting("usepics")==1){
			output("`n`n`0You decide to take a quick look at the map:`n`n");
			rawoutput("<br><center><table><tr><td align=center><img src=modules/signetimg/d2.gif></td></tr></table></center><br>"); 
		}
		set_module_pref("earthsigmap",1);
	}elseif (is_module_active("signetd3") && $current==3){
		output("`&%s`0.",get_module_setting("watermaploc","signetd3"));
		if (get_module_setting("usepics")==1){
			output("`n`n`0You decide to take a quick look at the map:`n`n");
			rawoutput("<br><center><table><tr><td align=center><img src=modules/signetimg/d3.gif></td></tr></table></center><br>"); 
		}
		set_module_pref("watersigmap",1);
	}elseif (is_module_active("signetd4") && $current==4){
		output("`&%s`0.",get_module_setting("firemaploc","signetd4"));
		if (get_module_setting("usepics")==1){
			output("`n`n`0You decide to take a quick look at the map:`n`n");
			rawoutput("<br><center><table><tr><td align=center><img src=modules/signetimg/d4.gif></td></tr></table></center><br>"); 
		}
		set_module_pref("firesigmap",1);
	}elseif (is_module_active("signetd5") && $current==5){
		output("`&%s`0.",get_module_setting("finalmaploc","signetd5"));
		output("`n`n'This is the last map I have to offer you from my collection of rare maps.  It's been my pleasure doing business with you.");
		output("I wish you the best of luck accomplishing this last map.  From what I recall, this is a very dangerous place to visit.'`n`n");
		output("'Good Luck!'");
		if (get_module_setting("usepics")==1){
			output("`n`n`0You decide to take a quick look at the map:`n`n");
			rawoutput("<br><center><table><tr><td align=center><img src=modules/signetimg/d5.gif></td></tr></table></center><br>"); 
		}
		set_module_pref("finalsigmap",1);
	}else{
	//If the next of the remaining modules haven't been written/installed, this message will default
		if ($current==2) set_module_pref("earthsigmap",1);
		if ($current==3) set_module_pref("watersigmap",1);
		if ($current==4) set_module_pref("firesigmap",1);
		if ($current==5) set_module_pref("finalsigmap",1);
		set_module_pref("incomplete",1);
		output("...  Actually, after careful examination of the map, you can't find the entrance!");
		output("You look over at the vendor with an evil scowl.`n`n");
		output("`#'I'm sorry, I don't think it's ready for you to explore yet.  Please check back and see if I can tell you were it is in the future.'");
		output("`n`n`0Unfortunately, there's not much you can do at this time.  If you are looking forward to finding the next dungeon, please send a note to the ruler of the land.");
	}
}
if ($op=="scroll1b"){
	output("`c`b`^The Aria Dungeon`0`c`b`n");
	output("The Aria Dungeon was once the center of a small community of dwarves.  About 15 years ago, a band of orcs invaded the community and defeated the dwarves.");
	output("`n`nIt is said that only the leader of the dwarves, Kilmor, and a few others escaped from the Orcs.");
}
//Bio Information starts here
if ($op=="signetnotes"){
	$userid = httpget("user");
	$strike = false;
	page_header("Signet Elementals");
	rawoutput("<big>");
	output_notl("`c");
	if (get_module_pref("completednum","signetsale",$userid)>0)output("Signet Recognition Title:`n`n");
	if (get_module_pref("completednum","signetsale",$userid)>10) output("`^`bGreat Mage of the Signets`b");
	if (get_module_pref("completednum","signetsale",$userid)==10) output("`%Power Signet Mage");
	if (get_module_pref("completednum","signetsale",$userid)==9) output("`\$Fire Signet Mage");
	if (get_module_pref("completednum","signetsale",$userid)==8) output("`!Water Signet Mage");
	if (get_module_pref("completednum","signetsale",$userid)==7) output("`QEarth Signet Mage");
	if (get_module_pref("completednum","signetsale",$userid)==6) output("`3Air Signet Mage");
	if (get_module_pref("completednum","signetsale",$userid)==5) output("`6Dark Lord's Bane");
	if (get_module_pref("completednum","signetsale",$userid)==4) output("`1Nemesis of Mierscri");
	if (get_module_pref("completednum","signetsale",$userid)==3) output("`#Supreme Vanquisher");
	if (get_module_pref("completednum","signetsale",$userid)==2) output("`@Grand Vanquisher");
	if (get_module_pref("completednum","signetsale",$userid)==1) output("`^Vanquisher");
	output_notl("`c`n");
	rawoutput("</big>");
	if (get_module_pref("airsignet","signetd1",$userid)==1) {
		output("`c`^`bSignet Markings`c");
		output("`n`c`3~ Air Signet ~`b`c");
	}
	if (get_module_pref("earthsignet","signetd2",$userid)==1) output("`b`n`c`Q~ Earth Signet ~`c`b");
	if (get_module_pref("watersignet","signetd3",$userid)==1) output("`b`n`c`!~ Water Signet ~`c`b");
	if (get_module_pref("firesignet","signetd4",$userid)==1) output("`b`n`c`\$~ Fire Signet ~`c`b");
	if (get_module_pref("powersignet","signetd5",$userid)==1) output("`b`n`c`%~ Power Signet ~`c`b");
	rawoutput("</big>");
	if ($userid==$session['user']['acctid'] && get_module_pref("scroll1")==1 && get_module_pref("airsignet","signetd1")==0 && get_module_pref("completednum")==0) output("`c`b`&Scrolls of the `3E`Ql`!e`\$m`3e`Qn`!t`\$a`3l`& Signets`b`c");
	if ($userid==$session['user']['acctid'] && get_module_pref("scroll1")==1) addnav("Scroll 1","runmodule.php?module=signetsale&op=scroll1&user=$userid");			
	modulehook("scrolls-signetsale");
	$return = httpget('return');
	$return = cmd_sanitize($return);
	$return = substr($return,strrpos($return,"/")+1);
	tlschema("nav");
	addnav("Return whence you came",$return);
	tlschema();
	blocknav("runmodule.php?module=mapmaker");
	blocknav("runmodule.php?module=cartographer");
}
if ($op=="scroll1"){
	$userid = httpget("user");
	output("`c`b`^The Aria Dungeon`0`c`b`n");
	output("The Aria Dungeon was once the center of a small community of dwarves.  About 15 years ago, a band of orcs invaded the community and defeated the dwarves.");
	output("`n`nIt is said that only the leader of the dwarves, Kilmor, and a few others escaped from the Orcs.");
	addnav("Return to Signets","runmodule.php?module=signetsale&op=signetnotes&user=$userid");
	blocknav("runmodule.php?module=mapmaker");
	blocknav("runmodule.php?module=cartographer");
}
if ($op == "hof") {
	page_header("Hall of Fame");
	$pp = get_module_setting("frpp","signetd5");
	$pageoffset = (int)$page;
	if ($pageoffset > 0) $pageoffset--;
	$pageoffset *= $pp;
	$limit = "LIMIT $pageoffset,$pp";
	$sql = "SELECT COUNT(*) AS c FROM " . db_prefix("module_userprefs") . " WHERE modulename = 'signetd5' AND setting = 'frhofnum' AND value > 0";
	$result = db_query($sql);
	$row = db_fetch_assoc($result);
	$total = $row['c'];
	$count = db_num_rows($result);
	if (($pageoffset + $pp) < $total){
		$cond = $pageoffset + $pp;
	}else{
		$cond = $total;
	}
if (get_module_setting("dksincewin")==-1){
	$sql = "SELECT ".db_prefix("module_userprefs").".value, ".db_prefix("accounts").".name FROM " . db_prefix("module_userprefs") . "," . db_prefix("accounts") . " WHERE acctid = userid AND modulename = 'signetd5' AND setting = 'frhofnum' AND value > 0 ORDER BY (value+0) DESC $limit";
	$result = db_query($sql);
	$rank = translate_inline("Rank");
	$name = translate_inline("Name");
	$none = translate_inline("Mierscri is Undefeated!");
	output("`b`c`@Vanquishers of the Dark Lord Mierscri`c`b`n`n");
	rawoutput("<table border='0' cellpadding='2' cellspacing='1' align='center' bgcolor='#999999'>");
	rawoutput("<tr class='trhead'><td>$rank</td><td>$name</td></tr>");
	if (db_num_rows($result)==0){
		output_notl("<tr class='trlight'><td colspan='3' align='center'>`&$none`0</td></tr>",true);
	}
	if (db_num_rows($result)>0){
		for($i = $pageoffset; $i < $cond && $count; $i++) {
			$row = db_fetch_assoc($result);
			if ($row['name']==$session['user']['name']){
			rawoutput("<tr class='trhilight'><td>");
		}else{
			rawoutput("<tr class='".($i%2?"trdark":"trlight")."'><td>");
		}
		$j=$i+1;
		output_notl("$j.");
		rawoutput("</td><td>");
		output_notl("`&%s`0",$row['name']);
		rawoutput("</td></tr>");
		}
	}
}
if (get_module_setting("dksincewin")>=0){
	$names=array("`)DarkSlayer","`&Vanquisher","`@Grand Vanquisher","`#Supreme Vanquisher","`1Nemesis","`6Bane of Evil","`3Air Mage","`QEarth Mage","`!Water Mage","`\$Fire Mage","`%Power Mage","`^Signet Mage","`^Signet Mage","`^Signet Mage","`^Signet Mage","`^Signet Mage","`^Signet Mage","`^Signet Mage","`^Signet Mage","`^Signet Mage","`^Signet Mage","`^Signet Mage","`^Signet Mage","`^Signet Mage","`^Signet Mage","`^Signet Mage","`^Signet Mage");
	$sql = "SELECT ".db_prefix("module_userprefs").".value, ".db_prefix("accounts").".name FROM " . db_prefix("module_userprefs") . "," . db_prefix("accounts") . " WHERE acctid = userid AND modulename = 'signetsale' AND setting = 'completednum' AND value > 0 ORDER BY (value+0) DESC $limit";
	$result = db_query($sql);
	$rank = translate_inline("Rank");
	$name = translate_inline("Name");
	$title = translate_inline("Signet Title");
	$none = translate_inline("Mierscri is Undefeated!");
	output("`b`c`@Vanquishers of the Dark Lord Mierscri`c`b`n`n");
	rawoutput("<table border='0' cellpadding='2' cellspacing='1' align='center' bgcolor='#999999'>");
	rawoutput("<tr class='trhead'><td>$rank</td><td>$name</td><td>$title</td></tr>");
	if (db_num_rows($result)==0){
		output_notl("<tr class='trlight'><td colspan='3' align='center'>`&$none`0</td></tr>",true);
	}
	if (db_num_rows($result)>0){
		for($i = $pageoffset; $i < $cond && $count; $i++) {
			$row = db_fetch_assoc($result);
			if ($row['name']==$session['user']['name']){
				rawoutput("<tr class='trhilight'><td>");
			}else{
				rawoutput("<tr class='".($i%2?"trdark":"trlight")."'><td>");
			}
			$j=$i+1;
			output_notl("$j.");
			rawoutput("</td><td>");
			output_notl("`&%s`0",$row['name']);
			rawoutput("</td><td>");
			output_notl("`@%s`0",$names[$row['value']]);
			rawoutput("</td></tr>");
        }
	}
}
	rawoutput("</table>");
	if ($total>$pp){
		addnav("Pages");
		for ($p=0;$p<$total;$p+=$pp){
			addnav(array("Page %s (%s-%s)", ($p/$pp+1), ($p+1), min($p+$pp,$total)), "runmodule.php?module=signetsale&op=hof&page=".($p/$pp+1));
		}
	}
	addnav("Other");
	addnav("Back to HoF", "hof.php");
	if (is_module_active("mapmaker") && get_module_setting("mapmaker")==1) blocknav("runmodule.php?module=mapmaker");
	if (is_module_active("cartographer") && get_module_setting("mapmaker")==1) blocknav("runmodule.php?module=cartographer");
	villagenav();
}
if ($op == "hof2") {
	page_header("Hall of Fame");
	$pp = get_module_setting("pp");
	$pageoffset = (int)$page;
	if ($pageoffset > 0) $pageoffset--;
	$pageoffset *= $pp;
	$limit = "LIMIT $pageoffset,$pp";
	$sql = "SELECT COUNT(*) AS c FROM " . db_prefix("module_userprefs") . " WHERE modulename = 'signetsale' AND setting = 'dkopena' AND value > 0";
	$result = db_query($sql);
	$row = db_fetch_assoc($result);
	$total = $row['c'];
	$count = db_num_rows($result);
	$none = translate_inline("No Signet Heros Yet");
	if (($pageoffset + $pp) < $total){
		$cond = $pageoffset + $pp;
	}else{
		$cond = $total;
	}
	$sql = "SELECT userid FROM " . db_prefix("module_userprefs") . " WHERE modulename = 'signetsale' AND setting = 'dkopena' AND value > 0";
	$result = db_query($sql);
	if (db_num_rows($result)>0){
		for($i = 1; $i <= $total; $i++) {
			$row = db_fetch_assoc($result);
			if (get_module_pref("complete","signetd5",$row['userid']))			$hoftemp=53;
			elseif (get_module_pref("powersignet","signetd5",$row['userid']))		$hoftemp=52;
			elseif (get_module_pref("finalsigmap","signetsale",$row['userid']))	$hoftemp=51;
			elseif (get_module_pref("paidgoldm","signetsale",$row['userid'])||
				  get_module_pref("paidturnm","signetsale",$row['userid'])||
				  get_module_pref("paidgemm","signetsale",$row['userid']))        $hoftemp=50;
			elseif (get_module_pref("dkopenm","signetsale",$row['userid']))		$hoftemp=49;
			elseif (get_module_pref("complete","signetd4",$row['userid']))		$hoftemp=43;
			elseif (get_module_pref("firesignet","signetd4",$row['userid']))		$hoftemp=42;
			elseif (get_module_pref("firesigmap","signetsale",$row['userid']))	$hoftemp=41;
			elseif (get_module_pref("paidgoldf","signetsale",$row['userid'])||
				  get_module_pref("paidturnf","signetsale",$row['userid'])||
				  get_module_pref("paidgemf","signetsale",$row['userid']))        $hoftemp=40;
			elseif (get_module_pref("dkopenf","signetsale",$row['userid']))		$hoftemp=39;
			elseif (get_module_pref("complete","signetd3",$row['userid']))		$hoftemp=33;
			elseif (get_module_pref("watersignet","signetd3",$row['userid']))		$hoftemp=32;
			elseif (get_module_pref("watersigmap","signetsale",$row['userid']))	$hoftemp=31;
			elseif (get_module_pref("paidgoldw","signetsale",$row['userid'])||
				  get_module_pref("paidturnw","signetsale",$row['userid'])||
				  get_module_pref("paidgemw","signetsale",$row['userid']))        $hoftemp=30;
			elseif (get_module_pref("dkopenw","signetsale",$row['userid']))		$hoftemp=29;
			elseif (get_module_pref("complete","signetd2",$row['userid']))		$hoftemp=23;
			elseif (get_module_pref("earthsignet","signetd2",$row['userid']))		$hoftemp=22;
			elseif (get_module_pref("earthsigmap","signetsale",$row['userid']))	$hoftemp=21;
			elseif (get_module_pref("paidgolde","signetsale",$row['userid'])||
				  get_module_pref("paidturne","signetsale",$row['userid'])||
				  get_module_pref("paidgeme","signetsale",$row['userid']))        $hoftemp=20;
			elseif (get_module_pref("dkopene","signetsale",$row['userid']))		$hoftemp=19;
			elseif (get_module_pref("complete","signetd1",$row['userid']))		$hoftemp=13;
			elseif (get_module_pref("airsignet","signetd1",$row['userid']))		$hoftemp=12;
			elseif (get_module_pref("airsigmap","signetsale",$row['userid']))		$hoftemp=11;
			elseif (get_module_pref("paidgolda","signetsale",$row['userid'])||
				  get_module_pref("paidturna","signetsale",$row['userid'])||
				  get_module_pref("paidgema","signetsale",$row['userid']))        $hoftemp=10;
			elseif (get_module_pref("dkopena","signetsale",$row['userid']))		$hoftemp=9;
			else 									$hoftemp=1;
			set_module_pref("hoftemp",$hoftemp,"signetsale",$row['userid']);
		}
	}
			
	$sql = "SELECT ".db_prefix("module_userprefs").".value, ".db_prefix("module_userprefs").".userid, ".db_prefix("accounts").".name FROM " . db_prefix("module_userprefs") . "," . db_prefix("accounts") . " WHERE acctid = userid AND modulename = 'signetsale' AND setting = 'hoftemp' AND value > 0 ORDER BY (value+0) DESC $limit";
	$result = db_query($sql);
	$rank = sprintf_translate("Rank");
	$name = sprintf_translate("Name");
	$temple1 = sprintf_translate("`b`c`3~ Aria Dungeon ~`c`b`0");
	$temple2 = sprintf_translate("`b`c`Q~ Aarde Temple ~`c`b`0");
	$temple3 = sprintf_translate("`b`c`!~ Wasser's Castle ~`c`b`0");
	$temple4 = sprintf_translate("`b`c`\$~ Fiamma's Fortress ~`c`b`0");
	$temple5 = sprintf_translate("`b`c`%~ Dark Lair ~`c`b`0");
	output("`b`c`@Status of the Quest for the Elemental Signets`c`b`n`n");
	rawoutput("<table border='0' cellpadding='2' cellspacing='1' align='center' bgcolor='#999999'>");
	rawoutput("<tr class='trhead'><td>");
	output($rank);
	rawoutput("</td><td>");
	output($name);
	rawoutput("</td><td>");
	output($temple1);
	rawoutput("</td><td>");
	output($temple2);
	rawoutput("</td><td>");
	output($temple3);
	rawoutput("</td><td>");
	output($temple4);
	rawoutput("</td><td>");
	output($temple5);
	rawoutput("</td></tr>");
	if (db_num_rows($result)==0) output_notl("<tr class='trlight'><td colspan='7' align='center'>`&$none`0</td></tr>",true);
	else{
		for($i = $pageoffset; $i < $cond && $count; $i++) {
			$row = db_fetch_assoc($result);
			if ($row['name']==$session['user']['name']){
				rawoutput("<tr class='trhilight'><td>");
			}else{
				rawoutput("<tr class='".($i%2?"trdark":"trlight")."'><td>");
			}
			$j=$i+1;
			output_notl("$j.");
			rawoutput("</td><td>");
			output_notl("`&%s`0",$row['name']);
			rawoutput("</td><td>");
			if (get_module_pref("complete","signetd1",$row['userid']))
				$text1 = sprintf_translate("`b`c`@~ Completed ~`c`b`0");
			elseif (get_module_pref("airsignet","signetd1",$row['userid']))
				$text1 = sprintf_translate("`b`c`!~ Has Signet ~`c`b`0");
			elseif (get_module_pref("airsigmap","signetsale",$row['userid']))
				$text1 = sprintf_translate("`c`^~ Has Map ~`c`0");
			elseif (get_module_pref("paidgolda","signetsale",$row['userid'])||
				  get_module_pref("paidturna","signetsale",$row['userid'])||
				  get_module_pref("paidgema","signetsale",$row['userid']))
				$text1 = sprintf_translate("`c`\$~ Financing ~`c`0");
			elseif (get_module_pref("dkopena","signetsale",$row['userid']))
				$text1 = sprintf_translate("`c`&~ Started ~`c`0");
			else $text1 = sprintf_translate("`c`)Not Started`c`0");
			output_notl($text1);
			rawoutput("</td><td>");
			if (get_module_pref("complete","signetd2",$row['userid']))
				$text2 = sprintf_translate("`b`c`@~ Completed ~`c`b`0");
			elseif (get_module_pref("earthsignet","signetd2",$row['userid']))
				$text2 = sprintf_translate("`b`c`!~ Has Signet ~`c`b`0");
			elseif (get_module_pref("earthsigmap","signetsale",$row['userid']))
				$text2 = sprintf_translate("`c`^~ Has Map ~`c`0");
			elseif (get_module_pref("paidgolde","signetsale",$row['userid'])||
				  get_module_pref("paidturne","signetsale",$row['userid'])||
				  get_module_pref("paidgeme","signetsale",$row['userid']))
				$text2 = sprintf_translate("`c`\$~ Financing ~`c`0");
			elseif (get_module_pref("dkopene","signetsale",$row['userid']))
				$text2 = sprintf_translate("`c`&~ Started ~`c`0");
			else $text2 = sprintf_translate("`c`)Not Started`c`0");
			output_notl($text2);
			rawoutput("</td><td>");
			if (get_module_pref("complete","signetd3",$row['userid']))
				$text3 = sprintf_translate("`b`c`@~ Completed ~`c`b`0");
			elseif (get_module_pref("watersignet","signetd3",$row['userid']))
				$text3 = sprintf_translate("`b`c`!~ Has Signet ~`c`b`0");
			elseif (get_module_pref("watersigmap","signetsale",$row['userid']))
				$text3 = sprintf_translate("`c`^~ Has Map ~`c`b`0");
			elseif (get_module_pref("paidgoldw","signetsale",$row['userid'])||
				  get_module_pref("paidturnw","signetsale",$row['userid'])||
				  get_module_pref("paidgemw","signetsale",$row['userid']))
				$text3 = sprintf_translate("`c`\$~ Financing ~`c`0");
			elseif (get_module_pref("dkopenw","signetsale",$row['userid']))
				$text3 = sprintf_translate("`c`&~ Started ~`c`0");
			else $text3 = sprintf_translate("`c`)Not Started`c`0");
			output_notl($text3);
			rawoutput("</td><td>");
			if (get_module_pref("complete","signetd4",$row['userid']))
				$text4 = sprintf_translate("`b`c`@~ Completed ~`c`b`0");
			elseif (get_module_pref("firesignet","signetd4",$row['userid']))
				$text4 = sprintf_translate("`b`c`!~ Has Signet ~`c`b`0");
			elseif (get_module_pref("firesigmap","signetsale",$row['userid']))
				$text4 = sprintf_translate("`c`^~ Has Map ~`c`0");
			elseif (get_module_pref("paidgoldf","signetsale",$row['userid'])||
				  get_module_pref("paidturnf","signetsale",$row['userid'])||
				  get_module_pref("paidgemf","signetsale",$row['userid']))
				$text4 = sprintf_translate("`c`\$~ Financing ~`c`0");
			elseif (get_module_pref("dkopenf","signetsale",$row['userid']))
				$text4 = sprintf_translate("`c`&~ Started ~`c`0");
			else $text4 = sprintf_translate("`c`)Not Started`c`0");
			output_notl($text4);
			rawoutput("</td><td>");
			if (get_module_pref("complete","signetd5",$row['userid']))
				$text5 = sprintf_translate("`b`c`@~ Completed ~`c`b`0");
			elseif (get_module_pref("powersignet","signetd5",$row['userid']))
				$text5 = sprintf_translate("`b`c`!~ Has Signet ~`c`b`0");
			elseif (get_module_pref("finalsigmap","signetsale",$row['userid']))
				$text5 = sprintf_translate("`c`^~ Has Map ~`c`0");
			elseif (get_module_pref("paidgoldm","signetsale",$row['userid'])||
				  get_module_pref("paidturnm","signetsale",$row['userid'])||
				  get_module_pref("paidgemm","signetsale",$row['userid']))
				$text5 = sprintf_translate("`c`\$~ Financing ~`c`0");
			elseif (get_module_pref("dkopenm","signetsale",$row['userid']))
				$text5 = sprintf_translate("`c`&~ Started ~`c`0");
			else $text5 = sprintf_translate("`c`)Not Started`c`0");
			output_notl($text5);
			rawoutput("</td></tr>");
		}

        }
	rawoutput("</table>");
	if ($total>$pp){
		addnav("Pages");
		for ($p=0;$p<$total;$p+=$pp){
			addnav(array("Page %s (%s-%s)", ($p/$pp+1), ($p+1), min($p+$pp,$total)), "runmodule.php?module=signetsale&op=hof2&page=".($p/$pp+1));
		}
	}
	addnav("Other");
	addnav("Back to HoF", "hof.php");
	if (is_module_active("mapmaker") && get_module_setting("mapmaker")==1) blocknav("runmodule.php?module=mapmaker");
	if (is_module_active("cartographer") && get_module_setting("mapmaker")==1) blocknav("runmodule.php?module=cartographer");
	villagenav();
}
page_footer();

function signetsale_work(){
	global $session;
	switch(e_rand(1,5)){
		case 1:
			output("'Well, you've certainly done a really mediocre job.");
		break;
		case 2:
			output("'Your organizational skills are pretty impressive.  Good Job!");
		break;
		case 3:
			output("'I think you've made more of a mess than there was before you started.  Very disappointing.");
		break;
		case 4:
			output("'Hold on for a second.  Let me think.  Oh yeah, I DID know a monkey with more talent than you have.");
		break;
		case 5:
			output("'Wonderful!  Keep up the good work.");
		break;
	}
}
?>
