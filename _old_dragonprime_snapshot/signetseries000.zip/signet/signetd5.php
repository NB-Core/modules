<?php
	global $session;
	global $badguy;
	//most of this is modification of the abandoned castle module by Lonnyl,
	//and I couldn't have coded this without using his work as a template.
	$op = httpget('op');
	$locale = httpget('loc');
	$skill = httpget('skill');
	$knownmonsters = array('random','door','blackwarlock','blackwarlocks','waterelemental','lostspirit','mierscri');
	if (in_array($op, $knownmonsters) || $op == "fight" || $op == "run") {
		signetd5_fight($op);
		die;
	}
	$misc= array ('scroll1b','scroll2b','scroll3b','scroll4b','scroll5b','scroll6b','scroll7b','1172','1138','1002','898','902','895','905','1104','724','736','792','804','687','691','701','705','pickdoor','860','872','fiamma','evad','william','niflescro','kilmor','niscosnat','arandee','wasser','sig1','sig2','sig3','sig4','sig5','sig6','sig7','sig8','warlockguard','mapfix','traphall','transporter','tohalls','tovill','335','503','503b','503c','503d','505','505b','505c','507','507b','507c','777','774','1012','1016','1016b','1220','1220b','1220c','1220d','deathbywand','834','766','766b','766c','948','849','1257','endgame','eg1','eg2','eg3','eg4','eg5','eg6','eg7','reset','eg1b','exits2','exits3');
	if (in_array($op,$misc)){
		signetd5_misc($op);
	}
	page_header("Mierscri's Lair");
	if ($session['user']['hitpoints'] > 0){} else{
		redirect("shades.php");
	}
	$umaze = get_module_pref('maze');
	$umazeturn = get_module_pref('mazeturn');
	$upqtemp = get_module_pref('pqtemp');
	if ($op == "" && $locale == "") {
		output("`c`b`&Myerscri's Lair`0`b`c`n");
		if (get_module_pref("startloc")==1274) output("`\$You only have two choices: Face your fears or run from them. You stand at the entrance to the most foul Lair you have ever encountered.  Which choice will you make?`0");
		elseif (get_module_pref("startloc")==796) output("`\$You enter `QTellusa's Chamber`\$. Are you ready to confront Mierscri?`0`n`n");
		$locale=get_module_pref("startloc");
		$umazeturn = 0;
		set_module_pref("mazeturn", 0);
		if (!isset($maze)){
			$maze = array(16,16,16,16,16,16,27,16,16,16,27,16,27,16,27,16,27,16,27,16,27,16,16,16,27,16,16,16,27,16,16,16,16,16,16,16,16,16,16,16,19,16,16,16,19,16,19,16,19,16,19,16,19,16,19,16,16,16,19,16,16,16,19,16,16,16,16,16,16,16,16,16,16,16,19,16,16,16,19,16,19,16,19,16,19,16,19,16,19,16,16,16,19,16,16,16,19,16,16,16,16,16,16,16,16,16,16,16,19,16,16,16,19,16,19,16,19,16,19,16,19,16,19,16,16,16,19,16,16,16,19,16,16,16,16,16,16,16,16,16,16,16,19,16,16,16,19,16,19,16,19,16,19,16,19,16,19,16,16,16,19,16,16,16,19,16,16,16,16,16,16,16,16,16,16,16,19,16,16,16,19,16,19,16,19,16,19,16,19,16,19,16,16,16,19,16,16,16,19,16,16,16,16,16,16,16,16,16,16,16,19,16,16,16,19,16,19,16,19,16,19,16,19,16,19,16,16,16,19,16,16,16,19,16,16,16,16,16,16,16,16,16,16,16,19,16,16,16,19,16,19,16,19,16,19,16,19,16,19,16,16,16,19,16,16,16,19,16,16,16,16,16,16,16,16,16,16,16,19,16,16,16,19,16,19,16,19,16,19,16,19,16,19,16,16,16,19,16,16,16,19,16,16,16,16,16,16,16,16,16,16,16,19,16,16,16,19,16,19,16,19,16,19,16,19,16,19,16,16,16,19,16,6,13,15,13,7,16,16,16,16,16,16,16,16,16,5,26,26,26,5,16,19,16,19,16,19,16,19,16,5,26,26,26,5,16,11,15,15,15,12,16,16,16,16,16,16,16,16,16,5,16,16,16,5,16,19,16,19,16,19,16,19,16,5,16,16,16,5,16,11,15,15,15,12,16,16,16,16,16,16,16,16,16,5,16,16,16,5,16,5,26,5,16,5,26,5,16,5,16,16,16,5,16,11,15,15,15,12,16,16,16,16,16,16,16,16,16,5,16,16,16,5,16,5,16,5,16,5,16,5,16,5,16,16,16,5,16,11,15,15,15,12,16,16,16,16,16,16,16,16,16,8,10,13,10,9,16,8,13,9,16,8,13,9,16,8,10,13,10,9,16,8,14,15,14,9,16,16,16,16,16,16,16,16,16,16,16,19,16,16,16,16,19,16,16,16,19,16,16,16,16,19,16,16,16,16,16,19,16,16,16,16,16,16,16,16,16,20,17,17,17,22,16,16,16,16,19,16,16,16,19,16,16,16,16,18,17,17,17,21,16,19,16,16,16,16,16,16,16,16,16,19,16,16,16,16,16,16,16,16,19,16,16,16,19,16,16,16,16,16,16,16,16,19,16,19,16,16,16,16,16,16,16,16,16,19,16,16,6,13,7,16,16,16,19,16,16,16,19,16,16,16,6,13,7,16,16,19,16,19,16,16,16,16,16,16,16,16,16,19,16,16,11,15,12,16,16,16,19,16,16,16,19,16,16,16,11,15,12,16,16,19,16,19,16,16,16,16,16,16,16,16,16,18,17,17,14,14,15,17,17,17,22,16,16,16,18,17,17,17,15,14,14,17,17,22,16,19,16,16,16,16,16,16,16,16,16,16,16,16,16,16,19,16,16,16,16,16,16,16,16,16,16,16,19,16,16,16,16,16,16,19,16,16,16,16,16,16,16,16,16,16,16,16,16,16,19,16,16,16,6,13,13,13,7,16,16,16,19,16,16,16,20,17,17,22,16,16,16,16,16,16,16,16,16,16,16,16,16,16,19,16,16,16,11,15,15,15,12,16,16,16,19,16,16,16,19,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,19,16,16,16,8,14,14,14,9,16,16,16,19,16,16,16,19,16,16,16,20,17,17,21,16,16,16,16,16,16,16,16,16,16,19,16,16,16,16,16,16,16,16,16,16,16,19,16,16,16,19,16,16,16,19,16,16,19,16,16,16,16,16,16,16,16,6,13,15,17,17,17,17,13,13,13,17,17,17,17,15,13,7,16,19,16,16,16,19,16,16,19,16,16,16,16,16,16,16,16,11,15,12,16,16,16,16,11,15,12,16,16,16,16,11,15,12,16,19,16,16,16,19,16,16,19,16,16,16,16,16,16,16,16,8,14,9,16,16,16,16,8,15,9,16,16,16,16,8,14,9,16,19,16,16,16,19,16,16,19,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,19,16,16,16,16,16,16,16,16,16,18,17,17,17,24,16,16,19,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,6,15,7,16,16,16,16,16,16,16,16,16,16,16,16,19,16,16,19,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,11,15,12,16,16,16,16,16,16,16,16,16,16,16,16,19,16,16,19,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,8,15,9,16,16,16,16,16,16,16,16,16,16,16,16,19,16,16,19,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,19,16,16,16,16,16,16,16,16,16,16,16,16,16,19,16,16,19,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,19,16,16,16,16,16,16,16,16,16,16,16,16,16,19,16,16,19,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,19,16,16,16,16,16,16,16,16,16,16,16,16,16,19,16,16,19,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,19,16,16,16,16,16,16,16,16,16,16,16,16,16,23,16,16,19,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,2,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,23,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16);
			$umaze = implode($maze,",");
			set_module_pref("maze", $umaze);
		}
	}
	if ($op <> ""){
		if ($op == "n") {
			$locale+=34;
			redirect("runmodule.php?module=signetd5&loc=$locale");
		}
		if ($op == "s"){
			$locale-=34;
			redirect("runmodule.php?module=signetd5&loc=$locale");
		}
		if ($op == "w"){
			$locale-=1;
			redirect("runmodule.php?module=signetd5&loc=$locale");
		}
		if ($op == "e"){
			$locale+=1;
			redirect("runmodule.php?module=signetd5&loc=$locale");
		}
	}else{
		if ($locale <> ""){
			$maze=explode(",", $umaze);
			if ($locale=="") $locale = $upqtemp;
			$upqtemp = $locale;
			set_module_pref("pqtemp", $upqtemp);
			for ($i=0;$i<$locale-1;$i++){
			}
			$navigate=ltrim($maze[$i]);
			output("`7");
			if ($session['user']['hitpoints'] > 0){
				if (get_module_pref("super")==1 || $locale=="1274") villagenav();
				//This is to prevent players from getting 250 gems and timing out or cheating.
				if (get_module_pref("loc503b")==1 || get_module_pref("loc507b")==1){
					output("You have been found in possession of stolen goods.  All of your `%gems`0, `^gold`0, and `^gold in the bank`0 has been confiscated.");
					$session['user']['gold']=0;
					$session['user']['gems']=0;
					$session['user']['goldinbank']=0;
					set_module_pref("loc503b",0);
					set_module_pref("loc507b",0);
				}
				if ($locale=="301"||$locale=="533"||$locale=="701"||$locale=="705"||$locale=="736"||$locale=="872"||$locale=="896"||$locale=="524"||$locale=="528"||$locale=="331"||$locale=="327"||$locale=="313"||$locale=="317"||$locale=="387"||$locale=="389"||$locale=="391"||$locale=="393"||$locale=="519"||$locale=="687"||$locale=="691"||$locale=="724"||$locale=="860"||$locale=="898"||$locale=="902"||$locale=="1138"||$locale=="1240") set_module_pref("header",1);
				elseif ($locale=="1002"||$locale=="1104") set_module_pref("header",2);
				elseif ($locale=="704"||$locale=="702"||$locale=="906"||$locale=="688"||$locale=="690"||$locale=="894"||$locale=="901"||$locale=="899"||$locale=="968") set_module_pref("header",3);
				elseif ($locale=="361"||$locale=="365"||$locale=="499"||$locale=="494"||$locale=="490"||$locale=="425"||$locale=="427"||$locale=="421"||$locale=="423"||$locale=="347"||$locale=="351"||$locale=="485") set_module_pref("header",4);
				elseif ($locale=="505"||$locale=="335") set_module_pref("header",5);
				elseif ($locale=="848"||$locale=="948"||$locale=="539") set_module_pref("header",6);
				elseif ($locale=="796") set_module_pref("header",7);
				elseif ($locale=="849") set_module_pref("header",8);
				elseif ($locale=="1274") set_module_pref("header",0);
				$title=array("","A Very Dark, Foul-Smelling Hallway","An Entrance Hall Carved Out of Black Rock","A Guard Room","A Hallway Lit With Torches","A Frightening Throne Room","A Dark, Narrow Cavern","A Peaceful Alcove","A Hallway with an Eerie Glow");
				output_notl("`b`^`c%s`b`c`0",translate_inline($title[get_module_pref("header")]));
				if (get_module_pref("header")==0) output("`n");
				if ($locale=="743" && get_module_pref("loc777")==0) output("`0The `)Dark Lord`0 stands before you.`n");
				else output("`n");

				//Set the transporter
				$exit=get_module_pref("loc109")+get_module_pref("loc113")+get_module_pref("loc115")+get_module_pref("loc117")+get_module_pref("loc119")+get_module_pref("loc121")+get_module_pref("loc123")+get_module_pref("loc127");
				if($locale=="109" && get_module_pref("loc109")==0){
					set_module_pref("loc109",1);
					if ($exit==4) set_module_pref("transport",1);
				}elseif($locale=="113" && get_module_pref("loc113")==0){
					set_module_pref("loc113",1);
					if ($exit==4) set_module_pref("transport",2);
				}elseif($locale=="115" && get_module_pref("loc115")==0){
					set_module_pref("loc115",1);
					if ($exit==4) set_module_pref("transport",3);
				}elseif($locale=="117" && get_module_pref("loc117")==0){
					set_module_pref("loc117",1);
					if ($exit==4) set_module_pref("transport",4);
				}elseif($locale=="119" && get_module_pref("loc119")==0){
					set_module_pref("loc119",1);
					if ($exit==4) set_module_pref("transport",5);
				}elseif($locale=="121" && get_module_pref("loc121")==0){
					set_module_pref("loc121",1);
					if ($exit==4) set_module_pref("transport",6);
				}elseif($locale=="123" && get_module_pref("loc123")==0){
					set_module_pref("loc123",1);
					if ($exit==4) set_module_pref("transport",7);
				}elseif($locale=="127" && get_module_pref("loc127")==0){
					set_module_pref("loc127",1);
					if ($exit==4) set_module_pref("transport",8);
				}
				if (get_module_pref("complete","signetd4")==1 && get_module_pref("reset","signetd4")==0) redirect("runmodule.php?module=signetd5&op=reset");
				elseif($locale=="1172" && get_module_pref("loc1172")==0) redirect("runmodule.php?module=signetd5&op=1172");
				elseif($locale=="1138" && get_module_pref("loc1138")==0) redirect("runmodule.php?module=signetd5&op=1138");
				elseif($locale=="1002" && get_module_pref("loc1002")==0) redirect("runmodule.php?module=signetd5&op=1002");
				elseif($locale=="898" && get_module_pref("loc898")==0) redirect("runmodule.php?module=signetd5&op=898");
				elseif($locale=="902" && get_module_pref("loc902")==0) redirect("runmodule.php?module=signetd5&op=902");
				elseif($locale=="895" && get_module_pref("loc895")==0) redirect("runmodule.php?module=signetd5&op=895");
				elseif($locale=="905" && get_module_pref("loc905")==0) redirect("runmodule.php?module=signetd5&op=905");
				elseif($locale=="1104" && get_module_pref("loc1104b")==0) redirect("runmodule.php?module=signetd5&op=1104");
				elseif($locale=="792" && get_module_pref("loc792")==0) redirect("runmodule.php?module=signetd5&op=792");
				elseif($locale=="724" && get_module_pref("loc724")==0) redirect("runmodule.php?module=signetd5&op=724");
				elseif($locale=="687" && get_module_pref("loc687")==0) redirect("runmodule.php?module=signetd5&op=687");
				elseif($locale=="691" && get_module_pref("loc691")==0) redirect("runmodule.php?module=signetd5&op=691");
				elseif($locale=="701" && get_module_pref("loc701")==0) redirect("runmodule.php?module=signetd5&op=701");
				elseif($locale=="705" && get_module_pref("loc705")==0) redirect("runmodule.php?module=signetd5&op=705");
				elseif($locale=="860" && get_module_pref("loc860")==0) redirect("runmodule.php?module=signetd5&op=860");
				elseif($locale=="872" && get_module_pref("loc872")==0) redirect("runmodule.php?module=signetd5&op=872");
				elseif($locale=="736" && get_module_pref("loc736")==0) redirect("runmodule.php?module=signetd5&op=736");
				elseif($locale=="804" && get_module_pref("loc804")==0) redirect("runmodule.php?module=signetd5&op=804");
				elseif(($locale=="685" && get_module_pref("loc685")==0)||($locale=="694" && get_module_pref("loc694")==0)||($locale=="698" && get_module_pref("loc698")==0)||($locale=="707" && get_module_pref("loc707")==0)) redirect("runmodule.php?module=signetd5&op=warlockguard");
				elseif(($locale=="1104" && get_module_pref("loc1104")==0)||($locale=="519" && get_module_pref("loc519")==0)||($locale=="524" && get_module_pref("loc524")==0)||($locale=="528" && get_module_pref("loc528")==0)||($locale=="533" && get_module_pref("loc533")==0)) redirect("runmodule.php?module=signetd5&op=blackwarlock");
				elseif ((($locale=="421" || $locale=="423") && get_module_pref("loc421")==0)||(($locale=="425" || $locale=="427") && get_module_pref("loc425")==0)||(($locale=="347" || $locale=="351") && get_module_pref("loc347")==0)||(($locale=="361" || $locale=="365") && get_module_pref("loc361")==0)) redirect("runmodule.php?module=signetd5&op=mapfix");
				elseif(($locale=="381" && get_module_pref("loc381")==0)||($locale=="385" && get_module_pref("loc385")==0)||($locale=="387" && get_module_pref("loc387")==0)||($locale=="389" && get_module_pref("loc389")==0)||($locale=="391" && get_module_pref("loc391")==0)||($locale=="393" && get_module_pref("loc393")==0)||($locale=="395" && get_module_pref("loc395")==0)||($locale=="399" && get_module_pref("loc399")==0)) redirect("runmodule.php?module=signetd5&op=waterelemental");
				elseif(($locale=="279" && get_module_pref("loc279")==0)||($locale=="283" && get_module_pref("loc283")==0)||($locale=="285" && get_module_pref("loc285")==0)||($locale=="287" && get_module_pref("loc287")==0)||($locale=="289" && get_module_pref("loc289")==0)||($locale=="291" && get_module_pref("loc291")==0)||($locale=="293" && get_module_pref("loc293")==0)||($locale=="297" && get_module_pref("loc297")==0)) redirect("runmodule.php?module=signetd5&op=traphall");
				elseif(($locale=="143" && get_module_pref("loc143")==0)||($locale=="147" && get_module_pref("loc147")==0)||($locale=="149" && get_module_pref("loc149")==0)||($locale=="151" && get_module_pref("loc151")==0)||($locale=="153" && get_module_pref("loc153")==0)||($locale=="155" && get_module_pref("loc155")==0)||($locale=="157" && get_module_pref("loc157")==0)||($locale=="161" && get_module_pref("loc161")==0)) redirect("runmodule.php?module=signetd5&op=lostspirit");
				elseif($locale=="7" && get_module_pref("transport")==1) redirect("runmodule.php?module=signetd5&op=transporter");
				elseif($locale=="7") redirect("runmodule.php?module=signetd5&op=tovill");
				elseif($locale=="11" && get_module_pref("transport")==2) redirect("runmodule.php?module=signetd5&op=transporter");
				elseif($locale=="11") redirect("runmodule.php?module=signetd5&op=tovill");
				elseif($locale=="13" && get_module_pref("transport")==3) redirect("runmodule.php?module=signetd5&op=transporter");
				elseif($locale=="13") redirect("runmodule.php?module=signetd5&op=tovill");
				elseif($locale=="15" && get_module_pref("transport")==4) redirect("runmodule.php?module=signetd5&op=transporter");
				elseif($locale=="15") redirect("runmodule.php?module=signetd5&op=tovill");
				elseif($locale=="17" && get_module_pref("transport")==5) redirect("runmodule.php?module=signetd5&op=transporter");
				elseif($locale=="17") redirect("runmodule.php?module=signetd5&op=tovill");
				elseif($locale=="19" && get_module_pref("transport")==6) redirect("runmodule.php?module=signetd5&op=transporter");
				elseif($locale=="19") redirect("runmodule.php?module=signetd5&op=tovill");
				elseif($locale=="21" && get_module_pref("transport")==7) redirect("runmodule.php?module=signetd5&op=transporter");
				elseif($locale=="21") redirect("runmodule.php?module=signetd5&op=tovill");
				elseif($locale=="25" && get_module_pref("transport")==8) redirect("runmodule.php?module=signetd5&op=transporter");
				elseif($locale=="25") redirect("runmodule.php?module=signetd5&op=tovill");
				elseif($locale=="29") redirect("runmodule.php?module=signetd5&op=tohalls");
				elseif($locale=="335" && get_module_pref("loc335")==0) redirect("runmodule.php?module=signetd5&op=335");
				elseif($locale=="503" && get_module_pref("loc503")==0) redirect("runmodule.php?module=signetd5&op=503");
				elseif($locale=="505" && get_module_pref("loc505")==0) redirect("runmodule.php?module=signetd5&op=505");
				elseif($locale=="507" && get_module_pref("loc507")==0) redirect("runmodule.php?module=signetd5&op=507");
				elseif($locale=="777" && get_module_pref("loc777")==0) redirect("runmodule.php?module=signetd5&op=777");
				elseif($locale=="774" && get_module_pref("loc774")==0) redirect("runmodule.php?module=signetd5&op=774");
				elseif($locale=="1012" && get_module_pref("loc1012")==0) redirect("runmodule.php?module=signetd5&op=1012");
				elseif($locale=="1016" && get_module_pref("loc1016")==0) redirect("runmodule.php?module=signetd5&op=1016");
				elseif($locale=="1016") redirect("runmodule.php?module=signetd5&op=1016b");
				elseif($locale=="1220") redirect("runmodule.php?module=signetd5&op=1220");
				elseif($locale=="766" && get_module_pref("loc766")==0) redirect("runmodule.php?module=signetd5&op=766");
				elseif($locale=="766") redirect("runmodule.php?module=signetd5&op=766b");
				elseif($locale=="834" && get_module_pref("loc834")==0) redirect("runmodule.php?module=signetd5&op=834");
				elseif($locale=="849" && get_module_pref("loc849")==0) redirect("runmodule.php?module=signetd5&op=849");
				elseif($locale=="1257") redirect("runmodule.php?module=signetd5&op=1257");
				//Random monsters
				elseif (get_module_pref("randomp")<get_module_setting("random")){
					switch(e_rand(1,30)){
						case 1: case 2: case 3: case 4: case 5: case 6:  case 7: case 8: case 9: case 10:
						case 11: case 12: case 13: case 14: case 15: case 16: case 17: case 18: case 19: case 20:
						case 21: case 22: case 23: case 24: case 25: case 26: case 27: case 28: case 29:
						break;
						case 30:
							$randenc=get_module_setting("randenc");
							switch(e_rand(1,$randenc)){
								case 1:
									increment_module_pref("randomp");
									switch(e_rand(1,7)){
										case 1:
											redirect("runmodule.php?module=signetd5&op=blackwarlock");
										break;
										case 2:
											redirect("runmodule.php?module=signetd5&op=waterelemental");
										break;
										case 3:
											redirect("runmodule.php?module=signetd5&op=lostspirit");
										break;
										case 4: case 5: case 6: case 7:
											redirect("runmodule.php?module=signetd5&op=random");
										break;
									}
								break;
								case 2: case 3: case 4: case 5: case 6: case 7: case 8: case 9: case 10:
								case 11: case 12: case 13: case 14: case 15: case 16: case 17: case 18: case 19: case 20:
								break;
							}
						break;
					}
				}
				$navcount = 0;
				$north=translate_inline("North");
				$south=translate_inline("South");
				$east=translate_inline("East");
				$west=translate_inline("West");
				$directions="";
				//Scrolls (Keep the old, add the new)
				addnav("Scrolls");
				addnav("1?Read Scroll 1","runmodule.php?module=signetd5&op=scroll1b");
				if (get_module_pref("scroll2","signetd1")==1) addnav("2?Read Scroll 2","runmodule.php?module=signetd5&op=scroll2b");
				if (get_module_pref("scroll3","signetd1")==1) addnav("3?Read Scroll 3","runmodule.php?module=signetd5&op=scroll3b");
				if (get_module_pref("scroll4","signetd2")==1) addnav("4?Read Scroll 4","runmodule.php?module=signetd5&op=scroll4b");
				if (get_module_pref("scroll5","signetd3")==1) addnav("5?Read Scroll 5","runmodule.php?module=signetd5&op=scroll5b");
				if (get_module_pref("scroll6","signetd4")==1) addnav("6?Read Scroll 6","runmodule.php?module=signetd5&op=scroll6b");
				if (get_module_pref("scroll7","signetd4")==1) addnav("7?Read Scroll 7","runmodule.php?module=signetd5&op=scroll7b");
				addnav("Directions");
				if($locale=="1274"){
					output("`nYou are at the entrance with passages to the");
				}else{
					output("`nYou may go");
				}
				$umazeturn++;
				set_module_pref('mazeturn', $umazeturn);
				if ($navigate=="1" or $navigate=="5" or $navigate=="6"or $navigate=="7" or $navigate=="11" or $navigate=="12"or $navigate=="13" or $navigate=="15" or $navigate=="19"or $navigate=="20" or $navigate=="21" or $navigate=="24" or $navigate=="25" or $navigate=="27") {
					if ($locale=="948"){
						blocknav("runmodule.php?module=signetd5&op=n&loc=$locale");
					}else{
						addnav("North","runmodule.php?module=signetd5&op=n&loc=$locale");
						$directions.=" $north";
						$navcount++;
					}
				}
				if ($navigate=="2" or $navigate=="5" or $navigate=="8"or $navigate=="9" or $navigate=="11" or $navigate=="12"or $navigate=="14" or $navigate=="15" or $navigate=="18" or $navigate=="19" or $navigate=="22" or $navigate=="23" or $navigate=="24" or $navigate=="25") {
					addnav("South","runmodule.php?module=signetd5&op=s&loc=$locale");
					$navcount++;
					if ($navcount > 1) $directions.=",";
					$directions.=" $south";
				}
				if ($navigate=="4" or $navigate=="7" or $navigate=="9"or $navigate=="10" or $navigate=="12" or $navigate=="13"or $navigate=="14" or $navigate=="15" or $navigate=="17" or $navigate=="21" or $navigate=="22" or $navigate=="24" or $navigate=="25") {
					addnav("West","runmodule.php?module=signetd5&op=w&loc=$locale");
					if ($locale=="1016") {
						blocknav("runmodule.php?module=signetd5&op=w&loc=$locale");
					}else{
						$navcount++;
						if ($navcount > 1) $directions.=",";
						$directions.=" $west";						
					}
				}
				if ($navigate=="3" or $navigate=="6" or $navigate=="8"or $navigate=="10" or $navigate=="11" or $navigate=="13"or $navigate=="14" or $navigate=="15" or $navigate=="17" or $navigate=="18" or $navigate=="20" or $navigate=="25") {
					addnav("East","runmodule.php?module=signetd5&op=e&loc=$locale");
					if (get_module_pref("loc11c")==0  && $locale=="743") {
						blocknav("runmodule.php?module=signetd5&op=e&loc=$locale");
					}else{
						$navcount++;
						if ($navcount > 1) $directions.=",";
						$directions.=" $east";					
					}
				}
				output_notl($directions);				
			}else{
				addnav("Continue","shades.php");
			}
			$mazemap=$navigate;
			$mazemap.="maze.gif";
			output_notl("`n");
			rawoutput("<small>");
			output("`7You");
			rawoutput(" = <img src=\"./modules/signetimg/mcyan.gif\" title=\"\" alt=\"\" style=\"width: 5px; height: 5px;\"> ");
			output("`7Entrance");
			rawoutput(" = <img src=\"./modules/signetimg/mgreen.gif\" title=\"\" alt=\"\" style=\"width: 5px; height: 5px;\"> ");
			output("`7Emergency Exit");
			rawoutput(" = <img src=\"./modules/signetimg/mexit.gif\" title=\"\" alt=\"\" style=\"width: 5px; height: 5px;\"><big>");
			$mapkey2="<table style=\"height: 130px; width: 110px; text-align: left;\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\"><tbody><tr><td style=\"vertical-align: top;\">";
			for ($i=0;$i<1326;$i++){
				$keymap=ltrim($maze[$i]);
				$mazemap=$keymap;
				$mazemap.="maze.gif";
				if ($i==$locale-1){
					$mapkey.="<img src=\"./modules/signetimg/mcyan.gif\" title=\"\" alt=\"\" style=\"width: 10px; height: 10px;\">";
				}else{
					if ($i==1273){
						$mapkey.="<img src=\"./modules/signetimg/mgreen.gif\" title=\"\" alt=\"\" style=\"width: 10px; height: 10px;\">";
					//door Left Right
					}elseif (($i==859 && ($locale=="894" || $locale=="826"))||($i==871 && ($locale=="906" || $locale=="838"))||($i==1137 && ($locale=="1172" || $locale=="1104"))||($i==1001 && ($locale=="1036" || $locale=="1002"))||($i==735 && ($locale=="770" || $locale=="702"))||($i==723 && ($locale=="758" || $locale=="690"))){
						$mapkey.="<img src=\"./modules/signetimg/dlrdoor.gif\" title=\"\" alt=\"\" style=\"width: 10px; height: 10px;\">";
					//door Up Down
					}elseif (($i==704 && ($locale=="704" || $locale=="706"))||($i==700 && ($locale=="700" || $locale=="702"))||($i==686 && ($locale=="686" || $locale=="688"))||($i==690 && ($locale=="690" || $locale=="692"))||($i==897 && ($locale=="897" || $locale=="899"))||($i==894 && ($locale=="894" || $locale=="896"))||($i==904 && ($locale=="904" || $locale=="906"))||($i==901 && ($locale=="901" || $locale=="903"))){
						$mapkey.="<img src=\"./modules/signetimg/duddoor.gif\" title=\"\" alt=\"\" style=\"width: 10px; height: 10px;\">";
					//Wand
					}elseif ($i==1219 && $locale=="1186"){
						$mapkey.="<img src=\"./modules/signetimg/wand.gif\" title=\"\" alt=\"\" style=\"width: 10px; height: 10px;\">";
					//Dark Lord
					}elseif (($i==776 && $locale=="743" && get_module_pref("loc777")==0)||($i==773 && $locale=="775" && get_module_pref("loc774")==0)||($i==1011 && $locale=="978" && get_module_pref("loc1012")==0)||($i==1015 && $locale=="1015" && get_module_pref("loc1016")==0)){
						$mapkey.="<img src=\"./modules/signetimg/dl.gif\" title=\"\" alt=\"\" style=\"width: 10px; height: 10px;\">";
					//Dark Lord Hallway
					}elseif ((($i==848 || $i==882 || $i==916 || $i==950 || $i==984 || $i==1018 || $i==1052 || $i==1086 || $i==1120 || $i==1154 || $i==1188 || $i==1222) && get_module_pref("loc849")==1)){
						$mapkey.="<img src=\"./modules/signetimg/darkhall.gif\" title=\"\" alt=\"\" style=\"width: 10px; height: 10px;\">";
					}elseif($i==1256 && get_module_pref("loc849")==1){
						$mapkey.="<img src=\"./modules/signetimg/dl2.gif\" title=\"\" alt=\"\" style=\"width: 10px; height: 10px;\">";
					//Red Dot
					}elseif (($i==502 && get_module_pref("loc503")==0 && ($locale=="469" || $locale=="470" ||$locale=="504"))||($i==504 && get_module_pref("loc505")==0 && ($locale=="506" || $locale=="470" ||$locale=="504" ||$locale=="471" ||$locale=="472"))||($i==506 && get_module_pref("loc507")==0 && ($locale=="472" || $locale=="473" ||$locale=="506"))||($i==833 && get_module_pref("loc834")==0 && ($locale=="833" || $locale=="799" ||$locale=="800"))||($i==765 && ($locale=="799" || $locale=="800" ||$locale=="765"))){
						$mapkey.="<img src=\"./modules/signetimg/mred.gif\" title=\"\" alt=\"\" style=\"width: 10px; height: 10px;\">";
					//Red Dot on Black
					}elseif (($i==6 && $locale=="41" && get_module_pref("transport")==1)||($i==10 && $locale=="45" && get_module_pref("transport")==2)||($i==12 && $locale=="47" && get_module_pref("transport")==3)||($i==14 && $locale=="49" && get_module_pref("transport")==4)||($i==16 && $locale=="51" && get_module_pref("transport")==5)||($i==18 && $locale=="53" && get_module_pref("transport")==6)||($i==20 && $locale=="55" && get_module_pref("transport")==7)||($i==24 && $locale=="59" && get_module_pref("transport")==8)||($i==28 && $locale=="63")){
						$mapkey.="<img src=\"./modules/signetimg/mredb.gif\" title=\"\" alt=\"\" style=\"width: 10px; height: 10px;\">";
					//proximity emergency exits
					}elseif (($i==6 && $locale=="41" && get_module_pref("transport")<>1)||($i==10 && $locale=="45" && get_module_pref("transport")<>2)||($i==12 && $locale=="47" && get_module_pref("transport")<>3)||($i==14 && $locale=="49" && get_module_pref("transport")<>4)||($i==16 && $locale=="51" && get_module_pref("transport")<>5)||($i==18 && $locale=="53" && get_module_pref("transport")<>6)||($i==20 && $locale=="55" && get_module_pref("transport")<>7)||($i==24 && $locale=="59" && get_module_pref("transport")<>8)){
						$mapkey.="<img src=\"./modules/signetimg/mexit.gif\" title=\"\" alt=\"\" style=\"width: 10px; height: 10px;\">";
					//Corrected Map
					}elseif ((get_module_pref("loc421")==1 && $i==421)||(get_module_pref("loc425")==1 && $i==425)||(get_module_pref("loc347")==1 && ($i==347||$i==348||$i==349))||(get_module_pref("loc361")==1 && ($i==361||$i==362||$i==363))){
						$mapkey.="<img src=\"./modules/signetimg/16maze.gif\" title=\"\" alt=\"\" style=\"width: 10px; height: 10px;\">";
					//Finishing the map
					}else{
						$mapkey.="<img src=\"./modules/signetimg/$mazemap\" title=\"\" alt=\"\" style=\"width: 10px; height: 10px;\">";
					}
				}
				if ($i==33 or $i==67 or $i==101 or $i==135 or $i==169 or $i==203 or $i==237 or $i==271 or $i==305 or $i==339 or $i==373 or $i==407 or $i==441 or $i==475 or $i==509 or $i==543 or $i==577 or $i==611 or $i==645 or $i==679 or $i==713 or $i==747 or $i==781 or $i==815 or $i==849 or $i==883 or $i==917 or $i==951 or $i==985 or $i==1019 or $i==1053 or $i==1087 or $i==1121 or $i==1155 or $i==1189 or $i==1223 or $i==1257 or $i==1291 or $i==1325){
					$mapkey="`n".$mapkey;
					$mapkey2=$mapkey.$mapkey2;
					$mapkey="";
				}
			}
			$mapkey2.="</td></tr></tbody></table>";
			output_notl($mapkey2,true);
		}
	}
page_footer();
function signetd5_runevent($type){
	global $session;
}
?>