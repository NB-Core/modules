<?php

function signetd4_fight($op) {
	$temp=get_module_pref("pqtemp");
	page_header("Fortress Fight");
	global $session,$badguy;
	//for the doors
	if ($op=="door"){
		if ($temp==362 && get_module_pref("loc362")==0) set_module_pref("loc362",2);
		$badguy = array(
			"type"=>"",
			"creaturename"=>"`Qa Heavy Door`0",
			"creaturelevel"=>8,
			"creatureweapon"=>"sharp splinters",
			"creatureattack"=>8,
			"creaturedefense"=>10,
			"creaturehealth"=>60,
			"diddamage"=>0);
		$session['user']['badguy']=createstring($badguy);
		$op="fight";
	}
	//for the monsters
	if ($op=="ooze"){
		if ($temp==1057 && get_module_pref("loc1057")==0) set_module_pref("loc1057",2);
		if ($temp==467 && get_module_pref("loc467")==0) set_module_pref("loc467",2);
		if ($temp==29 && get_module_pref("loc29")==0) set_module_pref("loc29",2);
		if ($temp==87 && get_module_pref("loc87")==0) set_module_pref("loc87",2);
		if ($temp==90 && get_module_pref("loc90")==0) set_module_pref("loc90",2);
		if ($temp==18 && get_module_pref("loc18")==0) set_module_pref("loc18",2);		
		$targetlevel=$session['user']['level'];
		$sql = "SELECT * FROM " . db_prefix("creatures") . " WHERE creaturelevel = $targetlevel AND forest=1 ORDER BY rand(".e_rand().") LIMIT 1";
		$result = db_query($sql);
		$badguy = db_fetch_assoc($result);
		$badguy = modulehook("buffbadguy", $badguy);
		$badguy['creaturename']="Blue Ooze";
		$badguy['creatureweapon']="slime";
		$badguy['type']="";
		$session['user']['badguy']=createstring($badguy);
		$op="fight";
	}
	if ($op=="random"){
		$targetlevel=$session['user']['level'];
		$sql = "SELECT * FROM " . db_prefix("creatures") . " WHERE creaturelevel = $targetlevel AND forest=1 ORDER BY rand(".e_rand().") LIMIT 1";
		$result = db_query($sql);
		$badguy = db_fetch_assoc($result);
		$badguy = modulehook("buffbadguy", $badguy);
		$randmonster=e_rand(1,4);
		if ($randmonster==1){
			$badguy['creaturename']="Kobold";
			$badguy['creatureweapon']="a Dagger";
		}elseif ($randmonster==2){
			$badguy['creaturename']="Lizard Man";
			$badguy['creatureweapon']="a spear";
		}elseif ($randmonster==3){
			$badguy['creaturename']="Death Fly";
			$badguy['creatureweapon']="a deadly buzz";
		}elseif ($randmonster==4){
			$badguy['creaturename']="Ogre";
			$badguy['creatureweapon']="a Spiked Club";
		}
		$badguy['type']="";
		$session['user']['badguy']=createstring($badguy);
		$op="fight";
	}
	if ($op=="zombie"){
		if ($temp==513 && get_module_pref("loc513")==0) set_module_pref("loc513",2);
		if ($temp==853 && get_module_pref("loc853")==0) set_module_pref("loc853",2);	
		$targetlevel=$session['user']['level']+1;
		$sql = "SELECT * FROM " . db_prefix("creatures") . " WHERE creaturelevel = $targetlevel AND forest=1 ORDER BY rand(".e_rand().") LIMIT 1";
		$result = db_query($sql);
		$badguy = db_fetch_assoc($result);
		$badguy = modulehook("buffbadguy", $badguy);
		$badguy['creaturename']="Zombie";
		$badguy['creatureweapon']="gangrenous arms";
		$badguy['type']="";
		$session['user']['badguy']=createstring($badguy);
		$op="fight";
	}
	if ($op=="drunkendwarf"){
		if ($temp==868 && get_module_pref("loc868")==0) set_module_pref("loc868",2);
		$targetlevel=$session['user']['level']+2;
		if ($session['user']['level']==15) $targetlevel=16;
		$sql = "SELECT * FROM " . db_prefix("creatures") . " WHERE creaturelevel = $targetlevel AND forest=1 ORDER BY rand(".e_rand().") LIMIT 1";
		$result = db_query($sql);
		$badguy = db_fetch_assoc($result);
		$badguy = modulehook("buffbadguy", $badguy);
		$badguy['creaturename']="Drunken Dwarf";
		$badguy['creatureweapon']="an Empty Mead Mug";
		$badguy['type']="";
		$session['user']['badguy']=createstring($badguy);
		$op="fight";
	}
	if ($op=="guards"){
		if ($temp==485 && get_module_pref("loc485")==0) set_module_pref("loc485",2);
		if ($temp==874 && get_module_pref("loc874")==0) set_module_pref("loc874",2);
		$badguy = array(
			"type"=>"",
			"creaturename"=>"Guards",
			"creaturelevel"=>$session['user']['level'],
			"creatureweapon"=>"Long Swords",
			"creatureattack"=>($session['user']['attack']+e_rand(2,4))*.84,
			"creaturedefense"=>($session['user']['defense']+e_rand(1,2))*.8,
			"creaturehealth"=>round($session['user']['hitpoints']*.84),
			"diddamage"=>0);
		$session['user']['badguy']=createstring($badguy);
		$op="fight";
	}
	if ($op=="warrior"){
		if ($temp==689 && get_module_pref("loc689")==0) set_module_pref("loc689",2);
		if ($temp==948 && get_module_pref("loc948")==0) set_module_pref("loc948",2);
		$badguy = array(
			"type"=>"",
			"creaturename"=>"Warrior",
			"creaturelevel"=>$session['user']['level'],
			"creatureweapon"=>"a Two-handed Sword",
			"creatureattack"=>($session['user']['attack']+e_rand(2,4))*.94,
			"creaturedefense"=>($session['user']['defense']+e_rand(1,2))*.7,
			"creaturehealth"=>round($session['user']['hitpoints']*.87),
			"diddamage"=>0);
		$session['user']['badguy']=createstring($badguy);
		$op="fight";
	}
	if ($op=="troll"){
		if ($temp==655 && get_module_pref("loc655")==0) set_module_pref("loc655",2);
		if ($temp==312 && get_module_pref("loc312")==0) set_module_pref("loc312",2);
		if ($temp==561 && get_module_pref("loc561")==0) set_module_pref("loc561",2);
		$badguy = array(
			"type"=>"",
			"creaturename"=>"Troll",
			"creaturelevel"=>$session['user']['level'],
			"creatureweapon"=>"Infected Claws",
			"creatureattack"=>($session['user']['attack']+e_rand(2,4))*.8,
			"creaturedefense"=>($session['user']['defense']+e_rand(1,2))*.8,
			"creaturehealth"=>round($session['user']['hitpoints']*.8),
			"diddamage"=>0);
		$session['user']['badguy']=createstring($badguy);
		$op="fight";
	}
	if ($op=="torturer"){
		if ($temp==198 && get_module_pref("loc198")==0) set_module_pref("loc198",2);
		$badguy = array(
			"type"=>"",
			"creaturename"=>"Torturer",
			"creaturelevel"=>$session['user']['level'],
			"creatureweapon"=>"Whips and Chains",
			"creatureattack"=>($session['user']['attack']+e_rand(2,4))*.94,
			"creaturedefense"=>($session['user']['defense']+e_rand(1,2))*.8,
			"creaturehealth"=>round($session['user']['hitpoints']*.86),
			"diddamage"=>0);
		$session['user']['badguy']=createstring($badguy);
		$op="fight";
	}
	if ($op=="barbarian"){
		if ($temp==386 && get_module_pref("loc386")==0) set_module_pref("loc386",2);
		$badguy = array(
			"type"=>"",
			"creaturename"=>"Barbarian",
			"creaturelevel"=>$session['user']['level'],
			"creatureweapon"=>"a Wooden Club",
			"creatureattack"=>($session['user']['attack']+e_rand(2,4))*.8,
			"creaturedefense"=>($session['user']['defense']+e_rand(1,2)),
			"creaturehealth"=>round($session['user']['hitpoints']*.8),
			"diddamage"=>0);
		$session['user']['badguy']=createstring($badguy);
		$op="fight";
	}
	if ($op=="hornets"){
		if ($temp==459 && get_module_pref("loc459")==0) set_module_pref("loc459",2);
		$badguy = array(
			"type"=>"",
			"creaturename"=>"A Swarm of Hornets",
			"creaturelevel"=>$session['user']['level'],
			"creatureweapon"=>"Poisoned Stingers",
			"creatureattack"=>($session['user']['attack']+e_rand(2,4)*1.1),
			"creaturedefense"=>($session['user']['defense']+e_rand(1,2)*.7),
			"creaturehealth"=>round($session['user']['hitpoints']*.6),
			"diddamage"=>0);
		$session['user']['badguy']=createstring($badguy);
		$op="fight";
	}
	if ($op=="fiamma"){
		if ($temp==182 && get_module_pref("loc182")==0) set_module_pref("loc182",2);
		if ($session['user']['maxhitpoints']>$session['user']['hitpoints']) $hitpoints=$session['user']['maxhitpoints'];
		else $hitpoints=$session['user']['hitpoints'];
		$badguy = array(
			"type"=>"",
			"creaturename"=>"`QF`\$iamma",
			"creaturelevel"=>$session['user']['level']+1,
			"creatureweapon"=>"`qa Huge Mace",
			"creatureattack"=>($session['user']['defense']+e_rand(-1,2)),
			"creaturedefense"=>($session['user']['attack']+e_rand(-1,2)),
			"creaturehealth"=>round($hitpoints*1.1),
			"diddamage"=>0);
		$session['user']['badguy']=createstring($badguy);
		$op="fight";
	}
	if ($op=="fight"){
		global $badguy;
		$battle=true;
		$fight=true;
		if ($battle){
			require_once("battle.php");
	    if ($victory){
       			addnav("Continue","runmodule.php?module=signetd4&loc=".get_module_pref('pqtemp'));
				//opening doors
				if ($temp==362 && get_module_pref("loc362")==2) {
					output("`^`n`bYou have opened the door safely.`b`n");
					$experience=$session['user']['level']*e_rand(6,9);
					output("`#You receive `6%s `#experience.`n",$experience);
					$session['user']['experience']+=$experience;
					if (get_module_pref("loc362")==2) set_module_pref("loc362",1);
				//special monsters
				}elseif($temp==182 && get_module_pref("loc182")==2){
					set_module_pref("loc182",1);
					output("`n`n`0You hit `QF`\$iamma`0 and his `QHuge Mace`0 flies against the west wall.  You've disarmed him!");
					output("`n`n`b`&You prepare the fatal blow against `QF`\$iamma`&, but with a dieing hand the coward begs for mercy!!`b`n");
					addnav("Continue","runmodule.php?module=signetd4&op=182b");
					blocknav("runmodule.php?module=signetd4&loc=".get_module_pref('pqtemp'));
				//Custom monsters
				}elseif (($temp==485 && get_module_pref("loc485")==2) || ($temp==386 && get_module_pref("loc386")==2) ||($temp==459 && get_module_pref("loc459")==2)||($temp==198 && get_module_pref("loc198")==2)||($temp==312 && get_module_pref("loc312")==2)||($temp==689 && get_module_pref("loc689")==2)||($temp==655 && get_module_pref("loc655")==2)||($temp==874 && get_module_pref("loc874")==2)||($temp==948 && get_module_pref("loc948")==2)||($temp==561 && get_module_pref("loc561")==2)){
					output("`b`4You have slain `^%s`4.`b`n",$badguy['creaturename']);
					$gold=e_rand(80,200);
					$session['user']['gold']+=$gold;
					$expmultiply = e_rand(10,20);
					$expbonus=$session['user']['dragonkills']*1.5;
					$expgain =round($session['user']['level']*$expmultiply+$expbonus);
					$session['user']['experience']+=$expgain;
					output("`n`@You search through the smelly corpse and find `^%s gold`@.`n",$gold);
					output("`n`#You have gained `7%s `#experience.`n",$expgain);
					if (get_module_pref("loc312")==2) set_module_pref("loc312",1);
					if (get_module_pref("loc485")==2) set_module_pref("loc485",1);
					if (get_module_pref("loc386")==2) set_module_pref("loc386",1);
					if (get_module_pref("loc459")==2) set_module_pref("loc459",1);
					if (get_module_pref("loc198")==2) set_module_pref("loc198",1);
					if (get_module_pref("loc689")==2) set_module_pref("loc689",1);
					if (get_module_pref("loc655")==2) set_module_pref("loc655",1);
					if (get_module_pref("loc874")==2) set_module_pref("loc874",1);
					if (get_module_pref("loc948")==2) set_module_pref("loc948",1);
					if (get_module_pref("loc561")==2) set_module_pref("loc561",1);
				//Forest Based Coded monsters
				}elseif (($temp==1057 && get_module_pref("loc1057")==2)||  ($temp==467 && get_module_pref("loc467")==2) || ($temp==90 && get_module_pref("loc90")==2) || ($temp==18 && get_module_pref("loc18")==2)||($temp==29 && get_module_pref("loc29")==2)|| ($temp==87 && get_module_pref("loc87")==2)||($temp==513 && get_module_pref("loc513")==2)|| ($temp==853 && get_module_pref("loc853")==2)||($temp==868 && get_module_pref("loc868")==2)){
					output("`b`4You have slain `^%s`4.`b`n",$badguy['creaturename']);
					$gold=e_rand(10,20)*$session['user']['level'];
					$session['user']['gold']+=$gold;
					$expmultiply = e_rand(5,15);
					$expbonus=$session['user']['dragonkills'];
					$expgain =round($session['user']['level']*$expmultiply+$expbonus);
					$session['user']['experience']+=$expgain;
					output("`n`@You search through the smelly corpse and find `^%s gold`@.`n",$gold);
					output("`n`#You have gained `7%s `#experience.`n",$expgain);
					if (get_module_pref("loc1057")==2) set_module_pref("loc1057",1);
					if (get_module_pref("loc467")==2) set_module_pref("loc467",1);
					if (get_module_pref("loc18")==2) set_module_pref("loc18",1);
					if (get_module_pref("loc29")==2) set_module_pref("loc29",1);
					if (get_module_pref("loc87")==2) set_module_pref("loc87",1);
					if (get_module_pref("loc90")==2) set_module_pref("loc90",1);
					if (get_module_pref("loc513")==2) set_module_pref("loc513",1);
					if (get_module_pref("loc853")==2) set_module_pref("loc853",1);
					if (get_module_pref("loc868")==2) set_module_pref("loc868",1);
				//next lines are for random encounters
				}else{
					output("`b`4You have slain `^%s`4.`b`n",$badguy['creaturename']);
					$gold=e_rand(50,150);
					$session['user']['gold']+=$gold;
					$expmultiply = e_rand(10,20);
					$expbonus=$session['user']['dragonkills']*1.5;
					$expgain =round($session['user']['level']*$expmultiply+$expbonus);
					$session['user']['experience']+=$expgain;
					output("`n`@You search through the smelly corpse and find `^%s gold`@.`n",$gold);
					output("`n`#You have gained `7%s `#experience.`n",$expgain);				
				}
				if ((get_module_setting("healing")==1) && ($session['user']['hitpoints']<$session['user']['maxhitpoints']*.6)){
					$hpdown=$session['user']['maxhitpoints']-$session['user']['hitpoints'];
					switch(e_rand(1,15)){
						case 1:
							if ($hpdown>200) $hpdown=200;
							output("`n`@You find a healing potion and take a deep drink.  You feel your strength return.");
							output("`n`nYou gain `b%s hitpoints`b!",$hpdown);
							$session['user']['hitpoints']+=$hpdown;
						break;
						case 2: case 3:
							output("`n`@You notice the remnants of a healing potion.  You have a chance to take a drink!");
							$hpheal=round(e_rand($hpdown*.3,$hpdown*.7));
							if ($hpheal<=1) $hpheal=2;
							if ($hpheal>120) $hpheal=120;
							output("`n`nYou gain `b%s hitpoints`b!",$hpheal);
							$session['user']['hitpoints']+=$hpheal;
						break;
						case 4: case 5: case 6:
							output("`n`@You notice the remnants of a small healing potion.  You have a chance to take a quick drink!");;
							$hpheal=round(e_rand($hpdown*.1,$hpdown*.4));
							if ($hpheal<=1) $hpheal=2;
							if ($hpheal>50) $hpheal=50;
							output("`n`nYou gain `b%s hitpoints`b!",$hpheal);
							$session['user']['hitpoints']+=$hpheal;
						break;
						case 7:
							$hpleft=$session['user']['hitpoints'];
							$hphurt=round(e_rand($hpleft*.1,$hpleft*.4));
							if ($hphurt>50) $hphurt=50;
							if ($hphurt>1  && $hpleft>5){
								output("`n`@You find a healing potion and drink it down.  `\$Oh no! It was poisoned!");
								output("`n`n`@You lose `b`\$%s hitpoints`b`@!",$hphurt);
								$session['user']['hitpoints']-=$hphurt;
							}
						break;
						case 8: case 9: case 10: case 11: case 12: case 13: case 14: case 15:
						break;
					}
				}
				$badguy=array();
				$session['user']['badguy']="";
			}elseif ($defeat){
				if ($temp==362 && get_module_pref("loc362")==2){
					if (get_module_pref("loc362")==2) set_module_pref("loc362",0);
					output("A splinter severs a major blood vessel and you die.`n");
					addnews("`% %s`5 has been slain trying to break down a door.",$session['user']['name']);
				}
				elseif (($temp==1057 && get_module_pref("loc1057")==2) || ($temp==182 && get_module_pref("loc182")==2)||($temp==485 && get_module_pref("loc485")==2)||($temp==386 && get_module_pref("loc386")==2)||($temp==459 && get_module_pref("loc459")==2)||($temp==467 && get_module_pref("loc467")==2)||($temp==90 && get_module_pref("loc90")==2)||($temp==18 && get_module_pref("loc18")==2)||($temp==29 && get_module_pref("loc29")==2)||($temp==87 && get_module_pref("loc87")==2)||($temp==198 && get_module_pref("loc198")==2)||($temp==513 && get_module_pref("loc513")==2)||($temp==853 && get_module_pref("loc853")==2)||($temp==689 && get_module_pref("loc689")==2)||($temp==655 && get_module_pref("loc655")==2)||($temp==312 && get_module_pref("loc312")==2)||($temp==868 && get_module_pref("loc868")==2)||($temp==874 && get_module_pref("loc874")==2)||($temp==948 && get_module_pref("loc948")==2)||($temp==561 && get_module_pref("loc561")==2)){
					if (get_module_pref("loc1057")==2) set_module_pref("loc1057",0);
					if (get_module_pref("loc182")==2) set_module_pref("loc182",0);
					if (get_module_pref("loc485")==2) set_module_pref("loc485",0);
					if (get_module_pref("loc386")==2) set_module_pref("loc386",0);
					if (get_module_pref("loc459")==2) set_module_pref("loc459",0);
					if (get_module_pref("loc467")==2) set_module_pref("loc467",0);
					if (get_module_pref("loc18")==2) set_module_pref("loc18",0);
					if (get_module_pref("loc29")==2) set_module_pref("loc29",0);
					if (get_module_pref("loc87")==2) set_module_pref("loc87",0);
					if (get_module_pref("loc90")==2) set_module_pref("loc90",0);
					if (get_module_pref("loc198")==2) set_module_pref("loc198",0);
					if (get_module_pref("loc513")==2) set_module_pref("loc513",0);
					if (get_module_pref("loc853")==2) set_module_pref("loc853",0);
					if (get_module_pref("loc655")==2) set_module_pref("loc655",0);
					if (get_module_pref("loc689")==2) set_module_pref("loc689",0);
					if (get_module_pref("loc312")==2) set_module_pref("loc312",0);
					if (get_module_pref("loc868")==2) set_module_pref("loc868",0);
					if (get_module_pref("loc874")==2) set_module_pref("loc874",0);
					if (get_module_pref("loc948")==2) set_module_pref("loc948",0);
					if (get_module_pref("loc561")==2) set_module_pref("loc561",0);
					output("`nAs you hit the ground the `^%s runs away.",$badguy['creaturename']);
					addnews("`%%s`5 has been slain by an evil %s in a dungeon.",$session['user']['name'],$badguy['creaturename']);
				//Next lines are for random encounters
				}else{
					output("`nAs you hit the ground the `^%s runs away.",$badguy['creaturename']);
					addnews("`%%s`5 has been slain by an evil %s in a dungeon.",$session['user']['name'],$badguy['creaturename']);
				}
		        $badguy=array();
		        $session['user']['badguy']="";  
		        $session['user']['hitpoints']=0;
		        $session['user']['alive']=false;
		        addnav("Continue","shades.php");
			}else{
					require_once("lib/fightnav.php");
					fightnav(true,false,"runmodule.php?module=signetd4");
			}
		}else{
			redirect("runmodule.php?module=signetd4&loc=".get_module_pref('pqtemp'));	
		}
	}
	page_footer();
}
function signetd4_misc($op) {
	$temp=get_module_pref("pqtemp");
	page_header("Fiamma's Fortress");
	global $session;
	if ($op=="exits1"){
		output("You have found an `\$Emergency Exit`0.");
		output("You have the option of leaving from this location at this time.");
		if (get_module_setting("exitsave")==1){
			output("`n`nIf you leave now, you may return to the dungeon at this location or enter at the main entrance.");
			addnav("`\$Take Exit`0");
			addnav("Main Entrance","runmodule.php?module=signetd4&op=exits2");
			addnav("This Location","runmodule.php?module=signetd4&op=exits3");
			addnav("Continue");
		}else{
			output("`n`nIf you leave now, you will re-enter the dungeon from this location.");
			addnav("`\$Take Exit","runmodule.php?module=signetd4&op=exits3");
		}
		addnav("Return to the Dungeon","runmodule.php?module=signetd4&loc=".get_module_pref('pqtemp'));
	}
	if ($op=="exits2"){
		output("You will re-enter the dungeon from the main exit.");
		set_module_pref("startloc",1279);
		villagenav();
	}
	if ($op=="exits3"){
		output("You will re-enter the dungeon at this location.");
		set_module_pref("startloc",get_module_pref("pqtemp"));
		villagenav();
	}
	if ($op=="reset"){
		clear_module_pref("maze","signetd3");
		clear_module_pref("mazeturn","signetd3");
		clear_module_pref("pqtemp","signetd3");
		clear_module_pref("randomp","signetd3");
		clear_module_pref("super","signetd3");
		clear_module_pref("header","signetd3");
		clear_module_pref("loc159","signetd3");
		clear_module_pref("loc839","signetd3");
		clear_module_pref("locprisonkey","signetd3");
		clear_module_pref("loc11","signetd3");
		clear_module_pref("loc11b","signetd3");
		clear_module_pref("loc11c","signetd3");
		clear_module_pref("loc29","signetd3");
		clear_module_pref("loc48","signetd3");
		clear_module_pref("loc53","signetd3");
		clear_module_pref("loc65","signetd3");
		clear_module_pref("loc66","signetd3");
		clear_module_pref("loc82","signetd3");
		clear_module_pref("loc87","signetd3");
		clear_module_pref("loc94","signetd3");
		clear_module_pref("loc148","signetd3");
		clear_module_pref("loc157","signetd3");
		clear_module_pref("loc164","signetd3");
		clear_module_pref("loc221","signetd3");
		clear_module_pref("loc331","signetd3");
		clear_module_pref("loc352","signetd3");
		clear_module_pref("loc354","signetd3");
		clear_module_pref("loc358","signetd3");
		clear_module_pref("loc401","signetd3");
		clear_module_pref("loc483","signetd3");
		clear_module_pref("loc499","signetd3");
		clear_module_pref("loc537","signetd3");
		clear_module_pref("loc561","signetd3");
		clear_module_pref("loc619","signetd3");
		clear_module_pref("loc625","signetd3");
		clear_module_pref("loc635","signetd3");
		clear_module_pref("loc745","signetd3");
		clear_module_pref("loc746","signetd3");
		clear_module_pref("loc931","signetd3");
		clear_module_pref("loc939","signetd3");
		clear_module_pref("loc1071","signetd3");
		clear_module_pref("loc1079","signetd3");
		clear_module_pref("loc1097","signetd3");
		clear_module_pref("loc1206","signetd3");
		set_module_pref("reset",1,"signetd3");
		if (get_module_pref("powersignet","signetd5")==1) redirect("runmodule.php?module=signetd5&op=eg1b");
		else redirect("runmodule.php?module=signetd4&loc=".get_module_pref('pqtemp'));
	}
	if ($op=="1177"){
		$loc1177count=get_module_pref("loc1177count");
		if ($loc1177count==2) output("You hold your breath and jump on the square.  This will work, won't it?`n`n");
		if ($loc1177count==0 || $loc1177count==1 || $loc1177count==2) output("A strange gas fills the air.  You faint.");
		if ($loc1177count==1) output("Before you pass out, you slap yourself on the forehead and realize you shouldn't have stepped into that spot again. Oh well.");
		if ($loc1177count==2) output("Nope. I guess not.");
		if ($loc1177count==3) output("This is getting a bit annoying.  You close your eyes, take a step forward, and hold your breath.  You feel a thump on your head and fall unconscious.");
		if ($loc1177count==4) output("You draw your weapon, cover your mouth with a sock so you don't breath in the poisonous gas, and pass out from the smell of your sock.");
		if ($loc1177count==5) output("You take a CLEAN sock out and cover your mouth.  You draw your weapon.  You step forward.  You trip on a rubber ducky and hit your head.");
		if ($loc1177count==6) output("You put a straw mannequin of yourself on the the poison gas plate and snicker.  Nothing happens.  You fall asleep waiting.");
		if ($loc1177count==7) output("Determined not to fall for this stupid trap, you start yelling `#'I will not fall for this stupid trap!!' `0 You hear a voice say `\$'Yes you will!'`0  You turn to see a frying pan hit you in the nose.");
		if ($loc1177count==8) output("You throw a duck at the square.  The duck quacks and walks forward.  You follow the duck and a strange gas fills the air.  You faint.");
		if ($loc1177count==9) output("You take out a can of paint and draw an entrance NEXT to the poison gas square.  You try to walk through the entrance that you just painted and hit your head and fall unconscious.");
		if ($loc1177count==10) output("Do you really think I'm going to sit here making up ways for you to get gassed?  Just face it, you're going to get gassed and sent to the cell.");
		if ($loc1177count==11) output("Fine, I'll make up some more. You spend time reading this text and notice the gas is filling in the air.  You faint.");
		if ($loc1177count==12) output("This time you figure out the trick.  You decide not to step on this square.  Oh wait, you.... zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz");
		if ($loc1177count==13) output("You really aren't too bright, are you?  I mean, seriously.  Not bright at all.  You see the gas seeping up.");
		if ($loc1177count==14) output("You're not here to explore, are you? You're addicted to the poison gas!");
		if ($loc1177count==15) output("This time you come prepared and gas yourself before they get a chance to gas you! HA!");
		if ($loc1177count>15) output("You walk up and close your eyes.  A feeling of resignation sweeps through you.");
		output("`n`nYou wake up in a locked cell.");
		increment_module_pref("loc1177count",1);
		set_module_pref("pqtemp",1097);
		addnav("Continue","runmodule.php?module=signetd4&loc=".get_module_pref('pqtemp'));
	}
	if ($op=="1099"){
		output("The door is locked and you are unable to break it down or pick it.");
		addnav("Continue","runmodule.php?module=signetd4&loc=".(get_module_pref('pqtemp')-1));
	}
	if ($op=="1059"){
		output("There is a key hanging on the wall here.  Take it?");
		addnav("Take Key","runmodule.php?module=signetd4&op=1059b");
		addnav("Leave","runmodule.php?module=signetd4&op=1059c");
	}
	if ($op=="1059b"){
		output("You grab the key and take it with you.  But what is it for?");
		set_module_pref("loc1059",1);
		addnav("Continue","runmodule.php?module=signetd4&loc=".get_module_pref('pqtemp'));
	}
	if ($op=="1059c"){
		output("Now why wouldn't you take the key?  You know you're going to need it somewhere in this fortress.");
		output("`n`nAre you SURE you don't want to take the key?");	
		addnav("Take Key","runmodule.php?module=signetd4&op=1059b");
		addnav("Leave","runmodule.php?module=signetd4&loc=".(get_module_pref('pqtemp')-1));
	}
	if ($op=="377"){	
		output("You find a trap.  Would you like to disarm it?");
		addnav("Disarm","runmodule.php?module=signetd4&op=377b");
		if (get_module_pref("loc343")==1) addnav("Leave","runmodule.php?module=signetd4&loc=".(get_module_pref('pqtemp')-34));
		else addnav("Leave","runmodule.php?module=signetd4&loc=".(get_module_pref('pqtemp')+34));
	}
	if ($op=="377b"){	
		output("You approach the trap and attempt to disarm it.`n`n");
		//Higher level characters will be more successful; thieves are more successful
		if($session['user']['level']>12) $trap=3;
		elseif($session['user']['level']>8) $trap=5;
		elseif($session['user']['level']>4) $trap=7;
		else $trap=9;
		if (get_module_pref("skill","specialtythiefskills")>0) $trap--;
		switch(e_rand(1,$trap)){
			case 1:
			case 2:
				set_module_pref("loc377",1);
				output("You cautiously disarm the trap... Successfully!!`n`n");
				$chance = e_rand(1,3);
				//I wanted to reward people for coming here with at least one turn left
				if ($session['user']['turns']==0 && $chance==1){
					output("You're a little too cautious about disarming the trap and you `@lose a turn`0.");
					$session['user']['turns']--;
				}elseif ($session['user']['turns']>0 && $chance==1){
					output("You get an adrenaline rush for disarming the trap! Nice job!");
					apply_buff('adrenaline',array(
						"name"=>"`QAdrenaline Rush",
						"rounds"=>8,
						"wearoff"=>"`^The adrenaline rush ends.",
						"atkmod"=>1.1,
						"roundmsg"=>"`#Adrenaline rushes through your veins!",
					));
				}
				addnav("Continue","runmodule.php?module=signetd4&loc=".get_module_pref('pqtemp'));
			break;
			case 3:
			case 4:
			case 5:
				output("Oh no! You've failed to disarm the trap!`n`n`@");
				switch(e_rand(1,5)){
				case 1:
				case 2:
				case 3:
				case 4:
					$hitpoints=round($session['user']['hitpoints']*.05);
					if ($hitpoints>0) output("A large poison dart shoots out and hits you in the shoulder. You `\$lose %s hitpoint%s`0.`n`n",$hitpoints,translate_inline($hitpoints>1?"s":""));
					$session['user']['hitpoints']-=$hitpoints;
				break;
				case 5:
					output("You feel a poison course through your body.");
					$hitpoints=round($session['user']['hitpoints']*.1);
					$session['user']['hitpoints']-=$hitpoints;
					if ($session['user']['turns']>0){
						$session['user']['turns']--;
						output("You lose one turn.");
					}
					if ($hitpoints>0) output("You `\$lose %s hitpoint%s`0.`n`n",$hitpoints,translate_inline($hitpoints>1?"s":""));
				break;
				}
				if (get_module_pref("loc343")==1) addnav("Leave","runmodule.php?module=signetd4&loc=".(get_module_pref('pqtemp')-34));
				else addnav("Leave","runmodule.php?module=signetd4&loc=".(get_module_pref('pqtemp')+34));
			break;
			case 6:
			case 7:
			case 8:
			case 9:
				output("Oh no! You've failed to disarm the trap!`n`n`@");
				if ($session['user']['gold']>100){
					$session['user']['gold']-=100;
					output("A blade sweeps out and almost kills you! Luckily, it only cuts open your gold sack and you `^lose 100 gold`@.");
				}elseif ($session['user']['gold']>0){
					$session['user']['gold']=0;
					output("A blade sweeps out and almost kills you! Luckily, it only cuts open your gold sack and you `^lose all of your gold`@.");
				}else{
					if ($session['user']['turns']>0){
						output("The trap triggers and you get knocked back by a huge gust of wind.");
						output("`n`n`@You `blose one turn`b.");
						$session['user']['turns']--;
					}
				}
				if (get_module_pref("loc343")==1) addnav("Leave","runmodule.php?module=signetd4&loc=".(get_module_pref('pqtemp')-34));
				else addnav("Leave","runmodule.php?module=signetd4&loc=".(get_module_pref('pqtemp')+34));
			break;
		}
	}
	if ($op=="717"){	
		output("You find a trap.  Would you like to disarm it?");
		addnav("Disarm","runmodule.php?module=signetd4&op=717b");
		if (get_module_pref("loc683")==1) addnav("Leave","runmodule.php?module=signetd4&loc=".(get_module_pref('pqtemp')-34));
		else addnav("Leave","runmodule.php?module=signetd4&loc=".(get_module_pref('pqtemp')+34));
	}
	if ($op=="717b"){
		output("You look closely at the trap and notice a small sign.");
		output("`c`b`n`#Pay `^200 gold`# to avoid this trap`b`c`n");
		output("`0What would you like to do?");
		addnav("Attempt to Disarm the Trap","runmodule.php?module=signetd4&op=717d");
		//Let's reward players for carrying some gold with them into the dungeon by making this easier on them
		addnav("Pay `^200 Gold","runmodule.php?module=signetd4&op=717c");
		if (get_module_pref("loc683")==1) addnav("Leave","runmodule.php?module=signetd4&loc=".(get_module_pref('pqtemp')-34));
		else addnav("Leave","runmodule.php?module=signetd4&loc=".(get_module_pref('pqtemp')+34));	
	}
	if ($op=="717c"){
		if ($session['user']['gold']>=200){
			output("You put `^200 gold`0 into the tiny slot and hear some strange whirling noises.`n.`n.`n.`n.`n");
			output("The trap is disarmed!");
			set_module_pref("loc717",1);
			addnav("Continue","runmodule.php?module=signetd4&loc=".get_module_pref('pqtemp'));
			$session['user']['gold']-=200;
		}else{
			output("You try to jam some round pieces of tin into the coin slot.  Somehow, the trap figures out your rouse.");
			output("`n`nThe coins get thrown out at you at great force!");
			$hitpoints=round($session['user']['hitpoints']*.1);
			$session['user']['hitpoints']-=$hitpoints;
			if ($session['user']['turns']>0){
				$session['user']['turns']--;
				output("You lose one turn.");
			}
			if ($hitpoints>0) output("You `\$lose %s hitpoint%s`0.`n`n",$hitpoints,translate_inline($hitpoints>1?"s":""));
			output("`n`n`@You obviously can't disarm the trap by trying to cheat it.");
			if (get_module_pref("loc683")==1) addnav("Leave","runmodule.php?module=signetd4&loc=".(get_module_pref('pqtemp')-34));
			else addnav("Leave","runmodule.php?module=signetd4&loc=".(get_module_pref('pqtemp')+34));			
		}
		
	}
	if ($op=="717d"){
		output("You approach the trap and attempt to disarm it.`n`n");
		//Higher level characters will be more successful; thieves are more successful
		if($session['user']['level']>12) $trap=3;
		elseif($session['user']['level']>8) $trap=5;
		elseif($session['user']['level']>4) $trap=7;
		else $trap=9;
		if (get_module_pref("skill","specialtythiefskills")>0) $trap--;
		switch(e_rand(1,$trap)){
			case 1:
			case 2:
				set_module_pref("loc717",1);
				output("You cautiously disarm the trap... Successfully!!`n`n");
				addnav("Continue","runmodule.php?module=signetd4&loc=".get_module_pref('pqtemp'));
			break;
			case 3:
			case 4:
			case 5:
				output("Oh no! You've failed to disarm the trap!`n`n`@");
				switch(e_rand(1,5)){
				case 1:
				case 2:
				case 3:
				case 4:
					$hitpoints=round($session['user']['hitpoints']*.05);
					if ($hitpoints>0) output("A large poison dart shoots out and hits you in the shoulder. You `\$lose %s hitpoint%s`0.`n`n",$hitpoints,translate_inline($hitpoints>1?"s":""));
					$session['user']['hitpoints']-=$hitpoints;
				break;
				case 5:
					output("You feel a poison course through your body.");
					$hitpoints=round($session['user']['hitpoints']*.1);
					$session['user']['hitpoints']-=$hitpoints;
					if ($session['user']['turns']>0){
						$session['user']['turns']--;
						output("You lose one turn.");
					}
					if ($hitpoints>0) output("You `\$lose %s hitpoint%s`0.`n`n",$hitpoints,translate_inline($hitpoints>1?"s":""));
				break;
				}
				if (get_module_pref("loc683")==1) addnav("Leave","runmodule.php?module=signetd4&loc=".(get_module_pref('pqtemp')-34));
				else addnav("Leave","runmodule.php?module=signetd4&loc=".(get_module_pref('pqtemp')+34));
			break;
			case 6:
			case 7:
			case 8:
			case 9:
				output("Oh no! You've failed to disarm the trap!`n`n`@");
				if ($session['user']['gold']>100){
					$session['user']['gold']-=100;
					output("A blade sweeps out and almost kills you! Luckily, it only cuts open your gold sack and you `^lose 100 gold`@.");
				}elseif ($session['user']['gold']>0){
					$session['user']['gold']=0;
					output("A blade sweeps out and almost kills you! Luckily, it only cuts open your gold sack and you `^lose all of your gold`@.");
				}else{
					if ($session['user']['turns']>0){
						output("The trap triggers and you get knocked back by a huge gust of wind.");
						output("`n`n`@You `blose one turn`b.");
						$session['user']['turns']--;
					}
				}
				if (get_module_pref("loc683")==1) addnav("Leave","runmodule.php?module=signetd4&loc=".(get_module_pref('pqtemp')-34));
				else addnav("Leave","runmodule.php?module=signetd4&loc=".(get_module_pref('pqtemp')+34));
			break;
		}
	}
	if ($op=="178"){	
		output("You find a trap.  Would you like to disarm it?");
		addnav("Disarm","runmodule.php?module=signetd4&op=178b");
		if (get_module_pref("loc177")==1) addnav("Leave","runmodule.php?module=signetd4&loc=".(get_module_pref('pqtemp')-1));
		else addnav("Leave","runmodule.php?module=signetd4&loc=".(get_module_pref('pqtemp')+1));
	}
	if ($op=="178b"){
		output("You approach the trap and attempt to disarm it.`n`n");
		//Higher level characters will be more successful; thieves are more successful
		if($session['user']['level']>12) $trap=3;
		elseif($session['user']['level']>8) $trap=5;
		elseif($session['user']['level']>4) $trap=7;
		else $trap=9;
		if (get_module_pref("skill","specialtythiefskills")>0) $trap--;
		switch(e_rand(1,$trap)){
			case 1:
			case 2:
				set_module_pref("loc178",1);
				output("You cautiously disarm the trap... Successfully!!`n`n");
				$chance = e_rand(1,3);
				//I wanted to reward people for coming here with at least one turn left
				if ($session['user']['turns']>0 && $chance==1){
					output("You get an adrenaline rush for disarming the trap. You gain an extra turn!");
					$session['user']['turns']++;
				}
				addnav("Continue","runmodule.php?module=signetd4&loc=".get_module_pref('pqtemp'));
			break;
			case 3:
			case 4:
			case 5:
				output("Oh no! You've failed to disarm the trap!`n`n`@");
				switch(e_rand(1,5)){
				case 1:
				case 2:
				case 3:
				case 4:
					$hitpoints=round($session['user']['hitpoints']*.05);
					if ($hitpoints>0) output("A large poison dart shoots out and hits you in the shoulder. You `\$lose %s hitpoint%s`0.`n`n",$hitpoints,translate_inline($hitpoints>1?"s":""));
					$session['user']['hitpoints']-=$hitpoints;
				break;
				case 5:
					output("You feel a poison course through your body.");
					$hitpoints=round($session['user']['hitpoints']*.1);
					$session['user']['hitpoints']-=$hitpoints;
					if ($session['user']['turns']>0){
						$session['user']['turns']--;
						output("You lose one turn.");
					}
					if ($hitpoints>0) output("You `\$lose %s hitpoint%s`0.`n`n",$hitpoints,translate_inline($hitpoints>1?"s":""));
				break;
				}
				if (get_module_pref("loc177")==1) addnav("Leave","runmodule.php?module=signetd4&loc=".(get_module_pref('pqtemp')-1));
				else addnav("Leave","runmodule.php?module=signetd4&loc=".(get_module_pref('pqtemp')+1));
			break;
			case 6:
			case 7:
			case 8:
			case 9:
				output("Oh no! You've failed to disarm the trap!`n`n`@");
				if ($session['user']['gold']>100){
					$session['user']['gold']-=100;
					output("A blade sweeps out and almost kills you! Luckily, it only cuts open your gold sack and you `^lose 100 gold`@.");
				}elseif ($session['user']['gold']>0){
					output("A blade sweeps out and almost kills you! Luckily, it only cuts open your gold sack and you `^lose all of your gold`@.");
					$session['user']['gold']=0;
				}else{
					if ($session['user']['turns']>0){
						output("The trap triggers and you get knocked back by a huge gust of wind.");
						output("`n`n`@You `blose one turn`b.");
						$session['user']['turns']--;
					}
				}
				if (get_module_pref("loc177")==1) addnav("Leave","runmodule.php?module=signetd4&loc=".(get_module_pref('pqtemp')-1));
				else addnav("Leave","runmodule.php?module=signetd4&loc=".(get_module_pref('pqtemp')+1));
			break;
		}
	}
	if ($op=="138"){
		output("There are 3 levers here.`n`n");
		//lever 1 is for the initial prison cell
		if (get_module_pref("loc1099")==1) output("The `@first lever`0 has already been pulled.`n");
		else addnav("Pull `@Lever 1","runmodule.php?module=signetd4&op=138b");
		//lever 2 is for the arena exit
		if (get_module_pref("loc726")==1) output("The `^second lever`0 has already been pulled.`n");
		else addnav("Pull `^Lever 2","runmodule.php?module=signetd4&op=138c");
		//lever 3 is for Fiamma's Closet
		if (get_module_pref("loc83")==1) output("The `\$third lever`0 has already been pulled.`n");
		else addnav("Pull `\$Lever 3","runmodule.php?module=signetd4&op=138d");
		addnav("Leave","runmodule.php?module=signetd4&loc=".(get_module_pref('pqtemp')+34));
		if (get_module_pref("loc1099")==1 && get_module_pref("loc726")==1 && get_module_pref("loc83")==1) set_module_pref("loc138",1);
	}
	if ($op=="138b"){
		$loc726=get_module_pref("loc726");
		$loc83=get_module_pref("loc83");
		$total=$loc726+$loc83;
		output("You pull the `@first lever`0 and hear a noise in the distance.");
		if ($total==1) output("`n`nThe ceiling starts to shake and rocks fall and almost hit you!");
		if ($total==2) output("`n`nThe ceiling collapses and destroys the levers!  You're lucky to escape unharmed.");
		set_module_pref("loc1099",1);
		if (get_module_pref("loc726")==0 || get_module_pref("loc83")==0) addnav("Pull another lever","runmodule.php?module=signetd4&op=138");
		if (get_module_pref("loc726")==1 && get_module_pref("loc83")==1){
			set_module_pref("loc138",1);
			addnav("Continue","runmodule.php?module=signetd4&loc=".get_module_pref('pqtemp'));
		}else{
			addnav("Leave","runmodule.php?module=signetd4&loc=".(get_module_pref('pqtemp')+34));
		}
	}
	if ($op=="138c"){
		$loc1099=get_module_pref("loc1099");
		$loc83=get_module_pref("loc83");
		$total=$loc1099+$loc83;
		output("You pull the `^second lever`0 and hear a noise in the distance.");
		if ($total==1) output("`n`nThe ceiling starts to shake and rocks fall and almost hit you!");
		if ($total==2) output("`n`nThe ceiling collapses and destroys the levers!  You're lucky to escape unharmed.");
		set_module_pref("loc726",1);
		if (get_module_pref("loc1099")==0 || get_module_pref("loc83")==0) addnav("Pull another lever","runmodule.php?module=signetd4&op=138");
		if (get_module_pref("loc1099")==1 && get_module_pref("loc83")==1){
			set_module_pref("loc138",1);
			addnav("Continue","runmodule.php?module=signetd4&loc=".get_module_pref('pqtemp'));
		}else{
			addnav("Leave","runmodule.php?module=signetd4&loc=".(get_module_pref('pqtemp')+34));
		}
	}
	if ($op=="138d"){
		$loc1099=get_module_pref("loc1099");
		$loc726=get_module_pref("loc726");
		$total=$loc1099+$loc726;
		output("You pull the `\$third lever`0 and hear a noise in the distance.");
		if ($total==1) output("`n`nThe ceiling starts to shake and rocks fall and almost hit you!");
		if ($total==2) output("`n`nThe ceiling collapses and destroys the levers!  You're lucky to escape unharmed.");
		set_module_pref("loc83",1);
		if (get_module_pref("loc1099")==0 || get_module_pref("loc726")==0) addnav("Pull another lever","runmodule.php?module=signetd4&op=138");
		if (get_module_pref("loc1099")==1 && get_module_pref("loc726")==1){
			set_module_pref("loc138",1);
			addnav("Continue","runmodule.php?module=signetd4&loc=".get_module_pref('pqtemp'));
		}else{
			addnav("Leave","runmodule.php?module=signetd4&loc=".(get_module_pref('pqtemp')+34));
		}
	}
	if ($op=="182"){
		output("You find yourself standing face to face with `QF`\$iamma`0.`n`n  He picks up a huge mace and taps it against his hand.");
		output("`n`nWith a smile he starts to approach you.  You don't have a chance to escape.  I hope you're ready!");
		addnav("Fight `QF`\$iamma","runmodule.php?module=signetd4&op=fiamma");
	}
	if ($op=="182b"){
		if (is_module_active("alignment")){
			$alignment=get_module_pref("alignment","alignment");
			$good=get_module_setting("goodalign","alignment");
			$evil=get_module_setting("evilalign","alignment");
			set_module_pref("loc182",1);
			if ($alignment<=$evil) {
				output("Being `\$Evil`0, you decide that `QF`\$iamma`0 is not worthy of your mercy.");
				addnav("Kill Fiamma","runmodule.php?module=signetd4&op=182d");
			}elseif($alignment>$evil && $alignment<$good) {
				output("Being `^Neutral`0, you hesitate for a second and decide to see if you can get anything more out of `QF`4iamma.");
				output("`n`n`#'What's in it for me to let you live, you evil fiend?'`0 you ask.");
				output("`n`n`Q'Well, I can tell you where I have hidden `%3 gems`Q in my bedroom if you let me live.  I promise you won't be able to find them otherwise.'");
				output("`n`n`0What would you like to  do?");
				addnav("`@Let `QF`\$iamma `@Go","runmodule.php?module=signetd4&op=182e");
				addnav("`^Accept `QF`\$iamma's`^ Offer","runmodule.php?module=signetd4&op=182c");
				addnav("`\$Kill `QF`\$iamma","runmodule.php?module=signetd4&op=182d");
			}elseif($alignment>=$good) {
				output("Being of `@Good Alignment`0, you decide to let `QF`\$iamma`0 go.");
				addnav("`@Let `QF`\$iamma `@Go","runmodule.php?module=signetd4&op=182e");
			}
		}else{
			output("You hesitate for a second and decide to see if you can get anything more out of `QF`4iamma.");
			output("`n`n`#'What's in it for me to let you live, you evil fiend?'`0 you ask.");
			output("`n`n`Q'Well, I can tell you where I have hidden `%3 gems`Q in my bedroom if you let me live.  I promise you won't be able to find them otherwise.'");
			output("`n`n`0What would you like to  do?");
			addnav("`@Let `QF`\$iamma `@Go","runmodule.php?module=signetd4&op=182e");
			addnav("`^Accept `QF`\$iamma's`^ Offer","runmodule.php?module=signetd4&op=182c");
			addnav("`\$Kill `QF`\$iamma","runmodule.php?module=signetd4&op=182d");
		}
	}
	if ($op=="182c"){
		output("You accept the offer.  `QF`\$iamma`0 reveals that there's a `%pouch of gems`0 hidden just south of you in the secret compartment in the wall.");
		output("`n`nYou head over to the southern wall and `QF`\$iamma`0  slithers away.");
		output("You chuckle to yourself realizing that he won't be able to survive the mortal wound that you inflicted on him.");
		set_module_pref("loc250",1);
		addnav("Continue","runmodule.php?module=signetd4&op=114");
	}
	if ($op=="182d"){
		if (is_module_active("alignment") && get_module_pref("alignment","alignment")>get_module_setting("evilalign","alignment")){
			output("Your action makes you more `\$Evil`0.");
			increment_module_pref("alignment",-4,"alignment");
		}
		output("You slay `QF`\$iamma`0 without mercy.");
		$expmultiply = e_rand(20,40);
		$expbonus=$session['user']['dragonkills']*3;
		$expgain =round($session['user']['level']*$expmultiply+$expbonus);
		$session['user']['experience']+=$expgain;
		output("`n`n`#You have gained `7%s `#experience.`n",$expgain);
		addnav("Continue","runmodule.php?module=signetd4&loc=".get_module_pref('pqtemp'));
	}
	if ($op=="182e"){
		if (is_module_active("alignment") && get_module_pref("alignment","alignment")<get_module_setting("goodalign","alignment")){
			output("Your action makes you more `@Good`0.");
			increment_module_pref("alignment",+4,"alignment");
		}
		output("You send `QF`\$iamma`0 away, hoping that your thrashing taught him a lesson.");
		output("`n`n`QF`\$iamma`0 starts to slither away, but draws a dagger and lunges at you!!");
		output("However, you knew that he was going to try this trick and you dodge the lunge and `QF`\$iamma`0 crashes against the wall and dies.");
		$expmultiply = e_rand(20,40);
		$expbonus=$session['user']['dragonkills']*3;
		$expgain =round($session['user']['level']*$expmultiply+$expbonus);
		$session['user']['experience']+=$expgain;
		output("`n`n`#You have gained `7%s `#experience.`n",$expgain);
		addnav("Continue","runmodule.php?module=signetd4&loc=".get_module_pref('pqtemp'));
	}
	if ($op=="114"){
		set_module_pref("pqtemp",114);
		//less experience because they received gems
		$session['user']['gems']+=2;
		$expmultiply = e_rand(10,20);
		$expbonus=$session['user']['dragonkills']*3;
		$expgain =round($session['user']['level']*$expmultiply+$expbonus);
		$session['user']['experience']+=$expgain;
		output("You go to the corner wall and find the pouch of gems.  It turns out that `QF`\$iamma`0 was telling the truth.");
		output("`n`nYou collect `%3 gems`0!!");
		output("`n`nIn addition, you gain experience from the battle with `QF`\$iamma`0.");
		output("`n`n`#You have gained `7%s `#experience.`n",$expgain);
		addnav("Continue","runmodule.php?module=signetd4&loc=".get_module_pref('pqtemp'));
	}
	if ($op=="250"){
		output("You pass over the body of `QF`\$iamma`0 in the hallway.  It looks like he didn't get far.");
		set_module_pref("loc250",0);
		addnav("Continue","runmodule.php?module=signetd4&loc=".get_module_pref('pqtemp'));
	}
	if ($op=="152"){
		set_module_pref("loc152",1);
		output("You wander over to find `QF`\$iamma's `QMace `0on the ground.");
		output("`n`nYou look it over carefully and believe that it may be more powerful than your %s`0.",$session['user']['weapon']);
		output("`n`nWould you like to use `QF`\$iamma's `QMace`0?");
		addnav("Yes. I'll use the `QMace","runmodule.php?module=signetd4&op=152b");
		addnav("No. I want to Leave.","runmodule.php?module=signetd4&loc=".get_module_pref('pqtemp'));
	}
	if ($op=="152b"){
		$oldweapon=$session['user']['weapon'];
		$oldattack=$session['user']['weapondmg'];
		$session['user']['weapon']="`QF`4iamma's `QMace";
		$session['user']['attack']++;
		$session['user']['weapondmg']++;
		$session['user']['weaponvalue']*=1.15;
		output("You decide to discard your %s`0 and pick up `QF`4iamma's `QMace`0. Yes, it seems like it's a better weapon than your old one.",$oldweapon);
		addnav("Continue","runmodule.php?module=signetd4&loc=".get_module_pref('pqtemp'));
	}
	if ($op=="83"){
		output("You try to open the door but despite your best efforts you can't get it open.`n`n");
		if (get_module_pref("scroll6")==0){
			output("You find a scrap of paper on the floor that may help you.");
			addnav("Get Scroll","runmodule.php?module=signetd4&op=83b");
		}
		addnav("Leave","runmodule.php?module=signetd4&loc=".(get_module_pref('pqtemp')+34));
	}
	if ($op=="83b"){
		increment_module_pref("pqtemp",34);
		set_module_pref("scroll6",1);
		redirect("runmodule.php?module=signetd4&op=scroll6b");
	}
	if ($op=="12"){
		output("You see a small `Qflame`0 floating in the air in front of you.  You pass your hand over it and nothing happens.  It seems to generate no heat.");
		output("`n`nWhat would you like to do?");
		addnav("Step Into the Flame","runmodule.php?module=signetd4&op=12b");
		addnav("Leave","runmodule.php?module=signetd4&loc=".(get_module_pref('pqtemp')+1));
	}
	if ($op=="12b"){
		output("You take a step into the `Qflame`0 and feel excrutiating pain course through your body.");
		output("`n`nYou feel your strength leave you.");
		$session['user']['hitpoints']=1;
		output("`n`n`\$Your hitpoints are reduced to one.");		
		addnav("Continue","runmodule.php?module=signetd4&op=12c");
	}
	if ($op=="12c"){
		output("Soon the pain starts to diminish and you feel a renewed strength.");
		output("`n`nYou now carry the mark of the `\$Fire Signet`0.");
		output("`n`nYour `@hitpoints are restored to full`0 as the energy of the `\$Fire Signet`0 courses through your body.");
		addnews("`@%s`@ was marked with the `QFire Signet`@ in `QFiamma's Fortress`@.",$session['user']['name']);
		$session['user']['hitpoints']=$session['user']['maxhitpoints'];
		set_module_pref("loc12",1);
		set_module_pref("firesignet",1);
		addnav("Continue","runmodule.php?module=signetd4&loc=".get_module_pref('pqtemp'));
	}
	if ($op=="394"){
		output("You step on a pressure plate and suddenly the corridor around you fills with light.");
		set_module_pref("loc394",1);
		addnav("Continue","runmodule.php?module=signetd4&loc=".get_module_pref('pqtemp'));
	}
	if ($op=="383"){
		output("You step on a pressure plate and suddenly the corridor around you fills with light.");
		set_module_pref("loc383",1);
		addnav("Continue","runmodule.php?module=signetd4&loc=".get_module_pref('pqtemp'));
	}
	if ($op=="726"){
		output("You are unable to open this door.");
		addnav("Leave","runmodule.php?module=signetd4&loc=".(get_module_pref('pqtemp')-1));
	}
	if ($op=="485"){
		output("As you wander down the secret passageway, guards see you and attack!");
		addnav("Continue","runmodule.php?module=signetd4&op=guards");
	}
	if ($op=="picklock"){
		output("You cannot pick the lock and you can't break down the door.");
		if ((get_module_pref("loc463")==1 && get_module_pref("pqtemp")==497)||(get_module_pref("loc506")==1 && get_module_pref("pqtemp")==540)) addnav("Leave","runmodule.php?module=signetd4&loc=".(get_module_pref('pqtemp')-34));
		else addnav("Leave","runmodule.php?module=signetd4&loc=".(get_module_pref('pqtemp')+34));
	}
	if ($op=="362"){
		output("The door is locked. Would you like to try to break down the door or pick the lock?");
		addnav("Break Down Door","runmodule.php?module=signetd4&op=door");
		addnav("Pick Lock","runmodule.php?module=signetd4&op=362b");
		if (get_module_pref("loc328")==1) addnav("Leave","runmodule.php?module=signetd4&loc=".(get_module_pref('pqtemp')-34));
		else addnav("Leave","runmodule.php?module=signetd4&loc=".(get_module_pref('pqtemp')+34));	
	}
	if ($op=="362b"){
		output("You approach the door and attempt to unpick the lock.`n`n");
		//Higher level characters will be more successful; thieves are more successful
		if($session['user']['level']>12) $trap=3;
		elseif($session['user']['level']>8) $trap=5;
		elseif($session['user']['level']>4) $trap=7;
		else $trap=9;
		if (get_module_pref("skill","specialtythiefskills")>0) $trap--;
		switch(e_rand(1,$trap)){
			case 1:
			case 2:
				set_module_pref("loc362",1);
				output("You cautiously pick the lock... Successfully!!`n`n");
				$chance = e_rand(1,3);
				//I wanted to reward people for coming here with at least one turn left
				if ($session['user']['turns']>0 && $chance==1){
					output("You get an adrenaline rush for unlocking the door. You gain an extra turn!");
					$session['user']['turns']++;
				}
				addnav("Continue","runmodule.php?module=signetd4&loc=".get_module_pref('pqtemp'));
			break;
			case 3:
			case 4:
			case 5:
				output("Oh no! You've failed to unlock the door!`n`n`@");
				switch(e_rand(1,5)){
				case 1:
				case 2:
				case 3:
				case 4:
					$hitpoints=round($session['user']['hitpoints']*.05);
					if ($hitpoints>0) output("`n`nA large poison dart shoots out from a trap mechanism and hits you in the shoulder. You `\$lose %s hitpoint%s`0.`n`n",$hitpoints,translate_inline($hitpoints>1?"s":""));
					$session['user']['hitpoints']-=$hitpoints;
				break;
				case 5:
					output("You feel a poison course through your body from a hidden needle embedded in the lock.");
					$hitpoints=round($session['user']['hitpoints']*.1);
					$session['user']['hitpoints']-=$hitpoints;
					if ($session['user']['turns']>0){
						$session['user']['turns']--;
						output("You lose one turn.");
					}
					if ($hitpoints>0) output("You `\$lose %s hitpoint%s`0.`n`n",$hitpoints,translate_inline($hitpoints>1?"s":""));
				break;
				}
				if (get_module_pref("loc328")==1) addnav("Leave","runmodule.php?module=signetd4&loc=".(get_module_pref('pqtemp')-34));
				else addnav("Leave","runmodule.php?module=signetd4&loc=".(get_module_pref('pqtemp')+34));	
			break;
			case 6:
			case 7:
			case 8:
			case 9:
				output("Oh no! You've failed to pick the lock!`n`n`@");
				if ($session['user']['gold']>100){
					$session['user']['gold']-=100;
					output("A blade sweeps out from the door and almost kills you! Luckily, it only cuts open your gold sack and you `^lose 100 gold`@.");
				}elseif ($session['user']['gold']>0){
					$session['user']['gold']=0;
					output("A blade sweeps out from the door and almost kills you! Luckily, it only cuts open your gold sack and you `^lose all of your gold`@.");
				}else{
					if ($session['user']['turns']>0){
						output("A trap triggers and you get knocked back by a huge gust of wind.");
						output("`n`n`@You `blose one turn`b.");
						$session['user']['turns']--;
					}
				}
				if (get_module_pref("loc328")==1) addnav("Leave","runmodule.php?module=signetd4&loc=".(get_module_pref('pqtemp')-34));
				else addnav("Leave","runmodule.php?module=signetd4&loc=".(get_module_pref('pqtemp')+34));
			break;
		}
	}
	if ($op=="93"){
		set_module_pref("loc93",1);
		output("You see several suits of armor here. They all seem to be pretty equivalent to what you're wearing now.  Would you be interested in changing your armor?`n`n");
		if ($session['user']['armordef']<=2){
			addnav("`#Papier Mache Shield","runmodule.php?module=signetd4&op=93a");
			addnav("`&Rice Paper Mail","runmodule.php?module=signetd4&op=93b");
			output("`c`n`#Papier Mache Shield`n");
			output("`n`&Rice Paper Mail`c");
		}elseif ($session['user']['armordef']<=5){
			addnav("`)Raven's Leather","runmodule.php?module=signetd4&op=93a");
			addnav("`^Griffon's Shield","runmodule.php?module=signetd4&op=93b");
			output("`c`n`)Raven's Leather`n");
			output("`n`^Griffin's Shield`c");
		}elseif ($session['user']['armordef']<=8){
			addnav("`^Lion `0Chain Mail","runmodule.php?module=signetd4&op=93a");
			addnav("`@Shield of the `&Eagle","runmodule.php?module=signetd4&op=93b");
			output("`c`n`^Lion `0Chain Mail`n");
			output("`n`@Shield of the `&Eagle`c");
		}elseif ($session['user']['armordef']<=11){
			addnav("`&Crystal Scale Mail","runmodule.php?module=signetd4&op=93a");
			addnav("`4Chiron's Shield","runmodule.php?module=signetd4&op=93b");
			output("`c`n`&Crystal Scale Mail`n");
			output("`n`4Chiron's Shield`c");
		}elseif ($session['user']['armordef']<=14){
			addnav("`!Lightning Plate Mail","runmodule.php?module=signetd4&op=93a");
			addnav("`@Titan's Shield","runmodule.php?module=signetd4&op=93b");
			output("`c`n`!Lightning Plate Mail`n");
			output("`n`@Titan's Shield`c");
		}elseif ($session['user']['armordef']>14){
			addnav("`@`bGreen Dragon Scale Mail`b","runmodule.php?module=signetd4&op=93a");
			addnav("`b`4Shield `#of `QJubilex`b","runmodule.php?module=signetd4&op=93b");
			output("`c`n`@`bGreen Dragon Scale Mail`b`n");
			output("`n`b`4Shield `#of `QJubilex`b`c");
		}
		addnav("Leave","runmodule.php?module=signetd4&op=93c");
	}
	if ($op=="93a"){
		if ($session['user']['armordef']<=2) $session['user']['armor']="`#Papier Mache Shield";
		elseif ($session['user']['armordef']<=5) $session['user']['armor']="`)Raven's Leather";
		elseif ($session['user']['armordef']<=8) $session['user']['armor']="`^Lion `0Chain Mail";
		elseif ($session['user']['armordef']<=11) $session['user']['armor']="`&Crystal Scale Mail";
		elseif ($session['user']['armordef']<=14) $session['user']['armor']="`!Lightning Plate Mail";
		elseif ($session['user']['armordef']>14) $session['user']['armor']="`@`bGreen Dragon Scale Mail`b";
		output("Your %s`0 fits quite nicely.  Yes, this was a nice choice.",$session['user']['armor']);
		addnav("Leave","runmodule.php?module=signetd4&loc=".get_module_pref('pqtemp'));
	}
	if ($op=="93b"){
		if ($session['user']['armordef']<=2) $session['user']['armor']="`&Rice Paper Mail";
		elseif ($session['user']['armordef']<=5) $session['user']['armor']="`^Griffin's Shield";
		elseif ($session['user']['armordef']<=8) $session['user']['armor']="`@Shield of the `&Eagle";
		elseif ($session['user']['armordef']<=11) $session['user']['armor']="`4Chiron's Shield";
		elseif ($session['user']['armordef']<=14) $session['user']['armor']="`@Titan's Shield";
		elseif ($session['user']['armordef']>14) $session['user']['armor']="`b`4Shield `#of `QJubilex`b";
		output("You pick up the %s`0.  This is quite a nice shield.  Good choice.",$session['user']['armor']);
		addnav("Leave","runmodule.php?module=signetd4&loc=".get_module_pref('pqtemp'));
	}
	if ($op=="93c"){
		output("You decide that you're not interested in switching your armor and turn to leave.");
		output("A goblin that had been hiding in the shadows runs over and steals both pieces of armor, then quickly runs away.");
		output("`n`nOh well, on with the adventure.");
		addnav("Leave","runmodule.php?module=signetd4&loc=".get_module_pref('pqtemp'));
	}
	if ($op=="198"){
		output("You hear monsters. Go back?");
		addnav("Fight Monsters","runmodule.php?module=signetd4&op=torturer");
		addnav("Leave","runmodule.php?module=signetd4&loc=".(get_module_pref('pqtemp')-1));
	}
	if ($op=="27"){
		output("The floor falls out from underneath you!`n`n");
		addnav("Continue","runmodule.php?module=signetd4&loc=".get_module_pref('pqtemp'));
		//Higher level characters will be more successful
		if($session['user']['level']>12) $trap=3;
		elseif($session['user']['level']>8) $trap=5;
		elseif($session['user']['level']>4) $trap=7;
		else $trap=9;
		set_module_pref("loc27",1);
		switch(e_rand(1,$trap)){
			case 1:
			case 2:
				output("You nimbly avoid the trap!`n`n");
				$chance = e_rand(1,3);
				if ($session['user']['turns']>0 && $chance==1){
					output("However, you lose a turn catching your breath.");
					$session['user']['turns']--;
				}
			break;
			case 3:
			case 4:
			case 5:
				output("Oh no! You fall into the pit!`n`n`@");
				switch(e_rand(1,5)){
				case 1:
				case 2:
				case 3:
				case 4:
					$hitpoints=round($session['user']['hitpoints']*.05);
					if ($hitpoints>0) output("You `\$lose %s hitpoint%s`0.`n`n",$hitpoints,translate_inline($hitpoints>1?"s":""));
					else output("Luckily, you don't lose any hitpoints.");
					$session['user']['hitpoints']-=$hitpoints;
				break;
				case 5:
					output("You fall onto a wooden spike!");
					$hitpoints=round($session['user']['hitpoints']*.1);
					$session['user']['hitpoints']-=$hitpoints;
					if ($session['user']['turns']>0){
						$session['user']['turns']--;
						output("You lose one turn.");
					}
					if ($hitpoints>0) output("You `\$lose %s hitpoint%s`0.`n`n",$hitpoints,translate_inline($hitpoints>1?"s":""));
					else output("Luckily, it doesn't hurt you.");
				break;
				}
			break;
			case 6:
			case 7:
			case 8:
			case 9:
				output("You hit your head on the ground.`n`n`@");
				if ($session['user']['gold']>100){
					$session['user']['gold']-=100;
					output("You awaken to find that somehow you've `^lost 100 gold`@.");
				}elseif ($session['user']['gold']>0){
					$session['user']['gold']=0;
					output("You awaken to find that somehow you've `^lost all of your gold`@.");
				}else{
					if ($session['user']['turns']>0){
						output("You wake up after a short period.");
						output("`n`n`@You `blose one turn`b.");
						$session['user']['turns']--;
					}
				}
			break;
		}
	}
	if ($op=="931"){
		output("There is a large oak barrel in this corner.");
		set_module_pref("loc931b",1);
		addnav("Break Barrel","runmodule.php?module=signetd4&op=931b");
		addnav("Leave","runmodule.php?module=signetd4&loc=".get_module_pref('pqtemp'));
	}
	if ($op=="931b"){
		output("You grab your %s`0 and take a swing at the barrel...",$session['user']['weapon']);
		output("`n`nIt explodes!!");
		$barrel=round($session['user']['hitpoints']*.2);
		set_module_pref("loc931",1);
		if ($barrel<=1) output("`n`nYou duck most of the debris and escape unharmed!");
		else{
			output("`n`nYou are injured and lose `\$%s hitpoints`0!",$barrel);
			$session['user']['hitpoints']-=$barrel;
		}
		addnav("Continue","runmodule.php?module=signetd4&loc=".get_module_pref('pqtemp'));
	}
	if ($op=="934"){
		output("There is a large oak barrel in this corner.");
		set_module_pref("loc934b",1);
		addnav("Break Barrel","runmodule.php?module=signetd4&op=934b");
		addnav("Leave","runmodule.php?module=signetd4&loc=".get_module_pref('pqtemp'));
	}
	if ($op=="934b"){
		output("You grab your %s`0 and take a swing at the barrel...",$session['user']['weapon']);
		output("`n`nIt explodes!!");
		$barrel=round($session['user']['hitpoints']*.2);
		set_module_pref("loc934",1);
		if ($barrel<=1) output("`n`nYou duck most of the debris and escape unharmed!");
		else{
			output("`n`nYou are injured and lose `\$%s hitpoints`0!",$barrel);
			$session['user']['hitpoints']-=$barrel;
		}
		output("`n`nAfter the dust settles you look down and see `%2 gems`0 in the dust!");
		$session['user']['gems']+=2;
		addnav("Continue","runmodule.php?module=signetd4&loc=".get_module_pref('pqtemp'));
	}
	if ($op=="1105"){
		output("You cannot pick the lock or break down the door no matter what you try.");
		if (get_module_pref("loc1104")==1) addnav("Leave","runmodule.php?module=signetd4&loc=".(get_module_pref('pqtemp')-1));
		else addnav("Leave","runmodule.php?module=signetd4&loc=".(get_module_pref('pqtemp')+1));	
	}
	if ($op=="1143"){
		output("You try to unlock the door but you can't.  Suddenly, you remember the key you found in that storage room!");
		output("`n`nYes! Aren't you glad you brought that with you? It opens the door!");
		set_module_pref("loc1143",1);
		addnav("Continue","runmodule.php?module=signetd4&loc=".get_module_pref('pqtemp'));	
	}
	if ($op=="1143b"){
		output("You cannot pick the lock or break down the door no matter what you try.");
		addnav("Leave","runmodule.php?module=signetd4&loc=".(get_module_pref('pqtemp')-34));	
	}
	if ($op=="868"){
		output("You hear monsters. Go back?");
		addnav("Fight Monsters","runmodule.php?module=signetd4&op=drunkendwarf");
		addnav("Leave","runmodule.php?module=signetd4&loc=".(get_module_pref('pqtemp')+34));	
	}
	if ($op=="874"){
		output("You hear monsters. Go back?");
		addnav("Fight Monsters","runmodule.php?module=signetd4&op=guards");
		addnav("Leave","runmodule.php?module=signetd4&loc=".(get_module_pref('pqtemp')+34));	
	}
	if ($op=="874b"){
		output("Several guards see you trying to leave the library and charge after you!");
		addnav("Fight Monsters","runmodule.php?module=signetd4&op=guards");
	}
	if ($op=="635"){
		output("You see a scroll on the desk.");
		addnav("Take the Scroll","runmodule.php?module=signetd4&op=635b");
		addnav("Leave","runmodule.php?module=signetd4&loc=".(get_module_pref('pqtemp')+34));	
	}
	if ($op=="635b"){
		set_module_pref("loc635",1);
		set_module_pref("scroll7",1);
		redirect("runmodule.php?module=signetd4&loc=".get_module_pref('pqtemp'));
	}
	//the scrolls
	if ($op=="scroll1b"){
		output("`c`b`^The Aria Dungeon`0`c`b`n");
		output("The Aria Dungeon was once the center of a small community of dwarves.  About 15 years ago, a band of orcs invaded the community and defeated the dwarves.");
		output("`n`nIt is said that only the leader of the dwarves, Kilmor, and a few others escaped from the Orcs.");
		addnav("Return","runmodule.php?module=signetd4&loc=".get_module_pref('pqtemp'));
	}
	if ($op=="scroll2b"){
		output("`c`b`^The Historical Scrolls of the `3E`Ql`!e`\$m`3e`Qn`!t`\$a`3l`^ Signets`0`c`b`n");
		output("Although there had until recently been general peace across the land, the evil sorcerer Mierscri has brought his great army of men and beasts to terrorize the land.");
		output("This great force laid waste to the land and its people. Soon, the battle would be over.");
		output("`n`nHowever, before this could happen, a coalition of the four greatest wizards of the land came together to end the reign of evil.");
		output("The wizards created 4 signets; each representing the great forces of nature:  `3Air`0, `QEarth`0, `!Water`0, and `\$Fire`0.");
		output("When one warrior was able to harness the power of these four signets, then the evil could be stopped.");
		output("`n`nMierscri learned of the plan and captured the four wizards before a warrior could be chosen to receive the signets.  His evil spells turned the wizards into Warlocks of great power but completely under his control.");
		output("`n`nPerhaps one day a warrior will be able to gather the four signets in order to finally defeat the evil Mierscri.");
		addnav("Return","runmodule.php?module=signetd4&loc=".get_module_pref('pqtemp'));
	}
	if ($op=="scroll3b"){
		output("`c`b`^Prison Notes by Kilmor`0`c`b`n");
		output("The Orcs are less than wonderful captors. I hope to be able to break free soon.");
		output("My first journey will be to the `^Temple of the Aarde Priests`0.  It is rumored that the high priest of the temple has the power of prophesy, but few have been allowed to see him.");
		addnav("Return","runmodule.php?module=signetd4&loc=".get_module_pref('pqtemp'));
	}
	if ($op=="scroll4b"){
		output("`c`b`^Report from Evad the Sage`c`b");
		output("`n`0In `\$Fiamma's Fortress`0 there is a secret control room which can be accessed from one of two secret passages.");
		output("The first starts in `\$Fiamma's`0 room.  The other starts between the arena and the jail cell.");
		output("From this room various gates around the castle can be operated.");
		addnav("Continue","runmodule.php?module=signetd4&loc=".get_module_pref('pqtemp'));
	}
	if ($op=="scroll5b"){
		output("`c`b`^The Story of Fiamma Fortress`c`b");
		output("`n`0Many years ago when Mierscri was invading the land, the men and beasts put aside their differences and joined together to fight him.");
		output("`n`nThe lowly Fiamma, who was an officer in this combined army, told Mierscri of the plan; thus it failed.");
		output("`n`nAs a reward for this action, Fiamma was given a great fortress and given the Fire Signet to guard over.");
		addnav("Continue","runmodule.php?module=signetd4&loc=".get_module_pref('pqtemp'));
	}
	if ($op=="scroll6b"){
		output("`c`b`^Fiamma's Fortress`0`c`b`n");
		output("`\$My Fortress is impenetrable.  I feel safe knowing that the control room can only be accessed from two places.");
		output("I carefully guard the first entrance in my bedroom so I have no concern of it being discovered.");
		output("However, even I fear mentioning the second location.  That secret will not be revealed on paper.");
		addnav("Return","runmodule.php?module=signetd4&loc=".get_module_pref('pqtemp'));
	}
	if ($op=="scroll7b"){
		output("`c`b`^Fiamma's Plans`0`c`b`n");
		output("`\$I cannot be a servant of the `bMaster Mierscri`b for all my life.  I have plans!");
		output("`n`nHis `)Dark Warlocks `\$concern me greatly but I think I have finally found a chance to defeat him.");
		output("I was able to place a deadly trap in his treasure trove of `^gold`\$ and coated his pile of `%gems`\$ with a poison.  The next time he plans to count his plunder he will find his life shortened!");
		output("`n`nIf that fails, I have a plan to steal his wand and use it against him.  He is vulnerable when his magic is turned against him.");
		output("`n`nMy reign of terror will begin soon after!");
		addnav("Return","runmodule.php?module=signetd4&loc=".get_module_pref('pqtemp'));
	}
	//Scrolls for in the bio start here
	if ($op=="scroll6"){
		$userid = httpget("user");
		output("`c`b`^Fiamma's Fortress`0`c`b`n");
		output("`\$My Fortress is impenetrable.  I feel safe knowing that the control room can only be accessed from two places.");
		output("I carefully guard the first entrance in my bedroom so I have no fear of it being discovered.");
		output("However, even I fear mentioning the second location.  That secret will not be revealed on paper.");
		addnav("Return to Signets","runmodule.php?module=signetsale&op=signetnotes&user=$userid");
	}
	if ($op=="scroll7"){
		$userid = httpget("user");
		output("`c`b`^Fiamma's Plans`0`c`b`n");
		output("`\$I cannot be a servant of `bMaster Mierscri`b for all my life.  I have plans!");
		output("`n`nHis `)Dark Warlocks `\$concern me greatly but I think I have finally found a chance to defeat him.");
		output("I was able to place a deadly trap in his treasure trove of `^gold`\$ and coated his pile of `%gems`\$ with a poison.  The next time he plans to count his plunder he will find his life shortened!");
		output("`n`nIf that fails, I have a plan to steal his wand and use it against him.  He is vulnerable when his magic is turned against him.");
		output("`n`nMy reign of terror will begin soon after!");
		addnav("Return to Signets","runmodule.php?module=signetsale&op=signetnotes&user=$userid");
	}
	page_footer();
}
?>