<?php

function signetd3_fight($op) {
	$temp=get_module_pref("pqtemp");
	page_header("Castle Fight");
	global $session,$badguy;
	//for the doors
	if ($op=="door"){
		if ($temp==221 && get_module_pref("loc221")==0) set_module_pref("loc221",2);
		$badguy = array(
			"type"=>"",
			"creaturename"=>"`Qa Heavy Door`0",
			"creaturelevel"=>6,
			"creatureweapon"=>"sharp splinters",
			"creatureattack"=>5,
			"creaturedefense"=>6,
			"creaturehealth"=>40,
			"diddamage"=>0);
		$session['user']['badguy']=createstring($badguy);
		$op="fight";
	}
	//for the monsters
	if ($op=="oldman"){
		if ($temp==1097 && get_module_pref("loc1097")==0) set_module_pref("loc1097",2);
		$badguy = array(
			"type"=>"",
			"creaturename"=>"An Old Man",
			"creaturelevel"=>$session['user']['level'],
			"creatureweapon"=>"his ugly stick",
			"creatureattack"=>($session['user']['attack']+e_rand(1,3))*.8,
			"creaturedefense"=>($session['user']['attack']+e_rand(1,3))*.85,
			"creaturehealth"=>round($session['user']['hitpoints']*.92),
			"diddamage"=>0);
		$session['user']['badguy']=createstring($badguy);
		$op="fight";
	}
	if ($op=="soldiers"){
		if ($temp==619 && get_module_pref("loc619")==0) set_module_pref("loc619",2);
		$badguy = array(
			"type"=>"",
			"creaturename"=>"Rowdy Soldiers",
			"creaturelevel"=>$session['user']['level'],
			"creatureweapon"=>"short swords",
			"creatureattack"=>($session['user']['attack']+e_rand(2,4))*.8,
			"creaturedefense"=>($session['user']['attack']+e_rand(2,4))*.85,
			"creaturehealth"=>round($session['user']['hitpoints']*.93),
			"diddamage"=>0);
		$session['user']['badguy']=createstring($badguy);
		$op="fight";
	}
	if ($op=="mages"){
		if ($temp==483 && get_module_pref("loc483")==0) set_module_pref("loc483",2);
		$badguy = array(
			"type"=>"",
			"creaturename"=>"Mages",
			"creaturelevel"=>$session['user']['level'],
			"creatureweapon"=>"magic missile spells",
			"creatureattack"=>($session['user']['attack']+e_rand(2,4))*.9,
			"creaturedefense"=>($session['user']['attack']+e_rand(0,1))*.7,
			"creaturehealth"=>round($session['user']['hitpoints']*.7),
			"diddamage"=>0);
		$session['user']['badguy']=createstring($badguy);
		$op="fight";
	}
	if ($op=="hornet"){
		if ($temp==358 && get_module_pref("loc358")==0) set_module_pref("loc358",2);
		if ($temp==499 && get_module_pref("loc499")==0) set_module_pref("loc499",2);
		$badguy = array(
			"type"=>"",
			"creaturename"=>"A Giant Hornet",
			"creaturelevel"=>$session['user']['level'],
			"creatureweapon"=>"Venom-filled Stinger",
			"creatureattack"=>($session['user']['attack']+e_rand(2,4))*.8,
			"creaturedefense"=>($session['user']['attack']+e_rand(2,4))*.8,
			"creaturehealth"=>round($session['user']['hitpoints']*.8),
			"diddamage"=>0);
		$session['user']['badguy']=createstring($badguy);
		$op="fight";
	}
	if ($op=="guard"){
		if ($temp==148 && get_module_pref("loc148")==0) set_module_pref("loc148",2);
		if ($temp==82 && get_module_pref("loc82")==0) set_module_pref("loc82",2);
		if ($temp==87 && get_module_pref("loc87")==0) set_module_pref("loc87",2);
		$badguy = array(
			"type"=>"",
			"creaturename"=>"Prison Guard",
			"creaturelevel"=>$session['user']['level'],
			"creatureweapon"=>"very sharp keys",
			"creatureattack"=>($session['user']['attack']+e_rand(1,2))*.7,
			"creaturedefense"=>($session['user']['attack']+e_rand(2,4))*.9,
			"creaturehealth"=>round($session['user']['hitpoints']*.92),
			"diddamage"=>0);
		$session['user']['badguy']=createstring($badguy);
		$op="fight";
	}
	if ($op=="asp"){
		if ($temp==401 && get_module_pref("loc401")==0) set_module_pref("loc401",2);
		$badguy = array(
			"type"=>"",
			"creaturename"=>"A Dangerous Asp",
			"creaturelevel"=>$session['user']['level'],
			"creatureweapon"=>"fangs",
			"creatureattack"=>($session['user']['attack']+e_rand(2,4))*1.1,
			"creaturedefense"=>($session['user']['attack']+e_rand(2,4))*.6,
			"creaturehealth"=>round($session['user']['hitpoints']*.7),
			"diddamage"=>0);
		$session['user']['badguy']=createstring($badguy);
		$op="fight";
	}
	if ($op=="troll"){
		if ($temp==164 && get_module_pref("loc164")==0) set_module_pref("loc164",2);
		$badguy = array(
			"type"=>"",
			"creaturename"=>"Troll",
			"creaturelevel"=>$session['user']['level'],
			"creatureweapon"=>"dirty claws",
			"creatureattack"=>($session['user']['attack']+e_rand(1,2))*.8,
			"creaturedefense"=>($session['user']['attack']+e_rand(1,2))*.8,
			"creaturehealth"=>round($session['user']['hitpoints']*.8),
			"diddamage"=>0);
		$session['user']['badguy']=createstring($badguy);
		$op="fight";
	}
	if ($op=="bantir"){
		if ($temp==94 && get_module_pref("loc94")==0) set_module_pref("loc94",2);
		$badguy = array(
			"type"=>"",
			"creaturename"=>"A Bantir",
			"creaturelevel"=>$session['user']['level'],
			"creatureweapon"=>"stringy appendages",
			"creatureattack"=>($session['user']['attack']+e_rand(1,3))*.76,
			"creaturedefense"=>($session['user']['attack']+e_rand(1,3))*.8,
			"creaturehealth"=>round($session['user']['hitpoints']*.7),
			"diddamage"=>0);
		$session['user']['badguy']=createstring($badguy);
		$op="fight";
	}
	if ($op=="wraith"){
		if ($temp==29 && get_module_pref("loc29")==0) set_module_pref("loc29",2);
		$level=$session['user']['level']+1;
		if ($level>=15) $level=15;
		$badguy = array(
			"type"=>"",
			"creaturename"=>"Wratih",
			"creaturelevel"=>$level,
			"creatureweapon"=>"withered claws",
			"creatureattack"=>($session['user']['attack']+e_rand(1,2)),
			"creaturedefense"=>($session['user']['attack']+e_rand(1,2))*.9,
			"creaturehealth"=>round($session['user']['hitpoints']*.95),
			"diddamage"=>0);
		$session['user']['badguy']=createstring($badguy);
		$op="fight";
	}
	if ($op=="skeleton"){
		if ($temp==65 && get_module_pref("loc65")==0) set_module_pref("loc65",2);
		$badguy = array(
			"type"=>"",
			"creaturename"=>"Skeleton",
			"creaturelevel"=>$session['user']['level'],
			"creatureweapon"=>"rusty sabre",
			"creatureattack"=>($session['user']['attack']+e_rand(1,2))*1.5,
			"creaturedefense"=>($session['user']['attack']+e_rand(1,2))*.8,
			"creaturehealth"=>round($session['user']['hitpoints']*.6),
			"diddamage"=>0);
		$session['user']['badguy']=createstring($badguy);
		$op="fight";
	}
	if ($op=="spider"){
		if ($temp==66 && get_module_pref("loc66")==0) set_module_pref("loc66",2);
		$badguy = array(
			"type"=>"",
			"creaturename"=>"A Giant Spider",
			"creaturelevel"=>$session['user']['level'],
			"creatureweapon"=>"Venom-filled Fangs",
			"creatureattack"=>($session['user']['attack']+e_rand(2,4))*.86,
			"creaturedefense"=>($session['user']['attack']+e_rand(2,4))*.8,
			"creaturehealth"=>round($session['user']['hitpoints']*.86),
			"diddamage"=>0);
		$session['user']['badguy']=createstring($badguy);
		$op="fight";
	}
	if ($op=="waterelemental"){
		if ($temp==745 && get_module_pref("loc745")==0) set_module_pref("loc745",2);
		$badguy = array(
			"type"=>"",
			"creaturename"=>"Guardian Water Elemental",
			"creaturelevel"=>$session['user']['level']+1,
			"creatureweapon"=>"powerful blasts of water",
			"creatureattack"=>($session['user']['attack']+e_rand(2,4)),
			"creaturedefense"=>($session['user']['attack']+e_rand(2,4)),
			"creaturehealth"=>round($session['user']['maxhitpoints']*.96),
			"diddamage"=>0);
		$session['user']['badguy']=createstring($badguy);
		$op="fight";
	}
	if ($op=="ranger"){
		if ($temp==591 && get_module_pref("loc591")==0) set_module_pref("loc591",2);
		$badguy = array(
			"type"=>"",
			"creaturename"=>"Ranger",
			"creaturelevel"=>$session['user']['level'],
			"creatureweapon"=>"morning star",
			"creatureattack"=>($session['user']['attack']+e_rand(1,2))*.8,
			"creaturedefense"=>($session['user']['attack']+e_rand(2,4))*.87,
			"creaturehealth"=>round($session['user']['hitpoints']*.92),
			"diddamage"=>0);
		$session['user']['badguy']=createstring($badguy);
		$op="fight";
	}
	if ($op=="ogres"){
		if ($temp==625 && get_module_pref("loc625")==0) set_module_pref("loc625",2);
		$badguy = array(
			"type"=>"",
			"creaturename"=>"Ogres",
			"creaturelevel"=>$session['user']['level'],
			"creatureweapon"=>"primitive maces",
			"creatureattack"=>($session['user']['attack']+e_rand(1,2))*.8,
			"creaturedefense"=>($session['user']['attack']+e_rand(2,4))*.87,
			"creaturehealth"=>round($session['user']['hitpoints']*.82),
			"diddamage"=>0);
		$session['user']['badguy']=createstring($badguy);
		$op="fight";
	}
	if ($op=="dripslime"){
		if ($temp==939 && get_module_pref("loc939")==0) set_module_pref("loc939",2);
		$badguy = array(
			"type"=>"",
			"creaturename"=>"A Bantir",
			"creaturelevel"=>$session['user']['level'],
			"creatureweapon"=>"stringy appendages",
			"creatureattack"=>($session['user']['attack']+e_rand(1,3))*.76,
			"creaturedefense"=>($session['user']['attack']+e_rand(1,3))*.7,
			"creaturehealth"=>round($session['user']['hitpoints']*.7),
			"diddamage"=>0);
		$session['user']['badguy']=createstring($badguy);
		$op="fight";
	}
	if ($op=="fight" or $op=="run"){
		global $badguy;
		$battle=true;
		$fight=true;
		if ($battle){
			require_once("battle.php");
    
	    if ($victory){
       			addnav("Continue","runmodule.php?module=signetd3&loc=".get_module_pref('pqtemp'));
				//opening doors
				if ($temp==221 && get_module_pref("loc221")==2) {
					output("`^`n`bYou have opened the door safely.`b`n");
					$experience=$session['user']['level']*e_rand(4,7);
					output("`#You receive `6%s `#experience.`n",$experience);
					$session['user']['experience']+=$experience;
					if (get_module_pref("loc221")==2) set_module_pref("loc221",1);
				//special monsters
				}elseif($temp==745 && get_module_pref("loc745")==2){
					set_module_pref("loc745",1);
					output("`b`4You have slain `^%s`4.`b`n",$badguy['creaturename']);
					$session['user']['gems']++;
					$expmultiply = e_rand(12,25);
					$expbonus=$session['user']['dragonkills']*3;
					$expgain =round($session['user']['level']*$expmultiply+$expbonus);
					$session['user']['experience']+=$expgain;
					output("`n`@The Water Elemental dissipates.  In its place remains a solitary `%gem`@.");
					output("`n`#You have gained `7%s `#experience.`n",$expgain);
				//monsters
				}elseif (($temp==1097 && get_module_pref("loc1097")==2) || ($temp==619 && get_module_pref("loc619")==2) || ($temp==483 && get_module_pref("loc483")==2) || ($temp==358 && get_module_pref("loc358")==2) || ($temp==148 && get_module_pref("loc148")==2) || ($temp==82 && get_module_pref("loc82")==2) || ($temp==87 && get_module_pref("loc87")==2) || ($temp==499 && get_module_pref("loc499")==2) || ($temp==401 && get_module_pref("loc401")==2) || ($temp==164 && get_module_pref("loc164")==2) || ($temp==94 && get_module_pref("loc94")==2) || ($temp==29 && get_module_pref("loc29")==2) || ($temp==65 && get_module_pref("loc65")==2) || ($temp==66 && get_module_pref("loc66")==2) || ($temp==939 && get_module_pref("loc939")==2) || ($temp==625 && get_module_pref("loc625")==2) || ($temp==591 && get_module_pref("loc591")==2)){
					output("`b`4You have slain `^%s`4.`b`n",$badguy['creaturename']);
					$gold=e_rand(80,200);
					$session['user']['gold']+=$gold;
					$expmultiply = e_rand(10,20);
					$expbonus=$session['user']['dragonkills']*1.5;
					$expgain =round($session['user']['level']*$expmultiply+$expbonus);
					$session['user']['experience']+=$expgain;
					output("`n`@You search through the smelly corpse and find `^%s gold`@.`n",$gold);
					output("`n`#You have gained `7%s `#experience.`n",$expgain);
					if (get_module_pref("loc1097")==2) set_module_pref("loc1097",1);
					if (get_module_pref("loc619")==2) set_module_pref("loc619",1);
					if (get_module_pref("loc483")==2) set_module_pref("loc483",1);
					if (get_module_pref("loc358")==2) set_module_pref("loc358",1);
					if (get_module_pref("loc148")==2 || get_module_pref("loc82")==2 || get_module_pref("loc87")==2){
						output("`nYou search through the prison guard's keys and find one that unlocks the cell door.");
						set_module_pref("prisonkey",1);
					}
					if (get_module_pref("loc148")==2) set_module_pref("loc148",1);
					if (get_module_pref("loc82")==2) set_module_pref("loc82",1);
					if (get_module_pref("loc87")==2) set_module_pref("loc87",1);
					if (get_module_pref("loc499")==2) set_module_pref("loc499",1);
					if (get_module_pref("loc401")==2) set_module_pref("loc401",1);
					if (get_module_pref("loc164")==2) set_module_pref("loc164",1);
					if (get_module_pref("loc94")==2) set_module_pref("loc94",1);
					if (get_module_pref("loc29")==2) set_module_pref("loc29",1);
					if (get_module_pref("loc65")==2) set_module_pref("loc65",1);
					if (get_module_pref("loc66")==2) set_module_pref("loc66",1);
					if (get_module_pref("loc625")==2) set_module_pref("loc625",1);
					if (get_module_pref("loc591")==2) set_module_pref("loc591",1);
					if (get_module_pref("loc939")==2) set_module_pref("loc939",1);
				//next lines are for random encounters
				}else{
					output("`b`4You have slain `^%s`4.`b`n",$badguy['creaturename']);
					$gold=e_rand(50,150);
					$session['user']['gold']+=$gold;
					$expmultiply = e_rand(10,20);
					$expbonus=$session['user']['dragonkills']*1.5;
					$expgain =round($session['user']['level']*$expmultiply+$expbonus);
					$session['user']['experience']+=$expgain;
					output("`n`@You search through the smelly corpse and find `^%s gold`@.`n",$gold);
					output("`n`#You have gained `7%s `#experience.`n",$expgain);				
				}
				if ((get_module_setting("healing")==1) && ($session['user']['hitpoints']<$session['user']['maxhitpoints']*.6)){
					$hpdown=$session['user']['maxhitpoints']-$session['user']['hitpoints'];
					switch(e_rand(1,14)){
						case 1:
							if ($hpdown>200) $hpdown=200;
							output("`n`@You find a healing potion and take a deep drink.  You feel your strength return.");
							output("`n`nYou gain `b%s hitpoints`b!",$hpdown);
							$session['user']['hitpoints']+=$hpdown;
						break;
						case 2:
						case 3:
							output("`n`@You notice the remnants of a healing potion.  You have a chance to take a drink!");
							$hpheal=round(e_rand($hpdown*.3,$hpdown*.7));
							if ($hpheal<=1) $hpheal=2;
							if ($hpheal>120) $hpheal=120;
							output("`n`nYou gain `b%s hitpoints`b!",$hpheal);
							$session['user']['hitpoints']+=$hpheal;
						break;
						case 4:
						case 5:
						case 6:
							output("`n`@You notice the remnants of a small healing potion.  You have a chance to take a quick drink!");;
							$hpheal=round(e_rand($hpdown*.1,$hpdown*.4));
							if ($hpheal<=1) $hpheal=2;
							if ($hpheal>50) $hpheal=50;
							output("`n`nYou gain `b%s hitpoints`b!",$hpheal);
							$session['user']['hitpoints']+=$hpheal;
						break;
						case 7:
							$hpleft=$session['user']['hitpoints'];
							$hphurt=round(e_rand($hpleft*.1,$hpleft*.4));
							if ($hphurt>50) $hphurt=50;
							if ($hphurt>1  && $hpleft>5){
								output("`n`@You find a healing potion and drink it down.  `\$Oh no! It was poisoned!");
								output("`n`n`@You lose `b`\$%s hitpoints`b`@!",$hphurt);
								$session['user']['hitpoints']-=$hphurt;
							}
						break;
						case 8:
						case 9:
						case 10:
						case 11:
						case 12:
						case 13:
						case 14:
						break;
					}
				}
				$badguy=array();
				$session['user']['badguy']="";
			}elseif ($defeat){
				if ($temp==1005 && get_module_pref("loc221")==2){
					if (get_module_pref("loc221")==2) set_module_pref("loc221",0);
					output("A splinter severs a major blood vessel and you die.`n");
					addnews("`% %s`5 has been slain trying to break down a door.",$session['user']['name']);
				}
				elseif (($temp==1097 && get_module_pref("loc1097")==2) || ($temp==619 && get_module_pref("loc619")==2) || ($temp==483 && get_module_pref("loc483")==2) || ($temp==358 && get_module_pref("loc358")==2) || ($temp==148 && get_module_pref("loc148")==2) || ($temp==82 && get_module_pref("loc82")==2) || ($temp==87 && get_module_pref("loc87")==2) || ($temp==499 && get_module_pref("loc499")==2) || ($temp==401 && get_module_pref("loc401")==2) || ($temp==164 && get_module_pref("loc164")==2) || ($temp==94 && get_module_pref("loc94")==2) || ($temp==29 && get_module_pref("loc29")==2) || ($temp==65 && get_module_pref("loc65")==2) || ($temp==66 && get_module_pref("loc66")==2) || ($temp==745 && get_module_pref("loc745")==2) || ($temp==939 && get_module_pref("loc939")==2) || ($temp==625 && get_module_pref("loc625")==2) || ($temp==591 && get_module_pref("loc591")==2)){
					if (get_module_pref("loc1097")==2) set_module_pref("loc1097",0);
					if (get_module_pref("loc619")==2) set_module_pref("loc619",0);
					if (get_module_pref("loc483")==2) set_module_pref("loc483",0);
					if (get_module_pref("loc358")==2) set_module_pref("loc358",0);
					if (get_module_pref("loc148")==2) set_module_pref("loc148",0);
					if (get_module_pref("loc82")==2) set_module_pref("loc82",0);
					if (get_module_pref("loc87")==2) set_module_pref("loc87",0);
					if (get_module_pref("loc499")==2) set_module_pref("loc499",0);
					if (get_module_pref("loc401")==2) set_module_pref("loc401",0);
					if (get_module_pref("loc164")==2) set_module_pref("loc164",0);
					if (get_module_pref("loc94")==2) set_module_pref("loc94",0);
					if (get_module_pref("loc29")==2) set_module_pref("loc29",0);
					if (get_module_pref("loc65")==2) set_module_pref("loc65",0);
					if (get_module_pref("loc66")==2) set_module_pref("loc66",0);
					if (get_module_pref("loc745")==2) set_module_pref("loc745",0);
					if (get_module_pref("loc625")==2) set_module_pref("loc625",0);
					if (get_module_pref("loc939")==2) set_module_pref("loc939",0);
					if (get_module_pref("loc591")==2) set_module_pref("loc591",0);
					output("As you hit the ground the `^%s runs away.",$badguy['creaturename']);
					addnews("`%%s`5 has been slain by an evil %s in a dungeon.",$session['user']['name'],$badguy['creaturename']);
				//Next lines are for random encounters
				}else{
					output("As you hit the ground the `^%s runs away.",$badguy['creaturename']);
					addnews("`%%s`5 has been slain by an evil %s in a dungeon.",$session['user']['name'],$badguy['creaturename']);
				}
		        $badguy=array();
		        $session['user']['badguy']="";  
		        $session['user']['hitpoints']=0;
		        $session['user']['alive']=false;
		        addnav("Continue","shades.php");
			}else{
					require_once("lib/fightnav.php");
					fightnav(true,false,"runmodule.php?module=signetd3");
			}
		}else{
			redirect("runmodule.php?module=signetd3&loc=".get_module_pref('pqtemp'));	
		}
	}
	page_footer();
}
function signetd3_misc($op) {
	$temp=get_module_pref("pqtemp");
	page_header("Wasser's Castle");
	global $session;
	if ($op=="exits1"){
		output("You have found an `\$Emergency Exit`0.");
		output("You have the option of leaving from this location at this time.");
		if (get_module_setting("exitsave")==1){
			output("`n`nIf you leave now, you may return to the dungeon at this location or enter at the main entrance.");
			addnav("`\$Take Exit`0");
			addnav("Main Entrance","runmodule.php?module=signetd3&op=exits2");
			addnav("This Location","runmodule.php?module=signetd3&op=exits3");
			addnav("Continue");
		}else{
			output("`n`nIf you leave now, you will re-enter the dungeon from this location.");
			addnav("`\$Take Exit","runmodule.php?module=signetd3&op=exits3");
		}
		addnav("Return to the Dungeon","runmodule.php?module=signetd3&loc=".get_module_pref('pqtemp'));
	}
	if ($op=="exits2"){
		output("You will re-enter the dungeon from the main exit.");
		set_module_pref("startloc",1275);
		villagenav();
	}
	if ($op=="exits3"){
		output("You will re-enter the dungeon at this location.");
		set_module_pref("startloc",get_module_pref("pqtemp"));
		villagenav();
	}
	if ($op=="reset"){	
		clear_module_pref("maze","signetd2");
		clear_module_pref("mazeturn","signetd2");
		clear_module_pref("pqtemp","signetd2");
		clear_module_pref("randomp","signetd2");
		clear_module_pref("super","signetd2");
		clear_module_pref("header","signetd2");
		clear_module_pref("loc334","signetd2");
		clear_module_pref("loc685","signetd2");
		clear_module_pref("loc1098","signetd2");
		clear_module_pref("donated","signetd2");
		clear_module_pref("donatenum","signetd2");
		clear_module_pref("loc55","signetd2");
		clear_module_pref("loc59","signetd2");
		clear_module_pref("loc82","signetd2");
		clear_module_pref("loc109","signetd2");
		clear_module_pref("loc109","signetd2");
		clear_module_pref("loc163","signetd2");
		clear_module_pref("loc279","signetd2");
		clear_module_pref("loc327","signetd2");
		clear_module_pref("loc334b","signetd2");
		clear_module_pref("loc381","signetd2");
		clear_module_pref("loc386","signetd2");
		clear_module_pref("loc496","signetd2");
		clear_module_pref("loc537","signetd2");
		clear_module_pref("loc537b","signetd2");
		clear_module_pref("loc556","signetd2");
		clear_module_pref("loc776","signetd2");
		clear_module_pref("loc822","signetd2");
		clear_module_pref("loc841","signetd2");
		clear_module_pref("loc843","signetd2");
		clear_module_pref("loc865","signetd2");
		clear_module_pref("loc890","signetd2");
		clear_module_pref("loc946","signetd2");
		clear_module_pref("loc947","signetd2");
		clear_module_pref("loc956","signetd2");
		clear_module_pref("loc970","signetd2");
		clear_module_pref("loc1010","signetd2");
		clear_module_pref("loc1010b","signetd2");
		clear_module_pref("loc1012","signetd2");
		clear_module_pref("loc1026","signetd2");
		clear_module_pref("loc1082","signetd2");
		clear_module_pref("loc1098","signetd2");
		clear_module_pref("loc1147","signetd2");
		clear_module_pref("loc1148","signetd2");
		set_module_pref("reset",1,"signetd2");
		if (get_module_pref("powersignet","signetd5")==1) redirect("runmodule.php?module=signetd5&op=eg1b");
		else redirect("runmodule.php?module=signetd3&loc=".get_module_pref('pqtemp'));
	}	
	if ($op=="1097"){	
		output("A mean looking old man says `#'Leave!'");
		addnav("Leave","runmodule.php?module=signetd3&loc=".(get_module_pref('pqtemp')-68));
		addnav("Fight the Old Man","runmodule.php?module=signetd3&op=oldman");		
	}
	if ($op=="931"){
		output("You see an ornate treasure chest.");
		addnav("Open It","runmodule.php?module=signetd3&op=931b");
		addnav("Leave","runmodule.php?module=signetd3&loc=".(get_module_pref('pqtemp')-34));
	}
	if ($op=="931b"){
		output("You find a scroll!");
		set_module_pref("loc931",1);
		set_module_pref("scroll5",1);
		addnav("Continue","runmodule.php?module=signetd3&loc=".get_module_pref('pqtemp'));
		addnav("Read Scroll 5","runmodule.php?module=signetd3&op=scroll5b");
	}
	if ($op=="619"){	
		output("A bunch of rowdy soldiers yell `#'Go away punk!'`0");
		addnav("Leave","runmodule.php?module=signetd3&loc=".(get_module_pref('pqtemp')-2));
		addnav("Stay","runmodule.php?module=signetd3&op=soldiers");
	}
	if ($op=="483"){	
		output("A group of men in robes say `#'You are in the wrong room.'`0");
		addnav("Leave","runmodule.php?module=signetd3&loc=".(get_module_pref('pqtemp')-2));
		addnav("Stay","runmodule.php?module=signetd3&op=mages");
	}
	if ($op=="fall"){	
		output("The floor opens and you fall to a stone surface and slide into a small room.`n`n");
		$loss=round($session['user']['maxhitpoints']*e_rand(2,10)/100);
		$session['user']['hitpoints']-=$loss;
		if ($session['user']['hitpoints']<=0){
			output("You have `\$died`0 from the fall.  You lose all your `^gold`0 and `#10% of your experience`0.");
			$session['user']['hitpoints']=0;
			$session['user']['gold']=0;
			$session['user']['experience']*=.9;
			$session['user']['alive']=false;
			addnav("Continue","shades.php");			
		}else{
			output("You have suffered `\$%s hitpoints`0 of damage from the fall.",$loss);
			set_module_pref("pqtemp",445);
			addnav("Continue","runmodule.php?module=signetd3&loc=".get_module_pref('pqtemp'));	
		}
	}
	if ($op=="221"){
		output("A large door blocks your way. Smash it down?");
		addnav("Leave","runmodule.php?module=signetd3&loc=".(get_module_pref('pqtemp')+34));
		addnav("Smash Door","runmodule.php?module=signetd3&op=door");
	}
	if ($op=="11"){
		output("You see a");
		if (get_module_pref("loc11c")==0) {
			addnav("Pull Lever","runmodule.php?module=signetd3&op=11c");
			output("lever on the wall and");
		}else{
			output("lever that was pulled and");
		}
		if (get_module_pref("loc11b")==0) {
			addnav("Search the Box","runmodule.php?module=signetd3&op=11b");
			output("a box on the floor.");
		}else{
			output("the empty box on the floor.");
		}
		addnav("Leave","runmodule.php?module=signetd3&loc=".(get_module_pref('pqtemp')-1));
	}
	if ($op=="11b"){
		$gold=e_rand(500,1500);
		$gems=e_rand(2,5);
		$session['user']['gold']+=$gold;
		$session['user']['gems']+=$gems;
		output("You search through the box and find a very generous treasure.");
		output("`n`nYou find `^%s gold`0 and `%%s gems`0!",$gold,$gems);
		set_module_pref("loc11b",1);
		if (get_module_pref("loc11c")==1) set_module_pref("loc11",1);
		else addnav("Leave","runmodule.php?module=signetd3&loc=".(get_module_pref('pqtemp')-1));
		addnav("Continue","runmodule.php?module=signetd3&loc=".get_module_pref('pqtemp'));
	}
	if ($op=="11c"){
		output("You pull the lever and hear the sound of masonry falling in the far distance.");
		output("`n`nDoesn't it make you wonder what just happened?");
		set_module_pref("loc11c",1);
		if (get_module_pref("loc11b")==1) set_module_pref("loc11",1);
		else addnav("Leave","runmodule.php?module=signetd3&loc=".(get_module_pref('pqtemp')-1));
		addnav("Continue","runmodule.php?module=signetd3&loc=".get_module_pref('pqtemp'));
	}
	if ($op=="prisondoor"){
		if (get_module_pref("prisonkey")==1){
			output("You use the key from the prison guard to unlock the cell.");
			if (get_module_pref("pqtemp")==148) set_module_pref("loc148",1);
			if (get_module_pref("pqtemp")==82) set_module_pref("loc82",1);
			if (get_module_pref("pqtemp")==87) set_module_pref("loc87",1);
			addnav("Continue","runmodule.php?module=signetd3&loc=".get_module_pref('pqtemp'));
		}else{
			output("The prison cell door is locked.  Would you like to pick the lock or bash down the door?");
			addnav("Bash Door","runmodule.php?module=signetd3&op=bash");
			addnav("Pick Lock","runmodule.php?module=signetd3&op=pick");
			if (get_module_pref("pqtemp")==148) addnav("Leave","runmodule.php?module=signetd3&loc=".(get_module_pref('pqtemp')+1));
			if (get_module_pref("pqtemp")==82 || get_module_pref("pqtemp")==87 ) addnav("Leave","runmodule.php?module=signetd3&loc=".(get_module_pref('pqtemp')+34));
		}
	}
	if ($op=="bash"){
		output("You start banging on the prison door.");
		output("`n`nFor 10 minutes you hit your shoulder against the door and finally... well, finally, nothing happens.");
		output("`n`nThis is, after all, a prison cell door.");
		output("`n`nYou feel a tap on your shoulder and realize that you've gotten the attention of the prison guard.");
		addnav("Fight Guard","runmodule.php?module=signetd3&op=guard");
	}
	if ($op=="pick"){
		output("You start working on picking the lock of the prison door.");
		if (get_module_pref("skill","specialtythiefskills")>0) {
			$expmultiply = e_rand(10,20);
			$expbonus=$session['user']['dragonkills']*1.5;
			$expgain =round($session['user']['level']*$expmultiply+$expbonus);
			$session['user']['experience']+=$expgain;			
			output("Using your special thieving skills, you are able to pick the lock.");
			output("`n`nYou `#gain %s experience`0 by using your skills.",$expgain);
			addnav("Continue","runmodule.php?module=signetd3&loc=".get_module_pref('pqtemp'));
			if (get_module_pref("pqtemp")==148) set_module_pref("loc148",1);
			if (get_module_pref("pqtemp")==82) set_module_pref("loc82",1);
			if (get_module_pref("pqtemp")==87) set_module_pref("loc87",1);
		}else{
			output("Not being a very good thief, you fail at picking the lock.");
			if ($session['user']['turns']>0){
				output("You `@lose one turn`0 trying to open the door.");
				$session['user']['turns']--;
			}
			output("`n`nAfter a frustrating amount of wasted time, you feel a tap on your shoulder.  It seems like the prison guard has been watching you.");
			addnav("Fight Guard","runmodule.php?module=signetd3&op=guard");
		}
	}
	if ($op=="48"){
		output("Two elves in this cell tell you `#'The key to the other cell is west of the Great Hall.'`0");
		addnav("Continue","runmodule.php?module=signetd3&loc=".get_module_pref('pqtemp'));
		set_module_pref("loc48",1);
	}
	if ($op=="53"){
		output("A Goblin gratefully thanks you for his freedom.");
		addnav("Continue","runmodule.php?module=signetd3&loc=".get_module_pref('pqtemp'));
		set_module_pref("loc53",1);
	}
	if ($op=="157"){
		if (get_module_pref("loc352")==0){
			output("No matter what you do you can't open this door.  It seems like you'll have to find a key somewhere.");
			addnav("Leave","runmodule.php?module=signetd3&loc=".(get_module_pref('pqtemp')-1));
		}else{
			output("Your key opens the cell door.");
			set_module_pref("loc157",1);
			addnav("Continue","runmodule.php?module=signetd3&loc=".get_module_pref('pqtemp'));
		}
	}
	if ($op=="159"){
		output("The old man awakens and says `#'Thank you brave adventurers.");
		output("I am Lord Wasser's aid and the castle has been overtaken by Fiamma.'");
		output("`n`n`0He Continues `#'You should go to the fortress of Fiamma to get the `QFire Signet`#.");
		output("To aid you I give you this,'`0 he says handing you a bag full of gems.`n`n `#'Remember'`0 he adds, `#'The fortress is well guarded.'`0");
		output("`n`nYou gain `%3 gems`0!");
		$session['user']['gems']+=3;
		set_module_pref("loc159",1);
		addnav("Continue","runmodule.php?module=signetd3&loc=".get_module_pref('pqtemp'));		
	}
	if ($op=="331"){
		output("The door is locked.  Would you like to try to pick the lock?");
		addnav("Leave","runmodule.php?module=signetd3&loc=".(get_module_pref('pqtemp')-34));
		addnav("Pick Lock","runmodule.php?module=signetd3&op=331b");	
	}
	if ($op=="331b"){
		if($session['user']['level']>13) $trap=4;
		elseif($session['user']['level']>10) $trap=3;
		elseif($session['user']['level']>7) $trap=2;
		elseif($session['user']['level']>4) $trap=1;
		else $trap=1;
		if (get_module_pref("skill","specialtythiefskills")>0){
			output("You're thieving skills help with your attempt...`n`n");
			$trap+=1;
		}
		switch(e_rand($trap,10)){
			case 1:
			case 2:
			case 3:
			case 4:
			case 5:
				output("You're unable to pick the lock... in fact it appears to be trapped!");
				$hitpoints=round($session['user']['maxhitpoints']*.08);
				if ($hitpoints>0) output("`n`nA cloud of `@poison gas`0 explodes from the trap.  You struggle to breath as you feel a burn in your lungs. You `\$lose %s hitpoint%s`0.`n`n",$hitpoints,translate_inline($hitpoints>1?"s":""));
				$session['user']['hitpoints']-=$hitpoints;
				increment_module_pref("pqtemp",-34);
				if ($session['user']['hitpoints']<=0){
					output("You have `\$died`0 from the gas.  You lose all your `^gold`0 and `#10% of your experience`0.");
					$session['user']['hitpoints']=0;
					$session['user']['gold']=0;
					$session['user']['experience']*=.9;
					$session['user']['alive']=false;
					addnav("Continue","shades.php");
					blocknav("runmodule.php?module=signetd3&loc=".get_module_pref('pqtemp'));
				}
			break;
			case 6:
			case 7:
			case 8:
			case 9:
			case 10:
				output("You successfully unlock the door.`n`n");
				set_module_pref("loc331",1);
			break;
		}
		addnav("Continue","runmodule.php?module=signetd3&loc=".get_module_pref('pqtemp'));
	}
	if ($op=="635"){
		$gems=e_rand(2,3);
		$session['user']['gems']+=$gems;
		output("You look under the bed and find `%%s gems`0.",$gems);
		set_module_pref("loc635",1);
		addnav("Continue","runmodule.php?module=signetd3&loc=".get_module_pref('pqtemp'));
	}
	if ($op=="537"){
		output("You see some graffiti on the wall.  Would you like to read it?");
		addnav("Read Graffiti","runmodule.php?module=signetd3&op=537b");	
		addnav("Leave","runmodule.php?module=signetd3&loc=".(get_module_pref('pqtemp')-1));
	}
	if ($op=="537b"){
		if (get_module_pref("loc537")==0) output("The graffiti on the wall says `#'I bet you thought we'd leave something valuable in the closet, didn't you?'");
		if (get_module_pref("loc537")==1) output("Below, more graffiti reads `#'Seriously, did you think there would be a hidden shelf?'");
		if (get_module_pref("loc537")==2) output("Below, more graffiti reads `#'Okay, there is no hidden shelf.  Go away.'");
		if (get_module_pref("loc537")==3) output("Below, more graffiti reads `#'GO AWAY!'");
		if (get_module_pref("loc537")==4) output("Below, more graffiti reads `#'You're getting annoying.'");
		if (get_module_pref("loc537")==5) output("Below, more graffiti reads `#'Fine, do you want me to tell you a story?  There was an adventurer that kept reading walls.  Nothing happened.  Now go away.'");
		if (get_module_pref("loc537")==6) output("Below, more graffiti reads `#'Look out! It's a trap!!!!'`n`n`n`n`n`n`n`n`n`n`n`n`n`n`n'Just kidding!'");
		if (get_module_pref("loc537")==7) output("Below, more graffiti reads `#'You're a persistent little bugger, aren't you?'");
		if (get_module_pref("loc537")==8) {
			output("Below, more graffiti reads `#'Fine, I give up.  You can have a `%gem`# if you'll go away.'");
			$session['user']['gems']++;
			output("`n`n`0You find a `%gem`0.");
		}
		if (get_module_pref("loc537")==9) {
			output("Below, more graffiti reads `#'I told you that you could have the `%gem`# only if you went away.  Now I'm taking your `%gem`# back.'");
			$session['user']['gems']--;
			output("`n`n`0You look at the wall and laugh, but drop the `%gem`0 you just found.  Oh my, you've lost your `%gem`0!");
		}
		if (get_module_pref("loc537")>=10) output("There's no more graffiti to read.");
		addnav("Leave","runmodule.php?module=signetd3&loc=".(get_module_pref('pqtemp')-1));
		increment_module_pref("loc537",1);
	}
	if ($op=="745"){
		output("You enter the room of `!Magic Pools`0 and you're attacked by a very powerful `!Guardian Water Elemental`0.");
		addnav("Fight Water Elemental","runmodule.php?module=signetd3&op=waterelemental");	
		addnav("Run Away!","runmodule.php?module=signetd3&loc=".(get_module_pref('pqtemp')-1));
	}
	if ($op=="746"){
		output("`&William the Wise`0 is standing here.  He is the keeper of the `!Water Signet`0.");
		output("`n`nHe says `#'I give thee the `!Water Signet`#; the most sacred of the `3E`Ql`!e`\$m`3e`Qn`!t`\$a`3l`^ Signets`#.'");
		set_module_pref("watersignet",1);
		set_module_pref("loc746",1);
		addnews("`@%s`@ was marked with the `!Water Signet`@ in `^Wasser's Castle`@.",$session['user']['name']);
		addnav("Continue","runmodule.php?module=signetd3&loc=".get_module_pref('pqtemp'));
	}
	if ($op=="839"){
		output("Here is a large wooden box.  What would you like to do?");
		addnav("Open the Box","runmodule.php?module=signetd3&op=839b");	
		addnav("Leave","runmodule.php?module=signetd3&loc=".(get_module_pref('pqtemp')+1));
	}
	if ($op=="839b"){
		output("You carefully open the box to find...`n`n");
		$gold=e_rand(500,1000);
		if ($session['user']['gold']>1000) {
			$session['user']['gold']+=$gold*2;
			output("`^%s gold`0 and",$gold*2);
		}else{
			output("`^%s gold`0 and",$gold);
			$session['user']['gold']+=$gold;
		}
		$gems=e_rand(2,4);
		$session['user']['gems']+=$gems;
		output("`%%s gems`0!",$gems);
		addnav("Continue","runmodule.php?module=signetd3&loc=".get_module_pref('pqtemp'));
		set_module_pref("loc839",1);
	}
	if ($op=="352"){
		output("Here is a treaure chest.  What would you like to do?");
		addnav("Open the Chest","runmodule.php?module=signetd3&op=352b");	
		addnav("Leave","runmodule.php?module=signetd3&loc=".(get_module_pref('pqtemp')+1));
	}
	if ($op=="352b"){
		output("You find a large key.  There's got to be some use for this key!");
		set_module_pref("loc352",1);
		addnav("Continue","runmodule.php?module=signetd3&loc=".get_module_pref('pqtemp'));
	}
	if ($op=="354"){
		output("Here is a treasure chest here but it appears to be trapped.  What would you like to do?");
		addnav("Disarm the Trap","runmodule.php?module=signetd3&op=354b");	
		addnav("Leave","runmodule.php?module=signetd3&loc=".(get_module_pref('pqtemp')-1));
	}
	if ($op=="354b"){
		$gold=e_rand(250,1000);
		$session['user']['gold']+=$gold;
		$gems=e_rand(2,4);
		$session['user']['gems']+=$gems;
		output("You were mistaken.  There weren't any traps.`n`nYou carefully open the box to find `^%s gold`0 and `%%s gems`0!",$gold,$gems);
		addnav("Continue","runmodule.php?module=signetd3&loc=".get_module_pref('pqtemp'));
		set_module_pref("loc354",1);
	}
	if ($op=="1079"){
		output("The door is locked.  Would you like to try to pick the lock?");
		addnav("Leave","runmodule.php?module=signetd3&loc=".(get_module_pref('pqtemp')-34));
		addnav("Pick Lock","runmodule.php?module=signetd3&op=1079b");	
	}
	if ($op=="1079b"){
		if($session['user']['level']>13) $trap=4;
		elseif($session['user']['level']>10) $trap=3;
		elseif($session['user']['level']>7) $trap=2;
		elseif($session['user']['level']>4) $trap=1;
		else $trap=1;
		if (get_module_pref("skill","specialtythiefskills")>0){
			output("You're thieving skills help with your attempt...`n`n");
			$trap+=1;
		}
		switch(e_rand($trap,10)){
			case 1:
			case 2:
			case 3:
			case 4:
			case 5:
				output("You're unable to pick the door lock... and it looks like it was trapped!");
				$hitpoints=round($session['user']['maxhitpoints']*.08);
				if ($hitpoints>0) output("`n`nA cloud of `@poison gas`0 explodes from the trap.  You struggle to breath as you feel a burn in your lungs. You `\$lose %s hitpoint%s`0.`n`n",$hitpoints,translate_inline($hitpoints>1?"s":""));
				$session['user']['hitpoints']-=$hitpoints;
				increment_module_pref("pqtemp",-34);
				if ($session['user']['hitpoints']<=0){
					output("You have `\$died`0 from the gas.  You lose all your `^gold`0 and `#10% of your experience`0.");
					$session['user']['hitpoints']=0;
					$session['user']['gold']=0;
					$session['user']['experience']*=.9;
					$session['user']['alive']=false;
					addnav("Continue","shades.php");
					blocknav("runmodule.php?module=signetd3&loc=".get_module_pref('pqtemp'));
				}
			break;
			case 6:
			case 7:
			case 8:
			case 9:
			case 10:
				output("You successfully pick the lock.`n`n");
				set_module_pref("loc1079",1);
			break;
		}
		addnav("Continue","runmodule.php?module=signetd3&loc=".get_module_pref('pqtemp'));
	}
	if ($op=="625"){
		output("Down the hall you see several ogres having a meeting.  They see you and run up the hall.");
		addnav("Fight Ogres","runmodule.php?module=signetd3&op=ogres");	
	}
	//the scrolls
	if ($op=="scroll1b"){
		output("`c`b`^The Aria Dungeon`0`c`b`n");
		output("The Aria Dungeon was once the center of a small community of dwarves.  About 15 years ago, a band of orcs invaded the community and defeated the dwarves.");
		output("`n`nIt is said that only the leader of the dwarves, Kilmor, and a few others escaped from the Orcs.");
		addnav("Return","runmodule.php?module=signetd3&loc=".get_module_pref('pqtemp'));
	}
	if ($op=="scroll2b"){
		output("`c`b`^The Historical Scrolls of the `3E`Ql`!e`\$m`3e`Qn`!t`\$a`3l`^ Signets`0`c`b`n");
		output("Although there had until recently been general peace across the land, the evil sorcerer Mierscri has brought his great army of men and beasts to terrorize the land.");
		output("This great force laid waste to the land and its people. Soon, the battle would be over.");
		output("`n`nHowever, before this could happen, a coalition of the four greatest wizards of the land came together to end the reign of evil.");
		output("The wizards created 4 signets; each representing the great forces of nature:  `3Air`0, `QEarth`0, `!Water`0, and `\$Fire`0.");
		output("When one warrior was able to harness the power of these four signets, then the evil could be stopped.");
		output("`n`nMierscri learned of the plan and captured the four wizards before a warrior could be chosen to receive the signets.  His evil spells turned the wizards into Warlocks of great power but completely under his control.");
		output("`n`nPerhaps one day a warrior will be able to gather the four signets in order to finally defeat the evil Mierscri.");
		addnav("Return","runmodule.php?module=signetd3&loc=".get_module_pref('pqtemp'));
	}
	if ($op=="scroll3b"){
		output("`c`b`^Prison Notes by Kilmor`0`c`b`n");
		output("The Orcs are less than wonderful captors. I hope to be able to break free soon.");
		output("My first journey will be to the `^Temple of the Aarde Priests`0.  It is rumored that the high priest of the temple has the power of prophesy, but few have been allowed to see him.");
		addnav("Return","runmodule.php?module=signetd3&loc=".get_module_pref('pqtemp'));
	}
	if ($op=="scroll4b"){
		output("`c`b`^Report from Evad the Sage`c`b");
		output("`n`0In `\$Fiamma's Fortress`0 there is a secret control room which can be accessed from one of two secret passages.");
		output("The first starts in `\$Fiamma's`0 room.  The other starts between the arena and the jail cell.");
		output("From this room various gates around the castle can be operated.");
		addnav("Continue","runmodule.php?module=signetd3&loc=".get_module_pref('pqtemp'));
	}
	if ($op=="scroll5b"){
		output("`c`b`^The Story of Fiamma Fortress`c`b");
		output("`n`0Many years ago when Mierscri was invading the land, the men and beasts put aside their differences and joined together to fight him.");
		output("`n`nThe lowly Fiamma, who was an officer in this combined army, told Mierscri of the plan; thus it failed.");
		output("`n`nAs a reward for this action, Fiamma was given a great fortress and given the Fire Signet to guard over.");
		addnav("Continue","runmodule.php?module=signetd3&loc=".get_module_pref('pqtemp'));
	}
	//Scrolls for in the bio start here

	if ($op=="scroll5"){
		$userid = httpget("user");
		output("`c`b`^The Story of Fiamma Fortress`c`b");
		output("`n`0Many years ago when Mierscri was invading the land, the men and beasts put aside their differences and joined together to fight him.");
		output("`n`nThe lowly Fiamma, who was an officer in this combined army, told Mierscri of the plan; thus it failed.");
		output("`n`nAs a reward for this action, Fiamma was given a great fortress and given the Fire Signet to guard over.");
		addnav("Return to Signets","runmodule.php?module=signetsale&op=signetnotes&user=$userid");
	}
	page_footer();
}
?>