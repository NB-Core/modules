<?php
/*
Module Name: signetd2.php
Category: Signet Series
Worktitle: Signet Maze 2: Aarde Priests Temple
Author: DaveS
Date:  February 26, 2006

Based on the code for Abandoned Castle by Lonnyl

Requires:
signetsale.php

Additional Modules for full function:
signetd1.php, signetd3.php, signetd4.php, and signetd5.php

Description:
Second of the Signet Elemental Dungeon series. 
The dungeons are based on a game from 1985 called Phantasie. 
Use the teleporters to get around... but be careful because danger lurks in the coffins!  
Visit the High Priest and get closer to solving the mystery of the Elemental Signets!

*/
require_once("lib/fightnav.php");
function signetd2_getmoduleinfo(){
	$info = array(
		"name"=>"Signet Maze 2: `QAarde Temple",
		"version"=>"4.14",
		"author"=>"DaveS",
		"category"=>"Signet Series",
		"download"=>"http://dragonprime.net/index.php?module=Downloads;sa=dlview;id=972",
		"vertxtloc"=>"",
		"settings"=>array(
			"Aarde Temple Settings,title",
			"random"=>"How many random monsters can be encountered in the temple?,int|5",
			"randenc"=>"Likelihood of random encounter:,enum,1,Common,5,Uncommon,10,Rare,15,Very Rare,20,Extremely Rare|10",
			"healing"=>"Allow for players to have a chance to find a partial healing potion after fights?,bool|1",
			"impalign"=>"Allow players to improve alignment by donating to temple?,bool|0",
			"costalign"=>"Cost in gold for each point to improve alignment if allowed?,int|1000",
			"Note:  Do not make this too expensive because it has other implications to finishing the module,note",
			"alignmax"=>"Max number of alignment points that can be improved?,int|20",
			"nodonate"=>"Number of times no donation has been offered:,int|0",
			"earthmaploc"=>"Where does the Aarde Temple appear?,location|".getsetting("villagename", LOCATION_FIELDS),
			"`\$Note: There are no Emergency Exits in the Aarde Temple due to the ease of use of teleporters,note",
		),
		"prefs"=>array(
			"Aarde Temple Preferences,title",
			"complete"=>"Has player completed the temple?,bool|0",
			"reset"=>"Have the preferences been reset by visiting Wasser's Castle?,bool|0",
			"super"=>"Does player have superuser access to the temple?,bool|0",
			"Encounters,title",
			"randomp"=>"How many random monsters has player encountered so far?,int|0",
			"earthsignet"=>"*`QReceived the Earth Signet?,bool|0",
			"scroll4"=>"*Found Scroll 4?,bool|0",
			"loc334"=>"*Passed Location 334?,bool|0",
			"loc685"=>"*Passed Location 685?,enum,0,No,1,Yes,2,In Process|0",
			"* Finish these points and the temple will be closed to this player,note",
			"loc1098"=>"Ready to see the High Priest?,bool|0",
			"donated"=>"How much has the player donated?,int|0",
			"donatenum"=>"How many times has the player donated?,int|0",
			"loc55"=>"Passed Location 55?,enum,0,No,1,Yes,2,In Process|0",
			"loc59"=>"Passed Location 59?,enum,0,No,1,Yes,2,In Process|0",			
			"loc82"=>"Passed Location 82?,enum,0,No,1,Yes,2,In Process|0",
			"loc109"=>"Passed Location 109?,bool|0",
			"loc109b"=>"Passed Location 109b?,bool|0",
			"loc163"=>"Passed Location 163?,bool|0",
			"loc279"=>"Passed Location 279?,enum,0,No,1,Yes,2,In Process|0",
			"loc327"=>"Passed Location 327?,enum,0,No,1,Yes,2,In Process|0",
			"loc334b"=>"Passed Location 334b?,bool|0",
			"loc381"=>"Passed Location 381?,bool|0",
			"loc386"=>"Passed Location 386?,enum,0,No,1,Yes,2,In Process|0",
			"loc496"=>"Passed Location 496?,bool|0",
			"loc537"=>"Passed Location 537?,enum,0,No,1,Yes,2,In Process|0",
			"loc537b"=>"Passed Location 537b?,bool|0",
			"loc556"=>"Passed Location 556?,bool|0",
			"loc776"=>"Passed Location 776?,bool|0",
			"loc822"=>"Passed Location 822?,enum,0,No,1,Yes,2,In Process|0",
			"loc841"=>"Passed Location 841?,bool|0",
			"loc843"=>"Passed Location 843?,bool|0",
			"loc865"=>"Passed Location 865?,enum,0,No,1,Yes,2,In Process|0",
			"loc890"=>"Passed Location 890?,enum,0,No,1,Yes,2,In Process|0",
			"loc946"=>"Passed Location 946?,enum,0,No,1,Yes,2,In Process|0",
			"loc947"=>"Passed Location 947?,enum,0,No,1,Yes,2,In Process|0",
			"loc956"=>"Passed Location 956?,enum,0,No,1,Yes,2,In Process|0",
			"loc970"=>"Passed Location 970?,enum,0,No,1,Yes,2,In Process|0",
			"loc1010"=>"Passed Location 1010 without key?,enum,0,No,1,Yes,2,In Process|0",
			"loc1010b"=>"Passed Location 1010b with key?,bool|0",
			"loc1012"=>"Passed Location 1012?,enum,0,No,1,Yes,2,In Process|0",
			"loc1026"=>"Passed Location 1026?,enum,0,No,1,Yes,2,In Process|0",
			"loc1082"=>"Passed Location 1082?,bool|0",
			"loc1098"=>"Passed Location 1082?,bool|0",
			"loc1147"=>"Passed Location 1147?,enum,0,No,1,Yes,2,In Process|0",
			"loc1148"=>"Passed Location 1148?,bool|0",
			"Maze View Only,title",
			"maze"=>"Maze,viewonly",
			"mazeturn"=>"Maze Return,int|",
			"pqtemp"=>"Temporary Information,int|",
			"header"=>"Which header array is the player at?,viewonly|0",
		),
		"requires"=>array(
			"signetsale" => "4.14| by DaveS, http://dragonprime.net/index.php?module=Downloads;sa=dlview;id=972",
		),
	);
	return $info;
}

function signetd2_install(){
	module_addhook("village");
	module_addhook("scrolls-signetsale");
	return true;
}

function signetd2_uninstall(){
	return true;
}

function signetd2_dohook($hookname,$args){
	global $session;
	$userid = $session['user']['acctid'];
	switch($hookname){
	case "village":
		if ($session['user']['location'] == get_module_setting("earthmaploc") && get_module_pref("earthsigmap","signetsale")==1  && get_module_pref("complete")==0){
			tlschema($args['schemas']['tavernnav']);
			addnav($args['tavernnav']);
    		tlschema();
			addnav("Aarde Temple","runmodule.php?module=signetd2");
		}
	break;
	case "scrolls-signetsale":
		$userid2 = httpget("user");
		if ($userid2==$userid){
			if (get_module_pref("scroll4","signetd2")==1) addnav("Scroll 4","runmodule.php?module=signetd2&op=scroll4&user=$userid");		
		}
	break;
	}
	return $args;
}
function signetd2_run(){
	global $SCRIPT_NAME;
	if ($SCRIPT_NAME == "runmodule.php"){
		$module=httpget("module");
		if ($module == "signetd2") {
			require_once("modules/signet/signetd2_func.php");
			include("modules/signet/signetd2.php");
		}
	}
}
?>