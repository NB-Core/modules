The Signet Series Dungeons:

This is a pack of five dungeons and a storefront (six modules total). 
The storefront is used to purchase the maps.

Current Version: 4.14

Release Notes:
V 4.0 	Released all dungeons as a package with repairs to multiple modules
V 4.01 	Fixed disfunctional banner display in dungeon 5
v 4.02 	Added clear_module_pref for completion of modules. Also tweaked signetsale.php
v 4.03  Added option to return to dungeon at the emergency exit locations, many little tweaks
v 4.04	Added option to repeat the dungeons after setting number of dks
v 4.05	Fixed a map error in d4 and a nav error for the HoF
v 4.06  Fixed replay calculation
v 4.07  Kickme Fixes!
v 4.08  Removed and fixed some remnants from coding
v 4.09  Fixed a problem with the replay calculation (thanks umk)
v 4.1   Fixed return from exit error in dungeon 5 and Contine typos
v 4.11  Added a setting for people to see a new HoF by Aelia and addnews to Fiamma's Fortress with Signet discovery
v 4.12  Fixes by Kickme integrated
v 4.13 	Aelia HoF repairs
v 4.14  Wasser castle fixed return location

The dungeons are based on a game from 1985 called Phantasie.

Goal:
Explore the first four dungeons to collect the four elemental signets.  Then go to the fifth
dungeon to take on the Evil Lord.

How to install the Signet Series Dungeons:
Drop all files (except the readme.txt file which may be deleted) into your modules folder.
Install the signetsale.php module (all other modules require its installation)
Install signetd1, signetd2, signet d3, signet d4, and signetd5

NOTE:
If you have previously installed the dungeons before this final release you may delete all
the files from previous releases.  I have consolidated the image files into one file and
placed all the files in a single subdirectory.

Advice for Administrators:
1.  Spread out the dungeons if you have multiple cities.
2.  Carefully consider if you want to change the prices of the maps in the map store;
I wrote that module with the default prices to balance out the experience gained without 
losing forest fights in the dungeons.
3.  Review the reward for killing the final Boss in the 5th Dungeon.  There are many
settings that allow you to customize the rewards based on the balance in your server.
4.  Feel free to make any changes to the files that you want to customize the dungeons
for your server.  If you have suggestions or find errors, please contact me on dragon prime
or at my email address (ds394 at hotmail.com).

Enjoy!

DaveS