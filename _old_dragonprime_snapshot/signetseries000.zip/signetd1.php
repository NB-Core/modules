<?php
/*
Module Name: signetd1.php
Category: Signet Series
Worktitle: Signet Maze 1: Aria
Author: DaveS
Date:  February 21, 2006

Based on the code for Abandoned Castle by Lonnyl

Requires:
signetsale.php

Additional Modules for full function:
signetd2.php, signetd3.php, signetd4.php, and signetd5.php

Description:
First of the Signet Elemental Dungeons series.
The dungeons are based on a game from 1985 called Phantasie.
Obtain scrolls, search secret passage ways, disarm traps, pull levers... 
Excitement around every corner!

*/
require_once("lib/fightnav.php");
function signetd1_getmoduleinfo(){
	$info = array(
		"name"=>"Signet Maze 1: `3Aria Dungeon",
		"version"=>"4.14",
		"author"=>"DaveS",
		"category"=>"Signet Series",
		"download"=>"http://dragonprime.net/index.php?module=Downloads;sa=dlview;id=972",
		"vertxtloc"=>"",
		"settings"=>array(
			"Aria Dungeon Settings,title",
			"random"=>"How many random monsters can be encountered in the dungeon?,int|5",
			"randenc"=>"Likelihood of random encounter:,enum,1,Common,5,Uncommon,10,Rare,15,Very Rare,20,Extremely Rare|10",
			"healing"=>"Allow for players to have a chance to find a partial healing potion after fights?,bool|1",
			"airmaploc"=>"Where does the Air Dungeon appear?,location|".getsetting("villagename", LOCATION_FIELDS),
			"exitsave"=>"Allow users to return to the dungeon from an emergency exit?,enum,0,No,1,Yes,2,Require|0",
			"`\$Note: If you chose 'Require' then players MUST come back in at the same location that they leave from; otherwise players will have a choice to come back through the main entrance or the exit location,note",
		),
		"prefs"=>array(
			"Aria Dungeon Preferences,title",
			"complete"=>"Has player completed the dungeon?,bool|0",
			"reset"=>"Have the preferences been reset by visiting Aarde Temple?,bool|0",
			"super"=>"Does player have superuser access to the dungeon?,bool|0",
			"Encounters,title",
			"randomp"=>"How many random monsters has player encountered so far?,int|0",
			"airsignet"=>"*`3Received the Air Signet?,bool|0",
			"scroll2"=>"*Found Scroll 2?,bool|0",
			"scroll3"=>"*Found Scroll 3?,bool|0",
			"loc411"=>"*Passed Location 411?,bool|0",
			"* Finish these points and the dungeon will be closed to this player,note",
			"loc54"=>"Passed Location 54?,enum,0,No,1,Yes,2,In Process|0",
			"loc113"=>"Passed Location 113?,bool|0",
			"loc113b"=>"Passed Location 113b?,bool|0",
			"loc303"=>"Passed Location 303?,bool|0",
			"loc333"=>"Passed Location 333?,bool|0",
			"loc453"=>"Passed Location 453?,enum,0,No,1,Yes,2,In Process|0",
			"loc465"=>"Passed Location 465?,enum,0,No,1,Yes,2,In Process|0",
			"loc494"=>"Passed Location 494?,enum,0,No,1,Yes,2,In Process|0",
			"loc521"=>"Passed Location 521?,enum,0,No,1,Yes,2,In Process|0",
			"loc593"=>"Passed Location 593?,enum,0,No,1,Yes,2,In Process|0",
			"loc623"=>"Passed Location 623?,enum,0,No,1,Yes,2,In Process|0",
			"loc673"=>"Passed Location 673?,enum,0,No,1,Yes,2,In Process|0",
			"loc677"=>"Passed Location 677?,bool|0",
			"loc685"=>"Passed Location 685?,bool|0",
			"loc689"=>"Passed Location 689?,enum,0,No,1,Yes,2,In Process|0",
			"loc711"=>"Passed Location 711?,bool|0",
			"loc759"=>"Passed Location 759?,bool|0",
			"loc787"=>"Passed Location 787?,enum,0,No,1,Yes,2,In Process|0",
			"loc891"=>"Passed Location 891?,bool|0",
			"loc899"=>"Passed Location 899?,enum,0,No,1,Yes,2,In Process|0",
			"loc973"=>"Passed Location 973?,enum,0,No,1,Yes,2,In Process|0",
			"loc983"=>"Passed Location 983?,enum,0,No,1,Yes,2,In Process|0",
			"loc1006"=>"Passed Location 1006?,enum,0,No,1,Yes,2,In Process|0",
			"loc1008"=>"Passed Location 1008?,enum,0,No,1,Yes,2,In Process|0",
			"loc1009"=>"Passed Location 1009?,enum,0,No,1,Yes,2,In Process|0",
			"loc1011"=>"Passed Location 1011?,bool|0",
			"loc1015"=>"Passed Location 1015?,enum,0,No,1,Yes,2,In Process|0",
			"loc1133"=>"Passed Location 1133?,bool|0",
			"loc1152"=>"Passed Location 1152?,enum,0,No,1,Yes,2,In Process|0",
			"loc1197"=>"Passed Location 1197?,enum,0,No,1,Yes,2,In Process|0",
			"loc1199"=>"Passed Location 1199?,bool|0",
			"loc1216"=>"Passed Location 1216?,enum,0,No,1,Yes,2,In Process|0",
			"loc1287"=>"Passed Location 1287?,bool|0",
			"loc1133b"=>"Attempted to attack the old man?,bool|0",
			"Maze View Only,title",
			"maze"=>"Maze,viewonly|",
			"mazeturn"=>"Maze Return,viewonly|0",
			"pqtemp"=>"Temporary Information,int|",
			"startloc"=>"Starting location,int|1279",
			"header"=>"Which header array is the player at?,viewonly|0",
		),
		"requires"=>array(
			"signetsale" => "4.14| by DaveS, http://dragonprime.net/index.php?module=Downloads;sa=dlview;id=972",
		),
	);
	return $info;
}

function signetd1_install(){
	module_addhook("village");
	module_addhook("scrolls-signetsale");
	return true;
}

function signetd1_uninstall(){
	return true;
}

function signetd1_dohook($hookname,$args){
	global $session;
	$userid = $session['user']['acctid'];
	switch($hookname){
	case "village":
		if ($session['user']['location'] == get_module_setting("airmaploc") && get_module_pref("airsigmap","signetsale")==1 && get_module_pref("complete")==0){
			tlschema($args['schemas']['tavernnav']);
			addnav($args['tavernnav']);
    		tlschema();
			addnav("Aria Dungeon","runmodule.php?module=signetd1");
		}
	break;
	case "scrolls-signetsale":
		$userid2 = httpget("user");
		if ($userid2==$userid){
			if (get_module_pref("scroll2","signetd1")==1) addnav("Scroll 2","runmodule.php?module=signetd1&op=scroll2&user=$userid");		
			if (get_module_pref("scroll3","signetd1")==1) addnav("Scroll 3","runmodule.php?module=signetd1&op=scroll3&user=$userid");		
		}
	break;
	}
	return $args;
}
function signetd1_run(){
	global $SCRIPT_NAME;
	if ($SCRIPT_NAME == "runmodule.php"){
		$module=httpget("module");
		if ($module == "signetd1") {
			require_once("modules/signet/signetd1_func.php");
			include("modules/signet/signetd1.php");
		}
	}
}
?>