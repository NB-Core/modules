<?php
/*
Module Name: signetsale.php
Category: Signet Series
Worktitle: Signet Sale
Author: DaveS
Date:  February 21, 2006

Additional Modules for full function:
signetd1.php, signetd2.php, signetd3.php, signetd4.php, and signetd5.php

Addhooks into mapmaker.php OR cartographer.php both by sixf00t4 if installed.

Description:
The Signet Elemental Dungeon series consists of 5 dungeons and this map selling program.
Because the dungeons have a huge potential for experience to be gained without costing any
turns, this program has players pay ahead of time for the chance to get that experience.
Players pay turns, gold, and gems to unlock the dungeon modules sequentially.

*/
require_once("lib/http.php");
function signetsale_getmoduleinfo(){
	$info = array(
		"name"=>"`3S`Qi`!g`\$n`3e`Qt `^Sale",
		"version"=>"4.14",
		"author"=>"DaveS, kickme fixes + HoF option by Aelia",
		"category"=>"Signet Series",
		"download"=>"http://dragonprime.net/index.php?module=Downloads;sa=dlview;id=972",
		"vertxtloc"=>"",
		"settings"=>array(
			"Signet Dungeon Maps Sales,title",
			"mapmaker"=>"If `^cartographer`0 installed use as location to buy maps?,bool|0",
			"mapsaleloc"=>"Where does the `3E`Ql`!e`\$m`3e`Qn`!t`\$a`3l`^ Signet`0 Shop appear,location|".getsetting("villagename", LOCATION_FIELDS),
			"usepics"=>"Show small picture of the map to the player upon purchase?,bool|1",
			"dksincewin"=>"Number of DKs before allowing players to replay the Signet Series after completing it?,int|-1",
			"`\$Set to -1 to prevent players from being able to replay the Signet Series. Please set this appropriately high based on the difficulty of dks on your server,note",
			"usehof"=>"Use detailed HoF by Aelia?,bool|1",
			"pp"=>"Number of players to show per page on the HoF?,int|25",
			"Air Signet Dungeon,title",
			"dkair"=>"`3How many `2dks`3 needed before able to purchase the Air map?,int|0",
			"costturna"=>"`3How many `@turns`3 are required to buy the Air map?,int|16",
			"costgolda"=>"`3How much `^gold`3 is required to buy the Air map?,int|12000",
			"costgema"=>"`3How many `%gems`3 are required to buy the Air map?,int|16",
			"Earth Signet Dungeon,title",
			"dkearth"=>"`QHow many `2dks`Q needed before able to purchase the Earth map?,int|0",
			"costturne"=>"`QHow many `@turns`Q are required to buy the Earth map?,int|15",
			"costgolde"=>"`QHow much `^gold `Qis required to buy the Earth map?,int|10000",
			"costgeme"=>"`QHow many `%gems`Q are required to buy the Earth map?,int|15",
			"Water Signet Dungeon,title",
			"dkwater"=>"`!How many `2dks`! needed before able to purchase the Water map?,int|0",
			"costturnw"=>"`!How many `@turns`! are required to buy the Water map?,int|15",
			"costgoldw"=>"`!How much `^gold`! is required to buy the Water map?,int|10000",
			"costgemw"=>"`!How many `%gems`! are required to buy the Water map?,int|15",
			"Fire Signet Dungeon,title",
			"dkfire"=>"`\$How many `2dks`\$ needed before able to purchase the Fire map?,int|0",
			"costturnf"=>"`\$How many `@turns`\$ are required to buy the Fire map?,int|15",
			"costgoldf"=>"`\$How much `^gold`\$ is required to buy the Fire map?,int|10000",
			"costgemf"=>"`\$How many `%gems`\$ are required to buy the Fire map?,int|15",
			"Final Signet Dungeon,title",
			"dkfinal"=>"`%How many `2dks`% needed before able to purchase the Final map?,int|0",
			"costturnm"=>"`%How many `@turns`% are required to buy the Final map?,int|15",
			"costgoldm"=>"`%How much `^gold`% is required to buy the Final map?,int|10000",
			"costgemm"=>"`%How many gems are required to buy the Final map?,int|15",
		),
		"prefs"=>array(
			"Signet Dungeon Maps Sales,title",
			"completednum"=>"How many times has the player completed the Signet Series?,int|0",
			"dksince"=>"How many dks has it been since player last completed the Signet Series?,int|0",
			"nodkopen"=>"Heard opening offer but not at dk high enough to purchase a map?,bool|0",
			"scroll1"=>"Given Scroll 1?,bool|0",
			"hoftemp"=>"Calculation field for status hof?,viewonly|0",
			"incomplete"=>"Has player received a map but the next dungeon is not installed?,bool|0",
			"Air Signet Dungeon Sales,title",
			"dkopena"=>"`3Heard opening offer & dk high enough to purchase Air map?,bool|0",
			"paidturna"=>"`3How many `@turns`3 have been given up for the Air map?,int|0",
			"paidgolda"=>"`3How much `^gold`3 has been paid for the Air map?,int|0",
			"paidgema"=>"`3How many `%gems`3 have been paid for Air map?,int|0",
			"airsigmap"=>"`3Purchased Air Dungeon Map?,bool|0",
			"Earth Signet Dungeon Sales,title",
			"dkopene"=>"`QHeard opening offer & dk high enough & completed `3Air map`Q?,bool|0",
			"paidturne"=>"`QHow many `@turns`Q have been given up for the Earth map?,int|0",
			"paidgolde"=>"`QHow much `^gold`Q has been paid for the Earth map?,int|0",
			"paidgeme"=>"`QHow many `%gems`Q have been paid for the Earth map?,int|0",
			"earthsigmap"=>"`QPurchased Earth Dungeon Map?,bool|0",
			"Water Signet Dungeon Sales,title",
			"dkopenw"=>"`!Heard opening offer & dk high enough & completed `QEarth map`!?,bool|0",
			"paidturnw"=>"`!How many `@turns`! have been given up for the Water map?,int|0",
			"paidgoldw"=>"`!How much `^gold`! has been paid for the Water map?,int|0",
			"paidgemw"=>"`!How many `%gems`! have been paid for the Water map?,int|0",
			"watersigmap"=>"`!Purchased Water Dungeon Map?,bool|0",
			"Fire Signet Dungeon Sales,title",
			"dkopenf"=>"`\$Heard opening offer & dk high enough & completed `!Water map`\$?,bool|0",
			"paidturnf"=>"`\$How many `@turns`$ have been given up for the Fire map?,int|0",
			"paidgoldf"=>"`\$How much `^gold`$ has been paid for the Fire map?,int|0",
			"paidgemf"=>"`\$How many `%gems`$ have been paid for the Fire map?,int|0",
			"firesigmap"=>"`\$Purchased Fire Dungeon Map?,bool|0",
			"Final Signet Dungeon Sales,title",
			"dkopenm"=>"`%Heard opening offer & dk high enough & completed `\$Fire map`%?,bool|0",
			"paidturnm"=>"`%How many `@turns`% have been given up for the Final map?,int|0",
			"paidgoldm"=>"`%How much `^gold`% has been paid for the Final map?,int|0",
			"paidgemm"=>"`%How many gems have been paid for the Final map?,int|0",
			"finalsigmap"=>"`%Purchased Final Dungeon Map?,bool|0",
		),
	);
	return $info;
}

function signetsale_install(){
	module_addhook("newday");
	module_addhook("village");
	module_addhook("footer-runmodule");
	module_addhook("bioinfo");
	module_addhook("footer-hof");
	module_addhook("dragonkill");
	return true;
}

function signetsale_uninstall(){
	return true;
}

function signetsale_dohook($hookname,$args){
	global $session, $REQUEST_URI;
	
	switch($hookname){
	case "dragonkill":
		if (get_module_pref("complete","signetd5")==1) {
			if (get_module_pref("dksince")>=get_module_setting("dksincewin") && get_module_setting("dksincewin")>=0){
				clear_module_pref("dksince");
				clear_module_pref("nodkopen");
				clear_module_pref("incomplete");
				clear_module_pref("dkopena");
				clear_module_pref("paidturna");
				clear_module_pref("paidgolda");
				clear_module_pref("paidgema");
				clear_module_pref("airsigmap");
				clear_module_pref("dkopene");
				clear_module_pref("paidturne");
				clear_module_pref("paidgolde");
				clear_module_pref("paidgeme");
				clear_module_pref("earthsigmap");
				clear_module_pref("dkopenw");
				clear_module_pref("paidturnw");
				clear_module_pref("paidgoldw");
				clear_module_pref("paidgemw");
				clear_module_pref("watersigmap");
				clear_module_pref("dkopenf");
				clear_module_pref("paidturnf");
				clear_module_pref("paidgoldf");
				clear_module_pref("paidgemf");
				clear_module_pref("firesigmap");
				clear_module_pref("dkopenm");
				clear_module_pref("paidturnm");
				clear_module_pref("paidgoldm");
				clear_module_pref("paidgemm");
				clear_module_pref("finalsigmap");
				clear_module_pref("airsignet","signetd1");
				clear_module_pref("complete","signetd1");
				clear_module_pref("reset","signetd1");
				clear_module_pref("earthsignet","signetd2");
				clear_module_pref("complete","signetd2");
				clear_module_pref("reset","signetd2");
				clear_module_pref("watersignet","signetd3");
				clear_module_pref("complete","signetd3");
				clear_module_pref("reset","signetd3");
				clear_module_pref("firesignet","signetd4");
				clear_module_pref("complete","signetd4");
				clear_module_pref("reset","signetd4");
				clear_module_pref("powersignet","signetd5");
				clear_module_pref("complete","signetd5");
				clear_module_pref("reset","signetd5");
				clear_module_pref("darkdead","signetd5");
				require_once("lib/systemmail.php");
				$name = $session['user']['name'];
				$staff= get_module_setting("frwhosend","signetd5");
				$id = $session['user']['acctid'];
				$subj = sprintf("`4Warning! `^The Return of Mierscri");
				$body = sprintf("`&Dear %s`&,`n`nIt is with great saddness that I write to inform you that the evil Mierscri has returned to terrorize our kingdom.  Please help stop him from destroying the tranquility we have come to treasure.`n`nSincerely,`n`n%s",$name,$staff);
				systemmail($id,$subj,$body);
			}
		}
	break;
	case "village":
		if ((is_module_active("mapmaker") || is_module_active("cartographer")) && get_module_setting("mapmaker")==1 && get_module_pref("finalsigmap")==0){
		}elseif ($session['user']['location'] == get_module_setting("mapsaleloc") && get_module_pref("finalsigmap")==0){
			tlschema($args['schemas']['marketnav']);
			addnav($args['marketnav']);
    		tlschema();
			addnav("Antiquities Cart","runmodule.php?module=signetsale&op=enter");
		}
	break;
	case "footer-runmodule":
		$module = httpget('module');
		if (($module=='mapmaker'||$module=='cartographer')&& get_module_setting('mapmaker') == 1 && $session['user']['dragonkills']>=get_module_setting("dkair") && get_module_pref("finalsigmap")==0){
			addnav("Maps For Sale");
			addnav("Special Maps","runmodule.php?module=signetsale&op=enter");
		}
	break;
	case "bioinfo":
		$argsid = $args['acctid'];
		$argsname = $args['login'];
		if (((int)get_module_pref("airsignet","signetd1",$args['acctid'])==1) || get_module_pref("completednum","signetsale",$args['acctid'])>0) {
			addnav("Elemental Signets","runmodule.php?module=signetsale&op=signetnotes&user=$argsid&username=$argsname&return=".URLencode($_SERVER['REQUEST_URI']));
		}elseif (get_module_pref("scroll1","signetsale")==1 && $session['user']['acctid']==$args['acctid']){
			addnav("Elemental Signets","runmodule.php?module=signetsale&op=signetnotes&user=$argsid&username=$argsname&return=".URLencode($_SERVER['REQUEST_URI']));
		}
		if (get_module_pref("completednum","signetsale",$args['acctid'])>0)output("Signet Recognition Title: ");
		if (get_module_pref("completednum","signetsale",$args['acctid'])>10) output("`^`bGreat Mage of the Signets`b");
		if (get_module_pref("completednum","signetsale",$args['acctid'])==10) output("`%Power Signet Mage");
		if (get_module_pref("completednum","signetsale",$args['acctid'])==9) output("`\$Fire Signet Mage");
		if (get_module_pref("completednum","signetsale",$args['acctid'])==8) output("`!Water Signet Mage");
		if (get_module_pref("completednum","signetsale",$args['acctid'])==7) output("`QEarth Signet Mage");
		if (get_module_pref("completednum","signetsale",$args['acctid'])==6) output("`3Air Signet Mage");
		if (get_module_pref("completednum","signetsale",$args['acctid'])==5) output("`6Dark Lord's Bane");
		if (get_module_pref("completednum","signetsale",$args['acctid'])==4) output("`1Nemesis of Mierscri");
		if (get_module_pref("completednum","signetsale",$args['acctid'])==3) output("`#Supreme Vanquisher");
		if (get_module_pref("completednum","signetsale",$args['acctid'])==2) output("`@Grand Vanquisher");
		if (get_module_pref("completednum","signetsale",$args['acctid'])==1) output("`^Vanquisher");
		if (get_module_pref("completednum","signetsale",$args['acctid'])>0) output_notl("`n");
	break;
	case "footer-hof":
		if(get_module_setting('frhof','signetd5')==1){
			addnav("Warrior Rankings");
			addnav("Vanquishers", "runmodule.php?module=signetsale&op=hof");	
		}
		if (get_module_setting("usehof")==1){
			addnav("Warrior Rankings");
			addnav("Signet Quest Status", "runmodule.php?module=signetsale&op=hof2");
		}
	break;
	}
	return $args;
}
function signetsale_run(){
	global $SCRIPT_NAME;
	if ($SCRIPT_NAME == "runmodule.php"){
		$module=httpget("module");
		if ($module == "signetsale") {
			include("modules/signet/signetsale.php");
		}
	}
}
?>
