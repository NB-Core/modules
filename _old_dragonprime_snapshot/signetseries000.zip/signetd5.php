<?php
/*
Module Name: signetd5.php
Category: Signet Series
Worktitle: Signet Maze 5: Dark Lair
Author: DaveS
Date: April 25, 2006
Based on the code for Abandoned Castle by Lonnyl

Requires:
signetsale.php

Additional Modules for full function:
signetd1.php, signetd2.php, signetd3.php, and signetd4.php

Description:
Fifth of the Signet Elemental Dungeons series.
The dungeons are based on a game from 1985 called Phantasie.
Complete the final dungeon to confront the Evil Dark Lord. Will you be able to save the kingdom?

*/
require_once("lib/fightnav.php");
require_once("lib/titles.php");
require_once("lib/names.php");
require_once("lib/systemmail.php");
require_once("lib/sanitize.php");
function signetd5_getmoduleinfo(){
	$info = array(
		"name"=>"Signet Maze 5: `%Dark Lair",
		"version"=>"4.14",
		"author"=>"DaveS",
		"category"=>"Signet Series",
		"download"=>"http://dragonprime.net/index.php?module=Downloads;sa=dlview;id=972",
		"vertxtloc"=>"",
		"settings"=>array(
			"Dark Lair Settings,title",
			"random"=>"How many random monsters can be encountered in the Dark Lair?,range,0,40,1|5",
			"randenc"=>"Likelihood of random encounter:,enum,1,Common,5,Uncommon,10,Rare,15,Very Rare,20,Extremely Rare|10",
			"healing"=>"Allow for players to have a chance to find a partial healing potion after fights?,bool|1",
			"finalmaploc"=>"Where does the Dark Lair appear?,location|".getsetting("villagename", LOCATION_FIELDS),
			"losegold"=>"`6Lose Percentage `^OR `6Amount `^of goldinbank for answering keypad wrong:,enum,0,Percentage,1,Amount|Percentage",
			"percentage"=>"`^Percentage of gold to lose from bank:,range,0,100,1|5",
			"numberlow"=>"`^Amount of gold to lose minimum from bank:,int|100",
			"numberhigh"=>"`^Amount of gold to lose maximum from bank:,int|1000",
			"goldwand"=>"`4Gold award after destroying the wand:,int|1000",
			"gemwand"=>"`4Gem award after destroying the wand:,int|2",
			"perexpr"=>"`@Percentage of experience lost if defeated by a Random Monster:,range,0,100,1|7",
			"perexpk"=>"`0Percentage of experience lost if defeated by a Black Warlock:,range,0,100,1|10",
			"exitsave"=>"Allow users to return to the dungeon from an emergency exit?,enum,0,No,1,Yes,2,Require|0",
			"`\$Note: If you chose 'Require' then players MUST come back in at the same location that they leave from; otherwise players will have a choice to come back through the main entrance or the exit location,note",
			"Dark Lord Settings,title",
			"perexpm"=>"`)Percentage of experience lost if defeated by Mierscri:,range,0,100,1|15",
			"dlhp"=>"`)Multiplier for Mierscri's hitpoints:,floatrange,1.0,3.5,0.1|1.6",
			"dlatt"=>"`)Multiplier for Mierscri's attack:,floatrange,1.0,2.5,0.1|1.6",
			"dldef"=>"`)Multiplier for Mierscri's defense:,floatrange,1.0,2.5,0.1|1.5",
			"Final Reward,title",
			"frexpdk"=>"`#Experience per dragon kill for defeating Mierscri:,range,0,15,1|10",
			"frexplvl"=>"`#Experience per level for defeating Mierscri:,range,20,100,5|100",
			"frgold"=>"`^Gold reward:,int|5000",
			"frgems"=>"`%Gem reward:,int|5",
			"frdefense"=>"`&Defense points rewarded:,int|0",
			"frattack"=>"`&Attack points rewarded:,int|0",
			"frcharm"=>"`&Charm points rewarded:,int|5",
			"fralign"=>"`&Improve alignment by this amount for completion:,int|5",
			"frtitleoff"=>"`6Offer title?,bool|1",
			"frsystemmail"=>"`^Send out system wide YoM of successful completion?,bool|0",
			"frsend"=>"`^Send letter from Staff congratulating the player?,bool|1",
			"frwhosend"=>"`^Who is the Staff sending the letters?,text|`@King  Arthur",
			"frhof"=>"`QUse Hall of Fame record of completion,bool|0",
			"frpp"=>"`QNumber of names per page in Hall of Fame,int|35",
			"frhofnumb"=>"`QNumber of players that have completed the Signet Series,viewonly|0",
			"frnewday"=>"`@Make announcement of successful completion on newday screen?,bool|0",
			"frscroll"=>"`@Victory announcement in Village for the rest of the day?,enum,0,None,1,Scrolling,2,Stable|1",
			"frlastscroll"=>"`@Is the announcement still being displayed in the village?,bool|0",
			"frlastone"=>"`@What is the name of the last player to complete the Signet Series?,text|",
			"Title Options,title",
			"frtitle"=>"`6Title for completing the Signet Series 1st time?,text|`b`&Vanquisher`0`b",
			"frtitle2"=>"`6Title for completing the Signet Series 2nd time?,text|`b`@GrandVanquisher`0`b",
			"frtitle3"=>"`6Title for completing the Signet Series 3rd time?,text|`b`#SupremeVanquisher`0`b",
			"frtitle4"=>"`6Title for completing the Signet Series 4th time?,text|`b`1Nemesis`0`b",
			"frtitle5"=>"`6Title for completing the Signet Series 5th time?,text|`b`6BaneOfEvil`0`b",
			"frtitle6"=>"`6Title for completing the Signet Series 6th time?,text|`b`3AirMage`0`b",
			"frtitle7"=>"`6Title for completing the Signet Series 7th time?,text|`b`QEarthMage`0`b",
			"frtitle8"=>"`6Title for completing the Signet Series 8th time?,text|`b`!WaterMage`0`b",
			"frtitle9"=>"`6Title for completing the Signet Series 9th time?,text|`b`4FireMage`0`b",
			"frtitle10"=>"`6Title for completing the Signet Series 10th time?,text|`b`%PowerMage`0`b",
			"frtitle11"=>"`6Title for completing the Signet Series 11th time or more?,text|`b`^SignetMage`0`b",
		),
		"prefs"=>array(
			"Dark Lair Preferences,title",
			"complete"=>"Has player completed the Lair?,bool|0",
			"super"=>"Does player have superuser access to the Lair?,bool|0",
			"frhofnum"=>"What number to complete the series is this player?,int",
			"announce"=>"Will they hear the announcement on the next newday?,bool|0",
			"Encounters,title",
			"randomp"=>"How many random monsters has player encountered so far?,range,0,40,1|0",
			"powersignet"=>"`%Received the Power Signet?,bool|0",
			"darkdead"=>"Defeated Mierscri?,enum,0,No,1,Yes,2,In Process|0",
			"transport"=>"Which Hall contains the transporter?,range,0,8,1|0",
			"usedtrans"=>"Has player used the transporter at least once?,bool|0",
			"bankloss"=>"Has player lost money from their bank?,bool|0",
			"loc109"=>"Passed Location 109?,bool|0",
			"loc113"=>"Passed Location 113?,bool|0",
			"loc115"=>"Passed Location 115?,bool|0",
			"loc117"=>"Passed Location 117?,bool|0",
			"loc119"=>"Passed Location 119?,bool|0",
			"loc121"=>"Passed Location 121?,bool|0",
			"loc123"=>"Passed Location 123?,bool|0",
			"loc127"=>"Passed Location 127?,bool|0",
			"loc143"=>"Passed Location 143?,enum,0,No,1,Yes,2,In Process|0",
			"loc147"=>"Passed Location 147?,enum,0,No,1,Yes,2,In Process|0",
			"loc149"=>"Passed Location 149?,enum,0,No,1,Yes,2,In Process|0",
			"loc151"=>"Passed Location 151?,enum,0,No,1,Yes,2,In Process|0",
			"loc153"=>"Passed Location 153?,enum,0,No,1,Yes,2,In Process|0",
			"loc155"=>"Passed Location 155?,enum,0,No,1,Yes,2,In Process|0",
			"loc157"=>"Passed Location 157?,enum,0,No,1,Yes,2,In Process|0",
			"loc161"=>"Passed Location 161?,enum,0,No,1,Yes,2,In Process|0",
			"loc279"=>"Passed Location 279?,bool|0",
			"loc283"=>"Passed Location 283?,bool|0",
			"loc285"=>"Passed Location 285?,bool|0",
			"loc287"=>"Passed Location 287?,bool|0",
			"loc289"=>"Passed Location 289?,bool|0",
			"loc291"=>"Passed Location 291?,bool|0",
			"loc293"=>"Passed Location 293?,bool|0",
			"loc297"=>"Passed Location 297?,bool|0",
			"loc335"=>"Passed Location 335?,enum,0,No,1,Yes,2,In Process|0",
			"loc347"=>"Passed Location 347/351?,bool|0",
			"loc361"=>"Passed Location 361/365?,bool|0",
			"loc381"=>"Passed Location 381?,enum,0,No,1,Yes,2,In Process|0",
			"loc385"=>"Passed Location 385?,enum,0,No,1,Yes,2,In Process|0",
			"loc387"=>"Passed Location 387?,enum,0,No,1,Yes,2,In Process|0",
			"loc389"=>"Passed Location 389?,enum,0,No,1,Yes,2,In Process|0",
			"loc391"=>"Passed Location 391?,enum,0,No,1,Yes,2,In Process|0",
			"loc393"=>"Passed Location 393?,enum,0,No,1,Yes,2,In Process|0",
			"loc395"=>"Passed Location 395?,enum,0,No,1,Yes,2,In Process|0",
			"loc399"=>"Passed Location 399?,enum,0,No,1,Yes,2,In Process|0",
			"loc421"=>"Passed Location 421/423?,bool|0",
			"loc425"=>"Passed Location 425/427?,bool|0",
			"loc503"=>"Passed Location 503?,bool|0",
			"loc503b"=>"Passed Location 503b?,bool|0",
			"loc505"=>"Passed Location 505?,bool|0",
			"loc505b"=>"Passed Location 505b?,bool|0",
			"loc507"=>"Passed Location 507?,bool|0",
			"loc519"=>"Passed Location 519?,enum,0,No,1,Yes,2,In Process|0",
			"loc524"=>"Passed Location 524?,enum,0,No,1,Yes,2,In Process|0",
			"loc528"=>"Passed Location 528?,enum,0,No,1,Yes,2,In Process|0",
			"loc533"=>"Passed Location 533?,enum,0,No,1,Yes,2,In Process|0",
			"loc685"=>"Passed Location 685?,enum,0,No,1,Yes,2,In Process|0",
			"loc687"=>"Passed Location 687?,bool|0",
			"loc691"=>"Passed Location 691?,bool|0",
			"loc694"=>"Passed Location 694?,enum,0,No,1,Yes,2,In Process|0",
			"loc698"=>"Passed Location 698?,enum,0,No,1,Yes,2,In Process|0",
			"loc701"=>"Passed Location 701?,bool|0",
			"loc705"=>"Passed Location 705?,bool|0",
			"loc707"=>"Passed Location 707?,enum,0,No,1,Yes,2,In Process|0",
			"loc724"=>"Passed Location 724?,enum,0,No,1,Yes,2,In Process|0",
			"loc736"=>"Passed Location 736?,enum,0,No,1,Yes,2,In Process|0",
			"loc766"=>"Passed Location 766?,bool|0",
			"loc774"=>"Passed Location 774?,bool|0",
			"loc777"=>"Passed Location 777?,bool|0",
			"loc792"=>"Passed Location 792?,bool|0",
			"loc804"=>"Passed Location 804?,bool|0",
			"loc834"=>"Passed Location 834?,bool|0",
			"loc849"=>"Passed Location 849?,bool|0",
			"loc860"=>"Passed Location 860?,bool|0",
			"loc872"=>"Passed Location 872?,bool|0",
			"loc895"=>"Passed Location 895?,bool|0",
			"loc898"=>"Passed Location 898?,enum,0,No,1,Yes,2,In Process|0",
			"loc902"=>"Passed Location 902?,enum,0,No,1,Yes,2,In Process|0",
			"loc905"=>"Passed Location 905?,bool|0",
			"loc1002"=>"Passed Location 1002?,bool|0",
			"loc1012"=>"Passed Location 1012?,bool|0",
			"loc1016"=>"Passed Location 1016?,bool|0",
			"loc1016b"=>"Number of Times Passed Location 1016b?,int|0",
			"loc1104"=>"Passed Location 1104?,enum,0,No,1,Yes,2,In Process|0",
			"loc1104b"=>"Passed Location 1104b?,bool|0",
			"loc1138"=>"Passed Location 1138?,bool|0",
			"loc1172"=>"Passed Location 1172?,bool|0",
			"loc1257"=>"Passed Location 1257?,bool|0",
			"Maze View Only,title",
			"maze"=>"Maze,viewonly",
			"mazeturn"=>"Maze Return,viewonly",
			"pqtemp"=>"Temporary Information,int",
			"startloc"=>"Starting location,int|1274",
			"header"=>"Which header array is the player at?,viewonly|0",
		),
		"requires"=>array(
			"signetsale" => "4.14| by DaveS, http://dragonprime.net/index.php?module=Downloads;sa=dlview;id=972",
		),
	);
	return $info;
}

function signetd5_install(){
	module_addhook("village");
	module_addhook("newday");
	module_addhook("newday-runonce");
	return true;
}

function signetd5_uninstall(){
	return true;
}

function signetd5_dohook($hookname,$args){
	global $session;
	$last=get_module_setting("frlastone");
	switch($hookname){
	case "newday-runonce":
		set_module_setting("frlastscroll",0);
	break;
	case "newday":
		if (get_module_pref("announce")==1 && get_module_setting("frnewday")==1){
			output("`n`@`bHear Ye! Hear Ye! All rejoice for the Evil Mierscri has been destroyed by`b %s`@`b!`b`n",$last);
			set_module_pref("announce",0);
		}
	break;
	case "village":
		if ($session['user']['location'] == get_module_setting("finalmaploc") && get_module_pref("finalsigmap","signetsale")==1 && get_module_pref("complete")==0){
			tlschema($args['schemas']['tavernnav']);
			addnav($args['tavernnav']);
    		tlschema();
			addnav("`)`bThe Dark Lair`b","runmodule.php?module=signetd5");
		}
		if ($session['user']['location']==get_module_setting("finalmaploc") && get_module_setting("frscroll")==1 && get_module_setting("frlastscroll")==1){
			$last = full_sanitize($last);
			output("`n");
			rawoutput("<marquee height=\"15\" width=\"100%\" onMouseover=\"this.stop()\" onMouseout=\"this.start()\" direction=left scrollamount=\"5\" style=\"Filter:Alpha(Opacity=50, FinishOpacity=100, Style=1, StartX=0, StartY=100, FinishX=0, FinishY=0); text-align:center\"><font class=body><font color=00FFFF>Hear Ye! Hear Ye! All rejoice for the</font><font color=FF0000> Evil Mierscri </font><font color=00FFFF>has been destroyed by</font><font color=66FF00> $last</font><font color=00FFFF>!</font><br></marquee>");
			output("`n");
		}
		if ($session['user']['location']==get_module_setting("finalmaploc") && get_module_setting("frscroll")==2 && get_module_setting("frlastscroll")==1){
			output("`n`@`b`cHear Ye! `#Hear Ye!`^ All rejoice for the `\$Evil M`)ierscri`^ has been destroyed by `@%s`^!`b`n`c",$last);
		}
	break;
	}
	return $args;
}
function signetd5_run(){
	global $SCRIPT_NAME;
	if ($SCRIPT_NAME == "runmodule.php"){
		$module=httpget("module");
		if ($module == "signetd5") {
			require_once("modules/signet/signetd5_func.php");
			include("modules/signet/signetd5.php");
		}
	}
}
?>
