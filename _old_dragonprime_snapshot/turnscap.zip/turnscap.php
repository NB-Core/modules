<?
function turnscap_getmoduleinfo(){

	$info = array(
		"name"=>"Turn cap for dragonkillers",
		"author"=>"Sixf00t4",
		"version"=>"20050503",
		"category"=>"General",
		"download"=>"http://www.dragonprime.net/users/sixf00t4/turncap.zip",
		"vertxtloc"=>"http://www.dragonprime.net/users/sixf00t4/",
		"settings"=>array(
			"cap" => "What is the cap?,int|100",
            "who" => "who is imposing the cap?,text|The Gods",
		)
	);
	return $info;	
}

function turnscap_install(){
	module_addhook("newday");
	return true;
}

function turnscap_uninstall(){
	return true;
}

function turnscap_dohook($hookname, $args){
	global $session;
	switch($hookname){
	case "newday":
    $turncap=get_module_setting("cap","turnscap");
    if($session['user']['turns'] > $turncap){
        $session['user']['turns']=$turncap;
        output("Since you seem to have so much free time to spend in the forest, %s has asked that you spend more time in the village helping the citizens learn the ways of the dragon killer.",get_module_setting("who","turnscap"));
    }
		break;
	}
	return $args;
}
?>
