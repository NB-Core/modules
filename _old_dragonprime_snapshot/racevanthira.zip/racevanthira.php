<?php

function racevanthira_getmoduleinfo(){
	$info = array(
		"name"=>"Rasse - Vanthira",
		"version"=>"1.2",
		"author"=>"Oliver Wellinghoff, Zusammenfassung Haku",
		"category"=>"Races",
		"download"=>"http://dragonprime.net/users/chicu/racevanthira.zip",
		"settings"=>array(
			"Vanthira - Rasseneinstellungen,title",
			"mindk"=>"Nach wievielen DKs wird die Rasse freigeschaltet?,int|10",
			"minedeathchance"=>"Prozentuale Chance f�r einen Vanthira in der Mine zu sterben,range,0,100,1|70",
			"wiedergeburt"=>"Wieviele Gefallen zahlt ein Vanthira f�r die Wiedergeburt? ,range,70,90,5|70",
			"senden"=>"Prozentuale Chance nach einem Kampf senden zu wollen ,range,3,10,1|5",
			"sendendauer"=>"--> Wielange dauert der Vorteil? ,range,5,40,1|5",
			"sendenst�rke"=>"--> Multiplikator f�r den Vorteil (auf Angriff) ,floatrange,1.05,1.50,0.01|1.05",
			"sehnen"=>"Prozentuale Chance nach einem Kampf Todessehnsucht zu bekommen ,range,3,10,1|3",
			"sehnenst�rke"=>"--> Multiplikator f�r den Nachteil (auf beide Werte!) ,floatrange,0,0.5,0.05|0.25",
			"sehnendauer"=>"--> Wielange dauert der Nachteil? ,range,5,40,1|10",
		),
	);
	return $info;
}

function racevanthira_install(){
// Vanthira leben unter allen V�lkern. Der Einfachheit halber beginnen sie beim gr��ten: den Menschen.
	if (!is_module_installed("racehuman")) {
		output("Vanthira starten bei den Menschen. Du musst das entsprechende Modul installieren.");
		return false;
		}
		module_addhook("graveyard-desc");
		module_addhook("chooserace");
		module_addhook("setrace");
		module_addhook("newday");
		module_addhook("charstats");
		module_addhook("raceminedeath");
		module_addhook("battle-victory");
	return true;
}

function racevanthira_uninstall(){
    global $session;
	// Force anyone who was a Vanthira to rechoose race
	$sql = "UPDATE  " . db_prefix("accounts") . " SET race='" . RACE_UNKNOWN . "' WHERE race='Vanthira'";
	db_query($sql);
	if ($session['user']['race'] == 'Vanthira')
	$session['user']['race'] = RACE_UNKNOWN;
	return true;
}

function racevanthira_dohook($hookname,$args){
	global $session;

    switch ($hookname) {
    case "graveyard-desc":
    output("`3`n`nIn der N�he des Mausoleums befinden sich zwei gro�e, dicht beieinanderstehende S�ulen: das Portal der Vanthira. Mit seiner Hilfe kann das Volk der Vanthira leichter zu den Lebenden zur�ckkehren.");
			if ($session['user']['race']==$race){
				$kosten=get_module_setting ("wiedergeburt");
				if ($session['user']['deathpower']>=$kosten) {
					output("`#`n`n`bGlei�endes Licht erstrahlt von beiden Seiten - es ist ge�ffnet!`b");
					output("`@`n`n<a href='newday.php?resurrection=true'>Ich schreite hindurch! (70 Gefallen)</a>", true);
					addnav("","newday.php?resurrection=true");
				}else{
					output("`3 Aber noch hat es sich nicht ge�ffnet ...`n");
				}
			}
    break;
    case "chooserace":
    	$mindk = get_module_setting("mindk");
			if ($session['user']['dragonkills'] < $mindk){
				output("`3Die Vanthira, die Wanderer zwischen den Welten, sind ein uraltes Volk ohne eigene Kultur. Sie lieben das Leben gleicherma�en wie den Tod und sind dementsprechend offen f�r alle Eindr�cke, seien sie leben-, seien sie todbringend. Sie sehen sich selbst als ewige Reisende und Lernende an. Ihr �u�eres gleicht dem eines Menschen, doch sie haben silbern schimmerndes, wei�es Haar.`n`b`4[Diese Rasse steht nur Spielern zur Verf�gung, die bereits %s Titelsteigerungen hinter sich haben.]`b`n`n", $mindk, true);
			}else{
				output("<a href='newday.php?setrace=Vanthira$resline'>Die Vanthira, `3die Wanderer zwischen den Welten, sind ein uraltes Volk ohne eigene Kultur. Sie lieben das Leben gleicherma�en wie den Tod und sind dementsprechend offen f�r alle Eindr�cke, seien sie leben-, seien sie todbringend. Sie sehen sich selbst als ewige Reisende und Lernende an. Ihr �u�eres gleicht dem eines Menschen, doch sie haben silbern schimmerndes, wei�es Haar.`n`n", true);
				addnav("`3Vanthira`0","newday.php?setrace=$race$resline");
				addnav("","newday.php?setrace=$race$resline");
			}
    break;
    case "setrace":
  if (is_module_active("racehuman")) {
        $city = get_module_setting("villagename", "racehuman");
    } else {
        $city = getsetting("villagename", LOCATION_FIELDS);
    }

if ($session['user']['race']==$race){ // it helps if you capitalize correctly
				output("`3Als Wanderer zwischen den Welten f�llt es Dir leichter als jedem anderen Wesen, `\$Ramius`3 gn�dig zu stimmen. Deshalb kannst Du schon mit nur 70 Gefallen wiederauferstehen.`n`nDu bist ein Wesen, das sich nicht f�r eine der beiden Welten entscheiden kann - mal sehnt es sich nach der einen, mal nach der anderen. ");
				if (is_module_active('alignment')) output("Deshalb solltest Du stets darum bem�ht sein, neutral gesinnt zu bleiben. ");
				output("`n`nDein �u�eres gleicht dem eines Menschen, doch Du hast silbern schimmerndes, wei�es Haar.`n`n");
				if (is_module_active('biblio')) output("`bLies bitte unbedingt den Eintrag in der Bibliothek, bevor Du anf�ngst, diese Rasse im Rollenspiel zu spielen!`b");
				//Vanthira k�nnen sich nicht f�r eine Seite entscheiden - weder nur f�r das Licht noch nur f�r die Dunkelheit.
				if ($session['user']['ctitle']=="`\$Ramius� ".($session[user][sex]?"Sklavin":"Sklave").""){
					output("`n`n`bWichtig:`b`n`3Da Du als Vanthira wiedergeboren wurdest, hat Dein bisheriger Meister `\$Ramius`3 keinen Einfluss mehr auf Dich, denn Vanthira k�nnen sich nicht f�r nur eine der beiden Seiten - Licht und Dunkelheit - entscheiden.");
					$session[user][ctitle] ="";
					$session[user][name] ="".$session[user][title]." ".$session[user][login]."";
					addnews("`#%s `3wurde als Vanthira wiedergeboren und entkam auf diese Weise ".($session[user][sex]?"ihrem":"seinem")." Schicksal als ".($session[user][sex]?"Sklavin":"Sklave")." des `\$Ramius`3!",$session['user']['login']);
				}
				if (is_module_active("cities")) {
					if ($session['user']['dragonkills']==0 && $session['user']['age']==0){
						set_module_setting("newest-$city",
						$session['user']['acctid'],"cities");
				}
				set_module_pref("homecity",$city,"cities");
				$session['user']['location']=$city;
				}
			}
    break;
    case "newday":
if ($session['user']['race']==$race){
				racevanthira_checkcity();
				//Da Vanthira weniger Gefallen f�r die Wiedererweckung zahlen, bekommen sie hier die Differenz zur�ck.
				if ($session['user']['spirits']==-6){
				$kosten=get_module_setting ("wiedergeburt");
				$session['user']['deathpower']+=100-$kosten;
				output("`3`nDurch das Portal der Vanthira kehrst Du neugierig und voller Tatendrang, aber etwas ersch�pft, zur�ck in die Welt der Lebenden.`n");
			}else output("`3`nDu fragst Dich, was der heutige Tag wohl bringen mag ... und vor allem: Wo er am sch�nsten sein wird, hier oder im Schattenreich. Etwas unentschlossen, aber neugierig trittst Du nach drau�en.`n");

			//Vanthira wollen neutral bleiben
				if  (is_module_active('alignment')){
					$alignment = get_align();
					$evil=get_module_setting('evilalign','alignment');
					$good=get_module_setting('goodalign','alignment');
					if ($alignment < 43 || $alignment > 57){
						if ($alignment < $evil){
							output("`3`bWeil Du merkst, dass Dein Karma sehr im Ungleichgewicht ist, machst Du aber erstmal ein paar intensive Konzentrations�bungen, was Dich einen Waldkampf kostet.`b`n");
							$session[user][turns]--;
							align("+4");
						}else if ($alignment > $good){
							output("`3`bWeil Du merkst, dass Dein Karma sehr im Ungleichgewicht ist, machst Du aber erstmal ein paar intensive Konzentrations�bungen, was Dich einen Waldkampf kostet.`b`n");
							$session[user][turns]--;
							align("-4");
						}else
							output("`3`bWeil Du merkst, dass Dein Karma etwas im Ungleichgewicht ist, machst Du auf dem Weg zum Dorfplatz ein paar Konzentrations�bungen.`b`n");
							if ($alignment < 43) align("2");
							else if ($alignment > 57) align("-2");
					}
				}
			}
    break;
    case "charstats":
    if ($session['user']['race']==$race){
				addcharstat("Vital Info");
				addcharstat("Race", translate_inline($race));
			}
    break;
    case "raceminedeath":
   if ($session['user']['race'] == $race) {
				$args['chance'] = get_module_setting("minedeathchance");
				$args['racesave'] = "`n`3Es ist so weit, das Reich der Schatten ruft nach Dir! Erregt hebst Du Deine Arme und freust Dich auf Deinen Tod. Erst im letzten Moment springst Du dann doch zur Seite - und bereust es sofort wieder ...`n";
				$args['schema']="module-racevanthira";
			}
    break;
    case "battle-victory":
			if ($session['user']['race']==$race){
				$Vorteil = (e_rand(0,100));
				$senden=get_module_setting("senden");
				$chancesehnen=get_module_setting("sehnen");
				$sehnen=$senden+$chancesehnen;
				if ($Vorteil <= $senden){
					$sendendauer=get_module_setting ("sendendauer");
					$sendenst�rke=get_module_setting ("sendenst�rke");
					output("`3`n`bNach diesem Kampf versp�rst Du den starken Drang, ein weiteres Wesen ins Schattenreich zu `isenden`i, wie es in Deinem Volke hei�t.`n`n`b");
					apply_buff("racialbenefit",array(
					"name"=>"`3Drang zu `isenden`i`0",
					"atkmod"=>"$sendenst�rke",
					"roundmsg"=>"`3Du fl�sterst: `#'Das Schattenreich hat viel zu bieten ... komm, lass Dich senden!'`3.",
					"wearoff"=>"`3`bDein Drang zu `isenden`i ist vor�ber. Du k�mpfst normal weiter.`b",
					"allowinpvp"=>0,
					"allowintrain"=>0,
					"rounds"=>"$sendendauer",
					"schema"=>"module-racevanthira",
					"activate"=>"offense")
					);
				}
				else if ($Vorteil > $senden && $Vorteil <= $sehnen){
					$sehnendauer=get_module_setting ("sehnendauer");
					$sehnenst�rke=get_module_setting ("sehnenst�rke");
					output("`3`n`bWehm�tig siehst Du Deinen Gegner zu Boden gehen ... Ach, wie gern w�rst Du an seiner Stelle! Du wirst von dem Drang befallen, ins Schattenreich zur�ckzukehren.`n`n`b");
					apply_buff("racialbenefit",array(
						"name"=>"`3Sehnsucht nach `iR�ckkehr`i`0",
						"atkmod"=>"$sehnenst�rke",
						"defmod"=>"$sehnenst�rke",
						"roundmsg"=>"`3Du rufst flehentlich: `#'Ich bitte Dich, bring mich ins Schattenreich!'`3.",
						"wearoff"=>"`3`bDein Drang zur `iR�ckkehr`i ist pl�tzlich vor�ber. Du k�mpfst normal weiter.`b",
						"allowinpvp"=>0,
						"allowintrain"=>0,
						"rounds"=>"$sehnendauer",
						"schema"=>"module-racevanthira",
						"activate"=>"offense",
						));
				}
			}
    break;
   }
   return $args;
}

function racevanthira_checkcity(){
	global $session;

		$race="Vanthira";
		if (is_module_active("racehuman")) {
			$city = get_module_setting("villagename", "racehuman");
		} else {
			$city = getsetting("villagename", LOCATION_FIELDS);
		}
		if ($session['user']['race']==$race && is_module_active("cities")){
			//if they're this race and their home city isn't right, set it up.
			if (get_module_pref("homecity","cities")!=$city){ //home city is wrong
				set_module_pref("homecity",$city,"cities");
			}
		}
	return true;
}
?>





