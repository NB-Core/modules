Race - Archangel

Version 1.02
Written by RPGSL
Download: http://rpgsl.com/lotgd/racearchangel_city.zip
Mirror: http://rpdragon.com/lotgd/racearchangel_city.zip

Game: http://rpdragon.com/


Installation
 
1) Copy racearchangel_city.php into your LotGD modules folder
2) Log in to LotGD with your admin account
4) Enter the Superuser Grotto
5) Click Manage Modules
6) Install racearchangel_city.php (Race - Demon)
7) Configure settings and save
8) Activate


Questions/Comments?

alex@rpgsl.com


Visit www.rpgsl.com today for your RPG needs.