<?php

function muad_getmoduleinfo(){
	$info = array(
		"name"=>"Muad's Smoothie Shoppe",
		"author"=>"Chris Vorndran<br>Idea by: `^Ken Stephens`0",
		"version"=>"1.2",
		"category"=>"Village",
		"download"=>"http://dragonprime.net/index.php?module=Downloads;sa=dlview;id=26",
		"vertxtloc"=>"http://dragonprime.net/users/Sichae/",
		"description"=>"Allows a user to feel the effects of an addiction to smoothie's. User gains a buff, that is based from how long the addiction has been going on. Rehab can be offered",
		"settings"=>array(
			"Muad's Smoothies - General,title",
				"is"=>"Increment of addiction from small buzz,int|2",
				"im"=>"Increment of addiction from medium buzz,int|4",
				"il"=>"Increment of addiction from large buzz,int|6",
				"irh"=>"Is rehab available?,bool|1",
				"hrh"=>"How many points of addiction are needed before rehab is available,int|10",
				"ma"=>"Maximum amount of HP that can be gained,int|15",
				"mb"=>"Minimum Mod for the Buff,floatrange,0,1,.05|0.7",
			"Muad's Smoothies - Costs,title",
				"smpl"=>"Cost of Small Smoothie per level,int|10",
				"mdpl"=>"Cost of Medium Smoothie pet level,int|30",
				"lgpl"=>"Cost of Large Smoothie per level,int|50",
				"crh"=>"Cost of rehab per point of addiction,int|100",
			"Muad's Smoothies Location,title",
				"mindk"=>"What is the minimum DK before this shop will appear to a user?,int|0",
				"mloc"=>"Location of Muad's Smoothie Shoppe,location|".getsetting("villagename", LOCATION_FIELDS),
		),
		"prefs"=>array(
			"Muad's Smoothies - Prefs,title",
				"la"=>"Last size Smoothie bought,enum,0,None,1,Small,2,Medium,3,Large|0",
				"lev"=>"Level of addiction,int|0",
				"has"=>"Has a drink been bought today,bool|0",
				"co"=>"Longest time on a fix,int|0",
				"ti"=>"Times a drink has been bought today,int|0",
				"da"=>"Days since last fix,int|0",
		),
		);
	return $info;
}
function muad_install(){
	module_addhook("newday");
	module_addhook("village");
	module_addhook("changesetting");
	module_addhook("dragonkilltext");
	return true;
	}
function muad_uninstall(){
	return true;
}
function muad_dohook($hookname,$args){
	global $session;
	$lev = get_module_pref("lev");
	switch ($hookname){
		case "newday":
			if ($lev > 0){
				if (get_module_pref("la") == 1){
					$i = get_module_setting("is");
				}elseif(get_module_pref("la") == 2){
					$i = get_module_setting("im");
				}elseif(get_module_pref("la") == 3){
					$i = get_module_setting("il");
				}
				output("`n`n`3You can feel `#Muad's Smoothies `3running in your head.");
				output("Perhaps you should quench this lust...`n`0");
				$new = $lev+$i;
				set_module_pref("lev",$new);
				if (get_module_pref("has") == 0){
					set_module_pref("da",get_module_pref("da")+1);
					set_module_pref("co",0);
				}else{
					$co = get_module_pref("co");
					$co++;
					set_module_pref("co",$co);
					set_module_pref("has",0);
				}
				set_module_pref("ti",round($lev/10));
				if (get_module_pref("da") > 0){
					muad_negbuff();
				}
			}
			set_module_pref("ti",0);
			break;
		case "village":
			if ($session['user']['location'] == get_module_setting("mloc")
			&& $session['user']['dragonkills'] >= get_module_setting("mindk")){
				tlschema($args['schemas']['tavernnav']);
				addnav($args['tavernnav']);
				tlschema();
				addnav("Muad's Smoothie Shoppe","runmodule.php?module=muad&op=enter");
			}
			break;
		case "changesetting":
			if ($args['setting'] == "villagename") {
				if ($args['old'] == get_module_setting("mloc")) {
				   set_module_setting("mloc", $args['new']);
				}
			}
			break;
		case "dragonkilltext":
			set_module_pref("co",0);			
			set_module_pref("ti",0);
			set_module_pref("lev",0);
			set_module_pref("la",0);
			set_module_pref("has",0);
			break;
		}
	return $args;
}
function muad_run(){
	global $session;
	$op = httpget('op');
	$sub = httpget('sub');
	$lev = get_module_pref("lev");
	$crh = get_module_setting("crh");
	$rehab = $lev*$crh;
	$bod = array(1=>"leg",2=>"arm",3=>"neck",4=>"butt",5=>"back",6=>"chest",7=>"torso",8=>"head");
	$ran = e_rand(1,8);
	$bodypart = $bod[$ran];
	$sm = (get_module_setting("smpl")*$session['user']['level'])+(get_module_pref("co")*2);
	$md = (get_module_setting("mdpl")*$session['user']['level'])+(get_module_pref("co")*3);
	$lg = (get_module_setting("lgpl")*$session['user']['level'])+(get_module_pref("co")*4);
	$dead = 0;
	page_header("Muad's Smoothies");

	switch ($op){
		case "enter":
			output("`#You enter `QMuad's Smoothie Shoppe.");
			output("`#A medium build, ordinary looking guy stands behind the counter.");
			output("\"`QWelcome to my Smoothie Shoppe,`#\" he says to you.");
			output("Looking around, you see an intricate looking brass machine on the counter.");
			output("Steam is hissing from some openings.");
			addnav("Options");
			addnav("View Menu","runmodule.php?module=muad&op=menu");
			if ($lev >= get_module_setting("hrh") && get_module_setting("irh") == 1) addnav("Re-Hab","runmodule.php?module=muad&op=rehab");
			break;
		case "menu":
			output("`#\"`QI should let you know, my beverages are very potent.");
			output("Some patrons have reported, um .... how shall we say this, negative aspects to not getting their fix, uh daily smoothie.");
			output("I can guarantee, however, that after just one drink you will be feeling great!`#\"");
			output("`n`n\"`QWhat can I get you?`#\" he says with a smile.");
			addnav("Menu");
			if ($session['user']['gold'] >= $sm) addnav(array("Small Smoothie (%s Gold)",$sm),"runmodule.php?module=muad&op=pick&sub=sm");
			if ($session['user']['gold'] >= $md) addnav(array("Medium Smoothie (%s Gold)",$md),"runmodule.php?module=muad&op=pick&sub=md");
			if ($session['user']['gold'] >= $lg) addnav(array("Large Smoothie (%s Gold)",$lg),"runmodule.php?module=muad&op=pick&sub=lg");
			break;
		case "rehab":
			if ($sub == ""){
				output("`#Muad looks at you, seeing that you are shaking violently.");
				output("He speaks, \"`QI am guessing that you have found the addictive strength of the `\$Dragon Fruit`Q.");
				output("I can ease you through this pain, since I have been through it myself...");
				output("But, it will cost you - `^%s `Qgold to be exact.",$rehab);
				output("Are you sure you wish to go through with this?`#\"");
				addnav("Choices");
				addnav("Yes","runmodule.php?module=muad&op=rehab&sub=yes");
				addnav("No","runmodule.php?module=muad&op=rehab&sub=no");
			}elseif ($sub == "no"){
				output("Muad simply shakes his head, and directs you to the menu, once more.");
				addnav("View Menu","runmodule.php?module=muad&op=menu");
			}else{
				output("`#Muad smiles, and goes to fetch his things.");
				output("He returns with a %s inch needle.",$session['user']['age']);
				output("He walks over and pushes the needle into your `\$%s`#.",$bodypart);
				if ($session['user']['gold'] >= $rehab){
					output("He withdraws the needle, and you feel completely cured.");
					output("\"`QNow, I suggest that ye not drink anymore, if you can not handle it.`#\"");
					$session['user']['gold']-=$rehab;
					set_module_pref("lev",0);
					set_module_pref("da",0);
					set_module_pref("la",0);
				}else{
					output("He looks into your gold stores, and sees that you have `^%s `#gold in there.",$session['user']['gold']);
					output("He pulls the needle out, quite disgusted.");
					output("\"`QI am sorry, but you need `^%s `Qmore gold, to have my services...`#\"",abs($rehab-$session['user']['gold']));
					output("He walks off, then comes running back...`n`n");
					switch (e_rand(1,2)){
						case 1:
							$dead = 1;
							output("`#You have died, due to overdose of `@Dragoncilin`#.");
							output("Muad sinks to his knees, \"`QWhy does this keep happening!?`#\"");
							$session['user']['hitpoints']=0;
							$session['user']['alive']=false;
							debuglog("died from overdose of rehab medications");
							addnav("Shades","shades.php");
							break;
						case 2:
							$gold = e_rand(1,1000);
							output("`#You have been pilfering Muad's shoppe.");
							output("You make off with `^%s `#gold.",$gold);
							output("Muad chases you out, shaking his fist in anger.");
							output("\"`QCome back here, you snot nosed punk!`#\"");
							$session['user']['gold']+=$gold;
							break;
					}
				}
			}
			break;
		case "pick":
			output("`#\"`QThanks for stopping in today.");
			output("Enjoy your drink!");
			output("Oh... if you get hungry make sure to stop by `\$Saucy's `QKitchen.`#\"");
			switch ($sub){
				case "sm":
					set_module_pref("la",1);
					$session['user']['gold']-=$sm;
					break;
				case "md":
					set_module_pref("la",2);
					$session['user']['gold']-=$md;
					break;
				case "lg":
					set_module_pref("la",3);
					$session['user']['gold']-=$lg;
					break;
			}
			muad_buff();
			$ti = get_module_pref("ti");
			$ti++;
			set_module_pref("ti",$ti);
			$lev = get_module_pref("lev");
			$lev++;
			set_module_pref("lev",$lev);
			set_module_pref("has",1);
			set_module_pref("da",0);
			break;
}
addnav("Leave");
if ($dead == 0) villagenav();
page_footer();
}
function muad_buff(){
	global $session;
	$la = get_module_pref("la");
	$ti = get_module_pref("ti");
	$da = get_module_pref("da");
	$mb = get_module_setting("mb");
	if ($la == 0) $b = 1;
	if ($la == 1) $b = 4;
	if ($la == 2) $b = 3;
	if ($la == 3) $b = 2;
	$a = $ti*(.01*$b);
	$c = $da*.01;
	$at = max(((1.3-$a)-$c),$mb);
	$hp = get_module_setting("ma")-$ti;
	if ($hp < 0) $hp = 0;
	if (get_module_pref("has") == 0) $session['user']['hitpoints']+=$hp;
		apply_buff("muad", 
			array(
				"name"=>"Muad's Smoothie",
				"rounds"=>15,
				"wearoff"=>"The smoothie dissappates in your blood...",
				"atkmod"=>$at,
				"defmod"=>$at,
				"roundmsg"=>"The buzz from the fruit smoothie pushes you forth!",
				"schema"=>"module-muad",
			)
		);
}
function muad_negbuff(){
	global $session;
	$da = get_module_pref("da");
	$mb = get_module_setting("mb");
	$at = max((1-($da*.05)),$mb);

		apply_buff("muad",
			array(
				"name"=>"Smoothie Withdrawl",
				"rounds"=>"15",
				"wearoff"=>"Perhaps it is time to fix...",
				"atkmod"=>$at,
				"defmod"=>$at,
				"roundmsg"=>"You shake violently... wishing to have a smoothie right about now...",
				"schema"=>"module-muad",
			)
		);
}
?>