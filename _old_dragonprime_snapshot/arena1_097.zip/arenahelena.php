<? 
require_once "common.php";  
checkday();

if ($session['user']['alive']){ }else{
	redirect("shades.php");
}
if ($session[user][turns]>0){ }else{
	redirect("newday.php");
}
page_header("Castle Gwen Arena");
output(" `c`b`3Castle Gwen Arena - Helena`b`c`n`n ");
if ($HTTP_GET_VARS[op]==""){ 
    output("`3You have selected to fight with Helena.  Your entrance fee is `^75 Gold`3. `n"); 
    output("Each fight costs 1 Forest fight and the entrance fee."); 
    addnav("Pay the 75 Gold","arenahelena.php?op=pay"); 
    addnav("Return to Arena","arena1.php?op=dont"); 
    
}else if ($HTTP_GET_VARS[op]=="pay"){ 
  if ($session[user][gold]>74){ 
  
      output(" `3You pay your admission fee of `^75 gold`3. `n");  
      output(" Your fight is with Helena of Castle Gwen.  You discover that ...`n`n"); 
      addnav("Return to Arena","arena1.php"); 
        $session[user][gold]-=75; 
        $session[user][turns]--; 
        debuglog("gave 75 gold to a arena"); 
        switch(e_rand(1,5)){ 
          case 1: case 2:
                output(" You battle with Helena! She use's her Scimitar.`n"); 
                output(" You fend off each attack with your {$session['user']['armor']} but you're slightly injured!`n");
                output(" You lose this fight!");
                $session[user][hitpoints]-=8;
                break; 
            case 3: 
                output(" You fight with Helena! She use's her Scimitar.`n"); 
                output(" You fend off each attack with your {$session['user']['armor']} and you are not injured!`n");
                output(" The fight is a draw! You receive `^25Gold`&, one third your entrance fee.");
                $session[user][gold]+=25; 
                break;
            case 4: case 5:
                $exp=$session[user][experience]*0.009;
                output(" You fight with Helena! She use's her Scimitar.`n"); 
                output(" You fiercly attack her with your {$session['user']['weapon']} and you injure Helena!`n");
                output(" You win this fight! plus `^107 Gold `&and 1 percent experience"); 
                $session[user][gold]+=107; 
                $session[user][experience]+=$exp;
                debuglog("got 107 gold from arena"); 
                break;  
        } 
    }else{ 
      output(" `n`n`&You need to have some `^gold `&and turns before you can fight. "); 
      addnav("Return to Castle","castlegwen.php"); 
    } 
}else{ 
      output(" `3Not wanting to participate in this Sporting event, you leave."); 
} 

page_footer();
?> 
