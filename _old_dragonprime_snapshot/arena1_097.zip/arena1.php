<?
/***************************************
The Arena
Written by Robert for Maddnet LoGD
Belongs with Gwen Castle
14Feb2004
****************************************/
require_once "common.php"; 
checkday();
if ($session[user][turns] < 1){
	page_header("Castle Gwen Arena");
	output("`c<font size='+1'>`3Castle Gwen Arena</font>`c`n`n",true);
    output("`n `2You are too tired to engage in any fights, perhaps another day");
    addnav("(C) Return to Castle","castlegwen.php");
}else{ 
    
page_header("Castle Gwen Arena"); 
output("`c<font size='+1'>`3Castle Gwen Arena</font>`c`n`n",true);
output(" `&You enter the `3Castle Gwen Arena`&, `n"); 
output(" There are hundreds of people in the stands, cheering away. `n"); 
output(" Here you can do battle with some experienced fighters. `n"); 
output(" Each fight will cost you 1 Forest Fight plus the entrance fee.`n");
output(" The cost to enter a fight is listed for each fighter.`n");
output(" If you win your battle, you will gain half of your opponents entrance fee,`n"); 
output(" If you lose, you will lose your entrance fee.`n"); 
output(" If the fight is a draw, you receive one third of the entrance fee. `n");
output(" `3Injuries may occur but a battle to the death, `4this is not. `b`3This is sport!`b `&`n"); 
output(" Fighting while injured may result in your death!`n"); 

    addnav("Fighters"); 
    addnav("(E) Eric - 60gold","arenaeric.php"); 
    addnav("(H) Helena - 75gold","arenahelena.php"); 
    addnav("(Z) Zena - 90gold","arenazena.php" );  
    addnav("Leave");
    addnav("(R) Return to Castle","castlegwen.php");  
    
} 
page_footer(); 
?>