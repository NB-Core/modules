<?php
/*
Details:
 * This allows users to download files direct from your website
History Log:
 * Version 1.0:
   o Now being tested
*/
require_once("lib/superusernav.php");
function aboutdownload_getmoduleinfo(){
	$info = array(
		"name"=>"Download from this Site",
		"version"=>"1.0",
		"author"=>"`@CortalUX",
		"category"=>"About",
		"vertxtloc"=>"http://dragonprime.net/users/CortalUX/",
		"download"=>"http://dragonprime.net/users/CortalUX/aboutdownload.php",
		"allowanonymous"=>true,
		"override_forced_nav"=>false,
		"settings"=>array(
			"Download from this Site - Settings,title",
			"catNope"=>"What category can users `bnot`b download from?,text|-NONE-",
			"(Any modules that appear in this category cannot be downloaded),note",
			"(Useful if you have 'this site only' modules),note",
			"otherMods"=>"Which modules cannot be downloaded from this website?,text|example1*example2",
			"(Any modules in that field cannot be downloaded),note",
			"(All modules must be star seperated like so: 'module1*module2'),note",
		),
	);
	return $info;
}

function aboutdownload_install(){
	if (!is_module_active('aboutdownload')){
		output("`n`Q`b`cInstalling About Download Module.`c`b`n");
	}else{
		output("`n`Q`b`cUpdating About Download Module.`c`b`n");
	}
	module_addhook("header-about");
	return true;
}

function aboutdownload_uninstall(){
	output("`n`Q`b`cUninstalling About Download Module.`c`b`n");
	return true;
}

function aboutdownload_dohook($hookname,$args){
	global $session;
	switch($hookname){
		case "header-about":
			addnav("Other");
			addnav("Download from this Site","runmodule.php?module=aboutdownload");
			if (httpget('op')=='listmodules') {
				output("`^This page contains the most up-to-date links for downloading modules, but you can optionally download them from this site.`nClick on the link on the side of the page.`n`n");
			}
		break;
	}
}

function aboutdownload_run(){
	global $session;
	if (httpget('op')=='download') {
		aboutdownload_download(httpget('file'));
	} else {
		page_header("About");
		addnav("About LoGD");
		addnav("Game Setup Info","about.php?op=setup");
		addnav("Module Info","about.php?op=listmodules");
		addnav("License Info", "about.php?op=license");
		modulehook("about");
		output("`^You can download most of our module files from this page.`nIf files do not appear on this page, they have not been released.`n`n");
		aboutdownload_list();
		if ($session['user']['loggedin']) {
			addnav("Return to the news","news.php");
		}else{
			addnav("Login Page","index.php");
		}
		page_footer();
	}
}

function aboutdownload_download($file) {
	$category = get_module_setting('catNope');
	$nallowed = explode('|', get_module_setting('otherMods'));
	$n=true;
	if (file_exists("modules/".$file.".php")) {
		require_once("modules/".$file.'.php'); 
		$modinfo = $file."_getmoduleinfo";
		if (function_exists($modinfo)) {
			$info = $modinfo();
			if ($info['category']!=$category&&!isset($nallowed[$file])) {
				$n=false;
				header('Content-Disposition: attachment; filename="'.$file.'.php.txt"');
				header('Content-Type: text/txt');
				readfile("modules/".$file.".php");
				die();
			}
		}
	}
	if ($n) {
		header("Content-type: text/txt");
		echo "This file is not allowed to be downloaded.";
	}
	die();
}

function aboutdownload_list() {
	$category = get_module_setting('catNope');
	$nallowed = explode('*', get_module_setting('otherMods'));
	$category = get_module_setting('catNope');
	$sql = "SELECT * from " . db_prefix("modules") . " WHERE active=1 ORDER BY category,formalname";
	$result = db_query($sql);
	$mname = translate_inline("Module Name");
	$mver = translate_inline("Version");
	$mauth = translate_inline("Module Author");
	$mdown = translate_inline("Download from this Site");
	rawoutput("<table border='0' cellpadding='2' cellspacing='1' bgcolor='#999999'>",true);
	rawoutput("<tr class='trhead'><td>$mname</td><td>$mver</td><td>$mauth</td><td>$mdown</td></tr>",true);
	if (db_num_rows($result) == 0) {
		rawoutput("<tr class='trlight'><td colspan='4' align='center'>");
		output("`i-- No modules installed --`i");
		rawoutput("</td></tr>");
	}
	$cat = "";
	for ($i = 0; $i < db_num_rows($result); $i++) {
		$row = db_fetch_assoc($result);
		require_once('modules/'.$row['modulename'].'.php'); 
		$modinfo = $row['modulename']."_getmoduleinfo";
		if (function_exists($modinfo)) {
			$info = $modinfo();
			$n = $row['modulename'];
			if ($info['category']!=$category&&!isset($nallowed[$n])) {
				if ($cat != $row['category']) {
					rawoutput("<tr class='trhead'><td colspan='4' align='left'>");
					output($row['category']);
					rawoutput(":</td></tr>");
					$cat = $row['category'];
				}
				rawoutput("<tr class='".($i%2?"trlight":"trdark")."'>");
				rawoutput("<td valign='top'>");
				output_notl("`&%s`0", $row['formalname']);
				rawoutput("<td valign='top'>",true);
				output_notl("`^%s`0", $row['version']);
				rawoutput("</td><td valign='top'>");
				output_notl("`^%s`0", $row['moduleauthor'], true);
				rawoutput("</td><td nowrap valign='top'>");
				rawoutput("<a class='colLtGreen' href='runmodule.php?module=aboutdownload&op=download&file=".$row['modulename']."' target='_blank'>");
				addnav("","runmodule.php?module=aboutdownload&op=download&file=".$row['modulename']);
				output_notl("`@".$mdown);
				rawoutput("</a>");
				rawoutput("</td>");
				rawoutput("</tr>");
			}
		}
	}
	rawoutput("</table>");
	output("`n`@Any modules that do not appear on this page, cannot be downloaded from this site.");
}
?>