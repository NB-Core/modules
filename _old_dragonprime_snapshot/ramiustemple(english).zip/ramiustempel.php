<?php
// Idea & programming
// Morpheus aka Apollon
// for www.morpheus-lotgd.de.vu in 2005
// Mail to morpheus@magic.ms
// dedicated to my wonderfull, beloved flower
require_once "common.php";
page_header("Temple of Ramius");

if ($HTTP_GET_VARS[op]==""){
	output("`7`b`cTemple of Ramius`c`b");
	output("`n<table align='center'><tr><td><IMG SRC=\"images/stadt/tempel1.jpg\"></tr></td></table>`n",true);
	output("`3You enter a dark temple, that's lit by torches, that hang around the walls.");
	output("`3The temple hall seems to be endlessly big in this twilight. In the middle of the hall you recognize a statue of `4Ramius `3and an altar in front of it, there you see a `%priest `3who waves at you to come near.`n");
	output("`3Carfully you step foward to the altar: `7Be welcome at the temple of Ramius, `6".$session['user']['name']."`7. So, you came here to crave the grace of Ramius from within the world of the living?`n");
	output("`3While he speaks, shivers run down you back, 'cause the `%priest `3looks  like one of `4Ramius `3creatures, but you nod, cause that's what you came for.`n");
	output("`7So `3he explains`7 that's no problem, if you have enough Gems to pay the price of Ramius grace`3.`n");
	output("`3 He informs you that: `610 favor `7will cost you `63 Gems`7, how many do you want to buy?.`n");
	$cost10 = (3);
	$cost20 = (5);
	$cost50 = (12);
	$cost100 = (15);
        addnav("Quantity/Costs");
        addnav("`610 `%favor - `6($cost10 gems)","ramiustempel.php?op=10");
        addnav("`620 `%favor  - `6($cost20 gems)","ramiustempel.php?op=20");
        addnav("`650 `%favor  - `6($cost50 gems)","ramiustempel.php?op=50");
        addnav("`6100 `%favor  - `6($cost100 gems)","ramiustempel.php?op=100");
	addnav("`bBack`b");
	addnav("s?Back to the street", "village.php");
     }
else if ($HTTP_GET_VARS[op]=="10"){
	if($session[user][gems]>=3){
		output("`n`3He takes your `6 3 Gems `3and drops them into a `Tchest`3 which is sitting before the `5statue `3on the altar, then raises his arms up and looks up to the `5statue `3. The eyes of the statue start to send out a ray of light.`n");
		output("`3The `%priest `3takes down his arms, turns around and looks at you: `7Your payment has been accepted and you now have`610 favor`7 with `5Ramius `7.");
		$session['user']['deathpower']+=10;
		$session['user']['gems']-=3;
 		addnav("f?Buy more favor", "ramiustempel.php");
		addnav("s?Back to the street", "village.php");
	}else{
		output("`n`3 He looks upon you and begins to laugh eeriely:`7You came here without having enough Gems? Do you want to incure the wrath of `5Ramius `7?`n");
		output("`3 He then turns around again praying to the `5Ramius `3statue`n");
		addnav("s?Back to the street", "village.php");
		}
      }
else if ($HTTP_GET_VARS[op]=="20"){
	if($session[user][gems]>=5){
		output("`n`3He takes your `6 5 Gems `3and drops them into a `Tchest`3 which is sitting before the `5statue `3on the altar, then raises his arms up and looks up to the `5statue `3. The eyes oft the statue starts to send out a ray of light.`n");
		output("`3The `%priest `3takes down his arms, turns around and looks at you: `7Your payment has been accepted and you now have`620 favor`7 with `5Ramius `7.");
		$session['user']['deathpower']+=20;
		$session['user']['gems']-=5;
 		addnav("f?Buy more favor", "ramiustempel.php");
		addnav("s?Back to the street", "village.php");
	}else{
		output("`n`3 He looks upon you and begins to laugh eeriely:`7You came here without having enough Gems? Do want to incure the wrath of `5Ramius `7?`n");
		output("`3 He then turns around again praying to the `5Ramius `3statue`n");
		addnav("s?Back to the street", "village.php");
		}
      }
else if ($HTTP_GET_VARS[op]=="50"){
	if($session[user][gems]>=12){
		output("`n`3He takes your `6 12 Gems `3and drops them into a `Tchest`3 which is sitting before the `5statue `3on the altar, then raises his arms up an looks up to the `5statue `3. The eyes oft the statue starts to send out a ray of light.`n");
		output("`3The `%priest `3takes down his arms, turns around and looks at you: `7Your payment has been accepted and you now have`650 favor`7 with `5Ramius `7.");
		$session['user']['deathpower']+=50;
		$session['user']['gems']-=12;
 		addnav("f?Buy more favor", "ramiustempel.php");
		addnav("s?Back to the street", "village.php"); 
	}else{
		output("`n`3 He looks upon you and begins to laugh eeriely:`7You came here without having enough Gems? Do want to incure the wrath of `5Ramius `7?`n");
		output("`3 He then turns around again praying to the `5Ramius `3statue`n");
		addnav("s?Back to the street", "village.php");
		}
      }
else if ($HTTP_GET_VARS[op]=="100"){
	if($session[user][gems]>=15){
		output("`n`3He takes your `6 15 Gems `3and drops them into a `Tchest`3 which is sitting before the `5statue `3on the altar, then raises his arms up an looks up to the `5statue `3. The eyes of the statue start to send out a ray of light.`n");
		output("`3The `%priest `3takes down his arms, turns around and looks at you: `7Your payment has been accepted and you now have`6100 favor`7 with `5Ramius `7.");
		$session['user']['deathpower']+=100;
		$session['user']['gems']-=15;
 		addnav("f?Buy more favor", "ramiustempel.php");
		addnav("s?Back to the street", "village.php");  
	}else{
		output("`n`3 He looks upon you and beginns to laugh eeriely:`7You came here without having enough Gems? Do want to incure the wrath of `5Ramius `7?`n");
		output("`3 He then turns around again praying to the `5Ramius `3statue`n");
		addnav("s?Back to the street", "village.php");
		}
      }
page_footer();
?> 
