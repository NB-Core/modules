<?php
/*
Module Name:  Spelling Bee
Category:  Forest Specials
Worktitle:  spellingbee
Author:  DaveS

Description:
This mod is a fun forest special with several options.

A random event pulls the player onto a stage to participate in a spelling bee officianted by a bee.
The player has to answer 3 questions correctly to win the contest.  They always have the option of 
attacking the bee.

Here are the consequences of each action:
1.  Winning the Spelling Bee:  Gain 200+50/level gold + 2 ffs + news
2.  Lose the Spelling Bee:  Lose 1 ff + news
3.  Attack Bee and Win:  Gain exp, gain 1 gold, lose 1 ff, and gain the buff "Speling Powre" + news
4.  Attack Bee and Lose:  Die, Lose 10% exp, and lose all gold + news

In addition, the spelling words are randomized with 4 different words for each of the 3 rounds.

The Spelling Bee ends with one of four animal based jokes.

v3.0 Cleaned up code a little and added vertxtloc
v3.01 little fix to news announcement
v3.1  Fixed some bugs (where do they all come from?), split to folder, improved translation readiness
v3.11 Changed new reporting so you know how many people have won the spelling bee.
*/

function spellingbee_getmoduleinfo(){
	$info = array(
		"name"=>"Spelling Bee",
		"version"=>"3.11",
		"author"=>"DaveS",
		"category"=>"Forest Specials",
		"download"=>"http://dragonprime.net/index.php?module=Downloads;sa=dlview;id=178",
		"vertxtloc"=>"",
		"settings"=>array(
			"Spelling Bee - Settings,title",
			"expmin"=>"Experience for Bee: Level * minimum: |25",
			"expmax"=>"Experience for Bee: Level * maximum: |50",
			"annualnumb"=>"How many people have won the spelling bee?,int|0",
		),
		"prefs"=>array(
			"Spelling Bee - Preferences,title",
			"spellbee"=>"Participated in the Spelling Bee this newday?,bool|0",
		),
	);
	return $info;
}
function spellingbee_chance() {
	global $session;
	if (get_module_pref('spellbee','spellingbee',$session['user']['acctid'])==1) return 0;
	return 100;
}
function spellingbee_install(){
	module_addeventhook("forest","require_once(\"modules/spellingbee.php\"); 
	return spellingbee_chance();");
	module_addhook("newday");
	return true;
}
function spellingbee_uninstall(){
	return true;
}
function spellingbee_dohook($hookname,$args){
	global $session;
	switch ($hookname) {
		case "newday":
			set_module_pref("spellbee",0);
		break;
	}
	return $args;
}
function spellingbee_runevent($type) {
	global $session;
	$session['user']['specialinc']="module:spellingbee";
	$op = httpget('op');
	set_module_pref("spellbee",1);
	output("`n`c`b`^T`!h`^e `!S`^p`!e`^l`!l`^i`!n`^g `!B`^e`!e`0`c`b`n`n");
	output("`@You come to a large section of tight brush, pushing forward to an opening into a large clearing...`n`n");
	output("`2And find yourself standing on a stage!!`n`n");
	output("Dazed for a second, you look around to see a crowd of studious forest animals watching you.");
	output("`Q A zebra is sunbathing.");
	output("For some reason, a snail is sitting in a little car.");
	output("Over by the drink stand, a termite is asking 'Is the bartender here?'");
	output("A dog sits on a chair reciting names of baseball players.`n`n");
	output("`2You notice you are standing in front of a primitive cone-shaped megaphone.");
	output("To your right is a very impressive looking bee.");
	output("He has a long handlebar mustache and is dressed in a tuxedo and a top hat.");
	output("You look closely and notice he is wearing a monocle, and your mind is distracted as you wonder 'Where did he find an optometrist in this place?'`n`n");
	output("You hear the bee clear his throat as if waiting for your response and it hits you!");
	output("You�ve walked right into the middle of a `^Spelling Bee`2!!!!!`n`n");
	addnav("C?Continue","runmodule.php?module=spellingbee&op=continue");
}
function spellingbee_run(){
	global $SCRIPT_NAME;
	if ($SCRIPT_NAME == "runmodule.php"){
		$module=httpget("module");
		if ($module == "spellingbee"){
			include("modules/spellingbee/spellingbee.php");
		}
	}
}
?>