<?php
page_header("The Spelling Bee");
global $session;
$session['user']['specialinc']="module:spellingbee";
$op = httpget('op');
if($op=="continue"){
	output("`n`c`b`^T`!h`^e `!S`^p`!e`^l`!l`^i`!n`^g `!B`^e`!e`0`c`b`n`n");
	output("`@Still confused by the strange situation you suddenly find yourself in, you ask the bee to explain what is going on.`n`n");
	output("Perhaps more surprising than the fact that you think the bee is going to talk, is the fact that the bee does!");
	output("And he responds with the most snobbish attitude you could ever imagine to hear from a talking bee...`n`n");
	output("`7'My name is Professor Riah, PhD.");
	output("You are obviously a contestant in the `^First Annual Forest Spelling Bee`7.'`n`n");
	output("`7Here are the rules:");
	output("You are in the final round of the contest.");
	output("The current leader spelled two words correctly.");
	output("If you can spell the next three words correctly, you will win.");
	output("There's no such thing as a tie though, so if you only get two words correct you will lose.'`n`n");
	output("`7'Are you ready for the next word?'`n`n");
	output("`@You have three choices.`n`n");
	output("If you want to compete in the competition, you can just nod your head and say `Q'Yes'`@.`n");
	output("If you want to leave, you can just `QWalk Away`@.`n");
	output("If you realize how stupid spelling bees are, you can `QSmoosh the Snobbish Professor Riah, PhD`@.`n");
	addnav("Options");
	addnav("Yes, I will compete","runmodule.php?module=spellingbee&op=question1");
	addnav("No, I'm going back to the forest","runmodule.php?module=spellingbee&op=leavebee");
	addnav("Smoosh the Snobbish Bee!","runmodule.php?module=spellingbee&op=attack");
}
if($op=="question1"){
	output("`n`c`b`^T`!h`^e `!S`^p`!e`^l`!l`^i`!n`^g `!B`^e`!e`0`c`b"); 
	output("`c`b`7Question One`0`c`b`n`n");
	output  ("`@Choose the correct spelling of the following word:`n`n");
	addnav("Choose");
	switch(e_rand(1,4)){
		case 1:
			output("`3What is it called when part of a flower is being fertilized?`n`n");
			output("`#1) polinatting`n");
			output("2) polinating`n");
			output("3) pollinating`n"); //correct!
			output("4) pollinatting`n");
			addnav("1) polinatting","runmodule.php?module=spellingbee&op=jj68baef");
			addnav("2) polinating","runmodule.php?module=spellingbee&op=jj84eabf");
			addnav("3) pollinating","runmodule.php?module=spellingbee&op=jj86bfea"); //correct!
			addnav("4) pollinatting","runmodule.php?module=spellingbee&op=jj68efab");
		break;
		case 2:
			output("`3What is it called when something is done with unintentional lack of care?`n`n");
			output("`#1)inadvertently`n"); //correct!
			output("2)inadvertantlly`n");
			output("3)inadvertentlly`n");
			output("4)inadvertantly`n");
			addnav("1)inadvertently","runmodule.php?module=spellingbee&op=jj86bfea"); //correct!
			addnav("2)inadvertantlly","runmodule.php?module=spellingbee&op=jj84eabf");
			addnav("3)inadvertentlly","runmodule.php?module=spellingbee&op=jj68baef");
			addnav("4)inadvertantly","runmodule.php?module=spellingbee&op=jj68efab");
		break;
		case 3:
			output("`3What is it called when you don't have enough of something?`n`n");
			output("`#1)insuficient`n");
			output("2)insuficiant`n");
			output("3)insufficient`n");  //correct!
			output("4)insufficiant`n");
			addnav("1)insuficient","runmodule.php?module=spellingbee&op=jj68baef");
			addnav("2)insuficiant","runmodule.php?module=spellingbee&op=jj84eabf");
			addnav("3)insufficient","runmodule.php?module=spellingbee&op=jj86bfea");  //correct!
			addnav("4)insufficiant","runmodule.php?module=spellingbee&op=jj68efab");
		break;
		case 4:
			output("`3What is it called when something occurs from time to time?`n`n");
			output("`#1)occasionaly`n");
			output("2)occassionally`n");
			output("3)ocassionaly`n");
			output("4)occasionally`n"); //correct!
			addnav("1)occasionaly","runmodule.php?module=spellingbee&op=jj68baef");
			addnav("2)occassionally","runmodule.php?module=spellingbee&op=jj84eabf");
			addnav("3)ocassionaly","runmodule.php?module=spellingbee&op=jj68efab");
			addnav("4)occasionally","runmodule.php?module=spellingbee&op=jj86bfea"); //correct!
		break;
	}
	addnav("Or Instead...");
	addnav("Smoosh the Snobbish Bee!","runmodule.php?module=spellingbee&op=attack");
}
if($op=="jj86bfea"){
	output("`n`c`b`^T`!h`^e `!S`^p`!e`^l`!l`^i`!n`^g `!B`^e`!e`0`c`b");
	output("`c`b`7Question Two`0`c`b`n");
	output("`b`^Correct!`0`b`n`n");
	output("`7Dr. Riah does not seem too impressed, but the forest animals give a quiet cheer to encourage you.");
	output("You're doing great and ready for the next word...`n`n");
	output("`@Choose the correct spelling of the following word:`n`n");
	addnav("Choose");
	switch(e_rand(1,4)){
		case 1:
			output("`3What is it called when you keep something cold?`n`n");
			output("`#1)refrigerated`n");//correct!
			output("2)refridgerated`n");
			output("3)refrigarated`n"); 
			output("4)refridgarated`n");
			addnav("1)refrigerated","runmodule.php?module=spellingbee&op=jj88eafb"); //correct!
			addnav("2)refridgerated","runmodule.php?module=spellingbee&op=jj68baef"); 
			addnav("3)refrigarated","runmodule.php?module=spellingbee&op=jj84eabf");
			addnav("4)refridgarated","runmodule.php?module=spellingbee&op=jj68efab");
		break;
		case 2:
			output("`3What is it called when something is done right away?`n`n");
			output("`#1)imediately`n"); 
			output("2)immediately`n"); //correct!
			output("3)imediatly`n"); 
			output("4)immediatly`n");
			addnav("1)imediately","runmodule.php?module=spellingbee&op=jj68baef"); 
			addnav("2)immediately","runmodule.php?module=spellingbee&op=jj88eafb"); //correct!
			addnav("3)imediatly","runmodule.php?module=spellingbee&op=jj84eabf");
			addnav("4)immediatly","runmodule.php?module=spellingbee&op=jj68efab");
		break;
		case 3:
			output("`3What is it called when you have lost awareness?`n`n");
			output("`#1)unconciousnes`n"); 
			output("2)unconsciousness`n"); //correct!
			output("3)unconsciousnes`n"); 
			output("4)unconciousness`n");
			addnav("1)unconciousnes","runmodule.php?module=spellingbee&op=jj68baef"); 
			addnav("2)unconsciousness","runmodule.php?module=spellingbee&op=jj88eafb"); //correct!
			addnav("3)unconsciousnes","runmodule.php?module=spellingbee&op=jj84eabf");
			addnav("4)unconciousness","runmodule.php?module=spellingbee&op=jj68efab");
		break;
		case 4:
			output("What is it called when something is dispersed almost to the point of disappearing`3?`n`n");
			output("`#1)dissippates`n"); 
			output("2)dissipates`n"); //correct!
			output("3)disapates`n"); 
			output("4)disappates`n");
			addnav("1)dissippates","runmodule.php?module=spellingbee&op=jj68baef"); 
			addnav("2)dissipates","runmodule.php?module=spellingbee&op=jj88eafb"); //correct!
			addnav("3)disapates","runmodule.php?module=spellingbee&op=jj84eabf");
			addnav("4)disappates","runmodule.php?module=spellingbee&op=jj68efab");
		break;
    }
	addnav("Or Instead...");
	addnav("Smoosh the Snobbish Bee!","runmodule.php?module=spellingbee&op=attack");
}
if($op=="jj88eafb"){
	output("`n`c`b`^T`!h`^e `!S`^p`!e`^l`!l`^i`!n`^g `!B`^e`!e`0`c`b");
	output("`c`b`7Question Three`0`c`b`n");
	output("`b`^Correct!`0`b`n`n");
	output("`7Once again, Dr. Riah does not seem too impressed, but the forest animals give a slightly louder cheer to encourage you.");
	output("This is it!");
	output("The final spelling word...`n`n");
	output("`@Choose the correct spelling of the following word:`n`n");
	addnav("Choose");
	switch(e_rand(1,4)){
		case 1:
			output("`3What is it when you roam about in search of pleasure?`n`n");
			output("`#1)galavanting`n"); 
			output("2)gallavanting`n"); 
			output("3)galivanting`n");
			output("4)gallivanting`n"); //correct
			addnav("1)galavanting","runmodule.php?module=spellingbee&op=jj68baef"); 
			addnav("2)gallavanting","runmodule.php?module=spellingbee&op=jj84eabf");
			addnav("3)galivanting","runmodule.php?module=spellingbee&op=jj68efab");
			addnav("4)gallivanting","runmodule.php?module=spellingbee&op=jj64aefb"); //correct!
		break;
		case 2:
			output("`3What is it when you ask for help?`n`n");
			output("`#1)assistance`n"); //correct!
			output("2)asistance`n"); 
			output("3)assisstance`n"); 
			output("4)asisstance`n");
			addnav("1)assistance","runmodule.php?module=spellingbee&op=jj64aefb"); //correct!
			addnav("2)asistance","runmodule.php?module=spellingbee&op=jj68baef"); 
			addnav("3)assisstance","runmodule.php?module=spellingbee&op=jj84eabf");
			addnav("4)asisstance","runmodule.php?module=spellingbee&op=jj68efab");
		break;
		case 3:
			output("`3What is a favorable circumstance? ?`n`n");
			output("`#1)opportunity`n"); //correct!
			output("2)opprotunity`n"); 
			output("3)oportunity`n"); 
			output("4)oprotunity`n");
			addnav("1)opportunity","runmodule.php?module=spellingbee&op=jj64aefb"); //correct!
			addnav("2)opprotunity","runmodule.php?module=spellingbee&op=jj68baef"); 
			addnav("3)oportunity","runmodule.php?module=spellingbee&op=jj84eabf");
			addnav("4)oprotunity","runmodule.php?module=spellingbee&op=jj68efab");
		break;
		case 4:
			output("What is it when something said is incomprehensible`3?`n`n");
			output("`#1)uninteligably`n"); 
			output("2)unintelligably`n"); 
			output("3)uninteligibly`n"); 
			output("4)unintelligibly`n"); //correct!
			addnav("1)uninteligably","runmodule.php?module=spellingbee&op=jj68baef"); 
			addnav("2)unintelligably","runmodule.php?module=spellingbee&op=jj84eabf");
			addnav("3)uninteligibly","runmodule.php?module=spellingbee&op=jj68efab");
			addnav("4)unintelligibly","runmodule.php?module=spellingbee&op=jj64aefb"); //correct!
		break;
		}
	addnav("Or Instead...");
	addnav("Smoosh the Snobbish Bee!","runmodule.php?module=spellingbee&op=attack");
}
if($op=="jj64aefb"){
	increment_module_setting("annualnumb",1);
	$numberpost=array("","st","nd","rd","th");
	$numbwin=get_module_setting("annualnumb");
	if ($numbwin>=4) $numbwin=4;
	output("`n`c`b`^T`!h`^e `!S`^p`!e`^l`!l`^i`!n`^g `!B`^e`!e`0`c`b`n");
	output("`c`b`^You Won!`0`b`c`n");
	output("`@All the forest animals cheer!`n`n");
	$goldgain=($session['user']['level']*50+200);
	$session['user']['gold']+=$goldgain;
	output("You go to collect your prize and find the trophy is made of pure gold!");
	output("By melting it down, you find that it's worth `^%s gold`@!!`n`n",$goldgain);
	output("In addition, you feel so good you have `^2 more forest fights`@!");
	$session['user']['turns']+=2;
	addnews("`@%s won the `^%s%s Interspecies Spelling Bee `@in the forest!",$session['user']['name'],get_module_setting("annualnumb"),$numberpost[$numbwin]);
	addnav("Continue","runmodule.php?module=spellingbee&op=leavebee");
}
if($op=="jj68baef" || $op=="jj84eabf" || $op=="jj68efab"){
	output("`n`c`b`^T`!h`^e `!S`^p`!e`^l`!l`^i`!n`^g `!B`^e`!e`0`c`b`n");
	output("`c`b`^Wrong Answer!`0`b`c`n");
	output("`@You shake your head in disbelief as you realize you spelled it wrong.");
	output("Before you get a chance to ask for the correct answer, you are shuffled off the stage to watch the winning animal rise to collect the Spelling Bee Trophy.");
	output("You can't believe it, but the winner of the competition is a `7Chicken`@!`n`n");
	output("Oh well... for wasting everyone's time you `^lose a forest fight`@.");
	$session['user']['turns']--;
	addnews("%s`@ lost in a `^Spelling Bee `@to a `7Chicken`@!",$session['user']['name']);
	addnav("Continue","runmodule.php?module=spellingbee&op=leavebee");
}
if ($op=="attack") {
	$level = $session['user']['level']-1;
	if ($level<=0) $level=1;
	$badguy = array(
		"creaturename"=>"`!S`^p`!e`^l`!l`^i`!n`^g `!B`^e`!e",
		"creaturelevel"=>$level,
		"creatureweapon"=>" a nerdy stinger",
		"creatureattack"=>round($session['user']['attack']*1.2),
		"creaturedefense"=>round($session['user']['defense']*0.9),
		"creaturehealth"=>round($session['user']['maxhitpoints']*1,0),
		"diddamage"=>0,
		"type"=>"spelingbee");
	$session['user']['badguy']=createstring($badguy);
	$op="fight";
}
if ($op=="fight"){ $battle=true; }
if ($battle){       
	include("battle.php");  
	if ($victory){
		$expmin= get_module_setting("expmin");
		$expmax= get_module_setting("expmax");
		$expmultiply = e_rand($expmin,$expmax);
		$expbonus=$session['user']['dragonkills']*4;
		$expgain =($session['user']['level']*$expmultiply+$expbonus);
		$session['user']['experience']+=$expgain;
		output("`@You ganed `#%s `@expereince.`n",$expgain);
		$session['user']['gold']++;
		//My apologies to people translating the next sentences.  They are intentionally spelled wrong.
		output("`n`6You did it! You killed the bee!");
		output("Speling is for losers!  All the animals rize up and cheer!");
		output("They throw away their glasses and notebooks and carry you around on their showlders.");
		output("You feel wonderful!`n`n");
		output("`@You ganed `^1 `@gold.  You found it stuck to your shoo.`n`n");
		output("You feal so good about yorselve that you feal stronger!`n`n");
		output("Unfotunately, you didn't notise the stinger that lodged in your hand.  You `^lose 1 turn`@ picking out the stingar!`n");
		if ($session['bufflist']['spellingbee']==""){
			apply_buff('spellingbee',array("name"=>"`^Speling Powre","rounds"=>5,"wearoff"=>"`4Your Spelling Improves.","atkmod"=>1.04,"activate"=>"offense"));
		}
		$session['user']['turns']--;
		addnews("%s`@ crushed the `^Spelling Bee `@to deth!",$session['user']['name']);
		addnav("Continue","runmodule.php?module=spellingbee&op=leavebee");
	}elseif($defeat){
		$session['user']['specialinc'] = "";
		require_once("lib/taunt.php");
		$taunt = select_taunt_array();
		$exploss = round($session['user']['experience']*.1);
		output("`n`b`4Oh No! You're allergic to bee stings and you've died from one!`n");
		output("`4All gold on hand has been lost!`n");
		output(" You lose `^%s `4experience.",$exploss);
		output("`n`n`c`@You may begin fighting again tomorrow.`c`b");
		addnav("Daily news","news.php");
		$session['user']['experience']-=$exploss;
		$session['user']['alive'] = false;
		$session['user']['hitpoints'] = 0;
		$session['user']['gold']=0;
		addnews("%s `@was schooled by the `^Spelling Bee`@ and was slain!`n%s",$session['user']['name'],$taunt);
	}else{
		require_once("lib/fightnav.php");
		fightnav(true,false,"runmodule.php?module=spellingbee");
	}
}
if ($op=='leavebee') {
	output("`n`@You turn back to the thick of the forest, thinking that this was a strange day.");
	output("In particular, you reflect on some of the strange activities of the animals in the forest.");
	output("And then you suddenly understand and you recall the joke...`n`n");
	switch(e_rand(1,4)){
		case 1:
			output("`QWhat is black and white and red all over?`n`n");
			output("`QA Zebra with a Sunburn!");
		break;
		case 2:
			output("`QA snail went to a car dealer and proceeded to order a car.");
			output("The snail mentions that he wants an S on both sides and on the hood and the trunk.`n`n");
			output("'What is the S for? Is it for snail?' asked the salesman.`n`n");
			output("No! I want people to say 'Gee whiz, look at that S car go!'");
		break;
		case 3:
			output("`QA termite walks into a bar, sits down, and asks 'Is the Bartender here?'`n`n");
			output("Get it? Is the bar nice and tender at this spot...");
		break;
		case 4:
			output("`QA man walks into a bar with a dog and tells everyone that his dog can talk.`n");
			output("The man proceeds to prove his claim by asking the dog 3 questions.`n`n");
			output("What is on top of a house?`n");
			output("The dog replies '`@roof!`Q'`n`n");
			output("What is on a tree?`n");
			output("The dog replies '`@bark!`Q'`n`n");
			output("Who is the greatest baseball player ever?`n");
			output("The dog sits up proudly and says '`@Ruth!`Q'`n`n");
			output("The man and his dog are promptly kicked out of the bar.`n");
			output("The dog leans over to the man and, somewhat frustrated, says '`@Do you think I should have said DiMaggio?`Q'`n`n");
		break;
	}
	$session['user']['specialinc']="";
	addnav("Back to the Forest","forest.php");
}
page_footer();
?>