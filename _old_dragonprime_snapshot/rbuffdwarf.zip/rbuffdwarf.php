<?php
//This is my first attempt at writing a module.
//It is a special buff to max hit points based on how much gold the player is carrying.  
//It is intended for dwarves, but race is selectable by admin.  If loss of gold causes
//player to reach 0 hp's (or less), the dwarf dies of gold fever.

function rbuffdwarf_getmoduleinfo(){
	$info = array(
		"name"=>"Gold Fever",
		"version"=>"1.0",
		"author"=>"Jason Tomlinson",
		"category"=>"Racial Buff",
		"download"=>"http://myweb.cableone.net/jtomlins/",
		"settings"=>array(
			"Gold Fever,title",
			//The amount of max hp's and xp loss on death is adjustable by the user
			"goldperhp"=>"Amount of Gold per Max Hp Gained,int|100",
			"feverloss"=>"XP% Loss for Gold Fever,int|15",
			"availablerace"=>"Which Race?,float|Dwarf",
		),
		"prefs"=>array(
			"Gold Fever Preferences,title",
			"hpgained"=>"Hit Points Gained from Gold Fever,int|0",
			"goldfeverdeath"=>"Died From Gold Fever?,int|0"
		),
	);
	return $info;
}

//I haven't tested every hook yet.  Most of them I put there so they can die if they lose gold
function rbuffdwarf_install(){
	module_addhook("forest");
	module_addhook("village");
	module_addhook("lumberyard");
	module_addhook("lostruins");
	module_addhook("quarry");
	module_addhook("travel");
	module_addhook("villagetext");
	module_addhook("shades");
	return true;
}

function rbuffdwarf_uninstall(){
	return true;
}

function rbuffdwarf_dohook($hookname,$args){
	global $session;
	switch($hookname){
		case ($hookname):
		//only works for race selected in settings
		$avrace = get_module_setting ("availablerace");
		if ($session['user']['race'] == $avrace) {
		if ($hookname != "shades"){
			//Calculates and adjusts max hp's, also compensates current hp's
			$dgoldperhp =  get_module_setting ("goldperhp");
			$oldhpgained = get_module_pref ("hpgained");
			$newhpgained = round(($session['user']['gold'] / $dgoldperhp));
			$currentmaxhp = ($session['user']['maxhitpoints']);
			$currenthp = ($session['user']['hitpoints']);
			$adjustedmaxhp = ($currentmaxhp + $newhpgained - $oldhpgained);
			$adjustedhp = ($currenthp + $newhpgained - $oldhpgained);
			set_module_pref ("hpgained",$newhpgained,"rbuffdwarf");

			//Adds a visual so player knows what's going on.  Note the buff does not affect stats.  If this buff is 
			//removed, it will only remove the display, not the buff
			$bueffname1 = "`^Gold Fever `6(+"; 
			$bueffname2 = " Max Hp's)";
			$bueffname3 = $bueffname1.$newhpgained.$bueffname2;
				apply_buff("rbuffdwarfSTAT",
					array(
						"name"=>$bueffname3,
						"rounds"=>"-1",
						"schema"=>"module-rbuffdwarf",
					)
				);
			if ($newhpgained - $oldhpgained > 0){	
			
				//a visual prompt to help clue the player in, along with the debug line.  
				output("`n`^Your insane passion for gold increases your fortitude`^!`0`n");
				debuglog("maxhp's were increased 'cuz he or she is a greedy s.o.b");
			}
			if ($newhpgained - $oldhpgained < 0){	  
				output("`n`^Your insane passion for gold decreases your fortitude`^!`0`n");
				debuglog("maxhp's were decreased 'cuz he or she is a greedy s.o.b");
			}
			//HP stat adjustment made
			$session['user']['maxhitpoints'] = $adjustedmaxhp;
			$session['user']['hitpoints'] = $adjustedhp;


			//This is the gold fever part if you die. I had a lot of trouble with this for a while.  I kept killing
			//players as soon as they were resurrected.  I learned the difference between "=" and "==" (instead of 
			// checking to see if player's hp were zero, it kept setting them to zero).  I rewrote this many times
			$xpsetting = get_module_setting ("feverloss");
			$xpchar = $session['user']['experience'] ;
			$xploss = (100- $xpsetting)*.01*$xpchar;
			if ($session['user']['hitpoints'] < 0) $feverdeath = 1;
			if ($session['user']['hitpoints'] == 0) $feverdeath = 1;
			if ($feverdeath == 1){
				$session['user']['alive'] = 0;
				set_module_pref ("goldfeverdeath", 1, "rbuffdwarf");
				$session['user']['experience'] = $xploss;				
				$session['user']['gold'] = 0;
			}}

			//tells you why you died.
			if ($hookname == "shades"){
				$gfever =  get_module_pref ("goldfeverdeath");
				if ($gfever == 1){
					output("`^Your lust for gold is no longer enough to sustain you...  You have died.");
					output(("You lose ").$xpsetting.("% of your experience.  You have lost all of your precious gold.`n"));
					set_module_pref ("goldfeverdeath", 0, "rbuffdwarf");
				}
			}
		}
	}
	return $args;
}
?>
