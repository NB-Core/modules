<?php

function newdaystats_getmoduleinfo(){
	$info = array(
		"name"=>"New Day Info in Stats",
		"version"=>"0.01",
		"author"=>"Derek0",
		"category"=>"Stat Display",
		"download"=>"http://dragonprime.net/users/Derek/newdaystats.txt",
	);
	return $info;
}

function newdaystats_install(){
	if (!is_module_active('newdaystats')){
		output("`4Installing New Day Stats Module.`n");
	}else{
		output("`4Updating New Day Stats Module.`n");
	}
	module_addhook("charstats");
	return true;
}

function newdaystats_uninstall(){
	output("`4Uninstalling New Day Stats Module.`n");
	return true;
}

function newdaystats_dohook($hookname,$args){
	global $session;
	switch($hookname){
   	case "charstats":
      $secstonewday = secondstonextgameday();
			addcharstat("Vital Info");
			addcharstat("Next New Day", date("G\\h, i\\m, s\\s \\(\\r\\e\\a\\l\\ \\t\\i\\m\\e\\)",
				$secstonewday));
   	break;
	}
	return $args;
}
