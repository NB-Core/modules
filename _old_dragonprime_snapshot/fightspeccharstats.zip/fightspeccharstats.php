<?php

function fightspeccharstats_getmoduleinfo(){
	$info = array(
		"name"=>"Kampfspezialisierung Stat-display",
        "version"=>"1.0",
        "author"=>"Haku",
        "category"=>"Stat Display",
		"download"=>"http://dragonprime.net/users/chicu/fightspeccharstats.zip",
        );
	return $info;
}

function fightspeccharstats_install(){
	module_addhook("charstat");
	return true;
}

function fightspeccharstats_uninstall(){
	return true;
}

function fightspeccharstats_dohook($hookname,$args){
	global $session;
	switch($hookname){
    case "charstats":
       $title = translate_inline("Vital Info");
       $name = translate_inline("Kampfspezialit�t");
       $line = get_module_pref("fightspec","elis_fightspec");
       setcharstat($title,$name,$line);
	   break;
	}
	return $args;
}
?>