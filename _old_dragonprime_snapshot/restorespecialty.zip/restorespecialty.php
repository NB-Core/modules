<?php

function restorespecialty_getmoduleinfo(){
   $info = array(
      "name"=>"Restore Specialty",
      "author"=>"Chris Vorndran",
      "category"=>"General",
      "version"=>"1.0",
	  "download"=>"http://dragonprime.net/index.php?module=Downloads;sa=dlview;id=80",
	  "vertxtloc"=>"http://dragonprime.net/users/Sichae/",
	  "description"=>"In case a database gets corrupted, this module will reset specialty points for a user, based on their level.",
      "prefs"=>array(
         "hasuser"=>"Has this user's specialty been fixed up?,bool|0",
      ),
   );
   return $info;
}
function restorespecialty_install(){
   module_addhook("newday");
   return true;
}
function restorespecialty_uninstall(){
   return true;
}
function restorespecialty_dohook($hookname,$args){
   global $session;
   switch ($hookname){
      case "newday":
         if (!get_module_pref("hasuser")){
            $specialties = modulehook("specialtymodules");
            $spec = $specialties[$session['user']['specialty']];
            $a = $session['user']['level'];
            set_module_pref("uses",ceil($a/3),$spec);
            set_module_pref("skill",$a,$spec);
            set_module_pref("hasuser",1);
         }
         break;
      }
   return $args;
}
?>