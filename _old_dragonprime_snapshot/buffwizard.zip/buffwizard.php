<?php

// Buffwizard 2005 by Eliwood and Serra
// based on Item-Editor (anpera) and on mount-Editor (Eric Stevens?)


require_once "common.php";

page_header("Buffwizard");
addnav("G?Zur�ck zur Grotte","superuser.php");
addnav("W?Zur�ck zum Weltlichen","village.php");


if ($_GET['op']=="save"){
	$buff = array();
	reset($_POST['item']['buff']);
	if (isset($_POST['item']['buff']['activate'])) $_POST['item']['buff']['activate']=join(",",$_POST['item']['buff']['activate']);
	while (list($key,$val)=each($_POST['item']['buff'])){
		if ($val>""){
			$buff[$key]=stripslashes($val);
		}
	}
	$_POST['item']['buff']=$buff;
	reset($_POST['item']);
	$keys='';
	$vals='';
	$sql='';
	$i=0;
	while (list($key,$val)=each($_POST['item'])){
		if (is_array($val)) $val = addslashes(serialize($val));
		if ($_GET['id']>""){
			$sql.=($i>0?",":"")."$key='$val'";
		}else{
			$keys.=($i>0?",":"")."$key";
			$vals.=($i>0?",":"")."'$val'";
		}
		$i++;
	}

	$session['bufflist']['buffwizard'.time()] = $buff;

	$echo = "\$buff = array( \n";
	$j= 0;
	while (list($key,$val)=each($_POST['item']['buff']))
	{
    ($j == 0? "" : $echo.=",");
    $echo.="\"$key\" => \"$val\"\n";
    $j++;
  }
  $echo.="); \n";
  $echo = highlight_string($echo,true);
  rawoutput("<pre>$echo</pre>");
  
  addnav("Neu","buffwizard.php");
}
else
{
  output("Hier darfst du neue Buffs ausprobieren, nach best�tigung des Buffs bekommst du ihn, zus�tzlich dazu noch ein St�ck Code.");
  itemform(array());
}

function itemform($item){
	global $output,$session;
	output("<form action='buffwizard.php?op=save' method='POST'>",true);
	addnav("","buffwizard.php?op=save");
	$output.="<table>";
	$output.="<tr><td valign='top'>Item Buff:</td><td>";
	$output.="<b>Meldungen:</b><Br/>";
	$output.="Buff Name: <input name='item[buff][name]' ><Br/>";
	//output("Initial Message: <input name='mount[mountbuff][startmsg]' value=\"".htmlentities($mount['mountbuff']['startmsg'])."\">`n",true);
	$output.="Meldung jede Runde: <input name='item[buff][roundmsg]'><Br/>";
	$output.="Ablaufmeldung: <input name='item[buff][wearoff]'><Br/>";
	$output.="Effektmeldung: <input name='item[buff][effectmsg]'><Br/>";
	$output.="Kein Schaden Meldung: <input name='item[buff][effectnodmgmsg]'><Br/>";
	$output.="Fehlgeschlagen Meldung: <input name='item[buff][effectfailmsg]'><Br/>";
	$output.="<Br/><b>Effekt:</b><Br/>";
	$output.="H�lt Runden (nach Aktivierung): <input name='item[buff][rounds]' size='5'><Br/>";
	$output.="Angriffsmulti Spieler: <input name='item[buff][atkmod]' size='5'><Br/>";
	$output.="Verteidigungsmulti Spieler: <input name='item[buff][defmod]' size='5'><Br/>";
	$output.="Regen: <input name='item[buff][regen]'><Br/>";
	$output.="Diener Anzahl: <input name='item[buff][minioncount]'><Br/>";
	$output.="Min Badguy Damage: <input name='item[buff][minbadguydamage]' size='5'><Br/>";
	$output.="Max Badguy Damage: <input name='item[buff][maxbadguydamage]' size='5'><Br/>";
	$output.="Min Goodguy Damage: <input name='item[buff][mingoodguydamage]' size='5'><Br/>";
	$output.="Max Goodguy Damage: <input name='item[buff][maxgoodguydamage]'  size='5'><Br/>";
	$output.="Lifetap: <input name='item[buff][lifetap]' size='5'><Br/>";
	$output.="Damage shield: <input name='item[buff][damageshield]'  size='5'> (multiplier)<Br/>";
	$output.="Badguy Damage mod: <input name='item[buff][badguydmgmod]' size='5'> (multiplier)<Br/>";
	$output.="Badguy Atk mod: <input name='item[buff][badguyatkmod]' size='5'> (multiplier)<Br/>";
	$output.="Badguy Def mod: <input name='item[buff][badguydefmod]'  size='5'> (multiplier)<Br/>";
	
	$output.="�berlebt neuen Tag? (Entweder 1 oder 0)<input name='item[buff][survivenewday]' size='5'>(multiplier)<Br/>";
	//$output.=": <input name='mount[mountbuff][]' value=\"".htmlentities($mount['mountbuff'][''])."\">`n",true);
	
	$output.="<Br/><b>Aktiviert bei:</b><Br/>";
	$output.="<input type='checkbox' name='item[buff][activate][]' value=\"roundstart\"> Start der Runde<Br/>";
	$output.="<input type='checkbox' name='item[buff][activate][]' value=\"offense\"> Bei Angriff<Br/>";
	$output.="<input type='checkbox' name='item[buff][activate][]' value=\"defense\"> Bei Verteidigung<Br/>";
	$output.="<Br/>";
	$output.="</td></tr>";
	$output.="</table>";
	$output.="<input type='submit' class='button' value='Speichern'></form>";
	$output.="</form>";
}

page_footer();
?>
