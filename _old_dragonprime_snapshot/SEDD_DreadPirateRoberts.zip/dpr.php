<?php

// Added a default value to basestat
// Added admin configurable percent chance for good outcome
// Changed admin config increment dropdowns to multiples of 5

function dpr_getmoduleinfo(){
	$info = array(
		"name"=>"Dread Pirate Roberts",
		"version"=>"1.0",
		"author"=>"`%Deedee`0 - Built with Module Builder by `3Lonny Luberts`0",
		"category"=>"Multi Specials",
		"download"=>"http://dragonprime.net/index.php?action=viewfiles;user=Deedee",
		"settings"=>array(
		"Dread Pirate Roberts Settings,title",
		"basestat"=>"Stat to base increase and decrease on,enum,charm,Charm,maxhitpoints,Hitpoints,dragonKills,Dragonkills,attack,Attack,defense,Defense|maxhitpoints",
		"baseperc"=>"Percent to increase/decrease stat,range,0,100,5|50",
		"chance"=>"Percent chance for good outcome,range,0,100,5|50"
		),
	);
	return $info;
}

function dpr_install(){
	module_addeventhook("travel","return (is_module_active('cities')?100:0);");
	module_addeventhook("village","return (is_module_active('cities')?0:100);");
	return true;
}

function dpr_uninstall(){
	return true;
}

function dpr_dohook($hookname,$args){
	return $args;
}

function dpr_runevent($type,$link) {
	global $session;
	$from = $link;
	$op = httpget('op');
	$session['user']['specialinc'] = "module:dpr";
	if ($op==""){
		output("`2`7As much as you hope it is your imagination, run wild from too much ale at the Inn last night... What you see barrelling towards you through the center of village square is most certainly, and chillingly without a doubt, the one... the only `4Dread Pirate Roberts `7himself.`n`n");
		output("`7In a dizzying panic, your mind screams \"Whatever shall I do?\"`0");
		addnav("Nod your head in passing",$from."op=yes");
		addnav("Run in the other direction",$from."op=no");
	} elseif ($op=="no") {
		output("`2`7With your heart racing and face cast severely downward, you scurry off in another direction as fast as you can...`0");
		$session['user']['specialinc'] = "";
	} else {
		output("`2`7You nod towards `4Dread Pirate Roberts `7and await his reaction while your stomach does cartwheels...`n`n`0");
		$basestat = get_module_setting("basestat");
		$baseperc = get_module_setting("baseperc") * .01;
		if (e_rand(0,100) <= get_module_setting("chance")) {
			$amt = rand(1,3);
			$session['user']['gems'] += $amt;
			output("`^`7By the grace of all things holy, `4Dread Pirate Roberts `7does not appear to recognize you from days of yore! As he passes by, he throws `6$amt gems `7to the ground at your feet while passing by muttering curses beneath his breath.`n`nWith your face turned away from him lest he recognize you still, you express your thanks as you quickly work to pick up the gems and spirit yourself safely back into the shadows.`0");
			$session['user']['specialinc'] = "";
		} else {
			$amt = round($session['user'][$basestat] * $baseperc);
			if ($amt > $session['user']['gold']) { $amt = $session['user']['gold']; }
			$session['user']['gold']-=$amt;
			output("`4`7Drats! The `4Dread Pirate Roberts `7has recognized you! He demands the `6$amt gold `7you owe him for deserting your agreed upon covenents with his minions in your darkest days. You quickly hand it over and turn away. Heading off into the other direction, as the distance between you grows, you realize how lucky you are to be alive!`n`n");
			$session['user']['specialinc'] = "";
		}
	}
}

function dpr_run(){
}
 
?> 