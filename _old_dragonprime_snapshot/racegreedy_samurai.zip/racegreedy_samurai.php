<?php

function racegreedy_samurai_getmoduleinfo(){
	$info = array(
		"name"=>"Race - Greedy Samurai",
		"version"=>"1.0",
		"author"=>"RPGSL",
		"category"=>"RPGSL",
		"download"=>"http://rpgsl.com/lotgd/racegreedy_samurai.zip",
		"settings"=>array(
		"Greedy Samurai Race Settings,title",
		"minedeathchance"=>"Percent chance for Samurai to die in the mine,range,0,100,1|75",
		"gemchance"=>"Percent chance for Samurai to find a gem on battle victory,range,1,100,1|10",
		"gemmessage"=>"Message to display when finding a gem|`3The Samurai see's a `%gem`&!",
		"mindk"=>"How many DKs do you need before the race is available?,int|20",
		"goldgain"=>"How much gold does a samurai gain in percentage points?,int|25",
		),
	);
	return $info;
}

function racegreedy_samurai_install(){

	module_addhook("chooserace");
	module_addhook("setrace");
	module_addhook("newday");
	module_addhook("charstats");
	module_addhook("raceminedeath");
	module_addhook("battle-victory");
	module_addhook("creatureencounter");
	module_addhook("pvpadjust");
	module_addhook("racenames");
	return true;
}

function racegreedy_samurai_uninstall(){
	global $session;
	$sql = "UPDATE  " . db_prefix("accounts") . " SET race='" . RACE_UNKNOWN . "' WHERE race='Greedy Samurai'";
	db_query($sql);
	if ($session['user']['race'] == 'Greedy Samurai')
	$session['user']['race'] = RACE_UNKNOWN;
	return true;
}

function racegreedy_samurai_dohook($hookname,$args){
	global $session,$resline;

	if (is_module_active("racehuman")) {
	$city = get_module_setting("villagename","racehuman");
	}else{
	$city = getsetting("villagename", LOCATION_FIELDS);
	}
	$race = "Greedy Samurai";
	switch($hookname){
	case "racenames":
	$args[$race] = $race;
	break;
	case "pvpadjust":
	if ($args['race'] == $race) {
		$args['creaturedefense']+=(2+floor($args['creaturelevel']/5));
		$args['creaturehealth']-= round($args['creaturehealth']*.10, 0);
		}
		break;
	case "raceminedeath":
		if ($session['user']['race'] == $race) {
			$args['chance'] = get_module_setting("minedeathchance");
			$args['racesave'] = "Fortunately your Samurai skills once again lets you escape.`n";
			$args['schema']="module-racegreedy_samurai";
		}
		break;
	case "charstats":
		if ($session['user']['race']==$race){
			addcharstat("Vital Info");
			addcharstat("Race", translate_inline($race));
		}
		break;
	case "chooserace":
		if ($session['user']['dragonkills'] < get_module_setting("mindk"))
			break;
		output("<a href='newday.php?setrace=Samurai$resline'>In the village of %s</a>, a village of ancient warriors, you are race of `3Samurai`0, You have great fighting abilty and lasting endurance.`n`n",$city, true);
		addnav("`5Greedy Samurai`0","newday.php?setrace=$race$resline");
		addnav("","newday.php?setrace=$race$resline");
		break;
	case "setrace":
		if ($session['user']['race']==$race){
		output("`&As a Greedy Samurai, you are keen to gain gold and gems, but aren't as stong as normal Samurai.`n");
		output("You gain extra defense, but not as much as normal Samurai receive!`n");
		output("`nYou can spot gems more clearly for being so greedy!`n");
		output("You gain extra gems from forest fights!");
		if (is_module_active("cities")) {
			if ($session['user']['dragonkills']==0 &&
			$session['user']['age']==0){
			set_module_setting("newest-$city",
				$session['user']['acctid'],"cities");
			}
			set_module_pref("homecity",$city,"cities");
			if ($session['user']['age'] == 0)
			$session['user']['location']=$city;
			}
		}
		break;
	case "battle-victory":
		if ($session['user']['race'] != $race) break;
		if ($args['type'] != "forest") break;
		if ($session['user']['level'] <=15 && e_rand(1,100) <= get_module_setting("gemchance")) {
			output(get_module_setting("gemmessage")."`n`0");
			$session['user']['gems']+=1;
			$session['user']['gold']+=50;
			//$session['user']['attack']++;
			//$session['user']['hitpoints']+=5;
			debuglog("found a gem when slaying a monster, for being a Samurai.");
		}
		break;

	case "creatureencounter":
		if ($session['user']['race']==$race){
			racegreedy_samurai_checkcity();
			$gain = (100 + get_module_setting("goldgain"))/100;
			$args['creaturegold']=round($args['creaturegold']*$gain,0);
		}
		break;
	case "newday":
		if ($session['user']['race']==$race){
			racegreedy_samurai_checkcity();
			apply_buff("racialbenefit",array(
			"name"=>"`3Samurai Chi`0",
			"defmod"=>"(<defense>?(1+((2+floor(<level>/5))/<defense>)):0)",
			"badguydmgmod"=>1.6,
			"allowinpvp"=>1,
			"allowintrain"=>1,
			"rounds"=>150,
			"schema"=>"module-racegreedy_samurai",
			)
			);
		}
		break;
	}

	return $args;
}

function racegreedy_samurai_checkcity(){
	global $session;
	$race="Samurai";
	if (is_module_active("racehuman")) {
		$city = get_module_setting("villagename", "racehuman");
	} else {
		$city = getsetting("villagename", LOCATION_FIELDS);
	}
	
	if ($session['user']['race']==$race && is_module_active("cities")){
		if (get_module_pref("homecity","cities")!=$city){
			set_module_pref("homecity",$city,"cities");
		}
	}
	return true;
}

function racegreedy_samurai_run(){
}
?>