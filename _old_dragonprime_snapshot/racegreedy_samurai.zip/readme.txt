Race - Greedy Samurai

Version 1.0
Written by RPGSL
Download: http://rpgsl.com/lotgd/racegreedy_samurai.zip
Mirror: http://rpdragon.com/lotgd/racegreedy_samurai.zip

Game: http://rpdragon.com/


Installation
 
1) Copy racegreedy_samurai.php into your LotGD modules folder
2) Log in to LotGD with your admin account
4) Enter the Superuser Grotto
5) Click Manage Modules
6) Install sracegreedy_samurai.php (Race - Greedy Samurai)
7) Configure settings and save
8) Activate


Questions/Comments?

alex@rpgsl.com


Visit www.rpgsl.com today for your RPG needs