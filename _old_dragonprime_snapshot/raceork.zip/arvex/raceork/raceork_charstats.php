<?php
if ($session['user']['race']==$race){
       		addcharstat("Dein Profil");
			addcharstat("Rasse", translate_inline($race));
       	}
?>