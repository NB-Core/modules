<?php
output("<a href='newday.php?setrace=$race$resline'>In Knechtschaft aufgewachsen</a>`2, entflohen und ums nackte �berleben k�mpfend, hast du es bis nach %s geschafft. Dort hast du dich mehr oder weniger mit den Gegebenheiten arrangiert, deine Brutalit�t, Bosheit und Falschheit hat dir das �berleben weiterhin gesichert.`n`n",$city,true);
        addnav("`2Ork`0","newday.php?setrace=$race$resline");
        addnav("","newday.php?setrace=$race$resline");
?>