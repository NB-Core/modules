<?php
if ($session['user']['race']==$race){
			raceork_checkcity();
			apply_buff("racialbenefit",array(
				"name"=>"`2Ork Brutalit�t`0",
            			"atkmod"=>"(<attack>?(1+((1+floor(<level>/5))/<attack>)):0)",
				"allowinpvp"=>1,
				"allowintrain"=>1,
				"rounds"=>-1,
				"schema"=>"module-raceork",
				)
			);
			if (is_module_active('alignment') && $al <= $align) {
				$session['user']['playerfights']+=2;
				output("`n`2Du bist so brutal und b�se, das dich deinesgleichen anbeten.`n");
				output("Dies gibt dir Kraft f�r zus�tzliche PvP K�mpfe`n");
			}elseif (is_module_active('alignment')){
				$session['user']['playerfights']--;
				output("`n`2Deinesgleichen verachtet dich, Schw�chling!`n");
			}
		}
?>