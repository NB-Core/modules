<?php
$race="Ork";
    if (is_module_active('racetroll')) {
		$city = get_module_setting('villagename', 'racetroll');
	}else{
		$city = getsetting('villagename', LOCATION_FIELDS);
	}
	
	if ($session['user']['race']==$race && is_module_active('cities')){
		if (get_module_pref('homecity','cities')!=$city){
			set_module_pref('homecity',$city,'cities');
		}
	}
?>