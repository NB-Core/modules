<?php
if ($session['user']['race'] == $race) {
       		$args['chance'] = $minedeath;
       		$args['racesave'] = "`2Trotz deiner Plump- und Tr�gheit bist du wie ein Wunder aus der Mine entkommen.`n";
		$args['schema'] = "module-raceork";
       	}
?>