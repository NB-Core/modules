<?php
	if (is_module_active('racetroll')) {
		$city = get_module_setting('villagename', 'racetroll');
	} else {
		$city = getsetting('villagename', LOCATION_FIELDS);
	}

	if (is_module_active('alignment')) 
    	{
		$al = get_align();
	}
    	$minedeath = get_module_setting('minedeathchance');
	$align = get_module_setting('align');
	$loss = get_module_setting('loss');
?>