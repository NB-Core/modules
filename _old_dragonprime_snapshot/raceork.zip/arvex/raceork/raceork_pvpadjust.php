<?php
if ($args['race'] == $race) {
			$args['creaturedefense']+=(1+floor($args['creaturelevel']/5));
			$args['creatureattack']+=(1+floor($args['creaturelevel']/5));
		}
?>