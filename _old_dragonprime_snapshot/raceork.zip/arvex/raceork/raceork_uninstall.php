<?php
global $session;
	$sql = "UPDATE  " . db_prefix('accounts') . " SET race='" . RACE_UNKNOWN . "' WHERE race='Ork'";
	db_query($sql);
	if ($session['user']['race'] == 'Ork')
	    $session['user']['race'] = RACE_UNKNOWN;
	return true;
?>