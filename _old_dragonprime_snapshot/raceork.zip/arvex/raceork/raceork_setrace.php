<?php
if ($session['user']['race']==$race){
       		output("`2Als Ork kannst du dir eine gewisse Brutalit�t antrainieren und verf�gst dann �ber zus�tzliche PvP K�mpfe");
            if (is_module_active('alignment')) set_module_pref('alignment',get_module_pref('alignment','alignment') - $loss,'alignment');
       		if (is_module_active('cities')) {
           		if ($session['user']['dragonkills']==0 &&
				    	$session['user']['age']==0){
                    set_module_setting('newest-$city',
                       		$session['user']['acctid'],'cities');
                }
                set_module_pref('homecity',$city,'cities');
				if ($session['user']['age'] == 0)
					$session['user']['location']=$city;
            }
        }
?>