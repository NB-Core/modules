<?php
if (!is_module_installed('racetroll')) {
		output("Die Orks haben sich entschlossen nur mit den Trollen zusammenzuleben. Du mu�t dieses Rassen Modul installieren.");
	    return false;
	}
    	module_addhook('chooserace');
	module_addhook('setrace');
	module_addhook('newday');
	module_addhook('charstats');
	module_addhook('raceminedeath');
	module_addhook('pvpadjust');
	module_addhook('racenames');
?>