<?php
/*
Sir Arvex; � 2005
Erstmalig auf Anagromataf.de erschienen
Bugs und Fehler an arvex@anagromataf.de
*/
function raceork_getmoduleinfo(){
   	$info = array(
        	"name"=>"Race - Ork",
        	"version"=>"1.03",
        	"author"=>"`)Arvex",
        	"category"=>"Races",
        	"download"=>"http://www.arvex.de/index.php?showforum=3",
        	"requires"=>array(
				"racetroll" => "1.0 | Eric Stevens",
			),
        	"settings"=>array(
            	"Orks Einstellungen,title",
            	"minedeathchance"=>"Chance f�r Orks in der Mine zu sterben,range,0,100,1|90",
            	"loss"=>"Wieviel an Gesinnung verliert man wenn man diese Rasse ausw�hlt,int|10",
		"align"=>"Unterhalb welcher Gesinnung werden zus�tzliche PvP K�mpfe gew�hrt?,int|33",
		"Es wird empfohlen das Modul alignment 1.6 http://dragonprime.net/users/Sichae/alignment.zip zu installieren.,note"
			),
    );
   	return $info;
}

function raceork_install(){
	include("modules/arvex/raceork/raceork_install.php"); 
    return true;
}

function raceork_uninstall(){
	include("modules/arvex/raceork/raceork_uninstall.php");
} 

function raceork_dohook($hookname,$args){
    	global $session,$resline;
    		include("modules/arvex/raceork/raceork_dohook.php");
   	$race = "Ork";
   	switch($hookname){
   	case 'racenames':
	    $args[$race] = $race;
	    break;
    	case 'raceminedeath':
    		include("modules/arvex/raceork/raceork_raceminedeath.php");
      	break;
    	case 'charstats':
   	 	include("modules/arvex/raceork/raceork_charstats.php");
    	 break;
    	case 'chooserace':
    		include("modules/arvex/raceork/raceork_chooserace.php");
        break;
   	case 'setrace':
   		include("modules/arvex/raceork/raceork_setrace.php");
        break;
    	case 'newday':
    		include("modules/arvex/raceork/raceork_newday.php");
	break;
    	case 'pvpadjust':
    		include("modules/arvex/raceork/raceork_pvpadjust.php");
	break;
    }
    return $args;
}

function raceork_checkcity(){
    	global $session;
    		include("modules/arvex/raceork/raceork_checkcity.php");
    	return true;
}

function raceork_run(){
}
?>
