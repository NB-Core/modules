<?php

/*
This is Copyright 2004 (C) Christopher Phillips.
Contact me on dragonprime.net.
Developed under the CCL.
Version 1.0
The code is based upon a template Copyright 2004 by Christian Rutsch who you can contact at christian-DOT-rutsch-AT-gmx-DOT-de
*/

require_once("lib/villagenav.php");
require_once("lib/quests.php");

function quest_gemtears_getmoduleinfo(){
	$info = array(
		"name"=>"Quest - Gemtears",
		"version"=>"1.0",
		"author"=>"`@CortalUX",
		"category"=>"Quest",
		"download"=>"http://dragonprime.net/users/cortalux",
		"requires"=>array(
			"questbasics" => "1.0|XChrisX, http://beta.lotgd.de/downloads/questpack.zip",
			"cities" => "1.0|Eric Stevens, core_module",
			"bankmod" => "1.1|Spider, http://dragonprime.net/users/Spider/bankmod.zip",
			"raceelf" => "1.0|Eric Stevens, core_module",
			"racedwarf" => "1.0|Eric Stevens, core_module",
			"smith" => "1.1|Eric Stevens, core_module",
		),
		"vertxtloc"=>"http://dragonprime.net/users/CortalUX/",
		"settings"=>array(
			"req_min_hw" => "Required Hero Points to receive the quest, int|10",
			"req_max_hw" => "Maximum Hero Points to receive the quest, int|20",
			"req_min_dk" => "Required Dragon Kills to receive the quest, int|2",
			"req_max_dk" => "Maximum Dragon Kills to receive the quest, int|2",
			"req_min_lev" => "Minimum level to receive the quest, int|3",
			"req_max_lev" => "Maximum level to receive the quest, int|15",
			"req_quest" => "Is another quest required before starting this quest?, string|",
			"req_superuser" => "Can the quest be done by superusers at any time?, bool|true",
			"reward_exp" => "Reward (Experience), int|10000",
			"reward_explevel" => "Additional experience points per level, int|75",
			"reward_gems" => "Reward (Gems), int|1000",
			"reward_gold" => "Reward (Gold), int|10000",
			"reward_goldlevel" => "Additional gold per level, int|7500",
			"reward_quest" => "Number of quest points the player receives?, int|50",
		),
		"prefs" => array(
			"queststarted" => "Has the player accepted the quest?, bool|false",
			"queststation" => "What point in the quest is the player at?, int|0",
		),
	);
	return $info;
}

function quest_gemtears_chance($where){
	global $session;
	$evname = get_module_setting("villagename", "raceelf");
	$dvname = get_module_setting("villagename", "racedwarf");
	$queststation = get_module_pref("queststation", "quest_gemtears");
	if (requirements_met("quest_gemtears") || get_module_pref("queststarted", "quest_gemtears")) {
		if ($where == "village") {
			if ($queststation == 0 && $session['user']['location'] == $evname) {
				$encounter = 50;
			}
			if ($queststation == 2 && $session['user']['location'] == $dvname) {
				$encounter = 50;
			}			
		} else if ($where == "forest" && $queststation == 1) {
			$encounter = 100;
		} else if ($where == "forest" && $queststation == 4) {
			$encounter = 100;
		} else {
			$encounter = 0;
		}
		return $encounter;
	} else {
		return 0;
	}
}

function quest_gemtears_install() {

	$station = array(
		"-2" => "`\$The Hero failed to return the Gems to Elessa.`0",
		"-1" => "`@The Hero returned the Gems to Elessa.`0",
		"0" => "`6 - Elessa and the Gemtears - `0",
		"1" => "`6The Hero met Elessa in the Elven village.`0",
		"2" => "`6In the forest the Hero met Smythe the Smith who gave the Hero a clue.`0",
		"3" => "`6In the Dwarven village, the Hero found Gemtear gunk.`0",
		"4" => "`6The Hero delivered the Gemtear gunk to Elessa, and Elessa has found out where the Gemtears are.`0",
		"5" => "`6The Hero battled a Gemtear Phantasm to renew the Gems.`0",
	);
	$questfilename = "quest_gemtears";
	db_query("DELETE FROM quests WHERE questname = '".$questfilename."'");
	foreach($station as $outputstation => $entry) {
		$sql = "INSERT INTO quests (questname, queststation, questdescription) VALUES ('".$questfilename."', '".$outputstation."', '".$entry."')";
		db_query($sql);
	}

	module_addeventhook("village", "require_once(\"modules/quest_gemtears.php\"); return quest_gemtears_chance(\"village\");");
	module_addeventhook("forest", "require_once(\"modules/quest_gemtears.php\"); return quest_gemtears_chance(\"forest\");");
	module_addhook("footer-runmodule");
	module_addhook("footer-bank");	
	return true;
}

function quest_gemtears_uninstall(){
	return true;
}

function quest_gemtears_dohook($hookname,$args) {
	global $session, $SCRIPT_NAME;
	$script = substr($SCRIPT_NAME,0,strpos($SCRIPT_NAME,"."));
	if ($script == "runmodule") $script = httpget('module');
	$queststation = get_module_pref("queststation", "quest_gemtears");
	if ($hookname == "footer-bank" && $queststation == 3) {
		addnav("Gem Tears");
		addnav("Ask Elessa about the Gem Gunk", "runmodule.php?module=quest_gemtears&step=gunk");
	} elseif ($hookname == "footer-bank" && $queststation == 4) {
		addnav("Gem Tears");
		addnav("Return the Phantasm Core to Elessa", "runmodule.php?module=quest_gemtears&step=greturn");
	} elseif ($hookname == "battle-defeat") {
		// If they have a special inc set for the dragon and they just
		// lost, reset it so they don't keep coming back here!
		if ($session['user']['specialinc'] == "module:quest_gemtears") {
			$session['user']['specialinc'] = "";
		}
	}
	return $args;
}

function quest_gemtears_runevent($type) {
	global $session;
	$evname = get_module_setting("villagename", "raceelf");
	$dvname = get_module_setting("villagename", "racedwarf");
	$queststation = get_module_pref("queststation", "quest_gemtears");
	$questinprogress = get_module_pref("questinprogress", "questbasics");

	if ($type == "village" && $session['user']['location'] == $evname && $queststation == 0 && $questinprogress < 1) {
		output("`7As you walk past the Bank, you are grabbed by a woman wearing green, who pulls you into an alleyway and pulls down her hood.`n`n");
		output("`3\"`@ am Elessa. We have a crisis- when we were transporting some Gems from ".$dvname.", a rogue band captured our Guards, and stole them all.`3\" says `&Elessa`3.`n`n");
		output("`3\"`^What has that to do with me?`3\" you ask.`n`n");
		output("`3\"`@Our Guards are scared of what they call a Phantasm menace, and there isn't anyone else to hire. I cannot pay, but your reward will be great. Find a clue and my meager magical arts will help you. Do you accept?3\" says `&Elessa`3.`n`n");
		output("`3\"`^I accept.`3\" you say.`n`n");
		output("`3\"`@Thankyou. You are a kind ".($session['user']['sex']?"wo":"")."man. All I know, is that you may find help in the woods.`3\" says `&Elessa`3.`n`n");
		start_quest("quest_gemtears");
	} elseif ($type == "forest" && $queststation == 1) {
		output("`7You step cautiously through the underbrush when you notice a burly fellow holding a massive hammer in one hand.  Confident that he poses no threat to you, you approach him and say, \"`&Ho, man!`7\".`n`n");
		output("\"`6My name is Smiythe,`7\" he responds.`n`n");
		output("\"`&What?`7\" you ask, always showing your smarts.`n`n");
		output("\"`6Smiythe, that's my name.  I'm a blacksmith.  Smiythe the Smith some call me.  And I would be glad to offer my smithing services for a fee, but my stuff is playing up.`7`n`n");
		output("\"`6All my Gems are turning to mush, and that's the only currency I can accept! I have a Gold allergy.`7\"`n`n");
		output("\"`&A Smith with an allergy to Gold?`7\" you ask.`n`n");
		output("\"`6I just said I did didn't I?!!`7\"`n`n");
		output("\"`&Enough of this rubbish! I'm on a quest to find someone's stolen Gems, I'll try and help you too. Have you noticed anything suspicious?`7\" you ask.`n`n");
		output("`7\"`6Not really... but thanks anyway.`7\"`n`n`@You walk off in a huff, and don't notice a gigantic cart with no license plate which is headed toward `^".$dvname."`@.");
		advance_quest("quest_gemtears");		
	} elseif ($type == "forest" && $queststation == 4) {
		output("`@You wander around the Forest aimlessly, when a bright light illuminates everything.. a crashing noise ensues, and something attacks you!`n`n");
		output("`c`b`\$You have found the Phantasm!`b`c");
		addnav("Attack it!","runmodule.php?module=quest_gemtears&step=phantbattle");
	} elseif ($type == "village" && $session['user']['location'] == $dvname && $queststation == 2) {
		output("`@As you walk through the caverns of ".$dvname.", you spot a weird cart with slime oozing from its insides...`n`n");
		output("`@You walk up to it, and, examining it closely, you see that a painted name has been rubbed off the side.`n`n");
		output("`@The name reads '`^The Ye Olde Banking Gem Cart`@'. Staring at it, you drop everything you are carrying, realising that this is the cart Elessa told you about.`n`n");
		output("`@You pick your money pouch up, and you look inside it as you step around the cart, when a Gem inside your pouch starts to turn to slime...`n`n");
		output("`@Maybe Elessa might be able to tell something from it?`n");
		advance_quest("quest_gemtears");
	}
}

function quest_gemtears_run(){
	global $session;
	$step = httpget('step');
	$op = httpget('op');
	$evname = get_module_setting("villagename", "raceelf");
	$dvname = get_module_setting("villagename", "racedwarf");
	if ($step == "gunk") {
		page_header("Elessa and the Gemtears");
		if ($session['user']['location'] == $evname) {
			output("`7You talk to Elessa, and ask if she can tell anything from the Gunk you brought back..`n`n");
			output("`3\"`@This is a Gemtear!`3\" `&Elessa`3 cries!`n`n");
			output("`3\"`^Huh?`3\" you intelligently say.`n`n");
			output("`3\"`@A magik of great `\$evil`@. Blood is extracted from someone who must continually eat Goodness to stay invincible. Gems hold Goodness from when they were formed aeons ago, and the Phantasm leaves behind a Gemtear, which cries for it's brother half...`3\" `&Elessa`3 explains.`n`n");
			output("`3\"`@If you can find the Phantasm, and defeat it, it should dissolve and accross the world the Gems will be reunited. All I can tell you is that the Phantasm is in the Elven wood. It must be weak, for there aren't many Gems here.`3\" `&Elessa`3 says.`n`n");
			output("`3\"`^I will defeat it.`3\" you swear.`n`n");
			output("`3\"`@I knew I could count on you!!`3\" `&Elessa`3 cries!`n`n");
			advance_quest("quest_gemtears");
		} else {
			output("`3\"`@I am sorry, thank you for this, but could you please send it to our Elven Village office? That is where I store my magical apparatus.`3\" says `&Elessa`3.`n`n");
			output("`3\"`^Of course...`3\" say you.");
		}
		addnav("Back to the Bank","bank.php");
	} elseif ($step == "greturn") {
		page_header("Elessa and the Gemtears");
		if ($session['user']['location'] == $evname) {
			output("`3\"`^The Phantasm disintegrated, only leaving this!`3\" you exclaim, as you hand the Phantasm core to Elessa.`n`n");
			output("`3\"`@Thankyou! I can reintegrate the Gems now!`3\" `&Elessa`3 says, as she fishes about in a pocket for a reward, and hands it to you.`n`n");
			end_quest("quest_gemtears");
		} else {
			output("`3\"`@I am sorry, thank you for this, but could you please send it to our Elven Village office? That is where I store my magical apparatus.`3\" says `&Elessa`3.`n`n");
			output("`3\"`^Of course...`3\" say you.");
		}
		addnav("Back to the Bank","bank.php");
	} elseif ($step=="phantbattle"){
		require_once("lib/forestoutcomes.php");
		restore_buff_fields();
		// Lets challenge you properly. Max HP is essential.
		$badguy = array();
		$badguy['creaturename']="An evil Gem Phantasm...";
		$badguy['creatureweapon']="Burning Gems";
		$badguy['creaturelevel']= $session['user']['level'];
		$badguy['creaturegold']=1000;
		$badguy['creatureexp'] = round($session['user']['experience']/10, 0);
		$badguy['creaturehealth']=$session['user']['maxhitpoints']-2;
		$badguy['creatureattack']=$session['user']['attack']-2;
		$badguy['creaturedefense']=$session['user']['defense']-2;
		calculate_buff_fields();
		$badguy['playerstarthp']=$session['user']['hitpoints'];
		$badguy['diddamage']=0;
		$badguy['type'] = 'quest';
		$session['user']['badguy']=createstring($badguy);
		$battle = true;
	} elseif ($op=="fight" || $op=="run"){
		$skill = httpget('skill');
		$f = httpget('f');
		if ($op == "run" && e_rand(1, 5) < 3) {
			// They managed to get away.
			page_header("Escape");
			output("You set off running through the forest at a breakneck pace heading back the way you came.`n`n");
			output("In your terror, you lose your way and become lost, losing time for a forest fight.`n`n");
			if ($session['user']['turns']>0) { $session['user']['turns']--; }
			output("After running for what seems like hours, you finally arrive back at %s.", $session['user']['location']);
			addnav(array("Enter %s",$session['user']['location']), "village.php");
			output("`$`c`b`iYou have failed the quest.`i`b`c`0");
			end_quest_failure("quest_gemtears");
			$battle=false;
		} else {
			$battle = true;
		}
	}
	if ($battle){
		page_header("Phantasm Battle!");
		require_once("battle.php");
		if ($victory){
			require_once("lib/forestoutcomes.php");
			forestvictory($badguy,false);
			output("`n`n`^You pick up a Phantasm Core...`)");
			advance_quest("quest_gemtears");
			villagenav();
		}elseif ($defeat){
			output("`n`n`^It ate your Gems...`)");
			$session['user']['gems']=0;
			require_once("lib/forestoutcomes.php");
			forestdefeat($badguy,"in the Gemtear quest");
			end_quest_failure("quest_gemtears");
		}else{
			require_once("lib/fightnav.php");
			fightnav(true,true,"runmodule.php?module=quest_gemtears&f=yes");
		}
	}
	page_footer();
}

?>