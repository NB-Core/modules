
Golden Goose
Mount for players thats not too strong but gives small daily boon

- > Open Mount Editor:
CREATE NEW MOUNT
	Name: Golden Goose
	Description: This is one tough Goose! If you treat her right, she may show her appreciation.
	Cost: 100 Gems
	attk:  1.2
	def:   1.2
	rounds: 20
	
	Suggestion: Keep the cost very high as this mount gives a small boon daily

- > You need to save and get the mount id number by mousing over it

- > INSERT mount id number where the ? appears in the following:
	if ($session['user']['hashorse']==?)

- > OPEN newday.php
	ADD:
	
// Golden Goose
if ($session['user']['hashorse']==?) {
	$goose=(e_rand(50,100));
	output(" `n`n`2Upon getting your `^Golden Goose `2you find she has left you a present. ");
	switch(e_rand(1,5)){
		case 1: case 2: case 3: case 4:
		output(" `n`2You discover `^$goose COINS `2under the Goose, How could that be? ...you wonder.");
		$session['user']['gold']+=$goose;
		break;
		case 5:
		output(" `n`2You discover a `^GEM `2under the Goose, How could that be? ...you wonder.");
		$session['user']['gems']+=1;
		break;
	}
}

- > Save and upload