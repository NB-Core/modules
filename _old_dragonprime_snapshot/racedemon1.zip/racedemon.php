<?php

function racedemon_getmoduleinfo(){
    $info = array(
        "name"=>"Race - Demon",
        "version"=>"1.3",
        "author"=>"shadowblack",
        "category"=>"Races",
        "download"=>"http://dragonprime.net/users/shadowblack/racedemon.zip",
        "settings"=>array(
            "Demon Race Settings,title",
            "runonce"=>"Demons receive extra torments only on server-generated game day?,bool|0",
            "minedeathchance"=>"Chance for Demon to die in the mine,range,0,100,1|50",
		        "mindk"=>"How many DKs do you need before the race is available?,int|5",
		        "torments"=>"How many extra torments do Demons receive per day?,range,0,10,1|2",
            "heal"=>"Percent of hit points restored after each fight?,range,0,50,1|10",
            "If you have less than max hit points after the end of the fight your current hit points are increased by maximum hit points multiplied by 100th of above setting,note",
        ),
        "prefs"=>array(
            "Demon Race Preferences,title",
            "received"=>"Has the user received extra Torments today?,bool|0",
        ),
    );
    return $info;
    };

function racedemon_install(){
  if (!is_module_installed("racevamp")) {
		output("The Demon only choose to live with Vampires. You must install that race module.");
		return false;
	}
	module_addhook("chooserace");
  module_addhook("setrace");
  module_addhook("charstats");
	module_addhook("newday");
	module_addhook("newday-runonce");
	module_addhook("dragonkill");
  module_addhook("raceminedeath");
  module_addhook("battle-victory");
	return true;
}

function racedemon_uninstall(){

  global $session;
	$vname = getsetting("villagename", LOCATION_FIELDS);
	$gname = get_module_setting("villagename");
	$sql = "UPDATE " . db_prefix("accounts") . " SET location='$vname' WHERE location = '$gname'";
	db_query($sql);
	if ($session['user']['location'] == $gname)
		$session['user']['location'] = $vname;
	$sql = "UPDATE  " . db_prefix("accounts") . " SET race='" . RACE_UNKNOWN . "' WHERE race='Demon'";
	db_query($sql);
	if ($session['user']['race'] == 'Demon')
		$session['user']['race'] = RACE_UNKNOWN;
	return true;
}

function racedemon_dohook($hookname,$args){

  $heal = get_module_setting("heal")*0.01;
  $torments = get_module_setting("torments");

  global $session,$resline;
	if (is_module_active("racevamp")) {
		$city = get_module_setting("villagename", "racevamp");
	} else {
		$city = getsetting("villagename", LOCATION_FIELDS);
	}
  $race = "Demon";

  switch($hookname){

  Case "chooserace":

  if ($session['user']['dragonkills'] < get_module_setting("mindk"))
			break;
    output("<a href='newday.php?setrace=Demon$resline'>In the darkest parts</a>`) of `\$%s, `)hidden away from the world. There you have fed on the souls of the fools that dare enter the domain of demons.`n`n",$city,true);
    addnav("`)Demon`0","newday.php?setrace=Demon$resline");
    addnav("","newday.php?setrace=Demon$resline");
 
    break;
  
  Case "setrace":

  if ($session['user']['race']==$race){
    if ($heal>0){
            output("`)As a demon you feed on the life energy of your victims, restoring your health after battle. You also enjoy torturing others, giving you extra torments per day.");
            }else {
            output("`)As a demon you enjoy torturing others, giving you extra torments per day.");
            }
            if (is_module_active("cities")) {
                if ($session['user']['dragonkills']==0 &&
                        $session['user']['age']==0){
                    //new farmthing, set them to wandering around this city.
                    set_module_setting("newest-$city",
                            $session['user']['acctid'],"cities");
                }
                set_module_pref("homecity",$city,"cities");
                $session['user']['location']=$city;
            }
        }
        break;
  
  Case "charstats":

  if ($session['user']['race']==$race){
      addcharstat("Vital Info");
      addcharstat("Race", $race);
  }
  break;

  Case "dragonkill":

  set_module_pref("received",0);
  break;

  Case "newday-runonce":

  if (get_module_setting("runonce")){
  $sql = "update ".db_prefix("module_userprefs")." set value=0 where value<>0 and setting='received' and modulename='racedemon'";
  db_query($sql);
	if ($session['user']['race'] != $race)
  break;
  $session['user']['gravefights'] += $torments;
  output("`)As a demon you receive `&%s `)extra torments for today.",$torments);
  set_module_pref("received",1);
  }
  break;

  Case "newday":

  if ($session['user']['race'] == $race){
  if (!get_module_setting("runonce")){
  $session['user']['gravefights'] += $torments;
  output("`)As a demon you receive `&%s `)extra torments for today.",$torments);
  }elseif(!get_module_pref("received")){
  $session['user']['gravefights'] += $torments;
  output("`)As a demon you receive `&%s `)extra torments for today.",$torments);
  set_module_pref("received",1);
  }
  }
  break;

  Case "raceminedeath":

  if ($session['user']['race'] == $race) {
            $args['chance'] = get_module_setting("minedeathchance");
            $args['racesave'] = "Fortunately your Demon skills let you escape unscathed.`n";
  }
  break;

  Case "battle-victory":

		if ($session['user']['race'] != $race)
      break;
    if ($session['user']['alive']==true){
    if ($heal == 0)
      break;
		if ($session['user']['hitpoints']<$session['user']['maxhitpoints']){
			$hpheal = $session['user']['maxhitpoints']*$heal;
			output("`)After you slay `0%s `)you absorb some of `0%s's `)life energy and restore some of your health.`n",$args['creaturename'],$args['creaturename']);
			$session['user']['hitpoints'] += $hpheal;
			}
			}
		  break;
  }
	return $args;
}

function racedemon_checkcity(){

  global $session;
    $race="Demon";
    if (is_module_active("racevamp")) {
		$city = get_module_setting("villagename", "racevamp");
	} else {
		$city = getsetting("villagename", LOCATION_FIELDS);
	}
	
	if ($session['user']['race']==$race && is_module_active("cities")){
		//if they're this race and their home city isn't right, set it up.
		if (get_module_pref("homecity","cities")!=$city){ //home city is wrong
			set_module_pref("homecity",$city,"cities");
		}
	}
	return true;
}

function racedemon_run(){
}
?>
