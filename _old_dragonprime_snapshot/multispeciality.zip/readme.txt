//Hierbei handelt es sich nur um ein Beispiel um die Hooks in den eigenen Modulen zu nutzen!
//This is only an example how to use the hooks into your own modules!

function XXX_install(){
	module_addhook('choosems');
	module_addhook('newdayms');
	module_addhook('fightms');
	return true;
}

function XXX_dohook($hookname,$args){
	global $session;
//--> Hat ein Spieler die Klasse 'Mystic Powers' und sein Ruf ist <0 darf er sie nicht nutzen!
//--> When a player has the specialty 'Mystic Powers' and his reputation is less than 0, he is not able to use it!

	$mpspec = ($session['user']['specialty']=='MP' && get_align()<0)?"MP,":"";

//--> Hat ein Spieler die Klasse 'Dark Arts' und sein Ruf ist >0 darf er sie nicht nutzen!
//--> When a player has the specialty 'Dark Arts' and his reputation is is greater than 0, he is not able to use it!

	$daspec = ($session['user']['specialty']=='DA' && get_align()>0)?"DA,":"";
	switch($hookname){

//--> Beispiel dafuer, welche Rasse welche Klasse waehlen darf. Elf darf nur Mystic Powers '$spec=MP' und Thievery '$spec=TS' waehlen. Steht eine Rasse nicht drin darf sie alle Klassen waehlen!
//--> Examples: What race can use a specialty. Elves can only use Mystic Powers(MP) and Theiving Skills(TS). No stock race can use all specialties!

		case 'choosems':
        	switch($session['user']['race']){
				case 'Elf':
					$args = array("choose"=>"MP,TS");
					break;
        	}
			break;
		case 'newdayms':
		    if ($mpspec) output("Weil dein Ruf zu schlecht ist, darfst du Mystic Powers nicht nutzen!");
		    //--> You are unable to use Mystic Powers, because your reputation is too low.

			$args = array("newday"=>"$mpspec$daspec");
			break;
		case 'fightms':
		    if ($mpspec) output("Du solltest etwas an deinem Ruf tun!");
		    //--> You should do something to increase your reputation!

			$args = array("fight"=>"$mpspec$daspec");
			break;
	}
	return $args;
}
