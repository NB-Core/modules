<?php
	set_module_pref('name','','multispeciality');
	set_module_pref('spec','','multispeciality');
	set_module_pref('ccode','','multispeciality');
	$sql = "DELETE FROM ".db_prefix('module_objprefs')." WHERE modulename='multispeciality' AND objid={$session['user']['acctid']}";
	db_query($sql);
?>
