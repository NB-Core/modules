<?php
	$args[$spec] = $ccode;
?>
