<?php
	$args[$spec] = "multispeciality";
?>
