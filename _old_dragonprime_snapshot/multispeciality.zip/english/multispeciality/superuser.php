<?php
	if (is_module_active('multispeciality')) {
		addnav("Module Configurations");
		if ($session['user']['superuser'] & SU_EDIT_MOUNTS) addnav("Specialty Editor","runmodule.php?module=multispeciality");
	}
?>
