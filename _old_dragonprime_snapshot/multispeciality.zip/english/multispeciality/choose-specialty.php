<?php
	if ($session['user']['specialty'] == '' || $session['user']['specialty'] == 0 || get_module_pref('spec','multispeciality') == '') {
		$donation = $session['user']['donation']-$session['user']['donationspent'];
		$sex = $session['user']['sex']?'class2':'class1';
		$su = $session['user']['superuser']==0?"active=1":"(active=0 or active=1)";

		$race = modulehook('choosems',array());

		if ($race['choose'] && $session['user']['superuser']==0){
			$class = $race['choose'];
			if (substr($class,-1)==',') $class=substr($class,0,-1);
			$klist=explode(",",$class);
			for($i=0;$i<=count($klist);$i++){
				if (!$vclass) $vclass = "spec='{$klist[$i]}' ";
				elseif (!$klist[$i]=="") $vclass.="OR spec='{$klist[$i]}' ";
			}
	    	$sql = "SELECT * FROM ".db_prefix('speciality')."
				WHERE ($vclass)
				AND mindk<={$session['user']['dragonkills']}
				AND cost<=".($donation<0?0:$donation)."
				AND $su
				ORDER BY $sex ASC";
		}else{
	    	$sql = "SELECT * FROM ".db_prefix('speciality')."
				WHERE $su
				AND mindk<={$session['user']['dragonkills']}
				AND cost<=".($donation<0?0:$donation)."
				ORDER BY $sex ASC";
   		}
		$result = db_query($sql);
   		for ($i=0;$i<db_num_rows($result);$i++){
       		$row = db_fetch_assoc($result);
			$t1 = $row['t2'];
			$t2 = appoencode($row['ccode'].($session['user']['sex']?$row['class2']:$row['class1'])."`0");
			$spec = $row['spec'];
			if ($session['user']['sex']==0 && $row['class1'] || $session['user']['sex']==1 && $row['class2']){
				addnav($row['ccode'].($session['user']['sex']?$row['class2']:$row['class1'])."`0","newday.php?setspecialty=$spec$resline");
				rawoutput("<a href='newday.php?setspecialty=$spec$resline'>$t1 ($t2)</a><br>");
				addnav("","newday.php?setspecialty=$spec$resline");
   			}
   		}
	}
?>
