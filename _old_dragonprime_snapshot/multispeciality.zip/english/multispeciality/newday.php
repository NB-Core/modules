<?php
	$bonus = getsetting('specialtybonus', 1);

	$race = modulehook('newdayms',array());

	if ($race['newday'] && $session['user']['superuser']==0){
		$class = $race['newday'];
		if (substr($class,-1)==',') $class=substr($class,0,-1);
		$klist=explode(",",$class);
		for($i=0;$i<=count($klist);$i++){
			if ($session['user']['specialty']==$klist[$i]) $break=1; break;
		}
	}
	
	if(!$break){
		if ($bonus == 1) {
			output("`n`2For being interested in %s%s`2, you receive `^1`2 extra `&%s%s`2 use for today.`n",$ccode,$name,$ccode,$name);
		}else{
			output("`n`2For being interested in %s%s`2, you receive `^%s`2 extra `&%s%s`2 uses for today.`n",$ccode,$name,$bonus,$ccode,$name);
		}
	}
	$amt = (int)(get_module_objpref($spec, $session['user']['acctid'], 'skill','multispeciality') / 3 + $bonus);
	set_module_objpref($spec, $session['user']['acctid'], 'uses', $amt,'multispeciality');

	$su = $session['user']['superuser']==0?"active=1":"(active=0 or active=1)";

	$sql = "SELECT spec FROM ".db_prefix('speciality')." WHERE $su AND spec!='$spec' ORDER BY class1 ASC";
	$result = db_query($sql);
	for ($i=0;$i<db_num_rows($result);$i++){
   		$row = db_fetch_assoc($result);
   		if (get_module_objpref($row['spec'], $session['user']['acctid'], 'skill', 'multispeciality')){

   	    	$amt =  (int)(get_module_objpref($row['spec'], $session['user']['acctid'], 'skill', 'multispeciality')/3);
			set_module_objpref($row['spec'], $session['user']['acctid'], 'uses', $amt, 'multispeciality');
   		}
	}
?>
