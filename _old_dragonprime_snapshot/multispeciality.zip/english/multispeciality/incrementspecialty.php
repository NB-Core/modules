<?php
	$new = get_module_objpref($spec, $session['user']['acctid'], 'skill', 'multispeciality') + 1;
	set_module_objpref($spec, $session['user']['acctid'], 'skill', $new, 'multispeciality');
	$c = $args['color'];
	output("`n%sYou gain a level in `&%s%s to `#%s%s!",$c, $name, $c, $new, $c);
	$x = $new % 3;
	if ($x == 0){
		output("`n`^You gain an extra use point!`n");
		set_module_objpref($spec, $session['user']['acctid'], 'uses', get_module_objpref($spec, $session['user']['acctid'], 'uses', 'multispeciality') + 1,'multispeciality');
	}else{
		if (3-$x == 1){
			output("`n`^Only 1 more skill level until you gain an extra use point!`n");
		}else{
			output("`n`^Only %s more skill levels until you gain an extra use point!`n", (3-$x));
		}
	}
	output_notl("`0");
?>
