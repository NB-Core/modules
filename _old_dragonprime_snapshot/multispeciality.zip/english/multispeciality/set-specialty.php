<?php
	$su = $session['user']['superuser']==0?"active=1":"(active=0 or active=1)";

	$sql = "SELECT class1,class2,spec,ccode,cost,t3 FROM ".db_prefix('speciality')." WHERE spec='$setspecialty' AND $su";
	$result = db_query($sql);
	if (db_num_rows($result)>$ppp){
		$row = db_fetch_assoc($result);
		page_header($session['user']['sex']?$row['class1']:$row['class2']);
		output($row['t3']);
		$session['user']['donationspent']+=$row['cost'];
		set_module_pref('name',($session['user']['sex']?$row['class2']:$row['class1']),'multispeciality');
		set_module_pref('spec',$row['spec'],'multispeciality');
		set_module_pref('ccode',$row['ccode'],'multispeciality');
		$session['user']['specialty'] = $row['spec'];
	}
?>
