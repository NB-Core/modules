<?php
/*
Written for lotgd.eq-gildenhaus.de, Antic �2004-2005
Bugs to antic@eq-gildenhaus.de or dragonprime.net

Some sources and texts are from core version.

modules/specialtythiefskills.php
lib/buffs.php
mounts.php

Thanks to Eric Stevens & JT Traub
*/
function multispeciality_getmoduleinfo(){
	$info = array(
		"name" => "Multispecialities",
		"author" => "`3Antic`0",
		"version" => "0.77",
		"download" => "http://dragonprime.net/users/Antic/multispeciality.zip",
		"category" => "General",
		"settings"=> array(
			"Multispecialities Settings,title",
			"anw"=>"Max amount of Buffs each Specialty?,range,4,99,1|4",
			"libn"=>"Textfield 1,text|Library",
			"lib"=>"Textfield 1 enabled?,bool|0",
			"aka1n"=>"Textfield 2,text|Academy 1",
			"aka1"=>"Textfield 2 enabled?,bool|0",
			"aka2n"=>"Textfield 3,text|Academy 2",
			"aka2"=>"Textfield 3 enabled?,bool|0",
		),
		"prefs" => array(
			"Multispecialities User Settings,title",
			"count"=>"Use counter enabled?,bool|0",
			"name"=>"Specialty,text|",
			"spec"=>"Specialty short,text|",
			"ccode"=>"Specialty color,text|",
		),
	);
	return $info;
}

function multispeciality_install(){
	include ("modules/multispeciality/install.php");
	return true;
}

function multispeciality_uninstall(){
	$sql = "DROP TABLE speciality";
	mysql_query($sql);
	return true;
}

function multispeciality_dohook($hookname,$args){
	global $session,$resline;

	$name = get_module_pref('name','multispeciality');
	$spec = get_module_pref('spec','multispeciality');
	$ccode = get_module_pref('ccode','multispeciality');
    $setspecialty = httpget('setspecialty');
	$char = httpget('char');
	$userid = httpget('userid');
	$anw = get_module_setting('anw','multispeciality');
	include ("modules/multispeciality/$hookname.php");
	return $args;
}

function multispeciality_run(){
	include ("modules/multispeciality/run.php");
}
?>
