<?php
	$bonus = getsetting('specialtybonus', 1);

	$race = modulehook('newdayms',array());

	if ($race['newday'] && $session['user']['superuser']==0){
		$class = $race['newday'];
		if (substr($class,-1)==',') $class=substr($class,0,-1);
		$klist=explode(",",$class);
		for($i=0;$i<=count($klist);$i++){
			if ($session['user']['specialty']==$klist[$i]) $break=1; break;
		}
	}
	
	if(!$break){
		if ($bonus == 1) {
			output("`n`2F�r deine Klasse %s%s`2, erh�ltst du f�r heute `^1`2 zus�tzliche Anwendung.`n",$ccode, $name);
		}else{
			output("`n`2F�r deine Klasse %s%s`2, erh�ltst du f�r heute `^%s`2 zus�tzliche Anwendungen.`n",$ccode, $name,$bonus);
		}
	}
	$amt = (int)(get_module_objpref($spec, $session['user']['acctid'], 'skill','multispeciality') / 3 + $bonus);
	set_module_objpref($spec, $session['user']['acctid'], 'uses', $amt,'multispeciality');

	$su = $session['user']['superuser']==0?"active=1":"(active=0 or active=1)";

	$sql = "SELECT spec FROM ".db_prefix('speciality')." WHERE $su AND spec!='$spec' ORDER BY class1 ASC";
	$result = db_query($sql);
	for ($i=0;$i<db_num_rows($result);$i++){
   		$row = db_fetch_assoc($result);
   		if (get_module_objpref($row['spec'], $session['user']['acctid'], 'skill', 'multispeciality')){

   	    	$amt =  (int)(get_module_objpref($row['spec'], $session['user']['acctid'], 'skill', 'multispeciality')/3);
			set_module_objpref($row['spec'], $session['user']['acctid'], 'uses', $amt, 'multispeciality');
   		}
	}
?>
