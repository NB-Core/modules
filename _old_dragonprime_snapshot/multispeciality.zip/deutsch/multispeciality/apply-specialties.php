<?php
		$skill = httpget('skill');
		$l = httpget('l');
		$noneed = array("name"=>"1","newday"=>1,"startmsg"=>1,"roundmsg"=>1,"wearoff"=>1,"effectmsg"=>1,"effectnodmgmsg"=>1,"effectfailmsg"=>1,"schema"=>1);
		$su = $session['user']['superuser']==0?"active=1":"(active=0 or active=1)";

	    $sql = "SELECT spec FROM ".db_prefix('speciality')." WHERE spec='$skill' AND $su";
   		$result = db_query($sql);

		if (db_num_rows($result)){
			$sql = "SELECT spec,buff$l as buff,uses$l as uses FROM ".db_prefix('speciality')." WHERE spec='$skill'";
	   		$result = db_query($sql);
			$row = db_fetch_assoc($result);
			if (get_module_objpref($row['spec'], $session['user']['acctid'], 'uses', 'multispeciality') >= $l){
	   			$rspec = strtolower("$skill$l");
				$buff = unserialize($row['buff']);
   				while (list($key,$val)=each($buff)){
   		        	$string = $val;
					$val = preg_replace("/<([A-Za-z0-9]+)\\|([A-Za-z0-9]+)>/","get_module_pref('\\2','\\1')",$val);
					$val = preg_replace("/<([A-Za-z]+)>/","\$session['user']['\\1']",$val);
					if ($key=='rounds' && $string != $val) 		$buff[$key] = eval("return $val;");
					elseif (!$noneed[$key] && $string == $val) 	$buff[$key] = eval("return $val;");
					unset($val);
   				}
				apply_buff("$rspec",$buff);
				set_module_objpref($row['spec'], $session['user']['acctid'], 'uses', get_module_objpref($row['spec'], $session['user']['acctid'], 'uses', 'multispeciality')-$row['uses'], 'multispeciality');
			}
		}
?>
