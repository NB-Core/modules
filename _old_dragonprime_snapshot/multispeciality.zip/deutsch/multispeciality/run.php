<?php
	require_once('common.php');
	require_once('lib/http.php');
	require_once('lib/showform.php');
	require_once('lib/superusernav.php');

	global $session;

	$op = httpget('op');
	$act = httpget('act');
	$del = httpget('del');
	$spec = httpget('spec');
	$test = httpget('test');
	$pspec = httppost('spec');
	$anw = get_module_setting('anw','multispeciality');

	page_header('Klassen Editor');

	$sqla = "SELECT spec$anw FROM ".db_prefix('speciality')."";
	mysql_query($sqla);
	if ($error=mysql_error()){
	    for ($c=1;$c<=$anw;$c++){
			$sql = "ALTER TABLE speciality ADD (`spec$c` varchar(50) NOT NULL default '',`buff$c` text NOT NULL,`uses$c` tinyint(3) NOT NULL default '0')";
			mysql_query($sql);
		}
	}
	if (get_module_setting('lib','multispeciality') || get_module_setting('aka1','multispeciality') || get_module_setting('aka2','multispeciality')){
		$sqlb = "SELECT t6 FROM ".db_prefix('speciality')."";
		mysql_query($sqlb);
		if ($error=mysql_error()){
			$sql = "ALTER TABLE speciality ADD `t4` text NOT NULL AFTER t3";
			mysql_query($sql);
			$sql = "ALTER TABLE speciality ADD `t5` text NOT NULL AFTER t4";
			mysql_query($sql);
			$sql = "ALTER TABLE speciality ADD `t6` text NOT NULL AFTER t5";
			mysql_query($sql);
		}
	}

	$classdatarray=array(
		"Grundwerte,title",
		"class1"=>"Name der Klasse (maennlich):,",
		"class2"=>"Name der Klasse (weiblich):,",
		"spec"=>"Name der Klasse (kurz): *,",
		"`i`& * Mussfeld`i,note",
		"ccode"=>"Farbcode:,",
		"active"=>"Klasse aktiviert?:,bool",
		"mindk"=>"Drachenkills minimal:,int",
		"cost"=>"Spendenpunkte:,int",
		"t2"=>"Klassenauswahl,textarea",
		"t3"=>"Klassenbeschreibung,textarea",
		"t1"=>"Lodge Text,textarea",
		);

	$classbuffarray=array(
		"Meldungen,note",
		"name"=>"Buffname:,",
		"newday"=>"Meldung beim neuen Tag:,",
		"startmsg"=>"Meldung beim Buffstart:,",
		"roundmsg"=>"Meldung jede Runde:,",
		"wearoff"=>"Ablaufmeldung:,",
		"effectmsg"=>"Effektmeldung:,",
		"effectnodmgmsg"=>"Kein Schaden Meldung:,",
		"effectfailmsg"=>"Fehlgeschlagen Meldung:,",

		"Effekte,note",
		"rounds"=>"H�lt Runden (nach Aktivierung):,",
		"atkmod"=>"Angriffsfaktor Spieler:,",
		"defmod"=>"Verteidigungsfaktor Spieler:,",
		"regen"=>"Regeneration:,",
		"minioncount"=>"Helfer Anzahl:,",
		"minbadguydamage"=>"Helfer min Schaden:,",
		"maxbadguydamage"=>"Helfer max Schaden:,",
		"mingoodguydamage"=>"Gegner min Schaden:,",
		"maxgoodguydamage"=>"Gegner max Schaden:,",
		"lifetap"=>"Lebensentzug Faktor:,",
		"damageshield"=>"Schadensschild Faktor:,",
		"badguydmgmod"=>"Gegnerschaden Faktor:,",
		"badguyatkmod"=>"Angriffsfaktor Gegner:,",
		"badguydefmod"=>"Verteidigungsfaktor Gegner:,",

		"Spezialfunktionen,note",
		"invulnerable"=>"Spieler ist unverwundbar:,bool",
		"suspended"=>"L�uft weiter am neuen Tag:,bool",
		"allowinpvp"=>"Bei PVP erlaubt:,bool",
		"allowintrain"=>"Beim Meister erlaubt:,bool",
		"expireafterfight"=>"Buff nach Kampf beenden:,bool",
		"schema"=>"Itemschema,viewonly",
		);

	$classarray=array(
   		"Klassenanwendung_,title",
		"spec"=>"Anwendung :,text",
		"uses"=>"Anwendungkosten:,int",
	);

	$libn=array("t4"=>get_module_setting('libn','multispeciality').",textarea","`i`&- \$row['t4'] -`i,note");
	$aka1n=array("t5"=>get_module_setting('aka1n','multispeciality').",textarea","`i`&- \$row['t5'] -`i,note");
	$aka2n=array("t6"=>get_module_setting('aka2n','multispeciality').",textarea","`i`&- \$row['t6'] -`i,note");

if ($op==''){

	$tcommand = translate_inline("Befehle");
	$tmale = translate_inline("Maennlich");
	$tfemale = translate_inline("Weiblich");
	$tshort = translate_inline("Kurz");
	$tcount = translate_inline("Benutzer");
	$tactive = translate_inline("Aktivieren");
	$tdeactive = translate_inline("Deaktivieren");
	$ttest = translate_inline("Testen");
	$tdel = translate_inline("Loeschen");
	if (get_module_pref('count','multispeciality')) $scount = "<td>`b`c`&$tcount`c`b</td>";
	
	rawoutput("<table border=0 align='center' cellpadding=2 cellspacing=1 bgcolor='#999999'>");
	output_notl("<tr style=\"background-color:#339999;\"><td>`b`c`&$tcommand`c`b</td><td>`b`c`&$tmale`c`b</td><td>`b`c`&$tfemale`c`b</td><td>`b`c`&$tshort`c`b</td>$scount</tr>",true);

    $sql = "SELECT class1,class2,spec,ccode,active FROM ".db_prefix('speciality')." ORDER BY spec ASC";
    $result = db_query($sql);
    for ($i=0;$i<db_num_rows($result);$i++){
		$row = db_fetch_assoc($result);
		rawoutput("<tr class='".($i%2?"trdark":"trlight")."'>",true);

		rawoutput("<td align='center'>");

		if ($row['active']==1){
			output_notl("`&[ $tactive");
		}else{
			output_notl("`&[ <a href='runmodule.php?module=multispeciality&act=1&spec={$row['spec']}'>$tactive</a>",true);
			addnav("","runmodule.php?module=multispeciality&act=1&spec={$row['spec']}");
		}

		if ($row['active']==0){
			output_notl("`&| $tdeactive");
		}else{
			$confdeaktivieren = sprintf_translate("WARNUNG!!!! Du bist gerade dabei die Klasse %s bei allen Nutzern zu deaktivieren! Willst du das wirklich?", $row['class1']?$row['class1']:$row['class2']);
			output_notl("`&| <a href='runmodule.php?module=multispeciality&act=2&spec={$row['spec']}' onClick=\"return confirm('$confdeaktivieren');\">$tdeactive</a>",true);
			addnav("","runmodule.php?module=multispeciality&act=2&spec={$row['spec']}");
		}

		if ($session['user']['specialty']==$row['spec']){
			output_notl("`&| $ttest");
		}else{
			output_notl("`&| <a href='runmodule.php?module=multispeciality&test=1&spec={$row['spec']}'>$ttest</a>",true);
			addnav("","runmodule.php?module=multispeciality&test=1&spec={$row['spec']}");
		}

		output_notl("`&| <a href='runmodule.php?module=multispeciality&op=edit&spec={$row['spec']}'>Editieren</a>",true);
		addnav("","runmodule.php?module=multispeciality&op=edit&spec={$row['spec']}");

		$confloeschen = sprintf_translate("WARNUNG!!!! Du bist gerade dabei die Klasse %s zu l�schen! Willst du das wirklich?", $row['class1']?$row['class1']:$row['class2']);
		output_notl("`&| <a href='runmodule.php?module=multispeciality&del=ja&spec={$row['spec']}' onClick=\"return confirm('$confloeschen');\">$tdel</a> `&]",true);
		addnav("","runmodule.php?module=multispeciality&del=ja&spec={$row['spec']}");

		rawoutput("<td align='center'>");
		rawoutput(appoencode($row['ccode'].$row['class1']));
		rawoutput("<td align='center'>");
		rawoutput(appoencode($row['ccode'].$row['class2']));
		rawoutput("<td align='center'>");
		rawoutput(appoencode($row['ccode'].$row['spec']));
		if (get_module_pref('count','multispeciality')){
			rawoutput("<td align='center'>");

	    	$sql = "SELECT count(specialty) as c FROM ".db_prefix('accounts')." WHERE specialty='{$row['spec']}'";
    		$result1 = db_query($sql);
			$row1 = db_fetch_assoc($result1);

			rawoutput($row1['c']);
		}
		rawoutput("</td></tr>");

    }
    rawoutput("</table>");
    addnav("Neues Klasse erstellen","runmodule.php?module=multispeciality&op=edit");

    if ($act){
		$sql = "UPDATE ".db_prefix('speciality')." SET active=".($act==1?1:0)." WHERE spec='$spec'";
   		db_query($sql);

		if ($act==2){
			$sql = "UPDATE ".db_prefix('accounts')." SET specialty='' WHERE specialty='$spec'";
   			db_query($sql);
		}
    	redirect("runmodule.php?module=multispeciality");
    }

    if ($test){
    	$sql = "SELECT class1,class2,spec,ccode FROM ".db_prefix('speciality')." WHERE spec='$spec'";
    	$result = db_query($sql);
		$row = db_fetch_assoc($result);
        $tsex = $session['user']['sex']?$row['class2']:$row['class1'];

		$tuses = get_module_objpref($session['user']['specialty'], $session['user']['acctid'], 'uses', 'multispeciality');
		$tskill = get_module_objpref($session['user']['specialty'], $session['user']['acctid'], 'skill', 'multispeciality');
		set_module_objpref($session['user']['specialty'], $session['user']['acctid'], 'uses', 0, 'multispeciality');
		set_module_objpref($session['user']['specialty'], $session['user']['acctid'], 'skill', 0, 'multispeciality');
		set_module_objpref($spec, $session['user']['acctid'], 'uses', $tuses, 'multispeciality');
		set_module_objpref($spec, $session['user']['acctid'], 'skill', $tskill, 'multispeciality');
		$session['user']['specialty']=$spec;
		set_module_pref('name',$tsex,'multispeciality');
		set_module_pref('spec',$spec,'multispeciality');
		set_module_pref('ccode',$row['ccode'],'multispeciality');
	  	redirect("runmodule.php?module=multispeciality");
    }

    if ($del=='ja'){
		$sql = "UPDATE ".db_prefix('accounts')." SET specialty='' WHERE specialty='$spec'";
		db_query($sql);
   		$sql = "DELETE FROM ".db_prefix('module_objprefs')." WHERE modulename='multispeciality' AND objtype='$spec'";
   		db_query($sql);
   		$sql = "DELETE FROM ".db_prefix('speciality')." WHERE spec='$spec'";
   		db_query($sql);
    	redirect("runmodule.php?module=multispeciality");
    }

}elseif ($op=='edit'){

	$data = array();

	if ($spec){
    	$sql = "SELECT * FROM ".db_prefix('speciality')." WHERE spec='$spec'";
    	$result = db_query($sql);
		$row = db_fetch_assoc($result);

	    for ($i=1;$i<=$anw;$i++){
			$iarray=unserialize($row["buff$i"]);
			if (!is_array($iarray)) $iarray=array();
	   		while (list($key,$val)=each($iarray)){
				$aarray = array(appoencode($key."|".$i)=>stripslashes("$val"));
				$data=array_merge($data,$aarray);
	   		}
	    }
		$data = array_merge($row,$data);
	}

	$carray = array_merge($classarray,$classbuffarray);

    for ($i=1;$i<=$anw;$i++){
		$darray = $carray;
   		while (list($key,$val)=each($darray)){
			if ($classarray[$key]>""){
   		    	if ($key=="0|$i"){
					$barray = array("$key"=>"Anwendung $i,title");
   		    	}else{
					$barray = array(appoencode($key.$i)=>stripslashes("$val"));
   		    	}
			}else{
				$barray = array(appoencode($key."|".$i)=>stripslashes("$val"));
   		    }
			$data1=array_merge($data1,$barray);
   		}
    }
	if (get_module_setting('lib','multispeciality')) $classdatarray = array_merge($classdatarray,$libn);
	if (get_module_setting('aka1','multispeciality')) $classdatarray = array_merge($classdatarray,$aka1n);
	if (get_module_setting('aka2','multispeciality')) $classdatarray = array_merge($classdatarray,$aka2n);

	$array = array_merge($classdatarray,$data1);

	rawoutput("<table width=\"100%\" border=0 align='center' cellpadding=2 cellspacing=1 bgcolor='#999999'>");
   	rawoutput("<td colspan=4 style=\"background-color:#339999;\">");
	rawoutput("<form action='runmodule.php?module=multispeciality&op=save&spec=$spec' method='POST'>");
	addnav("","runmodule.php?module=multispeciality&op=save&spec=$spec");
	showform($array, $data);
	rawoutput("</form></table>");
    addnav("K?Zur Klassen�bersicht","runmodule.php?module=multispeciality");

}elseif ($op=='save'){

	$schema = array("schema"=>"multispeciality");
	$data1 = $_POST;

    for ($i=1;$i<=$anw;$i++){
		$array = array();
		$data = $_POST;
   		while (list($key,$val)=each($data)){
			list($a1, $a2) = explode("|", $key);
   		    if ($a2==$i){
   		        $key = $a1;
				if ($classbuffarray[$key]>""){
			    	if ($key=="name" && $val=='') break;
					if ($val>"") $data2 = array("$key"=>stripslashes("$val"));
					$array=array_merge($array,$data2);
				}
			$array=array_merge($array,$schema);
   			}
   	    }
		$array = serialize($array);
		$sql.=("buff$i='".addslashes($array)."',"); $keys.=("buff$i,"); $vals.=("'".addslashes($array)."',");
    }

    for ($i=1;$i<=$anw;$i++){
		$data = $_POST;
   		while (list($key,$val)=each($data)){
   		    if (substr($key,-1)==$i){
   		        $j = substr($key,0,-1);
				if ($classarray[$j]>""){
					$sql.=($key."='".$val."',");
                	$keys.=($key.",");
                	$vals.=("'".$val."',");
				}
   			}
   	    }
    }

	while (list($key,$val)=each($data1)){
		if ($classdatarray[$key]>""){
			$sql.=($key."='".$val."',");

            $keys.=($key.",");
            $vals.=("'".$val."',");
		}
	}
    if ($spec){
	    $sql="UPDATE ".db_prefix('speciality')." SET ".substr($sql,0,-1)." WHERE spec='$spec'";
    }else{
        $sql="INSERT INTO ".db_prefix('speciality')." (".substr($keys,0,-1).") VALUES (".substr($vals,0,-1).")";
    }
    db_query($sql);
  	redirect("runmodule.php?module=multispeciality");
}
superusernav();
page_footer();
?>
