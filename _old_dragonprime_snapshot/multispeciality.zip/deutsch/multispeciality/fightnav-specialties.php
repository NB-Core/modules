<?php
	$su = $session['user']['superuser']==0?"active=1":"(active=0 or active=1)";

	$race = modulehook('fightms',array());

	if ($race['fight'] && $session['user']['superuser']==0){
		$class = $race['fight'];
		if (substr($class,-1)==',') $class=substr($class,0,-1);
		$klist=explode(",",$class);
		for($i=0;$i<=count($klist);$i++){
			if (!$vclass) $vclass = "AND (spec != '{$klist[$i]}' ";
			elseif (!$klist[$i]=="") $vclass.="OR spec != '{$klist[$i]}' ";
		}
		if ($vclass) $vclass.=")";
	}

    $sql = "SELECT * FROM ".db_prefix('speciality')." WHERE $su $vclass ORDER BY class1 ASC";
	$result = db_query($sql);
   	for ($i=0;$i<db_num_rows($result);$i++){
      	$row = db_fetch_assoc($result);

       	$uses = get_module_objpref($row['spec'], $session['user']['acctid'], 'uses', 'multispeciality');
		$script = $args['script'];
   		$ccode = $row['ccode'];
		$spec = $row['spec'];
		$punkte = ('Punkte');

		if ($uses==1) $punkte=('Punkt');

   		for ($j=1;$j<=$anw;$j++){
			if ($row["spec$j"] != '' && $row["uses$j"] != 0 && $uses >= $row["uses$j"]) {
				if ($j==1) addnav("$ccode".($session['user']['sex']?$row['class2']:$row['class1'])." ($uses $punkte)`0","");
				addnav("$ccode &#149; ".$row["spec$j"]."`7 (".$row["uses$j"].")`0",
					$script."op=fight&skill=$spec&l=$j", true);
			}
   		}
   	}
?>
