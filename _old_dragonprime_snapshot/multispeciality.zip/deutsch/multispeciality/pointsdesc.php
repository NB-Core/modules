<?php
$sql = "SELECT class1,class2,mindk,cost,t1 FROM ".db_prefix('speciality')." WHERE active=1 AND (mindk > 0 OR cost > 0) ORDER BY spec ASC";
$result = db_query($sql);
for ($i=0;$i<db_num_rows($result);$i++){
   	$row = db_fetch_assoc($result);
	$args['count']++;
	$format = $args['format'];
	$str = $row['t1'];
	$str = sprintf($str, $session['user']['sex']?$row['class2']:$row['class1'], $row['mindk'],$row['cost']);
	if ($row['t1']) output($format, $str, true);
}
?>
