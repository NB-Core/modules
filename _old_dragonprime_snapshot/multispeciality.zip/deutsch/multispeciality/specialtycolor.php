<?php
$args[$spec] = $ccode;
?>
