<?php
$new = get_module_objpref($spec, $session['user']['acctid'], 'skill', 'multispeciality') + 1;
set_module_objpref($spec, $session['user']['acctid'], 'skill', $new, 'multispeciality');
$c = $args['color'];
output("`n%sDu steigst als `&%s%s `# auf Level `#%s%s auf!",$c, $name, $c, $new, $c);
$x = $new % 3;
if ($x == 0){
	output("`n`^Du bekommst eine zus�tzliche Anwendung!`n");
	set_module_objpref($spec, $session['user']['acctid'], 'uses', get_module_objpref($spec, $session['user']['acctid'], 'uses', 'multispeciality') + 1,'multispeciality');
}else{
	if (3-$x == 1) {
		output("`n`^Nur noch 1 Stufe mehr, bis du eine zus�tzliche Anwendung erh�ltst!`n");
	} else {
		output("`n`^Nur noch %s mehr Stufen, bis du eine zus�tzliche Anwendung erh�ltst!`n", (3-$x));
	}
}
output_notl("`0");
?>
