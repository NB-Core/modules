<?php
if ($char){
	$sql = "SELECT ".db_prefix('speciality').".*,".db_prefix('accounts').".sex
		FROM ".db_prefix('speciality')." INNER JOIN ".db_prefix('accounts')."
		ON ".db_prefix('speciality').".spec=".db_prefix('accounts').".specialty
		WHERE ".db_prefix('accounts').".login='$char'";
	$result = db_query($sql);
	$row = db_fetch_assoc($result);
	$args[$row['spec']] = $row['sex']?$row['class2']:$row['class1'];
}elseif ($userid){
	$sql = "SELECT ".db_prefix('speciality').".*,".db_prefix('accounts').".sex
		FROM ".db_prefix('speciality')." INNER JOIN ".db_prefix('accounts')."
		ON ".db_prefix('speciality').".spec=".db_prefix('accounts').".specialty
		WHERE ".db_prefix('accounts').".acctid='$userid'";
	$result = db_query($sql);
	$row = db_fetch_assoc($result);
	if (db_num_rows($result)) $args[$row['spec']] = $row['sex']?$row['class2']:$row['class1'];
}
?>
