<?php
	if(!is_module_active('multispeciality') && !db_table_exists("speciality"))
	{
		$sql = "CREATE TABLE `speciality` (";
  			$sql .= "`class1` varchar(50) NOT NULL default '',";
			$sql .= "`class2` varchar(50) NOT NULL default '',";
			$sql .= "`spec` char(2) NOT NULL default '',";
  			$sql .= "`ccode` char(2) NOT NULL default '',";
  			$sql .= "`active` tinyint(1) NOT NULL default '0',";
  			$sql .= "`mindk` smallint(5) NOT NULL default '0',";
  			$sql .= "`cost` smallint(5) NOT NULL default '0',";
  			$sql .= "`t1` text NOT NULL,";
  			$sql .= "`t2` text NOT NULL,";
  			$sql .= "`t3` text NOT NULL,";
  			$sql .= "`spec1` varchar(50) NOT NULL default '',";
  			$sql .= "`buff1` text NOT NULL,";
  			$sql .= "`uses1` tinyint(3) NOT NULL default '0',";
  			$sql .= "`spec2` varchar(50) NOT NULL default '',";
  			$sql .= "`buff2` text NOT NULL,";
  			$sql .= "`uses2` tinyint(3) NOT NULL default '0',";
  			$sql .= "`spec3` varchar(50) NOT NULL default '',";
  			$sql .= "`buff3` text NOT NULL,";
  			$sql .= "`uses3` tinyint(3) NOT NULL default '0',";
  			$sql .= "`spec4` varchar(50) NOT NULL default '',";
  			$sql .= "`buff4` text NOT NULL,";
  			$sql .= "`uses4` tinyint(3) NOT NULL default '0',";
  			$sql .= "PRIMARY KEY  (`spec`)";
			$sql .= ") TYPE=MyISAM AUTO_INCREMENT=2210" ;
		db_query($sql);
	}
	module_addhook('superuser');
	module_addhook('dragonkill');
	module_addhook('choose-specialty');
	module_addhook('set-specialty');
	module_addhook('specialtycolor');
	module_addhook('specialtymodules');
	module_addhook('incrementspecialty');
	module_addhook('newday');
	module_addhook('fightnav-specialties');
	module_addhook('apply-specialties');
	module_addhook('pointsdesc');
	module_addhook('specialtynames');
?>
