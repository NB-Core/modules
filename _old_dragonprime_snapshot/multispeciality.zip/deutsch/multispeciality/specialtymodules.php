<?php
$args[$spec] = "multispeciality";
?>
