<?php
/*
Geschrieben fuer lotgd.eq-gildenhaus.de, Antic �2004-2005
Bugmeldungen bitte an antic@eq-gildenhaus.de
Vorschlaege zur Verbesserung sind jederzeit willkommen!
*/
function multispeciality_getmoduleinfo(){
	$info = array(
		"name" => "Multiklassen (german)",
		"author" => "`3Antic`0",
		"version" => "0.77",
		"download" => "http://dragonprime.net/users/Antic/multispeciality.zip",
		"category" => "General",
		"settings"=> array(
			"Multiklassen Einstellungen,title",
			"anw"=>"Maximale Anzahl von Anwendungen?,range,4,99,1|4",
			"libn"=>"Textfeld 1,text|Library",
			"lib"=>"Textfeld 1 eingeschaltet?,bool|0",
			"aka1n"=>"Textfeld 1,text|Akademie 1",
			"aka1"=>"Akademie 1 Text eingeschaltet?,bool|0",
			"aka2n"=>"Textfeld 1,text|Akademie 2",
			"aka2"=>"Akademie 2 Text eingeschaltet?,bool|0",
		),
		"prefs" => array(
			"Multiklassen,title",
			"count"=>"Anwendercounter eingeschaltet?,bool|0",
			"name"=>"Klasse,text|",
			"spec"=>"Klasse Kurzform,text|",
			"ccode"=>"Klasse Farbe,text|",
		),
	);
	return $info;
}

function multispeciality_install(){
	include ("modules/multispeciality/install.php");
	return true;
}

function multispeciality_uninstall(){
	return true;
}

function multispeciality_dohook($hookname,$args){
	global $session,$resline;

	$name = get_module_pref('name','multispeciality');
	$spec = get_module_pref('spec','multispeciality');
	$ccode = get_module_pref('ccode','multispeciality');
    $setspecialty = httpget('setspecialty');
	$char = httpget('char');
	$userid = httpget('userid');
	$anw = get_module_setting('anw','multispeciality');
	include ("modules/multispeciality/$hookname.php");
	return $args;
}

function multispeciality_run(){
	include ("modules/multispeciality/run.php");
}
?>
