<?
/******************************
 Remote Backup - LoGD Dump
 By: Kevin Hatfield - Arune
 03/04
******************************/
require_once "dbconnect.php";
if ($_SERVER['REMOTE_ADDR']=="192.168.0.2" | $_SERVER['DB_HOST']=="localhost") {
        $name = "logdbackup-".date("Y-m-d H:i").".sql.gz";
        header("Content-Type: application/x-gzip; name=\"".htmlentities($name)."\";");
        header("Content-Disposition: attachment/download; filename=\"".htmlentities($name)."\";");
        $cmd = "mysqldump -u \"$DB_USER\" --pass=\"$DB_PASS\" -h \"$DB_HOST\" \"$DB_NAME\" | gzip -9";
        e_exec($cmd);

}else{
        //echo $_SERVER['REMOTE_ADDR'];
}

function e_exec($cmd){
  $fp=popen("$cmd",'r');
        fpassthru($fp);
  }
?>