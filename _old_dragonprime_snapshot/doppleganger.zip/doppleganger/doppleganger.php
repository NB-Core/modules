<?php
	global $session;
	$op = httpget('op');
	$op2 = httpget('op2');
	$op3 = httpget('op3');
	$id = httpget('id');
	$ap = httpget('ap');
	page_header("The Doppleganger");
if ($op=="enter"){
	page_header("An Encounter");
	$session['user']['specialinc']="";
	set_module_pref("encountered",1);
	$sql = "SELECT name, acctid FROM ".db_prefix("accounts")." INNER JOIN ".db_prefix("module_userprefs")." ON acctid=userid WHERE modulename='doppleganger' AND setting='dopplename' AND value=1 ORDER BY rand(".e_rand().") LIMIT 1";
	$res = db_query($sql);
	$row = db_fetch_assoc($res);
	$name = $row['name'];
	$id = $row['acctid'];
	if ($id==0){
		$armor=get_module_setting("armor");
		$name=get_module_setting("name");
		$weapon=get_module_setting("weapon");
		$sex=get_module_setting("sex");
	}else{
		$armor=get_module_pref("armor","doppleganger",$id);
		$name=get_module_pref("name","doppleganger",$id);
		$weapon=get_module_pref("weapon","doppleganger",$id);
		$sex=get_module_pref("sex","doppleganger",$id);
	}
	set_module_pref("dgid",$id);
	set_module_pref("dgname",$name);
	set_module_pref("dgweapon",$weapon);
	set_module_pref("dgsex",$sex);
	output("`n`@You enter a clearing and");
	if ($id==$session['user']['acctid']){
		output("see yourself standing several feet away! How is this possible?");
		output("You notice that %s is wearing `&%s`@ and is brandishing a `&%s`@.",translate_inline($sex?"she":"he"),$armor,$weapon);
		output("`n`nSlowly you come to realize that this is the Doppleganger! You prepare your `&%s`@ and get ready for a great duel.",$session['user']['weapon']);
	}else{
		output("notice someone standing several feet away. You recognize that it's `^%s`@. %s is brandishing a `&%s`@ and wearing `&%s`@.",$name,translate_inline($sex?"She":"He"),$weapon,$armor);
		output("`n`n%s looks you over. `#'It is time to see who is the greater warrior.  Prepare for battle!'",translate_inline($sex?"She":"He"));
	}
	addnav(array("Fight `^%s", $name),"runmodule.php?module=doppleganger&op=attack&id=$id");
}
if ($op=="choose"){
	output("`c`b`@The Doppleganger`b`c`n");
	if (get_module_pref("dopplename")==2){
		output("You puff out your chest in a show of power and force. Is there anyone in the land greater than you?");
		output("`n`nYou feel a tap on your shoulder. You turn around and find yourself face to face with yourself!");
		output("`n`nYourself introduces %sself to you.",translate_inline($session['user']['sex']?"her":"him"));
		output("`n`n`#'Hello.  I am The Doppleganger.  I am a shapeshifter and I am able to assume the appearance of anyone that I deem worthy.'");
		output("`n`n'You are worthy.'");
		output("`n`n'From henceforth, occassionally other warriors will encounter me in the forest, and I will honor your accomplishments by dueling them in your name.");
		output("In addition, I will wield a fascimile of your weapon and wear your armor so that they may see how mighty you are.'`n`n");
		set_module_pref("dopplename",1);
		set_module_pref("name",$session['user']['name']);
		set_module_pref("armor",$session['user']['armor']);
		set_module_pref("weapon",$session['user']['weapon']);
		set_module_pref("sex",$session['user']['sex']);
	}
	$ap=0;
	if (get_module_pref("approve1")==2) $ap=1;
	elseif (get_module_pref("approve2")==2) $ap=2;
	elseif (get_module_pref("approve3")==2) $ap=3;
	if ($ap>0){
		$phrase1 = httpget('phrase1');
		if ($phrase1==""){
			blocknav("news.php");
			blocknav("village.php");
			$subop = httpget('subop');
			$submit1= httppost('submit1');
			if ($subop!="submit1"){
				output("`@The Doppleganger looks you over and notices that you are worthy of greater adoration.`n`n`#'I will use");
				if ($ap==1) output("a battle cry in my attacks when I fight to honor you.  You may choose which battle cry I will use to cause my foe to cringe in fear.'`n`n`#'What is your battle cry?'`n`n");
				if ($ap==2){
					output("another battle cry in my attacks when I fight to honor you.  You may choose another battle cry I will use to cause my foe to cringe in fear.'`n`n");
					if (get_module_pref("approve1")==4) output("`#'You declined to offer a battle cry the first time.  Would you like to offer a battle cry now?'");
					else {
						output("'The first battle cry that you chose was:`n`n");
						output("`c`@'%s`@'`c",get_module_pref("phrase1"));
						output("`n`#'What is your 2nd battle cry?'`n`n");
					}
				}
				if ($ap==3){
					output("a third battle cry in my attacks when I fight to honor you.  You may choose one more battle cry I will use to cause my foe to cringe in fear.'`n`n");
					if (get_module_pref("approve1")==4 && get_module_pref("approve2")==4) output("`n`n`#'You declined to offer a battle cry earlier.  Would you like to offer a battle cry now?'");
					elseif (get_module_pref("approve1")==4 && get_module_pref("approve2")!=4) {
						output("`n`n'The first battle cry that you chose was:`n`n");
						output("`c`@'%s`@'`c",get_module_pref("phrase1"));
						output("`n`#'You declined to offer a second battle cry.'`n");
						output("`n`#'What is your next battle cry?'`n`n");
					}elseif (get_module_pref("approve1")!=4 && get_module_pref("approve2")==4) {
						output("`n`n'The declined the first battle cry.`n`n");
						output("`n`n`#'You second battle cry that you chose was:'`n");
						output("`c`@'%s`@'`c",get_module_pref("phrase2"));
						output("`n`#'What is your next battle cry?'`n`n");
					}else{
						output("`n`n'The first two battle cries that you chose are:`n`n");
						output("`c`@'%s`@'`c",get_module_pref("phrase1"));
						output("`c`n`@'%s`@'`c",get_module_pref("phrase2"));
						output("`n`#'What is your 3rd battle cry?'`n`n");
					}
				}
				output("`^`cNote: You may use colors`c`n");
				$submit1 = translate_inline("Submit");
				rawoutput("<form action='runmodule.php?module=doppleganger&op=choose&subop=submit1' method='POST'><input name='submit1' id='submit1'><input type='submit' class='button' value='$submit1'></form>");
				addnav("","runmodule.php?module=doppleganger&op=choose&subop=submit1");	
				addnav("Submit","runmodule.php?module=doppleganger&op=choose");
				addnav("Decline","runmodule.php?module=doppleganger&op=decline&op2=$ap");
			}else{
				if ($submit1==""){
					output("`#'Since you did not submit a phrase I will offer you a chance to try again.  Otherwise, you may decline.'");
					addnav("Try Again","runmodule.php?module=doppleganger&op=choose");
					addnav("Decline","runmodule.php?module=doppleganger&op=decline&op2=$ap");
				}else{
					output("`#'Is this the phrase you wish to use?'");
					output("`n`n`c`@'%s`@'`c",$submit1);
					addnav("Yes","runmodule.php?module=doppleganger&op=choose&phrase1=$submit1");
					addnav("No","runmodule.php?module=doppleganger&op=choose");
				}
			}
		}else{
			output("`^Your phrase will be reviewed for approval.`n");
			set_module_pref("approve".$ap,3);
			set_module_pref("phrase".$ap,$phrase1);
		}
	}
	addnav("News","news.php");
	villagenav();
}
if ($op=="decline"){
	output("`c`b`@The Doppleganger`b`c`n");
	output("`#'It is within your rights to decline a battle cry. I understand.'");
	set_module_pref("approve".$op2,4);
	addnav("News","news.php");
	villagenav();
}
if ($op=="fwin"){
	output("`c`b`@The Doppleganger`b`c`n");
	output("`#'That was very impressive. I");
	$dks=$session['user']['dragonkills'];
	$name=get_module_pref("dgname");
	$expbonus=$dks*3;
	$expgain =($session['user']['level']*30+$expbonus);
	$session['user']['experience']+=$expgain;
	$ap1=get_module_pref("approve1");
	$ap2=get_module_pref("approve2");
	$ap3=get_module_pref("approve3");
	if (get_module_pref("dgid")==$session['user']['acctid']){
		output("think I will have to use your current weapon and armor in my next imitation of you. In addition, I");
		set_module_pref("weapon",$session['user']['weapon']);
		set_module_pref("armor",$session['user']['armor']);
		set_module_pref("name",$session['user']['name']);
	}
	if ($ap1==0 && $ap2==0 && $ap3==0) output("give you my highest compliments on an excellent duel!'`n");
	elseif(($dks>= get_module_setting("phrase2dk") || $dks>= get_module_setting("phrase3dk")) && ($ap1<>2 && $ap2<>2 && $ap<>2)){
		output("would like to offer you a chance to change one of the battle cries I use for you.'");
		if ($ap1==4 && $ap2==4 && ($ap3==0 || $ap3==4)) output("`n`n`#'You declined to offer any battle cries earlier.'");
		else{
			output("`n`n`^Previous battle cry choices:`n`n");
			if ($ap1==1 || $ap1==3) output("`c`2Phrase 1: `@'%s`@'`c",get_module_pref("phrase1"));
			if ($ap2==1 || $ap2==3) output("`c`3Phrase 2: `@'%s`@'`c",get_module_pref("phrase2"));
			if ($ap3==1 || $ap3==3) output("`c`4Phrase 3: `@'%s`@'`c",get_module_pref("phrase3"));
		}
		addnav("Change Phrase 1","runmodule.php?module=doppleganger&op=changewin&op2=1");
		addnav("Change Phrase 2","runmodule.php?module=doppleganger&op=changewin&op2=2");
		if($dks>= get_module_setting("phrase3dk") && $ap3<>2) addnav("Change Phrase 3","runmodule.php?module=doppleganger&op=changewin&op2=3");
	}elseif($dks>= get_module_setting("phrase1dk")){
		output("would like to offer you a chance to change your battle cry I use for you.'`n");
		addnav("Change Your Phrase","runmodule.php?module=doppleganger&op=changewin&op2=1");
	}elseif($dks<get_module_setting("doppledk")){
		output("believe one day you will have the honor of my imitation. But not quite yet.'`n");
	}else{
		output("give you my highest compliments on an excellent duel!'`n");
	}
	output("`n`@`bYou've gained `#%s experience`@.`b`n`n",$expgain);
	addnav("Return to the Forest","runmodule.php?module=doppleganger&op=exit");
}
if ($op=="changewin"){
	output("`c`b`@The Doppleganger`b`c`n");
	output("`#'On your next day you will be able to choose a new phrase.'");
	set_module_pref("approve".$op2,2);
	$session['user']['specialinc']="";
	addnav("To the Forest","forest.php");

}
if ($op=="exit"){
	$session['user']['specialinc']="";
	redirect("forest.php");
}
//From Lonny's Job Application
if ($op=="super1"){
	addnav("Navigation");
	addnav("Return to the Grotto","superuser.php");
	villagenav();
	page_header("Doppleganger");
	output("`c`b`&Doppleganger Phrase %s Approval`0`b`c`n",$ap);
	if ($op2 == ""){
		$sql = "SELECT acctid,name,value FROM ".db_prefix('module_userprefs')." LEFT JOIN ".db_prefix('accounts')." ON (acctid = userid) WHERE modulename='doppleganger' and setting='approve".$ap."' and value=3";
		$result = db_query($sql);
		output("<table border='0' cellpadding='5' cellspacing='0'>",true);
        for ($i=0;$i<db_num_rows($result);$i++){
         $row = db_fetch_assoc($result);
			if ($row['value'] > 0){
				$j++;
				output("<tr class='".($j%2?"trlight":"trdark")."'>",true);
				output("<td>",true);
				$name=$row['name'];
				$acctid=$row['acctid'];
				$reason=get_module_pref("phrase".$ap,"doppleganger",$acctid);
				output("`^<a href=\"runmodule.php?module=doppleganger&op=super1&op2=process&op3=$acctid&ap=$ap\">`^ From: `0$name`0 -> `2Phrase: `#$reason</a>",true);
				output("</tr>",true);
				addnav("","runmodule.php?module=doppleganger&op=super1&op2=process&op3=$acctid&ap=$ap");
			}
		}
		output("</table>",true);
	}
	if ($op2 == "process"){
		$acctid=$op3;
		addnav("Actions");
		addnav("Approve","runmodule.php?module=doppleganger&op=super1&op2=approve&op3=$acctid&ap=$ap");
		addnav("Deny","runmodule.php?module=doppleganger&op=super1&op2=deny&op3=$acctid&ap=$ap");
		$sql = "SELECT acctid,name,value FROM ".db_prefix('module_userprefs')." LEFT JOIN ".db_prefix('accounts')." ON (acctid = userid) WHERE modulename='doppleganger' and setting='approve".$ap."'";
		$result = db_query($sql);
		for ($i=0;$i<db_num_rows($result);$i++){
			$row = db_fetch_assoc($result);
			if ($row['acctid'] == $acctid){
				output("`^<a href=\"runmodule.php?module=doppleganger&op=super1&op2=approve&op3=$acctid&ap=$ap\">`@Approve</a> `0or",true);
				addnav("","runmodule.php?module=doppleganger&op=super1&op2=approve&op3=$acctid&ap=$ap");
				output("`^<a href=\"runmodule.php?module=doppleganger&op=super1&op2=deny&op3=$acctid&ap=$ap\">`\$Deny</a>`0 Doppleganger Phrase ".$ap." for ".$row['name']."`7?",true);
				addnav("","runmodule.php?module=doppleganger&op=super1&op2=deny&op3=$acctid&ap=$ap");			
			}
		}
	}
	if ($op2 == "approve"){
		$acctid=$op3;
		$sql = "SELECT acctid,name,login,value FROM ".db_prefix('module_userprefs')." LEFT JOIN ".db_prefix('accounts')." ON (acctid = userid) WHERE acctid = ".$acctid." and modulename='doppleganger' and setting='approve".$ap."'";
		$result = db_query($sql);
		$row = db_fetch_assoc($result);
		$name=$row['name'];
		$login=$row['login'];
		$id = $row['acctid'];
		set_module_pref("approve".$ap,1,"doppleganger",$acctid);
		require_once("lib/systemmail.php");
		$subj = sprintf("`@Doppleganger `&Phrase %s Approval",$ap);
		$body = sprintf("`^Congratulations.  Your submission for your Doppleganger Phrase %s:`n`n`@%s`n`n`^has been approved.",$ap,get_module_pref("phrase".$ap,"doppleganger",$id));
		systemmail($id,$subj,$body);
		output("Doppleganger Phrase %s approved for %s.`n",$ap,$name);
	}
	if ($op2 == "deny"){
		$acctid=$op3;
		$subop = httpget('subop');
		$submit= httppost('submit');
		if ($subop!="submit"){
			output("Please give a reason.`n");
			$submit = translate_inline("Submit");
			output("<form action='runmodule.php?module=doppleganger&op=super1&op2=deny&op3=$acctid&subop=submit' method='POST'><input name='submit' id='submit'><input type='submit' class='button' value='$submit'></form>",true); 
			addnav("","runmodule.php?module=doppleganger&op=super1&op2=deny&op3=$acctid&subop=submit");
		}else{
			$sql = "SELECT acctid,name,value FROM ".db_prefix('module_userprefs')." LEFT JOIN ".db_prefix('accounts')." ON (acctid = userid) WHERE modulename='doppleganger' and setting='approve".$ap."' and value=3";
			$result = db_query($sql);
			for ($i=0;$i<db_num_rows($result);$i++){
				$row = db_fetch_assoc($result);
				if ($row['acctid'] == $acctid){
					$name=$row['name'];
				}
			}
			set_module_pref("approve".$ap,2,"doppleganger",$acctid);
			require_once("lib/systemmail.php");
			$subj = sprintf("`@Doppleganger `&Phrase %s Denied",$ap);
			$body = sprintf("`@Unfortunately your requested phrase for the doppleganger was denied for the following reason:`n`n`#%s`n`n`@You will have a chance to submit another phrase at the next newday.",$submit);
			systemmail($acctid,$subj,$body);
			output("Doppleganger Phrase %s denied  for %s`n",$ap,$name);
		}
	}
	addnav("Process");
	$sql = "SELECT acctid,name,value FROM ".db_prefix('module_userprefs')." LEFT JOIN ".db_prefix('accounts')." ON (acctid = userid) WHERE modulename='doppleganger' and setting='approve1' and value=3";
	$result = db_query($sql);
	$countp1=db_num_rows($result);
	if (get_module_pref('super')&& $countp1>0) addnav(array("Process Doppleganger Phrase 1 `4(%s)",$countp1),"runmodule.php?module=doppleganger&op=super1&ap=1");
	$sql = "SELECT acctid,name,value FROM ".db_prefix('module_userprefs')." LEFT JOIN ".db_prefix('accounts')." ON (acctid = userid) WHERE modulename='doppleganger' and setting='approve2' and value=3";
	$result = db_query($sql);
	$countp2=db_num_rows($result);
	if (get_module_pref('super')&& $countp2>0) addnav(array("Process Doppleganger Phrase 2 `4(%s)",$countp2),"runmodule.php?module=doppleganger&op=super1&ap=2");
	$sql = "SELECT acctid,name,value FROM ".db_prefix('module_userprefs')." LEFT JOIN ".db_prefix('accounts')." ON (acctid = userid) WHERE modulename='doppleganger' and setting='approve3' and value=3";
	$result = db_query($sql);
	$countp3=db_num_rows($result);
	if (get_module_pref('super')&& $countp3>0) addnav(array("Process Doppleganger Phrase 3 `4(%s)",$countp3),"runmodule.php?module=doppleganger&op=super1&ap=3");
}
//End code based on work from Lonny

if ($op=="attack") {
	if ($id==0){
		$name=get_module_setting("name");
		$weapon=get_module_setting("weapon");
	}else{
		$name=get_module_pref("name","doppleganger",$id);
		$weapon=get_module_pref("weapon","doppleganger",$id);
	}
	$level=$session['user']['level']+1;
	if ($level>15) $targetlevel=15;
	$hitpoints=$session['user']['maxhitpoints'];
	$badguy = array(
		"creaturename"=>$name,
		"creatureweapon"=>$weapon,
		"creaturelevel"=>$level,
		"creatureattack"=>$session['user']['attack']*get_module_setting("dgatt"),
		"creaturedefense"=>$session['user']['defense']*get_module_setting("dgdef"),
		"creaturehealth"=>round($hitpoints*get_module_setting("dghp")),
		"diddamage"=>0
	);
	$session['user']['badguy']=createstring($badguy);
	$op="fight";
}
if ($op=="fight") {
	$battle=true;
	blocknav("runmodule.php?module=doppleganger&op=fight&auto=ten");
	blocknav("runmodule.php?module=doppleganger&op=fight&auto=full");
	$speak=e_rand(1,3);
	rawoutput("<big>");
	if ($speak==1 && get_module_pref("approve1")==1) output("`c`@The Doppleganger cries out `b'%s`@'`c`b`n",get_module_pref("phrase1"));
	if ($speak==2 && get_module_pref("approve2")==1) output("`c`@The Doppleganger gives a battle cry: `b'%s`@'`c`b`n",get_module_pref("phrase2"));
	if ($speak==3 && get_module_pref("approve3")==1) output("`c`@The Doppleganger attacks and yells `b'%s`@'`c`b`n",get_module_pref("phrase3"));
	rawoutput("</big>");
}
if ($battle){       
	include("battle.php");
	if ($victory){
		$sex=get_module_pref("dgsex");
		$name = get_module_pref("dgname");
		addnews("%s `@defeated %s`@ in the forest... or was it something else?",$session['user']['name'],$name);
		output("`n`@Before you are able to strike your final blow, the Doppleganger raises %s hand.",translate_inline($sex?"her":"his"));
		if (get_module_pref("dgid")!=$session['user']['acctid'] && get_module_setting("dopyom")==1 && get_module_pref("user_stat")==1){
			require_once("lib/systemmail.php");
			$id = get_module_pref("dgid");
			$subj = sprintf("`@%s `@Doppleganger Defeat",$name);
			$body = sprintf("`#I am writing to inform you that I have been defeated by `^%s`# while fighting in your guise. Perhaps your name does not inspire the fear I thought it would.`n`nSigned,`n`nThe Doppleganger",$session['user']['name']);
			systemmail($id,$subj,$body);
		}
		addnav("Continue","runmodule.php?module=doppleganger&op=fwin");
	}elseif($defeat){
		if (get_module_pref("dgid")!=$session['user']['acctid'] && get_module_setting("dopyom")==1 && get_module_pref("user_stat")==1){
			require_once("lib/systemmail.php");
			$id = get_module_pref("dgid");
			$name = get_module_pref("dgname");
			$subj = sprintf("`@%s `@Doppleganger Success",$name);
			$body = sprintf("`#I am writing to inform you that I have defeated `^%s`# while fighting in your guise.  Your name has been glorified once again.  Gloating may be in order.`n`nSigned,`n`nThe Doppleganger",$session['user']['name']);
			systemmail($id,$subj,$body);
		}
		$name=get_module_pref("dgname");
		require_once("lib/taunt.php");
		$taunt = select_taunt_array();
		$session['user']['gold']=0;
		$exploss = round($session['user']['experience']*get_module_setting("perexpl")/100);
		$session['user']['experience']-=$exploss;
		$rand=e_rand(1,2);
		$session['user']['specialinc']="";
		output("`b`4You lose `#%s experience`4.`b`n`n",$exploss);
		output("`^The Doppleganger takes all of your gold.`n`n");
		output("`#'You fought bravely, but");
		if (($rand==1 && get_module_setting("death")==2) || get_module_setting("death")==1){
			output("it's time for you to sleep a deep sleep.'");
			addnews("%s `@was killed by %s`@... or was it something else?`n%s",$session['user']['name'],$name,$taunt);
			addnav("Daily news","news.php");
			$session['user']['alive'] = false;
			$session['user']['hitpoints'] = 0;
		}else{
			output("you were not strong enough to win this battle.  This victory is mine, but I will let you learn from the lessons I have taught you.'");
			addnews("%s `@was defeated in battle by %s`@... or was it something else?`n%s",$session['user']['name'],$name,$taunt);		
			$session['user']['hitpoints'] = 1;
			addnav("Return to the Forest","forest.php");
		}
	}else{
		require_once("lib/fightnav.php");
		fightnav(true,false,"runmodule.php?module=doppleganger");
	}
}
page_footer();

?>