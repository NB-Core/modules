<?php
/*
Module Name:  doppleganger.php
Category:  Forest Specials
Worktitle:  Doppleganger
Author:  DaveS
Date:  May 29, 2006

Description:

Reward your players with high dk numbers with a forest special that uses their name and customized phrases.

A doppleganger honors players be imitating them in the forest.  The doppleganger will use their weapon
and armor.  Also, 3 battle cries will be called out during fighting. Phrases must be staff approved.

V3.01	Fixed the approval system
*/

function doppleganger_getmoduleinfo(){
	$info = array(
		"name"=>"Doppleganger",
		"version"=>"3.01",
		"author"=>"DaveS",
		"category"=>"Forest Specials",
		"download"=>"",
		"settings"=>array(
			"Doppleganger Settings,title",
			"forest"=>"Chance to encounter in the forest:,range,5,100,5|100",
			"mindk"=>"Minimum dks for player to encounter the Doppleganger:,int|1",
			"doppledk"=>"Dks needed to have a Doppleganger of the player?,int|1",
			"phrase1dk"=>"Dks needed to have phrase 1?,int|2",
			"phrase2dk"=>"Dks needed to have phrase 2?,int|3",
			"phrase3dk"=>"Dks needed to have phrase 3?,int|4",
			"dopyom"=>"Send the person who the doppleganger copied a YoM for the battle results?,bool|1",
			"Doppleganger,title",
			"perexpl"=>"Percentage of experience lost if defeated by Doppleganger:,range,0,100,1|15",
			"death"=>"Kill player if they lose to the Doppleganger?,enum,0,No,1,Yes,2,50% of the time|2",
			"dghp"=>"Multiplier for Doppleganger's hitpoints:,floatrange,0.7,2.0,0.1|0.9",
			"dgatt"=>"Multiplier for Doppleganger's attack:,floatrange,0.7,2.0,0.1|0.9",
			"dgdef"=>"Multiplier for Doppleganger's defense:,floatrange,0.7,2.0,0.1|1.1",
			"name"=>"What is the Doppleganger's name if no one available?,txt|King Arthur",
			"armor"=>"What is the Doppleganger's armor if no one available?,txt|Plate Mail",
			"weapon"=>"What is the Doppleganger's weapon if no one available?,txt|Excalibur",
			"sex"=>"What is the Doppleganger's sex if no one available?,enum,0,Male,1,Female|0",
		),
		"prefs"=>array(
			"Doppleganger Encounter,title",
			"super"=>"Admin/Moderator Doppleganger Phrase Approval?,bool|0",
			"encountered"=>"Has player encountered the Doppleganger today?,bool|0",
			"dgname"=>"What was the name of the last Doppleganger encountered?,viewonly|",
			"dgid"=>"What was the id of the last Doppleganger encountered?,viewonly|",
			"dgweapon"=>"What was the weapon from the last Doppleganger encountered?,viewonly|",
			"dgsex"=>"What was the sex of the last Doppleganger encountered?,viewonly|",
			"user_stat"=>"Receive a YoM when your Doppleganger fights another player?,bool|1",
			"This may be overridden by your local Admin,note",
			"Doppleganger of Player,title",
			"dopplename"=>"Has the player received a Doppleganger?,enum,0,NA,1,Yes,2,No|0",
			"name"=>"What is the player's Doppleganger's name?,txt|",
			"armor"=>"What is the player's Doppleganger's armor?,txt|",
			"weapon"=>"What is the player's Doppleganger's weapon?,txt|",
			"sex"=>"What is the player's Doppleganger's sex?,enum,0,Male,1,Female|0",
			"phrase1"=>"What is the player's Phrase 1?,txt|",
			"approve1"=>"Has Phrase 1 been approved?,enum,0,NA,1,Yes,2,To Submit,3,Pending,4,Declined|0",
			"phrase2"=>"What is the player's Phrase 2?,txt|",
			"approve2"=>"Has Phrase 2 been approved?,enum,0,NA,1,Yes,2,To Submit,3,Pending,4,Declined|0",
			"phrase3"=>"What is the player's Phrase 3?,txt|",
			"approve3"=>"Has Phrase 3 been approved?,enum,0,NA,1,Yes,2,To Submit,3,Pending,4,Declined|0",
		),
	);
	return $info;
}
function doppleganger_chance() {
	global $session;
	$ret= get_module_setting('forest','doppleganger');
	if ($session['user']['dragonkills']<get_module_setting("mindk","doppleganger")||get_module_pref("encountered","doppleganger",$session['user']['acctid'])==1) $ret=0;
	return $ret;
}
function doppleganger_install(){
	module_addeventhook("forest","require_once(\"modules/doppleganger.php\");
	return doppleganger_chance();");
	module_addhook("newday");
	module_addhook("superuser");
	return true;
}
function doppleganger_uninstall(){
	return true;
}
function doppleganger_dohook($hookname,$args){
	global $session;
	switch($hookname){
		case "newday":
			set_module_pref("encountered",0);
			$dks=$session['user']['dragonkills'];
			if($dks>= get_module_setting("doppledk") && get_module_pref("dopplename")==0) set_module_pref("dopplename",2);
			if($dks>= get_module_setting("phrase1dk") && get_module_pref("approve1")==0) set_module_pref("approve1",2);
			if($dks>= get_module_setting("phrase2dk") && get_module_pref("approve2")==0) set_module_pref("approve2",2);
			if($dks>= get_module_setting("phrase3dk") && get_module_pref("approve3")==0) set_module_pref("approve3",2);
			if(get_module_pref("encountered")==2 || get_module_pref("approve1")==2 || get_module_pref("approve2")==2 || get_module_pref("approve3")==2){
				blocknav("news.php");
				blocknav("village.php");
				if ($session['user']['restorepage'] != "runmodule.php?module=doppleganger&op=choose"){
					addnav("The Doppleganger","runmodule.php?module=doppleganger&op=choose");
				}
			}
		break;
		case "superuser":
			$sql = "SELECT acctid,name,value FROM ".db_prefix('module_userprefs')." LEFT JOIN ".db_prefix('accounts')." ON (acctid = userid) WHERE modulename='doppleganger' and setting='approve1' and value=3";
			$result = db_query($sql);
			$countp1=db_num_rows($result);
			if (get_module_pref('super')&& $countp1>0) addnav(array("Process Doppleganger Phrase 1 `4(%s)",$countp1),"runmodule.php?module=doppleganger&op=super1&ap=1");
			$sql = "SELECT acctid,name,value FROM ".db_prefix('module_userprefs')." LEFT JOIN ".db_prefix('accounts')." ON (acctid = userid) WHERE modulename='doppleganger' and setting='approve2' and value=3";
			$result = db_query($sql);
			$countp2=db_num_rows($result);
			if (get_module_pref('super')&& $countp2>0) addnav(array("Process Doppleganger Phrase 2 `4(%s)",$countp2),"runmodule.php?module=doppleganger&op=super1&ap=2");
			$sql = "SELECT acctid,name,value FROM ".db_prefix('module_userprefs')." LEFT JOIN ".db_prefix('accounts')." ON (acctid = userid) WHERE modulename='doppleganger' and setting='approve3' and value=3";
			$result = db_query($sql);
			$countp3=db_num_rows($result);
			if (get_module_pref('super')&& $countp3>0) addnav(array("Process Doppleganger Phrase 3 `4(%s)",$countp3),"runmodule.php?module=doppleganger&op=super1&ap=3");
		break;
	}
	return $args;
}
function doppleganger_runevent($type) {
	redirect("runmodule.php?module=doppleganger&op=enter");
}
function doppleganger_run(){
	global $SCRIPT_NAME;
	if ($SCRIPT_NAME == "runmodule.php"){
		$module=httpget("module");
		if ($module == "doppleganger"){
			include("modules/doppleganger/doppleganger.php");
		}
	}
}
?>