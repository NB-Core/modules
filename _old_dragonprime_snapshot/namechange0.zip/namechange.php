<?php

function namechange_getmoduleinfo(){
	$info = array(
		"name"=>"Names Department",
		"author"=>"Derek0, Chris Vorndran",
		"version"=>"1.0",
		"category"=>"Village",
		"download"=>"",
		"vertxtloc"=>"",
		"settings"=>array(
			"Names Department Settings,title",
			"cost"=>"Cost `iin gems`i for a Name,int|5",
			"namechangeloc"=>"Where does the Names Department appear,location|".getsetting("villagename", LOCATION_FIELDS)
		),
		"prefs"=>array(
			"Names Department Prefs,title",
			"name"=>"What is this user's name,text|",
		)
		);
	return $info;
}
function namechange_install(){
	module_addhook("village");
	module_addhook("changesetting");
	return true;
}
function namechange_uninstall(){
	return true;
}
function namechange_dohook($hookname,$args){
	global $session;
	switch ($hookname){
		case "village":
			if ($session['user']['location'] == get_module_setting("namechangeloc")) {
				tlschema($args['schemas']['marketnav']);
		        addnav($args['marketnav']);
				tlschema();
		        addnav("Names Deparment","runmodule.php?module=namechange&op=enter");
			}
			break;
		case "changesetting":
			if ($args['setting'] == "villagename") {
				if ($args['old'] == get_module_setting("namechangeloc")) {
			        set_module_setting("namechangeloc", $args['new']);
			    }
			}
	    	break;
		}
	return $args;
}
function namechange_run(){
	global $session;
	$op = httpget('op');
	$cost = get_module_setting("cost");
	$name = $session['user']['name'];
	$namec = httppost('name');
	page_header("Names Department");

	switch ($op){
		case "enter":
			if ($session['user']['gems'] >= $cost){
				output("`qYou wander into the town hall, and spot a sign that says 'Names Department'.");
				output(" You choose to check it out, wondering if a new name would be nice.");
				output(" As you walk down the hall, you notice someone else walking back.");
				output(" You notice that he has a nice new colored name, and wonder if you could have one as good as that.");
				output(" 'You want to have a new name just like his, don't you' said a man, almost as if he could read your mind.");
				output(" Before you could answer, he says, 'follow me'. You follow him down the hall into an office that could most likely be be mistaken for a cosy living room.");
				output(" As you sit down in one of the cosy leather chairs, the man says, '`QAll new names cost `%%s `QGems`q'",$cost);
				addnav("Legal Name Options");
				addnav("Change your name","runmodule.php?module=namechange&op=name");
			}else{
				output("`QAs you wal in, you wonder how much the name costs.");
				output(" You start to look for a sign of some sorts, one telling you if a new name could fit into your budget.");
				output(" After searching around yu finally notice a sign saying, '`QAll new names cost `%%s `Qgems.'",$cost);
				output(" Dissapointed, you walk back to the door.");
			}
				break;
		case "name":
			if ($namec == ""){
				output("`qThe man looks at you and then opens a desk droor, searching for a fle.");
				output(" 'Here we go. Your name is `&%s`q. You seem to have a rather dull name. I can see why you may want a new one'",$weapon);
				output("So, what would you like your new name to be?");
				rawoutput("<form action='runmodule.php?module=namechange&op=name' method='POST'>");
                output("`^New Name:");
                rawoutput("<input id='input' name='name' value='".get_module_pref("name")."' width=5> <input type='submit' class='button' value='".translate_inline("Rename")."'>");
                rawoutput("</form>");
                output("<script language='javascript'>document.getElementById('input').focus();</script>",true);
                addnav ("", "runmodule.php?module=namechange&op=name");
			}else{
				output("`qYou shake the man's hand, smile, and hand him `%%s `qgems.",$cost);
				output(" You turn around and walk out of the town hall, smiling happily.");
				$session['user']['gems']-=$cost;
				$session['user']['name']=$namec;
			}
			break;
		}
	addnav("Leave");
	villagenav();
page_footer();
}
?>




