<?php
function confirmrs_getmoduleinfo()
{
    $info = array
    (
        "name" 			=> "Confirm Race and Specialty",
        "version" 		=> "1.11",
        "author"		=> "RPGSL",
        "category" 		=> "RPGSL",
        "download" 		=> "http://www.rpdragon.com/lotgd/confirmrs.zip",
        "vertxtloc" 	=> "http://www.rpdragon.com/",
        "description"	=> "Allows characters to change their minds when choosing race and specialty.",
        "settings" 		=> array
        (
            "Confirm Race and Specialty, title",
			"ra" 			=> "Allow characters to change their mind when choosing a race?,bool|1",
			"rat"			=> "How many times can they change their mind on race each DK?,int|1",
			"sp" 			=> "Allow characters to change their mind when choosing a specialty?,bool|1",
			"spt"			=> "How many times can they change their mind on specialty each DK?,int|1",
        ),
		"prefs"			=> array
		(
			"Confirm RS User Preferences,title",
			"timesr"			=> "How many times they changed their mind about race this DK?,int|0",
			"timess"			=> "How many times they changed their mind about specialty this DK?,int|0",
		),
	);
    return $info;
}

function confirmrs_install()
{
	if (!is_module_installed("confirmrs"))
	{
		output("Installing `bConfirm Race and Specialty`b (confirmrs.php) module by Role Play Game Story Lines (www.rpgsl.com)`n`n");
	}
	else
	{
		output("Updating `bConfirm Race and Specialty`b (confirmrs.php) module by Role Play Game Story Lines (www.rpgsl.com)`n`n");
	}
    module_addhook("setrace");
	module_addhook("set-specialty");
	module_addhook("dragonkill");
    return true;
}

function confirmrs_uninstall()
{
	output("Uninstalling `bConfirm Race and Specialty`b (confirmrs.php) module by Role Play Game Story Lines (www.rpgsl.com)`n");
	return true;
}

function confirmrs_dohook($hookname, $args)
{
    global $session;
    switch($hookname)
    {
	    case "setrace":
			if (get_module_setting('ra') && get_module_pref('timesr') < get_module_setting('rat'))
			{
				addnav("I don't want this race!", "runmodule.php?module=confirmrs&op=rmis");
			}
			break;
	    case "set-specialty":
   			if (get_module_setting('sp') && get_module_pref('timess') < get_module_setting('spt'))
			{
				addnav("I don't want this specialty!", "runmodule.php?module=confirmrs&op=smis");
			}
			break;
		case "dragonkill":
			if (get_module_pref('timesr') > 0)
			{
				set_module_pref('timesr', get_module_pref('timesr') - 1);
			}
			if (get_module_pref('timess') > 0)
			{
				set_module_pref('timess', get_module_pref('timess') - 1);
			}
    }
	return $args;
}

function confirmrs_run()
{
	global $session;
	$op = httpget("op");
	page_header("I made a mistake...");
	if ($op=="rmis")
	{
		if ($session['user']['race'] == "Arachnus")
		{
			$session['user']['charm'] *= 2;
		}
		$session['user']['race'] = "";
		set_module_pref('timesr', get_module_pref('timesr') + 1);
		redirect("newday.php");
	}
	if ($op=="smis")
	{
		$session['user']['specialty'] = "";
		set_module_pref('timess', get_module_pref('timess') + 1);
		redirect("newday.php");
	}
	page_footer();
}

?>