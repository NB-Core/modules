Confirm Race and Specialty

Version 1.11
Written by RPGSL
Download: http://rpgsl.com/lotgd/confirmrs.zip
Mirror: http://rpdragon.com/lotgd/confirmrs.zip

Game: http://rpdragon.com/


Installation

1) Copy confirmrs.php into your LotGD modules folder
2) Log in to LotGD with your admin account
3) Enter the Superuser Grotto
4) Click Manage Modules
5) Install confirmrs.php (Confirm Race and Specialty)
6) Configure settings and save
7) Activate


Questions/Comments?

alex@rpgsl.com


Visit www.rpgsl.com today for your RPG needs