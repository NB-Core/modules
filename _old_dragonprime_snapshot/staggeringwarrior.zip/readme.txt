Staggering Warrior
Version: 1.0
LotGD v.98 Forest Event
Author: Eth ethstavern(at)gmail(dot)com
Release Date: 03/03/2005

Instructions:
Unzip, drop into your Modules directory, and activate it. 
Located under Forest Specials afterwards.