<?php
/**************
Name: Staggering Warrior
Author: Eth - ethstavern(at)gmail(dot)com 
Version: 1.0
Release Date: 03-03-2005
About: Encounter a long dead warrior in the forest
	   for various results.      
Translation compatible.
*****************/

function staggeringwarrior_getmoduleinfo(){
	$info = array(
		"name"=>"Staggering Warrior",
		"version"=>"1.0",
		"author"=>"Eth",
		"category"=>"Forest Specials",
		"download"=>"http://dragonprime.net/users/Eth/staggeringwarrior.zip",
		"vertxtloc"=>"http://dragonprime.net/users/Eth/",
		"settings"=>array(
			"Forest Spook - Main,title",
			"spookchance"=>"Chance of encountering warrior?,range,0,100,5|50",
			"spookencounter"=>"Encounter once per day or dragonkill?,enum,0,Newday,1,Dragon Kill"			
		),				
		"prefs"=>array(	
			"seenspook"=>"Encountered warrior yet?,bool|0"				
		),
	);
	return $info;
}
function staggeringwarrior_install(){
	module_addhook("dragonkill");
	module_addeventhook("forest", "require_once(\"modules/staggeringwarrior.php\"); return staggeringwarrior_test();");	
	module_addhook("newday");	
	return true;
}
function staggeringwarrior_uninstall(){
	return true;
}
function staggeringwarrior_test(){
	global $session;	
	$chance = get_module_setting("spookchance","staggeringwarrior");
	if (get_module_pref("seenspook","staggeringwarrior") == 1) return 0; 
	return $chance; 
}
function staggeringwarrior_dohook($hookname,$args){
	global $session;
	switch ($hookname) {
		case "dragonkill":
		if (get_module_setting("spookencounter") == 1){	
		set_module_pref("seenspook",0);	
		}
		break;
		case "newday":
		if (get_module_setting("spookencounter") == 0){	
		set_module_pref("seenspook",0);	
		}
		break;	
	}
	return $args;
}
function staggeringwarrior_runevent($type){
	global $session;
	$op = httpget('op');
	if ($type == "forest") $from = "forest.php?";				
	$session['user']['specialinc'] = "module:staggeringwarrior";
	output("`n");	
	switch($type){
		case forest:
		if ($op=="") {
			output("`2Stopping to rest a moment under the shade of a nearby tree, you catch movement out of the corner of your eye.");
			output(" `2Turning to investigate, you see what looks like someone slowly staggering towards you through the thick underbrush.`n`n");
			output("`2The fellow seems to be having a difficult time moving, and you wonder if he is in need of your assistance.`n`n");
			addnav("Help Warrior",$from."op=help");			
			addnav("Leave Instead",$from."op=leave");
		//MOVING ON...	
		}else if ($op=="help"){
			if ($session['user']['weapon'] == "Fists"){
				output("Unclenching your fists, you move to aid the warrior.");
			}else{
				output("`2Stowing your %s`2, you move to aid the warrior.", $session['user']['weapon']);		
			}
			output(" `2However, as you draw nearer, you notice something is amiss about his appearance.`n`n");
			output("`2His clothes are old and tattered, the weapon he grips is rusted and chipped, and there's something unusual about his gait.`n`n");
			addnav("Draw Closer", $from."op=closer");
			addnav("Leave Instead",$from."op=leave");
		}else if ($op=="closer"){
			output("`2Drawing closer, you suddenly stop in your tracks.");
			output(" `2A leering skeletal face looks up to you as you stare in horror at the remains of a long dead warrior slowly moving towards you.`n`n");			
			//time for the fun part. The thing either collapses, fights you, or turns out to be someone else in disguise			
			switch (e_rand(1,10)){
				//fight
				case 1:
				case 2:
				case 3:
				case 4: 				
				output("`3Turning to run, your ankle becomes caught in the thick undergrowth of the forest.");
				output(" `3Struggling to free yourself, you realize only too late the undead horror is nearly upon you!`n`n");
				output("`2You can try to escape or fight the thing before it strikes you down.`n`n");
				addnav("Fight",$from."op=fightspook");
				//i'm going to be nice and offer players the *chance* to escape
				addnav("Try to Escape",$from."op=escape");				
				break;
				//collapse
				case 5:
				case 6:
				case 7:
				case 8:
				$rewardgold = round($session['user']['level']*35);
				output("`3Suddenly however, a shudder runs through it's body and it falls forward to the ground.");
				output(" `3It convulses slightly for a moment, then is still.`n`n");
				output(" `3Carefully you move to investigate and discover whatever fell magic or spirit reanimated it's bones has now dissipated.`n`n");
				output("`2Bending down, you decide to search the remains for any treasures it might conceal.");
				//lets give the player something...
				if (e_rand(1,2)==1){
					if (e_rand(1,4)==1){
						output(" `2Fortune favors you, as you find a small coin purse containing `^%s gold`2 and a `%glittering gem`2.`n`n", $rewardgold);	
						$session['user']['gold']+=$rewardgold;					
						$session['user']['gems']++;
					}else{
					output(" `2Luck favors you and you find a small coin purse containing `^%s gold`2.`n`n", $rewardgold);
					$session['user']['gold']+=$rewardgold;
					}
				}else{
					output("`2Sifting through the remains, you find nothing of value.`n`n");
				}
				//kill the event
				$session['user']['specialinc'] = "";
				set_module_pref("seenspook",1);
				addnav("Back to Forest","forest.php");	
				break;
				//and now something just for laughs
				case 9:
				case 10:								
				$id = $session['user']['acctid'];
				$sql = "SELECT acctid,name,sex FROM ".db_prefix("accounts")." WHERE alive=1 and acctid<>'$id' ORDER BY rand(".e_rand().") LIMIT 1";
				$result = db_query($sql);
				$row = db_fetch_assoc($result);
				$who = $row['name'];
				$gender = translate_inline($row['sex']?"her":"his");
				$gender2 = translate_inline($row['sex']?"she":"he");
				output("`3Suddenly the undead warrior collapses to the ground in a heap and something from up in the trees falls shortly after.`n`n");
				output("`3Moving closer to examine the dropped object, you discover it's a wooden pallet with a series of wires attached to it.");
				output(" `3Standing there scratching your head in confusion, `@%s `3suddenly jumps down from a tree branch with a huge grin on %s face.`n`n", $who,$gender);
				output("`2\"Got you!\" %s says, and runs off into the woods.`n`n", $gender2);
				output("`2What an odd joke to play you think, as you continue to scratch your head in confusion.`n`n");
				$session['user']['specialinc'] = "";
				addnav("Back to Forest","forest.php");
				set_module_pref("seenspook",1);				
				addnews("`3%s `2played a joke on %s `2in the forest today!", $who,$session['user']['name']);
				break;				
			}			
		}else if ($op=="leave"){	
			output("`2You decide it would be in your best interest to leave the struggling warrior behind.");	
			output(" `2There was something about him that didn't seem quite right, you decide.`n`n");			
			$session['user']['specialinc'] = "";	
		}else if ($op=="escape"){
			if (e_rand(1,3)==1){
				output("`2You manage to free your ankle and escape to the forest only a mere instant before the undead horror's sword strikes the ground where you had been.`n`n");		
				output("`2You consider yourself quite lucky today.`n`n");
				addnews("`3%s `2narrowly escaped from an `4undead horror `2in the forest today!", $session['user']['name']);
				set_module_pref("seenspook",1);
				$session['user']['turns']--;
				$session['user']['specialinc'] = "";
			}else{
				output("`2You manage to free your ankle, but not in time to avoid the chance to escape the undead fiend that now stands before you.`n`n");
				output("`2You must stand and fight now!`n`n");
				addnav("Fight",$from."op=fightspook");
			}				
		//BATTLE - BATTLE - BATTLE				
		}else if ($op=="fightspook"){
		//he's tough
		$badguy = array(
		"creaturename"=>"`3Undead Warrior",
		"creaturelevel"=>$session['user']['level'],
		"creatureweapon"=>"`6a Rusty Long Sword",
		"creatureattack"=>$session['user']['attack'],
		"creaturedefense"=>$session['user']['defense'],
		"creaturehealth"=>$session['user']['maxhitpoints'],			
		"creatureexp"=>round($session['user']['level']*23, 0),			
		"diddamage"=>0,
		"type"=>"forest");
		$session['user']['badguy']=createstring($badguy);
		$op="fight";
		httpset('op', "fight");					
		}
		if ($op=="run"){
			//I gave you the chance to escape earlier, no turning back now
			output("`3As you attempt to flee into the forest, the undead warrior blocks your path!`n");
			$op="fight";
			httpset('op', "fight");			
		}
		if ($op=="fight"){ $battle=true; }
		if ($battle){		
			include("battle.php");	
			if ($victory){
				$goldreward = $session['user']['level']*45;
				$gemreward = e_rand(1,3);
				output("`n");
				output("`3With one final blow from your %s`3, the undead warrior's bones shatter and it collapses to the ground in a dusty heap.`n`n", $session['user']['weapon']);
				output("`3Searching the remains afterwards, you discover a tattered old coin purse containing `^%s gold `3and", $goldreward);			
				if ($gemreward == 1){ output(" a `%glittering gemstone`2.`n`n", $gemreward);
				}else{ output(" `%%s gems`2.`n`n",$gemreward); }
				$session['user']['gold']+=$goldreward;
				$session['user']['gems']+=$gemreward;
				$session['user']['experience']+=$badguy['creatureexp'];				
				output("`2You've also gained `3%s experience `2from this encounter.`n`n",$badguy['creatureexp']);
				set_module_pref("seenspook",1);
				$badguy=array();
				$session['user']['badguy']="";				
				addnews("`3%s `2defeated an `3undead warrior `2in the forest today!", $session['user']['name']);
				$session['user']['specialinc'] = "";
				addnav("Back to Forest","forest.php");
			}else if ($defeat){	
				output("`n`3You let loose a pained cry as the undead warrior thrusts his sword into your chest.`n`n");
				output(" `3Collapsing to the ground, your life quickly fading away, you suddenly wish you had simply ignored the thing altogether.`n`n");
				addnews("`3%s `2was slain by an `3undead warrior `2in the forest today!", $session['user']['name']);
				$session['user']['alive']=false;
				$session['user']['hitpoints']=0;
				//I'm a nice guy, I'll let you keep some of your gold
				if ($session['user']['gold']>2){
					output("`#You've lost half of your gold!`n`n");
					$session['user']['gold']=round($session['user']['gold']*.50);				
				}else{ 
					output("`#Since you had barely any gold, you've lost little you had left!`n`n");
					$session['user']['gold']=0; 
				}
				set_module_pref("seenspook",1);
				$badguy=array();
				$session['user']['badguy']="";
				$session['user']['specialinc'] = "";
				addnav("View News","news.php");				
			}else{
				fightnav(true,true);
			}
		}		
		break;
	}
}
function staggeringwarrior_run(){	
}
?>