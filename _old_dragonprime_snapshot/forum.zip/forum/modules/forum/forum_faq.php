<?php
function forum_faq() {
	$title="Forum Help";
	$q=array("How do I use the Forum?"=>"Well, that question has quite a few answers... ","Who made all those cool icons?"=>"All thread icons were made by CortalUX, L1%s, and are released under a CCL licence. More details below.`nAll category icons were made by David Vignoni at L2%s, and are released under the CCL/Creative Commons Licence. This means that it is illegal for them to be edited or modified, and they must be redistributed in their exact format, with the same licence, or a link to it; along with recognition of the author. This notice cannot be removed. I would like to thank him for redistribution permission. The licence and terms on his website are compatible with the LotGD CCL licence.");
	$x=0;
	$q=translate_inline($q);
	tlschema("faq");
	popup_header($title);
	$c = translate_inline("Return to Contents");
	output_notl("`c<a name='top'></a><a class='colLtWhite' href='petition.php?op=faq'>%s</a><hr>`c",$c,true);
	output_notl("`&`c`b%s`b`c",translate_inline($title));
	foreach ($q as $header => $ans) {
		$x++;
		$ans=str_replace('L1%s','<a href="http://cortalux.tczhost.net/" target="_blank">http://cortalux.tczhost.net/</a>',$ans);
		$ans=str_replace('L2%s','<a href="http://www.icon-king.com/" target="_blank">http://www.icon-king.com/</a>',$ans);
		output_notl("`^%s. %s`n`@%s`n`n",$x,$header,$ans,true);
	}
	output_notl("`c<hr><a class='colLtCyan' href='#top'>%s</a>`c",translate_inline("To The Top"),true);
	output_notl("`@%s `^`i<small>%s</small>`i`@:`n<form>",translate_inline("Try out the LotGD codes here"),translate_inline("(there are a few that aren't available in many other places... look at the list below)"),true);
	require_once("modules/forum/forum_box.php");
	forum_box("faqPreview");
	rawoutput("</form>");
	output_notl("`c<hr><a class='colLtCyan' href='#top'>%s</a>`c",translate_inline("To The Top"),true);
	require_once("modules/forum/forum_taglist.php");
	forum_taglist();
	output_notl("`c<hr><a class='colLtWhite' href='petition.php?op=faq'>%s</a>`n<a class='colLtCyan' href='#top'>%s</a>`c",$c,translate_inline("To The Top"),true);
	addnav("","petition.php?op=faq");
	popup_footer();
}
?>