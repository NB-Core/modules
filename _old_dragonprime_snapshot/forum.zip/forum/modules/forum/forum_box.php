<?php
function forum_box($box="",$cols=55,$rows=5,$stuff="") {
	static $b;
	global $session;
	if(!isset($session['user']['weapon'])) {
	 	$session['user']['weapon']="";
 	}
	$wep=str_replace("'","\'",appoencode($session['user']['weapon']));
	if (!isset($b)) $b=0;
	$b++;
	rawoutput("<script language='JavaScript'>
	function boxpreview$b(t){
		var out = '<span class=\'colLtWhite\'>';
		var end = '</span>';
		var bold=0;
		var wep='$wep';
		var div=0;
		var italics=0;
		var emphasis=0;
		var align=0;
		var x=0;
		var y='';
		var z='';
		
		for (; x < t.length; x++){
			y = t.substr(x,1);
			if (y=='`'){
				if (x < t.length-1){
					z = t.substr(x+1,1);
					if (z=='0'){
						out += '</span>';
					}else if (z=='1'){
						out += '</span><span class=\'colDkBlue\'>';
					}else if (z=='2'){
						out += '</span><span class=\'colDkGreen\'>';
					}else if (z=='3'){
						out += '</span><span class=\'colDkCyan\'>';
					}else if (z=='4'){
						out += '</span><span class=\'colDkRed\'>';
					}else if (z=='5'){
						out += '</span><span class=\'colDkMagenta\'>';
					}else if (z=='6'){
						out += '</span><span class=\'colDkYellow\'>';
					}else if (z=='7'){
						out += '</span><span class=\'colDkWhite\'>';
					}else if (z=='q'){
						out += '</span><span class=\'colDkOrange\'>';
					}else if (z=='!'){
						out += '</span><span class=\'colLtBlue\'>';
					}else if (z=='@'){
						out += '</span><span class=\'colLtGreen\'>';
					}else if (z=='#'){
						out += '</span><span class=\'colLtCyan\'>';
					}else if (z=='$'){
						out += '</span><span class=\'colLtRed\'>';
					}else if (z=='%'){
						out += '</span><span class=\'colLtMagenta\'>';
					}else if (z=='^'){
						out += '</span><span class=\'colLtYellow\'>';
					}else if (z=='&'){
						out += '</span><span class=\'colLtWhite\'>';
					}else if (z=='Q'){
						out += '</span><span class=\'colLtOrange\'>';
					}else if (z==')'){
						out += '</span><span class=\'colLtBlack\'>';
					}else if (z=='w'){
						out += wep;
					}else if (z=='b'){
						if (bold==0){
							bold=1;
							out += '<b>';
						}else{
							bold=0;
							out += '</b>';
						}
					}else if (z=='H'){
						if (div==0){
							div=1;
							out += '<span class=\'navhi\'>';
						}else{
							div=0;
							out += '</span>';
						}
					}else if (z=='i'){
						if (italics==0){
							italics=1;
							out += '<i>';
						}else{
							italics=0;
							out += '</i>';
						}
					}else if (z=='t'){
						if (emphasis==0){
							emphasis=1;
							out += '<em>';
						}else{
							emphasis=0;
							out += '</em>';
						}
					}else if (z=='c'){
						if (align==0){
							align=1;
							out += '<div align=\'center\'>';
						}else{
							align=0;
							out += '</div>';
						}
					}else if (z=='<'){
						if (align==0){
							align=1;
							out += '<div style=\'float: left; clear: left;\'>';
						}else{
							align=0;
							out += '</div>';
						}
					}else if (z=='>'){
						if (align==0){
							align=1;
							out += '<div style=\'float: right; clear: right;\'>';
						}else{
							align=0;
							out += '</div>';
						}
					}else if (z=='n'){
						out += '<br/>';
					}else if (z=='`'){
						out += '&#0096;';
					} else {
						out += '&#0096;' + z;
					}
					x++;
				}
			}else if (y=='\\n') {
				out += '<br/>';
			}else if (y=='<') {
				out += '&lt;';
			}else if(y=='>'){
				out += '&gt;';
			}else{
				out += y;
			}
		}
		if (align==1){
			align=0;
			out += '</div>';
		}
		if (italics==1){
			italics=0;
			out += '</i>';
		}
		if (emphasis==1){
			emphasis=0;
			out += '</em>';
		}
		if (div==1){
			div=0;
			out += '</span>';
		}
		if (bold==1){
			bold=0;
			out += '</b>';
		}
		document.getElementById(\"boxpreview$b\").innerHTML=out+end+'<br/>';
	}
	</script>
	");
	output_notl("<textarea cols='$cols' rows='$rows' class='input' name='$box' id='$box' onKeyUp='boxpreview$b(document.getElementById(\"$box\").value);';></textarea>",true);
	rawoutput("<div border='1' id='boxpreview$b'>".$stuff."</div>",true);
}
?>