<?php
function forum_thread() {
	global $userid,$session;
	$forumid=httpget('forumid');
	$thread=httpget('thread');
	$sql="SELECT * FROM `".db_prefix("forumcat")."` WHERE catid=$forumid;";
	$result=db_query($sql);
	if (db_num_rows($result)>0) {
		$row=db_fetch_assoc($result);
		$sql="SELECT * FROM `".db_prefix("forumcat")."` WHERE catid={$row['parentid']};";
		$resul=db_query($sql);
		$other=db_fetch_assoc($resul);
		$sql="SELECT * FROM `".db_prefix("forumposts")."` WHERE id=$thread OR parent=$thread";
		$otheri=db_query($sql);
		$y=db_num_rows($otheri);
		$others=db_fetch_assoc($otheri);
		rawoutput("<table width='100%' border='0'><tr class='trhilight'><td colspan='3'>".appoencode("`c<a href='runmodule.php?module=forum&op=list' class='colLtYellow'>".translate_inline("Forum Listing")."</a> `#-> <a href='runmodule.php?module=forum&op=list&parentid={$row['parentid']}' class='colLtYellow'>{$other['catname']}</a> -> <a href='runmodule.php?module=forum&op=threadlist&parentid={$row['parentid']}&forumid=$forumid' class='colLtYellow'>{$row['catname']}</a> -> <a href='runmodule.php?module=forum&op=thread&parentid={$row['parentid']}&forumid=$forumid&thread=$thread' class='colLtYellow'>{$others['title']}</a>`c",true)."</td></tr>");
		addnav("","runmodule.php?module=forum&op=list");
		addnav("","runmodule.php?module=forum&op=list&parentid={$row['parentid']}");
		addnav("","runmodule.php?module=forum&op=threadlist&parentid={$row['parentid']}&forumid=$forumid");
		addnav("","runmodule.php?module=forum&op=thread&parentid={$row['parentid']}&forumid=$forumid&thread=$thread");
		if ($y>0) {
			$lastpost=$others['postdate'];
			$data="`^";
			require_once("modules/forum/forum_datefunctions.php");
			if ($lastpost!=="0000-00-00 00:00:00") $data.=translate_inline("Thread started at `@").forum_date($lastpost)."`^.";
			$lastpost=$others['newpostdate'];
			if ($lastpost!=="0000-00-00 00:00:00") $data.=translate_inline(" Last post at `@").forum_date($lastpost)."`^.";
			$sql="SELECT * FROM `".db_prefix("forumposts")."` WHERE parent={$others['id']}";
			$x=db_query($sql);
			$y=db_num_rows($x);
			$replies=$y;
			if ($replies==1) {
				$word=translate_inline(" `%One `^Reply.");
			} else {
				$word=str_replace("%s",$y,translate_inline(" `%%s`^ Replies."));
			}
			$data.=$word;
			$sql="SELECT name FROM `".db_prefix("accounts")."` WHERE acctid={$others['userid']} AND locked=0";
			$i=db_query($sql);
			if (db_num_rows($i)>0) {
				$ni=db_fetch_assoc($i);
			} else {
				$ni=array();
				$ni['name']=$others['author'];
			}
			$x=1;
			$others['title']=stripslashes($others['title']);
			$others['content']=stripslashes($others['content']);
			if ($others['locked']==1||$row['locked']==1||$other['locked']==1||$session['user']['loggedin']==0) {
				$word="locked";
				if ($session['user']['loggedin']==0) $word="logged out";
				$bj=" <img src='./images/forum/other/locked.png' alt='$l'/><small>".translate_inline("`^(locked)")."</small>";
			} else {
				require_once("modules/forum/forum_image.php");
				$bj=" ".forum_image("other/post.png","Reply","runmodule.php?module=forum&op=post&parentid=$thread&forumid=$forumid");
			}
			rawoutput("<table width='100%' border='0'>");
			rawoutput("<tr class='trhead'><td colspan='3'>".appoencode("`c`&`b".color_sanitize($others['title'])."`b$bj`c",true));
			rawoutput("<tr class='trhead'><td colspan='3'>".appoencode("`c`^".$data."`c",true)."</td></tr>");
			rawoutput("<tr class='".($x%2?"trlight":"trdark")."'><td width='35%'>".appoencode("`&`c{$ni['name']}",true));
			require_once("modules/forum/forum_side_show.php");
			rawoutput(appoencode(forum_side_show($others['userid'])."`c",true)."</td><td colspan='2'>".appoencode("`&".$others['content']));
			if (get_module_pref('user_signature','forum',$others['userid'])!='') {
				$sig=substr(nltoappon(get_module_pref('user_signature','forum',$others['userid'])),0,500);
				if (get_module_pref('sigBlock','forum',$others['userid'])==1) $sig="`&`c`b".translate_inline("*BLOCKED*")."`c`b";
				rawoutput("<hr width='80%'/>");
				output_notl($sig);
			}
			require_once("modules/forum/forum_nfix.php");
			forum_nfix();
			rawoutput("</td></tr>");
			while ($others=db_fetch_assoc($otheri)) {
				$sql="SELECT name FROM `".db_prefix("accounts")."` WHERE acctid={$others['userid']} AND locked=0";
				$i=db_query($sql);
				if (db_num_rows($i)>0) {
					$ni=db_fetch_assoc($i);
				} else {
					$ni=array();
					$ni['name']=$others['author'];
				}
				$others['title']=stripslashes($others['title']);
				$others['content']=stripslashes($others['content']);
				$data=translate_inline("Posted at ")."`@".forum_date($others['postdate']);
				$data.="`^.<br/>`b`7".$others['title']."`b";
				$data.=" ".forum_image("other/post.png","Reply","runmodule.php?module=forum&op=post&parentid={$others['id']}&forumid=$forumid");
				rawoutput("<tr class='trhead'><td colspan='3'>".appoencode("`c`^".$data."`^.`c",true)."</td></tr>");
				forum_nfix();
				rawoutput("<tr class='".($x%2?"trlight":"trdark")."'><td width='35%'>".appoencode("`&`c{$ni['name']}",true));
				rawoutput(appoencode(forum_side_show($others['userid'])."`c",true)."</td><td colspan='2'>".appoencode("`&".$others['content']));
				if (get_module_pref('user_signature','forum',$others['userid'])!='') {
					$sig=substr(nltoappon(get_module_pref('user_signature','forum',$others['userid'])),0,500);
					if (get_module_pref('sigBlock','forum',$others['userid'])==1) $sig="`&`c`b".translate_inline("*BLOCKED*")."`c`b";
					rawoutput("<hr width='80%'/>");
					output_notl($sig);
				}
				forum_nfix();
				rawoutput("</td></tr>");
			}
		} else {
			rawoutput("<tr class='".($x%2?"trlight":"trdark")."'><td colspan='3'>".appoencode("`&".translate_inline("That thread isn't there!"))."</td></tr>");
		}
		rawoutput("</table>");
	} else {
		output("`c`Q`bThat forum wasn't found!!!!`b`Q`c");
	}
}
?>