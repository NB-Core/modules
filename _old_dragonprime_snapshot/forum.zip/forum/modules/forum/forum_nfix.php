<?php
function forum_nfix() {
	global $nestedtags;
	foreach ($nestedtags as $tag=>$status) {
		$x=$tag;
		if ($tag=="font") $x="0";
		if ($tag=="div") $x="c";
		if ($status!==false) {
			output_notl("`$x");
		}
	}
}
?>