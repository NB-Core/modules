<?php
function forum_mysqldtime() {
	return date('Y-m-d H:i:s',time());
}

function forum_date($date){
	return date("F j, Y h:i T", strtotime($date));
}
?>