<?php
function forum_clickables($form="",$box="") {
	$tags=array("1"=>"DkBlue","2"=>"DkGreen","3"=>"DkCyan","4"=>"DkRed","5"=>"DkMagenta","6"=>"DkYellow","7"=>"DkWhite","q"=>"DkOrange","!"=>"LtBlue","@"=>"LtGreen","#"=>"LtCyan","\$"=>"LtRed","%"=>"LtMagenta","^"=>"LtYellow","&"=>"LtWhite","Q"=>"LtOrange",")"=>"LtBlack");
	output("`n`c`@-=-=Normal Tags=-=-`n");
	$click=translate_inline("Click");
	foreach ($tags as $stroke=>$class) {
		if($stroke!='1') output("`&,  ");
		rawoutput("<a class='col$class' alt='$class' href=\"javascript:addCode('`$stroke');\">$click</a> ");
	}
	output("`n`n`@-=-=Clickable Codes=-=-`n");
	$tags=array("b"=>"Bold","H"=>"Hilight","i"=>"Italics","t"=>"Emphasis","c"=>"Centre Align","<"=>"Left Align",">"=>"Right Align");
	foreach ($tags as $stroke=>$exp) {
		if($stroke!='b') output("`&,  ");
		rawoutput("<a class='colLtWhite' href=\"javascript:addCode('`$stroke');\" alt='$exp'>(".translate_inline($exp).")</a> ");
	}
	output_notl("`c");
	if (is_module_active('emoticons')&&file_exists("modules/emoticons.php")) {
		require_once("modules/emoticons.php");
		if (function_exists('emoticons_clickdisplay')) {
			rawoutput(emoticons_clickdisplay($form,$box));
		} else {
			output("`c`@-=-=Clickable Smilies=-=-`n");
			$emots=array("*frown*"=>"frown.gif","*grin*"=>"grin.gif","*biggrin*"=>"grin2.gif","*happy*"=>"happy.gif","*laugh*"=>"laugh.gif","*love*"=>"loveface.gif","*angry*"=>"mad.gif","*mad*"=>"mad2.gif","*music*"=>"musicface.gif","*order*"=>"order.gif","*purple*"=>"purpleface.gif","*red*"=>"redface.gif","*rofl*"=>"rofl.gif","*rolleyes*"=>"rolleyes.gif","*shock*"=>"shock.gif","*shocked*"=>"shocked.gif","*slimer*"=>"slimer.gif","*spineyes*"=>"spineyes.gif","*sarcastic*"=>"srcstic.gif","*tongue*"=>"tongue.gif","*tongue2*"=>"tongue2.gif","*wink*"=>"wink.gif","*wink2*"=>"wink2.gif","*wink3*"=>"wink3.gif","*confused*"=>"confused.gif","*embarassed*"=>"embarassed.gif","*rose*"=>"rose.gif","*drool*"=>"drool.gif","*sick*"=>"sick.gif","*kiss*"=>"kiss.gif","*brokeheart*"=>"brokeheart.gif","*wimper*"=>"wimper.gif","*whew*"=>"whew.gif","*cry*"=>"cry.gif","*angel*"=>"angel.gif","*nerd*"=>"nerd.gif","*stop*"=>"stop.gif","*zzz*"=>"zzz.gif","*shhh*"=>"shhh.gif","*nottalking*"=>"nottalking.gif","*party*"=>"party.gif","*yawn*"=>"yawn.gif","*doh*"=>"doh.gif","*clap*"=>"clap.gif","*lie*"=>"lie.gif","*bateyes*"=>"bateyes.gif","*pray*"=>"pray.gif","*peace*"=>"peace.gif","*nono*"=>"nono.gif","*bow*"=>"bow.gif","*groove*"=>"groove.gif","*giggle*"=>"giggle.gif","*yakyak*"=>"yakyak.gif");
			foreach ($emots as $stroke=>$pic) {
				rawoutput("<a alt='$stroke' href=\"javascript:addCode(' $stroke ');\" border='0' style='border:0;'><img border='0' style='border:0;' src='./images/$pic'></a> ");
			}
			output_notl("`c");
		}
	}
	rawoutput("<script language=\"JavaScript\" type=\"text/javascript\">\n");
	rawoutput("function addCode(textToAdd)\n");
	rawoutput("{\n");
	rawoutput("document.getElementById(\"$box\").value += textToAdd;");
	rawoutput("document.getElementById(\"$box\").focus();\n");
	rawoutput("}\n");
	rawoutput("</script>\n");
}
?>