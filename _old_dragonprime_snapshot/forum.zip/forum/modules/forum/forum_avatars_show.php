<?php
function forum_avatars_show($usid=0) {
	global $args,$b;
	$b=$args;
	$args['acctid']=$usid;
	$args=$b;
	$x=avatars_getmoduleinfo();
	if (isset($x['vertxtloc'])&&$x['vertxtloc']=="http://dragonprime.net/users/CortalUX/"&&function_exists('avatars_resizeshow')) {
		$stuff=avatars_resizeshow($args);
		$stuff="";
	} else {
		$avatar = get_module_pref("user_avatar","avatars",$args['acctid']);
		$avatar = stripslashes(preg_replace("'[\"\'\\><@?*&#; ]'","",$avatar));
		if ($avatar>"" && strpos($avatar,".gif")<1 && strpos($avatar,".GIF")<1 && strpos($avatar,".jpg")<1 && strpos($avatar,".JPG")<1 && strpos($avatar,".png")<1 && strpos($avatar,".PNG")<1){
				require_once("lib/systemmail.php");
				set_module_pref("user_avatar","","avatars",$args['acctid']);
				$subj = array("`\$Avatar deleted!`0");
				$body = array("`QThe URL of your avatar was corrupt or was no picture and has been deleted automatically. Please check the following URL and enter a new URL in your preferences:`n`\$%s",$avatar);
				systemmail($args['acctid'],$subj,$body);
				$stuff="";
		}elseif ($avatar>""){
			$maxwidth = get_module_setting("maxwidth",'avatars');
			$maxheight = get_module_setting("maxheight",'avatars');
			$pic_size = @getimagesize($avatar);
			$pic_width = $pic_size[0];
			$pic_height = $pic_size[1];
			$stuff="<table><tr><td valign='top'>";
			if ($session['user']['superuser'] & SU_EDIT_USERS) {
				$ret = httpget('ret');
				$del = translate_inline("Del");
				$conf = translate_inline("Are you sure you wish to delete this avatar?");
				$stuff.="[ <a href='runmodule.php?module=avatars&act=del&who={$args['acctid']}&ret=$ret' onClick=\"return confirm('$conf');\">$del</a> ]";
				addnav("","runmodule.php?module=avatars&act=del&who={$args['acctid']}&ret=$ret");
			}
			$stuff.="</td><td valign='top'><img src=\"$avatar\" ";
			if ($pic_width > $maxwidth) rawoutput("width=\"$maxwidth\" ");
			if ($pic_height > $maxheight) output("height=\"$maxheight\" ");
			$stuff.="alt=\"An avatar\"></td></tr></table>";
		}
	}
	return $stuff;
}
?>