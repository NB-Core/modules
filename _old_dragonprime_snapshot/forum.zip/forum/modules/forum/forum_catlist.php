<?php
function forum_catlist($parentid=false) {
	global $userid,$session;
	$sql="SELECT * FROM `".db_prefix("forumcat")."`";
	if ($parentid!==false&&is_numeric($parentid)) $sql.=" WHERE parentid=$parentid OR catid=$parentid";
	$result=db_query($sql);
	if (db_num_rows($result)>0) {
		rawoutput("<table width='100%' border='0'><tr class='trhilight'><td colspan='3'>".appoencode("`c<a href='runmodule.php?module=forum&op=list' class='colLtYellow'>".translate_inline("Forum Listing")."`c",true)."</a></td></tr>");
		addnav("","runmodule.php?module=forum&op=list");
		$array=array();
		while ($row=db_fetch_assoc($result)) {
			if ($row['iscatparent']==1) {
				$id=$row['catid'];
				$array['cats'][$id]=$row;
			} else {
				$id=$row['parentid'];
				$id2=$row['catid'];
				$array['forums'][$id][$id2]=$row;
			}
		}
		$cats=$array['cats'];
		foreach ($cats as $id => $arstuff) {
			$x=0;
			rawoutput("<tr class='trhead'><td colspan='3'>".appoencode("`&".$arstuff['catname'])."<br/>".appoencode("`i`^<small>".$arstuff['description']."</small>`i",true)."</td></tr>");
			if (isset($array['forums'][$id])) {
				$forums=$array['forums'][$id];
				foreach ($forums as $id=>$rw) {
					$x++;
					$data="<small>";
					$lastpost=$rw['lastpost'];
					require_once("modules/forum/forum_datefunctions.php");
					if ($lastpost!=="1980-01-01 00:00:00") {
						$data.="`@".translate_inline("Last Post at ")."`^".forum_date($lastpost)."`@.`n";
					} else {
						$data.=translate_inline("`QIt's a `b`\$NEW`b`Q forum!!!!")."`n";
					}
					$lastpostusid=$rw['lastpostusid'];
					if ($lastpostusid!=="0") {
						$sql="SELECT name FROM `".db_prefix("accounts")."` WHERE acctid=$lastpostusid AND locked=0";
						$i=db_query($sql);
						if (db_num_rows($i)>0) {
							$ni=db_fetch_assoc($i);
							$data.="`@".translate_inline("Last Post by ")."`^".color_sanitize($ni['name'])."`@.`n";
						}
					}
					$postid=$rw['postid'];
					if ($postid!=="0") {
						$sql="SELECT title FROM `".db_prefix("forumposts")."` WHERE id=$postid AND locked=0";
						$i=db_query($sql);
						if (db_num_rows($i)>0) {
							$ni=db_fetch_assoc($i);
							$data.="`@".translate_inline("Last Post called ")."`^".$ni['title']."`@.";
						}
					}
					$data.="</small>";
					$file="cats/enter_";
					if (strtotime($lastpost)>strtotime(get_module_pref('lastView'))) {
						$file.="unread";
					} else {
						$file.="read";
					}
					if ($rw['locked']!=0) $file.="_locked";
					$file.=".png";
					if ($rw['locked']!=0) $rw['catname'].=" `@`i<small>".translate_inline("(locked)")."</small>`i";
					require_once("modules/forum/forum_image.php");
					rawoutput("<tr class='".($x%2?"trlight":"trdark")."' align='center' valign='center'><td width='15%'>".appoencode(forum_image($file,"Enter Forum","runmodule.php?module=forum&op=threadlist&parentid={$rw['parentid']}&forumid={$rw['catid']}"),true)."</td><td style='text-align:left;'>".appoencode("`Q".$rw['catname']."`n`^`i".$rw['description']."`i",true)."</td><td>".appoencode("`@".$data,true)."</td></tr>");
					addnav("","runmodule.php?module=forum&op=threadlist&parentid={$rw['parentid']}&forumid={$rw['catid']}");
				}
			} else {
				rawoutput("<tr class='".($x%2?"trlight":"trdark")."' align='center' valign='center'><td colspan='3'>".appoencode("`@`b`c".translate_inline("This category has no forums.")."`c`b")."</td></tr>");
			}
		}
		rawoutput("</table>");
	} else {
		output("`c`Q`bNo forums were found!!!!`b`Q`c");
	}
}
?>