<?php
switch ($hookname) {
	case "faq-toc":
		$t = translate_inline("`@Frequently Asked Questions about the Forums`0");
		output_notl("&#149;<a href='runmodule.php?module=forum&op=faq'>$t</a><br/>", true);
		addnav("","runmodule.php?module=forum&op=faq");
	break;
	case "village":
		addnav($args['othernav']);
	case "superuser":
	case "footer-shades":
	case "index":
		$link=array("superuser"=>"Actions","footer-shades"=>"Places","index"=>"Game Functions");
		if ($hookname!="village") addnav($link[$hookname]);
		require_once("modules/forum/forum_addnav.php");
		forum_addnav();
	break;
	case "biostat":
		if (get_module_pref('user_pcount')==1) {
			$sql = "SELECT count(content) AS c FROM `".db_prefix("forumposts")."` WHERE userid={$args['acctid']}";
			$result = db_query($sql);
			if (db_num_rows($result)>0) {
				$row=db_fetch_assoc($result);
				output("`^Forum Postcount: `@%s`0`n",$row['c']);
			}
		}
	break;
}
?>