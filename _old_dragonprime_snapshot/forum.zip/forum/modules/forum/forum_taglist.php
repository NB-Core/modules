<?php
function forum_taglist() {
	$tags=array("0"=>"Color Tag Resetting","1"=>"Dark Blue","2"=>"Dark Green","3"=>"Dark Cyan","4"=>"Dark Red","5"=>"Dark Magenta","6"=>"Dark Yellow","7"=>"Dark White","q"=>"Dark Orange","!"=>"Light Blue","@"=>"Light Green","#"=>"Light Cyan","\$"=>"Light Red","%"=>"Light Magenta","^"=>"Light Yellow","&"=>"Light White","Q"=>"Light Orange",")"=>"Light Black","n"=>"For inserting a New Line","`"=>"For typing an ``");
	$ctags=array("b"=>"Bold","H"=>"Hilighted","i"=>"Italicized","t"=>"Emphasized","c"=>"Centre Aligned","<"=>"Left Aligned",">"=>"Right Aligned");
	rawoutput("<table border='0'><tr class='trhead'><td colspan='3'>");
	output("`&`iNormal Tags`i");
	rawoutput("</td></tr><tr class='trhead'><td>");
	output("`^Example");
	rawoutput("</td><td>");
	output("`^Combination");
	rawoutput("</td><td>");
	output("`^Name");
	rawoutput("</td></tr>");
	$p=translate_inline("Preview");
	$x=0;
	foreach ($tags as $tag=>$exp) {
		$x++;
		$exp=translate_inline($exp);
		output_notl("<tr class='".($x%2?"trlight":"trdark")."'><td>`$tag",true);
		if ($tag!="`"&&$tag!='n') output_notl($p);
		output_notl("`0</td><td>`@`b ``$tag `b</td><td>`&$exp</td></tr>",true);
	}
	rawoutput("<tr class='trhead'><td colspan='3'>");
	output_notl("`&`i%s`i`n`#<small>%s</small>",translate_inline("Close Tags"),translate_inline("these tags should normally be closed, although the forum will fix them for you"),true);
	rawoutput("</td></tr><tr class='trhead'><td>");
	output("`^Example");
	rawoutput("</td><td>");
	output("`^Combination");
	rawoutput("</td><td>");
	output("`^Name");
	rawoutput("</td></tr>");
	$p="`&".$p;
	$x=0;
	foreach ($ctags as $tag=>$exp) {
		$x++;
		$exp=translate_inline($exp);
		output_notl("<tr class='".($x%2?"trlight":"trdark")."'><td>`$tag$p`$tag</td><td>`@`b``$tag`b `i<small>%s</small>`i `b``$tag`b</td><td>`&$exp</td></tr>",translate_inline("Some Text"),true);
	}
	rawoutput("</table>");
}
?>