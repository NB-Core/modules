<?php
function forum_navs($op="list") {
	global $session;
	$forum=httpget("forumid");
	$parentid=httpget("parentid");
	addnav("Navigation");
	if ($session['user']['loggedin']==1) {
		checkday();
		if ($session['user']['alive']==1){
			villagenav();
		}else{
			addnav("S?Return to the Shades","shades.php");
		}
		addnav("Currently Online","list.php");
		if ($session['user']['clanid']>0){
			addnav("Online Clan Members","list.php?op=clan");
			if ($session['user']['alive']) {
				addnav("Clan Hall","clan.php");
			}
		}
		if ($session['user']['superuser']&~SU_DOESNT_GIVE_GROTTO)  addnav("X?`bSuperuser Grotto`b","superuser.php");
	} else {
		addnav("Login Screen","index.php");
		addnav("Currently Online","list.php");
	}
	addnav("General Actions");
	addnav("0?Forum Help","runmodule.php?module=forum&op=faq",false,true);
	addnav("1?List all Categories","runmodule.php?module=forum&op=list");
	
	addnav("Forum Options");
	if (is_numeric($parentid)&&is_numeric($forum)) {
		$sql="SELECT catname FROM `".db_prefix("forumcat")."` WHERE catid=$parentid AND locked=0";
		$i=db_query($sql);
		if (db_num_rows($i)>0) {
			$ni=db_fetch_assoc($i);
			addnav(array("2?List Forums - %s",$ni['catname']),"runmodule.php?module=forum&op=list&parentid=".$parentid);
		}
	}
	if (is_numeric($parentid)&&is_numeric($forum)) {
		$sql="SELECT catname FROM `".db_prefix("forumcat")."` WHERE catid=$forum AND locked=0";
		$i=db_query($sql);
		if (db_num_rows($i)>0) {
			$ni=db_fetch_assoc($i);
			addnav(array("3?List Threads - %s",$ni['catname']),"runmodule.php?module=forum&op=threadlist&parentid=".$parentid."&forumid=$forum");
		}
		addnav(array("4?Post a Thread - %s",$ni['catname']),"runmodule.php?module=forum&op=post&parentid=0&forumid=$forum");
	}
	$thread=httpget('thread');
	if ($op=='thread'&&is_numeric($thread)) {
		addnav("Thread Options");
		addnav("5?Refresh Thread","runmodule.php?module=forum&op=thread&parentid=".$parentid."&forumid=$forum&thread=$thread");
	}
	if (get_module_pref('canCat')==1&&$session['user']['loggedin']==1) {
		set_module_pref('canMod',1);
		$subop=httpget('subop');
		$ty=httpget('ty');
		addnav("Creation");
		addnav("7?Create a Category Parent","runmodule.php?module=forum&op=categories&subop=parent");
		addnav("8?Create a Forum","runmodule.php?module=forum&op=categories&subop=forum");
		addnav("Modification");
		addnav("9?Lock a Forum","runmodule.php?module=forum&op=categories&subop=lock&b=1");
		addnav("-?Unlock a Forum","runmodule.php?module=forum&op=categories&subop=lock&b=0");
		addnav("=?Move Forum Posts","runmodule.php?module=forum&op=categories&subop=move");
		addnav("Deletion");
		addnav("[?Delete a Forum/Category","runmodule.php?module=forum&op=categories&subop=del");
		addnav("]?Post Pruning","runmodule.php?module=forum&op=categories&subop=prune");
		rawoutput("<br/><hr width='70%'/>");
		$news=array("11/12/2005"=>array("Pruning Functions are in development.","Thread listing code will be made more reusable, and topics will be displayed in a better way showing titles.","Replies will post with the title properly.","Images will have better backgrounds.","The link will have '- NEW!' when more topics appear."),"17/12/2005"=>array("Pruning functions `bmay`b work.","The `\$`b- NEW!`b`^ link works.","The navbar at the top of the threadlist page now uses... reusable code. I'm moving it to all pages now."));
		foreach ($news as $date => $stuff) {
			if ($news!="11/12/2005") output_notl("`n`n");
			output_notl("`@`b%s - %s`b",$date,"CortalUX");
			foreach ($stuff as $item) {
				output_notl("`n`Q%s `^%s","&#149;",$item,true);
			}
		}
		output_notl("`n`n`&These messages are only shown to `)Forum Admin`& from `%modules/forum/forum_navs.php`&, and will be included for the duration of development.");
	}
	checkday();
}
?>