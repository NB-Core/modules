<?php
function forum_categories() {
	$subop=httpget('subop');
	$ty=httpget('ty');
	require_once("lib/showform.php");
	switch ($subop) {
		case "parent":
			$catname=str_replace("'","\'",httppost('catname'));
			$description=str_replace("'","\'",httppost('description'));
			if ($ty==''||empty($catname)||empty($description)) {
				if ($ty!='') output("`c`\$`bThe description and name cannot be empty.`b`c`n");
				rawoutput("<form action=\"runmodule.php?module=forum&op=categories&subop=parent&ty=1\" method=\"post\">");
				$form=array(
					"Category Creation,title",
					"catname"=>"Parent Name?,text|",
					"description"=>"Category Description?,textarea|",
				);
				$empty=array('catname'=>$catname,'description'=>$description);
				showform($form,$empty,true);
				rawoutput("<input type='submit' class='button' value='".translate_inline("Create")."'>");
				rawoutput("</form>");
				addnav("","runmodule.php?module=forum&op=categories&subop=parent&ty=1");
			} else {
				$sql = "INSERT INTO `".db_prefix("forumcat")."` ( `catname` , `lastpost` , `postid` , `lastpostusid` , `iscatparent` , `catid` , `usertype` , `locked` , `parentid` , `description` )
					VALUES (
						'$catname', NOW(), '0', '0', '1', '', '0', '0', '0', '$description'
					);";
				db_query($sql);
				output("`@That category parent was created.");
			}
		break;
		case "forum":
			$catname=httppost('catname');
			$description=httppost('description');
			$parent=httppost('parent');
			if ($ty==''||empty($catname)||empty($description)||empty($parent)||$parent=='0') {
				if ($ty!='') output("`c`\$`bThe description, parent, or name cannot be empty.`b`c`n");
				rawoutput("<form action=\"runmodule.php?module=forum&op=categories&subop=forum&ty=1\" method=\"post\">");
				$sql = "SELECT catname,catid FROM `".db_prefix("forumcat")."` WHERE iscatparent=1";
				$result = db_query($sql);
				if (db_num_rows($result)>0) {
					$string="";
					while ($row=db_fetch_assoc($result)) {
						$string.=",{$row['catid']},".str_replace(',','',$row['catname']);
					}
					$form=array(
						"Forum Creation,title",
						"catname"=>"Forum Name?,text|",
						"description"=>"Description?,textarea|",
						"parent"=>"Parent?,enumpretrans,0,".translate_inline("Choose a Parent")."$string",
					);
					$empty=array('catname'=>$catname,'description'=>$description,'parent'=>$parent);
					showform($form,$empty,true);
					rawoutput("<input type='submit' class='button' value='".translate_inline("Create")."'>");
					rawoutput("</form>");
					addnav("","runmodule.php?module=forum&op=categories&subop=forum&ty=1");
				} else {
					output("`@There are `bno`b Forum Categories.");
				}
			} else {
				$sql = "INSERT INTO `".db_prefix("forumcat")."` VALUES ('$catname', '1980-01-01 00:00:00', 0, 0, 0, 0, 0, 0, $parent, '$description');";
				db_query($sql);
				output("`@That forum was created.");
			}
		break;
		case "lock":
			$forum=httppost('forum');
			$b=httpget('b');
			if ($ty==''|empty($forum)||$forum=='0') {
				if ($ty!='') output("`c`\$`bThe forum cannot be empty.`b`c`n");
				rawoutput("<form action=\"runmodule.php?module=forum&op=categories&subop=lock&ty=1&b=$b\" method=\"post\">");
				$sql = "SELECT catname,catid FROM `".db_prefix("forumcat")."` WHERE locked<>$b AND iscatparent=0";
				$result = db_query($sql);
				if (db_num_rows($result)>0) {
					$string="";
					while ($row=db_fetch_assoc($result)) {
						$string.=",{$row['catid']},".str_replace(',','',$row['catname']);
					}
					if ($b==1) {
						$form=array("Forum Locking,title");
						$word=translate_inline("Lock");
					} else {
						$form=array("Forum Unlocking,title");
						$word=translate_inline("Unlock");
					}
					$form['forum']=translate_inline("Forum Name?").",enumpretrans,0,".translate_inline("Choose a Forum")."$string";
					$empty=array('forum'=>$forum);
					showform($form,$empty,true);
					rawoutput("<input type='submit' class='button' value='".$word."'>");
					rawoutput("</form>");
					addnav("","runmodule.php?module=forum&op=categories&subop=lock&ty=1&b=$b");
				} elseif ($b==1) {
					output("`@There are `bno`b unlocked forums.");
				} else {
					output("`@There are `bno`b locked forums.");
				}
			} else {
				$y=0;
				if ($b==1) $y=1;
				$sql = "UPDATE `".db_prefix("forumcat")."` SET locked=$y WHERE catid=$forum;";
				db_query($sql);
				if ($b==1) {
					output("`@That forum was locked.");
				} else {
					output("`@That forum was unlocked.");
				}
			}
		break;
		case "move":
			$forum=httppost('forum');
			$moveto=httppost('moveto');
			if ($ty==''|empty($forum)||$forum=='0'||$moveto=='0'||empty($moveto)||$forum==$moveto) {
				if ($ty!='') output("`c`\$`bNeither forum can be deselected, you cannot move posts to the same forum.`b`c`n");
				rawoutput("<form action=\"runmodule.php?module=forum&op=categories&subop=move&ty=1\" method=\"post\">");
				$sql = "SELECT catname,catid FROM `".db_prefix("forumcat")."` WHERE iscatparent=0";
				$result = db_query($sql);
				if (db_num_rows($result)>0) {
					$string="";
					while ($row=db_fetch_assoc($result)) {
						$string.=",{$row['catid']},".str_replace(',','',$row['catname']);
					}
					$form=array(translate_inline("Post Moving from Forum to Forum").",title",
						"forum"=>translate_inline("Move Posts From?").",enumpretrans,0,".translate_inline("Choose a Forum")."$string",
						"moveto"=>translate_inline("To?").",enumpretrans,0,".translate_inline("Choose a Forum")."$string",
					);
					$empty=array('forum'=>$forum,'moveto'=>$moveto);
					showform($form,$empty,true);
					rawoutput("<input type='submit' class='button' value='".translate_inline("Move")."'>");
					rawoutput("</form>");
					addnav("","runmodule.php?module=forum&op=categories&subop=move&ty=1");
				}
			} else {
				$sql = "UPDATE `".db_prefix("forumposts")."` SET forumcat=$moveto WHERE forumcat=$forum;";
				db_query($sql);
				output("`@Those forum posts were moved.");
			}
		break;
		case "del":
			$forum=httppost('forum');
			if ($ty==''|empty($forum)||$forum=='0') {
				if ($ty!='') output("`c`\$`bYou must choose a forum or category!`b`c`n");
				rawoutput("<form action=\"runmodule.php?module=forum&op=categories&subop=del&ty=1\" method=\"post\">");
				$sql = "SELECT catname,catid,iscatparent FROM `".db_prefix("forumcat")."`";
				$result = db_query($sql);
				if (db_num_rows($result)>0) {
					$string="";
					while ($row=db_fetch_assoc($result)) {
						if ($row['iscatparent']==0) {
							$row['catname']="- ".$row['catname'];
						} else {
							$row['catname']=$row['catname']." >>";
						}
						$string.=",{$row['catid']},".str_replace(',','',$row['catname']);
					}
					$form=array(translate_inline("Forum/Category Deletion").",title",
						"forum"=>translate_inline("Which forum?").",enumpretrans,0,".translate_inline("Choose a Forum")."$string",
					);
					$empty=array('forum'=>$forum);
					showform($form,$empty,true);
					rawoutput("<input type='submit' class='button' value='".translate_inline("Delete")."'>");
					rawoutput("</form>");
					addnav("","runmodule.php?module=forum&op=categories&subop=del&ty=1");
				}
			} else {
				$cats=array();
				$sql = "SELECT * FROM `".db_prefix("forumcat")."` WHERE catid=$forum OR parentid=$forum;";
				$x=db_query($sql);
				while ($y=db_fetch_assoc($x)) {
					$forum=$y['catid'];
					$sql = "DELETE FROM `".db_prefix("forumposts")."` WHERE forumcat=$forum;";
					db_query($sql);
					$sql = "DELETE FROM `".db_prefix("forumcat")."` WHERE catid=$forum;";
					db_query($sql);
				}
				output("`@That forum/category was erased. All posts within it have been erased. Any subcategories within it have been erased.");
			}
		break;
		case "prune":
			$forum=httppost('forum');
			$range=httppost('range');
			$postsfrom=httppost('postsfrom');
			if ($ty==''|empty($forum)||$forum=='0') {
				if ($ty!='') output("`c`\$`bYou must choose a forum or category!`b`c`n");
				rawoutput("<form action=\"runmodule.php?module=forum&op=categories&subop=prune&ty=1\" method=\"post\">");
				$sql = "SELECT catname,catid FROM `".db_prefix("forumcat")."` WHERE iscatparent=0";
				$result = db_query($sql);
				if (db_num_rows($result)>0) {
					$string="";
					while ($row=db_fetch_assoc($result)) {
						$string.=",{$row['catid']},".str_replace(',','',$row['catname']);
					}
					$form=array("Forum Selection,title",
						"forum"=>translate_inline("Which forum?").",enumpretrans,0,".translate_inline("Choose a Forum").",@A,".translate_inline("All Forums")."$string",
						"note"=>translate_inline("(choose a forum- or select 'ALL' above)").",note",
						"Post Timing,title",
						"postsfrom"=>"Amount...,range,1,30,2|30",
						"range"=>"Units...,enum,3600,Hours,86400,Days,604800,Weeks,1209600,Fortnights,259200,Months (30 days)",
						"note2"=>"(choose an amount... IE: 4- and a set of units... IE: Hours. Sending this would make all posts older than four hours get erased.),note",
					);
					$empty=array('forum'=>$forum,'note'=>'','range'=>$range,'postsfrom'=>$postsfrom,'note2'=>'');
					showform($form,$empty,true);
					rawoutput("<input type='submit' class='button' value='".translate_inline("Prune")."'>");
					rawoutput("</form>");
					addnav("","runmodule.php?module=forum&op=categories&subop=prune&ty=1");
				}
			} else {
				$string="";
				if ($forum!="@A") $string=" AND forumcat=$forum";
				$time=$range*$postsfrom;
				$time=time()-$time;
				$time=date('Y-m-d H:i:s',$time);
				$sql = "SELECT id FROM `".db_prefix("forumposts")."` WHERE newpostdate<'$time'$string";
				$x=db_query($sql);
				while ($y=db_fetch_assoc($x)) {
					$id=$y['id'];
					$sql = "DELETE FROM `".db_prefix("forumposts")."` WHERE id=$id OR parent=$id;";
					db_query($sql);
				}
				output("`@Pruning operation completed. All posts `\$INACTIVE`@ from `^%s`@ or before have been erased within the forums you selected.",$time);
			}
		break;
		case "delpost":
			$forum=httpget('forum');
			$id=httpget('post');
			$sql = "DELETE FROM `".db_prefix("forumposts")."` WHERE id=$id;";
			output("`@Post erased.");
			if (httpget('parent')=="yes") {
				$sql.=" OR parent=$id;";
				output("`n`^All posts under that were also deleted.");
			}
			db_query($sql);
		break;
		default:
			output("`@Nothing here...");
		break;
	}
}
?>