<?php
global $session;
if (!is_module_active('forum')){
	output("`n`Q`b`cInstalling Forum Module.`c`b`n");
}else{
	output("`n`Q`b`cUpdating Forum Module.`c`b`n");
}
// table creation
if (!db_table_exists(db_prefix("forumcat"))){
	$sql = "CREATE TABLE `".db_prefix("forumcat")."` (
	  `catname` varchar(255) NOT NULL default 'General',
	  `lastpost` datetime NOT NULL default '0000-00-00 00:00:00',
	  `postid` int(5) NOT NULL default '0',
	  `lastpostusid` int(11) NOT NULL default '0',
	  `iscatparent` int(1) NOT NULL default '0',
	  `catid` int(11) NOT NULL auto_increment,
	  `usertype` int(2) NOT NULL default '0',
	  `locked` int(1) NOT NULL default '0',
	  `parentid` int(3) NOT NULL default '0',
	  `description` text NOT NULL,
	  PRIMARY KEY  (`catid`)
	) TYPE=MyISAM COMMENT='This holds the category info for the LotGD forum.' AUTO_INCREMENT=1 ;";
	db_query($sql);
	output("`n`Q`b`cCreating Category Table.`c`b`n");
}
// table creation
if (!db_table_exists(db_prefix("forumposts"))){
	$sql = "CREATE TABLE `".db_prefix("forumposts")."` (
	  `id` int(11) NOT NULL auto_increment,
	  `postdate` datetime NOT NULL default '0000-00-00 00:00:00',
	  `newpostdate` datetime NOT NULL default '0000-00-00 00:00:00',
	  `author` text NOT NULL,
	  `parent` int(11) NOT NULL default '0',
	  `userid` int(11) NOT NULL default '0',
	  `title` varchar(100) NOT NULL default '',
	  `content` text NOT NULL,
	  `locked` tinyint(1) NOT NULL default '0',
	  `forumcat` int(5) NOT NULL default '2',
	  PRIMARY KEY  (`id`)
	) TYPE=MyISAM AUTO_INCREMENT=1 ;";
	db_query($sql);
	output("`n`Q`b`cCreating Posts Table.`c`b`n");
}
// db upgrading
if (db_table_exists(db_prefix("logdforum"))){
	$sql="INSERT INTO `".db_prefix("forumcat")."` VALUES ('General', '0000-00-00 00:00:00', 0, 0, 1, 1, 0, 0, 0, 'This is for anything...');";
	db_query($sql);
	$sql="INSERT INTO `".db_prefix("forumcat")."` VALUES ('Old Threads', '0000-00-00 00:00:00', 0, 0, 0, 2, 0, 1, 1, 'All threads from your old forum are here.');";
	db_query($sql);
	$sql="INSERT INTO `".db_prefix("forumcat")."` VALUES ('New Threads', '0000-00-00 00:00:00', 0, 0, 0, 3, 0, 0, 1, 'New threads can go in here!');";
	db_query($sql);
	output("`n`Q`b`cMoving Old Posts to the new Table.`c`b`n");
	$sql="SELECT * FROM `".db_prefix("logdforum")."`;";
	$result=db_query($sql);
	while($row=db_fetch_assoc($result)) {
		$sql = "INSERT INTO `".db_prefix("forumposts")."` VALUES ({$row['id']}, '{$row['postdate']}', '{$row['newpostdate']}', '{$row['author']}', 0, {$row['userid']}, '".str_replace("*apost*","\'",$row['title'])."', '".str_replace("*apost*","\'",$row['content'])."', 0, 2);";
		db_query($sql);
	}
	$sql="DROP TABLE `".db_prefix("logdforum")."`;";
	db_query($sql);
	output("`n`Q`b`cDeleting the old table.`c`b`n");
}
if ($session['user']['superuser']&SU_MANAGE_MODULES) {
	output("`c`n`n`#`bDON'T FORGET TO SET PREFERENCES IN THE GROTTO FOR EVERY MODERATOR, AND CATEGORY CREATOR!`b`c");
	set_module_pref('canCat',1);
	output("`n`c`\$Your permissions have been set automatically.`c");
}
module_addhook("superuser");
module_addhook("faq-toc");
module_addhook("village");
module_addhook("footer-shades");
module_addhook("index");
module_addhook("biostat");
?>