<?php
page_header("Oops!");
output("`@You shouldn't be on this page.");
addnav("Navigation");
if ($session['user']['loggedin']) {
	if ($session['user']['alive']==1){
		villagenav();
	}else{
		addnav("S?Return to the Shades","shades.php");
	}
} else {
	addnav("Login Screen","index.php");
	addnav("Currently Online","list.php");
}
page_footer();
die();
?>