<?php
function forum_threadlist() {
	global $userid,$session;
	require_once("modules/forum/forum_image.php");
	$forumid=httpget('forumid');
	$parentid=httpget('parentid');
	$sql="SELECT * FROM `".db_prefix("forumcat")."` WHERE catid=$forumid;";
	$result=db_query($sql);
	if (db_num_rows($result)>0) {
		$row=db_fetch_assoc($result);
		$sql="SELECT locked FROM `".db_prefix("forumcat")."` WHERE catid=$forumid;";
		$result=db_query($sql);
		$other=db_fetch_assoc($result);
		if ($other['locked']==1||$session['user']['loggedin']==0||$session['user']['dragonkills']<get_module_setting('minPost')) {
			if (get_module_pref('user_imageuse')==1||$session['user']['loggedin']==0) {
				if ($session['user']['loggedin']==0) {
					$l=translate_inline("you are not logged in");
				} elseif ($session['user']['dragonkills']<get_module_setting('minPost')) {
					$l=translate_inline("you need at least %s dragonkills to post");
					$l=str_replace('%s',get_module_setting('minPost'),$l);
				} else {
					$l=translate_inline("locked");
				}
				$string="<img src='./images/forum/other/locked.png' alt='$l'/>";
			} else {
				if ($other['locked']==1) {
					$string=appoencode("`^<small>`i".translate_inline("(this forum is locked)")."`i</small>",true);
				} else {
					$l=translate_inline("you need at least %s dragonkills to post");
					$l=str_replace('%s',get_module_setting('minPost'),$l);
					$string=appoencode("`^<small>`i".$l."`i</small>",true);
				}
			}
		} else {
			$string = appoencode(forum_image("other/post.png","Post a Thread","runmodule.php?module=forum&op=post&parentid=0&forumid=$forumid"),true);
		}
		$sql="SELECT * FROM `".db_prefix("forumcat")."` WHERE catid=$parentid;";
		$result=db_query($sql);
		$other=db_fetch_assoc($result);
		require_once("modules/forum/forum_navbar.php");
		forum_navbar();
		rawoutput("<table width='100%' border='0'><tr class='trhead' valign='center'><td colspan='2'>".appoencode("`b`&{$row['catname']}`b",true)."</td><td align='center' width='10%'>$string</td></tr>");
		addnav("","runmodule.php?module=forum&op=list");
		addnav("","runmodule.php?module=forum&op=list&parentid=$parentid");
		addnav("","runmodule.php?module=forum&op=threadlist&parentid=$parentid&forumid=$forumid");
		$sql="SELECT * FROM `".db_prefix("forumposts")."` WHERE forumcat=$forumid AND parent=0";
		$otheri=db_query($sql);
		$x=0;
		$c=0;
		if (db_num_rows($otheri)>0) {
			while ($others=db_fetch_assoc($otheri)) {
				$c++;
				$lastpostusid=$others['userid'];
				$data="<small>`@";
				$lastpost=$others['postdate'];
				if ($session['user']['loggedin']&&get_module_pref("canMod")) $others['title'] .= appoencode(forum_image("other/delete.png"," Delete this Thread","runmodule.php?module=forum&op=categories&subop=delpost&post={$others['id']}&forumid=$forumid"),true);
				require_once("modules/forum/forum_datefunctions.php");
				if ($lastpostusid!==0&&is_numeric($lastpostusid)) {
					$sql="SELECT name FROM `".db_prefix("accounts")."` WHERE acctid=$lastpostusid AND locked=0";
					$i=db_query($sql);
					if (db_num_rows($i)>0) {
						$ni=db_fetch_assoc($i);
						$data.=translate_inline("`@Thread started by `^").color_sanitize($ni['name'])."`n";
					}
				}
				$sql="SELECT * FROM `".db_prefix("forumposts")."` WHERE parent={$others['id']}";
				$x=db_query($sql);
				$y=db_num_rows($x);
				$rep=$y;
				$others['title'].="`n<small>".str_replace("%s",$rep,translate_inline("`^Replies: `&(`@%s`&)"));
				if ($rep>0) {
					while ($y>0) {
						$y--;
						$r=db_fetch_assoc($x);
					}
					$sql="SELECT name FROM `".db_prefix("accounts")."` WHERE acctid={$r['userid']} AND locked=0";
					$i=db_query($sql);
					if (db_num_rows($i)>0) {
						$ni=db_fetch_assoc($i);
						$others['title'].="`n".translate_inline("`@Last reply by `^").color_sanitize($ni['name']);
					}
					if ($lastpost!=="0000-00-00 00:00:00") $others['title'].="`n".translate_inline("`@Last post at `^").forum_date($lastpost);
				}
				$lastpost=$others['newpostdate'];
				if ($lastpost!=="0000-00-00 00:00:00") $others['title'].="`n".translate_inline("`@Thread started at `^").forum_date($lastpost);
				$others['title'].="</small>";
				$data.="</small>";
				$file="threads/thread_";
				if ($lastpost>get_module_pref('lastView')) {
					$file.="unread";
				} else {
					$file.="read";
				}
				if ($others['locked']!=0) $file.="_locked";
				$file.=".png";
				if ($others['locked']!=0) $others['title'].=" `@`i<small>".translate_inline("(locked)")."</small>`i";
				rawoutput("<tr class='".($x%2?"trlight":"trdark")."' align='center' valign='center'><td width='10%'>".appoencode(forum_image($file,"View Thread","runmodule.php?module=forum&op=thread&parentid=$parentid&forumid=$forumid&thread={$others['id']}"),true)."</td><td width='60%' style='text-align:left;'>".appoencode("`Q".$others['title'],true)."</td><td>".appoencode("`@".$data,true)."</td></tr>");
			}
		}
		if ($c<=0) {
			rawoutput("<tr class='".($x%2?"trlight":"trdark")."'><td colspan='3'>".appoencode("`&".translate_inline("There are no threads!"))."</td></tr>");
		}
		rawoutput("</table>");
	} else {
		output("`c`Q`bThat forum wasn't found!!!!`b`Q`c");
	}
}
?>