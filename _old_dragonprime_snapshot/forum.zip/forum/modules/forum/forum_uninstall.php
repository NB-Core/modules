<?php
output("`n`Q`b`cUninstalling Forum Module.`c`b`n");
if (db_table_exists(db_prefix("forumposts"))){
	$sql = "DROP TABLE `".db_prefix("forumposts")."`";
	db_query($sql);
}
if (db_table_exists(db_prefix("forumcat"))){
	$sql = "DROP TABLE `".db_prefix("forumcat")."`";
	db_query($sql);
}
?>