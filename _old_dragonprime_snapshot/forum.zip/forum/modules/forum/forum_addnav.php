<?php
function forum_addnav() {
	global $session;
	if ($session['user']['loggedin']) {
		if ($session['user']['specialmisc']=="forum"||get_module_pref('lastView')=="") {
			require_once("modules/forum/forum_datefunctions.php");
			debug("User has just browsed the forum. Setting the last visit to ".forum_mysqldtime()." and resetting the specialmisc.");
			set_module_pref('lastView',forum_mysqldtime());
			$session['user']['specialmisc']="";
		}
		$count=db_query("SELECT count(id) AS c FROM `".db_prefix("forumposts")."` WHERE newpostdate>'".get_module_pref('lastView')."';");
		$res=db_fetch_assoc($count);
		$count=$res['c'];
	} else {
		$count=0;
	}
	$text="";
	if ($count>0) $text=translate_inline("`\$ - NEW!");
	if (get_module_pref('canSee')==1&&$session['user']['loggedin']||get_module_setting('allowBrowse')&&!$session['user']['loggedin']) addnav(array("[?`2`bLotGD Forum%s`b",$text),"runmodule.php?module=forum&op=list");
	// some of the formatting of the text from the above line was borrowed from Lonnyl's code, to look the same
}
?>