<?php
function forum_navbar() {
	global $session;
	rawoutput("<table width='100%' border='0'><tr class='trhilight'><td colspan='3' style='text-align:center;'>");
	output_notl("<a href='runmodule.php?module=forum&op=list' class='colLtYellow'>".translate_inline("Forum Listing")."</a>",true);
	addnav("","runmodule.php?module=forum&op=list");
	if (httpget('parentid')!='') {
		$sql="SELECT catname FROM `".db_prefix("forumcat")."` WHERE catid=".httpget('parentid')." AND iscatparent='1' LIMIT 1;";
		$result=db_query($sql);
		$other=db_fetch_assoc($result);
		output_notl("`#-> <a href='runmodule.php?module=forum&op=list&parentid=".httpget('parentid')."' class='colLtYellow'>{$other['catname']}</a>",true);
		addnav("","runmodule.php?module=forum&op=list&parentid=".httpget('parentid'));
	}
	if (httpget('forumid')!='') {
		$sql="SELECT catname FROM `".db_prefix("forumcat")."` WHERE catid=".httpget('forumid')." AND iscatparent='0' LIMIT 1;";
		$result=db_query($sql);
		$other=db_fetch_assoc($result);
		output_notl("`#-> <a href='runmodule.php?module=forum&op=list&parentid=".httpget('parentid')."&forumid=".httpget('forumid')."' class='colLtYellow'>{$other['catname']}</a>",true);
		addnav("","runmodule.php?module=forum&op=threadlist&parentid=".httpget('parentid')."&forumid=".httpget('forumid'));
	}
	if (httpget('thread')!='') {
		$sql="SELECT title FROM `".db_prefix("forumposts")."` WHERE parent=0 AND id=".httpget('thread')." LIMIT 1;";
		$result=db_query($sql);
		$other=db_fetch_assoc($result);
		output_notl("`#-> <a href='runmodule.php?module=forum&op=list&parentid=".httpget('parentid')."&forumid=".httpget('forumid')."&thread=".httpget('thread')."' class='colLtYellow'>{$other['title']}</a>",true);
		addnav("","runmodule.php?module=forum&op=thread&parentid=".httpget('parentid')."&forumid=".httpget('forumid')."&thread=".httpget('thread'));
	}
	rawoutput("</tr></table>");
}
?>