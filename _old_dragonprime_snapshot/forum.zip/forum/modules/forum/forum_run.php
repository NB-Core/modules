<?php
	global $session;
	if (!db_table_exists(db_prefix("forumcat"))||!db_table_exists(db_prefix("forumposts"))){
		page_header("Oops!");
		output("`@One of the forum database tables is missing.");
		villagenav();
		page_footer();
		die();
	}
	$session['user']['specialmisc']="forum";
	$op=httpget('op');
	if (get_module_setting('allowBrowse')==0&&$session['user']['loggedin']==0||get_module_setting('allowBrowse')==1&&$session['user']['loggedin']==0&&$op=='post') $op='Uh oh!!!';
	switch ($op) {
		case "faq":
			popup_header("Forum - FaQ");
			require_once("modules/forum/forum_faq.php");
			forum_faq();
			popup_footer();
			die();
		break;
		case "list":
			page_header("Forum - Listing");
			$parentid=httpget('parentid');
			if ($parentid=='') $parentid=false;
			require_once("modules/forum/forum_catlist.php");
			forum_catlist($parentid);
		break;
		case "threadlist":
			page_header("Forum - Listing");
			require_once("modules/forum/forum_threadlist.php");
			forum_threadlist();
		break;
		case "post":
			page_header("Forum - Posting");
			require_once("modules/forum/forum_post.php");
			forum_post();
		break;
		case "thread":
			page_header("Forum - Thread View");
			require_once("modules/forum/forum_thread.php");
			forum_thread();
		break;
		case "categories":
			page_header("Forum - Category Editing");
			require_once("modules/forum/forum_categories.php");
			forum_categories();
		break;
		default:
			require_once("modules/forum/forum_error.php");
		break;
	}
	require_once("modules/forum/forum_navs.php");
	forum_navs($op);
	page_footer();
?>