<?php
function forum_side_show($usid=0) {
	$str="<small>";
	if ($usid!=0) {
		if (get_module_pref('user_avatars')&&file_exists("modules/avatars.php")) {
			$str.="`n";
			require_once("modules/avatars.php");
			require_once("modules/forum/forum_avatars_show.php");
			$str.=forum_avatars_show($usid);
		}
		$sql = "SELECT count(content) AS c FROM `".db_prefix("forumposts")."` WHERE userid=$usid";
		$result = db_query($sql);
		if (db_num_rows($result)>0) {
			$row = db_fetch_assoc($result);
			$str.="`&".htmlentities(translate_inline("Post Count: ")."`^`i".$row['c'])."`i";
		}
		if (get_module_pref('user_tag','forum',$usid)!='') {
			$tag=htmlentities(color_sanitize(get_module_pref('user_tag','forum',$usid)));
			if (get_module_pref('tagBlock','forum',$usid)==1) $tag=htmlentities(color_sanitize(translate_inline("*BLOCKED*")));
			$tag=substr($tag,0,60);
			$str.="`n`&".htmlentities(translate_inline("Tag: "))."`^`i".$tag."`i";
		}
	}
	$str.="</small>";
	return $str;
}
?>