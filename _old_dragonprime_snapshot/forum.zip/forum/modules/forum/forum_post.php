<?php
function forum_post() {
	global $session;
	$parentid=httpget('parentid');
	$forumid=httpget('forumid');
	$ty=httpget('ty');
	$title=httppost('title');
	if ($title==""&&$parentid!=0) {
		$sql = "SELECT title FROM `".db_prefix("forumposts")."` WHERE id='$parentid';";
		$res=db_query($sql);
		$row=db_fetch_assoc($res);
		$rep=translate_inline("RE: %s");
		$rep=explode(" ",$rep);
		$rep=str_replace("%s","",$rep[0]);// the things I do for translation compat...
		if (strpos($title, $rep)===false) {
			$rep=translate_inline("RE: %s");
			$title=str_replace("%s",$row['title'],$rep);
		}
	}
	$sql="SELECT parent FROM `".db_prefix("forumposts")."` WHERE id='$parentid';";
	$res=db_query($sql);
	$row=db_fetch_assoc($res);
	if ($row['parent']!=0) $parentid=$row['parent'];
	$post=httppost('post');
	if ($ty==''||empty($title)||empty($post)) {
		if ($ty!='') output("`\$`b`cThe title, and post must both contain something.`c`b`n");
		rawoutput("<form name='postf' id='postf' action='runmodule.php?module=forum&op=post&parentid=$parentid&forumid=$forumid&ty=2' method='post'>");
		output_notl("`^`b%s`b`@ <input size='58' name='title' value='$title'>`n",translate_inline("Title:"),true);
		output("`^`bPost:`b`n");
		require_once("modules/forum/forum_box.php");
		forum_box("post",55,5,$post);
		$s=translate_inline("Post");
		rawoutput("<input class='button' type='submit' value='$s'></form>");
		rawoutput("<div align='center' style='align:center;'><br/><script language=\"JavaScript\">\nfunction forumShowAndHide(theId)\n{\n   var el = document.getElementById(theId)\n\n   if (el.style.display==\"none\")\n   {\n      el.style.display=\"block\"; //show element\n   }\n   else\n   {\n      el.style.display=\"none\"; //hide element\n   }\n}\n</script>");
		if (get_module_pref('user_click')==1) {
			rawoutput("<span class='colLtYellow'>[<a href=\"javascript:forumShowAndHide('clickables');\" class='colLtGreen'>".translate_inline("Show/Hide Clickables")."</a>]</span>");
			rawoutput("<div id='clickables' style=\"display:none;\">");
			require_once("modules/forum/forum_clickables.php");
			forum_clickables("postf","post");
			rawoutput("</div>");
		}
		rawoutput("<center><span class='colLtYellow'>[<a href=\"javascript:forumShowAndHide('comblist');\" class='colLtGreen'>".translate_inline("Show/Hide Code List")."</a>]</span></center>");
		rawoutput("<div id='comblist' style=\"display:none;\">");
		require_once("modules/forum/forum_taglist.php");
		forum_taglist();
		rawoutput("</div></div>");
	} else {
		$post=addslashes($post);
		$title=addslashes($title);
		$name=addslashes($session['user']['name']);
		require_once("modules/forum/forum_datefunctions.php");
		$sql = "INSERT INTO `".db_prefix("forumposts")."` SET content='$post',title='$title',author='$name',userid={$session['user']['acctid']},forumcat=$forumid,postdate='".forum_mysqldtime()."',parent=$parentid;";
		$res=db_query($sql);
		$sql = "UPDATE `".db_prefix("forumposts")."` SET newpostdate='".forum_mysqldtime()."';";
		$res=db_query($sql);
		$sql = "SELECT id FROM `".db_prefix("forumposts")."` WHERE content='$post' AND title='$title' AND author='$name' AND userid={$session['user']['acctid']} AND forumcat=$forumid AND parent=$parentid;";
		$res=db_query($sql);
		$row=db_fetch_assoc($res);
		$sql = "UPDATE `".db_prefix("forumcat")."` SET lastpost=NOW(),lastpostusid={$session['user']['acctid']}";
		if ($row['id']!="") {
			$sql.=",postid={$row['id']}";
		}
		$sql.=" WHERE catid=$forumid;";
		$res=db_query($sql);
		$sql="SELECT parentid FROM `".db_prefix("forumcat")."` WHERE catid='$forumid';";
		$res=db_query($sql);
		$row=db_fetch_assoc($res);
		httpset('parentid',$row['parentid'],true);
		output("`@`b`cPost success.`c`b");
		require_once("modules/forum/forum_threadlist.php");
		forum_threadlist();
	}
}
?>