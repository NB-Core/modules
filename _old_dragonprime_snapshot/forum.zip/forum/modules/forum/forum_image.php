<?php
function forum_image($file="",$text="",$page="") {
	$text=translate_inline($text);
	if (get_module_pref('user_imageuse')==1) {
		$str="<a style='border:0;' href='$page'><img border='0' style='border:0;' src='./images/forum/$file' alt='$text'/></a>";
	} else {
		$str="`&[<a href='$page' class='colLtYellow'>".htmlentities($text)."</a>`&]";
	}
	addnav("",$page);
	return $str;
}
?>