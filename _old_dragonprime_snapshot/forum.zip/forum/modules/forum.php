<?php
require_once("lib/http.php");
require_once("lib/sanitize.php");
require_once("lib/nltoappon.php");

/*if (file_exists('./usertype.php')) {
	include_once('./usertype.php');
	$userid=usertype_level();
} else {*/
	$userid=0;
//}
function forum_getmoduleinfo(){
		$info = array(
		"name"=>"LotGD Forum",
		"version"=>"2.000000000.2",
		"pshiftstuff"=>true,
		"override_forced_nav"=>true,
		"allowanonymous"=>true,
		"author"=>"<a href='http://cortalux.tczhost.net' class='colLtGreen'>CortalUX</a>`#, based on a concept by `&Lonnyl",
		"category"=>"General",
		"download"=>"http://dragonprime.net/users/CortalUX/forum.zip",
		"vertxtloc"=>"http://dragonprime.net/users/CortalUX/",
		"settings"=>array(
			"Forum - Settings,title",
			"allowBrowse"=>"Allow offline users to browse the forums?,bool|1",
			"minPost"=>"Minimum number of DKs needed to post?,int|0",
			"(0 for no min number),note",
			"Forum - Categories,title",
			"Categories must be created from within the forum.,note",
		),
		"prefs"=>array(
			"Forum,title",
			"canCat"=>"Can this user create/edit categories and forums?,bool|0",
			"canSee"=>"Can this user enter the forum/post in the forum?,bool|1",
			"canMod"=>"Can this user moderate posts?,bool|0",
			"sigBlock"=>"Is this user's signature blocked?,bool|0",
			"tagBlock"=>"Is this user's tag-line blocked?,bool|0",
			"lastView"=>"Last thread view?,viewonly|",
			"user_imageuse"=>"Use images?,bool|1",
			"user_click"=>"Use clickables?,bool|1",
			"user_avatars"=>"Show avatars in the forum?,bool|1",
			"user_pcount"=>"Show post-counts in bios?,bool|1",
			"user_tag"=>"Forum tag-line `i(60 chars max)`i?,text|",
			"user_signature"=>"Forum signature `i(500 chars max)`i?,textarea|",
		),
	);
	return $info;
}

function forum_install(){
	require_once("modules/forum/forum_install.php");
	return true;
}

function forum_uninstall(){
	require_once("modules/forum/forum_uninstall.php");
	return true;
}

function forum_dohook($hookname,$args){
	global $session;
	require_once("modules/forum/forum_dohook.php");
	return $args;
}

function forum_run(){
	global $session;
	require_once("lib/villagenav.php");
	require_once("modules/forum/forum_run.php");
}
?>