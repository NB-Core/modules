<?php

function racedarkfelyne_getmoduleinfo(){
$info = array(
"name"=>"Race - Dark Felyne",
"version"=>"1.0",
"author"=>"`!Akutozo`0",
"category"=>"Races",
"download"=>"",
"settings"=>array(
"dark_felyne Race Settings,title",
"villagename"=>"Name for the Dark Felyne village|Dakar Si",
"minedeathchance"=>"Percent chance for Dark Felynes to die in the mine,range,0,100,1|25",
"goldgemchance"=>"Percent chance for Dark Felynes to find a gem on battle victory,range,0,100,1|10",
"goldgemmessage"=>"Message to display when finding a gem|`&Your `\)Dark Felyne senses tingle, and you notice a `%gem`&!",
"goldloss"=>"How much less gold (in percent) do the Dark Felynes find?,range,0,100,1|10",
"mindk"=>"How many DKs do you need before the race is available?,int|3",
),
);
return $info;
}

function racedarkfelyne_install(){
module_addhook("chooserace");
module_addhook("setrace");
module_addhook("newday");
module_addhook("villagetext");
module_addhook("travel");
module_addhook("charstats");
module_addhook("validlocation");
module_addhook("moderate");
module_addhook("changesetting");
module_addhook("raceminedeath");
module_addhook("racenames");
    module_addhook("pvpadjust");
    // Update from commentary sections using village-$city to village-$race;
    // This is pretty much a one-time thing
    $sql = "UPDATE " . db_prefix("commentary") . " SET section='village-darkfelyne' WHERE section='village-Dakar Si'";
    db_query($sql);
return true;
}

function racedarkfelyne_uninstall(){
global $session;
 $vname = getsetting("villagename", LOCATION_FIELDS);
 $gname = get_module_setting("villagename");
 $sql = "UPDATE " . db_prefix("accounts") . " SET location='$vname' WHERE location = '$gname'";
 db_query($sql);
 if ($session['user']['location'] == $gname)
  $session['user']['location'] = $vname;
 $sql = "UPDATE  " . db_prefix("accounts") . " SET race='" . RACE_UNKNOWN . "' WHERE race='darkfelyne'";
 db_query($sql);
 if ($session['user']['race'] == 'darkfelyne')
  $session['user']['race'] = RACE_UNKNOWN;
 return true;
}

function racedarkfelyne_dohook($hookname,$args){
global $session,$resline;

if (is_module_active("raceDakar Si")) {
$city = get_module_setting("villagename", "raceDakar Si");
} else {
$city = getsetting("villagename", LOCATION_FIELDS);
}
$race = "`\)Dark Felyne";
switch($hookname){
case "racenames":
$args[$race] = $race;
break;
case "pvpadjust":
if ($args['race'] == $race) {
$args['creaturedefense']+=(5+floor($args['creaturelevel']/5));
}
break;
case"adjuststats":
if ($args['race'] == $race) {
$args['defense'] += (2+floor($args['level']/5));
$args['maxhitpoints'] -= round($args['maxhitpoints']*.05, 0);
}
break;
case "raceminedeath":
if ($session['user']['race'] == $race) {
$args['chance'] = get_module_setting("minedeathchance");
$args['racesave'] = "Fortunately your `\)Dark Felyne skills let you escape unscathed.`n";
$args['schema']="module=racedarkfelyne";
}
break;
case "charstats":
if ($session['user']['race']==$race){
addcharstat("Vital Info");
addcharstat("Race", translate_inline($race));
}
break;
case "chooserace":
if ($session['user']['dragonkills'] < get_module_setting("mindk"))
break;
output("In the city of %s, your race of `5`\)Dark Felynes`0, ", true);
addnav("`5`\)Dark Felyne`0","newday.php?setrace=$race$resline");
addnav("","newday.php?setrace=$race$resline");
break;
case "setrace":
if ($session['user']['race']==$race){
output("`&As a `\)Dark Felyne, your amazing reflexes allow you to respond very quickly to any attacks.`n");
output("You gain extra defense!`n");
output("`n");
if (is_module_active("cities")) {
if ($session['user']['dragonkills']==0 &&
$session['user']['age']==0){
set_module_setting("newest-$city",
$session['user']['acctid'],"cities");
}
set_module_pref("homecity",$city,"cities");
if ($session['user']['age'] == 0)
$session['user']['location']=$city;
}
}
break;
case "battle-victory":
if ($session['user']['race'] != $race) break;
if ($args['type'] != "forest") break;
if ($session['user']['level'] < 15 &&
e_rand(1,100) <= get_module_setting("goldgemchance")) {
output(get_module_setting("goldgemmessage")."`n`0");
$session['user']['gems']++;
//debuglog("found a gem when slaying a monster, for being a `\)Dark Felyne.");
}
break;

case "creatureencounter":
if ($session['user']['race']==$race){

racedarkfelyne_checkcity();
$loss = (100 - get_module_setting("goldloss"))/100;
$args['creaturegold']=round($args['creaturegold']*$loss,0);
}
break;
case "newday":
if ($session['user']['race']==$race){
racedarkfelyne_checkcity();
apply_buff("racialbenefit",array(
"name"=>"`@`4Dark Dexterity`0",
"defmod"=>"(<defense>?(1+((5+floor(<level>/5))/<defense>)):0)",
"badguydmgmod"=>1.05,
"allowinpvp"=>1,
"allowintrain"=>1,
"rounds"=>-1,
"schema"=>"module=racedarkfelyne",
)
);
}
break;
}

return $args;
}

function racedarkfelyne_checkcity(){
global $session;
$race="`_Dark Felyne";
if (is_module_active("raceDakar Si")) {
$city = get_module_setting("villagename", "raceDakar Si");
} else {
$city = getsetting("villagename", LOCATION_FIELDS);
}

if ($session['user']['race']==$race && is_module_active("cities")){
if (get_module_pref("homecity","cities")!=$city){ 
set_module_pref("homecity",$city,"cities");
}
} 
return true;
}

function racedarkfelyne_run(){
}
 
?>