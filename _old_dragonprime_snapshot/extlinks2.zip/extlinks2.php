<?php
// addnews ready
// mail ready
// translator ready

function extlinks2_getmoduleinfo(){
	$info = array(
		"name"=>"External Links v2",
		"version"=>"2.0",
		"author"=>"Peter Corcoran based on JT Traub's External Links module",
		"allowanonymous"=>true,
		"category"=>"General",
		"download"=>"http://dragonprime.net/users/R4000/extlinks2.zip",
		"settings"=>array(
			"External Links Settings,title",
			"Please use the tabs above to select a link and change it!,note",
		),
	);
	for ($i = 1; $i <= 20; $i++) {
		$info['settings'][] = "Link $i,title";
		$info['settings']['link'.$i.'heading'] = "Nav heading for Link ".$i."|";
		$info['settings']['link'.$i.'title'] = "Text for Link ".$i."|";
		$info['settings']['link'.$i.'link'] = "URL for Link ".$i."|";				
	}
	return $info;
}

function extlinks2_install(){
	module_addhook("everyhit");
	return true;
}

function extlinks2_uninstall(){
	return true;
}

function extlinks2_dohook($hookname,$args){
	switch($hookname){
		case "everyhit":
			$output = TRUE;
			break;
	}
	if($output === TRUE){
		extlinks2_display();
	}
	return $args;
}
function extlinks2_display(){
	rawoutput("<style>");
	rawoutput("all.clsMenuItemNS, .clsMenuItemIE{text-decoration: none; font: bold 12px Arial; color: white; cursor: hand; z-index:100}");
	rawoutput("#MainTable A:hover {color: yellow;}");
	rawoutput("</style>");
	rawoutput("<script language=\"JavaScript\">");
	rawoutput("var keepstatic=1 //specify whether menu should stay static 0=non static (works only in IE4+)");
	rawoutput("var menucolor=\"#000000\" //specify menu color");
	rawoutput("var submenuwidth=150 //specify sub menus' color");
	rawoutput("</script>");
	rawoutput("<script language=\"JavaScript\" src=\"modules/extlinks2/menu.js\"></script>");
	rawoutput("<script language=\"JavaScript\">");
	rawoutput("function showToolbar()");
	rawoutput("{");
	rawoutput("// AddItem(id, text, hint, location, alternativeLocation);");
	rawoutput("// AddSubItem(idParent, text, hint, location, linktarget);");
	rawoutput("	menu = new Menu();");
	$heads = array ();
	for ($i = 1; $i <= 20; $i++) {
		$pref = "link$i";
		$head = get_module_setting($pref."heading");
		if($heads[$head] != 1){
			$heads[$head] = 1;
			rawoutput("	menu.addItem(\"".str_replace(" ","_",$head)."\", \"".$head."\", \"".$head."\",  null, null)");
		}
		$title = get_module_setting($pref."title");
		$link = get_module_setting($pref."link");
		if ($title && $link){
			rawoutput("	menu.addSubItem(\"".str_replace(" ","_",$head)."\", \"".$title."\", \"".$title."\",  \"".$link."\", \"\");");
		}
	}
	rawoutput("	menu.showMenu();");
	rawoutput("}");
	rawoutput("</script>");
	rawoutput("<script language=\"JavaScript\">");
	rawoutput("showToolbar();");
	rawoutput("</script>");
	rawoutput("<script language=\"JavaScript\">");
	rawoutput("function UpdateIt(){");
	rawoutput("if (ie&&keepstatic&&!opr6)");
	rawoutput("document.all[\"MainTable\"].style.top = document.body.scrollTop;");
	rawoutput("setTimeout(\"UpdateIt()\", 200);");
	rawoutput("}");
	rawoutput("UpdateIt();");
	rawoutput("</script>");
}
function extlinks2_run(){
}
?>
