<?php
	$name = get_module_pref("name");
	$classarray = array(
		0=>translate_inline("Squire"),
		1=>translate_inline("Knight"),
		2=>translate_inline("Warlord")
	);
	$maxarray = array(
		0=>get_module_setting("knight"),
		1=>get_module_setting("warlord"),
		2=>get_module_setting("max")
	);
	$class = get_module_pref("class");
	if (get_module_setting("exp") != 0){
		$exp = 1-(get_module_setting("exp")/100);
	}else{
		$exp = 1;
	}
	$min = get_module_setting("mindmg");
	$max = get_module_setting("maxdmg");
	// Apply flux based on Squire's level and class
	$bk = (get_module_setting("boost-knight")/100);
	$bw = (get_module_setting("boost-warlord")/100);
	$minion = 1;
	$mindmg = $min+get_module_pref("level");
	switch (get_module_pref("class")){
		case 0:
			$maxdmg = $max+get_module_pref("level");
			break;
		case 1:
			$maxdmg = round($max+get_module_pref("level")*$bk);
			break;
		case 2:
			$maxdmg = round($max+get_module_pref("level")*$bw);
			$minion = 2; // Two Blades
			break;
		}
	$minstat = $mindmg;
	$maxstat = $maxdmg;
	// Applying miss calculation
	if (e_rand(1,100) > get_module_pref("acc")){
		$mindmg = 0;
		$maxdmg = $max;
	}
	switch ($hookname){
		case "footer-hof":
			if (get_module_setting("hof")){
				addnav("Warrior Rankings");
				addnav("Strongest Squires","runmodule.php?module=academy&op=hof");	
			}
			break;
		case "creatureencounter":
			$buffarray = array(0=>1.05,1=>$bk,2=>$bw);
			if (get_module_pref("active") && !get_module_pref("dead")){
				$args['creatureexp'] = round($args['creatureexp']*$exp,0);
				$args['creatureattack'] = round($args['creatureattack']*($buffarray[$class]));
				$args['creaturedefense'] = round($args['creaturedefense']*($buffarray[$class]));
				$args['creaturehealth'] = round($args['creaturehealth']*($buffarray[$class]*($class==2?"2":"1.2")));
			}
			break;
		case "newday":
			if (get_module_pref("active") && !get_module_pref("dead")){
				if (e_rand(1,100) <= get_module_pref("level")*5){
					apply_buff("academy", array(
							"name"=>sprintf_translate("%s's Melody",$name),
							"roundmsg"=>sprintf_translate("The tune of %s's melody empowers you.",$name),
							"rounds"=>e_rand(5,30),
							"atkmod"=>1.1,
							"defmod"=>1.1,
							"wearoff"=>sprintf_translate("The tune of %s's melody slowly fades amongst the wind...",$name),
							"schema"=>"module-academy",
						)
					);
				}
			}
			set_module_pref("tacc",0);
			break;
		case "battle":
			if (get_module_pref("active") && !get_module_pref("dead")){
				apply_buff("battle-academy", array(
					"name"=>$name,
					"startmsg"=>sprintf_translate("%s `6readies his weapon.",$name),
					"rounds"=>-1,
					"minioncount"=>$minion,
					"minbadguydamage"=>$mindmg,
					"maxbadguydamage"=>$maxdmg,
					"allowinpvp"=>get_module_setting("pvp"),
					"allowintrain"=>get_module_setting("train"),
					"effectmsg"=>sprintf_translate("`&%s `6strikes `\${badguy} `6for `^{damage}`6 damage!",$name),
				    "effectnodmgmsg"=>sprintf_translate("`\${badguy} `6narrowly dodges the weapon of `&%s",$name),
					"effectfailmsg"=>sprintf_translate("`\${badguy} `6narrowly dodges the weapon of `&%s",$name),
					"schema"=>"module-academy",
					)
				);
			}
			break;
		case "battle-victory":
			strip_buff("battle-academy");
			break;
		case "shades":
		case "graveyard":
			if (get_module_pref("active") && httpget('module') != "battlearena"){
				if (!get_module_pref("dead")){
					output("`n`n`)Sadly, %s `)has lost his life, trying to defend your body.`n",$name);
					debuglog("'s Squire is dead.");
				}
				set_module_pref("dead",1);
			}
			strip_buff("battle-academy");
			break;
		case "biostat":
			if (get_module_pref("user_bio","academy",$args['acctid']) 
				&& get_module_pref("active","academy",$args['acctid'])){
				$name = get_module_pref("name","academy",$args['acctid']);
				$class = get_module_pref("class","academy",$args['acctid']);
				$level = get_module_pref("level","academy",$args['acctid']);
				$acc = get_module_pref("acc","academy",$args['acctid']) . "%";
				if ($name != "")	output("`^%s's Name: `@%s`0`n",$classarray[$class],$name);
				output("`^%s's Level: `@%s`0`n",$classarray[$class],$level);
				output("`^%s's Accuracy: `@%s`0`n",$classarray[$class],$acc);
			}
			break;
		case "dragonkill":
		case "training-victory":
			if (get_module_pref("active") && !get_module_pref("dead")){
				$levelsetting = get_module_setting("level");
				$levelpref = get_module_pref("level");
				$levelsincelevel = get_module_pref("lsl");
				if ($levelpref < $maxarray[$class]){
					if ($levelsincelevel != $levelsetting){
						output("`n`%%s `^is slowly becoming stronger!`n",$name);
						$levelsincelevel++;
						set_module_pref("lsl",$levelsincelevel);
					}else{
						output("`n`%%s `^should be able to level up now!`n",$name);
					}
				}else{
					output("`n%s has become the strongest he can be...`n",$name);
				}
			}
			break;			
		case "village":
			if ($session['user']['location'] == get_module_setting("academyloc")){
				tlschema($args['schemas']['fightnav']);
				addnav($args['fightnav']);
				tlschema();
				addnav("Dycedarg's Academy","runmodule.php?module=academy&op=enter");
			}
			break;
		case "changesetting":
			if ($args['setting'] == "villagename"){
				if ($args['old'] == get_module_setting("academyloc")){
					set_module_setting("academyloc",$args['new']);
				}
			}
			break;
		case "charstats":
			$classarray = array(0=>translate_inline("Squire"),1=>translate_inline("Knight"),2=>translate_inline("Warlord"));
			if (get_module_pref("user_showstats") && get_module_pref("active")){
				$title = sprintf("%s Info",$classarray[$class]);
				$name_stat = translate_inline("Name");
				$status = translate_inline("Status");
				$level = translate_inline("Level");
				$attack = translate_inline("Damage");
				$ready = translate_inline("Ready to Level");
				$train = translate_inline("Train Accuracy");
				$acc = translate_inline("Accuracy");
				setcharstat($title,$name_stat,$name);
				setcharstat($title,$status,translate_inline(get_module_pref("dead")==1?"Dead":"Alive"));
				setcharstat($title,$level,get_module_pref("level"));
				setcharstat($title,$attack,$minstat."-".$maxstat);
				setcharstat($title,$acc,get_module_pref("acc")."%");
				$cond = translate_inline("No");
				if (get_module_pref("lsl") == get_module_setting("level")) $cond = translate_inline("Yes");
				setcharstat($title,$ready,$cond);
				if ($acc<get_module_setting("miss"))
					setcharstat($title,$train,translate_inline(get_module_pref("tacc")==1?"Unable":"Able")) ;
			}
			break;
		}
?>