No special install instructions here.

0.9.7 PointParlor by sixf00t4
made for http://sixf00t4.com/dragon
structure taken from Robert's apothecary
------
0.9.8 conversion by Danilo Stern-Sapad aka Ariadoss
Fixed some gramatical errors, modified, updated, & removed code.
TODO: going to add ability to change hard coded values in settings.
Note: this module was tested on LoGD 0.9.8-prerelease.13

ver. 1.1 by Lonny Luberts
Added the ability to set shop owner name.
Added code to update donationspent user data.
Added support for odor,usedchow,portable potions,secondweapon, and bladder modules.
Cleaned up code to be a bit more readable.
