<?

function pointparlor_getmoduleinfo(){
	$info = array(
	"name"=>"Point Parlor",
	"version"=>"20050509",
	"author"=>"sixf00t4<br>Modified by Danilo Stern-Sapad & `#Lonny Luberts<br>`^Maintianed by `#Lonny Luberts",
	"category"=>"Lodge",
		"download"=>"http://www.pqcomp.com/modules/mydownloads/visit.php?cid=3&lid=81",
		"vertxtloc"=>"http://www.pqcomp.com/",
	"settings"=> array(
				"Point Parlor Settings,title",
				"owner"=>"Name of the person running the Parlor?,text|Robert",
				"smname"=>"Who to send Mail Doantions to,text|",
				"smaddress"=>"Address for Mail,text|",
				"smaddress2"=>"City State Zip for mail,text|",
			),
			"prefs" => array(
				"Point Parlor User Prefs,title",
				"deoderant"=>"Days left on deoderant,int|0",
				"depends"=>"Diapers left,int|0",
				"breakfastbar"=>"Breakfast Bars left,int|0",
				"newdays"=>"How Many new days does player have,int|0",
			),
		);
	return $info;
}

function pointparlor_install(){
	output("Installing Point Parlor.`n");
    module_addhook("lodge");
    module_addhook("pointsdesc");
    module_addhook("newday");
    module_addhook("village");
    module_addhook("header-lodge");
    module_addhook("shades");
return true;
}

function pointparlor_uninstall(){
	output("Uninstalling Point Parlor.`n");
	return true;
}

function pointparlor_dohook($hookname,$args){
global $session;
switch($hookname){
	case "shades":
		if (get_module_pref("newdays") > 0){
			addnav("Donator Specials");
			addnav(array("New Day (%s)",get_module_pref("newdays")),"runmodule.php?module=pointparlor&op=usenewday");
		}
	break;
	case "referral":
		addnav("Point Parlor","runmodule.php?module=pointparlor");
	break;
	case "header-lodge":
		output("`c");
		$paysite = getsetting("paypalemail", "");
		if ($paysite != ""){
			$paypalstr = '<table align="center"><tr><td>';
			$paypalstr .= '</td><td>';
			$paypalstr .= '<form action="https://www.paypal.com/cgi-bin/webscr" method="post" target="_blank">
			<input type="hidden" name="cmd" value="_xclick">
			<input type="hidden" name="business" value="'.$paysite.'">
			<input type="hidden" name="item_name" value="Legend of the Green Dragon Site Donation from '.full_sanitize($session['user']['name']).'">
			<input type="hidden" name="item_number" value="'.htmlentities($session['user']['login']).":".$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'].'">
			<input type="hidden" name="no_shipping" value="1">';
			if (file_exists("payment.php")) {
				$paypalstr .= '<input type="hidden" name="notify_url" value="http://'.$_SERVER["HTTP_HOST"].dirname($_SERVER['REQUEST_URI']).'/payment.php">';
			}
			$paypalstr .= '<input type="hidden" name="cn" value="Your Character Name">
			<input type="hidden" name="cs" value="1">
			<input type="hidden" name="currency_code" value="USD">
			<input type="hidden" name="tax" value="0">
			<input type="image" src="images/paypal.gif" border="0" name="submit" alt="Donate!">
			</form>';
			$paypalstr .= '</td></tr></table>';
			rawoutput($paypalstr);
			if (get_module_setting("smname") <> ""){
				output("`n`@Snail Mail Donations:`n");
				output("Send to: %s`n",get_module_setting("smname"));
				output("Address: %s`n",get_module_setting("smaddress"));
				output("City: %s`n",get_module_setting("smaddress2"));
				output("Please include a note that this is a LOTGD Donation along with your user name.`n`0");
			}
		}
		output("`c`n");
	break;
	case "lodge":
		addnav("Point Parlor","runmodule.php?module=pointparlor");
		
	break;
	case "village":
	case "newday":
		if ($hookname == "village"){
			if (get_module_pref("newdays") > 0){
				addnav("Donator Specials");
				addnav(array("New Day (%s)",get_module_pref("newdays")),"runmodule.php?module=pointparlor&op=usenewday");
			}
		}
		//only run this routine for those who have and have spent donations
		if ($session['user']['donationspent'] > 0){
			$deoderant = get_module_pref('deoderant');
			$depends = get_module_pref('depends');
			$breakfastbar = get_module_pref('breakfastbar');
			if ($deoderant > 0){
				if ($hookname == "newday"){
					set_module_pref('deoderant',$deoderant - 1);
					output("`#Your deoderant kicks in!`n");
				}else{
					if (get_module_pref('odor','odor') > 0 ) output("`#Your deoderant is working!`n");
				}
				set_module_pref('odor',0,'odor');
			}
			if ($depends > 0){
				if ($hookname == "newday"){
					set_module_pref('depends',$depends - 1);
					output("`#You change your wet adult diaper!`n");
				}else{
					if (get_module_pref('bladder','bladder') > 0 ) output("`#Your adult diaper gets a little fuller!`n");
				}
				set_module_pref('bladder',0,'bladder');
			}
			if ($breakfastbar > 0){
				if ($hookname == "newday"){
					set_module_pref('breakfastbar',$breakfastbar - 1);
					output("`#You wolf down a breakfast bar!`n");
				}else{
					if (get_module_pref('hunger','usechow') > 0 )output("`#Your breakfast bar keeps you full!`n");
				}
				set_module_pref('hunger',0,'usechow');
			}
			
		}
	break;
}
return $args;
}

function pointparlor_run(){
	global $SCRIPT_NAME;
	if ($SCRIPT_NAME == "runmodule.php"){
		$module=httpget("module");
		if ($module == "pointparlor"){
			include("modules/lib/pointparlor.php");
		}
	}
}
?>