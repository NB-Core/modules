<?php
global $session;
$owner = get_module_setting('owner');
page_header($owner."'s Parlor");
$op = httpget('op');
output("`c");
$paysite = getsetting("paypalemail", "");
if ($paysite != ""){
	$paypalstr = '<table align="center"><tr><td>';
	$paypalstr .= '</td><td>';
	$paypalstr .= '<form action="https://www.paypal.com/cgi-bin/webscr" method="post" target="_blank">
	<input type="hidden" name="cmd" value="_xclick">
	<input type="hidden" name="business" value="'.$paysite.'">
	<input type="hidden" name="item_name" value="Legend of the Green Dragon Site Donation from '.full_sanitize($session['user']['name']).'">
	<input type="hidden" name="item_number" value="'.htmlentities($session['user']['login']).":".$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'].'">
	<input type="hidden" name="no_shipping" value="1">';
	if (file_exists("payment.php")) {
		$paypalstr .= '<input type="hidden" name="notify_url" value="http://'.$_SERVER["HTTP_HOST"].dirname($_SERVER['REQUEST_URI']).'/payment.php">';
	}
	$paypalstr .= '<input type="hidden" name="cn" value="Your Character Name">
	<input type="hidden" name="cs" value="1">
	<input type="hidden" name="currency_code" value="USD">
	<input type="hidden" name="tax" value="0">
	<input type="image" src="images/paypal.gif" border="0" name="submit" alt="Donate!">
	</form>';
	$paypalstr .= '</td></tr></table>';
	rawoutput($paypalstr);
	if (get_module_setting("smname") <> ""){
		output("`n`@Snail Mail Donations:`n");
		output("Send to: %s`n",get_module_setting("smname"));
		output("Address: %s`n",get_module_setting("smaddress"));
		output("City: %s`n",get_module_setting("smaddress2"));
		output("Please include a note that this is a LOTGD Donation along with your user name.`n`0");
	}
}
output("`c`n");
if ($op == ""){

output("`c`b`@%s's Point Parlor`b`c",$owner,true);
output(" `nYou enter %s's Parlor, he welcomes you and says: What do you want today?`n",$owner);
output(" I have some great offers on some really good potions today.. Just look here:`n");
output(" `%Please note that almost none of these effects will stay after you have defeated the `@Green Dragon`0.`n");
output("`%Only the health or hitpoint effect will stay.`0.`n`n");
output(" `&You have `^%s `& donation points`n`n",$session['user']['donation'] - $session['user']['donationspent']);

output(" `@Strength costs `%10 donator points`@. And will give you one more attack-point`n");
output(" Hardskin costs `%10 donator points`@. And will give you one more defense-point`n");
output(" Health costs `%15 donator points`@. And will give you one more max HP`n");
output(" Charm costs `%10 donator points`@. And will give you 10 more charm-points`n");
output(" Endurance costs `%5 donator points`@. And will give you 5 more forest-fights this day`n`n");
output(" Wealth `%5 donator points`@. And will give you 1000 more gold`n");
output(" Experience costs `%15 donator points`@. And will give you 500 more experience`n");
output(" Favor costs `%20 donator points `@today. And will give you 100 more favor with Ramius`n");
if (is_module_active('odor')){
	output(" `@Deoderant costs `%15 donator points`@. And will protect you for 10 days`n");
}
if (is_module_active('bladder')){
	output(" `@Depends undergaments cost `%15 donator points`@ for a 10 pack`n");
}
if (is_module_active('usechow')){
	output(" `@Breakfast Bar cost `%15 donator points`@ for a 10 pack and satisfys your hunger when you wake up`n");
}
if (is_module_active('potions')){
	output(" `@Portable Potion costs `%5 donator points`@ each.`n");
}
if (is_module_active('secondweapon')){
	output(" `@Secondary Weapon Ammo costs `%5 donator points`@ per pair.`n");
}
output("Mega Magic Sword costs `%50 donator points `@today. It's a level 20 sword!`n");
output("Mega Magic Armor costs `%50 donator points `@today. It's level 20 armor!`n");
output("A New Game day costs `%25 donator points `@today. Get another new day!`n");
output(" `^These are all I have today. Maybe I will have more potions tomorrow....`n`&");

addnav("Rewards");
addnav("Strength","runmodule.php?module=pointparlor&op=attack");
addnav("Hardskin","runmodule.php?module=pointparlor&op=defense");
addnav("Health","runmodule.php?module=pointparlor&op=health");
addnav("Charm","runmodule.php?module=pointparlor&op=charm");
addnav("Endurance","runmodule.php?module=pointparlor&op=endurance");
addnav("Wealth","runmodule.php?module=pointparlor&op=wealth");
addnav("Experience","runmodule.php?module=pointparlor&op=exp");
addnav("Favor","runmodule.php?module=pointparlor&op=favor");
if (is_module_active('odor')){
	addnav("Deoderant","runmodule.php?module=pointparlor&op=deoderant");
}
if (is_module_active('bladder')){
	addnav("Depends","runmodule.php?module=pointparlor&op=depends");
}
if (is_module_active('usechow')){
	addnav("Breakfast Bar","runmodule.php?module=pointparlor&op=breakfastbar");
}
if (is_module_active('potions')){
	addnav("Portable Potion","runmodule.php?module=pointparlor&op=potion");
}
if (is_module_active('secondweapon')){
	addnav("Ammo","runmodule.php?module=pointparlor&op=ammo");
}
addnav("Mega Magic Sword","runmodule.php?module=pointparlor&op=mmsword");
addnav("Mega Magic Armor","runmodule.php?module=pointparlor&op=mmarmor");
addnav("Newday","runmodule.php?module=pointparlor&op=newday");
addnav("Other");
addnav("L?Return to the Lodge","lodge.php");
}

if ($op == "attack"){
if ($session['user']['donation'] - $session['user']['donationspent']> 9){
	$session['user']['attack']++;
	$session['user']['donationspent'] +=10;
	output("You gain 1 attack point.`n");
	output("You feel a sudden growth in your muscles.");
	addnav("Back to Parlor","runmodule.php?module=pointparlor");
}else{
	output("You can`t afford this");
	addnav("Back to Parlor","runmodule.php?module=pointparlor");
}
}

if ($op == "wealth"){
if ($session['user']['donation'] - $session['user']['donationspent']> 4){
	$session['user']['gold']+= 1000;
	$session['user']['donationspent'] +=5;
	output("You gain 1000 gold.`n");
	output("%s throws you a sack of coins.",$owner);
	addnav("Back to Parlor","runmodule.php?module=pointparlor");
}else{
	output("You can`t afford this");
	addnav("Back to Parlor","runmodule.php?module=pointparlor");
}
}

if ($op == "exp"){
if ($session['user']['donation'] - $session['user']['donationspent']> 14){
	$session['user']['experience']+= 500;
	$session['user']['donationspent'] +=15;
	output("You gain 500 experience.`n");
	output("You feel experienced.");
	addnav("Back to Parlor","runmodule.php?module=pointparlor");
}else{
	output("You can`t afford this");
	addnav("Back to Parlor","runmodule.php?module=pointparlor");
}
}

if ($op == "favor"){
if ($session['user']['donation'] - $session['user']['donationspent']> 19){
	$session['user']['deathpower']+= 100;
	$session['user']['donationspent'] +=20;
	output("You gain 100 favor with Ramius.`n");
	output("You feel the ground shake.");
	addnav("Back to Parlor","runmodule.php?module=pointparlor");
}else{
	output("You can`t afford this");
	addnav("Back to Parlor","runmodule.php?module=pointparlor");
}
}

if ($op == "defense"){
if ($session['user']['donation'] - $session['user']['donationspent']> 9){
	$session['user']['defense']++;
	$session['user']['donationspent'] +=10;
	output(" %s gives you a Hardskin's Potion and takes 10 of your donator points.`n",$owner);
	output(" You feel that you skin hardens.");
	addnav("Back to Parlor","runmodule.php?module=pointparlor");
}else{
	output("You can`t afford this");
	addnav("Back to Parlor","runmodule.php?module=pointparlor");
}
}

if ($op == "health"){
if ($session['user']['donation'] - $session['user']['donationspent']> 14){
	$session['user']['maxhitpoints']++;
	$session['user']['hitpoints'] = $session['user']['maxhitpoints'];
	$session['user']['donationspent'] +=15;
	output("%s gives you a Potion of Endurance and takes 15 of your donator points.`n",$owner);
	output("You feel that you can withstand more now.");
	addnav("Back to Parlor","runmodule.php?module=pointparlor");
}else{
	output("You can`t afford this");
	addnav("Back to Parlor","runmodule.php?module=pointparlor");
}
}

if ($op == "charm"){
if ($session['user']['donation'] - $session['user']['donationspent']> 9){
	$session['user']['charm']+= 10;
	$session['user']['donationspent'] +=10;
	output("%s gives you a Potion of Love and takes 10 of your donator points.`n",$owner);
	output("You can feel the charm grow inside you.");
	addnav("Back to Parlor","runmodule.php?module=pointparlor");
}else{
	output("You can`t afford this");
	addnav("Back to Parlor","runmodule.php?module=pointparlor");
}

}

if ($op == "endurance"){
if ($session['user']['donation'] - $session['user']['donationspent']> 4) {
	$session['user']['donationspent'] +=5;
	$session['user']['turns']+= 5;
	output("%s gives you a Wanderer's Potion and takes 5 of your donator points.`n",$owner);
	output("You can feel the forest calling for you.");
	addnav("Back to Parlor","runmodule.php?module=pointparlor");
}else{
	output("You can`t afford this");
	addnav("Back to Parlor","runmodule.php?module=pointparlor");
}
}

if ($op == "deoderant"){
if ($session['user']['donation'] - $session['user']['donationspent']> 14) {
	$session['user']['donationspent'] +=15;
	set_module_pref('deoderant',10);
	output("%s applies your deoderant and takes 15 of your donator points.`n",$owner);
	output("You can feel the forest calling for you.");
	addnav("Back to Parlor","runmodule.php?module=pointparlor");
}else{
	output("You can`t afford this");
	addnav("Back to Parlor","runmodule.php?module=pointparlor");
}
}

if ($op == "depends"){
if ($session['user']['donation'] - $session['user']['donationspent']> 14) {
	$session['user']['donationspent'] +=15;
	set_module_pref('depends',10);
	output("%s hands you a bag of adult diapers and takes 15 of your donator points.`n",$owner);
	output("You can feel the forest calling for you.");
	addnav("Back to Parlor","runmodule.php?module=pointparlor");
}else{
	output("You can`t afford this");
	addnav("Back to Parlor","runmodule.php?module=pointparlor");
}
}

if ($op == "breakfastbar"){
if ($session['user']['donation'] - $session['user']['donationspent']> 14) {
	$session['user']['donationspent'] +=15;
	set_module_pref('breakfastbar',10);
	output("%s hands you a bag of breakfast bars and takes 15 of your donator points.`n",$owner);
	output("You can feel the forest calling for you.");
	addnav("Back to Parlor","runmodule.php?module=pointparlor");
}else{
	output("You can`t afford this");
	addnav("Back to Parlor","runmodule.php?module=pointparlor");
}
}

if ($op == "potion"){
$potions = get_module_pref('potion','potions');
if ($potions < 5){
if ($session['user']['donation'] - $session['user']['donationspent']> 4) {
	$session['user']['donationspent'] +=5;
	set_module_pref('potion',$potions + 1,'potions');
	output("%s hands you a potion and takes 5 of your donator points.`n",$owner);
	output("You can feel the forest calling for you.");
	addnav("Back to Parlor","runmodule.php?module=pointparlor");
}else{
	output("You can`t afford this");
	addnav("Back to Parlor","runmodule.php?module=pointparlor");
}
}else{
	output("You already have your limit of potions");
	addnav("Back to Parlor","runmodule.php?module=pointparlor");
}
}

if ($op == "ammo"){
if (get_module_pref('weapon','secondweapon') <> ""){
if ($session['user']['donation'] - $session['user']['donationspent']> 4) {
	$session['user']['donationspent'] +=5;
	set_module_pref('ammo',get_module_pref('ammo','secondweapon') + 2,'secondweapon');
	output("%s hands you 2 ammo and takes 5 of your donator points.`n",$owner);
	output("You can feel the forest calling for you.");
	addnav("Back to Parlor","runmodule.php?module=pointparlor");
}else{
	output("You can`t afford this");
	addnav("Back to Parlor","runmodule.php?module=pointparlor");
}
}else{
	output("You do not have a weapon to use ammo with!");
	addnav("Back to Parlor","runmodule.php?module=pointparlor");
}
}

if ($op == "mmsword"){
	if ($session['user']['armor'] == "`3Mega `#Magic `!Sword"){
		output("You already have the `3Mega `#Magic `!Sword.`n");
		addnav("Back to Parlor","runmodule.php?module=pointparlor");
	}else{
		if ($session['user']['donation'] - $session['user']['donationspent']> 49) {
			$session['user']['donationspent'] +=50;
			output("%s takes your %s and tosses it in a pile of discared weapons.",$owner,$session['user']['weapon']);
			$session['user']['weapon']="`3Mega `#Magic `!Sword";
			$session['user']['weaponvalue']=0;
			$session['user']['attack']-=$session['user']['weapondmg'];
			$session['user']['weapondmg'] = 20;
			$session['user']['attack']+=20;
			output("You try out your new `3Mega `#Magic `!Sword, it feels well balanced, and very sturdy.");
			addnav("Continue","runmodule.php?module=pointparlor");
		}else{
			output("You can`t afford this");
			addnav("Back to Parlor","runmodule.php?module=pointparlor");
		}
	}
}

if ($op == "mmarmor"){
	if ($session['user']['armor'] == "`2Mega `@Magic `^Armor"){
		output("You already have the `2Mega `@Magic `^Armor.`n");
		addnav("Back to Parlor","runmodule.php?module=pointparlor");
	}else{
		if ($session['user']['donation'] - $session['user']['donationspent']> 49) {
			$session['user']['donationspent'] +=50;
			output("%s takes your %s and tosses it in a pile of discared armor.",$owner,$session['user']['armor']);
			$session['user']['armor']="`2Mega `@Magic `^Armor";
			$session['user']['armorvalue']=0;
			$session['user']['defense']-=$session['user']['armordef'];
			$session['user']['armordef'] = 20;
			$session['user']['defense']+=20;
			output("You try on your new `2Mega `@Magic `^Armor, it fits well, and feels very sturdy.");
			addnav("Continue","runmodule.php?module=pointparlor");
		}else{
			output("You can`t afford this");
			addnav("Back to Parlor","runmodule.php?module=pointparlor");
		}
	}	
}

if ($op == "newday"){
	if ($session['user']['donation'] - $session['user']['donationspent']> 24) {
		$session['user']['donationspent'] +=25;
		output("`#You have purchased a new day!  You will find a newday link in the villages and shades!`n");
		output("To use your new day simply click on that link.`n");
		set_module_pref("newdays",(get_module_pref("newdays") + 1));
		addnav("Continue","runmodule.php?module=pointparlor");
	}else{
		output("You can`t afford this");
		addnav("Back to Parlor","runmodule.php?module=pointparlor");
	}
}

if ($op == "usenewday"){
	set_module_pref("newdays",(get_module_pref("newdays") - 1));
	redirect("newday.php");
}

page_footer();
?>