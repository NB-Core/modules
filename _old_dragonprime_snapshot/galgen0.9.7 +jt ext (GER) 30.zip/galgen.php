<?php 
//Idee und Umsetzung
//Morpheus aka Apollon
//f�r LoGD.at 2005

require_once "common.php"; 
page_header("Der Richtplatz"); 
if (!isset($session)) exit(); 
if ($_GET_VARS[op]==""){ 
	output("`c`b`4Der Richtplatz`c`b`n`n");
	output("`3Du betrittst einen gro�en Platz, der direkt vor dem Tor ist und auf einem H�gel liegt, in dessen Mitte ein `Th�lzernes Gestell `3mit einem `9Galgen `3steht, direkt daneben ein zweites mit einem `9Richtklotz`3."); 
	output("`3Ein St�ck weiter, nicht sehr weit davon, steht ein kleines `7Haus`3, in dem der `4Scharfrichter `4wohnt`3, der hier, bei entsprechendem Anla�, seinem grausigen Gewerbe nachgeht, direkt neben dem `7Haus`3, den `7H�gel `3herab, ist eine `QAbfallhalde`3, wo die Sachen derer, die ihm zum Opfer wurden, landen.`n"); 
	output("`3Auf dem Platz selbst ist, im Moment, nicht viel los, hier und da stehen ein paar `vLeute `3und unterhalten sich, ein `vHund `3streunt �ber den Platz und ein paar `vKinder `3spielen nahe der gar grausigen St�tte.`n"); 

	addcommentary(); 
	viewcommentary("galgen","Sprechen",15,"spricht"); 
	addnav("Sonstiges"); 
	addnav("Platz untersuchen","galgen.php?op=platz");     
	addnav("Halde untersuchen","galgen.php?op=halde");     
	addnav("Wege"); 
	addnav("Weiter zum Wald","forest.php");          
	addnav("Zur�ck zur Stadt","stadttor.php");     
     
} 
if ($_GET_VARS[op] == "platz") { 
	output("`3Du schlenderst �ber den Platz und blickst Dich um: da, wo sich sonst Massen dr�ngen, das grausame Schauspiel zu verfolgen, herrscht nun, bis auf wenige Menschen, g�hnende Leere."); 
	output("`3 Du blickst genau um Dich und "); 
		switch(e_rand(1,6)){ 
			case 1: 
			output("`3entdeckst ein `tPlakat`3, auf dem f�r das `tTheater `3in `6Eythgim `3geworben wird, vielleicht solltest Du es mal besuchen!?"); 
			break; 
			case 2: 
			output("`3�bersiehst dabei eine Kuhle im Boden, die mit `TMatsch `3gef�llt ist und in die Du trittst, wobei Du Dir den Fu� b�se verstauchst."); 
			$session[user][hitpoints]*=0.95;
			break; 
			case 3: 
			if ($session[user][gold]>=10){ 
				output("`3siehst einen `%alten Mann`3, der um seinen Lebensunterhalt bettelt."); 
				output("`3Weil er Dir sehr leid tut, gibst Du ihm etwas `6Gold `3und er bedankt sich �berschwenglich bei Dir.");
				output("`3Du f�hlst Dich richtig gut und bekommst einen Charmepunkt."); 
				$session[user][gold]-=10;
				$session[user][charm]++;
			}else{
				output("`3siehst einen `%alten Mann`3, der um seinen Lebensunterhalt bettelt."); 
				output("`3Weil er Dir sehr leid tut, k�ndigst Du an, ihm etwas `6Gold `3zu geben und greifst zu Deinem Beutel, der jedoch so `\$leer `3ist, da� Du ihm nichts geben kannst.");
				output("`3Sichtlich entt�uscht geht `%der Alte `3wieder von dannen und Du wirst `\$knallrot`3, weil es Dir so peinlich ist."); 
				output("`3Aus `\$lauter Scham `3verlierst Du einen Charmepunkt."); 			
				$session[user][charm]--;
			}
			break; 
			case 4: 
			if ($session[user][turns]>=1){ 
				output("`3siehst auch `2nicht das Geringste`3, was von Interesse sein k�nnte, doch vert�delst Du die Zeit f�r einen Waldkampf."); 
				$session[user][turns]-=1;
			}else{
				output("`3siehst auch `2nicht das Geringste`3, was von Interesse sein k�nnte, doch stolperst Du fast �ber die eigenen F��e und verletzt Dich dabei.");
				$session[user][hitpoints]*=0.98;
			}
			break;
			case 5:
			output("`3siehst ein merkw�rdiges `^Glitzern `3am Fu�e der Treppe zu einem der `TGestelle."); 
			output("`3Als Du nachsiehst, entdeckst Du"); 
				switch(e_rand(1,4)){ 
					case 1:
					output("`@3 Edelsteine`3."); 
					$session[user][gems]+=3;
					break;
					case 2:
					output("`3eine wertlose Scherbe."); 
					break;
					case 3:
					output("`3einen `6Beutel Gold`3."); 
					$session[user][gold]+=250;
					break;
					case 4:
					output("`3eine wertlose Scherbe."); 
					break;
				}
			break; 
			case 6:
			output("`3findest ein `tPergament`3, auf dem f�r die `4Schenke `6'Zur K�nigskrone' `3geworben wird und ihren `4exzellenten Wein`3..."); 
			break;
     } 
    addnav("Wege"); 
    addnav("Z?Zur�ck zum Platz","galgen.php"); 
    addnav("S?Zur�ck zur Stadt","stadttor.php"); 
} 
if ($_GET_VARS[op] == "halde") { 
	output("`3Du gehst �ber den Platz und n�herst Dich der `QAbfallhalde`3, auf der die restlichen Habseligkeiten der Deliquenten, die dem Scharfrichter einheim fielen, ebenfalls ihrem Ende fristen."); 
	output("`3Vorsichtig steigst Du den `1Hang `3herab, den Blick immer suchend zu Boden und "); 
	if ( $session[user][turns]>0 ) { 
		$session[user][turns] -=1; 
			switch(e_rand(1,15)){ 
				case 1: 
                		output("`3findest einen `5h�slichen Stock `3und noch bevor Du es richtig begreifst, da� es der des alten Mannes aus dem Wald ist, hast Du ihn schon ber�hrt, verlierst einen Charmpunkt und der Stock zerf�llt zu Staub.");
				$session[user][charm]--;
				break;
				case 2: 
                		output("`3findest einen alten `TStiefel`3, der schon fast verrottet ist.");
				break;
				case 3:
                		output("`3findest eine `tPhiolle `3mit einem Trank.");
				output("`3Du �ffnest sie, trinkst und"); 
					switch(e_rand(1,4)){ 
						case 1:
						output("`3verlierst `^1 permanenten Lebenspunkt`3."); 
						$session[user][hitpoints]--;
						break;
						case 2:
						output("`3gewinnst `^1 permanenten Lebenspunkt`3."); 
						$session[user][hitpoints]++;
						break;
						case 3:
						output("`3f�hlst Dich `6gro�artig`3!"); 
						$session[user][hitpoints]*=1.2;
						break;
						case 4:
						output("`3f�hlst Dich `4schlecht`3."); 
						$session[user][hitpoints]*=0.8;
						break;
						case 4:
						output("`3f�hlst Dich `^hervorragend `3und `^stark`3!"); 
						$session[user][hitpoints]*=1.2;
						$session[user][turns]+=3;
						break;
						case 4:
						output("`3f�hlst Dich absolut `4mies`3!"); 
						$session[user][hitpoints]*=0.8;
						$session[user][turns]-=3;
						break;
						case 4:
						output("`3stirbst! Du bist `4TOT"); 
						$session['user']['alive']=false;
						$session['user']['hitpoints']=0;
						$session['user']['gold']=0;
						$session['user']['experience']*0.95;
						addnews($session['user']['name']." starb aus Gier und wird nun zu D�nger.");
						addnav("T�gliche News","news.php");
						break;
					}
				break;
				case 4: 
                		output("`3findest einen Edelstein.");
				$session[user][gems]++;
				case 5:                     
                		output("`3findest das abgenagte `&Skelett `3einer `VKatze`3, die noch ein Halsband tr�gt, auf dem `6'LUCKY' `3steht."); 
				break; 
				case 6:
                		output("`3findest einen alten `4Strumpf`3 der erb�rmlich `4stinkt `3und in den der Name `\$Bundy `3eingen�ht ist.");
				break;
				case 7: 
                		output("`3findest einen `%h�bschen Stock`3, erkennst in ihm den des alten Mannes im Wald, nimmst ihn und bekommst einen Charmepunkt, worauf hin der Stock zu Staub zerf�llt.");
				$session[user][charm]++;
				break;
				case 8: 
				output("`3findest einen alten `7Helm`3."); 
                		output("`3Als Du ihn herum drehst, um zu sehen, ob er noch tragbar ist, springt eine `VRatte `3heraus und bei�t Dich.");
				$session[user][hitpoints]*=0.98;
				break; 
				case 9: 
				output("`3findest `^1 Golst�ck.");
				$session[user][gold]+=1;
				break;
				case 10: 
                		output("`3findest einen zerbrochenen `TKrug`3, der laut Auschrift einmal `2Richter Adam `3geh�rte.");
				break;
				case 11: 
                		output("`3findest eine alte `TSteinschleuder`3, wie Du sie als Kind mal hattest, auf dem Griff ist klein eineritzt der Name `^Bart `3zu lesen.");
				break;
				case 12: 
				output("`3 einen Stappel `TBretter`3, die Du einpackst und an `tAeki `3verkaufst, der Dir daf�r noch `6100 Gold `3gibt."); 
				$session[user][gold]+= 100; 
				break; 
				case 13:
				output("`3 einen Sack voll `@Gems`3, der im Boden fest steckt."); 
				output("`3 Als Du ihn heraus ziehen willst, stolperst Du und st�rzt r�ckw�rts die `QHalde `3herab, an deren Fu�e Du in einen `TBaumstumpf`3, der wie ein `TPfahl `3aus dem Boden ragt, st�rtzt und stirbst."); 
				output("`3Du bist `4TOT"); 
				$session['user']['alive']=false;
				$session['user']['hitpoints']=0;
				$session['user']['gold']=0;
				$session['user']['experience']*0.95;
				addnews($session['user']['name']." starb aus Gier und wird nun zu D�nger.");
				addnav("T�gliche News","news.php");
				break;
				case 14: 
                		output("`3findest einen Stapel alte `tPergamente`3, die v�llig verschmutzt und zerissen sind, nur auf dem Titell kannst Du noch die Aufschrift `^".($session[user][sex]?"Playgirl":"Playboy")." `3lesen.");
				break;
				case 15: 
				output("`3findest ein kleines S�ckchen mit `@3 Gems`3."); 
				output("`3Als Du es aufhebst, gleitest Du aus ud f�llst r�cklinks die Halde herab, wobei Du Dich schwer verletzt."); 
				$session[user][gems]+=3; 
				$session['user']['hitpoints']=1;
				break; 
			} 
	}else { 
		output("`3Du gehst �ber den Platz und n�herst Dich der `QAbfallhalde`3, auf der die restlichen Habseligkeiten der Deliquenten, die dem Scharfrichter einheim fielen, ebenfalls ihrem Ende fristen.");
		output("`3Als Du an den Abgrund trittst, schl�gt Dir ein derartiger `4Gestank `3entgegen, da� Dir �bel wird und Du beschlie�t, lieber doch nicht zu suchen.");         
		$session[user][hitpoints]*=0.99; 
	} 
	addnav("Wege"); 
    addnav("Z?Zur�ck zum Platz","galgen.php"); 
    addnav("S?Zur�ck zur Stadt","stadttor.php");  
} 
page_footer(); 
?> 