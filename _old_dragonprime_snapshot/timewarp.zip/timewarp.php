<?php

function timewarp_getmoduleinfo()
{
	$info = array
	(
		"name"			=> "Time Warp",
		"version"		=> "1.13",
		"author"		=> "RPGSL",
		"category"		=> "RPGSL",
		"download"		=> "http://www.rpdragon.com/lotgd/timewarp.zip",
		"vertxtloc"		=> "http://www.rpdragon.com/",
		"description"	=> "A time warp found in the forest that gives players a new day",
		"settings"		=> array
		(
			"Time Warp, title",
				"allowed"			=> "How many times can a character use the Time Warp in a day (not including the day gained by this module)?,int|1",
				"runonce"			=> "Should the times the character used the Time Warp only reset on each server generated new day?, bool|1",				
		),
		"prefs"			=> array
		(
			"Time Warp - Prefs, title",
				"times"				=> "How many times did this character use the Time Warp today?,int|0",
				"inuse"				=> "Is the Time Warp in use?,bool|0",
		)
	);
	return $info;
}

function timewarp_install()
{
	if (!is_module_installed("timewarp"))
	{
		output("Installing `bTime Warp`b (timewarp.php) module by Role Play Game Story Lines (www.rpgsl.com)`n`n");
	}
	else
	{
		output("Updating `bTime Warp`b (timewarp.php) module by Role Play Game Story Lines (www.rpgsl.com)`n`n");
	}
	module_addeventhook("forest", "return 20;");
	module_addhook("newday");
	module_addhook("newday-runonce");
	return true;
}

function timewarp_uninstall()
{
	output("Uninstalling `bTime Warp`b (timewarp.php) module by Role Play Game Story Lines (www.rpgsl.com)`n");
	return true;
}

function timewarp_dohook($hookname, $args)
{
	global $session;
	switch ($hookname)
	{	
		case "newday":
			if (get_module_pref('inuse'))
			{
				set_module_pref('times', get_module_pref('times') - 1);
			}
			if (!get_module_setting("runonce") && !get_module_pref('inuse'))
	       	{
				set_module_pref('times', 0);
			}
			break;
		case "newday-runonce":
        	if (get_module_setting("runonce"))
        	{
        		$sql = "update ".db_prefix("module_userprefs")." set value=0 where value<>0 and setting='times' and modulename='timewarp'";
        		db_query($sql);
        	}
			break;
	}	
	return $args;
}

function timewarp_runevent($type)
{
	global $session;
	$from = "forest.php?";
	$session['user']['specialinc'] = "module:timewarp";
	$op = httpget('op');
	if ($op == "" && !get_module_pref('inuse') || $op == "search" && !get_module_pref('inuse'))
	{
		output("`nA strange glimmer from a puddle catches your eyes. You decide to walk a little closer to see where the glimmer is coming from.`n");
		output("`nUpon closer inspection, you see that the glimmer is actually a swirling time warp of brilliant colors!`n");
		output("`nRumors have it that if you jump into the Time Warp, you will be granted a new day.`n");
		output("Do you jump in?");
		addnav("Jump in", $from."op=jump");
		addnav("Leave it be", $from . "op=nojump");
	}
	if ($op == "nojump")
	{
		$session['user']['specialinc'] = "";
		output("You decide that you don't need a new day right now and continue on in this day's adventures.`n`0");
	}
	if ($op == "jump")
	{
       	if (get_module_pref('times') < get_module_setting('allowed') && !get_module_pref('inuse'))
        {
        	output("`%`nThe forest about you swirls `@in multi-hued and luminescent `#paintstrokes of glorious `^color`7!");
        	output(" Just as your eyes widen at the grand and awesome spectacle, you feel a strong tug from within your stomach.");
        	output(" The lights flow past you in brilliant trails of speed, and with a sudden rush of air and sound engulfing you,");
        	output(" the hues flash into a pure white glow. Then with a blink of an eye, you find yourself where you first saw the puddle.");
        	output("`n`n`^You have gained a new day!`7");
        	set_module_pref('times', get_module_pref('times') + 2);
        	set_module_pref('inuse', 1);
			addnav("Continue", "newday.php");
		}
        else
        {
        	if (!get_module_pref('inuse'))
        	{
        		output("`nAs you jump into the air, the puddle evaporates into a bewildering and sparkling cloud before dissipating!");
        		output("The bedazzlement makes you lose your balance and you land right upon your rump!`n");
				$session['user']['specialinc'] = "";
        	}
        	else
        	{
        		output("`n`c`b`#You feel refreshed and ready to start the day anew!`0`b`c`n");
	       		set_module_pref('inuse', 0);
				$session['user']['specialinc'] = "";
	       	}
        }
	}
}

function timewarp_run()
{
}

?>