Race - Time Warp

Version 1.13

Download: http://rpdragon.com/lotgd/timewarp.zip
Mirror: http://rpgsl.com/lotgd/timewarp.zip

Game: http://rpdragon.com/


Installation

1) Copy timewarp.php into your LotGD modules folder
2) Log in to LotGD with your admin account
3) Enter the Superuser Grotto
4) Click Manage Modules
5) Install timewarp.php (Time Warp)
6) Configure settings and save
7) Activate


Questions/Comments?

alex@rpgsl.com


Visit www.rpgsl.com today for your RPG needs.