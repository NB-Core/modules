lib/module.php

function injectmodule($modulename,$force=false){
	global $mostrecentmodule,$injected_modules;
	//early escape if we already called injectmodule this hit with the same args.
	
	if (isset($injected_modules[$force][$modulename])) {
		$mostrecentmodule=$modulename;
		return $injected_modules[$force][$modulename];
	}
	
	$modulename = modulename_sanitize($modulename);
	$modulefilename = "modules/{$modulename}.php";
	if (file_exists($modulefilename)){
		tlschema("module-{$modulename}");
		$sql = "SELECT active,filemoddate,infokeys,version FROM " . db_prefix("modules") . " WHERE modulename='$modulename'";
		$result = db_query_cached($sql, "inject-$modulename", 3600);
		
		if (!$force) {
			//our chance to abort if this module isn't currently installed or doesn't meet the prerequisites.
			if (db_num_rows($result)==0) {
				$injected_modules[$force][$modulename]=false;
				return MODULE_NOT_INJECTED;
			}
			$row = db_fetch_assoc($result);
			if ($row['active']){ } else { 
				$injected_modules[$force][$modulename]=false;
				return MODULE_NOT_INJECTED; 
			}
		}
		require_once($modulefilename);
		$mostrecentmodule = $modulename;
		$info = "";
		if (!$force){
			//avoid calling the function if we're forcing the module
			$fname = $modulename."_getmoduleinfo";
			$info = $fname();
			if (!isset($info['requires'])) $info['requires'] = array();
			if (!is_array($info['requires'])) $info['requires'] = array();
			if (!module_check_requirements($info['requires'])) {
				$injected_modules[$force][$modulename]=false;
				return MODULE_NOT_INJECTED;
			}
		}
		//check to see if the module needs to be upgraded.
		if (db_num_rows($result)>0){
			if (!$row) $row = db_fetch_assoc($result);
			$filemoddate = date("Y-m-d H:i:s",filemtime($modulefilename));
			if ($row['filemoddate']!=$filemoddate || $row['infokeys']=="" ||
					$row['infokeys'][0] != '|' || $row['version']==''){
				//The file has recently been modified, lock tables and
				//check again (knowing we're the only one who can do this
				//at one shot)
				$sql = "LOCK TABLES " . db_prefix("modules") . " WRITE";
				db_query($sql);
				//check again after the table has been locked.
				$sql = "SELECT filemoddate FROM " . db_prefix("modules") . " WHERE modulename='$modulename'";
				$result = db_query($sql);
				$row = db_fetch_assoc($result);
				if ($row['filemoddate']!=$filemoddate ||
						$row['infokeys']=="" || $row['infokeys'][0] != '|' ||
						$row['version']==''){
					//the file mod time is still different from that
					//recorded in the database, time to update the database
					//and upgrade the module.
					debug("The module $modulename was found to have updated, upgrading the module now.");
					if (!is_array($info)){
						//we might have gotten this info above, if not, we need it now.
						$fname = $modulename."_getmoduleinfo";
						$info = $fname();
					}
					//Everyone else will block at the initial lock tables,
					//we'll update, and on their second check, they'll fail.
					//Only we will update the table.
					
					$keys = "|".join(array_keys($info), "|")."|";
					
					$sql = "UPDATE ". db_prefix("modules") . " SET moduleauthor='".addslashes($info['author'])."', category='".addslashes($info['category'])."', formalname='".addslashes($info['name'])."', filemoddate='$filemoddate', infokeys='$keys',version='".addslashes($info['version'])."',download='".addslashes($info['download'])."' WHERE modulename='$modulename'";
					db_query($sql);
					$sql = "UNLOCK TABLES";
					db_query($sql);
					// Remove any old hooks (install will reset them)
					module_wipehooks();
					$fname = $modulename."_install";
					$fname();
					invalidatedatacache("inject-$modulename");

				}else{
					$sql = "UNLOCK TABLES";
					db_query($sql);
				}
			}
		}
		tlschema();
		$injected_modules[$force][$modulename]=true;
		return MODULE_INJECTED;
	}else{
		$injected_modules[$force][$modulename]=false;
		return MODULE_NOT_INJECTED;
	}
}

/**
 * Checks if the module requirements are satisfied.  Should a module require other modules to be installed and active, then optionally makes them so
 *
 * @param array $reqs Requirements of a module from _getmoduleinfo()
 * @param bool $injectModule Should the module be injected
 * @return bool If successful or not
 */
function module_check_requirements($reqs, $injectModule = true){
	
	global $mostrecentmodule, $injected_Modules;
	
	// Keep a ref to the last modules used - otherwise mayhem happens if modules don't use their module name
	// Would be nice if this was an array - it would help debug module call stacks
	$oldModule = $mostrecentmodule;
	
	// Keep a ref to the last set of injected modules
	// Helps us unwind the module stack if things go pear shaped
	$oldInjectedModules = $injected_modules;
	
	if (!is_array($reqs)) return false;		// Not sure about this line JT
	// If this function gets called an their are no requirements - the function would indicate failure

	reset($reqs);
	
	while (list($key,$val)=each($reqs)){
		$info = explode("|",$val);
		$thisModuleStatus = is_module_installed($key,$info[0]);
		if ($thisModuleStatus & MODULE_NOT_INSTALLED) {
			// Something that's required isn't installed
			// Let's reset to some safe data
			$mostrecentmodule = $oldModule;
			$injected_modules = $oldInjectedModules;
			// Drop out of the loop by returning
			return false;
		} else {
			// So the module is installed - first test passed
			$thisModuleStatus = $thisModuleStatus | is_module_active($key);
			if ($thisModuleStatus & MODULE_ACTIVE) {
				// So the module is installed & active
				if ($thisModuleStatus & MODULE_INJECTED) {
					// It's installed, active & injected already
					// Which means the modules functions are in the general namespace for this requirement entry
				} else {
					// The module isn't currently injected - but it's marked as installed and injected
					if ($thisModuleStatus & MODULE_VERSION_OK) {
						// Cool - The module is Installed, Active and the version is good
						if ($injectModule==true) {
							// We're being asked to inject the module
							$result = injectmodule($key,false);
							if ($result & MODULE_INJECTED) {
								// The module was injected ok - so onto the next requirement for this module
							} else {
								// The module wasn't injected ok
								// Bail early - although it'd be better to run through all the requirements
								// and setup some associative array indicating what was ok - and what wasn't
								// Let's reset to some safe data
								$mostrecentmodule = $oldModule;
								$injected_modules = $oldInjectedModules;
								return false;
							}
						} else {
							// We're not being asked to inject the module - 
							// but all the requirements have been met for this requires statement
						}
					} else {
						// The module version isn't ok
						
						// Bail early - although it'd be better to run through all the requirements 
						// and setup some associative array indicating what was ok - and what wasn't
						// Let's reset to some safe data
						$mostrecentmodule = $oldModule;
						$injected_modules = $oldInjectedModules;
						return false;
					}
				}
			} else {
				// The required module isn't Active
				// Bail early - although it'd be better to run through all the requirements
				// and setup some associative array indicating what was ok - and what wasn't
				// Let's reset to some safe data
				$mostrecentmodule = $oldModule;
				$injected_modules = $oldInjectedModules;
				return false;
			}
		}
	}
	// set mostRecentModule - back to what it was before the function was called
	// otherwise all hell breaks loose when modules don't use the modulename in settings/prefs/etc
	$mostrecentmodule = $oldModule;
	return true;
}


/**
 * Determines if a module is installed
 *
 * @param string $modulename The module name
 * @param string $version The version to check for
 * @return bool If the module is installed
 */
function is_module_installed($modulename,$version=false){
	$modulename = modulename_sanitize($modulename);
	$modulefilename = "modules/{$modulename}.php";
	
	$moduleStatus=MODULE_NOT_INSTALLED; // Default to a failure
	
	if (file_exists($modulefilename)){
		// Changed query to make use of the same query as the inject
		$sql = "SELECT active,filemoddate,infokeys,version FROM " . db_prefix("modules") . " WHERE modulename='$modulename'";
		$result = db_query_cached($sql, "inject-$modulename", 3600);
		if (db_num_rows($result)>0){
			//the module is installed.
			if ($version!==false){
				//this module is present but we care about version
				$row = db_fetch_assoc($result);
				if (module_compare_versions($row['version'],$version) < 0){
					//installed version is less than the required version
					$moduleStatus=MODULE_INSTALLED | MODULE_VERSION_TOO_LOW;
				}else{
					//installed version is new enough
					$moduleStatus = MODULE_INSTALLED | MODULE_VERSION_OK;
				}
			}else{
				//we don't care about version, and this module is present
				$moduleStatus = MODULE_INSTALLED | MODULE_VERSION_OK;
			}
		}else{
			//the module is not installed.
			$moduleStatus = MODULE_NOT_INSTALLED;
		}
	}else{
		//the module's file does not exist.
		$moduleStatus = MODULE_FILE_NOT_PRESENT;
	}
	return $moduleStatus;
}


/**
 * Returns if a module is active
 *
 * @param string $modulename The module to check
 * @return bool If the module is active or not
 */
function is_module_active($modulename){
	global $injected_modules;
	
	$modulename = modulename_sanitize($modulename);
	$modulefilename = "modules/{$modulename}.php";
	
	if (file_exists($modulefilename)){
		// Changed query to make use of the same query as the inject
		$sql = "SELECT active,filemoddate,infokeys,version FROM " . db_prefix("modules") . " WHERE modulename='$modulename'";
		$result = db_query_cached($sql, "inject-$modulename", 3600);
		if (db_num_rows($result)>0){
			$row = db_fetch_assoc($result);
			if ($row['active']){
				//module's here and active.
				if ($injected_modules[false][$modulename]==true)
					$moduleStatus = MODULE_INJECTED;

				$moduleStatus=$moduleStatus | MODULE_INSTALLED | MODULE_ACTIVE;
			}else{
				//module's here but not active.
				$moduleStatus=MODULE_INSTALLED | MODULE_NOT_ACTIVE;
			}
		}else{
			//the module is not installed.
			$moduleStatus=MODULE_NOT_INSTALLED | MODULE_NOT_ACTIVE;
		}
	}else{
		//the module's file does not exist.
		$moduleStatus=MODULE_FILE_NOT_PRESENT | MODULE_NOT_ACTIVE;
	}
	return $moduleStatus;
}


lib/constants.php
define("MODULE_INJECTED",true);
define("MODULE_NOT_INJECTED",(!MODULE_INJECTED));
define("MODULE_INSTALLED",2);
define("MODULE_VERSION_OK",4);
define("MODULE_NOT_INSTALLED",8);
define("MODULE_FILE_NOT_PRESENT",16);
define("MODULE_VERSION_TOO_LOW",32);
define("MODULE_ACTIVE",128);
define("MODULE_REQUIREMENTS_OK",256);
define("MODULE_NOT_ACTIVE", 512);
