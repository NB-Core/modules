-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
House System - Cellar - A module for Legend of the Green Dragon 0.9.8

Legend of the Green Dragon
by  Eric "MightyE" Stevens (http://www.mightye.org)
and JT "Kendaer" Traub (http://www.dragoncat.net)

Software Project Page:
http://sourceforge.net/projects/lotgd

Modification Community Page:
http://dragonprime.net

Author of this Module:
Original - Rowne-Wuff Mastaile
Altered by - Enderandrew (enderandrew@gmail.com)

Enderandrew's LoGD game:
http://enderandrew.com/lotgd/

Download the latest version of this module from:
http://dragonprime.net/index.php?action=viewfiles&user=enderwiggin

----------------------------------------------
-- STATUS: -----------------------------------
----------------------------------------------
This module is STABLE.

----------------------------------------------
-- INFORMATION: ------------------------------
----------------------------------------------
This is Rowne's module.  I made a few small changes to the module.
Namely, I fixed a bug where cellar_travel() was being called, but
the function didn't exist.  I also optimized the code, and shorted
the length of the script.

----------------------------------------------
-- INSTALLATION: -----------------------------
----------------------------------------------
Copy housecellar.php within this zip into your modules directory.

Login to the Superuser Grotto and Install / Activate it.

-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-