<?php
require_once("lib/nltoappon.php");
function aboutinfo_getmoduleinfo(){
	$info = array(
		"name"=>"About Page Server Info",
		"author"=>"Chris Vorndran",
		"version"=>"1.01",
		"category"=>"General",
		"download"=>"http://dragonprime.net/index.php?module=Downloads;sa=dlview;id=72",
		"vertxtloc"=>"http://dragonprime.net/users/Sichae/",
		"allow_anonymous"=>1,
		"settings"=>array(
			"Server Info,title",
				"This information shall appear on the about page of the game.,note",
				"Normally you have to edit the about.php itself to put in this info.,note",
				"info"=>"Server Info:,textarea|",
				"To add images use the HTML code for an image with single quote (') for the src attribute.,note",
			),
		);
	return $info;
}
function aboutinfo_install(){
	module_addhook("about");
	return true;
}
function aboutinfo_uninstall(){
	return true;
}
function aboutinfo_dohook($hookname,$args){
	global $session;
	switch ($hookname){
		case "about":
			if (get_module_setting("info") <> "") output_notl("%s",nltoappon(get_module_setting("info")),true);
			break;
		}
	return $args;
}
?>