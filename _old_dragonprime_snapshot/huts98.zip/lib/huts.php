<?php
	global $session;
	$op = httpget('op');
	$converse = $_POST['converse'];
	$hut = httpget('hut');
	$whatname = "hut".$hut."name";
	$whatsex = "hut".$hut."sex";
	if (get_module_setting($whatsex) == "she"){
		$hisher = "her";
	}else{
		$hisher = "his";
	}
	page_header(get_module_setting($whatname)."'s House");
	output("`c`b`&%s's House`0`b`c`n`n",get_module_setting($whatname));
	if ($op == ""){
		output("%s has one of the only huts right in the village, it's also rumored that %s`n",get_module_setting($whatname),get_module_setting($whatsex));
		output("likes to hide things all about %s house.`n`n",$hisher);
	}
	$cupfind=e_rand(1,100);
	$bedfind=e_rand(1,100);
	$boardsfind=e_rand(1,100);
	$garbagefind=e_rand(1,100);
	$mattressfind=e_rand(1,100);
	addnav("Go Somewhere");
	villagenav();
	if ($op == ""){
	if (e_rand(1,100) > 25){
	addnav("Explore");
	output("No one seems to be home.`n");
	output("Would you like to explore %s's House or Return to %s?",get_module_setting($whatname),$session['user']['location']);
	addnav("Explore","runmodule.php?module=huts&hut=$hut&op=explore");
	}else{
		output("`4Darn it anyway, %s is home.`n",get_module_setting($whatname));
		output("`6%s Welcomes you at the Door`n",get_module_setting($whatname));
		output("`7%s Says \"Welcome, %s`7 please come in\"`n",get_module_setting($whatname),$session['user']['name']);
		output("`7Will you accept %s invitation or return to %s?`n",$hisher,$session['user']['location']);
		addnav(array("Go in and Talk with %s",get_module_setting($whatname)),"runmodule.php?module=huts&hut=$hut&op=talk");
		}
	}
	if ($op == "explore" ){
	if (get_module_pref('searches') > 0){
	addnav("Explore");
	addnav("Check the Cupboards","runmodule.php?module=huts&hut=$hut&op=cupboards");
	addnav("Look under the Bed","runmodule.php?module=huts&hut=$hut&op=bed");
	addnav("Check for Loose Floorboards","runmodule.php?module=huts&hut=$hut&op=boards");
	addnav("Rummage through the garbage","runmodule.php?module=huts&hut=$hut&op=garbage");
	addnav("Check under the Mattress","runmodule.php?module=huts&hut=$hut&op=mattress");	
	output("You do realize that taking things from this house is stealing, don't you?");
	}else{
		output("`4You are too tired to search anymore today.`n");
	}
	}
	if ($op == "talk" ){
		talkto($converse,get_module_setting($whatname));
		output("`nTalk to %s`n",get_module_setting($whatname)); 
		output("<form action='runmodule.php?module=huts&hut=$hut&op=talk' method='POST'><input name='converse' id='converse'><input type='submit' class='button' value='Say It'></form>",true); 
		output("<script language='JavaScript'>document.getElementById('converse').focus();</script>",true); 
		addnav("","runmodule.php?module=huts&hut=$hut&op=talk");
	}
	if ($op == "cupboards" ){
		output("`7You Search through the Cupboards and find ");
		set_module_pref('searches',(get_module_pref('searches') - 1));
		if ($cupfind > 82){
			if (is_module_active('usechow') and e_rand(1,6) == 3){
				$uchow  = get_module_pref("chow", "usechow");
							for ($i=0;$i<6;$i+=1){
								$chow[$i]=substr(strval($uchow),$i,1);
								if ($chow[$i] > 0) $userchow++;
							}
							if ($userchow<5){
								switch(e_rand(1,7)){
									case 1:
										output("`^ a slice of bread!`0");
										for ($i=0;$i<6;$i+=1){
											$chow[$i]=substr(strval($uchow),$i,1);
											if ($chow[$i]=="0" and $done < 1){
												$chow[$i]="1";
												$done = 1;
											}
											$newchow.=$chow[$i];
										}
										break;
									case 2:
										output("`^ a Pork Chop!`0");
										for ($i=0;$i<6;$i+=1){
											$chow[$i]=substr(strval($uchow),$i,1);
											if ($chow[$i]=="0" and $done < 1){
												$chow[$i]="2";
												$done = 1;
											}
											$newchow.=$chow[$i];
										}
										break;
									case 3:
										output("`^ a Ham Steak!`0");
										for ($i=0;$i<6;$i+=1){
											$chow[$i]=substr(strval($uchow),$i,1);
											if ($chow[$i]=="0" and $done < 1){
												$chow[$i]="3";
												$done = 1;
											}
											$newchow.=$chow[$i];
										}
										break;
									case 4:
										output("`^ a Steak!`0");
										for ($i=0;$i<6;$i+=1){
											$chow[$i]=substr(strval($uchow),$i,1);
											if ($chow[$i]=="0" and $done < 1){
												$chow[$i]="4";
												$done = 1;
											}
											$newchow.=$chow[$i];
										}
										break;
									case 5:
										output("`^ a Whole Chicken!`0");
										for ($i=0;$i<6;$i+=1){
											$chow[$i]=substr(strval($uchow),$i,1);
											if ($chow[$i]=="0" and $done < 1){
												$chow[$i]="5";
												$done = 1;
											}
											$newchow.=$chow[$i];
										}
										break;
									case 6:
										output("`^ a bottle of milk!`0");
										for ($i=0;$i<6;$i+=1){
											$chow[$i]=substr(strval($uchow),$i,1);
											if ($chow[$i]=="0" and $done < 1){
												$chow[$i]="6";
												$done = 1;
											}
											$newchow.=$chow[$i];
										}
										break;
									case 7:
										output("`^ a bottle of Water!`0");
										for ($i=0;$i<6;$i+=1){
											$chow[$i]=substr(strval($uchow),$i,1);
											if ($chow[$i]=="0" and $done < 1){
												$chow[$i]="7";
												$done = 1;
											}
											$newchow.=$chow[$i];
										}
										break;
								}
								set_module_pref('chow', $newchow, 'usechow');
							}else{
								output("nothing.`n");
							}
			}else{
				find();
			}
			addnav("Continue","runmodule.php?module=huts&hut=$hut&op=explore");
		}else{
			output("nothing.`n");
			addnav("Continue","runmodule.php?module=huts&hut=$hut&op=explore");
		}
	}
	if ($op == "bed" ){
		output("`7You Search under the bed and find ");
		set_module_pref('searches',(get_module_pref('searches') - 1));
		if ($bedfind > 82){
			find();	
			addnav("Continue","runmodule.php?module=huts&hut=$hut&op=explore");
		}else{
			output("nothing.`n");
			addnav("Continue","runmodule.php?module=huts&hut=$hut&op=explore");
		}
	}
	if ($op == "boards" ){
		output("`7You Search the floor and find a loose board you lift it and find ");
		set_module_pref('searches',(get_module_pref('searches') - 1));
		if ($boardsfind > 82){
			if (is_module_active('potions') and e_rand(1,6) == 3){
				$upotion = get_module_pref('potion', 'potions');
				if ($upotion<5){
					output("a Healing Potion!");
					set_module_pref('potion', ++$upotion, 'potions');
				}else{
					output("nothing.`n");
				}
			}else{
			find();
			}
			addnav("Continue","runmodule.php?module=huts&hut=$hut&op=explore");		
		}else{
			output("nothing.`n");
			addnav("Continue","runmodule.php?module=huts&hut=$hut&op=explore");
		}
	}
	if ($op == "garbage" ){
		if (is_module_active('odor') and e_rand(1,3) == 3){
			set_module_pref('odor',(get_module_pref('odor','odor') - 1),'odor');
		}
		if (e_rand(1,100) > 89){
			output("`4The town gossip see's you digging through the garbage!`n");
			output("`4Now everyone is going to know!`n");
			output("`4You loose 1 Charm!`n");
			$session['user']['charm']-=1;
			$name = $session['user']['name'];
			addnews("$name`7 was caught going through the garbage!");
		}
		output("`7You dig through the garbage and find ");
		set_module_pref('searches',(get_module_pref('searches') - 1));
		if ($garbagefind > 82){
			find();
			addnav("Continue","runmodule.php?module=huts&hut=$hut&op=explore");		
		}else{
			output("nothing.`n");
			addnav("Continue","runmodule.php?module=huts&hut=$hut&op=explore");
		}
	}
	if ($op == "mattress" ){
		output("`7You lift up the mattress and find ");
		set_module_pref('searches',(get_module_pref('searches') - 1));
		if ($mattressfind > 82){
			find();
			addnav("Continue","runmodule.php?module=huts&hut=$hut&op=explore");		
		}else{
			output("nothing.`n");
			addnav("Continue","runmodule.php?module=huts&hut=$hut&op=explore");
		}
	}
	page_footer();
?>