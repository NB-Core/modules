<?php
function talkto($talk,$who){
	global $session;
	if ($talk <> ""){
		output("You say: \" %s \"`n",stripcslashes($talk));
		//everything is in order here.... word 1 = response 1 and so on
		$words = array(
			"haunt",
			"why",
			"village",
			"dragon",
			"green dragon",
			"hitpoints",
			"attack",
			"defense",
			"charm",
			"gold",
			"gems",
			"search",
			"castle",
			"ghost",
			"spirit",
			"wine",
			"the inn",
			"darkhorse tavern",
			"warrior training",
			"forest",
			"stupid",
			"ugly",
			"gift shop",
			"diner",
			"confession",
			"library",
			"guest room",
			"bedroom",
			"haunted",
			"nursery",
			"gardens",
			"great hall",
			"the keep",
			"dining room",
			"kitchen",
			"storage room",
			"attic",
			"basement",
			"dungeon",
			"bathroom",
			"ballroom",
			"tower",
			"trading post",
			"potion",
			"voodoo",
			"title",
			"village idiot",
			"villageidiot",
			"undead",
			"baby",
			"healer",
			"love",
			"me angry",
			"kill something",
			"hello",
			"kill you",
			"thanks",
			"thank you",
			"bye",
			"goodbye",
			"moejo",
			"how are you",
			"fox pelt",
			"fish eye",
			"worms",
			"bat wing",
			"eye of newt",
			"puppy dog tail",
			"frog leg",
			"wort",
			"shrunken head",
			"wool",
			"cloth",
			"leather",
			"next level",
			"you are dumb",
			"fight",
			"fart",
			"graveyard",
			"grave yard",
			"house dirty",
			"house messy",
			"hut dirty",
			"hut messy",
			"u have any money",
			"how are you",
			"how old are you",
			"money",
			"currency",
			"king",
			"hero",
			"dwarf",
			"death",
			"haunting",
			"mail",
			"weapon",
			"armor",
			"slumming",
			"thrillseeking",
			"curious looking rock",
			"drunk",
			"drink",
			"cedrick",
			"dag drunick",
			"violet",
			"seth",
			"bard",
			"barkeep",
			);
			$response = array(
			"One can haunt those in the living world when they are dead.",
			"Why what?",
			"The Village Square is the center of all here.  You can get everywhere from there.  You will find many warriors talking there.",
			"The dragon is a fierce creature, it is feared by all.  You should be wary if you encounter such a beast.",
			"Many warriors seek out the Green Dragon train hard my friend and you will become a hero of the realm.",
			"Your hitpoints are very important, when they hit 0 you are dead!",
			"Your attack is how powerful your attack is, this includes your weapons.",
			"Your defense is very important, the higher the number the more you can withstand.  Be sure to buy the best armor.",
			"Charm is a level of how attractive you are, raise this up and other warriors will be attracted to you.",
			"There are lots of places to find gold in the realm, the most common is on forest creatures.  They like to collect shiny items and many of them carry lots of gold.",
			"Gems are hard to come by, once you find a few.  Buy some items at the mall or trading post and trade them to earn more gems.  If you can earn alot of gems you can get yourself a sweet ride.",
			"Searching for items in places can turn up alot of useful things.  Be sure to look everywhere that you are able.",
			"The biggest and finest castle in the realm is ".get_module_setting('castleloc','lonnycastle')." Castle.  Beware however the place is haunted.",
			"There are ghosts everywhere, some of them are even dead warriors.  I hear that Lonny's castle is full of wandering spirits.",
			"Be careful, some spirits are helpful... and then there are the ones that are rather evil.  Many a warrior has fallen at the hands of a vengeful spirit.",
			"Rumor has it there is a great wine cellar in the basement of ".get_module_setting('castleloc','lonnycastle').".",
			"The inn is a great place to rest after a hard day of fighting.  You are much safer there from other warriors who might like a piece of you.",
			"Darkhorse tavern is a strange and quiet place deep in the woods.  I have never been there, so I can't tell you too much.",
			"Warrior training is found in the village.  This is a place for you to train and advance a level.  When you get to level 15 you are mature enough to seek out the Green Dragon.",
			"The forest is vast and filled with many fearsom creatures.  This is the best place to gain experience, so you can beat your master and advance a level.",
			"I would watch who you are calling stupid!  You are stupid!",
			"I would watch who you are calling ugly!  DogFace!",
			"The various gift shops are great places to buy gifts for other warriors.",
			"The Diner is a great place to get a meal.  You need to eat to stay healthy.",
			"Confessing your sins in the castle chapel will help keep you on the good side of the constable.",
			"Stop by the library in ".get_module_setting('castleloc','lonnycastle')." to brush up on your knowlege.",
			"The Castle Guest Room is a great place to rest, beware though I hear there is a pretty nasty ghost hanging around in there.",
			"The Castle Bedroom is a nice place to nap, however I hear it is haunted.",
			"There are many places in the realm that are haunted by spirits and ghosts some of them are even other warriors who have recently passed on.",
			"Once upon a time there were 4 young children who were taken care of in the Nursery, someone still to this day fills a baby bottle with milk for the long gone babies.",
			"The Gardens are a wonderful place to relax.",
			"The Great Hall in ".get_module_setting('castleloc','lonnycastle')." is a huge an beautiful area of the castle.",
			"The keep is filled with old and no longer used weapons and armor.",
			"The dining room is used for huge feasts for the nobility in the realm.  Some of the best food ever eaten is served in the dining room of ".get_module_setting('castleloc','lonnycastle').".",
			"Huge feasts are cooked by chefs in the Kitchen of ".get_module_setting('castleloc','lonnycastle').".  Some of the finest meals ever eaten are prepared in that kitchen.",
			"The storage room is used to store supplies for the kitchen.  It also has accesses to the attic and the basement.",
			"I have heard stories of a lost soul in the attic of ".get_module_setting('castleloc','lonnycastle').".",
			"There is plenty of wine in the basement of ".get_module_setting('castleloc','lonnycastle').".  I have also heard it told that if you look hard enough you will find the dungeon",
			"I have heard there is a Dungeon in ".get_module_setting('castleloc','lonnycastle').".  Few have seen it, and even fewer have come out.",
			"The bathroom is a great place to relieve yourself, and there is a mirror in there to take a good look at yourself.",
			"The ballroom in ".get_module_setting('castleloc','lonnycastle')." used to hold grand events.  Tales be told of some lost spirits still there longing for those grand events of days past.",
			"The towers of the Castle are great for taking a good look around.",
			"The Trading Posts are for buying and selling goods for a profit.",
			"The Healer cooks up some pretty good potions.",
			"The Voodoo Priestess can cast spells on anyone in the realm, even you.",
			"Titles are used as classes here, you can get new titles by slaying the dragon.  And there are titles for perfoming special actions.  Village Idiot is one such title.",
			"There can be only one Village Idiot.  If there is on you will see a sign in the village proclaiming who it is.",
			"There can be only one Village Idiot.  If there is on you will see a sign in the village proclaiming who it is.",
			"Watch out for those who are undead, they are very hard to dispense.",
			"Baby's are very small people who take their food from a bottle.",
			"The healer can patch you up when you have been beaten up pretty bad, or when you do something stupid and get hurt.",
			"I Love YOU! Come here you little cutie!",
			"You should learn to control your anger.  Anger serves no real purpose.",
			"The forest is the place for killing things.",
			"Hello to you too.",
			"Bring it on Wimp.",
			"You're welcome.",
			"You're welcome.",
			"Goodbye.",
			"Bye Bye Now.",
			"You got no moejo my friend.",
			"I am fine, Thank You.",
			"Fox Pelts are available at the various trade establishments.",
			"Fish Eyes are available at the various trade establishments.",
			"Worms are available at the various trade establishments.",
			"Bat Wings are available at the various trade establishments.",
			"Eye of Newt is available at the various trade establishments.",
			"Puppy Dog Tails are available at the various trade establishments.",
			"Frog Legss are available at the various trade establishments.",
			"Wort is available at the various trade establishments.",
			"Shrunken Heads are available at the various trade establishments.",
			"Wool is available at the various trade establishments.",
			"Cloth is available at the various trade establishments.",
			"Leather is available at the various trade establishments.",
			"To move up to the next level and attain a new title.... KILL THE DRAGON!",
			"No, you are dumb.",
			"If you really want to fight, head out the the forest.",
			"Something smells in here.... was that you?  Man you stink!",
			"The Graveyard is where you end up when you die.  Spirits in the Graveyard may haunt other players!",
			"The Graveyard is where you end up when you die.  Spirits in the Graveyard may haunt other players!",
			"Yah, like your place is any better.",
			"Yah, like your place is any better.",
			"Yah, like your place is any better.",
			"Yah, like your place is any better.",
			"I've got tons of Money!  As a matter of fact I am rich.  But You are not getting any of it.",
			"I am fine thank you.",
			"I'm not telling you my age.",
			"We use gold for our currency here.",
			"We use gold for our money here.",
			"The real king is the admin of this game.  Make sure you follow the rules here, or the king might have you thrown in jail.",
			"Hero's are those who kill the dragon!  Be sure to check the Hall 'o fame to see who the hero's of the realm are.",
			"A dwarf is a small humanoid creature that smells very bad.",
			"Death comes to those in the realm who are not strong enough.",
			"A haunting is when a spirit interferes with the living world.",
			"Ye Olde Mail is a great way to communicate with other warriors.",
			"Weapon's are attained at the Weapon Shop in the village.",
			"Armor is attained at the Armor Shop in the village.",
			"When one goes slumming you are looking for creatures that are less powerful than normal.",
			"When one goes thrillseeking you are looking for creatures that are more powerful than normal.",
			"Yes it is awfully curious looking isn't it",
			"Drinking too much can make you that way... it can have adverse affects on you.",
			"One may get a drink at the inn... be careful however more than one is not good.",
			"Cedrick is the barkeep at the inn.",
			"Dag Durnick is a shady fellow... he hangs out at the inn.  Be careful of him, he may put a bounty on your head.",
			"Violet is the waitress at the inn.  That's all I can tell you about her.",
			"Seth is the bard at the inn.  That's all I can tell you about him.",
			"Seth is the bard at the inn.  That's all I can tell you about him.",
			"Cedrick is the barkeep at the inn.",
			);
			$talk = trim($talk);
			$talk = strtolower($talk);
			$talk = strip_tags($talk);
			// $i<= should equal the number or keywords and responses
			for ($i=0;$i<=107;$i++){
			if (strstr($talk, $words[$i]) !=""){
				$reply=$response[$i];
								
			}
		}
			$sql = "SELECT words FROM ".db_prefix("nastywords");
			$result = db_query($sql);
			$row = db_fetch_assoc($result);
			$bwords = str_replace(" ",",",$row['words']);
			$bwords = str_replace(",,",",",$bwords);
			$bwords = str_replace("*","",$bwords);
			$badwords = explode(",",$bwords);
			for ($i=0;$i<1000;$i++){
    			if ($badwords[$i] == "") $i =1000;
    			//lets not slap them for words like massive and assist
    			if ($badwords[$i] == "ass") $badwords[$i] = " asshole";
    			if ($badwords[$i] == "hell") $badwords[$i] = " hell ";
				if ($badwords[$i] <> "" and strstr($talk, $badwords[$i]) !=""){
				$reply="I will not tolerate vulgar language!  You loose charm for talking like that!";
				$session['user']['charm']--;
			}
		}
	if ($reply == ""){
		switch(e_rand(1,12)){
			case 1:
			$reply = "I don't quite understand.";
			break;
			case 2:
			$reply = "Could you rephrase that.";
			break;
			case 3:
			$reply = "Try speaking english.";
			break;
			case 4:
			$reply = "I am not sure what you are talking about.";
			break;
			case 5:
			$reply = "Try asking me something about the realm.";
			break;
			case 6:
			$reply = "My knowledge is limited, ask me something about the village.";
			break;
			case 7:
			$reply = "Your not making any sense.";
			break;
			case 8:
			$reply = "Ask me something else.";
			break;
			case 9:
			$reply = "Could you illiterate a little better.";
			break;
			case 10:
			$reply = "Really, you don't say.";
			break;
			case 11:
			$reply = stripcslashes($talk);
			break;
			case 12:
			$relpy = "Why do you say that.";
			break;
		}
}
	output("%s says: \"%s\"`n",$who,$reply);
}
}
?>