<?php
function huts_getmoduleinfo(){
	$info = array(
		"name"=>"Huts",
		"version"=>"2.1",
		"author"=>"`#Lonny Luberts",
		"category"=>"PQcomp",
		"download"=>"http://www.pqcomp.com/modules/mydownloads/visit.php?cid=3&lid=6",
		"vertxtloc"=>"http://www.pqcomp.com/",
		"settings"=>array(
			"Huts Module Settings,title",
			"hut1loc"=>"Where does Hut 1 appear,location|".getsetting("villagename", LOCATION_FIELDS),
			"hut1name"=>"Name of occupant Hut 1,text|Abby",
			"hut1sex"=>"Sex (he/she) of occupant Hut 1,text|she",
			"hut2loc"=>"Where does Hut 2 appear,location|".getsetting("villagename", LOCATION_FIELDS),
			"hut2name"=>"Name of occupant Hut 2,text|Blayze",
			"hut2sex"=>"Sex (he/she) of occupant Hut 2,text|he",
			"hut3loc"=>"Where does Hut 3 appear,location|".getsetting("villagename", LOCATION_FIELDS),
			"hut3name"=>"Name of occupant Hut 3,text|Hopper",
			"hut3sex"=>"Sex (he/she) of occupant Hut 3,text|he",
			"maxsearches"=>"Maximum Hut searches per day,int|25",
		),
		"prefs"=>array(
			"Huts Module User Preferences,title",
			"searches"=>"Hut searches left,int|25",
		),
	);
	return $info;
}

function huts_install(){
	if (is_module_active('lonnycastle')){
	if (!is_module_active('huts')){
		output("`4Installing Huts Module.`n");
		if (!is_module_active('voodoopriestess')){
			output("`4Warning: The Characters in the huts refer to the Voodoo Priestess which is not an active module.`n");
			output("`4Warning: The module will however run correctly.`n");
		}
		if (!is_module_active('trading')){
			output("`4Warning: The Characters in the huts refer to the Trading Module which is not an active module.`n");
			output("`4Warning: The module will NOT run correctly.`n");
		}
		if (!is_module_active('pqgiftshop')){
			output("`4Warning: The Characters in the huts refer to the Gift Shop which is not an active module.`n");
			output("`4Warning: The module will however run correctly.`n");
		}
	}else{
		output("`4Updating Huts Module.`n");
	}
	module_addhook("village");
	module_addhook("newday");
	}else{
		output("`4Lonny's Castle Not Installed!  Not Hooking!`n");
	}
	return true;
}

function huts_uninstall(){
	output("`4Un-Installing Huts Module.`n");
	return true;
}

function huts_dohook($hookname,$args){
	global $session;
	switch($hookname){
	case "newday":
		set_module_pref('searches',get_module_setting('maxsearches'));
	break;
	case "village":
	$town=$session['user']['location'];
			if ($session['user']['location'] == get_module_setting("hut1loc")){
			tlschema($args['schemas']['tavernnav']);
    		addnav($args['tavernnav']);
    		tlschema();
			addnav(array("%s's Hut",get_module_setting('hut1name')),"runmodule.php?module=huts&hut=1");
			}
			if ($session['user']['location'] == get_module_setting("hut2loc")){
			tlschema($args['schemas']['tavernnav']);
    		addnav($args['tavernnav']);
    		tlschema();
			addnav(array("%s's Hut",get_module_setting('hut2name')),"runmodule.php?module=huts&hut=2");
			}
			if ($session['user']['location'] == get_module_setting("hut3loc")){
			tlschema($args['schemas']['tavernnav']);
    		addnav($args['tavernnav']);
    		tlschema();
			addnav(array("%s's Hut",get_module_setting('hut3name')),"runmodule.php?module=huts&hut=3");
			}
	break;
	}
	return $args;
}

function huts_run(){
	global $SCRIPT_NAME;
	if ($SCRIPT_NAME == "runmodule.php"){
		require_once("modules/lib/huts_func.php");
		include("modules/lib/huts.php");
	}
}

?>