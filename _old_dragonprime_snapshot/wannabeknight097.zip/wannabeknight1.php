<?
/********************
Wannabe Knight #1 
Wannabe Knight script with option to give chase.
Written by Robert for Maddnet LoGD
Drop into your Specials folder
*********************/
if (!isset($session)) exit();
$name=$session[user][name]; 
if ($HTTP_GET_VARS[op]==""){
     output(" `^You have come across a `b`4Wannabe Knight`b `^who attack's you with his Battle Axe,`n");
     output(" `^you are quick! Your {$session['user']['armor']} protects you and are not injured!`n");
     output(" `^ You fend off the `b`4Wannabe Knight`b `^until he turns and runs away!`n");
     output(" `^You have already gained 2% experience! `n");
     output(" You notice he is hurt, running slow and maybe you should chase after him to finish him off, `n");
     output(" You will lose a forest fight if you do. `&What do you do? `n ");
     output(" Chase after him with bloodlust in your eye's or return to the forest to face other creatures? ");
     $session[user][experience]*=1.02;
     addnav("Wannabe Knight");
     addnav("(C) Chase after him","forest.php?op=chase");
     addnav("(R) Return to forest","forest.php?op=dont"); 
     $session[user][specialinc]="wannabeknight1.php";
}else if ($HTTP_GET_VARS[op]=="chase"){
        output(" `^You decided to give chase after the `4Wannabe Knight, `n ");
        output(" `^your not so sure you did the the right thing, but you wanted revenge for him ambushing you `n");
        output(" `^like he did. You catch up to the `4Wannabe Knight `^who quickly turns, raises his Battle Axe and ..`n ");
        $session[user][turns]--;
        switch(e_rand(1,5)){
	        case 1:
                output(" `^before you could raise your {$session['user']['armor']}, you are badly injured!");
                output(" The `4Wannabe Knight `^spares your life, turns and walks away. ");
                output(" `^The severity of your wounds cause you to lose 2 Forest Fights!");
                $session[user][turns]-=2;
                break;
            case 2:
                output(" `^you are quick with your {$session['user']['armor']} and you are not injured!`n");
                output(" `^ You fight with the `4Wannabe Knight `^fending off each attack of his Battle Axe `n");
                output(" You manage to hit him a few times and once again he turns and runs away. `n");
                output(" You too weary to give chase once more but have learned a few things!`n");
                output(" `^You gain 2% experience!`n");
                $session[user][alive]=true;
                $session[user][experience]*=1.02;
                break;
            case 3:
                output(" `^swings for your chest, your {$session['user']['armor']} fails to protect you. `n");
                output(" One mighty blow of his Battle Axe knocks you down. Sparing your life, he turns and walks away`n");
                output(" `^You are badly injured, and find revenge not to be a good thing. `n");
                output(" `^You lose 5% of experience! `n");
                $session[user][alive]=true;
                $session[user][hitpoints]=2;
                $session[user][experience]*=0.95;
                break;
            case 4:
                output(" `^swings for your chest, you're too slow and your {$session['user']['armor']} fails to protect you`n");
                output(" `5You have Died! `n");
                output(" `^You lose 10% of your experience.`n"); 
                output(" You may continue playing again tomorrow."); 
                $session[user][alive]=false; 
                $session[user][hitpoints]=0; 
                $session[user][experience]*=0.9; 
                $session[user][gold] = 0; 
                addnav("(D) Daily News","news.php"); 
                addnews(" $name `2was slain by the `4Wannabe Knight`2.`0"); 
                break;
            case 5: 
                output("`^ I'll slay thee $name `^but I mean ye no harm!");
                output(" I was giving chase after a Treacherous Troll. When I attacked ye, I thought him to be you. `n");
                output(" When me mind cleared a bit and seen ye were not the Troll, I am ashamed to say `n");
                output(" that I turned and ran away. To keep this between you and I. I will give ye `5$gold gold ");
                output(" `^for your silence and speak of this day no more. ");
                $gold = e_rand($session[user][level]*30,$session[user][level]*80); 
                $session[user][gold]+=$gold; 
                debuglog("got $gold gold from wannabe knight");
                break;   
}
}else{ 
      output("`%Not wanting to waste your time, you head back to the forest. ");  
}
?>