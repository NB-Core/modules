<?php
//Images by Eph
function orchard_getmoduleinfo(){
	$info = array(
		"name"=>"Fruit Orchard XL",
		"author"=>"Spider, Billie Kennedy<br>Modified by `#Lonny Luberts, XL by DaveS",
		"version"=>"3.05",
		"category"=>"Village",
		"download"=>"http://www.pqcomp.com/modules/mydownloads/visit.php?cid=3&lid=106",
		"vertxtloc"=>"http://www.pqcomp.com/",
		"settings"=>array(
			"Fruit Orchard Settings,title",
			"version"=>"This the new XL version of the orchard,viewonly|1",
			"growth"=>"How many days does it take for a tree to grow?,int|10",
			"everyday"=>"Do the trees grow every single day?,bool|0",
			"Note: Select no if you only want the trees to grow when the user logs in.,note",
			"healfruit"=>"How many temp hitpoints are given per level of tree when eating fruit?,int|7",
			"treesinorchard"=>"How many different types of fruit trees are there to be the orchard?,range,1,20|20",
			"lodgeseed"=>"How many lodge points are needed to buy the 19th seed?,int|25",
			"dryrot"=>"Chance of encounter to get Fruit Tree Disease (FTD) in the Forest?,enum,0,None,1,4%,2,10%,3,25%,4,40%,5,75%,6,100%|2",
			"dryenable"=>"If FTD enabled when could they encounter it again?,enum,0,Anytime,1,1x Per System Newday,2,1x Per Newday,3,1x Per Dragonkill|3",
			"treecare"=>"Number of turns spent for a chance to save their tree if it gets Fruit Tree Disease?,int|5",
			"The current fruit tree will die if they do not spend these turns before the next newday,note",
			"treechance"=>"Percent chance tree will still die despite spending the needed turns trying to save it?,range,1,100,1|10",
			"orchardloc"=>"What city is the Orchard in?,location|".getsetting("villagename", LOCATION_FIELDS),
			"usehof"=>"Use Hall of Fame?,bool|1",
			"perpage"=>"How many trees per page in Hall of Fame?,int|25",
		),
		"prefs"=>array(
			"Fruit Orchard User Preferences,title",
			"Be careful when editing these.  If you don't fully understand what they each do you could easily break the module for the user you're editing.  If you need more explanation on then get in touch with spider at spider@spiderscripts.org.uk,note",
			"seed"=>"The level of the seed the user is currently searching for,int|0",
			"found"=>"If the user has found their current seed this is it's level,int|0",
			"tree"=>"The level of the users best tree,int|0",
			"treegrowth"=>"The number of days left for the users current tree to finish growing:,int|0",
			"dietreehit"=>"Has player encountered the Fruit Tree Disease (FTD) event?,bool|0",
			"dieingtree"=>"If player has encountered FTD they need to spend this number of turns fixing their tree still:,int|0",
			"monsterid"=>"If the user is looking for a seed found on a dead monster this is that monster's ID:,int|0",
			"monsterlevel"=>"If the user is looking for a seed found on a dead monster this is that monster's level:,int|0",
			"monstername"=>"If the user is looking for a seed found on a dead monster this is that monster's name:",
			"bankkey"=>"Has player had an offer to chat about the bank key for the 11th seed?,enum,0,No,1,Yes,2,Purchased|0",
			"mespiel"=>"Has the player heard  MightyE's spiel for the 14th seed?,bool|0",
			"meplay"=>"Has the player played MightyE's game today?,bool|0",
			"menumb"=>"Number of times player played MightyE's game:,int|0",
			"caspiel"=>"Has the player heard  Crazy Audrey's spiel for the 16th seed?,bool|0",
			"caplay"=>"Has the player played Crazy Audrey's game today?,bool|0",
			"canumb"=>"Number of times player played Crazy Audrey's game:,int|0",
			"bellyrub"=>"Number of bird's bellies that player has rubbed looking for the 17th seed:,int|0",
			"pegplay"=>"Has the player listened to Pegasus tell her story today for the 18th seed?,bool|0",
			"dragonseedage"=>"How old is the Dragon Seed?,enum,0,Not Available,1,1st Generation,2,2nd Generation,3,Ready to Collect|0",
			"hadfruittoday"=>"Has the user eaten fruit from their trees today?,bool|0",
			"user_stat"=>"Display your current fruit name or a picture in the Stat bar?,enum,0,Nothing,1,Words,2,Images|1",
		)
	);
	return $info;
}

function orchard_percent($from) {
	global $session;
	$seed = get_module_pref("seed","orchard",$session['user']['acctid']);
	$dryrot= get_module_setting("dryrot","orchard");
	$ret = 0;
	if (is_module_active("cellar")){
		if ($seed==1 && $from=="cellar") $ret = 100;
		
	}else{
		if ($seed==1 && $from=="forest") $ret = 100;
	}
	
	if ($seed==2 && $from=="forest") $ret = 100;
	
	if (is_module_active("darkalley")){
		if ($seed==9 && $from=="darkalley") $ret = 100;
	}else{
		if ($seed==9 && $from=="forest") $ret = 100;
	}
	
	if (is_module_active("quarry") && get_module_setting("alloworchard","quarry")==1 && get_module_pref("seed","orchard",$session['user']['acctid'])==15){
	}elseif ($seed==15 && $from=="forest") $ret = 100;
	
	if (is_module_active("crazyaudrey")==0 && $seed==16 && $from=="forest") $ret = 100;
	
	if ($seed==17 && $from=="forest") $ret = 100;
	if ($dryrot>0){
		if (($seed==4||$seed==6||$seed==7||$seed==10||$seed==11||$seed==14||$seed==18||$seed==19||$seed==20)&&$from=="forest"){
			if ($dryrot==1) $ret= 4;
			if ($dryrot==2) $ret= 10;
			if ($dryrot==3) $ret= 25;
			if ($dryrot==4) $ret= 40;
			if ($dryrot==5) $ret= 75;
			if ($dryrot==6) $ret= 100;
			if (get_module_pref("dietreehit","orchard",$session['user']['acctid'])==1) $ret=0;
		}
	}
	return $ret;
	
}

function orchard_install(){
	module_addhook("changesetting");
	module_addhook("village");
	module_addhook("newday");
	module_addhook("newday-runonce");
	module_addhook("ale");
	module_addhook("stables-nav");
	module_addhook("dragonkilltext");
	module_addhook("battle-victory");
	module_addhook("mausoleum");
	module_addhook("ancienthall");
	module_addhook("footer-runmodule"); //added by DaveS
	module_addhook("lodge"); 		//added by DaveS
	module_addhook("footer-armor"); // added by DaveS
	module_addhook("footer-weapons"); // added by DaveS
	module_addhook("footer-bank"); 	// added by DaveS
	module_addhook("injail");		// added by DaveS
	module_addhook("footer-hof"); 	// added by Billie Kennedy
	module_addhook("charstats");  	// added by Billie Kennedy
	module_addeventhook("forest",
		"require_once(\"modules/orchard.php\");
		return orchard_percent(\"forest\");");
	if (is_module_active("darkalley")) {
		module_addhook("darkalley");
		module_addeventhook("darkalley",
			"require_once(\"modules/orchard.php\");
			return orchard_percent(\"darkalley\");");
	}
	if (is_module_active("cellar")) {
		module_addeventhook("cellar",
			"require_once(\"modules/orchard.php\");
			return orchard_percent(\"cellar\");");
	}
	return true;
}

function orchard_uninstall(){
	return true;
}

function orchard_dohook($hookname, $args){
	global $session;
	require_once("modules/lib/orchard_func.php");
	switch($hookname){
		case "changesetting":
			if ($args['setting'] == "villagename") {
				if ($args['old'] == get_module_setting("orchardloc")) set_module_setting("orchardloc", $args['new']);
			}
		break;
		case "village":
			if ($session['user']['location'] == get_module_setting("orchardloc")){
				addnav($args["tavernnav"]);
				addnav("Fruit Orchard", "runmodule.php?module=orchard");
			}
		break;
		case "ale":
			if (get_module_pref("seed")==4){
				addnav("Other");
				addnav("Ask about fruit seed", "runmodule.php?module=orchard&op=cedrick");
			}
		break;
		case "ancienthall":
			if (get_module_pref("seed")==6){
				addnav("Other");
				addnav("Ask Odin about Seed", "runmodule.php?module=orchard&op=odin");
			}
		break;
		case "mausoleum":
			if (get_module_pref("seed")==6){
				addnav("Other");
				addnav("Ask Ramius about Seed", "runmodule.php?module=orchard&op=ramius");
			}
		break;
		case "stables-nav":
			if (get_module_pref("seed")==7){
				if (getsetting("villagename", LOCATION_FIELDS) == $session['user']['location']){
					addnav("Other");
					addnav("Search for fruit seed", "runmodule.php?module=orchard&op=stables");
				}
			}
		break;
		case "footer-bank":
			if (get_module_pref("seed")==11 && get_module_pref("bankkey")==2) addnav("Lock Box Withdrawal","runmodule.php?module=orchard&op=bank");
		break;
		case "injail":
			if (get_module_pref("seed")==12) addnav("Order Last Meal","runmodule.php?module=orchard&op=lastmeal");
		break;
		case "footer-weapons":
			if (get_module_pref("seed")==14) addnav("Ask About Avocados","runmodule.php?module=orchard&op=megame");
		break;
		case "footer-runmodule":
			$module = httpget('module');
			if ($module=='crazyaudrey' && get_module_pref("seed")==16) addnav("Mention Seeds","runmodule.php?module=orchard&op=caseed");
		break;
		case "footer-armor":
			if (get_module_pref("seed")==18) addnav("Ask About Cranberries","runmodule.php?module=orchard&op=pegcran");
		break;
		case "lodge":
			if (get_module_pref("seed")==19) addnav(array("Star Fruit Seed (%s points)", get_module_setting("lodgeseed")),"runmodule.php?module=orchard&op=starseedbuy");
		break;
		case "dragonkilltext":
			if (get_module_setting("dryenable")==3) set_module_pref("dietreehit",0);
			if (get_module_pref("seed")==10){
				output("You notice a small Cherry seed in the grass beside you, for some reason you decide to pick it up, perhaps it will be useful somewhere...");
				orchard_findseed();
			}
			if (get_module_pref("seed")==20){
				$dsage=get_module_pref("dragonseedage");
				increment_module_pref("dragonseedage");
				if ($dsage==0){
					output("`n`n`#You have a dim memory of doing something before you woke up.  You feel in your pockets and feel that they're empty; remembering something about a dragon seed.");
					output("You recollect hiding the seed amongst some dragon eggs.  Soon enough, you forget about the whole incident.");
				}elseif ($dsage==1 || $dsage==2) output("`n`n`#You have a dim memory of seeing a Dragon Seed sitting comfortably in a patch of dragon eggs. You try to remember to ask `!Elendir`# at the orchard what to do next.");			
				elseif ($dsage==3){
					output("`n`n`#You feel in your pocket and smile, feeling the warmth of a happy Dragon Seed in your pocket.");
					set_module_pref("dragonseedage",0);
					orchard_findseed();
				}
			}
		break;
		case "footer-hof":  // added by Billie Kennedy
			if(get_module_setting('usehof')){
				addnav("Warrior Rankings");
				addnav("Trees", "runmodule.php?module=orchard&op=hof");
			}
		break;
		case "charstats":
			if(get_module_pref("user_stat")>0){
				$names=array("","Apple","Orange","Pear","Apricot","Banana","Peach","Plum","Fig","Mango","Cherry","Tangerine","Grapefruit","Lemon","Avocado","Lime","Pomegranate","Kiwi","Cranberry","Star Fruit","Dragonfruit");
				$tree=get_module_pref("tree");
				if($tree>0) {
					if (get_module_pref("user_stat")==2){
						$fruitpic=".gif";
						$fruitimg=$tree.$fruitpic;
						$fruit="<img src=\"./modules/orchardimg/$fruitimg\" title=\"\" alt=\"\" style=\"width: 30px; height: 30px;\">";
						setcharstat("Personal Info", "Tree", $fruit);
					}else{
						setcharstat("Personal Info", "Tree", "`@" . $names[$tree]);				
					}
				}
			}
		break;
        case "darkalley":
			addnav("Shady Houses");
			addnav("Abandoned House", "runmodule.php?module=orchard&op=abh");
			blocknav("runmodule.php?module=abh");
		break;
		case "newday":
			if (get_module_pref("dieingtree")>0){
				set_module_pref("bankkey",0);
				set_module_pref("mespiel",0);
				set_module_pref("menumb",0);
				set_module_pref("caspiel",0);
				set_module_pref("canumb",0);
				set_module_pref("bellyrub",0);
				set_module_pref("pegplay",0);
				set_module_pref("dragonseedage",0);
				set_module_pref("dietreehit",0);
				set_module_pref("dieingtree",0);
				clear_module_pref("monsterid");
				clear_module_pref("monsterlevel");
				clear_module_pref("monstername");
				if (get_module_pref("seed")>0) increment_module_pref("seed",-1);
				if (get_module_pref("found")>0) increment_module_pref("found",-1);
				if (get_module_pref("tree")>0) increment_module_pref("tree",-1);
				output("`n`n`%You receive a very sad notice from `!Elendir`% informing you that one of your fruit trees has died from Fruit Tree Disease.`n");
			}
			if (get_module_setting("dryenable")==2) set_module_pref("dietreehit",0);
			set_module_pref("hadfruittoday",0);
			set_module_pref("meplay",0);
			set_module_pref("caplay",0);
			set_module_pref("pegplay",0);
			if (get_module_setting("everyday")){
				if (get_module_pref("treegrowth")>0) output("`n`@You recall that your tree still has `^%s`@ more days to grow`n",get_module_pref("treegrowth"));
			}else{
				$growth=get_module_pref("treegrowth");
				if ($growth>0){
					$growth--;
					set_module_pref("treegrowth",$growth);
					if ($growth>0) output("`n`@You recall that your tree still has `^%s`@ more days to grow`n",$growth);
					else{
						$tree = get_module_pref("tree")+1;
						set_module_pref("tree",$tree);
						output("`n`@You recall that your should be fully grown by now, perhaps you should visit the orchard and take a look.`n");
					}
				}
			}
		break;
		case "newday-runonce":
			if (get_module_setting("dryenable")==1){
       			$sql = "update ".db_prefix("module_userprefs")." set value=0 where value<>0 and setting='dietreehit' and modulename='orchard'";
       			db_query($sql);				
			}
			if (get_module_setting("everyday")){
				$sql = "SELECT * FROM " . db_prefix("module_userprefs") . " WHERE modulename = 'orchard' AND setting = 'treegrowth' AND value > 0";
				$result = db_query($sql);
				while($row = db_fetch_assoc($result)){
					$value = $row['value'] - 1;
					$sql2 = "Update " . db_prefix("module_userprefs") . " set value='$value' where modulename='orchard' AND setting='treegrowth' AND userid='{$row['userid']}'";
					db_query($sql2);
					if ($value==0){
						$tree = get_module_pref("tree","orchard",$row['userid']) + 1;
						$sql3 = "Update " . db_prefix("module_userprefs") . " set value='$tree' where modulename='orchard' AND setting='tree' AND userid='{$row['userid']}'";
						db_query($sql3);
					}
				}
			}
		break;
		case "battle-victory":
			if (get_module_pref("monsterid")==$args['creatureid'] && $args['type']=="forest"){
				output("`nYou find a small seed on the slain monsters corpse.  It appears to be exactly the seed you were looking for!");
				set_module_pref("monsterid",0);
				set_module_pref("monsterlevel",0);
				set_module_pref("monstername","");
				orchard_findseed();
			}
		break;
	}
	return $args;
}

function orchard_run(){
	global $SCRIPT_NAME;
	if ($SCRIPT_NAME == "runmodule.php"){
		$module=httpget("module");
		if ($module == "orchard"){
			require_once("modules/lib/orchard_func.php");
			include("modules/lib/orchard.php");
		}
	}
}

function orchard_runevent($type){
		include("modules/lib/orchard_event.php");
}
?>