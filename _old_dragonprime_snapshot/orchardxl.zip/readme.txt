Fruit Orchard XL

Version 3.01

History:
v3.01	Valhalla integration and db_prefix fix
v3.02 	Those sneaky db prefix fixes!
v3.03 	Those sneaky db prefix fixes!
v3.04  	Quite a few tweaks for the cellar/forest interactions.
v3.05 	Another db prefix fix; thanks Sichae.

1 | apple | cellar (or random monster)
2 | orange | forest special
3 | pear | after fighting a specific enemy
4 | apricot | buy from cedrick barkeep
5 | banana | Abandoned House Quest (or random monster)
6 | peach | graveyard (from ramius)
7 | plum | stables
8 | fig | after fighting a specific enemy
9 | mango | alley special (or forest special)
10 | cherry | dragon's corpse 
11 | tangerine | bank
12 | grapefruit | jail (or random monster)
13 | lemon | Lumberyard (or random monster)
14 | avocado | MightyEs weaponry
15 | lime | Quarry (or forest special)
16 | pomegranate | Audrey's crazy cats (or forest special)
17 | kiwi | forest special quest - encounter 3 times
18 | cranberry | Pegasus Armor
19 | star fruit | Hunter's Lodge 
20 | dragonfruit | Plant at a dragon corpse; grows over 3 dragon kills


Congratulations on choosing the new Orchard XL.

This version will do everything the old orchard did and much more.  However, if you want it to only
do what the old orchard did, you can make it so it only does that.


Here are some new features:

1.  Setting for HP increase per Fruit (Remember, it used to be 10 per fruit level.  Since there are so
many more trees, I have made a setting with the default 7.)
2.  Setting for the number of fruit trees for the orchard: If you don't want 20 trees and for some 
reason you only want 15, then you can change the setting.
3.  Fruit Tree Disease (FTD):  This is a pretty critical part of the module that I think was missing.
It adds a forest event that will cause fruit trees to get sick.  Players have to go to the orchard
and spend turns (setting: default is 5 turns) trying to heal the tree otherwise it will die at the next newday.
Even if they heal the tree there's a chance it will still die (setting: default is 10%). The event then has a chance to
occur again (setting: default once per dragon kill).
This increases the replay value of the module because now players will have a chance that they will lose there
current fruit tree (Note:  The Lumberyard also would cause players to lose trees).
4.  Preference for showing an image of your fruit tree or text or nothing.

In order for the Lumberyard tie in to work you Must have:
Lumberyard V3.5

In order for the Quarry tie-ins to work you MUST have:
Quarry v3.5
