<?php
global $session;
require_once("lib/http.php");
require_once("lib/villagenav.php");
$op = httpget('op');
$subop = httpget('subop');
if ($op==""){
	page_header("The Fruit Orchard");
	addnav("Enter the Hollow Tree","runmodule.php?module=orchard&op=hollowtree");
	addnav("Explore the orchard","runmodule.php?module=orchard&op=explore");
	if (get_module_pref("tree")>0 || get_module_pref("treegrowth")>0) addnav("Visit your trees","runmodule.php?module=orchard&op=trees");
	villagenav();
	output("`7You stroll into the orchard, it's a picturesque area filled with a large variety of different fruit trees, many of the fruits look ripe and ready to be picked.");
	output("You could easily spend hours just relaxing in here.`n`n");
	output("To the right of the entrance is a small path leading up to the hollow tree, the house of `!Elendir`7, keeper of the orchard.`n`n");
	output("It looks as though he might be home.");
	modulehook ("orchard-entrance");   
}
if ($op=="explore"){
	page_header("The Fruit Orchard");
	addnav("Return to the entrance","runmodule.php?module=orchard");
	output("`7Wandering through the orchard between the many trees planted by different villagers, occasionally you meet someone else and wave.");
	output("It's a beautiful place to spend an afternoon.`n`n");
	output("`c`b`^The best trees in the orchard:`b`c`n");
	$names=array("","Apple","Orange","Pear","Apricot","Banana","Peach","Plum","Fig","Mango","Cherry","Tangerine","Grapefruit","Lemon","Avocado","Lime","Pomegranate","Kiwi","Cranberry","Star Fruit","Dragonfruit");
	$perpage = 15;
	if ($subop=="") $subop=1;
	$min = ($subop-1)*$perpage;
	$limit = "LIMIT $min,$perpage";
	$sql = "SELECT COUNT(*) AS c FROM " . db_prefix("module_userprefs") . " WHERE modulename = 'orchard' AND setting = 'tree' AND value > 0";
	$result = db_query($sql);
	$row = db_fetch_assoc($result);
	$total = $row['c'];
	addnav("Pages");
	for($i = 0; $i < $total; $i+= $perpage) {
		$pnum = ($i/$perpage+1);
		$min = ($i+1);
		$max = min($i+$perpage,$total);
		addnav(array("Page %s (%s-%s)", $pnum, $min, $max), "runmodule.php?module=orchard&op=explore&subop=$pnum");
	}
	$sql =  "SELECT " . db_prefix("module_userprefs") . ".value,".db_prefix('accounts').".name FROM " . db_prefix("module_userprefs") . "," . db_prefix("accounts") . " WHERE acctid = userid AND modulename = 'orchard' AND setting = 'tree' AND value > 0 ORDER BY (value+0) DESC $limit";
	$result = db_query($sql);
	$name = translate_inline("Name");
	$tree = translate_inline("Best Tree");
	$none = translate_inline("No Trees Found");
	rawoutput("<table border='0' cellpadding='2' cellspacing='1' align='center' bgcolor='#999999'>");
	rawoutput("<tr class='trhead'><td>$name</td><td>$tree</td></tr>");
	if (db_num_rows($result)==0) output_notl("<tr class='trlight'><td colspan='2' align='center'>`&$none`0</td></tr>",true);
	else{
		for ($i=0;$i<db_num_rows($result);$i++){
			$row = db_fetch_assoc($result);
			if ($row['name']==$session['user']['name']) rawoutput("<tr class='trhilight'><td>");
			else rawoutput("<tr class='".($i%2?"trdark":"trlight")."'><td>");
			output_notl("`&%s`0",$row['name']);
			rawoutput("</td><td>");
			output_notl("`@%s`0",$names[$row['value']]);
			rawoutput("</td></tr>");
		}
	}
	rawoutput("</table>");
}
if ($op=="hollowtree"){
	page_header("The Hollow Tree");
	addnav("Return to the entrance","runmodule.php?module=orchard");
	if (get_module_pref("dietreehit")==1 && get_module_pref("dieingtree")>0){
		output("\"`#I'm so glad you were able to make it here so quickly.`7\"");
		$dieingtree=get_module_pref("dieingtree");
		if ($session['user']['turns']>=get_module_pref("dieingtree")){
			output("`n`n\"`#We'll need to spend `@%s turn%s`# to even have a chance to save your tree. Are you ready?`7\"",$dieingtree,translate_inline($dieingtree>1?"s":""));
			addnav("Try to Save Your Tree","runmodule.php?module=orchard&op=savetree");
		}else{
			output("`n`n\"`#Unfortunately, you don't have enough time to help take care of your tree.  If you can't find the time before the new day, your tree is going to die.");
			output("You need `@%s turn%s`# to save your tree.`7\"",$dieingtree,translate_inline($dieingtree>1?"s":""));
		}
	}else{
		if (get_module_pref("bankkey")==1) addnav("Ask about the Bank Key","runmodule.php?module=orchard&op=bankkey");
		$tree = get_module_pref("tree");
		if (get_module_pref("found")>0) addnav("Show Elendir your seed","runmodule.php?module=orchard&op=giveseed");
		elseif ($tree<get_module_setting("treesinorchard")) addnav("Ask about tree seeds","runmodule.php?module=orchard&op=askseeds");
		if ($tree>0 || get_module_pref("treegrowth")>0) addnav("Ask about your trees","runmodule.php?module=orchard&op=asktrees");
		output("`!Elendir`7 spots you as you are walking down the path and comes out to greet you.");
		if ($tree==0 && get_module_pref("seed")==0){
			output("`n`n\"`#Hello there, you're a new face, have you looked around the orchard yet?  It's truly wonderful is it not.`7\" he says merrily.`n");
			output("\"`#Please, do come in and stay a while, I can tell you all about the orchard if you like.`7\"`n`n");
			output("Of course, you were heading to his house anyway and who can refuse an invitation from an elf, so you follow him inside.`n`n");
			output("\"`#OK, I'm sure you'll be wanting your own little spot and I believe theres still space for more trees.");
			output("Unfortunately it isn't quite that simple, I cannot help you plant trees unless you bring me seeds to plant them with.  And then of course they take time to grow, but I think you'll agree that it's worth the wait.`7\"`n");
			output("`!Elendir`7 smiles and waves his arms vaguely towards the window, where there is a superb view of the orchard.");
		}elseif ($tree==0){
			output("`n`n\"`#Hello there %s`#!  You are looking very well today, I wonder, have you found any seeds for me yet?`7\"",$session['user']['name']);
			output("He says, greeting you with a firm handshake.`n`n");
			output("\"`#Please, come inside and sit a while.`7\" `!Elendir`7 gestures you inside and you follow politely.`n`n");
			output("\"`#So, would you like me to tell you about the orchard?  Perhaps you think I know about some seeds you may be able to find?`7\"");
			output("He smiles at you knowingly and sits down opposite you.");
		}else{
			output("\"`#Hello there %s`#!  How are you today, you're trees seem to be doing very well for themselves, as do everyone elses.  What is it you would like today?`7\" he asks jovially, gesturing you inside.`n`n",$session['user']['name']);
			output("You follow him in and take a seat.`n`n");
			if ($tree<get_module_setting("treesinorchard")){
				output("\"`#I suppose you're interested in how your trees are doing?  and of course there are always more seeds to be found.`7\"");
			}else{
				output("\"`#My friend, you know as much about the trees in this orchard as I do, I'm not sure I can be of any more service to you.  Of course you are welcome to stay and relax here as long as you want.`7\"");
			}
		}
	modulehook ("orchard-hollowtree"); 
	}
}
if ($op=="savetree"){
	page_header("The Orchard");
	$dieingtree=get_module_pref("dieingtree");
	$session['user']['turns']-=$dieingtree;
	output("`7You work dilligently with `!Elendir`7 to save your tree.");
	output("`n`nTime slows to a standstill as you work.");
	if (e_rand(1,100)<=get_module_setting("treechance")){
		output("`n`nUnfortunately, You're unable to save the tree.  You sadly look down and `!Elendir`7 calls out the time of death.");
		set_module_pref("bankkey",0);
		set_module_pref("mespiel",0);
		set_module_pref("menumb",0);
		set_module_pref("caspiel",0);
		set_module_pref("canumb",0);
		set_module_pref("bellyrub",0);
		set_module_pref("pegplay",0);
		set_module_pref("dragonseedage",0);
		set_module_pref("dietreehit",0);
		clear_module_pref("monsterid");
		clear_module_pref("monsterlevel");
		clear_module_pref("monstername");
		if (get_module_pref("seed")>0) increment_module_pref("seed",-1);
		if (get_module_pref("found")>0) increment_module_pref("found",-1);
		if (get_module_pref("tree")>0) increment_module_pref("tree",-1);
	}else{
		if (get_module_setting("dryenable")==0) set_module_pref("dietreehit",0);
		output("`n`nHappily, you're able to save your tree!!! You thank `!Elendir`7 for all his help.");
	}
	set_module_pref("dieingtree",0);
	addnav("Return to the entrance","runmodule.php?module=orchard");
	villagenav();
}
if ($op=="giveseed"){
	page_header("The Hollow Tree");
	addnav("Return to the entrance","runmodule.php?module=orchard");
	$tree = get_module_pref("tree");
	$names=array("","Apple","Orange","Pear","Apricot","Banana","Peach","Plum","Fig","Mango","Cherry","Tangerine","Grapefruit","Lemon","Avocado","Lime","Pomegranate","Kiwi","Cranberry","Star Fruit","Dragonfruit");
	if (get_module_pref("treegrowth")>0){
			output("`7\"`#If you recall, you still have a `@%s`# tree growing in the orchard, you need to wait for it to finish growing before you can plant another.`7\"",$names[($tree+1)]);
			if ($tree>0) addnav("Ask about your trees","runmodule.php?module=orchard&op=asktrees");
	}else{
		$found = get_module_pref("found");
		if ($tree>0) addnav("Pick some fruit","runmodule.php?module=orchard&op=pick");
		output("`7\"`#Ah, wonderful, a `@%s`# seed.  Come, lets head out into the orchard and get this planted shall we.`7\"`n`n",$names[$found]);
		output("You follow `!Elendir`7 out into the orchard to a small clearing and he asks for the `@%s`7 seed.",$names[$found]);
		output("`!Elendir`7 begins to dig a small hole to plant the seed in and starts chatting about the orchard.");
		output("You sit and listen whilst he plants the tree, keeping an eye on what he's doing.");
		output("After a short while the tree is planted and `!Elendir`7 stands up and smiles at you.`n`n");
		output("\"`#Thats going to be a fine tree when it's fully grown, trust me.  Just make sure you look after it.`7\"`n`n");
		output("\"`#Remember never to pick too much fruit from it, otherwise it will become unhealthy and possibly even die.`7\"`n`n");
		output("\"`#Oh, and it will take `^%s`# days for the tree to grow to full size and bear fruit for you to eat.  You must be patient.`7\"`n`n",get_module_setting("growth"));
		output("With a final wave `!Elendir`7 heads back through the orchard, leaving you with the newly planted tree.");
		set_module_pref("found",0);
		set_module_pref("treegrowth",get_module_setting("growth"));
		if ($tree>0){
			for($i=1;$i<=$tree;$i++){
				if ($trees == null) $trees = $names[$i];
				else$trees = $trees."`7,`^ ".$names[$i];
			}
		output("Looking around, you see that you have the following trees: `^%s`7.",$trees);
		}
	}
}
if ($op=="askseeds"){
	page_header("The Hollow Tree");
	addnav("Return to the entrance","runmodule.php?module=orchard");
	$tree=get_module_pref("tree");
	if (get_module_pref("treegrowth")>0) $tree++;
	if (get_module_pref("found")>0) addnav("Show Elendir your seed","runmodule.php?module=orchard&op=giveseed");
	if ($tree>0)addnav("Ask about your trees","runmodule.php?module=orchard&op=asktrees");
	output("`7\"`#So you want to find a seed to make your own contribution to the orchard, thats wonderful!`7\"`n`n");
	switch ($tree){
		case 0:
			if (is_module_active("cellar")) output("\"`#I know that Cedrick used to have a few apple seeds in his posession, but he probably lost them in the cellar somewhere knowing him.`7\"");
			else orchard_monster(1);
		break;
		case 1:
			output("\"`#I heard tell of an orange grove hidden deep in the forest, perhaps you will find it in your travels.`7\"");
		break;
		case 2:
			orchard_monster(3);
		break;
		case 3:
			output("\"`#Cedrick owns a small apricot tree, it's a very important posession to him so it will probably cost you dearly to get a seed from it, go and talk to him.`7\"");
		break;
		case 4:
			if (is_module_active("darkalley")) output("\"`#An old man used to live in the Dark Alley, he owned a banana tree, perhaps he left some seeds in his house when he left.`7\"");
			else orchard_monster(5);
		break;
		case 5:
			output("\"`#I have here a peach seed, but unfortunately it has been dead for some time.  I will help you plant it if you can convince Raimus to breathe life back into the seed.`7\"");
		break;
		case 6:
			output("\"`#I believe Merick feeds the horses at his stables plums sometimes.`7\"");
		break;
		case 7:
			orchard_monster(8);
		break;
		case 8:
			if (is_module_active("darkalley")) output("\"`#The last I heard, some unsavoury character who is often seen in the Dark Alley had some mango seeds, who knows where he is now though.`7\"");
			else output("\"`#I heard tell of a mango grove hidden deep in the forest, perhaps you will find it in your travels.`7\"");
		break;
		case 9:
			output("\"`#Rumour has it that the Green Dragon is fond of cherries.  There is only one way to find out for sure though.`7\"");
		break;
		case 10:
			output("\"`#I'm not sure if this is true or not, but there may be a tangerine seed in the bank.");
			if (get_module_pref("bankkey")==0){
				output("I think I have a key around here somewhere that might help you.");
				set_module_pref("bankkey",1);
				addnav("Talk Some More","runmodule.php?module=orchard&op=bankkey");
			}
		break;
		case 11:
			if (is_module_active("jail"))output("\"`#I hear they serve really good grapefruit for your last meal in jail.`7\"");
			else orchard_monster(12);
		break;
		case 12:
			if (is_module_active("lumberyard")&&get_module_setting("alloworchard","lumberyard")==1)output("\"`#There's a sneaky foreman that runs the lumberyard.  Perhaps you can find a lemon seed while you swing the ole axe for a little bit.`7\"");
			else orchard_monster(13);
		break;
		case 13:
			output("\"`#Well, I promised him I wouldn't mention it to anyone, but I think you might find an avocado seed over at `!MightyE's`# Weaponry.`0\"");
		break;
		case 14:
			if (is_module_active("quarry")&&get_module_setting("alloworchard","quarry")==1)output("\"`#You're going to need to find a lime seed next.  Perhaps there's one in the quarry.`7\"");
			else output("\"`#I heard tell of a lime grove hidden deep in the forest, perhaps you will find it in your travels.`7\"");
		break;
		case 15:
			if (is_module_active("crazyaudrey")) output("\"`#There's a strange woman that I've seen in the village and in the forest.  She may have a Pomegranate seed, but I'm not sure if she's mentally stable.  Try to find `%Crazy Audrey`# as she may have a seed for you.`7\"");
			else output("\"`#I heard tell of a pomegranate grove hidden deep in the forest, perhaps you will find it in your travels.`7\"");
		break;
		case 16:
			output("\"`#You won't believe this, and I'm sure it won't make much sense to you, but here's the deal:\"`n`n\"There's a bird in the forest.  If you rub it's tummy you can get a seed from it.");
			output("The bird is a kiwi bird and it loves to have its belly rubbed. For some reason it has a collection of kiwi seeds and will offer one to you if you do this. I know, it doesn't make much sense, but I promise you there's magic in that forest!`7\"");
		break;
		case 17:
			output("\"`#The Gypsy named Pegasus is known for creating some of the most amazing armor in the kingdom. She also has the finest Cranberry tree around.  Perhaps she will let you have a seed.`7\"");
		break;
		case 18:
			output("\"`#The Star Fruit Seed is only available for those who are of a generous nature. You can visit the Lodge for your next seed if you're the generous type.`7\"");
		break;
		case 19:
			$dsage=get_module_pref("dragonseedage");
			if ($dsage==0){
				output("`!Elendir`7 hands you a seed.  It's warm to the touch.  You smile thinking how this seed has turned out to be so easy to get.  You are about to ask him to help you plant it when he stops you.");
				output("`n`n\"`#Here is the Dragon Fruit Seed.  Unfortunately, it will not grow unless it is nurtured by a dragon.  You will need to plant this seed in the cave of the `@Green Dragon`# the next time you face her.");
				output("It will need to be in a dragon lair for 3 generations of dragons before it will be ready to be planted.  Good luck!`7\"");
			}elseif ($dsage>0){
				output("\"`#Your Dragon Seed is germinating in the Dragon's Cave. Just");
				if ($dsage==1) output("3 more dragon kills");
				if ($dsage==2) output("2 more dragon kills");
				if ($dsage==3) output("one more dragon kill");
				output("and it will be ready for planting.`7\"");
			}
		break;
		}
	set_module_pref("seed",($tree+1));
}
if ($op=="asktrees"){
	page_header("The Hollow Tree");
	addnav("Return to the entrance","runmodule.php?module=orchard");
	$names=array("","Apple","Orange","Pear","Apricot","Banana","Peach","Plum","Fig","Mango","Cherry","Tangerine","Grapefruit","Lemon","Avocado","Lime","Pomegranate","Kiwi","Cranberry","Star Fruit","Dragonfruit");
	$tree=get_module_pref("tree");
	if (get_module_pref("found")>0) addnav("Show Elendir your seed","runmodule.php?module=orchard&op=giveseed");
	elseif ($tree<get_module_setting("treesinorchard")) addnav("Ask about tree seeds","runmodule.php?module=orchard&op=askseeds");
	output("`7\"`#Of course you can always go and look at your trees yourself, you're free to roam the orchard as you please.");
	output("But if you want my opinion on your trees then it is yours.`7\"`n`n");
	switch($tree){
		case 0:
			output("\"`#Sadly you have no fully grown trees in the orchard, but time will change that as I'm sure you know.`)\"");
		break;
		case 1:case 2:case 3:case 4: case 5: case 6: case 7:
			output("\"`#Well, I'm very pleased that you've taken an interest in the orchard, but you still have a lot to learn from me about trees.`n");
				output("I hope you maintain your interest, and your little section of my orchard grows.`7\"");
		break;
		case 8: case 9: case 10: case 11: case 12: case 13:
			output("\"`#I have to say you're doing very well, there are still a few things I have to show you though, but I'm sure you'll pick them up just fine.`7\"");
		break;
		case 14: case 15: case 16: case 17: case 18: case 19:
			output("\"`#Well, your skills in the orchard almost match my own.  You should be very proud of what you have achieved here.`7\"");
		break;
		case 20:
			output("\"`#We are like brothers, our knowledge of the orchard is equal and unrivalled.`7\"");
		break;
	}
	$growth=get_module_pref("treegrowth");
	if ($growth>0) output("`n`n\"`#No doubt you're also wondering about the `@%s`# tree that we planted not long ago, well it still has `^%s`# more days before it will be fully grown.`7\"",$names[$tree+1],$growth);
}
if ($op=="trees"){
	page_header("The Fruit Orchard");
	$names=array("","Apple","Orange","Pear","Apricot","Banana","Peach","Plum","Fig","Mango","Cherry","Tangerine","Grapefruit","Lemon","Avocado","Lime","Pomegranate","Kiwi","Cranberry","Star Fruit","Dragonfruit");
	$tree=get_module_pref("tree");
	addnav("Return to the entrance","runmodule.php?module=orchard");
	if ($tree>0) addnav("Pick some fruit","runmodule.php?module=orchard&op=pick");
	output("`7You saunter through the orchard to a familiar area, you think back to the proud moment when `!Elendir`7 helped you to plant your very own trees in this spot.");
	output("Some of the fruit on the more mature trees looks wonderfully ripe, you could so easily reach out and pick some and eat it right now.`n`n");
	if ($tree>0){
		for($i=1;$i<=get_module_pref("tree");$i++){
			if ($trees == null) $trees = $names[$i];
			else $trees = $trees."`7,`^ ".$names[$i];
		}
		output("Looking around, you see that you have the following trees: `^%s`7.",$trees);
	}
	if (get_module_pref("treegrowth")>0)output("`n`nYou note that the tree you and `!Elendir`7 planted is still not fully grown, perhaps `!Elendir`7 could give you an idea of how much longer it will take.");
}
if ($op=="pick"){
	page_header("The Fruit Orchard");
	addnav("Go back to your trees","runmodule.php?module=orchard&op=trees");
	addnav("Return to the entrance","runmodule.php?module=orchard");
	if (get_module_pref("dietreehit")==1 && get_module_pref("dieingtree")>0){
		output("As you grab the fruit, you realize there's something wrong with it.");
		output("Perhaps you better talk to `!Elendir`7 before you eat that piece of fruit!");
	}elseif (get_module_pref("hadfruittoday")) output("`7You reach out to pick some fruit, but remember what `!Elendir`7 told you, only one piece of fruit per day or the trees may grow unhealthy.");
	else{
		$names=array("","Apple","Orange","Pear","Apricot","Banana","Peach","Plum","Fig","Mango","Cherry","Tangerine","Grapefruit","Lemon","Avocado","Lime","Pomegranate","Kiwi","Cranberry","Star Fruit","Dragonfruit");
		$level=get_module_pref("tree");
		$tree=$names[$level];
		output("`7You reach out and pick a ripe `@%s`7 from a nearby tree and munch on it happily.`n`n",$tree);
		output("You feel much healthier for it, and gain `^%s`7 health!",$level*get_module_setting("healfruit"));
		$session['user']['hitpoints']+=$level*get_module_setting("healfruit");
		set_module_pref("hadfruittoday",1);
	}
}
// everything after here is interaction with other modules
if ($op=="starseedbuy"){
	page_header("Hunter's Lodge");
	addnav("L?Return to the Lodge","lodge.php");
	$seedcost=get_module_setting("lodgeseed");
	$pointsavailable = $session['user']['donation'] - $session['user']['donationspent'];
	output("`7J. C. Petersen smiles at you, \"`&So, you're interested in purchasing a Star Fruit Seed.`7\"`n");
	if ($pointsavailable < $seedcost){
		output("`nHe consults his book silently for a moment and then turns to you. \"`&I'm terribly sorry, but you only have %s points available.`7\"`n", $pointsavailable);
	}else{
		output("`n\"`&This very rare seed will cost %s points.`7\"`n`n",$seedcost);
		addnav("Buy Star Fruit Seed","runmodule.php?module=orchard&op=buylseed");
	}
}
if ($op=="buylseed"){
	page_header("Hunter's Lodge");
	$seedcost=get_module_setting("lodgeseed");
	$session['user']['donationspent'] += $seedcost;
	debuglog ("spent $seedcost lodge points buying the Star Fruit Seed.");
	output("J. C. Petersen nods and hopes you enjoy your Star Fruit Seed.");
	orchard_findseed();
	addnav("L?Return to the Lodge","lodge.php");
}
if ($op=="pegcran"){
	page_header("Pegasus");
	output("`c`b`%Pegasus Armor`0`c`b");
	if (get_module_pref("pegplay")==0){
		output("`5After admiring the amazing armor, you look up at `#Pegasus`5 and ask if she would be willing to give you a cranberry seed.");
		output("`n`n`5\"`@I'm glad you asked about my cranberry tree.  If you have a moment, I'd like to share a story with you.`5\"");
		addnav("Listen to her story","runmodule.php?module=orchard&op=pegstory");
	}else{
		output("`#Pegasus`5 ignores you. Perhaps she'll chat some more with you tomorrow.");
	}
	addnav("Look at Armor","armor.php");
}
if ($op=="pegstory"){
	page_header("Pegasus");
	output("`c`b`%Pegasus Armor`0`c`b");
	if ($session['user']['turns']<4){
		output("`5\"`@Oh, I'm so sorry.  It will probably take about 4 turns to hear the whole story. Stop back when you have more time.");
		villagenav();
	}else{
		set_module_pref("pegplay",1);
		$story=e_rand(1,10);
		$session['user']['turns']-=4;
		set_module_pref("pegstory",$story);
		$homechoice=array("","Parantray","Ofrenhaven","Gravenstaff","Ordenmarn","Priselton","Havermark","Traktrin","Garensow","Rikenham","Schantiln");
		$artpiece=array("","duck","butterfly","wagon","helmet","unicorn","tree","flower","penguin","frog","turtle");
		$months=array(0,36,37,38,39,40,41,42,43,44,45);
		output("`5\"`@I�m sure you�ve noticed that I have my shop set up inside of my wagon.");
		output("It�s true, I am one of the Gypsies of the %s province.",$homechoice[get_module_pref("pegstory")]);
		output("I remember growing up with my best friend `3Maritrina`@.  She was an amazing singer and we would often stay up late to sing harmonies with the world around us.");
		output("It was a wonderful way to grow up and I have such fond memories of my childhood.`5\"");
		output("`n`n`5\"`@So how did a young gypsy child learn to make the armor you see before you?");
		output("That's a story of turnabout, I guess.  I was a gypsy who grew tired of the nomadic ways of our people. I needed stability and I settled down and looked for something that I could do for a living.");
		output("I found that I loved creating pieces of art with my hands.  I started by working with glass.");
		output("The first sculpture I ever made was of a %s.  I admit it wasn't the most beautiful sculpture ever seen, but it was enough to spark a passion that has never left me.",$artpiece[get_module_pref("pegstory")]);
		output("Soon enough I turned my skills to molding and shaping metal.  It took me over %s months to make a suit of armor that was tournament worthy, but when I finished the suit the knight that wore it won the competition!`5\"",$months[get_module_pref("pegstory")]);
		output("`n`n`5\"`@My armor reflects my appreciation for nature.  And that's how my story comes around full circle to the Cranberry Tree. I have a feeling you can see why I do not trust my cranberry seeds to just anyone.`5\"");
		output("`n`nBy the time `#Pegasus`5 finishes her story, you realize that it's taken `@4 turns`5 to hear.");
		addnav("Continue","runmodule.php?module=orchard&op=pegcontinue");
	}
}
if ($op=="pegcontinue"){
	page_header("Pegasus");
	output("`c`b`%Pegasus Armor`0`c`b");
	output("`5\"`@Before I give you the Cranberry Seed, you have to answer one little question for me about my story.`5\"`n`n");
	addnav("Answers");
	switch(e_rand(1,3)){
		case 1:
			output("`5\"`@What was the name of the province that my people came from?`5\"");
			addnav("Parantray","runmodule.php?module=orchard&op=1");
			addnav("Ofrenhaven","runmodule.php?module=orchard&op=2");
			addnav("Gravenstaff","runmodule.php?module=orchard&op=3");
			addnav("Ordenmarn","runmodule.php?module=orchard&op=4");
			addnav("Priselton","runmodule.php?module=orchard&op=5");
			addnav("Havermark","runmodule.php?module=orchard&op=6");
			addnav("Traktrin","runmodule.php?module=orchard&op=7");
			addnav("Garensow","runmodule.php?module=orchard&op=8");
			addnav("Rikenham","runmodule.php?module=orchard&op=9");
			addnav("Schantiln","runmodule.php?module=orchard&op=10");
		break;
		case 2:
			output("`5\"`@What was the first scultpure I made out of glass?`5\"");
			addnav("Duck","runmodule.php?module=orchard&op=1");
			addnav("Butterfly","runmodule.php?module=orchard&op=2");
			addnav("Wagon","runmodule.php?module=orchard&op=3");
			addnav("Helmet","runmodule.php?module=orchard&op=4");
			addnav("Unicorn","runmodule.php?module=orchard&op=5");
			addnav("Tree","runmodule.php?module=orchard&op=6");
			addnav("Flower","runmodule.php?module=orchard&op=7");
			addnav("Penguin","runmodule.php?module=orchard&op=8");
			addnav("Frog","runmodule.php?module=orchard&op=9");
			addnav("Turtle","runmodule.php?module=orchard&op=10");
		break;
		case 3:
			output("`5\"`@How many months did it take me to master my first suit of armor?`5\"");
			addnav("36","runmodule.php?module=orchard&op=1");
			addnav("37","runmodule.php?module=orchard&op=2");
			addnav("38","runmodule.php?module=orchard&op=3");
			addnav("39","runmodule.php?module=orchard&op=4");
			addnav("40","runmodule.php?module=orchard&op=5");
			addnav("41","runmodule.php?module=orchard&op=6");
			addnav("42","runmodule.php?module=orchard&op=7");
			addnav("43","runmodule.php?module=orchard&op=8");
			addnav("44","runmodule.php?module=orchard&op=9");
			addnav("45","runmodule.php?module=orchard&op=10");
		break;
	}
}
if (($op=="1"||$op=="2"||$op=="3"||$op=="4"||$op=="5"||$op=="6"||$op=="7"||$op=="8"||$op=="9"||$op=="10") && $op==get_module_pref("pegstory")){
	page_header("Pegasus");
	output("`c`b`%Pegasus Armor`0`c`b");
	output("`5\"`@You are indeed worthy of one of my Cranberry Seeds.  Please take good care of it.`5\"");
	set_module_pref("pegplay",0);
	clear_module_pref("pegstory");
	orchard_findseed();
	villagenav();
}
elseif ($op=="1"||$op=="2"||$op=="3"||$op=="4"||$op=="5"||$op=="6"||$op=="7"||$op=="8"||$op=="9"||$op=="10"){
	page_header("Pegasus");
	output("`c`b`%Pegasus Armor`0`c`b");
	output("`5\"`%You weren't paying attention were you? I think you need to leave now.`5\"");
	output("`n`nShe gives you a glare and turns her attention to watching the swordsmith in the store next to her wagon. Maybe you can talk to her again tomorrow.");
	villagenav();
}
if ($op=="caseed"){
	page_header("Crazy Audrey");
	if (get_module_pref("caspiel")==0){
		output("`5\"`%You're after my precious seed, aren't you?`5\"");
		output("`n`nTrying to compose yourself, you explain that you'd be willing to compensate her fairly for her pomegranate seed.");
		output("`n`n\"`%You think you can just take my precious seed, don't you?`5\"");
		output("`n`nOnce again you try to explain that money isn't a problem... you want to be fair.");
		output("`n`n\"`%NO NO  no no nononononono... Money isn't a problem.  But if you want my precious seed, you have to beat me.`5\"");
		output("`n`nAt this point, you have no qualms with beating her, but you have a feeling that's not what this is about.");
		output("`n`n\"`%It will be a staring contest.  And it will cost you `^1000 gold `%each time you play me.`5\"");
		output("`n`n`5Ready to stare down Crazy Audrey?");
		addnav("Stare at Crazy Audrey","runmodule.php?module=orchard&op=stareca");
		addnav("Run away from Crazy Audrey","runmodule.php?module=orchard&op=runca");
		set_module_pref("caspiel",1);
	}elseif (get_module_pref("caplay")==0){
		output("`5\"`%You think you can stare me down for my precious seed today?  If you've got `^1000`% gold, then bring it on!`5\"");
		output("`n`n`5Ready to stare down Crazy Audrey?");
		addnav("Stare at Crazy Audrey","runmodule.php?module=orchard&op=stareca");
		addnav("Run away from Crazy Audrey","runmodule.php?module=orchard&op=runca");
	}else{
		output("`5\"`%Come back to stare at my beautiful eyes already, have you? Well, I don't think you can handle so much beauty in one day. Come back tomorrow.`5\"");
		villagenav();
	}
}
if ($op=="runca"){
	page_header("Crazy Audrey");
	output("`5You run, very quickly, away from this mad woman.");
	villagenav();
}
if ($op=="stareca"){
	page_header("Crazy Audrey");
	$canumb=get_module_pref("canumb");
	if ($session['user']['gold']<1000) output("`5Not having `^1000`5 gold you wander sadly away.");
	elseif (get_module_pref("canumb")<=1){
		set_module_pref("caplay",1);
		increment_module_pref("canumb",1);
		output("`5You hand over `^1000`5 gold and settle down for a staring contest with Crazy Audrey.");
		output("`n`nYou're doing quite well, when suddenly she throws a %s at you.",get_module_setting("animal","crazyaudrey"));
		output("\"`%HA HA ha ha hahahahaha!!! You lost! Come back tomorrow and maybe you can beat me then.`5\"");
		output("`n`nSomewhat dejected and defeated, you leave.  Oh, she'll learn her lesson tomorrow!");
		increment_module_pref("canumb",1);
		$session['user']['gold']-=1000;
	}else{
		set_module_pref("caplay",1);
		increment_module_pref("canumb",1);
		$session['user']['gold']-=1000;
		switch(e_rand($canumb,10)){
			case 1:
			case 2:
			case 3:
			case 4:
			case 5:
			case 6:
			case 7:
			case 8:
			case 9:
				output("`5This time you're ready for that Crazy Audrey. \"`#No throwing %s!`5\" you tell her.",get_module_setting("animals","crazyaudrey"));
				output("`n`nAnd you start staring... and staring...`n`n");
				switch(e_rand(1,5)){
					case 1:
						output("Then you notice the big hairy mole on her cheek! You can't take it anymore and you turn away.");
					break;
					case 2:
						output("You feel Crazy Audrey kick you under the table. You look down and lose the staring contest!");
					break;
					case 3:
						output("You suddenly smell a very obnoxious odor.  Suddenly, Crazy Audrey starts smiling very broadly as you realize she just passed gas.");
						output("The smell overwhelms you and you cover your nose and turn away.");
					break;
					case 4:
						output("Crazy Audrey starts drooling. A huge gob is about to hit the ground when she sucks it back up.");
						output("She really is crazy.  You can't stand watching her and lose the staring contest!");
					break;
					case 5:
						output("You notice that Crazy Audrey is picking at a scab on her arm.  She slowly peals it off and eats it.");
						output("If, at this point, you are not honestly sick to your stomach, you should be.  You can't watch anymore and turn away.");
					break;
				}
				output("`n`n\"`%Thanks for the gold.  You can try and beat me again tomorrow.`5\"");
			break;
			case 10:
				output("`5You take your position and begin the contest.  She won't be  able to distract you this time!");
				output("`n`nShe picks her nose, scratches her butt, puts her finger in her ear, and even pulls out her hair trying to distract you.");
				output("`n`nHowever, you keep your stare.  It seems like you're going to win and you start to smile.`n`n");
				output("\"`%You have such hideous teeth! I can't stand it anymore!`5\"");
				output("`n`n`bYou've beaten Crazy Audrey!!!`b");
				orchard_findseed();
				set_module_pref("caplay",0);
				set_module_pref("canumb",0);
				set_module_pref("caspiel",0);
			break;
		}	
	}
	villagenav();
}
if ($op=="quarry"){
	page_header("The Quarry");
	if (is_module_active('lostruins') && get_module_setting("usequarry","quarry")==0) {
		output("`n`c`b`@T`3he %s `@Q`3uarry`c`b`n",get_module_setting("quarryfinder","quarry"));
	}else{
		output("`n`c`b`@T`3he `@Q`3uarry`c`b`n");
	}
	output("`0You look down and notice some limestone.");
	addnav("Investigate","runmodule.php?module=orchard&op=limestone");
}
if ($op=="limestone"){
	page_header("The Quarry");
	if (is_module_active('lostruins') && get_module_setting("usequarry","quarry")==0) {
		output("`n`c`b`@T`3he %s `@Q`3uarry`c`b`n",get_module_setting("quarryfinder","quarry"));
	}else{
		output("`n`c`b`@T`3he `@Q`3uarry`c`b`n");
	}
	addnav("V?(V) Return to Village","village.php");
	if (get_module_pref("usedqts","quarry")<get_module_setting("quarryturns","quarry")) addnav("Work the Quarry","runmodule.php?module=quarry&op=work");
	addnav("Office","runmodule.php?module=quarry&op=office");
	output("`0There's more here then just limestone.  It seems like....");
	output("`n`n`n`nWait for it...");
	output("`n`n`nIt's the Lime Seed!!!");
	orchard_findseed();
}
if ($op=="megame"){
	page_header("MightyE's Weapons");
	output("`c`b`&MightyE's Weapons`0`c`b");
	if (get_module_pref("mespiel")==0){
		output("A dagger whizzes by and just touches misses cutting your ear.");
		output("`n`n\"`#You want to know about avocados?  That `!Elendir`# has been shooting his mouth off again, hasn't he? Fair enough.`0\"");
		output("`n`n\"`#Okay. Here's the deal. I'll give you one chance to grab the avocado seed from my hand.`0\" He shows you the very seed you're looking for.");
		output("`\"`#If you succeed, you can have my avocado seed. If you fail, you'll get a nice little scar and a painful reminder that sometimes you have to pay a price to play.`0\"");
		output("`n`n`!MightyE`0 twirls a dagger in one hand and teases you with the avocado in the other.");
		set_module_pref("mespiel",1);
		addnav("Play the Game","runmodule.php?module=orchard&op=playmegame");
	}elseif (get_module_pref("meplay")==0){
		output("\"`#So, are you ready to play my game again?`0\"");
		addnav("Play the Game","runmodule.php?module=orchard&op=playmegame");
	}else{
		output("\"`#Don't be a fool. Come back tomorrow`0\"");
	}
	addnav("Slowly Back Away","weapons.php");
}
if ($op=="playmegame"){
	page_header("MightyE's Weapons");
	output("`c`b`&MightyE's Weapons`0`c`b");
	$menumb=get_module_pref("menumb");
	set_module_pref("meplay",1);
	increment_module_pref("menumb",1);
	if ($menumb==0){
		output("You grab for the avocado before `!MightyE`0 has a chance to react...`n`n");
		output("or at least so you thought.  You feel a sharp sting as the dagger pierces your hand.");
		output("`n`n\"`#Not today. Come again tomorrow and maybe you'll get my avocado seed.`0\"");
		apply_buff('mecut',array(
			"name"=>"`!MightyE's Cut",
			"rounds"=>8,
			"wearoff"=>"`!The cut from MightyE heals.",
			"atkmod"=>.97,
			"defmod"=>.97,
			"roundmsg"=>"`!The cut on your hand prevents you from fighting at your best.",
		));
	}else{
		output("You stare at the avocado with deep concentration.");
		output("`n`nYour hand shoots out! You look down and and feel the seed in your hand!");
		switch(e_rand($menumb,5)){
			case 1:
			case 2:
			case 3:
			case 4:
				output("`n`nYou turn your hand over to gloat and suddenly realize that there's blood in your hand, not a seed.");
				output("`n`nYou marvel at `!MightyE's`0 speed.");
				output("`n`nWith a sly look, `!MightyE`0 points you to the door. \"`#See you again tomorrow?`0\"");
				apply_buff('mecut',array(
					"name"=>"`!MightyE's Cut",
					"rounds"=>8-$menumb,
					"wearoff"=>"`!The cut from MightyE heals.",
					"atkmod"=>.97,
					"defmod"=>.97,
					"roundmsg"=>"`!The cut on your hand prevents you from fighting at your best.",
				));
			break;
			case 5:
				output("`n`nYou sense that `!MightyE`0 may have grown bored with the game, but you're still proud nonetheless.");
				orchard_findseed();
				set_module_pref("meplay",0);
				set_module_pref("menumb",0);
				set_module_pref("mespiel",0);
			break;
		}
	}
	addnav("Return to the Storefront","weapons.php");
}
if ($op=="lumberyard"){
	page_header("Lumber Yard");
	output("`n`c`b`QT`qhe `QL`qumber `QY`qard `QP`qhase `Q1`0`c`b`n");
	output("`^You're about to take a swing at the tree when you suddenly stop.  What is that little white rock by your feet?");
	output("`n`nYou take a closer look and notice something... It's not a rock! That's a lemon seed!");
	orchard_findseed();
	output("`^You decide to get back to work chopping that tree down!`n`n");
	output("You've completed `QPhase 1`^ of work in the lumber yard.");
	output("It only took you `@one turn`^.`n`n");
	addnav("`@To the forest","forest.php");
	addnav("Cut More Trees","runmodule.php?module=lumberyard&op=work");
	addnav("Plant Trees","runmodule.php?module=lumberyard&op=planttree");
	addnav("`@T`7he `@F`7oreman's `@O`7ffice","runmodule.php?module=lumberyard&op=office");
}
if ($op=="lastmeal"){
	$sheriff = get_module_setting("sheriffname","jail");
	page_header(array("The jail of %s", $session['user']['location']));
	output("You tell the sheriff to come over to your cell and order a `#'Last Meal'`0.`n`n");
	output("%s`0 gladly comes back in a little while carrying a beautiful grapefruit.",$sheriff);
	output("`n`nAfter gobbling down the grapefruit, you grab one of the seeds and slip it in your pocket.");
	output("Now all you have to do is wait for the next day and you'll be free!");
	orchard_findseed();
	addnav("Continue","runmodule.php?module=orchard&op=returnjail");
}
if ($op=="returnjail"){
	$sheriff = get_module_setting("sheriffname","jail");
	page_header(array("The jail of %s", $session['user']['location']));
	output("%s comes back and takes your plate away and leads you out of the jail cell.",$sheriff);
	output("You are a bit confused by this.`n`n`#'What is going on?'`0 you enquire.");
	output("`n`n`@'We're going to a hangin'!'`0 replies the Sheriff.");
	output("`n`n`0This seems like a pleasant diversion, so you enquire who is being executed.");
	output("`n`nWith a sly grin, %s`0 responds `@'Why, after such a pleasant last meal, it's clearly you!'",$sheriff);
	addnav("Get Executed","runmodule.php?module=orchard&op=execution");
}
if ($op=="execution"){
	page_header("Hanging Gallows");
	output("Soon enough, there's a rope around your neck and a crowd gathering to watch.");
	output("`n`nYou should be getting nervous at this point.");
	output("`n`nThe trap door is released and you close your eyes.");
	addnav("Shades","runmodule.php?module=orchard&op=jshades");
}
if ($op=="jshades"){
	page_header("Hanging Gallows");
	output("You fall to the ground... it seems that someone was using some cheap rope and it broke.");
	output("`n`nWell, that's a relief.  You're pardoned and sent on your merry way.  You suddenly remember something in your pocket.");
	addnews("%s `@escaped from a hanging. That's luck for you.",$session['user']['name']);
	set_module_pref("injail",0,"jail");
	villagenav();
}
if ($op=="bankkey"){
	page_header("The Fruit Orchard");
	if ($subop==""){
		output("`!Elendir`7 walks you back to his office and starts to search through some drawers.");
		output("\"`#Ah, yes, here it is.  Well, I'm not making any guarantees about this, but I'd be willing to sell this to you for a price.\"");
		output("`n`n`7You pause, a little concerned about how high the price may be.`n`n");
		output("\"`#Only `^12,000 gold`# and `%12 gems`#. Isn't that a great price?\"");
		output("`n`n`7He gives you a knowing grin, sensing that you may actually be interested.");
		addnav("Buy Bank Key","runmodule.php?module=orchard&op=bankkey&subop=buy");
	}elseif ($subop="buy"){
		if ($session['user']['gold']>=12000 && $session['user']['gems']>=12){
			output("`!Elendir`7 takes your gold and gems and hands you a small key in exchange.");
			$session['user']['gold']-=12000;
			$session['user']['gems']-=12;
			set_module_pref("bankkey",2);
		}else{
			if ($session['user']['gold']>=12000)output("`!Elendir`7 stares at you blankly.  \"`#You don't have that many gems, `bgo get some more gems!`b`7\" he says.");
			elseif ($session['user']['gems']>=12) output("`!Elendir `7stares at you blankly.  \"`#You don't have enough gold, `bgo get some more gold!`b`7\" he says.");
			else output("`!Elendir `7stares at you blankly.  \"`#You don't have enough gold or gems, `bgo get some more!`b`7\" he says.");
		}
	}
	addnav("Return to the entrance","runmodule.php?module=orchard");
}
if ($op=="bank"){
	page_header("Ye Olde Bank");
	output("`6You show `@Elessa`6 your bank key and she leads you to the back room where the locked boxes are kept.");
	output("`n`nYou match up your key with the correct box and open it.");
	output("`n`nThere's nothing there! Curse that `!Elendir`6!! You shake the box and then a tiny little seed falls out.");
	output("`n`nExcellent!`n");
	orchard_findseed();
	addnav("Return to the Front of the Bank","bank.php");
	set_module_pref("bankkey",0);
	villagenav();
}
if ($op=="cedrick"){
	$iname = getsetting("innname", LOCATION_INN);
	page_header($iname);
	rawoutput("<span style='color: #9900FF'>",true);
	output_notl("`c`b$iname`b`c");
	if ($subop==""){
		output("\"`%You're looking for seeds, are ya?`0\" Cedrik asks.  \"`%Well I guess I could part with my prized Apricot seed, but it'll cost ya. `^10 gems`% and `^10,000 gold`%!`0\"`n`n");
		output("Will you buy the seed from Cedrick?");
		addnav("Buy Apricot seed","runmodule.php?module=orchard&op=cedrick&subop=buy");
	}elseif ($subop="buy"){
		if ($session['user']['gold']>=10000 && $session['user']['gems']>=10){
			output("Cedrick takes your gold and gems and hands you a small seed in exchange.");
			$session['user']['gold']-=10000;
			$session['user']['gems']-=10;
			orchard_findseed();
		}else{
			if ($session['user']['gold']>=10000)output("Cedrik stares at you blankly.  \"`%You don't have that many gems, `bgo get some more gems!`b`0\" he says.");
			elseif ($session['user']['gems']>=10) output("Cedrik stares at you blankly.  \"`%You don't have enough gold, `bgo get some more gold!`b`0\" he says.");
			else output("Cedrik stares at you blankly.  \"`%You don't have enough gold or gems, `bgo get some more!`b`0\" he says.");
		}
	}
	addnav("Other");
	addnav("Return to the Inn","inn.php");
	villagenav();
}
if ($op=="stables"){
	page_header("Merick's Stables");
	output("`7You go searching for the Plum seed in the stables, Merick gives you an odd sort of glance but lets you be.");
	output("Unfortunately you can't seem to find it, just as you're about to give up you spot a large heap of manure in the corner.");
	output("You're not entirely sure you want to go looking in there, but what the heck it's worth it right?`n`n");
	output("You delve into the manure heap up to your waist and push your arms into the pile searching around.");
	output("By some miracle you manage to find a Plum seed in the stinking mess and raise it above you head shouting \"`5Woohoo!`7\"");
	output("`7Seeing what you're doing, Merick comes storming over screaming \"`&Ach, thats disgusting! git outta me stables!`7\" and chases you away.`n`n");
	output("`7Fortunately you managed to keep hold of the Plum seed and race away from the stables triumphantly.");
	orchard_findseed();
	villagenav();
}
if ($op=="abh"){
	if (get_module_pref("seed")==5){
		page_header("Abandoned House");
		output("`7`c`bAbandoned House`b`c`n");
		output("You enter the derelict building to discover... nothing.");
		output("Oddly enough the place is empty having been abandoned some time ago by it's previous owner.`n`n");
		output("You explore a little, and notice a small seed covered in dust, you aren't sure, but it looks like a banana seed.");
		addnav("Return to the Alley","runmodule.php?module=darkalley");
		orchard_findseed();
	}else{
		page_header("Abandoned House");
		output("`7`c`bAbandoned House`b`c`n");
		output("You enter the derelict building to discover... nothing.");
		output("Oddly enough the place is empty having been abandoned some time ago by it's previous owner.`n`n");
		output("You explore a little, but discover nothing of interest, the previous owner must have taken everything with them when they left.");
		addnav("Return to the Alley","runmodule.php?module=darkalley");
	}
}
if ($op=="ramius"){
	page_header("The Graveyard");
	output("`7`b`cThe Mausoleum`c`b");
	if (get_module_pref("seed")==6){
		if ($subop=="restore"){
			$session['user']['deathpower']-=100;
			output("`\$Ramius`7 is impressed with your actions, and agrees to restore life to your peach seed.`n`n");
			orchard_findseed();
		}else{
			if ($session['user']['deathpower']>=100){
				output("`\$Ramius`7 speaks, \"`7You ask a favour of me?  but of course, as you are such a faithful servant to me I would be happy to grant this request.`7\"");
				addnav("Restore the Seed (100 Favors)","runmodule.php?module=orchard&op=ramius&subop=restore");
			}else{
				output("`\$Ramius`7 speaks, \"`7No, I refuse to grant your request.  If you want something from me, you have to earn it.  Continue my work and we may speak further.`7\"");
			}
		}
	}
	output("`n`nYou have `6%s`7 favor with `\$Ramius`7.", $session['user']['deathpower']);
	addnav("Question `\$Ramius`0 about the worth of your soul","graveyard.php?op=question");
	$max = $session['user']['level'] * 5 + 50;
	$favortoheal = round(10 * ($max-$session['user']['soulpoints'])/$max);
	addnav(array("Restore Your Soul (%s favor)",$favortoheal),"graveyard.php?op=restore");
	addnav("Places");
	addnav("S?Land of the Shades","shades.php");
	addnav("G?Return to the Graveyard","graveyard.php");
	modulehook("ramiusfavors");
}
if ($op=="odin"){
	page_header("The Ancient Hall");
	output("`7`b`cThe Ancient Halls`c`b");
	if (get_module_pref("seed")==6){
		if ($subop=="restore"){
			$session['user']['deathpower']-=100;
			output("`&Odin`7 is impressed with your actions, and agrees to restore life to your peach seed.`n`n");
			orchard_findseed();
		}else{
			if ($session['user']['deathpower']>=100){
				output("`&Odin`7 speaks, \"`7You ask a favour of me?  but of course, as you are such a faithful servant to me I would be happy to grant this request.`7\"");
				addnav("Restore the Seed (100 Favors)","runmodule.php?module=orchard&op=odin&subop=restore");
			}else{
				output("`&Odin`7 speaks, \"`7No, I refuse to grant your request.  If you want something from me, you have to earn it.  Continue my work and we may speak further.`7\"");
			}
		}
	}
	output("`n`nYou have `6%s`7 favor with `&Odin`7.", $session['user']['deathpower']);
	addnav("Question `\$Odin`0 about the worth of your soul","runmodule.php?module=valhalla&location=ancienthall&op=question");
	$max = $session['user']['level'] * 5 + 50;
	$favortoheal = round(10 * ($max-$session['user']['soulpoints'])/$max);
	addnav(array("Restore Your Soul (%s favor)",$favortoheal),"runmodule.php?module=valhalla&location=ancienthall&op=restore");
	addnav("Places");
	addnav("Return to Valhalla","runmodule.php?module=valhalla&location=valhalla");
	addnav("A?Return to the Ancient Halls","runmodule.php?module=valhalla&location=ancienthall");
}

if ($op=="hof"){
	page_header("Hall of Fame");
	$names=array("","Apple","Orange","Pear","Apricot","Banana","Peach","Plum","Fig","Mango","Cherry","Tangerine","Grapefruit","Lemon","Avocado","Lime","Pomegranate","Kiwi","Cranberry","Star Fruit","Dragonfruit");
	$perpage = get_module_setting('perpage');
	if ($subop=="") $subop=1;
	$min = ($subop-1)*$perpage;
	$limit = "LIMIT $min,$perpage";
	$sql = "SELECT COUNT(*) AS c FROM " . db_prefix("module_userprefs") . " WHERE modulename = 'orchard' AND setting = 'tree' AND value > 0";
	$result = db_query($sql);
	$row = db_fetch_assoc($result);
	$total = $row['c'];
	addnav("Pages");
	for($i = 0; $i < $total; $i+= $perpage) {
		$pnum = ($i/$perpage+1);
		$min = ($i+1);
		$max = min($i+$perpage,$total);
		addnav(array("Page %s (%s-%s)", $pnum, $min, $max), "runmodule.php?module=orchard&op=hof&subop=$pnum");
	}
	$sql = "SELECT prefs.value, users.name FROM ".db_prefix("module_userprefs")." AS prefs , ".db_prefix("accounts")." AS users WHERE acctid = userid AND modulename = 'orchard' AND setting = 'tree' AND value > 0 ORDER BY (value+0) DESC $limit";
	$result = db_query($sql);
	$name = translate_inline("Name");
	$tree = translate_inline("Best Tree");
	$none = translate_inline("No Trees Found");
	rawoutput("<table border='0' cellpadding='2' cellspacing='1' align='center' bgcolor='#999999'>");
	rawoutput("<tr class='trhead'><td>$name</td><td>$tree</td></tr>");
	if (db_num_rows($result)==0) output_notl("<tr class='trlight'><td colspan='2' align='center'>`&$none`0</td></tr>",true);
	else{
		for ($i=0;$i<db_num_rows($result);$i++){
			$row = db_fetch_assoc($result);
			if ($row['name']==$session['user']['name']) rawoutput("<tr class='trhilight'><td>");
			else  rawoutput("<tr class='".($i%2?"trdark":"trlight")."'><td>");
			output_notl("`&%s`0",$row['name']);
			rawoutput("</td><td>");
			output_notl("`@%s`0",$names[$row['value']]);
			rawoutput("</td></tr>");
		}
	}
	rawoutput("</table>");
	addnav("Other");
	addnav("Back to HoF", "hof.php");
	villagenav();
}
page_footer();
?>