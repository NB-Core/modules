<?php
function uno_getmoduleinfo(){
	$info=array(
		"name"=>"UNO",
		"version"=>"1.1.0",
		"author"=>"`%Simon Welsh`0`nLoosely based on the unobot in #uno and wordpython by `2Oliver Brendel",
		"category"=>"Games",
		"vertxtloc"=>"http://simon.geek.nz/",
		"download"=>"http://dragonprime.net/index.php?module=Downloads;sa=dlview;id=975",
		"settings"=>array(
			"Uno - Settings,title",
			"fee"=>"Fee for this game?,int|50",
			"maxplayers"=>"How many players are allowed for this game? (Server performance),range,2,10,1|10",
			"minplayers"=>"How many players are necessary for this game?,range,2,10,1|2",
			"gamename"=>"How is this game called in the parlor?,text|UNO",
			"allowbuild"=>"Allow draw twos/fours to build up?,bool|1",
			"i.e. player A plays a D2. If set to yes, player B can play another D2 on top, making player C draw 4 unless player C can play a D2 on top.,note",
		),
		"requires"=>array(
			"playergames"=>"1.0|`2Oliver Brendel",
		), 
	);
	return $info;
}
function uno_install(){
	module_addhook("parlorgames");
	return true;
}
function uno_uninstall(){
	return true;
}
function uno_dohook($hookname,$args){
	switch ($hookname) {
		case "parlorgames":
			$merge=array("fee"=>get_module_setting("fee"),"module"=>"uno","name"=>translate_inline("UNO - The fun card game"));
			array_push($args,$merge);
			break;
	}
	return $args;
}
function uno_run(){
	require_once("./modules/playergames/func.php");
	require_once("./modules/uno/func.php");
	require_once("./modules/uno/run.php");
	uno_run_private();
}
?>