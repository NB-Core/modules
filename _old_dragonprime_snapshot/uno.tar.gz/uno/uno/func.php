<?php
function uno_check_deck(&$data){
	//Pile -> Deck
	if(count($data['deck']) == 0) $data['deck'] = $data['pile'];
	//No cards in deck or pile -- Lets make a new deck
	if(count($data['deck']) == 0) uno_make_deck($data['deck'],$data);
	//Emptying pile
	$data['pile'] = array();
}
function uno_draw($id=false,$number,$data,$amount=1){
	if($amount === true){
		$return = true;
		$dataedit = false;
		unset($amount);
	}else{
		$return = false;
		$dataedit = true;
		uno_check_deck($data);
	}
	if($id === false){
		global $session;
		$ids = $session['user']['acctid'];
		$sql="SELECT playerone,players FROM ".db_prefix("playergames")." WHERE number=$number LIMIT 1";
		$result=db_query($sql);
		$row=db_fetch_assoc($result);
		$array=explode(",", $row['players']);
		$pos = array_keys($array,$ids);
		$pos[0]++;
		if($session['user']['acctid'] == $row['playerone']) $id = $array[0];
		else $id = $array[$pos[0]];
		if(!isset($array[$pos[0]])) $id = $row['playerone'];
	}
	if(isset($amount) && $amount > 1){
		$card = array();
		for(;$amount!=0;$amount--){
			if($return === true) $card[] = uno_draw($id,$number,$data,true);
			else $data = uno_draw($id,$number,$data);
		}
	}elseif($dataedit === true){
		$rand = array_rand($data['deck']);
		$data[$id][] = $data['deck'][$rand];
		unset($data['deck'][$rand]);
	}elseif($return === true){
		$rand = array_rand($data['deck']);
		$card = $data['deck'][$rand];
	}
	if($return === true) return $card;
	else return $data;
}
function uno_getcards($number=false,$id=false,$data=false){
	global $session;
	if($number === false) $number=httpget("number");
	if($data === false){
		require_once("./modules/playergames/func.php");
		$data=getdata($number);
	}
	if($id === false) $id=$session['user']['acctid'];
	if(isset($data[$id])) $cards=$data[$id];
	else{
		$cards=uno_deal_cards();
	}
	return $cards;
}
function uno_showcards($cards=false,$number=false){
	global $session;
	if(!is_array($cards)) $cards=uno_cards();
	if($number === false) $number=httpget("number");
	foreach($cards as $card){
		rawoutput("[<a href=\"runmodule.php?module=uno&number=$number&op=play&card=$card\">");
		output_notl("$card`0");
		rawoutput("</a>]");
		addnav("","runmodule.php?module=uno&number=$number&op=play&card=$card");
	}
}
function uno_cards(){
	$colours=array(
		"`$",
		"`@",
		"`1",
		"`^",
	);
	$cards=array();
	for($i=0;$i!=4;$i++){
		$cards[$colours[$i]]=array(
			"0",
			"1",
			"2",
			"3",
			"4",
			"5",
			"6",
			"7",
			"8",
			"9",
			"DT",
			"`^W`1D`$4",
			"S",
			"R",
			"W",
		);
	}
	return $cards;
}
function uno_deal_cards(&$data,$id=false){
	global $session;
	if(!isset($data)){
		require_once("./modules/playergames/func.php");
		$data=getdata(httpget("number"));
	}
	if($id === false) $id = $session['user']['acctid'];
	if(is_array($data[$id])) return $data[$id];
	$deck = $data['deck'];
	$data[$id] = array();
	if(is_array($deck)) uno_make_deck($deck,$data);
	for($i=0;$i!=7;$i++){
		$rand = array_rand($deck);
		$data[$id][] = $deck[$rand];
		unset($deck[$rand]);
	}
	return $data[$id];
}
function uno_reverse_players($number=false){
	if($number===false) $number=httpget("number");
	$sql="SELECT playerone,players FROM ".db_prefix("playergames")." WHERE number=$number LIMIT 1";
	$result=db_query($sql);
	$row=db_fetch_assoc($result);
	if(count($row['players']) == 0){
		uno_nextturn($number);
		return;
	}
	$array=explode(",", $row['players']);
	$array=array_reverse($array,true);
	$sql="UPDATE ".db_prefix("playergames")." SET players=".implode(",",$array)." WHERE number=$number";
	db_query($sql);
}
function uno_nextturn($number){
	//Copied from playergames/func.php by Nightborn
	$sql="SELECT playerone,nextturn,players FROM ".db_prefix("playergames")." WHERE number=".$number;
	$result=db_query($sql);
	$row=db_fetch_assoc($result);
	$players=explode(",",$row['players']);
	while ($checkid=array_shift($players)) {
		if ($checkid==$row['nextturn']) {
			$id=array_shift($players);
			if (!$id) $id=$row['playerone'];
		}
	}
	if (!$id) $id=array_shift(explode(",",$row['players']));
	$sql="UPDATE ".db_prefix("playergames")." SET nextturn=".$id." WHERE number=".$number;
	$result=db_query($sql);	
}
function uno_make_deck(&$deck,$data){
	$deck=array();
	$cards=uno_cards();
	$l=0;
	for($i=0;$i!=14;$i++){
		foreach($cards as $colour=>$numbers){
			$deck[]=$colour.$cards[$colour][$i];
		}
	}
	shuffle($deck);
	if(!isset($data['top']) && isset($data['deck'])){
		$rand=array_rand($data['deck']);
		$data['top']=$data['deck'][$rand];
		unset($data['deck'][$rand]);
	}
}
function uno_canplay($card,$data){
	// Wilds and WD4s
	if(($card[2] == "w" || $card[2] == "`") && !isset($data['draw2']) && !isset($data['draw4'])) $canplay=true;
	elseif(get_module_setting("allowbuild") == 1 && isset($data['draw2']) && $card[2] == "D") $canplay=true;
	elseif(get_module_setting("allowbuild") == 1 && isset($data['draw4']) && $card[2] == "w") $canplay=true;
	elseif(get_module_setting("allowbuild") == 1 && isset($data['draw2'])) $canplay=false;
	elseif(get_module_setting("allowbuild") == 1 && isset($data['draw4'])) $canplay=false;
	else{
		// Colour check
		if($card[1] == $data['top'][1]) $canplay=true;
		// Same card check
		elseif($card[2] == $data['top'][2]) $canplay=true;
		// Can't play card
		else $canplay=false;
	}
	return $canplay;
}
function uno_game_won($data,$id){
	global $session;
	if(count($data[$session['user']['acctid']]) == 0) return true;
	else return false;
}
?>