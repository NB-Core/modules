<?php
function uno_run_private(){
	global $session;
	$number=httpget("number");
	$namegame=getgamename($number);
	$op=httpget('op');
	$data=getdata($number);
	if(!is_array($data['pile'])) $data['pile'] = array();
	page_header("UNO - The fun card game");
	villagenav();
	addnav("Navigation");
	addnav("Main Game Hall","runmodule.php?module=playergames");
//	addnav("Resume","runmodule.php?module=uno&op=resume&number=$number");
	switch($op){
		case "view":
			output("This is the top card: [ %s `0]",$data['top']);
			if(!is_array($data['deck'])) uno_make_deck($data['deck']);
			if(!isset($data['top']) && isset($data['deck'])){
				$rand=array_rand($data['deck']);
				$data['top']=$data['deck'][$rand];
				unset($data['deck'][$rand]);
			}
			if(isset($data['winner'])){
				$sql = "SELECT name FROM ".db_prefix('accounts')." WHERE acctid={$data['winner']} LIMIT 1";
				$result = db_query($sql);
				$row = db_fetch_assoc($result);
				output("`nGame won by %s",$row['name']);
			}
		break;
		case "end":
			endgame($number);
			output("Game has ended");
		break;
		case "resume":
			if(!is_array($data['deck'])) uno_make_deck($data['deck']);
			if(!isset($data['top']) && isset($data['deck'])){
				$rand=array_rand($data['deck']);
				$data['top']=$data['deck'][$rand];
				unset($data['deck'][$rand]);
			}
			if(!is_array($data[$session['user']['acctid']])) $data[$session['user']['acctid']]=uno_deal_cards($data,$session['user']['acctid']);
			addnav("Draw","runmodule.php?module=uno&op=draw&number=$number");
			addnav("End UNO","runmodule.php?module=uno&op=end&number=$number");
			output("This is the top card: [ %s `0]`n`n",$data['top']);
			output("Your cards:`n");
			uno_showcards(uno_getcards($number,$session['user']['acctid'],$data));
		break;
		case "play":
			require_once("./modules/uno/run_play.php");
			$data = uno_run_play($number,$data);
		break;
		case "wild":
			$card = httpget("card");
			$colour = httpget("colour");
			$place = array_keys($data[$session['user']['acctid']],$card);
			if(httpget("wd4") == "yes"){
				if(get_module_setting("allowbuild") == 0){
					$data = uno_draw(false,$number,$data,4);
					uno_nextturn($number);
				}elseif(isset($data['draw4'])) $data['draw4']++;
				else $data['draw4'] = 1;
			}
			$card = "`".$colour[1]."*";
			$data['top'] = $card;
			output("You have played [ %s `0]",$card);
			$data['pile'][] = $data[$session['user']['acctid']][$place[0]];
			unset($data[$session['user']['acctid']][$place[0]]);
			if(uno_game_won($data,$session['user']['acctid']) === false) nextturn($number);
			else{
				output("You have won the game!!!");
				$data['winner'] = $session['user']['acctid'];
				setdata($number,$data);
				endgame($number);
				page_footer();
				die();
			}
		break;
		case "draw":
			uno_check_deck($data);
			if(isset($data['draw2'])){
				uno_draw($session['user']['acctid'],$number,$data,$data['draw2']*2);
				$play = true;
				output("You drew %s cards.",$data['draw2']*2);
				unset($data['draw2']);
			}elseif(isset($data['draw4'])){
				uno_draw($session['user']['acctid'],$number,$data,$data['draw4']*4);
				$play = true;
				output("You drew %s cards.",$data['draw4']*4);
				unset($data['draw4']);
			}else{
				$card = uno_draw($session['user']['acctid'],$number,$data,true,1);
				output("You drew [ %s `0]`n",$card);
				$play = false;
			}
			if(uno_canplay($card,$data)===true && !$play) addnav(array("Play [ %s `0]",$card),"runmodule.php?module=uno&op=play&number=$number&card=$card");
			if(!isset($card)) addnav("Pass","runmodule.php?module=uno&op=pass&number=$number");
			else addnav("Pass","runmodule.php?module=uno&op=pass&number=$number&card=$card");
		break;
		case "pass":
			$card = httpget("card");
			if($card) $data[$session['user']['acctid']][] = $card;
			output("You passed");
			nextturn($number);
		break;
		default:
			uno_make_deck($data['deck'],$data);
			uno_deal_cards($data,$session['user']['acctid']);
			if(!isset($data['top']) && isset($data['deck'])){
				$rand=array_rand($data['deck']);
				$data['top']=$data['deck'][$rand];
				unset($data['deck'][$rand]);
			}
			addnav("Draw","runmodule.php?module=uno&op=draw&number=$number");
			addnav("End UNO","runmodule.php?module=uno&op=end&number=$number");
			output("This is the top card: [ %s `0]`n`n",$data['top']);
			output("Your cards:`n");
			uno_showcards(uno_getcards($number,$session['user']['acctid'],$data));
		break;
	}
	setdata($number,$data);
	page_footer();
}
?>