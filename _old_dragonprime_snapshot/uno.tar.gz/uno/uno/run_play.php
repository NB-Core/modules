<?php
function uno_run_play($number,&$data){
	global $session;
	$card=httpget("card");
	$canplay = uno_canplay($card,$data);
	if($canplay === false){
		output("You can't play that card, pick another`n");
		addnav("Draw","runmodule.php?module=uno&o=draw&number=$number");
		addnav("End UNO","runmodule.php?module=uno&op=end&number=$number");
		output("This is the top card: [ %s `0]`n`n",$data['top']);
		output("Your cards:`n");
		uno_showcards(uno_getcards($number,$session['user']['acctid'],$data));
	}elseif($canplay === true){
		switch($card[2]){
			case "s":
				uno_nextturn($number);
			break;
			case "r":
				uno_reverse_players($number);
			break;
			case "W":
				$wild = "no";
			case "`":
				if(!isset($wild)) $wild = "yes";
				output("Choose a colour: ");
				$red = translate_inline("`\$RED`0");
				$blue = translate_inline("`1BLUE`0");
				$green = translate_inline("`@GREEN`0");
				$yellow = translate_inline("`^YELLOW`0");
				rawoutput("<a href=\"runmodule.php?module=uno&number=$number&op=wild&colour=$red&wd4=$wild&card=$card\">");
				output_notl("$red</a>",true);
				rawoutput("<a href=\"runmodule.php?module=uno&number=$number&op=wild&colour=$blue&wd4=$wild&card=$card\">");
				output_notl("$blue</a>",true);
				rawoutput("<a href=\"runmodule.php?module=uno&number=$number&op=wild&colour=$green&wd4=$wild&card=$card\">");
				output_notl("$green</a>",true);
				rawoutput("<a href=\"runmodule.php?module=uno&number=$number&op=wild&colour=$yellow&wd4=$wild&card=$card\">");
				output_notl("$yellow</a>",true);
				addnav("","runmodule.php?module=uno&number=$number&op=wild&colour=$red&wd4=$wild&card=$card");
				addnav("","runmodule.php?module=uno&number=$number&op=wild&colour=$blue&wd4=$wild&card=$card");
				addnav("","runmodule.php?module=uno&number=$number&op=wild&colour=$green&wd4=$wild&card=$card");
				addnav("","runmodule.php?module=uno&number=$number&op=wild&colour=$yellow&wd4=$wild&card=$card");
				setdata($number,$data);
				page_footer();
				die();
			break;
			case "D":
				if(get_module_setting("allowbuild") == 0){
					$data = uno_draw(false,$number,$data,4);
					uno_nextturn($number);
				}elseif(isset($data['draw2'])) $data['draw2']++;
				else $data['draw2'] = 1;
			break;
			default:
			break;
		}
		$data['top']=$card;
		output("You have played [ %s `0]",$card);
		$place=array_keys($data[$session['user']['acctid']],$card);
		$data['pile'][] = $data[$session['user']['acctid']][$place[0]];
		unset($data[$session['user']['acctid']][$place[0]]);
		if(uno_game_won($data,$session['user']['acctid']) === false) nextturn($number);
		else{
			output("You have won the game!!!");
			$data['winner'] = $session['user']['acctid'];
			setdata($number,$data);
			endgame($number);
			page_footer();
			die();
		}
	}else die("CHEATER!!!!!!!!!!!!!");
	return $data;
}
?>