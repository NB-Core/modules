<?php

// The Haunted Museum v1.0
// My first ever LoGD Module
// Written by Lurch 
// www.taf.co.nz

require_once("lib/villagenav.php");

function haunted_getmoduleinfo(){
	$info = array(
		"name"=>"The Haunted Museum",
		"version"=>"1.0",
		"author"=>"Lurch",
		"category"=>"Forest Specials",
		"download"=>"http://dragonprime.net/users/Lurch/haunted.zip",
	);
	return $info;
}


function haunted_install() {
	if (!is_module_active('haunted')){
		output("`4Installing The Haunted Museum Module.`n");
	}else{
		output("`4Updating The Haunted Museum Module.`n");
	}
	module_addeventhook("forest", "return 100;");
		return true;
}


function haunted_uninstall(){
	output("`4Uninstalling The Haunted Museum Module.`n");
	return true;
}

function haunted_runevent($type) {
	global $session;
	$op = httpget('op');

	$session[user][specialinc] = "module:haunted";
	$from = "forest.php?";

	page_header();

	switch ($op) {
		case "":
			output("`2You suddenly trip and fall down, you expect any moment now to stop falling but you don't and keep on going. You stop screaming after awhile as you have been falling for quite sometime now`n`n");
			output("Finally after many hours you see something appearing at a great rate at the bottom of the hole, you brace yourself for the big impact that is to come and close your eyes...`n`n");
			output("`2But you feel nothing and come to a stop as though you were on a cushion of air. Finally you are standing on terra firma and as you look around you see two doors one to the right and the other on the left of you... ");
			addnav("Choose the left door", $from."op=left");
			addnav("Choose the right door", $from."op=right");
			addnav("Look for another way out", $from."op=out");
			addnews("%s has discovered the Haunted Museum.",$session['user']['name']);
			break;
		case "out":
			output("`2You decide to look for another way out, and spot a ladder to the left and head on up.`n`n");
			output("After sometime climbing you reach the top, however you smell really bad so you loose some charm.`n`n");
				$session['user']['charm']--;
				$session['user']['specialinc'] = "";
				addnews("%s is a big ass chicken...and took the easy way out....",$session['user']['name']);
			break;

		case "left":
			output("`2You open the left door and step through to the other side....");
			switch(e_rand(1,3)) {
				case 1: 
					output("On the other side you see a large room which looks like a Museum. You also hear loud moaning which seems to be getting louder and louder. To your dismay a mummie is slowly drawing nearing preparing to attack....`n`n");
					addnav("Fight", $from."op=fightmummie");
					break;
				case 2:
					output("On the other side your see a large room which looks like a Museum. You notice some gold trinkets laying on the floor and decide to take them. After snooping around for awhile you also find a door marked exit and decide to open it, on the other side you find yourself back in the forest again...`n`n");
					$gold = $session['user']['level'] * 50;
					$session['user']['gold'] += $gold;
					output("`&You find `^%s`& Pieces of gold.`n`n", $gold);
					debuglog("found %s gold at the Haunted Museum.", $gold);
					$session['user']['specialinc'] = "";
					break;
				case 3:
					output("On the other side you see a large room which looks like a Museum. You look around and see nothing much apart from a small box which is laying on the floor. You walk over to the box and open it and find some weapon cleaner.`n`n");
					output("`@You think to yourself, why not. Without haste you apply the cleaner to your weapon which is now gleaming more than ever. There now appears to be a Blue-Glow � around it...and the weapon appears alot stronger now! After doing this you suddenly notice a door marked exit and head on out to the forest with new vigor!");
					apply_buff("blueglow", array(
						"name" => "`@Blue-Glow � ",
						"rounds" => 15,
						"wearoff" => "`@The Blue-Glow � fades and finally goes out.",
						"badguydefmod" => 0.5,
						"roundmsg" => "`@You attack with all your might knowing the Blue-Glow � will be there to help!",
						"survivenewday" => 1,
						"newdaymessage" => "`@The Blue-Glow � from your weapon is still there, you breath a sigh of relief.")
					);
					$session['user']['specialinc'] = "";
					addnews("%s has discovered the sacred Blue-Glow �",$session['user']['name']);
					break;		
			} 


			break;
		case "right":
			output("`2You open the right door and step through into a long hallway, you read afew of the name tags on the doors as you go past and come to the conclusion you are in a Museum of some type...`n`n");
			switch(e_rand(1,3)) {
				case 1:
					output("You decide to open one of the doors with caretaker writen on it. On the otherside you find and empty room with something glittering in the mop bucket. You take the mop out to find a gold watch. You also notice behind the bucket a door marked exit, you open the door to find that you are now back in the forest.`n`n");
					$gold = $session['user']['level'] * 15;
					$session['user']['gold'] += $gold;
					output("`&The gold watch is worth `^%s`& pieces of gold.`n`n", $gold);
					debuglog("Recieved %s gold after finding gold on mop at haunted museum.", $gold);
					break;
				case 2:
					output("You decide to open the door marked custumes. On the otherside you find a makeup table, you sit down and quickly look around to make sure no-one is looking and apply some lipstick! You look in the mirror and think to yourself, man I look good. `n`n");
					output("You also notice that the mirror moves, you move it aside and find an exit that takes you back into the forest. You also recieve some charm for wearing some might fine makeup...`n`n");
					addnews("%s is looking rather pretty in their bright red lipstick.",$session['user']['name']);
					$session['user']['charm']++;
					break;
				case 3:
					output("You decide to open the door marked exit!`n`n");
					output("You find yourself back in the forest.");
					break;
			} 
			
			$session['user']['specialinc'] = "";
			break;
		case "fightmummie":
			$session['user']['specialinc'] = "";
			$guardattack = $session['user']['attack'] * 1.5; 
			$guarddefence = $session['user']['defence'] * 1.3; 
			$guardhitpoints = $session['user']['maxhitpoints'] * 2.25;
			$badguy = array(
						"creaturename" => "Museum Mummie",
						"creaturelevel" => $session['user']['level'] + 2, 
						"creatureweapon" => "Long Wrappings",
						"creatureattack" => $guardattack,
						"creaturedefense" => $guarddefence,
						"creaturehealth" => $guardhitpoints,
						"diddamage" => 0
			);
			$session['user']['badguy'] = createstring($badguy);
			$op = "fight";
			httpset("op", "fight");
		case "run":
		case "fight":
			$fight = true;
			if ($op == "run") {
				output("`&The mummie is far to quick for you and blocks your exit!`n");
				$fight=true;
				$battle=true;
			} else if ($op == "fight") {
				$battle = true;
			}
			if ($fight == true) $session['user']['specialinc'] = "module:haunted";
			if ($battle) {
				include("battle.php");
				if ($victory){
					output("`n`7You defeat the Museum Mummie!`n");
		            $XpBonus = round($session['user']['experience'] * 0.12);
		            $session[user][experience] += $XpBonus;
		            output("After defeating the Museum Mummie you find that he was standing on the exit back to the forest.");
					output("`^You gain %s points of experience!", $XpBonus);
			        $session['user']['specialinc'] = "";
				    addnav("Back to the forest", "forest.php");
				}elseif ($defeat){
					output("`n`2You hear the Museum Mummie still whisper: \"`2Today is your day.`2\"`n`n");
					$session['user']['specialinc']="";
				    $session['user']['alive']=false;
				    $session['user']['gold']=0;
				    $session['user']['hitpoints']=0;
				    $session['user']['experience']=round($session['user']['experience']*.9,0);
				    $session['user']['gravefights']=round($session['user']['gravefights']*0.75);
				    output("`b`&The Museum Mummie takes your down!`n");
				    output("Your gold forever lost in the museum!`n");
				    output("You lost 10% experience!`n");
				    output("You can fight again tomorrow.`n");
				    addnav("Daily news","news.php");
				    debuglog("News @ 7 The Museum Mummie strikes again....");
				    addnews("%s was killed by the Museum Mummie",$session['user']['name']);
				}else{
					fightnav(true, true);
				}
			}
			break;

	} 
}
?>