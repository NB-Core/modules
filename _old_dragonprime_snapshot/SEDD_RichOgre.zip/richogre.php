<?php

// Added a default value to basestat
// Added admin configurable percent chance for good outcome
// Changed admin config increment dropdowns to multiples of 5

function richogre_getmoduleinfo(){
	$info = array(
		"name"=>"Deedee's Rich Ogre",
		"version"=>"1.0",
		"author"=>"`%Deedee`0 - Built with Module Builder by `3Lonny Luberts`0",
		"category"=>"Forest Specials",
		"download"=>"http://dragonprime.net/index.php?action=viewfiles;user=Deedee",
		"settings"=>array(
		"richogre Settings,title",
		"basestat"=>"Stat to base increase and decrease on,enum,charm,Charm,maxhitpoints,Hitpoints,dragonKills,Dragonkills,attack,Attack,defense,Defense|maxhitpoints",
		"baseperc"=>"Percent to increase/decrease stat,range,0,100,5|50",
		"chance"=>"Percent chance for good outcome,range,0,100,5|50"
		),
	);
	return $info;
}

function richogre_install(){
	module_addeventhook("forest",
	"return (is_module_active('cities')?0:100);");
	return true;
}

function richogre_uninstall(){
	return true;
}

function richogre_dohook($hookname,$args){
	return $args;
}

function richogre_runevent($type,$link) {
	global $session;
	$from = $link;
	$op = httpget('op');
	$session['user']['specialinc'] = "module:richogre";
	if ($op==""){
		output("`2`n`nYou become aware of a particularly nasty smell in the air about you!  Your senses do not mislead you, as you quietly investigate and come upon `%Rich Ogre!");
		output("`2`n`nHe is sloppy and careless and well known to drop gold on his daily wonderings...  Do you risk snapping a twig under foot to follow him and collect any dropped gold?`0");
		addnav("Follow Ogre",$from."op=yes");
		addnav("Continue on your way",$from."op=no");
	} elseif ($op=="no") {
		output("`2You continue quietly on your way, in the other direction!`0");
	$session['user']['specialinc'] = "";
		} else {
			output("`2Following Ogre... not too close...`n`n`0");
			$basestat = get_module_setting("basestat");
			$baseperc = get_module_setting("baseperc") * .01;
	if (e_rand(0,100) <= get_module_setting("chance")) {
		$amt = round($session['user'][$basestat] * $baseperc);
	if ($amt > $session['user']['gold']) $amt = $session['user']['gold'];
		$session['user']['gold']+=$amt;
		output("`^`2Today was a good day to follow Ogre, who seems particularly distracted as he has dropped `6$amt gold`2, which you quickly and quietly pick up!`0");
		$session['user']['specialinc'] = "";
	} else {
			$amt = round($session['user'][$basestat] * $baseperc);
			if ($amt > $session['user']['gold']) $amt = $session['user']['gold'];
			$session['user']['gold']-=$amt;
			output("`4Today was NOT such a good day to follow Ogre!  He has discovered you following and taken `6$amt gold `4from you in a fit of rage before stomping off!`n`n");
			$session['user']['specialinc'] = "";
		}
	}
}

function richogre_run(){
}
 
?>