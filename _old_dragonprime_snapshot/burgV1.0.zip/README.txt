===============================================================================================================================

*** Kurzbeschreibung: ***

Diese zip-Datei beinhaltet die Umsetzung von Apollons Ritterburg aus 0.9.7 f�r 1.0.X Server

===============================================================================================================================

*** Installation: ***

Die Dateien ins Modulverzeichnis kopieren.
Anschlie�end in die Grotte wechseln und das Modul "burg.php" installieren.
Modul aktivieren.

===============================================================================================================================

*** Erweiterungen: ***

Die neuen modulehooks "burg" und "burg_beschreibung" erlauben in einfacher Form das Hinzuf�gen von eigenen Modulen 
in der Burg.
Module m�ssen mit add_modulehook("stadtmauer"); verlinkt werden.
Die Beschreibung kann beliebig durch add_modulehook("stadtmauer_beschreibung); erg�nzt werden.
Beide hooks einfach durch cases in der function dohook aufrufen.
Somit ist ein "unbegrenzter" Ausbau der Burg in Zukunft gew�hrleistet.
Die Einordnung der Burg erfolgt in der Kategorie "Stadtmauer".

===============================================================================================================================


Viel Spa�! :)
Apollon und BansheeElhayn.


**************************

Versionshistorie:

21.12.2005  --  Version 1.0, Umsetzung der 0.9.7 Version f�r 1.0.X, erste Ver�ffentlichung