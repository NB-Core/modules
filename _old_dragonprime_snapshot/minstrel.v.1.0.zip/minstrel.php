<?
require_once "common.php";
checkday();

page_header("Traveling Minstrels");
output("`c`b`&The Wagon of Traveling Minstrels`0`b`c");
if ($HTTP_GET_VARS[op]==""){
    addnav("Return to the village","village.php");
	output("`@As you head to the edge of town you hear the lovely sounds of lute's and clarinets.`n");
	output("`@You see a wagon ahead with numerous players outside, each practicing their own instrument.`n", true);
    output("`@As you get closer a man steps out of the wagon.`n`n",true);
	output("`#Hullo there.  Welcome to Jayden's Traveling Minstrels.  I can offer you the finest minstrels in all the land.`n`n",true);
	output("`@He whispers to you then..`#I can also offer ye the cheapest minstrels in all the land...`@he points over to a scraggly band of guys playing not so in tune.`n`n",true);
	output("`#Each band of minstrel's offers their own selection of music.  They'll travel with you all day, and they can lift your spirits!`n",true);
	output("`#But at the end of the day, their work is done, unless of course you come back tomorrow and want to hire them again!`n`n",true);
    output("<table cellpadding='0' border='0'><tr><td align='center'><b>Minstrel's Name</b></td><td align='center'><b>Attack Buff<b></td><td align='center'><b>Cost</b></td></tr>",true);
    output("<tr class='trdark'><td><a href='minstrel.php?op=robin'>Robin's Minstrels</a></td><td align='right'>20%</td><td align='right'>`^300 Gold</td></tr>",true);
	output("<tr class='trlight'><td><a href='minstrel.php?op=lancelot'>Lancelot's Band</a></td><td align='right'>30%</td><td align='right'>`^600 Gold</td></tr>",true);
	output("<tr class='trdark'><td><a href='minstrel.php?op=arthur'>King Arthur's Court</a></td><td align='right'>50%</td><td align='right'>`^850 Gold</td></tr>",true);
	output("<tr class='trlight'><td><a href='minstrel.php?op=god'>God's Symphony</a></td><td align='right'>75%</td><td align='right'>`^1000 Gold</td></tr>",true);
	output("</table>",true);
	addnav("","minstrel.php?op=robin");
	addnav("","minstrel.php?op=lancelot");
	addnav("","minstrel.php?op=arthur");
	addnav("","minstrel.php?op=god");
}else if ($HTTP_GET_VARS[op]=="robin"){
	addnav("Return to the village","village.php");
	output("`#Ahh, `^Robin's Minstrels.  `#A most..uh...economical choice.`n", true);
	output("`#Are you sure you want them to travel with you?`n`n", true);
	output("<form action='minstrel.php?op=comp&mins=robin' method='POST'>", true);
	output("<input type='submit' class='button' value='Yes'></form>",true);
	addnav("","minstrel.php?op=comp&mins=robin");
	output("<form action='minstrel.php' method='POST'>", true);
	output("<input type='submit' class='button' value='No'></form>",true);
	addnav("","minstrel.php");
}else if ($HTTP_GET_VARS[op]=="lancelot"){
	addnav("Return to the village","village.php");
	output("`^Lancelot's Band.  `#A very brave choice!!`n", true);
	output("`#Are you sure you want them to travel with you?`n`n", true);
	output("<form action='minstrel.php?op=comp&mins=lancelot' method='POST'>", true);
	output("<input type='submit' class='button' value='Yes'></form>",true);
	addnav("","minstrel.php?op=comp&mins=lancelot");
	output("<form action='minstrel.php' method='POST'>", true);
	output("<input type='submit' class='button' value='No'></form>",true);
	addnav("","minstrel.php");      
}
else if ($HTTP_GET_VARS[op]=="arthur"){
	addnav("Return to the village","village.php");
	output("`^King Arthur's Court!  `#A very fine selection, the coconut player is the best in the land!`n", true);
	output("`#Are you sure you want them to travel with you?`n`n", true);
	output("<form action='minstrel.php?op=comp&mins=arthur' method='POST'>", true);
	output("<input type='submit' class='button' value='Yes'></form>",true);
	addnav("","minstrel.php?op=comp&mins=arthur");
	output("<form action='minstrel.php' method='POST'>", true);
	output("<input type='submit' class='button' value='No'></form>",true);
	addnav("","minstrel.php");      
}
else if ($HTTP_GET_VARS[op]=="god"){
	addnav("Return to the village","village.php");
	output("`#OH MY! `^God's Symphony `#is an excellent choice! You will not find better music in all the land!`n", true);
	output("`#Are you sure you want them to travel with you?`n`n", true);
	output("<form action='minstrel.php?op=comp&mins=god' method='POST'>", true);
	output("<input type='submit' class='button' value='Yes'></form>",true);
	addnav("","minstrel.php?op=comp&mins=god");
	output("<form action='minstrel.php' method='POST'>", true);
	output("<input type='submit' class='button' value='No'></form>",true);
	addnav("","minstrel.php");      
}
else if ($HTTP_GET_VARS[op]="comp"){
    addnav("Return to the village","village.php");
	$minstrel=$HTTP_GET_VARS[mins];
	$wep=$session[user][weapon];
	output("`#Too have them play music, simply click their name in buff area.`n", true);
	output("`#Having the minstrels with you will give you the buff regardless if they play you music or not.`n`n", true);
	     /*<SCRIPT LANGUAGE=\"JScript\">window.close(\"mins\")</SCRIPT>*/
		 if ($minstrel=="robin"){
	      $cost=300;
		  $buff=array("name"=>"<a href='songs.php?mins=robin' target='_blank' onClick=\"window.open('songs.php?mins=robin','mins','scrollbars=yes,resizable=yes,width=300,height=200');return false;\" class='hotmotd'>Robin's Minstrels</a>","rounds"=>50,"wearoff"=>"`3The Minstrels are quite tired today, and head home.","atkmod"=>1.20,"roundmsg"=>"`#The `^interesting music `#from Robin's Minstrels encourages you to fight harder!!","activate"=>"offense");
		  }
		  else if($minstrel=="lancelot"){
		  $cost=600;
		  $buff=array("name"=>"<a href='songs.php?mins=lance' target='_blank' onClick=\"window.open('songs.php?mins=lance','mins','scrollbars=yes,resizable=yes,width=300,height=200');return false;\" class='hotmotd'>Lancelot's Band</a>","rounds"=>60,"wearoff"=>"`3The band has jammed too much, and decides to call it quits for the day.","atkmod"=>1.30,"roundmsg"=>"`#Lancelot's Band jams away.  Your `^$wep `#begins to rock with them!","activate"=>"offense");
		  }
		  else if($minstrel=="arthur"){
		  $cost=850;
		  $buff=array("name"=>"<a href='songs.php?mins=arthur' target='_blank' onClick=\"window.open('songs.php?mins=arthur','mins','scrollbars=yes,resizable=yes,width=300,height=200');return false;\" class='hotmotd'>King Arthur's Court</a>","rounds"=>75,"wearoff"=>"`3It's time for the Court to play at a feast for `#The `^King!","atkmod"=>1.50,"roundmsg"=>"`#King Arthur's Court's music reminds you of battles gone by.  You remember fallen heroes for inspiration!","activate"=>"offense");
		  }
		  else if($minstrel=="god"){
		  $buff=array("name"=>"<a href='songs.php?mins=god' target='_blank' onClick=\"window.open('songs.php?mins=god','mins','scrollbars=yes,resizable=yes,width=300,height=200');return false;\" class='hotmotd'>God's Symphony</a>","rounds"=>100,"wearoff"=>"`3Even God rested on the 7th day.","atkmod"=>1.75,"roundmsg"=>"`#The power of God, the music of God, makes you kick serious ass!","activate"=>"offense");
		  $cost=1000;}
	 if (($session[user][gold]-$cost)<0){
	     output("`#Looks like NO ONE is playing for you, you don't have enough gold!`n", true);}
		 else{
		      $session[user][gold]=$session[user][gold]-$cost;
		      $session[bufflist][101]=$buff;
			  }
}
page_footer();
?>
