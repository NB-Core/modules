<html>
<head><title>Your Minstrels</title>
<style type="text/css">
<!--
.style1 {
	font-family: Geneva, Arial, Helvetica, sans-serif;
	font-size: small;
	font-weight: bold;
}
.style2 {
	font-family: Geneva, Arial, Helvetica, sans-serif;
	font-size: x-small;
}
body,td,th {
	color: #FFFFFF;
}
body {
	background-color: #333333;
}
a:link {
	color: #CCCC66;
}
a:visited {
	color: #CC6600;
}
a:hover {
	color: #CCFF00;
}
-->
</style>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1"></head>
<body>
<?php

if ($HTTP_GET_VARS[mins]=="robin"){
echo "<p class=\"style1\" align=\"center\">Robin's Minstrel's Song List</a></p>";
echo "<font class=\"style2\"><ol>";
echo "<li><a href='songs.php?mins=robin&num=1' target='_self'>Brave Sir Robin</a></li>";
echo "<li><p class=\"style2\" <a href='songs.php?mins=robin&num=2' target='_self'>Monty Medley</a></li>";
echo "<li><p class=\"style2\" <a href='songs.php?mins=robin&num=3' target='_self'>We Try</a></li>";
echo "</ol></font>";
     $songnum=$HTTP_GET_VARS[num];
	 if ($songnum==1){echo '<embed src="midi/r1.mid" autostart="true" loop="true" volume="100" hidden="true">';}
	 if ($songnum==2){echo '<embed src="midi/r2.mid" autostart="true" loop="true" volume="100" hidden="true">';}
	 if ($songnum==3){echo '<embed src="midi/r3.mid" autostart="true" loop="true" volume="100" hidden="true">';}
}
//Lance
 if ($HTTP_GET_VARS[mins]=="lance"){
echo "<p class=\"style1\" align=\"center\">Lancelot's Band Song List</a></p>";
echo "<font class=\"style2\"><ol>";
echo "<li><a href='songs.php?mins=lance&num=1' target='_self'>Lance-A-Rama</a></li>";
echo "<li><a href='songs.php?mins=lance&num=2' target='_self'>Baby, Please don't Lance Me</a></li>";
echo "<li><a href='songs.php?mins=lance&num=3' target='_self'>Can't Lance This</a></li>";
echo "<li><a href='songs.php?mins=lance&num=3' target='_self'>The Right Lance</a></li>";
echo "</ol></font>";
     $songnum=$HTTP_GET_VARS[num];
	 if ($songnum==1){echo '<embed src="midi/l1.mid" autostart="true" loop="true" volume="100" hidden="true">';}
	 if ($songnum==2){echo '<embed src="midi/l2.mid" autostart="true" loop="true" volume="100" hidden="true">';}
	 if ($songnum==3){echo '<embed src="midi/l3.mid" autostart="true" loop="true" volume="100" hidden="true">';}
     if ($songnum==3){echo '<embed src="midi/l4.mid" autostart="true" loop="true" volume="100" hidden="true">';}
}
//Arthur
 if ($HTTP_GET_VARS[mins]=="arthur"){
echo "<p class=\"style1\" align=\"center\">King Arthur's Court Song List</a></p>";
echo "<font class=\"style2\"><ol>";
echo "<li><a href='songs.php?mins=arthur&num=1' target='_self'>It's Only a Model</a></li>";
echo "<li><a href='songs.php?mins=arthur&num=2' target='_self'>Coconut Surprise</a></li>";
echo "<li><a href='songs.php?mins=arthur&num=3' target='_self'>The Castle AAAARGH</a></li>";
echo "<li><a href='songs.php?mins=arthur&num=4' target='_self'>Salute to CastleRock</a></li>";
echo "</ol></font>";
     $songnum=$HTTP_GET_VARS[num];
	 if ($songnum==1){echo '<embed src="midi/a1.mid" autostart="true" loop="true" volume="100" hidden="true">';}
	 if ($songnum==2){echo '<embed src="midi/a2.mid" autostart="true" loop="true" volume="100" hidden="true">';}
	 if ($songnum==3){echo '<embed src="midi/a3.mid" autostart="true" loop="true" volume="100" hidden="true">';}
     if ($songnum==3){echo '<embed src="midi/a4.mid" autostart="true" loop="true" volume="100" hidden="true">';}
}
//God
 if ($HTTP_GET_VARS[mins]=="god"){
echo "<p class=\"style1\" align=\"center\">God's Symphony Song List</a></p>";
echo "<font class=\"style2\"><ol>";
echo "<li><a href='songs.php?mins=god&num=1' target='_self'>The 5th</a></li>";
echo "<li><a href='songs.php?mins=god&num=2' target='_self'>Big Number 9</a></li>";
echo "<li><a href='songs.php?mins=god&num=3' target='_self'>Ride with God</a></li>";
echo "<li><a href='songs.php?mins=god&num=4' target='_self'>Rock your Heaven</a></li>";
echo "</ol></font>";
     $songnum=$HTTP_GET_VARS[num];
	 if ($songnum==1){echo '<embed src="midi/g1.mid" autostart="true" loop="true" volume="100" hidden="true">';}
	 if ($songnum==2){echo '<embed src="midi/g2.mid" autostart="true" loop="true" volume="100" hidden="true">';}
	 if ($songnum==3){echo '<embed src="midi/g3.mid" autostart="true" loop="true" volume="100" hidden="true">';}
     if ($songnum==3){echo '<embed src="midi/g4.mid" autostart="true" loop="true" volume="100" hidden="true">';}
}
?>
</body>
</html>