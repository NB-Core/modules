<?
require_once "common.php";
$session[user][hitpoints]*.5;
page_header("Purgatory");
//Made by DeathDragon
//add this to village:
//addnav("Purgatory","purgatory.php");
/*also add this to graveyard,news, and shades.
    if ($session[user][location]==666){
		redirect("newday.php?rezzed=true");
		}else{
			and then right at the end before page_footer add:
			}
			
			then in newday after $resline = $_GET['resurrection']=="true" ? "&resurrection=true" : "" ;
			add:
			if ($resline == "" &&  $_GET['rezzed']=="true")
    $resline = $_GET['rezzed']=="true" ? "&rezzed=true" : "" ;

	then after if ($_GET['resurrection']=="true"){
            addnews("`&{$session['user']['name']}`& has been resurrected by `\$Ramius`&.");
            $spirits=-6;
            $session['user']['deathpower']-=100;
            $session['user']['restorepage']="csquare.php?c=1";
        }
		add:
		else if ($_GET['rezzed']=="true")  {
             $spirits=-6;
			 $session[user][location]=99;
              $session['user']['restorepage']="csquare.php?c=1";
                       $session['user']['resurrections']++;
            output("`@You are resurrected!  This is your ".ordinal($session['user']['resurrections'])." resurrection.`0`n");
}
save and upload all the files and your done!
addcommentary();
checkday();

output("`b`c`2Purgatory `0`c`b");

output("`n`nYou enter a brightly lit temple, a sign hangs above the doorway, the sign reads, \"Purgatory\". You notice a bishop next to");
output("`n a Giant Golden Cross. He says, \"You are in a place in between life and death, here you can pray for fallen ones and bring `n");
output("`n them back from the grasps of Ramius. But in doing this you will lose 3 times the amount of favour with Ramius than you would`n");
output("`n regurally lose. Also by entering this place you have lost half of your hitpoints.\" You recount that you have ".$session[user][deathpower]."`n");
output("`n favour with Ramius.`n");


addnav("Return to the Camelot","csquare.php");

if ($HTTP_GET_VARS[op]==""){
  checkday();
           if ($session[user][deathpower] > 299) {
             output("The Bishop asks, \" Who would you like to Resurect?\"`n`n");
              output("<form action='purgatory.php?op=findname' method='POST'>T<u>o</u>: <input name='to' accesskey='o'> (partial names are ok, you will be asked to confirm the Ressurection before it occurs).`n",true);
                output("<input type='submit' class='button' value='Preview List'></form>",true);
                output("<script language='javascript'>document.getElementById('to').focus();</script>",true);
                addnav("","purgatory.php?op=findname");
                output("`n`n");
                }
      }
    else if ($HTTP_GET_VARS[op]=="findname"){
       $string="%";
        for ($x=0;$x<strlen($_POST['to']);$x++){
                $string .= substr($_POST['to'],$x,1)."%";
        }
            
        $sql = "SELECT name,login,acctid,alive,deathpower FROM accounts WHERE alive=0 AND name LIKE '".addslashes($string)."'";
        $result = db_query($sql);
          if (db_num_rows($result)==1){
                $row = db_fetch_assoc($result);
                output("<form action='purgatory.php?op=pickname' method='POST'>",true);
                output("`6Resurrect `&$row[name]`6 who has $row[deathpower] Favour?");
                output("<input type='hidden' name='to' value='".HTMLEntities($row['login'])."'><input type='submit' class='button' value='Complete Resurrection'></form>",true);
                addnav("","purgatory.php?op=pickname");
        }elseif(db_num_rows($result)>100){
                output("The God looks at you disgustedly and suggests you try narrowing down the field of who you want to Revive just a little bit!`n`n");
                output("T<u>o</u>: <input name='to' accesskey='o' value='". $_POST['to'] . "'> (partial names are ok, you will be asked to confirm the resurrection before it occurs).`n",true);
                output("<input type='submit' class='button' value='Preview Subject'></form>",true);
              //  output("<script language='javascript'>document.getElementById('amount').focus();</script>",true);
                addnav("","purgatory.php?op=findname");
        }elseif(db_num_rows($result)>1){
                output("<form action='purgatory.php?op=pickname' method='POST'>",true);
                output("`6Ressurect<select name='to' class='input'>",true);
                for ($i=0;$i<db_num_rows($result);$i++){
                        $row = db_fetch_assoc($result);
                        //output($row[name]." ".$row[login]."`n");
                        output("<option value=\"".HTMLEntities($row['login'])."\">".preg_replace("'[`].'","",$row['name'])."</option>",true);
                }
                output("</select><input type='hidden' name='acctid' value='$row[acctid]'><input type='submit' class='button' value='Complete Resurrection'></form>",true);
                addnav("","purgatory.php?op=pickname");
        }else{
                output("`6No one matching that name could be found!  Please try again.");
        }
        }
        else if($_GET['op']=="pickname") {
        $result = db_query($sql = "SELECT name,acctid,deathpower,alive,lasthit FROM accounts WHERE login='{$_POST['to']}'");

                if (db_num_rows($result)==1){
                        $row = db_fetch_assoc($result);
                        if ($row[alive] == 0) {
                        $row[deathpower] = $row[deathpower] - 300;
                        if ($row[deathpower] < 0) {
                             $session['user']['deathpower']+= ($row[deathpower]);
                           $row[deathpower] = 0;
                           }

                 }
                 if ($row[alive] == 0){
                     $sql = "UPDATE accounts SET alive=1,deathpower=".$row['deathpower'].",location='666' WHERE acctid='{$row['acctid']}'";
                                db_query($sql);
                                output("`nResurrection Completed!`n`n");
                                systemmail($row['acctid'],"`^You have been Resurrected!`0","`&{$session['user']['name']}`6 has Ressurrected you!  You should go thank them");
                            addnews("`&".$session[user][name]."`& has generously resurrected ".$row[name]."`&");

                }
            }
        }
page_footer();
?>
