<?
/********************
The Goat - ver1.0
10MAR2004
Special Forest Event
Written by Robert for Maddnet LoGD

Fun and Humorous Special Event that gives a Goat to player with no mount,
the Goat does NOTHING, he wonders off to eat while you fight.

Create mount in your Mount Editor:
   Mount Name: Goat
   Mount Cost (Gold): 100
   New Day Message: You strap your {weapon} to your back and find your Goat is waitng to travel with you.
   Buff name: Goat
   Message each round: `6The Goat wonders off to eat some nearby shrubbery while you fight.
   Wear off message: `^The Goat is bored with you - and wonders off
   Rounds to last (from new day): 75
   Activate:
    X   On Attack
    X   On Defen
    
Save - open Mount Editor and *deactivate* Goat (so it does not appear in the Stables)
Now mouse over the *edit* and look in your browser to get the id=(?)
find below: $session[user][hashorse] = 44; and replace 44 with YOUR Goat ID number (?)
save and drop into your special folder
Players having a mount will be redirected to another special event   
*********************/
if ($session[user][hashorse]> 0){
    redirect("forest.php?op=search");
}else{

     output("`n`n`2You stumble upon a small house in the Forest.`n");
     output("Searching through the abondoned house you find nothing of value.`n");
     output("You decide to take a nap on the bed that looks comfortable.`n");
     output("Upon awakening you find a Goat nibbling on your shoes.`n");
     output("You arise and leave the annoying Goat behind,`n");
     output("the Goat follows you into the Forest");
     debuglog("found a Goat at a small house");
     $session[user][hashorse] = 44;
}
?>