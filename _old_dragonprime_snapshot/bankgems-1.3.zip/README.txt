Legend of the Green Dragon
by  Eric "MightyE" Stevens (http://www.mightye.org)
and JT "Kendaer" Traub (http://www.dragoncat.net)

Software Project Page:
http://sourceforge.net/projects/lotgd

Modification Community Page:
http://dragonprime.net

Gem Vault Module
Aes (aes@ioerror.org)
http://logd.ioerror.org

Download the latest Gem Vault module from:
http://dragonprime.net/users/aes

----------------------------------------------
-- What is this module? ----------------------
----------------------------------------------

This module allows users to store gems in the
bank by opening up an account.

----------------------------------------------
-- UPGRADING: --------------------------------
----------------------------------------------
Copy this file into your modules directory overwriting the 
any previous Gem Vault.

Login to the Superuser Grotto and Reinstall it.

----------------------------------------------
-- INSTALLATION: -----------------------------
----------------------------------------------
Copy this file into your modules directory.

Login to the Superuser Grotto and Install / Activate it.

----------------------------------------------
-- CHANGELOG: --------------------------------
----------------------------------------------
CHANGES in version 1.3 (05/09/2004)
- Added ability to edit amount of gems in users
  Gem Vault in the Grotto.  - Thanks for the suggestion Spider
- Removed old code that wasn't going to be used.

CHANGES in version 1.1 - 1.2
- Minor bugs fixed

CHANGES in version 1.0
- Released into the wild!  :)


----------------------------------------------
-- TO DO: --------------------------------
----------------------------------------------
Nothing.
Anyone have any features they want to request?  Post your
request on dragonprime under Gem Vault.

Enjoy!