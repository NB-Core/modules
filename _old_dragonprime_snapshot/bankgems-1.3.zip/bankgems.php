<?php
// -----------------------------------------------------------------------
// Gem Vault
// Aes (aes@ioerror.org)
// http://logd.ioerror.org
// 
// Please read the Readme
// -----------------------------------------------------------------------

function bankgems_getmoduleinfo(){
	$info = array(
		"name"=>"Gem Vault",
		"version"=>"1.3",
		"author"=>"Aes",
		"category"=>"Bank",
		"download"=>"http://dragonprime.net/users/aes",
		"settings"=>array(
			"Gem Vault Settings,title",
			"gemaccountcost"=>"How much gold does it cost to open a gem account?,int|1000",
		),
		"prefs"=>array(
			"Gem Vault User Preferences,title",
			"gemsinbank"=>"Gems in their Gem Vault,int|0",
			"gemsaccount"=>"Has an account?,bool|0",
		)
	);
	return $info;
}

function bankgems_install(){
	module_addhook("footer-bank");
	return true;
}

function bankgems_uninstall(){
	return true;
}

function bankgems_dohook($hookname,$args){
global $session;

switch($hookname){
	case "footer-bank":
	addnav("Gems");
	addnav("Gem Vault","runmodule.php?module=bankgems&op=gemvault");
	break;
	}
	return $args;
}

function bankgems_run(){
	global $session;
	$op = httpget("op");
	page_header("Gem Vault");
	$gemaccountcost = get_module_setting("gemaccountcost");
	$gemtransfercost = get_module_setting("gemtransfercost");
	$msg="";

	if ($op == "gemvault"){ 
		
		// BEGIN - Update accounts with new gemsaccount setting.  This is a new
		//         settig that determines if a player has an account.  When upgrading from
		//         Gem Vault 1.2 to 1.3 this will set players up an account if they have
		//         gems in the bank.
		if (get_module_pref("gemsinbank")>0){
			set_module_pref("gemsaccount",1);	
		}
		// END - Update accounts with new gemsaccount setting.
		
		output("`6Elessa leads you to the back of the bank and down into a dark tunnel lit only by the slivers of light from the bank floor above.`n");
		output("`6As she leads you through the dark damp infested labryinth with the light fading away, you think to yourself what an awful place this would be to get lost.`n");
		output("`6You finally reach your destination, a rather large chamber flickering with tourch flames.  As you scan the room you notice a very large ogre garuding what appears to be an entry way.`n`n");
		output("`6Elessa silently nods to the huge beast who then procedes to push a bolder twice your size out of the way.`n");
		output("\"Please step inside.\" Elesaa says smiling.`n`n");
		output("`^`c`bWelcome to the Gem Vault.`b`c`n");
			if ($session['user']['goldinbank']>=0){
				output("`6Elessa pulls some books down from a shelf and begins to flip through them.  `3Aah, yes, here we are.  You have `^%s gems`3 in our precious gem vault.  Is there anything else I can do for you?`6\"",get_module_pref("gemsinbank"));
			}
			else{
				output("I'm afraid you do not have any gems in our vault.");
			}
		
		if (get_module_pref("gemsaccount") == 0){
			addnav(array("Open new account`0 (`^%s gold`0)",$gemaccountcost),"runmodule.php?module=bankgems&op=newaccount");
		}else{
			addnav("Withdraw Gems","runmodule.php?module=bankgems&op=withdrawgems");
			addnav("Deposit Gems","runmodule.php?module=bankgems&op=depositgems");
		}
	
		} 
	
	if ($op == "newaccount"){
				
		if ($session['user']['gold']<$gemaccountcost){
			output("I'm sorry sir but you do not appear to have enough money on you to open a new account.");
		}else{
			set_module_pref("gemsaccount",1);
			$session['user']['gold']-=$gemaccountcost;
			output("You have successfully opened a new account at our prestigious bank vault.");	
			
			addnav("Withdraw Gems","runmodule.php?module=bankgems&op=withdrawgems");
			addnav("Deposit Gems","runmodule.php?module=bankgems&op=depositgems");
			}
		}

if($op=="depositgems"){
	
	output("<form action='runmodule.php?module=bankgems&op=depositgemsfinish' method='POST'>",true);
	output("`6Elessa says, \"`3You have a balance of `^%s`3 gems in the bank.`6\"`n",get_module_pref("gemsinbank"));
	output("`6Carefully reaching for your gem pouch you notice you have `^%s`6 gems on hand.`n`n", $session['user']['gems']);
	output("`^Deposit how much?");
	output("<input id='input' name='amount' width=5> <input type='submit' class='button' value='Deposit'>",true);
	output("`n`iEnter 0 or nothing to deposit it all`i");
	output("</form>",true);
	
	addnav("","runmodule.php?module=bankgems&op=depositgemsfinish");
	addnav("Return to Gem Vault","runmodule.php?module=bankgems&op=gemvault");
}

if($op=="depositgemsfinish"){
	$amount = abs((int)httppost('amount'));
	if ($amount==0){
		$amount=$session['user']['gems'];
	}

	if ($amount>$session['user']['gems']){
		output("Not enough gems in hand to deposit.");
	}else{
		debuglog("deposited " . $amount . " gems in the bank");
		$totalamount = get_module_pref("gemsinbank") + $amount;
		set_module_pref("gemsinbank",$totalamount);
		$session['user']['gems']-=$amount;
	}
	output("`6Elessa records your deposit of gems in her ledger. \"`3You now have a balance of `^%s`3 gems in the bank.`6\"`n",get_module_pref("gemsinbank"));

}

if($op=="withdrawgems"){
	
	output("<form action='runmodule.php?module=bankgems&op=withdrawgemsfinish' method='POST'>",true);
	output("`6Elessa says, \"`3You have a balance of `^%s`3 gems in the bank.`6\"`n",get_module_pref("gemsinbank"));
	output("`^How many would you like to withdraw?");
	output("<input id='input' name='amount' width=5> <input type='submit' class='button' value='Withdraw'>",true);
	output("`n`iEnter 0 or nothing to withdraw it all`i");
	output("</form>",true);
	
	addnav("","runmodule.php?module=bankgems&op=withdrawgemsfinish");
	addnav("Return to Gem Vault","runmodule.php?module=bankgems&op=gemvault");
}

if($op=="withdrawgemsfinish"){
	$amount = abs((int)httppost('amount'));
	if ($amount==0){
		$amount=get_module_pref("gemsinbank");
	}

	if ($amount>get_module_pref("gemsinbank")){
		output("You don't have that many gems in the bank.");
	}else{
		debuglog("withdrawn " . $amount . " gems from the bank");
		$totalamount = get_module_pref("gemsinbank") - $amount;
		set_module_pref("gemsinbank",$totalamount);
		$session['user']['gems']+=$amount;
	}
	output("`6Elessa records your deposit of gems in her ledger. \"`3You now have a balance of `^%s`3 gems in the bank.`6\"`n",get_module_pref("gemsinbank"));

}

require_once("lib/villagenav.php");
villagenav();
addnav("Return to Bank","bank.php");
page_footer(); 
}
?>
