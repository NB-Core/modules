****************************************************************
Name: Equipment Shop Buffs
Author: Eth - ethstavern(at)gmail(dot)com 
Version: 1.3
Release Date: 01-25-2006
About: Readme file for mysticalshop.zip
Files: mysticalshop.php
***************************************************************

To install, drop into your modules directory and activate 
via the Modules Manager. Instructions for use are included
within the Equipment Shop Buff Manager itself. 