<?

// Casino - by thegleek

require_once "common.php";
checkday();

// again this is option, if u dont use casinoturns, COMMENT out this line below!
if ($session[user][casinoturns]>=1) {

        if ($HTTP_GET_VARS[op]==""){
                $gamecnt=0;
                page_header("Wumpscut Casino");
                addnav("Main Lobby");
                if (@file_exists("blackjack.php"))      { addnav("Blackjack","blackjack.php"); $gamecnt++; }
                if (@file_exists("roulette.php"))       { addnav("Roulette","roulette.php"); $gamecnt++; }
                addnav("Back to Village","village.php");
                output("Welcome to the Casino.`n`n");

                // comment out below line if u dont use casinoturns
                output("You only have ". $session[user][casinoturns] . " turn(s) left for today.`n`n");

                if ($gamecnt) { output("Only ". $gamecnt . " game(s) are available. More coming soon!`n`n"); }
                else { output("Sorry, no games are available at this time... Check back later!`n`n"); }
        }

// comment out all this below (from START to FINISH) if u dont use casinoturns...
// START
} else {
        page_header("Wumpscut Casino");
        addnav("Main Lobby");
        addnav("Back to Village","village.php");
        output("Welcome to the Casino.`n`n");
        output("You have exhausted all your casino turns for today.`n`n");
        output("Please visit us tomorrow!`n`n");
        $HTTP_GET_VARS[op]="";
}
// FINISH

page_footer();

?>
