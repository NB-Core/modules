-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
Speciality - Seductive Skills - A module for Legend of the Green Dragon 1.0.3

Legend of the Green Dragon
by  Eric "MightyE" Stevens (http://www.mightye.org)
and JT "Kendaer" Traub (http://www.dragoncat.net)

Software Project Page:
http://sourceforge.net/projects/lotgd

Modification Community Page:
http://dragonprime.net

Author of this Module:
Original - Lonny Luberts
Rewritten by - Enderandrew (enderandrew@gmail.com)

Enderandrew's LoGD game:
http://enderandrew.com/lotgd/

Download the latest version of this module from:
http://dragonprime.net/index.php?action=viewfiles&user=enderwiggin

----------------------------------------------
-- STATUS: -----------------------------------
----------------------------------------------
This module is STABLE.

----------------------------------------------
-- INFORMATION: ------------------------------
----------------------------------------------
I started with one small tweak to this module, and before you know it, I basically
completely rewrote it.  The idea for the module originated from Lonny and Sixf00t4,
but most everything has been replaced.

All the buffs/effects are new.  Both the number of uses you get per day, as well as
the power of the buffs are affected by how much charm the character has.  It only
makes sense.  I felt many of the specialties were fairly static.  This rewards some
of the players who go out of the way to roleplay their character according to what
their race and specialty are.  However, I must warn you, that as I am developing new
races and specialties with dynamic effects based off charm, alignment, etc. that a
player could twink out their character.  Effectively, this is designed for that, in
so much as that it rewards players for certain actions.  To balance this, you have
to consider two things.

One, it takes effort and time to raise charm, alignment, etc. so the bonus power is
not granted for nothing.  Secondly, these specialties and races with dynamic effects
are usually a little less powerful to start off with.  Or atleast, the ones I am 
designing are that way.

For instance, until you hit around 20 charm, you get no bonus to the duration of the
buffs.  And the base is 4 rounds instead of 4.  You also won't really get any bonus
use parts early on either. So, I don't think this is unbalancing.  To start it's weaker,
and has the potential of becoming more powerful if the player plays their cards right.

This module requires version 1.0.3 or later of LotGD.

----------------------------------------------
-- INSTALLATION: -----------------------------
----------------------------------------------
Copy specialtyseductiveskills.php within this zip into your modules directory.

Login to the Superuser Grotto and Install / Activate it.

-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-