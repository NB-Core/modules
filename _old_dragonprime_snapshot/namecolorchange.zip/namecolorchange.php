<?php

//addnews ready
/***************************************************************************/
/* Name: Name Color Change for the Lodge                                   */
/* ver 1.2                                                                 */
/* Billie Kennedy => dannic06@gmail.com                                    */
/*                                                                         */
/*  Fixes                                                                  */
/* fixed the download attribute to reflect that it is actually a download. */
/*2-19-05                                                                  */
/*  - Added support for Check Module Verison                               */
/***************************************************************************/

function namecolorchange_getmoduleinfo(){
	$info = array(
		"name"=>"Name Color Change",
		"author"=>"Billie Kennedy",
		"version"=>"1.2",
		"download"=>"http://www.orpgs.com/modules.php?name=Downloads&d_op=viewdownload&cid=7",
		"vertxtloc"=>"http://www.orpgs.com/downloads/",
		"category"=>"Lodge",
		"settings"=>array(
			"Name Color Change Module Settings,title",
			"ninitialpoints"=>"How many donator points needed to get first title change?,int|5000",
			"nextrapoints"=>"How many additional donator points needed for subsequent title changes?,int|1000",
		),
		"prefs"=>array(
			"Name Color Change User Preferences,title",
			"ntimespurchased"=>"How many Name Color changes have been bought?,int|0",
		),
	);
	return $info;
}

function namecolorchange_install(){
	module_addhook("lodge");
	module_addhook("pointsdesc");
	return true;
}
function namecolorchange_uninstall(){
	return true;
}

function namecolorchange_dohook($hookname,$args){
	global $session;
	switch($hookname){
	case "pointsdesc":
		$args['count']++;
		$format = $args['format'];
		$str = translate("The ability to change the colors of your name upon reaching %s and every %s points thereafter. (this doesn't use up those points)");
		$str = sprintf($str, get_module_setting("ninitialpoints"),
				get_module_setting("nextrapoints"));
		output($format, $str, true);
		break;
	case "lodge":
		// If they have less than what they need just ignore them
		$times = get_module_pref("ntimespurchased");
		if (get_module_setting("ninitialpoints") +
				($times * get_module_setting("nextrapoints")) >
				$session['user']['donation'])
			break;
		addnav("Custom Name Colors","runmodule.php?module=namecolorchange&op=namechange");
		break;
	}
	return $args;
}

function namecolorchange_run(){
	require_once("lib/sanitize.php");
	require_once("lib/names.php");
	global $session;
	$op = httpget("op");

	page_header("Hunter's Lodge");
	if ($op=="namechange"){
		output("`3`bCustomize Name Colors`b`0`n`n");
		output("`7Because you have earned sufficient points, you have been granted the ability to set your name to the colors of your choosing.`n`n");
		$oname = get_player_basename();
		output("`7Your name is currently`0 ");
		output($oname);
		output_notl("`0`n");
		output("`7How would you like your name to look?`n");
		rawoutput("<form action='runmodule.php?module=namecolorchange&op=namepreview' method='POST'>");
		rawoutput("<input id='input' name='newname' width='25' maxlength='25' value='".htmlentities($oname)."'>");
		rawoutput("<input type='submit' class='button' value='Preview'>");
		rawoutput("</form>",true);
		output("`n`nTo do colors, use a ` mark (found right above the tab key) followed by 1, 2, 3, 4, 5, 6, 7, q, !, @, #, $, %, ^, &, Q.  Each of these corresponde with a color to look like this: `n`11 `22  `33  `44  `55  `66  `77  `qq `n`!! `@@ `## `\$\$ `%% `^^ `&& `QQ `))`n ");
		
		addnav("", "runmodule.php?module=namecolorchange&op=namepreview");
	}elseif ($op=="namepreview"){
		$nname = rawurldecode(httppost('newname'));
		$nname = newline_sanitize($nname);
		$oname = get_player_basename();
		$cname = color_sanitize($nname);
		$oname = color_sanitize($oname);
		if ($cname != $oname)
		{
			output("`7Your new name does not match your old name.");
			addnav("Back", "runmodule.php?module=namecolorchange&op=namechange");
		}else{

			output("`7Your new name will look like: %s`0`n`n",
			 $nname);
			output("`7Is this how you wish it to look?");
			addnav("`bConfirm Custom Name`b");
			addnav("Yes", "runmodule.php?module=namecolorchange&op=changename&newname=".rawurlencode($nname));
			addnav("No", "runmodule.php?module=namecolorchange&op=namechange");
		}
	}elseif ($op=="changename"){
		$nname=rawurldecode(httpget('newname'));
		$newname = change_player_name($nname);
		$session['user']['name'] = $newname;
		set_module_pref("ntimespurchased", get_module_pref("ntimespurchased")+1);
		output("Your custom name has been set.");
		modulehook("namechange", array());
	}
	addnav("L?Return to the Lodge","lodge.php");
	page_footer();
}
?>
