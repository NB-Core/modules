<?
// Generic Village
// by Robert of Maddnet
// Download a Generic Village and edit to make you own to suit your realm
// File available at Dragon Prime
// http://dragonprime.cawsquad.net
//
// For use with LoGD - .097
// Edit to make your own village
// Add  link to wherever to get here
// Rename this file after editing to whatever you choose
// Save and  upload
// 
require_once "common.php"; 
addcommentary(); 
checkday(); 
if ($session['user']['alive']){ }else{
	redirect("shades.php");
}

addnav("Generic Village"); 
addnav("`bMain Street`b");  
// add your links
addnav("");
addnav("path leading");
addnav("(F) to Forest","forest.php"); 
  

// Edit to name your Village
page_header("Generic Village"); 
// Edit to name your Village
output("`c<font size='+1'>`^Generic Village</font>`c`n`n",true);
// Edit to add description for your village
output("`2The village hustles and bustles. `n");
output(" edit this `n"); 
output(" edit this `n");
output(" edit this `n"); 
output("`edit this `n`n"); 
output("`@The clock reads `^".getgametime()."`@."); 


// Edit these for your commentary
output("`n`n`6People talk:`n"); 
viewcommentary("gvillage","talk with others",15); 

page_footer(); 
?> 