<?
/********************
Imps
Written by Robert for Maddnet LoGD
Imps attack causing much damage.
Use this only if you also use castle.php
*********************/
if ($session['user']['dragonkills']>6){
output(" `n`n`2It is dark and you hear a noise, curious, you take your {$session['user']['weapon']}.`n");
output(" and walk toward where the noise came from. In the darkness you trip over a rock and fall to the ground.`n");
output(" On the ground defenseless, you are attacked by a horde of Imps! `n");
output(" `&You survive the ordeal but find you are badly beaten and `&`iweaker`i than you were.`n ");
output(" You stand up to find your weapon and armor is also damaged.`n ");
addnews($session[user][name]." `2was attacked in the Forest by a Horde of Imps.");
debuglog(" weapon and armor damaged by Horde of Imps");
                    $newarmor = "Damaged".$session[user][armor]; 
                    $session[user][armor]= $newarmor; 
                    $session[user][armordef]-=3; 
                    $cost = $session[user][armordef] * 49; 
                    $session[user][armorvalue]-=$cost; 
                    $session[user][defence]-=3; 
                    $newweapon = "Damaged".$session[user][weapon]; 
                    $session[user][weapon]= $newweapon; 
                    $session[user][weapondmg]-=3; 
                    $cost = $session[user][weapondmg] * 49; 
                    $session[user][weaponvalue]-=$cost; 
                    $session[user][attack]-=3; 
                    $session[user][maxhitpoints]-=2; 
    }else{
	output("`n`n`2You wander through the Forest, hearing strange noises. Looking around, you see nothing.`n");
    output("You continue your journey but can't shake the feeling that you're being watched.`n");
    addnews($session[user][name]." `2hears strange noises in the Forest.");
}
?>