<?
/*
Myrrdin the teacher, by Spider

you need to make a small change to common.php for this addition to work properly:

find:
function increment_specialty(){
	
and replace the entire function with this:

function increment_specialty($force=false){
  global $session;
  if ($force==false){
		if ($session[user][specialty]>0){
			$skillnames = array(1=>"Dark Arts","Mystical Powers","Thievery");
			$skills = array(1=>"darkarts","magic","thievery");
			$skillpoints = array(1=>"darkartuses","magicuses","thieveryuses");
			$session[user][$skills[$session[user][specialty]]]++;
			output("`nYou gain a level in `&".$skillnames[$session[user][specialty]]."`# to ".$session[user][$skills[$session[user][specialty]]].", ");
			$x = ($session[user][$skills[$session[user][specialty]]]) % 3;
			if ($x == 0){
				output("you gain an extra use point!`n");
				$session[user][$skillpoints[$session[user][specialty]]]++;
			}else{
				output("only ".(3-$x)." more skill levels until you gain an extra use point!`n");
			}
		}else{
			output("`7You have no direction in the world, you should rest and make some important decisions about your life.`n");
		}
	}
	else{
		$skillnames = array(1=>"Dark Arts","Mystical Powers","Thievery");
		$skills = array(1=>"darkarts","magic","thievery");
		$skillpoints = array(1=>"darkartuses","magicuses","thieveryuses");
		$session[user][$skills[$force]]++;
		output("`nYou gain a level in `&".$skillnames[$force]."`# to ".$session[user][$skills[$force]].", ");
		$x = ($session[user][$skills[$force]]) % 3;
		if ($x == 0){
			output("you gain an extra use point!`n");
			$session[user][$skillpoints[$force]]++;
		}else{
			output("only ".(3-$x)." more skill levels until you gain an extra use point!`n");
		}
	}
}

*/

require_once "common.php";
page_header("Myrrdin's House");

output("`7`c`bMyrrdin's House`b`c`n");
$skills = array(1=>"Dark Arts","Mystical Powers","Thievery");
switch((int)$session[user][specialty]){
case 1:
	$c="`$";
	break;
case 2:
	$c="`%";
	break;
case 3:
	$c="`^";
	break;
default:
	$c="`0";
	break;
}

if ($HTTP_GET_VARS[op]==""){
	output("Myrrdin's house is large and spacious, the main room is filled with shelves and shelves of books and strange looking instruments.  Myrrdin himself is sitting behind a large oak desk closely examining some metal contraption.  Unsure of what exactly it is, you don't get too close.`n");
	output("You discreetly clear your throat, trying to get Myrrdin's attention, it works.`n`n");
	if ($session['user']['specialty']>0 && $session['user']['specialty']<4){
		output("`3\"Oh, hello there, I'm sorry, I was rather engrossed.  Let me look at you.  Ah yes, I see that you are interested in ".$skills[$session[user][specialty]].", well I can certainly teach you a little about that, or something else if you desire.  Of course learning something you are unfamiliar with won't be so easy, and will cost you a little more.\"`n`n");
	}
	else{
		output("`3\"Oh, hello there, I'm sorry, I was rather engrossed.  Let me look at you.  Well now theres a thing, you aren't interested in anythings.  I suppose I can still teach you, but it will cost you considerably more as you have little experience of these things.\"`n`n");
	}
	switch($session['user']['specialty']){
		case 1:
			output("`3\"I can teach you about `\$Dark Arts`3 for `^5000 gold`3 and `%2 gems`3\"`n");
			output("`3\"I can teach you about `%Mystical Powers`3 for `^10000 gold`3 and `%4 gems`3\"`n");
			output("`3\"I can teach you about `^Thievery`3 for `^10000 gold`3 and `%4 gems`3\"`n");
			break;
		case 2:
			output("`3\"I can teach you about `\$Dark Arts`3 for `^10000 gold`3 and `%4 gems`3\"`n");
			output("`3\"I can teach you about `%Mystical Powers`3 for `^5000 gold`3 and `%2 gems`3\"`n");
			output("`3\"I can teach you about `^Thievery`3 for `^10000 gold`3 and `%4 gems`3\"`n");
			break;
		case 3:
			output("`3\"I can teach you about `\$Dark Arts`3 for `^10000 gold`3 and `%4 gems`3\"`n");
			output("`3\"I can teach you about `%Mystical Powers`3 for `^10000 gold`3 and `%4 gems`3\"`n");
			output("`3\"I can teach you about `^Thievery`3 for `^5000 gold`3 and `%2 gems`3\"`n");
			break;
		default:
			output("`3\"I can teach you about `\$Dark Arts`3 for `^10000 gold`3 and `%4 gems`3\"`n");
			output("`3\"I can teach you about `%Mystical Powers`3 for `^10000 gold`3 and `%4 gems`3\"`n");
			output("`3\"I can teach you about `^Thievery`3 for `^10000 gold`3 and `%4 gems`3\"`n");
			break;
	}
	addnav("Learn about Dark Arts","myrrdin.php?op=learn&type=1");
	addnav("Learn about Mystical Powers","myrrdin.php?op=learn&type=2");
	addnav("Learn about Thievery","myrrdin.php?op=learn&type=3");
}

else if ($HTTP_GET_VARS[op]=="learn"){
	if ($HTTP_GET_VARS[type]=="1" && $session['user']['specialty']==1){
		$cheap=true;
	}
	if ($HTTP_GET_VARS[type]=="2" && $session['user']['specialty']==2){
		$cheap=true;
	}
	if ($HTTP_GET_VARS[type]=="3" && $session['user']['specialty']==3){
		$cheap=true;
	}
	if ($cheap==true){
		if ($session[user][gold]>4999 && $session[user][gems]>1){
			output("`3\"I see you you want to learn more about your interests.  Good, I like a person who persues what they enjoy.  Sit down for a while and I will teach you all about ".$skills[$HTTP_GET_VARS[type]].".\"`0`n`n");
			output("You sit and listen to Myrrdin's wise words for a time.");
			increment_specialty();
			$session[user][gold]-=5000;
			$session[user][gems]-=2;
		}
		else{
			output("`3\"You don't appear to have enough to cover my costs, I'm afraid I can't teach you unless I receive the full payment up front.  Remember that the benefit of education far outweighs the costs.\"");
		}
	}
	else{
		if ($session[user][gold]>9999 && $session[user][gems]>3){
			output("`3\"Wonderful, you're seeking to expand your interests.  You know, I highly recommend learning about all of the things I can teach you, they are all quite rewarding.\"`n");
			output("`3\"If you would like to take a seat, I shall teach you a little about ".$skills[$HTTP_GET_VARS[type]]."\"`0`n`n");
			output("You sit and listen to Myrrdin's wise words for a time.");
			increment_specialty($force=$HTTP_GET_VARS[type]);
			$session[user][gold]-=10000;
			$session[user][gems]-=4;
		}
		else{
			output("`3\"You don't appear to have enough to cover my costs, I'm afraid I can't teach you unless I receive the full payment up front.  Remember that the benefit of education far outweighs the costs.\"");
		}
	}
}

addnav("Return to Village","village.php");

page_footer();
?>