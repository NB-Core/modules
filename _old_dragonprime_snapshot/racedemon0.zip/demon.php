<?php

function racedemon_getmoduleinfo(){
    $info = array(
        "name"=>"Race - Demon",
        "version"=>"1.0",
        "author"=>"Jim Lunsford based off of Ghoul by Chris Vorndran",
        "category"=>"Races",
        "download"=>"http://dragonprime.net/users/Sichae/raceghoul.zip",
        "settings"=>array(
            "Demon Race Settings,title",
            "minedeathchance"=>"Chance for Demon to die in the mine,range,0,100,1|25",
			"divide"=>"Favor is divided by this value to provide extra hp perday,int|3",
			"mindk"=>"How many DKs do you need before the race is available?,int|5",
        ),
        );
    return $info;
}

function racedemon_install(){
	if (!is_module_installed("racevamp")) {
		output("The Demons only choose to live with vampires.   You must install that race module.");
		return false;
	}
    module_addhook("chooserace");
    module_addhook("setrace");
    module_addhook("creatureencounter");
    module_addhook("charstats");
	module_addhook("newday");
    module_addhook("raceminedeath");
    return true;
}

function racedemon_uninstall(){
	global $session;
	// Force anyone who was a Demon to rechoose race
	$sql = "UPDATE  " . db_prefix("accounts") . " SET race='" . RACE_UNKNOWN . "' WHERE race='Demon'";
	db_query($sql);
	if ($session['user']['race'] == 'Demon')
		$session['user']['race'] = RACE_UNKNOWN;
    return true;
}

function racedemon_dohook($hookname,$args){
    //yeah, the $resline thing is a hack.  Sorry, not sure of a better way
    //to handle this.
    // It could be passed as a hook arg?
    global $session,$resline;
	if (is_module_active("racevamp")) {
		$city = get_module_setting("villagename", "racevamp");
	} else {
		$city = getsetting("villagename", LOCATION_FIELDS);
	}
    $race = "Demon";
	$divide = get_module_setting("divide");
	$demon = $session['user']['deathpower']/$divide; 
    switch($hookname){
    case "raceminedeath":
        if ($session['user']['race'] == $race) {
            $args['chance'] = get_module_setting("minedeathchance");
            $args['racesave'] = "Fortunately your Demon skill let you escape unscathed.`n";
        }
        break;
    case "charstats":
        if ($session['user']['race']==$race){
            addcharstat("Vital Info");
            addcharstat("Race", $race);
        }
        break;
     case "chooserace":
		 if ($session['user']['dragonkills'] < get_module_setting("mindk"))
			break;
        output("<a href='newday.php?setrace=Demon$resline'>Born out of death.</a> Crowmina `)hidden away from the world. `^Demonish`0 `)crystals protecting you, from those that do not realize your kind. You are a creature of the dead, wishing for a purpose...`n`n",true);
        addnav("`7G`)houl`0","newday.php?setrace=Demon$resline");
        addnav("","newday.php?setrace=Demon$resline");
        break;
    case "setrace":
        if ($session['user']['race']==$race){
            output("`^As a Demon, you feel your ancestors building in your bones.`nYou gain extra hitpoints!");
            if (is_module_active("cities")) {
                if ($session['user']['dragonkills']==0 &&
                        $session['user']['age']==0){
                    //new farmthing, set them to wandering around this city.
                    set_module_setting("newest-$city",
                            $session['user']['acctid'],"cities");
                }
                set_module_pref("homecity",$city,"cities");
                $session['user']['location']=$city;
            }
        }
        break;
    case "newday":
        if ($session['user']['race']==$race){
            racedemon_checkcity();
            $session['user']['hitpoints']+=$demon;
        }
        break;
	}
    return $args;
}

function racedemon_checkcity(){
    global $session;
    $race="Demon";
    if (is_module_active("racevamp")) {
		$city = get_module_setting("villagename", "racevamp");
	} else {
		$city = getsetting("villagename", LOCATION_FIELDS);
	}
	
	if ($session['user']['race']==$race && is_module_active("cities")){
		//if they're this race and their home city isn't right, set it up.
		if (get_module_pref("homecity","cities")!=$city){ //home city is wrong
			set_module_pref("homecity",$city,"cities");
		}
	}
    return true;
}

function racedemon_run(){
}
?>