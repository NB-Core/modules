<?php

function kopfgeldliste_getmoduleinfo() {
	$info=array(
	
		"name"=>"Kopfgeldliste",
		"version"=>"1.0",
		"author"=>"<a href='http://www.dailyzone.selfhost.de/lotgd' target=_new>BansheeElhayn</a>",
		"category"=>"Stadttor",
		"download"=>"http://dragonprime.net/users/AgentHerby/stadttor-pack.zip",
		"settings"=>array(
			"Kopfgeldliste - Einstellungen,title",
			"max"=>"Maximale Anzahl der angezeigten Spieler,range,10,100,5|25",
			),
	);
  return $info;
}

function kopfgeldliste_install() {
	if (!is_module_active("kopfgeldliste")) {
		output("`n`3Installiere das Zusatzmodul \"`\$Kopfgeldliste`3\".");
		output("`nViel Spa�!!`n`n");
	}
	module_addhook("charstats");
	return true;
}

function kopfgeldliste_uninstall() {
	output("Die Kopfgeldliste wird deinstalliert.");
	return true;
}

function kopfgeldliste_dohook($hookname, $args) {
	global $session;
	switch($hookname) {
		case("charstats"):
			$kopfgeldliste="<a href='runmodule.php?module=kopfgeldliste' target='blank' style=\"font-size:12px\">Anzeigen</a>";	
			addcharstat("Vital Info");
			addcharstat(translate_inline("Kopfgeldliste"), $kopfgeldliste);
			addnav("","runmodule.php?module=kopfgeldliste");
			break;
		}
	return($args);
}

function kopfgeldliste_run() {
	global $session;
	$max=get_module_setting("max");
	$tspieler=translate_inline("Spielername");
	$tlevel=translate_inline("Level");
	$tdk=translate_inline("Drachenkills");
	$tkopfgeld=translate_inline("Kopfgeld");
	$tgeschlecht=translate_inline("Geschlecht");
	$taufenthalt=translate_inline("Aufenthaltsort");
	$ton=translate_inline("Status");
	$leben=translate_inline("Gesundheit");
	popup_header("Kopfgeldliste");
	$anzahluser="SELECT acctid FROM ". db_prefix("accounts") ." WHERE acctid>0 ORDER BY acctid DESC LIMIT 0,1";
	$maxuserzahl=db_query($anzahluser) or die(sql_error($anzahluser));
	$user=db_fetch_assoc($maxuserzahl);
	$maxuser=$user['acctid'];
	$liste=array();
		for ($i=0;$i<$maxuser+1;$i++) {
			  $kopfgeld="SELECT amount FROM ". db_prefix("bounty") ." WHERE status=0 AND target=$i";
			  $ergebnis1 = db_query($kopfgeld) or die(sql_error($kopfgeld));
				for ($j=0;$j<db_num_rows($ergebnis1)+1;$j++) {
    			$table = db_fetch_assoc($ergebnis1);
    			$bounty+=$table['amount'];
				}
				if ($bounty>0) {
    			$spieler="SELECT name,location,sex,level,dragonkills,loggedin,alive FROM ". db_prefix("accounts") ." WHERE acctid=$i";
				$ergebnis2 = db_query($spieler) or die(sql_error($spieler));
				$table2 = db_fetch_assoc($ergebnis2);
				if ($table2['name']<>"") {
					$z++;
					$liste[$z] = array('name'=>$table2['name'],'kopfgeld'=>$bounty,'level'=>$table2['level'],'dragonkills'=>$table2['dragonkills'],'sex'=>$table2['sex'],'location'=>$table2['location'],'alive'=>$table2['alive'], 'loggedin'=>$table2['loggedin']);
				}
		        $bounty=0;
			  }
		}	
			usort($liste,'sortkopfgeld');
			if ($z<$max) $max=$z;
			output("<big><big><big><big>`c`4- - - K O P F G E L D L I S T E - - -`c</big></big></big></big>`n`n",true);
			output("<big><big>`c`2(Die `^%s `2wertvollsten K�pfe unseres Landes)`c`0</big></big>`n`n",$max,true);
			output("`c");
			rawoutput("<table border=3 cellpadding=2 cellspacing=1 bgcolor='#000000'>");
			rawoutput("<tr class='trhead'><td>$tspieler</td><td>$tkopfgeld</td><td>$tlevel</td><td>$tdk</td><td>$tgeschlecht</td><td>$taufenthalt</td><td>$leben</td><td>$ton</td><tr>");
			for ($t=0;$t<$max;$t++) { 
				rawoutput("</td><td>");
                output_notl("`^{$liste[$t]['name']}`0");
		        rawoutput("</td><td>");
				output_notl("`3{$liste[$t]['kopfgeld']}`0");
		        rawoutput("</td><td>");
		        output_notl("`4{$liste[$t]['level']}`0");
		        rawoutput("</td><td>");
		        output_notl("`6{$liste[$t]['dragonkills']}`0");
		        rawoutput("</td><td>");
		        output($liste[$t]['sex']?"`5weiblich`0":"`!m�nnlich`0");
		        rawoutput("</td><td>");
		        output_notl("`&{$liste[$t]['location']}`0");
		        rawoutput("</td><td>");
		        output($liste[$t]['alive']?"`6Lebt`0":"`4Tot`0");
		        rawoutput("</td><td>");
		        output($liste[$t]['loggedin']?"`5online`0":"`7offline`0");
		        rawoutput("</td></tr>");
			}	
			rawoutput("</table>");
			output("`n`n<a href='runmodule.php?module=kopfgeldliste' class='button' target='blank' style=\"font-size:18px\">Aktualisieren</a>",true);
			output("`c");			
	popup_footer();
}

function sortkopfgeld($argument1, $argument2) {
	if ($argument1['kopfgeld']==$argument2['kopfgeld']) return 0;
	elseif ($argument1['kopfgeld']>$argument2['kopfgeld']) return -1; 
	elseif ($argument1['kopfgeld']<$argument2['kopfgeld']) return 1;
}

?>