<?php

function derhenker_getmoduleinfo(){
	$info = array(
		"name"=>"Der Henker im Wald",
		"version"=>"1.0",
		"author"=>"<a href='http://www.dailyzone.de/lotgd' target=_new>BansheeElhayn</a>",
		"category"=>"Stadttor",
		"download"=>"http://dragonprime.net/users/AgentHerby/stadttor-pack.zip",
		"settings"=>array(
			"Der Henker im Wald - Einstellungen, title",
			"opferzahl"=>"Wieviele zuf�llige Opfer jagt der Henker pro Tag?,int|5",
		),			
	);
	return $info;
}

function derhenker_install(){
	if (!is_module_active("derhenker")) {
		output("`n`3Installiere das Zusatzmodul \"`\$Der Henker im Wald`3\".");
		output("`nViel Spa�!!`n`n");
	}
	module_addeventhook("forest", "return 100;");
	module_addhook("newday-runonce");
	return true;
}

function derhenker_uninstall(){ 
	output("Der Henker im Wald wird deinstalliert.");
	return true; 
}

function derhenker_dohook($hookname,$args){
	switch ($hookname) {
		
		case ("newday-runonce"):
			opferliste();
			set_module_pref("heutetot",0);
		break;
	}
   return $args;
}
function opferliste() {
	global $session;
	$opferzahl=get_module_setting("opferzahl");
	$list=array();
	$opferliste=array();
	$merken="";
	$anzahluser="SELECT acctid FROM ". db_prefix("accounts") ." WHERE acctid>0 ORDER BY acctid DESC LIMIT 0,1";
	$maxuserzahl=db_query($anzahluser) or die(sql_error($anzahluser));
	$user=db_fetch_assoc($maxuserzahl);
	$maxuser=$user['acctid'];
	if ($opferzahl>$maxuser) $opferzahl=$maxuser;
	for ($i=0;$i<$maxuser;$i++) {
		$liste="SELECT name FROM ". db_prefix("accounts") ." WHERE acctid=$i";
		$ergebnis=db_query($liste) or die(sql_error($liste));
		$feld=db_fetch_assoc($ergebnis);
		$sname=$feld['name'];
		if ($sname<>"") {
			$z++;
			$list[$z]=array('name'=>$sname);
		}
	}
	for ($i=0;$i<$opferzahl;$i++) {
			$zuffi=e_rand(1,$z);
			$opferliste[$i]=array('name'=>$list[$zuffi]['name']);
			$var=substr_count($merken,$opferliste[$i]['name']);
			if ($var==0) { $merken.=$opferliste[$i]['name']." "; }
			else $i--;
	}
	set_module_setting("opferliste",$merken);
}

function derhenker_runevent($type){
	global $session;
	$opfer=get_module_setting("opferliste");
	$lehnsherr="`1Banshee`!Elhayn";
	$heutetot=get_module_pref("heutetot");
	$sql="SELECT amount FROM ". db_prefix("bounty") ." WHERE status=0 and target=".$session['user']['acctid'];
	$ergebnis = db_query($sql) or die(sql_error($sql));
	for ($i=0;$i<db_num_rows($ergebnis);$i++){
   		$row = db_fetch_assoc($ergebnis);
   		$bounty+=$row[amount];
	}
	if ($bounty=="") $bounty=0;
	$var=substr_count($opfer,$session['user']['name']);
		output("`2Aus der Ferne siehst Du eine Gestalt auf Dich zu kommen. Als sie n�her kommt, erkennst Du in ihr den Henker aus der Burg wieder.`n`n");
		output("`6\"Seid mir gegr��t `3%s. `6Euch habe ich schon lange nicht mehr gesehen. Ich bin auf der Suche nach B�sewichten, die mir mein Lehnsherr %s",$session['user']['name'],$lehnsherr);
		output("`6auf einer Liste zusammengestellt hat. Ihr armseliger K�rper soll am Galgen baumeln.\"`n`n\"La� mich einen Blick auf meine Liste werfen, ob");
		output("Du nicht etwa auch darauf stehst.\"`n`n");
		if ($var==1 && $heutetot==0) {
			output("`2Nach einem kurzen Blick auf seine Opferliste schaut Dich der Henker mitleidig an und sch�ttelt den Kopf. Dann ergreift er Dich,");
			output("`2noch bevor Du Dich wehren kannst, und schleppt Dich �ber den Waldboden bis auf den Richtplatz. Dort wirst Du, unter dem Johlen des Volkes,");
			output("`2am `4Galgen `2aufgekn�pft.`n`n");
			output("`4Du stirbst einen grausamen Tod durch die Strangulation des handgekn�pften Strickes.`n");
			output("`4Deine Seele wandert in die Unterwelt ab.`nDein Gold erh�lt die Staatskasse, ebenso 10 Prozent Deiner Erfahrung.`n");
			if ($bounty>0) {
				output("`4Gleiches gilt f�r das Kopfgeld, das auf Dich ausgesetzt war.`n");
				addnews("`2%s `4wurde im Wald vom `3Henker `4geschnappt und auf dem Burghof am Galgen aufgekn�pft.`n`3Die `^%s Goldst�cke `4Kopfgeld `3erhielt die Staatskasse",$session['user']['name'],$bounty);
				$sql = "UPDATE ". db_prefix("bounty") ." SET status=1 WHERE target=".$session['user']['acctid'];
				db_query($sql);
			} else addnews("`2%s `4wurde im Wald vom `3Henker `4geschnappt und auf dem Burghof am Galgen aufgekn�pft.",$session['user']['name']);
			set_module_setting("gspieler",$session['user']['name'],"henkerstube");
			set_module_pref("heutetot",1);
			$session['user']['alive']=false;
			$session['user']['hitpoints']=0;
			$session['user']['gold']=0;
			$session['user']['experience']*=0.9;
			addnav("Neuigkeiten");
			addnav("T�gliche News","news.php");
			}
		else {
			output("`2Nach einem kurzen Blick auf seine Opferliste rollt der Henker diese wieder zusammen und w�nscht Dir noch einen sch�nen Tag.");
			output("`2Offenbar hattest Du Gl�ck und warst heute brav genug, um nicht aufgelistet zu werden.`n`n");
		}
}

function derhenker_run() {}

?> 