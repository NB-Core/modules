<?php
// Idee und Umsetzung
// Apollon, 2005
// gewidmet meiner geliebten Blume.
// ab Version 1.1 mit freundlicher Unterst�tzung, Mithilfe und Erg�nzung von BansheeElhayn
function stadttor_getmoduleinfo(){
    $info = array(
        "name"=>"Das Stadttor",
        "version"=>"1.7",
        "author"=>"Apollon und <a href='http://www.dailyzone.selfhost.de/lotgd' target=_new>BansheeElhayn</a>",
        "category"=>"Stadttor",
        "download"=>"http://dragonprime.net/users/Apollon/stadttor-pack.zip",
        "settings"=>array(
			"Stadttor Einstellungen,title",
			"ort"=>"Wo soll das Stadttor erscheinen?,location|".getsetting("villagename", LOCATION_FIELDS),
			"alle"=>"Stadttor f�r ALLE St�dte verf�gbar machen?,bool|1",
			"Anmerkung: Verf�gbarkeit f�r ALLE St�dte setzt die Einstellung des Stadtnames au�er Kraft,note",
			"navmauer"=>"Navigationen in der Stadtmauer erlauben?,bool|1",
			"Anmerkung: Hierdurch wird das Durchschreiten der Stadtmauer unterbrochen und Zusatzmodule k�nnen eingef�gt werden,note",
			"Der Kommandant,title",
			"minleben"=>"Mindestwert der Lebenspunkte des Kommandanten pro Spielerlevel:,int|10",
			"maxleben"=>"H�chstwert  der Lebenspunkte des Kommandanten pro Spielerlevel:,int|15",
			"dk"=>"Steigt die St�rke des Kommandanten mit jedem DragonKill des Spielers?,bool|1",
			"abonus"=>"Angriffsbonus des Kommandanten zum Spielerangriff,range,1,10,1|2",
			"dbonus"=>"Verteidigungsbonus des Kommandanten zur Spielerverteidigung,range,1,10,1|2",
			"Kopfgeld,title",
			"kopfgeld"=>"Ab welcher Kopfgeldsumme wird der Spieler f�r die Stadtwache interessant?,int|100",
			"anzeige"=>"Kopfgeld f�r den jeweiligen Spieler in den Infos anzeigen?,bool|1",
		),
		"pref"=>array(
			"woher"=>"Von wo kommt der Spieler zum Tor,text|Neuinstallation",
		),
		"requires"=>array(
		"cities"=>" -- Teil des Core-Codes"
		),
    );
    return $info;
}

function stadttor_install(){
	if (!is_module_active("stadttor")) output("Das Stadttormodul Modul wird installiert.");
	module_addhook("village");
	module_addhook("changesetting");
	module_addhook("forest");
	module_addhook("travel");
	module_addhook("worldnav");
	module_addhook("potion");
	module_addhook("charstats");
	return true;
	
}

function stadttor_uninstall(){
	output("Das Stadttormodul Modul wird deinstalliert.");
	return true;
}

function stadttor_dohook($hookname, $args){
	global $session;
	
	switch($hookname){
		
		case "village":
			$woher=get_module_pref("woher");
			if (((get_module_setting("alle")==false) && ($session['user']['location'] == get_module_setting("ort"))) || (get_module_setting("alle")==true)) {   
				if ($session['user']['location'] != $woher) {
				page_header("%s",$session['user']['location']);
				blocknav("runmodule.php",true);
				blocknav("pvp.php",true);
				blocknav("forest.php");
				blocknav("login.php",true);
				blocknav("lodge.php");
				blocknav("gypsy.php");
				blocknav("pavilion.php");
				blocknav("inn.php");
				blocknav("stables.php");
				blocknav("gardens.php");
				blocknav("rock.php");
				blocknav("clan.php");
				blocknav("train.php");
				blocknav("bank.php");
				blocknav("weapons.php");
				blocknav("armor.php");
				blocknav("hof.php");
				blocknav("healer.php",true);
				blocknav("petition.php?op=faq");
				blocknav("news.php");
				blocknav("list.php");
				blocknav("prefs.php");
				unblocknav("runmodule.php?module=stadttor");
				unblocknav("runmodule.php?module=stadttor&op=mauer2");
				$wo=$args['gatenav'];
				addnav("$wo");
				addnav("`QDas Stadttor`0", "runmodule.php?module=stadttor");
				addnav("`QDie Stadtmauer`0", "runmodule.php?module=stadttor&op=mauer2");
				output("`c`\$Die Stadt %s`c`n",$session['user']['location']);
				output("`3Du erreichst `^%s`3, und stehst vor den Toren der Stadt.",$session['user']['location']);
				output("Zum Betreten der Stadt musst Du entweder durch");
				output("das bewachte Stadttor gehen, oder Dir einen Weg durch die Stadtmauer suchen.`n`n");
				set_module_pref("woher",$session['user']['location']);
				if (module_events("village", getsetting("villagechance", 0)) != 0) {
				if (checknavs()) {
				page_footer();
				} 
				else {
				$session['user']['specialinc'] = "";
				$session['user']['specialmisc'] = "";
				$skipvillagedesc=true;
				}
				}
				page_footer();
				}
			if ($session['user']['location'] == $woher) {			
				$wo=$args['gatenav'];
				addnav("$wo");
				addnav("`QDas Stadttor`0", "runmodule.php?module=stadttor");
				addnav("`QDie Stadtmauer`0", "runmodule.php?module=stadttor&op=mauer1");
				blocknav("pvp.php",true);
				blocknav("forest.php");
				blocknav("runmodule.php?module=cities",true);
				blocknav("login.php",true);
				if (is_module_active('worldmapen')) blocknav("runmodule.php?module=worldmapen",true);
				}
		  } 
		  else {
			set_module_pref("woher",$session['user']['location']);
		  }
		break;
		
		case "changesetting":
			if ($args['setting'] == "villagename"){ 
				if ($args['old'] == get_module_setting("ort")) {
					set_module_setting("ort", $args['new']);
				}
			}
		break;
		
		case "forest":
			if (((get_module_setting("alle")==false) && ($session['user']['location'] == get_module_setting("ort"))) || (get_module_setting("alle")==true)) {
				blocknav("village.php",true);
				addnav("Zur�ck");
				addnav("`QDas Stadttor`0", "runmodule.php?module=stadttor");
				addnav("`QDie Stadtmauer`0", "runmodule.php?module=stadttor&op=mauer");
			} 
			else {}
		break;
		  
		case "travel":
			blocknav("village.php",true);
			addnav(array("Stadt %s",$session['user']['location']));
			addnav("`QBetrete das Stadttor`0","runmodule.php?module=stadttor");
			addnav("`QBetrete die Stadtmauer`0", "runmodule.php?module=stadttor&op=mauer2");
		break;
			
		case "worldnav":
			blocknav("village.php",true);
			if ($session['user']['location'] != "World") {
				addnav(array("Stadt %s",$session['user']['location']));
				addnav("`QBetrete das Stadttor`0","runmodule.php?module=stadttor");
				addnav("`QBetrete die Stadtmauer`0", "runmodule.php?module=stadttor&op=mauer2");
			} else {}
		break;
		
		case "potion":
			blocknav("village.php",true);
		break;
		
		case "charstats":
		if (get_module_setting("anzeige")) {
			$sql="SELECT amount FROM ". db_prefix("bounty") ." WHERE status=0 and target=".$session['user']['acctid'];
			$ergebnis = db_query($sql) or die(sql_error($sql));
			for ($i=0;$i<db_num_rows($ergebnis);$i++){
   			$row = db_fetch_assoc($ergebnis);
  		    $bounty+=$row[amount];
			}
			if ($bounty=="") $bounty=0;
			setcharstat("Vital Info","Kopfgeld",$bounty);
		}
		break;
				
	}																			
	return $args;
}


function stadttor_run() {
	global $session;
	$op = httpget('op');
	$kopfgeld=get_module_setting("kopfgeld");
	$sql="SELECT amount FROM ". db_prefix("bounty") ." WHERE status=0 and target=".$session['user']['acctid'];
	$ergebnis = db_query($sql) or die(sql_error($sql));
	for ($i=0;$i<db_num_rows($ergebnis);$i++){
    $row = db_fetch_assoc($ergebnis);
    $bounty+=$row[amount];
	}
	if ($bounty=="") $bounty=0;
	$navmauer=get_module_setting("navmauer");
	require_once("lib/commentary.php");
	require_once("common.php");
	require_once("lib/villagenav.php");
	require_once("lib/fightnav.php");
	
	page_header("Das Stadttor");
if($op=="") {
	include ("modules/stadttor/stadttor_main.php");	
}
if($op=="felder"){
	page_header("Die Felder");
	output("`3 Du gehst in das Feldlager, das sich vor dem Tor befindet und schlenderst an vielen Zelten vorbei.");
	output("`3 Vor einigen sitzen Krieger, von denen Dich manche misstrauisch beobachten, andere wiederum Dich zu ihrem Lagerfeuer einladen.");
	output("`3Bei einem der Krieger machst Du dann halt und nimmst seine Einladung an, seinen Geschichten am Lagerfeuer zu lauschen:`n`n");
	addcommentary();
	viewcommentary("Felder","prahlt",20,"erz�hlt");
	addnav("Wege");
	addnav("Zur�ck zum Stadttor","runmodule.php?module=stadttor");
	$session['user']['specialinc']="";
	$session['user']['specialmisc']="";
	if ($session['user']['location'] != getsetting("villagename", LOCATION_FIELDS) && $session['user']['location'] != get_module_setting("villagename","ghosttown") && $session['user']['location'] != get_module_setting("villagename","icetown")) addnav("In den Wald","forest.php");
	addnav("Die Felder");
		if (getsetting("pvp",1))
		{
		addnav("Spieler t�ten","pvp.php");
		}
	addnav("Nachtlager aufschlagen `5(Logout)`0","login.php?op=logout",true);
	}
	
if ($op == "fighting"){
		$min=get_module_setting("minleben");
		$max=get_module_setting("maxleben");
		$leben=(e_rand($min,$max)*$session['user']['level']);
		if (get_module_setting("dk")) $bonus=$session['user']['dragonkills']*10;
		$gesamtleben=$leben+=$bonus;
		$abonus=get_module_setting("abonus");
		$dbonus=get_module_setting("dbonus");
		$badguy = array(        "creaturename"=>translate_inline("`4Kommandant der Torwache`0")
                                ,"creaturelevel"=>$session['user']['level']+1
                                ,"creatureweapon"=>translate_inline("Gro�e Hellebarde")
                                ,"creatureattack"=>$session['user']['attack']+=$abonus
                                ,"creaturedefense"=>$session['user']['defense']+=$dbonus
                                ,"creaturehealth"=>$gesamtleben
                                ,"creaturegold"=>0
                                ,"diddamage"=>0);
    $session['user']['badguy']=createstring($badguy);
    $op="fight";
    $battle=true;
	}
	
if ($op == "fight"){
		require_once("lib/fightnav.php");
		include("battle.php");
		
		if ($victory){
		output("`2Mit einem m�chtigen Hieb gibst Du dem Kommandanten den Todesstoss, nimmst die Beine in die Hand und verschwindest.`n`n");
		$erfahrung=round($session['user']['experience']*1.1) - $session['user']['experience'];
		$session['user']['experience']*=1.1;
		addnav("Weiter","runmodule.php?module=stadttor&op=weiter");
		output("Du erh�ltst `^%s`2 Erfahrungspunkte f�r Deinen Sieg.`n`n", $erfahrung);
		addnews("%s war im Kampf mit dem Kommandanten der Stadtwache siegreich.",$session['user']['name']);
	}
		elseif ($defeat){
		$session['user']['alive']=false;
		$session['user']['hitpoints']=0;
		$session['user']['gold']=0;
		$session['user']['experience']*=0.9;
		output("`4Du bist `bTOT`b!!!`nDu verlierst all Dein Gold und etwas Erfahrung.");
		addnav("T�gliche News","news.php");
		addnews("`2%s `4unterlag im Kampf dem Kommandant der Torwache.`nDieser hat hat nat�rlich auch die `6%s`4 Goldst�cke Kopfgeld kassiert.",$session['user']['name'],$bounty);
		$sql = "UPDATE ". db_prefix("bounty") ." SET status=1 WHERE target=".$session['user']['acctid'];
		db_query($sql);
	}
		else { fightnav(true,false,"runmodule.php?module=stadttor");
		}
}
			
if($op=="weiter"){
		output("`3Nach diesem schweren Kampf �berlegst Du Dir nun, wie es weiter gehen soll. Du lehnst Dich einen Moment an die Mauer und schaust Dir Deine M�glichkeiten nochmals genau an!`n`n");
			addnav("In der Stadtmauer");
			addnav("`QZur�ck in die Stadt`0","village.php");
			if (is_module_active('worldmapen')) addnav("Reisen","runmodule.php?module=worldmapen&op=beginjourney");
			else addnav("Reisen","runmodule.php?module=cities&op=travel");
			modulehook("stadttor");
			addnav("Vor dem Stadttor");
			$session['user']['specialinc']="";
			$session['user']['specialmisc']="";
			addnav("Zu den Feldern","runmodule.php?module=stadttor&op=felder");
			if ($session['user']['location'] != getsetting("villagename", LOCATION_FIELDS) && $session['user']['location'] != get_module_setting("villagename","ghosttown") && $session['user']['location'] != get_module_setting("villagename","icetown")) addnav("In den Wald","forest.php");
		}
		
if($op=="mauer"){
	page_header("Die Stadtmauer");
		output("`3 Du gehst, vom `2Wald `3kommend, zur Stadtmauer, da Du etwas zu verbergen hast und bef�rchtest, von den Torwachen gestellt zu werden, weshalb Du eine geheime T�r in der Mauer nutzen m�chtest, die nicht immer von den Stadwachen bewacht wird.");
		output("`3 Jetzt stehst Du vor der Stadtmauer, die stellenweise mit B�schen und Efeu dicht verwachsen ist und kannst die Stelle schon sehen, an der sich die T�r befinden mu�.");
		output("`@`n`nWas willst Du tun?`n`n");
		addnav("Die Stadtmauer");
		if ($navmauer==true) addnav("Versuchen, in die Stadt zu schleichen","runmodule.php?module=stadttor&op=schleichen&op2=nav");
		else addnav("Versuchen, in die Stadt zu schleichen","runmodule.php?module=stadttor&op=schleichen&op2=weiter");
		addnav("Vielleicht schaffe ich es ja doch durch das Stadttor","runmodule.php?module=stadttor");
		addnav("Doch lieber zur�ck in den Wald","forest.php");
		}

if($op=="schleichen"){
	include ("modules/stadttor/schleichen.php");
}

if($op=="mauer1"){
	page_header("Die Stadtmauer");
		output("`3 Du gehst, vom Marktplatz kommend, zu einer einsamen, verdeckten Stelle an der Stadtmauer, da Du etwas zu verbergen hast und bef�rchtest, von den Torwachen gestellt zu werden, weshalb Du eine geheime T�r in der Mauer nutzen m�chtest, die nicht immer von den Stadwachen bewacht wird.");
		output("`3 Jetzt stehst Du vor der Stadtmauer, die stellenweise mit B�schen und Efeu dicht verwachsen ist und kannst die Stelle schon sehen, an der sich die T�r befinden mu�.");
		output("`@`n`nWas willst Du tun?`n`n");
		addnav("Die Stadtmauer");
		if ($navmauer==true) addnav("Versuchen, aus Stadt zu schleichen","runmodule.php?module=stadttor&op=schleichen1&op2=nav");
		else addnav("Versuchen, aus Stadt zu schleichen","runmodule.php?module=stadttor&op=schleichen1&op2=weiter");
		addnav("Vielleicht schaffe ich es ja doch durch das Stadttor","runmodule.php?module=stadttor");
		addnav("Doch lieber zur�ck zum Marktplatz","village.php");
		}
		
if($op=="schleichen1"){
	include ("modules/stadttor/schleichen1.php");
}

if($op=="mauer2"){
	page_header("Die Stadtmauer");
		output("`3 Du gehst, aus `2der Wildnis `3kommend, zur Stadtmauer, da Du etwas zu verbergen hast und bef�rchtest, von den Torwachen gestellt zu werden, weshalb Du eine geheime T�r in der Mauer nutzen m�chtest, die nicht immer von den Stadwachen bewacht wird.");
		output("`3 Jetzt stehst Du vor der Stadtmauer, die stellenweise mit B�schen und Efeu dicht verwachsen ist und kannst die Stelle schon sehen, an der sich die T�r befinden mu�.");
		output("`@`n`nWas willst Du tun?`n`n");
		addnav("Die Stadtmauer");
		if ($navmauer==true) addnav("Versuchen, in die Stadt zu schleichen","runmodule.php?module=stadttor&op=schleichen&op2=nav");
		else addnav("Versuchen, in die Stadt zu schleichen","runmodule.php?module=stadttor&op=schleichen&op2=weiter");
		addnav("Vielleicht schaffe ich es ja doch durch das Stadttor","runmodule.php?module=stadttor");
		if (is_module_active('worldmapen')) addnav("Doch lieber sonst wohin reisen","runmodule.php?module=worldmapen&op=beginjourney");
		else addnav("Doch lieber sonst wohin reisen","runmodule.php?module=cities&op=travel");
		}

	page_footer();
}
?>