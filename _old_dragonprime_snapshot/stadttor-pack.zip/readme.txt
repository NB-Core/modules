**********************************************************************
* Das Stadttorpack --- ein Modulbundle von Apollon und BansheeElhayn *
*								     *
*       Kontakt: Apollon@magic.ms oder Agent.Herby@web.de            *
**********************************************************************


Dieses Zip-File sollte folgende Dateien beinhalten:

	- stadttor.php
	- torshop.php
	- burg.php
	- rittersaal.php
	- wolkeninsel.php
	- derhenker.php
	- henkerstube.php
	- geheimgang.php
	- richtplatz.php
	- kopfgeldliste.php
	- ein Unterverzeichnis "stadttor"
	- diese readme-Datei


==============================================================================================================

Installation:

Alle Dateien dieses Zip-Verzeichnisses in den Ordner .../modules kopieren und danach die Module einzeln �ber
die Grotte installieren und aktivieren.

==============================================================================================================


Hinweis: 

Das Modulbundle basiert auf der bereits ver�ffentlichten Version 1.61 (stadttor) und 1.4 (torshop). Die 
beiden Module wurden �berarbeitet und aus dem Modul Stadttor - zwecks Optimierung der Performance - mehrere 
Programmteile ausgegeliedert, die jetzt nur bei Bedarf nachgeladen werden (gleiches gilt f�r das Zusatzmodul
"henkerstube").
In das Bundle wurden nunmehr die Zusatzmodule burg, rittersaal und wolkeninsel aufgenommen, die bislang als 
Zusatzmodule einzeln verf�gbar waren.
Weiterhin wurde ein zus�tzlicher Einschnitt beim Durchschreiten der Stadtmauer eingef�gt, wonach dort nun auch
Erweiterungen plaziert werden k�nnen.
Abschlie�end wurden noch die NEUEN Module: derhenker (Waldspecial), henkerstube, richtplatz, kopfgeldliste und 
geheimgang beigef�gt, um das Bundle abzurunden und weitergehende M�glichkeiten zu schaffen.


==============================================================================================================


Unterst�tzte Fremdmodule:

Durch das Modulbundle werden folgende Fremdmodule unterst�tzt, deren Vorhandensein allerdings nicht zwingend
erforderlich f�r die Module sind. Diese laufen auch so stabil, bieten aber hierdurch weitere Funktionen:

	- worldmapen.php		(stadttor)
	- jail.php			(stadttor)
	- alignment.php			(henkerstube)
	- odor.php			(geheimgang)
	- battlearena.php		(henkerstube)

==============================================================================================================


Und nun, viel Spa�, 

Apollon und BansheeElhayn.

