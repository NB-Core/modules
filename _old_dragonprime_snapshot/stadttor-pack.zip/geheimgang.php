<?php

function geheimgang_getmoduleinfo() {
	$info = array (
		"name"=>"Stadtmauer-Geheimgang",
        "version"=>"1.0",
        "author"=>"<a href='http://www.dailyzone.selfhost.de/lotgd' target=_new>BansheeElhayn</a>",
        "category"=>"Stadttor",
        "download"=>"http://dragonprime.net/users/AgentHerby/stadttor-pack.zip",     
        "requires"=>array(
        "stadttor"=>"-- V1.7 by Apollon und BansheeElhayn",
        ),
        "settings"=>array(
        	"Geheimgang - Einstellungen,title",
        	"maxschritte"=>"Wieviel Schritte muss der Spieler machen bis er am Ende des Ganges steht?,int|10",
        	"Der Mauergeist,title",
        	"minleben"=>"Mindestwert der Lebenspunkte des Mauergeistes pro Spielerlevel:,int|10",
			"maxleben"=>"H�chstwert  der Lebenspunkte des Mauergeistes pro Spielerlevel:,int|15",
			"dk"=>"Steigt die St�rke des Mauergeistes mit jedem DrachenKill des Spielers?,bool|1",
        ),
        "prefs"=>array(
        	"heutebetreten"=>"Hat der Spieler den Geheimgang heute schon betreten?,bool|0",
        	"schritte"=>"Wie viele Schritte hat der Spieler bereits im Geheimgang zur�ckgelegt?,int|10"
        ),
    );
    return $info; 
}

function geheimgang_install() {
	if (!is_module_active("geheimgang")) {
		output("`n`3Installiere das Zusatzmodul \"`\$Geheimgang`3\" f�r die Stadtmauer.");
		output("`nUm das Modul in `bvollem Umfang`b nutzen zu k�nnen, sollte das Modul `6odor \"odor.php\" `3installiert sein.");
		output("`nViel Spa�!!`n`n");
	}
	module_addhook("mauer_nav"); 
	module_addhook("mauer_beschreibung");
	module_addhook("newday"); 
	return true;
}

function geheimgang_uninstall() {
	return true;
}

function geheimgang_dohook($hookname, $args){
	global $session;
	
	switch($hookname){
		case ("mauer_nav"):
			if (get_module_pref("heutebetreten")==false) {
				$zuffi=e_rand(1,4);
				switch ($zuffi) {
					case 2:
					output("`4`n`c<big><big>Ein lautes Klicken ist aus Deiner unmittelbaren Umgebung zu vernehmen.`c`0</big></big>",true);
					addnav("Das komische Klicken");
					addnav("N�her untersuchen","runmodule.php?module=geheimgang");
					break;
				}
			}
		break;
		
		case ("mauer_beschreibung"):
			output("`n`n`2Trotz, dass die W�nde hier recht feucht sind und die Luft muffig ist, gehst Du dicht an der Wand entlang,"); 
			output("`2um m�glichst nicht gesehen zu werden.`n`n`0");	
		break;
		
		case ("newday"):
			set_module_pref("heutebetreten",false);
			set_module_pref("schritte",1);
		break;
	}
  return $args;
}

function geheimgang_run() {
	global $session;
	$op=httpget('op');
	set_module_pref("vonmodul",true,"stadttor");
	$sql="SELECT amount FROM ". db_prefix("bounty") ." WHERE status=0 and target=".$session['user']['acctid'];
	$ergebnis = db_query($sql) or die(sql_error($sql));
	for ($i=0;$i<db_num_rows($ergebnis);$i++){
   		$row = db_fetch_assoc($ergebnis);
   		$bounty+=$row[amount];
	}
	if ($bounty=="") $bounty=0;
	page_header("Ein Geheimgang");
	
	if ($op=="") {
		output("`n`n`4Pl�tzlich, als Du das komische Klicken n�her untersuchst und mit Deinen H�nden an den dunklen, nassen W�nden der Stadtmauer herumdr�ckst,");
		output("`4ber�hrst Du durch Zufall einen Schalter, der den Eingang zu einem dunklen Gang freilegt.");
		output("`4Wie von Zauberhand sind ein paar Steine in der Wand zur Seite geglitten und Du kannst durch den Spalt");
		output("`4in das tiefe, feuchte, dunkle Innere der weiterf�hrenden Stadtmauer blicken.`n`n`2Wo mag der Gang nur hinf�hren? Was wird Dich erwarten?`n`n");
		output("`2Diese - und noch mehr - Fragen stellst Du Dir selbst. Wird Dich Deine Neugier packen den Gang zu gehen oder l��t Du es lieber bleiben?");
		addnav("Zur�ck");
		addnav("Zur�ck","runmodule.php?module=geheimgang&op=zurueck");
		addnav("Untersuchen");
		addnav("Weiter im Gang","runmodule.php?module=geheimgang&op=untersuchen");
	}
	
	if ($op=="untersuchen") {
		set_module_pref("heutebetreten",true);
		output("`2Du enscheidest Dich dazu, den Gang genauer unter die Lupe zu nehmen und trittst durch den Spalt, der den Eingang bildet.");
		output("`2Mit einem leisen Knirschen schlie�t sich die Wand wieder hinter Dir und l�sst Dich somit wissen, dass Du Dir wohl einen anderen Weg");
		output("`2hinaus suchen musst.`n`n`3Nachdem sich Deine Augen langsam an die Dunkelheit gew�hnt haben, beginnst Du Dich vorsichtig voran zu tasten.");
		output("`3Deine H�nde ertasten die groben, feuchten Steine der Mauer und der Gang f�hrt, jedenfalls ebenerdig, weiter. Schritt f�r Schritt tastest Du");
		output("`3Dich voran.`n`n");
		$op="untersuchen2";
	}
	
	if ($op=="zurueck") {
		output("`4Du kneifst, wie ein Feigling, aus Angst, dass Dich eine Spinne oder eine Ratte bei�en k�nnte. Schon in Deiner Kinderzeit hattest Du Panik");
		output("`4vor Dunkelheit und seltsamen Kreaturen. Nun werden Dir wohl f�r immer die Geheimnisse des Ganges verborgen bleiben. Eigentlich schade darum!`n`n");
		output("`2Mit dieser Moralpredigt Deines Gewissens trittst Du zur�ck ins diffuse Fackellicht des Durchgangs.");
		addnav("Weiter");
		addnav("Weiter","runmodule.php?module=stadttor&op=schleichen&op2=nav");
	}
	
	if($op=="untersuchen2") {
		$schritte=get_module_pref("schritte");
		output("`3Vorsichtig tastest Du Dich im Dunkeln weiter voran ...");
		if ($schritte<(get_module_setting("maxschritte")+1)) {
			$ueberschrift=translate_inline("`6`n`n`c ~ ~ ~ Etwas Besonderes ~ ~ ~`c`0");
			$zuffi=e_rand(1,50);
			switch ($zuffi) {
			
				case 1: case 2: case 3: case 4: case 9: case 10: case 11: case 12: case 13: case 14:
				case 17: case 18: case 20: case 21: case 22: case 23: case 26: case 27: case 28: case 29:
				case 30: case 31: case 32: case 34: case 35: case 36: case 37: case 38: case 39: case 40:
				case 41: case 42: case 44: case 45: case 47: case 48: case 49: 
					output("`2doch Dir f�llt nichts Besonderes auf.`n`n");
				break;
			
				case 5: case 33: case 46:
					output("<big><big>%s</big></big>",$ueberschrift,true);
					$goldfund=(e_rand(10,100)*$session['user']['level']); 
					output("`n`n`2Du greifst mit Deiner linken Hand in einen Mauerspalt und findest `^%s Goldst�cke `2darin verborgen.",$goldfund);
					$session['user']['gold']+=$goldfund;
				break;
				
				case 6: case 24:
					output("<big><big>%s</big></big>",$ueberschrift,true); 
					output("`n`n`2Du greifst mit Deiner linken Hand in einen Mauerspalt und findest `5einen Edelstein `2darin verborgen.");
					$session['user']['gems']++;
				break;
			
				case 7: case 50:
					output("<big><big>%s</big></big>",$ueberschrift,true);
					output("`n`n`2Pl�tzlich h�rst Du das Rauschen einer Toilettensp�lung und von links kommt aus der Wand ein Wasserstrahl geschossen. Alles l�uft");
					output("`2Dir �ber Deine R�stung. Offenbar befindest Du Dich in der N�he des �rtlichen Wohnviertels. Du r�mpfst die Nase, als Du");
					output("`2bemerkst, dass es Abw�sser sind und Du nun erheblich danach riechst.`n`n");
					if (is_module_active("odor")) {
						$odor=get_module_setting("odor","odor");
						$odor++;
						set_module_pref("odor",$odor,"odor");
						output("`4Dein K�rpergeruch ist dadurch wohl ein wenig strenger geworden.");
					} else {
						output("`4Die Nase Deiner Mitb�rger wird wohl ein wenig darunter zu leiden haben, so dass Du `5einen Charmepunkt `4verlierst.");
						$session['user']['charme']--;
					}
				break;
			
				case 8: case 15:
					output("<big><big>%s</big></big>",$ueberschrift,true);
					output("`n`n`2Du rutschst auf einem lockeren Stein im Boden aus und f�llst hin. Schnell rappelst Du Dich wieder auf und tastest Dich weiter.");
					output("`n`n`4Gl�cklicherweise hast Du Dich nicht `bernsthaft`b verletzt.`n");
					$session['user']['hitpoints']*=0.95;
					$max=round($session['user']['gold']/5);
					if ($max>1) { 
						$zuffi1=e_rand(1,3);	
						switch ($zuffi1) {
							case 2:
								$goldverlust=e_rand(2,$max);
								output("`4Dummerweise hast Du jedoch bei Deinem Sturz `^%s Goldst�cke `4verloren.",$goldverlust);
						}
					}
				break;
			
				case 16:
					output("<big><big>%s</big></big>",$ueberschrift,true);
					output("`n`n`2Pl�tzlich greift Deine rechte Hand ins Leere. Als Du Deinen Kopf nach der Seite drehst, erkennst Du im Dunkeln ein kleine");
					output("`2Einbuchtung in der Wand. Als Du dort mit Deinen H�nden tastend umhersuchst, findest Du `^eine Schatztruhe`2.`n`n");
					output("`4Voller Erstaunen l�sst Du einen leisen Pfiff ert�nen und ... z�gerst. Was mag die Truhe wohl verbergen?`n`n");
					output("`3Willst Du die Truhe �ffnen, oder doch sicherheitshalber lieber nicht?");
					addnav("Eine Schatztruhe");
					addnav("�ffnen","runmodule.php?module=geheimgang&op=oeffnen");
					addnav("Lieber nicht","runmodule.php?module=geheimgang&op=zulassen");
					$schritte++;
					set_module_pref("schritte",$schritte);
					page_footer();
				break;
			
				case 19:
					output("<big><big>%s</big></big>",$ueberschrift,true);
					output("`n`n`2Aus dem Nichts taucht pl�tzlich ein schwebendes Bettlaken auf. Noch bevor Du recht wei�t, was da auf Dich zu kommt, st��t das");
					output("`@Etwas `2auch schon einen markersch�tternden Schrei aus und greift Dich an.`n`n");
					output("`4Sofort wird Dir bewu�t, Du hast es mit einem `^Mauergeist `4 zu tun.");
					addnav("Ein Kampf");
					addnav("Gib Dein Bestes","runmodule.php?module=geheimgang&op=fighting");
					$schritte++;
					set_module_pref("schritte",$schritte);
					page_footer();
				break;
				
				case 25:
					output("<big><big>%s</big></big>",$ueberschrift,true);
					output("`n`n`2Aus dem Nichts begegnet Dir pl�tzlich eine schwarze Katze. Zuerst hast Du sie gar nicht bemerkt, da sie mit ihrem schwarzen");
					output("`2Fell in dieser Dunkelheit kaum auff�llt. Aber als sie schlie�lich um Deine Beine streicht und schnurrt und Du beinahe �ber sie");
					output("`2gefallen w�rst, wirst Du erst auf sie aufmerksam.`n`n");
					$katze=e_rand(1,6);
					switch ($katze) {
						
						case 1: case 2: case 3: case 4:
							output("`4Du b�ckst Dich und streichelst das K�tzchen, welches verz�ckt schnurrt und anschlie�end wieder in der Dunkelheit");
							output("`4des Ganges verschwindet.");
						break;
						
						case 5: 
							output("`4Du b�ckst Dich und streichelst das K�tzchen, welches sich mit einem lauten *puff* in den `@gestiefelten Kater");
							output("`4verwandelt. Du dachtest immer, der gestiefelte Kater sei nur eine Erfindung der `^Gebr�der Grimm`4, doch offenbar");
							output("`4lagst Du mit dieser Vermutung falsch.`n`n");
							output("`3\"Ich danke Dir f�r Deine Freundlichkeit mich zu streicheln\"`2, beginnt der `@gestiefelte Kater `2zu sprechen.");
							output("`3\"Daf�r sollst Du eine Belohnung erhalten. Ich werde Dir zum Dank meine `^Siebenmeilenstiefel `3vermachen.\"`n`n");
							output("`2Du erh�ltst dadurch `52 `2zus�tzliche freie Reisen f�r heute.");
							$reisen=get_module_pref("traveltoday","cities");
							$reisen-=2;
							set_module_pref("traveltoday",$reisen,"cities");
						break;
						
						case 6:
							output("`4Du b�ckst Dich und streichelst das K�tzchen, welches verz�ckt schnurrt und anschlie�end in einem kleinen Durchbruch");
							output("`4in der Wand verschwindet. Hierdurch erst wirst Du auf den Durchbruch aufmerksam und probierst mit der Hand aus, ob");
							output("`4Du auch durchpassen w�rdest. Nachdem Du feststellst, dass Du ebenfalls hindurchpassen w�rdest, �berlegst Du Dir, ob");
							output("`4Du es versuchen solltest.`n`n`2Willst Du der Katze durch den Durchbruch folgen oder lieber den Gang weitergehen?");
							addnav("Was tun?");
							addnav("Der Katze folgen","runmodule.php?module=geheimgang&op=folgen");
							addnav("Weiter im Gang","runmodule.php?module=geheimgang&op=weiter");
							$schritte++;
							set_module_pref("schritte",$schritte);
							page_footer();
						break;	
					}
				break;
				
				case 43:
					output("<big><big>%s</big></big>",$ueberschrift,true);
					output("`n`n`2Pl�tzlich trittst Du auf einen Stein, der leicht unter dem Gewicht Deines K�rpers nachgibt. Aus der Entfernung h�rst Du ein");
					output("`2dumpfes Krachen und anschlie�end ein dumpfes Poltern.`n`nDas Poltern wird immer lauter und hinzu kommt ein Ger�usch, das sich");
					output("`2anh�rt, als w�rden Steine zwischen gro�en M�hlenr�dern zermahlen.`n`n");
					output("`4Noch bevor Du die Zeit dazu hast dar�ber nachzudenken, was das Ger�usch bedeuten k�nnte und woher es kommen mag, siehst Du auch");
					output("`4schon aus dem Dunkeln vor Dir eine riesige Felskugel heranrollen. Hastig suchst Du nach einem Fluchtweg, doch rechts und links von");
					output("`4Dir sind nur die W�nde der Stadtmauer. Eilig drehst Du Dich um und versucht in die Richtung, aus der Du kamst, wegzulaufen, doch");
					output("`4auf Grund des, in diese Richtung absch�ssigen, Ganges hat Dich die Kugel binnen Sekunden eingeholt und �berrollt. Du hattest");
					output("`4keine Chance und wurdest zermalmt, wie eine Coladose unter einer Dampfwalze.`n`n");
					output("`4Du bist TOT!!!`nDu verlierst all Dein Gold und 10 Prozent Erfahrung.");
					$session['user']['alive']=false;
					$session['user']['hitpoints']=0;
					$session['user']['gold']=0;
					$session['user']['experience']*=0.9;
					addnav("Neuigkeiten");
					addnav("T�gliche News","news.php");
					if ($bounty>0) {
						addnews("`2%s `4wurde von einer Felskugel �berrollt und zermalmt.`nDie `6%s`4 Goldst�cke Kopfgeld fallen der Staatskasse zu.",$session['user']['name'],$bounty);
						$sql = "UPDATE ". db_prefix("bounty") ." SET status=1 WHERE target=".$session['user']['acctid'];
						db_query($sql);
					}
					else addnews("`2%s `4wurde von einer Felskugel �berrollt und zermalmt.",$session['user']['name']);
					page_footer();
				break;
			}
			$schritte++;
			set_module_pref("schritte",$schritte);
			addnav("Weiter");
			addnav("einen Schritt vorw�rts machen","runmodule.php?module=geheimgang&op=untersuchen2");
			page_footer();
		}  else {
			output("`2und erreichst eine kleine T�r.`n`n`3Z�gernd �ffnest Du sie und stehst wieder in der Stadtmauer. Du bemerkst, dass Du in der Mauer einmal");
			output("`3rund um ganz `^%s `3herum gelaufen bist.`n`n`4F�r heute hast Du genug von Geheimg�ngen. Vielleicht wirst Du Dein Gl�ck morgen wieder versuchen",$session['user']['location']);
			addnav("Weiter");
			addnav("Geheimgang verlassen","runmodule.php?module=stadttor&op=schleichen&op2=nav");
			page_footer();
		}
	}
	
	if ($op=="zulassen") {
		output("`4Aus Angst vor dem Inhalt der Truhe, l�sst Du diese unge�ffnet und setzt Deinen Weg durch den Gang fort.");
		addnav("Weiter");
		addnav("einen Schritt vorw�rts machen","runmodule.php?module=geheimgang&op=untersuchen2");
	}
	
	if ($op=="oeffnen") {
		page_header("Eine Schatztruhe");
		output("`3Neugierig wie Du bist, �ffnest Du die Truhe und ");
		$zuffi=e_rand(1,10);
		switch ($zuffi) {
			
			case 1: case 2: case 8:
				$goldfund=(e_rand(100,500)*$session['user']['level']); 
				$session['user']['gold']+=$goldfund;
				output("`2findest `n`n`c`^<big><big>%s Goldst�cke</big></big>`c`n`n`2darin.",$goldfund,true);
			break;
			
			case 3: case 9:
				output("`2findest `n`n`c`5<big><big>3 Edelsteine</big></big>`c`n`n`2darin.",true);	
				$session['user']['gems']+=3;
			break;
			
			case 4:
				output("`2springst erschrocken zur�ck.`n`n`4Aus der Truhe heraus ert�nt ein markersch�tternder Schrei und ein `&Mauergeist `4steigt empor.");
				output("`nDu hast keine andere Wahl ... und wirst wohl k�mpfen m�ssen.`n`n");
				addnav("Ein Kampf");
				addnav("Gib Dein Bestes","runmodule.php?module=geheimgang&op=fighting");
				page_footer();
			break;
			
			case 5: case 10:
				output("`2findest `n`n`c`4<big><big>nichts au�er Spinnweben</big></big>`c`n`n`2darin.",true);
				output("`2Offenbar ist Dir schon jemand Anderes zuvorgekommen.");
			break;
			
			case 6:
				output("`2findest `n`n`c`@<big><big>die legend�re Drachenr�stung</big></big>`c`n`n`2darin.",true);
				if ($session['user']['armordef']<16) {
					if (get_module_pref("armorname","customeq")=="") {
						$session['user']['armor']="Drachenr�stung";
						output("`3`n`nVoller Stolz legst Du Deine neue R�stung an und sp�rst, die Macht der `@Drachenr�stung `3sofort!");
					} else {
						output("`3`n`nVoller Stolz legst Du Deine neue R�stung an und sp�rst, die Macht der `@Drachenr�stung `3sofort!");
						output("`4`n`nDoch sogleich verwandelt sie sich wieder in Deine alte R�stung `^%s `4zur�ck, ohne Dir jedoch ihre neue Macht wieder zu nehmen.",$session['user']['armor']);
					}
					$verteidigung=(16-$session['user']['armordef']);
					$session['user']['defense']+=$verteidigung;
					$session['user']['armordef']=16;
					$session['user']['armorvalue']=20000;
				} else {
					output("`n`n`4Doch da Deine aktuelle R�stung bereits st�rker ist, als die `@Drachenr�stung`4, l�sst Du sie unber�hrt in der Truhe liegen.");
				}
				addnews("`2%s `1fand heute in einer `^Schatztruhe `1die `@legend�re Drachenr�stung`1.",$session['user']['name']);
			break;
			
			case 7:
				output("`2findest `n`n`c`@<big><big>das legend�re Drachenschwert</big></big>`c`n`n`2darin.",true);
				if ($session['user']['weapondmg']<16) {
					if (get_module_pref("weaponname","customeq")=="") {
						$session['user']['weapon']="Drachenschwert";
						output("`3`n`nVoller Stolz nimmst Du Deine neue Waffe in die Hand und sp�rst, die Macht des `@Drachenschwertes `3sofort!");
					} else {
						output("`3`n`nVoller Stolz nimmst Du Deine neue Waffe in die Hand und sp�rst, die Macht des `@Drachenschwertes `3sofort!");
						output("`4`n`nDoch sogleich verwandelt es sich wieder in Deine alte Waffe `^%s `4zur�ck, ohne Dir jedoch seine neue Macht wieder zu nehmen.",$session['user']['weapon']);
					}
					$angriff=(16-$session['user']['weapondmg']);
					$session['user']['attack']+=$angriff;
					$session['user']['weapondmg']=16;
					$session['user']['weaponvalue']=20000;
				} else {
					output("`n`n`4Doch da Deine aktuelle Waffe bereits st�rker ist, als das `@Drachenschwert`4, l�sst Du es unber�hrt in der Truhe liegen.");
				}
				addnews("`2%s `1fand heute in einer `^Schatztruhe `1das `@legend�re Drachenschwert`1.",$session['user']['name']);
			break;
		}
		addnav("Weiter");
		addnav("einen Schritt vorw�rts machen","runmodule.php?module=geheimgang&op=untersuchen2");
	}
	
	if ($op=="folgen") {
		output("`2Neugierig folgst Du dem kleinen K�tzchen in den Durchbruch.`n`n`4Nach l�ngerer Krabbelei und unz�hligen Biegungen, verbreitert sich der");
		output("`4Durchgang pl�tzlich und Du stehst in ");
		if (is_module_active("burg")) $max=3;
		else $max=2;
		$zuffi=e_rand(1,$max);
		switch ($zuffi) {
			
			case 1:
				output("`4einem ger�umigen, halbdunklen Schacht.`n`n");
				output("`2Nachdem sich Deine Augen wieder langsam an das sp�rliche Licht Deines Umfeldes gew�hnt haben erkennst Du, dass Du in einem");
				output("`2tiefen Brunnenschacht stehst. An der Wand bemerkst Du eine Leiter, die im Schacht nach oben f�hrt.`n`n");
				output("`3Langsam beginnst Du die Leiter nach oben zu klettern. Als Du am oberen Ende des Brunnens angelangt bist, stellst Du fest, dass Du");
				output("`3auf dem Marktplatz von `^%s `3herausgekommen bist.",$session['user']['location']);
				addnav("Der Ausgang");
				addnav("Brunnen verlassen","village.php");
			break;
			
			case 2:
				output("`4einer ger�umigen, halbdunklen H�hle.`n`n");
				output("`2Nachdem sich Deine Augen wieder langsam an das sp�rliche Licht Deines Umfeldes gew�hnt haben erkennst Du diverse H�hlenmalereien");
				output("`2an den W�nden, die auf eine l�ngst verlassene H�hle aus alter Zeit hindeuten. Zeichnungen von Menschen bei der Jagd auf l�ngst");
				output("`2ausgestorbene Urzeitriesen sind ebenso zu sehen, wie Kreaturen bei ihrem Kampf mit mutigen Abenteurern. Ganz besonders");
				output("`2fasziniert Dich jedoch eine Abbildung, auf der Du die `@legend�re Drachenr�stung `2und das `@legend�re Drachenschwert");
				output("`2wiedererkennst. Du siehst, wie sie ein alter Schmied offenbar in Truhen versteckt, die sich in einem langen, dunklen Gang befinden.");
				output("`2Nach l�ngerer Betrachtung des Bildes wirst Du das Gef�hl nicht los, dass Du diesen Gang schon einmal gesehen hast. Wo k�nnten sich");
				output("`2diese Truhen blo� befinden und die Sch�tze versteckt sein?`n`n`3Nach l�ngerem Gr�beln verl�sst Du erst einmal die H�hle und");
				output("`3trittst hinaus in das Dickicht des `2Waldes`3.");
				addnav("Der Ausgang");
				addnav("H�hle verlassen","forest.php");
			break;
			
			case 3:
				output("`4einem ger�umigen, halbdunklen Schacht.`n`n");
				output("`2Nachdem sich Deine Augen wieder langsam an das sp�rliche Licht Deines Umfeldes gew�hnt haben erkennst Du, dass Du in einem");
				output("`2tiefen Brunnenschacht stehst. An der Wand bemerkst Du eine Leiter, die im Schacht nach oben f�hrt.`n`n");
				output("`3Langsam beginnst Du die Leiter nach oben zu klettern. Als Du am oberen Ende des Brunnens angelangt bist, stellst Du fest, dass Du");
				output("`3auf dem Burghof in der Burganlage von `^%s `3herausgekommen bist.",$session['user']['location']);
				addnav("Der Ausgang");
				addnav("Brunnen verlassen","runmodule.php?module=burg");
			break;
		}
		page_footer();
	}
	
	if ($op=="weiter") {
		output("`2Du entscheidest Dich dazu, dem K�tzchen nicht zu folgen, sondern Deinen Weg durch den Tunnel fort zu setzen. Wer wei�, wohin der Weg");
		output("`2wohl gef�hrt haben mag.`n`n");
		output("`4Mit beherztem Schritt setzt Du Deinen Weg durch den Geheimgang fort.");
		addnav("Weiter");
		addnav("einen Schritt vorw�rts machen","runmodule.php?module=geheimgang&op=untersuchen2");
	}
	
	if($op=="fighting") {
		$min=get_module_setting("minleben");
		$max=get_module_setting("maxleben");
		$leben=(e_rand($min,$max)*$session['user']['level']);
		if (get_module_setting("dk")) $bonus=$session['user']['dragonkills']*10;
		$gesamtleben=$leben+=$bonus;
		$badguy = array(        "creaturename"=>translate_inline("`4Mauergeist`0")
                                ,"creaturelevel"=>$session['user']['level']+1
                                ,"creatureweapon"=>translate_inline("`4Spukgeschrei")
                                ,"creatureattack"=>$session['user']['attack']+=5
                                ,"creaturedefense"=>$session['user']['defense']+=5
                                ,"creaturehealth"=>$gesamtleben
                                ,"creaturegold"=>0
                                ,"diddamage"=>0);
    	$session['user']['badguy']=createstring($badguy);
    	$op="fight";
    	$battle=true;
	}
	
	if($op=="fight") {
		require_once("lib/fightnav.php");
		include("battle.php");
		
		if ($victory){
		output("`2Dein letzter Schlag l��t den Mauergeist mit einem kl�glichen Seufzer verschwinden.`n`n");
		$erfahrung=round($session['user']['experience']*1.05) - $session['user']['experience'];
		if ($erfahrung>0) $session['user']['experience']*=1.05;
		else {
			$session['user']['experience']++;
			$erfahrung=1;
		}
		addnav("Weiter","runmodule.php?module=geheimgang&op=sieg");
		output("Du erh�ltst `^%s`2 %s f�r Deinen Sieg.`n`n", $erfahrung,translate_inline($erfahrung?"Erfahrungspunkt":"Erfahrungspunkte"));
		addnews("`4%s `2hat das Spukgeschrei eines Mauergeistes �berlebt.",$session['user']['name']);
		}
		elseif ($defeat){
		$session['user']['alive']=false;
		$session['user']['hitpoints']=0;
		$session['user']['gold']=0;
		$session['user']['experience']*=0.9;
		output("`3`nMit einem letzten, markersch�tternden Schrei bef�rdert Dich der Geist ins Jenseits.`n`n");
		output("`4Du bist TOT!!!`nDu verlierst all Dein Gold und 10 Prozent Erfahrung.");
		addnav("Neuigkeiten");
		addnav("T�gliche News","news.php");
		if ($bounty>0) {
			addnews("`2%s `4wurde von einem Mauergeist ins Jenseits bef�rdert.`nDie `6%s`4 Goldst�cke Kopfgeld fallen der Staatskasse zu.",$session['user']['name'],$bounty);
			$sql = "UPDATE ". db_prefix("bounty") ." SET status=1 WHERE target=".$session['user']['acctid'];
			db_query($sql);
		}
		else addnews("`2%s `4wurde von einem Mauergeist ins Jenseits bef�rdert.",$session['user']['name']);
		}
		else { 
			fightnav(true,false,"runmodule.php?module=geheimgang");
		}
	}
	
	if ($op=="sieg") {
		output("<big><big><big>`5`c - - - S I E G - - -`c</big></big></big>",true);
		output("`n`n`2Du hast es tats�chlich geschafft. Lose, ohne Inhalt, liegt das Leichentuch, das Dich eben erst bek�mpfte, auf dem Boden des Ganges.");
		output("`2Schaudernd denkst Du nocheinmal dar�ber nach, welche Kreaturen hier wohl hausen und gehst raschen Schrittes weiter, um schnellstm�glich");
		output("`2einen Ausweg aus dem Gang zu finden.");
		addnav("Weiter");
		addnav("einen Schritt vorw�rts machen","runmodule.php?module=geheimgang&op=untersuchen2");
	}
	
	page_footer();
}