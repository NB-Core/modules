<?php

		page_header("Der Galgen");
			output("<big><big>`c`4- - - Der Galgen - - -`c</big></big>`n`n",true);
			output("`3Du n�herst Dich dem Galgen auf dem Richtplatz.`n`nNeugierig trittst Du n�her und siehst zu Deinem Schrecken als neustes Opfer `^%s `3daran baumeln.",$gspieler);
			output("`3Erschrocken springst Du einen Schritt zur�ck");
			if ($besuchgalgen<3) {
			  if ($align<$balign) {
				output("`3, doch zu sp�t! Deine `4 b�sen %s `3haben sich bereits herumgesprochen.",$aktiv);
				output("`3Keuchend siehst Du den Henker heraneilen und");
				$zuffi=e_rand(1,10);
				switch ($zuffi) {
					
					case 1:
					case 2:
					case 3:
						output("`3gibst schnell Fersengeld.`n`n`2Knapp war's, aber Du hast es geschafft. Du bist dem Henker gerade noch einmal entkommen.");
					break;
					
					case 4:
					case 5:
						output("`3gibst schnell Fersengeld.`n`n`2Du tauchst dem verdutzten Henker zwischen den Beinen durch und greifst dabei noch");
						output("`2nach dessen Geldb�rse an seinem G�rtel.");
						output("`2Es gelingt Dir auf diese Art sogar, zus�tzlich zu Deiner Flucht, `^%s `2Goldst�cke zu entwenden.",e_rand(30,70)*$session['user']['level']);
						output("`2Nat�rlich ist der Henker dar�ber nicht wirklich froh und wird sich Dein Gesicht in Zukunft wohl gut merken.");
						set_module_pref("henkerbestohlen",1);
						if ($alignja) {
							output("`2Deine Gesinnung hat sich dadurch nat�rlich auch nicht wirklich verbessert, eher wohl noch verschlechtert");
							align(-3);
						}
					break;
					
					case 6:
					case 7:
						output("`3gibst schnell Fersengeld.`n`n`2Die Axt des Henkers schwirrt durch die Luft und trifft Dich noch im R�cken."); 
						output("Schwer verletzt gelingt Dir dennoch die Flucht. Das war knapp!");
						$session['user']['hitpoints']*=0.1;
					break;
					
					case 8:
					case 9:
						if ($henkerkampf==0) {
							output("stellst fest, dass Du keine Zeit mehr zur Flucht hast.`n`n`2Jetzt gibt es nur noch eines .... k�mpfe um Dein Leben!!");
							addnav("Auf in den Kampf");
							addnav("K�mpfen","runmodule.php?module=henkerstube&op=fighting");
						} 
						else {
							output("`3gibst schnell Fersengeld.`n`n`2Die Axt des Henkers schwirrt durch die Luft und trifft Dich noch im R�cken."); 
							output("Schwer verletzt gelingt Dir dennoch die Flucht. Das war knapp!");
							$session['user']['hitpoints']*=0.1;
						}
					break;
					
					case 10:
						output("hast keine Zeit mehr zur Flucht.`n`n`2Die Axt des Henkers schwirrt durch die Luft und trifft Dich noch im R�cken.");
						output("Die Wunde ist so tief, dass Du nach wenigen Schritten, die Du noch zu fl�chten versuchst, schwer getroffen");
						output("zu Boden sinkst. Der Henker holt Dich ein und tr�gt Dich zum Galgen. Noch keine 5 Minuten sp�ter baumelst Du neben");
						output("all den anderen armen Seeln. Deine Seele macht einen Ausflug in die Unterwelt.`n`n`4Du verlierst 5% Deiner Erfahrung");
						set_module_setting("gspieler",$session['user']['name']);
						$session['user']['experience']*=0.95;	
						output("und all Dein Gold.`n");
						if ($bounty>0) {
							output("`4Dein einziger Vorteil liegt wohl darin, dass der Henker auch Dein Kopfgeld kassiert und Du Dich nunmehr weniger vor");
							output("`4Deinen Mitspielern zu f�rchten brauchst.`n");
							addnews("`2%s `4wurde vom Henker am Galgen aufgekn�pft.`nDie `^%s Goldst�cke Kopfgeld `4hat dieser nat�rlich auch kassiert.",$session['user']['name'],$bounty);
							$kopfgeldloeschen = "UPDATE ". db_prefix("bounty") ." SET status=1 WHERE target=".$session['user']['acctid'];
							db_query($kopfgeldloeschen);
						}
						if ($alignja){
							output("`4Au�erdem wird dadurch Dein Ruf etwas gel�utert und Du steigst in Deiner Gesinnung wieder ein wenig.`n");
							align(+2);
						}
						if ($henkerbestohlen) {
							set_module_pref("henkerbestohlen",0);
							output("`4Daf�r, dass Du den Henker damals bestohlen hattest, hat er sich nun wahrlich ger�cht!");
						}
						$session['user']['alive']=false;
						$session['user']['hitpoints']=0;
						$session['user']['gold']=0;
						addnav("Neuigkeiten");
						addnav("T�gliche News","news.php");
						page_footer();
					break;
				}
			}
			  if ($align>=$balign && $align<$galign) {
				output("`3und erschauderst bei dem Gedanken daran, auch einmal so enden zu k�nnen. Aber Deine `^%s `3haben sich herumgesprochen.",$aktiv);
				output("`3Da Du weder besonders gut noch b�se warst, ist diese Wahrscheinlichkeit eher gering. Neben dem Galgen steht der Henker");
				output("`3und sch�rft seine Axt. Daneben liegen bereits neue, frisch gekn�pfte Stricke, die nur darauf warten einem Opfer um den");
				output("`3Hals gelegt zu werden.`n`nNeugierig gehst Du n�her und");
				$zuffi=e_rand(1,10);
				switch ($zuffi) {
					
					case 1:
					case 2:
					case 3:
						output("`3schaust dem Henker bei seiner Arbeit zu. Doch dieser beachtet Dich nicht sonderlich, sondern arbeitet ruhig weiter.`n`n");
						output("`2Nach einiger Zeit wird es Dir aber zu langweilig und Du gehst zur�ck zum Richtplatz.");
					break;
					
					case 4:
					case 5:
						output("`3schaust dem Henker bei seiner Arbeit zu. Dieser schaut nach einer Weile auf und starrt Dir ins Gesicht.`n`n`2Bei dem");
						output("`2Anblick seiner Augen erschrickst Du Dich derma�en, dass Du schreiend davonrennst. Dabei wirst Du von ein paar Burgfr�uleins");
						output("`2beobachtet und erntest schallendes Gel�chter. Du sch�mst Dich in Grund und Boden und versteckst Dich hinter einem");
						output("`2gro�en Fa� `6Maisbrei`2, das zuf�llig neben dem Galgen steht.`n`n");
						if ($alignja) {
							output("`4Deine �bertriebene Angst l��t Dich in Deinem Ansehen ein wenig sinken.");
							align(-1);
						} else {
							output("`4Durch Deine �bertriebene Angst und das sp�ttische Gel�chter der Burgfr�uleins b��t Du einen Charmepunkt ein.");
							$session['user']['charm']--;
						}
					break;
					
					case 6:
					case 7:
						output("`3schaust dem Henker bei seiner Arbeit zu.`n`n`2Dann bittet er Dich pl�tzlich darum, mit seiner Arbeit fortzufahren, da er");
						output("`2ein dringendes Bed�rfnis versp�re und gleich noch eine Hinrichtung habe. Du stimmst zu und �bernimmst das Sch�rfen der");
						output("`2Axt f�r ihn.`n`n`4Nach einigen Minuten kommt er zur�ck und betrachtet Dein Werk.`n`n");
						$zuffi=e_rand(1,3);
						switch ($zuffi1) {
							
							case 1:
							case 2:
								$lohn=e_rand(10,40)*$session['user']['level'];
								output("`4Offenbar ist er zufrieden mit Deiner Arbeit und gibt Dir daf�r `6%s Goldst�cke `4als Lohn f�r Deine M�he.",$lohn);
								$session['user']['gold']+=$lohn;
							break;
							
							case 3:
								output("`4Nach kurzer Betrachtung der Schneide beschwert er sich �ber Deine Unf�higkeit und jagt Dich fort.");
							break;
						}
					break;
					
					case 8:
					case 9:
						output("`3schaust dem Henker bei seiner Arbeit zu.`n`n`2Dann bittet er Dich pl�tzlich darum, mit seiner Arbeit fortzufahren, da er");
						output("`2ein dringendes Bed�rfnis versp�re und gleich noch eine Hinrichtung habe. Du stimmst zu und �bernimmst das Sch�rfen der");
						output("`2Axt f�r ihn.`n`n`4Stunden sp�ter ist er noch immer nicht zur�ck. Pl�tzlich bringt der Scheriff der Stadt einen Verurteilten");
						output("`4zum Galgenbaum und verk�ndet dem Volk dessen Hinrichtung. Da Du dem Henker versprochen hast, sein Werk w�hrend seiner");
						output("`4Abwesenheit zu �bernehmen, musst Du wohl oder �bel auch die Hinrichtung durchf�hren.`nDu streifst Dir also die Maske �ber, die");
						output("`4neben Dir liegt, und begibst Dich auf das Schafott. Mit einem leichten Magendr�cken nimmst Du mit der Axt Ma� und ...");
						$zuffi=e_rand(1,3);
						switch ($zuffi1) {
							
							case 1:
							case 2:
								output("`4l��t die Axt niedersausen. Das Werk ist vollbracht und die Menge jubelt Dir zu. Als Du dann, schwei�gebadet die Kapuze");
								output("`4abstreifst, geht ein Raunen durch die Schaulustigen. Der Scheriff ist vollkommen verbl�fft und, nachdem er sich");
								output("`4kurz gesammelt hat, kommt er auf Dich zu. Er sch�ttelt Dir die Hand und gratuliert Dir zu Deinem Einsatz.");
								$lohn=e_rand(30,70)*$session['user']['level'];
								output("`4Der Lohn des Scharfrichters wird nun Dir zuteil. Er �berreicht Dir `^%s Goldst�cke `4als Entlohnung.`n`n");
								$session['user']['gold']+=$lohn;
							break;	
							
							case 3:
								output("`4l��t die Axt dann sinken. Ein Raunen geht durch die Menge und der Scheriff entr�stet sich lautstark �ber Dich.");
								output("`4Pl�tzlich springt ein Mann aus dem Publikum auf das Schafott und rei�t dem Verurteilten die Augenbinde ab.");
								output("`4Nun geht ein Aufschrei durch die Menge. Der Scheriff selbst f�llt fast in Ohnmacht als er - ohne die Augenbinde - den");
								output("`4geknebelt und gefesselten B�rgermeister erkennt. Irgendwie war es dem Verbrecher gelungen zu entkommen und den");
								output("`4B�rgermeister an seine Stelle zu bringen. Sofort werden nat�rlich alle Fesseln gel�st und der B�rgermeister");
								output("`4und der Scheriff sind �bergl�cklich, dass Du die Axt nicht hast niedersausen lassen.`n`n");
								output("`2Aus Dankbarkeit �ber seine unerwartete Rettung in letzter Sekunde �berl�sst Dir der B�rgermeister");
								output("`55 seiner Edelsteine.`n`n");
								$session['user']['gems']+=5;
								if ($alignja) {
									output("`2Die Rettung des B�rgermeisters l��t Dich im allgemeinen Ansehen stark steigen.");
									align(+5);
								} else {
									output("`2Die Rettung des B�rgermeisters bringt Dich ein St�ck weiter in die Herzen der Frauen des Landes.");
									output("`2Du erh�ltst `55 Charmepunkte`2.");
									$session['user']['charm']+=5;
								}
								addnews("`2%s `3rettete heute den B�rgermeister von `^%s `3vor dem Tod durch die Axt.",$session['user']['name'],$session['user']['location']);
							break;
						}
					break;
						
					case 10:
						output("`3schaust dem Henker bei seiner Arbeit zu.`n`n`2Dann bittet er Dich pl�tzlich darum, mit seiner Arbeit fortzufahren, da er");
						output("`2ein dringendes Bed�rfnis versp�re und gleich noch eine Hinrichtung habe. Du stimmst zu und �bernimmst das Sch�rfen der");
						output("`2Axt f�r ihn.`n`n`4Pl�tzlich rutschst Du vom Schleifstein ab und rammst Dir dabei die Axt - mit der Schneide zu Dir -");
						output("`4in die Brust. Noch ehe der Henker, der gerade wiederkommt, Dir helfen kann, bist Du an Deiner schweren Verletzung gestorben.");
						addnews("`2%s `4hat sich heute beim Sch�rfen einer Axt verletzt und ist daran gestorben.",$session['user']['name']);
						$session['user']['alive']=false;
						$session['user']['hitpoints']=0;
						$session['user']['gold']=0;
						addnav("Neuigkeiten");
						addnav("T�gliche News","news.php");
						page_footer();
					break;
				}
			}
			  if ($align>=$galign) {
				output("`3. Du sch�ttelst nur den Kopf und �berlegst, weshalb man so schrecklich enden kann. Deine `2guten %s `3 machen es Dir schwer, dies",$aktiv);
				output("`3zu verstehen. Du willst der Sache weiter auf den Grund gehen und besteigst das Schafott, um Dir die armen Teufel dort n�her zu");
				output("`3betrachten. Schlie�lich gehst Du zum einem der baumelnden K�rper und liest auf dem Schild auf seiner Brust:`n`n`c`6Verurteilt zum Tode");
				output("`6durch den Strang auf Anordnung des h�chsten Gerichtes des Landes f�r`n");
				$schrift=e_rand(1,15);
				$info1="`1Banshee`!Elhayn";
				$info2="`1Apollon's Segen";
				$info3="`qApollon";
				switch ($schrift) {
					
					 case 1: output("das Beleidigen seiner Majest�t \"%s\".`3",$info1); break;
	 				 case 2: output("den Diebstahl von Edelsteinen aus dem Haus des B�rgermeisters.`3"); break;
					 case 3: output("die Bel�stigung von Rittern im Rittersaal w�hrend des Festmahles.`3"); break;
					 case 4: output("die Vergewaltigung von Prinzessin \"`QArlonara\".`3"); break;
					 case 5: output("das Entz�nden eines Waldfeuers mit Todesfolge f�r 1000 Waldtiere.`3"); break;
				 	 case 6: output("das Brauen von Starkbier au�erhalb \"`!Cedrik's `^Brauerei\".`3"); break;
					 case 7: output("den Versuch einer billigen Kopie von \"%s\".`3",$info2); break;
					 case 8: output("das Ver�ndern von \"%s's `6und %s's `4Modulen\".`3",$info1,$info3); break;
					 case 9: output("die Beschwerde �ber das Essen in der Burgschenke.`3"); break;
					case 10: output("st�ndiges, nerviges Fragen nach Adminrechten auf dem Server.`3"); break;
					case 11: output("die 17182zigste Petition ohne Sinn und ohne Ziel.`3"); break;
					case 12: output("das Lachen �ber den Coder dieses Moduls, weil die SQL-Datenabfrage zum x-ten Mal nicht funktionierte."); break;
					case 13: output("eigentlich gar nichts. Reine Willk�r der Admins."); break;
					case 14: output("das Zerst�ren der Trainingsger�te in \"`5Tynan's Trainingslager\".`3"); break;
					case 15: output("seine Dummheit, einen Admincharakter im PVP anzugreifen.`3"); break;
				
				}
				output("`c`n`n`3Du entschlie�t Dich, den armen Tropf abzuschneiden und ihm ein ordentliches Begr�bnis zu spendieren");
				$zuffi=e_rand(1,10);
					switch ($zuffi) {
						
						case 1:
						case 2:
						case 3:
							output("`3.`n`n`2 Nachdem Du den Strick mit Deiner Waffe durchtrennt hast, nimmst Du den Leichnam �ber die Schulter und gehst");
							output("`2zum nahegelegenen Friedhof. Dort schaufelst Du ihm ein Grab und setzt die Leiche w�rdig bei.`n`n");
							output("`2Anschie�end sprichst Du noch ein stilles Gebet und gehst wieder zum Richtplatz zur�ck.`n");
							$ramius=e_rand(1,3);
								switch ($ramius) {
									
									case 1:
									case 2:
										output("`4Als `\$Ramius `4von Deiner Tat erf�hrt, ist sie nicht sonderlich begeistert. Sie �rgert sich ma�los �ber Deine");
										output("`4Unverfrorenheit diese Seele in der Erde zu bestatten, statt sie ihr zu �berlassen.");
										output("`4Aus Wut straft sie Dich um 15 Gefallen!`n");
										$session['user']['deathpower']-=15;
										if ($session['user']['deathpower']<0) $session['user']['deathpower']=0;
										if ($alignja) {
											output("`2Deine gute Tat kommt daf�r jedoch beim Volk gut an. Du steigst in seinem Ansehen.");
											align(+2);
										} 
										else {
											output("`2Die Damen der Stadt sind von Deinem Handeln begeistert. Du gewinnst `52 Charmepunkte`2.");
											$session['user']['charm']+=2;
										}
									break;
									
									case 3:
										output("`4Als die B�rger der Stadt erfahren, welch noble Tat Du begangen hast, jubeln sie Dir zu.");
										output("`4Sie tragen Dich auf H�nden und feiern Dich wie einen Helden, der den `@gr�nen Drachen `4besiegt hat.`n");
										if ($alignja) {
											output("`2Deine gute Tat kommt beim Volke so gut an, dass Du erheblich in seinem Ansehen steigst.");
											align(+5);
										}
										else {
											output("`2Die Damen der Stadt sind von Deinem Handeln begeistert. Du gewinnst `53 Charmepunkte`2.");
											$session['user']['charm']+=3;
										}
									break;
								}
						break;								
						
						case 4:
						case 5:
							output("`3und nimmst Deine Waffe zum Durchtrennen des Strickes. Doch dieser erweist sich als haltbarer, als Du dachtest.`n");
							output("`2Pl�tzlich rutschtst Du ab und schneidest Dir tief ins Gesicht.`n");
							output("`4Abgesehen von Deinen Verletzungen hast Du dummerweise auch `52 Charmepunkte `4eingeb��t.");
							$session['user']['charm']-=2;
							if ($session['user']['charm']<0) $session['user']['charm']=0;
							$session['user']['hitpoints']*=0.3;
						break;
						
						case 6:
						case 7:
							output("`3.`n`n`2 Nachdem Du den Strick mit Deiner Waffe durchtrennt hast, nimmst Du den Leichnam �ber die Schulter und gehst");
							output("`2zum nahegelegenen Friedhof. Dort schaufelst Du ihm ein Grab und setzt die Leiche w�rdig bei.`n`n");
							output("`4Als Du Dich dann Deinem stillen Gebet f�r den armen Kerl zuwenden willst, siehst Du pl�tzlich eine Prozession von");
							output("`4B�rgern aus den Burgtoren herannahen, die sich allesamt anschlie�end um das Grab versammeln. Gemeinsam mit dem Pastor,");
							output("`4dem Scheriff und dem B�rgermeister der Stadt h�ltst Du ein feierliches Begr�bniszeremoniell ab. In Mitten des Gebetes");
							output("`4tritt dann pl�tzlich eine alte Frau schluchtzend aus der Menge hervor, kniet am Grab nieder und weint bitterlich.");
							output("`4Wie es sich herausstellt, ist die alte Frau die Mutter des Toten. Da dieser keine weitere Familie hatte und sowohl");
							output("`4sie selbst als auch er selbst recht wohlhabend waren, �berl��t sie Dir gro�z�gig den Inhalt seines Bankkontos.`n");
							$bankkonto=$session['user']['level']*1000;
							$session['user']['goldinbank']+=$bankkonto;
							output("`2Der Betrag von `^%s Goldst�cken `2wurde von der Bank bereits auf Dein Konto umgebucht!",$bankkonto);
							addnews("`2%s `3hat heute f�r seine noble Tat `^%s Goldst�cke `3geerbt.",$session['user']['name'],$bankkonto);
						break;
						
						case 8:
						case 9:
							output("`3.`n`n`2 Nachdem Du den Strick mit Deiner Waffe durchtrennt hast, nimmst Du den Leichnam �ber die Schulter und gehst");
							output("`2zum nahegelegenen Friedhof. Doch auf Deinem Wege dorthin kommen pl�tzlich Schw�rme von Geiern, die �ber das tote");
							output("`2Fleisch herfallen.`n`n`4Nat�rlich gelingt es den wenigsten Schn�beln nur das tote Fleisch zu treffen, so dass");
							output("`4auch Dein K�rper nicht \"ungeschn�belt\" bleibt. Du l�sst die Leiche fallen, die sodann von den Aasgeiern in Fetzen");
							$zuffi1=e_rand(1,3);
							switch ($zuffi1) {
								
								case 1:
								case 2:
									output("`4gerissen wird. Gl�cklicherweise wurdest Du nur verletzt und nicht auch noch zum Futter der Tiere!");
									$session['user']['hitpoints']*=0.3;
								break;
								
								case 3:
									output("`4gerissen wird. Doch leider haben sie sich auch an lebendiges Fleisch gew�hnt und zerhacken auch Dich in kleine St�cke.`n");
									output("`n`4Du bist TOT! Du verlierst Dein Gold und 10 Prozent Deiner Erfahrung. Deine Seele wandert in die Unterwelt.");
									addnews("`2%s `4wurde heute von Aasgeiern bei lebendigem Leibe gefressen.",$session['user']['name']);
									$session['user']['alive']=false;
									$session['user']['hitpoints']=0;
									$session['user']['gold']=0;
									addnav("Neuigkeiten");
									addnav("T�gliche News","news.php");
									page_footer();
								break;
							}
						break;
						
						case 10:							
							output("`3.`n`n`2 Nachdem Du den Strick mit Deiner Waffe durchtrennt hast, nimmst Du den Leichnam �ber die Schulter und gehst");
							output("`2zum nahegelegenen Friedhof. Dort schaufelst Du ihm ein Grab und setzt die Leiche w�rdig bei.`n`n");
							output("`2Pl�tzlich erscheint ein `6Engel `2aus den Wolken des Himmels und ein `6glei�endes Licht `2f�llt auf Dich herab.");
							output("`1\"Seht her mein Sohn, Ihr habt wohl getan, mit Eurem Handeln. Die G�tter sind Euch g�nstig gestimmt. Euch soll");
							output("`1heute die g�ttliche Kraft zu Teil werden, die selten ein Sterblicher erfahren darf.\" `2Mit diesen Worten verschwindet");
							output("`2der Engel wieder in den Wolken und das Licht erlischt.`n`n");
							if($session['user']['level']<15 || $hatengel==false) {
								if ($session['user']['experience']>$benoetigt) $benoetigt=$session['user']['experience'];
								output("`4Du f�hlst Dich `6enorm befl�gelt`4 und gewinnst `6EINEN LEVEL`4!!!`n`n");
								$session['user']['level']+=1;
								$session['user']['experience']=$benoetigt;
								$session['user']['attack']+=1;
								$session['user']['defense']+=1;
								require_once("lib/increment_specialty.php");
								increment_specialty("`Q");
								addnews("`5%s `!erschien heute ein Engel und bef�rderte %s zu `4Level %s.",$session['user']['name'],translate_inline($session['user']['sex']?"sie":"ihn"),$session['user']['level']);
							}
							else {
								output("`4Du f�hlst Dich `6enorm befl�gelt`4 und um Deine Ausr�stung herum glei�t das Licht weiter!!!`n`n");
								output("`6Deine R�stung und Deine Waffe haben einen enormen St�rkeschub erhalten");
								$session['user']['attack']+=5;
								$session['user']['defense']+=5;
							}
						break;
					}
			}
		
			set_module_pref("besuchgalgen",get_module_pref("besuchgalgen")+1);
		}
			if ($besuchgalgen>=3) output("`3.`n`n`6Du hast f�r heute genug von den Schreckensbildern und kehrst zum Richtplatz zur�ck.");
			addnav("Zur�ck");
			addnav("`4Zur�ck zum Richtplatz`0","runmodule.php?module=richtplatz");
		page_footer;
		
?>