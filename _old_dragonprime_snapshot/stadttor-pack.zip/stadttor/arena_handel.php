<?php

output("`6\"Nun denn, so soll es sein. Ich werde Dir Deine Arenapunkte eintauschen.\"`n`n");

if ($op2=="gold") {
	if ($arenapunkte>=$goldkost) {
		output("`3Mit diesen Worten greift `4%s `3in eine Schublade an seinem Tisch und nimmt `^einen Beutel Gold `3daraus hervor.`n`n",$henkername);
		output("`2Du erh�ltst im Austausch f�r `3%s `4%s `3%s `2den Betrag von `^%s Goldst�cken`2!`n`n",translate_inline($goldkost?"Deine":"Deinen"),$goldkost,translate_inline($goldkost?"Arenapunkte":"Arenapunkt"),$goldangebot);
		$session['user']['gold']+=$goldangebot;
		$arenapunkteneu=$arenapunkte-$goldkost;
		set_module_pref("battlepoints",$arenapunkteneu,"battlearena");
	} else {
		$op2="zuwenig";
	}
}

if ($op2=="edelsteine") {
	if ($arenapunkte>=$edelsteinkost) {
		output("`3Mit diesen Worten greift `4%s `3in eine Schublade an seinem Tisch und nimmt `5einen Edelstein `3daraus hervor.`n`n",$henkername);
		output("`2Du erh�ltst im Austausch f�r `3%s `4%s `3%s `2einen `5Edelstein`2!`n`n",translate_inline($edelsteinkost?"Deine":"Deinen"),$edelsteinkost,translate_inline($edelsteinkost?"Arenapunkte":"Arenapunkt"));
		$session['user']['gems']++;
		$arenapunkteneu=$arenapunkte-$edelsteinkost;
		set_module_pref("battlepoints",$arenapunkteneu,"battlearena");
	} 
	else $op2="zuwenig";
}

if ($op2=="erfahrung") {
	if ($arenapunkte>=$edelsteinkost) {
		output("`3Mit diesen Worten greift `4%s `3in eine Schublade an seinem Tisch und nimmt `Qeinen magischen Trank `3daraus hervor.`n`n",$henkername);
		output("`2Du erh�ltst im Austausch f�r `3%s `4%s `3%s `2%s Erfahrungspunkte`2!`n`n",translate_inline($erfahrungskost?"Deine":"Deinen"),$erfahrungskost,translate_inline($erfahrungskost?"Arenapunkte":"Arenapunkt"),$erfahrung);
		$session['user']['experience']+=$erfahrung;
		$arenapunkteneu=$arenapunkte-$erfahrungskost;
		set_module_pref("battlepoints",$arenapunkteneu,"battlearena");
	} 
	else $op2="zuwenig";
}
	
if ($op2=="bwaffe") {
 $max="SELECT damage FROM " . db_prefix("weapons") . " WHERE level>=0 ORDER BY damage DESC LIMIT 0,1";
 $ergebnis=db_query($max);
 $maximum=db_fetch_assoc($ergebnis);
 $maxlist=$maximum['damage'];
 if ($session['user']['armordef']>$maxlist) {
  if ($session['user']['weapondmg']<$maxlist) {
   if ($session['user']['weapondmg']!=0) {
	if ($arenapunkte>=$waffenkost) {
		$max="SELECT level FROM " . db_prefix("weapons") . " WHERE damage>0 ORDER BY level DESC LIMIT 0,1";
		$ergebnis=db_query($max);
		$maximum=db_fetch_assoc($ergebnis);
		$maxlist=$maximum['level'];
		$waffe="SELECT * FROM " . db_prefix("weapons") . " WHERE level=$maxlist AND damage=".($session['user']['weapondmg']+1)." ORDER BY weaponid DESC LIMIT 0,1";
		$ergebnis=db_query($waffe);
		$waffeneu=db_fetch_assoc($ergebnis);
		if (get_module_pref("weaponname","customeq")=="") $session['user']['weapon']=$waffeneu['weaponname'];
		else $waffadverb=translate_inline("`4(verbessert)");
		$session['user']['weapondmg']=$waffeneu['damage'];
		$session['user']['weaponvalue']=$waffeneu['value'];
		$session['user']['attack']+=1;
		output("`3Mit diesen Worten greift `4%s `3in eine Schublade an seinem Tisch und nimmt `\$%s%s `3daraus hervor.`n`n",$henkername,$session['user']['weapon'],$waffadverb);
		if (get_module_pref("weaponname","customeq")=="") output("`2Du erh�ltst im Austausch f�r `3%s `4%s `3%s `2eine `\$bessere Waffe`2!`n`n",translate_inline($waffenkost?"Deine":"Deinen"),$waffenkost,translate_inline($waffenkost?"Arenapunkte":"Arenapunkt"));
		else output("`2Deine Waffe `5\"%s\" `2wurde um `4einen Level `2verbessert.`n`n",$session['user']['weapon']);
		$arenapunkteneu=$arenapunkte-$waffenkost;
		set_module_pref("battlepoints",$arenapunkteneu,"battlearena");
	}
	else $op2="zuwenig";
   }
   else {
   	output("`6\"Moment mal ... Du tr�gst ja gar keine Waffe ... Deine blo�en H�nde kann ich schlecht verbessern. Lege Dir erst einmal eine Waffe zu!\"`n`n");
   	addnav("Zur�ck");
	addnav("`QZur�ck zur Henkerstube`0","runmodule.php?module=henkerstube");
	addnav("`4Zur�ck zum Richtplatz`0","runmodule.php?module=richtplatz");
   	page_footer();
   }
  } 
  else {
  	output("`6\"Deine Waffe ist die beste, bekannte Waffe die Deiner St�rke w�rdig ist. Ich kann Dir keine Bessere anbieten. Ich werde Dir daf�r aber Deine");
  	output("`6Angriffsf�higkeit um `42 `6Punkte erh�hen!\"`n`n");
  	$session['user']['attack']+=2;
  	$arenapunkteneu=$arenapunkte-$waffenkost;
	set_module_pref("battlepoints",$arenapunkteneu,"battlearena");
  }
 }else {
   	output("`6\"Es tut mir leid, aber Du tr�gst die beste Waffe des gesamten Landes. Ich kann nichts mehr f�r Dich tun!\"`n`n");
   	addnav("Zur�ck");
	addnav("`QZur�ck zur Henkerstube`0","runmodule.php?module=henkerstube");
	addnav("`4Zur�ck zum Richtplatz`0","runmodule.php?module=richtplatz");
   	page_footer();
 }
} 

if ($op2=="bruestung") {
 $max="SELECT defense FROM " . db_prefix("armor") . " WHERE level>=0 ORDER BY defense DESC LIMIT 0,1";
 $ergebnis=db_query($max);
 $maximum=db_fetch_assoc($ergebnis);
 $maxlist=$maximum['defense'];
 if ($session['user']['armordef']>$maxlist) {
  if ($session['user']['armordef']<$maxlist) {
   if ($session['user']['armordef']!=0) {
	if ($arenapunkte>=$ruestkost) {
		$max="SELECT level FROM " . db_prefix("armor") . " WHERE defense>0 ORDER BY level DESC LIMIT 0,1";
		$ergebnis=db_query($max);
		$maximum=db_fetch_assoc($ergebnis);
		$maxlist=$maximum['level'];
		$ruestung="SELECT * FROM " . db_prefix("armor") . " WHERE level=$maxlist AND defense=".($session['user']['armordef']+1)." ORDER BY armorid DESC LIMIT 0,1";
		$ergebnis=db_query($ruestung);
		$ruestneu=db_fetch_assoc($ergebnis);
		if (get_module_pref("armorname","customeq")=="") $session['user']['armor']=$ruestneu['armorname'];
		else $ruestadverb=translate_inline("`4(verbessert)");
		$session['user']['armordef']=$ruestneu['defense'];
		$session['user']['armorvalue']=$ruestneu['value'];
		$session['user']['defense']+=1;
		output("`3Mit diesen Worten greift `4%s `3in eine Schublade an seinem Tisch und nimmt `\$%s%s `3daraus hervor.`n`n",$henkername,$session['user']['armor'],$ruestadverb);
		if (get_module_pref("armorname","customeq")=="") output("`2Du erh�ltst im Austausch f�r `3%s `4%s `3%s `2eine `\$bessere R�stung`2!`n`n",translate_inline($ruestkost?"Deine":"Deinen"),$ruestkost,translate_inline($ruestkost?"Arenapunkte":"Arenapunkt"));
		else output("`2Deine R�stung `5\"%s\" `2wurde um `4einen Level `2verbessert.`n`n",$session['user']['armor']);
		$arenapunkteneu=$arenapunkte-$ruestkost;
		set_module_pref("battlepoints",$arenapunkteneu,"battlearena");
	}
	else $op2="zuwenig";
   }
   else {
   	output("`6\"Moment mal ... Du tr�gst ja gar keine R�stung ... Deine blo�e Kleidung kann ich schlecht verbessern. Lege Dir erst einmal eine R�stung zu!\"`n`n");
   	addnav("Zur�ck");
	addnav("`QZur�ck zur Henkerstube`0","runmodule.php?module=henkerstube");
	addnav("`4Zur�ck zum Richtplatz`0","runmodule.php?module=richtplatz");
   	page_footer();
   }
  } 
  else {
  	output("`6\"Deine R�stung ist die beste, bekannte R�stung die Deiner St�rke w�rdig ist. Ich kann Dir keine Bessere anbieten. Ich werde Dir daf�r aber Deine");
  	output("`6Verteidigungsf�higkeit um `42 `6Punkte erh�hen!\"`n`n");
  	$session['user']['defense']+=2;
  	$arenapunkteneu=$arenapunkte-$ruestkost;
	set_module_pref("battlepoints",$arenapunkteneu,"battlearena");
  }
 }else {
   	output("`6\"Es tut mir leid, aber Du tr�gst die beste R�stung des gesamten Landes. Ich kann nichts mehr f�r Dich tun!\"`n`n");
   	addnav("Zur�ck");
	addnav("`QZur�ck zur Henkerstube`0","runmodule.php?module=henkerstube");
	addnav("`4Zur�ck zum Richtplatz`0","runmodule.php?module=richtplatz");
   	page_footer();
 }
} 

if ($op2=="zuwenig") {
	output("`3Doch noch bevor er sich zu seinem Tisch bewegt um den Handel abzuschlie�en, h�lt er inne.`n`n`6\"Moment einmal ... Du hast ja gar nicht");
	output("`6gen�gend Arenapunkte ... Du verschwendest nur meine Zeit ... ");
	output("`6Ich habe das Gef�hl, Du willst mich hier zum Narren halten! Ich werde Dir eine Lektion verpassen, die Du nie vergessen wirst!\"`n`n");
		$zuffi=e_rand(1,5);
		switch ($zuffi) {
			case 1: case 2: case 3:
				output("`3Schnell nimmst Du die Beine unter den Arm und rennst, am Henker vorbei, aus seinem Quartier. Wutschnaubend h�rst Du `4%s",$henkername);
				output("`3noch eine Weile hinter Dir herfluchen, doch Du wei�t, dass er die Angelegenheit schon bald vergessen haben wird.`n`n");
				output("`@Das ist ja gl�cklicherweise nochmal gut gegangen!");
				addnav("Zur�ck");
				addnav("`4Zur�ck zum Richtplatz`0","runmodule.php?module=richtplatz");
			break;
				
			case 4:
				output("`2Mit diesen Worten schwingt er seine Axt und zieht Dich am Kragen zum Kampf hinaus auf den Richtplatz.`n`n");
				addnav("Der Kampf");
				addnav("Gib Dein Bestes","runmodule.php?module=henkerstube&op=fighting");
			break;	
				
			case 5:
				output("`2Mit diesen Worten ergreift Dich der Henker und, bevor Du die Chance hast Dich zu wehren, hat er Dich auch unter dem Jubeln und");
				output("`2Johlen des Volkes am Galgen auf dem Richtplatz aufgekn�pft.`n`n");
				output("`4Du bist TOT, stranguliert durch den Strick und gefressen von den wartenden Aasgeiern.`n");
				output("`4Du verlierst all Dein Gold, welches der Henker nun als seine \"Vermittlungsgeb�hr\" betrachtet.`n");
				output("`4Doch die Erfahrung, dass man einen Henker nicht �rgern soll, gleicht jeglichen anderen Erfahrungsverlust aus.");
				addnews("`2%s `4hat heute den Henker ver�rgert und starb daf�r den Tod am Galgen.",$session['user']['name']);
				set_module_setting("gspieler",$session['user']['name']);
				$session['user']['alive']=false;
				$session['user']['gold']=0;
				$session['user']['hitpoints']=0;
				addnav("Neuigkeiten");
				addnav("T�gliche News","news.php");
			break;
		}
	page_footer();				
}

output("`6\"Ich werde den Gladiatoren und F�hrern der Arena von unserem Handel berichten. Sie werden Euch die entprechenden Arenapunkte");
output("`6abziehen und dies in ihrer Statisktik vermerken. Denkt daran neue Punkte zu sammeln und falls ihr der Arenachampion wart, wundert Euch nicht,");
output("`6wenn Euch nun ein Anderer vielleicht dadurch �berholt hat.\"`6");
addnav("Zur�ck");
addnav("`QZur�ck zur Henkerstube`0","runmodule.php?module=henkerstube");
addnav("`4Zur�ck zum Richtplatz`0","runmodule.php?module=richtplatz");

?>