<?php

	output("`c`b`4Das Stadttor`b`c`n");
		output("`3Du kommst zu einem grossen Stadttor, das an seinen Seiten je einen Turm hat, von dem aus die Umgebung beobachtet werden kann.");
		if ($session['user']['location'] == getsetting("villagename", LOCATION_FIELDS)) {
		output("`3Innerhalb des Tores liegt `^%s`3, die Hauptstadt des Reiches. Du kannst Menschen erkennen, die gesch�ftig umher laufen, aus einigen Schornsteinen steigt Rauch empor und der Geruch von Essen und Stadt erreicht Deine Nase.",getsetting("villagename", LOCATION_FIELDS));
		}
		else {
		output("`3Innerhalb des Tores liegt `^%s`3. Du kannst Kreaturen erkennen, die gesch�ftig umher laufen, aus einigen Schornsteinen steigt Rauch empor und der Geruch von Essen und Stadt erreicht Deine Nase.`n",$session['user']['location']);
		}
		modulehook("stadttor_beschreibung");
		output("`3Eine breite, gut ausgebaute Strasse f�hrt weiter in andere St�dte.`n");
		output("`3Au�erhalb der Stadtmauer haben Abenteurer und K�mpfer ein Lager errichtet und ihre Zelte aufgeschlagen.`n");
		output("`3Rechts und Links des Tores stehen, jeweils innen und aussen, je 2 m�chtige Trollkrieger, die die Uniform der Stadtwache tragen, welche vom Sheriff befehligt wird, und beobachten jeden, egal ob er die Stadt betritt oder verl��t.`n`n");
		if ($bounty>$kopfgeld) {
			output("`3Du gehst durch das Tor");
			if (is_module_active("jail")) $rand=24; 
			else $rand=22;
				switch(e_rand(1,$rand)){
					case 1:
					case 2:
					case 3:
					case 4:
					case 5:
					case 6:
					case 7:
					case 8:
					case 9:
					case 10:
					case 11:
					case 12:
					case 13:
	   				case 14:
	   				output("`3und nickst den Stadtwachen freundlich zu, aber sie ignorieren Dein L�cheln und betrachten Dich ganz genau.");
	   				output("`3Bevor sie Dich noch erkennen legst Du unauf�llig einen Schritt zu und passierst das Tor.`n");
	   				output("`@Puh, das ist noch mal gut gegangen!.");
					addnav("In der Stadtmauer");
					addnav("`QZum Stadtzentrum`0","village.php");
					if (is_module_active('worldmapen')) addnav("Reisen","runmodule.php?module=worldmapen&op=beginjourney");
					else addnav("Reisen","runmodule.php?module=cities&op=travel");
					modulehook("stadttor");
					addnav("Vor dem Stadttor");
					$session['user']['specialinc']="";
					$session['user']['specialmisc']="";
					addnav("Zu den Feldern","runmodule.php?module=stadttor&op=felder");
					if ($session['user']['location'] != getsetting("villagename", LOCATION_FIELDS) && $session['user']['location'] != get_module_setting("villagename","ghosttown") && $session['user']['location'] != get_module_setting("villagename","icetown")) addnav("In den Wald","forest.php");
	   				break;
	   				case 15:
	   				case 16:
					case 17:
					case 18:
	   				output("`3und nickst der Stadtwache freundlich zu, aber die ignorieren Dein L�cheln und betrachten Dich ganz genau.");
					output("`3Pl�tzlich ruft einer der Trolle:`4\"Hey, Dich kenne ich doch, auf Dich ist ein Kopfgeld ausgesetzt!\"`3, st�rmt auf Dich zu und h�lt Dich am Arm.");
	   				output("`3Du windest Dich aus seinem Griff, wobei Du Dich verletzt, nimmst dann die Beine in die Hand und l�ufst. Noch bevor die anderen Trolle reagieren k�nnen, bist Du schon in den Menschenmassen untergetaucht.");
					$session['user']['hitpoints']*=0.9;
					addnews("`2%s `4wurde verletzt, als %s sich der Verhaftung durch die Stadtwache entzog.",$session['user']['name'],translate_inline($session['user']['sex']?"sie":"er"));
					addnav("In der Stadtmauer");
					addnav("`QZur�ck in die Stadt`0","village.php");
					if (is_module_active('worldmapen')) addnav("Reisen","runmodule.php?module=worldmapen&op=beginjourney");
					else addnav("Reisen","runmodule.php?module=cities&op=travel");
					modulehook("stadttor");
					addnav("Vor dem Stadttor");
					$session['user']['specialinc']="";
					$session['user']['specialmisc']="";
					addnav("Zu den Feldern","runmodule.php?module=stadttor&op=felder");
					if ($session['user']['location'] != getsetting("villagename", LOCATION_FIELDS) && $session['user']['location'] != get_module_setting("villagename","ghosttown") && $session['user']['location'] != get_module_setting("villagename","icetown")) addnav("In den Wald","forest.php");
					break;
					case 19:
					case 20: 
	   				output("`3und nickst der Stadtwache freundlich zu, aber die ignorieren Dein L�cheln und betrachten Dich ganz genau.");
					output("`3Pl�tzlich ruft einer der Trolle:`4\"Hey, Dich kenne ich doch, auf Dich ist ein Kopfgeld ausgesetzt!\"`3, st�rmt auf Dich zu und h�lt Dich am Arm.");
	   				output("`3Du windest Dich aus seinem Griff und rennst los, doch die Trolle haben bereits zu ihren Bogen gegrifen und spiken Dich mit Pfeilen.");
		output("`3Das Letzte, was Du noch h�rst, ist das Lachen der Trolle, die sich auf das `6Kopfgeld`3 freuen.");
					$session['user']['alive']=false;
					$session['user']['deathpower']+=15;
					$session['user']['hitpoints']=0;
					$session['user']['gold']=0;
					$session['user']['experience']*0.97;
					addnews("`2%s `4starb bei dem Versuch, der Verhaftung durch die Stadtwache zu entkommen.`nDie Stadtwache hat nat�rlich auch die `6%s`4 Goldst�cke Kopfgeld kassiert.",$session['user']['name'],$bounty);
					$sql = "UPDATE ". db_prefix("bounty") ." SET status=1 WHERE target=".$session['user']['acctid'];
					db_query($sql);
					addnav("T�gliche News","news.php");
					break;
					case 21:
					case 22:
	   				output("`3und nickst der Stadtwache freundlich zu, aber die ignorieren Dein L�cheln und betrachten Dich ganz genau.");
					output("`3Pl�tzlich ruft einer der Trolle:`4\"Hey, Dich kenne ich doch, auf Dich ist ein Kopfgeld ausgesetzt!\"`3, st�rmt auf Dich zu und h�lt Dich am Arm.");
	   				output("`3Du windest Dich aus seinem Griff, nimmst dann die Beine in die Hand und l�ufst los so schnell Du kannst.");
	   				output("`3Schnell biegst Du um eine Ecke, blickst vorsichtig zur�ck und kannst keinen der Trolle mehr sehen.");
	   				output("`3Du atmest tief aus, wischst den Schwei� von der Stirn, drehst Dich rum und willst gehen, als Du Dich pl�tzlich dem Kommandanten der Torwache gegen�ber siehst, der mit gez�ckter Waffe vor Dir steht.");
					addnav("K�mpfe","runmodule.php?module=stadttor&op=fighting");
					break; 
					case 23:
					case 24:
					$sname=(get_module_setting("sheriffname","jail"));
					output("`3, doch pl�tzlich steht `4%s `3vor Dir. Du blickst in seine Augen, die Dir verraten, dass eine Flucht sinnlos w�re",$sname);
					output("und Dich lediglich Dein Leben kosten w�rde. Mit gesenktem Kopf und niedergeschlagenen Schritten folgst Du `4%s `3ins `\$Gef�ngnis`3,",$sname);
					output("wo Du wohl die n�chste Zeit verbringen wirst. Das Positive daran ist lediglich, dass nun kein Kopfgeld mehr auf Dich ausgesetzt ist.");
					set_module_pref("wantedlevel",0,"jail");
					set_module_pref("injail",1,"jail");
					set_module_pref("village",$session['user']['location'],"jail");
					addnews("`4%s `2wurde von `4Scheriff %s`2 am Stadttor verhaftet und ins Gef�ngnis gesteckt.`nDie `6%s Goldst�cke Kopfgeld `2erh�lt die Staatskasse.",$session['user']['name'],$sname,$bounty);
					$sql = "UPDATE ". db_prefix("bounty") ." SET status=1 WHERE target=".$session['user']['acctid'];
					db_query($sql);
					addnav("Weiter");
					addnav("Ab ins Gef�ngis","runmodule.php?module=jail");
					break;
				}
		}else{
			output("`3Du gehst durch das Tor und nickst der Stadtwache freundlich zu, diese erwiedern Dein Nicken und widmen sich dann wieder, unverz�glich, der Kontrolle des Stadtzugangs.");
			addnav("In der Stadtmauer");
			addnav("`QZur�ck in die Stadt`0","village.php");
			if (is_module_active('worldmapen')) addnav("Reisen","runmodule.php?module=worldmapen&op=beginjourney");
			else addnav("Reisen","runmodule.php?module=cities&op=travel");
			modulehook("stadttor");
			addnav("Vor dem Stadttor");
			$session['user']['specialinc']="";
			$session['user']['specialmisc']="";
			addnav("Zu den Feldern","runmodule.php?module=stadttor&op=felder");
			if ($session['user']['location'] != getsetting("villagename", LOCATION_FIELDS) && $session['user']['location'] != get_module_setting("villagename","ghosttown") && $session['user']['location'] != get_module_setting("villagename","icetown")) addnav("In den Wald","forest.php");
		}
		
?>