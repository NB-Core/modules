<?php

	output("\"`6Wie ??? Du wagst es ??? Du kommst her, beanspruchst meine Zeit, l�sst mich hier rechnen und bist dann nicht gewillt oder in der Lage zu zahlen ???");
	output("`6Ich habe das Gef�hl, Du willst mich hier zum Narren halten! Ich werde Dir eine Lektion verpassen, die Du nie vergessen wirst!\"`n`n");
		$zuffi=e_rand(1,5);
		switch ($zuffi) {
			case 1: case 2: case 3:
				output("`3Schnell nimmst Du die Beine unter den Arm und rennst, am Henker vorbei, aus seinem Quartier. Wutschnaubend h�rst Du `4%s",$henkername);
				output("`3noch eine Weile hinter Dir herfluchen, doch Du wei�t, dass er die Angelegenheit schon bald vergessen haben wird.`n`n");
				output("`@Das ist ja gl�cklicherweise nochmal gut gegangen!");
				addnav("Zur�ck");
				addnav("`4Zur�ck zum Richtplatz`0","runmodule.php?module=richtplatz");
			break;
				
			case 4:
				output("`2Mit diesen Worten schwingt er seine Axt und zieht Dich am Kragen zum Kampf hinaus auf den Richtplatz.`n`n");
				addnav("Der Kampf");
				addnav("Gib Dein Bestes","runmodule.php?module=henkerstube&op=fighting");
			break;	
				
			case 5:
				output("`2Mit diesen Worten ergreift Dich der Henker und, bevor Du die Chance hast Dich zu wehren, hat er Dich auch unter dem Jubeln und");
				output("`2Johlen des Volkes am Galgen auf dem Richtplatz aufgekn�pft.`n`n");
				output("`4Du bist TOT, stranguliert durch den Strick und gefressen von den wartenden Aasgeiern.`n");
				output("`4Du verlierst all Dein Gold, welches der Henker nun als seine \"Vermittlungsgeb�hr\" betrachtet.`n");
				output("`4Doch die Erfahrung, dass man einen Henker nicht �rgern soll, gleicht jeglichen anderen Erfahrungsverlust aus.");
				addnews("`2%s `4hat heute den Henker ver�rgert und starb daf�r den Tod am Galgen.",$session['user']['name']);
				set_module_setting("gspieler",$session['user']['name']);
				$session['user']['alive']=false;
				$session['user']['gold']=0;
				$session['user']['hitpoints']=0;
				addnav("Neuigkeiten");
				addnav("T�gliche News","news.php");
			break;				
		}

?>