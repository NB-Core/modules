<?php

		$hgebuehr=get_module_setting("henkergebuehr");
		$sgebuehr=get_module_setting("scheriffgebuehr");
		output("`3Du erinnerst Dich daran, dass `4%s `3ein guter Freund des �rtlichen Scherriffs ist.`n`n",$henkername);
		output("`4\"Ich m�chte gerne das Kopfgeld loswerden, das auf meinen Kopf ausgesetzt ist\"`2 antwortest Du dem Henker.`n`n");
		if ($bounty>0) {
			output("`6\"Soso, Dein Kopfgeld macht Dir also Sorgen? Na denn wollen wir doch mal sehen, was ich f�r Dich tun kann. Mal schauen, Dein aktuelles");
			output("`6Kopfgeld betr�gt `5%s `6Goldm�nzen. Weil ich den �rtlichen Scherriff so gut kenne, kann ich Dir helfen. Ich bin von ihm befugt, f�r einen",$bounty); 
			output("`6kleinen Zuschlag versteht sich, Kopfgelder einzukassieren und Dich somit von der schwarzen Liste entfernen zu lassen.`n");
			output("`6Dann lass uns mal rechnen: Ich bekomme `2%s Prozent `6als Vermittlergeb�hr und der Scherriff erh�lt `2%s Prozent `6als Provision.",$hgebuehr,$sgebuehr);
			output("`6Somit k�men wir dann, Alles in Allem auf ...\"`n`n`2Mit diesen Worten nimmt er sich ein St�ck Pergament vom Tisch, stellt seine Axt");
			output("`2in die Ecke des Raums und nimmt sich Tintenfa� und Feder. Dann beginnt er auf dem Pergament zu schreiben und h�lt es Dir schlie�lich");
			output("`2unter die Nase.`n`n");
			$vermittlung=round(($bounty/100)*$hgebuehr);
			$provision=round(($bounty/100)*$sgebuehr);
			$rsumme=$bounty+$vermittlung+$provision;
			output("<big><big>`c`4- - - Rechnung - - -</big></big>`n",true);
			output("`n`^Dein momentanes Kopfgeld : %s Goldst�cke",$bounty);
			output("`n`^Meine Vermittlungsgeb�hr : %s Goldst�cke",$vermittlung);
			output("`n`^Provision f�r den Scheriff : %s Goldst�cke",$provision);
			output("`n`^=================================================");
			output("`n`^Zu zahlende Rechnungsumme: %s Goldst�cke",$rsumme);
			output("`n`n`c`6\"Bist Du bereit, diesen Betrag zu bezahlen?");
			set_module_pref("rbetrag",$rsumme);
			addnav("Rechnung zahlen");
			addnav("Ja","runmodule.php?module=henkerstube&op=rechja");
			addnav("Nein","runmodule.php?module=henkerstube&op=rechnein");
			page_footer();
		} else {
			output("`4%s `2schnaut in seinem gro�en Buch nach, in dem alle aktuellen Kopfgelder des Landes verzeichnet sind. Nach mehrfachem Durchsuchen",$henkername);
			output("`2aller Eintr�ge dreht er sich w�tend um und schnauzt Dich an:`n`n");
			$zuffi=e_rand(1,10);
			switch ($zuffi) {
				
				case 1: case 2: case 3: case 4: case 5: case 6: case 7: case 8:
					output("`6\"Auf Deinen armseligen Kopf ist ja gar kein Kopfgeld ausgesetzt. Du verschwendest meine Zeit. Eigentlich sollte ich Dich daf�r");
					output("`6am Galgen baumeln lassen. Aber ich bin heute nicht in der Stimmung dazu. Verschwinde aus meinem Quartier.\"");
					addnav("Zur�ck");
					addnav("`4Zur�ck zum Richtplatz`0","runmodule.php?module=richtplatz");
				break;
				
				case 9: 
					output("`6\"Auf Deinen armseligen Kopf ist ja gar kein Kopfgeld ausgesetzt. Du verschwendest meine Zeit.");
					output("`6Daf�r werde ich Dich wohl t�ten m�ssen.\"");
					addnav("Der Kampf");
					addnav("Gib Dein Bestes","runmodule.php?module=henkerstube&op=fighting");
				break;
				
				case 10:
					output("`6\"Auf Deinen armseligen Kopf ist ja gar kein Kopfgeld ausgesetzt. Du verschwendest meine Zeit.");
					output("`6Daf�r sollst Du am Galgen baumeln!\"`n`n");
					output("`3Mit diesen Worten ergreift Dich der Henker und, bevor Du die Chance hast Dich zu wehren, hat er Dich auch unter dem Jubeln und");
					output("`3Johlen des Volkes am Galgen auf dem Richtplatz aufgekn�pft.`n`n");
					output("`4Du bist TOT, stranguliert durch den Strick und gefressen von den wartenden Aasgeiern.`n");
					output("`4Du verlierst all Dein Gold, welches der Henker nun als seine \"Vermittlungsgeb�hr\" betrachtet.`n");
					output("`4Doch die Erfahrung, dass man einen Henker nicht �rgern soll, gleicht jeglichen anderen Erfahrungsverlust aus.");
					addnews("`2%s `4hat heute den Henker ver�rgert und starb daf�r den Tod am Galgen.",$session['user']['name']);
					set_module_setting("gspieler",$session['user']['name']);
					$session['user']['alive']=false;
					$session['user']['gold']=0;
					$session['user']['hitpoints']=0;
					addnav("Neuigkeiten");
					addnav("T�gliche News","news.php");
				break;				
			}
		}

?> 