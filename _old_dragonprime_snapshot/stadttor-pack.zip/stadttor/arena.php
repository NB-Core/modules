<?php

		if ($arenapunkte>0) {
			if ($arenapunkte>11) $adverb=translate_inline("`4kl�glichen");
			if ($arenapunkte>35) $adverb=translate_inline("`4wenigen");
			if ($arenapunkte>71) $adverb=translate_inline("`4mageren");
			if ($arenapunkte>119) $adverb=translate_inline("`2inzwischen beachtlichen");
			if ($arenapunkte>179) $adverb=translate_inline("`2guten");
			if ($arenapunkte>251) $adverb=translate_inline("`2sehr guten");
			if ($arenapunkte>335) $adverb=translate_inline("`5hervorragenden");
			if ($arenapunkte>999) $adverb=translate_inline("`5�berragenden");
			if ($arenapunkte>1599) $adverb=translate_inline("`%nahezu g�ttlichen");
			output("`6\"Nun, wie ich sehe hast Du Dich bereits in der Arena bew�hrt und `3%s %s `6gesammelt. Deine `^%s `6Erfolge sind bis nach hier gedrungen.`n`n",$arenapunkte,translate_inline($arenapunkte?"Arenapunkte":"Arenapunkt"),$adverb);
			output("`6Daher biete ich Dir einen Tauschhandel an `&`i--- Arenapunkte gegen materielle Dinge und Zauber ---`i`6\".`n`n");
			output("`6\"Was m�chtest Du f�r Deine Arenapunkte haben?\"`n`n");
			output("<big><big>`c`4- - - T A U S C H W A R E N - - -</big></big>`n`n",true);
			output("`^%s Gold `2- f�r - `3%s Arenapunkte`n",$goldangebot,$goldkost);
			output("`51 Edelstein `2- f�r - `3%s Arenapunkte`n",$edelsteinkost);
			output("`Q%s Erfahrungspunkte `2- f�r - `3%s Arenapunkte`n",$erfahrung,$erfahrungskost);
			output("`\$Waffe verbessern `2- f�r - `3%s Arenapunkte`n",$waffenkost);
			output("`@R�stung verbessern `2- f�r - `3%s Arenapunkte`n`c",$ruestkost);
			addnav("Tauschwaren");
			addnav("Gold nat�rlich","runmodule.php?module=henkerstube&op=arena2&op2=gold");
			addnav("lieber Edelsteine","runmodule.php?module=henkerstube&op=arena2&op2=edelsteine");
			addnav("Erfahrungspunkte bitte","runmodule.php?module=henkerstube&op=arena2&op2=erfahrung");
			addnav("eine bessere Waffe","runmodule.php?module=henkerstube&op=arena2&op2=bwaffe");
			addnav("eine bessere R�stung","runmodule.php?module=henkerstube&op=arena2&op2=bruestung");
			addnav("Zur�ck");
			addnav("`qZur�ck zur Henkerstube`0","runmodule.php?module=henkerstube");
			addnav("`4Zur�ck zum Richtplatz`0","runmodule.php?module=richtplatz");
		} else {
			output("`6\"Nun, wie ich sehe hast Du Dich bislang noch nicht in der Arena bew�hrt. Deine `4sch�ndliche Feigheit `6ist sogar bis nach hier gedrungen.");
			output("`6Du siehst, Dein Ruf eilt Dir voraus.\"`n`n");
			output("`4Da Du bislang keine Arenapunkte gesammelt hast, wirst Du Dich wohl nach `2%s `4begeben und Dir dort erst einmal die Sporen verdienen m�ssen!",get_module_setting("arenaloc","battlearena"));
			addnav("Zur�ck");
			addnav("`qZur�ck zur Henkerstube`0","runmodule.php?module=henkerstube");
			addnav("`4Zur�ck zum Richtplatz`0","runmodule.php?module=richtplatz");
		}

?>