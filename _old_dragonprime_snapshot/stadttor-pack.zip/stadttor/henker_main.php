<?php

		output("<big><big>`c`4- - - Die Henkerstube - - -`c</big></big>`n`n",true);
		output("`3Du betrittst eine dunkle Kammer, die lediglich von Fackeln erhellt wird. Die kargen W�nde des Raumes erstrahlen im diffusen Licht der tanzenden");
		output("`3Flammen der einzelnen Fackeln. Der Feuerschein wirft die Gegenst�nde der Raumeinrichtung in verzerrten Schatten an die W�nde. Alles in Allem");
		output("`3ein recht ungem�tlicher Platz um sich aufzuhalten.`n`n");
		if ($henkerkampf==0) {
		output("`3Doch, noch bevor Du ausgiebig dar�ber nachgedacht hast, ob Du den Raum nicht lieber schnell wieder verlassen solltest, sp�rst Du den");
		output("`3kalten Stahl einer gro�en Zweih�nderaxt in Deinem Genick.");
		output("`3Du erstarrst vor Schreck und bist unf�hig auch nur die Lippen zu einem Schrei zu formen. Hinter Dir h�rst Du eine tiefe, rauhe Stimme:`n");
		if ($henkerbestohlen) {
			output("`6\"Ihr traut Euch wirklich in mein Quartier, nachdem Ihr mir bei Eurer feigen Flucht am Galgen letztens Gold gestohlen habt?\"`3,");
			output("donnert der Henker. Ungl�ubig, dass er sich noch an Dich erinnert, verziehst Du das Gesicht zu einem letzten Grinsen. Dann f�llt die Axt");
			output("und schneidet Dich in zwei H�lften.`n`n");
			output("`4Du bist TOT.`nDu verlierst 5 Prozent Deiner Erfahrung und all Dein Gold.`n");
			output("Deine Seele macht einen Ausflug in die Unterwelt.`n`n");
			$session['user']['experience']*=0.95;	
			if ($bounty>0) {
				output("`4Dein einziger Vorteil liegt wohl darin, dass der Henker auch Dein Kopfgeld kassiert und Du Dich nunmehr weniger vor");
				output("`4Deinen Mitspielern zu f�rchten brauchst.`n");
				addnews("`2%s `4wurde vom Henker am Galgen aufgekn�pft.`nDie `^%s Goldst�cke Kopfgeld `4hat dieser nat�rlich auch kassiert.",$session['user']['name'],$bounty);
				$kopfgeldloeschen = "UPDATE ". db_prefix("bounty") ." SET status=1 WHERE target=".$session['user']['acctid'];
				db_query($kopfgeldloeschen);
			}
			if ($alignja){
				output("`4Au�erdem wird dadurch Dein Ruf etwas gel�utert und Du steigst in Deiner Gesinnung ein wenig.");
				set_module_pref("alignment",$align+2,"alignment");
			}
			$session['user']['alive']=false;
			$session['user']['hitpoints']=0;
			$session['user']['gold']=0;
			set_module_pref("henkerbestohlen",0);
			addnav("Neuigkeiten");
			addnav("T�gliche News","news.php");
		} else {
			output("`6\"Wer es wagt meine R�ume zu betreten muss entweder besonders mutig oder besonders dumm sein. Freiwillig kommt nicht einmal das Vieh");
			output("`6zur Schlachtbank. Da Ihr jedoch nicht ausseht als w�rt Ihr besonders dumm, gebe ich Euch eine Chance. Erkl�rt mir, was Euch zu mir f�hrt!\"");
			output("`n`n`3Langsam sp�rst Du, wie Leben in Deine Glieder zur�ckkehrt und das, schon eingefroren geglaubte, Blut wieder in Deinen Adern zu flie�en");
			output("`3beginnt. Dein Herz pocht wie wild und Du drehst Dich langsam, mit zitternden Knien um. Hinter Dir steht, mit der Axt in den H�nden und");
			output("`3seiner Kapuze �ber dem Kopf, `4der Henker %s`3. Durch die Sehschlitze seiner Kapuze kannst Du seine Augen erkennen, doch scheinen die Pupillen",$henkername);
			output("`3schwarz wie Ebenholz und von der Gr��e eines Groschen zu sein. Alles in Allem ein st�mmiger Kerl von gut und gerne 2 Metern Gr��e und 300 Pfund");
			output("`3Lebendgewicht. Den Urkunden an der Wand nach zu urteilen, hat er bereits in seinen fr�heren Jahren unz�hlige Male den `@gr�nen Drachen");
			output("`3bezwungen und wurde vor etlichen Jahren von seinem Lehnsherrn %s f�r seine 1000. Hinrichtung geehrt. Ein �bler Typ also, mit dem Du Dich besser",$lehnsherr);
			output("`3nicht anlegen solltest.`n`n");
			output("`2Du �berlegst Dir, was Du nun anfangen sollst.");
			addnav("Auswahl");
			addnav("Kopfgeld abzahlen","runmodule.php?module=henkerstube&op=kopfgeld");
			addnav("Rasse wechseln","runmodule.php?module=henkerstube&op=rasse");
			if (is_module_active("battlearena")) addnav("Arenapunkte einsetzen","runmodule.php?module=henkerstube&op=arena");
			addnav("Sonstiges");
			addnav("Einfach gehen","runmodule.php?module=henkerstube&op=gehen");
			addnav("Ziehe Deine Waffe","runmodule.php?module=henkerstube&op=waffe");
		}
		} else {
			output("`4Da Du, nachdem Du den Henker f�r heute au�er Gefecht gesetzt hast, hier nichts mehr zu erwarten hast, gehst Du gelangweilt zum Richtplatz zur�ck.");
			addnav("Zur�ck");
			addnav("`4Zur�ck zum Richtplatz`0","runmodule.php?module=richtplatz");
		}
		
?>