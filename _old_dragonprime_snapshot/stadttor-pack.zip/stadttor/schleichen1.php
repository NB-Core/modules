<?php

page_header("Die Stadtmauer");
$op2=httpget('op2');
	
	if($op2=="nav") {	
		if (($navmauer==true) && (get_module_pref("vonmodul")==false)) {
			output("`3 Langsam trittst Du n�her an die Mauer und dr�ckst dichte Efeub�schel nach rechts und links zur Seite, worunter eine massiver Stahlt�r zum Vorscheinen kommt.");
			output("`3 �ngstlich blickst Du Dich noch einmal um, ob auch keine der Stadtwachen in der N�he ist und Dich auch sonst niemand beobachtet.`n");
			output("`3 Die Luft ist rein, Du trittst n�her an die T�r, dr�ckst die Klinke nieder, �ffnest die T�r und stehst in Mitten der dicken Stadtmauern.`n");
			modulehook("mauer_beschreibung");
			addnav("Weiter");
			addnav("Weiter zum Marktplatz","runmodule.php?module=stadttor&op=schleichen&op2=weiter");
			addnav("Weiter zur Wildnis","runmodule.php?module=stadttor&op=schleichen1&op2=weiter");
			modulehook("mauer_nav");
		} elseif (($navmauer==true) && (get_module_pref("vonmodul")==true)) {
			output("`3Du stehst erneut in Mitten der dicken, alten Stadtmauer. Z�gernd schaust Du Dich um ... was nun?`n");
			modulehook("mauer_beschreibung");
			addnav("Weiter");
			addnav("Weiter zum Marktplatz","runmodule.php?module=stadttor&op=schleichen&op2=weiter");
			addnav("Weiter zur Wildnis","runmodule.php?module=stadttor&op=schleichen1&op2=weiter");
			modulehook("mauer_nav");			
		}
	}
		
	if($op2=="weiter") {
		if ($navmauer==false) {
			output("`3 Langsam trittst Du n�her an die Mauer und dr�ckst dichte Efeub�schel nach rechts und links zur Seite, worunter eine massiver Stahlt�r zum Vorscheinen kommt.");
			output("`3 �ngstlich blickst Du Dich noch einmal um, ob auch keine der Stadtwachen in der N�he ist und Dich auch sonst niemand beobachtet.`n");
			output("`3 Die Luft ist rein, Du trittst n�her an die T�r, dr�ckst die Klinke nieder, �ffnest die T�r,");
		}
		if ($navmauer==true) output("`3Du wanderst weiter durch die Stadtmauer, erreichst die �u�ere T�r,");
		set_module_pref("vonmodul",false);
		if ($bounty>$kopfgeld) {
			if (is_module_active("jail")) $rand=21; 
			else $rand=20;
				switch(e_rand(1,$rand)){
					case 1:
					case 2:
					case 3:
					case 4:
					case 5:
					case 6:
					case 7:
					case 8:
					case 9:
					case 10:
					case 11:
					case 12:
					case 13:
	   				case 14:
	   				case 15:
	   				case 16:
					case 17:
					case 18:
	   				output("`3passierst sie schnell und machst sie von au�en wieder zu..`n");
	   				output("`@Hui, das ging noch mal gut!");
					addnav("Zur�ck in die Stadt");
					addnav("`QZur�ck zum Stadttor`0","runmodule.php?module=stadttor"); 
					addnav("`QZur�ck zur Stadtmauer`0","runmodule.php?module=stadttor&op=mauer2");
					addnav("Reisen");      
					if (is_module_active('worldmapen')) addnav("Reisen","runmodule.php?module=worldmapen&op=beginjourney");
					else addnav("Reisen","runmodule.php?module=cities&op=travel");
					addnav("Vor dem Stadttor");
					$session['user']['specialinc']="";
					$session['user']['specialmisc']="";
					addnav("Zu den Feldern","runmodule.php?module=stadttor&op=felder");
					if ($session['user']['location'] != getsetting("villagename", LOCATION_FIELDS) && $session['user']['location'] != get_module_setting("villagename","ghosttown") && $session['user']['location'] != get_module_setting("villagename","icetown")) addnav("In den Wald","forest.php");
	   				break;
					case 19:
	   				output("`3passierst sie schnell, machst sie von au�en wieder zu und willst grade gen `2Wald `3laufen, als eine Stadtwache auf Dich zu st�rzt, die in einem Schatten stand: : `4\"Hey, Dich kenne ich doch, auf Dich ist ein Kopfgeld ausgesetzt!\"");
					output("`3Du ziehst Deine Waffe, schl�gst nach der Wache und diese f�llt ohnm�chtig zu Boden, w�hrend Du schnell das Weite suchst, wobei Du Dich allerdings auch verletzt.");
					$session['user']['hitpoints']*=0.9;
					addnews("`2%s `4wurde verletzt, als %s aus der Stadt schlich.",$session['user']['name'],translate_inline($session['user']['sex']?"sie":"er"));
					addnav("Zur�ck in die Stadt");
					addnav("`QZur�ck zum Stadttor`0","runmodule.php?module=stadttor"); 
					addnav("`QZur�ck zur Stadtmauer`0","runmodule.php?module=stadttor&op=mauer2");
					addnav("Reisen");          
					if (is_module_active('worldmapen')) addnav("Reisen","runmodule.php?module=worldmapen&op=beginjourney");
					else addnav("Reisen","runmodule.php?module=cities&op=travel");
					addnav("Vor dem Stadttor");
					$session['user']['specialinc']="";
					$session['user']['specialmisc']="";
					addnav("Zu den Feldern","runmodule.php?module=stadttor&op=felder");
					if ($session['user']['location'] != getsetting("villagename", LOCATION_FIELDS) && $session['user']['location'] != get_module_setting("villagename","ghosttown") && $session['user']['location'] != get_module_setting("villagename","icetown")) addnav("In den Wald","forest.php");
					break;
					case 20: 
	   				output("`3passierst sie schnell, machst sie von au�en wieder zu und willst grade gen Marktplatz laufen, als eine Stadtwache auf Dich zu st�rzt, die in einem Schatten stand: : `4\"Hey, Dich kenne ich doch, auf Dich ist ein Kopfgeld ausgesetzt!\"");
	   				output("`3Du greifst nach Deiner Waffe und willst auf ihn einschlagen, doch er ist schneller und streckt Dich mit einem gezielten Schwerthieb nieder.");
					output("`3T�dlich getroffen sinkst Du zu Boden.");
					$session['user']['alive']=false;
					$session['user']['deathpower']+=15;
					$session['user']['hitpoints']=0;
					$session['user']['gold']=0;
					$session['user']['experience']*0.97;
					addnews("`2%s `4starb bei dem Versuch, sich aus der Stadt zu schleichen.`nDie Stadtwache freut sich �ber die `6%s`4 Goldst�cke Kopfgeld.",$session['user']['name'],$bounty);
					$sql = "UPDATE ". db_prefix("bounty") ." SET status=1 WHERE target=".$session['user']['acctid'];
					db_query($sql);
					addnav("T�gliche News","news.php");
					break;
					case 21:
					$sname=(get_module_setting("sheriffname","jail"));
					output("`3doch pl�tzlich steht `4%s `3vor Dir. Du blickst in seine Augen, die Dir verraten, dass eine Flucht sinnlos w�re",$sname);
					output("und Dich lediglich Dein Leben kosten w�rde. Mit gesenktem Kopf und niedergeschlagenen Schritten folgst Du `4%s `3ins `\$Gef�ngnis`3,",$sname);
					output("wo Du wohl die n�chste Zeit verbringen wirst. Das Positive daran ist lediglich, dass nun kein Kopfgeld mehr auf Dich ausgesetzt ist.");
					set_module_pref("wantedlevel",0,"jail");
					set_module_pref("injail",1,"jail");
					set_module_pref("village",$session['user']['location'],"jail");
					addnews("`4%s `2wurde von `4Scheriff %s`2 in der Stadtmauer verhaftet und ins Gef�ngnis gesteckt.`nDie `6%s Goldst�cke Kopfgeld `2erh�lt die Staatskasse.",$session['user']['name'],$sname,$bounty);
					$sql = "UPDATE ". db_prefix("bounty") ." SET status=1 WHERE target=".$session['user']['acctid'];
					db_query($sql);
					addnav("Weiter");
					addnav("Ab ins Gef�ngis","runmodule.php?module=jail");
					break;
					}
				}
				else {
					output("`3passierst sie schnell und machst sie von au�en wieder zu..`n");
	   				output("`@Hui, das ging noch mal gut!");
					addnav("Zur�ck in die Stadt");
					addnav("`QZur�ck zum Stadttor`0","runmodule.php?module=stadttor"); 
					addnav("`QZur�ck zur Stadtmauer`0","runmodule.php?module=stadttor&op=mauer2");
					addnav("Reisen");           
					if (is_module_active('worldmapen')) addnav("Reisen","runmodule.php?module=worldmapen&op=beginjourney");
					else addnav("Reisen","runmodule.php?module=cities&op=travel");
					addnav("Vor dem Stadttor");
					$session['user']['specialinc']="";
					$session['user']['specialmisc']="";
					addnav("Zu den Feldern","runmodule.php?module=stadttor&op=felder");   
					if ($session['user']['location'] != getsetting("villagename", LOCATION_FIELDS) && $session['user']['location'] != get_module_setting("villagename","ghosttown") && $session['user']['location'] != get_module_setting("villagename","icetown")) addnav("In den Wald","forest.php");
			}
	}
			
?>