<?php

//Idee und Umsetzung    
//Morpheus aka Apollon  
//f�r lotgd.at       
//Umsetzung f�r 1.0.X BansheeElhayn
//Mail to Morpheus@magic.ms or Apollon@magic.ms or Agent.Herby@web.de

function wolkeninsel_getmoduleinfo() {
	$info = array(
		"name"=>"Die Wolkeninsel",
		"version"=>"1.0",
		"author"=>"Apollon und <a href='http://www.dailyzone.selfhost.de/lotgd' target=_new>BansheeElhayn</a>",
		"category"=>"Stadttor",
		"download"=>"http://dragonprime.net/users/Apollon/stadttor-pack.zip",
		"requires"=>array(
		"stadttor"=>"1.7 by Apollon und BansheeElhayn",
		"burg"=>"1.0 by Apollon und BansheeElhayn",
		),
	);
	return $info;
}

function wolkeninsel_install() {
		if (!is_module_active("wolkeninsel")) output("Die Wolkeninsel wird installiert.");
		module_addhook("burg");
		module_addhook("burg_beschreibung");
		return true;
}

function wolkeninsel_uninstall() {
	output("Die Wolkeninsel wird deinstalliert.");
	return true;
}

function wolkeninsel_dohook($hookname, $args) {
	global $session;
	switch($hookname) {
		
		case ("burg"):
		addnav("In den Burggarten","runmodule.php?module=wolkeninsel");
		break;
		
		case ("burg_beschreibung"):
		output("Ein kleiner, unbefestigter Weg f�hrt vom Burghof in den Burggarten. Dieser scheint liebevoll angelegt. Die Wege sind von");
		output("bl�henden Blumenfeldern und sorgsam zugeschnittenen B�umchen eingefa�t. Am Ende des Weges liegt ein kristallklarer");
		output("Burgteich mit einem Steg der in seine Mitte f�hrt. Dort kannst Du, auf Grund des dichten Nebels �ber dem Wasser, aber nichts Genaues erkennen.`n");
		break;
		
	}
	return $args;
}

function wolkeninsel_run() {
	global $session;
	$op=httpget('op');
	require_once "common.php";
	require_once("lib/commentary.php"); 

	page_header("Der Burggarten");
    output("`c`b`@Der Burggarten`b`c`n");
	if ($op=="") {
        output("`@Du gehst am Ufer des Sees entlang bis zu einem kleinen, schmalen Steg, der zu einer Insel im Teich f�hrt, die st�ndig im Nebel liegt und deshalb vom Ufer nicht gesehen werden kann.");
        output("Vorsichtig gehst Du, Schritt f�r Schritt, �ber den Steg bis hin zur Insel, auf der ein v�llig anders Wetter ist, als am �brigen Teich, das sich aber auch hier nicht �ndert.");
        output("Der Himmel �ber Dir ist klar und blau, die Sonne scheint");
	switch(e_rand(1,10)) {
		
		case 1:
		output("und die V�gel singen fr�hlich ihre Lieder, w�hrend kleine `^Feen `@lustig dazu tanzen.`n`n");
		break;
		
		case 2:
		output("und Du gehst �ber dieses wundervolle Fleckchen Erde, jeden Schritt genie�end, zum `&Pavillon`@.`n`n");
		$session['user']['charm']+=1;//Eine heimliche Belohnung f�r RPler
		break;
		
		case 3:
		output("und ein `4Eichh�rnchen `@kreuzt Deinen Weg, sieht Dich verschmitzt an und l�uft lustig quiekend zum n�chsten Baum.`n`n");
		break;
		
		case 4:
		output("und 2 `&Schw�ne `@watscheln verliebt �ber die Wiese bis zum See, indem sie schlie�lich gemeinsam davon schwimmen.`n`n");
		break;
		
		case 5:
		output("und eine `6Entenmutter `@f�hrt ihre Jungen, quer �ber die Wiese, zu ihrer ersten Schwimmstunde zum See.`n`n");
		break;
		
		case 6:
		output("und die Luft ist klar und warm, wie an einem sch�nen `6Sommertag`@.`n`n");
		break;
		
		case 7:
		output("und Dein `\$Herz `@beginnt h�her zu schlagen bei diesem wundervollen, traumhaft sch�nen Anblick.`n`n");
		$session['user']['charm']+=1;//Eine heimliche Belohnung f�r RPler
		break;
		
		case 8:
		output("und Du f�hlst Dich, als ob Du soeben hier `6neu geboren`@ worden w�rst im Paradies.`n`n");
		break;
		
		case 9:
		output("und Du glaubst, auf der Insel der `^G�tter`@ zu sein, so wundersch�n und ruhig wie dieser Ort ist.`n`n");
		$session['user']['hitpoints']*=1.01;//Eine heimliche Belohnung f�r RPler
		break;
		
		case 10:
		output("und Du f�hlst Dich `6seelig `@und zufrieden, diesen wundervollen Ort gefunden zu haben.`n`n");
		break;
		
		}
	addnav("Wandern");
	addnav("Weiter","runmodule.php?module=wolkeninsel&op=insel");
	}
	
	else if ($op=="insel") {
		page_header("Die Wolkeninsel");
		output("`c`b`@Die Wolkeninsel`b`c`n");
        output("In der Mitte der Insel steht ein kleiner Pavillon, umringt von B�umen auf einer Wiese, durch die ein sanfter Wind weht und Geschichten erz�hlt von der Liebe.");
        output("Am Ufer ist ein Strand aus feinem, wei�em Sand der zum Baden einl�dt. Der Boden unter Dir scheint so sanft und weich, da� Du glaubst, auf Wolken zu wandeln.`n");
        output("�berall bl�hen Blumen in den sch�nsten Farben und ein kleines Rinnsal bahnt sich, lustig pl�tschernd, seinen Weg zum See, w�hrend Du hier und da kleine Feen sehen kannst, die sich im lustigen Tanze in der Luft bewegen.");
        output("In der Ferne kannst Du 2 Einh�rner erkennen, die friedlich nebeneinander grasen, w�hrend ihr Junges lustige Kapriolen macht.`n`n");
        output("`2Eine der Feen, die hier umherschwirren, erinnert dich daran, dass der Ort ein Platz f�r Rollenspiel ist, und dass dieser Bereich vollst�ndig auf charakterspezifische Kommentare beschr�nkt ist.`n`n");
        addcommentary();
        viewcommentary("wolkeninsel","Hier fl�stern",20,"fl�stert");
        addnav("Wandern");
        addnav("Zur�ck zum Burghof","runmodule.php?module=burg");
        page_footer();
	}
page_footer();

}
?>