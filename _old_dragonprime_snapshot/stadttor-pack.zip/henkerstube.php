<?php

function henkerstube_getmoduleinfo() {
	$info = array(
		"name"=>"Die Henkerstube und der Galgen",
		"version"=>"1.0",
		"author"=>"<a href='http://www.dailyzone.selfhost.de/lotgd' target=_new>BansheeElhayn</a>",
		"category"=>"Stadttor",
		"download"=>"http://dragonprime.net/users/AgentHerby/stadttor-pack.zip",
		"description"=>"Ein Zusatzmodul f�r den Richtplatz am Stadttor",
		"requires"=>array(
			"stadttor"=>"1.7 by Apollon und BansheeElhayn",
			"richtplatz"=>"1.0 by Apollon",
			),
		"settings"=>array(
			"Die Henkerstube - Einstellungen,title",
				"henkername"=>"Name des Henkers,text",
				"gspieler"=>"Wer h�ngt zur Zeit am Galgen?,text|Gulthaz",
				"henkergebuehr"=>"Wieviel Prozent Vermittlungsgeb�hr erh�lt der Henker?,range5,100,5|20",
				"scheriffgebuehr"=>"Wieviel Prozent Provision erh�lt der Scheriff?,range5,100,5|25",
			"Henkerkampf,title",
				"minleben"=>"Mindestwert der Lebenspunkte des Henkers pro Spielerlevel:,int|10",
				"maxleben"=>"H�chstwert  der Lebenspunkte des Henkers pro Spielerlevel:,int|15",
				"dk"=>"Steigt die St�rke des Henkers mit jedem DrachenKill des Spielers?,bool|1",
			"Arenapunkte,title",
				"Diese Einstellungen haben nur Auswirkung wenn das Modul \"battlearena.php\"aktiv ist!,note",
				"goldkost"=>"Wieviel Arenapunkte kosten 500 Goldst�cke pro Spielerlevel?,int|15",
				"edelsteinkost"=>"Wieviele Arenapunkte kostet ein Edelstein?,int|15",
				"erfahrungskost"=>"Wieviele Arenapunkte kosten 25% der erforderlichen Erfahrungspunkte f�r den n�chsten Level?,int|25",
				"waffenkost"=>"Wieviele Arenapunkte kostet eine bessere Waffe?,int|30",
				"ruestkost"=>"Wieviele Arenapunkte kostet eine bessere R�stung?,int|30",
				"Die Werte sind BASISWERTE ... Hinzu kommt jeweils der Wert der aktuellen Drachenkills,note",
			"Rassenwechsel,title",
				"immer"=>"Ist ein Rassenwechsel permanent f�r den laufenden DK?,bool|0",
				"Wenn nicht h�lt die neu gew�hlte Rasse nur einen Spieltag,note",
				"rassenkostgold"=>"Wieviel Gold kostet eine andere Rasse?,int|7500",
				"rassenkostedel"=>"Wieviel Edelsteine kostet eine andere Rasse?,int|3",
				"Bitte beachte f�r die folgenden Eistellungen dass der Name der Rasse dem Namen im MODUL entsprechen muss!!,note",
				"zusatzrasse1"=>"Name der Zusatzrasse 1?,text",
				"minimumdk1"=>"Mindestzahl der DrachenKills f�r Zusatzrasse 1?,int|1",
				"zusatz1aktiv"=>"Zusatzrasse 1 aktiv?,bool|0",
				"zusatzrasse2"=>"Name der Zusatzrasse 2?,text",
				"minimumdk2"=>"Mindestzahl der DrachenKills f�r Zusatzrasse 2?,int|1",
				"zusatz2aktiv"=>"Zusatzrasse 2 aktiv?,bool|0",
				"zusatzrasse3"=>"Name der Zusatzrasse 3?,text",
				"minimumdk3"=>"Mindestzahl der DrachenKills f�r Zusatzrasse 3?,int|1",
				"zusatz3aktiv"=>"Zusatzrasse 3 aktiv?,bool|0",
				"zusatzrasse4"=>"Name der Zusatzrasse 4?,text",
				"minimumdk4"=>"Mindestzahl der DrachenKills f�r Zusatzrasse 4?,int|1",
				"zusatz4aktiv"=>"Zusatzrasse 4 aktiv?,bool|0",
				"zusatzrasse5"=>"Name der Zusatzrasse 5?,text",
				"minimumdk5"=>"Mindestzahl der DrachenKills f�r Zusatzrasse 5?,int|1",
				"zusatz5aktiv"=>"Zusatzrasse 5 aktiv?,bool|0",
				"zusatzrasse6"=>"Name der Zusatzrasse 6?,text",
				"minimumdk6"=>"Mindestzahl der DrachenKills f�r Zusatzrasse 6?,int|1",
				"zusatz6aktiv"=>"Zusatzrasse 6 aktiv?,bool|0",
				"zusatzrasse7"=>"Name der Zusatzrasse 7?,text",
				"minimumdk7"=>"Mindestzahl der DrachenKills f�r Zusatzrasse 7?,int|1",
				"zusatz7aktiv"=>"Zusatzrasse 7 aktiv?,bool|0",
				"zusatzrasse8"=>"Name der Zusatzrasse 8?,text",
				"minimumdk8"=>"Mindestzahl der DrachenKills f�r Zusatzrasse 8?,int|1",
				"zusatz8aktiv"=>"Zusatzrasse 8 aktiv?,bool|0",
				"zusatzrasse9"=>"Name der Zusatzrasse 9?,text",
				"minimumdk9"=>"Mindestzahl der DrachenKills f�r Zusatzrasse 9?,int|1",
				"zusatz9aktiv"=>"Zusatzrasse 9 aktiv?,bool|0",
				"zusatzrasse10"=>"Name der Zusatzrasse 10?,text",
				"minimumdk10"=>"Mindestzahl der DrachenKills f�r Zusatzrasse 10?,int|1",
				"zusatz10aktiv"=>"Zusatzrasse 10 aktiv?,bool|0",
				"zusatzrasse11"=>"Name der Zusatzrasse 11?,text",
				"minimumdk11"=>"Mindestzahl der DrachenKills f�r Zusatzrasse 11?,int|1",
				"zusatz11aktiv"=>"Zusatzrasse 11 aktiv?,bool|0",
				"zusatzrasse12"=>"Name der Zusatzrasse 12?,text",
				"minimumdk12"=>"Mindestzahl der DrachenKills f�r Zusatzrasse 12?,int|1",
				"zusatz12aktiv"=>"Zusatzrasse 12 aktiv?,bool|0",
				"zusatzrasse13"=>"Name der Zusatzrasse 13?,text",
				"minimumdk13"=>"Mindestzahl der DrachenKills f�r Zusatzrasse 13?,int|1",
				"zusatz13aktiv"=>"Zusatzrasse 13 aktiv?,bool|0",
				"zusatzrasse14"=>"Name der Zusatzrasse 14?,text",
				"minimumdk14"=>"Mindestzahl der DrachenKills f�r Zusatzrasse 14?,int|1",
				"zusatz14aktiv"=>"Zusatzrasse 14 aktiv?,bool|0",
				"zusatzrasse15"=>"Name der Zusatzrasse 15?,text",
				"minimumdk15"=>"Mindestzahl der DrachenKills f�r Zusatzrasse 15?,int|1",
				"zusatz15aktiv"=>"Zusatzrasse 15 aktiv?,bool|0",
		),
		"prefs"=>array(
			"Die Henkerstube - Spielerbereich",
				"henkerbestohlen"=>"Hat der Spieler den Henker bestohlen?,bool|0",
				"hatengel"=>"Hat der Spieler heute schon den Engel gesehen?,bool|0",
				"besuchgalgen"=>"Wie oft hat der Spieler heute schon den Galgen besucht?,int|0",
				"henkerkampf"=>"Hat der Spieler heute schon den Henker in seiner Stube angegriffen?,bool|0"
		),
	);
    return $info;
}

function henkerstube_install() {
	if (!is_module_active("henkerstube")) {
		output("`n`3Installiere das Zusatzmodul \"`\$Henkerstube`3\" f�r den Richtplatz am Stadttor.");
		output("`nUm das Modul in `bvollem Umfang`b nutzen zu k�nnen, sollten `6die Arena \"battlearena.php\" `3und `6Alignment \"alignment.php\" `3installiert sein.");
		output("`nViel Spa�!!`n`n");
	}
	module_addhook("richtplatz");
	module_addhook("richtplatz_beschreibung");
	module_addhook("newday");
	return true;
}

function henkerstube_uninstall() {
	return true;
}

function henkerstube_dohook($hookname, $args) {
	global $session;
	switch($hookname) {
		
			case("richtplatz"):
				addnav("Henkerstube","runmodule.php?module=henkerstube");
				addnav("Galgen untersuchen","runmodule.php?module=henkerstube&op=galgen");
			break;
			
			case("richtplatz_beschreibung"):
				output("`n`3Der Henker hat auf dem Richtplatz selbst einen Galgen montiert.");
				output("`3Du bleibst kurz stehen und schaust Dir die armen Gestalten an, die dort ihr trauriges Ende gefunden haben.`n`n");
			break;
			
			case("newday"):
				set_module_pref("hatengel",0);
				set_module_pref("besuchgalgen",0);
				set_module_pref("henkerkampf",0);
				$tage=get_module_pref("tage");
				$immer=get_module_setting("immer");
				$neuerasse=get_module_pref("neuerasse");
				$alterasse=get_module_pref("alterasse");
				if ($immer==false){
				if ($tage==0 && (get_module_pref("msg")==1)) {
					output("`n<big><big>`!Nach Ablauf Deiner Testzeit f�r Deine Rasse als `1%s `!erwachst Du wieder als `1%s`!.</big></big>`n",translate_inline($neuerasse),translate_inline($alterasse),true);
					$session['user']['race']=$alterasse;
					set_module_pref("tage",2);
					set_module_pref("msg",0);
				}
				if ($tage=="1") {
					output("`n<big><big>`1Der Zaubertrank des Henkers tut seine Wirkung .. Du erwachst als `!%s`1.</big></big>`n",$neuerasse,true);
					$session['user']['race']=$neuerasse;
					set_module_pref("tage",0);
					set_module_pref("msg",0);
				}
				} else {
					if (get_module_pref("msg")==1) {
						output("`n<big><big>`1Der Zaubertrank des Henkers tut seine Wirkung .. Du erwachst als `!%s`1.</big></big>`n",$neuerasse,true);
						$session['user']['race']=$neuerasse;
						set_module_pref("msg",0);
					}
				}
			break;
			
	}
	return $args;
}

function henkerstube_run() {
	global $session;
	$op=httpget('op');
	$op2=httpget('op2');
	$rasse=httpget('rasse');
	$rbetrag=get_module_pref("rbetrag");
	$gspieler=get_module_setting("gspieler");
	$sql="SELECT amount FROM ". db_prefix("bounty") ." WHERE status=0 and target=".$session['user']['acctid'];
	$ergebnis = db_query($sql) or die(sql_error($sql));
	for ($i=0;$i<db_num_rows($ergebnis);$i++){
   		$row = db_fetch_assoc($ergebnis);
   		$bounty+=$row[amount];
	}
	if ($bounty=="") $bounty=0;
	$arenapunkte=get_module_pref("battlepoints","battlearena");
	$goldkost=get_module_setting("goldkost")+$session['user']['dragonkills'];
	$edelsteinkost=get_module_setting("edelsteinkost")+$session['user']['dragonkills'];
	$erfahrungskost=get_module_setting("erfahrungskost")+$session['user']['dragonkills'];
	$waffenkost=get_module_setting("waffenkost")+$session['user']['dragonkills'];
	$ruestkost=get_module_setting("ruestkost")+$session['user']['dragonkills'];
	$goldangebot=$session['user']['level']*500;
	$henkername=get_module_setting("henkername");
	$lehnsherr="`1Banshee`!Elhayn`3";
	$henkerbestohlen=get_module_pref("henkerbestohlen");
	$henkerkampf=get_module_pref("henkerkampf");
	$hatengel=get_module_pref("hatengel");
	$besuchgalgen=get_module_pref("besuchgalgen");
	require_once("lib/experience.php");
    $aktlevel=$session['user']['level'];
    $dks=$session['user']['dragonkills'];
	$benoetigt=exp_for_next_level($aktlevel, $dks);
	$erfahrung=round($benoetigt*0.25);
	$rassenkostgold=get_module_setting("rassenkostgold");
	$rassenkostedel=get_module_setting("rassenkostedel");
	$list=array();
	if (is_module_active("alignment")) {
		$align=get_module_pref("alignment","alignment");
		$galign=get_module_setting("goodalign","alignment");
		$balign=get_module_setting("evilalign","alignment");
		$aktiv=translate_inline("Neigungen des Lebens");
		$alignja=1;
	} else {
		$align=e_rand(1,100);
		$galign=66;
		$balign=33;
		$aktiv=translate_inline("Taten in letzter Zeit");
	}
	
	page_header("Die Henkerstube");
	
	if ($op=="") {
		include ("modules/stadttor/henker_main.php");
	}
	
	if($op=="galgen") {
		include ("modules/stadttor/galgen.php");
	}
	
	if($op=="kopfgeld") {
		include ("modules/stadttor/kopfgeld.php");
	}
	
	if($op=="gehen") {
		$zuffi=e_rand(1,4);
		switch ($zuffi) {
			
			case 1:
			case 2:
			case 3:
				output("`3Frech, wie Du nun einmal bist, ignorierst Du den Henker einfach und schiebst ihn beiseite. Anschlie�end verl�sst Du seine Stube");
				output("`3einfach durch die Eingangst�r.`n`n`4%s `2ist so verdutzt, dass er Dich einfach ziehen l�sst.",$henkername);
				addnav("Zur�ck");
				addnav("`4Zur�ck zum Richtplatz`0","runmodule.php?module=richtplatz");
			break;
			
			case 4:
				output("`3Frech, wie Du nun einmal bist, ignorierst Du den Henker einfach und versuchst ihn einfach zur Seite zu schieben.");
				output("`3Dies erbost ihn nat�rlich sehr, denn welcher Henker l�sst sich schon gerne ignorieren?`n`n");
				output("`2W�tend schwingt er seine Axt und zieht Dich am Kragen zum Kampf hinaus auf den Richtplatz.`n`n");
				addnav("Der Kampf");
				addnav("Gib Dein Bestes","runmodule.php?module=henkerstube&op=fighting");
			break;
		}
	}
	
	if($op=="waffe") {
		output("`3Mutig ziehst Du Deine Waffe. Etwas Besseres f�llt Dir im Moment echt nicht ein. Dein Magen dreht sich bei dem Gedanken, dass Du wohlm�glich");
		output("`3das Licht der Welt nie wieder lebend erblicken und niemals mehr eines der h�bschen Burgfr�uleins lachen h�ren wirst.`n`n");
		output("`3Der Henker %s `3bricht in schallendes Gel�chter aus und entgegnet Dir mit seiner rauhen Stimme:`n",$henkername);
		output("`6\"Soooo, Du bist aber %s. Ich h�tte Dich eigentlich schlauer eingesch�tzt.",translate_inline($session['user']['sex']?"ein mutiges M�del":"ein mutiger Bursche"));
		output("`6Du hast meine Urkunden bewundert und wei�t um meine Verdienste. Dann solltest Du auch wissen, dass Du einen harten Kampf erwarten darfst.");
		output("`6Nun denn, dann lass uns unsere Kr�fte messen.\"`n`n");
		output("`2Mit diesen Worten schwingt er seine Axt und zieht Dich am Kragen zum Kampf hinaus auf den Richtplatz.`n`n");
		addnav("Der Kampf");
		addnav("Gib Dein Bestes","runmodule.php?module=henkerstube&op=fighting");
	}
	
	if ($op=="rasse") {
		set_module_pref("alterasse",$session['user']['race']);
		output("`3Du entscheidest Dich f�r einen Rassenwechsel, da Du offenbar mit Deinem bisherigen Leben als `4%s `3nicht wirklich zufrieden warst.`n`n",translate_inline($session['user']['race']));
		output("`6\"Nun, %s. Dann will ich mal meine Beziehungen spielen lassen und nachschauen, welche V�lker dieses Landes bereit sind Dich in Ihrem",translate_inline($session['user']['sex']?"meine Liebe":"mein Freund"));
		$immer=get_module_setting("immer");
		if ($immer==false) {
			output("`6Scho�e der Gesellschaft aufzunehmen. Bitte bedenke, dass es sich hierbei nur um ein Hineinschnuppern handelt und daher nur `5einen Tag `6lang");
			output("`6anh�lt.Deine neue 'Schnupperrasse' wird am n�chsten Spieltag erst aktiv. Meine Bem�hungen kosten Dich `^%s Goldst�cke",$rassenkostgold);
			output("`6 und `5%s Edelsteine`6.\"`n`n",$rassenkostedel);
		} else {
			output("`6Scho�e der Gesellschaft aufzunehmen. Deine Rassenwahl wird erst am n�chsten Spieltag aktiv. Meine Bem�hungen kosten Dich `^%s Goldst�cke",$rassenkostgold);
			output("`6 und `5%s Edelsteine`6.\"`n`n",$rassenkostedel);
		}
		output("`n`n<big><big><big><big>`4`c- - - R A S S E N A U S W A H L - - -</big></big>`n`n`2",true);
		output("~ Zwerg ~`n~ Elf ~`n~ Mensch ~`n~ Troll ~`n");
		addnav("Rassenliste");
		addnav("Zwerg","runmodule.php?module=henkerstube&op=wechsel&rasse=Dwarf");
		addnav("Elf","runmodule.php?module=henkerstube&op=wechsel&rasse=Elf");
		addnav("Mensch","runmodule.php?module=henkerstube&op=wechsel&rasse=Human");
		addnav("Troll","runmodule.php?module=henkerstube&op=wechsel&rasse=Troll");
		if (($session['user']['dragonkills']>=get_module_setting("mindk","racecat")) && (is_module_active("racecat"))) {
			output("~ Felyne ~`n");
			addnav("Felyne","runmodule.php?module=henkerstube&op=wechsel&rasse=Felyne");
		}
		if ((get_module_pref("bought","racestorm")) && (is_module_active("racestorm"))) {
			output("~ Sturmgigant ~`n");
			addnav("Sturmgigant","runmodule.php?module=henkerstube&op=wechsel&rasse=Storm Giant");
		}
		for ($i=1;$i<16;$i++) {
			$zrasse=(get_module_setting("zusatzrasse".$i));
			$raktiv=(get_module_setting("zusatz".$i."aktiv"));
			$minimumdk=(get_module_setting("minimumdk".$i));
			if (($raktiv) && ($session['user']['dragonkills']>=$minimumdk)) {
				output("~ %s ~`n",translate_inline($zrasse));
				addnav(translate_inline($zrasse),"runmodule.php?module=henkerstube&op=wechsel&rasse=".$zrasse);
			}
		}
		output("</big></big>`c`n`n",true);
		addnav("Zur�ck");
		addnav("`qZur�ck zur Henkerstube`0","runmodule.php?module=henkerstube");
		addnav("`4Zur�ck zum Richtplatz`0","runmodule.php?module=richtplatz");
	}
	
	if($op=="wechsel") {
		if (($session['user']['gold']>=$rassenkostgold) && ($session['user']['gems']>=$rassenkostedel)) { 
			output("`6\"So soll es denn sein.\"`n`n`3Mit diesen Worten �bergibt Dir `4%s `3eine kleine Flasche mit einer purpurfarbenen Essenz. Du trinkst den",$henkername);
			output("`3Inhalt in einem Zuge leer und wartest auf den Eintritt der Wirkung ... doch nichts geschieht ... Dann erinnerst Du Dich wieder an die Worte,");
			output("`3die der Henker noch zu Dir sprach ... Die Wirkung tritt erst mit Beginn des n�chsten Spieltages ein.");
			output("`n`n`2Du kannst es kaum erwarten, die neue Rasse auszuprobieren und sehnst Dich nach dem neuen Tag.");
			$session['user']['gold']-=$rassenkostgold;
			$session['user']['gems']-=$rassenkostedel;
			set_module_pref("tage",1);
			set_module_pref("msg",1);
			set_module_pref("neuerasse",$rasse);
			addnav("Zur�ck");
			addnav("`qZur�ck zur Henkerstube`0","runmodule.php?module=henkerstube");
			addnav("`4Zur�ck zum Richtplatz`0","runmodule.php?module=richtplatz");
		} else {
			output("`6\"Moment mal ... Ich sehe gerade, dass dies Deine finanzielle Leistungsf�higkeit �bersteigt. Ich habe das Gef�hl, Du willst mich hier");
			output("`6zum Narren halten! Ich werde Dir eine Lektion verpassen, die Du nie vergessen wirst!\"`n`n");
			$zuffi=e_rand(1,7);
			switch ($zuffi) {
				case 1: case 2: case 3: case 4: case 5:
					output("`3Schnell nimmst Du die Beine unter den Arm und rennst, am Henker vorbei, aus seinem Quartier. Wutschnaubend h�rst Du `4%s",$henkername);
					output("`3noch eine Weile hinter Dir herfluchen, doch Du wei�t, dass er die Angelegenheit schon bald vergessen haben wird.`n`n");
					output("`@Das ist ja gl�cklicherweise nochmal gut gegangen!");
					addnav("Zur�ck");
					addnav("`4Zur�ck zum Richtplatz`0","runmodule.php?module=richtplatz");
				break;
				
				case 6:
					output("`2Mit diesen Worten schwingt er seine Axt und zieht Dich am Kragen zum Kampf hinaus auf den Richtplatz.`n`n");
					addnav("Der Kampf");
					addnav("Gib Dein Bestes","runmodule.php?module=henkerstube&op=fighting");
				break;	
				
				case 7:
					output("`2Mit diesen Worten ergreift Dich der Henker und, bevor Du die Chance hast Dich zu wehren, hat er Dich auch unter dem Jubeln und");
					output("`2Johlen des Volkes am Galgen auf dem Richtplatz aufgekn�pft.`n`n");
					output("`4Du bist TOT, stranguliert durch den Strick und gefressen von den wartenden Aasgeiern.`n");
					output("`4Du verlierst all Dein Gold, welches der Henker nun als seine \"Vermittlungsgeb�hr\" betrachtet.`n");
					output("`4Doch die Erfahrung, dass man einen Henker nicht �rgern soll, gleicht jeglichen anderen Erfahrungsverlust aus.");
					addnews("`2%s `4hat heute den Henker ver�rgert und starb daf�r den Tod am Galgen.",$session['user']['name']);
					set_module_setting("gspieler",$session['user']['name']);
					$session['user']['alive']=false;
					$session['user']['gold']=0;
					$session['user']['hitpoints']=0;
					addnav("Neuigkeiten");
					addnav("T�gliche News","news.php");
				break;				
			}
		}
	}
	
	if($op=="rechja") {
		include ("modules/stadttor/rechja.php");
		set_module_pref("rbetrag",0);
	}
	
	if($op=="rechnein") {
		include ("modules/stadttor/rechnein.php");
		set_module_pref("rbetrag",0);
	}
	
	if($op=="arena") {
		include ("modules/stadttor/arena.php");
	}
	
	if ($op=="arena2") {
		include ("modules/stadttor/arena_handel.php");
		require_once("modules/battlearena.php");
		battlearena_isnewleader();
	}
	
	if($op=="fighting") {
		$min=get_module_setting("minleben");
		$max=get_module_setting("maxleben");
		$leben=(e_rand($min,$max)*$session['user']['level']);
		if (get_module_setting("dk")) $bonus=$session['user']['dragonkills']*10;
		$gesamtleben=$leben+=$bonus;
		$badguy = array(        "creaturename"=>translate_inline("`4Der Henker`0")
                                ,"creaturelevel"=>$session['user']['level']+1
                                ,"creatureweapon"=>translate_inline("`4Henkeraxt")
                                ,"creatureattack"=>$session['user']['attack']+=5
                                ,"creaturedefense"=>$session['user']['defense']+=5
                                ,"creaturehealth"=>$gesamtleben
                                ,"creaturegold"=>0
                                ,"diddamage"=>0);
    $session['user']['badguy']=createstring($badguy);
    $op="fight";
    $battle=true;
	}
	
	if($op=="fight") {
		require_once("lib/fightnav.php");
		include("battle.php");
		
		if ($victory){
		output("`2Dein letzter Schlag l��t den Henker zu Boden sinken und Dir gelingt die Flucht.`n`n");
		$erfahrung=round($session['user']['experience']*1.05) - $session['user']['experience'];
		if ($erfahrung>0) $session['user']['experience']*=1.05;
		else {
			$session['user']['experience']++;
			$erfahrung=1;
		}
		addnav("Weiter","runmodule.php?module=henkerstube&op=sieg");
		output("Du erh�ltst `^%s`2 %s f�r Deinen Sieg.`n`n", $erfahrung,translate_inline($erfahrung?"Erfahrungspunkt":"Erfahrungspunkte"));
		addnews("`4%s `2hat den Henker auf dem Richtplatz im Kampf bezwungen.",$session['user']['name']);
	}
		elseif ($defeat){
		$session['user']['alive']=false;
		$session['user']['hitpoints']=0;
		$session['user']['gold']=0;
		$session['user']['experience']*=0.9;
		output("`3`nMit einem letzten, m�chtigen Schlag mit seiner riesigen Axt, teilt Dich der Henker in zwei H�lften.`n`n");
		output("`4Du bist TOT!!!`nDu verlierst all Dein Gold und 10 Prozent Erfahrung.");
		addnav("Neuigkeiten");
		addnav("T�gliche News","news.php");
		if ($bounty>0) addnews("`2%s `4unterlag im Kampf dem Henker auf den Richtplatz.`nDieser hat hat nat�rlich auch die `6%s`4 Goldst�cke Kopfgeld kassiert.",$session['user']['name'],$bounty);
		else addnews("`2%s `4unterlag im Kampf dem Henker auf den Richtplatz.",$session['user']['name']);
		$sql = "UPDATE ". db_prefix("bounty") ." SET status=1 WHERE target=".$session['user']['acctid'];
		db_query($sql);
	}
		else { fightnav(true,false,"runmodule.php?module=henkerstube");
		}
	}
	
	if ($op=="sieg") {
		output("<big><big><big>`5`c - - - S I E G - - -`c</big></big></big>",true);
		output("`n`n`3Du hast es tats�chlich geschafft !!! Kaum zu glauben aber wahr.`n`n");
		output("`3Mit Deinem letzten Schlag geht der Henker, schwer getroffen zu Boden. Sofort kommen Ritter aus der nahegelegenen Burg angelaufen");
		output("`3und tragen den Henker in sein Quartier. Einer der Ritter kommt auf Dich zu ... doch Du bist schneller.");
		output("`3Du ziehst Dich in eine abgelegene Ecke des Richtplatzes zur�ck.`n`nSp�ter erf�hrst Du, dass der Henker nicht");
		output("`3nachtragend ist und den Kampf mit Dir eigentlich ganz erquickend fand.`n");
		if ($alignja) {
			output("`3Eigentlich ein seltsames Lob, das Dich aber in Deinem Ansehen steigen l�sst. Somit hat sich der Kampf noch mehr gelohnt.");
			align(+3);
		}
		$zuffi=e_rand(1,3);
		switch($zuffi) {
			case 3:
			if ($session['user']['hitpoints']<$session['user']['maxhitpoints']) {
				output("`3Als Du sp�ter wieder an die Stelle, an der Du gek�mpft hast, kommst, findest Du dort sogar einen Heiltrank. An diesem ist ein Zettel");
				output("`3befestigt, der Dir sagt, dass dieser Trank f�r Dich und den fairen Kampf als Belohnung vom Henker hier bereitsgestellt wurde.");
				output("`3Schnell, bevor ihn jemand anderes trinkt, kippst Du den Trank hinunter.");
			$session['user']['hitpoints']=$session['user']['maxhitpoints'];
			}
		}
		set_module_pref("henkerkampf",1);
		addnav("Zur�ck");
		addnav("`4Zur�ck zum Richtplatz`0","runmodule.php?module=richtplatz");
	}
	
	page_footer();
}

?>