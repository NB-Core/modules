<?php

// New Hall of Fame features by anpera
// http://www.anpera.net/forum/viewforum.php?f=27

require_once "common.php";
page_header("Hall of Fame");
checkday();

/* this is part of my gardenflirt script and pretty useless without it
if ($_GET[op]=="paare"){ 
	output("In a small room beside the main hall you find a list of heros of another kind. Those heros manage the danger of marriage together!`n`n");
	addnav("Back to hall of fame","hof.php");
	$sql = "SELECT acctid,name,marriedto FROM accounts WHERE sex=0 AND charisma=4294967295 ORDER BY acctid DESC";
	output("`c`b`&Couples of this world`b`c`n");
	output("<table cellspacing=0 cellpadding=2 align='center'><tr><td>`bName (f)`b</td><td></td><td>`b Name (m)`b</td></tr>",true);
	$result = db_query($sql) or die(db_error(LINK));
	if (db_num_rows($result)==0){
  		output("<tr><td colspan=4 align='center'>`&`iThere are no couples in this land`i`0</td></tr>",true);
	}
	for ($i=0;$i<db_num_rows($result);$i++){
    		$row = db_fetch_assoc($result);
		$sql2 = "SELECT name FROM accounts WHERE acctid=".$row[marriedto]."";
		$result2 = db_query($sql2) or die(db_error(LINK));
    		$row2 = db_fetch_assoc($result2);
  		output("<tr class='".($i%2?"trlight":"trdark")."'><td>`&$row2[name]`0</td><td>`) and `0</td><td>`&",true);
		output("$row[name]`0</td></tr>",true);
	}
	output("</table>",true);
} else
end of gardenflirt
*/

 if ($_GET[op]=="reichtum"){
	$sql = "SELECT name,goldinbank,gold FROM accounts WHERE locked = 0 ORDER BY goldinbank+gold DESC";
	output("`c`b`^The richest warriors of this land`b`c`0`n");
	output("<table cellspacing=0 cellpadding=2 align='center'><tr><td>`bRank`b</td><td>`bName`b</td><td>`bEstimated Gold`b</td></tr>",true);
	$result = db_query($sql) or die(db_error(LINK));
	if (db_num_rows($result)==0){
  		output("<tr><td colspan=4 align='center'>`&No players found`0</td></tr>",true);
	}
	for ($i=0;$i<db_num_rows($result) && $i<20;$i++){
    		$row = db_fetch_assoc($result);
		$amt = $row[goldinbank]+$row[gold]+e_rand(0-round($row[goldinbank]*0.05),round($row[goldinbank]*0.05));
		if ($row[name]==$session[user][name]){
	  		output("<tr bgcolor='#007700'>",true);
		} else {
  			output("<tr class='".($i%2?"trlight":"trdark")."'>",true);
		}
  		output("<td>".($i+1).".</td><td>$row[name]</td><td align='right'>$amt gold</td></tr>",true);
	}
	output("</table>`n(Amount +/- 5%)",true);
	$sql = "SELECT name FROM accounts WHERE locked = 0 ORDER BY gems DESC";
	output("`n`n`n`c`b`#Biggest 'Gem'blers`b`c`0`n");
	output("<table cellspacing=0 cellpadding=2 align='center'><tr><td>`bRank`b</td><td>`bName`b</td></tr>",true);
	$result = db_query($sql) or die(db_error(LINK));
	if (db_num_rows($result)==0){
  		output("<tr><td colspan=4 align='center'>`&No players found`0</td></tr>",true);
	}
	for ($i=0;$i<db_num_rows($result) && $i<20;$i++){
    		$row = db_fetch_assoc($result);
		if ($row[name]==$session[user][name]){
	  		output("<tr bgcolor='#007700'>",true);
		} else {
  			output("<tr class='".($i%2?"trlight":"trdark")."'>",true);
		}
  		output("<td>".($i+1).".</td><td>$row[name]</td></tr>",true);
	}
	output("</table>",true);
	addnav("Back to hall of fame","hof.php");
} else if ($_GET[op]=="armut"){
	$sql = "SELECT name,goldinbank,gold FROM accounts WHERE locked = 0 ORDER BY goldinbank+gold ASC";
	output("`c`b`^The poorest warrioirs of this land`b`c`0`n");
	output("<table cellspacing=0 cellpadding=2 align='center'><tr><td>`bRank`b</td><td>`bName`b</td><td>`bEstimated Gold`b</td></tr>",true);
	$result = db_query($sql) or die(db_error(LINK));
	if (db_num_rows($result)==0){
  		output("<tr><td colspan=4 align='center'>`&No players found`0</td></tr>",true);
	}
	for ($i=0;$i<db_num_rows($result) && $i<20;$i++){
		$tma=$amt;
    		$row = db_fetch_assoc($result);
		$amt = $row[goldinbank]+$row[gold]+e_rand(0-round($row[goldinbank]*0.05),round($row[goldinbank]*0.05));
		if ($amt<0) $amt="`\$".$amt;
		if ($amt==$tma && $tma=="0") $i--;
		if ($row[name]==$session[user][name]){
	  		output("<tr bgcolor='#007700'>",true);
		} else {
  			output("<tr class='".($i%2?"trlight":"trdark")."'>",true);
		}
  		output("<td>".($i+1).".</td><td>$row[name]</td><td align='right'>$amt gold`0</td></tr>",true);
	}
	output("</table>`n(Amount +/- 5%)",true);
	addnav("Back to hall of fame","hof.php");
} else if ($_GET[op]=="nice"){
	$sql = "SELECT name,sex,race FROM accounts WHERE locked = 0 ORDER BY charm DESC";
	output("`c`b`%Most beautiful warrioirs`b`c`0`n");
	output("<table cellspacing=0 cellpadding=2 align='center'><tr><td>`bRank`b</td><td>`bName`b</td><td>`bGender`b</td><td>`bRace`b</td></tr>",true);
	$result = db_query($sql) or die(db_error(LINK));
	if (db_num_rows($result)==0){
  		output("<tr><td colspan=4 align='center'>`&No players found`0</td></tr>",true);
	}
	for ($i=0;$i<db_num_rows($result) && $i<20;$i++){
    		$row = db_fetch_assoc($result);
		if ($row[name]==$session[user][name]){
	  		output("<tr bgcolor='#007700'>",true);
		} else {
  			output("<tr class='".($i%2?"trlight":"trdark")."'>",true);
		}
		output("<td>".($i+1).".</td><td>$row[name]</td><td align='center'>".($row[sex]?"`!Female`0":"`!Male`0")."</td><td>",true);
		output("".$races[$row[race]]."</td></tr>",true);
	}
	output("</table>",true);
	addnav("Back to hall of fame","hof.php");
} else if ($_GET[op]=="stark"){
	$sql = "SELECT name,level,race FROM accounts WHERE locked = 0 ORDER BY maxhitpoints DESC";
	output("`c`b`\$The strongest warrioirs of this world`b`c`0`n");
	output("<table cellspacing=0 cellpadding=2 align='center'><tr><td>`bRank`b</td><td>`bName`b</td><td>`bRace`b</td><td>`bLevel`b</td></tr>",true);
	$result = db_query($sql) or die(db_error(LINK));
	if (db_num_rows($result)==0){
  		output("<tr><td colspan=4 align='center'>`&No players found`0</td></tr>",true);
	}
	for ($i=0;$i<db_num_rows($result) && $i<20;$i++){
    		$row = db_fetch_assoc($result);
		if ($row[name]==$session[user][name]){
	  		output("<tr bgcolor='#007700'>",true);
		} else {
  			output("<tr class='".($i%2?"trlight":"trdark")."'>",true);
		}
  		output("<td>".($i+1).".</td><td>$row[name]</td><td>",true);
		output("".$races[$row[race]]."</td><td>$row[level]</td></tr>",true);
	}
	output("</table>",true);
	addnav("Back to hall of fame","hof.php");
} else if ($_GET[op]=="tot"){
	$sql = "SELECT name,level FROM accounts WHERE locked = 0 ORDER BY resurrections DESC";
	output("`c`b`)The clumsiest warriors of this land`b`c`0`n");
	output("<table cellspacing=0 cellpadding=2 align='center'><tr><td>`bRank`b</td><td>`bName`b</td><td>`bLevel`b</td></tr>",true);
	$result = db_query($sql) or die(db_error(LINK));
	if (db_num_rows($result)==0){
  		output("<tr><td colspan=4 align='center'>`&No players found`0</td></tr>",true);
	}
	for ($i=0;$i<db_num_rows($result) && $i<20;$i++){
    		$row = db_fetch_assoc($result);
		if ($row[name]==$session[user][name]){
	  		output("<tr bgcolor='#007700'>",true);
		} else {
  			output("<tr class='".($i%2?"trlight":"trdark")."'>",true);
		}
  		output("<td>".($i+1).".</td><td>$row[name]</td><td>$row[level]</td></tr>",true);
	}
	output("</table>",true);
	addnav("Back to hall of fame","hof.php");
} else {
	$sql = "SELECT name,dragonkills,level,dragonage,bestdragonage FROM accounts WHERE dragonkills > 0 ORDER BY dragonkills DESC,level DESC,experience DESC";
	output("`c`b`&Heros of this world`b`c`n");
	output("<table cellspacing=0 cellpadding=2 align='center'><tr><td>`bRank`b</td><td>`bName`b</td><td>`bKills`b</td><td>`bLevel`b</td><td>&nbsp;</td><td>`bDays`b</td><td>&nbsp;</td><td>`bBest Days`b</td></tr>",true);
	$result = db_query($sql) or die(db_error(LINK));
	if (db_num_rows($result)==0){
  		output("<tr><td colspan=4 align='center'>`&No heros in this world`0</td></tr>",true);
	}
	for ($i=0;$i<db_num_rows($result);$i++){
    		$row = db_fetch_assoc($result);
		if ($row[name]==$session[user][name]){
	  		output("<tr bgcolor='#007700'>",true);
		} else {
  			output("<tr class='".($i%2?"trlight":"trdark")."'>",true);
		}
  		output("<td>".($i+1).".</td><td>$row[name]</td><td>$row[dragonkills]</td><td>{$row['level']}</td><td>&nbsp;</td><td>".($row[dragonage]?$row[dragonage]:"unknown")."</td><td>&nbsp;</td><td>".($row[bestdragonage]?$row[bestdragonage]:"unknown")."</td></tr>",true);
	}
	output("</table>",true);
	addnav("Top 20");
	addnav("Richest","hof.php?op=reichtum");
	addnav("Poorest","hof.php?op=armut");
	addnav("Strongest","hof.php?op=stark");
	addnav("Most beautiful","hof.php?op=nice");
	addnav("Clumsiest","hof.php?op=tot");
	addnav("Other");
//	addnav("Couples","hof.php?op=paare"); // part of gardenflirt
}
addnav("Back to the Village","village.php");
page_footer();
?>