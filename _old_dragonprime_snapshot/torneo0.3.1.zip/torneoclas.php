<?php

/* This file is part of "The Tournament"
* made by Excalibur, refer to torneo.php
* for instructions and copyright notice */

$livello['1'] = "uno";
$livello['2'] = "due";
$livello['3'] = "tre";
$livello['4'] = "quattro";
$livello['5'] = "cinque";
$livello['6'] = "sei";
$livello['7'] = "sette";
$livello['8'] = "otto";
$livello['9'] = "nove";
$livello['10'] = "dieci";
$livello['11'] = "undici";
$livello['12'] = "dodici";
$livello['13'] = "tredici";
$livello['14'] = "quattordici";
$livello['15'] = "quindici";

require_once "common.php";
page_header("Tournament Score");
addnav("V?`@Back to Village","village.php");
addnav("G?`#General Score","torneoclas.php?op=generale");
addnav("L?`%Score for each Level","torneoclas.php?op=livello");
if ($HTTP_GET_VARS[op]=="") {
	output("<font size='+1'>`c`b`!Great LoGD Tournament's Classifications`b`c`n`n</font>",true);
	output("`6Welcome to `@Great LoGD Tournament's 'Classification's`6. This is the place where you can view different ");
	output("kind of tables. One of this is the `@General Classication`6, where are shown players actually busy to reach ");
	output("the first places with shown their total points and the number of trial played till now, or you can choose ");
	output("to view the classification for every single trial played, where you can see who's best scored in that trial. ");
	output("Choose a Classification`n");
}
if ($HTTP_GET_VARS[op]=="generale") {
	output("<font size='+1'>`c`b`!LoGD Tournament's General Classification`b`c`n`n</font>",true);
	$sql = "SELECT name,torneo,torneopoints,superuser FROM accounts WHERE torneo > 0 AND superuser = 0 ORDER BY torneo DESC";
    output("`c`b`&LoGD Tournament's General Classification`b`c`n");
    output("<table cellspacing=0 cellpadding=2 align='center'><tr><td></td><td align='center'>`bName`b</td><td align='center'>`bScore`b</td><td align='center'>`bN� of Trials`b</td></tr>", true);
    $result = db_query($sql) or die(db_error(LINK));
    if (db_num_rows($result) == 0) {
        output("<tr><td colspan=4 align='center'>`&Nobody has signed for the Tournament`0</td></tr>", true);
    } 
    for ($i = 0;$i < db_num_rows($result);$i++) {
        $row = db_fetch_assoc($result);
        $row[torneopoints]=unserialize($row[torneopoints]);
		if ($row[name] == $session[user][name]) {
        	output("<tr bgcolor='#007700'>", true);
        } else {
            output("<tr class='" . ($i % 2?"trlight":"trdark") . "'>", true);
        } 
		 $prove=count($row[torneopoints])/2;
		  output("<td>" . ($i + 1) . ".</td><td>$row[name]</td><td align='right'>$row[torneo]</td><td align='center'>$prove</td></tr>", true);
	} 
    output("</table>", true);
}
if ($HTTP_GET_VARS[op]=="livello" && $HTTP_GET_VARS[op1]==""){
	output("<font size='+1'>`c`b`!Level Classification of LoGD Tournament`b`c`n`n</font>",true);
	for ($i=1; $i<16; $i++){
	addnav("`\$Level $i","torneoclas.php?op=livello&op1=".$i);
	}
}
if ($HTTP_GET_VARS[op]=="livello" && $HTTP_GET_VARS[op1]!=""){
	$arr=array();
	$sql = "SELECT name,torneo,torneopoints,superuser FROM accounts WHERE torneo > 0 AND superuser = 0";
	$result = db_query($sql) or die(db_error(LINK));
	$k=1;
	$z=db_num_rows($result);
	for ($i = 0;$i < $z ;$i++){
		$row = db_fetch_assoc($result);
		$row[torneopoints]=unserialize($row[torneopoints]);
		$convers=array();
		//print_r($row[torneopoints]);
		for ($ii = 0; $ii < count ($row[torneopoints]); $ii += 2) {
			if (isset ($row[torneopoints][$ii]) && isset ($row[torneopoints][$ii + 1])) {
				$convers[] = array ("punteggio" => $row[torneopoints][$ii],"livello" => $row[torneopoints][$ii + 1]);
			}
		}
		//print_r($convers);
		reset($convers);
		$nome=$row[name];
		foreach ($convers as $key => $row){
			if ($convers[$key]['livello'] == $livello[$HTTP_GET_VARS[op1]]){
				$arr[$k]['punteggio'] = $convers[$key]['punteggio'];
				$arr[$k]['nome'] = $nome;
				$k++;
			}
		}
	}
	arsort($arr);
	reset($arr);
	output("<font size='+1'>`c`b`!Level $HTTP_GET_VARS[op1] Classification of LoGD Tournament`b`c`n`n</font>",true);
	output("<table cellspacing=0 cellpadding=2 align='center'><tr><td></td><td align='center'>`bName`b</td><td align='center'>`bScore`b</td></tr>", true);
    
	foreach ($arr as $key => $row) {
	if ($arr[$key]['nome'] == $session[user][name]) {
		output("<tr bgcolor='#007700'>", true);
	} else {
		output("<tr class='" . (($key+1) % 2?"trlight":"trdark") . "'>", true);
		}
	output("<td>" . ($key) . ".</td><td>{$arr[$key]['nome']}</td><td align='right'>{$arr[$key]['punteggio']}</td></tr>", true);
	$flag=1;
	}
	if (!$flag) {
		output("<tr><td colspan=4 align='center'>`&Nobody has played this level yet`0</td></tr>", true);
		}
	output("</table>", true);
}
page_footer();
?>