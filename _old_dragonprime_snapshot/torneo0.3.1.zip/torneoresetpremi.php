<?
/* This file is part of "The Tournament"
* made by Excalibur, refer to torneo.php
* for instructions and copyright notice */

require_once "common.php";
page_header("Reset Tournament's Table");
if ($HTTP_GET_VARS[op]==""){
	output("`\$`n`n`c<font size='+1'>ATTENTION !!! You are about to reset the Tournament Table.`n",true);
	output("Are you 100% sure ?</font>`c",true);
	addnav("G?`#Back to Grotto","superuser.php");
	addnav("M?`@Back to Mundanity","village.php");
	addnav("R?`\$Reset Table","torneoresetpremi.php?op=azzera");
	addnav("C?`^Give Prizes","torneoresetpremi.php?op=premi");
}
if ($HTTP_GET_VARS[op]=="azzera"){
	output("`@<font size='+1'>`c`n`nThis is your last chance. `nBehind this point you can't go back.`n",true);
	output("`\$Are you REALLY sure to reset the Tournament Table ?`c</font>",true);
	addnav("G?`#Back to Grotto","superuser.php");
	addnav("M?`@Back to Mundanity","village.php");
	addnav("R?`\$Reset Table","torneoresetpremi.php?op=sicuro");
} 

if ($HTTP_GET_VARS[op]=="sicuro"){
	$session['user']['torneopoints']=0;
	$session['user']['torneopoints']="";
	$sql="UPDATE accounts SET torneo='0',torneopoints=''";
	db_query($sql);
	if (db_affected_rows()>0){
		output("`^Row Modified: ". db_affected_rows()." !");
	}else{
		output("`#Table not revised: $sql");
	}
	addnav("G?`#Back to Grotto","superuser.php");
	addnav("M?`@Back to Mundanity","village.php");
	output("`n`@Tournament's Table resetted !!");
}
if ($HTTP_GET_VARS[op]=="premi"){
    
	output("`c`b`&The Giveaways of Prizes of the Big Tourney of LoGD`b`c`n");
    $sql = "SELECT acctid,name,gems,goldinbank,torneo FROM accounts WHERE torneo > 0  ORDER BY torneo DESC LIMIT 3";
	$result = db_query($sql) or die(db_error(LINK));
    if (db_num_rows($result) == 0) {
		output("`c`&No Player has joined the Tourney`0`c");
	} 
    for ($i = 0;$i < db_num_rows($result);$i++) {
        $row = db_fetch_assoc($result);
        if ($i==0){
		$account=$row[acctid];
		$oro=$row[goldinbank]+10000;
		$gemme=$row[gems]+10;
		output("`^$row[name] has $row[gems] gems and $row[goldinbank] gold in bank `n");
		addnews("`#$row[name] `#has classified `^1� place`# in `@Tournament`#.`n
		`#$row[name] `#has gained `^10 gems`# e `&10.000 gold !!"); 
		}else if ($i==1){
		$account=$row[acctid];
		$oro=$row[goldinbank]+8000;
		$gemme=$row[gems]+8;
		output("`#$row[name] has $row[gems] gems e $row[goldinbank] gold in bank `n");
		addnews("`#$row[name] `#has classified `^2� place`# in `@Tournament`#.`n
		`#$row[name] `#si � aggiudicat".($row[sex]?"a":"o")." `^8 gemme`# e `&8.000 pezzi d'oro !!"); 
		}else if ($i==2){
		$account=$row[acctid];
		$oro=$row[goldinbank]+5000;
		$gemme=$row[gems]+5;
		output("`@$row[name] has $row[gems] gems e $row[goldinbank] gold in bank `n");
		addnews("`#$row[name] `#has classified `^3� place`# in `@Tournament`#.`n
		`#$row[name] `#has gained `^5 gems`# e `&5.000 gold !!"); 
		}
		$sql = "UPDATE `accounts` SET `gems` = $gemme WHERE `acctid` = $account";
		$result1=db_query($sql);
		$sql = "UPDATE `accounts` SET `goldinbank` = $oro WHERE `acctid` = $account";
		$result2=db_query($sql);
		output("{$row[name]} ha adesso $gemme gemme e $oro pezzi d'oro. `n`n");
		}
		addnav("G?`#Back to Grotto","superuser.php");
		addnav("M?`@Back to Mundanity","village.php");
		addnav("A?`^Reset Tourney","torneoresetpremi.php");
		output("`n`\$`bPrizes given !!`b");
	}
page_footer();
?>