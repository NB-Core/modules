<?php
/*
* The Tournament v0.3
* by Excalibur for OGSI (www.ogsi.it)
* excalthesword@fastwebnet.it
* English version by Talisman (http://dragonprime.cawsquad.net)
* Code Optimization: Talisman
*  you can modify it, but leave this note

----- SQL
You have to add 2 fields in 'accounts' table:

ALTER TABLE `accounts` ADD `torneo` INT( 4 ) DEFAULT '0' NOT NULL ; 
ALTER TABLE `accounts` ADD `torneopoints` TEXT NOT NULL ; 

-----
Put an entry point in your village or somewhere else. I have
a Castle named Castel Excalibur where I've put the addnav to get to
tournament and score:

addnav("T?`^Tournament","torneo.php");
addnav("C?`^Tournament Score","torneoclas.php");

----- Open:
 superuser.php

----- Add:

addnav("Reset Tournament","azzeratorneo.php");

----- Open:
common.php

----- Find:
if (is_array($session[user][dragonpoints])) $session[user][dragonpoints]=serialize($session[user][dragonpoints]);

----- After, add:
if (is_array($session[user][torneopoints])) $session[user][torneopoints]=serialize($session[user][torneopoints]);

----- Find:
$session[user][dragonpoints]=unserialize($session[user][dragonpoints]);

----- After, add:
$session[user][torneopoints]=unserialize($session[user][torneopoints]);
if (!is_array($session[user][torneopoints])) $session[user][torneopoints]=array();

----- Open:
dragon.php

----- Find:
,"beta"=>1

----- After, add:
,"torneo"=>1
,"torneopoints"=>1

----- Upload:
torneo.php
torneo2.php
azzeratorneo.php
torneoclass.php 
*/

require_once "common.php";
page_header("The Tournament");
output("`b`!The LoGD Tournament`0`b`n`n",true);
if ($session['user']['torneo']==0 AND $HTTP_GET_VARS[op]==""){

    output("`3You walk into a dimly lit office and peer around at it's sparsely furnished interior. ");
    output("`3As your eyes adjust to the light, you notice a tall warrior appraising you.`n `n ");
    output("`^I am Sir Tristan, Tournament Master, `3he informs you. `^You might not be the mightiest warrior I've seen...but yet...I sense potential within you. ");
    output("`bDo you think you have what it takes to win my `!Grand Tournament`^?`b`n`n");
    output("The entrance fee is `b`^500 Gold pieces`b and `b`&1 Gem`b`^.`n `n");
    output("The mightiest warriors will receive riches in reward for their efforts:`n`n");
    output("<font size='+1'>`b`c`&First Place: 10 Gems - 10,000 Gold Pieces`n",true);
    output("`@Second Place:  8 Gems -  8,000 Gold Pieces`n",true);
    output("`^Third Place:  5 Gems -  5,000 Gold Pieces`b`c`n`n</font>",true);
    output("`^Why not take a chance and enter? Are ye strong enough? Powerful enough? If ye have what it takes, Victory may be yours!`n ");
    output("`n`3Please note that everybody has an equal chance - it matters not how many dragons ye've slain!`n ",true);

    addnav("Y?`@Yes, Enter the Tournament","torneo.php?op=enter");
    addnav("N?`\$No, Return to the Village","village.php");
}    elseif ($session['user']['torneo']!=0){
        output("`3You walk into a dimly lit office and peer around at it's sparsely furnished interior. ");
        output("`3Sir Tristan welcomes you. `^Welcome, competitor. You have paid the entrance fee and may continue onwards to the Tournament Arena.");
        addnav("T?`@Enter the Tournament Arena","torneo2.php");
        addnav("V?`#Return to the Village","village.php");
    }
        elseif($HTTP_GET_VARS[op]=="enter" AND $session['user'][gems]>0 AND $session['user'][gold]>499){
            output("`3Sir Tristan breaks into a toothy grin.`n`n `^Excellent! You have chosen to enter the Tournament. You must face a challenge, at each level of your training.`n");
            output("For each challenge, you will receive a number of points.  Whoever attains the highest score at the end of the tournament collects the prizes.`n`n");
        output("`^`bGood Luck to Ye!`b`n ");
            //$session[user][torneopoints]=array();
            //$session['user']['torneopoints']['0']="zero";
            $session['user']['gems']-=1;
            $session['user']['gold']-=500;
            $session['user']['torneo']=1;
            addnav("V?`^Enter the Tournament Arena","torneo2.php");
        }    else{
                output("`3Sir Tristan glares at you.`n`n`^ What do ye think I run here?  A charity?  Ye do not have enough gold and gems for the Entrance Fee.`n");
        output("`^Get out of my office, you dishonourable swine!`n`n ");
                output("`^`bDon't waste my time until you can afford the paltry sum required to enter!`b");
                addnav("V?`3Return to the Village","village.php");        
            }
page_footer();
?>
