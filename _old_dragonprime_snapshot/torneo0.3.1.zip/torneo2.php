<?php
/* This file is part of "The Tournament"
* made by Excalibur, refer to torneo.php
* for instructions and copyright notice */


$levels['1'] = "one";
$levels['2'] = "two";
$levels['3'] = "three";
$levels['4'] = "four";
$levels['5'] = "five";
$levels['6'] = "six";
$levels['7'] = "seven";
$levels['8'] = "eight";
$levels['9'] = "nine";
$levels['10'] = "ten";
$levels['11'] = "eleven";
$levels['12'] = "twelve";
$levels['13'] = "thirteen";
$levels['14'] = "fourteen";
$levels['15'] = "fifteen";

require_once "common.php";
page_header("The Tournament");
output("<font size='+1>'`b`c`#THE TOURNAMENT`b`c`n`n</font>",true);
$level=$session['user']['level'];
$flag="";

while (list($key, $val) = each($session[user][torneopoints])) {
	if ($val == $levels[$level]) $flag="pippo";
}

addnav("B?`@Back to Village","village.php");
addnav("V?`@View Scores","torneoclas.php");

if ($flag=="pippo"){
output("`3Sir Tristan informs you that your challenge for this level has been completed. `n`^`bCome back when you have more experience!!`b`");
}else{

	$points=e_rand(1,100);
	$resto=100-$points;
	$session['user']['torneo']+=$points;
	$points1=intval($points / 10);
	if ($points1==0) $points1=1;
	array_push($session['user']['torneopoints'],$points, $levels[$level]);

	output("`3Sir Tristan's faithful assistant, Belanthros prepares you for the `^Level $level Challenge.`n`n");
switch ($level) {
	
case 1:
	output("`@Do not underestimate this level, for each is as challenging as the next!! `nBut enough idle chatter, let's get this show on the road!`n`n ");
	output("This challenge is called `%`bDwarf Tossing`b`@. The further ye throw them, the more points ye earn!`n ");
	output("Have at 'em!!!`n`n");

	for ($i=0; $i<$points; $i++){
		output("`% +");
		}

	switch ($points1) {
		case 1:
		  output("`n`n`@That must be the worst throw I have seen.  `n`n<font size='+1'>`6You have earned a lame $points points!!</font>",true);
		  break;
		case 2: case 3: case 4: case 5:
		  output("`n`n`@Not bad, but I've seen better.  `n`n<font size='+1'>`6You have earned a paltry $points points!!</font>",true);
		  break;
		case 6: case 7: case 8: case 9:
		  output("`n`n`@Nice throw, Warrior.  My compliments to ye.  `n`n<font size='+1'>`6You have earned a respectable $points points!!</font>",true);
		  break;
		case 10:
		  output("`n`n`@Remarkable! You've bested even `!MightyE`@ with a perfect toss!!!`n`n<font size='+1'>`6You have earned the maximum $points points!!</font>",true);
		  output("`n`nYou receive `b1 gem`b as a bonus!!!");
		  $session['user']['gems']+=1;
		break;
	}break;
	
case 2:
	output("`@This challenge will push you to the extremes of your physical endurance.  Do not think this will be simple.`n ");
	output("You must run.  Aye, run.  Ye must run as far as you possibly can!  You will receive 1 point for each kilometre you run.");
	output("`n`nNow get those feet moving!!!`n`n");
	for ($i=0; $i<$points; $i++){
		output("`% + +");
		}
	switch ($points1) {
		case 1:
		  output("`n`n`@Such a miserable performance!!! Ye consider yourself worthy of this tournament? HA!`nYou have run barely <font size='+1'>`6$points kilometres</font>`@!!",true);
		  output("`n<font size='+1'>`^You accumulate a measily $points points!!</font>",true);
		  break;
		case 2: case 3: case 4: case 5:
		  output("`n`n`@Ye have failed to impress me, I know ye can do better then this. `nYou ran the moderate distance of <font size='+1'>`6$points kilometers</font> `@!!",true);
		  output("`n<font size='+1'>`^You merit only $points points!!</font>",true);
		  break;
		case 6: case 7: case 8: case 9:
		  output("`n`n`@Mhhh, not bad at all, gratz. `n`@You travelled coast to coast, covering <font size='+1'>`6$points kilometers</font>`@!!",true);
		  output("`n<font size='+1'>`6I shall award ye $points well deserved points!!</font>",true);
		  break;
		case 10:
		  output("`n`n`@Most impressive!!!  Should I call ye Forrest Gump, perchance?`nYou realized the goal of running the full <font size='+1'>`6$points kilometers</font> `@of the Challenge!!",true);
		  output("`n<font size='+1'>`6You shall receive a perfect score of $points points!!</font>",true);
		  output("`n`^You also gain `b1 gem`b as bonus!!!");
		  $session['user']['gems']+=1;
		  break;
	}break;
	
case 3:
	output("`@This challenge is not physically demanding, rather it is a test of your skill at arms and accuracy.`n");
	output("Ye must fire five bolts from this crossbow, hitting the target 100 yards away.  `n");
	output("A Bullseye counts for 20 points. The best possible score is 100 points.`n");
	output("Can ye match the perfect score set by our sharpshooter, `bFarmboy Saruman`b??`n`n");
	for ($z=1; $z<6; $z++){
		output("`!Shot # $z ");
		for ($i=0; $i<e_rand(0,$points1); $i++){
		 	output("`% + +");
		}
	 	output("`n");
	}	
	switch ($points1) {
		case 1:
		  output("`n`n`@Mark yer target next time, not the cat!!! I've seen goblins shoot better then that!`nOnly one struck near the right target! `nYou have scored only <font size='+1'>`6$points points!!</font>",true);
		  break;
		case 2: case 3: case 4: case 5:
		  output("`n`n`@Well, ye've shot 3 arrows in the right direction, but I know ye can do better. `n<font size='+1'>`6You receive $points points!!</font>",true);
		  break;
		case 6: case 7: case 8: case 9:
		  output("`n`n`@Mhhh, not bad at all, compadre. `n`@It looks like one of your 4 accurate shots found the Bullseye. `n<font size='+1'>`6I shall give ye $points points!!</font>",true);
		  break;
		case 10:
		  output("`n`n`@Bravisimo!  A perfect score!!!  Are you related to Robin Hood?`n");
		  output("<font size='+1'>`6`bYou shall receive $points points and 1 gem!!!`b</font>",true);
		  $session['user']['gems']+=1;
		  break;
	}break;

case 4:
	output("`@Mastery of the long bow is a difficult goal to achieve, but ye had best have it if you hope to win this challenge. ");
	output("`nYour accuracy will be judged on how expertly you fire five arrows into yonder target.");
	output("`nYou will receive points for each strike, with the BullsEye worth 20 points. ");
	output("`nGo now, and show me that you are as skilled as `^Aris!!`n`n");

	for ($z=1; $z<6; $z++){
		output("`!Shot # $z ");
		for ($i=0; $i<e_rand(0,$points1); $i++){
		 	output("`% + +");
		}
	 	output("`n");
	}	
	switch ($points1) {
		case 1:
		  output("`n`n`@What are ye waiting for?  You may begin!!! `nWait...you've already shot?  Pathetic!!!");
		  output("`n<font size='+1'>`6These meager $points points will do little for ye!!</font>",true);
		  break;
		case 2: case 3: case 4: case 5:
		  output("`n`n`@Hardly a noteworthy effort, my friend, but I have seen much worse. `n <font size='+1'>`6Be thankful for the $points points you've received!!</font>",true);
		  break;
		case 6: case 7: case 8: case 9:
		  output("`n`n`@Splendid shooting, amigo!!! `n<font size='+1'>`6Including that bullseye, I count $points points for you!!</font>",true);
		  break;
		case 10:
$nam=$session['user']['name'];
  		  output("`n`n`@Ye have truly shown the skill of `#Aris`@!! Are ye sure your name is really $nam??`n");
		  output("<font size='+1'>`6Five arrows, five Bullseyes!!! $points points and `i`bone bonus Gem`b`i for you!",true);
		  $session['user']['gems']+=1;
		  break;
	}break;
	
case 5:
	output("`@You are doing well to make it this far, my friend.  You have worked hard and deserve some refreshment.`n ");
	output("Have a seat...right over there.  Make yourself comfortable.  Would ye care for some ale?  `nLet me get ye some of Cedrick's finest.`n");
	output("`nNow...ye didn't think it would be THIS easy, did ye?  Of course ye didn't - ye know me better by now.");
	output("`nThis is a competition, one which now tests your constitution!  How much of this ale can ye stomach???`nWell, I'll tell ye now...ye get 5 points for each mug ye down.  Can ye match Cedrick's own record of 20??`n`n`c");
	for ($z=0; $z<5; $z++){
		for ($i=0; $i<e_rand(0,$points1); $i++){
		output("`6 + +");
		}
	output("`n");
	}	
	switch ($points1) {
		case 1:
		  output("`c`n`n`@Hey!!! Whatsa matter with you?  Got a hole in your lip?  More ale went on the table than your mouth.`n<font size='+1'>`6I can only let ye have $points points for that pathetic performance.</font>",true);
		  break;
		case 2: case 3: case 4: case 5:
		  output("`c`n`n`@Nice try, but hardly a worthwhile effort, young friend. That would be but a warmup for Cedrick!`n<font size='+1'>`6Ye drank enough mugs to earn $points points!!</font>",true);
		  break;
		case 6: case 7: case 8: case 9:
		  output("`c`n`n`@My compliments on a valiant effort, although ye are certainly no competition for Cedrick. `n<font size='+1'>`6Eighteen mugs, minus the spillage, adds $points points to your score!!</font>`n",true);
		  break;
		case 10:
		  output("`c`n`n`@Amazing!  You must be Cedrick's ".($session[user][sex]?"sister":"brother")."! `n");
		  output("<font size='+1'>`6Ye drank all 20 mugs, and nary spilled a drop! Ye truly deserve these $points points!!</font>",true);
		  output("`n`^Ye also receive `b1 gem`b as a bonus!!!");
		  $session['user']['gems']+=1;
		  break;
	}break;
	
case 6:
	output("`@Ye're fast nearing the halfway mark, my friend. It is now that champions begin to separate themselves from the 'also rans', and show their true mettle. ");
	output("Ye must have worked up an appetite after the runs and beer drinking, aye?");
	output("Cedrik suggested some `b`7Smoked Herrings`&`b`@ might now hit the spot.`n`n");
	output("The one who is able to scarf the most herrings will earn points and the title of `\$Smoked Herring Scarfer of the Year`b`@. `nThe champion of our village is `b`#Luke`b`@, who managed to wolf down 99 smoked herring.`n`n");

	for ($z=0; $z<5; $z++){
		for ($i=0; $i<e_rand(0,$points1); $i++){
		output("`7 + +");
		}
	output("`n");
	}	
	switch ($points1) {
		case 1:
		  output("`n`n`@Ye should have said ye were allergic to seafood!!! `n<font size='+1'>`6You have eaten only $points herrings!!</font>",true);
		  break;
		case 2: case 3: case 4: case 5:
		  output("`n`n`@Bah!  I've seen better lately...did the ale fill ye? `n<font size='+1'>`6 You have eaten $points smoked herring!!</font>",true);
		  break;
		case 6: case 7: case 8: case 9:
		  output("`n`n`@Mhhh, you could give even Luke a run for his money, my compliments. `n`@I see you have left only $resto herrings on the table.`n<font size='+1'>`6You have earned $points points!!</font>",true);
		  break;
		case 10:
		  output("`n`n`@Wow, we have a new champion in the village!! You destroyed `#Luke's`@ record!!`n");
		  output("`@You have scarfed all 100 herring, mastering this challenge. `n<font size='+1'>`6You have earned $points points!!</font>",true);
		  output("`n`^You also recieve a bonus gem`b!!!");
		  $session['user']['gems']+=1;
		  break;
	}break;

case 7:
	output("`@Ye've now reached the halfway point in our competition, and are about to meet my favorite challenge.");
	output("With the herring and ale of the last two trials your stomach must be churning. Do you already feel the pressure of the gas trying to escape?  Well don't let it out yet!!`n");
	output("In this challenge, whoever produces the `b`7longest belch`@`b will receive the highest score. But be careful that ALL ye do is belch - I don't wish to see the ale or herring again!!!`n`n");
	output(" The one and only champion of this trial is our quiet fellow-citizen `!`bHutgard`b`@ with 99 seconds.");
	output("Hmmm, that dull rumble I hear tells me I'd better stop talking and let ye start belching!!!`n`n");

	for ($z=0; $z<5; $z++){
		for ($i=0; $i<e_rand(0,$points1); $i++){
		output("`6 * *");
		}
	output("`n");
	}	
	switch ($points1) {
		case 1:
		  output("`n`n`@You call that a belch??  That wasn't even a hiccup, let alone a burp!!! `n<font size='+1'>`6Your so called belch lasted only $points seconds!!</font>",true);
		  break;
		case 2: case 3: case 4: case 5:
		  output("`n`n`@A good start, but no follow through! `n<font size='+1'>`6You belched for $points seconds!!!</font>",true);
		  break;
		case 6: case 7: case 8: case 9:
		  output("`n`n`@Saaayyyy...not bad...not bad at all!  Ye knocked out 30 farmies with that one!!!. `n<font size='+1'>`6Your belch earns ye a total of $points points!!!</font>",true);
		  break;
		case 10:
		  output("`n`n`@I would not have thought it possible, but ye've obliterated all traces of `#Hutgard's`@ record!!`n");
		  output("`@A full barrack of troops is unconcious, ye've broken every window in the village and neighbouring villages have reported minor earth tremors!!!`n ");
		  output("<font size='+1'>`6Your efforts warrant $points points and `b1 gem`b as bonus!!!</font>",true);
		  $session['user']['gems']+=1;
		  break;
	}break;
	
case 8:
	output("`@Ye still walk amongst the living, `b".$session['user']['name']."`b? Unexpected, but tis grand to see!  Sadly, we are not done with ye yet.`n");
	output("Between the herring, beer and belches of the last few challenges, how would ye feel about a good rest?  From the look on your face, I suspect you are eager for a good sleep!`n");
	output("Well...I hope we've tired ye enough that ye may win this challenge by sleeping the longest of any competitor.  Ye shall earn one point for each hour of sleep.");
	output("Your goal should be to beat our friend `!`bDankor's`b`@ record of 99 hours of uninterrupted sleep!! `n`n");

	for ($z=0; $z<5; $z++){
		for ($i=0; $i<e_rand(0,$points1); $i++){
		output("`7 z z");
		}
	output("`n");
	}	
	switch ($points1) {
		case 1:
		  output("`n`n`@Terrible, TERRIBLE!!! This is one ocassion where time spent sleeping would not be wasted time.`n<font size='+1'>`6Sadly, you slept for only $points hours!!</font>`n",true);
		  break;
		case 2: case 3: case 4: case 5:
		  output("`n`n`@Well, I don't think ye need to worry about anyone calling ye 'Sleepy Head'. `n<font size='+1'>`6Ye slept for $points hours!!</font>",true);
		  break;
		case 6: case 7: case 8: case 9:
		  output("`n`n`@Mhhh, nice, really!  Ye could consider yerself kin to Rumplestiltskin! `n<font size='+1'>`6Your nap lasted for $points hours!!</font>",true);
		  break;
		case 10:
		  output("`n`n`^Amazing, a new champion in the village!! Your laziness has surpassed even `#Dankor's`@ long sleep with `b100 hours`b!!`n");
		  output("`@Your sleeping rivals that of `#Sleeping Beauty`@...although I fear ye not be quite as beautiful as she was rumoured to be!!! ");
		  output("<font size='+1'>`6You have earned $points points!!!</font>",true);
		  output("`nYou also gain `b1 gem`b as bonus!!!");
		  $session['user']['gems']+=1;
		  break;
	}break;

case 9:
	output("`@This next challenge is directly related to the last one; in fact, you completed it at the same time you were sleeping in the previous challenge. Surprised?  Well, it's quite simple really. Ye see, we measured the decibel level of your snoring, and awarded you one point per decibel.`n");
	output("The loudest snoring in memory was that of `b`!CMT`b`@, at an amazing 99 decibels - louder than the dying dragon's roar!`nNow let me check to see if ye've done better than that...`n`n ");
	for ($z=0; $z<5; $z++){
		for ($i=0; $i<e_rand(0,$points1); $i++){
		output("`7 Z Z");
		}
	output("`n");
	}
	switch ($points1) {
		case 1:
		  output("`n`n`@Noooooo, that is one of the worst performances I've never heard!!! `n<font size='+1'>`6You have reached only $points decibels!!!</font>`n",true);
		  output("`@Don't you know that blowing your nose before going to bed makes it harder to get good `isound`i?`n");
		  break;
		case 2: case 3: case 4: case 5:
		  output("`n`n`@What can I say, you managed to wake your ".($session[user][sex]?"husband":"wife")." from slumber beside you, but made little impact beyond that. `n<font size='+1'>`6You peaked at $points decibels!!!</font>",true);
		  break;
		case 6: case 7: case 8: case 9:
		  output("`n`n`#Mhhh, not that bad, really. `#You woke the whole neighbourhood with your snoring! `n<font size='+1'>`6A measure of $points decibels earns ye $points points!!</font>",true);
		  break;
		case 10:
		  output("`n`n`@My goodness! We have a new champion - You smashed the old record held by `#CMT`@ with `b100 decibels`b!!`n");
		  output("`@We could use your snoring instead of explosives to demolish enemy fortresses!!!! ");
		  output("`n<font size='+1'>`6You have earned $points points and `b1 bonus gem`b!!!</font>",true);
		  $session['user']['gems']+=1;
		  break;
	}break;

case 10:
	output("`@H-Hey, `b".$session['user']['name']."`b!!!  I've got something you need, right here - 100 rubber bands.`n`nNow, ye might be wondering why ye might need 100 rubber bads? We-e-ell, I'm glad ye asked!`n");
	output("As you well know, the Garden Gnomes don't keep the forest as tidy as they should, and allow water to stagnate, thus allowing the proliferation of mosquitoes.`n`n");
	output("Your challenge is to wipe out as many mosquitoes as ye can with those rubber bands. A perfect score will see ye crowned as `#King of Rubber Bands'`@ in place of `b`#OberonGloin`b`@, the current 'King'.`n`n");
	for ($z=0; $z<5; $z++){
		for ($i=0; $i<e_rand(0,$points1); $i++){
		output("`6 o o");
		}
	output("`n");
	}	
	switch ($points1) {
		case 1:
		  output("`n`n`@Noooooo, ye're a terrible shot with those bands, and the Mosquitos thank you!!!`n");
		  output("<font size='+1'>`^You have scored only $points points!!</font>`n",true);
		  output("`@As ye seem to be on the mosquito's side, tell me...are ye `\$Nosferatu's`@ relative ???`n");
		  break;
		case 2: case 3: case 4:
		  output("`n`n`@Ye seem rather fond of those mosquitoes, judging by your low kill ratio.  Don't tell me...is your favorite drink a`$ Bloody Mary`@?`n");
		  output("<font size='+1'>`6You have earned only $points points!!</font>",true);
		  break;
		case 5: case 6: case 7: case 8: case 9:
		  output("`n`n`@Mhhh, you're a sharpshooter with those elastics! `@The mosquitos are learning to stay away from ye.");
		  output("`n<font size='+1'>`6With $points dead mosquitoes, you earn $points points!!</font>",true);
		  break;
		case 10:
		  output("`n`n`@Well now, I think I shall dub thee `3Rubber Hood`@ in recognition of your outstanding aim!! You have beat the record of `#OberonGloin`@ with `b100 hits`b !! ");
		  output("`@The adjacent villages are ready to contract you to assassinate all the mosquitos in their shires!!! ");
		  output("`n<font size='+1'>`6You have earned $points points and `b1 gem`b!!</font>",true);
		  $session['user']['gems']+=1;
		  break;
	}break;

case 11:
	output("`@My good friend `3`bMerick`b`@ has asked of favour of me, and I think it would make for a great challenge. ");
	output("Only `3`bMerick`b`@ can truly tame a centaur, but a strong warrior should be able to ride one for some time.  You will have to ride this powerfull beast for as long as ye can, earning a point for each second of your flight. Our champion is `bPoker`b`@, with 99 seconds on it's back. Can ye beat him?? `n`n");
	for ($z=0; $z<5; $z++){
		for ($i=0; $i<e_rand(0,$points1); $i++){
		output("`% <^>");
		}
	output("`n");
	}
	switch ($points1) {
		case 1:
		  output("`n`n`@You better stick to cleaning the stables!!!  You stuck to that centaur like `6`bGrog`b`@ does to soap!`n");
		  output("<font size='+1'>`6Your ride only lasted $points seconds!!</font>`n",true);
		  break;
		case 2: case 3: case 4:
		  output("`n`n`@Forget about that career as a wrangler, your ride only lasted $points seconds. `n<font size='+1'>`6Anyhow you have earned $points points!!</font>",true);
		  break;
		case 5: case 6: case 7: case 8: case 9:
		  output("`n`n`@Outstanding ride, my friend...ye must have been riding centaurs since ye were knee high to a goblin!!`n<font size='+1'>`6You kept hold on his back for $points seconds!!!</font>",true);
		  break;
		case 10:
		  output("`n`n`@Wow, not even `!Merick`@ stayed as long as you just did!!! You replace `#Poker`@ as the village champion!! `nNow...do ye think ye could tame my wild canary?`n <font size='+1'>`6You receive `b100 points`b and a `bbonus gem`b!!</font>`n", true);
		  $session['user']['gems']+=1;
		  break;
	}break;

case 12:
	output("`@This next challenge is a test of your agility and dexterity.  I have 100 of my favorite friends, the sprytes, who will enter a room with ye.  Your task is to catch as many of them as ye are able, but ye must be careful not to injure them.");
	output("Will you be able to catch as many as did our champion, `%`bKhendra`b`@, who holds the record with 99?`n`n");

	for ($z=0; $z<5; $z++){
		for ($i=0; $i<e_rand(0,$points1); $i++){
		output("`& * * * *");
		}
	output("`n");
	}	
	switch ($points1) {
		case 1:
		  output("`n`n`@Need glasses?  Couldn't see them? Or are those mitts you call hands too clumsy to catch such graceful creatures? `n<font size='+1'>`6Your pathetic score nets you only $points points!!</font>`n",true);
		  break;
		case 2: case 3: case 4:
		  output("`n`n`@Well, you caught $points sprytes.  I guess it could have been worse, but it should have been much better. `n<font size='+1'>`6You have earned $points points!!</font>",true);
		  break;
		case 5: case 6: case 7: case 8: case 9:
		  output("`n`n`@Mhhh, excellent. A a little more effort, and maybe you may have been able to break the old record. `n<font size='+1'>`6You caught $points Sprytes!!!</font>",true);
		  break;
		case 10:
		  output("`n`n`@Bravo!!! You surpassed `#Khendra's`@ old record of 99!!! `n<font size='+1'>`6Ye captured `b$points Sprytes`b. Your legendary performance also nets you `b1 gem`b!!</font>",true);
		  $session['user']['gems']+=1;
		  break;
	}break;

case 13:
	output("`@I wonder, as I look at ye...how do ye like your eggs?  Sunnyside up?...Poached?...Scrambled maybe?  But wait!  Don't tell me...I'll let ye show me.  Here is a bucket of 100 fresh eggs. Ye must toss them, one at a time, into that large frying pan 20 feet away.  Ye shall receive one point for each egg that lands in the pan unbroken.  Careful now!!!`n`n");
	for ($z=0; $z<5; $z++){
		for ($i=0; $i<e_rand(0,$points1); $i++){
		output(" `&(`^0`&) `&(`^X`&)");
		}
	output("`n");
	}	
	switch ($points1) {
		case 1:
		  output("`n`n`@Remind me not to send you for eggs!! I guess you must like yours scrambled and crunchy.`n<font size='+1'>`6You broke all but $points eggs!!!</font>`n",true);
		  break;
		case 2: case 3: case 4:
		  output("`n`n`@If ye help anybody cook a steak and eggs breakfast, I'd recommend you cook the steak and leave the eggs to somebody more skilled.  You broke $resto eggs. `n<font size='+1'>`6Your egg throwing earned you $points points!!!</font>",true);
		  break;
		case 5: case 6: case 7: case 8: case 9:
		  output("`n`n`@Congratulations, except for the $resto broken eggs, you were perfect.  Ok, not quite perfect, but not too bad, either.  `n<font size='+1'>`6You landed $points unbroken eggs!!!",true);
		  break;
		case 10:
		  output("`n`n`@Well done!!! `#Nulla`@ should take some lesson from ye - your perfect score unseated him as village champion!!! `n<font size='+1'>`6Your reward is `b$points points`b and `bone bonus gem`b!!</font>`n",true);
		  $session['user']['gems']+=1;
		  break;
	}break;

case 14:
	output("`@You will now face one of the most difficult challenges of the tournament, that of sword twirling.  I see your arms are strong, as is your desire to win.  Ye are to take this greatsword, and singlehandedly throw it in the air, allowing it to rotate one full revolution before catching it by it's handle.  Ye shall receive one point for each successful catch.`n`n");

	for ($z=0; $z<5; $z++){
		for ($i=0; $i<e_rand(0,$points1); $i++){
		output(" `^-{`7--- `s`s`s`s`s`s   ---`^}-`s`s`s`s`s`s");
		}
	output("`n`n");
	}	
	switch ($points1) {
		case 1:
		  output("`n`n`@Your arms would not be so scarred if ye listened to my instructions - catch by the handle, not by the blade.  `n<font size='+1'>`6You get credit for just $points catches!!</font>`n",true);
		  break;
		case 2: case 3: case 4:
		  output("`n`n`@Ye're sure not any ".($session[user][sex]?"Xena":"Conan").", but ye do get the job done out in the forest.  I'd suggest ye stick to the normal methods of swordhandling. `n<font size='+1'>`6You earn $points points for your catches!!</font>",true);
		  break;
		case 5: case 6: case 7: case 8: case 9:
		  output("`n`n`@A good effort, I think ye're our local `#".($session[user][sex]?"Xena the Warrior Princess":"Conan the Barbarian")."`@!!`n<font size='+1'>`6You completed $points sword catches!!</font>",true);
		  break;
		case 10:
		output("`n`n`@Outstanding! Ye beat `bMightyE`b`@'s old record of 99 catches!!! `n<font size='+1'>`6You have earned $points points and `b1 gem`b as bonus!!!</font>",true);
		$session['user']['gems']+=1;
		break;
	}break;

case 15:
	output("`@My friend, you have arrived at the most challenging portion of this competition.  I know not that ye have the strength and endurance to survive this trial alive, yet ye have come this far and it would be unfair to stop ye now.  We have managed to acquire, just for this competition, a rare `$ Red Dragon`@.  All ye need to do is withstand the blast of his flames for as long as ye can.`nGood luck to ye.`n`n",true);
	for ($z=0; $z<5; $z++){
		for ($i=0; $i<e_rand(0,$points1); $i++){
		output(" `4w`$ Y `4w`$ Y ");
		}
	output("`n");
	}	
	switch ($points1) {
		case 1:
		  output("`n`@Couldn't stand the heat?  Get out of the frying pan!!! `n<font size='+1'>`6Your pathetic effort earned you a mere $points points!!</font>`n",true);
		  break;
		case 2: case 3: case 4:
		  output("`n`n`@Hmmmm...I see some 3rd degree burns on ye...what are ye?  A fool?  Ye shouldn't push your luck so.  Maybe next time you'll wear some heat resistant clothing!`n<font size='+1'>`6You survived $points seconds in the company of that`$ Red Dragon`@!!</font>",true);
		  break;
		case 5: case 6: case 7: case 8: case 9:
		  output("`n`n`@I swear ye must be at home in the desert, and firewalk for fun.  The `\$Red Dragon`@'s flame barely singed ye, but ye were still $resto seconds short of beating `bExcalibur`b's`@ record. `n<font size='+1'>`6You gain $points points!!!</font>",true);
		  break;
		case 10:
		  output("`n`n`@Amazing!!! Ye have beaten `2`bExcalibur`b`@'s record!!! Ye spent `b$points seconds`b`@ with the `\$Red Dragon`@'s flames trying to turn ye into a walking torch, and you don't even have a hair out of place!!!!`n<font size='+1'>`6You have earned $points points and also gain `b1 gem`b!!!</font>",true);
		  $session['user']['gems']+=1;
		  break;
	}break;

	} // chiusura switch $levels
} //chiusura else riga 14





output("`n`n`^Your current tournament score is `^".$session[user][torneo]." Points.");

page_footer();
?>


