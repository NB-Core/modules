<?
require_once "common.php";
checkday();
//--------------------------------------------------------------------------------------------------------
//| Written by:  Death Dragon (Server is invite only sorry)
//| Version:     1.0 - 06/08/2004
//|
//| About:   Housing Script
//|
//| Description:
//|			This mod allows players to have a house! They can store gems and gold!
//|         Make sure you also use the housing.php!
//|         Also in accounts add housing int 11 unsigned default 0
//|
//|  SQL:
//|   CREATE TABLE `housing` (
//|   `ownerid` int( 11 ) unsigned NOT NULL default '0',
//|   `ownername` varchar( 50 ) NOT NULL default '',
//|   `value` int( 11 ) unsigned NOT NULL default '0',
//|   `type` varchar( 20 ) NOT NULL default '',
//|   `welcome` varchar( 100 ) NOT NULL default '',
//|   `weapon` varchar( 50 ) NOT NULL default '',
//|   `weapvalue` int( 11 ) unsigned NOT NULL default '0',
//|   `attack` int( 11 ) NOT NULL default '0',
//|   `armor` varchar( 50 ) NOT NULL default '',
//|   `armvalue` int( 11 ) unsigned NOT NULL default '0',
//|   `defense` int( 11 ) NOT NULL default '0',
//|   PRIMARY KEY ( `ownerid` ) 
//|   ) TYPE = MYISAM ;
//|
//|  Village:
//|  add under addnav("Ye Olde Bank","bank.php");
//|  addnav("Housing");
//|  if ($session[user][housing]==0){addnav("Housing","thehousing.php");
//|  }
//|  if ($session[user][housing]>=1){ addnav("`^`nMy House`n","house.php");}
//|
//|
//|
//|
//--------------------------------------------------------------------------------------------------------
page_header("My House!");
##########
#Settings#
##########
$myname=$session[user][name];
$gemsinchest=$session['user']['gemsinchest'];
$goldinchest=$session['user']['goldinchest'];
$acctid=$session[user][acctid];
$config = unserialize($session['user']['donationconfig']);
if ($session[user][housing]!=0){
$sql = "SELECT * FROM housing WHERE ownerid='$acctid'";
$result = db_query($sql);
$row = db_fetch_assoc($result);}
##############
#End Settings#
##############
addcommentary();

{

switch($HTTP_GET_VARS[op])
    {
case "":

if ($session[user][housing]==0){
//take care of the "rare" occurence of someone getting to the house.php with no house LoL
output("Not supposed to be here...");
addnav("Return to Village","village.php");
}else{
addnav("Other");
//only people with a castle or a mansion can logout on my server....which is the housing 4 and 5
if ($session[user][housing]==4 OR $session[user][housing]==5){addnav("Sleep(Logout)","house.php?op=logout");}
//option to have maid
if ($session[user][maid]==1){
	addnav("The Maid","house.php?op=maid2");}
addnav("House Options");
addnav("Withdraw Gold from Chest","house.php?op=withdrawgold");
addnav("Withdraw Gems from Chest","house.php?op=withdrawg");
addnav("Deposit Gold in Chest","house.php?op=bankgold");
addnav("Deposit Gems in Chest","house.php?op=bankg");
addnav("Change Your Welcome Message","house.php?op=welcome");
addnav("The Closet","house.php?op=closet");
addnav("The Kitchen","house.php?op=kitchen");
//only people with a castle can hire a maid
if ($session[user][housing]==5 && $session[user][maid]==0){
	addnav("Hire a Butler/Maid","house.php?op=maid");}
addnav("Back to Village","village.php");
output("The clock on your mantle reads `^".getgametime()."`@.`n");
//Next New Day in ... is by JT from logd.dragoncat.net
$time = gametime();
$tomorrow = strtotime(date("Y-m-d H:i:s",$time)." + 1 day");
$tomorrow = strtotime(date("Y-m-d 00:00:00",$tomorrow));
$secstotomorrow = $tomorrow-$time;
$realsecstotomorrow = $secstotomorrow / getsetting("daysperday",4);
output("`7 You figure a new day in: `^".date("G \\h\\o\\u\\r\\s i \\m\\i\\n\\u\\t\\e\\s s \\s\\e\\c\\o\\n\\d\\s",strtotime("1970-01-01 00:00:00 + $realsecstotomorrow seconds"))."`0`n`n");
//welcome message
if ($row[welcome] != "")        
output("`&".$row[welcome]."`&`n"); 
output("`2You have $goldinchest gold in your Gold Chest!`n");
output("`2You have $gemsinchest gems in your Gems Chest!`n");
}

break;

case "welcome":
        output("Change your welcome message, message has a 50 word limit.`nCurrent Message: $row[welcome]`n`n");
        output("<form action='house.php?op=newwelcome' method='POST'><input name='welcome'><input type='submit' class='button' value='submit'></form>",true);

    addnav("Nevermind","house.php");
    addnav("","house.php?op=newwelcome");

        break;


//where users can change there welcome message.
case "newwelcome":
           $newwel = addslashes($_POST[welcome]);
          $sql = "UPDATE housing SET welcome= \"".$newwel."\" WHERE ownerid='$acctid'";
       db_query($sql);
output("Your Welcome Message has Been Changed to $newwel!`n`n");
    addnav("Return to House","house.php");
   break;
   

    case "bankg":
	//lets users store gems
  output("<form action='house.php?op=depositfinish' method='POST'>You have ".($session[user][gemsinchest]>=0?"":"a debt of")." ".abs($session[user][gemsinchest])." gems in your Chest.`n",true);
        output("`^".($session[user][gemsinchest]>=0?"Drop":"Pay off")." <u>h</u>ow much? <input id='input' name='amount' width=5 accesskey='h'> <input type='submit' class='button' value='Deposit'>`n`iEnter 0 or nothing to drop it all`i</form>",true);
        output("<script language='javascript'>document.getElementById('input').focus();</script>",true);
  addnav("","house.php?op=depositfinish");
    addnav("Back to Home","house.php");
  break;
        case "depositfinish":
        $_POST[amount]=abs((int)$_POST[amount]);
        if ($_POST[amount]==0){
                $_POST[amount]=$session[user][gems];
        }
        if ($_POST[amount]>$session[user][gems]){
                output("`\$ERROR: Not enough gems in hand to store away.`^`n`n");
                output("You plunk your `&".$session[user][gems]."`^gems into your chest and think for a minute, you tried to put `&$_POST[amount]`^ in...realizing your mistake, you try again");
                addnav("Back to Home","house.php");
        }else{
                output("`^`bYou Drop `&$_POST[amount]`^ gems in to your chest, ");
                debuglog("deposited " . $_POST[amount] . " gems in chest");
                $session[user][gemsinchest]+=$_POST[amount];
                $session[user][gems]-=$_POST[amount];
                output("leaving you with ".($session[user][gemsinchest]>=0?"":"a debt of")." `&".abs($session[user][gemsinchest])."`^ gems in your chest and `&".$session[user][gems]."`^ gems in hand.`b");}
               addnav("Back to Home","house.php");
              break;

   case "withdrawg":
	   //lets users withdraw their stored gems
  output("<form action='house.php?op=withdrawfinish' method='POST'>You have ".$session[user][gemsinchest]." gems in your chest`n",true);
  output("`^Withdraw <u>h</u>ow much? <input id='input' name='amount' width=5 accesskey='h'> <input type='submit' class='button' value='Withdraw'>`n`iEnter 0 or nothing to withdraw it all`i</form>",true);
        output("<script language='javascript'>document.getElementById('input').focus();</script>",true);
  addnav("","house.php?op=withdrawfinish");
      addnav("Back to Home","house.php");
  break;

 case "closet":
	 //lets users store their weapon and armor
    output("`&You open your closet and notice some space to store your weapon!`n`n");
        output("`6Current Stored Weapon:$row[weapon] `nattack: $row[attack]`n value:$row[weapvalue]`n");
		output("`6Current Stored Armor:$row[armor] `ndefence: $row[defense]`n value:$row[armvalue]");
         addnav("Switch Weapon","house.php?op=switchweap");
		 addnav("Switch Armor","house.php?op=switcharm");
          addnav("Return to House","house.php");

        break;

        case "switchweap":
      $weapstore=$session[user][weapon];
          $attackstore=$session[user][weapondmg];
          $valuestore=$session[user][weaponvalue];

      $session[user][weapon]=$row[weapon];
          $session[user][weapondmg]=$row[attack];
          $session[user][weaponvalue]=$row[weapvalue];  

          $session[user][attack] = $session[user][attack] - $attackstore + $row[attack];  

          $sql = "UPDATE housing SET weapon=\"".$weapstore."\",attack=\"".$attackstore."\",weapvalue=\"".$valuestore."\" WHERE ownerid='$acctid'";
db_query($sql);

output("`6`n`nYour Weapon Has Been Switched!");

 addnav("Return to House","house.php");
      break;

case "switcharm":
      $armstore=$session[user][armor];
          $defensestore=$session[user][armordef];
          $valuesstore=$session[user][armorvalue];

      $session[user][weapon]=$row[armor];
          $session[user][armordef]=$row[armordef];
          $session[user][armorvalue]=$row[armorvalue];  

          $session[user][defence] = $session[user][defence] - $defensestore + $row[defence]; 

          $sql = "UPDATE housing SET armor=\"".$armstore."\",defense=\"".$defensestore."\",armvalue=\"".$valuesstore."\" WHERE ownerid='$acctid'";
db_query($sql);

output("`6`n`nYour Armor Has Been Switched!");

 addnav("Return to House","house.php");
      break;

case "withdrawfinish":
        $_POST[amount]=abs((int)$_POST[amount]);
        if ($_POST[amount]==0){
                $_POST[amount]=abs($session[user][gemsinchest]);
        }
        if ($_POST[amount]>$session[user][gemsinchest] && $_POST[borrow]=="") {
                output("`\$ERROR: Not enough gems in the chest to to withdraw.`^`n`n");
                output("Having been informed that you have `&".$session[user][gemsinchest]."`^ gems in your chest, you try to withdraw `&$_POST[amount]`^ of it.");
                output("`n`nYou realize your grabbing at air, you realize your mistake, and try again.");
                addnav("Back to Home","house.php");
        }else if($_POST[amount]>$session[user][gemsinchest]){
                $lefttoborrow = $_POST[amount];
                $maxborrow = $session[user][level]*getsetting("borrowperlevel",20);
                if ($lefttoborrow<=$session[user][gemsinchest]+$maxborrow){
                        if ($session[user][gemsinchest]>0){
                                output("`6You withdraw your remaining `^".$session[user][gemsinchest]."`6 gems, and ");
                                $lefttoborrow-=$session[user][gemsinchest];
                                $session[user][gems]+=$session[user][gemsinchest];
                                $session[user][gemsinchest]=0;
                                debuglog("withdrew " . $_POST[amount] . " gems from the bank");
                        }else{
                                output("`6You ");
                        }
                        if ($lefttoborrow-$session[user][gemsinchest] > $maxborrow){
                                output("ask to borrow `^$lefttoborrow`6 gems.  The Tall man looks up your account and informs you that you may only borrow up to `^$maxborrow`6 gems.");
                        }else{
                                output("borrow `^$lefttoborrow`6 gems.");
                                $session[user][gemsinchest]-=$lefttoborrow;
                                $session[user][gems]+=$lefttoborrow;
                                debuglog("borrows $lefttoborrow gems from the bank");
                        }
                }else{
                        output("`6Considering the `^{$session[user][gemsinchest]}`6 gold in your account, you ask to borrow `^".($lefttoborrow-$session[user][gemsinchest])."`6, but
                        the short little man looks up your account and informs you that you may only borrow up to `^$maxborrow`6 gems at your level.");
                }
        }else{
                output("`^`bYou withdraw `&$_POST[amount]`^ gems from your chest, ");
                $session[user][gemsinchest]-=$_POST[amount];
                $session[user][gems]+=$_POST[amount];
                debuglog("withdrew " . $_POST[amount] . " gems from the bank");
                output("leaving you with `&".$session[user][gemsinchest]."`^ gems in your chest and `&".$session[user][gems]."`^ gems in hand.`b");
                 addnav("Back to Home","house.php"); }break;

                 case "bank":
        output("You have successfully banked ".$session[user][gold]." gold.");
        $session[user][goldinbank]+=$session[user][gold];
        $session[user][gold]=0;
        addnav("Back to Home","house.php");
        break;

		case "kitchen":
			if ($session[user][atefood]==0){
			output("Want to get food?");
		addnav("Yes","house.php?op=getfood");
		addnav("No","house.php");
		}else{
			output("Your Kitchen is empty!!");
			addnav("Your House","house.php");}
		break;

		case "getfood":
			output("You are fully healed!!");
		$session[user][atefood]=1;
		$session[user][hitpoints]=$session[user][maxhitpoints];
		addnav("Your House","house.php");
		break;

		case "maid":
			output("You want to hire a maid/butler?");
		addnav("Yes","house.php?op=maidhire");
		addnav("No","house.php");
		break;

		case "maidhire":
			output("Congratulations You have hired a maid!!");
		$session[user][maid]=1;
		addnav("Your House","house.php");
		break;

case "maid2":
	output("You walk in and see the maid. She is cleaning busily.");
if ($session[user][usedmaid]==0){
addnav("Maid Options");
addnav("Get Food","house.php?op=food");
addnav("Order a Add-on","house.php?op=addons");
addnav("Your House","house.php");
}else{
addnav("Your House","house.php");}
break;

case "food":
	output("Your Maid goes to get food and says she will be back later.");
$session[user][atefood]=0;
$session[user][usedmaid]=1;
addnav("Your House","house.php");
break;

case "addons":
	//working on adding a marriage fund and a pool add on
	output("You want some addons?");
addnav("Add-Ons");
addnav("A Pool","");
addnav("Marriage Funds","");
addnav("Your House","house.php");
break;

        case "logout":
			//where users can logout and be safe from pvp!
         $sql = "UPDATE accounts SET loggedin=0,location=2 WHERE acctid = ".$session[user][acctid];
         db_query($sql);



        $session=array();
        redirect("index.php");
                      break;

                       case "wakeup":
     output("`^You wake up feeling great.`n`n");
            addnav("The Livingroom","house.php");


                      break;




                      case "bankgold":
  output("<form action='house.php?op=depositfinish2' method='POST'>You have ".($session[user][goldinchest]>=0?"":"a debt of")." ".abs($session[user][goldinchest])." gold in your Chest.`n",true);
        output("`^".($session[user][goldinchest]>=0?"Drop":"Pay off")." <u>h</u>ow much? <input id='input' name='amount' width=5 accesskey='h'> <input type='submit' class='button' value='Deposit'>`n`iEnter 0 or nothing to drop it all`i</form>",true);
        output("<script language='javascript'>document.getElementById('input').focus();</script>",true);
  addnav("","house.php?op=depositfinish2");
   addnav("Back to Home","house.php");
  break;
        case "depositfinish2":
        $_POST[amount]=abs((int)$_POST[amount]);
        if ($_POST[amount]==0){
                $_POST[amount]=$session[user][gold];
        }
        if ($_POST[amount]>$session[user][gold]){
                output("`\$ERROR: Not enough gold in hand to store away.`^`n`n");
                output("You plunk your `&".$session[user][gold]."`^gold into your chest and think for a minute, you tried to put `&$_POST[amount]`^ in...realizing your mistake, you try again");
        }else{
                output("`^`bYou Drop `&$_POST[amount]`^ gold in to your chest, ");
                debuglog("deposited " . $_POST[amount] . " gold in chest");
                $session[user][goldinchest]+=$_POST[amount];
                $session[user][gold]-=$_POST[amount];
                output("leaving you with ".($session[user][goldinchest]>=0?"":"a debt of")." `&".abs($session[user][goldinchest])."`^ gold in your chest and `&".$session[user][gold]."`^ gold in hand.`b");}
               addnav("Back to Home","house.php");
              break;

   case "withdrawgold":
  output("<form action='house.php?op=withdrawfinish2' method='POST'>You have ".$session[user][goldinchest]." gold in your chest`n",true);
  output("`^Withdraw <u>h</u>ow much? <input id='input' name='amount' width=5 accesskey='h'> <input type='submit' class='button' value='Withdraw'>`n`iEnter 0 or nothing to withdraw it all`i</form>",true);
        output("<script language='javascript'>document.getElementById('input').focus();</script>",true);
  addnav("","house.php?op=withdrawfinish2");
   addnav("Back to Home","house.php");
  break;
case "withdrawfinish2":
        $_POST[amount]=abs((int)$_POST[amount]);
        if ($_POST[amount]==0){
                $_POST[amount]=abs($session[user][goldinchest]);
        }
        if ($_POST[amount]>$session[user][goldinchest] && $_POST[borrow]=="") {
                output("`\$ERROR: Not enough gold in the chest to to withdraw.`^`n`n");
                output("Having been informed that you have `&".$session[user][goldinchest]."`^ gold in your chest, you try to withdraw `&$_POST[amount]`^ of it.");
                output("`n`nYou start grabbing at air, you realize your mistake, and try again.");
                addnav("Back to Home","house.php");
        }else if($_POST[amount]>$session[user][goldinchest]){
                $lefttoborrow = $_POST[amount];
                $maxborrow = $session[user][level]*getsetting("borrowperlevel",20);
                if ($lefttoborrow<=$session[user][goldinchest]+$maxborrow){
                        if ($session[user][goldinchest]>0){
                                output("`6You withdraw your remaining `^".$session[user][goldinchest]."`6 gold, and ");
                                $lefttoborrow-=$session[user][goldinchest];
                                $session[user][gold]+=$session[user][goldinchest];
                                $session[user][goldinchest]=0;
                                debuglog("withdrew " . $_POST[amount] . " gold from the bank");
                        }else{
                                output("`6You ");
                        }
                        if ($lefttoborrow-$session[user][goldinchest] > $maxborrow){
                                output("ask to borrow `^$lefttoborrow`6 gold.  The Tall man looks up your account and informs you that you may only borrow up to `^$maxborrow`6 gold.");
                        }else{
                                output("borrow `^$lefttoborrow`6 gold.");
                                $session[user][goldinchest]-=$lefttoborrow;
                               // $session[user][gems]+=$lefttoborrow;
                                debuglog("borrows $lefttoborrow gold from the bank");
                        }
                }else{
                        output("`6Considering the `^{$session[user][goldinchest]}`6 gold in your account, you ask to borrow `^".($lefttoborrow-$session[user][goldinchest])."`6, but
                        the short little man looks up your account and informs you that you may only borrow up to `^$maxborrow`6 gold at your level.");
                }
        }else{
                output("`^`bYou withdraw `&$_POST[amount]`^ gold from your chest, ");
                $session[user][goldinchest]-=$_POST[amount];
                $session[user][gold]+=$_POST[amount];
                debuglog("withdrew " . $_POST[amount] . " gold from chest");
                output("leaving you with `&".$session[user][goldinchest]."`^ gold in your chest and `&".$session[user][gold]."`^ gold in hand.`b");
                 addnav("Back to Home","house.php"); }break;

                 case "bank":
        output("You have successfully banked ".$session[user][gold]." gold.");
        $session[user][goldinbank]+=$session[user][gold];
        $session[user][gold]=0;
        addnav("Back to Home","house.php");
        break;
}
}

    page_footer();
?>
