<?php
require_once("common.php");
require_once("lib/http.php");
require_once("lib/commentary.php");
function streetsplus_getmoduleinfo(){
	$info = array(
		"name"=>"Streets Plus",
		"author"=>"`b`@Radioactivebloke`b, modified by `4S`)ig`4g",
		"version"=>"1.0",
		"category"=>"Streets",
		"download"=>"",
		"description"=>"A heavy modification of Radioactivebloke's street module.",
		"settings"=>array(
			"Basic information,title",
			"fname"=>"Name of the area where the forest streets are located,text|Town Outskirts",
			"cname"=>"Name of the area where the city streets are located,text|Downtown",
			"c1name"=>"Name of the first city street,text|Main Street",
			"c1bool"=>"Is the first city street enabled?,bool|1",
			"c2name"=>"Name of the second city street,text|Blades Boulevard",
			"c2bool"=>"Is the second city street enabled?,bool|0",
			"c3name"=>"Name of the third city street,text|Market Street",
			"c3bool"=>"Is the third city street enabled?,bool|0",
			"c4name"=>"Name of the fourth city street,text|Tavern Street",
			"c4bool"=>"Is the fourth city street enabled?,bool|0",
			"c5name"=>"Name of the fifth city street,text|Info Alley",
			"c5bool"=>"Is the fifth city street enabled?,bool|0",
			"f1name"=>"Name of the first forest street,text|Old Inn Path",
			"f1bool"=>"Is the first forest street enabled?,bool|1",
			"f2name"=>"Name of the second forest street,text|Farm Road",
			"f2bool"=>"Is the second forest street enabled?,bool|0",
			"f3name"=>"Name of the third forest street,text|High Road",
			"f3bool"=>"Is the third street enabled?,bool|0",
			"f4name"=>"Name of the fourth forest street,text|Low Street",
			"f4bool"=>"Is the fourth forest street enabled?,bool|0",
			"f5name"=>"Name of the fifth forest street,text|Arcadian District",
			"f5bool"=>"Is the fifth forest street enabled?,bool|0",

			"City 1 Text,title",
			"c1text1"=>"First Street Addnav 1 Text,text|",
			"c1text2"=>"First Street Addnav 2 Text,text|",
			"c1text3"=>"First Street Addnav 3 Text,text|",
			"c1text4"=>"First Street Addnav 4 Text,text|",
			"c1text5"=>"First Street Addnav 5 Text,text|",
			"c1text6"=>"First Street Addnav 6 Text,text|",
			"c1text7"=>"First Street Addnav 7 Text,text|",
			"c1text8"=>"First Street Addnav 8 Text,text|",
			"c1text9"=>"First Street Addnav 9 Text,text|",
			"c1text10"=>"First Street Addnav 10 Text,text|",
			"c1description"=>"Description of the First City Street,textarea}",

			"City 1 Links,title",
			"c1link1"=>"First Street Addnav 1 Link,text|",
			"c1link2"=>"First Street Addnav 2 Link,text|",
			"c1link3"=>"First Street Addnav 3 Link,text|",
			"c1link4"=>"First Street Addnav 4 Link,text|",
			"c1link5"=>"First Street Addnav 5 Link,text|",
			"c1link6"=>"First Street Addnav 6 Link,text|",
			"c1link7"=>"First Street Addnav 7 Link,text|",
			"c1link8"=>"First Street Addnav 8 Link,text|",
			"c1link9"=>"First Street Addnav 9 Link,text|",
			"c1link10"=>"First Street Addnav 10 Link,text|",

			"City 2 Text,title",
			"c2text1"=>"Second Street Addnav 1 Text,text|",
			"c2text2"=>"Second Street Addnav 2 Text,text|",
			"c2text3"=>"Second Street Addnav 3 Text,text|",
			"c2text4"=>"Second Street Addnav 4 Text,text|",
			"c2text5"=>"Second Street Addnav 5 Text,text|",
			"c2text6"=>"Second Street Addnav 6 Text,text|",
			"c2text7"=>"Second Street Addnav 7 Text,text|",
			"c2text8"=>"Second Street Addnav 8 Text,text|",
			"c2text9"=>"Second Street Addnav 9 Text,text|",
			"c2text10"=>"Second Street Addnav 10 Text,text|",
			"c2description"=>"Description of the Second City Street,textarea}",

			"City 2 Links,title",
			"c2link1"=>"Second Street Addnav 1 Link,text|",
			"c2link2"=>"Second Street Addnav 2 Link,text|",
			"c2link3"=>"Second Street Addnav 3 Link,text|",
			"c2link4"=>"Second Street Addnav 4 Link,text|",
			"c2link5"=>"Second Street Addnav 5 Link,text|",
			"c2link6"=>"Second Street Addnav 6 Link,text|",
			"c2link7"=>"Second Street Addnav 7 Link,text|",
			"c2link8"=>"Second Street Addnav 8 Link,text|",
			"c2link9"=>"Second Street Addnav 9 Link,text|",
			"c2link10"=>"Second Street Addnav 10 Link,text|",

			"City 3 Text,title",
			"c3text1"=>"Third Street Addnav 1 Text,text|",
			"c3text2"=>"Third Street Addnav 2 Text,text|",
			"c3text3"=>"Third Street Addnav 3 Text,text|",
			"c3text4"=>"Third Street Addnav 4 Text,text|",
			"c3text5"=>"Third Street Addnav 5 Text,text|",
			"c3text6"=>"Third Street Addnav 6 Text,text|",
			"c3text7"=>"Third Street Addnav 7 Text,text|",
			"c3text8"=>"Third Street Addnav 8 Text,text|",
			"c3text9"=>"Third Street Addnav 9 Text,text|",
			"c3text10"=>"Third Street Addnav 10 Text,text|",
			"c3description"=>"Description of the Third City Street,textarea}",

			"City 3 Links,title",
			"c3link1"=>"Third Street Addnav 1 Link,text|",
			"c3link2"=>"Third Street Addnav 2 Link,text|",
			"c3link3"=>"Third Street Addnav 3 Link,text|",
			"c3link4"=>"Third Street Addnav 4 Link,text|",
			"c3link5"=>"Third Street Addnav 5 Link,text|",
			"c3link6"=>"Third Street Addnav 6 Link,text|",
			"c3link7"=>"Third Street Addnav 7 Link,text|",
			"c3link8"=>"Third Street Addnav 8 Link,text|",
			"c3link9"=>"Third Street Addnav 9 Link,text|",
			"c3link10"=>"Third Street Addnav 10 Link,text|",

			"City 4 Text,title",
			"c4text1"=>"Fourth Street Addnav 1 Text,text|",
			"c4text2"=>"Fourth Street Addnav 2 Text,text|",
			"c4text3"=>"Fourth Street Addnav 3 Text,text|",
			"c4text4"=>"Fourth Street Addnav 4 Text,text|",
			"c4text5"=>"Fourth Street Addnav 5 Text,text|",
			"c4text6"=>"Fourth Street Addnav 6 Text,text|",
			"c4text7"=>"Fourth Street Addnav 7 Text,text|",
			"c4text8"=>"Fourth Street Addnav 8 Text,text|",
			"c4text9"=>"Fourth Street Addnav 9 Text,text|",
			"c4text10"=>"Fourth Street Addnav 10 Text,text|",
			"c4description"=>"Description of the Fourth City Street,textarea}",

			"City 4 Links,title",
			"c4link1"=>"Fourth Street Addnav 1 Link,text|",
			"c4link2"=>"Fourth Street Addnav 2 Link,text|",
			"c4link3"=>"Fourth Street Addnav 3 Link,text|",
			"c4link4"=>"Fourth Street Addnav 4 Link,text|",
			"c4link5"=>"Fourth Street Addnav 5 Link,text|",
			"c4link6"=>"Fourth Street Addnav 6 Link,text|",
			"c4link7"=>"Fourth Street Addnav 7 Link,text|",
			"c4link8"=>"Fourth Street Addnav 8 Link,text|",
			"c4link9"=>"Fourth Street Addnav 9 Link,text|",
			"c4link10"=>"Fourth Street Addnav 10 Link,text|",

			"City 5 Text,title",
			"c5text1"=>"Fifth Street Addnav 1 Text,text|",
			"c5text2"=>"Fifth Street Addnav 2 Text,text|",
			"c5text3"=>"Fifth Street Addnav 3 Text,text|",
			"c5text4"=>"Fifth Street Addnav 4 Text,text|",
			"c5text5"=>"Fifth Street Addnav 5 Text,text|",
			"c5text6"=>"Fifth Street Addnav 6 Text,text|",
			"c5text7"=>"Fifth Street Addnav 7 Text,text|",
			"c5text8"=>"Fifth Street Addnav 8 Text,text|",
			"c5text9"=>"Fifth Street Addnav 9 Text,text|",
			"c5text10"=>"Fifth Street Addnav 10 Text,text|",
			"c5description"=>"Description of the Fifth City Street,textarea}",

			"City 5 Links,title",
			"c5link1"=>"Fifth Street Addnav 1 Link,text|",
			"c5link2"=>"Fifth Street Addnav 2 Link,text|",
			"c5link3"=>"Fifth Street Addnav 3 Link,text|",
			"c5link4"=>"Fifth Street Addnav 4 Link,text|",
			"c5link5"=>"Fifth Street Addnav 5 Link,text|",
			"c5link6"=>"Fifth Street Addnav 6 Link,text|",
			"c5link7"=>"Fifth Street Addnav 7 Link,text|",
			"c5link8"=>"Fifth Street Addnav 8 Link,text|",
			"c5link9"=>"Fifth Street Addnav 9 Link,text|",
			"c5link10"=>"Fifth Street Addnav 10 Link,text|",

			"Forest 1 Text,title",
			"f1text1"=>"First Street Addnav 1 Text,text|",
			"f1text2"=>"First Street Addnav 2 Text,text|",
			"f1text3"=>"First Street Addnav 3 Text,text|",
			"f1text4"=>"First Street Addnav 4 Text,text|",
			"f1text5"=>"First Street Addnav 5 Text,text|",
			"f1text6"=>"First Street Addnav 6 Text,text|",
			"f1text7"=>"First Street Addnav 7 Text,text|",
			"f1text8"=>"First Street Addnav 8 Text,text|",
			"f1text9"=>"First Street Addnav 9 Text,text|",
			"f1text10"=>"First Street Addnav 10 Text,text|",
			"f1description"=>"Description of the First Forest Street,textarea}",

			"Forest 1 Links,title",
			"f1link1"=>"First Street Addnav 1 Link,text|",
			"f1link2"=>"First Street Addnav 2 Link,text|",
			"f1link3"=>"First Street Addnav 3 Link,text|",
			"f1link4"=>"First Street Addnav 4 Link,text|",
			"f1link5"=>"First Street Addnav 5 Link,text|",
			"f1link6"=>"First Street Addnav 6 Link,text|",
			"f1link7"=>"First Street Addnav 7 Link,text|",
			"f1link8"=>"First Street Addnav 8 Link,text|",
			"f1link9"=>"First Street Addnav 9 Link,text|",
			"f1link10"=>"First Street Addnav 10 Link,text|",

			"Forest 2 Text,title",
			"f2text1"=>"Second Street Addnav 1 Text,text|",
			"f2text2"=>"Second Street Addnav 2 Text,text|",
			"f2text3"=>"Second Street Addnav 3 Text,text|",
			"f2text4"=>"Second Street Addnav 4 Text,text|",
			"f2text5"=>"Second Street Addnav 5 Text,text|",
			"f2text6"=>"Second Street Addnav 6 Text,text|",
			"f2text7"=>"Second Street Addnav 7 Text,text|",
			"f2text8"=>"Second Street Addnav 8 Text,text|",
			"f2text9"=>"Second Street Addnav 9 Text,text|",
			"f2text10"=>"Second Street Addnav 10 Text,text|",
			"f2description"=>"Description of the Second Forest Street,textarea}",

			"Forest 2 Links,title",
			"f2link1"=>"Second Street Addnav 1 Link,text|",
			"f2link2"=>"Second Street Addnav 2 Link,text|",
			"f2link3"=>"Second Street Addnav 3 Link,text|",
			"f2link4"=>"Second Street Addnav 4 Link,text|",
			"f2link5"=>"Second Street Addnav 5 Link,text|",
			"f2link6"=>"Second Street Addnav 6 Link,text|",
			"f2link7"=>"Second Street Addnav 7 Link,text|",
			"f2link8"=>"Second Street Addnav 8 Link,text|",
			"f2link9"=>"Second Street Addnav 9 Link,text|",
			"f2link10"=>"Second Street Addnav 10 Link,text|",

			"Forest 3 Text,title",
			"f3text1"=>"Third Street Addnav 1 Text,text|",
			"f3text2"=>"Third Street Addnav 2 Text,text|",
			"f3text3"=>"Third Street Addnav 3 Text,text|",
			"f3text4"=>"Third Street Addnav 4 Text,text|",
			"f3text5"=>"Third Street Addnav 5 Text,text|",
			"f3text6"=>"Third Street Addnav 6 Text,text|",
			"f3text7"=>"Third Street Addnav 7 Text,text|",
			"f3text8"=>"Third Street Addnav 8 Text,text|",
			"f3text9"=>"Third Street Addnav 9 Text,text|",
			"f3text10"=>"Third Street Addnav 10 Text,text|",
			"f3description"=>"Description of the Third Forest Street,textarea}",

			"Forest 3 Links,title",
			"f3link1"=>"Third Street Addnav 1 Link,text|",
			"f3link2"=>"Third Street Addnav 2 Link,text|",
			"f3link3"=>"Third Street Addnav 3 Link,text|",
			"f3link4"=>"Third Street Addnav 4 Link,text|",
			"f3link5"=>"Third Street Addnav 5 Link,text|",
			"f3link6"=>"Third Street Addnav 6 Link,text|",
			"f3link7"=>"Third Street Addnav 7 Link,text|",
			"f3link8"=>"Third Street Addnav 8 Link,text|",
			"f3link9"=>"Third Street Addnav 9 Link,text|",
			"f3link10"=>"Third Street Addnav 10 Link,text|",

			"Forest 4 Text,title",
			"f4text1"=>"Fourth Street Addnav 1 Text,text|",
			"f4text2"=>"Fourth Street Addnav 2 Text,text|",
			"f4text3"=>"Fourth Street Addnav 3 Text,text|",
			"f4text4"=>"Fourth Street Addnav 4 Text,text|",
			"f4text5"=>"Fourth Street Addnav 5 Text,text|",
			"f4text6"=>"Fourth Street Addnav 6 Text,text|",
			"f4text7"=>"Fourth Street Addnav 7 Text,text|",
			"f4text8"=>"Fourth Street Addnav 8 Text,text|",
			"f4text9"=>"Fourth Street Addnav 9 Text,text|",
			"f4text10"=>"Fourth Street Addnav 10 Text,text|",
			"f4description"=>"Description of the Fourth Forest Street,textarea}",

			"Forest 4 Links,title",
			"f4link1"=>"Fourth Street Addnav 1 Link,text|",
			"f4link2"=>"Fourth Street Addnav 2 Link,text|",
			"f4link3"=>"Fourth Street Addnav 3 Link,text|",
			"f4link4"=>"Fourth Street Addnav 4 Link,text|",
			"f4link5"=>"Fourth Street Addnav 5 Link,text|",
			"f4link6"=>"Fourth Street Addnav 6 Link,text|",
			"f4link7"=>"Fourth Street Addnav 7 Link,text|",
			"f4link8"=>"Fourth Street Addnav 8 Link,text|",
			"f4link9"=>"Fourth Street Addnav 9 Link,text|",
			"f4link10"=>"Fourth Street Addnav 10 Link,text|",

			"Forest 5 Text,title",
			"f5text1"=>"Fifth Street Addnav 1 Text,text|",
			"f5text2"=>"Fifth Street Addnav 2 Text,text|",
			"f5text3"=>"Fifth Street Addnav 3 Text,text|",
			"f5text4"=>"Fifth Street Addnav 4 Text,text|",
			"f5text5"=>"Fifth Street Addnav 5 Text,text|",
			"f5text6"=>"Fifth Street Addnav 6 Text,text|",
			"f5text7"=>"Fifth Street Addnav 7 Text,text|",
			"f5text8"=>"Fifth Street Addnav 8 Text,text|",
			"f5text9"=>"Fifth Street Addnav 9 Text,text|",
			"f5text10"=>"Fifth Street Addnav 10 Text,text|",
			"f5description"=>"Description of the Fifth Forest Street,textarea}",

			"Forest 5 Links,title",
			"f5link1"=>"Fifth Street Addnav 1 Link,text|",
			"f5link2"=>"Fifth Street Addnav 2 Link,text|",
			"f5link3"=>"Fifth Street Addnav 3 Link,text|",
			"f5link4"=>"Fifth Street Addnav 4 Link,text|",
			"f5link5"=>"Fifth Street Addnav 5 Link,text|",
			"f5link6"=>"Fifth Street Addnav 6 Link,text|",
			"f5link7"=>"Fifth Street Addnav 7 Link,text|",
			"f5link8"=>"Fifth Street Addnav 8 Link,text|",
			"f5link9"=>"Fifth Street Addnav 9 Link,text|",
			"f5link10"=>"Fifth Street Addnav 10 Link,text|"
		),
		"prefs"=>array(
			"seechat"=>"Does the user see the default chat?,hidden|",
			"seedesc"=>"Does the user see the description?,hidden|",
			"seelinks"=>"Does the user see the links?,hidden|"
		)
	);
	return $info;
}
function streetsplus_install(){module_addhook("header-village");module_addhook("header-forest");module_addhook("superuser");return true;}
function streetsplus_uninstall(){return true;}	
function streetsplus_dohook($hookname, $args){
	global $session;
	switch($hookname){
		case "header-forest";addnav('Heal');addnav('Fight');streetsplus_link(f);break;
		case "header-village":
			for($n = 1; $n <= 5; $n++){streetsplus_block('c'.$n);streetsplus_block('f'.$n);}
			addnav('City Gates');
			streetsplus_link(c);
			break;
		case "superuser":
				if($session['user']['superuser'] & SU_EDIT_CONFIG){
					addnav("Mechanics");
					addnav("Streets Plus Configuration", "configuration.php?op=modulesettings&module=streetsplus");
				}
			break;
	}
	return $args;
}
function streetsplus_run(){
	$op = httpget('op');
	$num = httpget('num');
	set_module_pref("seechat",1);
	set_module_pref("seedesc",1);
	set_module_pref("seelinks",1);
	page_header(get_module_setting($op."name"));
	rawoutput("<center><b>");
	output("`3".get_module_setting($op.$num.'name')."`n");
	rawoutput("</b></center>");
	modulehook('streetsplusall');
	modulehook($op.$num."street");
	if(get_module_pref("seedesc"))output(get_module_setting($op.$num.'description')."`n`n");
	if(get_module_pref("seelinks")){addnav(get_module_setting($op.$num."name"));streetsplus_add($op.$num);}
	if(get_module_pref("seechat")) {
		addcommentary();
		commentdisplay("",$op."street$num","Speak",25,"says");
	}
	addnav("Return");
	if($op == f) {addnav("F?Return to the Forest","forest.php");}else{addnav("V?Return to the Village","village.php");}
	page_footer();
}
function streetsplus_link($abrv){
	addnav(get_module_setting($abrv.'name'));
	for($s = 1; $s <= 5; $s++){
		if(get_module_setting($abrv.$s."bool") == 1){
			addnav(get_module_setting($abrv.$s.'name'),"runmodule.php?module=streetsplus&op=".$abrv."&num=".$s);
		}
	}
}
function streetsplus_add($abrv){
	for($d = 1; $d <= 10; $d++){
		addnav(get_module_setting($abrv."text".$d),get_module_setting($abrv."link".$d));
	}
}
function streetsplus_block($abrv){
	if(get_module_setting($abrv."bool") == 1){
		for($b = 1; $b <= 10; $b++){
			if(get_module_setting($abrv."link".$b)!=null) blocknav(get_module_setting($abrv."link".$b));
		}
	}
}
?>