<?
//Author Charlotte Ouellette
//Email: char@chars-web.com
//Author Note: I created this so as to allow adults to be able to chat freely without having to watch there language in chat. 
//Step 1: goto your database and add a table in accounts. I placed it right after name in accounts.
//Add: table name: bday int(4) not null
//Step 2: create.php
//After : db_query($sql);
//		output("`#`cYour email has been validated.  You may now log in.`c`0");
//		output("<form action='login.php' method='POST'><input name='name' value=\"$row[login]\" type='hidden'>
//Add: <input name='year' value=\"$row[bday]\" type='hidden'>
//After:
//	 if (getsetting("blockdupeemail",0)==1 && getsetting("requireemail",0)==1){
//			$sql = "SELECT login FROM accounts WHERE emailaddress='$_POST[email]'";
//			$result = db_query($sql); 
//			if (db_num_rows($result)>0){
//				$blockaccount=true;
//				$msg.="You may have only one account.`n";
//			}
//		}
//Add: 	
//		if (strlen($HTTP_POST_VARS[year]) <= 3){
//	       $msg.="You entered an invalid birthday.`n";
//		   $blockaccount=true;
//		}
//		if (strlen($HTTP_POST_VARS[year]) == ""){
//		$blockaccount=true;
//		$msg.="You did not enter in a birthdate`n";
//		}
//After :
//				$sql = "INSERT INTO accounts 
//					(name,
//Add:
//		bday,
//After:
//				) VALUES (
//					'$title $shortname',
//Add:
//					'$year',
//Near the bottom After:
//		  }else{
//					output("<form action='login.php' method='POST'><input name='name' value=\"$shortname\" type='hidden'>
//Add:
//	<input name='year' value=\"$year\" type= 'hidden'>
//After: 
//if ($HTTP_GET_VARS[op]==""){
//	output("`&`c`bCreate a Character`b`c");
//	output("`0<form action=\"create.php?op=create".($_GET['r']>""?"&r=".HTMLEntities($_GET['r']):"")."\" method='POST'>",true);
//	output("How will you be known to this world? <input name='name'>`n",true);
//Add:
//	output("Enter in year of Birth: <input name= 'year'>`n", true);
//Step 3: village.php
//Before: 
//		if (@file_exists("pavilion.php")) addnav("E?Eye-catching Pavilion","pavilion.php");
//Add:
//		addnav("Adult Chat", "test.php");

require_once"common.php";
addcommentary();
checkday();
$u =& $session[user];
if($u[bday] <= 1988){
viewcommentary("Adult Chat","Add",25);}else{
output("`b`^You are to young so get out of here!");
}

page_header("Adult Chat");
addnav("V?Return to Village", "village.php");
page_footer();
?>