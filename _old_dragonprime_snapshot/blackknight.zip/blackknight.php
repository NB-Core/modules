<?php

function blackknight_getmoduleinfo(){
		$info = array(
		"name"=>"Black Knight",
		"author"=>"Kendear and LonnyL converted to new version by `&S`7ephiroth",
		"category"=>"Specialties",
		"download"=>"",
		"version"=>"1.0",
		"settings"=>array(
			"lifecost"=>"How much life will be taken to buy ATK, DEF, or GOLD?,bool|0",
			"gemgain"=>"How many gems will user get?,bool|0",
			"goldgain"=>"How much gold will user get?,bool|0)",
		),
		"prefs" => array(
			"Specialty - Black Knight User Prefs,title",
			"skill"=>"Skill points in Black Knight,int|0",
			"uses"=>"Uses of Black Knight allowed,int|0",
		),
	);
	return $info;
}

function blackknight_install(){
	if (!is_module_active('blackknight')){
		output("`c`b`QInstalling Black Knight Module.`b`n`c");
	}else{
		output("`c`b`QUpbkting Black Knight Module.`b`n`c");
	}
	$sql = "DESCRIBE " . db_prefix("accounts");
	$result = db_query($sql);
	$specialty="BK";
	while($row = db_fetch_assoc($result)) {
		// Convert the user over
		if ($row['Field'] == "blackknight") {
			debug("Migrating blackknight field");
			$sql = "INSERT INTO " . db_prefix("module_userprefs") . " (modulename,setting,userid,value) SELECT 'specialtyblackknight', 'skill', acctid, blackknight FROM " . db_prefix("accounts");
			db_query($sql);
			debug("Dropping blackknight field from accounts table");
			$sql = "ALTER TABLE " . db_prefix("accounts") . " DROP blackknight";
			db_query($sql);
		} elseif ($row['Field']=="bkrkartuses") {
			debug("Migrating blackknight uses field");
			$sql = "INSERT INTO " . db_prefix("module_userprefs") . " (modulename,setting,userid,value) SELECT 'specialtyblackknight', 'uses', acctid, bkrkartuses FROM " . db_prefix("accounts");
			db_query($sql);
			debug("Dropping bkrkartuses field from accounts table");
			$sql = "ALTER TABLE " . db_prefix("accounts") . " DROP bkrkartuses";
			db_query($sql);
		}
	}
	debug("Migrating Black Knight Specialty");
	$sql = "UPDATE " . db_prefix("accounts") . " SET specialty='$specialty' WHERE specialty='1'";
	db_query($sql);

	module_addhook("choose-specialty");
	module_addhook("set-specialty");
	module_addhook("fightnav-specialties");
	module_addhook("apply-specialties");
	module_addhook("newday");
	module_addhook("incrementspecialty");
	module_addhook("specialtynames");
	module_addhook("specialtymodules");
	module_addhook("specialtycolor");
	module_addhook("dragonkill");
	return true;
}

function blackknight_uninstall(){
	output("`n`c`b`QBlack Knight Module Uninstalled`0`b`c");
	$sql = "UPDATE " . db_prefix("accounts") . " SET specialty='' WHERE specialty='BK'";
	db_query($sql);
	return true;
}

function blackknight_dohook($hookname, $args){
	global $session,$resline;
	$spec = "BK";
	$name = "Black Knight";
	$ccode = "`$";

	switch ($hookname) {
	case "dragonkill":
		set_module_pref("uses", 0);
		set_module_pref("skill", 0);
		break;
	case "choose-specialty":
		if ($session['user']['specialty'] == "" ||
				$session['user']['specialty'] == '0') {
			addnav("$ccode$name`0","newday.php?setspecialty=$spec$resline");
			$t1 = translate_inline("Killing a lot of woodland creatures");
			$t2 = appoencode(translate_inline("$ccode$name`0"));
			rawoutput("<a href='newday.php?setspecialty=$spec$resline'>$t1 ($t2)</a><br>");
			addnav("","newday.php?setspecialty=$spec$resline");
		}
		break;
	case "set-specialty":
		if($session['user']['specialty'] == $spec) {
			page_header($name);
			output("`5Growing up, you recall killing many small woodland creatures, insisting that they were plotting against you.");
			output("Your parents, concerned that you had taken to killing the creatures barehanded, bought you your very first pointy twig.");
			output("It wasn't until your teenage years that you began performing bkrk rituals with the creatures, disappearing into the forest for days on end, no one quite knowing where those sounds came from.");
		}
		break;
	case "specialtycolor":
		$args[$spec] = $ccode;
		break;
	case "specialtynames":
		$args[$spec] = translate_inline($name);
		break;
	case "specialtymodules":
		$args[$spec] = "specialtyblackknight";
		break;
	case "incrementspecialty":
		if($session['user']['specialty'] == $spec) {
			$new = get_module_pref("skill") + 1;
			set_module_pref("skill", $new);
			$c = $args['color'];
			$name = translate_inline($name);
			output("`n%sYou gain a level in `&%s%s to `#%s%s!",
					$c, $name, $c, $new, $c);
			$x = $new % 3;
			if ($x == 0){
				output("`n`^You gain an extra use point!`n");
				set_module_pref("uses", get_module_pref("uses") + 1);
			}else{
				if (3-$x == 1) {
					output("`n`^Only 1 more skill level until you gain an extra use point!`n");
				} else {
					output("`n`^Only %s more skill levels until you gain an extra use point!`n", (3-$x));
				}
			}
			output_notl("`0");
		}
		break;
	case "newday":
		$bonus = getsetting("specialtybonus", 1);
		if($session['user']['specialty'] == $spec) {
			$name = translate_inline($name);
			if ($bonus == 1) {
				output("`n`2For being interested in %s%s`2, you receive `^1`2 extra `&%s%s`2 use for today.`n",$ccode, $name, $ccode, $name);
			} else {
				output("`n`2For being interested in %s%s`2, you receive `^%s`2 extra `&%s%s`2 uses for today.`n",$ccode, $name,$bonus, $ccode,$name);
			}
		}
		$amt = (int)(get_module_pref("skill") / 3);
		if ($session['user']['specialty'] == $spec) $amt = $amt + $bonus;
		set_module_pref("uses", $amt);
		break;
	case "fightnav-specialties":
		$uses = get_module_pref("uses");
		$script = $args['script'];
		if ($uses > 0) {
			addnav(array("$ccode$name (%s points)`0", $uses),"");
			addnav(array("$ccode &#149; Skeleton Crew`7 (%s)`0", 1), 
					$script."op=fight&skill=$spec&l=1", true);
		}
		if ($uses > 1) {
			addnav(array("$ccode &#149; Voodoo`7 (%s)`0", 2),
					$script."op=fight&skill=$spec&l=2",true);
		}
		if ($uses > 2) {
			addnav(array("$ccode &#149; Curse Spirit`7 (%s)`0", 3),
					$script."op=fight&skill=$spec&l=3",true);
		}
		if ($uses > 4) {
			addnav(array("$ccode &#149; Wither Soul`7 (%s)`0", 5),
					$script."op=fight&skill=$spec&l=5",true);
		}
		break;
	case "apply-specialties":
		$skill = httpget('skill');
		$4 = httpget('4');
		if ($skill==$spec){
			if (get_module_pref("uses") >= $l){
				switch($4){
				case 1:
					apply_buff('bk1',array(
						"startmsg"=>"`\$You call on the spirits of the dead, and skeletal hands claw at {badguy} from beyond the grave.",
						"name"=>"`\$Skeleton Crew",
						"rounds"=>5,
						"wearoff"=>"Your skeleton minions crumble to dust.",
						"minioncount"=>round($session['user']['level']/3)+1,
						"maxbadguybkmage"=>round($session['user']['level']/2,0)+1,
						"effectmsg"=>"`)An undead minion hits {badguy}`) for `^{bkmage}`) bkmage.",
						"effectnodmgmsg"=>"`)An undead minion tries to hit {badguy}`) but `\$MISSES`)!",
						"schema"=>"module-specialtyblackknight"
					));
					break;
				case 2:
					apply_buff('bk2',array(
						"startmsg"=>"`\$You pull out a tiny doll that looks like {badguy}",
						"effectmsg"=>"You thrust a pin into the {badguy} doll hurting it for `^{bkmage}`) points!",
						"minioncount"=>1,
						"maxbadguybkmage"=>round($session['user']['attack']*3,0),
						"minbadguybkmage"=>round($session['user']['attack']*1.5,0),
						"schema"=>"module-specialtyblackknight"
					));
					break;
				case 3:
					apply_buff('bk3',array(
						"startmsg"=>"`\$You place a curse on {badguy}'s ancestors.",
						"name"=>"`\$Curse Spirit",
						"rounds"=>5,
						"wearoff"=>"Your curse has faded.",
						"badguydmgmod"=>0.5,
						"roundmsg"=>"{badguy} staggers under the weight of your curse, and deals only half bkmage.",
						"schema"=>"module-specialtyblackknight"
					));
					break;
				case 5:
					apply_buff('bk5',array(
						"startmsg"=>"`\$You hold out your hand and {badguy} begins to bleed from its ears.",
						"name"=>"`\$Wither Soul",
						"rounds"=>5,
						"wearoff"=>"Your victim's soul has been restored.",
						"badguyatkmod"=>0,
						"badguydefmod"=>0,
						"roundmsg"=>"{badguy} claws at its eyes, trying to release its own soul, and cannot attack or defend.",
						"schema"=>"module-specialtyblackknight"
					));
					break;
				}
				set_module_pref("uses", get_module_pref("uses") - $l);
			}else{
				apply_buff('bk0', array(
					"startmsg"=>"Exhausted, you try your bkrkest magic, a bad joke.  {badguy} looks at you for a minute, thinking, and finally gets the joke.  Laughing, it swings at you again.",
					"rounds"=>1,
					"schema"=>"module-specialtyblackknight"
				));
			}
		}
		break;
	}
	return $args;
}

function blackknight_run(){
$op=httpget($op);

$lifecost = round(get_module_setting("lifecost","blackknight"));
$gemgain = get_module_setting("gemgain","blackknight");
$goldgain = get_module_setting("goldgain","blackknight");

if($op==""){
	page_header("The Necromancer Hall");
output("`%`c`bThe Necromancer Hall`b`c");

// Death Knights get in for free.
if($session[user][specialty]==4){
	output("`n`n`7You stand on a twisted pathway in the bkrkest corner of `4Eythgim Village`7.  You step out of the mists and stroll towards the massive Iron gates that protect the Dark Temple. A pair of Necromancers see you approach and immediately open the gates for you. `n\"`5Welcome, %s`5, we are honored that you have returned.`7\"",$session['user']['name']);
	addnav("Enter the Temple","runmodule.php?module=blackknight&op=continue");
	addnav("Return to the Village","village.php");

}else{
output("`n`n`7You stand on a twisted pathway in the bkrkest corner of `4Eythgim Village`7.  A mist surrounds you and there is a sense");
output("of dread in the air. Warriors in black stroll casually towards this bkrk building and through a pair of massive iron doors. The `4Eythgim Tournament`7 has brought many souls to these black gates. Some seek victory in the tournament, other seek to further their understanding of the `4Black Knight`7. All of them seek power. Even in the face of the holy Cathedral, a bkrk magic thrives in Eythgim. You see a `4Death Knight `7walk into the Dark Temple as the robed Necromancers bow in respect. There is an order here that is quite obvious for those who can see.");
output("`n`n`7You approach the gateway to the Necromancer Hall`7 and two cloaked guards step out of the shadows. `n\"`5All are welcomed who pay the toll. We require `%2 gems`5 before you may enter here.`7\"");

//cost of entry or go away.
	if($session[user][gems]<2){
	output("`n`n`%Since you can not afford their request they step back into the shadows and the door magically bolts shut.");
	addnav("Return to the Eythgim","eythgim.php");

	}else{
	addnav("Pay the Toll","runmodule.php?module=blackknight&op=paid");
	addnav("Return to the Eythgim","eythgim.php");
		}
}
//pay the toll
}else if($op=="paid"){
page_header("The Necromancer Halls");
	output("`%`c`bThe Necromancer Hall`b`c");
	$session[user][gems]-=2;
	redirect("runmodule.php?module=blackknight&op=continue");

}else if($op=="continue"){
page_header("The Necromancer Halls");
output("`%`c`bThe Necromancer Hall`b`c");

output("`n`n`7Silently you walk down the sculpted corridors of the Necromancer Hall. Mages in bkrk robes ignore you as they patiently move about their domain. Making your way to the main chamber, you're greeted by a Necromancer in black leather armor. On his gauntlet you recognize the symbol of a famous Lich King, fabled to be long dead. Without remark on this knowledge, you nod to the Death Knight and he says,`n`n");
output("`4\"I sense potential in you. If you are willing to pay the cost, I can help you grow stronger or richer. I can grant you powers beyond that of mortal skill or the dusty books of noble sages. Everything has a price and
		we are the servants of your ambition.");
		
if ($session[user][maxhitpoints]>$lifecost*1.3){
addnav("Lifeforce");
addnav(array("Trade %s MaxHP for Strength",$lifecost),"runmodule.php?module=blackknight&op=str");
addnav(array("Trade MaxHP for Defense",$lifecost),"runmodule.php?module=blackknight&op=def");
addnav(array("Trade MaxHP for Wealth",$lifecost),"runmodule.php?module=blackknight&op=wealth");
}
addnav("Curses");
addnav("Mount Curse `^4000 `6Gold","runmodule.php?module=blackknight&op=cast&spell=mount&cost=4000");
addnav("Death Curse `^400000 `6Gold","runmodule.php?module=blackknight&op=cast&spell=death&cost=400000");
addnav("Arts");
if($session[user][specialty]!=1){addnav("Black Knight `^3000 `6Gold","runmodule.php?module=blackknight&op=blackknight");}
if($session[user][specialty]!=4){addnav("Death Knight `^25`4 (F)","runmodule.php?module=blackknight&op=dknight");}
if($session[user][specialty]==1){addnav("Training`^ 5`4 (F)","runmodule.php?module=blackknight&op=train");}
if($session[user][specialty]==4){addnav("Training`^ 5`4 (F)","runmodule.php?module=blackknight&op=train");}
addnav("Other");
addnav("Return to Eythgim","eythgim.php");

//Start other options now //ss//
///////ss// CURSES //////////////ss////////////////////////////////////////
}else if($op=="cast"){
page_header("The Necromancer Hall");
output("`%`c`bNecromancer Curse`b`c");

if (get_special_var(NecromancerCastCurse,Necromancer1)){
output("`7`n`nThe Death Knight shakes the room in a roar of laughter and heinous joy as he bellows,`n");
output("`n\" `4 Your burning hatred is admired, but you've already cast curses once today. `n Love not only hatred, but patience is also our way. Be patient and unyielding. Your enemy shall learn to fear you.`7\"");
addnav("Reconsider this Curse","runmodule.php?module=blackknight&op=continue");

}else if ($session['user']['gold']< $_GET[cost]){
		output("`5The room shakes as thunder booms in the air around you. The priestess shakes her head and throws you a wicked glance. Perhaps you should have make certain you have enough money before requesting her services. She may turn you into something. . . un-natural.`n");
	    output("`n`n`@You don't have enough money for that curse.");
	    addnav("Reconsider this Curse","runmodule.php?module=blackknight&op=continue");
		}else{		
		
addnav("Reconsider this Curse","runmodule.php?module=blackknight&op=continue");
$string="%";
for ($x=0;$x<strlen($_POST['name']);$x++){
	$string .= substr($_POST['name'],$x,1)."%";
}
$sql = "SELECT login,name,level FROM accounts WHERE name LIKE '".addslashes($string)."' AND locked=0 ORDER BY level,login";
$result = db_query($sql);
		        output("`\$The Death Knight`) will allow you to curse these people:`n");
		        output("<table cellpadding='3' cellspacing='0' border='0'>",true);
		        output("<tr class='trhead'><td>Name</td><td>Level</td></tr>",true);
		          for ($i=0;$i<db_num_rows($result);$i++){
			      $row = db_fetch_assoc($result);
			      output("<tr class='".($i%2?"trlight":"trbkrk")."'><td><a href='runmodule.php?module=blackknight&op=cast2&spell=$_GET[spell]&cost=$_GET[cost]&name=".HTMLEntities($row['login'])."'>",true);
			      output_not1($row['name']);
			      rawoutput("</a></td><td>",true);
			      output_not1($row['level']);
			      rawoutput("</td></tr>",true);
			      addnav("","runmodule.php?module=blackknight&op=cast2&spell=$_GET[spell]&cost=$_GET[cost]&name=".HTMLEntities($row['login']));
		          }
	}
}

if($op=="cast2"){
	page_header("The Necromancer Hall");
	output("`%`c`bA Curse`b`c");
	$sql = "SELECT name,level,acctid FROM accounts WHERE login='{$_GET['name']}'";
	$result = db_query($sql);
	if (db_num_rows($result)>0){
		$row = db_fetch_assoc($result);

		if (get_special_var(VoodooCurse,VoodooHut,$row['acctid'])){
			output("`4That person has already been cursed, please select another target.");
			addnav("Continue","runmodule.php?module=blackknight&op=continue");
		}
		else{
			$session['user']['gold']-=$_GET[cost];
			set_special_var(NecromancerCastCurse,true,Necromancer1);
			output("`@`n`nYou have successfully placed a spell of ".$_GET[spell]." on `7{$row['name']}`)!");
			
			set_special_var(VoodooCursedBy,$session[user][name],VoodooHut,$row['acctid']);
			set_special_var(VoodooCurse,$_GET[spell],VoodooHut,$row['acctid']);
		 	
			systemmail($row['acctid'],"`)You are CURSED!","`)An evil curse of ".$_GET[spell]." has been cast on you by {$session['user']['name']}!");
            addnav("Return to Eythgim","eythgim.php");
        }
}
///////ss// Lifeforce /////////ss/////////////////////////////////////////

}else if($op=="str" || $op=="def" || $op=="wealth"){
$session[user][maxhitpoints] -= $lifecost;
if($session[user][hitpoints]>$session[user][maxhitpoints]){
$session[user][hitpoints]=$session[user][maxhitpoints];
}
page_header("The Necromancer Hall");
output("`%`c`bThe Ritual`b`c");
output("`n`n`7You decide that the path to victory sometimes requires a little blood and you tell the Death Knight that you're willing to pay. He laughs at your bravery and several Necromancers escort you to a nearby chamber. You stand before a bkrk alter where a silver platter holds a bkrk pool of blood. The Necromancers take your arm and drive a stone bkgger deep into the muscle. You feel your life ebb slowly into the pool with every drop of vital fluid they spill. The low hum of their incantation fills your ears as blackness takes you. You wakeup in a lush room on a soft daybed. Several warriors are also in the room with you. They all sleep quietly in velvet couches, dreaming of their new strength, and its cost.");
output("`n`n`7Two cloaked guards step out of the shadows, ready to escort you back to the world. `n\"`5It is time for you to go.`7\"`n`n");
addnav("Stumble back to the Eythgim","eythgim.php");
if($op=="str"){
$session[user][attack]++;
output("`%Your strength has increased by `^1`%, but at the cost of`$ %s `%hitpoints.",$lifecost);
}else if($op=="def"){
$session[user][defence]++;
output("`%Your defence has increased by `^1`%, but at the cost of`$ %s `5hitpoints.",$lifecost);
}else if($op=="wealth"){
$session[user][gold] += $goldgain;
$session[user][gems] += $gemgain;
output("`%You gain `^%s gold `% and `^%s gems`%, but at the cost of`$ %s `%hitpoints.",$goldgain,$gemgain,$lifecost);

}

}

page_footer();


}
?>