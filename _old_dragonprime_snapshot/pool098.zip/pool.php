<?php
/* Pool of Water  18June2005
   Author: Robert of Maddrio dot com
   Converted from a 097 forest event
*/

function pool_getmoduleinfo(){
	$info = array(
	"name"=>"Pool of Water",
	"version"=>"1.0",
	"author"=>"`2Robert",
	"category"=>"Forest Specials",
	"download"=>"http://dragonprime.net/users/robert/pool098.zip",
	);
	return $info;
}

function pool_install(){
	module_addeventhook("forest","return 100;");
	return true;
}

function pool_uninstall(){
	return true;
}

function pool_dohook($hookname,$args){
	return $args;
}

function pool_runevent($type){

	global $session;
	$from = "forest.php?";
	$session['user']['specialinc'] = "module:pool";
	$op = httpget('op');

	if ($op=="" || $op=="search"){
	output("`n`n`2You encounter a sparkling clear pool of water. `n`n`&What will you do?");
	addnav("Pool of Water");
	addnav("(1) Take a Drink", $from."op=drink");
	addnav("(2) Dont risk it", $from."op=dont");
	}elseif ($op=="drink"){
		$session['user']['specialinc'] = "";
		output("`n`n`2 The pool of water is so tempting you decide to take a drink. `n`n");
		output(" You discover that ");
		switch(e_rand(1,5)){ 
		case 1:
		output(" you feel a surge of energy and receive an extra forest fight!");
		$session['user']['turns']++;
		break;
		case 2: 
		output(" on the bottom of the pool you spot a gold coin ...Lucky you!");
		$session['user']['gold']+=1;
		break;
		case 3:
		output(" the water is warm but refreshing, you feel better.");
		$session['user']['hitpoints']+=1;
		break;
		case 4:
		output(" the water is refreshing and you feel much better.");
		$session['user']['hitpoints']+=2;
		break;
		case 5:
		output(" the water is cool and refreshing, you feel so much better.");
		$session['user']['hitpoints']+=3;
		break;

}
}else{
output("`n`2 Not wanting to take the risk, you head back to the forest. "); 
$session['user']['specialinc'] = "";
}
}

function pool_run(){
}
?>