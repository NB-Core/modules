<?
/*********************************************
Lots of Code from: lonnyl69 - Big thanks for the help.
By: Kevin Hatfield - Arune v1.0
06-19-04 - Public Release
Written for Fishing Add-On - Poseidon Pool

Translation and simple modifications by deZent deZent@onetimepad.de


ALTER TABLE accounts ADD wormprice int(11) unsigned not null default '0';
ALTER TABLE accounts ADD minnowprice int(11) unsigned not null default '0';
ALTER TABLE accounts ADD wormavail int(11) unsigned not null default '0';
ALTER TABLE accounts ADD minnowavail int(11) unsigned not null default '0';
ALTER TABLE accounts ADD trades int(11) unsigned not null default '0';
ALTER TABLE accounts ADD worms int(11) unsigned not null default '0';
ALTER TABLE accounts ADD minnows int(11) unsigned not null default '0';
ALTER TABLE accounts ADD fishturn int(11) unsigned not null default '0';
add to newday.php
$session['user']['trades'] = 10;
if ($session[user][dragonkills]>1)$session[user][fishturn] = 3;
if ($session[user][dragonkills]>3)$session[user][fishturn] = 4;
if ($session[user][dragonkills]>5)$session[user][fishturn] = 5;
Now in village.php:
addnav("Poseidon Pool","pool.php");
********************************************/
require_once "common.php";
checkday();
addcommentary();
page_header("Der magische See");
//check and display inventory
output("`2Du hast in deinem Beutel.`n");
//Worms
$worms=$session[user][worms];
if ($session[user][worms]>0){ //These were added due to counters going into negative.
output("`!W�rmer - $worms`n");
}else{
output("`!W�rmer - 0`n");
}
$inventory=$session[user][worms];
//Minnows
$minnow=$session[user][minnows];
if ($session[user][minnows]>0){ //These were added due to counters going into negative.
output("`!Fliegen - $minnow`n");
}else{
output("`!Fliegen - 0`n");
}
$inventory+=$session[user][minnows];
$fishturns=$session[user][fishturn];
if ($session[user][fishturn]>0){ //These were added due to counters going into negative.
output("`!Runden zum fischen - $fishturns`n");
}else{
output("`!Runden zum fischen - 0`n");
}
if ($HTTP_GET_VARS[op] == "" ){
}
//output("`c<img src='images/fishing.jpg''>`c", true);
addnav("To do");
if ($session[user][minnows] > 0 and $session[user][fishturn] > 0) addnav("`!Fliege auswerfen","fish.php?op=check1");
if ($session[user][worms] > 0 and $session[user][fishturn] > 0) addnav("`!Wurm auswerfen","fish.php?op=check2");

if (($session[user][hitpoints])>0) {
	addnav("R?Zur�ck zum See","pool.php");
	addnav("B?Angelshop","bait.php");
}
else {addnav("S?Weiter","village.php");}

output("`n`n`7Du folgst dem Weg um den See...`n");
output("Wenn du dich umschaust siehst du andere Dorfbewohner die sich am See aufhalten.`n");
output("Du bist dir sicher, dass dir heute der gro�e Wurf gelingt.`n`n");
if ($HTTP_GET_VARS[op]=="check1"){
        output("`n`nDu wirfst deine Angel aus...`n`n");
        $session[user][minnows]-=1;
        $session[user][fishturn]-=1;
              check1();
}
if ($HTTP_GET_VARS[op]=="check2"){
        output("`n`nDu wirfst deine Angel aus...`n`n");
        $session[user][worms]-=1;
        $session[user][fishturn]-=1;
              check2();
}
output("`n`2-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-`n");
viewcommentary("fishing", "Etwas schreiben", 1000, "says");

/*******************
Fishing With Minnows
*******************/
function check1(){
global $session;
switch (e_rand(1,25)){
case 1:
output("Ein Boot?!`n");
output("Du brauchst gut 10 Minuten, bis du endlich den Knoten vom Steg gel�st hast...`n");
output("Das hat gedauert....`n`n");
output("`bDu verliehrst eine Angelrunde`n`n");
$session[user][fishturn]-=1;

break;

case 2:
output("`@ Du f�ngst einen kleinen Beutel... `n`n");
$a=e_rand(2,75);
output("`^In dem Beutel findest du",$a,"gold !!`^`n`n");
$session[user][gold]+= $a;
$session[user][fishturn]-=1;

break;

case 3:
output("Beim auswerfen verf�ngt sich der Angelhaken in deinem Ohr!!!! `n`n");
$b=e_rand(10,20);
output("Du verliehrst `^$b`^ Lebenspunkte`n");
$session[user][hitpoints] -= $b;
output("`!So ein gef�hrlicher See!`!`n");
output("`4Du entscheidest dich heute lieber nicht mehr zu angeln...`n`n");
$session[user][fishturn]=0;


break;

case 4:
output("Mit all deinem K�nnen hast du nichts gefangen! `n`n");
$session[user][fishturn]-=1;

break;

case 5:
output("`@Du bist dir sicher, dass du einen schweren Fisch am Haken hast!!!`n`n");
output("`@.........`n");
output("`@Leider war es doch nur ein alter Stiefel`n");
$session[user][fishturn]-=1;


break;

case 6:
output("`2Dein Haken verf�ngt sich in deiner Hand!! `nDu verliehrst 12 Lebenspunkte. `n`n");
$session[user][hitpoints]-=12;
$session[user][fishturn]-=1;
if ($session[user][hitpoints]<=0){
     $session[user][hitpoints]=1;
     output("`$ Ramius akzeptiert deinen j�mmerlichen Anglertod nicht!`n Er gibt dir einen Lebenspunkt, da er sein Schattenreich nicht mit unf�higen Weicheiern f�llen m�chte! ");


};


break;

case 7:
output("Leider bist du beim fischen eingeschlafen, und hast nicht mitbekommen ob etwas angebissen hat!`n`n");
$session[user][fishturn]-=1;

break;

case 8:
$number = e_rand(1,5);
output("Gerade als du deine Leine einholst siehst du im feuchten Gras etwas schimmern.....`n`n");
output("`^`bDu findest einen Edelstein !!! `^`b`n`n");
$session[user][gems]+=1;
$session[user][fishturn]-=1;

break;

case 9:
output("`@Du f�ngst etwas... `n`n");
output("`!Ein kleiner Beutel h�ngt an deinem Angelhaken... `n`n");
output("`&`bDu findest 3 W�rmer!`n `b`n`n");
$session[user][worms]+=3;
$session[user][fishturn]-=1;

break;

case 10:
output("`!Du f�ngst ein seltsames Silberkreuz! `n`n");
output("`7Als du es vom Haken nimmst beginnt es leicht zu leuchten`n");
output("Ein pulsierendes Leuchten erhellt das Ufer!!!`n`n");
        if    (strchr($session[user][weapon],"Glowing")){
        output("`b`4Deine Waffe beginnt ebenfalls zu gl�hen!");
        break;
        }else{
output(" Du f�hlst dich st�rker");
debuglog("Weapon - Glowing enhancement from pool");
$session[user][hitpoints]+=20;
$session[user][attack]+=5;
$session[user][defence]+=3;
$session[user][fishturn]-=1;
$newweapon = "gl�hend - ".$session[user][weapon];
$session[user][weapon]=$newweapon;
$session[user][weapondmg]+2;
}
break;

case 11:
output("`4Der Wind erfasst deine Angelschnur und wickelt sie um deinen Hals...Der Haken verf�ngt sich in deinem Mund!`n`n");
output("`3In Panik ziehst du an deiner Angel!`n");
output("`7Dabei zeihst du die Schlinge noch fester zu und f�llst auf den Boden!`n");
addnews("`@".$session[user][name]."`@ hat sich beim angeln `5erh�ngt`@.");
$session[user][alive]=false;
$session[user][hitpoints]=0;
$session[user][fishturn]-=1;

break;

case 12:
output("`3Dein Wurm ist dir vom Haken geh�pft und freut sich seines Lebens.. `n`n `$ Seit wann k�nnen W�rmer spingen?!?!`3 `n`n");
$session[user][fishturn]-=1;

break;

case 13:
output("Du hast nichts gefangen!`n`n");
$session[user][fishturn]-=1;

break;

case 14:
output("`7Du rutschst aus und f�llst ins Wasser !`n");
output("Da du nicht gut schwimmen kannst, kannst du dich gerade noch an Land retten.`n");
output("`^Durch diese peinliche Vorstellung verliehrst du 2 Charmpunkte!");
$session[user][charm]-=2;

break;

case 15:
output("`3Du hast Mitleid mit dem Wurm / der Fliege und schenkst Ihr die Freiheit!`3 `n`n");
$session[user][fishturn]-=1;
$session[user][charm]+=1;

break;

case 16:
output("Du f�ngst einen enormen Barsch!`n`n");
output("`7Da du eh Hunger hast isst du ihn noch am See`n");
$session[user][hitpoints]=$session[user][maxhitpoints];
$session[user][fishturn]-=1;

break;

case 17:
output("`@Du sp�rst einen Ruck an der Angel!`n`n");
output("`6Du ziehst mit einem Ruck...stolperst zur�ck und wirfst deinen Beutel mit K�der um`n");
output("`4Du verliehrst alle deine K�der!`n`n");
$session[user][minnows]=0;
$session[user][fishturn]-=1;
break;

case 18:
output("`@Du sp�rst einen Ruck an der Angel!`n`n");
output("Du springst zur�ck und zerrst mit all deiner Kraft an der Rute!`n");
output("`7ZUVIEL f�r deine Rute! Sie bricht und schl�gt dir ins Gesicht!`n");
output("`4AUTSCH! Direkt ins Auge.... das hat weh getan`n`n");
$session[user][hitpoints]=3;
$session[user][fishturn]-=1;

break;

case 19:
output("`2Du ziehst eine verfaulte Wasserleiche an Land! `2`n`n");
output("`7........`n");
output("Nach kurzem �berlegen untersuchst du ihren Goldbeutel,`n");
output("`^und findest 351 Gold!`n`n");
output("`2 Die Seejungfrau des Sees findet deine Aktion jedoch nicht sehr nett und zieht dir zwei Runden fischen ab!`n`n");
output("`^und findest 351 Gold!`n`n");
$session[user][gold]+=351;
$session[user][fishturn]-=2;

break;

case 20:
output("Du f�ngst leider nichts!`n`n Eine Erfahrung mehr in deinem Leben..`n `$ Du lernst, dass man nicht immer gewinnen kann");
$session[user][experience]+=250;
$session[user][fishturn]-=1;

break;

case 21:
output("`2Beim auswerfen der Leine siehst du eine Box mit W�rmern neben dir im Geb�sch!`2`n`n");
output("`^Du findest 3 W�rmer!`n`n");
$session[user][worms]+=3;

break;

case 22:
output("Du f�ngst einen kleinen Lederbeutel! `n`n");
output("^Darin findest du 2 Edelsteine!`n");
$session[user][gems]+=2;
$session[user][fishturn]-=1;

break;

case 23:
output("`2Du siehst eine kleine Welle, die sich sehr schnell auf deinen K�der zubewegt!`n`n");
output("`$ ZU `2 schnell f�r deinen Geschmack!`n");
output("Sicherheitshalber ziehst du deinen K�der schnell wieder ein!`n");
$session[user][fishturn]-=1;

break;

case 24:
output("Ein kleiner Goldfisch springt ans Ufer und bei�t dich in den Zeh!`n AUTSCH!");
$session[user][fishturn]-=1;
$session[user][hitpoints]-=1;

break;

case 25:
output("Du triffst genau ins Zentrum des Sees!`n`n Ein Blitz durchf�hrt deinen K�rper`n");
output("Die G�tter meinen es heute gut mit dir!");
output("`^Du f�hlst dich st�rker!");
$session[user][attack]+=8;
$session[user][fishturn]-=1;

break;

case 26:
output("`4Du stolperst �ber einen Stein und f�llst ins Wasser! `0!`n`n");
output("Nat�rlich landest du an der seichtesten Stelle des Sees und knallst mit dem Kopf auf einen Stein`n");
output("Als du wieder aufwachst stellst du fest, dass dir jemand dein ganzes Gold gestohlen hat!`n`n");
$session[user][hitpoints]=1;
$session[user][fishturn]=0;
$session[user][gold]=0;

break;
}
}
/************************
Fishing with worms
************************/
function check2(){
global $session;
switch (e_rand(1,21)){
case 1:

output("Du, wenn man es genauer betrachtet, NICHTS gefangen! `n`n");
$session[user][fishturn]-=1;

break;

case 2:

output("Du hast nichts gefangen! `n`n");
$session[user][fishturn]-=1;

break;

case 3:

output("Du f�ngst einen schweren Lederbeutel...`n");
output("Darin findest du 3 Edelsteine.`n");
output("`^3 Edelsteine!`0`n`n");
$session[user][fishturn]-=1;
$session[user][gems]+=3;

break;

case 4:

output("Du f�ngst einen enormen Fisch!`n");
output("Viele Fischer werden auf dich neidisch sein.`n");
output("`^Du bekommst 3 Charmpunkte!`0`n`n");
$session[user][charm]+=3;
$session[user][fishturn]-=1;

break;

case 5:

output("Deine Angelschnur ist gerissene!`n");
output("Du verliehrst deinen K�der`n`n");
$session[user][fishturn]-=1;
break;

case 6:

output("Als du deinen Haken einholst siehst du das du einen B�schel Seegras gefangen hast.`n");
output("Der B�schel stinkt so sehr, dass sofort  `^15 Fliegen dran h�ngen`0!`n`n");
$session[user][fishturn]-=1;
$session[user][minnows]+=15;


break;

case 7:

output("Auch nach einer Stunde hast du noch nichts gefangen! `n`n");
$session[user][fishturn]-=1;

break;

case 8:

output("Du siehst jemanden hinter dem Geb�sch und rufst ihm laut `iHALLO!`i zu. `n In diesem Moment f�llt dir ein wie dumm das von dir war.... `n`n Nat�rlich wei�t du, dass f�r die n�chste Stunde alle Fische verscheucht hast! `n`n");
$session[user][fishturn]-=1;

break;

case 9:

output("Du hast nichts gefangen! `n`n");
$session[user][fishturn]-=1;

break;

case 10:

output("Du hast nichts gefangen! `n`n");
$session[user][fishturn]-=1;

break;

case 11:

output("Du hast den K�dern neben den See geworfen... Eine Stunde sp�ter bist du dir endlich sicher, dass man an Land keine Fische fangen kann.. `n`n");
$session[user][fishturn]-=1;

break;

case 12:

output("Du hast nichts gefangen! `n`n");
$session[user][fishturn]-=1;

break;

case 13:
output("Als du deine Leine einholst siehst du etwas gl�hendes am Haken h�ngen`n");
output("Ein schwacher Energiesto� trifft deinen K�rper`n`n");
output("`^Deine Verteidigung steigt!`0`n`n");
$session[user][fishturn]-=1;
$session[user][defence]+=10;

break;

case 14:
output("`!Du f�ngst einen Kristall! `n`n");
output("`7Als du den Kristall in deiner Hand h�lst..`n");
output("beginnt das schwarze Wasser blau zu leuchten!!!`n`n");
        if    (strchr($session[user][weapon],"geh�rtet")){
        output("`b`4Deine Waffe ist immernoch geh�rtet!");
        break;
        }else{
output(" Deine Waffe wird schwerer und irgendwie f�hlt sie sich m�chtiger an.`n`n");
debuglog("Weapon - Crystalized enhancement from pool");
$session[user][hitpoints]+=20;
$session[user][attack]+=15;
$session[user][defence]+=15;
$session[user][fishturn]-=1;
$newweapon = "geh�rtet - ".$session[user][weapon];
$session[user][weapon]=$newweapon;
$session[user][weapondmg]+3;
}
break;

case 15:

output("Du f�ngst einen gigantischen Fisch!!`n");
output("Zappeld ziehst du ihn ans Ufer!`n");
output("Als zu ihn mit all deinen Kr�ften an Land gezogen hast und feststellst, dass er nicht zur�ck ins Wasser will, sondern sich schnappend in deine Richtung bewegt ziehst du schnell deine Waffe.!`n");
output("Unsicher stellst du dich dem Fisch..`n");
output("Struggling to get your belt lose you are running out of air quickly!`n");
if ($session[user][attack]<25){
 output("`4Gerade als zustechen wolltest packt dich der Fisch unerwartet am Fu� und zieht dich ins Wasser.`n`n Du wehrst dich mit all deiner Kraft, doch das pechschwarze Wasser raubt dir bereits den Blick zur Sonne. `n Der Fisch zieht dich immer weiter in die Tiefen des Sees..");
 $session[user][alive]=false;
 $session[user][experience]-=500;
 }else{
 $waffe1=$session[user][weapon];
 output("`!Der Fisch packt dich am Fu�, du nutzt deine Chance und erlegst ihn gekonnt mit deine(m) $waffe1 !`n`n");
 $session[user][fishturn]+=1;
 $session[user][experience]+=1000;
}

break;

case 16:

output("Du bist beim fischen eingeschlafen.... `n Als du wieder aufwachst stellst du fest, dass dein ganzes Gold verschwunden ist`n");
$session[user][fishturn]-=1;

break;

case 17:

output("Du hast nichts gefangen! `n`n");
$session[user][fishturn]-=1;

break;

case 18:
If ($session[user][sex]==0){
     output("Weit entfernt siehst du den Umriss einer Gestallt durch den dichten Nebel schimmern... Es k�nnte eine Seejungfrau sein... `n`n");
     output("Es ist eine Seejungfrau!! `^ Du bekommst einen Charmpunkt`n");
     }
If ($session[user][sex]==1){
     output("Weit entfernt siehst du den Umriss einer Gestallt durch den dichten Nebel schimmern... Es k�nnte ein Seejungmann sein... `n`n");
     output("Es ist ein Seejungmann!! `^ Du bekommst einen Charmpunkt`n");
     }
$session[user][fishturn]-=1;
$session[user][charm]+=1;

break;

case 19:

output("Du hast nichts gefangen! `n`n");
$session[user][fishturn]-=1;

break;

case 20:

output("`0Du hast einen Beutel  `^Gold`0 gefangen!`n");
output("Ganz auf all das Gold fixiert z�hlst du die M�nzen!`n");
output("`4BOOM! `0Du wurdest von etwas stumpfen getroffen...Und gehst zu Boden!`n`n");
output("`i Wieder einer auf den alten Goldbeuteltrick reingefallen`i h�rst du gerade noch als bei dir das Licht ausgeht!`n`n");
$session[user][hitpoints]=1;
$session[user][fishturn]=0;
$session[user][gold]=0;

break;

case 21:

output("Du hast etwas gefangen ....`n");
output("`^a Mei�el!`n");
output("`&Als du �ber die vielf�ltigen Einsatzgebiete eines Mei�els nachdenkst ber�hrst du versehntlich deine R�stung.`n");
output("`0Wow..irgendwie passt deine R�stung jetzt viel besser als zuvor. Sie wirkt auch irgendwie stabiler!`n");
if    (strchr($session[user][armor],"ver�ndert")){
        output("`b`4Leider war deine R�stung auch zuvor schon ver�ndert und du stellst fest, dass du dir das Ganze nur eingebildet hast!`n`n");
        break;
        }else{
output(" Deine R�stung wurde verbessert! Vor lauter freude wirfst du den Mei�el wieder in den See`n");
debuglog("Armor - Chisel enhancement from pool");
$session[user][defence]+=15;
$session[user][fishturn]-=1;
$newarmor = "verst�rkt ".$session[user][armor];
$session[user][armor]=$newarmor;
$session[user][charm]+=5;
output("Mit der neuen R�stung siehst du viel besser aus!`n");
output("`^Du bekommst 5 Charmpunkte!`n`n");
}

break;
}
}
page_footer();
?>