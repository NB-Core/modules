<?
/*********************************************
Lots of Code from: lonnyl69 - Thanks Lonny !
Also Thanks to Excalibur @ dragonprime for your help.
By: Kevin Hatfield - Arune v1.0
06-19-04 - Public Release
Written for Fishing Add-On - Poseidon Pool

Translation and simple modifications by deZent deZent@onetimepad.de



ALTER TABLE accounts ADD wormprice int(11) unsigned not null default '0';
ALTER TABLE accounts ADD minnowprice int(11) unsigned not null default '0';
ALTER TABLE accounts ADD wormavail int(11) unsigned not null default '0';
ALTER TABLE accounts ADD minnowavail int(11) unsigned not null default '0';
ALTER TABLE accounts ADD trades int(11) unsigned not null default '0';
ALTER TABLE accounts ADD worms int(11) unsigned not null default '0';
ALTER TABLE accounts ADD minnows int(11) unsigned not null default '0';
ALTER TABLE accounts ADD fishturn int(11) unsigned not null default '0';
add to newday.php
$session['user']['trades'] = 10;
if ($session[user][dragonkills]>1)$session[user][fishturn] = 3;
if ($session[user][dragonkills]>3)$session[user][fishturn] = 4;
if ($session[user][dragonkills]>5)$session[user][fishturn] = 5;

Now in village.php:
addnav("Poseidon Pool","pool.php");
********************************************/
require_once "common.php";
checkday();
page_header("Kerra's Angelladen");
output("`@`c`bKerra's Angelladen`b`c`n");
//
$myname=$session[user][name];
//
//check and display inventory
output("`2Du hast in deinem Beutel.`n");
//Worms
$worms=$session[user][worms];
output("`1Angelw�rmer - $worms`n");
$inventory=$session[user][worms];
//Minnows
$minnow=$session[user][minnows];
output("`!Fliegen - $minnow`n");
$inventory+=$session[user][minnows];
//Trades
$trades=$session[user][trades];
output("`7Du hast $trades Transaktionen �brig.`n");
//Inventory Checking//
$space=(50 - $inventory);
if ($inventory < 50) output("`2du hast noch f�r $space Dinge Platz im Beutel.`n`n");
if ($inventory > 49) output("`4Du bemerkst, dass dein Beutel schon voll ist.`n`n");
//
//built first time navigation
        if ($HTTP_GET_VARS[op]==""){
        if ($session[user][trades] > 0)
        $wormgold = e_rand(1,4);
        $session[user][wormprice]=$wormgold;
        $minnowgold = e_rand(5,9);
        $session[user][minnowprice]=$minnowgold;
        $wormavail = e_rand(5,25);
        $session[user][wormavail]=$wormavail;
        $minnowavail= e_rand(5,25);
        $session[user][minnowavail]=$minnowavail;
    }
//cancelled buy or sell navigation
if ($HTTP_GET_VARS[op]=="" or $HTTP_GET_VARS[op]=="trade"){
if ($session[user][trades] > 0){
if ($HTTP_GET_VARS[op]==""){
 if ($session[user][dragonkills]>=1){
 output("`5Kerra hinter der Theke, er sagt \"`6Was m�chtest du heute kaufen?`5\"`n");
}else{
 output("Kerra geht um die Theke , er sagt \"`6Es tut mir leid, aber du bist noch nicht erfahren genug um zu fischen... Du w�rdest mit deinem getrampel die Fische verschecken!`0\"`n`n");
}
}
if ($HTTP_GET_VARS[op]=="trade") output("`5Kerra sagt \"`6Noch etwas?`5\"`n");$wormgold=$session[user][wormprice];

$wormgold=$session[user][wormprice];
$minnowgold=$session[user][minnowprice];
if ($session[user][minnowavail] > 1 and $session[user][dragonkills]>=2) output("`5Wenn du noch etwas erfahrener bist kannst du sicher auch alleine mit W�rmern angeln...`n Solange solltest du dich auf die harmloseren Fliegen beschr�nken. `n");

if ($session[user][wormavail] > 1 and $session[user][dragonkills]>6) addnav("`!W�rmer `^($wormgold gold)","bait.php?op=worms");
if ($session[user][minnowavail] > 1 and $session[user][dragonkills]>=2) addnav("`!Fliegen `^($minnowgold gold)","bait.php?op=minnow");

addnav("`@Zur�ck zum See","pool.php");
}
else{
        output("`4Du kannst heute nicht mehr handeln.`n");
        addnav("`@Zur�ck zum See","pool.php");
}
}
//Selections
if ($HTTP_GET_VARS[op]=="worms"){
        $wormgold=$session[user][wormprice];
        output("`3W�rmer kosten $wormgold gold, m�chtest du welche kaufen oder verkaufen?`n");
        addnav("`2Kaufen","bait.php?op=wormbuy");
        addnav("`4Verkaufen","bait.php?op=wormsell");
        addnav("`!Etwas anderes kaufen","bait.php?op=trade");
        addnav("`@Zur�ck zum See","pool.php");
    }
if ($HTTP_GET_VARS[op]=="minnow"){
        $minnowgold=$session[user][minnowprice];
        output("`3Fliegen kosten $minnowgold gold, m�chtest du welche kaufen oder verkaufen?`n");
        addnav("`2Kaufen","bait.php?op=minnowbuy");
        addnav("`4Verkaufen","bait.php?op=minnowsell");
        addnav("`!Etwas anderes kaufen","bait.php?op=trade");
        addnav("`@Zur�ck zum See","pool.php");
    }
//buy products
if ($HTTP_GET_VARS[op]=="wormbuy"){
        if ($inventory>49){
                output("`!Dein Beutel ist doch schon voll! Verkauf erstmal etwas.`n");
            }
        else{
        output("`%Wieviele W�rmer m�chtest du heute kaufen?`n");
    output("<form action='bait.php?op=wormbuy2' method='POST'><input name='buy' id='buy'><input type='submit' class='button' value='kaufen'></form>",true);
    output("<script language='JavaScript'>document.getElementById('buy').focus();</script>",true);
    addnav("","bait.php?op=wormbuy2");
    }
    addnav("`!Etwas anderes kaufen","bait.php?op=trade");
        addnav("`@Zur�ck zum See","pool.php");
}
if ($HTTP_GET_VARS[op]=="wormbuy2"){
        $buy = $HTTP_POST_VARS[buy];
        if ($buy > (50 - $inventory)) $buy = (50 - $inventory);
        if ($session[user][gold] < ($buy * $session[user][wormprice])) output("Das kannst du dir nicht leisten!");
        else{
                output("`!Der Mann nimmt dein Gold und gibt dir $buy zappelnde W�rmer.");
                $cost=($buy * $session[user][wormprice]);
                $session[user][gold]-=$cost;
                $session[user][worms]+=$buy;
                $session[user][trades]-=1;
            }
        addnav("`!Etwas anderes kaufen","bait.php?op=trade");
        addnav("`@Zur�ck zum See","pool.php");
    }

if ($HTTP_GET_VARS[op]=="minnowbuy"){
        if ($inventory>49){
                output("`!Dein Beutel ist doch schon voll! Verkauf erstmal etwas.`n");
            }
        else{
        output("`%Wieviele Fliegen m�chtest du heute kaufen?`n");
    output("<form action='bait.php?op=minnowbuy2' method='POST'><input name='buy' id='buy'><input type='submit' class='button' value='kaufen'></form>",true);
    output("<script language='JavaScript'>document.getElementById('buy').focus();</script>",true);
    addnav("","bait.php?op=minnowbuy2");
    }
    addnav("`!Etwas anderes kaufen","bait.php?op=trade");
        addnav("`@Zur�ck zum See","pool.php");
}
if ($HTTP_GET_VARS[op]=="minnowbuy2"){
        $buy = $HTTP_POST_VARS[buy];
        if ($buy > (50 - $inventory)) $buy = (50 - $inventory);
        if ($session[user][gold] < ($buy * $session[user][wormprice])) output("Das kannst du dir nicht leisten!");
        else{
                output("`!Der Mann nimmt dein Gold und gibt dir $buy Fliegen.");
                $cost=($buy * $session[user][wormprice]);
                $session[user][gold]-=$cost;
                $session[user][minnows]+=$buy;
                $session[user][trades]-=1;
                }
                addnav("`!Etwas anderes kaufen","bait.php?op=trade");
        addnav("`@Zur�ck zum See","pool.php");
    }

//sell
if ($HTTP_GET_VARS[op]=="wormsell"){
        if ($session[user][worms]<1){
                output("`!Du hast weder W�rmer noch Fliegen zum verkaufen.`n");
            if ($session[user][sex]==0){
                output("`!Komm ja nicht auf die Idee deinen `$ EINZIGEN `!Wurm in den See zu h�ngen. Es k�nnen auch Kinder am See sein!`n");
                }
            }
        else{
        output("Du hast $worms W�rmer zum verkaufen.`n");
    output("`%Wieviele W�rmer m�chtest du verkaufen?`n");
    output("<form action='bait.php?op=wormsell2' method='POST'><input name='sell' id='sell'><input type='submit' class='button' value='verkaufen'></form>",true);
    output("<script language='JavaScript'>document.getElementById('bet').focus();</script>",true);
    addnav("","bait.php?op=wormsell2");
    }
    addnav("`!Etwas anderes kaufen","bait.php?op=trade");
        addnav("`@Zur�ck zum See","pool.php");
}

if ($HTTP_GET_VARS[op]=="wormsell2"){
        if ($session[user][worms] < $sell) output("`%Soviele W�rmer hast du nicht!`n");
        else{
                $cost=($sell * $session[user][wormprice]);
                output("`!Der Mann nimmt deine $sell W�rmer und gibt dir $cost gold.`n");
                $session[user][gold]+=$cost;
                $session[user][worms]-=$sell;
                $session[user][trades]-=1;
            }
        addnav("`!Etwas anderes kaufen","bait.php?op=trade");
        addnav("`@Zur�ck zum See","pool.php");
    }
if ($HTTP_GET_VARS[op]=="minnowsell"){
        if ($session[user][minnows]<1){
                output("`!Du hast keine Fliegen zum verkaufen.`n");
            }
        else{
        output("Du kannst $minnow Fliegen verkaufen.`n");
    output("`%Wieviele Fliegen m�chtest du verkaufen?`n");
    output("<form action='bait.php?op=minnowsell2' method='POST'><input name='sell' id='sell'><input type='submit' class='button' value='verkaufen'></form>",true);
    output("<script language='JavaScript'>document.getElementById('bet').focus();</script>",true);
    addnav("","bait.php?op=minnowsell2");
    }
    addnav("`!Etwas anderes verkaufen","bait.php?op=trade");
        addnav("`@Zur�ck zum See","pool.php");
}

if ($HTTP_GET_VARS[op]=="minnowsell2"){
        if ($session[user][minnows] < $sell) output("`%Du hast nicht so viele Fliegen!`n");
        else{
                $cost=($sell * $session[user][minnowprice]);
                output("`!Der Mann nimmt deine  $sell Fliegen und gibt dir $cost gold daf�r.`n");
                $session[user][gold]+=$cost;
                $session[user][minnows]-=$sell;
                $session[user][trades]-=1;
            }
        addnav("`!Etwas anderes kaufen","bait.php?op=trade");
        addnav("`@Zur�ck zum See","pool.php");


    }
page_footer();
?>