<?php

/*
A small special that can be encountered anywhere:
- village
- forest
- inn
- gardens (if you have LotGD version 1.1.0 or newer)
- during travel (if you have installed Multiple cities)
- library (if you have library version 2.73 or newer)

The Graveyard is the only place where you are safe...
*/

function theavatars_getmoduleinfo(){
	$info = array(
		"name"=>"The Avatars",
		"version"=>"1.0",
		"author"=>"shadowblack",
		"category"=>"Village Specials",
		"download"=>"http://dragonprime.net/index.php?module=Downloads;sa=dlview;id=985",
		"requires"=>array("alignment"=>"1.7|WebPixie<br> `#Lonny Luberts<br>`^and Chris Vorndran,available on Dragon Prime",
    ),
    "settings"=>array(
    "Avatars Settings,title",
    "mindk"=>"This event is available after how many Dragon Kills?,int|0",
    "attack"=>"Multiply player's attack by how much to set the Avatar's attack?,floatrange,1,2,0.05|1.4",
    "defense"=>"Multiply player's defense by how much to set the Avatar's defense?,floatrange,1,2,0.05|1.4",
    "hp"=>"Multiply player's hit points by how much to set the Avatar's hit points?,floatrange,1,2,0.05|1.5",
    ),
    "prefs"=>array(
    "Avatars Preferences,title",
    "avatar"=>"Which Avatar has the player encountered?,enum,0,None,1,Heavenly Avatar,2,Avatar of Balance,3,Infernal Avatar,|0",
    ),
	);
	return $info;
}

function theavatars_install(){
	module_addeventhook("forest", "return 100;");
	module_addeventhook("village", "return 100;");
	module_addeventhook("inn", "return 100;");
	module_addeventhook("gardens", "return 100;");
  if (is_module_installed("cities"))	module_addeventhook("travel", "return 100;");
	if (is_module_installed("library"))  module_addeventhook("library", "return 100;");
	return true;
}

function theavatars_uninstall(){
	return true;
}

function theavatars_dohook($hookname,$args){
	return $args;
}

function theavatars_runevent($type,$link){
	global $session;
	$from = $link;
	$op = httpget('op');
	$session['user']['specialinc'] = "module:theavatars";
  $battle = false;
  $mindk = get_module_setting("mindk");
  $dk = $session['user']['dragonkills'];

  Switch($type){
  Case "village":
  if($op==""){
    if (!is_module_active('alignment') || $dk<$mindk){
    output("As you walk around the village a cold wave passes through yur body. You stop for a bit and wonder what the cause could've been, then you go on your way.");
    $session['user']['specialinc'] = "";
    }else{
    output("As you walk around the village looking at what the various shops have to offer you hear a sound behind you, turn around sharply... and suddenly you are somewhere else...");
    addnav("Continue",$from."op=next");
    }
  }
  break;
  Case "forest":
  if($op=="" || $op=="search"){
    if (!is_module_active('alignment') || $dk<$mindk){
    output("As you walk through the forest looking for something to kill a cold wave passes through yur body. You stop for a bit and wonder what the cause could've been, then you go on your way.");
    $session['user']['specialinc'] = "";
    }else{
    output("As you walk through the forest looking for something to kill you hear a sound behind you, turn around sharply... and suddenly you are somewhere else...");
    addnav("Continue",$from."op=next");
    }
  }
  break;
  Case "inn":
  if($op==""){
    if (!is_module_active('alignment') || $dk<$mindk){
    output("As you look around the inn a cold wave passes through yur body. You stop for a bit and wonder what the cause could've been, then you go on your way.");
    $session['user']['specialinc'] = "";
    }else{
    output("As you look around the inn you blink... and suddenly you are somewhere else...");
    addnav("Continue",$from."op=next");
    }
  }
  break;
  Case "gardens":
  if($op==""){
    if (!is_module_active('alignment') || $dk<$mindk){
    output("As you explore the gardens a cold wave passes through yur body. You stop for a bit and wonder what the cause could've been, then you go on your way.");
    $session['user']['specialinc'] = "";
    }else{
    output("As you explore the gardens you sit down on a bench and close your eyes for a few seconds. When you open them you are somewhere else...");
    addnav("Continue",$from."op=next");
    }
  }
  break;
  Case "travel":
  if($op==""){
    if (!is_module_active('alignment') || $dk<$mindk){
    output("As you travel towards your destination a cold wave passes through yur body. You stop for a bit and wonder what the cause could've been, then you go on your way.");
    $session['user']['specialinc'] = "";
    }else{
    output("As you travel towards your destination you blink... and suddenly you are somewhere else...");
    addnav("Continue",$from."op=next");
    }
  }
  break;
  Case "library":
  if($op=="shelves"|| $op==""){
    if (!is_module_active('alignment') || $dk<$mindk){
    output("As you walk through the library looking at the shelves a cold wave passes through yur body. You stop for a bit and wonder what the cause could've been, then you go on your way.");
    $session['user']['specialinc'] = "";
    }else{
    output("As you walk through the library looking at the shelves you blink... and suddenly you are somewhere else...");
    addnav("Continue",$from."op=next");
    }
  }
  break;
  Default:
// Just in case something is wrong..
    output("Error! Something has gone wrong! Please inform the admin about this!");
    $session['user']['specialinc'] = "";
  break;
  }

  if($op=="next"){
  if (file_exists("./modules/alignment/func.php"))
  require_once("./modules/alignment/func.php");

  $avatar = e_rand(1,3);
  set_module_pref("avatar",$avatar);
  $weapon = array(
  1=>array(1=>"Heavenly Blades", 2=>"Divine Fury", 3=>"Celestial Thunder"),
  2=>array(1=>"Spirit Blades", 2=>"Lightning Storm", 3=>"Force Strike"),
  3=>array(1=>"Infernal Blades", 2=>"Rain of Fire", 3=>"Doom Bolts"),
  );
  $w = e_rand(1,3);
  $atk = get_module_setting("attack");
  $attack = round($session['user']['attack']*$atk);
  $def = get_module_setting("defense");
  $defense = round($session['user']['defense']*$def);
  $hp = get_module_setting("hp");
  $monhp = round($session['user']['maxhitpoints']*$hp);

  $align = get_align();
  $alignevil = get_module_setting("evilalign",'alignment');
  $aligngood = get_module_setting("goodalign",'alignment');
  if($align<=$alignevil){
  $evil = 1;
  }elseif($align>=$aligngood){
  $good = 1;
  }

  output("`n`nYou take a look around and see nothing but fog. It is so thick that you can't even see what you are standing on. You call out, but no one answers. No matter how hard you stare your gaze cannot penetrate the fog. Just as you wonder how to go back you hear a voice...`n");
  Switch($avatar){
  Case "1":
    if($good==1){
    output("\"`@Good shall triumph above all. For being a faithful servant of good you shall be rewarded...`0\"");
    output("`n`nYou receive the Avatar's blessing!");
    apply_buff('avatarbless',array(
    "name"=>"Avatar's Blessing",
    "defmod"=>2,
    "rounds"=>-1,
    "roundmsg"=>"Your defense is greatly enhanced by the Avatar's blessing!",
		"schema"=>"module-theavatars",
    ));
    $session['user']['specialinc'] = "";
    }else{
    output("\"`@Good shall triumph above all. You are in the way, and for that you will be destroyed...`0\"");
    output("`nAn ethereal creature emerges from the fog. It has the appearance of a winged humanoid, and stares at you with eyes devoid of all emotion...");
    $op = "fight";
    httpset("op",$op);

    $badguy = array(
		"creaturename"=>"Heavenly Avatar",
		"creatureweapon"=>$weapon[$avatar][$w],
		"creaturelevel"=>$session['user']['level']+2,
		"creaturehealth"=>$monhp,
		"creatureattack"=>$attack,
		"creaturedefense"=>$defense,
		"type"=>"avatar",
		);
		$session['user']['badguy'] = createstring($badguy);
    }
  break;
  Case "2":
    if($good==0 && $evil==0){
    output("\"`^Balance is the right path. For being a faithful servant of balance you will be rewarded...`0\"");
    output("`n`nYou receive the Avatar's blessing!");
    apply_buff('avatarbless',array(
    "name"=>"Avatar's Blessing",
    "atkmod"=>1.5,
    "defmod"=>1.5,
    "rounds"=>-1,
    "roundmsg"=>"Your attack and defense are significantly enhanced by the Avatar's blessing!",
		"schema"=>"module-theavatars",
    ));
    $session['user']['specialinc'] = "";
    }else{
    output("\"`^Balance is the right path. You, however, are on the wrong path. Think about the error of your ways while you are in `4Ramius'`^ domain...`0\"");
    output("`nAn ethereal creature emerges from the fog. Its body is humanoid and a large mask hides its entire head. The creature stares at you with empty eyes...");
    $op = "fight";
    httpset("op",$op);

    $badguy = array(
		"creaturename"=>"Avatar of Balance",
		"creatureweapon"=>$weapon[$avatar][$w],
		"creaturelevel"=>$session['user']['level']+2,
		"creaturehealth"=>$monhp,
		"creatureattack"=>$attack,
		"creaturedefense"=>$defense,
		"type"=>"avatar",
		);
		$session['user']['badguy'] = createstring($badguy);
    }
  break;
  Case "3":
    if($evil==1){
    output("\"`\$Evil shall conquer all. For being a faithful servant of evil you shall be rewarded...`0\"");
    output("`n`nYou receive the Avatar's blessing!");
    apply_buff('avatarbless',array(
    "name"=>"Avatar's Blessing",
    "atkmod"=>2,
    "rounds"=>-1,
    "roundmsg"=>"Your attack is greatly enhanced by the Avatar's blessing!",
		"schema"=>"module-theavatars",
    ));
    $session['user']['specialinc'] = "";
    }else{
    output("\"`\$Evil shall conquer all. And you will die for standing in the way...`0\"");
    output("`nAn ethereal demon emerges from the fog. It is somewhat humanoid and as it stares at you fire can be seen burning in its eyes...");
    $op = "fight";
    httpset("op",$op);

    $badguy = array(
		"creaturename"=>"Infernal Avatar",
		"creatureweapon"=>$weapon[$avatar][$w],
		"creaturelevel"=>$session['user']['level']+2,
		"creaturehealth"=>$monhp,
		"creatureattack"=>$attack,
		"creaturedefense"=>$defense,
		"type"=>"avatar",
		);
		$session['user']['badguy'] = createstring($badguy);
    }
  break;
  }
  }

  if($op == "fight"){
    if(get_module_pref("avatar")==0){
  //just in case something has gone wrong...
    output("Error! No opponent specified! Please inform the admin about this error!");
    $session['user']['specialinc'] = "";
    }else{
    apply_buff('ethereal',array(
        "name"=>"`0Ethereal Body",
				"rounds"=>-1,
				"atkmod"=>0.5,
				"roundmsg"=>"The Avatar's ethereal body renders your attacks ineffective!",
				"schema"=>"module-theavatars",
        ));
    }
  $battle = true;
  }
  if($op=="run"){//This should not be possibe, but just in case...
  output("You have no idea where you are or how to get out of here! You can't run away!");
	$op="fight";
	httpset('op',$op); 
  }

  if ($battle){
    include("battle.php");
  	if ($victory){
      set_module_pref("avatar",0);
      strip_buff("ethereal");
      output("`nSomehow you manage to defeat the Avatar. After the final blow you find yourself back where you were...");
      $expgain = round($session['user']['experience']*0.2);
      if($expgain<100) $expgain = 100;
      output("For your victory you receive %s experience.",$expgain);
      $session['user']['experience'] += $expgain;
      $session['user']['specialinc'] = "";
      addnews("`%%s`# has defeated one of the mighty `5Avatars!`0",$session['user']['name']);
  	}elseif($defeat){
      set_module_pref("avatar",0);
      strip_buff("ethereal");
      output("`nThe Avatar proves too powerful for you...`n`nYou have died! The lesson you received somewhat compensates the experience you have lost.");
      $exploss = round($session['user']['experience']*0.05);
      output("You loose all the gold you are carrying and %s experience.",$exploss);
      $session['user']['alive']=false;
  		$session['user']['hitpoints']=0;
  		$session['user']['experience']-=$exploss;
  		$goldlost = $session['user']['gold'];
  		$session['user']['gold'] = 0;
    	addnav("Daily News","news.php");
      addnews("`%%s `#disappeared without a trace...`0",$session['user']['name']);
      debuglog("Was killed by an Avatar and lost: $goldlost gold, $exploss experience.");
      $session['user']['specialinc'] = "";
    }else{
    require_once("lib/fightnav.php");
      if ($type == "forest"){
				fightnav(true, false);
			}else{
				fightnav(true, false, $link);
			}
    }
  }

}

function theavatars_run(){
}

?>
