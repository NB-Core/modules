<?php
/***********************************888888*************
  Dragon Kills and Registered Users
  LotGD 1.0.0+
  Coded By: Dragon89  Date: 07/30/06
  
  This will place a small blurb on the index page
  with the total dk's and register users for the site
/*****************************************888888*******/

function dkreguser_getmoduleinfo(){
	$info = array(
		"name"=>"DragonKills & Reg Users",
		"author"=>"Dragon89",
		"version"=>"1.0",
		"category"=>"General",
		"download"=>"",
		"settings"=>array(
			"DragonKills & Reg Users Settings,title",
			"showdks"=>"Show dragonkills on index,bool|1",
            "showreg"=>"Show registered players on index,bool|1",
	    ),
	);
	return $info;
}
function dkreguser_install(){
	module_addhook("index");
	return true;
}
function dkreguser_uninstall(){
	return true;
}
function dkreguser_dohook($hookname,$args){
	switch($hookname){
		case "index":
		if(get_module_setting("showdks") == TRUE){
            $sql = db_query("SELECT SUM(dragonkills) as dkcount FROM accounts");
            $row = db_fetch_assoc($sql);
			$dkcount = $row['dkcount'];
			if($dkcount > 0) {
                output("`&There are a total of `%%s`& Dragonkills to date.`0`n", number_format($dkcount));
			} else {
				output("`&There are no Dragonkills in this realm.`0`n");
			}
		}
		if(get_module_setting("showreg") == TRUE){
            $sql1 = db_query("SELECT COUNT(acctid) as regcount FROM accounts");
            $row1 = db_fetch_assoc($sql1);
			$regcount = $row1['regcount'];
            output("`&There are a total of `%%s`& registered players in the realm.`0`n", number_format($regcount));
		}
        break;
	}
	return $args;
}
function dkreguser_run(){
}
?>