Installation and use is pretty simple, so I am not going to explain it here.
Note: all currencies that exchange for gold are lost at dragonkill!
Note: this module no longer uses altcurrencylib.php... you may delete it from your lib folder.

Instead I am going to use the readme.txt to explaing coding module for alternative currencies.

If you are going to make you module use alternative currencies only... please use the requires
statement.  If not...

Well let's start at the top.

First off.... module settings... (I'm going to borrow code from my converted secondweapon.php)

Module settings difference...
I start out setting module settings into it's own array before setting the info array

like so...
	$modsettings = array("Secondweapon Module Settings,title");
			$modsettings['bowshoploc'] = "Where does the Bow Shop appear,location|".getsetting("villagename", LOCATION_FIELDS);
			$modsettings['bowshopowner'] = "Name of the Bow Shop owner,text|Warnick";
			$modsettings['bowshopsex'] = "Sex of Bow Shop Owner,enum,he,Male,she,Female";
			
			
then, check to see if alt currencies is active and add the setting
also require the altcurrency module here to use it's functions
	if (is_module_active('altcurrency')){
			$modsettings['usealtcurrency'] = "Use Alternative Currency,bool|0";
		}

then check to see if the setting is set (also check if module is active or things break)
	if (is_module_active('secondweapon')){
			if (get_module_setting('usealtcurrency') == 1 AND is_module_active('altcurrency')){
				$list = altcurrency_buildlist();
				$modsettings['bowshopcurrency'] = "Bow Shop Which Currency to use?,enum".$list;
				$modsettings['bowcost'] = "Cost for Bow in Alt Currency,int|0";
				$modsettings['arrowcost'] = "Cost for Arrow in Alt Currency,int|0";
			}
		}
		
Now in the info array your settings should now look like
	"settings"=>$modsettings
	
In the following code... I first check if we should use the alternate currency
then I check to see if the currency module is active and set the usealt variable to 0.
The third thing done here is to set the variables before going into the heart of the code
to make the coding easier and reduce sql calls.
Note the use of the altcurrency_checkamt function....
	$usealt = get_module_setting('usealtcurrency');
	if (!is_module_active('altcurrency')) $usealt = 0; //do this just in case the altcurrency module is deactived or uninstalled
	if ($usealt == 1){
		//Bow,Crossbow,Sling
		//I used strtolower($weap) and ($ammo) as I had these variables already set and made
		//the code much smaller
		$currency = get_module_setting(strtolower($weap)."shopcurrency");
		$weapcost = get_module_setting(strtolower($weap)."cost");
		$ammocost = get_module_setting(strtolower($ammo)."cost");
		$amnthave = altcurrency_checkamt($currency);
	}else{
		$currency = "gems";
		$weapcost = get_module_setting('weapcost');
		$ammocost = 1;
		$amnthave = $session['user']['gems'];
	}
	
now we can output for both currencies with one line.
	output("`#\"At %s %s they are a great deal!\"`n",$weapcost,$currency);
	
and we can check if the player has enough currency 
	if ($amnthave >= $weapcost){
		//blah blah blah
	}
	
and here we can take the correct currency either an alt or gold/gems
Note the use of the altcurrency_adjustdown function (there is a altcurrency_adjustup as well)
	if ($usealt == 0){
			$session['user']['gems']-=round($weapcost * .33);
		}else{
			altcurrency_adjustdown($currency,round($weapcost * .33));
		}

So.. here ends our lesson... for now.....