<?php
global $session;
$op = httpget('op');
$mode = httpget('mode');
if ($mode == 'editor'){
	page_header("Currency Editor");
	$editarray=array(
	"Currency Stats and Costs,title",
	"id"=>"Currency ID,hidden",
	"name"=>"Currency Name,Name|Pip",		
	"goldval"=>"Gold Value,int|0",
	"gemval"=>"Gem Value,int|0",
	"battle"=>"Can be found in battle,enum,0,No,1,Yes",
	"battlepercent"=>"Percentage of How often found in battle,int|0",
	"findmax"=>"Max Quantity found in forest,int|0",
	"exchange"=>"Allow Exchange,enum,0,No,1,Yes",
	);	
	$id = httpget('id');
	$from = "runmodule.php?module=altcurrency&mode=editor&";	
	if ($op=="view"){
		$edit = translate_inline("Edit");
		$del = translate_inline("Delete");
		$delconfirm = translate_inline("Are you sure you wish to delete this currency?");	
		$sql = "SELECT * FROM ".db_prefix("altcurrency")." WHERE id>=0 ORDER BY id";
		$result = db_query($sql);	
		if (db_num_rows($result)<1){
			output("");
		}else{
			$row = db_fetch_assoc($result);
		}
	output("`@`c`b-=Currency Editor=-`b`c");
	output("<table border=1 cellspacing=0 cellpadding=2 width='100%' align='center'><tr><td>`7`bEdit`b</td><td>`&`bID`b</td><td>`2`bCurrency Name`b</td><td>`6`bGold Value`b</td><td>`5`bGem Value`b</td><td>`@`bAllow in Battle`b</td><td>`@`bHow often found(%)`b</td><td>`@`bMax amount found`b`0</td><td>`4`bAllow Exchange`b`0</td></tr>",true);    
	$result = db_query($sql);
	for ($i=0;$i<db_num_rows($result);$i++){
		$row = db_fetch_assoc($result);
		output("<tr class='".($i%2?"trlight":"trdark")."'>",true); 
		rawoutput("<td>[<a href='runmodule.php?module=altcurrency&mode=editor&op=edit&id={$row['id']}'>$edit</a>|<a href='runmodule.php?module=altcurrency&mode=editor&op=delete&id={$row['id']}' onClick='return confirm(\"$delconfirm\");'>$del</a>]</td>");   	   
		addnav("","runmodule.php?module=altcurrency&mode=editor&op=edit&id={$row['id']}");
		addnav("","runmodule.php?module=altcurrency&mode=editor&op=delete&id={$row['id']}");    
		output("<td>`&%s</td>",$row['id'],true);
		output("<td>`2%s</td>",$row['name'],true);
		output("<td>`6%s</td>",$row['goldval'],true);    	
		output("<td>`5%s</td>",$row['gemval'],true);
		output("<td>`@%s</td>",($row['battle']?"`2yes":"`4no"),true); 
		output("<td>`@%s</td>",$row['battlepercent'],true);  
		output("<td>`@%s</td>",$row['findmax'],true); 
		output("<td>%s</td>",($row['exchange']?"`2yes":"`4no"),true);	   
		output("</tr>",true);
	}    	
	output("</table>",true);
	modulehook("altcurrency", array());      
	addnav("Functions");
	addnav("Add a Currency", $from."op=add"); 
	addnav("Refresh List", $from."op=view");
	addnav("Other");	
	addnav("Return to the Grotto", "superuser.php");
	villagenav();
	}elseif ($op=="edit" OR $op=="add"){
		require_once("lib/showform.php");
		if ($op=="edit"){
			$sql = "SELECT * FROM ".db_prefix("altcurrency")." WHERE id='$id'";
			$result = db_query($sql);
			$row = db_fetch_assoc($result);
		}else{
			$row=array(
			"id"=>"",
			"name"=>"",		
			"goldval"=>"",
			"gemval"=>"",
			"battle"=>"",
			"battlepercent"=>"",
			"findmax"=>"",
			"exchange"=>"",
			);
		}
		rawoutput("<form action='runmodule.php?module=altcurrency&mode=editor&op=save' method='POST'>");
		addnav("","runmodule.php?module=altcurrency&mode=editor&op=save");
		showform($editarray,$row);
		rawoutput("</form>");
		addnav("Go Back","runmodule.php?module=altcurrency&mode=editor&op=view");
	}elseif ($op=="save"){
		$id = httppost('id');
		$name = httppost('name');
		$goldval = httppost('goldval');
		$gemval = httppost('gemval');
		$battle = httppost('battle');
		$battlepercent = httppost('battlepercent');
		$findmax = httppost('findmax');
		$exchange = httppost('exchange');
		if ($id>0){
			$sql = "UPDATE ".db_prefix("altcurrency")." SET name=\"$name\",goldval=$goldval, gemval=$gemval, battle=$battle, battlepercent=$battlepercent, findmax=$findmax, exchange=$exchange WHERE id='$id'";
			output("`6%s `6has been successfully edited.`n`n",$name);		
		}else{
			$sql = "INSERT INTO ".db_prefix("altcurrency")." (name,goldval,gemval,battle,battlepercent,findmax,exchange) VALUES (\"$name\",$goldval,$gemval,$battle,$battlepercent,$findmax,$exchange)";
			output("`6The currency \"%s\" `6has been saved to the database.`n`n",$name);
		}
		db_query($sql);
		$currencylist = "";
				$sql = "SELECT name FROM ".db_prefix("altcurrency");
				$result = db_query($sql);
				for ($i=0;$i<db_num_rows($result);$i++){
					$row = db_fetch_assoc($result);
					$currencylist .= ",".$row['name'].",".$row['name'];
				}
				set_module_setting("currencylist",$currencylist);
		$op = "";
		httpset("op", $op);	
		addnav("Go Back","runmodule.php?module=altcurrency&mode=editor&op=view");
	}elseif ($op == "delete"){
		$sql = "DELETE FROM ".db_prefix("altcurrency")." WHERE id='$id'";
		db_query($sql);
		output("Currency deleted!`n`n");
		redirect($from."op=view");
		addnav("Go Back","runmodule.php?module=altcurrency&mode=editor&op=view");
		$op = "";
		httpset("op", $op);
		$currencylist = "";
				$sql = "SELECT name FROM ".db_prefix("altcurrency");
				$result = db_query($sql);
				for ($i=0;$i<db_num_rows($result);$i++){
					$row = db_fetch_assoc($result);
					$currencylist .= ",".$row['name'].",".$row['name'];
				}
				set_module_setting("currencylist",$currencylist);
	}
}elseif ($mode == "exchange"){
	page_header("Currency Exchange");
	$curr = httpget('curr');
	if ($op <> ""){
		$sql = "SELECT name,id,goldval,gemval FROM ".db_prefix("altcurrency")." WHERE id = ".$curr." LIMIT 1";
		$result = db_query($sql);
		$row = db_fetch_assoc($result);
	}
	if ($op == ""){
		output("`c`2Welcome to the Currency exchange.`c`n");
		output("`2Note: Any Currency that exchanges for gold is lost at dragon kill.`n");
		$sql = "SELECT name,id,goldval,gemval,exchange FROM ".db_prefix("altcurrency");
		$result = db_query($sql);
		for ($i=0;$i<db_num_rows($result);$i++){
			$row = db_fetch_assoc($result);
			if ($row['exchange'] == 1){
				output("`2%s is currently exchanging for ",$row['name']);
				if ($row['goldval'] > 0) output("%s gold ",$row['goldval']);
				if ($row['goldval'] > 0 AND $row['gemval'] > 0) output("&");
				if ($row['gemval'] > 0) output ("%s gems",$row['gemval']);
				output(".`n`0");
				addnav($row['name']);
				addnav("`4Sell","runmodule.php?module=altcurrency&mode=exchange&op=sell&curr=".$row['id']);
				addnav("`2Buy","runmodule.php?module=altcurrency&mode=exchange&op=buy&curr=".$row['id']);
			}else{
				output("`4The Bank is not Exchanging %s.`n`0",$row['name']);
			}
		}
	}elseif ($op == "buy"){
		output("`%How many %ss would you like to buy?`n",$row['name']); 
	    rawoutput("<form action='runmodule.php?module=altcurrency&mode=exchange&op=buy2&curr=".$row['id']."' method='POST'><input name='howmany' id='howmany'><input type='submit' class='button' value='buy'></form>");
	    rawoutput("<script language='JavaScript'>document.getElementById('howmany').focus();</script>");
	    addnav("","runmodule.php?module=altcurrency&mode=exchange&op=buy2&curr=".$row['id']);
	    addnav("Cancel Transaction","runmodule.php?module=altcurrency&mode=exchange");
	}elseif ($op == "sell"){
		output("`%How many %ss would you like to sell?`n",$row['name']); 
		rawoutput("<form action='runmodule.php?module=altcurrency&mode=exchange&op=sell2&curr=".$row['id']."' method='POST'><input name='howmany' id='howmany'><input type='submit' class='button' value='sell'></form>");
	    rawoutput("<script language='JavaScript'>document.getElementById('howmany').focus();</script>");
	    addnav("","runmodule.php?module=altcurrency&mode=exchange&op=sell2&curr=".$row['id']);
	    addnav("Cancel Transaction","runmodule.php?module=altcurrency&mode=exchange");
	}elseif ($op == "buy2"){
		$howmany = httppost('howmany');
		if ($howmany < 0){
			output("`4`b`cWhat are you trying to do CHEAT?`b`c`0");
		}else{
		if ($session['user']['gems'] < $howmany * $row['gemval'] or $session['user']['gold'] < $howmany * $row['goldval']){
			output("`4You can't afford that many!`n`0");
			addnav("Continue","runmodule.php?module=altcurrency&mode=exchange");
		}else{
			$session['user']['gold'] -= $howmany * $row['goldval'];
			$session['user']['gems'] -= $howmany * $row['gemval'];
			altcurrency_adjustup($row['name'],$howmany);
			output("The Banker takes your ");
			if ($howmany * $row['goldval'] > 0) output("%s gold ",$howmany * $row['goldval']);
			if ($howmany * $row['goldval'] > 0 AND $howmany * $row['gemval'] > 0) output("&");
			if ($howmany * $row['gemval'] > 0) output ("%s gems ",$howmany * $row['gemval']);
			output(" and hands you %s %s.`n",$howmany,$row['name']);
			addnav("Continue","runmodule.php?module=altcurrency&mode=exchange");
		}
		}
	}elseif ($op == "sell2"){
		$howmany = httppost('howmany');
		if ($howmany < 0){
			output("`4`b`cWhat are you trying to do CHEAT?`b`c`0");
		}else{
		if ($howmany > get_module_pref($row['name'])){
			output("`4You don't have that many!`n`0");
			addnav("Continue","runmodule.php?module=altcurrency&mode=exchange");
		}else{
			$session['user']['gold'] += $howmany * $row['goldval'];
			$session['user']['gems'] += $howmany * $row['gemval'];
			altcurrency_adjustdown($row['name'],$howmany);
			output("The Banker takes your %s %s and hands you ",$howmany,$row['name']);
			if ($howmany * $row['goldval'] > 0) output("%s gold ",$howmany * $row['goldval']);
			if ($howmany * $row['goldval'] > 0 AND $howmany * $row['gemval'] > 0) output("&");
			if ($howmany * $row['gemval'] > 0) output ("%s gems",$howmany * $row['gemval']);
			output(".`n");
			addnav("Continue","runmodule.php?module=altcurrency&mode=exchange");
		}
		}
	}else{
		//should not be here redirect to exchange
		redirect("runmodule.php?module=altcurrency&mode=exchange");
	}
	addnav("Other");
	addnav("Back to the Lobby","bank.php");
	villagenav();
}else{
	//should not be here redirect to village
	redirect("village.php");
}
page_footer();
?>