<?php
//currency that has a goldval > 0 will clear at dragonkill and is lost in battle!
//todo - add hof for alt currencies...
function altcurrency_getmoduleinfo(){
	$prefs = array("Alternate Currency User Preferences,title",
				"moderate"=>"Admin/Moderator Access?,bool|0",
			);
	if (is_module_active('altcurrency')){	
		if (db_table_exists(db_prefix("altcurrency"))){
			$sql = "SELECT name FROM ".db_prefix("altcurrency");
			$result = db_query($sql);
			for ($i=0;$i<db_num_rows($result);$i++){
				$row = db_fetch_assoc($result);
				$currencyname = $row['name'];
				$prefs[$currencyname] = $currencyname." quantity.,int|0";
			}
		}
	}
	$info = array(
		"name"=>"Alternate Currencies",
		"version"=>"2.12",
		"author"=>"`#Lonny Luberts",
		"category"=>"PQcomp",
		"download"=>"http://www.pqcomp.com/modules/mydownloads/visit.php?cid=3&lid=86",
		"vertxtloc"=>"http://www.pqcomp.com/",
		"settings"=>array(
			"Alternate Currencies Module Settings,title",
			"exchange"=>"Allow currency exchange?,bool|1",
			"forestchance"=>"Chance for Find Currency\Bandits,enum,75,75% Find/25% Bandits,66,66% Find/33% Bandits,50,50% Find/50% Bandits,33,33% Find/66% Bandits,25,25% Find/75% Bandits",
		),
		"prefs"=>$prefs
	);
	return $info;
}

function altcurrency_install(){
	if (!is_module_active('altcurrency')){
		output("`4Installing Alternate Currencies Module.`n");
	}else{
		output("`4Updating Alternate Currencies Module.`n");
	}
	//table install
	if (!db_table_exists(db_prefix("altcurrency"))){
		$sql = "CREATE TABLE ".db_prefix("altcurrency")." (";
		$sql .= "`id` int(11) NOT NULL auto_increment,";
		$sql .= "`name` text NOT NULL,";
		$sql .= "`goldval` int(11) NOT NULL default '0',";
		$sql .= "`gemval` int(11) NOT NULL default '0',";
		$sql .= "`battle` int(11) NOT NULL default '0',";
		$sql .= "`battlepercent` int(11) NOT NULL default '0',";
		$sql .= "`findmax` int(11) NOT NULL default '0',";
		$sql .= "`exchange` int(11) NOT NULL default '0',";
		$sql .= "PRIMARY KEY  (`id`)";
		$sql .= ") TYPE=MyISAM;";
		db_query($sql);
	}
	//database upgrade
    $sql = "Select exchange FROM ".db_prefix("altcurrency")." LIMIT 1";
    $result = mysql_query($sql);
    if (!$result) db_query("ALTER TABLE ".db_prefix("altcurrency")." ADD `exchange` int(11) NOT NULL default '0'");
	//install a currency if none installed
	$sql = "Select id FROM ".db_prefix("altcurrency")." LIMIT 1";
    $result = mysql_query($sql);
    $row = mysql_fetch_assoc($result);
    if (!$row['id']) db_query("INSERT INTO ".db_prefix("altcurrency")." VALUES (1,'Salt',100,1,0,5,5,1)");
	module_addhook("battle-victory");
	module_addhook("battle-defeat");
	module_addhook("dragonkill");
	module_addhook("superuser");
	module_addhook("charstats");
	module_addhook("footer-bank");
	module_addeventhook("forest", "return 100;");
	module_addeventhook("travel", "return 20;");
	return true;
}

function altcurrency_uninstall(){
	output("`4Un-Installing Alternate Currencies Module.`n");
	$sql = "DROP TABLE ".db_prefix("altcurrency");
    db_query($sql);
	return true;
}

function altcurrency_dohook($hookname,$args){
	global $session;
	switch($hookname){
	case "footer-bank":
		if (get_module_setting('exchange') == 1){
			addnav("Currency Exchange","runmodule.php?module=altcurrency&mode=exchange");
		}
	break;
	case "charstats":
	$title = translate_inline("Personal Info");		
		$sql = "SELECT name FROM ".db_prefix("altcurrency");
		$result = db_query($sql);
		for ($i=0;$i<db_num_rows($result);$i++){
			$row = db_fetch_assoc($result);
			setcharstat($title,$row['name'],get_module_pref($row['name'])+0);
		}
	break;
	case "superuser":
		if (get_module_pref('moderate') == 1){
			addnav("Editors");
			addnav("Currency Editor","runmodule.php?module=altcurrency&mode=editor&op=view");
		}
	break;
	case "battle-victory":
		global $badguy,$session;
		if ($badguy['type']=='pvp'){
			$sql = "SELECT name,id,goldval FROM ".db_prefix("altcurrency");
			$result = db_query($sql);
			for ($i=0;$i<db_num_rows($result);$i++){
				$row = db_fetch_assoc($result);
				if ($row['goldval'] > 0){
					$wincurrency = get_module_pref($row['name'],'altcurrency',$badguy['acctid']);
					set_module_pref($row['name'],get_module_pref($row['name']) + $wincurrency);
					set_module_pref($row['name'],0,'altcurrency',$badguy['acctid']);
					if ($wincurrency > 0) output("`#You get `6%s`# %s!`n",$wincurrency,$row['name']);
				}
			}
		}else{
			if ($badguy['type'] <> 'train' and $session['user']['alive'] == 1){
				$sql = "SELECT name,findmax,battlepercent FROM ".db_prefix("altcurrency")." WHERE battle = 1 ORDER BY RAND(".e_rand().") LIMIT 1";
				$result = db_query($sql);
				$row = db_fetch_assoc($result);
				$quantity = e_rand(1,$row['findmax']);
				$currency = $row['name'];
				if (e_rand(0,99) < $row['battlepercent']){	
					output("`#You receive `6%s `#%s!`n",$quantity,$currency);
					set_module_pref($currency,get_module_pref($currency) + $quantity);
				}
			}
		}
	break;
	case "battle-defeat":
		global $badguy;
		if ($badguy['type']=='pvp'){
			$sql = "SELECT name,id,goldval FROM ".db_prefix("altcurrency");
			$result = db_query($sql);
			for ($i=0;$i<db_num_rows($result);$i++){
				$row = db_fetch_assoc($result);
				if ($row['goldval'] > 0){
					$wincurrency = get_module_pref($row['name'],'altcurrency',$badguy['acctid']);
					set_module_pref($row['name'],get_module_pref($row['name'],'altcurrency',$badguy['acctid']) + $wincurrency,'altcurrency',$badguy['acctid']);
					set_module_pref($row['name'],0,'altcurrency');
					if ($wincurrency > 0) output("`#You loose `6%s`# %s!`n",$wincurrency,$row['name']);
				}
			}
		}else{
			if ($badguy['type'] <> 'train'){
				$sql = "SELECT name,id,goldval FROM ".db_prefix("altcurrency");
				$result = db_query($sql);
				for ($i=0;$i<db_num_rows($result);$i++){
					$row = db_fetch_assoc($result);
					if ($row['goldval'] > 0){
						set_module_pref($row['name'],0);
						output("``3All %s on hand was lost!",$row['name']);
					}
				}
			}
		}
	break;
	case "dragonkill":
		$sql = "SELECT name,id,goldval FROM ".db_prefix("altcurrency");
		$result = db_query($sql);
		for ($i=0;$i<db_num_rows($result);$i++){
			$row = db_fetch_assoc($result);
			if ($row['goldval'] > 0){
				set_module_pref($row['name'],0);
			}
		}
	break;
	}
	return $args;
}

function altcurrency_runevent($type){
	global $session;
	if (e_rand(1,100) < get_module_setting("forestchance")){
		$sql = "SELECT name,findmax FROM ".db_prefix("altcurrency")." ORDER BY RAND(".e_rand().") LIMIT 1";
		$result = db_query($sql);
		$row = db_fetch_assoc($result);
		$quantity = e_rand(1,$row['findmax']);
		$currency = $row['name'];
		if ($type == "forest"){
			$placemess = translate_inline("wandering the forest");
		}else{
			$placemess = translate_inline("travelling");
		}	
		output("`# Lucky Day! While %s You find %s %s!`n",$placemess,$quantity,$currency);
		set_module_pref($currency,get_module_pref($currency) + $quantity);
	}else{
		output("`b`c`$Surprise!`0`c`b");
		output("`2Before you know what hit you, you find yourself lying on the ground, pinned by a very large masked bandit.  ");
		output("  While the big guy holds you down his buddies rifle through your stuff.`n");
		$sql = "SELECT name FROM ".db_prefix("altcurrency");
		$result = db_query($sql);
		for ($i=0;$i<db_num_rows($result);$i++){
			$row = db_fetch_assoc($result);
			$altloot = round(get_module_pref($row['name'],'altcurrency') * .25);
			if ($altloot > 0) output("The Masked Bandits take %s %s.`n",$altloot,$row['name']);
			set_module_pref($row['name'],(get_module_pref($row['name'],'altcurrency') - $altloot),'altcurrency');
		}
		output("`2The bandits leave as quickly as they appeared!`n");
	}
}

function altcurrency_run(){
	global $SCRIPT_NAME;
	if ($SCRIPT_NAME == "runmodule.php"){
		$module=httpget("module");
		if ($module == "altcurrency") include("modules/lib/altcurrency.php");
	}
}

function altcurrency_buildlist(){
	$currencylist = get_module_setting("currencylist",'altcurrency');
	if (!$currencylist){
		$currencylist = "";
		$sql = "SELECT name FROM ".db_prefix("altcurrency");
		$result = db_query($sql);
		for ($i=0;$i<db_num_rows($result);$i++){
			$row = db_fetch_assoc($result);
			$currencylist .= ",".$row['name'].",".$row['name'];
		}
		set_module_setting("currencylist",$currencylist,'altcurrency');
	}
	return $currencylist;
}
//these functions will evolve to include userid.....
function altcurrency_adjustup($currency,$amt){
	set_module_pref($currency,get_module_pref($currency,'altcurrency') + $amt,'altcurrency');
}

function altcurrency_adjustdown($currency,$amt){
	set_module_pref($currency,get_module_pref($currency,'altcurrency') - $amt,'altcurrency');
}

function altcurrency_checkamt($currency){
	$amt = get_module_pref($currency,'altcurrency');
	return $amt;
}
?>