<?php

//V1.2 Translation readied the addcharstat
//V1.3 Removed the .xx display bug at newday

/* based on the Gold in Bank Display module written by Mike Counts (genmac) for version .98 */

function bankedgold_getmoduleinfo(){
	$info = array(
		"name"=>"Banked Gold Display",
		"version"=>"1.3",
		"author"=>"Kurt P., fixes by SexyCook",
		"category"=>"Stat Display",
		"download"=>"http://dragonprime.net/users/Sivian/bankedgold.zip"
	);
	return $info;
}

function bankedgold_install(){
	module_addhook("charstats");
    return true;
}

function bankedgold_uninstall(){
	return true;
}

function bankedgold_dohook($hookname,$args){
	global $session;
	switch($hookname){
	case "charstats":
		$u = floor($session['user']['goldinbank']);
		addcharstat("Personal Info");
		addcharstat("Banked Gold", $u);
		break;
	default:
	}
	return $args;
}

function bankedgold_run(){

}
?>
