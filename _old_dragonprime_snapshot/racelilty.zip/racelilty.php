<?php

function racelilty_getmoduleinfo(){
	$info = array(
		"name"=>"Rasse - Lilty",
		"version"=>"1.0",
		"author"=>"`QBasilius `qSauter",
		"category"=>"Rassen",
		"download"=>"http://dragonprime.net/users/Eliwood/racepack1.zip",
		"settings"=>array(
			"Lilty-Einstellungen,title",
			"villagename"=>"Name der Stadt|Altamira",
			"minedeathchance"=>"Liltys sterben in der Mine zu (%),range,0,100,1|80",
		),
	);
	return $info;
}

function racelilty_install(){
	module_addhook("chooserace");
	module_addhook("setrace");
	module_addhook("newday");
	module_addhook("villagetext");
	//module_addhook("stabletext");
	module_addhook("travel");
	module_addhook("charstats");
	module_addhook("validlocation");
	module_addhook("validforestloc");
	module_addhook("moderate");
	module_addhook("changesetting");
	module_addhook("raceminedeath");
	//module_addhook("stablelocs");
	module_addhook("racenames");
	return true;
}

function racelilty_uninstall(){
	global $session;
	$vname = getsetting("villagename", LOCATION_FIELDS);
	$gname = get_module_setting("villagename");
	$sql = "UPDATE " . db_prefix("accounts") . " SET location='$vname' WHERE location = '$gname'";
	db_query($sql);
	if ($session['user']['location'] == $gname)
		$session['user']['location'] = $vname;
	$sql = "UPDATE  " . db_prefix("accounts") . " SET race='" . RACE_UNKNOWN . "' WHERE race='Lilty'";
	db_query($sql);
	if ($session['user']['race'] == 'Lilty')
		$session['user']['race'] = RACE_UNKNOWN;
	return true;
}

function racelilty_dohook($hookname,$args){
	//yeah, the $resline thing is a hack.  Sorry, not sure of a better way
	// to handle this.
	// Pass it as an arg?
	global $session,$resline;
	$city = get_module_setting("villagename");
	$race = "Lilty";
	switch($hookname){
	case "racenames":
		$args[$race] = $race;
		break;
	case "raceminedeath":
		if ($session['user']['race'] == $race) {
			$args['chance'] = get_module_setting("minedeathchance");
		}
		break;
	case "changesetting":
		// Ignore anything other than villagename setting changes
		if ($args['setting'] == "villagename" && $args['module']=="racelilty") {
			if ($session['user']['location'] == $args['old'])
				$session['user']['location'] = $args['new'];
			$sql = "UPDATE " . db_prefix("accounts") .
				" SET location='" . $args['new'] .
				"' WHERE location='" . $args['old'] . "'";
			db_query($sql);
			if (is_module_active("cities")) {
				$sql = "UPDATE " . db_prefix("module_userprefs") .
					" SET value='" . $args['new'] .
					"' WHERE modulename='cities' AND setting='homecity'" .
					"AND value='" . $args['old'] . "'";
				db_query($sql);
			}
		}
		break;
	case "charstats":
		if ($session['user']['race']==$race){
			addcharstat("Vital Info");
			addcharstat("Race", translate_inline($race));
		}
		break;
	case "chooserace":
		output("`0<a href='newday.php?setrace=$race$resline'>In %s aufgewachsen</a>, der Hauptstadt der Liltys, bist du in der K�mpferschule in die Kampfart der Liltys eingeweiht worden und kannst hervorragend mit den Lanzen umgehen.`n`n", $city, true);
		addnav("`4Lilty`0","newday.php?setrace=$race$resline");
		addnav("","newday.php?setrace=$race$resline");
		break;
	case "setrace":
		if ($session['user']['race']==$race){
			output("`4Da du ein Lilty bist, bekommst du einen zus�tzlichen Angiffspunkt.");
			$session['user']['attack']+=1;
			if (is_module_active("cities")) {
				if ($session['user']['dragonkills']==0 &&
						$session['user']['age']==0){
					set_module_setting("newest-$city",
							$session['user']['acctid'],"cities");
				}
				set_module_pref("homecity",$city,"cities");
				if ($session['user']['age'] == 0)
					$session['user']['location']=$city;
			}
		}
		break;
	case "newday":
		if ($session['user']['race']==$race){
			raceelf_checkcity();
			apply_buff("racialbenefit",array(
				"name"=>"`4 Schw�che der Lilty",
				"atkmod"=>0.9,
				"allowinpvp"=>1,
				"allowintrain"=>1,
				"rounds"=>30,
				"schema"=>"module-racelilty",
				)
			);
		}
		break;
	case "validforestloc":
	case "validlocation":
		if (is_module_active("cities"))
			$args[$city]="village-$race";
		break;
	case "moderate":
		if (is_module_active("cities")) {
			tlschema("commentary");
			$args["village-$race"]=sprintf_translate("%s, Jahkt der Lilty", $city);
			tlschema();
		}
		break;
	case "travel":
		$capital = getsetting("villagename", LOCATION_FIELDS);
		$hotkey = substr($city, 0, 1);
		tlschema("module-cities");
		if ($session['user']['location']==$capital){
			addnav("Safer Travel");
			addnav(array("%s?Go to %s", $hotkey, $city),"runmodule.php?module=cities&op=travel&city=$city");
		}elseif ($session['user']['location']!=$city){
			addnav("More Dangerous Travel");
			addnav(array("%s?Go to %s", $hotkey, $city),"runmodule.php?module=cities&op=travel&city=$city&d=1");
		}
		if ($session['user']['superuser'] & SU_EDIT_USERS){
			addnav("Superuser");
			addnav(array("%s?Go to %s", $hotkey, $city),"runmodule.php?module=cities&op=travel&city=$city&su=1");
		}
		tlschema();
		break;	
	case "villagetext":
		racelilty_checkcity();
		if ($session['user']['location'] == $city){
			$args['text']=array("`&`c`b%s, die Hauptstadt der Lilty`b`c`n`7Hier l�uft viel, gesch�ftige Liltys wandern durch die Strassen, die k�nigliche Garde steht vor dem Palalst, andere laufen durch die Strassen und sorgen f�r Ordnung. Hier ist viel los.`n", $city, $city);
			$args['schemas']['text'] = "module-racelilty";
			$args['clock']="`n`7An der grossen Uhr am Palast wird die aktuelle Zeit angezeigt: `&%s`7 Uhr.`n";
			$args['schemas']['clock'] = "module-racelilty";
			if (is_module_active("calendar")) {
				$args['calendar'] = "`n`7Heute ist der `&%s`7, `&%s %s %s`7.`n";
				$args['schemas']['calendar'] = "module-racelilty";
			}
			$args['title']=array("%s, die Hauptstadt der Lilty", $city);
			$args['schemas']['title'] = "module-racelilty";
			$args['sayline']="spricht";
			$args['schemas']['sayline'] = "module-racelilty";
			$args['talk']="`n`&In der N�he sprechen einige Dorfbewohner:`n";
			$args['schemas']['talk'] = "module-racelilty";
			$new = get_module_setting("newest-$city", "cities");
			if ($new != 0) {
				$sql =  "SELECT name FROM " . db_prefix("accounts") .
					" WHERE acctid='$new'";
				$result = db_query_cached($sql, "newest-$city");
				$row = db_fetch_assoc($result);
				$args['newestplayer'] = $row['name'];
				$args['newestid']=$new;
			} else {
				$args['newestplayer'] = $new;
				$args['newestid']="";
			}
			if ($new == $session['user']['acctid']) {
				$args['newest']="`n`7Als Neuling in diesem dorf wanderst du ziellos umher.";
			} else {
				$args['newest']="`n`7`&%s`7 wandert ziellos durch die grosse Stadt.";
			}
			$args['schemas']['newest'] = "module-racelilty";
			$args['section']="village-$race";
			$args['gatenav']="Village Gates";
			$args['schemas']['gatenav'] = "module-racelilty";
			unblocknav("stables.php");
		}
		break;
	}
	return $args;
}

function racelilty_checkcity(){
	global $session;
	$race="Lilty";
	$city=get_module_setting("villagename");
	
	if ($session['user']['race']==$race && is_module_active("cities")){
		if (get_module_pref("homecity","cities")!=$city){ //home city is wrong
			set_module_pref("homecity",$city,"cities");
		}
	}	
	return true;
}

function racelilty_run(){

}

?>