<?php

function avatar_getmoduleinfo(){
	$info = array(
		"name"=>"Avatars",
		"author"=>"Chris Vorndran",
		"version"=>"1.1",
		"category"=>"General",
		"download"=>"http://dragonprime.net/index.php?module=Downloads;sa=dlview;id=69",
		"vertxtloc"=>"http://dragonprime.net/users/Sichae/",
		"description"=>"This module will display a User Chosen avatar in the user's bio, or in their Vital Info bar. The selection of avatars is regulated by the user with FTP access, giving much more control over what can be used.",
		"settings"=>array(
			"Avatar Settings - Types,title",
			"types"=>"Types of Avatars that are available,text|png,gif",
			"Please enter in the file formats seperated by commas. Make sure to clean up any stray commas. Thank you.,note",
			"codeword"=>"Secret codeword,text|sichae",
			"Basically this will allow you to make private images. Such as if you have an image named `^sichae.01.gif`0 that image will not show up for others to select from.,note",
			"Avatar Settings - Directory,title",
			"avdir"=>"Directory of Avatars,text|./modules/images/avatars/",
			"pp"=>"Display how many avatars per page?,int|10",
			"The default of `^./modules/images/avatars/`0 will be looking in the module's image's avatar directory.,note",
			"Please make sure to have the trailing/ending slash. Thank you.,note",
		),
		"prefs"=>array(
			"Avatar Prefs,title",
			"user_siv"=>"Show your Avatar in your Vital Info?,bool|0",
			"user_note"=>"If your image is large your Vital Info bar shall be stretched out. This may or may not occur due to the image size.,note",
			"user_sav"=>"Would you like to see other's avatars in their bios?,bool|1",
			"avatar"=>"User's Avatar,text|default.gif",
		),
	);
	return $info;
}
function avatar_install(){
	module_addhook("footer-prefs");
	module_addhook("biotop");
	module_addhook("charstats");
	return true;
}
function avatar_uninstall(){
	return true;
}
function avatar_dohook($hookname,$args){
	global $session;
	$dir = get_module_setting("avdir");
	$avatar = get_module_pref("avatar");
	switch ($hookname){
		case "footer-prefs":
			addnav("Change Avatar","runmodule.php?module=avatar&op=enter");
			break;
		case "biotop":
			$a = get_module_pref("avatar","avatar",$args['acctid']);
			$image = "<center><img src='$dir$a'></center>";
			if (get_module_pref("user_sav")){
				addnavheader("Avatar");
				addnav("$image","!!!addraw!!!",true);
			}
			break;
		case "charstats":
			if (get_module_pref("user_siv")){
				$title = translate_inline("Avatar");
				$area = translate_inline("Current Avatar");
				$image = "<center><img src='$dir$avatar'></center>";
				setcharstat($title,$area,$image);
			}
			break;
		}
	return $args;
}
function avatar_run(){
	global $session;
	$op = httpget('op');
	$page = httpget('page');
	$avatar = httppost('avatar');
	$type = httpget('typ');
	$dir = get_module_setting("avdir");
	$avy = get_module_pref("avatar");
	$cw = get_module_setting("codeword");
	
	page_header("Change Avatars");
	switch ($op){
		case "enter":
			$a = get_module_setting("types");
			$types = explode(",",$a);
			addnav("Avatar File Formats");
			for ($i = 0; $i < count($types); $i++){
				$ctype = $types[$i];
				addnav(array("%ss",strtoupper($ctype)),"runmodule.php?module=avatar&op=list&typ=".$ctype."&page=1");
			}
			output("`^Currently, this server supports `\$%s `^different file types.",count($types));
			output("Those being:`n`n");
			for ($i = 0; $i < count($types); $i++){
				$ctype = $types[$i];
				output("`c`b`#%s`b`c",$ctype);
			}			
			output("`n`^If you would like a new one added, and can suggest some images to be placed in, please write to your local admin.");
			output("`n`nThank you, The Management.");
			// This is to block any navs that would appear, due to an extra comma
			blocknav("runmodule.php?module=avatar&op=list&typ=");
			break;
		case "list":
			$pp = get_module_setting("pp");
			$pageoffset = (int)$page;
			if ($pageoffset > 0) $pageoffset--;
			$pageoffset *= $pp;
			$from = $pageoffset;
			$a = getlist(get_module_setting("avdir"));
			$images = array();
			for ($i = 0; $i < count($a); $i++){
				$ex = explode(".",$a[$i]);
				$f = $a[$i];
				if ($ex[1] == $type && $ex[0] != $cw) array_push($images,$f);
			}
			$count = count($images);
			$total = count($images);
			if ($from + $pp < $total){
				$cond = $pageoffset + $pp;
			}else{
				$cond = $total;
			}
			$num = translate_inline("Number");
			$image = translate_inline("Image");
			$op = translate_inline("Ops");
			if ($count > 0){
				rawoutput("<big>");
				output("`c`b`^Currently on Page `\$%s`b`c`0",$page);
				rawoutput("</big>");
				output_notl("`n`n");
				rawoutput("<table border='0' cellpadding='2' cellspacing='1' align='center' bgcolor='#999999'>");
				rawoutput("<tr class='trhead'><td>$num</td><td>$image</td><td>$op</td></tr>");
				for($i = $pageoffset; $i < $cond && $count; $i++) {
					$img = $images[$i];
					if ($img == get_module_pref("avatar")){
						rawoutput("<tr class='trhilight'><td>");
					} else {
						rawoutput("<tr class='".($i%2?"trdark":"trlight")."'><td>");
					}
					$j=$i+1;
					output_notl("$j.");
					rawoutput("</td><td>");
					rawoutput("<center><img src='$dir$img'></center>");
					rawoutput("</td><td>");
					rawoutput("<form action='runmodule.php?module=avatar&op=alter' method='POST'>");
					output_notl("`^");
					rawoutput("Select<input type='radio' name='avatar' value='$img'>");
					output_notl("`n");
					rawoutput("<input type='submit' class='button' value='".translate_inline("Change")."'>");
					rawoutput("</form>");
					rawoutput("</td></tr>");
				}
				rawoutput("</table>");
			}else{
				rawoutput("<big>");
				output("`c`b`#I am sorry, but there are no images of this format.");
				output("Please choose another.");
				output("If you wish, you may speak to your local admin about aquiring some of this format.");
				output("Or, if they are unable to find any, ask them to remove this format from their listing.`c`b");
				rawoutput("</big>");
			}
		if ($total>$pp){
			addnav("Pages");
			for ($p=0;$p<$total;$p+=$pp){
				addnav(array("Page %s (%s-%s)", ($p/$pp+1), ($p+1), min($p+$pp,$total)), "runmodule.php?module=avatar&op=list&typ=$type&page=".($p/$pp+1));
		}
		}
		addnav("","runmodule.php?module=avatar&op=alter");
		break;
	case "alter":
		set_module_pref("avatar",$avatar);
		rawoutput("<img src='$dir$avatar'>");
		rawoutput("<big>");
		output("`n`^`bYou have chosen this as your avatar.`b");
		// Since the nav can't update along with the setting of the pref, let's block it.
		blocknav("!!!addraw!!!");
		break;
	}
addnav("Other");
if ($op != "enter") addnav("Select File Format","runmodule.php?module=avatar&op=enter");
addnav("Return to your Preferences","prefs.php");
addnavheader("Current Avatar");
$curavy = "<center><img src='$dir$avy'></center>";
addnav("$curavy","!!!addraw!!!",true);
page_footer();
}
function getlist($dir, $ignore = true){
   $findir  =   array();
   if ($handle = opendir($dir)){
       while (false !== ($file = readdir($handle))){
           if ($ignore){
               if ($file != "." && $file != ".." && $file !="CVS"){
                   array_push($findir, $file);
               }
           }else{
               array_push($findir, $file);
           }
       }
       closedir($handle);
   }else{
       output("Unable to open directory: %s",$dir);
	   output("Please contact your local admin about this.");
   }
   return $findir;
}
?>	