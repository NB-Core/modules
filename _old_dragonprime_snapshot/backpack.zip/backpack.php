<?php

/***************************************************************************/
/* Name: Backpack                                                          */
/* ver 1.0                                                                 */
/* Billie Kennedy => dannic06@gmail.com                                    */
/*                                                                         */
/***************************************************************************/

require_once("lib/villagenav.php");
require_once("lib/http.php");

function backpack_getmoduleinfo(){
    $info = array(
        "name"=>"Backpack",
        "version"=>"0.5",
        "author"=>"Billie Kennedy",
        "category"=>"Bkobjects",
        "download"=>"http://orpgs.com/modules.php?name=Downloads&d_op=viewdownload&cid=3",
        "vertxtloc"=>"http://www.orpgs.com/downloads/version.txt",
        "requires"=>array(
			"generalstore" => "1.0|Billie Kennedy, http://orpgs.com/modules.php?name=Downloads&d_op=viewdownload&cid=3",
		),
        "prefs"=>array(
			"hasbackpack"=>"Does the user have a Backpack,bool|0",
			"numitems"=>"How many can this users Backpack hold,int|5",
			"inventorynum"=>"How many items are currently in the backpack?,int|0",
			"showinbio"=>"Do you want this to show contents in the bio?,bool|0",
		),
    );
    return $info;
}

function backpack_install(){
	module_addhook("village");
	module_addhook("generalstore");
    return true;
}

function backpack_uninstall(){
    return true;
}

function backpack_dohook($hookname,$args){
    global $session;
    switch($hookname){
		case "village":
			if (get_module_pref('hasbackpack')){
				global $texts;
				addnav("Inventory");
				addnav("Backpack", "runmodule.php?module=backpack");
			}
		break;   
		case "generalstore":
			$gold = 1000;
			$gems = 10;
			if (!get_module_pref('hasbackpack')){
				addnav("Buy Items");
				addnav("Backpack","runmodule.php?module=backpack&op=buyitem");
				output_notl("`@Buy a backpack to hold your items.  The backpacks cost %s gold and %s gems`n",$gold,$gems);	
			}
			if (get_module_pref('hasbackpack')){
				addnav("Sell Items");
				addnav("Backpack","runmodule.php?module=backpack&op=sellitem");
			}
	}
    return $args;
}

function backpack_run(){

	global $session;
	$texts = array();
	$op = httpget('op');
	$op2 = httpget('op2');
	$op3 = httpget('op3');
	$gold = 1000;
	$gems = 10;
	
	page_header("Backpack Contents");
	
	switch ($op){
		
		case "buyitem":
			addnav("Return to the Store","runmodule.php?module=generalstore");
			if (get_module_pref('hasbackpack')){
				output_notl("You already have a backpack.`n");
			}elseif (1000 > $session['user']['gold']){
				output_notl("You do not have enough gold to purchase a backpack.`n");
			}elseif (10 > $session['user']['gems']){
				output_notl("You do not have enough gems to purchase a backpack.`n");
			}else{
				output_notl("You have just purchased a fine used backpack.  Seems kinda expensive for something used.`n");
				$session['user']['gold'] -= $gold;
				$session['user']['gems'] -= $gems;
				set_module_pref('hasbackpack',1);
			}
		break;
		case "sellitem":
			addnav("Return to the Store","runmodule.php?module=generalstore");
			if (!get_module_pref('hasbackpack')){
				output ("You don't have a backpack to sell.`n");
				break;
			}
			if (get_module_pref('inventorynum')){
				output ("Your backpack has stuff in it still.  You need to empty it first.");
				break;
			}
			$sellprice = 400;
			$sellgems = 3;
			set_module_pref('hasbackpack',0);
			
			break;

		default:
			addnav("Return to Village","village.php");
			addnav("Use Items");
			output_notl("This is a great invention.  It can hold all kinds of stuff.  There are even straps so you can throw it over your shoulders.");
			output_notl("The burlap is a bit frayed on the edges.  Perhaps you shouldn't have purchased this at a discount.`n`n");
			output_notl("`#Inventory`n`^");
			modulehook("backpack",$texts);
		break;
	}
	
		
	page_footer();
}
?>