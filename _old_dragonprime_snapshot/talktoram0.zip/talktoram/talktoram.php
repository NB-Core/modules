<?php

function talktoram_getmoduleinfo(){
	$info = array(
	"name"=>"Talk Ramius",
	"version"=>"1.0",
	"author"=>"`^Harry Balzitch",
	"category"=>"Graveyard Specials",
	"download"=>"http://dragonprime.net/index.php?module=Downloads;sa=dlview;id=599",
	);
	return $info;
}

function talktoram_install(){
	module_addeventhook("graveyard", "return 100;");
	return true;
}

function talktoram_uninstall(){
	return true;
}

function talktoram_dohook($hookname,$args){
	return $args;
}

function talktoram_runevent($type)
{
	global $session;
	output("`n`n `7While wandering around the graveyard, you see Ramius sitting on a bench.`n");
	output("You walk over and sit down next to him, discussing politics, sports and religion.`n");
	output("After awhile you realize that Ramius is a really cool guy!`n");
	output("`&And you feel that Ramius is very pleased with you too!`0");
	$session['user']['gravefights']+=5;
	$session['user']['deathpower']+=e_rand(20,75);
}

function talktoram_run(){
}
?>