/****************************************************
	Game: 		LotGD
	Version:	0.9.7/0.9.7+jt
	Patch: 		Game settings for patches
	Author: 	Borge Alvestad aka BraveBrain
	Date: 		February 20th 2004

	Upload this file as:
				/patchsettings.php
	Affected files:
				/configuration.php
	Required files:
				NONE
				(/special/holes.php for example included in patchsettings.php)

	Description:
	This patch makes it easier to use the game's
	settings in future patches, 
	and to add your own	settings.
	Any future settings can be added by putting it
	in here instead of in configuration.php
	Syntax:
	$setup["settingname"] = "settingdescription, settingtype";

*//****************************************************/

Changes syntax:

[IN FILE] => The file to modify.
[FIND (#)] => The code to look for (any number represents the line number in an original file with no other changes than previous changes for the current patch). Closed with [/FIND].
[ADD AFTER] => The code to insert AFTER the found code. Closed with [/ADD AFTER]
[ADD BEFORE] => The code to insert BEFORE the found code. Closed with [/ADD BEFORE]

CHANGES:

[IN FILE]
configuration.php
[FIND (15)]
page_header("Game Settings");
[/FIND]
[ADD AFTER]
//BEGIN Patch-Settings patch by BraveBrain 
#1 of 3 // Add a new nav-item to ease navigation after updating dynamic settings
addnav("R?Reload Game Settings","configuration.php");
//END Patch-Settings patch by BraveBrain #1
[/ADD AFTER]
[FIND (54)]
	"Account Creation,title",
[/FIND]
[ADD BEFORE]
// BEGIN Patch-Settings patch by BraveBrain 
#2 of 3 // Split the setup-array to include the Patches section
	);
require_once("patchsettings.php");
$setup2 = array(
// END Patch-Settings patch by BraveBrain #2
[/ADD BEFORE]
[FIND (135)]
if ($_GET[op]==""){
[/FIND]
[ADD AFTER]
// BEGIN Patch-Settings patch by BraveBrain 
#3 of 3 // Merge the setup arrays
$setup = array_merge_recursive($setup,$setup2);	
// END Patch-Settings patch by BraveBrain 
[/ADD AFTER]

/*
I recommend keeping the comments for each change to make it easier to remember/undo the changes.
Hope you'll find this useful ;)
-BraveBrain
*/