<?php
/****************************************************
	Game: 		LotGD
	Version:	0.9.7/0.9.7+jt
	Patch: 		Game settings for patches
	Author: 	Borge Alvestad aka BraveBrain
	Date: 		February 20th 2004

	Upload this file as:
				/patchsettings.php
	Affected files:
				/configuration.php
	Required files:
				NONE
				(/special/holes.php for below example)

	Description:
	This patch makes it easier to use the game's
	settings in future patches, 
	and to add your own	settings.
	Any future settings can be added by putting it
	in here instead of in configuration.php

	USAGE:
	For each additional setting you want in your game,
	add a line like this:
	$setup["NAME"] = "TEXT, TYPE";
	where NAME is the setting's name, 
	TEXT is the description shown in the Game Settings in the Superuser Grotto,
	and TYPE is the the setting's data type (I.e. int, bool, enum etc...)

*//****************************************************/

array_push($setup, "Patches,title"); //Create a section for Patches' settings. DO NOT REMOVE!

// EXAMPLE PATCH (Requires /special/holes.php to work. Does not affect the game if left without the patch file)
/* BEGIN Holes patch settings
	(by BraveBrain. Made as an example of usage for this patch) */
// To make this work you will also need the Holes patch (holes.php) uploaded to your 'special' directory
// <--- Change this '//' to '/*' and remove the rest of the line to comment out this patch 
$setup["BB_holes"] = "Number of holes in game,int"; // Save settings after increasing this to be able to edit settings for new holes
$setup["BB_holesGold"] = "Maximum gold to find (Multiplied with player's level (0=unlimited)),int"; // If this is set one player can't find more than this amount
$holes = getsetting("BB_holes",5); // Get the amount of holes if set. If not set it defaults to 5
for ($i=0;$i<$holes;$i++) {  // Adds three game settings per hole (BB_holes)
	$tmp = $i+1;
	$setup["BB_holeGold".$tmp] = "Money currently in hole # $tmp,int"; // If a player dies money will go here for the specific hole
	$setup["BB_holeMax".$tmp] = "Max HP lost from hole # $tmp (%),int"; // The Max % of damage this hole can do (% of users max hp)
	$setup["BB_holeMin".$tmp] = "Min HP lost from hole # $tmp (%),int"; // The Min % of damage this hole can do (% of users max hp)
}
// END Holes patch settings */

?>