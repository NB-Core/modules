<?php
/* 
* Name:    Old Bridge  18April2005
* Author:  Robert of Maddrio dot com
* Note:    Converted from a 097 forest event
* v 1.1    optimized code July2005
*/

function oldbridge_getmoduleinfo(){
	$info = array(
	"name"=>"Old Bridge",
	"version"=>"1.1",
	"author"=>"`2Robert",
	"category"=>"Forest Specials",
	"download"=>"http://dragonprime.net/users/robert/oldbridge_098.zip",
	);
	return $info;
}

function oldbridge_install(){
	module_addeventhook("forest","return 100;");
	return true;
}

function oldbridge_uninstall(){
	return true;
}

function oldbridge_dohook($hookname,$args){
	return $args;
}

function oldbridge_runevent($type){
	global $session;
	$from = "forest.php?";
	$session['user']['specialinc'] = "module:oldbridge";
	$op = httpget('op');

	if ($op=="" || $op=="search"){
	output("`n`n`2 You come to a large ravine, before you is a rickety old bridge.`n");
	output(" You think about taking your chances to get to the other side. `n`n");
	output("`& What will you do?");
	addnav("old bridge");
	addnav("(C) Cross the bridge", $from."op=cross");
	addnav("(G) Go another way", $from."op=dont");
	}elseif ($op=="cross"){
		$session['user']['specialinc'] = "";
		if ($session['user']['level']>=6){
		output("`n`n`2 You try not to tremble as you attempt to cross the old bridge . .`n");
		switch(e_rand(1,6)){
		case 1:
		output("`2 the old bridge gives way - you plummet to your death! `n`n");
		output("`7 You lose 5% of your experience.`n"); 
		$session['user']['alive']=false; 
		$session['user']['hitpoints']=0; 
		$session['user']['experience']=round($session['user']['experience']*0.95);  
		addnews(" %s `2 has died while crossing on old bridge.",$session['user']['name']);
		debuglog ("died while crossing the old bridge`0");
		addnav("bad news"); 
		addnav("(D) Daily News","news.php"); 
		break;
		case 2:
		output("`2 you are quick to grab onto a nearby shrubbery as the bridge gives way! `n");
		output("`6 You saved your own life but are `iseverely injured`i in the process. `n`n");
		output("`5 You lose 3% of experience! `n");
			if ($session['user']['attack']>=32){
			output("`7 You lose 1 attack point! ");
			$session['user']['attack']--;
			debuglog(" lost 1 attack point crossing the old bridge");
			}
			$session['user']['alive']=true;
			$session['user']['hitpoints']=1;
			$session['user']['experience']=round($session['user']['experience']*0.97); 
		break;
		case 3: case 4: case 5: case 6:
		output("`2 you are quick to grab onto a nearby shrubbery as the bridge gives way!`n");
		output("`6 You saved your own life. `n`n");
		output("`7 You gain some experience! ");
		addnews("%s `2 nearly died crossing on old bridge.",$session['user']['name']);
		$session['user']['experience']=round($session['user']['experience']*1.05);
		break;
		}
	}else{
		output("`2 you are quick to grab onto a nearby shrubbery as the bridge gives way! `n");
		output(" You saved your own life but are shaken up quite a bit. `n`n");
		output("`7 You lose time for 2 Forest fights as you recover. ");
		$session['user']['turns']-=2;
		if ($session['user']['turns']< 0) $session['user']['turns'] = 0;
	}
}else{
output("`n`n`2 Not wanting to take chances with the old bridge, you search for another path. "); 
output("`n`n The time it takes you costs you 1 Forest fight. "); 
$session['user']['turns']--;
$session['user']['specialinc'] = "";
}
}

function oldbridge_run(){
}
?>