<?php

function pref_remove_getmoduleinfo(){
	$info = array(
		"name"=>"Useless Pref Removal",
		"author"=>"Chris Vorndran",
		"category"=>"Administrative",
		"version"=>"1.0",
	);
	return $info;
}

function pref_remove_install(){
	module_addhook("superuser");
	return true;
}
function pref_remove_uninstall(){
	return true;
}
function pref_remove_dohook($hookname,$args){
	global $session;
	switch ($hookname){
		case "superuser":
			if ($session['user']['superuser'] & SU_MEGAUSER){
				addnav("Actions");
				addnav("Useless Pref Removal","runmodule.php?module=pref_remove");
			}
			break;
	}
	return $args;
}
function pref_remove_run(){
	global $session;
	$op = httpget('op');
	page_header("Useless Pref Removal");
	switch ($op){
		case "":
			output("`#This tool removes pages upon pages of prefs that can't be used due to module error.");
			output("Sometimes a module will be created in such a way that it will fill an already overflowing table with more fodder.");
			$sql = "SELECT modulename FROM ".db_prefix("module_userprefs");
			$res = db_query($sql);
			$i = 0;
			while($row = db_fetch_assoc($res)){
				if (is_numeric($row['modulename'])) $i++;
			}
			output("`n`nCurrently, there are `^%s `#prefs that should be removed.",number_format($i));
			addnav("Remove Prefs","runmodule.php?module=pref_remove&op=remove");
			break;
		case "remove":
			$sql = "SELECT modulename FROM ".db_prefix("module_userprefs");
			$res = db_query($sql);
			$i = 0;
			while($row = db_fetch_assoc($res)){
				if (is_numeric($row['modulename'])){
					$i++;
					db_query("DELETE FROM ".db_prefix("module_userprefs")." 
								WHERE modulename='{$row['modulename']}'");
				}
			}
			output("`^%s `#rows deleted.",number_format($i));
			break;
		}
	require_once("lib/superusernav.php");
	superusernav();
	page_footer();
}
?>