<?
require_once "common.php";
checkday();

/*
Garrison's Training Center
Version 1.0 (08/05/04)
by Gary M. Hartzell
*/

page_header("Garrison's Training Center");
if ($HTTP_GET_VARS[op]=="")
{
//Main menu
output("`^You enter The Training Center filled with anticipation and a little fear.  Cries of both triumph and pain echo out of the various rooms.  You take a deep breath, and prepare yourself for one hell of a workout.`n`n");
addnav("C?Train with Court","garrisons.php?op=court");
if ($session[user][level] > 9)
{
addnav("G?Train with Garrison","garrisons.php?op=garrison");
}
addnav("M?Get a Massage","garrisons.php?op=massage");
addnav("R?Return to Town","village.php");
}
else if ($HTTP_GET_VARS[op]=="court")
{
//Court
if ($session[user][gtc_seenc] != 0)
{
output("Court doesn't have any more time for you today.  Try back tomorrow.");
addnav("R?Return to the Lobby","garrisons.php");
}
else
{
$session[user][gtc_seenc] = 1;
output("Court looks annoyed as you enter his gym.`n`n");
output("\"What do you want, maggot?  I'm a busy guy and I only have time to give you one lesson, so you better think fast.\"");
addnav("S?Strength","garrisons.php?op=courts");
addnav("D?Defense","garrisons.php?op=courtd");
addnav("E?Endurance","garrisons.php?op=courth");
addnav("R?Return to the Lobby","garrisons.php");
}
}
else if ($HTTP_GET_VARS[op]=="courts")
{
output("After a grueling workout with Court, you actually feel stronger.`n`n");
output("YOU GAIN 1 STRENGTH!");
$session[user][attack]+=1;
addnav("R?Return to the Lobby","garrisons.php");
}
else if ($HTTP_GET_VARS[op]=="courtd")
{
output("After a challenging session with Court, you feel better equipped to defend yourself.`n`n");
output("YOU GAIN 1 DEFENSE!");
$session[user][defence]+=1;
addnav("R?Return to the Lobby","garrisons.php");
}
else if ($HTTP_GET_VARS[op]=="courth")
{
output("After an intense hour, you feel tougher.`n`n");
output("YOU GAIN 1 HIT POINT!");
$session[user][maxhitpoints]+=1;
addnav("R?Return to the Lobby","garrisons.php");
}
else if ($HTTP_GET_VARS[op]=="garrison")
{
//Garrison
if ($session[user][gtc_seeng] != 0)
{
output("Garrison has many other warriors to train yet today.  Try back tomorrow.");
addnav("R?Return to the Lobby","garrisons.php");
}
else
{
$session[user][gtc_seeng] = 1;
output("You enter Garrison's gym and wait while the great man spars with another muscular warrior.  It turns out, you don't have to wait very long.  Garrison approaches you.  He looks like a statue up close, and you notice he hasn't even broken a sweat from all his training and sparring sessions of the day.`n`n");
output("\"So, you need a lesson,\" he says to you.  \"You are, indeed, an advanced warrior, but we all can use some help from time to time.  So, what do you feel you need the most help with?\"");
addnav("S?Strength","garrisons.php?op=garrisons");
addnav("D?Defense","garrisons.php?op=garrisond");
addnav("E?Endurance","garrisons.php?op=garrisonh");
addnav("R?Return to the Lobby","garrisons.php");
}
}
else if ($HTTP_GET_VARS[op]=="garrisons")
{
output("You train hard with The Great Garrison for a half-hour.`n`n");
switch(e_rand(1,4))
{
case 1:
output("\"You surely need more training,\" Garrison comments as you lay panting on the mats.`n`n");
output("YOU GAIN 2 STRENGTH.");
$session[user][attack]+=2;
break;
case 2:
output("\"Excellent,\" Garrison remarks, extending a hand to help you off the mats.`n`n");
output("YOU GAIN 10 STRENGTH!");
$session[user][attack]+=10;
break;
case 3:
output("\"Not bad,\" Garrison says, leaving you in a puddle of your own sweat on the mats.`n`n");
output("YOU GAIN 5 STRENGTH.");
$session[user][attack]+=5;
break;
case 4:
output("\"Good show,\" Garrison says afterwards.  You can't help but to smile at the compliment.`n`n");
output("YOU GAIN 7 STRENGTH.");
$session[user][attack]+=7;
break;
}
addnav("R?Return to the Lobby","garrisons.php");
}
else if ($HTTP_GET_VARS[op]=="garrisond")
{
output("You train hard with The Great Garrison for a half-hour.`n`n");
switch(e_rand(1,4))
{
case 1:
output("\"You surely need more training,\" Garrison comments as you lay panting on the mats.`n`n");
output("YOU GAIN 2 DEFENSE.");
$session[user][defence]+=2;
break;
case 2:
output("\"Excellent,\" Garrison remarks, extending a hand to help you off the mats.`n`n");
output("YOU GAIN 10 DEFENSE!");
$session[user][defence]+=10;
break;
case 3:
output("\"Not bad,\" Garrison says, leaving you in a puddle of your own sweat on the mats.`n`n");
output("YOU GAIN 5 DEFENSE.");
$session[user][defence]+=5;
break;
case 4:
output("\"Good show,\" Garrison says afterwards.  You can't help but to smile at the compliment.`n`n");
output("YOU GAIN 7 DEFENSE.");
$session[user][defence]+=7;
break;
}
addnav("R?Return to the Lobby","garrisons.php");
}
else if ($HTTP_GET_VARS[op]=="garrisonh")
{
output("You train hard with The Great Garrison for a half-hour.`n`n");
switch(e_rand(1,4))
{
case 1:
output("\"You surely need more training,\" Garrison comments as you lay panting on the mats.`n`n");
output("YOU GAIN 2 HIT POINTS.");
$session[user][maxhitpoints]+=2;
break;
case 2:
output("\"Excellent,\" Garrison remarks, extending a hand to help you off the mats.`n`n");
output("YOU GAIN 10 HIT POINTS!");
$session[user][maxhitpoints]+=10;
break;
case 3:
output("\"Not bad,\" Garrison says, leaving you in a puddle of your own sweat on the mats.`n`n");
output("YOU GAIN 5 HIT POINTS.");
$session[user][maxhitpoints]+=5;
break;
case 4:
output("\"Good show,\" Garrison says afterwards.  You can't help but to smile at the compliment.`n`n");
output("YOU GAIN 7 HIT POINTS.");
$session[user][maxhitpoints]+=7;
break;
}
addnav("R?Return to the Lobby","garrisons.php");
}
else if ($HTTP_GET_VARS[op]=="massage")
{
//Massage
if ($session[user][gtc_massage] !=0)
{
output("The earliest Bruno can fit you in for a massage is tomorrow.");
addnav("R?Return to the Lobby","garrisons.php");
}
else
{
$session[user][gtc_massage] = 1;
output("A very tall and muscular bald man grasps your hand and introduces himself as Bruno.  \"So, are you ready for a massage?\" he asks.  \"It will only cost you two gems.\"");
addnav("Y?Yes, pay him two gems","garrisons.php?op=massage2");
addnav("N?No thanks","garrisons.php");
}
}
else if ($HTTP_GET_VARS[op]=="massage2")
{
if ($session[user][gems] < 2)
{
output("You rummage through your possessions but can't seem to find two gems.  Maybe another time.");
addnav("R?Return to the Lobby","garrisons.php");
}
else
{
output("Bruno has an amazingly gentle touch for such a large man.  After only 20 minutes, you feel great.`n`n");
$session[user][gems]-=2;
switch(e_rand(1,6))
{
case 1:
case 5:
output("You feel so much better!  (You are completely healed.)");
$session[user][hitpoints] = $session[user][maxhitpoints];
break;
case 2:
output("You feel better about yourself!  (You gain 1 charm.)");
$session[user][charm] += 1;
break;
case 3:
case 6:
output("You feel ready to take on the world!  (You gain 2 turns.)");
$session[user][turns] += 2;
break;
case 4:
output("You feel ready to take on the world!  (You gain 1 player fight.)");
$session[user][playerfights]++;
break;
}
addnav("R?Return to the Lobby","garrisons.php");
}
}
else
{
addnav("R?Return to Town","village.php");
}

page_footer();

?>
