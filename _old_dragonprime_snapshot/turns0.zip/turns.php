<?php
function turns_getmoduleinfo(){
	$info = array(
		"name"=>"Carry over turns",
		"author"=>"`%kickme`0",
		"download"=>"http://dragonprime.net/users/kickme/turns.zip",
		"vertxtloc"=>"http://dragonprime.net/users/kickme/",
		"settings"=>array(
			"Carry over turns - settings,title",
			"amount"=>"Max amount of turns allowed?,int|200"
			),
		"prefs"=>array(
			"turns"=>"Should be zero,int|0"
			),
		"category"=>"General",
		"version"=>"1.1.0"
		);
	return $info;
}
function turns_install(){
	module_addhook("header-newday");
	module_addhook("footer-newday");
	return true;
}
function turns_uninstall(){
	return true;
}
function turns_dohook($where,$args){
	global $session;
	if(!(get_module_setting("amount") > getsetting("turns",10))) return $args;
	switch($where){
		case "header-newday":
			set_module_pref("turns",$session['user']['turns']);
			break;
		case "footer-newday":
			$turns = $session['user']['turns'] + get_module_pref("turns");
			if($turns > get_module_setting("amount")){
				$turns2 = get_module_setting("amount") - $session['user']['turns'];
				set_module_pref("turns",$turns2);
			}
			$session['user']['turns'] += get_module_pref("turns");
			if($session['user']['turns'] >= get_module_setting("amount")) output("`@You would gain more forest fights but you all ready have to much!`0");
			elseif(get_module_pref("turns") == 0);
			else output("`@You gain `^%s`@ forest fights due to not using them yesterday!`0",get_module_pref("turns"));
			set_module_pref("turns",0);
			break;
	}
	return $args;
}
function turns_run(){}
?>