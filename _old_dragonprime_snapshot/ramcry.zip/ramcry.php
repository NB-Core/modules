<?php

function ramcry_getmoduleinfo(){
	$info = array(
		"name"=>"Ramius' Crystals",
		"author"=>"Chris Vorndran",
		"version"=>"1.01",
		"category"=>"Graveyard",
		"download"=>"http://dragonprime.net/index.php?module=Downloads;sa=dlview;id=95",
		"vertxtloc"=>"http://dragonprime.net/users/Sichae/",
		"description"=>"Gem Dump. Gem is traded for favor.",
		"settings"=>array(
			"Ramius' Crystals - General Settings,title",
				"take"=>"Take Torments/Turns in exchange for favor?,bool|0",
				"amnt"=>"How many torments/turns?<br> `iif above statement is true`i,int|1",
				"max"=>"How many gems can be given daily?,int|3",
				"range"=>"Which two numbers will the favor be chosen out of?,int|5-20",
				"Make sure that the above values is set up in a `^`ix-x`i`0 formula.,note",
			"Ramius' Crystals - Living Settings,title",
				"living"=>"Does this shop exist in the living realm?,bool|0",
				"where"=>"If yes, then where does it exist?,location|".getsetting("villagename",LOCATION_FIELDS),
			),
		"prefs"=>array(
			"Ramius' Crystals Prefs,title",
				"times"=>"How many times has this been used?,int|0",
			),
		);
	return $info;
}
function ramcry_install(){
	module_addhook("ramiusfavors");
	module_addhook("newday");
	module_addhook("village");
	module_addhook("changesetting");
	return true;
}
function ramcry_uninstall(){
	return true;
}
function ramcry_dohook($hookname,$args){
	global $session;
	switch($hookname){
		case "village":
			if (get_module_setting("living")){
				if ($session['user']['location'] == get_module_setting("where")){
					tlschema($args['schemas']['marketnav']);
					addnav($args['marketnav']);
					tlschema();
					addnav("Ramius' Crystals","runmodule.php?module=ramcry&op=enter");
				}
			}
			break;
		case "changesetting":
			if ($args['setting'] == "villagename"){
				if ($args['old'] == get_module_setting("where")){
					set_module_setting("where",$args['new']);
				}
			}
			break;
		case "ramiusfavors":
			addnav("Ramius Favors");
			addnav("a?Ramius' Crystals","runmodule.php?module=ramcry&op=enter");
			break;
		case "newday":
			set_module_pref("times",0);
			break;
		}
	return $args;
}
function ramcry_run(){
	global $session;
	$op = httpget('op');
	$max = get_module_setting("max");
	$times = get_module_pref("times");
	page_header("Ramius' Crystals");
	addnav("Options");	
	switch($op){
		case "enter":
			if ($session['user']['gems'] >= 1){
				output("`)You enter a dark celler, beneath the Mausoleum.");
				output("Seeing that there is no light around, you begin to concentrate.");
				output("A small flame emits light from your hand, and you walk deeper in.");
				output("`\$Ramius `)sneaks up behind you, noticing a jingling in your gem pouch.`n`n");
				if ($times < $max){
					output("He strides a bit closers...");
					output("\"`\$Might I be able to nick a gem or more?`)\"");
					addnav("Hear More","runmodule.php?module=ramcry&op=exchange");
				}else{
					output("But, he merely slinks by you, proceeding onto a more wanton fervor.");
					output("You shake your fist at him, and frown.");
				}
			}else{
				output("`\$Ramius `)casts his glance on you, but no shimmer returns to him.");
				output("Noticing that you have no gems, you understand why he doesn't wish to speak with you.");
			}
			break;
		case "exchange":
			$d = httpget('d');
			switch($d){
				case "yes":
					$range = explode("-",get_module_setting("range"));
					$favor = e_rand($range[0],$range[1]);
					debug("Bottom ".$range[0]." Top ".$range[1]." Rand ".$favor);
					output("`\$Ramius `)lunges forward, and steals a gem from your pouch.");
					output("Instantly, you feel more power surging into you.");
					output("`n`nYou have gained `\$%s `)favor with `\$Ramius`)!",$favor);
					if (get_module_setting("take")){
						if ($session['user']['alive']){
							$session['user']['turns']-=get_module_setting("amnt");
							$turns = translate_inline(get_module_setting("amnt")==1?"Forest Fight":"Forest Fights");
						}else{
							$session['user']['gravefights']-=get_module_setting("amnt");
							$turns = translate_inline(get_module_setting("amnt")==1?"Gravefight":"Gravefights");
						}
						output("`n`nBut, you have lost `^%s `)%s!",
								get_module_setting("amnt"),
								$turns
							);
					}
					$session['user']['gems']--;
					$session['user']['deathpower']+=$favor;
					debuglog("traded 1 gem for $favor favor");
					$times++;
					set_module_pref("times",$times);
					break;
				case "no":
					output("`)You turn around, and begin to walk you.");
					output("`\$Ramius `)is quite displeased with you, and spits at your shadow.");
					break;
				default:
					output("`\$Ramius `)ushers you further in, and eyes your gem pouch warily.");
					output("\"`\$You know I be wanting them gems...");
					output("Now, why don't you be a good little mortal, and hand them over...`)\"");
					addnav("Give Gem","runmodule.php?module=ramcry&op=exchange&d=yes");
					addnav("Don't Give Gem","runmodule.php?module=ramcry&op=exchange&d=no");
					break;
				}
			break;
		}
addnav("Leave");
if ($session['user']['alive']){
	villagenav();
}else{
	addnav("Return to Mausoleum","graveyard.php?op=enter");
}
page_footer();
}
?>