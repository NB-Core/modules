In the database in the module_hooks table:

add hookactivewhen as a text field with a not null setting.


lib/modules.php
Add this function:

/**
 * Evaluates a PHP Expression
 *
 * @param string $condition The PHP condition to evaluate
 * @return bool The result of the evaluated expression
 */
function evalCondition($condition) {
	global $session;
//	debug("Testing condition '{$condition}'");
	$result = eval($condition);
//	$debugMsg = print_r($result,true);
//	debug("Result was: {$debugMsg}");
	return (bool)$result;	
}

And then change the following functions:

/**
 * Called by modules to receive notification of an event
 *
 * @param string $hookname The hook to receive a notification for
 * @param string $functioncall The function that should be called
 * @param string $hookactivewhen An expression that should be evaluated before triggering the event
 */
function module_addhook($hookname,$functioncall=false, $hookactivewhen=false){
	global $mostrecentmodule;
	module_drophook($hookname,$functioncall);
	
	if ($functioncall===false) 
		$functioncall=$mostrecentmodule."_dohook";
		
	if ($hookactivewhen===false)
		$hookactivewhen = "";
		
	debug("Adding a hook at $hookname for $mostrecentmodule to $functioncall which is active at '{$hookactivewhen}'");
	$sql = "INSERT INTO " . db_prefix("module_hooks") . " (modulename,location,function, hookactivewhen) VALUES ('$mostrecentmodule','".addslashes($hookname)."','".addslashes($functioncall)."','".addslashes($hookactivewhen)."')";
	db_query($sql);
	invalidatedatacache("hook-".$hookname);
}


/**
 * An event that should be triggered
 *
 * @param string $hookname The name of the event to raise
 * @param array $args Arguments that should be passed to the event handler
 * @param bool $allowinactive Allow inactive modules
 * @param bool $only Only this module?
 * @return array The args from the event handlers
 */
function modulehook($hookname, $args=false, $allowinactive=false, $only=false){
	global $navsection, $mostrecentmodule, $blocked_modules;
	if ($args===false) $args = array();
	$active = "";
	if (!$allowinactive) $active = " active=1 AND";

	$sql = "SELECT " . db_prefix("module_hooks") . ".* FROM " . db_prefix("module_hooks") . " INNER JOIN " . db_prefix("modules") . " ON ". db_prefix("modules") . ".modulename = " . db_prefix("module_hooks") . ".modulename WHERE $active location='$hookname' ORDER BY " . db_prefix("module_hooks") . ".modulename";
	$result = db_query_cached($sql,"hook-".$hookname);

	// $args is an array passed by value and we take the output and pass it
	// back through

	// Save off the mostrecent module since having that change can change
	// behaviour especially if a module calls modulehooks itself or calls
	// library functions which cause them to be called.
	$mod = $mostrecentmodule;

	while ($row = db_fetch_assoc($result)){
		// If we are only running hooks for a specific module, skip all
		// others.
		if ($only && $row['modulename']!=$only) continue;
		// Skip any module invocations which should be blocked.
		if ($blocked_modules[$row['modulename']]) continue;

		if (injectmodule($row['modulename'], $allowinactive)) {
			$oldnavsection = $navsection;
			tlschema("module-{$row['modulename']}");
			// Pass the args into the function and reassign them to the
			// result of the function.
			// Note: each module gets the previous module's modified return
			// value if more than one hook here.
			// Order of operations could become an issue, modules are called
			// in alphabetical order by their module name (not display name).
			$row['hookactivewhen']=trim($row['hookactivewhen']);
			
//			debug("Condition for module {$row['modulename']} is '{$row['hookactivewhen']}'");
			
			if (($row['hookactivewhen']=="") || (evalCondition($row['hookactivewhen'])==true)) {
				$res = $row['function']($hookname, $args);
				if (is_array($res)) $args = $res;
			}

			//revert the translation namespace
			tlschema();
			//revert nav section after we're done here.
			$navsection = $oldnavsection;
		}
	}

	$mostrecentmodule=$mod;

	// And hand them back so they can be used.
	return $args;
}
