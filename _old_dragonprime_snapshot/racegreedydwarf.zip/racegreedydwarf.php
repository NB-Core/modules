<?php
/*Base Code: Imp Race (by Chris Vorndran AKA Sichae)
racegreedydwarf_run and most cases for racegreedydwarf_dohook code from Dwarven race (by Eric Stevens)
*/
function racegreedydwarf_getmoduleinfo(){
    $info = array(
        "name"=>"Race - Greedy Dwarf",
        "version"=>"1.0",
        "author"=>"Michael Tartre",
        "category"=>"Races",
        "download"=>"http://dragonprime.net/users/SpiritOfFire/racegreedydwarf.zip",
        "settings"=>array(
            "Greedy Dwarf Race Settings,title",
            "minedeathchance"=>"Chance for Greedy Dwarf to die in the mine,range,0,100,1|2",
			"divide"=>"Gold (on hand) is sqare rooted and divided by this value to give buff,int|500",
			"mindk"=>"How many DKs do you need before the race is available?,int|5",
			"moregold"=>"What factor will the gold from opponents be multiplied by?,int|1.2",
			"base_val"=>"What is the minimum value for the attack bonus?,int|1"
        ),
        );
    return $info;
}

function racegreedydwarf_install(){
	if (!is_module_installed("racedwarf")) {
		output("The Greedy Dwarves only choose to live with fellow dwarves.   You must install that race module.");
		return false;
	}
    module_addhook("chooserace");
    module_addhook("setrace");
    module_addhook("charstats");
	module_addhook("newday");
    module_addhook("raceminedeath");
	module_addhook("creatureencounter");
	module_addhook("village");
    return true;
}

function racegreedydwarf_uninstall(){
	global $session;
	$vname = getsetting("villagename", LOCATION_FIELDS);
	$gname = get_module_setting("villagename");
	$sql = "UPDATE " . db_prefix("accounts") . " SET location='$vname' WHERE location = '$gname'";
	db_query($sql);
	if ($session['user']['location'] == $gname)
		$session['user']['location'] = $vname;
	$sql = "UPDATE  " . db_prefix("accounts") . " SET race='" . RACE_UNKNOWN . "' WHERE race='Greedy Dwarf'";
	db_query($sql);
	if ($session['user']['race'] == 'Greedy Dwarf')
		$session['user']['race'] = RACE_UNKNOWN;
	return true;
}
function racegreedydwarf_refresh_buff () {
	racegreedydwarf_checkcity();
    $greedydwarf = round(sqrt($session['user']['gold'])/$divide, 1);
	apply_buff("racialbenefit",array(
		"name"=>"`@Need for Gold`0",
		"atkmod"=>get_module_setting('base_val')+$greedydwarf,
		"allowintrain"=>0,
		"allowinpvp"=>1,
		"rounds"=>-1,
		)
	);
}
function racegreedydwarf_dohook($hookname,$args){
    //yeah, the $resline thing is a hack.  Sorry, not sure of a better way
    //to handle this.
    // It could be passed as a hook arg?
    global $session,$resline;
	if (is_module_active("racedwarf")) {
		$city = get_module_setting("villagename", "racedwarf");
	} else {
		$city = getsetting("villagename", LOCATION_FIELDS);
	}
    $race = translate_inline("Greedy Dwarf");
	$divide = get_module_setting("divide");
    switch($hookname){
    case "raceminedeath":
        if ($session['user']['race'] == $race) {
            $args['chance'] = get_module_setting("minedeathchance");
            $args['racesave'] = translate_inline("Fortunately your Dwarven skills let you escape unscathed.`n");
        }
        break;
    case "charstats":
        if ($session['user']['race']==$race){
			$vital_info_dh = translate_inline("Vital Info");
			$race_dh = translate_inline("Race");
            addcharstat($vital_info_dh);
            addcharstat($race_dh, $race);
        }
        break;
     case "chooserace":
        if ($session['user']['dragonkills'] < get_module_setting("mindk")) {
			break;
		}
        output("<a href='newday.php?setrace=Greedy%20Dwarf$resline'>As a `4Greedy Dwarf`0</a> , `5your primary pursuit is gold.  You feel a constant need for more gold, and it would seem that your very life was tied to the presence of this object.`n`n",true);
        addnav("`\$'4G`)reedy Dwarves`0","newday.php?setrace=Greedy%20Dwarf$resline");
        addnav("","newday.php?setrace=Greedy%20Dwarf$resline");
        break;
     case "setrace":
        if ($session['user']['race']==$race){
            output("`^As an Greedy Dwarf, you are benefited by the presence of gold.`nYou gain extra attack!");
            if (is_module_active("cities")) {
                if ($session['user']['dragonkills']==0 &&
                        $session['user']['age']==0){
                    //new farmthing, set them to wandering around this city.
                    set_module_setting("newest-$city",
                            $session['user']['acctid'],"cities");
                }
                set_module_pref("homecity",$city,"cities");
                $session['user']['location']=$city;
            }
        }
        break;
    case "newday":
        if ($session['user']['race']==$race){
            racegreedydwarf_refresh_buff();
        }
        break;
	case "creatureencounter":
		if($session['user']['race']==$race) {
			$args['creaturegold']=round($args['creaturegold']*get_module_setting('moregold'),0);
			racegreedydwarf_refresh_buff();
		}
		break;
	case "village":
		if($session['user']['race']==$race) {
			racegreedydwarf_refresh_buff();
		}
		break;
	}
    return $args;
}

function racegreedydwarf_checkcity(){
    global $session;
    $race="Greedy Dwarf";
    if (is_module_active("racedwarf")) {
		$city = get_module_setting("villagename", "racedwarf");
	} else {
		$city = getsetting("villagename", LOCATION_FIELDS);
	}
	
	if ($session['user']['race']==$race && is_module_active("cities")){
		//if they're this race and their home city isn't right, set it up.
		if (get_module_pref("homecity","cities")!=$city){ //home city is wrong
			set_module_pref("homecity",$city,"cities");
		}
	}
    return true;
}

function racegreedydwarf_run(){
	$op = httpget("op");
	switch($op){
	case "ale":
		require_once("lib/villagenav.php");
		page_header("Great Kegs of Ale");
		output("`3You make your way over to the great kegs of ale lined up near by, looking to score a hearty draught from their mighty reserves.");
		output("A mighty dwarven barkeep, standing at least 4 feet tall is serving out the drinks to the drunken crowd.");
		addnav("Drinks");
		modulehook("ale");
		addnav("Other");
		villagenav();
		page_footer();
		break;
	}
}
?>