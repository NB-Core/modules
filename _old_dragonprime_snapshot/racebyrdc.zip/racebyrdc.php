<?php

function racebyrdc_getmoduleinfo(){
	$info = array(
		"name"=>"Race - Byrd (city)",
		"version"=>"1.03",
		"author"=>"Enhas",
		"category"=>"Races",
		"download"=>"http://dragonprime.net/users/Enhas/racebyrdc.txt",
		"settings"=>array(
			"Byrd Race Settings,title",
                  "villagename"=>"Name for the Byrd city|Neergreve",
			"minedeathchance"=>"Percent chance for Byrds to die in the mine,range,0,100,1|70",
			"mindk"=>"How many DKs do you need before the race is available?,int|3",
                  "tributecost"=>"Cost to pay tribute to Azan (multiplied by level),int|5",
                  "maxtribute"=>"Maximum number of times a player can pay tribute each day,range,1,10,1|3",
		),
            "prefs"=>array(
			"Byrd Race Preferences,title",
                  "tributetoday"=>"Number of times player has paid tribute today,int|0",
		)
	);
	return $info;
}

function racebyrdc_install(){
	module_addhook("chooserace");
	module_addhook("setrace");
	module_addhook("villagetext");
	module_addhook("travel");
	module_addhook("charstats");
	module_addhook("village");
	module_addhook("validlocation");
	module_addhook("validforestloc");
	module_addhook("moderate");
	module_addhook("changesetting");
	module_addhook("raceminedeath");
	module_addhook("racenames");
      module_addhook("pvpadjust");
      module_addhook("adjuststats");
      module_addhook("battle-victory");
	module_addhook("battle-defeat");
      module_addhook("newday");
	return true;
}

function racebyrdc_uninstall(){
	global $session;
	$vname = getsetting("villagename", LOCATION_FIELDS);
	$gname = get_module_setting("villagename");
	$sql = "UPDATE " . db_prefix("accounts") . " SET location='$vname' WHERE location = '$gname'";
	db_query($sql);
	if ($session['user']['location'] == $gname)
		$session['user']['location'] = $vname;
	$sql = "UPDATE  " . db_prefix("accounts") . " SET race='" . RACE_UNKNOWN . "' WHERE race='Byrd'";
	db_query($sql);
	if ($session['user']['race'] == 'Byrd')
		$session['user']['race'] = RACE_UNKNOWN;
	
	return true;
}

function racebyrdc_dohook($hookname,$args){
	global $session,$resline;
	$city = get_module_setting("villagename");
	$race = "Byrd";
	switch($hookname){
	case "racenames":
		$args[$race] = $race;
		break;
      case "pvpadjust":
            if ($args['race'] == $race) {
			apply_buff("targetracialbenefit",array(
				"name"=>"",
				"minioncount"=>1,
				"mingoodguydamage"=>0,
				"maxgoodguydamage"=>1+ceil($args['creaturelevel']/3),
				"effectmsg"=>"`Q{badguy}`Q's `4Hawk`Q swoops down and attacks you for `\${damage}`Q damage!",
				"effectnodmgmsg"=>"`Q{badguy}`Q's `4Hawk`Q tries to swoop down and attack you,`Q but it `^MISSES`Q!",
				"allowinpvp"=>1,
				"rounds"=>-1,
				"schema"=>"module-racebyrdc",
				)
                        );
                        $args['creaturedefense']-=($args['creaturedefense']*.15);
                        $args['creatureattack']+=($args['creatureattack']*.2);
                        $args['creaturehealth']-= round($args['creaturehealth']*.1, 0);
		}
		break;
      case "adjuststats":
		if ($args['race'] == $race) {
			$args['defense'] -= ($args['defense']*.15);
			$args['attack'] += ($args['attack']*.2);
                  $args['maxhitpoints'] -= round($args['maxhitpoints']*.1, 0);
		}
		break;
      case "battle-victory":
	case "battle-defeat":
		if ($args['type'] == 'pvp') {
			strip_buff("targetracialbenefit");
		}
		break;
	case "raceminedeath":
		if ($session['user']['race'] == $race) {
			$args['chance'] = get_module_setting("minedeathchance");
			$args['racesave'] = "Your keen Byrd senses allow you to escape unharmed!`n";
			$args['schema']="module-racebyrdc";
		}
		break;
	case "changesetting":
		if ($args['setting'] == "villagename" && $args['module']=="racebyrdc") {
			if ($session['user']['location'] == $args['old'])
				$session['user']['location'] = $args['new'];
			$sql = "UPDATE " . db_prefix("accounts") .
				" SET location='" . $args['new'] .
				"' WHERE location='" . $args['old'] . "'";
			db_query($sql);
			if (is_module_active("cities")) {
				$sql = "UPDATE " . db_prefix("module_userprefs") .
					" SET value='" . $args['new'] .
					"' WHERE modulename='cities' AND setting='homecity'" .
					"AND value='" . $args['old'] . "'";
				db_query($sql);
			}
		}
		break;
	case "charstats":
		if ($session['user']['race']==$race){
			addcharstat("Vital Info");
			addcharstat("Race", translate_inline($race));
		}
		break;
	case "chooserace":
		if ($session['user']['dragonkills'] < get_module_setting("mindk"))
			break;
		output("<a href='newday.php?setrace=Byrd$resline'>High in the treetop city of %s</a>, your winged race of `QByrds`0 have lived in harmony with nature for generations.  The threat of `@The Green Dragon`0 looms over your people, as many have gone missing recently, never to return.`n`n",$city, true);
		addnav("`QByrd`0","newday.php?setrace=$race$resline");
		addnav("","newday.php?setrace=$race$resline");
		break;
	case "setrace":
		if ($session['user']['race']==$race){
			output("`^As a `QByrd`^, you are more tuned in with nature than other races.`n");
			output("Your childhood pet and longtime friend, a `4Hawk`^, joins you on your journey!`n`n");
                  output("Having been raised high in the trees, you know the ways of the hunt. You gain extra attack!`n`n");
                  output("However, your body is more frail than some other races.  You lose some defense!`");
			if (is_module_active("cities")) {
				if ($session['user']['dragonkills']==0 &&
						$session['user']['age']==0){
					//new farmthing, set them to wandering around this city.
					set_module_setting("newest-$city",
							$session['user']['acctid'],"cities");
				}
				set_module_pref("homecity",$city,"cities");
				if ($session['user']['age'] == 0)
					$session['user']['location']=$city;
			}
		}
		break;
	case "validforestloc":
	case "validlocation":
		if (is_module_active("cities"))
			$args[$city] = "village-$race";
		break;
	case "moderate":
		if (is_module_active("cities")) {
			tlschema("commentary");
			$args["village-$race"]=sprintf_translate("City of %s", $city);
			tlschema();
		}
		break;
	case "travel":
		$capital = getsetting("villagename", LOCATION_FIELDS);
		$hotkey = substr($city, 0, 1);
		tlschema("module-cities");
		if ($session['user']['location']==$capital){
			addnav("Safer Travel");
			addnav(array("%s?Go to %s", $hotkey, $city),"runmodule.php?module=cities&op=travel&city=$city");
		}elseif ($session['user']['location']!=$city){
			addnav("More Dangerous Travel");
			addnav(array("%s?Go to %s", $hotkey, $city),"runmodule.php?module=cities&op=travel&city=$city&d=1");
		}
		if ($session['user']['superuser'] & SU_EDIT_USERS){
			addnav("Superuser");
			addnav(array("%s?Go to %s", $hotkey, $city),"runmodule.php?module=cities&op=travel&city=$city&su=1");
		}
		tlschema();
		break;
      case "newday":
            set_module_pref("tributetoday",0);
		if ($session['user']['race']==$race){
			racebyrdc_checkcity();
			apply_buff("racialbenefit",array(
				"name"=>"`QByrd's `4Hawk`0",
				"minioncount"=>1,
				"minbadguydamage"=>0,
				"maxbadguydamage"=>"1+ceil(<level>/3)",
				"effectmsg"=>"`QYour `4Hawk`Q swoops down and attacks {badguy}`Q for `^{damage}`Q damage!",
				"effectnodmgmsg"=>"`QYour `4Hawk`Q tries to swoop down and attack {badguy}`Q, but it `\$MISSES`Q!",
                        "atkmod"=>1.2,
                        "defmod"=>0.85,
                        "badguydmgmod"=>1.1,
				"allowinpvp"=>1,
				"allowintrain"=>1,
				"rounds"=>-1,
				"schema"=>"module-racebyrdc",
				)
			);
		}
		break;	
	case "villagetext":
		racebyrdc_checkcity();
		if ($session['user']['location'] == $city){
			$args['text']=array("`Q`c`bAerial %s, city of the Byrds`b`c`n`QYou stand within %s's central square.  A statue of the ancient Byrd hero, `2Azan`Q, stands proud and tall in front of you.  Some people are chatting a bit down a street to the west of you, near `2Azan's Temple`Q.  Many houses and buildings are held up by the thick forest, and you admire the work that must have went into them to keep them from crashing down into the deep abyss far below.`n", $city, $city);
			$args['schemas']['text'] = "module-racebyrdc";
			$args['clock']="`n`QA crumbling clock face, carved into an old tree next to the statue, tells you the current time in the realm is `2%s`Q.`n";
			$args['schemas']['clock'] = "module-racebyrdc";
			if (is_module_active("calendar")) {
				$args['calendar'] = "`n`QA crude, but clever calendar carved to the right of the clock reads `2%s`Q, `2%s %s %s`Q.`n";
				$args['schemas']['calendar'] = "module-racebyrdc";
			}
			$args['title']= array("The Aerial City of %s", $city);
			$args['schemas']['title'] = "module-racebyrdc";
			$args['sayline']="chants";
			$args['schemas']['sayline'] = "module-racebyrdc";
			$args['talk']="`n`QNear `2Azan's Temple`Q, people chant:`n";
			$args['schemas']['talk'] = "module-racebyrdc";
			$new = get_module_setting("newest-$city", "cities");
			if ($new != 0) {
				$sql =  "SELECT name FROM " . db_prefix("accounts") .
					" WHERE acctid='$new'";
				$result = db_query_cached($sql, "newest-$city");
				$row = db_fetch_assoc($result);
				$args['newestplayer'] = $row['name'];
				$args['newestid']=$new;
			} else {
				$args['newestplayer'] = $new;
				$args['newestid']="";
			}
			if ($new == $session['user']['acctid']) {
				$args['newest']="`n`QYou stand within the square, taking in the sights as your wings flutter in the breeze.";
			} else {
				$args['newest']="`n`QStanding within the square, taking in the sights is `2%s`Q.";
			}
			$args['schemas']['newest'] = "module-racebyrdc";
			$args['gatenav']="The World Below";
			$args['schemas']['gatenav'] = "module-racebyrdc";
			$args['fightnav']="Terrace of Trial";
			$args['schemas']['fightnav'] = "module-racebyrdc";
			$args['marketnav']="Alley of Azan";
			$args['schemas']['marketnav'] = "module-racebyrdc";
			$args['tavernnav']="Back Streets";
			$args['schemas']['tavernnav'] = "module-racebyrdc";
			$args['section']="village-$race";
		}
		break;
	case "village":
		if ($session['user']['location'] == $city) {
			tlschema($args['schemas']['tavernnav']);
			addnav($args['marketnav']);
			tlschema();
			addnav("M?Azan's Temple","runmodule.php?module=racebyrdc&op=temple");
		}
		break;
	}
	return $args;
}

function racebyrdc_checkcity(){
	global $session;
	$race="Byrd";
	$city= get_module_setting("villagename");
	
	if ($session['user']['race']==$race && is_module_active("cities")){
		//if they're this race and their home city isn't right, set it up.
		if (get_module_pref("homecity","cities")!=$city){ //home city is wrong
			set_module_pref("homecity",$city,"cities");
		}
	}	
	return true;
}

function racebyrdc_run(){
      global $session;
	$op = httpget("op");
      $tribute=get_module_setting("tributecost");
      $maxtribute=get_module_setting("maxtribute");
      $tributetoday=get_module_pref("tributetoday");
      $level = $session['user']['level'];
      $tributecost = ($tribute * $level);
	if ($op=="temple"){
		require_once("lib/villagenav.php");
		page_header("Azan's Temple");
            if ($tributetoday >= $maxtribute) {
            output("`QRakan greets you as you enter.  `6'`2Azan`6 has blessed you enough for today.  You would be wise to return tomorrow to pay more tribute, and to line my pockets with.. er, get out!' `Qhe says, and pushes you towards the exit.`0");
            villagenav();
            }elseif ($tributetoday < $maxtribute) {
		output("`QWalking into the tall, cold stone building that is `2Azan's Temple`Q, you have an eerie feeling about this place.  ");
            output("Inside are more statues of the great `2Azan`Q, and of other great warriors you recognize from childhood stories.  Stopping to admire one of them, you suddenly feel something tap your shoulder from behind!`n`n");
            output("You are ready to draw your `7%s`Q, but you notice that the person is just a harmless old Byrd.`n`n", $session['user']['weapon']);
            output("`6'Greetings, warrior!  I am Rakan.'`Q he says. `6'Sorry to have startled you, but are you here to pay tribute to the mighty `2Azan`6?'`Q he says, shoving a small collection pan into your face.`n`n");
            output("`@'Pay tribute?'`Q you ask.`n`n");
            output("`QRakan nods.  `6'`2Azan`6 has been known to reward his followers, and the stronger warrior you are the better you shall be blessed!  Now, if you're not going to pay, get out of here!'`0");
            addnav(array("Pay %s gold",$tributecost),"runmodule.php?module=racebyrdc&op=pay");
		villagenav();
            }
            }elseif ($op=="pay"){
            require_once("lib/villagenav.php");
            page_header("Azan's Temple");
            if ($session['user']['gold'] < $tributecost){
            output("`QYou search your pockets for the required fee.  However, you do not find enough!`n`n");
            output("`QRakan reminds you that `2Azan`Q only rewards the paying, and pushes you towards the exit.`n`n`0");
            villagenav();
            }elseif ($session['user']['gold'] >= $tributecost){
            villagenav();
            $session['user']['gold']-=$tributecost;
            $tributetoday++;
            set_module_pref("tributetoday",$tributetoday);
            output("`QYou place your gold into the collection pan.  Rakan chants a small prayer, and you feel a sudden surge of power enter your body!`n`n");
            output("`6'`2Azan`6 has rewarded you!  Come back any time, I.. er, `2Azan`6 could use the extra gold!'`Q Rakan says, guding you to the exit.`n`n`0");
            $azanbuff = array(
				"name"=>"`2Azan's Blessing`0",
				"rounds"=>($level + 5),
				"wearoff"=>"`2Azan's blessing fades.  Perhaps you should pay tribute once more?",
				"atkmod"=>(1.05+($level / 100)),
				"roundmsg"=>"`2Azan's power is with you!",
				"schema"=>"module-racebyrdc"
			      );
			      apply_buff("azanbuff",$azanbuff);
      }
      }
      page_footer();
}
?>