Legend of the Green Dragon
by  Eric "MightyE" Stevens (http://www.mightye.org)
and JT "Kendaer" Traub (http://www.dragoncat.net)

Software Project Page:
http://sourceforge.net/projects/lotgd

Modification Community Page:
http://dragonprime.net

Author of this Module:
Lonnyl (http://www.pqcomp.com)
CortalUX (cortalux@gmail.com)

Download the latest version of this module from:
http://www.pqcomp.com/modules/mydownloads/visit.php?cid=3&lid=42

----------------------------------------------
-- STATUS: -----------------------------------
----------------------------------------------
This module is STABLE.

----------------------------------------------
-- INFORMATION: ------------------------------
----------------------------------------------
This is a module for LotGD 1.X.X, allowing you
to let users download modules from your site.

----------------------------------------------
-- INSTALLATION: -----------------------------
----------------------------------------------
Copy all FOLDERS within this zip into your main
directory.

Make sure you have the images on the list below.

Login to the Superuser Grotto and Install / Activate it.

----------------------------------------------
-- IMAGE LIST: -------------------------------
----------------------------------------------
The following 55 images come with the module.
These can be edited, deleted, and replaced, at any time, from the Grotto.

+-------------------+-------------------+
|	Keystroke		|	Filename		|
---------------------------------------
|	*sing*			|	sing.gif		|
|	*slimer*		|	slimer.gif		|
|	*spineyes*		|	spineyes.gif	|
|	*yakyak*		|	yakyak.gif		|
|	*tongue2*		|	tongue2.gif		|
|	*nono*			|	nono.gif		|
|	*nod*			|	nod.gif			|
|	*whew*			|	whew.gif		|
|	*bateyes*		|	bateyes.gif		|
|	*kiss*			|	kiss.gif		|
|	*brokeheart*	|	brokeheart.gif	|
|	*giggle*		|	giggle.gif		|
|	*confused*		|	confused.gif	|
|	*wink3*			|	wink3.gif		|
|	*sarcastic*		|	srcstic.gif		|
|	*order*			|	order.gif		|
|	*music*			|	musicface.gif	|
|	*red*			|	redface.gif		|
|	*purple*		|	purpleface.gif	|
|	*peace*			|	peace.gif		|
|	*wink2*			|	wink2.gif		|
|	*lie*			|	lie.gif			|
|	*mad*			|	mad2.gif		|
|	*shocked*		|	shocked.gif		|
|	*doh*			|	doh.gif			|
|	*wimper*		|	wimper.gif		|
|	*rofl*			|	rofl.gif		|
|	*rolleyes*		|	rolleyes.gif	|
|	*tongue*		|	tongue.gif		|
|	*laugh*			|	laugh.gif		|
|	*embarassed*	|	embarassed.gif	|
|	*groove*		|	groove.gif		|
|	*grin*			|	grin.gif		|
|	*shock*			|	shock.gif		|
|	*drool*			|	drool.gif		|
|	*clap*			|	clap.gif		|
|	*angel*			|	angel.gif		|
|	*wink*			|	wink.gif		|
|	*zzz*			|	zzz.gif			|
|	*nottalking*	|	nottalking.gif	|
|	*nerd*			|	nerd.gif		|
|	*stop*			|	stop.gif		|
|	*cry*			|	cry.gif			|
|	*frown*			|	frown.gif		|
|	*love*			|	loveface.gif	|
|	*angry*			|	mad.gif			|
|	*party*			|	party.gif		|
|	*rose*			|	rose.gif		|
|	*shhh*			|	shhh.gif		|
|	*sick*			|	sick.gif		|
|	*yawn*			|	yawn.gif		|
|	*pray*			|	pray.gif		|
|	*biggrin*		|	grin2.gif		|
|	*idea*			|	idea.gif		|
|	*happy*			|	happy.gif		|
+-------------------+-------------------+