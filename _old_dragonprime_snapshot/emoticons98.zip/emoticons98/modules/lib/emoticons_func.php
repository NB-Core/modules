<?php
function emoticons_nav() {
	rawoutput("<br>[<a href='runmodule.php?module=emoticons&op=add'>");
	output("Add an Emoticon");
	rawoutput("</a>] - [<a href='runmodule.php?module=emoticons&op=list'>");
	output("List Emoticons");
	rawoutput("</a>]");
	addnav("","runmodule.php?module=emoticons&op=add");
	addnav("","runmodule.php?module=emoticons&op=list");
}

function emoticons_delete() {
	$ty=httpget('ty');
	$stroke=httpget('stroke');
	$emots=emoticons_array();
	$url=$emots[$stroke];
	popup_header("Emoticon Deletion");
	if ($ty=='') {
		output("Are you sure you want to delete that emoticon? The file will be deleted, if possible.`n");
		rawoutput("<center><a href='runmodule.php?module=emoticons&op=delete&stroke=$stroke&ty=yes'>".translate_inline("Of course!!")."</a></center>");
		addnav("runmodule.php?module=emoticons&op=delete&stroke=$stroke&ty=yes");
	} else {
		output("Emoticon Deleted.`n");
		if (file_exists("./images/emoticons/$url")) {
			if (is_writable("./images/emoticons/$url")) {
				output("The file for the emoticon was erased.");
				unlink("./images/emoticons/$url");
			} else {
				output("The file for the emoticon couldn't be erased.");
			}
		} else {
			output("The file for the emoticon didn't exist, anyway.");
		}
	}
	emoticons_nav();
	popup_footer();
}

function emoticons_add() {
	require_once('lib/safeescape.php');
	$ty=httpget('ty');
	$name=safeescape(httppost('name'));
	$stroke=safeescape(httppost('stroke'));
	popup_header("Emoticon Adding");
	if (empty($ty)) {
		$s=translate_inline("Submit");
		$form ="<form name=\"upload\" id=\"upload\" action='runmodule.php?module=emoticons&op=add&ty=2' ENCTYPE=\"multipart/form-data\" method=\"post\">";
		$form .="<label for=\"userfile\"><b>".translate_inline("File").":</b></label> <input type=\"file\" id=\"userfile\" name=\"userfile\"><br/><label for=\"name\"><b>".translate_inline("Name for on the server").":</b></label> <input type=\"text\" id=\"name\" name=\"name\"><br><label for=\"stroke\"><b>".translate_inline("Keystroke").":</b></label> <input type=\"text\" id=\"stroke\" name=\"stroke\"><br/> <input type=\"submit\" name=\"upload\" value=\"$s\"></form>";
		addnav("","runmodule.php?module=emoticons&op=add&ty=2");
		rawoutput($form);
	} else {
		$emots=emoticons_array();
		if (file_exists("images/emoticons/$name")||empty($name)) {
			output("That file already exists, or that name is empty.");
		} elseif (isset($emots[$stroke])) {
			output("That stroke is already in use.");
		} elseif (emoticons_check()) {
			global $_FILES;
			$temp_name = $_FILES['userfile']['tmp_name'];
			$file_path = "./images/emoticons/".$name;
			$result = move_uploaded_file($temp_name, $file_path);
			if ($result) {
				$sql="INSERT INTO `".db_prefix("emoticons")."` VALUES ('$name', '$stroke');";
				db_query($sql);
				output("The file has been uploaded with the name, %s.",$name);
			} else {
				output("Something went wrong when trying to upload your file.");
			}
		} else {
			output("That file is not the right type, or it doesn't have the right extension.");
		}
	}
	emoticons_nav();
	popup_footer();
}

function emoticons_check() {
	global $_FILES;
	$name=httppost('name');
	$ext = strrchr($name, '.');
	$array=array('.jpg','.gif','.tif','.jpeg','.png');
	if (!in_array($ext,$array)) {
		output("Files you upload must end in .jpg, .gif, .tif, .png, or .jpeg.");
		return false;
	}
	return true;
}

function emoticons_edit() {
	$ty=httpget('ty');
	$emots=emoticons_array();
	$stroke=httppost('stroke');
	$strke=httpget('stroke');
	popup_header("Emoticon Editing");
	if (empty($ty)) {
		$s=translate_inline("Submit");
		$form ="<form name=\"upload\" id=\"upload\" action='runmodule.php?module=emoticons&op=edit&ty=2&stroke=$strke' ENCTYPE=\"multipart/form-data\" method=\"post\"><label for=\"stroke\"><b>".translate_inline("Change Keystroke to").":</b></label> <input type=\"text\" id=\"stroke\" name=\"stroke\" value=\"$strke\"><br/> <input type=\"submit\" name=\"upload\" value=\"$s\"></form>";
		addnav("","runmodule.php?module=emoticons&op=edit&ty=2&stroke=$strke");
		rawoutput($form);
	} else {
		if (!empty($stroke)&&!isset($emots[$stroke])&&isset($emots[$strke])) {
			require_once('lib/safeescape.php');
			$sql="UPDATE `".db_prefix("emoticons")."` SET stroke='".safeescape($stroke)."' WHERE stroke='".safeescape($strke)."';";
			db_query($sql);
			output("The stroke has been renamed to %s.",$stroke);
		} else {
			output("That stroke was empty, or is in use.");
		}
	}
	emoticons_nav();
	popup_footer();
}

function emoticons_faq() {
	tlschema("faq");
	popup_header("Emoticon Questions");
	$x = translate_inline("Contents");
	rawoutput("<center><strong><a href='petition.php?op=faq'>".$x."</a></strong><br/><hr></center>");
	output_notl("`n`c`b`7%s`b`c`n`n",translate_inline("Questions about Emoticons"));
	output_notl("`^%s`n",translate_inline("1. Why are there little faces smiling at me?"));
	output_notl("`@%s`n",translate_inline("That's because they know what you are doing."));
	output_notl("%s`n",translate_inline("Ok. So they really don't know what you are doing.  Though I'm sure if we tried to take over your webcam we could figure it out."));
	output_notl("%s`n`n",translate_inline("These little faces you see are really called Emoticons.  They are emotions in graphical form."));
	
	output_notl("`^%s`n",translate_inline("2. Where can I get them?"));
	output_notl("`@%s`n`n",translate_inline("You can't really catch them! They aren't contagious. It is just a series of keystrokes and they appear in any commentary you might be in, if you type them, that is."));

	output_notl("`^%s`n",translate_inline("3. Ok, I guess I didn't ask the right question then.  How do you make emoticons?"));
	output_notl("`@%s",translate_inline("Emoticons can only be made in the commentary... when two halfs of an emoticon love each other very much.."));
	output_notl("%s`n`n",translate_inline("These codes are normally enclosed in asteriks- * - and are substituted for the correct picture, by the server."));
	
	output_notl("`^%s`n",translate_inline("4. They are so small."));
	output_notl("`@%s`n`n",translate_inline("Do you hear that often?  Sorry, but to help cut down on page loading time it is best to keep them small, and anyway! Size doesn't matter, it's what you do with it that counts! *grins*"));

	output_notl("`^%s`n",translate_inline("5. I don't see one I like.  Can you add more?"));
	output_notl("`@%s`n`n",translate_inline("Sure, you find them and if I like them I might add them to the list."));
	
	output_notl("`^%s`n",translate_inline("6. Stop being so flippant!"));
	output_notl("`@%s`n`n",translate_inline("Aww....."));

	output_notl("`^%s`n",translate_inline("7. Is there a list of emoticons?"));
	output_notl("`@%s`n`^",translate_inline("Of course there is! You should've asked!"));
	emoticons_list();
	rawoutput("<center><hr><br/><strong><a href='petition.php?op=faq'>".$x."</a></strong></center>");
	popup_footer();
}

function emoticons_array() {
	$emots=array();
	$sql="SELECT * FROM `".db_prefix("emoticons")."`;";
	$result=db_query($sql);
	while ($row=db_fetch_assoc($result)) {
		$stroke=str_replace("\'","'",str_replace('\"','"',$row['stroke']));
		$image=str_replace("\'","'",str_replace('\"','"',$row['file']));
		$emots[$stroke]=$image;
	}
	foreach ($emots as $stroke=>$pic) {
		if (!file_exists("./images/emoticons/$pic")) {
			unset($emots[$stroke]);
			if ($session['user']['superuser']&SU_MANAGE_MODULES&&get_module_pref('canedit')==1) {
				require_once('lib/systemmail.php');
				global $session;
				systemmail($session['user']['acctid'],translate_inline("`\$`bUh oh!!`b"),array(translate_inline("The %s file for the emoticon %s does not exist. It should be removed from the DB, or placed in images/emoticons."),$pic,$stroke));
			}
		}
	}
	return $emots;
}

function emoticons_clickdisplay($form="talkform",$box="commentary") {
	$emots=emoticons_array();
	$code="<script language=\"JavaScript\" type=\"text/javascript\">\n";
	$code.="function addSmiley(textToAdd)\n";
	$code.="{\n";
	$code.="document.getElementById(\"$box\").value += textToAdd;";
	$code.="document.getElementById(\"$box\").focus();\n";
	$code.="}\n";
	$code.="</script>\n";
	$code.=appoencode(translate_inline("`n`c`@-=-=Clickable Smilies=-=-`n"));
	foreach ($emots as $stroke=>$pic) {
		$x++;
		$code.="<a href=\"javascript:addSmiley(' $stroke ');\" border='0' style='border:0;'><img border='0' src='./images/emoticons/$pic'></a> ";
	}
	$code.=appoencode("`c");
	return $code;
}

function emoticons_convert($string="",$type=true) {
	$emots=emoticons_array();
	if ($type!==false) {
		foreach ($emots as $stroke=>$pic) {
			$string=str_replace($stroke,"<img src='./images/emoticons/$pic'/>",$string);
		}
	} else {
		foreach ($emots as $stroke=>$pic) {
			$string=str_replace("<img src='./images/emoticons/$pic'/>",$stroke,$string);
		}
	}
	return $string;
}

function emoticons_list() {
	global $session;
	$emots=emoticons_array();
	rawoutput("<table border='1' width='80%' align='center'><tr class='trhead' valign='center'><td>".appoencode(translate_inline("Keystrokes"))."</td><td>".appoencode(translate_inline("Picture"))."</td>");
	if ($session['user']['superuser']&SU_MANAGE_MODULES&&get_module_pref('canedit')==1) rawoutput("<td>".translate_inline("Operations")."</td>");
	rawoutput("</tr>");
	$x=0;
	foreach ($emots as $stroke=>$pic) {
		$x++;
		rawoutput("<tr class='".($x%2?"trlight":"trdark")."' valign='top'><td>$stroke</td><td><img src='./images/emoticons/$pic'/></td>");
		if ($session['user']['superuser']&SU_MANAGE_MODULES&&get_module_pref('canedit')==1) {
			$conf=translate_inline("Are you sure you want to delete this?");
			rawoutput("<td>[<a href='runmodule.php?module=emoticons&op=edit&stroke=".urlencode($stroke)."'>".translate_inline("Edit")."</a>] - [<a href='runmodule.php?module=emoticons&op=delete&stroke=".urlencode($stroke)."'>".translate_inline("Delete")."</a>]");
			addnav("","runmodule.php?module=emoticons&op=delete&stroke=".urlencode($stroke));
			addnav("","runmodule.php?module=emoticons&op=edit&stroke=".urlencode($stroke));
		}
		rawoutput("</tr>");
	}
	rawoutput("</table>");
	if ($session['user']['superuser']&SU_MANAGE_MODULES&&get_module_pref('canedit')==1) {
		emoticons_nav();
	}
}

?>