<?php
//included images by Sichae and CortalUX
function emoticons_getmoduleinfo(){
	$info = array(
		"name"=>"Emoticons",
		"version"=>"2.2", 
		"author"=>"`#Lonny Luberts`^, `QDannic`^, and `@CortalUX`^.",
		"category"=>"PQcomp",
		"allowanonymous"=>true,
		"override_forced_nav"=>true,
		"download"=>"http://www.pqcomp.com/modules/mydownloads/visit.php?cid=3&lid=42",
		"vertxtloc"=>"http://www.pqcomp.com/",
		"settings"=>array(
			"Emoticons - General Settings,title",
			"everyFooter"=>"Have you done the module patch?,bool|0",
			"verDone"=>"What version was the patch last done on?,viewonly|It hasn't been",
		),
		"prefs"=>array(
			"Emoticons,title",
			"user_display"=>"Display emoticons?,bool|1",
			"user_click"=>"Display clickables in commentary?,bool|1",
			"canedit"=>"Can this user edit emoticons?,bool|0",
		),
	);
	return $info;
}

function emoticons_install(){
	global $session;
	if (!is_module_active('emoticons')){
		output("`c`b`QInstalling Emoticons Module.`b`n`c");
	}else{
		output("`c`b`QUpdating Emoticons Module.`b`n`c");
	}
	if (!db_table_exists(db_prefix("emoticons"))){
		$sql="CREATE TABLE `".db_prefix("emoticons")."` (
		  	 `file` varchar(30) NOT NULL default '',
		  	 `stroke` varchar(30) NOT NULL default '',
		  	   	PRIMARY KEY  (`stroke`)
		) TYPE=MyISAM;";
		db_query($sql);
		output("`c`b`QCreating Emoticons Table.`b`n`c");
		$emots=array("frown"=>"frown.gif","grin"=>"grin.gif","biggrin"=>"grin2.gif","happy"=>"happy.gif","laugh"=>"laugh.gif","love"=>"loveface.gif","angry"=>"mad.gif","mad"=>"mad2.gif","music"=>"musicface.gif","order"=>"order.gif","purple"=>"purpleface.gif","red"=>"redface.gif","rofl"=>"rofl.gif","rolleyes"=>"rolleyes.gif","shock"=>"shock.gif","shocked"=>"shocked.gif","slimer"=>"slimer.gif","spineyes"=>"spineyes.gif","sarcastic"=>"srcstic.gif","tongue"=>"tongue.gif","tongue2"=>"tongue2.gif","wink"=>"wink.gif","wink2"=>"wink2.gif","wink3"=>"wink3.gif","confused"=>"confused.gif","embarassed"=>"embarassed.gif","rose"=>"rose.gif","drool"=>"drool.gif","sick"=>"sick.gif","kiss"=>"kiss.gif","brokeheart"=>"brokeheart.gif","wimper"=>"wimper.gif","whew"=>"whew.gif","cry"=>"cry.gif","angel"=>"angel.gif","nerd"=>"nerd.gif","stop"=>"stop.gif","zzz"=>"zzz.gif","shhh"=>"shhh.gif","nottalking"=>"nottalking.gif","party"=>"party.gif","yawn"=>"yawn.gif","doh"=>"doh.gif","clap"=>"clap.gif","lie"=>"lie.gif","bateyes"=>"bateyes.gif","pray"=>"pray.gif","peace"=>"peace.gif","nono"=>"nono.gif","bow"=>"bow.gif","groove"=>"groove.gif","giggle"=>"giggle.gif","yakyak"=>"yakyak.gif","idea"=>"idea.gif","nod"=>"nod.gif","sing"=>"sing.gif");
		foreach ($emots as $stroke=>$pic) {
			$sql="INSERT INTO `".db_prefix("emoticons")."` VALUES ('$pic', '*$stroke*');";
			db_query($sql);
			if (file_exists("./images/$pic")&&is_writable("./images/$pic")) {
				unlink("./images/$pic");
			}
		}
		output("`c`b`QInserting Emoticons Table Data.`b`n`c");
	}
	output("`n`n`c`#`bDON'T FORGET TO SET PREFERENCES FOR USERS THAT CAN EDIT EMOTICONS, FROM THE USER EDITOR IN THE GROTTO!`b`c");
	if ($session['user']['superuser'] & SU_MANAGE_MODULES) {
		set_module_pref('canedit',1);
		output("`n`c`\$Your permissions have been set automatically.`c");
	}
	module_addhook_priority("footer-village",1);
	module_addhook_priority("footer-superuser",1);
	module_addhook("village");
	module_addhook("superuser");
	module_addhook("commentarytrail");
	module_addhook("viewcommentary");
	module_addhook("faq-toc");
	return true;
}

function emoticons_uninstall(){
	if (!db_table_exists(db_prefix("emoticons"))){
		$sql="DROP TABLE `".db_prefix("emoticons")."`;";
		db_query($sql);
		output("`c`b`QDropping Emoticons Table.`b`n`c");
	}
	output("`c`b`QUninstalling Emoticons Module.`b`n`c");
	return true;
}

function emoticons_dohook($hookname,$args){
	global $session;
	switch($hookname){
		case "footer-village":
			if (get_module_pref('user_display')==1&&get_module_pref('user_click')==1&&get_module_setting('everyFooter')==0&&$session['user']['specialinc']=="") {
				$code=emoticons_clickdisplay("talkform","commentary");
				rawoutput($code);
			}
		break;
		case "footer-superuser":
			if (get_module_pref('user_display')==1&&get_module_pref('user_click')==1&&get_module_setting('everyFooter')==0) {
				$code=emoticons_clickdisplay("talkform","commentary");
				rawoutput($code);
			}
		break;
		case "village":
			if ($session['user']['superuser']&SU_DOESNT_GIVE_GROTTO) { // if the user can't enter the grotto
				addnav($args['othernav']);
				addnav("Emoticon Tools","runmodule.php?module=emoticons&op=list",false,true);
			}
		break;
		case "superuser":
			global $logd_version;
			if (get_module_setting('verDone')!=$logd_version) set_module_setting('everyFooter',0);
			if (get_module_pref('canedit')==1) {
				addnav("Module Configurations");
				addnav("Emoticon Tools","runmodule.php?module=emoticons&op=list",false,true);
			}
		break;
		case "faq-toc":
			$t = translate_inline("`@Frequently Asked Questions on Emoticons`0");
			output_notl("&#149;<a href='runmodule.php?module=emoticons&op=faq'>$t</a><br/>", true);
		break;
		case "commentarytrail":
			global $logd_version;
			set_module_setting('everyFooter',1);
			set_module_setting('verDone',$logd_version);
			if (get_module_pref('user_display')&&get_module_pref('user_click')==1){
				rawoutput(emoticons_clickdisplay("talkform","commentary"));
			}
		break;
		case "viewcommentary":
			if (get_module_pref('user_display')){
				$args['commentline']=emoticons_convert($args['commentline'],true);
			}
		break;
	}
	return $args;
}

function emoticons_run(){
	global $session;
	$op = httpget("op");
	switch ($op) {
		case "add":
			emoticons_add();
		break;
		case "list":
			popup_header("Emoticons List");
			emoticons_list();
			popup_footer();
		break;
		case "delete":
			emoticons_delete();
		break;
		case "edit":
			emoticons_edit();
		break;
		case "faq":
			emoticons_faq();
		break;
		default:
			require_once("lib/forcednavigation.php");
			do_forced_nav(false, false);
		break;
	}
}
include_once ("lib/emoticons_func.php");
?>