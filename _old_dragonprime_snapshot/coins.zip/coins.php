<?php

function coins_getmoduleinfo(){
	$info = array(
		"name"=>"Coins Module",
		"version"=>"2.01",
		"author"=>"R4000, DaveS Repairs",
		"category"=>"Coins",
		"download"=>"",
		"settings" => array(
			"storeloc"=>"Where does the store appear?,location|".getsetting("villagename", LOCATION_FIELDS),
			),
  		"prefs"=> array(
  			"Main coin settings,note",
  		  	"unknowncoin"=>"User got unknown coin yet?,bool|0",
  			"magicalcoin"=>"User got magic coin yet?,bool|0",
  			"runecoin"=>"User got rune coin yet?,bool|0",
  			"goldcoin"=>"User got gold coin yet?,bool|0",
  			"silvercoin"=>"User got silver coin yet?,bool|0",
  			"bronzecoin"=>"User got bronze coin yet?,bool|0",
  			"rubbercoin"=>"User got rubber coin yet?,bool|0",
  			"tarnishedcoin"=>"User got tarnished coin yet?,bool|0",			
  			),
	);
	return $info;
}

function coins_chance(){
	return 50;
}

function coins_install(){
	if(!function_exists("strtolower")){
		output("`n`n`1`bSORRY! YOUR CURRENT PHP VERSION IS NOT SUPPORTED!`n");
		output("`^`bSORRY! YOUR CURRENT PHP VERSION IS NOT SUPPORTED!`n`n");		
		return false;
	}
	module_addhook("village");	
	module_addhook("footer-bank");
	module_addhook("inn-footer");
	module_addhook("changesetting");
	module_addeventhook("forest","require_once(\"modules/coins.php\"); return coins_chance()");
	return true;
}

function coins_uninstall(){
	return true;
}

function coins_dohook($hookname,$args){
	global $session;
	switch ($hookname) {
		case "changesetting":
			if ($args['setting'] == "villagename") {
				if ($args['old'] == get_module_setting("storeloc")) {
					set_module_setting("storeloc", $args['new']);
				}	
			}
			break;
		case "footer-bank":
			if(get_module_pref("tarnishedcoin") == 1){
				addnav("Coins");
				addnav("Show Elessa your coins","runmodule.php?module=coins&op=elessashow");			
			}
			break;
		case "village":
			if ($session['user']['location'] == get_module_setting("storeloc")){ 
				tlschema($args["schemas"]["marketnav"]);
				addnav($args["marketnav"]);
				tlschema();
				addnav("Rare Coin Shop", "runmodule.php?module=coins&op=shop&subop=enter");	
			}
			break;
		case "inn-footer":
			if(get_module_setting("shop") == 1){
				$rand = e_rand(1,20);
				if($rand == 10){
					addnav("Coin shop","runmodule.php?module=coins&op=shop&subop=enter");
					output("`^You find a small door...`n");
				}
			}
			break;
	}
	return $args;
}

function coins_runevent($type,$link) {
	global $session;	
	$coins = array ("Tarnished"	=> "dirty brown coin",
			"Rubber"	=> "small bouncy coin",
			"Bronze"	=> "dirty bronze coin",
			"Silver"	=> "bright silver coin",
			"Gold"		=> "pale gold coin",
			"Rune"		=> "coin with strange rune-like markings",
			"Magical"	=> "small coin that keeps changing colour",
			"Unknown"	=> "wierd unknown coin");
	$from = $link;
	$op = httpget('op');
	$session['user']['specialinc'] = "module:coins";
	$end = 0;
	$amount=0;
	foreach ($coins as $key=>$val){
		if(get_module_pref(strtolower($key)."coin") == 0 && $end != 1){
			output("`2You notice a %s on the floor.`n",$val);
			output("`2You lean over and pick it up!`n");
			debuglog("found ".strtolower($key)." coin");
			output("`n`2You have found the `7%s Coin`n",$key);
			if(strtolower($key) == "magical"){
				output("`2As you pick it up you feel a strange force spread though your body.`n");
			}
			set_module_pref(strtolower($key)."coin",1);
			$end = 1;	 		
		}else $amount++;
	}
	if ($amount==8) output("`2You notice a platinum coin and try to pick it up.  However, it's glued to the floor and you can't pry it out of the ground.");
	$session['user']['specialinc'] = "";
}

function coins_run(){
	global $session;
	$op = httpget('op');
	$subop = httpget('subop');	
	switch($op){
		case "elessashow":
			page_header("Your Coins");
			output("`2You hand your coins to Elessa.`n");
			output("`2She struggles to explain what each one does.`n");
			output("`2She hands you a sheet of paper with a list of your coins and a short description`n`n");
			$coins = array ("Tarnished"	=> "Useless",
					"Rubber"	=> "bounces, use when required",
					"Bronze"	=> "one of these is worth about 1 gold",
					"Silver"	=> "this is worth a few pieces of gold",
					"Gold"		=> "Rare. Worth 200 gold",
					"Rune"		=> "Never seen before",
					"Magical"	=> "Never seen before",
					"Unknown"	=> "Never seen before");
			foreach ($coins as $key=>$val){
				if(get_module_pref(strtolower($key)."coin") == 1){
					output("`^%s Coin `2",$key);
					output("-`1 %s`n",$val);					
				}
			}			
			addnav("I?Return to the Bank","bank.php");
			break;
		case "shop":
			page_header("Rare Coin Shop");
			switch($subop){
				case "enter":
					output("`2You walk into the small pokey shop`n");
					output("`2The windows are all dusty`n");
					output("`2Near the counter is an old man sleeping`n");
					output("`2Will you `^Nudge him`2 or `^Let him sleep`n");
					addnav("Old Man");
					addnav("Nudge Him","runmodule.php?module=coins&op=shop&subop=nudge");
					addnav("Let him sleep","village.php");
					break;
				case "nudge":
					output("`2You gently nudge the old man`n");
					output("`2He suddenly wakes up and jumps to his feet`n");
					output("`2\"`^Hello! Welcome to Squib and Splots coin shop!`2\", he states.`n");
					output("`2\"`^I am Squib, How may I help?`2\", he asks kindly.`n");
					addnav("Ask him...");
					addnav("...about coins","runmodule.php?module=coins&op=shop&subop=about");
					addnav("...if he sells coins","runmodule.php?module=coins&op=shop&subop=buy");
					if(get_module_pref("tarnishedcoin") == 1){
						addnav("Try to...");
						addnav("...sell him some coins","runmodule.php?module=coins&op=shop&subop=sell");
					}
					addnav("Sneak out...");
					addnav("...the front door","village.php");
					addnav("...the back door","inn.php");
					break;
				case "about":
					output("`2He hands you a leaflet`n`n");
					output("`^Coins are rare items only found in the forest...`n");
					output("`^There are many different coins, alot are rare!`n");
					output("`^If you wish to be a coin hunter you must find a tarnished coin!`n");
					output("`^NEVER GIVE ANYBODY THIS!`n");
					output("`^If you do, you won't be clasified as a coin hunter anymore!");
					addnav("I?Return to the shop","runmodule.php?module=coins&op=shop&subop=main");
					break;
				case "main":
					output("`2The old man suddenly jumps back out of his chair`n");
					output("`2\"`^I am Squib, How may i help?`2\", he asks kindly.`n");
					addnav("Ask him...");
					addnav("...about coins","runmodule.php?module=coins&op=shop&subop=about");
					addnav("...if he sells coins","runmodule.php?module=coins&op=shop&subop=buy");
					if(get_module_pref("tarnishedcoin") == 1){
						addnav("Try to...");
						addnav("...sell him some coins","runmodule.php?module=coins&op=shop&subop=sell");
					}
					addnav("Sneak out...");
					addnav("...the front door","village.php");
					addnav("...the back door","inn.php");
					break;	
				case "buy":
					output("`2\"`^Do you sell coins?`2\", you ask.`n");
					output("`2\"`^Oh.. no! I purchase them for my own collection!`2\", he tells you.`n");			
					output("`2You stand there gazing into space...");
					addnav("I?Return to the shop","runmodule.php?module=coins&op=shop&subop=main");
					break;
				case "sell":
					output("You show the old man our coins and ask if he would like to buy any.`n");
					output("He jumps up in joy and says he will buy any you wish to sell!");
					addnav("Sell him...");
					$coins = array ("Bronze","Silver","Gold");
					foreach ($coins as $key=>$val){
						if(get_module_pref(strtolower($val)."coin") == 1){
							addnav(array("...the %s coin",$val),"runmodule.php?module=coins&op=shop&subop=sell2&coin=".$val);
						}
					}	
					addnav("Nothing","runmodule.php?module=coins&op=shop&subop=main");
					break;
				case "sell2":
					$coin = httpget('coin');
					$coins = array ("Bronze" => 10,"Silver" => 20,"Gold" => 200);
					$coinvalue = $coins[$coin];
					output("`2He says, \"`^I'll give you %s for it!`2\".`n",$coinvalue);
					output("`2He hands you the gold and you walk out of the shop.");
					$session['user']['gold'] += $coinvalue;
					set_module_pref(strtolower($coin)."coin",0);
					villagenav();
					break;
			}
			break;
	}
	page_footer();	
}
?>