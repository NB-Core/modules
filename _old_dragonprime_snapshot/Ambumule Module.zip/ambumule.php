<?php
/*****************************************/
/* AmbuMule                              */
/* ---------                             */
/* Version 1.3                           */
/* Written by Jake Taft (Zanzaras)       */
/* Idea submitted by Nemo on Zan's World */
/*****************************************/

/*********************************************/
/* Version History                           */
/* ---------------                           */
/* 1.0 - Original release. - Zanzaras        */
/* 1.1 - Fixed module so that a player won't */
/*       encounter themselves. - Zanzaras    */
/* 1.2 - Added a description field to the    */
/*       module. - Zanzaras                  */
/* 1.3 - Removed an output line used for     */
/*       debugging. - Zanzaras               */
/*********************************************/

/*********************************************************************************/
/* Setup instructions                                                            */
/* ------------------                                                            */
/* Copy this file to the "Module" directory inside the main lotgd directory then */
/* in the game go to the Manage modules in the Grotto and Install/activate it.   */
/*********************************************************************************/

function ambumule_getmoduleinfo()
         {$info = array("name"=>"Ambumule",
                        "version"=>"1.3",
                        "author"=>"Jake Taft (Zanzaras)",
                        "category"=>"Village Specials",
                        "description"=>"The players encounter the cart & mule that serves as the village ambulance.",
                        "download"=>"http://www.dragonprime.net/users/Zanzaras/AmbuMule%20Module.zip",
                        "settings"=>array("AmbuMule - Settings,title",
                                          "damage"=>"Amount of damage taken when the AmbuMule runs over a player,int|10",
                                          "heal"=>"Number of hitpoints healed by the AmbuMule,int|10",
                                          "rawchance"=>"Raw chance of seeing the AmbuMule,range,10,90,5|40"),
                        "prefs"=>array("AmbuMule - Preferences,title",
                                       "sighted"=>"Has the player encountered the AmbuMule today,bool|0"),
                       );
          return $info;
         }

function ambumule_install()
         {module_addeventhook("village", "require_once(\"modules/ambumule.php\"); return get_module_setting(\"rawchance\",\"ambumule\")");
          module_addhook("newday");
         }

function ambumule_uninstall(){return true;}

function ambumule_dohook($hookname,$args)
         {global $session;
          switch($hookname)
                {case "newday":
                      set_module_pref("sighted",0);
                      break;
                }
          return $args;
         }

function ambumule_runevent($type)
         {global $session;
          $from = "village.php?";
          $session['user']['specialinc'] = "module:ambumule";
          $op = httpget('op');
          $damage = get_module_setting("damage");
          $heal = get_module_setting("heal");
          $sighted = get_module_pref("sighted");

          //Feel free to change the names in the array below.
          //If you add/subtract names to the array then pay close attention to the comments on lines 76-80.
          $RPS = array("Ugarit","DeathScream","Goat","Wolff");
          $membernumber = e_rand(0, count($RPS)-1);

          //For every person you add/subtract to the array, you must add/subtract a new "case" statement below.
          //These "case" statements ensure that a player will not "see" himself. This check is for my server,
          //since I actually have these players on playing there. If you don't have players whose names match
          //the ones in the array then the "if" statement will never be true and you can ignore it or comment it out.
          //If you don't care if a player sees himself driving the Ambumule then comment out the following "if" statement.
          if ($RPS[$membernumber] == $session['user']['login'])
             {switch($membernumber)
                    {case 0: $membernumber = 1;break;
                     case 1: $membernumber = 2;break;
                     case 2: $membernumber = 3;break;
                     case 3: $membernumber = 0;break;
                    }
             }

          $person = $RPS[$membernumber];

          if ($sighted == 0)
             {output("`n`7Walking through the village, you suddenly hear a loud commotion. You turn to see a mule and cart coming straight at you at \"break-neck\" mule speed.");
              output("From the screaming of the caged screech owls on either side of the cart and the flashing oil lamps on each corner, you know this is the `\$a`&m`\$b`&u`\$m`&u`\$l`&e`7 rushing off to another emergency!`n");
              $rand = e_rand(1,3);
              switch($rand)
                    {case 1:
                          output("`nAs you stand there wondering who might be hurt, you fail to step out of the way of the \"speeding\" mule!");
                          output("The `\$a`&m`\$b`&u`\$m`&u`\$l`&e`7 plows right into you! You groan in pain and roll over just in time to see the back of the cart disappear around a corner.`n`n");
                          if ($damage > 1) output("`7You lost `4%s`7 hitpoints to the hit and run mule.`n`n",$damage);
                          if ($damage == 1) output("`7You lost `4%s`7 hitpoint to the hit and run mule.`n`n",$damage);
                          if ($damage < 1) output("`7Luckily, you're only bruised and didn't receive any real wounds from the collision. You stomp off hoping to find out who was driving that thing!`n`n");
                          $session['user']['hitpoints']-= $damage;
                          if ($session['user']['hitpoints'] < 1) $session['user']['hitpoints'] = 1;
                          addnews("%s `3was plowed into by the `\$a`&m`\$b`&u`\$m`&u`\$l`&e`3, luckily the mule wasn't hurt!",$session['user']['name']);
                          break;
                     case 2:
                          output("`nAs you stand there wondering who it is who might be hurt, you fail to step out of the way of the \"speeding\" mule!");
                          output("The `\$a`&m`\$b`&u`\$m`&u`\$l`&e`7 plows right into you!`n`n You groan in pain as the mule and cart come to a screeching halt.");
                          output("`#%s`7 jumps out the back of the cart and whips out his handy dandy first-aid kit and patches you up as best he can,",$person);
                          output("then jumps back into the cart as it takes off again toward the emergency.`n`n");
                          if ($session['user']['hitpoints'] < $session['user']['maxhitpoints'])
                             {output("You sit up and realize that not only did `#%s`7 patch up the wounds he caused, but also some of the other scrapes and gashes you had!`n`n",$person);
                              if ($heal > 1) output("`7You've been healed of `6%s`7 hitpoints of damage!`n`n",$heal);
                              if ($heal == 1) output("`7You've been healed of `6%s`7 hitpoint of damage!`n`n",$heal);
                              if ($heal < 1) output("`7You've been healed of `6%s`7 hitpoints worth of damage!`n`n",$heal);
                              $session['user']['hitpoints']+= $heal;
                              if ($session['user']['hitpoints'] > $session['user']['maxhitpoints']) $session['user']['hitpoints'] = $session['user']['maxhitpoints'];
                             }
                          if ($session['user']['hitpoints'] >= $session['user']['maxhitpoints'])
                             {output("You sit up and realize that not only did `#%s`7 patch up the wounds he caused, but the medicine he used made you `^hyper`7!`n",$person);
                              output("`n`^You've gained a turn!`n`n");
                              $session['user']['turns']++;
                             }
                          addnews("%s `3was plowed into by the `\$a`&m`\$b`&u`\$m`&u`\$l`&e`3, luckily the mule wasn't hurt!",$session['user']['name']);
                          break;
                     case 3:
                          output("`nAs you stand there wondering who it is who might be hurt, the `\$a`&m`\$b`&u`\$m`&u`\$l`&e`7 comes to a grinding halt and the entire `@<RPS>`7 clan hops out");
                          output("looks you over, takes your temperature and checks your blood pressure. After a few minutes of this `#%s`7 looks at you and says",$person);
                          output("\"`5Wha!? You're not dead! Bah!`7\"`n`n With that, they all jump back on the cart and go speeding off around the corner. You stand there for a moment trying to comprehend");
                          output("what just happened, then shake your head and go on about your business.`n`n");
                          break;
                    }
             }
            else
             {output("`n`7As your're walking through the square, you glance down Tavern Street and see the `\$a`&m`\$b`&u`\$m`&u`\$l`&e`7 parked in front of the inn. You wonder if `#%s`7 is inside getting plastered while on duty.`n",$person);
              output("`nYou shudder at the thought and continue on your way.`n`n");
             }
          set_module_pref("sighted",1);
         }

function ambumule_run(){}
?>
