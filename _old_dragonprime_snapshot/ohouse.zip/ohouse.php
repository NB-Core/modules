<?php
//BY: UnderDark
//V:  1.0
require_once "common.php";
page_header("Abandoned House");
output("`b`c`#The Abandoned House`b`c`#");
//output("`c<img src='img/house.jpg' alt='The Abandoned House'>`c",true);
output("`#As you enter the house, the wood floor beneath you creaks`#`n");
if($session[user][oldhouse] == 0)
		output("`#You may search the house, but you can only do it once per game day`#`n");
else
		output("`#You have already searched the house today`#`n");										
addnav("Return to Village","village.php");
if ($_GET["search"]=="true") {
	 $session[user][oldhouse] = 1;
	 $r = rand(1,15);
	 switch($r) {
	 case 1:
	 			output("`&You look around, but find nothing of interest`&");
		    break;
	 case 2:
	 			$npb = rand(1,10);
				$dmg = rand(0,20);
				$tot = $npb*$dmg;
				$session['user']['hitpoints'] -= $tot;
	 			output("`&You were attacked by $npb Pirahna Bats and suffered $tot Damgage`&");
	 			break;
	 case 3:
	 			$tmp = rand(1*$session[user][level],5*$session[user][level]);
	 			output("`&In the dark, you stumble into the wall dealing $tmp damage`&");
				$session[user][hitpoints]-=$tmp;
	 			break;
	 case 4:
	 			$npb = rand(1,10);
				$dmg = rand(0,20);
				$tot = $npb*$dmg;
				$session['user']['hitpoints'] -= $tot;
	 			output("`&You were attacked by $npb Pirahna Bats and suffered $tot Damgage`&");
	 			break;
	 case 5:
	 			$npb = rand(1,10);
				$dmg = rand(0,20);
				$tot = $npb*$dmg;
				$session['user']['hitpoints'] -= $tot;
	 			output("`&You were attacked by $npb Pirahna Bats and suffered $tot Damgage`&");
	 			break;
	 case 6:
	 			$tmp = rand(1*$session[user][level],5*$session[user][level]);
	 			output("`&In the dark, you stumble into the wall dealing $tmp damage`&");
				$session[user][hitpoints]-=$tmp;
	 			break;
	 case 7:
	 			output("`&You look around, but find nothing of interest`&");
	 			break;
	 case 8:
	 			$tmp = rand(1*$session[user][level],5*$session[user][level]);
	 			output("`&In the dark, you stumble into the wall dealing $tmp damage`&");
				$session[user][hitpoints]-=$tmp;
	 			break;
	 case 9:
	 			$tmp = 3*$session[user][level];
	 			output("`&`bYou have found Excalibur!, but in the exitment, you drop it, shattering it!`b`n doing so, you gain $tmp attack points`&");
				$session[user][attack]+=3*$session[user][level];
	 			break;
	 case 10:
	 			$tmp = rand(1*$session[user][level],5*$session[user][level]);
	 			output("`&In the dark, you stumble into the wall dealing $tmp damage`&");
				$session[user][hitpoints]-=$tmp;
	 			break;
	 case 11:
	  		output("`&You look around, but find nothing of interest`&");
	 			break;
	 case 12:
	 			$tmp = 3*$session[user][level];
	 			output("`&`bYou have found Excalibur!, but in the exitment, you drop it, shattering it!`b`n doing so, you gain $tmp attack points`&");
				$session[user][attack]+=3*$session[user][level];
	 			break;
	 case 13:
	 			$npb = rand(1,10);
				$dmg = rand(0,20);
				$tot = $npb*$dmg;
				$session['user']['hitpoints'] -= $tot;
	 			output("`&You were attacked by $npb Pirahna Bats and suffered $tot Damgage`&");
	 			break;
	 case 14:
	 			$npb = rand(1,10);
				$dmg = rand(0,20);
				$tot = $npb*$dmg;
				$session['user']['hitpoints'] -= $tot;
	 			output("`&You were attacked by $npb Pirahna Bats and suffered $tot Damgage`&");
	 			break;
	 case 15:
	 			output("`&`bYou have found Excalibur!`b`&");
				$session[user][weapon]="`3Excalibur!`3";
				$session[user][weapondmg] += 2*$session[user][level];
				$session[user][attack]+= 2*$session[user][level];
				$session[user][weaponvalue] += 1000;
				$session[user][weapon_upgrade]=0;
				$session[user][wepplus]="";
	 			break;
	 }
}
if ($session[user][hitpoints]>=0 && $session[user][oldhouse]==0)
	 addnav("Search the house","oldhouse.php?search=true");
page_footer();
?>