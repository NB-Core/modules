<?php
/**************
Name: The Job Center
Author: Eth - ethstavern(at)gmail(dot)com 
Version: 1.0
Rerelease Date: 02-01-2006
About: Rehash of GenMac's Questmaster module, with my own touches.
	   Player can get assigned a job to kill a monster or find an item
	   and return afterwards for a cash reward.  	
Translation ready!
*****************/
require_once("lib/villagenav.php");
function jobcenter_getmoduleinfo(){
	$info = array(
	"name"=>"Job Center",
	"version"=>"1.0",
	"author"=>"Eth",
	"category"=>"Village",
	"download"=>"http://dragonprime.net/users/Eth/jobcenter.zip",
	"vertxtloc"=>"http://dragonprime.net/users/Eth/",
	"settings"=>array(
		"Job Center Main Settings,title",
			"name"=>"Name of job center?|Ye Olde Job Center",
			"dkreq"=>"DK's required to access?,int|0",			
			"loc"=>"Where does the Job Center appear?,location|".getsetting("villagename", LOCATION_FIELDS),
		"Job Center Item Settings,title",
			"chance"=>"Chance of finding item in forest?,range,0,100,1|50",
		"Job Center Reward Settings,title",	
			"mingoldmon"=>"Minimum gold for monster job,int|50",
			"maxgoldmon"=>"Maximum gold for monster job,int|200",
			"mingolditem"=>"Minimum gold for item job,int|50",
			"maxgolditem"=>"Maximum gold for item job,int|100",
			"Formula used is e_rand(min - max)*user level,note",
		),
		"prefs"=>array(
		"Job Center User Preferences,title",
			"havequest"=>"Have a job?,bool|0",
			"questtype"=>"Type of job?,enum,0,None,1,Monster,2,Item",
			"questdone"=>"Finished job?,bool|0",
			"itemname"=>"Name of Item being sought?|",
			"monsterid"=>"ID of monster?,int|0",
			"monstername"=>"Name of monster?|",
			"monsterpart"=>"Part of monster?|",
			"monsterlevel"=>"Level of monster for job?,int|0",
			"goldreward"=>"Gold reward?,int|0",	
			"jobsdone"=>"Jobs done?,int|0",
		),
	);
	return $info;
}
function jobcenter_install(){	
	module_addeventhook("forest", "require_once(\"modules/jobcenter.php\"); return jobcenter_test();");
	module_addhook("newday");
	module_addhook("village");
	module_addhook("dragonkill");
	module_addhook("battle-defeat");
	module_addhook("battle-victory");
	module_addhook("changesetting");
	return true;
}

function jobcenter_uninstall(){
	return true;
}
function jobcenter_test(){
	global $session;	
	$chance = get_module_setting("chance","jobcenter");
	if (get_module_pref("havequest","jobcenter") == 1 && get_module_pref("questtype","jobcenter") == 2) return $chance; 
	return 0; 
}
function jobcenter_dohook($hookname,$args){
	global $session;
	switch($hookname){
		case "battle-defeat":
		$mobid = get_module_pref("monsterid");
		if(get_module_pref("havequest") && get_module_pref("questtype") == 1 && get_module_pref("questdone") == 0){
			if ($args['creatureid'] == $mobid){
				output("`^You have been slain by the creature you were hunting for!`n");
				output("`^Harold has been informed of this and has hired another person to complete the job.`n");
				set_module_pref("havequest",0);
			}
		}
		break;
		case "battle-victory":
		$mobid = get_module_pref("monsterid");
		if(get_module_pref("havequest") && get_module_pref("questtype") == 1 && get_module_pref("questdone") == 0){
			if ($args['creatureid'] == $mobid){
				output("`^You have completed your job!`n");
				output("`^With grim determination, you hack off `2%s's `3%s `^as proof.`n", $args['creaturename'],get_module_pref("monsterpart"));
				set_module_pref("questdone",1);
			}
		}
		break;		
		case "changesetting":
		if ($args['setting'] == "villagename") {
			if ($args['old'] == get_module_setting("loc")) {
				set_module_setting("loc", $args['new']);
			}
		}
		break;
		case "dragonkill":
		if (get_module_pref("havequest")){
			output("`@You've forgetten all about the current job you were on for Harold at `2%s`@.`n`n", get_module_setting("name"));
		}
		break;
		case "newday":				
		if (get_module_pref("havequest")){
			output("`n`2`bA dispatch arrives from Harold at `@%s `2saying his client is no longer interested in your services.`n`b", get_module_setting("name"));
			set_module_pref("havequest",0);
		}
		break;
		case "village":
		$name = get_module_setting("name");
		if ($session['user']['location'] == get_module_setting("loc") && $session['user']['dragonkills']>=get_module_setting("dkreq")) {
			tlschema($args['schemas']['fightnav']);
			addnav($args['fightnav']);
			tlschema();
			addnav("$name","runmodule.php?module=jobcenter&op=enter&what=main");
		}
		break;
	}
	return $args;
}
function jobcenter_runevent($type){
	global $session;
	$from = "forest.php";
	$session['user']['specialinc'] = "";
	$op = httpget('op');
	switch ($type) {
		case forest:
		if ($op=="" || $op=="search"){	
			output_notl("`n");
			switch(e_rand(1,3)){
				case 1:		
				output("`2While venturing through the forest, you stumble into a pleasant little glen.");
				output(" `2Looking down at the grass, you happen to find the `@%s `2Harold's client wanted!`n`n", get_module_pref("itemname"));
				output("`3Well, that certainly was easy, you think.`n`n");
				break;
				case 2:
				output("`2Following a meandering little path through the woods, you glance down at the ground and spot the `@%s`2 you had been searching for!`n`n", get_module_pref("itemname"));
				output("`3Time to return to Harold and collect your payment.");
				break;
				case 3:
				output("`2While hunting for prey, you suddenly hear someone shouting out your name from behind you.");
				output(" `2Turning around, you spot an exhausted young man running towards you with something in his hand.`n`n");
				output("`3\"%s!`3\", `6he says, holding up the `@%s`2. `3\"I think you dropped this!\"`n`n", $session['user']['name'],get_module_pref("itemname"));
				output("`2You didn't drop it, but who are you to complain? Time to go and collect your payment!`n`n");				
				break;
			}
			set_module_pref("questdone",1);
			addnav("Back to Forest","forest.php");
		}
		break;
	}
}
function jobcenter_run(){
	global $session;
	$op = httpget('op');
	$from = "runmodule.php?module=jobcenter&";
	$name = get_module_setting("name");
	page_header("$name");	
	if ($op == "enter"){
		switch (httpget('what')){
			case "main":
			//has no job yet
			if (!get_module_pref("havequest")){
			output("`2Ducking into a small, plain building just near `#Bluespring's`2, you are greeted by a short, balding man sitting behind a desk.`n`n");
			output("`@\"Hello!\" `2he greets you. `@\"I'm Harold. Can I interest you in some work today?\"`n`n");
			modulehook("jobcenter", array()); 
			addnav("Jobs");
			addnav("Slay a Monster",$from."op=enter&what=jobmonster");
			addnav("Find an Item",$from."op=enter&what=jobitem");
			//has a job, but hasn't finished
			}else if (get_module_pref("havequest") && !get_module_pref("questdone")){				
				output("`2Harold looks up from his paperwork.`n`n");
				output("`@\"Still completing the job I assigned you, huh?\"`n`n");
				if (get_module_pref("questtype") == 1){	
					output("`2You're currently seeking the `3%s `2of a `^%s`2.`n`n", get_module_pref("monsterpart"),get_module_pref("monstername"));			
				}else if (get_module_pref("questtype") == 2){
					output("`2You're currently seeking a `^%s.`n`n", get_module_pref("itemname"));
				}
				addnav("Options");
				addnav("Quit Job",$from."op=enter&what=quit");
			//has job, and has finished
			}else{
				//Yeah, I know, this is cheap...
				redirect("runmodule.php?module=jobcenter&op=enter&what=jobdone");			
			}
			addnav("Other");
			addnav("Top Employees",$from."op=enter&what=topten");
			villagenav();
			break;
			case "topten":
			output("`2On the wall near the door is a plaque listing the top ten employees.`n`n");
			$sql = "SELECT userid,name,value FROM " . db_prefix('module_userprefs') . " LEFT JOIN " . db_prefix('accounts') . " ON (acctid = userid) WHERE modulename='jobcenter' AND setting='jobsdone' and value > 0 ORDER BY value + 0 DESC,name LIMIT 10";                
        	$result = db_query($sql);
        	$count = db_num_rows($result);
        	$rank = translate_inline("Rank");
        	$name = translate_inline("Player Name");
        	$jobs = translate_inline("Jobs Done");
        	if ($count == 0){
				output("`@No employees are listed yet!`n`n");				
			}else{
				rawoutput("<table cellspacing=0 cellpadding=2 width='500' align='center'><tr><td><b>$rank</b></td><td><b>$name</b></td><td><b>$jobs</b></td></tr>");    
	        	for ($i=0;$i<db_num_rows($result);$i++){
		        	$row = db_fetch_assoc($result);  
		        	output("<tr class='".($i%2?"trlight":"trdark")."'>",true);        
		        	output("<td>%s</td>",$i+1,true); 
		        	output("<td>%s</td>",$row['name'],true);        	
		        	output("<td>%s</td>",get_module_pref("jobsdone","jobcenter",$row['userid']),true); 
		        	rawoutput("</tr>");
				}
	        rawoutput("</table>"); 
			}
			addnav("Options");
			addnav("Go Back",$from."op=enter&what=main");
			break;
			case "jobitem":
			$items = array(
						0=>"chunk of fool's gold",
						1=>"stick of dynamite",
						2=>"pair of sunglasses",
						3=>"beer stein",
						4=>"shiny new pen",
						5=>"lock of golden hair",
						6=>"bottle of cough syrup",
						7=>"issue of Newsweek",
						8=>"cow skull",
						9=>"mummified gerbil",
						10=>"cat skull",
						11=>"eagle feather",
						12=>"empty pop can"
			);
			$item = translate_inline($items[e_rand(0, count($items)-1)]);
			$reward = round(e_rand(get_module_setting("mingolditem"),get_module_setting("maxgolditem"))*$session['user']['level']);
			output("`@\"This one should be easy,\" `2Harold says, scanning down a list in front of him.`n`n");
			output("`@\"I have a client who's searching for a `3%s`@. The pay for this job is `^%s gold`@.\"`n`n", $item,$reward);
			output("`2Assignment in hand, you decide it'd be best to get a start on it right away.`n`n");
			output("`3Harold suggests searching around in the forest might yield results.`n`n");
			set_module_pref("havequest",1);
			set_module_pref("questtype",2);
			set_module_pref("itemname",$item);
			set_module_pref("goldreward",$reward);
			addnav("Options");
			//addnav("Different Item",$from."op=enter&what=jobitem");
			villagenav();
			break;
			case "jobmonster":
			$parts = array(0=>"head",1=>"foot",2=>"hand",3=>"nose",4=>"scalp",5=>"toe",6=>"ear",7=>"leg");
			$part = translate_inline($parts[e_rand(0, count($parts)-1)]);
			$reward = round(e_rand(get_module_setting("mingoldmon"),get_module_setting("maxgoldmon"))*$session['user']['level']);
			if (e_rand(0,2)==1){
				$plev = (e_rand(1,5)==1?1:0);
				$nlev = (e_rand(1,3)==1?1:0);
			}else{
				$plev=0;
				$nlev=0;
			}
			$targetlevel = ($session['user']['level'] + $plev - $nlev );
			$sql = "SELECT * FROM " . db_prefix("creatures") . " WHERE creaturelevel = $targetlevel AND forest=1 ORDER BY rand(".e_rand().") LIMIT 1";
			$result = db_query($sql);
			$row = db_fetch_assoc($result);		
			if (e_rand(0,1) == 0) $who = "He's";
			else $who = "She's";	
			output("`@\"Excellent!\" `2Harold proclaims. `@\"Now, I have just the job for you right here.\"`n`n");
			output("`2He scans over a piece of paper on his table, then looks back up to you.`n`n");
			output("`@\"Right then, a client of mine wishes to procure the `2%s `@of a `3%s`@. %s willing to pay `^%s gold `@if accomplished.\"`n`n",$part,$row['creaturename'],$who,$reward);
			output("`2Assignment in hand, you decide it'd be best to get a start on it right away.`n`n");
			output("`3The target level of this creature is `^%s`3.`n`n", $targetlevel);
			set_module_pref("havequest",1);
			set_module_pref("questtype",1);
			set_module_pref("monsterid",$row['creatureid']);
			set_module_pref("monsterpart",$part);
			set_module_pref("monstername",$row['creaturename']);
			set_module_pref("goldreward",$reward);
			set_module_pref("monsterlevel",$targetlevel);
			//addnav("Jobs");
			//addnav("Different Monster",$from."op=enter&what=jobmonster");
			addnav("Options");
			villagenav();
			break;
			case "jobdone":
			output("`@\"Excellent work, %s`@! My client will be most pleased.\"`n`n", $session['user']['name']);
			output("`2He hands you your payment of `^%s gold `2and thanks you for a job well done.`n`n",get_module_pref("goldreward"));
			$session['user']['gold']+=get_module_pref("goldreward");
			set_module_pref("havequest",0);
			set_module_pref("questdone",0);
			set_module_pref("jobsdone",get_module_pref("jobsdone")+1);
			addnav("Options");
			villagenav();
			break;
			case "quit":
			output("`@\"Oh. You wish to abandon this job?\" `2asks the balding Harold. `@\"Alright. Consider it done.\"`n`n");
			set_module_pref("havequest",0);
			set_module_pref("questtype",0);	
			addnav("Options");		
			villagenav();
			break;
		}	
	}
	page_footer();
}
?>