<?php
/* 
   Small Girl 
   Author - Robert of Maddnet
   Forest Event for LotGD 097
   Install - Just drop into your specials folder
*/
if (!isset($session)) exit(); 
if ($HTTP_GET_VARS[op]==""){ 
    output("`n`n`2You come upon a young girl in the forest.  \"`^I'm lost can you show me the way back to `3the Village?`2\" she asks.  `n`n`&What will you do?"); 
    addnav("the small girl"); 
    addnav("(W) Walk her","forest.php?op=walk"); 
    addnav("(L) Leave her there","forest.php?op=dont"); 
    $session['user']['specialinc']="smallgirl.php"; 
}else if ($HTTP_GET_VARS[op]=="walk"){ 
  if ($session['user']['gems']>=3){ 
      output("`n`n`2You walk the small girl to the `3Village`2.`n`n "); 
      output("The child is grateful to be back home again and hands you a small shiny rock she said she found in the forest. `n`n "); 
      output("Looking at the rock you discover that ...`^");
      $session['user']['turns']--;
        switch(e_rand(1,10)){ 
          case 1: 
             output("the shiny rock is a Gem! `n`n`2You thank her for her kindness and return to the forest."); 
             $session['user']['gems']+=1; 
             debuglog("got `^1 gem `0from a small girl");
             break;
          case 2: case 3: case 4: case 5: case 6: case 7: case 8: case 9:
             output("the rock is shiny indeed but there is nothing else special about it. `n`n`2 You thank her for her kindness and return to the forest."); 
             break; 
          case 10:
             output("the rock is shiny indeed and as you hold it, a warm feeling goes through your body. `n`n`2 You thank her for her kindness and return to the forest.");  
             $session['user']['charm']++; 
             $session['user']['hitpoints']++;
             break; 
        } 
    }else{ 
      output("`n`n`2You walk the small girl to the `3Village`2.`n`n "); 
      output("The girl is grateful to be back home again and hands you a small shiny rock she said she found in the forest.  "); 
      output("Looking at the rock you discover that the shiny rock is a Gem!`n`n`2You thank her for her kindness and return to the forest."); 
      $session['user']['turns']--; 
      $session['user']['gems']++; 
    } 
}else{ 
  output("`n`n`2Not wanting to take the time to help a small child, you leave her there and continue on your way. ");
  output("`n`nAs you walk away you're hit in the head with a small rock from behind. You turn and give chase after the little girl but she is too quick and evades your pursuit. ");
  $session['user']['charm']--;
  if ($session['user']['hitpoints']>=6){
	  output("`n`nYou find that little rock hurt a lot more than you think! ");
  	  $session['user']['hitpoints']-=5;
	  }
}
?>