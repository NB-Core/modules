<?
/*
* Birthday v1.0
* by Excalibur (http://www.ogsi.it)
* excalthesword@fastwebnet.it
* English version by:
This are instructions to modify other scripts and DB:
-----------------------------------------------------
execute this in your PHPMyAdmin
ALTER TABLE `accounts` ADD `compleanno` DATE  DEFAULT '0000-00-00' NOT NULL ;
-----------------------------------------------------
OPEN village.php:
Insert where you want this code:

//Excalibur: modification to show players' birthday
$dataodierna = date("m-d");
//$sql = "SELECT name, substring(compleanno,1,4) AS year, substring(compleanno,6,2) AS month, substring(compleanno,9,2) AS day FROM accounts WHERE substring(compleanno,6) = '$dataodierna' ORDER BY name";
$sql = "SELECT name, substring(compleanno,1,4) AS year FROM accounts WHERE substring(compleanno,6) = '$dataodierna' ORDER BY name";
db_query($sql);
$result = db_query($sql);
if (db_num_rows($result) > 0){
   output("`n");
   for ($i=0;$i<db_num_rows($result);$i++){
      $row = db_fetch_assoc($result);
      $anni = date("Y") - $row['year'];
      output("<big>`^`c`#Today is the birthday of ".$row['name']."`# !! He's `^`b$anni`b`# years old!`0`n`c</big>",true);
   }
}
//Excalibur: end birthday

close and save
----------------------------------------------------
Open newday.php
find:
output("`2Your turns for today are `^ ".$turnsperday." `n");
add after:
                //Excalibur: modification to show players' birthday
                $dataodierna = date("m-d");
                $datacompleanno = substr($session['user']['compleanno'], 5, 5);
                $laston = substr($session['user']['lasthit'], 5, 5);
                if ($dataodierna == $datacompleanno AND $laston != $dataodierna){
                $quanti = date("Y") - substr($session['user']['compleanno'], 0, 4);
                output("<big>`c`n`(`bToday is your Birthday !! We must celebrate !!`n`b</big>",true);
                output("<big>`(LotGD Admin have decided to give you a little gift: `&10 Gems`( and `^10.000 gold pieces`(`n</big>",true);
                output("<big>`(Use them wise and Happy Birthday for your $quanti� birthday !!!`n`n`n`c</big>",true);
                $session['user']['gems'] += 10;
                $session['user']['gold'] += 10000;
                }
                //Excalibur:end birthday's prizes
close and save
------------------------------------------------------
That's all, have fun :-)

*/
require_once "common.php";
$month = array(
1=>"Jenuary",
2=>"February",
3=>"March",
4=>"April",
5=>"May",
6=>"June",
7=>"July",
8=>"August",
9=>"September",
10=>"October",
11=>"November",
12=>"December");
page_header("Birthdate Insertion");
output("`b`c`&Birthdate Insertion`c`b`n`n");
if ($HTTP_GET_VARS['op'] == "") {
   output("`@Welcome to the script with which you'll tell us your birthdate, so other players of the village ");
   output("will be aware of your birthday, and wish you a Happy Birthday !!`n`n");
   output("You can also decide to not communicate it, and in this case will skip the procedure of typying it" );
   output("and you'll go back to village square.`n");
   output("But don't esitate, go on and tell us your birthdate, or go back to village square.`n");
   addnav("Type Year","compleanno.php?op=year");
   addnav("Back to Village","compleanno.php?op=bypass");
}
if ($HTTP_GET_VARS['op'] == "year"){
   output("`@Type in the year of birth`n");
   output("<form action='compleanno.php?op=yearbis' method='POST'><input name='year' value='0'><input type='submit' class='button' value='Write Year of Birth'>`n",true);
   addnav("","compleanno.php?op=yearbis");
}elseif ($HTTP_GET_VARS['op'] == "yearbis"){
   $year = intval($HTTP_POST_VARS['year']);
   if (($year + 8) > date('Y') OR $year < 1920) {
       output("`%Don't joke !! How could you play LotGD being born in $year ?`n`n");
       addnav("Type year again","compleanno.php?op=year");
   } else {
       output("`@Well, you're born in `&$year`@, go on and type the month.`n`n");
       $session['year']=$year;
       addnav("Insert Month","compleanno.php?op=month");
   }
}
if ($HTTP_GET_VARS['op'] == "month"){
   if ($HTTP_POST_VARS['month'] == "") {
      output("<form action='compleanno.php?op=month' method='POST'><input type='submit' class='button' value='Chose Month'>`n`n",true);
      output("`2Seleziona il tuo mese di nascita`n");
      output("<input type='radio' name='month' value='1'> `@Jenuary&nbsp&nbsp&nbsp",true);
      output("<input type='radio' name='month' value='2'> February`n",true);
      output("<input type='radio' name='month' value='3'> March&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp",true);
      output("<input type='radio' name='month' value='4'> April&nbsp`n",true);
      output("<input type='radio' name='month' value='5'> May&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp",true);
      output("<input type='radio' name='month' value='6'> June&nbsp&nbsp`n",true);
      output("<input type='radio' name='month' value='7'> July&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp",true);
      output("<input type='radio' name='month' value='8'> August`n",true);
      output("<input type='radio' name='month' value='9'> September",true);
      output("<input type='radio' name='month' value='10'> October`n",true);
      output("<input type='radio' name='month' value='11'> November",true);
      output("<input type='radio' name='month' value='12'> December`n",true);
      addnav("","compleanno.php?op=month");
   }else{
      output("`@Nice, you're born in the month of `&".$month[$HTTP_POST_VARS['month']].".`@`n");
      output("Go on and chose the day of birth.`n");
      $session['month'] = $HTTP_POST_VARS['month'];
      addnav("Insert Day","compleanno.php?op=day");
   }
}
if ($HTTP_GET_VARS['op'] == "day"){
   if ($HTTP_POST_VARS['day'] == "") {
      output("<form action='compleanno.php?op=day' method='POST'><input type='submit' class='button' value='Chose Day'>`n`n",true);
      output("`2Seleziona il tuo giorno di nascita`n");
      output("<input type='radio' name='day' value='1'> `@1&nbsp&nbsp",true);
      output("<input type='radio' name='day' value='2'> 2&nbsp&nbsp",true);
      output("<input type='radio' name='day' value='3'> 3&nbsp&nbsp",true);
      output("<input type='radio' name='day' value='4'> 4`n",true);
      output("<input type='radio' name='day' value='5'> 5&nbsp&nbsp",true);
      output("<input type='radio' name='day' value='6'> 6&nbsp&nbsp",true);
      output("<input type='radio' name='day' value='7'> 7&nbsp&nbsp",true);
      output("<input type='radio' name='day' value='8'> 8`n",true);
      output("<input type='radio' name='day' value='9'> 9&nbsp&nbsp",true);
      output("<input type='radio' name='day' value='10'> 10",true);
      output("<input type='radio' name='day' value='11'> 11",true);
      output("<input type='radio' name='day' value='12'> 12`n",true);
      output("<input type='radio' name='day' value='13'> 13",true);
      output("<input type='radio' name='day' value='14'> 14",true);
      output("<input type='radio' name='day' value='15'> 15",true);
      output("<input type='radio' name='day' value='16'> 16`n",true);
      output("<input type='radio' name='day' value='17'> 17",true);
      output("<input type='radio' name='day' value='18'> 18",true);
      output("<input type='radio' name='day' value='19'> 19",true);
      output("<input type='radio' name='day' value='20'> 20`n",true);
      output("<input type='radio' name='day' value='21'> 21",true);
      output("<input type='radio' name='day' value='22'> 22",true);
      output("<input type='radio' name='day' value='23'> 23",true);
      output("<input type='radio' name='day' value='24'> 24`n",true);
      output("<input type='radio' name='day' value='25'> 25",true);
      output("<input type='radio' name='day' value='26'> 26",true);
      output("<input type='radio' name='day' value='27'> 27",true);
      output("<input type='radio' name='day' value='28'> 28`n",true);
      if ($session['month'] != 2 OR ($session['year']%4) == 0) {
         output("<input type='radio' name='day' value='29'> 29",true);
      }
      if ($session['month'] != 2) {
         output("<input type='radio' name='day' value='30'> 30",true);
      }
      if ($session['month'] != 2 AND $session['month'] != 4 AND $session['month'] != 6 AND $session['month'] != 9 AND $session['month'] != 11) {
         output("<input type='radio' name='day' value='31'> 31`n",true);
      }
      addnav("","compleanno.php?op=day");
   }else{
      output("`@Ok, you're born the day `&".$HTTP_POST_VARS['day']."`@`n");
      output("Ok, let's see you're complete birthydate.`n");
      $session['day'] = $HTTP_POST_VARS['day'];
      addnav("Riepilogo","compleanno.php?op=final");
   }
}
if ($HTTP_GET_VARS['op'] == "final"){
   output("`@This is your Birthday: `&".$session['day']." ".$month[$session['month']]." ".$session['year']);
   output("`n`@Do you confirm this date or do you want to modify it?");
   addnav("Modify it","compleanno.php?op=year");
   addnav("Confirm it","compleanno.php?op=ok");
}
if ($HTTP_GET_VARS['op'] == "ok"){
   $date = $session['year']."-".$session['month']."-".$session['day'];
   $session['user']['compleanno'] = $date;
   output("`^Birthday stored. When it will be your birthday a notice will appear in the village !");
   addnav("Back to Village","village.php");
}
if ($HTTP_GET_VARS['op'] == "bypass"){
   output("`(Are you sure you don't want to let us know your birthdate?`n");
   output("If you're 100% sure, chose `\$Back to Village`(, if you've changed your mind and you want to share ");
   output("your birthday with all players, chose `@Insert Birthdate`(.`n");
   addnav("`\$Back to Village","compleanno.php?op=bypassok");
   addnav("`@Insert Birthdate","compleanno.php");
}
if ($HTTP_GET_VARS['op'] == "bypassok"){
   output("`%Well, you've made your choice. The other villagers will never know your Birthday `n");
   output("and they can't compliment you when you'll make birthday.");
   $session['user']['compleanno'] = "2050-00-00";
   addnav("Back to Village","village.php");
}
page_footer();
?>