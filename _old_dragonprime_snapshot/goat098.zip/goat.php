<?php
/*
* Date:     April 17, 2005
* Author:   Robert of MaddRio dot com
* v 1.1     optimized code
*/
function goat_getmoduleinfo(){
	$info = array(
	"name"=>"Forest Goat",
	"version"=>"1.1",
	"author"=>"`2Robert",
	"category"=>"Forest Specials",
	"download"=>"http://dragonprime.net/users/Robert/goat098.zip",
	);
	return $info;
}

function goat_install(){
	module_addeventhook("forest","return 100;");
	return true;
}

function goat_uninstall(){
	return true;
}

function goat_dohook($hookname,$args){
	return $args;
}

function goat_runevent($type){
global $session;
output("`n`n`2 You stumble upon a small house in the Forest.`n");
output(" Searching through the abandoned house you find nothing of value.`n");
output(" You decide to take a nap on the bed that looks comfortable.`n");
output(" Upon awakening you find a Goat nibbling on your shoes.`n");
output(" You arise and leave the annoying Goat behind,`n");
output(". . . . `b`i the Goat follows you into the Forest! `i`b");
$goat = array(
	"name"=>"`2Forest Goat",
	"rounds"=>40,
	"defmod"=>1.0,
	"atkmod"=>1.0,
	"wearoff"=> "The goat tires of you and wanders off into the forest.",
	"roundmsg"=>"The Goat eats shrubbery while you fight.",
	"schema"=>"module-goat",
	);
apply_buff('goat',$goat);
}

function goat_run(){
}
?>