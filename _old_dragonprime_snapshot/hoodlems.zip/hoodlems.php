<?php
/* hoodlems - 2 august 2005
   Author: Fliquid
   converted from Rabbit Hole - 17 April 2005 by Robert of Maddrio dot com
*/

function hoodlems_getmoduleinfo(){
	$info = array(
	"name"=>"Hoodlems",
	"version"=>"1.0",
	"author"=>"Fliquid",
	"category"=>"Forest Specials",
	"download"=>"http://dragonprime.net/users/fliquid/hoodlems.txt",
	"settings"=>array(
	"hoodlems Settings,title",
	"percentage"=>"Chance player gains or loses 1 turn,range,10,100,2|50"
	),
	);
	return $info;
}

function hoodlems_install(){
	module_addeventhook("forest","return 100;");
	return true;
}

function hoodlems_uninstall(){
	return true;
}

function hoodlems_dohook($hookname,$args){
	return $args;
}

function hoodlems_runevent($type){
	global $session;
	$chance = get_module_setting("percentage");
	$rand = e_rand(1,100);
	if ($rand <= $chance) {
	output("`n`2 Suddenly hoodlems drop down from all the trees around you! `n");
	output(" They all kick and hit you from everywhere. `n");
	output(" That's the price you have to pay for not paying for your drugs. `n");
	if ($session['user']['turns'] >=1 ) {
		output("`2 You lost time for `^1 `2 forest fight! ");
		$session['user']['turns']--;
		}
	}else{
	output("`n`2 As you wander in the forest you spot some hoodlems in a tree! `n");
	output(" You avoid the encounter and walk a differend route. `n");
	output(" The stream flowing down from the hills gives you a soothing feeling. `n");
	output(" The walk is very refreshing! `n`n You gain `^1 `2 forest fight! ");
	$session['user']['turns']++;
	}
}

function hoodlems_run(){
}
?>