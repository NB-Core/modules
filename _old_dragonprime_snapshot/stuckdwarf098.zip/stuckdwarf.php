<?php
/**
* Version: 1.0 - Converted from 097
* Date:   April 16, 2005
* Author: Robert of MaddRio dot com
*/
function stuckdwarf_getmoduleinfo(){
        $info = array(
        "name"=>"Stuck Dwarf",
        "version"=>"1.0",
        "author"=>"`2Robert",
        "download"=>"http://dragonprime.net/users/Robert/stuckdwarf098.zip",
        "category"=>"Forest Specials",
        "settings"=>array(
		"Stuck Dwarf Settings,title",
		"mingold"=>"Minimum gold to steal,range,5,55,5|25",
		"maxgold"=>"Maximum gold to steal,range,60,200,10|50"
		),
        );
        return $info;
}

function stuckdwarf_install(){
        module_addeventhook("forest", "return 100;");
        return true;
}

function stuckdwarf_uninstall(){
        return true;
}

function stuckdwarf_dohook($hookname,$args){
        return $args;
}

function stuckdwarf_runevent($type){
global $session;
$min = get_module_setting("mingold");
$max = get_module_setting("maxgold");
output(" `^LUCKY YOU! `n");
output(" `2Finding a Dwarf hanging upside down from a tree.`n`n");
output(" Seems he got his foot caught in someone's animal snare! `n`n");
output(" You shake the Dwarf until `^his Gold `2falls out to the ground.`n`n");
switch(e_rand(1,5)){
	case 1:
	$gold = e_rand($min, $max);
	output(" You count %s `2, Thank the Dwarf and leave him there!",$gold);
	$session['user']['gold']+=$gold;
	debuglog(" gained $gold gold from a stuck dwarf ");
	break;
	case 2: case 3: case 4:
	$gold = $min;
	output(" You count %s `2, and say to him, a pauper you are? ...too bad!",$gold);
	$session['user']['gold']+=$gold;
	debuglog(" gained $gold gold from a stuck dwarf ");
	break;
	case 5:
	$gold = $max;
	output(" You count %s `2, and say to him, Ahh... thank you `bvery much`b my little friend!",$gold);
	$session['user']['gold']+=$gold;
	debuglog(" gained $gold gold from a stuck dwarf ");
	break;
}
}
function stuckdwarf_run(){
}
?>