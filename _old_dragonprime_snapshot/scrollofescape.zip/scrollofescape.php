<?php
// translator ready
// mail ready
// addnews ready
function scrollofescape_getmoduleinfo(){
	$info = array(
		"name"=>"Scroll Of Escape",
		"version"=>"1.1",
		"author"=>"Peter Corcoran",
		"category"=>"Lodge",
		"download"=>"http://dragonprime.net/users/R4000/scrollofescape.txt",
		"settings"=>array(
			"Scroll of escape Settings,title",
			"This module hooks onto the JCP hunter lodge.,note",
			"In version 2 an option for a shop in village should be added!,note",
			"price"=>"Price? (Lodge Points),int|100",
			),
		"prefs"=>array(
			"scrolls","Amount of escape scrolls a user has,int|0",
			),
	);
	return $info;
}

function scrollofescape_install(){
	module_addhook("fightnav-specialties");
	module_addhook("lodge");
	module_addhook("pointsdesc");
	module_addeventhook("village", "return 0;");
	return true;
}

function scrollofescape_uninstall(){
	return true;
}

function scrollofescape_dohook($hookname,$args){
		$price = get_module_setting("price");
	switch($hookname){
		case "lodge":
			addnav("Use Points");
			$donationsleft = ($session['user']['donation'] - $session['user']['donationspent']);
			addnav("Scroll of Escape - `#(".$price." Points each)","runmodule.php?module=scrollofescape&op=buyscroll");
			break;
		case "pointsdesc":
			$args['count']++;
			$format = $args['format'];
			$str = translate("Purchase a scroll of escape.");
			output($format, $str, true);
			break;
		case "fightnav-specialties":
			if(get_module_pref("scrolls") >= 1){
				addnav("`2Scrolls`0","");
				addnav(array("`2 &#149; Scroll of Escape (%s Left)`0",get_module_pref("scrolls")),"village.php?eventhandler=module-scrollofescape",true);
			}
	}
	return $args;
}
function scrollofescape_runevent(){
			set_module_pref("scrolls", get_module_pref("scrolls")-1);
			output("`2You recite the scroll and return to the village.`n`n`^Your peers are around you laughing.`n`^You lose a charm point.");
			$session['user']['charm']-=1;
			if(e_rand(1,100) == e_rand(1,100)){
				output("`n`n`1One of them runs up and kicks you in the crouch.`n`^You lose 10 hitpoints.");
				$session['user']['hitpoints']-=10;
			}
			$session['user']['specialinc'] = "";
}
function scrollofescape_run(){
	$op = httpget('op');
	page_header("Scroll of Escape");
	switch ($op){
		case "buyscroll":
			set_module_pref("scrolls", get_module_pref("scrolls")+1);
			$session['user']['donationspent']+=get_module_setting("price");
			output("`)You hand JCP your membership card and he swipes it, taking %s points off it.`n`n`^JCP hands you a 'Scroll of Escape'.`n`n`)JCP says, \"`2Use it wisely... and remember, Everything has its drawbacks!\"",get_module_setting("price"));
			addnav("Return to the Lodge","lodge.php");
			break;
	}
	page_footer();
}
?>