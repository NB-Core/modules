<?php
/* Dragon Tracks - 17April2005
   Author: Robert of Maddrio dot com
   converted from an 097 forest event
*/
function dragontracks_getmoduleinfo(){
	$info = array(
	"name"=>"Dragon Tracks ",
	"version"=>"1.0",
	"author"=>"`2Robert",
	"category"=>"Forest Specials",
	"download"=>"http://dragonprime.net/users/robert/dragontracks098.zip",
	);
	return $info;
}

function dragontracks_install(){
	module_addeventhook("forest","return 100;");
	return true;
}

function dragontracks_uninstall(){
	return true;
}

function dragontracks_dohook($hookname,$args){
	return $args;
}

function dragontracks_runevent($type){
	global $session;
	$chance = 60;
	$rand = e_rand(1,100);
	if ($rand <= $chance) {
	output("`n`n`2 You stumble into a dark part of the forest. `n`n");
	output(" You quickly notice upon the ground, `ifresh dragon tracks`i! `n`n");
	output(" Following the tracks with hopes of finding the `@Green Dragon`2, your effort fails. `n`n");
	if ($session['user']['turns'] >=1 ) {
		output("`2 You lost time for `^1 `2forest fight! ");
		$session['user']['turns']--;
		}
	}else{
	output("`n`n`2 You stumble into a dark part of the forest. `n`n");
	output(" You quickly notice upon the ground, `ifresh dragon tracks`i! `n`n");
	output(" Following the tracks with hopes of finding the `@Green Dragon`2, your effort fails. `n`n");
	output(" Better luck next time! ");
	}
}

function dragontracks_run(){
}
?>