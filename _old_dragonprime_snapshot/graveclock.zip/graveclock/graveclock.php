<?php
/*
Version 1.0:
 * Seems to be stable
*/

function graveclock_getmoduleinfo(){
	$info = array(
		"name"=>"The Graveyard Clock",
		"version"=>"1.0",
		"author"=>"`@CortalUX",
		"category"=>"Graveyard",
		"vertxtloc"=>"http://dragonprime.net/users/CortalUX/",
		"download"=>"http://dragonprime.net/users/cortalux/graveclock.zip",
		"settings"=>array(
			"The Graveyard Clock,title",
			"newDay"=>"Show the time till new day?,bool|1",
			"Clock Strings,title",
			"newDayStr"=>"New day str?,|`@A sinister demon hangs upon the door, chanting that the new day and freedom is in `$%s",
			"(type %s where you wish the time to appear),note",
		),
		"prefs"=>array(
			"The Graveyard Clock,title",
			"user_showTime"=>"Do you want to see the time till next new day- when you are in the Graveyard?,bool|1",
		),
	);
	return $info;
}

function graveclock_install(){
	module_addhook("graveyard-desc");
	return true;
}

function graveclock_uninstall(){
	return true;
}

function graveclock_dohook($hookname,$args){
	switch($hookname){
		case "graveyard-desc":
			if (get_module_pref("showTime")==1) {
				output("".get_module_setting("newDayStr")."`0`n", date("G\\h, i\\m, s\\s \\(\\r\\e\\a\\l\\ \\t\\i\\m\\e\\)",secondstonextgameday()));
			}
		break;
	}
	return $args;
}
?>
