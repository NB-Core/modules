<?php

function charclean_getmoduleinfo(){
	$info = array(
		"name"=>"Character Cleanup",
		"author"=>"Chris Vorndran",
		"version"=>"1.0",
		"category"=>"Administrative",
		"download"=>"http://dragonprime.net/index.php?module=Downloads;sa=dlview;id=140",
	);
	return $info;
}
function charclean_install(){
	module_addhook("superuser");
	return true;
}
function charclean_uninstall(){
	return true;
}
function charclean_dohook($hookname,$args){
	global $session;
	switch ($hookname){
		case "superuser":
			if ($session['user']['superuser'] & SU_MEGAUSER){
				addnav("Actions");
				addnav("Character Cleanup","runmodule.php?module=charclean");
			}
			break;
	}
	return $args;
}
function charclean_run(){
	global $session;
	$days = httppost('days');
	page_header("Character Cleanup");
	if ($days != ""){
		$clean = date("Y-m-d H:i:s",strtotime("-$days days"));
		$sql = "SELECT acctid FROM ".db_prefix("accounts")." 
				WHERE laston<'$clean' 
				AND (superuser&".NO_ACCOUNT_EXPIRATION.")=0";
		$res = db_query($sql);
		while($row = db_fetch_assoc($res)){
			require_once("lib/charcleanup.php");
			char_cleanup($row['acctid'],CHAR_DELETE_AUTO);
		}
		$amnt = db_affected_rows();
		output("`^%s `#accounts have been removed.",$amnt);
	}else{
		output("`#This tool allows an Administrator to induce the character expiration process.");
		output("It is recommended that you only go through with this if you understand what you are doing.");
		output("Otherwise, leave now.`n`n");
		rawoutput("<form action='runmodule.php?module=charclean' method='post'>");
		rawoutput("Days since laston: <input name='days' value='60'><br>");
		$conf = translate_inline("Are you sure you wish to go through with this deletion?");
		rawoutput("<input type='submit' class='button' onClick=\"return confirm('$conf');\" value='".translate_inline("Delete")."'></form>");
		addnav("","runmodule.php?module=charclean");
	}
	require_once("lib/superusernav.php");
	superusernav();
	page_footer();
}
?>