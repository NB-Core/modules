<?php
//addnews ready
/**
* Version:      0.9
* Updated Date:         November 15, 2005
* Author:       Kevin Hatfield - Arune http://www.dragonprime.net
* LOGD VER: 	Module for 1.0.+
*
*/
require_once("lib/http.php");

function instabank_getmoduleinfo(){
        $info = array(
                "name"=>"Instant Banking",
                "author"=>"Kevin Hatfield - Arune",
                "version"=>"0.9",
                "category"=>"Forest",
                "download"=>"http://dragonprime.net/users/khatfield/instabank.zip",
				"settings"=>array(
				"showeagle"=>"Show the eagle image from /images/eaglegif?,enum,0,No,1,Yes",
                ),
        );
        return $info;
}

function instabank_install(){
        debug("Adding Hooks");
        module_addhook("forest");
        return true;
}

function instabank_uninstall(){
        output("Uninstalling this module.`n");
        return true;
}

function instabank_dohook($hookname, $args){
        global $session;
        switch($hookname){
        case "forest":
        addnav("I?Instant Bank","runmodule.php?module=instabank");
	break;
        default:
        }
		return $args;
}
function instabank_run(){
        global $session;
        $op = httpget('op');
        switch($op){
        case "":
		page_header("Eagle Banking");
		output("`^`c`bInstant Banking`b`c`6");
		addnav("Return to Forest","forest.php");
		if (get_module_setting('showeagle') == 1) output("`c<img src='images/eagle.gif' width='200' height='230' align='right' alt='InstantBank'>`c",true);
	        $_POST[amount]=$session[user][gold];
	        }if ($session[user][goldinbank]>=0){
	        output("You take an empty pouch from your back pocket and put all your gold in it. You whistle loudly and suddenly a giant eagle swoops down from the clouds and takes your sack of gold from you. It flies towards the village and after a little while it returns to you carrying your empty sack and a note on how much money you deposited and how much you have in the bank now.");
	        output("`^`b`nYou deposit `&$_POST[amount]`^ gold in to your bank account. ");
	        debug("deposited " . $_POST[amount] . " gold in the bank");
	        $session[user][goldinbank]+=$_POST[amount];
	        $session[user][gold]-=$_POST[amount];
         }else{
	       output("\"`3You have have a `&debt`3 of `^".abs($session[user][goldinbank])." gold`3 at the bank, you cannot use instant deposit until you payoff your debt. ");
	       debug("Deposit not allowed, user has debt");
}
page_footer();
}
?>
