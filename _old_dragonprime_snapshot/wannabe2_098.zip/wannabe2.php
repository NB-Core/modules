<?php
/* Wannabe Knight II  18April2005
   Author: Robert of Maddrio dot com
   Converted from a 097 forest event
   optimized for smaller file size v1.1 July05
*/

function wannabe2_getmoduleinfo(){
	$info = array(
	"name"=>"Wannabe Knight II",
	"version"=>"1.1",
	"author"=>"`2Robert",
	"category"=>"Forest Specials",
	"download"=>"http://dragonprime.net/users/robert/wannabe2_098.zip",
	);
	return $info;
}

function wannabe2_install(){
	module_addeventhook("forest","return 100;");
	return true;
}

function wannabe2_uninstall(){
	return true;
}

function wannabe2_dohook($hookname,$args){
	return $args;
}

function wannabe2_runevent($type){

	global $session;
	$from = "forest.php?";
	$session['user']['specialinc'] = "module:wannabe2";
	$op = httpget('op');

	if ($op=="" || $op=="search"){
	output("`n`n`^ You have come across a `b`4Wannabe Knight`b `^who attack's you with his Battle Axe! `n");
	output("`^ You are quick! Your %s `^protects you and are not injured! `n",$session['user']['armor']);
	output(" You fend off the `b`4Wannabe Knight`b `^until he turns and runs away! `n");
	output(" You have already gained 2% experience! `n");
	output(" You notice he is hurt, running slow and maybe you should chase after him to finish him off? `n");
	output(" You will lose a forest fight if you do. `n`n`& What will you do? `n");
	output(" Chase after him with bloodlust in your eye's or return to the forest to face other creatures? ");
	$session['user']['experience']*=1.02;
	addnav("Wannabe Knight");
	addnav("(C) Chase after him", $from."op=chase");
	addnav("(R) Return to forest", $from."op=dont");
	}elseif ($op=="chase"){
		$session['user']['specialinc'] = "";
		output("`n`^ You decided to give chase after the `4Wannabe Knight`^! `n");
		output("`^ You are not so sure you did the right thing, but you wanted revenge for him ambushing you like he did. `n");
		output(" You catch up to the `4Wannabe Knight `^who quickly turns, raises his Battle Axe and ..`n");
		$session[user][turns]--;
		switch(e_rand(1,5)){
		case 1:
		output("`^ before you could raise your %s`^, you are badly injured!",$session['user']['armor']);
		output(" The `4Wannabe Knight `^spares your life, turns and walks away. ");
		if ($session['user']['turns']>=2){
		output("`n`n`6 The severity of your wounds cause you to lose 2 Forest Fights!");
		$session['user']['turns']-=2;
		}
		break;
		case 2:
		output("`^ you are quick with your %s `^ and you are not injured!`n",$session['user']['armor']);
		output(" You fight with the `4Wannabe Knight `^fending off each attack of his Battle Axe `n");
		output(" You manage to hit him a few times and once again he turns and runs away. `n");
		output(" You are too weary to give chase once more but have learned a few things! `n`n");
		output("`6 You gain 2% experience!`n");
		$session['user']['experience']*=1.02;
		break;
		case 3:
		output("`^ swings for your chest, your %s `^ fails to protect you. `n",$session['user']['armor']);
		output(" One mighty blow of his Battle Axe knocks you down. Sparing your life, he turns and walks away. `n`n");
		output("`6 You are badly injured, and find revenge not to be a good thing. `n");
		output("`7 You lose 3% of experience! `n");
		$session['user']['alive']=true;
		$session['user']['hitpoints']=2;
		$session['user']['experience']*=0.97;
		break;
		case 4:
		output("`^ swings for your chest, you are too slow and your %s `^ fails to protect you`n`n",$session['user']['armor']);
		output("`\$ You have Died! `n");
		output("`6 You lose 5% of your experience.`n");
		output("`7 You may continue playing again tomorrow.");
		$session['user']['alive']=false; 
		$session['user']['hitpoints']=0;
		$session['user']['experience']*=0.95;
		$session['user']['gold'] = 0; 
		addnav("bad news");
		addnav("(D) Daily News","news.php");
		addnews(" %s `2was slain by the `4Wannabe Knight`2.",$session['user']['name']);
		break;
		case 5:
		output("`^says,`6`b I will slay thee %s `6 but I mean ye no harm`b!",$session['user']['name']);
		output(" I was giving chase after a Treacherous Troll. When I attacked ye, I thought him to be you. ");
		output(" When me mind cleared a bit and seen ye were not the Troll, I am ashamed to say that I turned and ran away. ");
		output(" To keep this between you and I, ");
		output(" I will give ye `5 $gold `6 gold for your silence and speak of this day no more. ");
		$gold = e_rand($session['user']['level']*30,$session['user']['level']*50);
		$session['user']['gold']+=$gold; 
		debuglog("got $gold gold from wannabe knight");
		break;
}
}else{
output("`n`2 Not wanting to waste your time, you head back to the forest. ");
$session['user']['specialinc'] = "";
}
}

function wannabe2_run(){
}
?>