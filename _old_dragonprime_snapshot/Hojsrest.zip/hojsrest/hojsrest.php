<?php
	global $session;
	$op = httpget('op');
	$page = httpget('page');
	$table_id = httpget("table_num");
	$restname=get_module_setting("restname");
	page_header("%s",$restname);
	output("`n`c`b`^%s`0`c`b`n",$restname);
	villagenav();
	$rprice=get_module_setting("rprice");
	$tablenum=get_module_setting("tablenum");
	if ($tablenum>=0){
		$tabcount=get_module_setting("tabcount");
		$tableavail=$tablenum-$tabcount;
		$bribepr=round($rprice*.1);
	}else{
		//Arbitrary numbers if there are unlimited tables.  These just prevent the restaurant from ever being "full".
		$tabcount=100;
		$tableavail=50;
	}
if (get_module_pref("kicked_out")){ 
     set_module_pref("kicked_out",0); 
     redirect("runmodule.php?module=hojsrest&op=enter"); 
} 
if ($op=="enter") {
		output("`6A `^Maitre d'`6 stands at a podium looking at a schedule book.");
		output("His eyes never leave the book as you stand at the door waiting for several minutes.");
		output("You give a subtle `@'Ahem'`6 to get his attention.");
		output("`n`nYou look around and notice several tables with `&'Reserved'`6 on them.");
		output("A sign on the wall says `&'The Rules'`6.");
		output("`n`nThe `^Maitre d'`6 continues to ignore you as he appears to write something very important in the book.");
		output("After an eternity, he finally looks up.");
		output("In a thick French accent he addresses you.`n`n`0");
		addnav("Restaurant Rules","runmodule.php?module=hojsrest&op=rrules");
		//Check:  Have they surrendered a table in a restaurant that has limited seating?
		if (get_module_pref("restabnum")==0 && get_module_pref("resertoday")==1){
			output("'Unfortunately you are not allowed to make another reservation today.");
			if (get_module_pref("invitenum")>0) output("However, the table you have been invited to is ready for you.'");
			else output("If you are invited to a table you are welcome to come back. Otherwise, please come back tomorrow.'");
		}elseif (get_module_pref("restabnum")==0){
			if ($tableavail==0){
				output("'We do not have any more tables available for reservation today.");
				if (get_module_pref("invitenum")>0) output("However, the table you have been invited to is ready for you.'");
				else output("If you are invited to a table you are welcome to come back. Otherwise, please come back tomorrow.'");
			}else{
				output("'The price to reserve a table will be`^ %s gold`0.'`n`n",$rprice);
				output("'Would you like a");
				if (get_module_pref("invitenum")==0) output("table?'");			
				if (get_module_pref("invitenum")>0) output("table or are you here by invitation?'");
				addnav("Reserve a Table","runmodule.php?module=hojsrest&op=reservetable");
			}	
		}else{
			output("'Your table is ready.");
			output("If you would like to invite someone to your table it will cost `^%s gold`0.'`n`n",$rprice);
			output("'Otherwise, if you would like, you may surrender your current table.'");
			addnav("Surrender Your Reservation","runmodule.php?module=hojsrest&op=surrender");
			addnav("Invite Someone to Your Table","runmodule.php?module=hojsrest&op=invite");
		}
		hojsrest_tablenav();
		hojsrest_invitenav();
}
if ($op=="rrules") {
	output("`^1. Rules for language and activity that apply elsewhere in the kingdom apply here.");
	output("Even though conversations are private, they are still moderated by staff.");
	output("`n`n2. You may hold only one reservation per day and your reservation is good for that day.");
	output("You may return as many times as you would like for the day.");
	output("If you are finished, you may surrender your reservation at any time.");
	if ($tablenum>=0) output("Due to the limited capacity of the restaurant you may only make one reservation per day.");
	output("`n`n3. The tables will be 'cleared' with each new day so all conversations will also be 'cleared' daily.");
	output("`n`n4. You may invite as many individuals to dine with you as you wish; however, each invitation will cost you the price of another meal.");
	output("`n`n5. A person may only be invited to one dinner at a time.");
	output("If they are invited to dinner by someone else, it will erase their invitation to dine with you.");
	output("`n`n6. Choose the people you want to dine with carefully.");
	output("You cannot take your invitations back.");
	if ($tablenum>=0) {
		output("`n`n7. The restaurant has a maximum capacity of`& %s tables`^.",$tablenum);
		output("Sometimes we may not be able to accomodate you if the restaurant is full.");
		output("If this is the case, we apologize for any inconvenience and hope you will consider dining with us at another time.");
	}
	addnav("Speak to the `^Maitre d'`6","runmodule.php?module=hojsrest&op=enter");
}
if ($op=="reservetable") {
	if (get_module_pref("resertoday")==1){
		output("`0'`i%s`i, you cannot have 2 tables.",translate_inline($session['user']['sex']?"ma'am":"sir"));
		output("You already have &%s table`0.'",get_module_pref("restabnum"));
		output("`n`n'Please feel free to go to your table.  You may invite someone to join you for `^%s gold`0.'",$rprice);
		addnav("Invite Someone to Your Table","runmodule.php?module=hojsrest&op=invite");
		hojsrest_tablenav();
		hojsrest_invitenav();
	}elseif($tableavail==0){
		output("`0'We do not have any tables available today.");
		output("Come back tomorrow.'");
	}elseif ($session['user']['gold']<$rprice){
		output("`0'I'm sorry, `i%s`i.",translate_inline($session['user']['sex']?"ma'am":"sir"));
		output("Perhaps you didn't hear me.");
		output("You need `^%s gold `0to get a table today.'",$rprice);
		output("`n`n'Please leave.'");
	}elseif ($tableavail>round($tablenum*.9)||$tablenum==-1){
		if (get_module_setting("tabcount")>$tablenum && $tablenum>=0){
			hojsrest_tablefull();
		}else{
			hojsrest_tableassign();
			output("`6The `^Maitre d'`6 looks at your gold and suddenly starts acting very politely.");
			output("`n`n`0'Well well well.");
			output("I think we have a table for you.'");
			output("`n`n'You have been assigned `&table #%s`0.'",get_module_pref("restabnum"));
			output("`n`n'Would you like to go to your table?");
			output("Otherwise you may invite someone to join you for `^%s gold`0.'",$rprice);
			addnav("Restaurant Rules","runmodule.php?module=hojsrest&op=rrules");
			hojsrest_tablenav();
			hojsrest_invitenav();
			addnav("Invite Someone to Your Table","runmodule.php?module=hojsrest&op=invite");
		}
	}elseif ($session['user']['gold']>=($rprice+$bribepr)){
		output("`6The `^Maitre d'`6 looks down and mentions that there doesn't seem to be any tables available for you.  He holds out his hand.");
		output("`n`nPerhaps if you slip him an extra `^%s gold`6 you may get your table.",$bribepr);
		addnav("Bribe the `^Maitre d'`6","runmodule.php?module=hojsrest&op=bribe");
	}
}
if ($op=="bribe") {
	$session['user']['gold']-=$bribepr;
	output("`6You slip the `^Maitre d' `^%s gold`6 and look at him expectantly.`n`n",$bribepr);
	output("He quickly slips the gold into his pocket and looks down at his book again.");
	$bribery=(e_rand(1,2));
	if ($bribery==1){
		if (get_module_setting("tabcount")>$tablenum){
			hojsrest_tablefull();
		}else{
			hojsrest_tableassign();
			output("`n`n`0'Oh yes, I see that we do have a table for you.");
			output("You may have `&table %s`0.'",get_module_pref("restabnum"));
			output("`n`n'Would you like to go to your table or invite someone to join you for `^%s gold`0?'",$rprice);
			hojsrest_tablenav();
			hojsrest_invitenav();
			addnav("Invite Someone to Your Table","runmodule.php?module=hojsrest&op=invite");
		}
	}else{
		output("`n`n`6He completely ignores you.");
		output("Perhaps your bribe didn't work.");
		if ($session['user']['gold']>=($rprice+$bribepr)){
			output("`n`nWould you like to try and slip him another `^%s gold`6?",$bribepr);
			addnav("Bribe the `^Maitre d'`6 Again","runmodule.php?module=hojsrest&op=bribe");
		}else{
			output("`n`nYou don't have enough money to bribe him again.");
			output("Maybe if you can get together about `^%s gold`6 you could come back and try again.",$bribepr);
		}
	}
}
if($op=="invite"){
	if ($session['user']['gold']<$rprice){
		output("`0'I'm sorry, `i%s`i.",translate_inline($session['user']['sex']?"ma'am":"sir"));
		output("You need `^%s gold`0 to invite someone to a join you.'",$rprice);
		addnav("Restaurant Rules","runmodule.php?module=hojsrest&op=rrules");
		hojsrest_tablenav();
	}else{
		$who = httpget('who');
		if ($who==""){
			$subop = httpget('subop');
			if ($subop!="search"){
				output("`0'Who would you like to invite?'`n`n");
				$search = translate_inline("Search");
				rawoutput("<form action='runmodule.php?module=hojsrest&op=invite&subop=search' method='POST'><input name='name' id='name'><input type='submit' class='button' value='$search'></form>");
				addnav("","runmodule.php?module=hojsrest&op=invite&subop=search");
				hojsrest_table();
				hojsrest_tablenav();
				hojsrest_invitenav();
				rawoutput("<script language='JavaScript'>document.getElementById('name').focus();</script>");
			}else{
				hojsrest_table();
				hojsrest_tablenav();
				hojsrest_invitenav();
				addnav("Search Again","runmodule.php?module=hojsrest&op=invite");
				$search = "%";
				$name = httppost('name');
				for ($i=0;$i<strlen($name);$i++){
					$search.=substr($name,$i,1)."%";
				}
				$sql = "SELECT name,alive,location,sex,level,laston,loggedin,login FROM " . db_prefix("accounts") . " WHERE (locked=0 AND name LIKE '$search') ORDER BY level DESC";
				$result = db_query($sql);
				$max = db_num_rows($result);
				if ($max > 50) {
					output("`n`n'That is too many names to pick from.");
					output("Please choose from this list.'`n");
					$max = 50;
				}
				if ($max==0){
					output("'Unfortunately we do not have an address for anyone by that name.  Please try again.'");
				}else{
					output("'Who would you like to invite?'`n`n");			
				}
				rawoutput("<table border=0 cellpadding=0><tr><td>$n</td></tr>");
				for ($i=0;$i<$max;$i++){
					$row = db_fetch_assoc($result);
					rawoutput("<tr><td><a href='runmodule.php?module=hojsrest&op=invite&who=".rawurlencode($row['login'])."'>");
					output_notl("%s", $row['name']);
					rawoutput("</a></td></tr>");
					addnav("","runmodule.php?module=hojsrest&op=invite&who=".rawurlencode($row['login']));
				}
			rawoutput("</table>");
			}
		}else{
			$sql = "SELECT name,acctid FROM " . db_prefix("accounts") . " WHERE login='$who'";
			$result = db_query($sql);
			if (db_num_rows($result)>0){
				$row = db_fetch_assoc($result);
				$id = $row['acctid'];
				$name = $row['name'];
				hojsrest_table();
				hojsrest_tablenav();
				hojsrest_invitenav();
				if ($name==$session[user][name]){
					output("'I'm sorry `i%s`i, but you can't invite yourself to your table for you are already there.'",translate_inline($session['user']['sex']?"ma'am":"sir"));
					addnav("Search Again","runmodule.php?module=hojsrest&op=invite");
				}else{
					$session['user']['gold']-=$rprice;
					output("'Excellent, `i%s`i.'",translate_inline($session['user']['sex']?"ma'am":"sir"));
					output("`n`n`6The `^Maitre d'`6 takes `^%s gold`6 from you.",$rprice);
					output("`n`n`0'We have sent an invitation to `&%s`0 to join you at our restaurant.",$name);
					output("Is there anything else I can do for you?'");
					addnav("Invite Someone Else to Your Table","runmodule.php?module=hojsrest&op=invite");
					require_once("lib/systemmail.php");
					$subj = sprintf("An Invitation to Dinner");
					$body = sprintf("`^You have been invited to dine with `0%s`^ at `b%s`b in `0%s`^.`n`nPlease feel free to enjoy a lovely meal and good conversation. You have a reservation at `&table %s`^.",$session['user']['name'],$restname,get_module_setting("restloc"),get_module_pref("restabnum"));
					systemmail($id,$subj,$body);
					set_module_pref("invitenum",get_module_pref("restabnum"),"hojsrest",$id);
				}
			}else{
				output("`0'I do not know anyone named that.'");
			}
		}
	}
}
if ($op == "surrender"){
	output("`0'Very good, `i%s`i.",translate_inline($session['user']['sex']?"ma'am":"sir"));
	output("If any of your guests are still eating we will allow them to finish their meal before making the table available for someone else.'");
	output("`n`n`6The `^Maitre d'`6 crosses your name off the reservation list.");
	output("Feeling a little awkard, you leave.");
	increment_module_setting("tabcount",-1);
	$table=get_module_pref("restabnum");
	$sql = "update ".db_prefix("module_userprefs")." set value=0 where value=$table and setting='invitenum' and modulename='hojsrest'";
	db_query($sql);
	if ($tablenum==-1) set_module_pref("resertoday",0);
	set_module_pref("restabnum",0);
}
if ($op == "table"){
	output("`c`@Table %s`c",$table_id);
	output("`n`&Lovely flowers decorate the table and a gourmet meal is served.`n");
	hojsrest_table();
	$name = hojsrest_whoshere($table_id);
	output("`nSitting at the table: %s.",$name);
	output("`n`2-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-`n");
	viewcommentary("hojsrest".$table_id,"Enjoy your meal!",20,"says");
}
if ($op == "table"){
	set_module_pref("current_table",$table_id);
}else{
	set_module_pref("current_table",0);
}
page_footer();
?>