<?php
function hojsrest_tableassign(){
	global $session;
	$session['user']['gold']-=get_module_setting("rprice");
	increment_module_setting("usedtab",1);
	increment_module_setting("tabcount",1);
	set_module_pref("resertoday",1);
	for ($i = 1; $i <= get_module_setting("usedtab"); $i++){
		if (get_module_setting("usedtab") == $i)
			set_module_pref("restabnum",$i);
		}
	}	
function hojsrest_tablenav(){
	for ($i = 1; $i <= get_module_setting("usedtab"); $i++){
		if (get_module_pref("restabnum") == $i)
			addnav("Go to Your Reserved Table","runmodule.php?module=hojsrest&op=table&table_num=".$i);
	}
}
function hojsrest_invitenav(){
	for ($i = 1; $i <= get_module_setting("usedtab"); $i++){
		if (get_module_pref("invitenum") == $i)
			addnav("Go to Your Invited Table","runmodule.php?module=hojsrest&op=table&table_num=".$i);
	}
}
function hojsrest_tablefull(){
	global $session;
	set_module_pref("resertoday",1);
	output("`0'I'm very sorry sir, however I seem to have been mistaken.");
	output("There are no tables available today at the restaurant.'");
	output("Perhaps you can join us tomorrow.'`n`n");
}
function hojsrest_table(){
	addnav("Restaurant Rules","runmodule.php?module=hojsrest&op=rrules");
	addnav("Speak to the `^Maitre d'","runmodule.php?module=hojsrest&op=enter");
	addcommentary();
}
function hojsrest_whoshere($table_id){
	global $session;
	$sql = "SELECT name FROM ".db_prefix("accounts")." INNER JOIN ".db_prefix("module_userprefs")." ON acctid=userid WHERE modulename='hojsrest' AND setting='current_table' AND value='$table_id' AND loggedin=1 AND laston > '".date("Y-m-d H:i:s",strtotime("-".getsetting("LOGINTIMEOUT",300)." seconds"))."'";
	$res = db_query($sql);
	$name = "";
	for ($i = 0; $i < db_num_rows($res); $i++){
		$row = db_fetch_assoc($res);
		$guest = $row['name'];
		if ($guest == $session['user']['name']) $guest = translate_inline("Yourself");
		$name = sprintf("%s`@%s%s", $name, $name == "" ? "" : ", ",$guest);
	}
	return $name;
}
?>