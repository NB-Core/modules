<?php
/*
Module Name:  hojsrest.php
Category:  Village
Worktitle:  Hoj's Restaurant
Author:  DaveS and Chris Vorndran
Date:  December 4, 2005

Thanks to Sichae for making the module possible and for all his help.

Based on an idea by Runering

Dedicated to Sixf00t.

Description:
A location for players to go for "private converations".  A player buys a table and pays to invite others to join 
them. Settings can be made for the number of tables in the restaurant or left at infinite. Conversations are 
Erased every system newday. One reservation at a time.  A player may only have an invitation to one table at a 
time. If they are invited to another table, the previous invitation is revoked. Tables may have an unlimited number
of invitees to it.

If there are limited tables:
1. At 10% remaining, the maitre d' will accept bribes for a chance at the remaining tables.
2. Once a reservation is cancelled, the player cannot get another table.

If there are unlimited tables:
1. Once a reservation is cancelled, the player can get another table.

v3.1  Cleaned up some of the newday_runonce code

*/
require_once("common.php");
require_once("lib/showform.php");
require_once("lib/commentary.php");
function hojsrest_getmoduleinfo(){
	$info = array(
		"name"=>"Hoj's Restaurant",
		"version"=>"3.1",
		"author"=>"DaveS and Chris Vorndran",
		"category"=>"Village",
		"download"=>"http://dragonprime.net/index.php?module=Downloads;sa=dlview;id=146",
		"vertxtloc"=>"",
		"description"=>"",
		"settings"=>array(
            "Hoj's Restaurant Settings,title",
            "restname"=>"What is the name of the restaurant?,text|Hoj's Restaurant",
			"restloc"=>"Where does the restaurant appear?,location|".getsetting("villagename", LOCATION_FIELDS),
			"tprice"=>"What is the base price for a table?,int|200",
			"rprice"=>"What is today's price for a table?,int|200",
			"tablenum"=>"How many tables are there in the restaurant?,int|-1",
			"Set to -1 for unlimited tables,note",
			"tabcount"=>"How many tables are occupied today?,int|0",
			"usedtab"=>"What is the next table number to be assigned?,int|0",
        ),
        "prefs"=>array(
			"Hoj's Restaurant Preferences,title",
			"resertoday"=>"Has the player reserved a table today?,bool|0",
			"restabnum"=>"What table did they reserve?,int|0",
			"invitenum"=>"What number table were they invited to?,int|0",
			"current_table"=>"What table is the player currently at?,int|0",
			"kicked_out"=>"Was this player kicked out at newday?,bool|0",
        ),
    );
    return $info;
}
function hojsrest_install(){
	module_addhook("changesetting");
	module_addhook("village");
	module_addhook("newday-runonce");
	module_addhook("newday");
    return true;
}
function hojsrest_uninstall(){
	return true;
}
function hojsrest_dohook($hookname,$args){
	global $session;
	switch($hookname){
		case "changesetting":
			if ($args['setting'] == "villagename") {
				if ($args['old'] == get_module_setting("restloc")) {
					set_module_setting("restloc", $args['new']);
				}	
			}
			break;
		case "newday-runonce":
			$sql = "update ".db_prefix("module_userprefs")." set value=0 where value<>0 and setting='resertoday' and modulename='hojsrest'";
			db_query($sql);
			$sql = "update ".db_prefix("module_userprefs")." set value=0 where value<>0 and setting='restabnum' and modulename='hojsrest'";
			db_query($sql);
			$sql = "update ".db_prefix("module_userprefs")." set value=0 where value<>0 and setting='invitenum' and modulename='hojsrest'";
			db_query($sql);
			$sql = "update ".db_prefix("module_userprefs")." set value=0 where value<>0 and setting='current_table' and modulename='hojsrest'";
			db_query($sql);
			$pricemod=(e_rand(85,115));
			$totalused=get_module_setting("usedtab");
			set_module_setting("rprice",get_module_setting("tprice")*$pricemod/100);
			set_module_setting("tabcount",0);
			set_module_setting("resertoday",0);
			$comm = "";
			for ($i = 1; $i <= $totalused; $i++){
				set_module_setting("table".$i,0);
				$comm = sprintf("%s%s section='hojsrest$i'", $comm, $comm == ""?"":" OR ");
			}
			if ($comm <> ""){
				$sql = "DELETE FROM ".db_prefix("commentary")." WHERE $comm";
				db_query($sql);
			}
			set_module_setting("usedtab",0);
		break;
		case "newday":
			if (get_module_pref("current_table") != 0){
				set_module_pref("current_table",0);
				set_module_pref("kicked_out",1);
			}
		break;
		case "village":
			if ($session['user']['location'] == get_module_setting("restloc")){ 
				tlschema($args["schemas"]["marketnav"]);
				addnav($args["marketnav"]);
				tlschema();
				addnav(array("%s",get_module_setting("restname")),"runmodule.php?module=hojsrest&op=enter");
			}
		break;
	}
	return $args;
}
function hojsrest_run(){
	$op = httpget('op');
	global $SCRIPT_NAME;
	if ($SCRIPT_NAME == "runmodule.php"){
		$module=httpget("module");
		if ($module == "hojsrest"){
			require_once("modules/hojsrest/hojsrest_func.php");
			include("modules/hojsrest/hojsrest.php");
		}
	}
}
?>