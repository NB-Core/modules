<?
/****************************************/
/* Schlammloch
/* filename: mud.php
/* Version 0.1
/* Type: Forest Event
/* Web: http://www.pqcomp.com/logd
/* E-mail: logd@pqcomp.com
/* Author: Lonny Luberts
/*
/* Modification by SkyPhy, July 04
/* Translation by SkyPhy, July 04
/**************************************/
output("Du steigst!  Ohhhh! Direkt in ein riesiges Schlammloch!  Du bist von oben bist unten mit Schlamm bedeckt!");
$session['user']['clean']+=5;
?>