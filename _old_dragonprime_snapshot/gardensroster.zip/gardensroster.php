<?php

function gardensroster_getmoduleinfo(){
	$info = array(
		"name"=>"Gardens Roster",
		"author"=>"Chris Vorndran",
		"category"=>"Gardens",
		"version"=>"1.0",
		"download"=>"http://dragonprime.net/index.php?module=Downloads;sa=dlview;id=74",
		"vertxtloc"=>"http://dragonprime.net/users/Sichae/",
		"prefs"=>array(
			"ingardens"=>"Is this user in the Gardens?,bool|0",
		),
	);
	return $info;
}
function gardensroster_install(){
	module_addhook("gardens");
	module_addhook("village");
	// module_addhook("footer-runmodule");
	return true;
}
function gardensroster_uninstall(){
	return true;
}
function gardensroster_dohook($hookname,$args){
	global $session;
	switch ($hookname){
		case "village":
		// case "footer-runmodule":
			set_module_pref("ingardens",0);
			break;
		case "gardens":
			set_module_pref("ingardens",1);
			$sql = "SELECT name FROM ".db_prefix("accounts")." INNER JOIN ".db_prefix("module_userprefs")." ON acctid=userid WHERE modulename='gardensroster' AND setting='ingardens' AND value=1 AND loggedin=1 AND laston > '".date("Y-m-d H:i:s",strtotime("-".getsetting("LOGINTIMEOUT",300)." seconds"))."'";
			$res = db_query($sql);
			$parsing = "";
			while($row = db_fetch_assoc($res)){
				$name = $row['name'];
				if ($name == $session['user']['name']) $name = translate_inline("Yourself");
				$parsing = sprintf("%s`@%s%s", $parsing, $parsing == "" ? "" : ", ",$name);
			}
			if ($parsing != "") {
				output("`@Looking around the Gardens you see... ");
				output_notl($parsing);
				output_notl("`n");
			}
			break;
		}
	return $args;
}
?>