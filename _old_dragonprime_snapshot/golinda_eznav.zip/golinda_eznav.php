<?php
/**************
Name: Forest Nav for Golinda
Author: Eth - ethstavern(at)gmail(dot)com 
Version: 1.0
Release Date: 12-21-2005
About: Adds a link to the forest for users that have already paid to visit
	   Golinda. Blocks the normal healer nav as well for that day. Inspired by
	   an idea from seretogis.
Translation compatible.
*****************/
function golinda_eznav_getmoduleinfo(){
	$info = array(
		"name"=>"Forest Nav for Golinda",
		"author"=>"Eth",
		"version"=>"1.0",
		"category"=>"Forest",
		"download"=>"http://dragonprime.net/users/Eth/golinda_eznav.zip",
		"requires"=>array(
            "golinda"=>"Golinda|By JT Traub, part of the core",
        ),		
	);
	return $info;
}
function golinda_eznav_install(){
	module_addhook("forest");		
	return true;
}
function golinda_eznav_uninstall(){
	return true;
}
function golinda_eznav_dohook($hookname,$args){
	global $session;
	switch($hookname){
		case "forest":
		if (get_module_pref("paidtoday","golinda")) {	
			addnav("Heal");	
			blocknav("healer.php");	
			addnav("`^Visit Golinda","runmodule.php?module=golinda&op=healer");
		} 
		break;	
	}	
	return $args;
}
?>