<?
/*
*******************************************
 scuderie.php - The Race Course V1.0
 Originally by Excalibur (www.ogsi.it)
 05 October 2004

----install-instructions--------------------
DIFFICULTY SCALE: easy

Mod for LotGD 0.9.7
Drop into your main LoGD folder:
ippodromo.php
scuderie.php
ippodromoreset.php

Open village.php, add these lines (I've put them after Gypsy Tent)
addnav("The Stables","scuderie.php");
addnav("Race Course","ippodromo.php");

Open superuser.php and add somewhere:
addnav("Horse Race Control","ippodromoreset.php");

To run this mod you NEED that the first 3 mounts in your DB are:
Pony, Geldion, Stallion
Otherwise you'll run into problem ;-)
--------------------------------------------

Version History:
Ver. 1.0 created by Excalibur (www.ogsi.it)
Original Version posted to DragonPrime
********************************************
Originally by: Excalibur
English clean-up: Sixf00t4
05 December 2004

Run this SQL into your PHPMyAdmin

CREATE TABLE gara (
  acctid int(11) unsigned NOT NULL default '0',
  data int(11) unsigned NOT NULL default '0',
  giro1 int(5) unsigned NOT NULL default '0',
  giro2 int(5) unsigned NOT NULL default '0',
  giro3 int(5) unsigned NOT NULL default '0',
  giro4 int(5) unsigned NOT NULL default '0'
) TYPE=MyISAM;

CREATE TABLE scommessa (
  acctid int(11) unsigned NOT NULL default '0',
  acctid2 int(11) unsigned NOT NULL default '0',
  scommessa int(5) unsigned NOT NULL default '0',
  quota int(5) unsigned NOT NULL default '0',
  DATA int(11) unsigned NOT NULL default '0',
  tipo char(1) NOT NULL default ''
) TYPE=MyISAM;

CREATE TABLE scuderie (
  acctid int(11) unsigned NOT NULL default '0',
  mountid int(11) unsigned NOT NULL default '0',
  condizione int(5) unsigned NOT NULL default '0',
  sprint int(5) unsigned NOT NULL default '0',
  iscritto int(5) unsigned NOT NULL default '0'
) TYPE=MyISAM;


*/

require_once "common.php";
$operazione = $_GET[op];
$acctid = $session[user][acctid];
global $gara_ultima;$data_oggi;$gara_ippodromo;

$gara_ippodromo = getsetting("gara_ippodromo", 'false');
$gara_ultima = getsetting("gara_ultima", 0);
$gara_penultima = getsetting("gara_penultima", 0);
$data_oggi = time();

if ($gara_ultima==0) {
   savesetting("gara_ultima", $data_oggi);
   $gara_ultima = $data_oggi;
}

// inizio cancellazione dati ibsoleti
if ($gara_penultima!=0) {
    $sqlDelete = "DELETE FROM scommessa where data < '$gara_penultima'";
    db_query($sqlDelete) or die(db_error(LINK));
    $sqlDelete = "DELETE FROM gara where data < '$gara_penultima'";
    db_query($sqlDelete) or die(db_error(LINK));
}
// fine cancellazione dati ibsoleti


// Verifica se il player ha un cavallo
$sql = "SELECT s.acctid, s.mountid, s.condizione, s.sprint, s.iscritto, m.mountname  FROM scuderie s, mounts m WHERE s.acctid='$acctid' and s.mountid = m.mountid";
$result = db_query($sql) or die(db_error(LINK));
$ref = db_fetch_assoc($result);
// Fine Verifica

function generaQuotazione($caratteristiche,$partecipanti,$caratteristicaMax) {
    if ($partecipanti==1) return 1;
    $quotaBase = 10;
    if ($caratteristicaMax>=190) {
        if ($caratteristiche>=20) $quotaBase = 9;
        if ($caratteristiche>=40) $quotaBase = 8;
        if ($caratteristiche>=60) $quotaBase = 7;
        if ($caratteristiche>=80) $quotaBase = 6;
        if ($caratteristiche>=100) $quotaBase = 5;
        if ($caratteristiche>=130) $quotaBase = 4;
        if ($caratteristiche>=160) $quotaBase = 3;
        if ($caratteristiche>=190)$quotaBase = 2;
        return $quotaBase;
    }
    if ($caratteristicaMax>=160) {
        if ($caratteristiche>=20) $quotaBase = 9;
        if ($caratteristiche>=40) $quotaBase = 8;
        if ($caratteristiche>=60) $quotaBase = 7;
        if ($caratteristiche>=80) $quotaBase = 6;
        if ($caratteristiche>=100) $quotaBase = 5;
        if ($caratteristiche>=120) $quotaBase = 4;
        if ($caratteristiche>=140) $quotaBase = 3;
        if ($caratteristiche>=160) $quotaBase = 2;
        return $quotaBase;
    }
    if ($caratteristicaMax>=140) {
        $quotaBase = 9;
        if ($caratteristiche>=20) $quotaBase = 8;
        if ($caratteristiche>=40) $quotaBase = 7;
        if ($caratteristiche>=60) $quotaBase = 6;
        if ($caratteristiche>=80) $quotaBase = 5;
        if ($caratteristiche>=100) $quotaBase = 4;
        if ($caratteristiche>=120) $quotaBase = 3;
        if ($caratteristiche>=140) $quotaBase = 2;
        return $quotaBase;
    }
    if ($caratteristicaMax>=120) {
        $quotaBase = 8;
        if ($caratteristiche>=20) $quotaBase = 7;
        if ($caratteristiche>=40) $quotaBase = 6;
        if ($caratteristiche>=60) $quotaBase = 5;
        if ($caratteristiche>=80) $quotaBase = 4;
        if ($caratteristiche>=100) $quotaBase = 3;
        if ($caratteristiche>=120) $quotaBase = 2;
        return $quotaBase;
    }
    if ($caratteristicaMax>=100) {
        $quotaBase = 7;
        if ($caratteristiche>=20) $quotaBase = 6;
        if ($caratteristiche>=40) $quotaBase = 5;
        if ($caratteristiche>=60) $quotaBase = 4;
        if ($caratteristiche>=80) $quotaBase = 3;
        if ($caratteristiche>=100) $quotaBase = 2;
        return $quotaBase;
    }

    $quotaBase = 2;
    return $quotaBase;
}

function generaGiro($caratteristiche) {
    $fattoreImprevisto = e_rand(-2,2);
    $percorrenza = (intval(e_rand(2,5)) - $fattoreImprevisto) * intval($caratteristiche/2);
    return $percorrenza;
}

function generaCronaca($gara_ultima) {
   $sql = "SELECT a.name, g.giro1 FROM accounts a, gara g, scuderie s WHERE s.acctid=g.acctid AND a.acctid = s.acctid AND data = '$gara_ultima' order by giro1 DESC LIMIT 10";
   $result = db_query($sql) or die(db_error(LINK));
   $risultatoGara = array();
   if (db_num_rows($result) > 0) {
       output("`n`n`0The tension is growing. We can see the horses on the starting line ready to dash out at the signal.");
       output("`nJust a few seconds more .. ready ...`1THREE  `2TWO  `3ONE  `4GO!`0`n");
   }
   for ($i=0;$i<db_num_rows($result);$i++){
       $row = db_fetch_assoc($result);
       if ($i==0) {output("`n`3$row[name]'s horse `0takes the lead right away!");}
       if ($i==1) {output(" followed by `3$row[name]`0' horse. ");}
       if ($i==2) {output(" Behind we see `3$row[name]`0's horse");}
       if ($i==3) {output(" and then `3$row[name]`0");}
       if ($i==4) {output(" a few meters behind is `3$row[name]`0,");}
       if ($i==5) {output(" in sixth position we see the `3$row[name]`0's horse,");}
       if ($i==6) {output(" while back there's `3$row[name]`0's stallion,");}
       if ($i==7) {output(" drawing up cloe there's `3$row[name]`0's gelding");}
       if ($i==8) {output(" followed near by `3$row[name]`0's horse");}
       if ($i==9) {output(" while in tenth position we find `3$row[name]`0's stallion");}
       $risultatoGara[1][$i][name]=$row[name];
       $risultatoGara[1][$i][mountname]=$row[mountname];
       $risultatoGara[1][$i][giro]=$row[giro1];
   }
   if (db_num_rows($result) > 0) {
       output("`n`n`5And now the start of the second lap`0`n`n");
   }
   $sql = "SELECT a.name, (g.giro1+g.giro2) as giro FROM accounts a, gara g, scuderie s WHERE s.acctid=g.acctid AND a.acctid = s.acctid AND data = '$gara_ultima' order by giro DESC LIMIT 10";
   $result = db_query($sql) or die(db_error(LINK));
   for ($i=0;$i<db_num_rows($result);$i++){
       $row = db_fetch_assoc($result);
       $risultatoGara[2][$i][name]=$row[name];
       $risultatoGara[2][$i][mountname]=$row[mountname];
       $risultatoGara[2][$i][giro]=$row[giro];
       if ($i==0) {
          if ($risultatoGara[1][$i][name]==$risultatoGara[2][$i][name]) {
              output("`3$row[name]`0's horse is still in first position,");
          } else {
              output("Wait! `3$row[name]`0' horse takes the lead away!,");
          }
       }
       if ($i==1) {
          if ($risultatoGara[1][$i][name]==$risultatoGara[2][$i][name]) {
              output("second place is dominated by `3$row[name]`0's steed");
          } else {
              output("second place is now owned by `3$row[name]`0's steed");
          }
       }
       if ($i==2) {output(" immediatly behind we see `3$row[name]`0'horse");}
       if ($i==3) {output(" and `3$row[name]`0's horse");}
       if ($i==4) {output(" neck and neck with `3$row[name]`0");}
       if ($i==5) {output(" pressed hard by `3$row[name]`0,");}
       if ($i==6) {output(" not to far behind there's `3$row[name]`0's horse,");}
       if ($i==7) {output(" and hehind by just a quarter of a horse's length `3$row[name]`0");}
       if ($i==8) {output(" followed by `3$row[name]`0's gelding");}
       if ($i==9) {output(" and in tenth position we find `3$row[name]`0's horse.");}
   }
   if (db_num_rows($result) > 0) {
       output("`n`n`5And now the third and second to last lap !!`0`n`n");
   }
   $sql = "SELECT a.name, (g.giro1+g.giro2+g.giro3) as giro FROM accounts a, gara g, scuderie s WHERE s.acctid=g.acctid AND a.acctid = s.acctid AND data = '$gara_ultima' order by giro DESC LIMIT 10";
   $result = db_query($sql) or die(db_error(LINK));
   for ($i=0;$i<db_num_rows($result);$i++){
       $row = db_fetch_assoc($result);
       $risultatoGara[3][$i][name]=$row[name];
       $risultatoGara[3][$i][mountname]=$row[mountname];
       $risultatoGara[3][$i][giro]=$row[giro];
       if ($i==0) {
          if ($risultatoGara[2][$i][name]==$risultatoGara[3][$i][name]) {
              output("The `3$row[name]'s horse `0keep the first position");
          } else {
              output("We have a leader change! Now the powerful mount leading the race is `3$row[name]`0's horse");
          }
       }
       if ($i==1) {
          if ($risultatoGara[2][$i][name]==$risultatoGara[3][$i][name]) {
              output(" while `3$row[name]`0's steed defends the second place position tenaciously");
          } else {
              output(" We now see in second position`3$row[name]`0's steed");
          }
       }
       if ($i==2) {output(" immediatly behind is `3$row[name]`0's horse");}
       if ($i==3) {output(" and `3$row[name]`0s' steed");}
       if ($i==4) {output(" in fifth position following close is `3$row[name]`0,");}
       if ($i==5) {output(" and trailing not far behind `3$row[name]`0's animal,");}
       if ($i==6) {output(" we can see `3$row[name]`0's stallion in seventh position,");}
       if ($i==7) {output(" with `3$row[name]`0's horse nearing.");}
       if ($i==8) {output(" that is battling furiously with `3$row[name]`0's gelding");}
       if ($i==9) {output(" and in tenth position we find `3$row[name]`0's horse.");}
   }
   if (db_num_rows($result) > 0) {
       output("`n`n`5Finally we approach the `^Final Lap`%! This race is Amazing!, a nail bitter, let's see who will be victorious !!`0`n`n");
   }
   $sql = "SELECT a.name, (g.giro1+g.giro2+g.giro3+g.giro4) as giro FROM accounts a, gara g, scuderie s WHERE s.acctid=g.acctid AND a.acctid = s.acctid AND data = '$gara_ultima' order by giro DESC LIMIT 10";
   $result = db_query($sql) or die(db_error(LINK));
   for ($i=0;$i<db_num_rows($result);$i++){
       $row = db_fetch_assoc($result);
       if ($i==0) {
          output("The winner is `^$row[name]`0's horse!! Kudos to the trainer!");
       }
       if ($i==1) {
          output("`nSecond place is property of `3$row[name]`0's purebred");
       }
       if ($i==2) {output("`nThe lowest step of the podium is occupied by `3$row[name]`0's horse");}
       if ($i==3) {output("`nComing in a pathetic fourth, `3$row[name]`0's crock,");}
       if ($i==4) {output(" fifth `3$row[name]`0,");}
       if ($i==5) {output(" sixth `3$row[name]`0,");}
       if ($i==6) {output(" seventh `3$row[name]`0,");}
       if ($i==7) {output(" eighth `3$row[name]`0,");}
       if ($i==8) {output(" ninth `3$row[name]`0");}
       if ($i==9) {output(" and tenth `3$row[name]`0");}
   }
}

function generaGara($gara_ultima) {
    $sql = "SELECT a.acctid, s.mountid, s.condizione, s.sprint FROM scuderie s, mounts m, accounts a WHERE s.acctid = a.acctid and s.mountid = m.mountid and s.iscritto = 1";
    $result = db_query($sql) or die(db_error(LINK));
    for ($i=0;$i<db_num_rows($result);$i++){
         $percorrenzaTot = 0;
         $row = db_fetch_assoc($result);
         $condizione = $row[condizione];
         $sprint = $row[sprint];
         $caratteristiche = $condizione + $sprint;
         if ($row[mountid] == 1) {$handicap=1.25;}
         if ($row[mountid] == 2) {$handicap=1.13;}
         if ($row[mountid] == 3) {$handicap=1.00;}
         // Giro 1
         $percorrenza1 = generaGiro($caratteristiche);
         $condizione -= intval(e_rand(8,15)*$handicap);
         if ($condizione<=1) {$condizione=1;}
         $sprint -= intval(e_rand(8,15)*$handicap);
         if ($sprint<=1) {$sprint=1;}
         print("ID:".$row['acctid']."Condition:".$condizione."Sprint:".$sprint."<br>");
         $caratteristiche = $condizione + $sprint;
         // Giro 2
         $percorrenza2 = generaGiro($caratteristiche);
         $condizione -= intval(e_rand(8,15)*$handicap);
         if ($condizione<=1) {$condizione=1;}
         $sprint -= intval(e_rand(8,15)*$handicap);
         if ($sprint<=1) {$sprint=1;}
         print("ID:".$row['acctid']."Condition:".$condizione."Sprint:".$sprint."<br>");
         $caratteristiche = $condizione + $sprint;
         // Giro 3
         $percorrenza3 = generaGiro($caratteristiche);
         $condizione -= intval(e_rand(8,15)*$handicap);
         if ($condizione<=1) {$condizione=1;}
         $sprint -= intval(e_rand(8,15)*$handicap);
         if ($sprint<=1) {$sprint=1;}
         print("ID:".$row['acctid']."Condition:".$condizione."Sprint:".$sprint."<br>");
         $caratteristiche = $condizione + $sprint;
         // Giro 4
         $percorrenza4 = generaGiro($caratteristiche);
         $condizione -= intval(e_rand(8,15)*$handicap);
         if ($condizione<=1) {$condizione=1;}
         $sprint -= intval(e_rand(8,15)*$handicap);
         if ($sprint<=1) {$sprint=1;}
         print("ID:".$row['acctid']."Condition:".$condizione."Sprint:".$sprint."<br>");
         $sqlInsert = "INSERT INTO gara
                                    (acctid
                                    ,data
                                    ,giro1
                                    ,giro2
                                    ,giro3
                                    ,giro4
                            ) VALUES (
                                    '$row[acctid]'
                                   ,'$gara_ultima'
                                   ,'$percorrenza1'
                                   ,'$percorrenza2'
                                   ,'$percorrenza3'
                                   ,'$percorrenza4'
                            )";
         db_query($sqlInsert) or die(db_error(LINK));
         if (db_affected_rows(LINK)<=0){
            output("`n`n`\$Error`^: Something went wrong in Race (step1), inform Admin about it.");
         } else {
            $sqlUpdate = "UPDATE scuderie SET
                           iscritto = 0
                          ,condizione = '$condizione'
                          ,sprint = '$sprint'
                    WHERE acctid='$row[acctid]'";
            db_query($sqlUpdate) or die(db_error(LINK));
            if (db_affected_rows(LINK)<=0){
                output("`n`n`\$Error`^: Something went wrong in Race (step2), inform Admin about it.");
            }
         }
    }

}



switch ($operazione) {
       case "":
             page_header("Race Course");
             addcommentary();
             output("`0You enter the grounds and what you see is fantastic.`nThe construction is a huge ellipsis surrounded by
             covered seating full of a exicted horse race fans, ready for another thrilling day at the track.");
             output("`nOn the race track there are some jockeys parading their horses which soon will race around the track to victory or defeat.");
             output("`nNear the stands you notice a desk that collects stakes and another to enroll your horse for the next race.");
             output("`nBeside the desks there are two blackboards, one with horse's names that will participate in the next race, ");
             output(" the other with the result of the previous race.");
             addnav("Options");
             addnav("Check Results","ippodromo.php?op=check");
             if (db_num_rows($result)>0) {
                 if ($ref['iscritto']==0) {
                     if ($gara_ippodromo=='false') {
                         addnav("Enroll your horse","ippodromo.php?op=iscrizione");
                     }
                 } else {
                     output("`n`n`3Your horse is enrolled for the next race!`0");
                 }
             }
             addnav("Check Participants","ippodromo.php?op=iscritti");
             if ($gara_ippodromo=='false') {
                 addnav("Make a bet","ippodromo.php?op=scommetti1");
                 $clandestina = e_rand(0,9);
                 //if ($clandestina==0) {
                     output("`n`nA shady Drow, with shifty dark eyes, approaches you and asks if you want to try your hand at the thrill of illegal betting.");
                     addnav("Illegal bet","ippodromo.php?op=clandestina");
                 //}
             } else {
                 output("`n`n`4`cThe clerk tells you that you can't enroll your horse in the race or make a bet this close to the start of the race.`c`0");
             }
             output("`n`n");
             viewcommentary("ippodromo","Shout:",10,"urla");
             addnav("Places");
             addnav("Back to Stables","scuderie.php");
             addnav("Back to Village","village.php");
             break;
             // end case ""
       case "iscrizione":
             page_header("Race Ground");
             output("`0You approach the desk that accepts the enrollment and you tell the clerk you want to register your
                      {$ref['mountname']} in the next race.`n");
             output("`0The clerk tells you that you have to pay `^500 `0gold pieces and `%1 `0gem.");
             addnav("Pay the fee","ippodromo.php?op=iscrizioneok");
             output("`#`n`nWhat do you want do?");
             addnav("Places");
             addnav("Back to Race Course","ippodromo.php");
             addnav("Back to Stables","scuderie.php");
             addnav("Back to Village","village.php");
             break;
             // end case "no
       case "iscrizioneok":
             page_header("Race Course");
             if (($session['user']['gold']) < 500 || ($session['user']['gems']) < 1) {
                 output("`0The clerk looks at you ticked, \"`&'Listen here, I don't have time to waste.`n
                          If you don't have money or a gem, bugger off and come back when you have the fee, chump.`7\"");
             } else {
                 $sql = "UPDATE scuderie SET
                                iscritto = 1
                          WHERE acctid='$acctid'";
                 db_query($sql) or die(db_error(LINK));
                 if (db_affected_rows(LINK)<=0){
                       output("`n`n`\$Error`^: Something went wrong inscribing your horse, try again later.");
                 } else {
                       output("`0The clerk greedily takes your money in his grubby hands. He writes your name on sheepskin and gives it to his helper, ");
                       output("The helper approachs the blackboard and logs your horse in for the next race.");
                       $session['user']['gold']-=500;
                       $session['user']['gems']-=1;
                 }
             }
             addnav("Back to Race Course","ippodromo.php");
             addnav("Back to Stables","scuderie.php");
             addnav("Back to Village","village.php");
             break;
             // end case "no
       case "iscritti":
             page_header("Blackboard of Participants");
             output("`0You approach the blackboard to look at the name of the players.`n`n");
             $sql = "SELECT a.name, m.mountname, s.condizione+s.sprint as caratteristiche FROM scuderie s, mounts m, accounts a WHERE s.acctid = a.acctid and s.mountid = m.mountid and s.iscritto = 1 order by caratteristiche desc";
             output("<table cellspacing=0 cellpadding=2 align='center'><tr align='center'><td>`bPosition`b</td><td>`bPlayer`b</td><td>`bHorse`b</td></tr>",true);
             $result = db_query($sql) or die(db_error(LINK));
             if (db_num_rows($result)==0){
               output("<tr><td colspan=3 align='center'>`&There's no horses enrolled`0</td></tr>",true);
             }
             for ($i=0;$i<db_num_rows($result);$i++){
                 $row = db_fetch_assoc($result);
                 output("<tr align='center' class='".($i%2?"trlight":"trdark")."'><td>".($i+1).".</td><td>$row[name]</td><td>$row[mountname]</td></tr>",true);
             }
             output("</table>",true);
             addnav("Back to Race Course","ippodromo.php");
             addnav("Back to Stables","scuderie.php");
             addnav("Back to Village","village.php");
             break;
       case "scommetti1":
             page_header("Race Course");
             output("`0You approach the desk that accepts bets.`n");
             $sql = "SELECT s.acctid, s.acctid2, s.scommessa, s.quota FROM scommessa s WHERE s.acctid = '$acctid' and data = '$gara_ultima' AND tipo = 'L'";
             $result = db_query($sql) or die(db_error(LINK));
             $giaPuntato = false;
             if (db_num_rows($result)<>0) $giaPuntato=true;
             if ($giaPuntato) {
                 $row = db_fetch_assoc($result);
                 $sql = "SELECT name FROM accounts WHERE acctid = '$row[acctid2]'";
                 $resultAcc = db_query($sql) or die(db_error(LINK));
                 $rowAcc = db_fetch_assoc($resultAcc);
                 output("`0The clerk tells you that you have already made a bet for this race, you can't do more than one.`n");
                 output("You can check how odds on the race are going.`n`n`n");
                 output("`0If you have forgotten, you have bet `^$row[scommessa] `0gold on the `@$rowAcc[name]`0's horse.`n");
                 output("`0When you placed your bet the odds were set at `3$row[quota]/1`0.`n`n");
             } else {
                 output("`0The clerk asks you the name of the horse you want to put your bet on.`n`n");
             }
             $sql = "SELECT s.acctid, a.name, m.mountname, s.condizione+s.sprint as caratteristiche FROM scuderie s, mounts m, accounts a WHERE s.acctid = a.acctid and s.mountid = m.mountid and s.iscritto = 1 order by caratteristiche desc";
             output("<table cellspacing=0 cellpadding=2 align='center'><tr align='center'><td>`bPosition`b</td><td>`bPlayer`b</td><td>`bHorse`b</td><td>`bQuotation`b</td></tr>",true);
             $result = db_query($sql) or die(db_error(LINK));
             if (db_num_rows($result)==0){
                 output("<tr><td colspan=4 align='center'>`&No horses enrolled`0</td></tr>",true);
             } else {
                 $caratteristicaMax = 0;
                 for ($i=0;$i<db_num_rows($result);$i++){
                      $row = db_fetch_assoc($result);
                      if ($i==0) $caratteristicaMax=$row[caratteristiche];
                      $quotazione = generaQuotazione($row[caratteristiche],db_num_rows($result),$caratteristicaMax);
                      if ($giaPuntato) {
                          output("<tr align='center' class='".($i%2?"trlight":"trdark")."'><td>".($i+1).".</td><td>$row[name]</td><td>$row[mountname]</td><td>$quotazione/1</td></tr>",true);
                      } else {
                          $link = "ippodromo.php?op=scommetti2&id=$row[acctid]&quota=$quotazione";
                          addnav("",$link);
                          output("<tr align='center' class='".($i%2?"trlight":"trdark")."'><td><a href=$link>".($i+1)."</a>.</td><td><a href=$link>$row[name]</a></td><td><a href=$link>$row[mountname]</a></td><td><a href=$link>$quotazione/1</a></td></tr>",true);
                      }
                 }
             }
             output("</table>",true);
             addnav("Back to Race Course","ippodromo.php");
             addnav("Back to Stables","scuderie.php");
             addnav("Back to Village","village.php");
             break;
       case "scommetti2":
             page_header("Race Course");
             $id = $_GET[id];
             $quota = $_GET[quota];
             output("`0The clerk takes note of the horse's owner and asks you how much do you want bid.");
             addnav("Scommesse");
             addnav("500 Gold","ippodromo.php?op=scommetti3&gold=500&id=$id&quota=$quota");
             addnav("1.000 Gold","ippodromo.php?op=scommetti3&gold=1000&id=$id&quota=$quota");
             addnav("5.000 GOld","ippodromo.php?op=scommetti3&gold=5000&id=$id&quota=$quota");
             addnav("Places");
             addnav("Back to Race Course","ippodromo.php");
             addnav("Back to Stables","scuderie.php");
             addnav("Back to Village","village.php");
             break;
       case "scommetti3":
             page_header("Race Course");
             $gold = $_GET[gold];
             $id = $_GET[id];
             $quota = $_GET[quota];
             if ($session[user][gold] < $gold) {
                 output("`0The clerk looks at you peeved \"`&'See here, I don't have time to waste.`n
                          If you don't have money or gems don't come up here and jerk my chain, come back when you the dough.`7\"");
             } else {
                 $sql = "INSERT INTO scommessa
                                    (acctid
                                    ,acctid2
                                    ,scommessa
                                    ,quota
                                    ,data
                                    ,tipo
                            ) VALUES (
                                    '$acctid'
                                   ,'$id'
                                   ,'$gold'
                                   ,'$quota'
                                   ,'$gara_ultima'
                                   ,'L'
                            )";
                 db_query($sql) or die(db_error(LINK));
                 if (db_affected_rows(LINK)<=0){
                     output("`\$Error`^: Something went wrong placing the bid, try again later.");
                 } else {
                     output("`0The clerk accepts your bid and writes on a sheepskin, your name, the horse you've choosen, and the amount you've bet.");
                     $session['user']['gold']-=$gold;
                 }
             }
             addnav("Back to Race Course","ippodromo.php");
             addnav("Back to Stables","scuderie.php");
             addnav("Back to Village","village.php");
             break;
        case "check":
             page_header("Race Course");
             $dataCheck = getsetting("gara_penultima", 0);
             $sql = "SELECT a.name, m.mountname, (g.giro1+g.giro2+g.giro3+g.giro4) as giro FROM mounts m, accounts a, gara g, scuderie s WHERE g.acctid = a.acctid AND g.acctid=s.acctid AND s.mountid=m.mountid AND data = '$dataCheck' order by giro DESC";
             output("`c`b`&Winning Horses`b`c`n");
             output("<table cellspacing=0 cellpadding=2 align='center'><tr><td>`bPosition`b</td><td>`bPlayer`b</td><td>`bHorse`b</td></tr>",true);
             $result = db_query($sql) or die(db_error(LINK));
             if (db_num_rows($result)==0){
               output("<tr><td colspan=3 align='center'>`&No race has take place recently`0</td></tr>",true);
             } else {
               addnav("Chronicle","ippodromo.php?op=cronaca");
             }
             for ($i=0;$i<db_num_rows($result);$i++){
                 $row = db_fetch_assoc($result);
                 output("<tr class='".($i%2?"trlight":"trdark")."'><td>".($i+1).".</td><td>$row[name]</td><td>$row[mountname]</td></tr>",true);
             }
             output("</table>",true);
             addnav("Back to Race Course","ippodromo.php");
             addnav("Back to Stables","scuderie.php");
             addnav("Back to Village","village.php");
             break;
             // end case "no"
       case "cronaca":
             page_header("Chronicle");
             $dataCheck = getsetting("gara_penultima", 0);
             generaCronaca($dataCheck);
             addnav("Back to Race Course","ippodromo.php");
             addnav("Back to Stables","scuderie.php");
             addnav("Back to Village","village.php");
             break;
       case "clandestina":
             page_header("Race Course");
             output("`0You gesture to the Nefarious looking Dark Elf. He leads you into a seedy alley away from roaming eyes.`n");
             $sql = "SELECT s.acctid, s.acctid2, s.scommessa, s.quota FROM scommessa s WHERE s.acctid = '$acctid' and s.data = '$gara_ultima' AND tipo = 'C'";
             $result = db_query($sql) or die(db_error(LINK));
             $giaPuntato = false;
             if (db_num_rows($result)<>0) $giaPuntato=true;
             if ($giaPuntato) {
                 $row = db_fetch_assoc($result);
                 $sql = "SELECT name FROM accounts WHERE acctid = '$row[acctid2]'";
                 $resultAcc = db_query($sql) or die(db_error(LINK));
                 $rowAcc = db_fetch_assoc($resultAcc);
                 output("`0The cloaked and hooded Drow, stares at you with his piercing black eyes and tell's you that you have already placed a bid with him. He doesn't accept more bid.
                          `nIf you want you can I tell you what the odds are going.`n`n`n");
                 output("`0Just to remind you, you have placed a bid of `^$row[scommessa] `0gold pieces on `@$rowAcc[name]`0's horse.`n");
                 output("`0When you have placed the bid the odds of that horse were `3$row[quota]/1`0.`n`n");
             } else {
                 output("`0Standing off, in a shadowy place, he shows you a sheepskin on which you can check the horses. On which one do you want to bid on?`n`n");
             }

             $sql = "SELECT s.acctid, a.name, m.mountname, s.condizione+s.sprint as caratteristiche FROM scuderie s, mounts m, accounts a WHERE s.acctid = a.acctid and s.mountid = m.mountid and s.iscritto = 1 order by caratteristiche desc";
             output("<table cellspacing=0 cellpadding=2 align='center'><tr align='center'><td>`bPosition`b</td><td>`bPlayer`b</td><td>`bHorse`b</td><td>`bQuotation`b</td></tr>",true);
             $result = db_query($sql) or die(db_error(LINK));
             if (db_num_rows($result)==0){
                 output("<tr><td colspan=4 align='center'>`&There's no horses enrolled for the race !!`0</td></tr>",true);
             } else {
                 $caratteristicaMax = 0;
                 for ($i=0;$i<db_num_rows($result);$i++){
                      $row = db_fetch_assoc($result);
                      if ($i==0) $caratteristicaMax=$row[caratteristiche];
                      $quotazione = generaQuotazione($row[caratteristiche],db_num_rows($result),$caratteristicaMax);
                      if ($giaPuntato) {
                          output("<tr align='center' class='".($i%2?"trlight":"trdark")."'><td>".($i+1).".</td><td>$row[name]</td><td>$row[mountname]</td><td>$quotazione/1</td></tr>",true);
                      } else {
                          $link = "ippodromo.php?op=clandestina2&id=$row[acctid]&quota=$quotazione";
                          addnav("",$link);
                          output("<tr align='center' class='".($i%2?"trlight":"trdark")."'><td><a href=$link>".($i+1)."</a>.</td><td><a href=$link>$row[name]</a></td><td><a href=$link>$row[mountname]</a></td><td><a href=$link>$quotazione/1</a></td></tr>",true);
                      }
                 }
             }
             output("</table>",true);
             addnav("Back to Race Course","ippodromo.php");
             addnav("Back to Stables","scuderie.php");
             addnav("Back to Village","village.php");
             break;
       case "clandestina2":
             page_header("L'ippodromo");
             $id = $_GET[id];
             $quota = $_GET[quota];
             output("`0The Dark Elf takes note of the horse, and then ask you haw much do you want bid.");
             addnav("BID");
             addnav("500 Gold","ippodromo.php?op=clandestina3&gold=500&id=$id&quota=$quota");
             addnav("1.000 Gold","ippodromo.php?op=clandestina3&gold=1000&id=$id&quota=$quota");
             addnav("5.000 Gold","ippodromo.php?op=clandestina3&gold=5000&id=$id&quota=$quota");
             addnav("Places");
             addnav("Back to Race Course","ippodromo.php");
             addnav("Back to Stables","scuderie.php");
             addnav("Back to Village","village.php");
             break;
       case "clandestina3":
             page_header("Race Course");
             $gold = $_GET[gold];
             $id = $_GET[id];
             $quota = $_GET[quota];
             if ($session[user][gold] < $gold) {
                 output("`0The Drow stares at you with menacing eyes \"`&You think I'm a fool, loser. This Drow just wasn't born yesterday ...
                          You can't play without some shiny gold ... Come back when you'll have money.`7\"");
             } else {
                 $scommessa = e_rand(0,5);
                 switch ($scommessa) {
                    case 0;
                       output("`0The Drow draws nearer and with a rapid gesture he signs something behind your back shouting
                       `n\"`@`b<big><big>Grrrreeeennn Drrragggooonnnnnn !!`b</big></big>`0\"`n Remembering old adventures that fill your dreams with nightmares,
                       you jump dropping your gold and reflexively unsheath your sword ... to find that the only `@`bDragon`b`0 is the shady
                       Drow that has disappeared with your $gold gold pieces.",true);
                       //output("`0L'Umano prende il tuo oro e si dilegua prima che tu capisca cosa sta succedendo ... `6Hai perso i tuoi soldi`0...");
                       $session['user']['gold']-=$gold;
                       break;
                    case 1:
                    case 2:
                    case 3:
                    case 4:
                    case 5:
                       $sql = "INSERT INTO scommessa
                                          (acctid
                                          ,acctid2
                                          ,scommessa
                                          ,quota
                                          ,data
                                          ,tipo
                                  ) VALUES (
                                          '$acctid'
                                         ,'$id'
                                         ,'$gold'
                                         ,'$quota'
                                         ,'$gara_ultima'
                                         ,'C'
                                  )";
                       db_query($sql) or die(db_error(LINK));
                       if (db_affected_rows(LINK)<=0){
                           output("`\$Error`^: Something went wrong during the illegal bidding process, advice the Admins and report to jail for your illicit activities.");
                       } else {
                           output("`0The Drow takes your bid, nods and tells that he'll
                                    show up if you'll be lucky enough to win ...");
                           $session['user']['gold']-=$gold;
                       }
                       break;
                 }
             }
             addnav("Back to Race Course","ippodromo.php");
             addnav("Back to Stables","scuderie.php");
             addnav("Back to Village","village.php");
             break;
       case "no":
             page_header("Race Course");
             output("`0You walk to Race Course but a worker stop you telling you that it's not opened to public.");
             addnav("Back to Stables","scuderie.php");
             addnav("Back to Village","village.php");
             break;
             // end case "no"
//------------------------------------------------
}
//I cannot make you keep this line here but would appreciate it left in.
rawoutput("<br><div style=\"text-align: right ;\"><a href=\"http://www.ogsi.it\" target=\"_blank\"><font color=\"#33FF33\">Race Course by Excalibur @ http://www.ogsi.it</font></a><br>");

page_footer();
?>