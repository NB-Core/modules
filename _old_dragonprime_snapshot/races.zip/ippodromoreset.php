<?

/*
*******************************************
 scuderie.php - The Race Course V1.0
 Originally by Excalibur (www.ogsi.it)
 05 October 2004

----install-instructions--------------------
DIFFICULTY SCALE: easy

Mod for LotGD 0.9.7
Drop into your main LoGD folder:
ippodromo.php
scuderie.php
ippodromoreset.php

Open village.php, add these lines (I've put them after Gypsy Tent)
addnav("The Stables","scuderie.php");
addnav("Race Course","ippodromo.php");

Open superuser.php and add somewhere:
addnav("Horse Race Control","ippodromoreset.php");

To run this mod you NEED that the first 3 mounts in your DB are:
Pony, Geldion, Stallion
Otherwise you'll run into problem ;-)
--------------------------------------------

Version History:
Ver. 1.0 created by Excalibur (www.ogsi.it)
Original Version posted to DragonPrime
********************************************
Originally by: Excalibur
English clean-up: Sixf00t4
05 December 2004

Run this SQL into your PHPMyAdmin

CREATE TABLE gara (
  acctid int(11) unsigned NOT NULL default '0',
  data int(11) unsigned NOT NULL default '0',
  giro1 int(5) unsigned NOT NULL default '0',
  giro2 int(5) unsigned NOT NULL default '0',
  giro3 int(5) unsigned NOT NULL default '0',
  giro4 int(5) unsigned NOT NULL default '0'
) TYPE=MyISAM;

CREATE TABLE scommessa (
  acctid int(11) unsigned NOT NULL default '0',
  acctid2 int(11) unsigned NOT NULL default '0',
  scommessa int(5) unsigned NOT NULL default '0',
  quota int(5) unsigned NOT NULL default '0',
  DATA int(11) unsigned NOT NULL default '0',
  tipo char(1) NOT NULL default ''
) TYPE=MyISAM;

CREATE TABLE scuderie (
  acctid int(11) unsigned NOT NULL default '0',
  mountid int(11) unsigned NOT NULL default '0',
  condizione int(5) unsigned NOT NULL default '0',
  sprint int(5) unsigned NOT NULL default '0',
  iscritto int(5) unsigned NOT NULL default '0'
) TYPE=MyISAM;


*/

require_once "common.php";
page_header("Race Course Control Center");

$operazione = $_GET['op'];
global $gara_ultima;$data_oggi;$gara_ippodromo;

$gara_ippodromo = getsetting("gara_ippodromo", 'false');

$gara_ultima = getsetting("gara_ultima", 0);
$gara_penultima = getsetting("gara_penultima", 0);
$data_oggi = time();

if ($gara_ultima==0) {
   savesetting("gara_ultima", $data_oggi);
   $gara_ultima = $data_oggi;
}

/*****************************************************************/
function generaGiro($caratteristiche) {
    $fattoreImprevisto = e_rand(-1,1);
    $percorrenza = (intval(e_rand(2,4)) + $fattoreImprevisto) * intval($caratteristiche/2);
    print($fattoreImprevisto."  ".$percorrenza." <br>");
    return $percorrenza;
}

function generaGara($gara_ultima) {
    $sql = "SELECT a.acctid, s.mountid, s.condizione, s.sprint FROM scuderie s, mounts m, accounts a WHERE s.acctid = a.acctid and s.mountid = m.mountid and s.iscritto = 1";
    $result = db_query($sql) or die(db_error(LINK));
    for ($i=0;$i<db_num_rows($result);$i++){
         $percorrenzaTot = 0;
         $row = db_fetch_assoc($result);
         $condizione = $row[condizione];
         $sprint = $row[sprint];
         $caratteristiche = $condizione + $sprint;

         if ($row['mountid'] == 1) {
            $handicap=1.15;
            $handicap1=2;
         }
         if ($row['mountid'] == 2) {
            $handicap=1.10;
            $handicap1=1;
         }
         if ($row['mountid'] == 3) {
            $handicap=1.00;
            $handicap1=0;
         }
         // Giro 1
         $percorrenza1 = generaGiro($caratteristiche);
         $condizione -= intval(e_rand((7-$handicap1),(12+$handicap1))*$handicap);
         if ($condizione<=1) {$condizione=1;}
         $sprint -= intval(e_rand((7-$handicap1),(12+$handicap1))*$handicap);
         if ($sprint<=1) {$sprint=1;}
         $caratteristiche = $condizione + $sprint;
         // Giro 2
         $percorrenza2 = generaGiro($caratteristiche);
         $condizione -= intval(e_rand((7-$handicap1),(12+$handicap1))*$handicap);
         if ($condizione<=1) {$condizione=1;}
         $sprint -= intval(e_rand((7-$handicap1),(12+$handicap1))*$handicap);
         if ($sprint<=1) {$sprint=1;}
         $caratteristiche = $condizione + $sprint;
         // Giro 3
         $percorrenza3 = generaGiro($caratteristiche);
         $condizione -= intval(e_rand((7-$handicap1),(12+$handicap1))*$handicap);
         if ($condizione<=1) {$condizione=1;}
         $sprint -= intval(e_rand((7-$handicap1),(12+$handicap1))*$handicap);
         if ($sprint<=1) {$sprint=1;}
         $caratteristiche = $condizione + $sprint;
         // Giro 4
         $percorrenza4 = generaGiro($caratteristiche);
         $condizione -= intval(e_rand((7-$handicap1),(12+$handicap1))*$handicap);
         if ($condizione<=1) {$condizione=1;}
         $sprint -= intval(e_rand((7-$handicap1),(12+$handicap1))*$handicap);
         if ($sprint<=1) {$sprint=1;}
         $sqlInsert = "INSERT INTO gara
                                    (acctid
                                    ,data
                                    ,giro1
                                    ,giro2
                                    ,giro3
                                    ,giro4
                            ) VALUES (
                                    '$row[acctid]'
                                   ,'$gara_ultima'
                                   ,'$percorrenza1'
                                   ,'$percorrenza2'
                                   ,'$percorrenza3'
                                   ,'$percorrenza4'
                            )";
         db_query($sqlInsert) or die(db_error(LINK));
         if (db_affected_rows(LINK)<=0){
            output("`n`n`\$ERROR`^: an error has occurred during the race (step1)");
         } else {
            $sqlUpdate = "UPDATE scuderie SET
                           iscritto = 0
                          ,condizione = '$condizione'
                          ,sprint = '$sprint'
                    WHERE acctid='$row[acctid]'";
            db_query($sqlUpdate) or die(db_error(LINK));
            if (db_affected_rows(LINK)<=0){
                output("`n`n`\$ERROR`^: an error has occurred during the race (step2)");
            }
         }
    }

}
/*****************************************************************/


output("`\$`n`n`c<font size='+1'>ATTENTION !!! You are going to modify the Table of Race Course.</font>",true);
output("`nAre you 100% sure to do it ?`c`n`n",true);
if ($HTTP_GET_VARS['op']==""){
        output("The correct sequence is Begin Race, Give Prizes, Give Bets.",true);
        output("`nGiving away Bets will be updated in SETTING table the following variable:",true);
        output("`ngara_ultima    --> Today date",true);
        output("`ngara_penultima --> Last Race date (Zero if first)",true);
        output("`n`nDisable Stable inhibit possibility to access Stables, to Bet and Enroll horses",true);
        output("`nEnable Stable let players to access Stables, to Bet and Enroll horses",true);
        output("`n`nActual Configuration:",true);
        output("`ngara_ultima <-- $gara_ultima",true);
        output("`ngara_penultima <-- $gara_penultima",true);
        output("`ngara_ippodromo <-- $gara_ippodromo",true);
        addnav("G?`#Back to Grotto","superuser.php");
        addnav("M?`@Back to Mundanity","village.php");
        addnav("P?`5Check Enrolled Player","ippodromoreset.php?op=ctrliscritti");
        addnav("C?`5Check Bets","ippodromoreset.php?op=ctrlscommesse");
        if ($gara_ippodromo=='false') {
           addnav("D?`7Disable Stable","ippodromoreset.php?op=variabili");
        } else {
           addnav("E?`7Enable Stable","ippodromoreset.php?op=variabili");
        }
        addnav("B?`\$Let's Race Begin","ippodromoreset.php?op=iniziagara");
        addnav("r?`^Give away Prizes","ippodromoreset.php?op=premi");
        addnav("A?`^Give Away Bets","ippodromoreset.php?op=scommesse");
}

if ($HTTP_GET_VARS['op']=="iniziagara"){
        output("`n`nBegin Generation of Race",true);
        generaGara($gara_ultima);
        output("`n`nEnd Generation of Race",true);

        addnews("The Race at Race Course has begun!");

        addnav("G?`#Back to Grotto","superuser.php");
        addnav("M?`@Back to Mundanity","village.php");
        addnav("G?`^Give away Prizes","ippodromoreset.php?op=premi");
}

if ($HTTP_GET_VARS['op']=="premi") {
    output("`n`nBegin generation of prizes",true);
    $sqlGara = "SELECT g.acctid, a.name, a.sex, a.gems, a.gold, (g.giro1+g.giro2+g.giro3+g.giro4) as giro FROM gara g, accounts a WHERE g.acctid = a.acctid AND data = '$gara_ultima' order by giro DESC LIMIT 3";
    $resultGara = db_query($sqlGara) or die(db_error(LINK));
/**********************/
    output("`c`b`&The Winner Owners`b`c`n");
    output("<table cellspacing=0 cellpadding=2 align='center'><tr><td>`bPosition`b</td><td>`bPlayer`b</td></tr>",true);
/**********************/
    for ($i=0;$i<db_num_rows($resultGara);$i++){
        $rowGara = db_fetch_assoc($resultGara);
        $accountWin = $rowGara['acctid'];
        $nameWin = $rowGara['name'];
        $sexWin = $rowGara['sex'];
        $posto = $i+1;
        if ($i==0) {
           $handicap = 10;
           $gemme = 6;
           $gold = 6000;
           $mailmessage = "`@Your horse has won ! You have gained $gemme Gems and $gold Gold!!!";
           systemmail($accountWin,"`%Congratulations !!! Your horse stand victorious in the winners circle.",$mailmessage);
        }
        if ($i==1) {
           $handicap = 8;
           $gemme = 4;
           $gold = 4000;
           $mailmessage = "`@Your horse placed 2nd !!! You have gained $gemme Gems and $gold Gold!!!";
           systemmail($accountWin,"`%Congratulations !!! Maybe next time you'll get first",$mailmessage);
        }
        if ($i==2) {
           $handicap = 5;
           $gemme = 2;
           $gold = 2000;
           $mailmessage = "`@Your horse has placed 3rd! You have gained $gemme Gems and $gold Gold!!!";
           systemmail($accountWin,"`%Congratulations !!!",$mailmessage);
        }
        addnews("`#$nameWin `#has classified al `^".$posto."� place`# at the `@Race Course of LoGD`#.`n
                   `#$nameWin `#has won `^$gemme gems`# and `&$gold Gold Pieces !!");
/**********************/
        output("<tr align='center' class='".($s%2?"trlight":"trdark")."'><td>".($i+1).".</td><td>$nameWin</td></tr>",true);
/**********************/
        if ($session['user']['accti']==$accountWin) {
           $session['user']['gold']+=$gold;
           $session['user']['gems']+=$gemme;
        } else {
           $gemme += $rowGara['gems'];
           $gold += $rowGara['gold'];
           $sqlUpd = "UPDATE accounts SET gems = '$gemme', gold = '$gold' WHERE acctid = '$accountWin'";
           $resultUpd=db_query($sqlUpd);
           if (db_affected_rows(LINK)<=0){
              output("`n`n`\$ERROR`^: Something went wrong giving away prizes (step1) at Race Course, please advice Admins");
           }
        }
        //Modification by Excalibur to handicap the first 3
        $sqlhandicap = "UPDATE scuderie SET condizione = condizione - '$handicap', sprint = sprint - '$handicap' WHERE  acctid = '$accountWin'";
        $resulthandicap=db_query($sqlhandicap);
    }
/**********************/
    output("</table>",true);
/**********************/
    output("`n`nEnd Prizes Generation",true);
    addnav("G?`#Back to Grotto","superuser.php");
    addnav("M?`@Back to Mundanity","village.php");
    addnav("S?`^Give away Bets","ippodromoreset.php?op=scommesse");
}

if ($HTTP_GET_VARS['op']=="scommesse") {
    // PREMI PER LE SCOMMESSE
    $sqlPrimo = "SELECT acctid, (giro1+giro2+giro3+giro4) as giro FROM gara WHERE data = '$gara_ultima' order by giro DESC LIMIT 1";
    $resultPrimo = db_query($sqlPrimo) or die(db_error(LINK));
/**********************/
    output("`c`b`&Winning Bettor`b`c`n");
    output("<table cellspacing=0 cellpadding=2 align='center'><tr align='center'><td>`bPosition`b</td><td>`bPlayer`b</td><td>`bPrizes`b</td><td>`bKind`b</td></tr>",true);
/**********************/
        $rowPrimo = db_fetch_assoc($resultPrimo);
        $sqlScommessa = "SELECT acctid, scommessa, quota, tipo FROM scommessa WHERE acctid2 = '$rowPrimo[acctid]' AND data = '$gara_ultima' ";
        $resultScommessa = db_query($sqlScommessa) or die(db_error(LINK));
        if (db_num_rows($resultScommessa) <= 0){
            output("<tr><td colspan=4 align='center'>`&Nobody has bet on the winning horse`0</td></tr>",true);
        }
        for ($s=0;$s<db_num_rows($resultScommessa);$s++){
             // dati della scommessa
            $rowScommessa = db_fetch_assoc($resultScommessa);
            $accountWin = $rowScommessa['acctid'];
            $scommessa = $rowScommessa['scommessa'];
            $quota = $rowScommessa['quota'];
            $tipo = $rowScommessa['tipo'];
            // dati dell'account vincitore
            $sqlAcc = "SELECT acctid,name,gems,gold,evil FROM accounts WHERE acctid = '$accountWin'";
            $resultAcc = db_query($sqlAcc) or die(db_error(LINK));
            $rowAcc = db_fetch_assoc($resultAcc);

            $gemme = 0;
            $evil = 0;

            $premioGenerato = $scommessa * $quota;

            if ($tipo=='C') {
                $evil = 20;
                $gemme = 1;
                $mailmessage = "`@From out of the shadows comes the dark figures of lone Drow. Staring, he
                eyes you from top to toe, gives you your winnings $premioGenerato Gold and
                $gemme Gems !!! Guess sometimes crime does pay ...";
                systemmail($accountWin,"`%The Dark Drow is looking for you ...",$mailmessage);
            } else {
                $mailmessage = "`@You have bet on the winning horse! You have won $premioGenerato Gold Pieces!!!";
                systemmail($accountWin,"`%Congratulations! You have won the bet",$mailmessage);
            }

/**********************/
            output("<tr align='center' class='".($s%2?"trlight":"trdark")."'><td>".($i+1).".</td><td>$rowAcc[name]</td><td>$gemme Gems and $premioGenerato Gold</td><td>".($tipo=='C'?"Clandestina":"Legale")."</td></tr>",true);
/**********************/
            if ($session[user][acctid]==$accountWin) {
                $session['user']['gems']+=$gemme;
                $session['user']['gold']+=$premioGenerato;
                $session['user']['evil']+=$evil;
            } else {
                $sqlUpd1 = "";
                $sqlUpd2 = "";
                $sqlUpd3 = "";
                $sqlUpd4 = "";
                $golds = $premioGenerato + $rowAcc['gold'];
                $sqlUpd1 = "UPDATE accounts SET gold = '$golds'";
                if ($gemme!=0) {
                    $gemme += $rowAcc['gems'];
                    $sqlUpd2 = " ,gems = '$gemme' ";
                }
                if ($evil != 0) {
                   $evil += $rowAcc['evil'];
                   $sqlUpd3 = " ,evil = '$evil' ";
                }
                $sqlUpd4 = " WHERE acctid = '$accountWin'";
                $sqlUpd = $sqlUpd1."".$sqlUpd2."".$sqlUpd3."".$sqlUpd4;
                db_query($sqlUpd) or die(db_error(LINK));
                if (db_affected_rows(LINK)<=0){
                   output("`n`n`\$ERROR`^: Something went wrong giving away prizes (step2) from the Race, please advice Admins immediately.`n");
                }
            }
        }
/**********************/
    output("</table>",true);
/**********************/
    savesetting("gara_ultima", $data_oggi);
    if (db_num_rows($resultPrimo) > 0){
        savesetting("gara_penultima", $gara_ultima);
    }
    $gara_ultima = $data_oggi;
    addnav("G?`#Back to Grotto","superuser.php");
    addnav("M?`@Back to Mundanity","village.php");
    addnav("I?`^Back to Beginning","ippodromoreset.php");
}

if ($HTTP_GET_VARS['op']=="ctrliscritti"){
    $sql = "SELECT a.name, m.mountname, s.condizione, s.sprint, s.condizione+s.sprint as caratteristiche FROM scuderie s, mounts m, accounts a WHERE s.acctid = a.acctid and s.mountid = m.mountid and s.iscritto = 1 order by caratteristiche desc";
    output("<table cellspacing=0 cellpadding=2 align='center'><tr><td>`bPosition`b</td><td>`bPlayer`b</td><td>`bHorse`b</td><td>`bCondition`b</td><td>`bSprint`b</td><td>`bTotal`b</td></tr>",true);
    $result = db_query($sql) or die(db_error(LINK));
    if (db_num_rows($result)==0){
       output("<tr><td colspan=6 align='center'>`&There's no horses enrolled yet`0</td></tr>",true);
    }
    for ($i=0;$i<db_num_rows($result);$i++){
        $row = db_fetch_assoc($result);
        output("<tr align='center' class='".($i%2?"trlight":"trdark")."'><td>".($i+1).".</td><td>$row[name]</td><td>$row[mountname]</td><td>$row[condizione]</td><td>$row[sprint]</td><td>$row[caratteristiche]</td></tr>",true);
    }
    output("</table>",true);

    addnav("G?`#Back to Grotto","superuser.php");
    addnav("M?`@Back to Mundanity","village.php");
    addnav("I?`^Back to Beginning","ippodromoreset.php");

}

if ($HTTP_GET_VARS['op']=="ctrlscommesse"){
    $sql = "SELECT acctid, acctid2, scommessa, quota, tipo FROM scommessa WHERE data = '$gara_ultima' order by acctid";
    output("<table cellspacing=0 cellpadding=2 align='center'><tr align='center'><td>`bPosition`b</td><td>`bPlayer`b</td><td>`bBet on`b</td><td>`bHow Much`b</td><td>`bQuote`b</td><td>`bKind`b</td></tr>",true);
    $result = db_query($sql) or die(db_error(LINK));
    if (db_num_rows($result)==0){
       output("<tr><td colspan=6 align='center'>`&There's no bet yet`0</td></tr>",true);
    }
    for ($i=0;$i<db_num_rows($result);$i++){
        $row = db_fetch_assoc($result);
        $sqlAcc = "SELECT name FROM accounts WHERE acctid = '$row[acctid]'";
        $resultAcc = db_query($sqlAcc) or die(db_error(LINK));
        $rowAcc = db_fetch_assoc($resultAcc);
        $name = $rowAcc[name];
        $sqlAcc = "SELECT name FROM accounts WHERE acctid = '$row[acctid2]'";
        $resultAcc = db_query($sqlAcc) or die(db_error(LINK));
        $rowAcc = db_fetch_assoc($resultAcc);
        $name1 = $rowAcc[name];
        output("<tr class='".($i%2?"trlight":"trdark")."' align='center'><td>".($i+1).".</td><td>$name</td><td>$name1</td><td>$row[scommessa]</td><td>$row[quota]/1</td><td>".($row[tipo]=='C'?"Clandestine":"Legal")."</td></tr>",true);
    }
    output("</table>",true);

    addnav("G?`#Back to Grotto","superuser.php");
    addnav("M?`@Back to Mundanity","village.php");
    addnav("I?`^Back to Beginning","ippodromoreset.php");

}

if ($HTTP_GET_VARS['op']=="variabili"){
   if ($gara_ippodromo=='true') {
       savesetting("gara_ippodromo", 'false');
   } else {
       savesetting("gara_ippodromo", 'true');
   }
   redirect('ippodromoreset.php',true);
}
//I cannot make you keep this line here but would appreciate it left in.
rawoutput("<br><div style=\"text-align: right ;\"><a href=\"http://www.ogsi.it\" target=\"_blank\"><font color=\"#33FF33\">Race Course by Excalibur @ http://www.ogsi.it</font></a><br>");

page_footer();
?>