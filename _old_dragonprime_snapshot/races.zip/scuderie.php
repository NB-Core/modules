<?
/*
*******************************************
 scuderie.php - The Race Course V1.0
 Originally by Excalibur (www.ogsi.it)
 05 October 2004

----install-instructions--------------------
DIFFICULTY SCALE: easy

Mod for LotGD 0.9.7
Drop into your main LoGD folder:
ippodromo.php
scuderie.php
ippodromoreset.php

Open village.php, add these lines (I've put them after Gypsy Tent)
addnav("The Stables","scuderie.php");
addnav("Race Course","ippodromo.php");

Open superuser.php and add somewhere:
addnav("Horse Race Control","ippodromoreset.php");

To run this mod you NEED that the first 3 mounts in your DB are:
Pony, Geldion, Stallion
Otherwise you'll run into problem ;-)
--------------------------------------------

Version History:
Ver. 1.0 created by Excalibur (www.ogsi.it)
Original Version posted to DragonPrime
********************************************
Originally by: Excalibur
English clean-up: Sixf00t4
05 December 2004

Run this SQL into your PHPMyAdmin

CREATE TABLE gara (
  acctid int(11) unsigned NOT NULL default '0',
  data int(11) unsigned NOT NULL default '0',
  giro1 int(5) unsigned NOT NULL default '0',
  giro2 int(5) unsigned NOT NULL default '0',
  giro3 int(5) unsigned NOT NULL default '0',
  giro4 int(5) unsigned NOT NULL default '0'
) TYPE=MyISAM;

CREATE TABLE scommessa (
  acctid int(11) unsigned NOT NULL default '0',
  acctid2 int(11) unsigned NOT NULL default '0',
  scommessa int(5) unsigned NOT NULL default '0',
  quota int(5) unsigned NOT NULL default '0',
  DATA int(11) unsigned NOT NULL default '0',
  tipo char(1) NOT NULL default ''
) TYPE=MyISAM;

CREATE TABLE scuderie (
  acctid int(11) unsigned NOT NULL default '0',
  mountid int(11) unsigned NOT NULL default '0',
  condizione int(5) unsigned NOT NULL default '0',
  sprint int(5) unsigned NOT NULL default '0',
  iscritto int(5) unsigned NOT NULL default '0'
) TYPE=MyISAM;


*/
require_once "common.php";

$acctid = $session[user][acctid];
$sql = "SELECT s.acctid, s.mountid, s.condizione, s.sprint, s.iscritto, m.mountname  FROM scuderie s, mounts m WHERE s.acctid='$acctid' and s.mountid = m.mountid";
$result = db_query($sql) or die(db_error(LINK));
$ref = db_fetch_assoc($result);
$gara_ippodromo = getsetting("gara_ippodromo", 'false');

function valori($ref) {
         if ($ref['condizione']==100) $descrizione = "`3Excellent";
         if ($ref['condizione']<100)  $descrizione = "`3Optimal";
         if ($ref['condizione']<80)   $descrizione = "`3Good";
         if ($ref['condizione']<70)   $descrizione = "`3Growing";
         if ($ref['condizione']<50)   $descrizione = "`3Normal";
         if ($ref['condizione']<20)   $descrizione = "`3Bad";
         if ($ref['condizione']<10)   $descrizione = "`3Insufficient";
         output("`n`n Condizione: $ref[condizione] $descrizione");

         if ($ref['sprint']==100) $descrizione = "`3Excellent";
         if ($ref['sprint']<100)  $descrizione = "`3Optimal";
         if ($ref['sprint']<80)   $descrizione = "`3Good";
         if ($ref['sprint']<70)   $descrizione = "`3Growing";
         if ($ref['sprint']<50)   $descrizione = "`3Normal";
         if ($ref['sprint']<20)   $descrizione = "`3Bad";
         if ($ref['sprint']<10)   $descrizione = "`3Insufficient";
         output("`n`n`0 Sprint : $ref[sprint] $descrizione");
}

function updatepet($ref,$acctid,$operazionePet) {
         //output(" operazionePet ".$operazionePet);
         $sql = " UPDATE scuderie set ";
         if ($operazionePet=="condizione" || $operazionePet=="condizionesprint") {
             $sql = $sql." condizione = '$ref[condizione]' ";
         }
         if ($operazionePet=="sprint" || $operazionePet=="condizionesprint") {
             if ($operazionePet=="condizionesprint") {
                 $sql = $sql.",";
             }
             $sql = $sql." sprint     = '$ref[sprint]' ";
         }
         $sql = $sql." WHERE acctid='$acctid'";
         db_query($sql) or die(db_error(LINK));
}

$operazione = $_GET[op];
switch ($operazione) {
       case "":
             page_header("The Stables");
             addcommentary();
             output("Near the outskirts of the village, not to far away from gypsy camp, a new horse racing track has opened up.
                     `nThe sign at the entrance of the huge complex welcomes you to the `3Stables`0.");
             output("`n`nThe track is divided in two parts. In the first area one you can train your horses. In the
                      other is a `3Race-Course`0 where you can bet on races and participate with your horse.");
             if ($gara_ippodromo=='false') {
                 addnav("Visit the Riding-Ground","scuderie.php?op=maneggio");
             } else {
                 output("`n`n`4`cThe groom tells you that because of the next race you can't train horse.`c`0");
             }
             addnav("GoTo Race-Course","ippodromo.php");
             addnav("Back to Village","village.php");
             output("`n`n");
             viewcommentary("Stables","Talk:",10,"says");
             break;
             // end case ""
             // end case ""
       case "maneggio":
             page_header("The Riding-Ground");
             output("The Riding-Ground is full of horses of every shape and size.");
             if (db_num_rows($result)>0){
                 output("`n`n You see {$ref['mountname']} and his groom that is washing him.  You approach your steed and stroke him gently on the neck. You take out a carrot from the pouch and offer it to him. The horse takes the carrot and neighs happily to show his appreciation for you.");
                 valori($ref);

                 $sql = "SELECT * FROM mounts WHERE mountid='{$ref['mountid']}'";
                 $result = db_query($sql);
                 if (db_num_rows($result)<=0){
                         output("`7\"`&Blimey, your horse ran away !`7\" shout the groom!");
                 }else{
                         $mount = db_fetch_assoc($result);
                         $repaygold = round($mount['mountcostgold']*2/3,0);
                         $repaygems = round($mount['mountcostgems']*2/3,0);
                         output("`0`n`nThe groom reminds you that solding him would get you
                                  `^{$repaygold}`0 gold and `%{$repaygems}`0 gems`n");
                 }

             } else {
                 output("`n`n Looking around, you observe other grooms busy taking care of their assigned mounts.");
             }
             if (db_num_rows($result)>0){
                 addnav("Train your Horse","scuderie.php?op=allena");
                 addnav("Take a Ride","scuderie.php?op=passeggia");
                 addnav("Sell your Horse","scuderie.php?op=vendi&id={$ref['mountid']}");
             } else {
                 addnav("Examine a Horse","scuderie.php?op=esamina");
             }
             addnav("","");
             addnav("Back to Stables","scuderie.php");
             addnav("Back to Village","village.php");
             //$session['user']['quest'] += 1;
             break;
             // end case "maneggio"
       case "esamina":
             page_header("The Riding-Ground");
             output("You approach a mount that you know is for sale.");
             $sql = "SELECT mountname,mountid,mountcategory FROM mounts WHERE mountactive=1 AND mountcategory='Horses' ORDER BY mountcategory,mountcostgems,mountcostgold";
             $result = db_query($sql);
             addnav("Back to Riding-Ground","scuderie.php?op=maneggio");
             addnav("Back to Stables","scuderie.php");
             addnav("","");
             for ($i=0;$i<db_num_rows($result);$i++){
                  $row = db_fetch_assoc($result);
                  addnav("Examine {$row['mountname']}`0","scuderie.php?op=esaminacav&id={$row['mountid']}");
             }
             break;
             // end case "esamina"
       case "esaminacav":
             page_header("The Riding-Ground");
             addnav("Back to Riding-Ground","scuderie.php?op=maneggio");
             addnav("Back to Stables","scuderie.php");
             $sql = "SELECT * FROM mounts WHERE mountid='{$_GET['id']}'";
             $result = db_query($sql);
             if (db_num_rows($result)<=0){
                     output("`7\"`&Blimey, we don't have horses like this around here!`7\" shouts the groom!");
             }else{
                     output("`7\"`&Aye, it's nice beast indeed!`7\" comments the groom.`n`n");
                     $mount = db_fetch_assoc($result);
                     output("`7Animal: `&{$mount['mountname']}`n");
                     output("`7Description: `&{$mount['mountdesc']}`n");
                     output("`7Cost: `^{$mount['mountcostgold']}`& Gold Pieces, `%{$mount['mountcostgems']}`& Gems`n");
                     output("`n");
                     addnav("Buy this horse","scuderie.php?op=compra&id={$mount['mountid']}");
             }
             $sql = "SELECT mountname,mountid,mountcategory FROM mounts WHERE mountactive=1 AND mountcategory='Horses' ORDER BY mountcategory,mountcostgems,mountcostgold";
             $result = db_query($sql);
             addnav("","");
             for ($i=0;$i<db_num_rows($result);$i++){
                  $row = db_fetch_assoc($result);
                  addnav("Examine {$row['mountname']}`0","scuderie.php?op=esaminacav&id={$row['mountid']}");
             }
             break;
             // end case "esaminacav"
       case "compra":
             page_header("The Purchase");
             $sql = "SELECT * FROM mounts WHERE mountid='{$_GET['id']}'";
             $result = db_query($sql);
             if (db_num_rows($result)<=0){
                     output("`7\"`&Blimey, we don't have horses like this around here!`7\" shout the groom!!");
             }else{
                     $mount = db_fetch_assoc($result);
                     if (
                             ($session['user']['gold']) < $mount['mountcostgold']
                              ||
                             ($session['user']['gems']) < $mount['mountcostgems']
                     ){
                             output("`7The groom looks at you.  \"`&'Eh, what do you want to do?
                                      To buy {$mount['mountname']} you must give me `^{$mount['mountcostgold']}`& gold
                                      and `%{$mount['mountcostgems']}`& gems, and you don't have enough`7\"");
                     }else{
                             $caratteristiche = 8 + intval($mount[mountid]*2);
                             $sql = "INSERT INTO scuderie
                                        (acctid
                                        ,mountid
                                        ,condizione
                                        ,sprint
                                        ,iscritto
                                ) VALUES (
                                        '$acctid'
                                       ,'$mount[mountid]'
                                       ,'$caratteristiche'
                                       ,'$caratteristiche'
                                       ,'0'
                                )";
                             db_query($sql) or die(db_error(LINK));
                             if (db_affected_rows(LINK)<=0){
                                 output("`\$ERROR`^: Something went wrong buying a horse, try again later.");
                             } else {
                                 output("`7You pay the demand price and the groom gives over to you the reins
                                          of a beautiful `&{$mount['mountname']}`7!`n`n");
                                 $session['user']['gold']-=$mount['mountcostgold'];;
                                 $session['user']['gems']-=$mount['mountcostgems'];
                             }

                             debuglog("has bought a {$mount['mountname']} at the Stables");
                     }
             }
             addnav("Back to Riding-Ground","scuderie.php?op=maneggio");
             addnav("Back to Stables","scuderie.php");
             break;
             // end case "compra"
       case "vendi":
             page_header("The Sell");
             $sql = "SELECT * FROM mounts WHERE mountid='{$_GET['id']}'";
             $result = db_query($sql);
             if (db_num_rows($result)<=0){
                     output("`7\"`&Blimey, we don't have horses like this around here!`7\" shouts the groom!");
             }else{
                if ($ref['iscritto']==1) {
                    output("`7The groom tells you \"`&'Eh, your horse is enrolled for the next race. You should
                             wait for the result before selling him. Maybe he is a winning horse and will change your mind.`7\"");
                } else {
                     $mount = db_fetch_assoc($result);
                     $sql = "DELETE FROM scuderie
                              WHERE acctid = '$acctid'";
                     db_query($sql) or die(db_error(LINK));
                     if (db_affected_rows(LINK)<=0){
                          output("`\$ERROR`^: Something went wrong selling a horse, try again later.");
                     } else {
                          output("`7The groom pays you the requested price and the horse heartbroken, looks at you
                                   all sad like and neighs mournfully");
                          $repaygold = round($mount['mountcostgold']*2/3,0);
                          $repaygems = round($mount['mountcostgems']*2/3,0);
                          $session['user']['gold']+=$repaygold;
                          $session['user']['gems']+=$repaygems;
                     }
                     debuglog("has sold a {$mount['mountname']} at the Stables.");
                     // Recalculate so the selling stuff works right
                }
             }
             addnav("Back to Riding-Ground","scuderie.php?op=maneggio");
             addnav("Back to Stables","scuderie.php");
             break;
             // end case "compra"
       case "allena":
             page_header("The Riding-Ground");
             output("You approach your horse`n");
             $data_oggi = time();
                 $futtercost =intval($session[user][level]*(50+$session[user][dragonkills]+($session[user][level]/2))*0.8);
                 output("`n`0You are aware that training your horse you will cost turns.");
                 output("`n`nThe food today is priced `^$futtercost `0oro");
                 $futtercost += intval($futtercost*0.2);
                 output("`nWashing you horse will cost you `^$futtercost `0gold and TWO turns");
                 valori($ref);
                 output("`#`n`nWhat will you do?");
                 addnav("Feed him","scuderie.php?op=mangiare");
                 addnav("Train him","scuderie.php?op=corsa");
                 addnav("Wash him","scuderie.php?op=lavare");
                 addnav("","");
             addnav("Back to Riding-Ground","scuderie.php?op=maneggio");
             addnav("Back to Stables","scuderie.php");
             break;
             // end case "allena"
       case "mangiare":
             page_header("The Riding-Ground");
             $futtercost =intval($session[user][level]*(50+$session[user][dragonkills]+($session[user][level]/2))*0.8);
             if ($ref['condizione']==100) {
                 output("Your horse is already at full and doesn't need to be feed.");
             } else {
                  if ($session['user']['gold'] < $futtercost || $session[user][turns]<=0){
                      output("You don't have enough ");
                      if ($session['user']['gold'] < $futtercost)
                          output("gold ");
                      else
                          output("turns ");
                      output("to feed your horse");
                  } else {
                      output("You feed your horse and ...");
                      $casomangiare = e_rand(0,6);
                      $bonus = e_rand(1,6);
                      $condizione = intval($ref['condizione']*$bonus/100);
                      if ($condizione>=0 && $condizione<=1) $condizione=1;
                      if ($condizione<=0 && $condizione>=-1) $condizione=-1;
                      switch ($casomangiare) {
                              case 0:
                                   output("`n`n`^The hay is more nourishing then usual !! ");
                                   $condizione += intval($ref['condizione']*0.2);
                                   output("`n`n`2You gain $condizione Condition Point.");
                                   break;
                              case 1:
                                   output("`n`n`^The groom, bribed by your opponent, has fed your horse with a bundle of spiked
                                   horse-grass, that has made your horse {$ref['mountname']}... terribly ill.");
                                   $condizione = intval($condizione*-1);
                                   $condizioneOut = $condizione*-1;
                                   output("`n`n`2You lose $condizioneOut Condition Points.");
                                   break;
                              case 2:
                              case 3:
                              case 4:
                              case 5:
                              case 6:
                                   output("`n`n`^The hay satisfies your horse");
                                   output("`n`n`2You gain $condizione Condition Points.");
                                   break;
                      } // end case $casomangiare
                      if ($condizione>=0 && $condizione<=1) $condizione=1;
                      if ($condizione<=0 && $condizione>=-1) $condizione=-1;
                      $ref['condizione'] += intval($condizione);
                      if ($ref['condizione']>=100) $ref['condizione'] = 100;
                      if ($ref['condizione']<=0) $ref['condizione'] = 1;
                      updatepet($ref,$acctid,"condizione");
                      if (db_affected_rows(LINK)<=0){
                          output("`n`n`\$Error`^: Something went wrong training your horse, try again later");
                      } else {
                          output("`n`n`0Now your horse has {$ref['condizione']} Condition.");
                          $session[user][turns]--;
                          $session['user']['gold']-=$futtercost;
                      }
                  }
             }
             addnav("Train horse","scuderie.php?op=allena");
             addnav("","");
             addnav("Back to Riding-Ground","scuderie.php?op=maneggio");
             addnav("Back to Stables","scuderie.php");
             break;
             // end case "mangiare"
       case "corsa":
             page_header("The Riding-Ground");
             if ($ref['sprint']==100) {
                 output("Your horse's sprint is already perfect, he doesn't need any training session.");
             } else {
                  if ($session[user][turns]<=0){
                      output("You don't have enough turns to train your horse");
                  } else {
                      output("You train your horse and...");
                      $casosprint = e_rand(0,5);
                      $bonus = e_rand(1,6);
                      $sprint = intval($ref['sprint']*$bonus/100);
                      if ($sprint>=0 && $sprint<=1) $sprint=1;
                      if ($sprint<=0 && $sprint>=-1) $sprint=-1;
                      switch ($casosprint) {
                              case 0:
                                   output("`n`n`^Today he's very responsive and follow your commands !! ");
                                   $sprint += intval($ref['sprint']*0.2);
                                   output("`n`n`2You gain $sprint Sprint Points.");
                                   break;
                              case 1:
                                   output("`n`n`^Your horse gets out of control and you can't ride him !! ");
                                   $sprint = intval($sprint*-1);
                                   $sprintOut = $sprint*-1;
                                   output("`n`n`2You lose $sprintOut Sprint Points.");
                                   break;
                              case 2:
                              case 3:
                              case 4:
                              case 5:
                              case 6:
                                   output("`n`n`^You do a good job training your horse.");
                                   output("`n`n`2You gain $sprint Sprint Points.");
                                   break;
                      } // end case $casosprint
                      if ($sprint>=0 && $sprint<=1) $sprint=1;
                      if ($sprint<=0 && $sprint>=-1) $sprint=-1;
                      $ref['sprint'] += intval($sprint);
                      if ($ref['sprint']>=100) $ref['sprint'] = 100;
                      if ($ref['sprint']<=0) $ref['sprint'] = 1;
                      updatepet($ref,$acctid,"sprint");
                      if (db_affected_rows(LINK)<=0){
                          output("`n`n`\$Error`^: Something went wrong while you were training your horse, try again later.");
                      } else {
                          output("`n`n`0Right now the sprint of your horse is $ref[sprint]");
                          $session[user][turns]--;
                      }
                  }
             }
             addnav("Train your horse","scuderie.php?op=allena");
             addnav("","");
             addnav("Back to Riding-Ground","scuderie.php?op=maneggio");
             addnav("Back to Stables","scuderie.php");
             break;
             // end case "corsa"
       case "lavare":
             page_header("Horse Wash");
             $futtercost = intval($session[user][level]*(50+$session[user][dragonkills]+($session[user][level]/2))*0.8);
             $futtercost += intval($futtercost*0.2);
             if ($ref['condizione']==100 && $ref['sprint']==100) {
                 output("You notice that your horse is cleaner then you!!");
             } else {
                  if ($session['user']['gold'] < $futtercost || $session[user][turns]<=1){
                      output("You don't have enough ");
                      if ($session['user']['gold'] < $futtercost)
                          output("gold ");
                      else
                          output("turns ");
                      output("to wash your mount.");
                  } else {
                      output("You wash your horse and...");
                      $casolavare = e_rand(0,6);
                      $bonus = e_rand(1,3);
                      $condizione = intval($ref['condizione']*$bonus/100);
                      $sprint = intval($ref['sprint']*$bonus/100);
                      if ($condizione>=0 && $condizione<=1) $condizione=1;
                      if ($condizione<=0 && $condizione>=-1) $condizione=-1;
                      if ($sprint>=0 && $sprint<=1) $sprint=1;
                      if ($sprint<=0 && $sprint>=-1) $sprint=-1;
                      $operazionePet = "";
                      switch ($casolavare) {
                              case 0:
                                   output("`n`n`^You use a special cleaning product, courtesy of Merick, and your horse gains Speed and Conditioning!! ");
                                   if ($ref['condizione'] < 100) {
                                       $condizione += intval($ref['condizione']*0.2);
                                       $operazionePet = $operazionePet."condizione";
                                       output("`n`n`2You gain $condizione Condition Points.");
                                   }
                                   if ($ref['sprint'] < 100) {
                                       $sprint += intval($ref['sprint']*0.2);
                                       $operazionePet = $operazionePet."sprint";
                                       output("`n`n`2You gain $sprint Sprint Points.");
                                   }
                                   break;
                              case 1:
                                   output("`n`n`^After washing him, your horse runs through a mud puddle and is now more dirty then before!! ");
                                   if ($ref['condizione'] > 1) {
                                       $condizione = intval($condizione * -1);
                                       $condizioneOut = $condizione*-1;
                                       output("`n`n`2You lose $condizioneOut Condition Points.");
                                       $operazionePet = $operazionePet."condizione";
                                   }
                                   if ($ref['sprint'] > 1) {
                                       $sprint = intval($sprint * -1);
                                       $sprintOut = $sprint*-1;
                                       output("`n`n`2You lose $sprintOut Sprint Points.");
                                       $operazionePet = $operazionePet."sprint";
                                   }
                                   break;
                              case 2:
                              case 3:
                              case 4:
                              case 5:
                              case 6:
                                   output("`n`n`^You wash your horse, doing a good job.");
                                   if ($ref['condizione'] < 100) {
                                       output("`n`n`2You gain $condizione Condition Points.");
                                       $operazionePet = $operazionePet."condizione";
                                   }
                                   if ($ref['sprint'] < 100) {
                                       output("`n`n`2You gain $sprint Sprint Points.");
                                       $operazionePet = $operazionePet."sprint";
                                   }
                                   break;
                      } // end case $casolavare
                      if ($condizione>=0 && $condizione<=1) $condizione=1;
                      if ($condizione<=0 && $condizione>=-1) $condizione=-1;
                      if ($sprint>=0 && $sprint<=1) $sprint=1;
                      if ($sprint<=0 && $sprint>=-1) $sprint=-1;
                      $ref['condizione'] += intval($condizione);
                      $ref['sprint'] += intval($sprint);
                      if ($ref['condizione']>=100) $ref['condizione'] = 100;
                      if ($ref['sprint']>=100) $ref['sprint'] = 100;
                      if ($ref['condizione']<=0) $ref['condizione'] = 1;
                      if ($ref['sprint']<=0) $ref['sprint'] = 1;
                      updatepet($ref,$acctid,$operazionePet);
                      if (db_affected_rows(LINK)<=0){
                          output("`n`n`\$Error`^: Something went wrong while you were training your horse, try again later.");
                      } else {
                          output("`n`n`0Right now the Condition of your horse is  $ref[condizione]");
                          output("`n`0And the Sprint of your horse is $ref[sprint]");
                          $session[user][turns]-=2;
                          $session['user']['gold']-=$futtercost;
                      }
                  }
             }
             addnav("Train your horse","scuderie.php?op=allena");
             addnav("","");
             addnav("Back to Riding-Ground","scuderie.php?op=maneggio");
             addnav("Back to Stables","scuderie.php");
             break;
             // end case "lavare"
       case "passeggia":
             page_header("The Promenade");
             if ($session[user][turns]>0) {
                 output("You take your horse out for a stroll, walking him around the track.`n");
                 $passeggiata = e_rand(0,9);
                 switch ($passeggiata) {
                         case 0:
                         case 5:
                              output("`^`nYou relax yourself and your wounds get healed.");
                              $session[user][hitpoints]=$session[user][maxhitpoints];
                              $session[user][turns]--;
                              break;
                         case 1:
                         case 6:
                              if ($ref['sprint']==100) {
                                  output("`^`nYou relax and your wounds get healed.`n");
                                  output("At the same time the sprint of your horse improves!!`n");
                                  $session[user][hitpoints]=$session[user][maxhitpoints];
                                  $session[user][turns]--;
                              } else {
                                  output("`^`nYou exercise your mighty steed and his sprint is improved.");
                                  $bonus = e_rand(1,6);
                                  $sprint = intval($ref['sprint']*$bonus/100);
                                  if ($sprint>=0 && $sprint<=1) $sprint=1;
                                  output("`n`n`2Guadagni $sprint Punti Sprint.");
                                  $ref['sprint'] += intval($sprint);
                                  if ($ref['sprint']>=100) $ref['sprint'] = 100;
                                  updatepet($ref,$acctid,"sprint");
                                  if (db_affected_rows(LINK)<=0){
                                      output("`n`n`\$Error`^: Something went wrong while you were exercising your horse, try again later.");
                                  } else {
                                      output("`n`n`0Your horse's Condition is $ref[condizione]");
                                      output("`n`0Right now your horse's Sprint is $ref[sprint]");
                                      $session[user][turns]--;
                                  }
                              }
                              break;
                         case 2:
                         case 7:
                              if ($ref['condizione']==100) {
                                  output("`^`nYou relax and your wounds get healed.");
                                  $session[user][hitpoints]=$session[user][maxhitpoints];
                                  $session[user][turns]--;
                              } else {
                                  output("`^`nYou exercise your mighty steed and his sprint is improved.");
                                  $bonus = e_rand(1,6);
                                  $condizione = intval($ref['condizione']*$bonus/100);
                                  if ($condizione>=0 && $condizione<=1) $condizione=1;
                                  output("`n`n`2You gain $condizione Condition Points.");
                                  $ref['condizione'] += intval($condizione);
                                  if ($ref['condizione']>=100) $ref['condizione'] = 100;
                                  updatepet($ref,$acctid,"condizione");
                                  if (db_affected_rows(LINK)<=0){
                                      output("`n`n`\$Error`^: Something went wrong while you were exercising your horse, try again later.");
                                  } else {
                                      output("`n`n`0Your horse's Condition is $ref[condizione]");
                                      output("`n`0Right now your horse's Sprint is $ref[sprint]");
                                      $session[user][turns]--;
                                  }
                              }
                              break;
                         case 3:
                         case 8:
                              if ($ref['sprint']==0) {
                                  output("`^`nYou relax and your wounds get healed.");
                                  $session[user][hitpoints]=$session[user][maxhitpoints];
                                  $session[user][turns]--;
                              } else {
                                  output("`^`nUnfortunately while running your horse he gets injured and lose some speed.");
                                  $bonus = e_rand(1,6);
                                  $sprint = intval($ref['sprint']*$bonus/100);
                                  if ($sprint>=0 && $sprint<=1) $sprint=1;
                                  output("`n`n`2You lose $sprint Sprint Points.");
                                  $ref['sprint'] -= intval($sprint);
                                  if ($ref['sprint']<=0) $ref['sprint'] = 1;
                                  updatepet($ref,$acctid,"sprint");
                                  if (db_affected_rows(LINK)<=0){
                                      output("`n`n`\$Error`^: Something went wrong while you were exercising your horse, try again later.");
                                  } else {
                                      output("`n`n`0Your horse's Condition is $ref[condizione]");
                                      output("`n`0Right now your horse's Sprint is $ref[sprint]");
                                      $session[user][turns]--;
                                  }
                              }
                              break;
                         case 4:
                         case 9:
                              if ($ref['condizione']==0) {
                                  output("`^`nYou relax and your wounds get healed.");
                                  $session[user][hitpoints]=$session[user][maxhitpoints];
                                  $session[user][turns]--;
                              } else {
                                  output("`^`nUnfortunately while running your horse he gets injured and loses some  conditioning.");
                                  $bonus = e_rand(1,6);
                                  $condizione = intval($ref['condizione']*$bonus/100);
                                  if ($condizione>=0 && $condizione<=1) $condizione=1;
                                  output("`n`n`2You lose $condizione Sprint Points.");
                                  $ref['condizione'] -= intval($condizione);
                                  if ($ref['condizione']<=0) $ref['condizione'] = 1;
                                  updatepet($ref,$acctid,"condizione");
                                  if (db_affected_rows(LINK)<=0){
                                      output("`n`n`\$Error`^: Something went wrong while you were exercising your horse, try again later.");
                                  } else {
                                      output("`n`n`0Your horse's Condition is $ref[condizione]");
                                      output("`n`0Right now your horse's Sprint is $ref[sprint]");
                                      $session[user][turns]--;
                                  }
                              }
                              break;
                 }
                 // end switch($passeggiata)
             } else {
                 output("You don't have enough turns to exercise with your horse.");
             }
             addnav("Back to Riding-Ground","scuderie.php?op=maneggio");
             addnav("Back to Stables","scuderie.php");
             break;
             // end case "passeggia"

//------------------------------------------------
}
//I cannot make you keep this line here but would appreciate it left in.
rawoutput("<br><div style=\"text-align: right ;\"><a href=\"http://www.ogsi.it\" target=\"_blank\"><font color=\"#33FF33\">Race Course by Excalibur @ http://www.ogsi.it</font></a><br>");

page_footer();
?>