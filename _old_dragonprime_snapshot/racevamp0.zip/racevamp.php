<?php
// translator ready
// addnews ready
// mail ready

// V1.01 -- moved the check for enough points to be consistent with other
//          modules for the lodge.

function racevamp_getmoduleinfo(){
	$info = array(
		"name"=>"Race - Vampire",
		"version"=>"0.01",
		"author"=>"Webb, based on Stormgiant by Chris Vorndran",
		"category"=>"Races",
		"download"=>"core_module",
		"requires"=>array(
			"racedwarf"=>"1.0|By Eric Stevens,part of core download",
		),
		"settings"=>array(
			"Vampire Race Settings,title",
			"minedeathchance"=>"Percent chance for a Vampire to die in the mine,range,0,100,1|10",
			"cost"=>"Cost of Race in Lodge Points,int|100",
		),
		"prefs"=>array(
			"Vampire Preferences,title",
			"bought"=>"Has Vampire race been bought,bool|0",
		)
	);
	return $info;
}

function racevamp_install(){
	module_addhook("chooserace");
	module_addhook("setrace");
	module_addhook("newday");
	module_addhook("charstats");
	module_addhook("raceminedeath");
	module_addhook("pvpadjust");
	module_addhook("adjuststats");
	module_addhook("pointsdesc");
	module_addhook("lodge");
	module_addhook("racenames");
	module_addhook("battle-victory");
	module_addhook("battle-defeat");
	return true;
}

function racevamp_uninstall(){
	global $session;
	$sql = "UPDATE  " . db_prefix("accounts") . " SET race='" . RACE_UNKNOWN . "' WHERE race='Vampire'";
	db_query($sql);
	if ($session['user']['race'] == 'Vampire')
		$session['user']['race'] = RACE_UNKNOWN;
	return true;
}

function racevamp_dohook($hookname,$args){
	global $session,$resline;

	if (is_module_active("racedwarf")) {
		$city = get_module_setting("villagename", "racedwarf");
	} else {
		$city = getsetting("villagename", LOCATION_FIELDS);
	}
	$race = "Vampire";
	$cost = get_module_setting("cost");
	$bought = get_module_pref("bought");
	switch($hookname){
	case "racenames":
		$args[$race] = $race;
		break;
	case "pointsdesc":
		$args['count']++;
		$format = $args['format'];
		$str = translate("The race: Vampire; The Evil, Blood Thirsty Monsters.  This costs %s points");
		$str = sprintf($str, $cost);
		output($format, $str, true);
		break;
	case "pvpadjust":
		if ($args['race'] == $race) {
			apply_buff("targetracialbenefit",array(
				"name"=>"",
				"minioncount"=>1,
				"mingoodguydamage"=>0,
				"maxgoodguydamage"=>3+ceil($args['creaturelevel']/2),
				"effectmsg"=>"`#{badguy} `#Drains Your Life For `\${damage}`# damage.",
				"effectnodmgmsg"=>"`#{badguy} Throws you off And trys to Hit you,`# but it `\$MISSES`)!",
				"allowinpvp"=>1,
				"rounds"=>-1,
				"schema"=>"module-racevamp",
				)
			);
			$args['creaturedefense']+=(2+floor($args['creaturelevel']/3));
		}
		break;
	case "adjuststats":
		if ($args['race'] == $race) {
			$args['defense']+=(2+floor($args['level']/3));
		}
		break;
	case "battle-victory":
	case "battle-defeat":
		if ($args['type'] == 'pvp') {
			strip_buff("targetracialbenefit");
		}
		break;
	case "raceminedeath":
		if ($session['user']['race'] == $race) {
			$args['chance'] = get_module_setting("minedeathchance");
			$args['racesave'] = "The huge amout of health your drained, allows you to escape unharmed.`n";
			$args['schema']="module-racestorm";
		}
		break;
	case "charstats":
		if ($session['user']['race']==$race){
			addcharstat("Vital Info");
			addcharstat("Race", translate_inline($race));
		}
		break;
	case "chooserace":
		if ($bought == 1){
		output("<a href='newday.php?setrace=$race$resline'>In The Dark Caves Of %s</a>, the Place of Vampires, your race of `#Vampire `3Is dwelling in the caverns.",$city, true);
		output("Vampire's Are Masters Of HP, and many fear them.`n`n");
		addnav("`^Vampire`0","newday.php?setrace=$race$resline");
		addnav("","newday.php?setrace=$race$resline");
		}
		break;
	case "lodge":
		if (!$bought) {
			addnav(array("Acquire Vampire's Teeth (%s points)",$cost),
					"runmodule.php?module=racevamp&op=start");
		}
		break;
	case "setrace":
		if ($session['user']['race']==$race){
			output("`#Vampire `3are known for their amazing ability to drain HP, and their mastership over land masses.`n");
			output("`3You Attach your teeth and step it into battle!`n");
			if (is_module_active("cities")) {
				if ($session['user']['dragonkills']==0 &&
						$session['user']['age']==0){
					set_module_setting("newest-$city",
							$session['user']['acctid'],"cities");
				}
				set_module_pref("homecity",$city,"cities");
				if ($session['user']['age'] == 0)
					$session['user']['location']=$city;
			}
		}
		break;
	case "newday":
		if ($session['user']['race']==$race){
			racevamp_checkcity();
			apply_buff("racialbenefit",array(
				"name"=>"`#Vampire's Blood`0",
				"minioncount"=>1,
				"minbadguydamage"=>0,
				"maxbadguydamage"=>"3+ceil(<level>/2)",
				"effectmsg"=>"`#You drain {badguy}`# for `^{damage}`# damage.",
				"effectnodmgmsg"=>"`#You walk towards {badguy},`# But He Runs `\$MISSES`)!",
				"defmod"=>"(<defense>?(1+((2+floor(<level>/3))/<defense>)):0)",
				"allowinpvp"=>1,
				"allowintrain"=>1,
				"rounds"=>-1,
				"schema"=>"module-racevamp",
				)
			);
		}
		break;
	}

	return $args;
}

function racevamp_checkcity(){
	global $session;
	$race = "Vampire";
	if (is_module_active("racedwarf")) {
		$city = get_module_setting("villagename", "racedwarf");
	} else {
		$city = getsetting("villagename", LOCATION_FIELDS);
	}
	
	if ($session['user']['race']==$race && is_module_active("cities")){
		if (get_module_pref("homecity","cities")!=$city){
			set_module_pref("homecity",$city,"cities");
		}
	}	
	return true;
}

function racevamp_run(){
	global $session;
	page_header("Hunter's Lodge");
	$race = 'Vampire';
	$cost = get_module_setting("cost");
	$bought = get_module_pref("bought");
	$op = httpget('op');

	switch ($op){
		case "start":
			$pointsavailable = $session['user']['donation'] -
			$session['user']['donationspent'];
			if ($pointsavailable >= $cost && $bought == 0){
				output("`3J. C. Petersen looks upon you with a caustic grin.`n`n");
				output("\"`\$So, you wish to purchase the `^Vampire's Teeth`\$?`3\" he says with a smile.");
				addnav("Choices");
				addnav("Yes","runmodule.php?module=racevamp&op=yes");
				addnav("No","runmodule.php?module=racevamp&op=no");
			} else {
				output("`3J. C. Petersen stares at you for a moment then looks away as you realize that you don't have enough points to purchase this item.");
			}
			break;
		case "yes":
			output("`3J. C. Petersen hands you 2 Teeth, with a cold crimson liquid o it.`n`n");
			output("\"`\$That is `^Vampire's Teeth`\$.");
			output("Now, Remove Yours And Insert The Vampire's!`3\"`n`n");
			output("You double over, spasming on the ground.");
			output("J. C. Petersen grins, \"`\$Your body shall finish its change upon newday... I suggest you rest.`3\"");
			$session['user']['race'] = $race;
			$session['user']['donationspent'] += $cost;
			set_module_pref("bought",1);
			break;
		case "no":
			output("`3J. C. Petersen looks at you and shakes his head.");
			output("\"`\$I swear to you, this stuff is top notch.");
			output("This isn't like the crud that `%Cedrik `\$is selling.`3\"");
			break;
	}
	addnav("Return");
	addnav("L?Return to the Lodge","lodge.php");
	page_footer();
}	
?>
