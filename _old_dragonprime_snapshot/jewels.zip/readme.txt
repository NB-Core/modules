Jewels By Kiara
Version 1.0

Based on Mystie's Sweet Shoppe by Chris Vorndran
Edited by Cassandra at RPGSL
Modified by RPGSL

Download: http://rpgsl.com/lotgd/jewels.zip
Mirror: http://rpdragon.com/lotgd/jewels.zip

Game: http://rpdragon.com


Installation

1) Copy jewels.php into your LotGD modules folder
2) Log in to LotGD with your admin account
3) Enter the Superuser Grotto
4) Click Manage Modules
5) Install jewels.php (Jewels by Kiara)
6) Configure settings and save
7) Activate

-------------------------------------------------
Questions/Comments?

alex@rpgsl.com
-------------------------------------------------

Visit www.rpgsl.com today for your RPG needs.