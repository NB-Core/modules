<?php
require_once("lib/villagenav.php");
require_once("lib/http.php");
require_once("lib/commentary.php");
function jewels_getmoduleinfo()
{
	$info = array
	(
  		"name"=>"Jewels By Kiara",
  		"author"=>"`@Cassandra & `^RPGSL - based on Mystie's Sweet Shop by Chris Vorndran",
  		"version"=>"1.0",
  		"category"=>"Village",
  		"download"=>"http://rpdragon.com/lotgd/jewels.zip",
  		"vertxtloc"=>"http://rpdragon.com",		
  		"settings"=>array
  		(
  			"Jewels By Kiara Settings,title",
  			"times"=>"How many times per day,int|3",
  			"hital"=>"How many times to pour,int|5",
  			"stopq"=>"Does the stopper exist,bool|0",
  			"Jewels By Kiara Pricing,title",
			"pearlcost"=>"How much do pearls cost in gold,int|100",
			"emercost"=>"How much do emeralds  cost in gold,int|100",
			"rubycost"=>"How much does a ruby cost in gold,int|200",
			"saphcost"=>"How much does a sapphire cost in gold,int|300",
			"opalcost"=>"How much does a opal cost in gold,int|300",
			"diacost"=>"How much does a diamond cost in gold,int|400",
//DAHZL
			"hitpointsmod"=>"Divide the cost by how much to add that many hit points to the reward,int|50",
			"turnsmod"=>"Divide the hit points mod above by how much to add that many turns to the reward,int|2",
			"gemsmod"=>"Divide the hit points mod above by how much to add that many gems to the reward,int|4",
			"rewardmod"=>"Reward Mod Variable (changing this here is not important),hidden|1",
//END
			"Jewels By Kiara Location,title",
			"jewelsloc"=>"Where does Jewels appear,location|".getsetting("villagename", LOCATION_FIELDS)
		),
		"prefs"=>array
		(
			"Jewels By Kiara Preferences,title",
			"hit"=>"How many times have hit,int|0",
			"used"=>"How many times been used,int|0",
			"stopped"=>"Has stopper been activated,bool|0",
			"stop"=>"How many days left for stopper,range,0,3,1|0",
			"event"=>"Event Message,text|",
		)
	);
	return $info;
}
function jewels_install()
{
	module_addhook("moderate");
	module_addhook("changesetting");
	module_addhook("village");
	module_addhook("newday");
	module_addhook("everyhit");
	return true;
}
function jewels_uninstall()
{
	return true;
}
function jewels_dohook($hookname,$args)
{
	global $session;
	$menu = array(1=>"`)Pearls",2=>"`@Emeralds",3=>"`4Rubies",4=>"`1Sapphires",5=>"`7Opals",6=>"`&Diamonds");
	$stopped = get_module_pref("stopped");
	$stop = get_module_pref("stop");
	$stopq = get_module_setting("stopq");
	$rand = e_rand(1,6);
	$countersel = $counter[$rand];
	switch ($hookname)
	{
		case "changesetting":
			if ($args['setting'] == "villagename")
			{
				if ($args['old'] == get_module_setting("jewelsloc"))
				{
					set_module_setting("jewelsloc", $args['new']);
       			}
    		}
			break;
		case "moderate":
			$args['jewelstalk'] = "Jewel Shoppe";
			break;
		case "village":
			if ($session['user']['location'] == get_module_setting("jewelsloc"))
			{
				tlschema($args['schemas']['marketnav']);
				addnav($args['marketnav']);
				tlschema();
				addnav("Jewels By Kiara","runmodule.php?module=jewels&op=enter");
			}
    	    break;
		case "newday":
			if ($stopq==1)
			{
				if ($stopped==1)
				{
					$stop--;
					set_module_pref("stop",$stop);
					if ($stop>0)
					{
						output("`nYou still feel the glint of the gems in your eyes, and do not wish to choke on one...");
						output(" A druid tells you, that you can go back in %s %s.`n",$stop,translate_inline($stop==1?"day":"days"));
					}
	  				if ($stop==0)
	  				{
						output("`nThe awe of having the jewels from Kiara's has finally warn off leaving you wanting for more.%s.`n",$menusel);
						set_module_pref("stopped",0);
					}
				}
			}
			set_module_pref("used",0);
			set_module_pref("hit",0);
			break;
		case "everyhit":
			if (get_module_pref('event') <> "")
			{
				$message=get_module_pref('event');
				output("`4`c`bSpecial Event: %s`b`c`7`n`n",$message);
				set_module_pref('event',"");
			}
	}
	return $args;
}
function jewels_run()
{
	global $session;
	$times = get_module_setting("times");
	$used = get_module_pref("used");
	$pearlcost = get_module_setting("pearlcost");
	$emercost = get_module_setting("emercost");
	$diacost = get_module_setting("diacost");
	$saphcost = get_module_setting("saphcost");
	$opalcost = get_module_setting("opalcost");
	$rubycost = get_module_setting("rubycost");
	$hital = get_module_setting("hital");
	$hit = get_module_pref("hit");
	$stopped = get_module_pref("stopped");
	$theygold = $session['user']['gold'];
	$op = httpget("op");
//DAHZL	
	$hitpointsmod = get_module_setting("hitpointsmod");
//END
	page_header("Jewels By Kiara");
	if($op=="enter")
	{
		output("A bell rings on the shop door as you step in to investigate this new establishment.");
		output(" The sparkles of all the beautiful jewels catch your attention as you are greeted with a rather melodic voice..");
		output(" You turn to see a woman, of goddess like beauty.");
		output(" She smiles brightly, \"Dark tidings I am Kiara!");
		output(" Which of my beautiful jewels catch your attention today?\"`n`n");
		output("`3Counter:`n");
		output("`)Pearls: `^%s gold`n",$pearlcost);
		output("`@Emeralds: `^%s gold`n",$emercost);
		output("`4Rubies: `^%s gold`n",$rubycost);
		output("`1Sapphires: `^%s gold`n",$saphcost);
		output("`7Opals: `^%s gold`n",$opalcost);
		output("`&Diamonds: `^%s gold`n",$diacost);
		if($used<$times)
		{
			addnav("Back to the counter");
			if ($theygold>=$pearlcost) addnav("Pearls","runmodule.php?module=jewels&op=pearls");
			if ($theygold>=$emercost) addnav("Emeralds","runmodule.php?module=jewels&op=emeralds");
			if ($theygold>=$diacost) addnav("Diamonds","runmodule.php?module=jewels&op=diamond");
			if ($theygold>=$saphcost) addnav("Sapphires","runmodule.php?module=jewels&op=sapphire");
			if ($theygold>=$rubycost) addnav("Rubies","runmodule.php?module=jewels&op=ruby");
			if ($theygold>=$opalcost) addnav("Opals","runmodule.php?module=jewels&op=opal");
		}
		if ($hit<$hital)
		{
			addnav("Cause Some Mischief","runmodule.php?module=jewels&op=hit");
		}
		addnav("Other Fun Stuff");
		addnav("Talk Amongst Others","runmodule.php?module=jewels&op=talk");
		addnav("Leave");
		villagenav();
	}
 	elseif ($op=="pearls")
 	{
		output("Kiara pulls out your pearls and hands them to you with a smile telling you to come back and visit another time.");
//DAHZL
		$rewardmod = intval($pearlcost/$hitpointsmod);
		set_module_setting("rewardmod",$rewardmod);
//END
		jewels_generator();
		$session['user']['gold']-=$pearlcost;
		$used++;
		set_module_pref("used",$used);
		if ($used<$times)
		{
			addnav("Return to the counter","runmodule.php?module=jewels&op=enter");
		}
		villagenav();
	}
	elseif($op=="emeralds")
	{
		output("Kiara pulls out your emeralds and hands them to you with a smile telling you to come back and visit another time.");
//DAHZL
		$rewardmod = intval($emercost/$hitpointsmod);
		set_module_setting("rewardmod",$rewardmod);
//END	
		jewels_generator();
		$session['user']['gold']-=$emercost;
		$used++;
		set_module_pref("used",$used);
		if ($used<$times)
		{
			addnav("Return to the counter","runmodule.php?module=jewels&op=enter");
		}
		villagenav();
	}
	elseif($op=="diamond")
	{
		output("Kiara pulls out your diamond and hands it to you with a smile telling you to come back and visit another time.");
//DAHZL
		$rewardmod = intval($diacost/$hitpointsmod);
		set_module_setting("rewardmod",$rewardmod);
//END
		jewels_generator();
		$session['user']['gold']-=$diacost;
		$used++;
		set_module_pref("used",$used);
		if ($used<$times)
		{
			addnav("Return to the counter","runmodule.php?module=jewels&op=enter");
		}
		villagenav();
	}
	elseif($op=="ruby")
	{
		output("Kiara pulls out your ruby and hands it to you with a smile telling you to come back and visit another time.");
//DAHZL
		$rewardmod = intval($rubycost/$hitpointsmod);
		set_module_setting("rewardmod",$rewardmod);
//END
		jewels_generator();
		$session['user']['gold']-=$rubycost;
		$used++;
		set_module_pref("used",$used);
		if ($used<$times)
		{
			addnav("Return to the counter","runmodule.php?module=jewels&op=enter");
		}
		villagenav();
	}
	elseif($op=="sapphire")
	{
		output("Kiara pulls out your sapphire and hands it to you with a smile telling you to come back and visit another time.");
//DAHZL
		$rewardmod = intval($saphcost/$hitpointsmod);
		set_module_setting("rewardmod",$rewardmod);
//END
		jewels_generator();
		$session['user']['gold']-=$saphcost;
		$used++;
		set_module_pref("used",$used);
		if ($used<$times)
		{
			addnav("Return to the Counter","runmodule.php?module=jewels&op=enter");
		}
		villagenav();
	}
	elseif($op=="opal")
	{
		output("Kiara pulls out your opal and hands it to you with a smile telling you to come back and visit another time.");
//DAHZL
		$rewardmod = intval($opalcost/$hitpointsmod);
		set_module_setting("rewardmod",$rewardmod);
//END
		jewels_generator();
		$session['user']['gold']-=$opalcost;
		$used++;
		set_module_pref("used",$used);
		if ($used<$times)
		{
			addnav("Return to the Counter","runmodule.php?module=jewels&op=enter");
		}
		villagenav();
	}
	elseif($op=="talk")
	{
		output("You enter a adjoining room off the jewel shop, and others seem to be sitting and comparing their beautiful jewels.`n`n"); 
		addcommentary();
		viewcommentary("jeweltalk","Talking Amongst Others",25,"says in awe");
		addnav("Return to the counter","runmodule.php?module=jewels&op=enter");
		villagenav();
	}
	elseif($op=="hit")
	{
  		$water="1";
  		output("`7You slip into a private room unseen and notice several bottles of diamond dust on the table.`7.");
		output(" A small grin peeks across your lips, as you hoist one of the bottles up.");
		if ($used<$times)
		{
			addnav("Return to the counter","runmodule.php?module=jewels&op=enter");
		}
		output("`7You also see standing below.`n");
		$sql = "SELECT acctid,location,name,loggedin,laston FROM ".db_prefix("accounts")."";
		$result = db_query($sql);
		for ($i=0;$i<db_num_rows($result);$i++)
		{
			$row = db_fetch_assoc($result);
			if ($row['location']==$session['user']['location'] and $row['acctid'] <> $session['user']['acctid'] and $row['loggedin']==1 AND $row['laston'] > date("Y-m-d H:i:s",strtotime("-".getsetting("LOGINTIMEOUT",300)." seconds")))
			{
				$inchat = $row['name'];
				if ($inchat <> "")
				{
					$water=1;
				}
				output("%s`7..`6",$inchat); 
			} 
		}
		villagenav();
		addnav("Dump diamond dust on people","runmodule.php?module=jewels&op=hit2");
	}
	elseif($op=="hit2")
	{
		$hit++;
		set_module_pref("hit",$hit);
		if ($used<$times)
		{
			addnav("Return to the counter","runmodule.php?module=jewels&op=enter");
		}
		villagenav();
		$sql = "SELECT login,acctid,location,name,loggedin,laston FROM ".db_prefix("accounts")." WHERE acctid <> ".$session['user']['acctid']." ORDER BY RAND(".e_rand().")";
		output("You hit....");
		$name=$session['user']['name'];
		$result = db_query($sql);
		for ($i=0;$i<db_num_rows($result);$i++)
		{
			$row = db_fetch_assoc($result);
			if (get_module_pref('event','jewels',$row['acctid']) == "" AND $row['location']==$session['user']['location'] and $row['acctid'] <> $session['user']['acctid'] AND $row['loggedin']==1 AND $row['laston'] > date("Y-m-d H:i:s",strtotime("-".getsetting("LOGINTIMEOUT",300)." seconds")))
			{
				$inchat = $row['name'];
				if ($inchat <> "")
				{
					addnews("%s `3dumped `&diamond dust `3from Jewels By Kiara on %s!",$name,$inchat);
					$message="\"";
					$message.="`7You have been covered in `&Diamond Dust`7! ";
					$message.=$name;
					$message.="`7  dumped `&Diamond Dust `7on you from Jewels By Kiara.\"";
					set_module_pref('event',$message,'jewels',$row['acctid']);
					$water=1;
				}
				output("%s`7..`6",$inchat); 
				$inchat = "";
				if ($water == 1)
				{
					$i=db_num_rows($result)+1;
				}
			}
		}
		if ($water <> 1)
		{
			output("no one!  You missed!");
		}
	}
	page_footer();
}
function jewels_generator()
{
	global $session;
	$stopped = get_module_pref("stopped");
	$stopq = get_module_setting("stopq");
	$stopday = e_rand(2,4);
//DAHZL
	$turnsmod = get_module_setting("turnsmod");
	$gemsmod = get_module_setting("gemsmod");
	$rewardmod = get_module_setting("rewardmod");
	$rewardmodturns = intval($rewardmod/$turnsmod);
	$rewardmodgems = intval($rewardmod/$gemsmod);
//END
	if ($stopped==0)
	{
		switch (e_rand(1,15))
		{
			case 1:
				output("You picked up your jewels and pocket them and gain `^%s hitpoints.", $rewardmod+5);
				$session['user']['hitpoints']+=$rewardmod+5;
				break;
			case 2:
				output("You picked up your jewels and pocket them and gain `^%s hitpoints.", $rewardmod+10);
				$session['user']['hitpoints']+=$rewardmod+10;
				break;
			case 3:
				output("You picked up your jewels and pocket them and gain  `^%s hitpoints.", $rewardmod+15);
				$session['user']['hitpoints']+=$rewardmod+15;
				break;
			case 4:
				output("You picked up your jewels and pocket them and gain  `^%s hitpoints.", $rewardmod+20);
				$session['user']['hitpoints']+=$rewardmod+20;
				break;
			case 5:
				output("You picked up your jewels and pocket them and gain  `^%s hitpoints.", $rewardmod+25);
				$session['user']['hitpoints']+=$rewardmod+25;
				break;
			case 6:
				output("The exhilaration of owning such exquisite jewels makes you want to fight more.");
				output(" You gain `^%s turn.", $rewardmodturns+1);
				$session['user']['turns']+=$rewardmodturns+1;
				break;
			case 7:
				output("The exhilaration of owning such exquisite jewels makes you want to fight more.");
				output(" You gain `^%s turns.", $rewardmodturns+2);
				$session['user']['turns']+=$rewardmodturns+2;
				break;
			case 8:
				output("The exhilaration of owning such exquisite jewels makes you want to fight more.");
				output(" You gain `^%s turns.", $rewardmodturns+3);
				$session['user']['turns']+=$rewardmodturns+3;
				if ($stopq==1)
				{
					set_module_pref("stopped",1);
					set_module_pref("stop",$stopday);
				}
				break;
			case 9:
				output("The exhilaration of owning such exquisite jewels makes you want to fight more.");
				output(" You gain `^%s turns.", $rewardmodturns+4);
				$session['user']['turns']+=$rewardmodturns+4;
				if ($stopq==1)
				{
					set_module_pref("stopped",1);
					set_module_pref("stop",$stopday);
				}
				break;
			case 10:
				output("The exhilaration of owning such exquisite jewels makes you want to fight more.");
				output(" You gain `^%s turns.", $rewardmodturns+5);
				$session['user']['turns']+=$rewardmodturns+5;
				if ($stopq==1)
				{
					set_module_pref("stopped",1);
					set_module_pref("stop",$stopday);
				}
				break;
			case 11:
				output("You accidentally drop your jewel and when you pick it up you notice something more.");
				output(" You gain `^%s Gem(s).", $rewardmodgems+1);
				$session['user']['gems']+=$rewardmodgems+1;
				break;
			case 12:
				output("You accidentally drop your jewel and when you pick it up you notice something more.");
				output(" You gain `^%s Gems.", $rewardmodgems+2);
				$session['user']['gems']+=$rewardmodgems+2;
				break;
			case 13:
				output("You accidentally drop your jewel and when you pick it up you notice something more.");
				output(" You gain `^%s Gems.", $rewardmodgems+3);
				$session['user']['gems']+=$rewardmodgems+3;
				if ($stopq==1)
				{
					set_module_pref("stopped",1);
					set_module_pref("stop",$stopday);
				}
				break;
			case 14:
				output("You accidentally drop your jewel and when you pick it up you notice something more.");
				output(" You gain `^%s Gems.", $rewardmodgems+4);
				$session['user']['gems']+=$rewardmodgems+4;
				if ($stopq==1)
				{
					set_module_pref("stopped",1);
					set_module_pref("stop",$stopday);
				}
				break;
			case 15:
				output("You accidentally drop your jewel and when you pick it up you notice something more.");
				output(" You gain `^%s gems.", $rewardmodgems+5);
				$session['user']['gems']+=$rewardmodgems+5;
				if ($stopq==1)
				{
					set_module_pref("stopped",1);
					set_module_pref("stop",$stopday);
				}
				break;
		}
	}
	if ($stopped==1)
	{
		switch (e_rand(1,7))
		{
			case 1:
				output("You picked up your jewels and pocket them and gain `^%s hitpoints.", $rewardmod+5);
				$session['user']['hitpoints']+=$rewardmod+5;
				break;
			case 2:
				output("You picked up your jewels and pocket them and gain `^%s hitpoints.", $rewardmod+10);
				$session['user']['hitpoints']+=$rewardmod+10;
				break;
			case 3:
				output("You picked up your jewels and pocket them and gain `^%s hitpoints.", $rewardmod+15);
				$session['user']['hitpoints']+=$rewardmod+15;
				break;
			case 4:
				output("You picked up your jewels and pocket them and gain `^%s hitpoints.", $rewardmod+20);
				$session['user']['hitpoints']+=$rewardmod+20;
				break;
			case 5:
				output("You picked up your jewels and pocket them and gain `^%s hitpoints.", $rewardmod+25);
				$session['user']['hitpoints']+=$rewardmod+25;
				break;
			case 6:
				output("The exhilaration of owning such exquisite jewels makes you want to fight more.");
				output(" You gain `^%s turn.", $rewardmodturns+1);
				$session['user']['turns']+=$rewardmodturns+1;
				break;
			case 7:
				output("The exhilaration of owning such exquisite jewels makes you want to fight more.");
				output(" You gain `^%s turns.", $rewardmodturns+2);
				$session['user']['turns']+=$rewardmodturns+2;
				break;
		}
	}
}
?>