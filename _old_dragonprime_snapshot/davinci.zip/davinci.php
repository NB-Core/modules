<?php

// A module based on charm (for reward), since I feel that there's too few of them out there :P

function davinci_getmoduleinfo(){
	$info = array(
		"name"=>"DaVinci the Painter",
		"version"=>"1.02",
		"author"=>"Enhas",
		"category"=>"Forest Specials",
            "download"=>"http://dragonprime.net/users/Enhas/davinci.txt",
            "settings"=>array(
		"DaVinci the Painter Settings,title",
            "maxgold"=>"Maximum amount of gold DaVinci can pay,int|2000",
            "maxfflost"=>"Maximum amount of forest fights the player can lose,range,1,3,1|2",
		),
	);
	return $info;
}

function davinci_install(){
	module_addeventhook("forest", "return 100;");
	return true;
}

function davinci_uninstall(){
	return true;
}

function davinci_dohook($hookname,$args){
	return $args;
}

function davinci_runevent($type)
{
	global $session;
	// We assume this event only shows up in the forest currently.
	$from = "forest.php?";
	$session['user']['specialinc'] = "module:davinci";
      $maxgold = get_module_setting("maxgold");
      $maxfflost = get_module_setting("maxfflost");
      $goldcharm = ($session['user']['charm'] + 50);
      $goldcharm2 = ($goldcharm - 10);
      output("`Q`c`bDaVinci, the Painter`b`c`n");
	$op = httpget('op');
	if ($op=="" || $op=="search"){
		output("`3You notice a small clearing ahead.  A man stands with his back to you, lamenting to himself while standing near his easel.`n`n");
		output("`Q'No, no.. this is not right.. nothing worth painting here at all..'`3 he mutters, still seemingly unaware of your presence.  However, he quickly turns around to greet you!`n`n");
            output("`Q'Greetings!  I am the famous painter, DaVinci.  I'm in a creativity slump right now though, and am in no mood for..'`n`n");
            output("DaVinci`3 remains silent for a moment, studying you.  `Q'Yes, yes!  You are exactly what I need!  I want to paint a portrait of your well-defined features, and I will `^pay`Q you well, based on how `%beautiful`Q you are!'`n`n");
		output("`3You think carefully for a few moments.  `QDaVinci`3 will likely take his time painting you to get his portrait its finest, which means you will lose the time for some `@forest fights`3 for today.  However, the offer of `^gold`3 sounds quite tempting..`n`n");
            output("`^What do you do?`0");
            addnav("DaVinci, the Painter");
		addnav("Accept his Offer", $from."op=accept");
		addnav("Refuse", $from."op=refuse");
            }elseif ($op=="accept"){
                  $session['user']['specialinc'] = "";
                  $fflost = e_rand(1,$maxfflost);
                  $goldmultiplier= e_rand($goldcharm2,$goldcharm);
                  $goldgained = ($session['user']['level'] * $goldmultiplier);
                  if ($goldgained > $maxgold) {
                  $goldgained = $maxgold;
                  }
                  if ($session['user']['turns'] < $fflost) {
		      $fflost = $session['user']['turns'];
			}
                  $session['user']['turns'] -= $fflost;
                  $session['user']['gold'] += $goldgained;
                  output("`3You accept `QDaVinci`3's offer, and sit down onto the log he directs you to.`n`n");
                  output("He shouts at you to move this way, then that way.. over and over again as he paints.`n`n");
                  output("Finally, after what seems like hours later, he is finished.  You take a look at his work.. it is remarkable!`n`n");
                  output("`Q'This is my greatest work ever!  Please take this as a token of my gratitude!' DaVinci `3says, tossing you a leather bag.  `Q'Farewell!'`3 he says, packing up his equipment and dashing back to town with his new portrait.`n`n");
                  output("You notice that the sun is lower in the sky!  `QDaVinci`3 must have taken a long time.. and you lose `\$%s`3 of your forest fights!  However, you open the leather bag he handed you, and discover `^%s`3 gold within!`n`n", $fflost, $goldgained);
                  output("Feeling happy at your profit, you continue on your way.`0");
                  if ($session['user']['turns'] < 0)
                  $session['user']['turns'] = 0;
            }elseif ($op=="refuse"){
                  output("`3You politely refuse `QDaVinci`3's offer, and continue on your way.  You hear him muttering something like `Q'`@The Green Dragon`Q would make a much better portrait than you..'`3, but take no notice.`0");
                  $session['user']['specialinc']= "";

	     }
}

function davinci_run(){
}
?>