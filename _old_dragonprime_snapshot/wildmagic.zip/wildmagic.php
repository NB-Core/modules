<?
/*------------------------------------------------------------
/ Wild Magic
/ 
/ 2004-04-11 The only original thing BlackEdgeMine ever wrote
/            (With thanks to Mortimer & Strider's Druid Forest Special)
/            Coded for www.tqfgames.com
------------------------------------------------------------*/
if (!isset($session)) exit();
if ($HTTP_GET_VARS[op]==""){
    output("`n`7As you make your way through the forest you notice a faint `^glimmer`7 in the distance.`n");
    output("Pushing aside the shallow underbrush, you approach the light.`n");
    output("Suddenly a scream of wind `&slams`7 you to the ground!`n`n");
    output("A black slash of `b`&void`7`b, surrounded by a raging whirlwind of `!C`@O`#L`^O`%R`7 assaults your eyes.`n`n");
    output("You only have a moment to decide.  `b`&What do you do?`b");
    addnav("Enter the Vortex","forest.php?op=enter");
    addnav("Stare into the Void","forest.php?op=stare");
    addnav("Flee to Safety","forest.php?op=flee");
    $session[user][specialinc]="wildmagic.php";
}else if ($HTTP_GET_VARS[op]=="enter"){
        output("`n`7Fearing no evil, you push forward into the vortex..`n`n");
        switch(e_rand(1,5)){
            case 1:
                output(" `6You begin to shiver, and fall to the ground again.  Your eyes begin to blur..`n");
			    $session[bufflist]['wildmagic'] = array("name"=>"`#Cold Chill","rounds"=>20,"wearoff"=>"You feel strong again.","atkmod"=>0.8,"roundmsg"=>"`#A chill runs down your spine.","activate"=>"offense");
                break;
            case 2:
                output(" `6For no reason, you begin to feel happy.  You are overcome with joy as tears fill your eyes`n");
			    $session[bufflist]['wildmagic'] = array("name"=>"`#Enchanted Joy","rounds"=>30,"wearoff"=>"You feel normal.","atkmod"=>1.2,"roundmsg"=>"`#You fight with cheer in your heart!","activate"=>"offense");
                break;
            case 3:
                output(" `6But after a few minutes in the blindness of the vortex, you get bored..`n");
                break;
            case 4:
                output(" `6Being unable to see, you quickly get bored and leave.`n");
                output(" `#You do not notice that something from the vortex has followed you...`n");
			    $session[bufflist]['wildmagic'] = array("name"=>"`#Vortex Minion","rounds"=>30,"wearoff"=>"Your minion vanishes as mysteriously as it appeared.","atkmod"=>1.1,"minioncount"=>1,"minbadguydamage"=>1,"maxbadguydamage"=>10,"effectmsg"=>"A swash of vortex strikes your foe for {damage} damage!","activate"=>"offense");
                break;
            case 5:
                output(" `6Being unable to see, you quickly get bored and leave.`n");
                output(" `#You do not notice that something from the vortex has followed you...`n");
			    $session[bufflist]['wildmagic'] = array("name"=>"`#Vortex Minion","rounds"=>10,"wearoff"=>"Your minion vanishes as mysteriously as it appeared.","atkmod"=>1.1,"minioncount"=>1,"mingoodguydamage"=>1,"maxgoodguydamage"=>$session['user']['level'],"effectmsg"=>"A swash of vortex strikes you for {damage} damage!","activate"=>"roundstart");
                break;
        }
}else if ($HTTP_GET_VARS[op]=="stare"){
        output("`n`7You stare into the void..`n`n");
        switch(e_rand(1,4)){
            case 1:
                output(" `6The `bVOID`b stares BACK!`n");
                output(" `6You lose turns!`n");
                if ($session['user']['turns']<4) {$session['user']['turns']=0;}
                else {$session['user']['turns']-=4;}
                break;
            case 2:
                output(" `6The `bVOID`b flees from your heavy gaze!`n");
                output(" `6You gain turns!`n");
                $session['user']['turns']+=4;
                break;
            case 3:
                output(" `6Being unable to see, you quickly get bored and leave.`n");
                output(" `#You do not notice that something from the vortex has followed you...`n");
			    $session[bufflist]['wildmagic'] = array("name"=>"`#Vortex Minion","rounds"=>30,"wearoff"=>"Your minion vanishes as mysteriously as it appeared.","atkmod"=>1.1,"minioncount"=>1,"minbadguydamage"=>1,"maxbadguydamage"=>10,"effectmsg"=>"A swash of vortex strikes your foe for {damage} damage!","activate"=>"offense");
                break;
            case 4:
                output(" `6Being unable to see, you quickly get bored and leave.`n");
                output(" `#You do not notice that something from the vortex has followed you...`n");
			    $session[bufflist]['wildmagic'] = array("name"=>"`#Vortex Minion","rounds"=>10,"wearoff"=>"Your minion vanishes as mysteriously as it appeared.","atkmod"=>1.1,"minioncount"=>1,"mingoodguydamage"=>1,"maxgoodguydamage"=>$session['user']['level'],"effectmsg"=>"A swash of vortex strikes you for {damage} damage!","activate"=>"roundstart");
                break;
        }
} else {
    output("`n`@You flee from the vortex!`n");
}

?>













