<?php
function slap_getmoduleinfo(){
	$info = array(
		"name" => "Slap Challenge",
		"author" => "`QJosh Elwell`0 - `i`&S`7anctum`i",
		"version" => "1.3",
		"category" => "General",
		"description" => "Slap Players, will send mail saying You've Been Slapped",
		"settings"=>array(
			"Slap Challenge Settings,title",
				"maxslaps"=>"Max Slaps a Day,int|5",
				//"timesslapped"=>"Show how many times user has been slapped in bio?,bool|1",
				"chance"=>"Chance of finding it, will be one out of the number you input,int|100",
				"glove"=>"Name/Type of Glove, no need to put the word glove",
				"mindk"=>"Minimum DK's user can find glove,int|10",
				"challengetimeout","Amount of seconds before user shows up on regular pvp list again,int|900",
				"offline"=>"User has to be offline to fight?,bool|0",
		),
		"prefs" => array(
			"glove"=>"User has a glove?,bool",
			"slapped"=>"Times Player has Slappedd others today.,int|0",
			"slappinghistory"=>"Last Players Slapped,viewonly",
			"beenslapped"=>"Login of the challenger,text|",
			"slapswon"=>"Slap Challenges won,int|0",
			"slapslost"=>"Slap Challenges lost,int|0",
			"inchallenge"=>"In a challenge?,bool",
			"loggedout"=>"Time logged out for challenge,viewonly",
		),
		);
	return $info;
}
function slap_install(){
	module_addhook("bioinfo");
	module_addhook("newday");
	module_addhook("biostat");
	module_addhook("battle-victory");
	module_addhook("battle-victory");
	module_addhook("player-logout");
	module_addhook("footer-pvp");
	return true;
}
function slap_uninstall(){
	return true;
}
function slap_dohook($hookname,$args){
	global $session;
	switch ($hookname){
		case "bioinfo":
			$ret = httpget('ret');
			$char = httpget('char');
			$id = $args['acctid'];
			if(get_module_pref("beenslapped")<>"" AND $char=="".get_module_pref("beenslapped").""){
			addnav("Challenges");
			addnav("Accept Challenge","runmodule.php?module=slap&op=accept&id=$id&char=$char&ret=$ret");
			addnav("Deny Challenge","runmodule.php?module=slap&op=deny&id=$id&char=$char$ret=$ret");
			}elseif(get_module_pref("glove")){
			addnav("Slap User", "runmodule.php?module=slap&id=$id&char=$char&ret=$ret");
			}
		break;
		case "newday":
			set_module_pref("slapped",0,"slap",false);
			set_module_pref("slappinghistory",0,"slap",false);
		break;
		case "biostat":
			$sql = "SELECT * FROM accounts WHERE login='".httpget("char")."'";
			$res = db_query($sql);
			$row = db_fetch_assoc($res);
			$won = get_module_pref("slapswon");
			$lost = get_module_pref("slapslost");
			output("`^Slap Challenges Won: `@".$won."`0`n");
			output("`^Slap Challenges Lost: `@".$lost."`0`n");
		break;
		case "battle-victory":
			if ($args['type'] == "forest")	{
			if($session[user][dragonkills]>=get_module_setting("mindk")){
			$chance = e_rand(1,get_module_setting("chance"));
			if ($chance == get_module_setting("chance")-1 AND get_module_pref("glove")==0){
				$glove = "".get_module_setting("glove")." Glove";
				output("`n`^You've found a(n) %s!`n",$glove);
				set_module_pref("glove",1);
				}
			}
		}
		break;
		case "player-logout":
			if(get_module_pref("inchallenge")){
			$sql = "SELECT acctid,name FROM accounts WHERE login='".get_module_pref("beenslapped")."'";
			$res = db_query($sql);
			$row = db_fetch_assoc($row);
			$subject = sprintf_translate("`^Slap!`0");
			$body = sprintf_translate("%s `^has accepted your challenge and logged out, you can now go attack them in PVP no matter what level or how many dragonkills they have!!!",$name);
			systemmail($row['acctid'],$subject,$body,$session['user']['acctid']);
		}
		break;
		case "player-login":
			if(get_module_pref("inchallenge")){
			set_module_pref("inchallenge",0);
			set_module_pref("loggedout",0);
		}
		break;
		case "footer-pvp": 
               $sql = "SELECT login,name FROM ".db_prefix("accounts")." INNER JOIN ".db_prefix("module_userprefs")." ON acctid=userid WHERE value='{$session['user']['login']}' AND modulename='slap' AND setting='beenslapped'"; 
               $res = db_query($sql); 
               $row = db_fetch_assoc($res); 
               if (httpget('act') != "attack" && !httpget('op') && db_num_rows($res) > 0){ 
                    addnav("Challenge"); 
                    addnav(array("Attack %s",$row['name']),"runmodule.php?module=slap&op=fight1&name=".rawurlencode($row['login']).""); 
               } 
          break;
		case "pvpmodifytargets":
			
          foreach ($args as $index=>$target) {
               if (get_module_pref("beenslapped", "slap", $target['acctid'])) {
				    if((date("U") - strtotime(get_module_pref("loggedout")) < get_module_setting("challengetimeout"))){
					$args[$index]['invalid'] = 0;
					}else{
                    $args[$index]['invalid'] = 1;
					}
               }
          }
          break;
	}
	return $args;
}
function slap_run(){
	global $session;
	require_once("lib/systemmail.php");
	page_header("Slap Challenge!");
	$history = unserialize(get_module_pref("slappinghistory"));
	if (!is_array($history)){
		$history=array();
	}
	$ret = httpget('ret');
	$char = httpget('char');
	$id = httpget('id');
	$slapped = get_module_pref("slapped");
	$beenslapped = get_module_pref("beenslapped",false,$id);
	$name = $session['user']['name'];
	$slapped++;
	$beenslapped++;
	$op = httpget('op');
	if($op==""){
	if($n>get_module_setting("maxslaps")){
		output("Sorry you have slapped the max amount of times today!!");
		addnav("Return","bio.php?char=$char&ret=$ret");
	}elseif($id==$session['user']['acctid']){
		output("`^You cannot slap yourself!");
		addnews("$name `^was seen trying to slap themself!!`0");
		addnav("Return","bio.php?char=$char&ret=$ret");
	}elseif($history[0]==$id OR $history[1]==$id OR $history[2]==$id OR $history[3]==$id OR $history[4]==$id OR $history[4]==$id){
		output("You already slapped this person!");
		addnav("Return","bio.php?char=$char&ret=$ret");
	}else{
		set_module_pref("slapped",$slapped);
	if (count($history)>=get_module_setting("maxslaps")) 
		array_shift($history); 
		array_push($history,$id);
		set_module_pref("slappinghistory",serialize($history));
		set_module_pref("beenslapped",$session['user']['login'],false,$id);
		addnews("$name `^was seen slapping $char`^ with their dueling glove!!");
		$subject = sprintf_translate("`^Slap!`0");
		$body = sprintf_translate("`^You have been slapped by %s`^!!! They challenge you to a duel, if you accept then go to their bio and slap them back, then logout to the fields!!!",$name);
		systemmail($id,$subject,$body,$session['user']['acctid']);
		addnav("Return","bio.php?char=$char&ret=$ret");
	}
	}elseif($op=="accept"){
		output("`^You have accepted the challenge! Please go logout to the fields now.");
		set_module_pref("inchallenge",1);
		addnav("Return","bio.php?char=$char&ret=$ret");
	}elseif($op=="deny"){
		output("`^You have accepted the challenge! Please go logout to the fields now.");
		set_module_pref("beenslapped",0,false,$id);
		addnav("Return","bio.php?char=$char&ret=$ret");
	}
	elseif ($op == "fight1"){
		$name = rawurldecode(httpget('name'));
		$badguy = challenge_target($name);
		$session['user']['badguy'] = createstring($badguy);		$session['user']['playerfights']--;
		$battle = true;
	}
	elseif ($op == "fight"){
		$battle = true;
	}
    if ($battle){
	$slapswon = get_module_pref("slapswon");
	$slap2won = get_module_pref("slapswon",false,$id);
	$slapslost = get_module_pref("slapslost");
	$slap2lost = get_module_pref("slapslost",false,$id);
        include("battle.php");
        if ($victory){
			set_module_pref("beenslapped",0,false,$id);
			$slapswon++;
			$slap2lost++;
			set_module_pref("slapswon",$slapswon);
			set_module_pref("slapslost",$slap2lost,false,$id);
			set_module_pref("inchallange",0);
			set_module_pref("inchallange",0,false,$id);
			$killedin = translate_inline("A Challenge!!!");
			require_once("lib/pvpsupport.php");
			pvpvictory($badguy, $killedin);
            addnews("`^%s`# defeated `^%s`# in a challenge!!!", $session['user']['name'], $badguy['creaturename']);
            $badguy = array();
			villagenav();
        }elseif ($defeat){
			$slapslost++;
			$slap2won++;
			set_module_pref("beenslapped",0,false,$id);
			set_module_pref("slapslost",$slapslost);
			set_module_pref("slap2won",$slap2won,false,$id);
			set_module_pref("inchallange",0);
			set_module_pref("inchallange",0,false,$id);
			$killedin = translate_inline("A Challenge!");
			require_once("lib/taunt.php");
			$taunt = select_taunt_array();
			require_once("lib/pvpsupport.php");
			pvpdefeat($badguy, $killedin, $taunt);
            addnews("`4%s`3 was defeated while attacking `4%s`3 in a challenge.`n%s", $session['user']['name'], $badguy['creaturename'], $taunt);
			addnav("Return to Shades","shades.php");			
        }else{
			$script = "runmodule.php?module=slap&op=fight";
			require_once("lib/fightnav.php");
	        fightnav(false,false,$script);
        }
    }
	page_footer();
}

function challenge_target($name)
{
	global $pvptimeout, $session;
	$sql = "SELECT name AS creaturename, level AS creaturelevel, weapon AS creatureweapon, gold AS creaturegold, experience AS creatureexp, maxhitpoints AS creaturehealth, attack AS creatureattack, defense AS creaturedefense, loggedin, location, laston, alive, acctid, pvpflag, boughtroomtoday, race FROM " . db_prefix("accounts") . " WHERE login=\"$name\"";
	$result = db_query($sql);
	if (db_num_rows($result)>0){
		$row = db_fetch_assoc($result);
		if (strtotime($row['laston']) >
				strtotime("-".getsetting("LOGINTIMEOUT",900)." sec") &&
				$row['loggedin'] AND get_module_setting("offline")==1){
			output("`\$Error:`4 That user is now online, and cannot be attacked until they log off again.");
			return false;
		} elseif((int)$row['alive']!=1){
			output("`\$Error:`4 That user is not alive.");
			return false;
		}elseif ($session['user']['playerfights']>0){
			$sql = "UPDATE " . db_prefix("accounts") . " SET pvpflag='".date("Y-m-d H:i:s")."' WHERE acctid={$row['acctid']}";
			db_query($sql);
			require_once("lib/pvpwarning.php");
			$row['creatureexp'] = round($row['creatureexp'],0);
			$row['playerstarthp'] = $session['user']['hitpoints'];
			$row['fightstartdate'] = strtotime("now");
			$row['type']="pvp";
			$row = modulehook("pvpadjust", $row);
			pvpwarning(true);
			return $row;
		}else{
			output("`4Judging by how tired you are, you think you had best not engage in battle against other players right now.");
			return false;
		}
	} else {
		output("`\$Error:`4 That user was not found!  It's likely that their account expired just now.");
		return false;
	}
	return false;
}
?>