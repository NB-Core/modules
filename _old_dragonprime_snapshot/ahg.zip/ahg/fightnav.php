<?php
// translator ready
// addnews ready
function fightnav($allowspecial=true, $allowflee=true,$script=false){
	global $PHP_SELF,$session;
	tlschema("fightnav");
	if ($script===false){
		$script = substr($PHP_SELF,strrpos($PHP_SELF,"/")+1)."?";
	}else{
		if (!strpos($script,"?")) {
			$script.="?";
		}elseif (substr($script,strlen($script)-1)!="&"){
			$script.="&";
		}
	}
	addnav("Fight",$script."op=ahg&sop=fight");
	if ($allowflee) {
		addnav("Run",$script."op=ahg&sop=run");
	}
	if (getsetting("autofight",0)) {
		addnav("Automatic Fighting");
		addnav("5?For 5 Rounds", $script."op=ahg&sop=fight&auto=five");
		addnav("1?For 10 Rounds", $script."op=ahg&sop=fight&auto=ten");
		if (getsetting("autofightfull", 0)) {
			addnav("U?Until End", $script."op=ahg&sop=fight&auto=full");
		}
	}
	if ($allowspecial) {
		addnav("`bSpecial Abilities`b");
		if ($session['user']['darkartuses']>0) {
			addnav("`\$Dark Arts ({$session['user']['darkartuses']} points)`0", "");
			addnav("`\$&#149; Skeleton Crew`7 (1)`0",$script."op=ahg&sop=fight&skill=DA&l=1",true);
		}
		if ($session['user']['darkartuses']>1)
			addnav("`\$&#149; Voodoo`7 (2)`0",$script."op=ahg&sop=fight&skill=DA&l=2",true);
		if ($session['user']['darkartuses']>2)
			addnav("`\$&#149; Curse Spirit`7 (3)`0",$script."op=ahg&sop=fight&skill=DA&l=3",true);
		if ($session['user']['darkartuses']>4)
			addnav("`\$&#149; Wither Soul`7 (5)`0",$script."op=ahg&sop=fight&skill=DA&l=5",true);
	
		if ($session['user']['thieveryuses']>0) {
			addnav("`^Thieving Skills ({$session['user']['thieveryuses']} points)`0","");
			addnav("`^&#149; Insult`7 (1)`0",$script."op=ahg&sop=fight&skill=TS&l=1",true);
		}
		if ($session['user']['thieveryuses']>1)
			addnav("`^&#149; Poison Blade`7 (2)`0",$script."op=ahg&sop=fight&skill=TS&l=2",true);
		if ($session['user']['thieveryuses']>2)
			addnav("`^&#149; Hidden Attack`7 (3)`0",$script."op=ahg&sop=fight&skill=TS&l=3",true);
		if ($session['user']['thieveryuses']>4)
			addnav("`^&#149; Backstab`7 (5)`0",$script."op=ahg&sop=fight&skill=TS&l=5",true);
	
		if ($session['user']['magicuses']>0) {
			addnav("`%Mystical Powers ({$session['user']['magicuses']} points)`0","");
			addnav("g?`%&#149; Regeneration`7 (1)`0",$script."op=ahg&sop=fight&skill=MP&l=1",true);
		}
		if ($session['user']['magicuses']>1)
			addnav("`%&#149; Earth Fist`7 (2)`0",$script."op=ahg&sop=fight&skill=MP&l=2",true);
		if ($session['user']['magicuses']>2)
			addnav("p?`%&#149; Siphon Life`7 (3)`0",$script."op=ahg&sop=fight&skill=MP&l=3",true);
		if ($session['user']['magicuses']>4)
			addnav("A?`%&#149; Lightning Aura`7 (5)`0",$script."op=ahg&sop=fight&skill=MP&l=5",true);

		if ($session['user']['superuser'] & SU_DEVELOPER) {
			addnav("`&Super user`0","");
			addnav("!?`&&#149; __GOD MODE",$script."op=ahg&sop=fight&skill=godmode",true);
		}
	}
	tlschema();
}
?>
