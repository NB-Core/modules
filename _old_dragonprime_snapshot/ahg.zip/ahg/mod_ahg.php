<?php
	$op = httpget("op");
	$sop= httpget("sop");
	
  global $session;
  $turns = $session['user']['turns'];
	switch($sop)
	{
	  case "hunt":
  		$session['user']['turns']--;
	  case "fight":
	  case "run":
	    include "modules/ahg/dobattle.php";
	    DoBattle();
	    break;
	  default:
				if ($turns>0)
				{
  	      output("Something about the grounds here.");
				  if (($session['user']['hitpoints'] < $session['user']['maxhitpoints']) && (rand(1,3)>1))
				  {
				    addnav("H?Seek the Healer", "runmodule.php?module=ahg&op=healer");
				  }
					addnav("S?Seek out the evils within", "runmodule.php?module=ahg&op=ahg&sop=hunt");
				  if (rand(1,70)>60)
				  {
  					villagenav();
  				}
				}
				else
				{
  	      output("You have ran out of umph for the day and must return to the village till tomorow.");
					villagenav();
				}
	    break;
	}
?>
