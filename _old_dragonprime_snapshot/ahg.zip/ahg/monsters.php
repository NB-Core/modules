<?php
/*
	$ahg_creatures = array( 'Test Creature' => array( 'NamePostModifiers' => array('Shaman'=>array(
	  'Lightning Bolt'=>array('$ahg_creatureattackval=10;'), 
		'Fire Bolt'=>array('$ahg_creatureattackval=20;'))
																							 											 			),
																					'Defense'=>'300'
																			 			)
/*/

	$ahg_creatures = array( 'Dragon' => array( 'NamePreModifiers' => array ('Red', 'Gold', 'Blue', 'Winged'),
								 	 		 								 					 'Attacks' => array ('Flame Breath', 'Frost Breath', 'Razor Sharp Claws')
								 	 		 								 				 ), 
															'Orc' => array( 'NamePreModifiers' => array('Large', 'Small', 'Old', 'Young'),
																			 				'NamePostModifiers' => array('Shaman'=>array('Lightning Bolt', 'Fire Bolt'),
																			 															       'Letunentant', 'Commander', 'Warrior'
																							 											 			),
																			 				'Attacks' => array('Club', 'Mace', 'Sword', 'Dagger')
																			 			), 
															'Halfling' => array( 'NamePreModifiers' => array('Large', 'Small', 'Old', 'Young'),
																			 				'NamePostModifiers' => array('Shaman'=>array('Lightning Bolt', 'Fire Bolt'),
																			 															       'Letunentant', 'Commander', 'Warrior'
																							 											 			),
																			 				'Attacks' => array('Club', 'Mace', 'Sword', 'Dagger')
																			 			), 
															'Dwarf' => array( 'NamePreModifiers' => array('Large', 'Small', 'Old', 'Young'),
																			 				'NamePostModifiers' => array('Shaman'=>array('Lightning Bolt', 'Fire Bolt'),
																			 															       'Letunentant', 'Commander', 'Warrior'
																							 											 			),
																			 				'Attacks' => array('Club', 'Mace', 'Sword', 'Dagger')
																			 			), 
															'Elf' => array( 'NamePreModifiers' => array('Large', 'Small', 'Old', 'Young'),
																			 				'NamePostModifiers' => array('Shaman'=>array('Lightning Bolt', 'Fire Bolt'),
																			 															       'Letunentant', 'Commander', 'Warrior'
																							 											 			),
																			 				'Attacks' => array('Sword', 'Dagger', 'Bow')
																			 			), 
								 	 		 				'Dark-Elf'  => array( 'NamePreModifiers' => array('Large', 'Small', 'Old', 'Young'),
																			 				'NamePostModifiers' => array('Shaman'=>array('Lightning Bolt', 'Fire Bolt'),
																			 															       'Letunentant', 'Commander', 'Warrior'
																							 											 			),
																			 				'Attacks' => array('Sword', 'Dagger', 'Bow')
																			 			),
/*
															'Drake', 
															'Wyvern', 
															'Wyrm', 
															'Naga'
															'Basilisk', 
															'Centaur', 
															'Cerberus', 
															'Chimera', 
															'Cyclops', 
															'Griffin', 
															'Harpie', 
															'Hydra', 
															'Kraken',
															'Mandrake', 
															'Manticore', 
															'Medusa', 
															'Minotaur',
															'Pegasus', 
															'Phoenix', 
															'Roc', 
															'Salamander',
															'Satyr', 
															'Siren', 
															'Sphinx', 
															*/
															'Unicorn' => array( 'Attacks' => array( 'Magic Horn' => array('$ahg_creatureattackval=110;'), 
																					 										 				'Front Hoves' => array('$ahg_creatureattackval=110;')
																																		),
																				          'Defence' => '300'
																			 			)
														);

	$ahg_pointsperlevel = 50;
	$ahg_expperlevel	  = 50;
	$ahg_expmodifier		= 10;
  global $session;
	$ahg_creaturelevel  = $session['user']['level'] + (rand(1,3) - 2);
	$ahg_creaturepoints = $ahg_pointsperlevel * $ahg_creaturelevel;
	$ahg_creaturelifemod= ((rand(1, 20)-10)/100);
	$ahg_creaturelifemod= $session['user']['maxhitpoints'] * $ahg_creaturelifemod;
	$ahg_creaturelife   = $session['user']['maxhitpoints'] + $ahg_creaturelifemod;
	$ahg_creaturepoints -= $ahg_creaturelife;
	$ahg_creatureexp	  = $ahg_pointsperlevel * $ahg_creaturelevel;
	
	$ahg_creaturecount  = count($ahg_creatures);
	$ahg_creatureindex	= rand(0, $ahg_creaturecount-1);
	reset($ahg_creatures);

	if ($ahg_creatureindex > 0)
	{
		for ($i=0;$i<$ahg_creatureindex;$i++)
		{
		  next($ahg_creatures);
		}
	}
	$ahg_creatureinfo   = current($ahg_creatures);
	$ahg_creaturename   = key($ahg_creatures);
	if (IsSet($ahg_creatureinfo['NamePreModifiers']))
	{
	  $ahg_creaturenamepremods = $ahg_creatureinfo['NamePreModifiers'];
	  $ahg_creaturenamepremodcount = count($ahg_creaturenamepremods);
	  $ahg_creaturepreindex = rand(0, $ahg_creaturenamepremodcount-1);
	  if ($ahg_creaturepreindex < $ahg_creaturenamepremodcount)
	  {
  	  reset($ahg_creaturenamepremods);
	    if ($ahg_creaturepreindex > 0)
	    {
				for ($i=0;$i<$ahg_creaturepreindex;$i++)
				{
				  next($ahg_creaturenamepremods);
				}
	    }
	    $mobprename = current($ahg_creaturenamepremods);
	    if (Is_Array($mobprename))
			{
	      $ahg_creaturename = key($ahg_creaturenamepremods)." $ahg_creaturename";
	      $ahg_creatureattacks = $mobprename;
	    }
	    else
	    {
	      $ahg_creaturename = "$mobprename $ahg_creaturename";
	    }
	  }
	}

	if (IsSet($ahg_creatureinfo['NamePostModifiers']))
	{
	  $ahg_creaturenamepostmods = $ahg_creatureinfo['NamePostModifiers'];
	  $ahg_creaturenamepostmodcount = count($ahg_creaturenamepostmods);
	  $ahg_creaturepostindex = rand(0, $ahg_creaturenamepostmodcount-1);
	  if ($ahg_creaturepostindex < $ahg_creaturenamepostmodcount)
	  {
  	  reset($ahg_creaturenamepostmods);
	    if ($ahg_creaturepostindex > 0)
	    {
				for ($i=0;$i<$ahg_creaturepostindex;$i++)
				{
				  next($ahg_creaturenamepostmods);
				}
	    }
	    $mobpostname = current($ahg_creaturenamepostmods);
	    if (Is_Array($mobpostname))
			{
	      $ahg_creaturename = " $ahg_creaturename ".key($ahg_creaturenamepostmods);
	      $ahg_creatureattacks = $mobpostname;
	    }
	    else
	    {
	      $ahg_creaturename = "$ahg_creaturename $mobpostname";
	    }
	  }
	}

	if (!IsSet($ahg_creatureattacks)){
  	$ahg_creatureattacks= $ahg_creatureinfo['Attacks'];
	}
	$ahg_creatureattackcount = count($ahg_creatureattacks);
	$ahg_creatureattackindex = rand(0, $ahg_creatureattackcount-1);
	reset($ahg_creatureattacks);
	if ($ahg_creatureattackindex > 0)
	{
		for ($i=0;$i<$ahg_creatureattackindex;$i++)
		{
		  next($ahg_creatureattacks);
		}
	}
	$ahg_creatureattackval=$session['user']['attack'] * ($ahg_creaturelevel / $session['user']['level']);
	if (Is_Array(current($ahg_creatureattacks)))
	{
	  $ahg_creatureattack=key($ahg_creatureattacks);
	  $ahg_attackscript=current($ahg_creatureattacks);
	  reset($ahg_attackscript);
	  $ahg_attackscript=current($ahg_attackscript);
		eval($ahg_attackscript);
	}
	else
	{
	  $ahg_creatureattack=current($ahg_creatureattacks);
	}
	$ahg_creaturepoints -= $ahg_creatureattackval;
	if (IsSet($ahg_creatureinfo['Defence']))
	{
	  $ahg_creaturedefenceval=$ahg_creatureinfo['Defence'];
	}
	else
	{
	  $ahg_creaturedefenceval=$session['user']['defence'] * ($ahg_creaturelevel / $session['user']['level']);
	}
	$ahg_creaturepoints -= $ahg_creaturedefenceval;	
	$ahg_creaturegold   = $ahg_creaturepoints;
	
global $ahg_badguy;
  $ahg_badguy = array();
	$ahg_badguy['creaturename']= $ahg_creaturename;
	$ahg_badguy['creatureweapon']="it's $ahg_creatureattack";
	$ahg_badguy['creaturelevel']=$ahg_creaturelevel;
	$ahg_badguy['creaturegold']=ceil($ahg_creaturegold);
	$ahg_badguy['creatureexp'] =floor($ahg_creatureexp);
	$ahg_badguy['creaturehealth']=ceil($ahg_creaturelife);
	$ahg_badguy['creatureattack']=ceil($ahg_creatureattackval);
	$ahg_badguy['creaturedefense']=ceil($ahg_creaturedefenceval);
?>
