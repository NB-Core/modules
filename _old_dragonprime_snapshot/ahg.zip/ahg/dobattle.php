<?php
  function DoBattle()
  {
    global $session;
		$op = httpget("op");
		$sop= httpget("sop");

		if ($sop=="hunt")
		{
				//they've been waylaid.
				require_once("lib/forestoutcomes.php");
				$sql = "SELECT * FROM " . db_prefix("creatures") . " WHERE creaturelevel = '{$session['user']['level']}' ORDER BY rand(".e_rand().") LIMIT 1";
				$result = db_query($sql);
				restore_buff_fields();
				if (db_num_rows($result) == 0) 
				{
				  require_once("modules/ahg/monsters.php");
				  global $ahg_badguy;
				  $badguy = $ahg_badguy;
				} 
				else 
				{
					$badguy = db_fetch_assoc($result);
					$badguy = buffbadguy($badguy);
				}
		    calculate_buff_fields();
				$badguy['playerstarthp']=$session['user']['hitpoints'];
				$badguy['diddamage']=0;
				$session['user']['badguy']=createstring($badguy);
	if ($session['user']['alive']){
		output("`2%s`2's Hitpoints: `6%s`0`n",$badguy['creaturename'],$badguy['creaturehealth']);
		output("`2YOUR Hitpoints: `6%s`0`n",$session['user']['hitpoints']);
	}else{
		output("`2%s`2's Soulpoints: `6%s`0`n",$badguy['creaturename'],$badguy['creaturehealth']);
		output("`2YOUR Soulpoints: `6%s`0`n",$session['user']['hitpoints']);
	}
				$battle = true;
		}
		elseif ($sop=="fight" || $sop=="run")
		{
			if ($sop == "run" && e_rand(1, 5) < 3) 
			{
				// They managed to get away.
				page_header("Escape");
				output("You set off running through the Hunting Grounds at a breakneck pace heading back the way you came.`n`nAfter running for what seems like hours, you finally arrive back at %s.", $session['user']['location']);
				if ($session['user']['turns']>0)
					$session['user']['turns']--;
				addnav(array("Enter %s",$session['user']['location']), "village.php");
				page_footer();
			}
			$battle=true;
		}
		global $victory, $defeat;
		if ($battle)
		{
			page_header("You've been waylaid!");
			include("modules/ahg/battle.php");
			if ($victory)
			{
				require_once("lib/forestoutcomes.php");
				forestvictory($badguy,false);
				addnav("C?You come forth victorious from the battle.  You may now Continue your jurney.","runmodule.php?module=ahg&op=ahg");
			}
			elseif ($defeat)
			{
				require_once("lib/forestoutcomes.php");
				forestdefeat($badguy,"traveling to $city");
			}else
			{
				require_once("modules/ahg/fightnav.php");
				fightnav(true,true,"runmodule.php?module=ahg&op=ahg&sop=fight");
			}
    }
  }
?>
