<?php
// ahg.php
/* ver 1.0 by Jeremy Darling => jdarling -at- eonclash -dot- com
   ver 1.1 - added in functionality to allow replacement of experience
	 		 		 	 function in install/uninstall.  Upgraded mob generation script
	 		 		 	 to give more then just dopplegangers of player.
*/

require_once("lib/http.php");
require_once("lib/villagenav.php");

function ahg_getmoduleinfo(){
	$info = array(
		"name"=>"Advanced Hunting Grounds",
		"version"=>"1.1",
		"author"=>"Jeremy Darling",
		"category"=>"Village",
		"download"=>"http://dragonprime.net/users/kermit/ahg.zip",
		"settings"=>array(
			"minlevel"=>"The minimum level a player must be to enter,int|13",
			"mindks"=>"The minimum number of Dragon Kills a user must have,int|10",
			"ahgloc"=>"Where does the Hunting Ground appear,location|".getsetting("villagename", LOCATION_FIELDS)
		)
	);
	return $info;
}

function ahg_install(){
	module_addhook("changesetting");
	module_addhook("village");
	module_addhook("newday");
	rename("lib/experience.php", "lib/experience.php.old");
	rename("modules/ahg/new_experience.php", "lib/experience.php");
	return true;
}

function ahg_uninstall(){
  unlink("lib/experience.php");
	rename("lib/experience.php.old", "lib/experience.php");
	return true;
}

function ahg_dohook($hookname,$args){
	global $session;
	switch($hookname){
	case "changesetting":
		if ($args['setting'] == "villagename") {
			if ($args['old'] == get_module_setting("ahgloc")) {
				set_module_setting("ahgloc", $args['new']);
			}
		}
		break;
	case "village":
		if (($session['user']['level'] > get_module_setting("minlevel")) &&
			  ($session['user']['dragonkills'] > get_module_setting("mindks")) &&
				($session['user']['location'] == get_module_setting("ahgloc"))) {
			addnav($args['othernav']);
			addnav("Advanced Hunting Grounds","runmodule.php?module=ahg&op=enter");
		}
		break;
	case "newday":
		//set_module_pref("eatentoday",0);
		break;
	}
	return $args;
}

function ahg_CheckForLevel()
{
	require_once("lib/experience.php");
  global $session;
	$level = $session['user']['level'];
	$dks = $session['user']['dragonkills'];
  $exprequired=exp_for_next_level($level, $dks);
	global $maxlev;
  if (($session['user']['experience'] > $exprequired) && ($session['user']['level'] < $maxlev))
    {
      while($session['user']['experience'] > $exprequired)
      {
        $session['user']['level']++;
				$session['user']['maxhitpoints']+=10;
				$session['user']['soulpoints']+=5;
				$session['user']['attack']++;
				$session['user']['defence']++;

        output("You have reached Level %s.`n", $session['user']['level']);
				$level = $session['user']['level'];
				$dks = $session['user']['dragonkills'];
        $exprequired=exp_for_next_level($level, $dks);
      }
    }
}

function ahg_run()
{
	$op = httpget("op");
	checkday();
  
	ahg_CheckForLevel();
	
  page_header("Advanced Hunting Grounds");
  if ($op=="" || $op=="enter")
	{
	// Check to see if the player wants to enter the hunting grounds
		villagenav();
		addnav("E?Enter the Hunting Grounds", "runmodule.php?module=ahg&op=ahg");
		output("Advanced Hunting Grounds");
		output("Realizing that attacking the dragon in the caves is nothing more then a death sentence you opt to try your luck in the Advanced Hunting Grounds.");
		output("Entering these hunting grounds will allow you to level up past level 14, get new items with stronger powers and will allow you to have new powers only available in the Hunting Grounds.");
		output("This all comes at a price thou.  Every day you enter the grounds you will loose 2 forrest fights and battles resulting in death will cost you more then just your gold a little bit of experience.");
		output("Death could even cost you the items on your back.  So its up to you do you chicken out and run back to fight the dragon or do you enter the hunting grounds and risk everything you have?");
	}
	else
	{
	  $modname = "modules/ahg/mod_$op.php";
	  if (file_exists($modname))
	  {
	    include ($modname);
	  }
	  else
	  {
  	  output("Could not locate: %s please contact your system admin.`n", $modname);
	  }
	}

	if ($session['user']['superuser']&~SU_DOESNT_GIVE_GROTTO)
	{
	  addnav("X?`bSuperuser Grotto`b","superuser.php");
	}
	if ($session['user']['superuser'] & SU_INFINITE_DAYS)
	{
	  addnav("/?New Day","newday.php");
	}
	page_footer();
}

?>
