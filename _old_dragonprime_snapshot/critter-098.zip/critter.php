<?
/*
   Critter...
      ,,,a passing experiment by Rowne.

  Basically this is both a coding endeavour and something
  of a social experiment.  I think it'd be funny to see
  just how my players would react to this.  So I thought
  I'd code it, just for kicks.  Most of them are going
  to kill me, I 'spect.  Wah.  
*/

function critter_getmoduleinfo(){
	$info = array(
		"name"=>"Critter",
		"version"=>"0.3",
		"author"=>"Rowne-Wuff Mastaile",
		"category"=>"Forest Specials",
	        "settings"=>array(
                        "Critter Encounter Module Settings,title",
                        "critterexp"=>"Experience cost`n(negative modifier):,int|0.3",
			"critterhit"=>"Temp Hitpoints Boost`n(positive modifier),int|0.8",
			"crittergem"=>"Gems found (* level`n- positive modifier):,int|0.2",
			"critterrnd"=>"Critter only seeks`npeople with a minimum`nrandom exp of 0 to:,int|600",
			"critteresc"=>"Player has a 1 in ?`nchance of escaping`n(default: 1):,int|10",
		),
	);
	return $info;
}

function critter_install(){
	module_addeventhook("forest", "return 100;");
	return true;
}

function critter_uninstall(){
	return true;
}

function critter_dohook($hookname,$args){
	return $args;
}

function critter_runevent($type)
{
  global $session;
  $from = "forest.php?";
  $op = httpget('op');
  if ($op == "" || $op == "search") {
  	output("`n`#`b`cWhat the...`b`c");
  	output("`n`5There's an odd twist to the path you walk now, not in the path itself bath in the route itself.");
	output("The twist happens to be the trees, you could've sworn they were evergreens, now they appear to be cherry blossoms.");
	output("In fact, you're not even sure if they're that.  You look around a bit more and there're some forms of flora that you can't even begin to identify.");
	output("Flora... and fauna.");
  	output("`n`nBefore you is a peculiar--you try for words but the closest you could gather is '`". e_rand(1,9) ."Wolf`5'.");
	output("It looks almost demonic with its many shifting colours and thusly you ready yourself for battle and inch towards your %s, yet... it speaks.", $session['user']['weapon']);
	output("\"`6There will be no need for that,`5\" the words echo. You can't be sure whether they were spoken by the Wolf or not.");
	output("You cast your gaze around worriedly and then back to the Wolf which confirms.`n`n");
    	output("\"`6Indeed, 'twas I.");
    	$critterrndpref = get_module_setting("critterrnd");
    	$critterrnd = e_rand(1,$critterrndpref);
    	$critterescpref = get_module_setting("critteresc");
    	$critteresc = e_rand(1,$critterescpref);
    	if ($session['user']['experience'] > $critterrnd && $critteresc == $critterescpref){
		$prefhit = get_module_setting("critterhit");
		$critterhit = round($session['user']['maxhitpoints']*$prefhit/3);
		$session['user']['hitpoints']+=$critterhit;
    		output("Now calm your...`5\" the surprise is evident in the Wolf's voice as somehow, you're fighting his illusion.");
    		output("Somehow, through your own intellect (be it as it may), bizarre chance or the grace of a diety,");
    		output("you've managed to see through his illusions, you begin to feel strange however as if this Wolf were working something else on you to counteract your resistance.");
    		output("`n`nThrough warrior instinct and reflex you scramble to your feet, trying to work more on instinct than thought as you put one leg in front of the other and run!");
    		output("Out of breath and a distance away you shake your head once more to clear the last of the illusions away, what was that creature?");
    		output("`n`nNonetheless, you came away unscathed and more, you feel as if something it did... as if you've gained something. There is a new fire burning inside you,");
    		output("urging you on. You don't feel as though you could take on the World... but perhaps a small army.");
		output("`n`n`&You've gained a temporary boost of `$%s`& hitpoints!", $critterhit);
    	} elseif ($session['user']['experience'] > $critterrnd){
		$prefexp = get_module_setting("critterexp");
		$critterexp = round($session['user']['experience']*$prefexp);
		$session['user']['experience']-=$critterexp;
		$prefhit = get_module_setting("critterhit");
		$critterhit = round($session['user']['maxhitpoints']*$prefhit);
		$session['user']['hitpoints']+=$critterhit;
		$prefgem = get_module_setting("crittergem");
		$crittergem = round($session['user']['level']*$prefgem);
		$session['user']['gems']+=$crittergem;
    		output("Now calm yourself, we'll be a while...`5\" and with that, the World around you seems to slowly swim out of existance, melding into an e'er moving swirling neosma.");
		output("It is too much to comprehend and your mind drifts slowly into the welcoming blackness of unconciousness.");
  		output("`n`nYou awaken many hours later, you feel mighty peculiar too at that.");
		output("Your mind feels like it's been put through the wringer, as if some things had been misplaced, others had been taken and yet stranger still you feel highly energenized.");
		output("You rub your head quickly before hopping to your feet. The Forest appears to be normal once more. You however do not feel so... there's something different about you.");
		output(" What had that creature done?");
  		output("`n`nLying on the ground mere inches from where you too had lead, are `@%s gems`5!", $crittergem);
		output(" You snatch them up quickly before anyone else gets the chance and plod off into the woods.");
		output(" Well, perhaps today wasn't wholly unproductive after all and you do feel absolutely fantastic.");
		output(" So much so that you could skip joyfully, as a child. Wait... skip joyfully?");
		output("Maybe you should go see the healer after all.`n`n");
		output(" `&You've lost `$%s`& experience points but you've gained a temporary boost of `$%s`& hitpoints and `@%s gems`&!", $critterexp, $critterhit, $crittergem);
    	} else {
    		output("`6Yet you have nothing I need, you may leave.`5\" and with that, the Wolf turns to wander away and as it does, it seems to fade out of existance and with its fade,");
    		output(" the World around you slowly returns to its usual set of colours. You have no idea what that was about but you feel that perhaps you should count your blessings,");
    		output(" as small as they might be right now.");
  	}
  }
}

function critter_run(){
}
?>