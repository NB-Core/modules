<?php
/*
Module Name:  bioviewing.php
Category:  Administrative
Worktitle:  Bio Viewing
Author:  DaveS
Date: October 8, 2005
Required Modules for function:
None

Credits:
Inspired by bioinformation.php by Keith - Converted by:Kevin Hatfield - Arune
Also, module allows bioequip.php by Chris Vorndran to take priority if it is also installed

Description:
Allows for settings so that EVERYONE can view  any of:
gold, goldinbank, gems, experience, charm, weapon, armor, attack, defense, hitpoints, 
maxhitpoints, turns, pvps, favor, and laston.
Also allows for any of the above to be viewed as a preference (would be shown in red in Bio)

May be useful for your Staff to have a quick way to see what players are doing.

PLEASE NOTE:  Default setting leaves the "Last Time On" as ON otherwise EVERYTHING else is off. 

v3.0 added vertxtloc
*/
require_once("lib/http.php");
function bioviewing_getmoduleinfo(){
	$info = array(
		"name"=>"Bio Viewing",
		"author"=>"DaveS",
		"version"=>"3.0",
		"category"=>"Administrative",
		"download"=>"http://dragonprime.net/index.php?module=Downloads;sa=dlview;id=182",
		"vertxtloc"=>"",
		"settings"=>array(
			"Bio Viewing,title",
			"masterssee"=>"Allow Everyone to see ALL details?,bool|0",		
			"Otherwise In Bios Can Everyone See...,note",
			"sseegold"=>"Gold?,bool|0",
			"sseegoldbank"=>"Gold in bank?,bool|0",
			"sseegems"=>"Gems?,bool|0",
			"sseeexp"=>"Experience?,bool|0",
			"sseecharm"=>"Charm?,bool|0",
			"sseeweapon"=>"Weapon?,bool|0",
			"Weapon viewing disabled from here if bioequip.php installed,note",
			"sseearmor"=>"Armor?,bool|0",
			"Armor viewing disabled from here if bioequip.php installed,note",
			"sseeattack"=>"Attack?,bool|0",
			"sseedefense"=>"Defense?,bool|0",
			"sseehitpoints"=>"Current Hitpoints?,bool|0",
			"sseemaxhitpoints"=>"Max Hitpoints?,bool|0",
			"sseeturns"=>"Turns?,bool|0",
			"sseepvps"=>"Number of PVPs?,bool|0",
			"sseefavor"=>"Favor?,bool|0",	
			"sseelaston"=>"Last Time On?,bool|1",			
		),
		"prefs"=>array(
			"Bio Information Preferences,title",
			"These will appear in red indicating that it is not a setting,note",
			"mastersee"=>"Allow User to see ALL details in other users Bios?,bool|0",
			"Otherwise in Bios can turn each on individually to see...,note",
			"seegold"=>"Gold?,bool|0",
			"seegoldbank"=>"Gold in Bank?,bool|0",
			"seegems"=>"Gems?,bool|0",
			"seeexp"=>"Experience?,bool|0",
			"seecharm"=>"Charm?,bool|0",
			"seeweapon"=>"Weapon?,bool|0",
			"Weapon viewing disabled from here if bioequip.php installed,note",
			"seearmor"=>"Armor?,bool|0",
			"Armor viewing disabled from here if bioequip.php installed,note",
			"seeattack"=>"Attack?,bool|0",
			"seedefense"=>"Defense?,bool|0",
			"seehitpoints"=>"Current Hitpoints?,bool|0",
			"seemaxhitpoints"=>"Max Hitpoints?,bool|0",
			"seeturns"=>"Turns?,bool|0",
			"seepvps"=>"Number of PVPs?,bool|0",
			"seefavor"=>"Favor?,bool|0",	
			"seelaston"=>"Last Time On?,bool|0",
		),
	);
	return $info;
}
function bioviewing_install(){
	module_addhook("biostat");
	module_addhook("bioequip");
	return true;
}
function bioviewing_uninstall(){
	return true;
}
function bioviewing_dohook($hookname, $args){
	global $session;
	switch($hookname){
		case "biostat":
			$name = httpget('char');
			$sql = "SELECT gold,goldinbank,gems,experience,charm,attack,defense,weapon,armor,hitpoints,maxhitpoints,turns,playerfights,deathpower,laston FROM ".db_prefix("accounts")." WHERE login='$name'";
			$res = db_query($sql);
			$row2 = db_fetch_assoc($res);
			$row2[login] = rawurlencode($row2[login]);
			$mastersee=get_module_pref("mastersee");
			$masterssee=get_module_setting("masterssee");
			if (get_module_setting("sseegold")==1 || $masterssee==1) output("`^Gold: `@$row2[gold]`n");
			elseif (get_module_pref("seegold")==1 || $mastersee==1) output("`\$Gold: `@$row2[gold]`n");
			if (get_module_setting("sseegoldbank")==1 || $masterssee==1) output("`^Gold in Bank: `@$row2[goldinbank]`n");
			elseif (get_module_pref("seegoldbank")==1 || $mastersee==1) output("`\$Gold in Bank: `@$row2[goldinbank]`n");
			if (get_module_setting("sseegems")==1 || $masterssee==1) output("`^Gems: `@$row2[gems]`n");
			elseif (get_module_pref("seegems")==1 || $mastersee==1) output("`\$Gems: `@$row2[gems]`n");
			if (get_module_setting("sseeexp")==1 || $masterssee==1) output("`^Experience: `@$row2[experience]`n");
			elseif (get_module_pref("seeexp")==1 || $mastersee==1) output("`\$Experience: `@$row2[experience]`n");
			if (get_module_setting("sseecharm")==1 || $masterssee==1)  output("`^Charm: `@$row2[charm]`n");
			elseif (get_module_pref("seecharm")==1 || $mastersee==1) output("`\$Charm: `@$row2[charm]`n");
			if (is_module_active("bioequip")){
			}else{
			if (get_module_setting("sseeweapon")==1 || $masterssee==1) output("`^Weapon: `@$row2[weapon]`n");
			elseif (get_module_pref("seeweapon")==1 || $mastersee==1) output("`\$Weapon: `@$row2[weapon]`n");
			if (get_module_setting("sseearmor")==1 || $masterssee==1) output("`^Armor: `@$row2[armor]`n");
			elseif (get_module_pref("seearmor")==1 || $mastersee==1) output("`\$Armor: `@$row2[armor]`n");
			}
			if (get_module_setting("sseeattack")==1 || $masterssee==1) output("`^Attack: `@$row2[attack]`n");
			elseif (get_module_pref("seeattack")==1 || $mastersee==1) output("`\$Attack: `@$row2[attack]`n");
			if (get_module_setting("sseedefense")==1 || $masterssee==1) output("`^Defense: `@$row2[defense]`n");
			elseif (get_module_pref("seedefense")==1 || $mastersee==1) output("`\$Defense: `@$row2[defense]`n");
			if (get_module_setting("sseehitpoints")==1 || $masterssee==1) output("`^Hitpoints: `@$row2[hitpoints]`n");
			elseif (get_module_pref("seehitpoints")==1 || $mastersee==1) output("`\$Hitpoints: `@$row2[hitpoints]`n");
			if (get_module_setting("sseemaxhitpoints")==1 || $masterssee==1) output("`^Maxhitpoints: `@$row2[maxhitpoints]`n");
			elseif (get_module_pref("seemaxhitpoints")==1 || $mastersee==1) output("`\$Maxhitpoints: `@$row2[maxhitpoints]`n");
			if (get_module_setting("sseeturns")==1 || $masterssee==1) output("`^Turns: `@$row2[turns]`n");
			elseif (get_module_pref("seeturns")==1 || $mastersee==1) output("`\$Turns: `@$row2[turns]`n");
			if (get_module_setting("sseepvps")==1 || $masterssee==1) output("`^Player Fights: `@$row2[playerfights]`n");
			elseif (get_module_pref("seepvps")==1 || $mastersee==1) output("`\$Player Fights: `@$row2[playerfights]`n");
			if (get_module_setting("sseefavor")==1 || $masterssee==1) output("`^Favor: `@$row2[deathpower]`n");
			elseif (get_module_pref("seefavor")==1 || $mastersee==1) output("`\$Favor: `@$row2[deathpower]`n");
			if (get_module_setting("sseelaston")==1 || $masterssee==1) output("`^Last On: `@$row2[laston]`n");
			elseif (get_module_pref("seelaston")==1 || $mastersee==1) output("`\$Last On: `@$row2[laston]`n");
		break;
	}
	return $args;
}
function bioviewing_run(){
}
?>
