<?php
function nocreate_getmoduleinfo(){
	$info = array(
		"name"=>"No New Account Creation",
		"version"=>"1.0",
		"author"=>"Catscradler",
		"category"=>"Administrative",
		"download"=>"http://dragonprime.net",
	);
	return $info;
}

function nocreate_install(){
	module_addhook("index");
	module_addhook("header-create");
	return true;
}

function nocreate_uninstall(){
	return true;
}

function nocreate_dohook($hookname,$args){
	switch($hookname){

		case "index":
			blocknav("create.php");
			break;

		case "header-create":
			$op=httpget("op");
			if ($op=="" || $op=="create"){
				require_once("lib/forcednavigation.php");
				do_forced_nav(false, false);
			}
			break;
	}
	return $args;
}
?>
