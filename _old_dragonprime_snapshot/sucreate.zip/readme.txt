Two files in this archive:


sucreate.php - Adds a link in the Grotto so User Editors can make new characters.

nocreate.php - Prevents anonymous account creation. This is an alternative to the Game Setting "Allow creation of new characters".  You only really need to install this if you want an invite-only game and are using sucreate.