<? 
/********************
Warrior Diamond Statue - belongs with Diamond Hills 
Written by Robert for Maddnet LoGD
*********************/
require_once "common.php"; 
addcommentary(); 
checkday(); 

if ($session['user']['alive']){ }else{
	redirect("shades.php");
}

addnav("Diamond Statue"); 
addnav(""); 
addnav("path leading");
addnav("(C) to Castle Gwen","castlegwen.php");    
addnav("(D) to Diamond Hills","diamondhills.php");    
 
page_header("The Warrior Diamond Statue"); 
output("`^`c`bThe Warrior Diamond Statue`b`c `n");
output("`3`cThe estate of the late Lady Dianne of Castle Gwen`c `n`n");
output(" `2You approach a statue made of grey stone. `n"); 
output(" Dressed in a Chainmail and holding a Short Sword.`n"); 
output(" The pose of the statue brings tears to your eyes as it is very beautiful. `n");
output(" You have fond memories of the late `3Warrior Diamond`2. `n");
output(" A tragic story of her demise, a warrior with so much promise, eaten alive by the Green Dragon. `n");
output(" The tales of her quests and battles are still told in the Lazy Dragon Inn. `n");
output("`2You can also see the clock tower of `3Diamond Hills `2, tall majestic tower with a clock.`n"); 
 

page_footer(); 
?> 