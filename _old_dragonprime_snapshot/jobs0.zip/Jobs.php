<?php
/*
employment mod by Mr.FixIt

You must have Voratus potions mod installed or change the potion perks.
You must have Lonnys trading game mod installed or change the trading item perks.
Thanks to Voratus and Lonny for such great mods, without them this mod would not be the same.

Instructions:
ALTER TABLE `accounts` ADD `applytoday` TINYINT( 1 ) DEFAULT '0' NOT NULL ,
ADD `job` VARCHAR( 11 ) DEFAULT '0' NOT NULL ;

On common.php find: 
$spirits=array("-15"=>"Resurrected","-2"=>"Very Low","-1"=>"Low","0"=>"Normal","1"=>"High","2"=>"Very High");
after put:
$job=array("0"=>"None","1"=>"Trashman","2"=>"Farmhand","3"=>"Seamstress","4"=>"Guardsman","5"=>"Carpenter","6"=>"Chef","7"=>"Hostess","8"=>"Lumberjack","9"=>"Rancher","10"=>"Goldminer","11"=>"Doctor","12"=>"Lawyer","13"=>"Judge","14"=>"Banker","15"=>"CEO");       

On common.php find: 
.templatereplace("statrow",array("title"=>"Armor","value"=>$u['armor']))
after put:
.templatereplace("statrow",array("title"=>"Occupation","value"=>"".$job[(string)$u['job']].""))

add to newday.php:
$session['user']['applytoday'] = 0;

add to newday.php(before footer):
if ($session['user']['job']==1) {
$session['user']['turns'] -= 5; 
$goldplus = ($session['user']['level']*90); 
$experienceplus = ($session['user']['level']*70);
$session['user']['gold'] += $goldplus; 
$session['user']['experience'] += $experienceplus; 
output("`nBecause your a  Trashman:`n");
output("`nYour paycheck is $goldplus gold.`n");
output("`nYou gained $experienceplus experience points.`n");
$perk=e_rand(1,3);
$session['user']['frog']+=$perk;
output("`nYou found $perk frog legs.`n");
$perk1=e_rand(1,2);
$session['user']['wort']+=$perk1;
output("`nYou found $perk1 wort.`n");
output("`nYou spent five forest fights working today.`n");
}
elseif ($session['user']['job']==2) {
$session['user']['turns'] -= 5; 
$goldplus = ($session['user']['level']*95); 
$experienceplus = ($session['user']['level']*75);
$session['user']['gold'] += $goldplus; 
$session['user']['experience'] += $experienceplus; 
output("`nBecause your a Farmhand.`n");
output("`nYour paycheck is $goldplus gold.`n");
output("`nYou gained $experienceplus experience points.`n");
$perk=e_rand(20,30);
$session['user']['worms']+=$perk;
output("`nYou dug up $perk worms.`n");
output("`nYou spent five forest fights working today.`n");
}
elseif ($session['user']['job']==3) {
$session['user']['turns'] -= 5; 
$goldplus = ($session['user']['level']*95); 
$experienceplus = ($session['user']['level']*75);
$session['user']['gold'] += $goldplus; 
$session['user']['experience'] += $experienceplus; 
output("`nBecause your a Seamstress.`n");
output("`nYour paycheck is $goldplus gold.`n");
output("`nYou gained $experienceplus experience points.`n");
$perk=e_rand(40,50);
$session['user']['fox']+=$perk;
output("`nYou got $perk fox pelts.`n");
output("`nYou spent five forest fights working today.`n");
}
elseif ($session['user']['job']==4) {
$session['user']['turns'] -= 5; 
$goldplus = ($session['user']['level']*95); 
$experienceplus = ($session['user']['level']*75);
$session['user']['gold'] += $goldplus; 
$session['user']['experience'] += $experienceplus; 
output("`nBecause your a Guardsman.`n");
output("`nYour paycheck is $goldplus gold.`n");
output("`nYou gained $experienceplus experience points.`n");
$session[bufflist][111] = array("name"=>"Guardsman Bonus","rounds"=>20,"wearoff"=>"You bonus is gone for today.","atkmod"=>1.1,"roundmsg"=>"Because your a guardsman you have a little advantage.","activate"=>"offense");
output("`nYou spent five forest fights working today.`n");       
}
elseif ($session['user']['job']==5) {
$session['user']['turns'] -= 5; 
$goldplus = ($session['user']['level']*100); 
$experienceplus = ($session['user']['level']*80);
$session['user']['gold'] += $goldplus; 
$session['user']['experience'] += $experienceplus; 
output("`nBecause your a Carpenter.`n");
output("`nYour paycheck is $goldplus gold.`n");
output("`nYou gained $experienceplus experience points.`n");
$session[bufflist][111] = array("name"=>"Carpenter Bonus","rounds"=>20,"wearoff"=>"Your hammer broke.","atkmod"=>1.2,"roundmsg"=>"You smash your foe with your hammer.","activate"=>"offense");
output("`nYou spent five forest fights working today.`n");    
}
elseif ($session['user']['job']==6) {
$session['user']['turns'] -= 5; 
$goldplus = ($session['user']['level']*100); 
$experienceplus = ($session['user']['level']*80);
$session['user']['gold'] += $goldplus; 
$session['user']['experience'] += $experienceplus; 
output("`nBecause your a Chef.`n");
output("`nYour paycheck is $goldplus gold.`n");
output("`nYou gained $experienceplus experience points.`n");
$perk=e_rand(35,45);
$session['user']['fish']+=$perk;
output("`nYou got $perk fish eyes.`n");
output("`nYou spent five forest fights working today.`n");
}
elseif ($session['user']['job']==7) {
$session['user']['turns'] -= 5; 
$goldplus = ($session['user']['level']*100); 
$experienceplus = ($session['user']['level']*80);
$session['user']['gold'] += $goldplus; 
$session['user']['experience'] += $experienceplus; 
output("`nBecause your a Hostess.`n");
output("`nYour paycheck is $goldplus gold.`n");
output("`nYou gained $experienceplus experience points.`n");
$perk=e_rand(250,300);
$session['user']['gold']+=$perk;
output("`nYou got $perk gold in tips.`n");
output("`nYou spent five forest fights working today.`n");
}
elseif ($session['user']['job']==8) {
$session['user']['turns'] -= 5; 
$goldplus = ($session['user']['level']*105); 
$experienceplus = ($session['user']['level']*85);
$session['user']['gold'] += $goldplus; 
$session['user']['experience'] += $experienceplus; 
output("`nBecause your a  Lumberjack.`n");
output("`nYour paycheck is $goldplus gold.`n");
output("`nYou gained $experienceplus experience points.`n");
$session[bufflist][111] = array("name"=>"Lumberjack Bonus","rounds"=>20,"wearoff"=>"Your axe broke.","atkmod"=>1.3,"roundmsg"=>"You chop your foe with your axe.","activate"=>"offense");
output("`nYou spent five forest fights working today.`n");
}
elseif ($session['user']['job']==9) {
$session['user']['turns'] -= 5; 
$goldplus = ($session['user']['level']*105); 
$experienceplus = ($session['user']['level']*85);
$session['user']['gold'] += $goldplus; 
$session['user']['experience'] += $experienceplus; 
output("`nBecause your a Rancher.`n");
output("`nYour paycheck is $goldplus gold.`n");
output("`nYou gained $experienceplus experience points.`n");
$perk=e_rand(30,40);
$session['user']['bat']+=$perk;
output("`nYou got $perk bat wings.`n");
output("`nYou spent five forest fights working today.`n");
}
elseif ($session['user']['job']==10) {
$session['user']['turns'] -= 5; 
$goldplus = ($session['user']['level']*105); 
$experienceplus = ($session['user']['level']*85);
$session['user']['gold'] += $goldplus; 
$session['user']['experience'] += $experienceplus; 
output("`nBecause your a Gold Miner.`n");
output("`nYour paycheck is $goldplus gold.`n");
output("`nYou gained $experienceplus experience points.`n");
$perk=e_rand(350,400);
$session['user']['gold']+=$perk;
output("`nYou found $perk extra gold.`n");
output("`nYou spent five forest fights working today.`n");
}
elseif ($session['user']['job']==11) {
$session['user']['turns'] -= 5; 
$goldplus = ($session['user']['level']*120); 
$experienceplus = ($session['user']['level']*100);
$session['user']['gold'] += $goldplus; 
$session['user']['experience'] += $experienceplus; 
output("`nBecause your a Doctor.`n");
output("`nYour paycheck is $goldplus gold.`n");
output("`nYou gained $experienceplus experience points.`n");
$session['user']['potions'] ++; 
$session['user']['medheal'] ++;  
output("`nYou got a normal healing potion.`n"); 
output("`nYou spent five forest fights working today.`n");  
}
elseif ($session['user']['job']==12) {
$session['user']['turns'] -= 5; 
$goldplus = ($session['user']['level']*120); 
$experienceplus = ($session['user']['level']*100);
$session['user']['gold'] += $goldplus; 
$session['user']['experience'] += $experienceplus; 
output("`nBecause your a  Lawyer.`n");
output("`nYour paycheck is $goldplus gold.`n");
output("`nYou gained $experienceplus experience points.`n");
$session[bufflist][111] = array("name"=>"Lawyer Bonus","rounds"=>30,"wearoff"=>"You bonus is gone for today.","defmod"=>1.3,"roundmsg"=>"Because your a lawyer you have a little advantage.","activate"=>"offense");
output("`nYou spent five forest fights working today.`n");
}
elseif ($session['user']['job']==13) {
$session['user']['turns'] -= 5; 
$goldplus = ($session['user']['level']*130); 
$experienceplus = ($session['user']['level']*110);
$session['user']['gold'] += $goldplus; 
$session['user']['experience'] += $experienceplus; 
output("`nBecause your a Judge.`n");
output("`nYour paycheck is $goldplus gold.`n");
output("`nYou gained $experienceplus experience points.`n");
$perk=e_rand(450,500);
$session['user']['gold']+=$perk;
output("`nYou got $perk gold in bribes.`n");
$session['user']['potions'] ++; 
$session['user']['greatheal'] ++;  
output("`nYou got a greater healing potion.`n"); 
output("`nYou spent five forest fights working today.`n");
}
 elseif ($session['user']['job']==14) {
$session['user']['turns'] -= 5; 
$goldplus = ($session['user']['level']*140); 
$experienceplus = ($session['user']['level']*120);
$session['user']['gold'] += $goldplus; 
$session['user']['experience'] += $experienceplus; 
output("`nBecause your a Banker.`n");
output("`nYour paycheck is $goldplus gold.`n");
output("`nYou gained $experienceplus experience points.`n");
$perk=e_rand(550,600);
$session['user']['gold']+=$perk;
output("`nYou got $perk gold in interest.`n");
$session['user']['potions'] ++; 
$session['user']['greatheal'] ++;  
}
elseif ($session['user']['job']==15) {
$session['user']['turns'] -= 5; 
$goldplus = ($session['user']['level']*150); 
$experienceplus = ($session['user']['level']*130);
$session['user']['gold'] += $goldplus; 
$session['user']['experience'] += $experienceplus; 
output("`nYour paycheck is $goldplus gold.`n");
output("`nYou gained $experienceplus experience points.`n");
output("`nBecause your a CEO.`n");
$session['user']['gems'] ++;  
output("`nYou got a gem.`n"); 
$session['user']['potions'] ++; 
$session['user']['fullheal'] ++;  
output("`nYou got a full healing potion.`n"); 
}

END edit newday.php

Add employment.php to your main folder and link to it (default return is village.)

*/
require_once "common.php"; 
checkday(); 
page_header("Employment Office"); 
switch($HTTP_GET_VARS[op]) 
{ 
case "": 
if ($session['user']['job']>= 1) {
output("You already have a job. If you want a new job you have to quit your old one first.`n");
}
else {
if ($session['user']['applytoday']>=1) output("You've already applied for a job today, please come back tommorow.");
if ($session['user']['applytoday']==0) addnav("Trashman","employment.php?op=Trashman");
if ($session['user']['dragonkills']>=1 && $session['user']['applytoday']==0) addnav("Farmhand","employment.php?op=Farmhand");
if ($session['user']['dragonkills']>=1 && $session['user']['applytoday']==0) addnav("Seamstress","employment.php?op=Seamstress");
if ($session['user']['dragonkills']>=1 && $session['user']['applytoday']==0) addnav("Guardsman","employment.php?op=Guardsman");
if ($session['user']['dragonkills']>=3 && $session['user']['applytoday']==0) addnav("Carpenter","employment.php?op=Carpenter");
if ($session['user']['dragonkills']>=3 && $session['user']['applytoday']==0) addnav("Chef","employment.php?op=Chef");
if ($session['user']['dragonkills']>=3 && $session['user']['applytoday']==0) addnav("Hostess","employment.php?op=Hostess");
if ($session['user']['dragonkills']>=5 && $session['user']['applytoday']==0) addnav("Lumberjack","employment.php?op=Lumberjack");
if ($session['user']['dragonkills']>=5 && $session['user']['applytoday']==0) addnav("Rancher","employment.php?op=Rancher");
if ($session['user']['dragonkills']>=5 && $session['user']['applytoday']==0) addnav("Gold Miner","employment.php?op=Miner");
if ($session['user']['dragonkills']>=10 && $session['user']['applytoday']==0) addnav("Doctor","employment.php?op=Doctor");
if ($session['user']['dragonkills']>=10 && $session['user']['applytoday']==0) addnav("Lawyer","employment.php?op=Lawyer");
if ($session['user']['dragonkills']>=15 && $session['user']['applytoday']==0) addnav("Judge","employment.php?op=Judge");
if ($session['user']['dragonkills']>=20 && $session['user']['applytoday']==0) addnav("Banker","employment.php?op=Banker");
if ($session['user']['dragonkills']>=25 && $session['user']['applytoday']==0) addnav("CEO","employment.php?op=CEO");
if ($session['user']['applytoday']==0) output("`n`bAll jobs cost five forest fights per new day.`b`n");
if ($session['user']['applytoday']==0) output("`nAs a trashman your benefits are few and your pay is minimum. `nOne good thing is you always find something in the trash to sell.`n");
if ($session['user']['dragonkills']>=1 && $session['user']['applytoday']==0) output("`nAs a Farmhand you lead an average life. `nOne good thing is your always digging things up like worms to sell.`n");
if ($session['user']['dragonkills']>=1 && $session['user']['applytoday']==0) output("`nAs a Seamstress you lead an average life. `nOne good thing is you always have left over things like fox pelts to sell.`n");
if ($session['user']['dragonkills']>=1 && $session['user']['applytoday']==0) output("`nAs a Guardsman you lead an average life. `nOne good thing is you get a little bonus in battle.`n");
if ($session['user']['dragonkills']>=3 && $session['user']['applytoday']==0) output("`nAs a Carpenter you lead a pretty decent life. `nOne good thing is you can use your hammer in battle.`n");
if ($session['user']['dragonkills']>=3 && $session['user']['applytoday']==0) output("`nAs a Chef you lead a pretty decent life. `nOne good thing is you cook alot of fish and you always save the eyes to sell.`n");
if ($session['user']['dragonkills']>=3 && $session['user']['applytoday']==0) output("`nAs a Hostess you lead a pretty decent life. `nOne good thing is you always get good tips from your customers.`n");
if ($session['user']['dragonkills']>=5 && $session['user']['applytoday']==0) output("`nAs a Lumberjack you lead a rough life, but the money is right. `nOne good thing is you can chop your enemy's with your axe.`n");
if ($session['user']['dragonkills']>=5 && $session['user']['applytoday']==0) output("`nAs a Rancher you lead a rough life, but the money is right. `nOne good thing is you kill bats near your fields and sell their wings`n");
if ($session['user']['dragonkills']>=5 && $session['user']['applytoday']==0) output("`nAs a Gold Miner you lead a rough life, but the money is right. `nOne good thing is you always find extra gold.`n");
if ($session['user']['dragonkills']>=10 && $session['user']['applytoday']==0) output("`nAs a Doctor you lead a great life. `nOne good thing is you always start the day with an extra potion.`n");
if ($session['user']['dragonkills']>=10 && $session['user']['applytoday']==0) output("`nAs a Lawyer you lead a great life. `nOne good thing is you get a little bonus in battle.`n");
if ($session['user']['dragonkills']>=15 && $session['user']['applytoday']==0) output("`nAs a Judge you lead a very terrific life. `nOne good thing is you get some bribes to help your expensive tastes.`n");
if ($session['user']['dragonkills']>=20 && $session['user']['applytoday']==0) output("`nAs a Banker you lead an almost perfect life. `nOne good thing is you get extra interest.`n");
if ($session['user']['dragonkills']>=25 && $session['user']['applytoday']==0) output("`nAs a CEO you lead the best life. `nOne good thing is you get a very special bonus everyday.`n");
}
if ($session['user']['job']>= 1) addnav("Quit Job","employment.php?op=Quitjob"); 
break;

case "Trashman": 
$hire=e_rand(1,10);
switch ($hire){
case 1:
case 2:
case 3:
case 4:
case 5:
case 6:
case 7:
case 8:
case 9:
output("You're Hired!! Your job starts the next new day.");
$session['user']['job'] = 1;
break;
case 10:
output("Sorry, you've been turned down for the job. Please try again tommorow.");
$session['user']['applytoday'] = 1;
break;
}  
break;

case "Farmhand": 
$hire=e_rand(1,10);
switch ($hire){
case 1:
case 2:
case 3:
case 4:
case 5:
case 6:
case 7:
case 8:
output("You're Hired!! Your job starts the next new day.");
$session['user']['job'] = 2;
break;
case 9:
case 10:
output("Sorry, you've been turned down for the job. Please try again tommorow.");
$session['user']['applytoday'] = 1;
break;
}  
break;

case "Seamstress": 
$hire=e_rand(1,10);
switch ($hire){
case 1:
case 2:
case 3:
case 4:
case 5:
case 6:
case 7:
case 8:
output("You're Hired!! Your job starts the next new day.");
$session['user']['job'] = 3;
break;
case 9:
case 10:
output("Sorry, you've been turned down for the job. Please try again tommorow.");
$session['user']['applytoday'] = 1;
break;
}  
break;

case "Guardsman": 
$hire=e_rand(1,10);
switch ($hire){
case 1:
case 2:
case 3:
case 4:
case 5:
case 6:
case 7:
case 8:
output("You're Hired!! Your job starts the next new day.");
$session['user']['job'] = 4;
break;
case 9:
case 10:
output("Sorry, you've been turned down for the job. Please try again tommorow.");
$session['user']['applytoday'] = 1;
break;
}  
break;

case "Carpenter": 
$hire=e_rand(1,10);
switch ($hire){
case 1:
case 2:
case 3:
case 4:
case 5:
case 6:
case 7:
output("You're Hired!! Your job starts the next new day.");
$session['user']['job'] = 5;
break;
case 8:
case 9:
case 10:
output("Sorry, you've been turned down for the job. Please try again tommorow.");
$session['user']['applytoday'] = 1;
break;
}  
break;

case "Chef": 
$hire=e_rand(1,10);
switch ($hire){
case 1:
case 2:
case 3:
case 4:
case 5:
case 6:
case 7:
output("You're Hired!! Your job starts the next new day.");
$session['user']['job'] = 6;
break;
case 8:
case 9:
case 10:
output("Sorry, you've been turned down for the job. Please try again tommorow.");
$session['user']['applytoday'] = 1;
break;
}  
break;

case "Hostess": 
$hire=e_rand(1,10);
switch ($hire){
case 1:
case 2:
case 3:
case 4:
case 5:
case 6:
case 7:
output("You're Hired!! Your job starts the next new day.");
$session['user']['job'] = 7;
break;
case 8:
case 9:
case 10:
output("Sorry, you've been turned down for the job. Please try again tommorow.");
$session['user']['applytoday'] = 1;
break;
}  
break;

case "Lumberjack": 
$hire=e_rand(1,10);
switch ($hire){
case 1:
case 2:
case 3:
case 4:
case 5:
case 6:
output("You're Hired!! Your job starts the next new day.");
$session['user']['job'] = 8;
break;
case 7:
case 8:
case 9:
case 10:
output("Sorry, you've been turned down for the job. Please try again tommorow.");
$session['user']['applytoday'] = 1;
break;
}  
break;

case "Rancher": 
$hire=e_rand(1,10);
switch ($hire){
case 1:
case 2:
case 3:
case 4:
case 5:
case 6:
output("You're Hired!! Your job starts the next new day.");
$session['user']['job'] = 9;
break;
case 7:
case 8:
case 9:
case 10:
output("Sorry, you've been turned down for the job. Please try again tommorow.");
$session['user']['applytoday'] = 1;
break;
}  
break;

case "Miner": 
$hire=e_rand(1,10);
switch ($hire){
case 1:
case 2:
case 3:
case 4:
case 5:
case 6:
output("You're Hired!! Your job starts the next new day.");
$session['user']['job'] = 10;
break;
case 7:
case 8:
case 9:
case 10:
output("Sorry, you've been turned down for the job. Please try again tommorow.");
$session['user']['applytoday'] = 1;
break;
}  
break;

case "Doctor": 
$hire=e_rand(1,10);
switch ($hire){
case 1:
case 2:
case 3:
case 4:
case 5:
output("You're Hired!! Your job starts the next new day.");
$session['user']['job'] = 11;
break;
case 6:
case 7:
case 8:
case 9:
case 10:
output("Sorry, you've been turned down for the job. Please try again tommorow.");
$session['user']['applytoday'] = 1;
break;
}  
break;

case "Lawyer": 
$hire=e_rand(1,10);
switch ($hire){
case 1:
case 2:
case 3:
case 4:
case 5:
output("You're Hired!! Your job starts the next new day.");
$session['user']['job'] = 12;
break;
case 6:
case 7:
case 8:
case 9:
case 10:
output("Sorry, you've been turned down for the job. Please try again tommorow.");
$session['user']['applytoday'] = 1;
break;
}  
break;

case "Judge": 
$hire=e_rand(1,10);
switch ($hire){
case 1:
case 2:
case 3:
case 4:
output("You're Hired!! Your job starts the next new day.");
$session['user']['job'] = 13;
break;
case 5:
case 6:
case 7:
case 8:
case 9:
case 10:
output("Sorry, you've been turned down for the job. Please try again tommorow.");
$session['user']['applytoday'] = 1;
break;
}  
break;

case "Banker": 
$hire=e_rand(1,10);
switch ($hire){
case 1:
case 2:
case 3:
output("You're Hired!! Your job starts the next new day.");
$session['user']['job'] = 14;
break;
case 4:
case 5:
case 6:
case 7:
case 8:
case 9:
case 10:
output("Sorry, you've been turned down for the job. Please try again tommorow.");
$session['user']['applytoday'] = 1;
break;
}  
break;

case "CEO": 
$hire=e_rand(1,10);
switch ($hire){
case 1:
case 2:
output("You're Hired!! Your job starts the next new day.");
$session['user']['job'] = 15;
break;
case 3:
case 4:
case 5:
case 6:
case 7:
case 8:
case 9:
case 10:
output("Sorry, you've been turned down for the job. Please try again tommorow.");
$session['user']['applytoday'] = 1;
break;
}  
break;

case "Quitjob": 
$session['user']['job'] = 0;
$session['user']['applytoday'] = 0;
addnav("Return to Office","employment.php");
break;

}
addnav("Leave Office","village.php");
page_footer(); 
?> 