<?


require_once "common.php";
require_once("lib/http.php");
require_once("lib/villagenav.php");

function exchange_getmoduleinfo(){
                    $info = array(
                       "name"=>"Exchange",
                       "version"=>"1.0",
                       "author"=>"ShadowRaven",
                       "category"=>"Village",
                       "download"=>"http://dragonprime.net/users/ShadowRaven/Exchange.zip",
                "settings"=>array(
                
                "Renaming shop Settings,title",
                 "shopname"=>"what is the name of the shop?,|The Forge",
                 "mindk"=>"Minimum Dragon kills for shop to show?,int|0",
                 "agems"=>"Cost in Gems to rename armor,int|10",
                 "agold"=>"Cost in Gold to rename armor,int|10000",
                 "wgems"=>"Cost in Gems to rename weapon,int|10",
                 "wgold"=>"Cost in Gold to rename weapon,int|10000",
                 ),

        );
return $info;
}
function exchange_install(){
    module_addhook("village");
    output("installing Exchange");
    return true;
}
function exchange_uninstall(){
    output("uninstalling exchange");
    return true;
}
function exchange_dohook($hookname,$args){
    global $session;
    $name = get_module_setting("shopname");
    $mindk = get_module_setting("mindk");
    switch($hookname){
    case "arcadia":
    if ($session['user']['dragonkills']>= $mindk){

        addnav(array(" %s `0",$name),"runmodule.php?module=exchange");
        }
                break;
                }
        return $args;
}
function exchange_run(){
global $session;
        $name = get_module_setting("shopname");
        $mindk = get_module_setting("mindk");
        $agems = get_module_setting("agems");
        $agold = get_module_setting("agold");
        $wgems = get_module_setting("wgems");
        $wgold = get_module_setting("wgold");
        $op = httpget("op");
        if($op==""){
        page_header(" %s ",$name);
        output("You walk into large building and look around. All around you are more weapons and armor than you can even begin to count!`nThe blacksmith looks over at you and smiles...\"Welcome to %s ! I have many different types of weapons and armor, I might even have some with the same values as yours!`nWhich would you like the exchange first?\" ",$name);
        output("`n`nHe then mumbles something about a price of %s gold and %s gems to exchange a weapon and %s gems and %s gold to exchange armor",$wgold,$wgems,$agems,$agold);
                addnav("Exchange Weapon","runmodule.php?module=exchange&op=chweapon");
                addnav("Exchange Armor","runmodule.php?module=exchange&op=charmor");
                villagenav();
        page_footer();
        }

        if($op=="chweapon"){
        page_header("Name Weapon");

          if($session['user']['gems'] < $wgems or $session['user']['gold'] < $wgold){
          output("You dig through your pockets but can't seem to find the amount of gold or gems to pay and decide to come back later");
          output("`n`nThe Blacksmith grumbles as he shows you the door");
          villagenav();
          }elseif($session['user']['gems'] > $wgems or $session['user']['gold'] > $wgold){
            output("Ahhh, Wonderful! Just Type in the name of what you want for your weapon and I'll see if its available!");
            rawoutput("<form action='runmodule.php?module=exchange&op=weapondone' method='POST'>");
            //rawoutput("<form action='runmodule.php?module=exchange&op=confirm' method='POST'>");
            rawoutput("<input id='input' name='weaponname'>");
            rawoutput("<input type='submit' class='button' value='rename'>");
            rawoutput("</form>");
            rawoutput("<script language='javascript'>document.getElementById('input').focus();</script>",true);

             addnav("","runmodule.php?module=exchange&op=weapondone");
             //addnav("","runmodule.php?module=exchange&op=confirm");
             addnav("Maybe later","runmodule.php?module=exchange");
            }
           page_footer();
       }
        /*if($op=="confirm"){
        page_header("Confirmation");
         $wname = httppost('weaponname');
        output("Are you sure you want this name: %s  ?",$wname);
        addnav("Yes","runmodule.php?module=exchange&op=weapondone");
        addnav("no, go back","runmodule.php?module=exchange&op=chweapon");

           page_footer();
         }*/
         if($op=="weapondone"){
          $wgems = get_module_setting('wgems');
         $wgold = get_module_setting('wgold');
         page_header("Weapon exchanged!");
        $wname = httppost('weaponname');
         output("Your Weapon has been changed to: %s !",$wname);

        $session['user']['weapon']=$wname;
         $session['user']['gems']-=$wgems;
         $session['user']['gold']-=$wgold;
        addnav("Back to shop","runmodule.php?module=exchange");
        villagenav();
        page_footer();
                }
       if($op=="charmor"){
        page_header("Name Armor");

          if($session['user']['gems'] < $agems or $session['user']['gold'] < $agold){
          output("You dig through your pockets but can't seem to find the amount of gold or gems to pay and decide to come back later");
          output("`n`nThe Blacksmith grumbles as he shows you the door");
          villagenav();
          }elseif($session['user']['gems'] > $agems or $session['user']['gold'] > $agold){
            output("Ahhh, Wonderful! Just Type in the name of what you want for your armor and I'll see if its available!");
            //rawoutput("<form action='runmodule.php?module=exchange&op=confirm2' method='POST'>");
            rawoutput("<form action='runmodule.php?module=exchange&op=armordone' method='POST'>");
            rawoutput("<input id='input' name='armorname'>");
            rawoutput("<input type='submit' class='button' value='rename'>");
            rawoutput("</form>");
            rawoutput("<script language='javascript'>document.getElementById('input').focus();</script>",true);

             addnav("","runmodule.php?module=exchange&op=armordone");
             //addnav("","runmodule.php?module=exchange&op=confirm2");
             addnav("Maybe later","runmodule.php?module=exchange");
            }
           page_footer();
       }
        /*if($op=="confirm2"){
        page_header("Confirmation");
         $aname = httppost('armorname');
        output("Are you sure you want this name: %s  ?",$aname);
        addnav("Yes","runmodule.php?module=exchange&op=armordone");
        addnav("no, go back","runmodule.php?module=exchange&op=charmor");

           page_footer();
         }*/
         if($op=="armordone"){
        $agold = get_module_setting('agold');
        $agems = get_module_setting('agems');
page_header("Armor exchanged!");
        $aname = httppost('armorname');
           output("Your Armor has been changed to: %s!",$aname);
        $session['user']['armor']=$aname;
        $session['user']['gems']-=$agems;
        $session['user']['gold']-=$agold;
        addnav("Back to shop","runmodule.php?module=exchange");
        villagenav();
        page_footer();
                }
                
                
        }
?>
