<?php
/* 
/ pietre.php - Magic Stones V0.2.1 
/ Originally by Excalibur (www.ogsi.it) 
/ English cleanup by Talisman (dragonprime.cawsquad.net) 
/ Original concept from Aris (www.ogsi.it) 
/ May 2004 
/ deutsch by theKlaus 

----install-instructions-------------------------------------------------- 
DIFFICULTY SCALE: easy 

Forest Event for LotGD 0.9.7 
Drop into your "Specials" folder 
-------------------------------------------------------------------------- 
SQL Modification 
# 
# Table structure `pietre` 
# 

CREATE TABLE `pietre` ( 
`pietra` int(4) unsigned NOT NULL default '0', 
`owner` int(4) unsigned NOT NULL default '0' 
) TYPE=MyISAM; 

ALTER TABLE accounts ADD pietra int(4) unsigned NOT NULL default '0'; 
-------------------------------------------------------------------------- 
----- In File: 
newday.php 

----- Find: 
$config = unserialize($session['user']['donationconfig']); 

----- Add before: 
//Modification for pietre.php 
$flagstone=$session[user][pietra]; 
if ($flagstone != 0) { 
if ($flagstone != 1) { 
output("`n`n`@Da du den {$pietre[$flagstone]} `@besitzt, erh�ltst du einen zus�tzlichen Waldkampf !`n"); 
$session[user][turns]+=1; 
} else { 
output("`n`n`\$Da du den {$pietre[$flagstone]} `\$besitzt, verlierst du einen Waldkampf !`n"); 
$session[user][turns]-=1; 
} 
} 
//end pietre.php modification 


----- In File: 
common.php 

----- Find: 
$races=array(1=>"Troll",2=>"Elf",3=>"Human",4=>"Dwarf"); 

----- Add before: 

$pietre=array(1=>"`\$Poker Stein",2=>"`^Liebes Stein",3=>"`^Freundschafts Stein",4=>"`#K�nigs Stein",5=>"`#AllMighthys Stein",6=>"`#Pegasus Stein",7=>"`@Aris Stein",8=>"`@Excaliburs Stein",9=>"`@Lukes Stein",10=>"`&Stein der Unschuld",11=>"`#Stein der K�nigin",12=>"`#Stein des Eroberers",13=>"`!Goldener Stein",14=>"`%Kraft Stein",15=>"`\$Ramius Stein",16=>"`#Cedriks Stein",17=>"`%Baldurs Stein",18=>"`&Stein der Reinheit",19=>"`&Stein des Lichts",20=>"`&Ladys Stein"); 

----- In File: 
dragon.php 

----- Find: 
,"beta"=>1 

----- Add After: 
,"pietra"=>1 

-------------------------------------------------------------------------- 

Drop the code of monpietre.php where you like ... You can put in in hof.php (the new version from 0.9.8) 
or you use it "as is" giving a link from village. 

Version History: 
Ver. Alpha Created by Excalibur (www.ogsi.it) 
Original Version posted to DragonPrime 

// -Originally by: Excalibur 
// -Contributors: Excalibur, Talisman 
// May 2004 
*/ 

page_header("Allmightys Quelle"); 
output("<font size='+1'>`c`b`!Allmightys Quelle`b`c`n</font>",true); 
$session['user']['specialinc']="pietre.php"; 
$numpietre="20"; 
if ($session['user']['pietra']==0){ 
switch($HTTP_GET_VARS[op]){ 
case "": 
page_header("Die Quelle"); 
output("`@Auf deinem Weg durch den Wald, auf der Suche nach Abenteuern, findest du eine klare Quelle, die einen �bernat�rlcihen Schein ausstrahlt. Du bist durch Zufall �ber `&AllMightys magische Quelle`@ gestolpert, `nbenannt nach der wandelnden Sage, die sie entdeckt hat."); 
output("`n`nEs ist nur sehr wenig �ber sie bekannt. AllMighty hat ein paar ihrer Geheimnisse gel�ftet, `nwelche in einem geheimen Buch aufgeschrieben hat. `nEr entdeckte unter anderem, dass die Steine, die man dort findet eine einzigartige Kraft entwickeln. Sie k�nnen `ndie Energie des Besitzers erh�hen und schenken ihm jeden Tag einen zus�tzlichen Waldkampf.`n"); 
output("Die Anzahl der Steine ist begrenzt, und jeder Stein kann nur von einem Krieger zur gleichen Zeit besessen werden. `nMit etwas Gl�ck kannst du einen dieser Steine besitzen.`n`n"); 
output("Du bemerkst einen Knopf, der in den Felsen nahe der Quelle eingelassen ist. Er ist mit magische Symbolen beschriftet. `n"); 
output("Du verstehst deren Sinn nicht - sind sie eine Einladung? Oder...vielleicht...eine Warnung?"); 
addnav("`\$Verlasse die Quelle","forest.php?op=lascia"); 
addnav("`^Dr�cke den Knopf","forest.php?op=premi"); 
break; 
case "premi"; 
output("`@Deine Hand h�lt �ber dem Knopf kurz inne, als du die St�rke der magischen Kraft f�hlen kannst, `ndie von AllMightys Quelle und seinen versteckten Sch�tzen ausgeht.`n"); 
output("Du beginnst dar�ber nachzudenken, ob die Legenden wahr sind, oder ob du einen t�dlichen Fehler begehst.`nAls du dir Aura der Energie f�hlst, die von dem Stein ausgeht, schliesst du die Augen und dr�ckst auf den Knopf. `n"); 
output("Als der Knopf unter dem Druck nachgibt, h�rst du mechanische Ger�usche im Inneren des Felsen. `nAls du deine Augen wieder �ffnest, siehst du was die Quelle dir offenbart. `nEin goldenes Glitzern im Wasser l�sst dich glauben, dass der Erdgott dir einen Gefallen tun wird .... `n`n"); 
$session['user']['specialinc']=""; 
addnav("`@Zur�ck ins Dorf","village.php"); 
addnav("`\$Zur�ck in den Wald","forest.php"); 
$pietra=e_rand(1,$numpietre); 
$sql="SELECT pietra,owner FROM pietre WHERE pietra = $pietra"; 
$result = db_query($sql) or die(db_error(LINK)); 
//$numpietre=db_num_rows($result); 
if (db_num_rows($result) == 0) { 
// The stone is available 
output("`#... du h�rst im Inneren des Felsen etwas rollen und einer der sagenhaften Steine erscheint in der Quelle!! 
`n`nEr hat einige eingravierte Zeichen, "); 
if ($pietra==1){ 
output("und du bemerkst mit Schrecken, dass dies der {$pietre[$pietra]} `#ist!!!`n Der Besitz dieses verfluchten Steins kostet dich jeden Tag einen Waldkampf. `nDeine einzige Hoffnung ist, dass ein anderer ungl�cklicher Krieger �ber `&Allmightys Quelle`# stolpert und den Stein von dir �bernimmt. "); 
$session['user']['turns']-=1; 
$session['user']['pietra']=$pietra; 
$id=$session[user][acctid]; 
$sql="INSERT INTO pietre (pietra,owner) VALUES ('$pietra','$id')"; 
db_query($sql); 
}else{ 
output("und du bemerkst mit Freude, dass es der {$pietre[$pietra]}`# ist!! `nDer Besitz dieses Steines gibt dir jeden Tag eine extra Waldkampf. `nHeute ist ein gl�cklicher Tag, {$session[user][name]}!!!`n"); 
$session['user']['pietra']=$pietra; 
$session['user']['turns']+=1; 
$id=$session[user][acctid]; 
$sql="INSERT INTO pietre (pietra,owner) VALUES ('$pietra','$id')"; 
db_query($sql); 
addnews("`6{$session[user][name]}`#hat den `5{$pietre[$pietra]}`# gefunden!!!"); 
} 
}else{ 
$row = db_fetch_assoc($result); 
output("`# du h�rst ein pfeifendes Ger�usch, das schnell an Intensit�t gewinnt, bis es in ein f�rchterliches Jammern m�ndet, und pl�tzlich h�rt es auf, wie es begann. `nEine tiefe, angenehme Stimme spricht: `n`n\""); 
$caso=e_rand(0,1); 
$account=$row['owner']; 
$sqlz="SELECT name FROM accounts WHERE acctid = $account"; 
$resultz = db_query($sqlz) or die(db_error(LINK)); 
$rowz = db_fetch_assoc($resultz); 
if ($pietra==1) $switch=1; 
if ($caso==0){ 
output("`%".($switch?"Du Gl�ckspilz":"Du Pechvogel").", {$session[user][name]}`%. Der {$pietre[$pietra]}`% ist das Eigentum von `@{$rowz[name]}`%. `nEs liegt nicht in meinem Wesen, ihn ihm wegzunehmen. `nAls Ausgleich wirst du mit `^`b5`b`% zus�tzlichen Waldk�mpfen belohnt, die ich dir sofort zuteile.`#\" `n`nEin Strom von Energie durchfliesst deinen K�rper, und du weisst, dass die Stimme ihr Versprechen gehalten hat!!! `n"); 
$session['user']['turns']+=5; 
}else{ 
output("`^Der Stein, der f�r dich ausgew�hlt wurde, geh�rt `@{$rowz[name]}`^. Da er bei mir an Ansehen verloren hat, `nhabe ich beschlossen, dass er ihn nicht mehr verdient hat und �berlasse den Stein deiner Obhut.`#\". `n`nDu siehst einen wundervollen Stein im Quellwasser erscheinen, `nund nimmst ihn an dich."); 
if ($pietra != 1){ 
output("Du bewunderst den {$pietre[$pietra]}`#, in dem Wissen, dass du ab jetzt jeden Tag einen zus�tzlichen Waldkampf erh�ltst. `n"); 
$session['user']['turns']+=1; 
}else{ 
output("uDu bemerkst mit Schrecken, dass dies der {$pietre[$pietra]} `# ist!!!`n Der Besitz dieses verfluchten Steins kostet dich jeden Tag einen Waldkampf. `nDeine einzige Hoffnung ist, dass ein anderer ungl�cklicher Krieger �ber `&Allmightys Quelle`# stolpert und den Stein von dir �bernimmt."); 
$session['user']['turns']-=1; 
} 
$sqlp="UPDATE accounts SET pietra = '0' WHERE acctid = $account"; 
db_query($sqlp); 
$session['user']['pietra']=$pietra; 
$account1=$session[user][acctid]; 
$sqlr="UPDATE pietre SET owner = $account1 WHERE pietra = $pietra"; 
db_query($sqlr); 
$mailmessage = "`@{$session['user']['name']} `@hat `&AllMightys Quelle`@ entdeckt und der Erdgott hat beschlossen, ihm deinen {$pietre[$pietra]} zu geben`@!! Es ist ein ".($switch?"":"un")."gl�cklicher Tag f�r dich."; 
systemmail($account,"`2Deinen Stein besitzt jetzt {$session['user']['name']} `2",$mailmessage); 
} 
} 
break; 
case "lascia"; 
$session['user']['specialinc']=""; 
$perdita=intval($session[user][maxhitpoints]*0.3); 
$session[user][hitpoints]-=$perdita; 
if ($session[user][hitpoints] < 1) { 
$perdita += $session[user][hitpoints]; 
$session[user][hitpoints] = 1; 
} 
output("`6Erschrocken durch die Macht der Quelle, beschlie�t du, dein Schicksal nicht herauszufordern. `nDu wendest dich ab in Richtung Wald und f�hlst dich in einer tr�gerischen Sicherheit. W�hrend du dich abwendest, h�rst du ein blubberndes Ger�usch `naus der Quelle. `n`n`^Ein Strahl Wasser trifft deinen Hinterkopf wie ein Hammerschlag `nund wirft dich zu Boden!`n`n `\$`bDu verlierst $perdita Lebenspunkte durch den Sturz!!!!`b"); 
addnav("`\$Zur�ck in den Wald","forest.php"); 
break; 
}//chiusura switch 
}else{ //chiusura if iniziale 
$session['user']['specialinc']=""; 
output("`@W�hrend du auf der Suche nach neuen Abenteuern durch den Wald streifst, findest du eine magische Quelle, von der`n ein mystisches Gl�hen ausgeht. Du bist durch Zufall �ber `&AllMightys magische Quelle`@ gestolpert, `nbenannt nach der wandelnden Sage, die sie entdeckt hat."); 
output("`nAber diese Quelle ist dir nicht unbekannt und du weisst sehr wohl �ber ihre magischen Kr�fte bescheid, `nda du ja schon den {$pietre[$session[user][pietra]]} besitzt. `n`nSei nicht gierig und lasse andere Krieger auch von den magischen Kr�ften profitieren. `nW�hrend deines Aufenthalts an der Quelle trinkst du von dem klaren Wasser und f�hlst die erfrischende Wirkung.`n`n`%Du verlierst einen Waldkampf, aber wirst komplett geheilt."); 
$session[user][turns]-=1; 
if ($session[user][hitpoints]<$session[user][maxhitpoints]) $session[user][hitpoints]=$session[user][maxhitpoints]; 
addnav("`\$Zur�ck in den Wald","forest.php"); 
} 
page_footer(); 
?>