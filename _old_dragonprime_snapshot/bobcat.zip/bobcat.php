<?php
//my first module
//with help from tutorial by Shannon Brown. Used template from find_gem core module.
function bobcat_getmoduleinfo(){
	$info = array(
		"name"=>"bobcat",
		"version"=>"1.1",
		"author"=>"Gator
		based on tutorial by Shannon Brown",
		"category"=>"Forest Specials",
		"download"=>"http://dragonprime.net/users/pmccord/bobcat.zip",
	);
	return $info;
}
function bobcat_install(){
	module_addeventhook("forest", "return 100;");
	module_addeventhook("travel", "return 20;");
	return true;
}
function bobcat_uninstall(){
	return true;
}

//this section is used to hook into anther place or event. Not using it in this //module but putting it here for reference use later!!
function bobcat_dohook($hookname,$args){
	return $args;
}

function bobcat_runevent($type,$link)
{
	global $session;
	output("`^You are being stalked by a bobcat, in your haste to run away, you drop a gem in the dirt`0");
	$session['user']['gems']--;
	debuglog("dropped a gem in the dirt");
}
function bobcat_run(){
}
?>