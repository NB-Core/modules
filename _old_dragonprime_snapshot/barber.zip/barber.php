<?php

//By: UnderDark

require_once("common.php");
page_header("The UnderDark Barber Shop");

output("`c`b`#The UnderDark Barber Shop`b`c`n`n");
output("`^You see the resident hair master, Nimbus, making his rounds, cutting hair.`nYou hear thanks and cures directed at him, but he seems unaffected by anything`n");
output("`^`nYou look at the price list:`n");
output("`^-Haircut: 5,000 gold`n");
output("`^-Donate Hair: 500 gold/charm point`n`n");

switch($_GET['op']){
   case "":
	    break;
	 case "cut":
	    if($session[user][gold]<5000)
			   output("`n`n`$ You want a haircut, but they're not free!");
			else{
			   output("`@ Nimbus takes your gold, and then desends upon your hair...`n");
				 $c = rand(1,7);
				 $r = rand(1,2);
				 if ($r == 2)
				 		$c = $c * -1;
				 if ($c < 0){
				 		$t = abs($c);
				 		output("`$ You gasp at the horror that WAS your hair, Nimbus appologizes, but then says that all sales are final`nYou LOSE `&$t`$ charm");
				 }else
				    output("`% You smile as you view your new hair cut`nYou gain `&$c`% charm");
				 $session[user][gold] -= 5000;
				 $session[user][charm] += $c;
			}
			break;
	 case "donate":
	    if($session[user][charm] <= 0)
			   output("`n`nNimbus takes one at your hair and says, \"You know, I think a rat died on your head,\"");
			else{
			   output("`@Nimbus takes your hair, and cuts a section of it off `nYou `$ lose 1 charm`@, but get `^500`@ gold!");
				 $session[user][charm]--;
				 $session[user][gold] += 500;
			}
			break;
	default:
     output("`& Nimbus looks at you, scratches his head, and then walks away.");
		 break;
}

addnav("Barber Shop");
addnav("Haircut","barber.php?op=cut");
addnav("Donate","barber.php?op=donate");
addnav("Return");
addnav("Return to Village","village.php");

page_footer();
?>
