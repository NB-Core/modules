<?php
	$mailmessage=$_POST['mailmessage'];
	page_header("Jobs");
	output("`c`b`&Job Applications`0`b`c`n`n");
	if ($op == ""){
        
		$sql = "SELECT acctid,name,value FROM ".db_prefix('module_userprefs')." LEFT JOIN ".db_prefix('accounts')." ON (acctid = userid) WHERE modulename='jobs' and setting='jobapp' and value>0";
		$result = db_query($sql);
		output("<table border='0' cellpadding='5' cellspacing='0'>",true);
        for ($i=0;$i<db_num_rows($result);$i++){
         $row = db_fetch_assoc($result);
			if ($row['value'] > 0){
			$j++;
			output("<tr class='".($j%2?"trlight":"trdark")."'>",true);
			output("<td>",true);
			$name=$row['name'];
			$acctid=$row['acctid'];
            $reason=get_module_pref("reason","jobs",$acctid);
			output("`^<a href=\"runmodule.php?module=jobs&place=super&op=process&op2=$acctid\">Process -></a>`0 $reason",true);
			output("</tr>",true);
			addnav("","runmodule.php?module=jobs&place=super&op=process&op2=$acctid");
		}
		}
		output("</table>",true);
	}
	if ($op == "process"){
		$acctid=$op2;
		addnav("Approve","runmodule.php?module=jobs&place=super&op=approve&op2=$acctid");
		addnav("Deny","runmodule.php?module=jobs&place=super&op=deny&op2=$acctid");
		$sql = "SELECT acctid,name,value FROM ".db_prefix('module_userprefs')." LEFT JOIN ".db_prefix('accounts')." ON (acctid = userid) WHERE modulename='jobs' and setting='jobapp'";
		$result = db_query($sql);
		for ($i=0;$i<db_num_rows($result);$i++){
	    $row = db_fetch_assoc($result);
		if ($row['acctid'] == $acctid){
		output("`7Approve or Deny Job application for ".$row['name']."`7?");
			}
		}
	}
	if ($op == "approve"){
		$acctid=$op2;
		$sql = "SELECT acctid,name,login,value FROM ".db_prefix('module_userprefs')." LEFT JOIN ".db_prefix('accounts')." ON (acctid = userid) WHERE acctid = ".$acctid." and modulename='jobs' and setting='jobapp'";
		//$sql = "SELECT acctid,name,jobapp,job,login,lastworked FROM accounts WHERE acctid=".$acctid;
		$result = db_query($sql);
		$row = db_fetch_assoc($result);
		$name=$row['name'];
		$job=$row['value'];
		$login=$row['login'];	
		if ($row['value'] > 5){
			$sql2 = "SELECT name,value FROM ".db_prefix('module_userprefs')." LEFT JOIN ".db_prefix('accounts')." ON (acctid = userid) WHERE modulename='jobs' and setting='job' and value='".$job."' LIMIT 1";
			//$sql2 = "SELECT name FROM accounts where job = '".$job."' LIMIT 1";
			$result2 = db_query($sql2);
			$row2 = db_fetch_assoc($result2);
		}
		if ($row2['name'] == ""){
		$mailmessage="`7Congratulations ";
		$mailmessage.=$name;
		$mailmessage.="`7!  You may start your job at ";
		if ($job==1 or $job==6) $mailmessage.="the farm ";
		if ($job==2 or $job==7) $mailmessage.="the mill ";
		if ($job==3 or $job==8) $mailmessage.="the textile mill ";
		if ($job==4 or $job==9) $mailmessage.="the brewery ";
		if ($job==5 or $job==10) $mailmessage.="the foundry ";
		$mailmessage.="immediately.";
		if ($acctid==$session['user']['acctid']){
		set_module_pref('job',$job);
		set_module_pref('jobapp',0);
		set_module_pref('jobworked',0);
		set_module_pref('lastworked',date("Y-m-d H:i:s"));
		}else{
		$lastworked=date("Y-m-d H:i:s");	
		set_module_pref('job',$job,'jobs',$acctid);
		set_module_pref('jobapp',0,'jobs',$acctid);
		set_module_pref('jobworked',0,'jobs',$acctid);
		set_module_pref('lastworked',$lastworked,'jobs',$acctid);
		}
		systemmail($acctid,"`2Job Application Approved`2",$mailmessage);
		$news="`7";
		$news.=$name;
		$news.="`7 got a job at ";
		if ($job==1 or $job==6) $news.="the farm.";
		if ($job==2 or $job==7) $news.="the mill.";
		if ($job==3 or $job==8) $news.="the textile mill.";
		if ($job==4 or $job==9) $news.="the brewery.";
		if ($job==5 or $job==10) $news.="the foundry.";
		addnews("%s",$news);
		output("Job application for %s approved.`n",$name);
	}else{
		output("Management Job already filled!");
		$op = "deny";
	}
	}
	if ($op == "deny"){
		$acctid=$op2;
		if ($mailmessage==""){
			output("Please give a reason.`n");
			output("<form action='runmodule.php?module=jobs&place=super&op=deny&op2=$acctid' method='POST'><input name='mailmessage' id='mailmessage'><input type='submit' class='button' value='submit'></form>",true); 
			output("<script language='JavaScript'>document.getElementById('mailmessage').focus();</script>",true); 
			addnav("","runmodule.php?module=jobs&place=super&op=deny&op2=$acctid");
		}else{
		$sql = "SELECT acctid,name,value FROM ".db_prefix('module_userprefs')." LEFT JOIN ".db_prefix('accounts')." ON (acctid = userid) WHERE modulename='jobs' and setting='jobapp'";
		//$sql = "SELECT acctid,name,jobapp,job FROM accounts";
		$result = db_query($sql);
		for ($i=0;$i<db_num_rows($result);$i++){
	    $row = db_fetch_assoc($result);
		if ($row['acctid'] == $acctid){
		$name=$row['name'];
		$job=$row['jobapp'];
			}
		}
		set_module_pref('jobapp',0,'jobs',$acctid);
		systemmail($acctid,"`2Job Application Denied`2",$mailmessage);
		output("Job application for %s denied.`n",$name);
	}
	}
	addnav("Process more apps","runmodule.php?module=jobs&place=super");
	addnav("Return the the Grotto","superuser.php");
	page_footer();
?>