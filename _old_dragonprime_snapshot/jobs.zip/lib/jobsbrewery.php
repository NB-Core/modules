<?php
    page_header("The Brewery");
    output("`c`b`&The Brewery`0`b`c`n`n");
    if (get_module_pref('lastworked') < date("Y-m-d H:i:s",strtotime("-259200 seconds")) and get_module_pref('job') == 2){
        output("You have been fired for not showing up to work for too long!");
        set_module_pref('job',0);
        set_module_pref('jobexp',1000);
    }
    if ($op == ""){
        output("This is a brewery, at a brewery ale is produced for consumption by the villagers.`n");
        $sql = "SELECT acctid FROM ".db_prefix('module_userprefs')." LEFT JOIN ".db_prefix('accounts')." ON (acctid = userid) WHERE modulename='jobs' and setting='job' and value ='4'";
        $result = db_query($sql);
        for ($i=0;$i<db_num_rows($result);$i++){
        $row = db_fetch_assoc($result);
        $sql2 = "SELECT name,value FROM ".db_prefix('module_userprefs')." LEFT JOIN ".db_prefix('accounts')." ON (acctid = userid) WHERE acctid = '".$row['acctid']."' and modulename='jobs' and setting='jobexp'";
        $result2 = db_query($sql2);
        $row2 = db_fetch_assoc($result2);
            if ($row2['value'] > $top){
                $top = $row2['value'];
                $plaque = $row2['name'];
            }
        }
    if ($plaque <> ""){
        output("`7On a Plaque it says our top employee ");
        output("%s`7.`n",$plaque); 
    }
    }
    if (get_module_pref('jobapp') == 4){
        output("You wonder if you will get the job here that you applied for.`n");
    }else{
    if (get_module_pref('job') < 4 and get_module_pref('jobapp') <> 4 and $op == ""){
        output("You see a sign on the outside of the brewery that says help wanted.  You realize that a job");
        output("would be a great way to earn some gold.  Good hard work can cleanse the soul.`n");
        output("Besides what better place to work than a brewery?");
        addnav("Apply for a Job","runmodule.php?module=jobs&place=brewery&op=apply");
    }
    if (get_module_pref('job') == 4){
        if (get_module_pref('jobworked')==0 and $op == ""){
        output("You come back to the brewery.  As you are employed here it would be good to work at least 1");
        output("shift if you intend to keep your job.`n");
        if ($session['user']['turns'] > 0) addnav("Work","runmodule.php?module=jobs&place=brewery&op=work");
        }else{
        if (get_module_pref('jobworked')==1){
        output("You have already worked today, come back again tommorow.`n");
            }
        }
        addnav("Quit your job","runmodule.php?module=jobs&place=brewery&op=quit");
    }
    if (get_module_pref('job') == 9){
        if (get_module_pref('jobworked')==0 and $op == ""){
        output("You come back to the brewery.  As you are management here it would be good to work at least 1");
        output("shift if you intend to keep your job.`n");
        if ($session['user']['turns'] > 0) addnav("Work","runmodule.php?module=jobs&place=brewery&op=work");
        }else{
        if (get_module_pref('jobworked')==1){
        output("You have already worked today, come back again tommorow.`n");
            }
        }
        addnav("Quit your job","runmodule.php?module=jobs&place=brewery&op=quit");
    }
    if (get_module_pref('job') > 4 and get_module_pref('job') <> 9){
        output("You have fond memories of many a hard day working on the brewery.  Hard work like that helped");
        output("to build character and make you the successful person you are today.1n");
    }
    }
    if ($op == "quit"){
        output("Are you sure you want to quit your job?");
        addnav("Yes","runmodule.php?module=jobs&place=brewery&op=yesquit");
        addnav("No","runmodule.php?module=jobs&place=brewery");
    }
    if ($op == "yesquit"){
        output("Your letter of resignation has been submitted, you no longer work here.");
        set_module_pref('job',0);
        addnews($session['user']['name']."`7 quit their job at the brewery today.");
    }
    if ($op == "apply"){
        output("<big><big><big><span style=\"font-weight: bold;\">Job Application<br></span><small><small><small>",true);
        output("`n`7Name: %s`7.`n",$session['user']['name']);
        output("`7Postion Applied for: Brewery Worker`n");
        output("<form action='runmodule.php?module=jobs&place=brewery&op=applied' method='POST'>",true);
        output("<script language='JavaScript'>document.getElementById('bet').focus();</script>",true); 
        output("<p>Are you currently Employed? <input type=\"checkbox\" name=\"C1\" value=\"ON\">yes",true);
        output("<input type=\"checkbox\" name=\"C2\" value=\"ON\">no</p>",true);
        output("<p>Are you currently wanted for any crimes? <input type=\"checkbox\" name=\"C3\" value=\"ON\">yes",true);
        output("<input type=\"checkbox\" name=\"C4\" value=\"ON\">no</p>",true);
        output("<p>Please give a short reason why you would be qualified for this job: <input type=\"text\" name=\"T1\" size=\"37\"></p>",true);
        output("<p><input type=\"submit\" value=\"Submit\" name=\"B1\"><input type=\"reset\" value=\"Reset\" name=\"B2\"></p>",true);
        output("</form>",true);
        addnav("","runmodule.php?module=jobs&place=brewery&op=applied");
    }
    if ($op == "applied"){
        if (get_module_pref('jobexp')>1500){
        set_module_pref('jobapp',4);
        
        $mailmessage=$session['user']['name'];
        $mailmessage.=" has applied for a job at the brewery. ";
        if ($C1 == "ON"){
            $mailmessage.=" They are currently employed. ";
        }else{
            $mailmessage.=" They are not currently employed. ";
        }
        if ($C3 == "ON"){
            $mailmessage.=" They say that they are currently wanted for crimes against society. ";
        }else{
            $mailmessage.=" They say that they are currently not wanted for any crimes. ";
        }
        $mailmessage.=" They comment: ";
        $mailmessage.=$T1;
        set_module_pref('reason',$mailmessage);
        $sql = "SELECT acctid,value FROM ".db_prefix('module_userprefs')." LEFT JOIN ".db_prefix('accounts')." ON (acctid = userid) WHERE modulename='jobs' and setting='email' and value ='1'";
        $result = db_query($sql);
        for ($i=0;$i<db_num_rows($result);$i++){
        $row = db_fetch_assoc($result);
        if ($row['value'] == 1){
        systemmail($row['acctid'],"`2Job Application`2",$mailmessage);  
            }
        }
        output("Job application sent to Human Resources.");
    }else{
        output("`7The lady looks at your application and shakes her head.  She says \"I am sorry ");
        output("%s`7 but you do not have enough job experience to work here.  I ",$session['user']['name']);
        output("suggest you work at the textile mill for a while and get more work experience.  We only ");
        output("hire very experienced workers here.\"  You feel a little dejected but think maybe a little more ");
        output("job experience would be good.`n");
    }
    }
    if ($op == "work"){
        if (get_module_pref('drunkeness','drinks')>65 and get_module_pref('job')==4){
            output("The Foreman stops you...... \"How dare you show up to work in this condition!\"");
            output("\"Go sober up!\"");
            $session['user']['experience']-=3;
            villagenav();
        }else{
        if ($shifts < 1){
            output("How many shifts (turns) would you like to work? (5 Max)`n");
            output("<form action='runmodule.php?module=jobs&place=brewery&op=work' method='POST'>",true);
            output("<p><input type=\"text\" name=\"shifts\" size=\"37\"></p>",true);
            output("<p><input type=\"submit\" value=\"Submit\" name=\"B1\"><input type=\"reset\" value=\"Reset\" name=\"B2\"></p>",true);
            output("</form>",true);
            addnav("","runmodule.php?module=jobs&place=brewery&op=work");
        }else if ($shifts > 5){
            output("You cannot work more than 5 shifts!");
            addnav("Continue","runmodule.php?module=jobs&place=brewery&op=work");   
        }else if ($shifts > $session['user']['turns']){
            output("You can only work".$session['user']['turns']."shifts!");
            addnav("Continue","runmodule.php?module=jobs&place=brewery&op=work");   
        }else{
            output("You put your time in and work for ".$shifts." shifts.`n");
            if (get_module_pref('job')==4){
            for ($i=1;$i<$shifts+1;$i++){
            output("Shift %s: ",$i);
            $a=1;
            if (get_module_pref('drunkeness','drinks')>32 and e_rand(1,2)==2) $a=9;
            switch(e_rand($a,9)){
                case 1:
                output("You make ale.`n");
                break;
                case 2:
                output("You clean the machinery.`n");
                break;
                case 3:
                output("You sweep the floor.`n");
                break;
                case 4:
                output("You fix machinery.`n");
                break;
                case 5:
                output("You unload hops.`n");
                break;
                case 6:
                output("You bottle ale.`n");
                break;
                case 7:
                output("You work the line.`n");
                break;
                case 8:
                output("You load bottles onto wagons.`n");
                break;
                case 9:
                output("You slack off for a while.`n");
                set_module_pref('jobexp',(get_module_pref('jobexp') - 3));
                break;
                }
            }
            }
            if ($shifts == 1) output("You hardly worked at all.`n");
            if ($shifts == 2) output("You worked for a little while, you will never be the top employee that way.`n");
            if ($shifts == 3) output("You worked a decent amount of time, keep up the good work.`n");
            if ($shifts == 4) output("You worked for quite a while!  You are a hard worker, keep it up!`n");
            if ($shifts == 5) output("You are a workhorse!  Keep it up and you will be moving on up!`n");
            $brewincpay=get_module_setting("brewincpay","jobs");
            //make the increase pay variable into a percentage
            $brewincpay1= $brewincpay/100 +1;
            //make the multiplier a variable based on the number of shifts
            $brewpay1= get_module_setting("brewpay1","jobs");
            $brewpay2= $brewpay1*$brewincpay1;
            $brewpay3= $brewpay1*$brewincpay1*$brewincpay1;
            $brewpay4= $brewpay1*$brewincpay1*$brewincpay1*$brewincpay1;
            $brewpay5= $brewpay1*$brewincpay1*$brewincpay1*$brewincpay1*$brewincpay1;
            //calculate the pay based on the number of shifts worked
            if ($shifts == 1) $paid1 = $brewpay1;
            if ($shifts == 2) $paid1 = $brewpay1 + $brewpay2;
            if ($shifts == 3) $paid1 = $brewpay1 + $brewpay2 + $brewpay3;
            if ($shifts == 4) $paid1 = $brewpay1 + $brewpay2 + $brewpay3 + $brewpay4;
            if ($shifts == 5) $paid1 = $brewpay1 + $brewpay2 + $brewpay3 + $brewpay4 + $brewpay5;
            //make payment an integer after multiplying by percentages
            $paid=round($paid1);
            $session['user']['gold']+=$paid;
            if (get_module_pref('job') == 9){
                $session['user']['gold']+=($shifts*70);
                $paid+=$shifts*70;
            }
            output("You are paid $paid gold for working today.");
            $session['user']['turns']-=$shifts;
            $experience=((e_rand(100,150)*$shifts)+$session['user']['level'])/5;
            if (get_module_pref('job')>5){
                $experience+=((e_rand(130,180)*$shifts)+$session['user']['level'])/5;
            }
            set_module_pref('jobexp',(get_module_pref('jobexp') + $experience)); 
            set_module_pref('jobworked',1);
            if (is_module_active('odor')){
                set_module_pref('odor', get_module_pref('odor','odor') + 2,'odor');
            }
            if (is_module_active('usechow')){
                set_module_pref('hunger', get_module_pref('hunger','usechow') + $shifts,'usechow');
            }
            set_module_pref('jobexp',(get_module_pref('jobexp') + ($shifts*4)));
            set_module_pref('lastworked',date("Y-m-d H:i:s"));
            set_module_setting('brewery',(get_module_setting('brewery') + $shifts));
            $sql = "SELECT value FROM ".db_prefix('module_userprefs')." WHERE modulename='jobs' and setting='job' and value='4'";
            $result = db_query($sql);
            for ($i=0;$i<db_num_rows($result);$i++){
            $row = db_fetch_assoc($result);
            $sql2 = "SELECT value,name FROM ".db_prefix('module_userprefs')." LEFT JOIN ".db_prefix('accounts')." ON (acctid = userid) WHERE modulename='jobs' and setting='jobexp' and userid = '".$row['userid']."'";
            $result2 = db_query($sql2);
            $row2 = db_fetch_assoc($result2);
            if ($row2['value'] > $topjob){
            $topjob = $row2['value'];
            $plaque = $row2['name'];
            if ($row2['name']==$session['user']['name']){
                output("You are the Top Employee!  You have a Brewers Baddness!");
                apply_buff('brewbad',array("name"=>"`4Brewers Baddness","rounds"=>25,"wearoff"=>"`4Your brewers badness fades.","atkmod"=>1.25,"roundmsg"=>"`4You've got brewers badness going, your attack is amazing!.","activate"=>"offense"));
            }
        }
        }
    }
    }       
    }
    $sql = "SELECT name FROM ".db_prefix('module_userprefs')." LEFT JOIN ".db_prefix('accounts')." ON (acctid = userid) WHERE modulename='jobs' and setting='job' and value ='9' LIMIT 1";
    $result = db_query($sql);
    $row = db_fetch_assoc($result);
    if ($row['name'] <> ""){
        output("`nManagement: ".$row['name']);
    }
    output("`nCurrent Employees`n");
    $sql = "SELECT name FROM ".db_prefix('module_userprefs')." LEFT JOIN ".db_prefix('accounts')." ON (acctid = userid) WHERE modulename='jobs' and setting='job' and value ='4' ORDER BY name";
        $result = db_query($sql);
        for ($i=0;$i<db_num_rows($result);$i++){
        $row = db_fetch_assoc($result);
        output("`2- %s `2-`n",$row['name']);
        }
    villagenav();
    page_footer();
?>