<?php
	page_header("Market");
	output("`c`b`&Market`0`b`c`n`n");
	if ($op == ""){
	output("The market sells the items that are created in the factories.`n");
	//fill the inventory
		for ($i=0;$i<1000;$i++){
		if (get_module_setting('farm') > 10 and get_module_setting('milk') < $i){
			set_module_setting('farm',(get_module_setting('farm') - 10));
			set_module_setting('milk',(get_module_setting('milk') + 1));
		}
		if (get_module_setting('farm') > 10 and get_module_setting('eggs') < $i){
			set_module_setting('farm',(get_module_setting('farm') - 10));
			set_module_setting('eggs',(get_module_setting('eggs') + 1));
		}
		if (get_module_setting('farm') > 10 and get_module_setting('pork') < $i){
			set_module_setting('farm',(get_module_setting('farm') - 10));
			set_module_setting('pork',(get_module_setting('pork') + 1));
		}
		if (get_module_setting('farm') > 10 and get_module_setting('beef') < $i){
			set_module_setting('farm',(get_module_setting('farm') - 10));
			set_module_setting('beef',(get_module_setting('beef') + 1));
		}
		if (get_module_setting('farm') > 10 and get_module_setting('chicken') < $i){
			set_module_setting('farm',(get_module_setting('farm') - 10));
			set_module_setting('chicken',(get_module_setting('chicken') + 1));
		}
		if (get_module_setting('farm') < 10) $i=1000;
	}
		for ($i=0;$i<1000;$i++){
		if (get_module_setting('mill') > 15 and get_module_setting('bread') < $i){
			set_module_setting('mill',(get_module_setting('mill') - 15));
			set_module_setting('bread',(get_module_setting('bread') + 1));
		}
		if (get_module_setting('mill')<15) $i=1000;
	}
		for ($i=0;$i<1000;$i++){
		if (get_module_setting('textile') > 20 and get_module_setting('cloth') < $i){
			set_module_setting('textile',(get_module_setting('textile') - 20));
			set_module_setting('cloth',(get_module_setting('cloth') + 1));
		}
		if (get_module_setting('textile') > 20 and get_module_setting('leather') < $i){
			set_module_setting('textile',(get_module_setting('textile') - 25));
			set_module_setting('leather',(get_module_setting('leather') + 1));
		}
		if (get_module_setting('textile')<25) $i=1000;
	}
		for ($i=0;$i<1000;$i++){
		if (get_module_setting('brewery') > 30 and get_module_setting('ale') < $i){
			set_module_setting('brewery',(get_module_setting('brewery') - 30));
			set_module_setting('ale',(get_module_setting('ale') + 1));
		}
		if (get_module_setting('brewery')<30) $i=1000;
	}
		for ($i=0;$i<1000;$i++){
		if (get_module_setting('foundry') > 60 and get_module_setting('breastplate') < $i){
			set_module_setting('foundry',(get_module_setting('foundry') - 60));
			set_module_setting('breastplate',(get_module_setting('breastplate') + 1));
		}
		if (get_module_setting('foundry') > 60 and get_module_setting('longsword') < $i){
			set_module_setting('foundry',(get_module_setting('foundry') - 60));
			set_module_setting('longsword',(get_module_setting('longsword') + 1));
		}
		if (get_module_setting('foundry') > 60 and get_module_setting('chainmail') < $i){
			set_module_setting('foundry',(get_module_setting('foundry') - 65));
			set_module_setting('chainmail',(get_module_setting('chainmail') + 1));
		}
		if (get_module_setting('foundry') > 60 and get_module_setting('duallongsword') < $i){
			set_module_setting('foundry',(get_module_setting('foundry') - 65));
			set_module_setting('duallongsword',(get_module_setting('duallongsword') + 1));
		}
		if (get_module_setting('foundry') > 60 and get_module_setting('fullarmor') < $i){
			set_module_setting('foundry',(get_module_setting('foundry') - 70));
			set_module_setting('fullarmor',(get_module_setting('fullarmor') + 1));
		}
		if (get_module_setting('foundry') > 60 and get_module_setting('duallongsworddaggers') < $i){
			set_module_setting('foundry',(get_module_setting('foundry') - 70));
			set_module_setting('duallongsworddaggers',(get_module_setting('duallongsworddaggers') + 1));
		}
		if (get_module_setting('foundry')<70) $i=1000;
	}
	//now list and sell items
	output("The items for sale here are items made at the surrounding factories.`n");
	output("In Inventory today are:`n");
	if (get_module_setting('milk') > 0) output("`2Milk: `3%s`n",get_module_setting('milk'));
	if (get_module_setting('eggs') > 0) output("`2Eggs: `3%s`n",get_module_setting('eggs'));
	if (get_module_setting('pork') > 0) output("`2Pork: `3%s`n",get_module_setting('pork'));
	if (get_module_setting('beef') > 0) output("`2Beef: `3%s`n",get_module_setting('beef'));
	if (get_module_setting('chicken') > 0) output("`2Chicken: `3%s`n",get_module_setting('chicken'));
	if (get_module_setting('bread') > 0) output("`2Bread: `3%s`n",get_module_setting('bread'));
	if (get_module_setting('cloth') > 0) output("`2Cloth: `3%s`n",get_module_setting('cloth'));
	if (get_module_setting('leather') > 0) output("`2Leather: `3%s`n",get_module_setting('leather'));
	if (get_module_setting('ale') > 0) output("`2Ale: `3%s`n",get_module_setting('ale'));
	if (get_module_setting('breastplate') > 0) output("`2Breastplate Armor (Defense 16): `3%s`n",get_module_setting('breastplate'));
	if (get_module_setting('chainmail') > 0) output("`2Chainmail Armor (Defense 17): `3%s`n",get_module_setting('chainmail'));
	if (get_module_setting('fullarmor') > 0) output("`2Full Armor (Defense 18): `3%s`n",get_module_setting('fullarmor'));
	if (get_module_setting('longsword') > 0) output("`2Long Sword (Attack 16): `3%s`n",get_module_setting('longsword'));
	if (get_module_setting('duallongsword') > 0) output("`2Dual Bladed Longsword (Attack 17): `3%s`n",get_module_setting('duallongsword'));
	if (get_module_setting('duallongsworddaggers') > 0) output("`2Dual Bladed Longsword with 2 more small blades (Attack 18): `3%s`n",get_module_setting('duallongsworddaggers'));
	if (get_module_setting('milk') > 0 and $session['user']['gold'] > 49) addnav("Milk 50 Gold","runmodule.php?module=jobs&place=market&op=buymilk");
	if (get_module_setting('eggs') > 0 and $session['user']['gold'] > 49) addnav("Eggs 50 Gold","runmodule.php?module=jobs&place=market&op=buyeggs");
	if (get_module_setting('pork') > 0 and $session['user']['gold'] > 74) addnav("Pork 75 Gold","runmodule.php?module=jobs&place=market&op=buypork");
	if (get_module_setting('beef') > 0 and $session['user']['gold'] > 74) addnav("Beef 75 Gold","runmodule.php?module=jobs&place=market&op=buybeef");
	if (get_module_setting('chicken') > 0 and $session['user']['gold'] > 74) addnav("Chicken 75 Gold","runmodule.php?module=jobs&place=market&op=buychicken");
	if (get_module_setting('bread') > 0 and $session['user']['gold'] > 99) addnav("Bread 100 Gold","runmodule.php?module=jobs&place=market&op=buybread");
	if (get_module_setting('cloth') > 0 and $session['user']['gems'] > 2) addnav("Cloth ".get_module_setting("clothprice")." gems","runmodule.php?module=jobs&place=market&op=buycloth");
	if (get_module_setting('leather') > 0 and $session['user']['gems'] > 3) addnav("Leather ".get_module_setting("leatherprice")." gems","runmodule.php?module=jobs&place=market&op=buyleather");
	if (get_module_setting('ale') > 0 and $session['user']['gold'] > 299) addnav("Ale 300 Gold","runmodule.php?module=jobs&place=market&op=buyale");
	if (get_module_setting('breastplate') > 0 and $session['user']['gold'] > 13999) addnav("Breastplate 14000 Gold","runmodule.php?module=jobs&place=market&op=buybreastplate");
	if (get_module_setting('chainmail') > 0 and $session['user']['gold'] > 15999) addnav("Chainmail 16000 Gold","runmodule.php?module=jobs&place=market&op=buychainmail");
	if (get_module_setting('fullarmor') > 0 and $session['user']['gold'] > 17999) addnav("Full Armor 18000 Gold","runmodule.php?module=jobs&place=market&op=buyfullarmor");
	if (get_module_setting('longsword') > 0 and $session['user']['gold'] > 13999) addnav("Long Sword 14000 Gold","runmodule.php?module=jobs&place=market&op=buylongsword");
	if (get_module_setting('duallongsword') > 0 and $session['user']['gold'] > 15999) addnav("Dual Long Sword 16000 Gold","runmodule.php?module=jobs&place=market&op=buyduallongsword");
	if (get_module_setting('duallongsworddaggers') > 0 and $session['user']['gold'] > 17999) addnav("Dual Sword with Daggers 18000 Gold","runmodule.php?module=jobs&place=market&op=buyduallongsworddaggers");
	}
	if ($op == "buymilk"){
		if ($session['bufflist']['calcboost']==""){
		$session['user']['gold']-=50;
		if (is_module_active('usechow')) set_module_pref('hunger', get_module_pref('hunger','usechow') - 3,'usechow');
		if (is_module_active('bladder')) set_module_pref('bladder', get_module_pref('bladder','bladder') + 1,'bladder');
		output("Milk, it does a body good!  You get a Calcium Boost!");
		apply_buff('calcboost',array("name"=>"`4Calcium Boost","rounds"=>10,"wearoff"=>"`4Your Calcium Boost fades.","defmod"=>1.25,"roundmsg"=>"`4You've got a Calcuim Boost!.","activate"=>"offense"));
		set_module_setting('milk',(get_module_setting('milk') - 1));
		}else{
		output("You have had enough milk.");
		}
		addnav("Continue","runmodule.php?module=jobs&place=market");
	}
	if ($op == "buyeggs"){
		if ($session['bufflist']['eggboost']==""){
		$session['user']['gold']-=50;
		if (is_module_active('usechow')) set_module_pref('hunger', get_module_pref('hunger','usechow') - 5,'usechow');
		output("Eggs are high in protein!  You get an Egg Boost!");
		apply_buff('eggboost',array("name"=>"`4Egg Boost","rounds"=>10,"wearoff"=>"`4Your Egg Boost fades.","defmod"=>1.25,"roundmsg"=>"`4You've got a Egg Boost!.","activate"=>"offense"));
		set_module_setting('eggs',(get_module_setting('eggs') - 1));
		}else{
		output("You have had enough eggs.");
		}
		addnav("Continue","runmodule.php?module=jobs&place=market");
	}
	if ($op == "buypork"){
		if ($session['bufflist']['protboost']==""){
		$session['user']['gold']-=75;
		if (is_module_active('usechow')) set_module_pref('hunger', get_module_pref('hunger','usechow') - 8,'usechow');
		output("Meat is high in protien!  You get an Protien Boost!");
		apply_buff('protboost',array("name"=>"`4Protien Boost","rounds"=>10,"wearoff"=>"`4Your Protien Boost fades.","atkmod"=>1.25,"roundmsg"=>"`4You've got a Protien Boost!.","activate"=>"offense"));
		set_module_setting('pork',(get_module_setting('pork') - 1));
		}else{
		output("You have had enough meat.");
		}
		addnav("Continue","runmodule.php?module=jobs&place=market");
	}
	if ($op == "buybeef"){
		if ($session['bufflist']['protboost']==""){
		$session['user']['gold']-=75;
		if (is_module_active('usechow')) set_module_pref('hunger', get_module_pref('hunger','usechow') - 8,'usechow');
		output("Meat is high in protien!  You get an Protien Boost!");
		apply_buff('protboost',array("name"=>"`4Protien Boost","rounds"=>10,"wearoff"=>"`4Your Protien Boost fades.","atkmod"=>1.25,"roundmsg"=>"`4You've got a Protien Boost!.","activate"=>"offense"));
		set_module_setting('beef',(get_module_setting('beef') - 1));
		}else{
		output("You have had enough meat.");
		}
		addnav("Continue","runmodule.php?module=jobs&place=market");
	}
	if ($op == "buychicken"){
		if ($session['bufflist']['protboost']==""){
		$session['user']['gold']-=75;
		if (is_module_active('usechow')) set_module_pref('hunger', get_module_pref('hunger','usechow') - 8,'usechow');
		output("Meat is high in protien!  You get an Protien Boost!");
		apply_buff('protboost',array("name"=>"`4Protien Boost","rounds"=>10,"wearoff"=>"`4Your Protien Boost fades.","atkmod"=>1.25,"roundmsg"=>"`4You've got a Protien Boost!.","activate"=>"offense"));
		set_module_setting('chicken',(get_module_setting('chicken') - 1));
		}else{
		output("You have had enough meat.");
		}
		addnav("Continue","runmodule.php?module=jobs&place=market");
	}
	if ($op == "buybread"){
		if ($session['bufflist']['breadboost']==""){
		$session['user']['gold']-=75;
		if (is_module_active('usechow')) set_module_pref('hunger', get_module_pref('hunger','usechow') - 6,'usechow');
		output("Bread is good for you!  You get an Bread Boost!");
		apply_buff('breadboost',array("name"=>"`4Bread Boost","rounds"=>10,"wearoff"=>"`4Your Bread Boost fades.","atkmod"=>1.25,"roundmsg"=>"`4You've got a Bread Boost!.","activate"=>"offense"));
		set_module_setting('bread',(get_module_setting('bread') - 1));
		}else{
		output("You have had enough bread.");
		}
		addnav("Continue","runmodule.php?module=jobs&place=market");
	}
	if ($op == "buycloth"){
		$inventory2=0;
		$inventory2=get_module_pref('wool','trading');
		$inventory2+=get_module_pref('cloth','trading');
		$inventory2+=get_module_pref('leather','trading');
		$room2=get_module_setting('room2','trading');
	if ($inventory2 < $room2){
		output("You hand over your gems and receive a bundle of cloth");
		$session['user']['gems']-=get_module_setting('clothprice');
		set_module_pref('cloth',(get_module_pref('cloth','trading') + 1),'trading');
		set_module_setting('cloth',(get_module_setting('cloth') - 1));
	}else{
		output("You don't have enough space in your sac to carry that.");
	}
		addnav("Continue","runmodule.php?module=jobs&place=market");
	}
	if ($op == "buyleather"){
		$inventory2=0;
		$inventory2=get_module_pref('wool','trading');
		$inventory2+=get_module_pref('cloth','trading');
		$inventory2+=get_module_pref('leather','trading');
		$room2=get_module_setting('room2','trading');
	if ($inventory2 < $room2){
		output("You hand over your gems and receive a bundle of leather");
		$session['user']['gems']-=get_module_setting('leatherprice');
		set_module_pref('leather',(get_module_pref('leather','trading') + 1),'trading');
		set_module_setting('leather',(get_module_setting('leather') - 1));
	}else{
		output("You don't have enough space in your sac to carry that.");
	}
		addnav("Continue","runmodule.php?module=jobs&place=market");
	}
	if ($op == "buyale"){
		$drunk = round(get_module_pref('drunkeness','drinks')/10-.5,0);
			if ($drunk > 8){
				output("`1You have already had too much!");
			}else{
				$session['user']['gold']-=300;
				if (is_module_active('bladder')) set_module_pref('bladder', get_module_pref('bladder','bladder') + 3,'bladder');
				set_module_setting('ale',(get_module_setting('ale') - 1));
				$drunktmp=get_module_pref('drunkeness','drinks');
				$drunktmp+=33;
				set_module_pref('drunkeness',$drunktmp,'drinks');
				$drunk = round(get_module_pref('drunkeness','drinks')/10);
				output("`1You chug down the ale!`n");
				switch(e_rand(1,3)){
							  case 1:
								case 2:
								  output("`1You feel healthy!");
									$session['user']['hitpoints']+=round($session['user']['maxhitpoints']*.1,0);
									break;
								case 3:
								  output("`&You feel vigorous!");
									$session['user']['turns']++;
							}
							apply_buff('buzz',array("name"=>"`#Buzz","rounds"=>10,"wearoff"=>"Your buzz fades.","atkmod"=>1.25,"roundmsg"=>"You've got a nice buzz going.","activate"=>"offense"));
				$drunkenness = array(-1=>"stone cold sober",
															 0=>"quite sober",
															 1=>"barely buzzed",
										 					 2=>"pleasantly buzzed",
															 3=>"almost drunk",
															 4=>"barely drunk",
															 5=>"solidly drunk",
															 6=>"sloshed",
															 7=>"hammered",
															 8=>"really hammered",
															 9=>"almost unconscious"
										);
					output("`n`n`1You now feel ".$drunkenness[$drunk]."`n`n");
			}
			addnav("Continue","runmodule.php?module=jobs&place=market");		
	}
	if ($op == "buybreastplate"){
		$session['user']['gold']-=14000;
		set_module_setting('breastplate',(get_module_setting('breastplate') - 1));
		output("The lady takes your ".$session['user']['armor']." and tosses it in a pile of discared armor.");
		$session['user']['armor']="Foundry Breastplate";
		$session['user']['armorvalue']=14000;
		$session['user']['defense']-=$session['user']['armordef'];
		$session['user']['armordef'] = 16;
		$session['user']['defense']+=16;
		output("You try on your new breastplate, it fits well, and feels very sturdy.");
		addnav("Continue","runmodule.php?module=jobs&place=market");
	}
	if ($op == "buychainmail"){
		$session['user']['gold']-=16000;
		set_module_setting('chainmail',(get_module_setting('chainmail') - 1));
		output("The lady takes your ".$session['user']['armor']." and tosses it in a pile of discared armor.");
		$session['user']['armor']="Foundry Chainmail";
		$session['user']['armorvalue']=16000;
		$session['user']['defense']-=$session['user']['armordef'];
		$session['user']['armordef'] = 17;
		$session['user']['defense']+=17;
		output("You try on your new Chainmail, it fits well, and feels very sturdy.");
		addnav("Continue","runmodule.php?module=jobs&place=market");
	}
	if ($op == "buyfullarmor"){
		$session['user']['gold']-=18000;
		set_module_setting('fullarmor',(get_module_setting('fullarmor') - 1));
		output("The lady takes your ".$session['user']['armor']." and tosses it in a pile of discared armor.");
		$session['user']['armor']="Foundry Full Armor";
		$session['user']['armorvalue']=18000;
		$session['user']['defense']-=$session['user']['armordef'];
		$session['user']['armordef'] = 18;
		$session['user']['defense']+=18;
		output("You try on your new Full Armor, it fits well, and feels very sturdy.");
		addnav("Continue","runmodule.php?module=jobs&place=market");
	}
	if ($op == "buylongsword"){
		$session['user']['gold']-=14000;
		set_module_setting('longsword',(get_module_setting('longsword') - 1));
		output("The lady takes your ".$session['user']['weapon']." and tosses it in a pile of discared weapons.");
		$session['user']['weapon']="Foundry LongSword";
		$session['user']['weaponvalue']=17;
		$session['user']['attack']-=$session['user']['weapondmg'];
		$session['user']['weapondmg'] = 16;
		$session['user']['attack']+=16;
		output("You try out your new longsword, it feels well balanced, and very sturdy.");
		addnav("Continue","runmodule.php?module=jobs&place=market");
	}
	if ($op == "buyduallongsword"){
		$session['user']['gold']-=16000;
		set_module_setting('duallongsword',(get_module_setting('duallongsword') - 1));
		output("The lady takes your ".$session['user']['weapon']." and tosses it in a pile of discared weapons.");
		$session['user']['weapon']="Foundry Dual LongSword";
		$session['user']['weaponvalue']=16000;
		$session['user']['attack']-=$session['user']['weapondmg'];
		$session['user']['weapondmg'] = 17;
		$session['user']['attack']+=17;
		output("You try out your new  dual longsword, it feels well balanced, and very sturdy.");
		addnav("Continue","runmodule.php?module=jobs&place=market");
	}
	if ($op == "buyduallongsworddaggers"){
		$session['user']['gold']-=18000;
		set_module_setting('duallongsworddaggers',(get_module_setting('duallongsworddaggers') - 1));
		output("The lady takes your ".$session['user']['weapon']." and tosses it in a pile of discared weapons.");
		$session['user']['weapon']="Foundry Dual LongSword with Daggers";
		$session['user']['weaponvalue']=18000;
		$session['user']['attack']-=$session['user']['weapondmg'];
		$session['user']['weapondmg'] = 18;
		$session['user']['attack']+=18;
		output("You try out your new  dual longsword with daggers, it feels well balanced, and very sturdy.");
		addnav("Continue","runmodule.php?module=jobs&place=market");
	}
	villagenav();
	page_footer();
?>