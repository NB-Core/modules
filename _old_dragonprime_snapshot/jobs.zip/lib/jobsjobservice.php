<?php
	page_header("Job Services");
	output("`c`b`&Job Services`0`b`c`n`n");
	if ($op == ""){
	output("You step into the dimly lit Job Services Office.");
	output("At the desk you see a haggard wrinkled old woman.  She looks up at you then goes back");
	output("to what she was doing without so much as even acknowledging that you are there.  On the");
	output("wall you see a poster labeled Top Employees.  You can check with the old woman your job");
	output("experience, apply for jobs, and check status on Job Applications.`n`n");
	output("Top Employees:`n");
	$sql = "SELECT acctid FROM ".db_prefix('module_userprefs')." LEFT JOIN ".db_prefix('accounts')." ON (acctid = userid) WHERE modulename='jobs' and setting='job' and value ='1'";
	$result = db_query($sql);
	for ($i=0;$i<db_num_rows($result);$i++){
		$row = db_fetch_assoc($result);
		$sql2 = "SELECT name,value FROM ".db_prefix('module_userprefs')." LEFT JOIN ".db_prefix('accounts')." ON (acctid = userid) WHERE acctid = '".$row['acctid']."' and modulename='jobs' and setting='jobexp'";
		$result2 = db_query($sql2);
		$row2 = db_fetch_assoc($result2);
			if ($row2['value'] > $top){
				$top = $row2['value'];
				$plaque = $row2['name'];
			}
		}
	if ($plaque <> ""){
		output("`7Farm: ");
		output("%s`7.`n",$plaque); 
	}
	$plaque="";
	$sql = "SELECT acctid FROM ".db_prefix('module_userprefs')." LEFT JOIN ".db_prefix('accounts')." ON (acctid = userid) WHERE modulename='jobs' and setting='job' and value ='2'";
	$result = db_query($sql);
	for ($i=0;$i<db_num_rows($result);$i++){
		$row = db_fetch_assoc($result);
		$sql2 = "SELECT name,value FROM ".db_prefix('module_userprefs')." LEFT JOIN ".db_prefix('accounts')." ON (acctid = userid) WHERE acctid = '".$row['acctid']."' and modulename='jobs' and setting='jobexp'";
		$result2 = db_query($sql2);
		$row2 = db_fetch_assoc($result2);
			if ($row2['value'] > $top){
				$top = $row2['value'];
				$plaque = $row2['name'];
			}
		}
	if ($plaque <> ""){
		output("`7Mill: ");
		output("%s`7.`n",$plaque); 
	}
	$plaque="";
	$sql = "SELECT acctid FROM ".db_prefix('module_userprefs')." LEFT JOIN ".db_prefix('accounts')." ON (acctid = userid) WHERE modulename='jobs' and setting='job' and value ='3'";
	$result = db_query($sql);
	for ($i=0;$i<db_num_rows($result);$i++){
		$row = db_fetch_assoc($result);
		$sql2 = "SELECT name,value FROM ".db_prefix('module_userprefs')." LEFT JOIN ".db_prefix('accounts')." ON (acctid = userid) WHERE acctid = '".$row['acctid']."' and modulename='jobs' and setting='jobexp'";
		$result2 = db_query($sql2);
		$row2 = db_fetch_assoc($result2);
			if ($row2['value'] > $top){
				$top = $row2['value'];
				$plaque = $row2['name'];
			}
		}
	if ($plaque <> ""){
		output("`7Textile Mill: ");
		output("%s`7.`n",$plaque); 
	}
	$plaque="";
	$sql = "SELECT acctid FROM ".db_prefix('module_userprefs')." LEFT JOIN ".db_prefix('accounts')." ON (acctid = userid) WHERE modulename='jobs' and setting='job' and value ='4'";
	$result = db_query($sql);
	for ($i=0;$i<db_num_rows($result);$i++){
		$row = db_fetch_assoc($result);
		$sql2 = "SELECT name,value FROM ".db_prefix('module_userprefs')." LEFT JOIN ".db_prefix('accounts')." ON (acctid = userid) WHERE acctid = '".$row['acctid']."' and modulename='jobs' and setting='jobexp'";
		$result2 = db_query($sql2);
		$row2 = db_fetch_assoc($result2);
			if ($row2['value'] > $top){
				$top = $row2['value'];
				$plaque = $row2['name'];
			}
		}
	if ($plaque <> ""){
		output("`7Brewery: ");
		output("%s`7.`n",$plaque); 
	}
	$plaque="";
	$sql = "SELECT acctid FROM ".db_prefix('module_userprefs')." LEFT JOIN ".db_prefix('accounts')." ON (acctid = userid) WHERE modulename='jobs' and setting='job' and value ='5'";
	$result = db_query($sql);
	for ($i=0;$i<db_num_rows($result);$i++){
		$row = db_fetch_assoc($result);
		$sql2 = "SELECT name,value FROM ".db_prefix('module_userprefs')." LEFT JOIN ".db_prefix('accounts')." ON (acctid = userid) WHERE acctid = '".$row['acctid']."' and modulename='jobs' and setting='jobexp'";
		$result2 = db_query($sql2);
		$row2 = db_fetch_assoc($result2);
			if ($row2['value'] > $top){
				$top = $row2['value'];
				$plaque = $row2['name'];
			}
		}
	if ($plaque <> ""){
		output("`7Foundry: ");
		output("%s`7.`n",$plaque); 
	}
	addnav("Check your Experience","runmodule.php?module=jobs&place=jobservice&op=exp");
	if (get_module_pref('jobapp') == 0) addnav("Apply for a Job","runmodule.php?module=jobs&place=jobservice&op=apply");
	if (get_module_pref('jobapp') <> 0) addnav("Application Status","runmodule.php?module=jobs&place=jobservice&op=status");
	addnav("Help","runmodule.php?module=jobs&place=jobservice&op=help");
	}
	if ($op == "exp"){
		output("`7You walk up to the old woman to ask her to evaluate your job experience.  She grumbles ");
		output("something under her breath that you can't quite make out.  She looks up at you and says ");
		output("\"".$session['user']['name']."`7 you have ".get_module_pref('jobexp')." job experience.\"`n");
		addnav("Continue","runmodule.php?module=jobs&place=jobservice");
	}
	if ($op == "apply"){
		output("You walk up to the old woman and ask to apply for a job.  She gives you a quick glance");
		output(" and looks back down at what she is working on and mumbles \"You are experienced enough");
		output(" to work at the following places.  What app would you like to fill out?\"`n");
		if (get_module_pref('job') <> 1) addnav("Farm","runmodule.php?module=jobs&place=jobservice&op=farmapp");
		if (get_module_pref('jobexp') > 249 and get_module_pref('job') <> 2) addnav("Mill","runmodule.php?module=jobs&place=jobservice&op=millapp");
		if (get_module_pref('jobexp') > 750 and get_module_pref('job') <> 3) addnav("Textile Mill","runmodule.php?module=jobs&place=jobservice&op=textileapp");
		if (get_module_pref('jobexp') > 1500 and get_module_pref('job') <> 4) addnav("Brewery","runmodule.php?module=jobs&place=jobservice&op=brewapp");
		if (get_module_pref('jobexp') > 2500 and get_module_pref('job') <> 5) addnav("Foundry","runmodule.php?module=jobs&place=jobservice&op=foundapp");
		if (get_module_pref('jobexp') > 4500 and get_module_pref('job') <> 6) addnav("Farm Management","runmodule.php?module=jobs&place=jobservice&op=farmman");
		if (get_module_pref('jobexp') > 7500 and get_module_pref('job') <> 7) addnav("Mill Management","runmodule.php?module=jobs&place=jobservice&op=millman");
		if (get_module_pref('jobexp') > 10000 and get_module_pref('job') <> 8) addnav("Textile Mill Management","runmodule.php?module=jobs&place=jobservice&op=textileman");
		if (get_module_pref('jobexp') > 15000 and get_module_pref('job') <> 9) addnav("Brewery Management","runmodule.php?module=jobs&place=jobservice&op=brewman");
		if (get_module_pref('jobexp') > 20000 and get_module_pref('job') <> 10) addnav("Foundry Management","runmodule.php?module=jobs&place=jobservice&op=foundman");
		addnav("Continue","runmodule.php?module=jobs&place=jobservice");
	}
	if ($op == "farmapp"){
		if ($op2 == ""){
		output("<big><big><big><span style=\"font-weight: bold;\">Job Application<br></span><small><small><small>",true);
		output("`n`7Name: %s`7.`n",$session['user']['name']);
		output("`7Postion Applied for: Farm Hand`n");
		output("<form action='runmodule.php?module=jobs&place=jobservice&op=farmapp&op2=applied' method='POST'>",true);
	  	output("<script language='JavaScript'>document.getElementById('bet').focus();</script>",true); 
		output("<p>Are you currently Employed? <input type=\"checkbox\" name=\"C1\" value=\"ON\">yes",true);
	  	output("<input type=\"checkbox\" name=\"C2\" value=\"ON\">no</p>",true);
	  	output("<p>Are you currently wanted for any crimes? <input type=\"checkbox\" name=\"C3\" value=\"ON\">yes",true);
	  	output("<input type=\"checkbox\" name=\"C4\" value=\"ON\">no</p>",true);
	  	output("<p>Please give a short reason why you would be qualified for this job: <input type=\"text\" name=\"T1\" size=\"37\"></p>",true);
	  	output("<p><input type=\"submit\" value=\"Submit\" name=\"B1\"><input type=\"reset\" value=\"Reset\" name=\"B2\"></p>",true);
		output("</form>",true);
		addnav("","runmodule.php?module=jobs&place=jobservice&op=farmapp&op2=applied");
	}
	if ($op2 == "applied"){
		set_module_pref('jobapp',1);
		$mailmessage=$session['user']['name'];
		$mailmessage.=" has applied for a job at the farm. ";
		if ($C1 == "ON"){
			$mailmessage.=" They are currently employed. ";
		}else{
			$mailmessage.=" They are not currently employed. ";
		}
		if ($C3 == "ON"){
			$mailmessage.=" They say that they are currently wanted for crimes against society. ";
		}else{
			$mailmessage.=" They say that they are currently not wanted for any crimes. ";
		}
		$mailmessage.=" They comment: ";
		$mailmessage.=$T1;
                set_module_pref('reason',$mailmessage);
		$sql = "SELECT acctid,value FROM ".db_prefix('module_userprefs')." LEFT JOIN ".db_prefix('accounts')." ON (acctid = userid) WHERE modulename='jobs' and setting='email' and value ='1'";
		$result = db_query($sql);
		for ($i=0;$i<db_num_rows($result);$i++){
	    $row = db_fetch_assoc($result);
		if ($row['value'] == 1){
		systemmail($row['acctid'],"`2Job Application`2",$mailmessage);	
			}
		}
		output("Job application sent to Human Resources.");
		addnav("Continue","runmodule.php?module=jobs&place=jobservice");
	}
	}
	if ($op == "millapp"){
		if ($op2 == ""){
		output("<big><big><big><span style=\"font-weight: bold;\">Job Application<br></span><small><small><small>",true);
		output("`n`7Name: %s`7.`n",$session['user']['name']);
		output("`7Postion Applied for: Mill Worker`n");
		output("<form action='runmodule.php?module=jobs&place=jobservice&op=millapp&op2=applied' method='POST'>",true);
	  	output("<script language='JavaScript'>document.getElementById('bet').focus();</script>",true); 
		output("<p>Are you currently Employed? <input type=\"checkbox\" name=\"C1\" value=\"ON\">yes",true);
	  	output("<input type=\"checkbox\" name=\"C2\" value=\"ON\">no</p>",true);
	  	output("<p>Are you currently wanted for any crimes? <input type=\"checkbox\" name=\"C3\" value=\"ON\">yes",true);
	  	output("<input type=\"checkbox\" name=\"C4\" value=\"ON\">no</p>",true);
	  	output("<p>Please give a short reason why you would be qualified for this job: <input type=\"text\" name=\"T1\" size=\"37\"></p>",true);
	  	output("<p><input type=\"submit\" value=\"Submit\" name=\"B1\"><input type=\"reset\" value=\"Reset\" name=\"B2\"></p>",true);
		output("</form>",true);
		addnav("","runmodule.php?module=jobs&place=jobservice&op=millapp&op2=applied");
	}
	if ($op2 == "applied"){
		set_module_pref('jobapp',2);
		$mailmessage=$session['user']['name'];
		$mailmessage.=" has applied for a job at the mill. ";
		if ($C1 == "ON"){
			$mailmessage.=" They are currently employed. ";
		}else{
			$mailmessage.=" They are not currently employed. ";
		}
		if ($C3 == "ON"){
			$mailmessage.=" They say that they are currently wanted for crimes against society. ";
		}else{
			$mailmessage.=" They say that they are currently not wanted for any crimes. ";
		}
		$mailmessage.=" They comment: ";
		$mailmessage.=$T1;
                set_module_pref('reason',$mailmessage);
		$sql = "SELECT acctid,value FROM ".db_prefix('module_userprefs')." LEFT JOIN ".db_prefix('accounts')." ON (acctid = userid) WHERE modulename='jobs' and setting='email' and value ='1'";
		$result = db_query($sql);
		for ($i=0;$i<db_num_rows($result);$i++){
	    $row = db_fetch_assoc($result);
		if ($row['value'] == 1){
		systemmail($row['acctid'],"`2Job Application`2",$mailmessage);	
			}
		}
		output("Job application sent to Human Resources.");
		addnav("Continue","runmodule.php?module=jobs&place=jobservice");
	}
	}
	if ($op == "textileapp"){
		if ($op2 == ""){
		output("<big><big><big><span style=\"font-weight: bold;\">Job Application<br></span><small><small><small>",true);
		output("`n`7Name: %s`7.`n",$session['user']['name']);
		output("`7Postion Applied for: Textile Mill Worker`n");
		output("<form action='runmodule.php?module=jobs&place=jobservice&op=textileapp&op2=applied' method='POST'>",true);
	  	output("<script language='JavaScript'>document.getElementById('bet').focus();</script>",true); 
		output("<p>Are you currently Employed? <input type=\"checkbox\" name=\"C1\" value=\"ON\">yes",true);
	  	output("<input type=\"checkbox\" name=\"C2\" value=\"ON\">no</p>",true);
	  	output("<p>Are you currently wanted for any crimes? <input type=\"checkbox\" name=\"C3\" value=\"ON\">yes",true);
	  	output("<input type=\"checkbox\" name=\"C4\" value=\"ON\">no</p>",true);
	  	output("<p>Please give a short reason why you would be qualified for this job: <input type=\"text\" name=\"T1\" size=\"37\"></p>",true);
	  	output("<p><input type=\"submit\" value=\"Submit\" name=\"B1\"><input type=\"reset\" value=\"Reset\" name=\"B2\"></p>",true);
		output("</form>",true);
		addnav("","runmodule.php?module=jobs&place=jobservice&op=textileapp&op2=applied");
	}
	if ($op2 == "applied"){
		set_module_pref('jobapp',3);
		$mailmessage=$session['user']['name'];
		$mailmessage.=" has applied for a job at the textile mill. ";
		if ($C1 == "ON"){
			$mailmessage.=" They are currently employed. ";
		}else{
			$mailmessage.=" They are not currently employed. ";
		}
		if ($C3 == "ON"){
			$mailmessage.=" They say that they are currently wanted for crimes against society. ";
		}else{
			$mailmessage.=" They say that they are currently not wanted for any crimes. ";
		}
		$mailmessage.=" They comment: ";
		$mailmessage.=$T1;
                set_module_pref('reason',$mailmessage);
		$sql = "SELECT acctid,value FROM ".db_prefix('module_userprefs')." LEFT JOIN ".db_prefix('accounts')." ON (acctid = userid) WHERE modulename='jobs' and setting='email' and value ='1'";
		$result = db_query($sql);
		for ($i=0;$i<db_num_rows($result);$i++){
	    $row = db_fetch_assoc($result);
		if ($row['value'] == 1){
		systemmail($row['acctid'],"`2Job Application`2",$mailmessage);	
			}
		}
		output("Job application sent to Human Resources.");
		addnav("Continue","runmodule.php?module=jobs&place=jobservice");
	}
	}
	if ($op == "brewapp"){
		if ($op2 == ""){
		output("<big><big><big><span style=\"font-weight: bold;\">Job Application<br></span><small><small><small>",true);
		output("`n`7Name: %s`7.`n",$session['user']['name']);
		output("`7Postion Applied for: Brewery Worker`n");
		output("<form action='runmodule.php?module=jobs&place=jobservice&op=brewapp&op2=applied' method='POST'>",true);
	  	output("<script language='JavaScript'>document.getElementById('bet').focus();</script>",true); 
		output("<p>Are you currently Employed? <input type=\"checkbox\" name=\"C1\" value=\"ON\">yes",true);
	  	output("<input type=\"checkbox\" name=\"C2\" value=\"ON\">no</p>",true);
	  	output("<p>Are you currently wanted for any crimes? <input type=\"checkbox\" name=\"C3\" value=\"ON\">yes",true);
	  	output("<input type=\"checkbox\" name=\"C4\" value=\"ON\">no</p>",true);
	  	output("<p>Please give a short reason why you would be qualified for this job: <input type=\"text\" name=\"T1\" size=\"37\"></p>",true);
	  	output("<p><input type=\"submit\" value=\"Submit\" name=\"B1\"><input type=\"reset\" value=\"Reset\" name=\"B2\"></p>",true);
		output("</form>",true);
		addnav("","runmodule.php?module=jobs&place=jobservice&op=brewapp&op2=applied");
	}
	if ($op2 == "applied"){
		set_module_pref('jobapp',4);
		$mailmessage=$session['user']['name'];
		$mailmessage.=" has applied for a job at the brewery. ";
		if ($C1 == "ON"){
			$mailmessage.=" They are currently employed. ";
		}else{
			$mailmessage.=" They are not currently employed. ";
		}
		if ($C3 == "ON"){
			$mailmessage.=" They say that they are currently wanted for crimes against society. ";
		}else{
			$mailmessage.=" They say that they are currently not wanted for any crimes. ";
		}
		$mailmessage.=" They comment: ";
		$mailmessage.=$T1;
                set_module_pref('reason',$mailmessage);
		$sql = "SELECT acctid,value FROM ".db_prefix('module_userprefs')." LEFT JOIN ".db_prefix('accounts')." ON (acctid = userid) WHERE modulename='jobs' and setting='email' and value ='1'";
		$result = db_query($sql);
		for ($i=0;$i<db_num_rows($result);$i++){
	    $row = db_fetch_assoc($result);
		if ($row['value'] == 1){
		systemmail($row['acctid'],"`2Job Application`2",$mailmessage);	
			}
		}
		output("Job application sent to Human Resources.");
		addnav("Continue","runmodule.php?module=jobs&place=jobservice");
	}
	}
	if ($op == "foundapp"){
		if ($op2 == ""){
		output("<big><big><big><span style=\"font-weight: bold;\">Job Application<br></span><small><small><small>",true);
		output("`n`7Name: %s`7.`n",$session['user']['name']);
		output("`7Postion Applied for: Foundry Worker`n");
		output("<form action='runmodule.php?module=jobs&place=jobservice&op=foundapp&op2=applied' method='POST'>",true);
	  	output("<script language='JavaScript'>document.getElementById('bet').focus();</script>",true); 
		output("<p>Are you currently Employed? <input type=\"checkbox\" name=\"C1\" value=\"ON\">yes",true);
	  	output("<input type=\"checkbox\" name=\"C2\" value=\"ON\">no</p>",true);
	  	output("<p>Are you currently wanted for any crimes? <input type=\"checkbox\" name=\"C3\" value=\"ON\">yes",true);
	  	output("<input type=\"checkbox\" name=\"C4\" value=\"ON\">no</p>",true);
	  	output("<p>Please give a short reason why you would be qualified for this job: <input type=\"text\" name=\"T1\" size=\"37\"></p>",true);
	  	output("<p><input type=\"submit\" value=\"Submit\" name=\"B1\"><input type=\"reset\" value=\"Reset\" name=\"B2\"></p>",true);
		output("</form>",true);
		addnav("","runmodule.php?module=jobs&place=jobservice&op=foundapp&op2=applied");
	}
	if ($op2 == "applied"){
		set_module_pref('jobapp',5);
		$mailmessage=$session['user']['name'];
		$mailmessage.=" has applied for a job at the foundry. ";
		if ($C1 == "ON"){
			$mailmessage.=" They are currently employed. ";
		}else{
			$mailmessage.=" They are not currently employed. ";
		}
		if ($C3 == "ON"){
			$mailmessage.=" They say that they are currently wanted for crimes against society. ";
		}else{
			$mailmessage.=" They say that they are currently not wanted for any crimes. ";
		}
		$mailmessage.=" They comment: ";
		$mailmessage.=$T1;
                set_module_pref('reason',$mailmessage);
		$sql = "SELECT acctid,value FROM ".db_prefix('module_userprefs')." LEFT JOIN ".db_prefix('accounts')." ON (acctid = userid) WHERE modulename='jobs' and setting='email' and value ='1'";
		$result = db_query($sql);
		for ($i=0;$i<db_num_rows($result);$i++){
	    $row = db_fetch_assoc($result);
		if ($row['value'] == 1){
		systemmail($row['acctid'],"`2Job Application`2",$mailmessage);	
			}
		}
		output("Job application sent to Human Resources.");
		addnav("Continue","runmodule.php?module=jobs&place=jobservice");
	}
	}
	if ($op == "farmman"){
		if ($op2 == ""){
		output("<big><big><big><span style=\"font-weight: bold;\">Job Application<br></span><small><small><small>",true);
		output("`n`7Name: %s`7.`n",$session['user']['name']);
		output("`7Postion Applied for: Farm Management`n");
		output("<form action='runmodule.php?module=jobs&place=jobservice&op=farmman&op2=applied' method='POST'>",true);
	  	output("<script language='JavaScript'>document.getElementById('bet').focus();</script>",true); 
		output("<p>Are you currently Employed? <input type=\"checkbox\" name=\"C1\" value=\"ON\">yes",true);
	  	output("<input type=\"checkbox\" name=\"C2\" value=\"ON\">no</p>",true);
	  	output("<p>Are you currently wanted for any crimes? <input type=\"checkbox\" name=\"C3\" value=\"ON\">yes",true);
	  	output("<input type=\"checkbox\" name=\"C4\" value=\"ON\">no</p>",true);
	  	output("<p>Please give a short reason why you would be qualified for this job: <input type=\"text\" name=\"T1\" size=\"37\"></p>",true);
	  	output("<p><input type=\"submit\" value=\"Submit\" name=\"B1\"><input type=\"reset\" value=\"Reset\" name=\"B2\"></p>",true);
		output("</form>",true);
		addnav("","runmodule.php?module=jobs&place=jobservice&op=farmman&op2=applied");
	}
	if ($op2 == "applied"){
		$sql = "SELECT value FROM ".db_prefix('module_userprefs')." where value = 6";
		$result = db_query($sql);
		$jobfilled=db_num_rows($result);
		if ($jobfilled < 1){
		set_module_pref('jobapp',6);
		$mailmessage=$session['user']['name'];
		$mailmessage.=" has applied for a job at the farm as management. ";
		if ($C1 == "ON"){
			$mailmessage.=" They are currently employed. ";
		}else{
			$mailmessage.=" They are not currently employed. ";
		}
		if ($C3 == "ON"){
			$mailmessage.=" They say that they are currently wanted for crimes against society. ";
		}else{
			$mailmessage.=" They say that they are currently not wanted for any crimes. ";
		}
		$mailmessage.=" They comment: ";
		$mailmessage.=$T1;
                set_module_pref('reason',$mailmessage);
		$sql = "SELECT acctid,value FROM ".db_prefix('module_userprefs')." LEFT JOIN ".db_prefix('accounts')." ON (acctid = userid) WHERE modulename='jobs' and setting='email' and value ='1'";
		$result = db_query($sql);
		for ($i=0;$i<db_num_rows($result);$i++){
	    $row = db_fetch_assoc($result);
		if ($row['value'] == 1){
		systemmail($row['acctid'],"`2Job Application`2",$mailmessage);	
			}
		}
		output("Job application sent to Human Resources.");
		addnav("Continue","runmodule.php?module=jobs&place=jobservice");
	}else{
		output("Sorry, but the Management Postiion is already filled.");
		addnav("Continue","runmodule.php?module=jobs&place=jobservice");
	}
	}
	}
	if ($op == "millman"){
		if ($op2 == ""){
		output("<big><big><big><span style=\"font-weight: bold;\">Job Application<br></span><small><small><small>",true);
		output("`n`7Name: %s`7.`n",$session['user']['name']);
		output("`7Postion Applied for: Mill Manager`n");
		output("<form action='runmodule.php?module=jobs&place=jobservice&op=millman&op2=applied' method='POST'>",true);
	  	output("<script language='JavaScript'>document.getElementById('bet').focus();</script>",true); 
		output("<p>Are you currently Employed? <input type=\"checkbox\" name=\"C1\" value=\"ON\">yes",true);
	  	output("<input type=\"checkbox\" name=\"C2\" value=\"ON\">no</p>",true);
	  	output("<p>Are you currently wanted for any crimes? <input type=\"checkbox\" name=\"C3\" value=\"ON\">yes",true);
	  	output("<input type=\"checkbox\" name=\"C4\" value=\"ON\">no</p>",true);
	  	output("<p>Please give a short reason why you would be qualified for this job: <input type=\"text\" name=\"T1\" size=\"37\"></p>",true);
	  	output("<p><input type=\"submit\" value=\"Submit\" name=\"B1\"><input type=\"reset\" value=\"Reset\" name=\"B2\"></p>",true);
		output("</form>",true);
		addnav("","runmodule.php?module=jobs&place=jobservice&op=millman&op2=applied");
	}
	if ($op2 == "applied"){
		$sql = "SELECT value FROM ".db_prefix('module_userprefs')." where value = 7";
		$result = db_query($sql);
		$jobfilled=db_num_rows($result);
		if ($jobfilled < 1){
		set_module_pref('jobapp',7);
		$mailmessage=$session['user']['name'];
		$mailmessage.=" has applied for a job at the mill as management. ";
		if ($C1 == "ON"){
			$mailmessage.=" They are currently employed. ";
		}else{
			$mailmessage.=" They are not currently employed. ";
		}
		if ($C3 == "ON"){
			$mailmessage.=" They say that they are currently wanted for crimes against society. ";
		}else{
			$mailmessage.=" They say that they are currently not wanted for any crimes. ";
		}
		$mailmessage.=" They comment: ";
		$mailmessage.=$T1;
                set_module_pref('reason',$mailmessage);
		$sql = "SELECT acctid,value FROM ".db_prefix('module_userprefs')." LEFT JOIN ".db_prefix('accounts')." ON (acctid = userid) WHERE modulename='jobs' and setting='email' and value ='1'";
		$result = db_query($sql);
		for ($i=0;$i<db_num_rows($result);$i++){
	    $row = db_fetch_assoc($result);
		if ($row['value'] == 1){
		systemmail($row['acctid'],"`2Job Application`2",$mailmessage);	
			}
		}
		output("Job application sent to Human Resources.");
		addnav("Continue","runmodule.php?module=jobs&place=jobservice");
	}else{
		output("Sorry, but the Management Postiion is already filled.");
		addnav("Continue","runmodule.php?module=jobs&place=jobservice");
	}
	}
	}
	if ($op == "textileman"){
		if ($op2 == ""){
		output("<big><big><big><span style=\"font-weight: bold;\">Job Application<br></span><small><small><small>",true);
		output("`n`7Name: %s`7.`n",$session['user']['name']);
		output("`7Postion Applied for: Textile Management`n");
		output("<form action='runmodule.php?module=jobs&place=jobservice&op=textileman&op2=applied' method='POST'>",true);
	  	output("<script language='JavaScript'>document.getElementById('bet').focus();</script>",true); 
		output("<p>Are you currently Employed? <input type=\"checkbox\" name=\"C1\" value=\"ON\">yes",true);
	  	output("<input type=\"checkbox\" name=\"C2\" value=\"ON\">no</p>",true);
	  	output("<p>Are you currently wanted for any crimes? <input type=\"checkbox\" name=\"C3\" value=\"ON\">yes",true);
	  	output("<input type=\"checkbox\" name=\"C4\" value=\"ON\">no</p>",true);
	  	output("<p>Please give a short reason why you would be qualified for this job: <input type=\"text\" name=\"T1\" size=\"37\"></p>",true);
	  	output("<p><input type=\"submit\" value=\"Submit\" name=\"B1\"><input type=\"reset\" value=\"Reset\" name=\"B2\"></p>",true);
		output("</form>",true);
		addnav("","runmodule.php?module=jobs&place=jobservice&op=textileman&op2=applied");
	}
	if ($op2 == "applied"){
		$sql = "SELECT value FROM ".db_prefix('module_userprefs')." where value = 8";
		$result = db_query($sql);
		$jobfilled=db_num_rows($result);
		if ($jobfilled < 1){
		set_module_pref('jobapp',8);
		$mailmessage=$session['user']['name'];
		$mailmessage.=" has applied for a job at the Textile mill as managment. ";
		if ($C1 == "ON"){
			$mailmessage.=" They are currently employed. ";
		}else{
			$mailmessage.=" They are not currently employed. ";
		}
		if ($C3 == "ON"){
			$mailmessage.=" They say that they are currently wanted for crimes against society. ";
		}else{
			$mailmessage.=" They say that they are currently not wanted for any crimes. ";
		}
		$mailmessage.=" They comment: ";
		$mailmessage.=$T1;
                set_module_pref('reason',$mailmessage);
		$sql = "SELECT acctid,value FROM ".db_prefix('module_userprefs')." LEFT JOIN ".db_prefix('accounts')." ON (acctid = userid) WHERE modulename='jobs' and setting='email' and value ='1'";
		$result = db_query($sql);
		for ($i=0;$i<db_num_rows($result);$i++){
	    $row = db_fetch_assoc($result);
		if ($row['value'] == 1){
		systemmail($row['acctid'],"`2Job Application`2",$mailmessage);	
			}
		}
		output("Job application sent to Human Resources.");
		addnav("Continue","runmodule.php?module=jobs&place=jobservice");
	}else{
		output("Sorry, but the Management Postiion is already filled.");
		addnav("Continue","runmodule.php?module=jobs&place=jobservice");
	}
	}
	}
	if ($op == "brewman"){
		if ($op2 == ""){
		output("<big><big><big><span style=\"font-weight: bold;\">Job Application<br></span><small><small><small>",true);
		output("`n`7Name: %s`7.`n",$session['user']['name']);
		output("`7Postion Applied for: Brewery Manager`n");
		output("<form action='runmodule.php?module=jobs&place=jobservice&op=brewman&op2=applied' method='POST'>",true);
	  	output("<script language='JavaScript'>document.getElementById('bet').focus();</script>",true); 
		output("<p>Are you currently Employed? <input type=\"checkbox\" name=\"C1\" value=\"ON\">yes",true);
	  	output("<input type=\"checkbox\" name=\"C2\" value=\"ON\">no</p>",true);
	  	output("<p>Are you currently wanted for any crimes? <input type=\"checkbox\" name=\"C3\" value=\"ON\">yes",true);
	  	output("<input type=\"checkbox\" name=\"C4\" value=\"ON\">no</p>",true);
	  	output("<p>Please give a short reason why you would be qualified for this job: <input type=\"text\" name=\"T1\" size=\"37\"></p>",true);
	  	output("<p><input type=\"submit\" value=\"Submit\" name=\"B1\"><input type=\"reset\" value=\"Reset\" name=\"B2\"></p>",true);
		output("</form>",true);
		addnav("","runmodule.php?module=jobs&place=jobservice&op=brewman&op2=applied");
	}
	if ($op2 == "applied"){
		$sql = "SELECT value FROM ".db_prefix('module_userprefs')." where value = 9";
		$result = db_query($sql);
		$jobfilled=db_num_rows($result);
		if ($jobfilled < 1){
		set_module_pref('jobapp',9);
		$mailmessage=$session['user']['name'];
		$mailmessage.=" has applied for a job at the Brewery as Management. ";
		if ($C1 == "ON"){
			$mailmessage.=" They are currently employed. ";
		}else{
			$mailmessage.=" They are not currently employed. ";
		}
		if ($C3 == "ON"){
			$mailmessage.=" They say that they are currently wanted for crimes against society. ";
		}else{
			$mailmessage.=" They say that they are currently not wanted for any crimes. ";
		}
		$mailmessage.=" They comment: ";
		$mailmessage.=$T1;
                set_module_pref('reason',$mailmessage);
		$sql = "SELECT acctid,value FROM ".db_prefix('module_userprefs')." LEFT JOIN ".db_prefix('accounts')." ON (acctid = userid) WHERE modulename='jobs' and setting='email' and value ='1'";
		$result = db_query($sql);
		for ($i=0;$i<db_num_rows($result);$i++){
	    $row = db_fetch_assoc($result);
		if ($row['value'] == 1){
		systemmail($row['acctid'],"`2Job Application`2",$mailmessage);	
			}
		}
		output("Job application sent to Human Resources.");
		addnav("Continue","runmodule.php?module=jobs&place=jobservice");
	}else{
		output("Sorry, but the Management Postiion is already filled.");
		addnav("Continue","runmodule.php?module=jobs&place=jobservice");
	}
	}
	}
	if ($op == "foundman"){
		if ($op2 == ""){
		output("<big><big><big><span style=\"font-weight: bold;\">Job Application<br></span><small><small><small>",true);
		output("`n`7Name: %s`7.`n",$session['user']['name']);
		output("`7Postion Applied for: Foundry Manager`n");
		output("<form action='runmodule.php?module=jobs&place=jobservice&op=foundman&op2=applied' method='POST'>",true);
	  	output("<script language='JavaScript'>document.getElementById('bet').focus();</script>",true); 
		output("<p>Are you currently Employed? <input type=\"checkbox\" name=\"C1\" value=\"ON\">yes",true);
	  	output("<input type=\"checkbox\" name=\"C2\" value=\"ON\">no</p>",true);
	  	output("<p>Are you currently wanted for any crimes? <input type=\"checkbox\" name=\"C3\" value=\"ON\">yes",true);
	  	output("<input type=\"checkbox\" name=\"C4\" value=\"ON\">no</p>",true);
	  	output("<p>Please give a short reason why you would be qualified for this job: <input type=\"text\" name=\"T1\" size=\"37\"></p>",true);
	  	output("<p><input type=\"submit\" value=\"Submit\" name=\"B1\"><input type=\"reset\" value=\"Reset\" name=\"B2\"></p>",true);
		output("</form>",true);
		addnav("","runmodule.php?module=jobs&place=jobservice&op=foundman&op2=applied");
	}
	if ($op2 == "applied"){
		$sql = "SELECT value FROM ".db_prefix('module_userprefs')." where value = 10";
		$result = db_query($sql);
		$jobfilled=db_num_rows($result);
		if ($jobfilled < 1){
		set_module_pref('jobapp',10);
		$mailmessage=$session['user']['name'];
		$mailmessage.=" has applied for a job at the foundry as management. ";
		if ($C1 == "ON"){
			$mailmessage.=" They are currently employed. ";
		}else{
			$mailmessage.=" They are not currently employed. ";
		}
		if ($C3 == "ON"){
			$mailmessage.=" They say that they are currently wanted for crimes against society. ";
		}else{
			$mailmessage.=" They say that they are currently not wanted for any crimes. ";
		}
		$mailmessage.=" They comment: ";
		$mailmessage.=$T1;
                set_module_pref('reason',$mailmessage);
		$sql = "SELECT acctid,value FROM ".db_prefix('module_userprefs')." LEFT JOIN ".db_prefix('accounts')." ON (acctid = userid) WHERE modulename='jobs' and setting='email' and value ='1'";
		$result = db_query($sql);
		for ($i=0;$i<db_num_rows($result);$i++){
	    $row = db_fetch_assoc($result);
		if ($row['value'] == 1){
		systemmail($row['acctid'],"`2Job Application`2",$mailmessage);	
			}
		}
		output("Job application sent to Human Resources.");
		addnav("Continue","runmodule.php?module=jobs&place=jobservice");
	}else{
		output("Sorry, but the Management Postiion is already filled.");
		addnav("Continue","runmodule.php?module=jobs&place=jobservice");
	}
	}
	}
	if ($op == "status"){
		output("You nervously approach the old woman at the desk and ask the status of your job application.");
		output("  The old woman looks up at you with an angry glare and says \"Listen if you had gotten the");
		output(" job you would know!  I suggest a little patience, as mine is wearing thin with you!\"`n");
		addnav("Continue","runmodule.php?module=jobs&place=jobservice");
	}
	if ($op == "help"){
		output("You pick up a piece of paper that says Help with Jobs`n`n");
		output("`c`b`&Job Help`0`b`c`n");
		output("You get paid by the shift for work that you do.`n");
		output("You may work up to 5 shifts a day.");
		output("For each shift you gain job experience.`n");
		output("Job experience is needed to get a better job.`n");
		output("Low level jobs (farm,mill) pay poorly.`n");
		output("The better the job, the better the pay, the better the benefits.`n");
		output("As working builds muscle and character you gain experience while working.`n");
		output("The top employee gets a special bonus each day that he/she works.`n");
		output("The products at the market come as a direct result of working.`n");
		output("The products that you produce while working provide bonuses for those who consume them.`n");
		output("You must apply for a job first before you can work.`n");
		output("You will get a letter telling you when you have gotten your job.`n");
		output("If you do not work for too many days you will be fired from your job.`n");
		output("If you are fired from your job, you loose work experience.`n");
		output("You will not be hired if you are a wanted criminal.`n");
		output("You may quit your job at any time.`n");
		output("Getting a new job will automatically terminate your previous employment.`n");
		output("After getting your job, you should immediately put in at least 1 shift.`n");
		addnav("Continue","runmodule.php?module=jobs&place=jobservice");
	}
	villagenav();
	page_footer();
?>