<?php
page_header("Large Farm");
    output("`c`b`&Large Farm`0`b`c`n`n");
    if (get_module_pref('lastworked') < date("Y-m-d H:i:s",strtotime("-864000 seconds")) and get_module_pref('job') == 1 and get_module_pref('jobexp') > 0){
        output("You have been fired for not showing up for work for too long!");
        set_module_pref('job',0);
        set_module_pref('jobexp',(get_module_pref('jobexp') - 15));
    }
    if ($op == ""){
        output("This is a farm, on the farm things like milk, meat, and vegetables are produced for use by the villagers.`n");
        $sql = "SELECT acctid FROM ".db_prefix('module_userprefs')." LEFT JOIN ".db_prefix('accounts')." ON (acctid = userid) WHERE modulename='jobs' and setting='job' and value ='1'";
        $result = db_query($sql);
        for ($i=0;$i<db_num_rows($result);$i++){
        $row = db_fetch_assoc($result);
        $sql2 = "SELECT name,value FROM ".db_prefix('module_userprefs')." LEFT JOIN ".db_prefix('accounts')." ON (acctid = userid) WHERE acctid = '".$row['acctid']."' and modulename='jobs' and setting='jobexp'";
        $result2 = db_query($sql2);
        $row2 = db_fetch_assoc($result2);
            if ($row2['value'] > $top){
                $top = $row2['value'];
                $plaque = $row2['name'];
            }
        }
        if ($plaque <> ""){
        output("`7On a Plaque it says our top employee ");
        output("%s`7.`n",$plaque); 
    }
    }
    if (get_module_pref('jobapp') == 1){
        output("You wonder if you will get the job here that you applied for.`n");
    }else{
    if (get_module_pref('job') < 1 and get_module_pref('jobapp') <> 1 and $op == ""){
        output("You see a sign on the outside of the barn that says help wanted.  You realize that a job");
        output("would be a great way to earn some gold.  Good hard work can cleanse the soul.`n");
        addnav("Apply for a Job","runmodule.php?module=jobs&place=farm&op=apply");
    }
    if (get_module_pref('job') == 1){
        if (get_module_pref('jobworked')==0 and $op == ""){
        output("You come back to the farm.  As you are employed here it would be good to work at least 1");
        output("shift if you intend to keep your job.`n");
        if ($session['user']['turns'] > 0) addnav("Work","runmodule.php?module=jobs&place=farm&op=work");
        }else{
        if (get_module_pref('jobworked')==1){
        output("You have already worked today, come back again tommorow.`n");
            }
        }
        addnav("Quit your job","runmodule.php?module=jobs&place=farm&op=quit");
    }
    if (get_module_pref('job') == 6){
        if (get_module_pref('jobworked')==0 and $op == ""){
        output("You come back to the farm.  As you are a manager here it would be good to work at least 1");
        output("shift if you intend to keep your job.`n");
        if ($session['user']['turns'] > 0) addnav("Work","runmodule.php?module=jobs&place=farm&op=work");
        }else{
        if (get_module_pref('jobworked')==1){
        output("You have already worked today, come back again tommorow.`n");
            }
        }
        addnav("Quit your job","runmodule.php?module=jobs&place=farm&op=quit");
    }
    if (get_module_pref('job') > 1 and get_module_pref('job') <> 6){
        output("You have fond memories of many a hard day working on the farm.  Hard work like that helped");
        output("to build character and make you the successful person you are today.`n");
    }
    }
    if ($op == "quit"){
        output("Are you sure you want to quit your job?");
        addnav("Yes","runmodule.php?module=jobs&place=farm&op=yesquit");
        addnav("No","runmodule.php?module=jobs&place=farm");
    }
    if ($op == "yesquit"){
        output("Your letter of resignation has been submitted, you no longer work here.");
        set_module_pref('job',0);
        addnews($session['user']['name']."`7 quit their job at the farm today.");
    }
    if ($op == "apply"){
        output("<big><big><big><span style=\"font-weight: bold;\">Job Application<br></span><small><small><small>",true);
        output("`n`7Name: %s`7.`n",$session['user']['name']);
        output("`7Postion Applied for: Farm Hand`n");
        output("<form action='runmodule.php?module=jobs&place=farm&op=applied' method='POST'>",true);
        output("<script language='JavaScript'>document.getElementById('bet').focus();</script>",true); 
        output("<p>Are you currently Employed? <input type=\"checkbox\" name=\"C1\" value=\"ON\">yes",true);
        output("<input type=\"checkbox\" name=\"C2\" value=\"ON\">no</p>",true);
        output("<p>Are you currently wanted for any crimes? <input type=\"checkbox\" name=\"C3\" value=\"ON\">yes",true);
        output("<input type=\"checkbox\" name=\"C4\" value=\"ON\">no</p>",true);
        output("<p>Please give a short reason why you would be qualified for this job: <input type=\"text\" name=\"T1\" size=\"37\"></p>",true);
        output("<p><input type=\"submit\" value=\"Submit\" name=\"B1\"><input type=\"reset\" value=\"Reset\" name=\"B2\"></p>",true);
        output("</form>",true);
        addnav("","runmodule.php?module=jobs&place=farm&op=applied");
    }
    if ($op == "applied"){
        set_module_pref('jobapp',1);
        $mailmessage=$session['user']['name'];
        $mailmessage.=" has applied for a job at the farm. ";
        if ($C1 == "ON"){
            $mailmessage.=" They are currently employed. ";
        }else{
            $mailmessage.=" They are not currently employed. ";
        }
        if ($C3 == "ON"){
            $mailmessage.=" They say that they are currently wanted for crimes against society. ";
        }else{
            $mailmessage.=" They say that they are currently not wanted for any crimes. ";
        }
        $mailmessage.=" They comment: ";
        $mailmessage.=$T1;
                set_module_pref('reason',$mailmessage);
        $sql = "SELECT acctid,value FROM ".db_prefix('module_userprefs')." LEFT JOIN ".db_prefix('accounts')." ON (acctid = userid) WHERE modulename='jobs' and setting='email' and value ='1'";
        $result = db_query($sql);
        for ($i=0;$i<db_num_rows($result);$i++){
        $row = db_fetch_assoc($result);
        if ($row['value'] == 1){
        systemmail($row['acctid'],"`2Job Application`2",$mailmessage);  
            }
        }
        output("Job application sent to Human Resources.");
    }
    if ($op == "work"){
        if (get_module_pref('drunkeness','drinks')>65 and get_module_pref('job') == 1){
            output("The Foreman stops you...... \"How dare you show up to work in this condition!\"");
            output("\"Go sober up!\"");
            $session['user']['experience']-=3;
            villagenav();
        }else{
        if ($shifts < 1){
            output("How many shifts (turns) would you like to work? (5 Max)`n");
            output("<form action='runmodule.php?module=jobs&place=farm&op=work' method='POST'>",true);
            output("<p><input type=\"text\" name=\"shifts\" size=\"37\"></p>",true);
            output("<p><input type=\"submit\" value=\"Submit\" name=\"B1\"><input type=\"reset\" value=\"Reset\" name=\"B2\"></p>",true);
            output("</form>",true);
            addnav("","runmodule.php?module=jobs&place=farm&op=work");
        }else if ($shifts > 5){
            output("You cannot work more than 5 shifts!");
            addnav("Continue","runmodule.php?module=jobs&place=farm&op=work");  
        }else if ($shifts > $session['user']['turns']){
            output("You can only work".$session['user']['turns']."shifts!");
            addnav("Continue","runmodule.php?module=jobs&place=farm&op=work");  
        }else{
            output("You put your time in and work for %s shifts.`n",$shifts);
            if (get_module_pref('job') == 1){
            for ($i=1;$i<$shifts+1;$i++){
            output("Shift %s: ",$i);
            switch(e_rand(1,17)){
                case 1:
                output("You clean pig pens.`n");
                break;
                case 2:
                output("You work feed pigs.`n");
                break;
                case 3:
                output("You work in the Wheat field.`n");
                break;
                case 4:
                output("You work in the Hops field.`n");
                break;
                case 5:
                output("You milk cows.`n");
                break;
                case 6:
                output("You clean cow stalls.`n");
                break;
                case 7:
                output("You clean the manure from the barn.`n");
                break;
                case 8:
                output("You make hay.`n");
                break;
                case 9:
                output("You work in the corn field.`n");
                break;
                case 10:
                output("You feed the cows.`n");
                break;
                case 11:
                output("You clean chicken coops.`n");
                break;
                case 12:
                output("You collect chicken eggs.`n");
                break;
                case 13:
                output("You feed the chickens.`n");
                break;
                case 14:
                output("You pluck chickens.`n");
                break;
                case 15:
                output("You butcher beef.`n");
                break;
                case 16:
                output("You butcher ham.`n");
                break;
                case 17:
                output("You pluck and butcher chickens.`n");
                break;
            }
            }
            }
            if ($shifts == 1) output("You hardly worked at all.`n");
            if ($shifts == 2) output("You worked for a little while, you will never be the top employee that way.`n");
            if ($shifts == 3) output("You worked a decent amount of time, keep up the good work.`n");
            if ($shifts == 4) output("You worked for quite a while!  You are a hard worker, keep it up!`n");
            if ($shifts == 5) output("You are a workhorse!  Keep it up and you will be moving on up!`n");
            $farmincpay=get_module_setting("farmincpay","jobs");
            //make the increase pay variable into a percentage
            $farmincpay1= $farmincpay/100 +1;
            //make the multiplier a variable based on the number of shifts
            $farmpay1= get_module_setting("farmpay1","jobs");
            $farmpay2= $farmpay1*$farmincpay1;
            $farmpay3= $farmpay1*$farmincpay1*$farmincpay1;
            $farmpay4= $farmpay1*$farmincpay1*$farmincpay1*$farmincpay1;
            $farmpay5= $farmpay1*$farmincpay1*$farmincpay1*$farmincpay1*$farmincpay1;
            //calculate the pay based on the number of shifts worked
            if ($shifts == 1) $paid1 = $farmpay1;
            if ($shifts == 2) $paid1 = $farmpay1 + $farmpay2;
            if ($shifts == 3) $paid1 = $farmpay1 + $farmpay2 + $farmpay3;
            if ($shifts == 4) $paid1 = $farmpay1 + $farmpay2 + $farmpay3 + $farmpay4;
            if ($shifts == 5) $paid1 = $farmpay1 + $farmpay2 + $farmpay3 + $farmpay4 + $farmpay5;
            //make payment an integer after multiplying by percentages
            $paid=round($paid1);
            $session['user']['gold']+=$paid;
            if (get_module_pref('job') == 6){
                $session['user']['gold']+=($shifts*70);
                $paid+=$shifts*70;
            }
            output("You are paid $paid gold for working today.");
            $session['user']['turns']-=$shifts;
            $experience=((e_rand(10,60)*$shifts)+$session['user']['level'])/5;
            if (get_module_pref('job')>5){
                $experience+=((e_rand(130,180)*$shifts)+$session['user']['level'])/5;
            }
            set_module_pref('jobexp',(get_module_pref('jobexp') + $experience)); 
            set_module_pref('jobworked',1);
            if (is_module_active('odor')){
                set_module_pref('odor', get_module_pref('odor','odor') + 3,'odor');
            }
            if (is_module_active('usechow')){
                set_module_pref('hunger', get_module_pref('hunger','usechow') + $shifts,'usechow');
            }
            set_module_pref('jobexp',(get_module_pref('jobexp') + $shifts)); 
            set_module_pref('lastworked',date("Y-m-d H:i:s"));
            set_module_setting('farm',(get_module_setting('farm') + $shifts));
            $sql = "SELECT value FROM ".db_prefix('module_userprefs')." WHERE modulename='jobs' and setting='job' and value='1'";
            $result = db_query($sql);
            for ($i=0;$i<db_num_rows($result);$i++){
            $row = db_fetch_assoc($result);
            $sql2 = "SELECT value,name FROM ".db_prefix('module_userprefs')." LEFT JOIN ".db_prefix('accounts')." ON (acctid = userid) WHERE modulename='jobs' and setting='jobexp' and userid = '".$row['userid']."'";
            $result2 = db_query($sql2);
            $row2 = db_fetch_assoc($result2);
            if ($row2['value'] > $topjob){
            $topjob = $row2['value'];
            $plaque = $row2['name'];
            if ($row2['name']==$session['user']['name']){
                output("You are the Top Employee!  You have a Farmer Fury!");
                apply_buff('farmfury',array("name"=>"`4Farmer Fury","rounds"=>10,"wearoff"=>"`4Your farmers fury fades.","atkmod"=>1.25,"roundmsg"=>"`4You've got a farmers fury going, your attack is amazing!.","activate"=>"offense"));
            }
        }
        }
    }
    }
    }
    $sql = "SELECT name FROM ".db_prefix('module_userprefs')." LEFT JOIN ".db_prefix('accounts')." ON (acctid = userid) WHERE modulename='jobs' and setting='job' and value ='6' LIMIT 1";
    $result = db_query($sql);
    $row = db_fetch_assoc($result);
    if ($row['name'] <> ""){
        output("`nManagement: ".$row['name']);
    }
    output("`n`2Current Employees`n");
    $sql = "SELECT name FROM ".db_prefix('module_userprefs')." LEFT JOIN ".db_prefix('accounts')." ON (acctid = userid) WHERE modulename='jobs' and setting='job' and value ='1' ORDER BY name";
        $result = db_query($sql);
        for ($i=0;$i<db_num_rows($result);$i++){
        $row = db_fetch_assoc($result);
        output("`2- %s `2-`n",$row['name']);
        }
    villagenav();
    page_footer();
?>