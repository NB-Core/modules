<?php

function jobs_getmoduleinfo(){
    $info = array(
        "name"=>"Jobs",
        "version"=>"20050530b",
        "author"=>"`#Lonny Luberts<br />Contributions by `!Hex, tweak by DaveS",
        "category"=>"PQcomp",
        "download"=>"http://www.pqcomp.com/modules/mydownloads/visit.php?cid=3&lid=7",
        "vertxtloc"=>"",
        "prefs"=>array(
            "Jobs Module User Preferences,title",
            "super"=>"Admin/Moderator Job Application Processing,bool|0",
            "email"=>"Send email on new applications?,bool|0",
            "reason"=>"Reason they are applying,text|",
            "lastworked"=>"Date Last Worked,text",
            "job"=>"Job,int|0",
            "jobexp"=>"Job Experience,int|0",
            "jobapp"=>"Job application,int|0",
            "jobworked"=>"Job Worked,int|0",
        ),
        "settings"=>array(
            "Jobs Module Settings,title",
            "clothprice"=>"Selling price for Cloth,int|3",
            "leatherprice"=>"Selling price for Leather,int|4",
            "farmloc"=>"Where does the Farm appear,location|".getsetting("villagename", LOCATION_FIELDS),
            "millloc"=>"Where does the Mill appear,location|".getsetting("villagename", LOCATION_FIELDS),
            "textileloc"=>"Where does the Textile Mill appear,location|".getsetting("villagename", LOCATION_FIELDS),
            "breweryloc"=>"Where does the Brewery appear,location|".getsetting("villagename", LOCATION_FIELDS),
            "foundryloc"=>"Where does the Foundry appear,location|".getsetting("villagename", LOCATION_FIELDS),
            "jobserviceloc"=>"Where does the Job Services appear,location|".getsetting("villagename", LOCATION_FIELDS),
            "marketloc"=>"Where does the Market appear,location|".getsetting("villagename", LOCATION_FIELDS),
            "farm"=>"Unused Farm shifts,int|0",
            "mill"=>"Unused Mill shifts,int|0",
            "textile"=>"Unused Textile Mill shifts,int|0",
            "brewery"=>"Unused Brewery shifts,int|0",
            "foundry"=>"Unused Foundry shifts,int|0",
            "farmpay1"=>"Pay for first day of work at farm,int|50",
            "millpay1"=>"Pay for first day of work at millpay,int|80",
            "textpay1"=>"Pay for first day of work at textilepay,int|120",
            "brewpay1"=>"Pay for first day of work at brewerypay,int|170",
            "founpay1"=>"Pay for first day of work at foundrypay,int|230",
            "farmincpay"=>"Percentage pay increase for each ff worked at the farm, int|30",
            "millincpay"=>"Percentage pay increase for each ff worked at the mill, int|26",
            "textincpay"=>"Percentage pay increase for each ff worked at the textile, int|22",
            "brewincpay"=>"Percentage pay increase for each ff worked at the brewery, int|18",
            "founincpay"=>"Percentage pay increase for each ff worked at the foundry, int|14",
            "milk"=>"Milk Quantity,int|0",
            "egg"=>"Egg Quantity,int|0",
            "pork"=>"Pork Quantity,int|0",
            "beef"=>"Beef Quantity,int|0",
            "chicken"=>"Chicken Quantity,int|0",
            "bread"=>"Bread Quantity,int|0",
            "cloth"=>"Cloth Quantity,int|0",
            "leather"=>"Leather Quantity,int|0",
            "ale"=>"Ale Quantity,int|0",
            "breastplate"=>"Breastplate Quantity,int|0",
            "longsword"=>"LongSword Quantity,int|0",
            "chainmail"=>"Chainmail Quantity,int|0",
            "duallongsword"=>"Dual Longsword Quantity,int|0",
            "fullarmor"=>"Full Armor Quantity,int|0",
            "duallongsworddaggers"=>"Dual Longsword with daggers Quantity,int|0",
        ),
    );
    return $info;
}

function jobs_install(){
    if (!is_module_active('jobs')){
        output("`4Installing Jobs Module.`n");
    }else{
        output("`4Updating Jobs Module.`n");
    }
    module_addhook("newday");
    module_addhook("village");
    module_addhook("superuser");
    return true;
}

function jobs_uninstall(){
    output("`4Installing Jobs Module.`n");
    return true;
}

function jobs_dohook($hookname,$args){
    global $session;
    switch($hookname){
        case "village":
            if ($session['user']['location'] == get_module_setting("farmloc")){
            tlschema($args['schemas']['marketnav']);
            addnav($args['marketnav']);
            tlschema();
            addnav("Farm","runmodule.php?module=jobs&place=farm");
            }
            if ($session['user']['location'] == get_module_setting("millloc")){
            tlschema($args['schemas']['marketnav']);
            addnav($args['marketnav']);
            tlschema();
            addnav("Mill","runmodule.php?module=jobs&place=mill");
            }
            if ($session['user']['location'] == get_module_setting("textileloc")){
            tlschema($args['schemas']['marketnav']);
            addnav($args['marketnav']);
            tlschema();
            addnav("Textile Mill","runmodule.php?module=jobs&place=textile");
            }
            if ($session['user']['location'] == get_module_setting("breweryloc")){
            tlschema($args['schemas']['marketnav']);
            addnav($args['marketnav']);
            tlschema();
            addnav("Brewery","runmodule.php?module=jobs&place=brewery");
            }
            if ($session['user']['location'] == get_module_setting("foundryloc")){
            tlschema($args['schemas']['marketnav']);
            addnav($args['marketnav']);
            tlschema();
            addnav("Foundry","runmodule.php?module=jobs&place=foundry");
            }
            if ($session['user']['location'] == get_module_setting("jobserviceloc")){
            tlschema($args['schemas']['marketnav']);
            addnav($args['marketnav']);
            tlschema();
            addnav("Job Services","runmodule.php?module=jobs&place=jobservice");
            }
            if ($session['user']['location'] == get_module_setting("marketloc")){
            tlschema($args['schemas']['marketnav']);
            addnav($args['marketnav']);
            tlschema();
            addnav("Industrial Market","runmodule.php?module=jobs&place=market");
            }
        break;
        case "newday":
            set_module_pref('jobworked',0);
        break;
        case "superuser":
        $sql = "SELECT acctid,name,value FROM ".db_prefix('module_userprefs')." LEFT JOIN ".db_prefix('accounts')." ON (acctid = userid) WHERE modulename='jobs' and setting='jobapp' and value>0";
        $result = db_query($sql);
        $countapps=db_num_rows($result);
            if (get_module_pref('super')) addnav(array("Process Job Applications (%s)",$countapps),"runmodule.php?module=jobs&place=super");
        break;
    }
    return $args;
}

function jobs_run(){
    global $session;
    require_once("lib/systemmail.php");
    $op = httpget('op');
    $op2 = httpget('op2');
    $place = httpget('place');
    $shifts = $_POST['shifts'];
    $C1 = $_POST['C1'];
    $C2 = $_POST['C2'];
    $C3 = $_POST['C3'];
    $C4 = $_POST['C4'];
    $T1 = $_POST['T1'];
    if ($place == "farm"){
        include("modules/lib/jobsfarm.php");    
    }
    if ($place == "mill"){
        include("modules/lib/jobsmill.php");
    }
    if ($place == "textile"){
        include("modules/lib/jobstextile.php");
    }
    if ($place == "brewery"){
        include("modules/lib/jobsbrewery.php");
    }
    if ($place == "foundry"){
        include("modules/lib/jobsfoundry.php");
    }
    if ($place == "jobservice"){
        include("modules/lib/jobsjobservice.php");
    }
    if ($place == "market"){
        include("modules/lib/jobsmarket.php");
    }
    if ($place == "super"){
        include("modules/lib/jobssuper.php");
    }
}
?>