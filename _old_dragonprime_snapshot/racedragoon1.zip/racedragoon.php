<?php
// City-Less Functionality adopted from racefelyne of core.

function racedragoon_getmoduleinfo(){
    $info = array(
        "name"=>"Race - Dragoon",
        "version"=>"1.0",
        "author"=>"TechnoDragon.net",
        "category"=>"Races",
        "download"=>"http://forum.technodragon.net/index.php?action=tpmod;dl=0",
		"description"=>"Race. Buff based on Level. Male Specific",
        "settings"=>array(
            "Dragoon Race Settings,title",
            "minedeathchance"=>"Chance for Dragoon to die in the mine,range,0,100,1|25",
			"divide"=>"Level is divided by this value to give buff,int|5",
			"mindk"=>"How many DKs do you need before the race is available?,int|5",
        ),
        );
    return $info;
}

function racedragoon_install(){
	if (!is_module_installed("raceelf")) {
		output("The Dragoon only choose to live with elves.   You must install that race module.");
		return false;
	}
    module_addhook("chooserace");
    module_addhook("setrace");
    module_addhook("charstats");
	module_addhook("newday");
	module_addhook("racenames");
    module_addhook("raceminedeath");
    return true;
}

function racedragoon_uninstall(){
	global $session;
	$vname = getsetting("villagename", LOCATION_FIELDS);
	$gname = get_module_setting("villagename");
	$sql = "UPDATE " . db_prefix("accounts") . " SET location='$vname' WHERE location = '$gname'";
	db_query($sql);
	if ($session['user']['location'] == $gname)
		$session['user']['location'] = $vname;
	$sql = "UPDATE  " . db_prefix("accounts") . " SET race='" . RACE_UNKNOWN . "' WHERE race='Dragoon'";
	db_query($sql);
	if ($session['user']['race'] == 'Dragoon')
		$session['user']['race'] = RACE_UNKNOWN;
	return true;
}

function racedragoon_dohook($hookname,$args){
    //yeah, the $resline thing is a hack.  Sorry, not sure of a better way
    //to handle this.
    // It could be passed as a hook arg?
    global $session,$resline;
	if (is_module_active("raceelf")) {
		$city = get_module_setting("villagename", "raceelf");
	} else {
		$city = getsetting("villagename", LOCATION_FIELDS);
	}
    $race = "Dragoon";
	$divide = get_module_setting("divide");
    $dragoon = min((round($session['user']['level']/$divide)),3);
    switch($hookname){
    case "raceminedeath":
        if ($session['user']['race'] == $race) {
            $args['chance'] = get_module_setting("minedeathchance");
            $args['racesave'] = "Fortunately your Dragoon skills let you escape unscathed.`n";
        }
        break;
	case "racenames":
		$args[$race] = $race;
		break;
    case "charstats":
        if ($session['user']['race']==$race){
            addcharstat("Vital Info");
            addcharstat("Race", translate_inline($race));
        }
        break;
     case "chooserace":
		if ($session['user']['sex']==FEMALE)
		    break;
        if ($session['user']['dragonkills'] < get_module_setting("mindk"))
			break;
        output("<a href='newday.php?setrace=Dragoon$resline'>The land of Elves and Dragoons, %s</a>, `5hidden away from the world. `^Dragoon`0`5-Dedicating your life to the destruction of the Legendary `@Green Dragon`0`n`n`0", $city,true);
        addnav("`^D`5ragoon`0","newday.php?setrace=Dragoon$resline");
        addnav("","newday.php?setrace=Dragoon$resline");
        break;
    case "setrace":
        if ($session['user']['race']==$race){
            output("`^As a dragoon, your acquired knowledge helps you in battle.`nYou gain extra defense!");
            if (is_module_active("cities")) {
                if ($session['user']['dragonkills']==0 &&
                        $session['user']['age']==0){
                    //new farmthing, set them to wandering around this city.
                    set_module_setting("newest-$city",
                            $session['user']['acctid'],"cities");
                }
                set_module_pref("homecity",$city,"cities");
                $session['user']['location']=$city;
            }
        }
        break;
    case "newday":
        if ($session['user']['race']==$race){
            racedragoon_checkcity();
            apply_buff("racialbenefit",array(
                "name"=>"`@Dragoon Dexterity`0",
                "defmod"=>"(<defense>?(1+((1+floor($dragoon))/<defense>)):0)",
                "allowintrain"=>1,
                "allowinpvp"=>1,
                "rounds"=>-1,
                )
            );
        }
        break;
    }
    return $args;
}

function racedragoon_checkcity(){
    global $session;
    $race="Dragoon";
    if (is_module_active("raceelf")) {
		$city = get_module_setting("villagename", "raceelf");
	} else {
		$city = getsetting("villagename", LOCATION_FIELDS);
	}
	
	if ($session['user']['race']==$race && is_module_active("cities")){
		//if they're this race and their home city isn't right, set it up.
		if (get_module_pref("homecity","cities")!=$city){ //home city is wrong
			set_module_pref("homecity",$city,"cities");
		}
	}
    return true;
}

function racedragoon_run(){
}
?>