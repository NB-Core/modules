I've come up with the following way of allowing lonnyl's potions on quests and during forest fights (including the dragon).
 There may be a better way, but this works for me:

in quests.php

after
--------------------------
page_header("Quests");    
-------------------------- 


add
--------------------------
$session['usepotion'] = 1; 
--------------------------


at the end of the file,

after
--------------------------
   $session[user][experience]+=($badguy[creatureexp]+$expbonus);
   $creaturelevel = $badguy[creaturelevel];
   $HTTP_GET_VARS[op]=""; 
--------------------------


add
--------------------------
$session['usepotion'] = 0;
--------------------------
 


in common.php

in the potion meter code

change
--------------------------
if ($badguy['creaturename']<>"" or $session['user']['alive']==0 or strstr($currentpage, "usepotion") !="" or strstr($currentpage, "usechow") !="" or strstr($currentpage, "newday") !="" or $session['user']['specialinc'] <> ""){ 
-------------------------- 


to
--------------------------
if ($session['usepotion'] == 0 or $session['user']['alive']==0 or strstr($currentpage, "usepotion") !="" or strstr($currentpage, "usechow") !="" or strstr($currentpage, "newday") !="" or $session['user']['specialinc'] <> ""){ 
-------------------------- 


further down
after
--------------------------
if ($currentpage != "usepotion.php" or $currentpage != "usechow.php"){
      $session['user']['pqrestorepage']=$currentpage;
   } 
-------------------------- 


add
--------------------------
   if ($currentpage == "quests.php")   {
      $currentpage2=$_SERVER['REQUEST_URI'];
      if (strstr($currentpage2, "?") !=""){
         $position2=strrpos($currentpage2,"?");
         $currentpage2=substr($currentpage2,$position2);
         $currentpage2 = "quests.php".$currentpage2;
         $session['user']['pqrestorepage']= $currentpage2;
      }
   }
   if ($currentpage == "forest.php")   {
      $currentpage2=$_SERVER['REQUEST_URI'];
      if (strstr($currentpage2, "?") !=""){
         $position2=strrpos($currentpage2,"?");
         $currentpage2=substr($currentpage2,$position2);
         $currentpage2 = "forest.php".$currentpage2;
         $session['user']['pqrestorepage']= $currentpage2;
      }
   } 
   if ($currentpage == "dragon.php")   {
      $currentpage2=$_SERVER['REQUEST_URI'];
      if (strstr($currentpage2, "?") !=""){
         $position2=strrpos($currentpage2,"?");
         $currentpage2=substr($currentpage2,$position2);
         $currentpage2 = "dragon.php".$currentpage2;
         $session['user']['pqrestorepage']= $currentpage2;
      }
   }
--------------------------




in forest.php

after
--------------------------
require_once "common.php"; 
--------------------------


add
--------------------------
$session['usepotion'] = 1; 
--------------------------


after
--------------------------
output("`b`&$badguy[creaturelose]`0`b`n");  
-------------------------- 


add
--------------------------
$session['usepotion'] = 0; 
--------------------------


the use of lonnyl's suggestion of using the $session variables is to keep people from drinking potions on the screen that awards exp and gold, because without them, you can drink potions there, and get a second dose of reward, or third or however many potions you drink.

You can add the $session['usepotion'] = 0 to any file, or forest specials you don't want them to drink potions in, or any pieces parts of them as well.....

Thanks to lonnyl for the potion script.