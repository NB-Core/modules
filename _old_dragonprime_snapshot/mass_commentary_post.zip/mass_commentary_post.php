<?php

function mass_commentary_post_getmoduleinfo(){
	$info = array(
		"name"=>"Mass Commentary Post",
		"author"=>"Chris Vorndran",
		"version"=>"1.0",
		"category"=>"Administrative",
	);
	return $info;
}
function mass_commentary_post_install(){
	module_addhook("superuser");
	return true;
}
function mass_commentary_post_uninstall(){
	return true;
}
function mass_commentary_post_dohook($hookname,$args){
	global $session;
	switch($hookname){
		case "superuser":
			if ($session['user']['superuser'] & SU_EDIT_USERS){
				addnav("Actions");
				addnav("Mass Commentary Post","runmodule.php?module=mass_commentary_post");
			}
			break;
		}
	return $args;
}
function mass_commentary_post_run(){
	global $session;
	$comment = httppost('comment');
	page_header("Mass Commentary Post");
	if ($comment == ""){
		rawoutput("<form action='runmodule.php?module=mass_commentary_post' method='post'>");
		rawoutput("<input name='comment' maxlength='255'>");
		rawoutput("<input type='submit' class='button' value='".translate_inline("Post")."'></form>");
	}else{
		$sql = "SELECT DISTINCT section FROM ".db_prefix("commentary")."";
		$res = db_query($sql);
		while($row = db_fetch_assoc($res)){
			require_once("lib/commentary.php");
			injectrawcomment($row['section'], $session['user']['acctid'], $comment);
		}
	}
	addnav("","runmodule.php?module=mass_commentary_post");
	require_once("lib/superusernav.php");
	superusernav();
	page_footer();
}
?>