<?php
//translator ready
//V0.81 - Old Man now can't win with a hand over 21 points

function game_black_jack_getmoduleinfo(){
	$info = array(
		"name"=>"Black Jack Game for DarkHorse",
		"author"=>"Hazardy, fix by SexyCook",
		"version"=>"0.81",
		"category"=>"Darkhorse Game",
		"download"=>"http://dragonprime.net/users/HADES-HL/game_black_jack.zip"
	);
	return $info;
}

function game_black_jack_install(){
	global $session;
	debug("Adding Hooks");
	module_addhook("darkhorsegame");
	return true;
}

function game_black_jack_uninstall(){
	output("Uninstalling this module.`n");
	return true;
}

function game_black_jack_dohook($hookname, $args){
	if ( $hookname == "darkhorsegame" ) {
		$ret = $args['return'];
		addnav("B?Play Black Jack Game",
				"runmodule.php?module=game_black_jack&ret=$ret");
	}
	return $args;
}

function game_black_jack_cardpoints($cards, $card) {
	$points = 0;
	$ace = 0;
	for($i=1;$i<=$card;$i++) {
		switch ( $cards[$i.'n'] ) {
			case  1	: $ace++; break;
			case 11 : $points+=10; break;
			case 12 : $points+=10; break;
			case 13 : $points+=10; break;
			default : $points+=$cards[$i.'n']; break;
		}
	}
	while ( $ace ) {
		if ( $points > 10 || $ace > 1 ) {
			$points+=1;
		}
		else {
			$points+=11;
		}
		$ace--;
	}
	return $points;
}

function game_black_jack_cardcolor($card) {
	switch ( $card ) {
		case 1 : $color = translate_inline("club"); break;
		case 2 : $color = translate_inline("diamonds"); break;
		case 3 : $color = translate_inline("hearts"); break;
		case 4 : $color = translate_inline("spade"); break;
	}
	return $color;
}

function game_black_jack_cardname($card) {
	switch ( $card ) {
		case  1 : $cname = translate_inline("an ace"); break;
		case  2 : $cname = translate_inline("a two"); break;
		case  3 : $cname = translate_inline("a three"); break;
		case  4 : $cname = translate_inline("a four"); break;
		case  5 : $cname = translate_inline("a five"); break;
		case  6 : $cname = translate_inline("a six"); break;
		case  7 : $cname = translate_inline("a seven"); break;
		case  8 : $cname = translate_inline("a eight"); break;
		case  9 : $cname = translate_inline("a nine"); break;
		case 10 : $cname = translate_inline("a ten"); break;
		case 11 : $cname = translate_inline("a jack"); break;
		case 12 : $cname = translate_inline("a queen"); break;
		case 13 : $cname = translate_inline("a king"); break;
	}
	return $cname;
}

function game_black_jack_number($i) {
	switch ( $i ) {
		case 1  : $number = translate_inline("1st"); break;
		case 2  : $number = translate_inline("2nd"); break;
		case 3  : $number = translate_inline("3rd"); break;
		default : $number = translate_inline($i."th"); break;
	}
	return $number;
}

function game_black_jack_run(){
	global $session;
	$ret = httpget("ret");
	page_header("A Game of Black Jack");
	$cards = unserialize($session['user']['specialmisc']);
	for ( $i = 1; $i <= 4; $i++ ) {
		for ( $j = 1; $j <= 13; $j++ ) {
			$cards[left][$i][$j] = 6;
		}
	}

	if ( $session['user']['gold'] > 0 ) {
		$bet = abs((int)httpget('bet') + (int)httppost('bet'));
		if ( $bet <= 0 ) {
			$sex = $session['user']['sex'];
			if ( $sex ) {
				$sex = translate_inline("lady");
			}
			else {
				$sex = translate_inline("man");
			}
			addnav("Never mind", "$ret?op=oldman");
			output("`3\"`!You get two open cards from me and I take one open and one down card, than you can choose if you take one more card or not, until you get more than 21 points. If you have more than 21 you've lost, if you have 21 or less and don't want anymore, I'll do the same. The one with the most points will win.`3\"`n`n");
			output("`3\"`!How much would you bet young %s?`3\"",$sex);
			rawoutput("<form action='runmodule.php?module=game_black_jack&what=begin&ret=$ret' method='POST'>");
			rawoutput("<input name='bet' id='bet'>");
			rawoutput("<input type='submit' class='button' value='Bet'>");
			rawoutput("</form>");
			output("<script language='JavaScript'>document.getElementById('bet').focus();</script>",true);
			addnav("","runmodule.php?module=game_black_jack&what=begin&ret=$ret");
		}
		elseif ( $bet > $session['user']['gold'] ) {
			output("`3The old man reaches out with his stick and pokes your coin purse.  \"`!I don't believe you have `^%s`! gold!`3\" he declares.`n`n",$bet);
			output("Desperate to really show him good, you open up your purse and spill out its contents: `^%s`3 gold.",$session['user']['gold']);
			output("`n`nEmbarrased, you think you'll head back to the tavern.");
			addnav("Return to the Main Room","$ret?op=tavern");
		}
		else {
			$what = httpget('what');
			$card=(int)httpget('card');
			$mcard=(int)httpget('mcard');
			if ( $what == "card" || $what == "begin" ) {
				if ( $what == "begin" ) {
					while ( $mcard < 2 ) {
						$mcard++;
						do {
							$cards[man][$mcard.'c'] = e_rand(1,4);
							$cards[man][$mcard.'n'] = e_rand(1,13);
						} while ( $cards[left][$cards[man][$mcard.'c']][$cards[man][$mcard.'n']] == 0 );
						$cards[left][$cards[man][$mcard.'c']][$cards[man][$mcard.'n']]--;
					}
					while ( $card < 2 ) {
						$card++;
						do {
							$cards[user][$card.'c'] = e_rand(1,4);
							$cards[user][$card.'n'] = e_rand(1,13);
						} while ( $cards[left][$cards[user][$card.'c']][$cards[user][$card.'n']] == 0 );
						$cards[left][$cards[user][$card.'c']][$cards[user][$card.'n']]--;
					}
				}

				else {
					do {
						$card++;
						$cards[user][$card.'c'] = e_rand(1,4);
						$cards[user][$card.'n'] = e_rand(1,13);
					} while ( $cards[left][$cards[user][$card.'c']][$cards[user][$card.'n']] == 0 );
					$cards[left][$cards[user][$card.'c']][$cards[$card.'n']]--;
				}

				$upoints = game_black_jack_cardpoints($cards[user],$card);
				$color = game_black_jack_cardcolor($cards[man]['1'.'c']);
				$cname = game_black_jack_cardname($cards[man]['1'.'n']);
				$number = game_black_jack_number(1);
				output("The %s card of the man is %s of %s.`n",$number,$cname,$color);
				$number = game_black_jack_number(2);
				output("The %s card of the man is hide.`n`n",$number);

				for ( $i = 1; $i <= $card; $i++ ) {
					$color = game_black_jack_cardcolor($cards[user][$i.'c']);
					$cname = game_black_jack_cardname($cards[user][$i.'n']);
					$number = game_black_jack_number($i);
					output("Your %s. card is %s of %s.`n",$number,$cname,$color);
				}
				output("`nYour points are now %s.`nYou've bet %s Gold.`n",$upoints,$bet);

				if ( $upoints == 21 ) {
					if ( $card == 2 ) {
						output("You got a black jack!");
						addnav("Rest","runmodule.php?module=game_black_jack&what=bljack&card=$card&mcard=$mcard&bet=$bet&ret=$ret");
					}
					else {
						output("You got 21 points, well done!");
						addnav("Rest","runmodule.php?module=game_black_jack&what=rest&card=$card&mcard=$mcard&bet=$bet&ret=$ret");
					}
				}
				elseif ( $upoints < 21 ) {
					output("Want you one more or rest?");
					addnav("Card","runmodule.php?module=game_black_jack&what=card&card=$card&mcard=$mcard&bet=$bet&ret=$ret");
					addnav("Rest","runmodule.php?module=game_black_jack&what=rest&card=$card&mcard=$mcard&bet=$bet&ret=$ret");
				}
				else {
					output("D'oh you got more than 21 points, you've lost...");
					addnav("Lost","runmodule.php?module=game_black_jack&what=lost&card=$card&mcard=$mcard&bet=$bet&ret=$ret");
				}
			}
			else{
				$upoints = game_black_jack_cardpoints($cards[user],$card);
				if ( $upoints > 21 ) {
					$win = -1;
				}
				elseif ( $what == $bljack ) {
					if ( game_black_jack_cardpoints($cards[man],$mcard) == 21 ) {
						$win = 0;
					}
					else {
						$win = 1;
					}
				}
				else {
					while ( game_black_jack_cardpoints($cards[man],$mcard) < 16 ) {
						$mcard++;
						do {
							$cards[man][$mcard.'c'] = e_rand(1,4);
							$cards[man][$mcard.'n'] = e_rand(1,13);
						} while ( $cards[left][$cards[man][$mcard.'c']][$cards[man][$mcard.'n']] == 0 );
						$cards[left][$cards[man][$mcard.'c']][$cards[man][$mcard.'n']]--;
					}
					$mpoints = game_black_jack_cardpoints($cards[man],$mcard);
					if ( $mpoints > $upoints && $mpoints < 22 ) {
						$win = -1;
					}
					elseif ( $mpoints < $upoints || $mpoints > 21 ) {
						$win = 1;
					}
					else {
						$win = 0;
					}
				}
				$mpoints = game_black_jack_cardpoints($cards[man],$mcard);
				for ( $i = 1; $i <= $card; $i++ ) {
					$color = game_black_jack_cardcolor($cards[user][$i.'c']);
					$cname = game_black_jack_cardname($cards[user][$i.'n']);
					$number = game_black_jack_number($i);
					output("Your %s card is %s of %s.`n",$number,$cname,$color);
				}
				output("`nYour points are now %s.`nYou've bet %s Gold.`n`n",$upoints,$bet);
				for ( $i = 1; $i <= $mcard; $i++ ) {
					$color = game_black_jack_cardcolor($cards[man][$i.'c']);
					$cname = game_black_jack_cardname($cards[man][$i.'n']);
					$number = game_black_jack_number($i);
					output("The %s card of the man is %s of %s.`n",$number,$cname,$color);
				}
				output("`nThe points of the man are now %s.",$mpoints);
				if ( $win < 0 ) {
					output("`n\"`7Yeehaw, I knew the likes of you would never stand up to the likes of me!`0\" exclaims the old man as you hand him your `^%s`0 gold.",$bet);
					$session['user']['gold']-=$bet;
					debuglog("lost $bet gold at bljack");
				}
				elseif ( $win == 0 ) {
					output("`n\"`7Yah... well, looks as though we tied.`0\" he says.");
				}
				else {
					output("`n\"`7Aaarrgh!!!  How could the likes of you beat me?!?!?`0\" shouts the old man as he gives you the gold he owes.");
					$session['user']['gold']+=$bet;
					debuglog("won $bet gold at bljack");
				}
				$cards=array();
				addnav("Play again?","runmodule.php?module=game_black_jack&ret=$ret");
				addnav("Other Games","$ret?op=oldman");
				addnav("Return to the Main Room","$ret?op=tavern");
			}
		}
	}
	else{
		output("`3The old man reaches out with his stick and pokes your coin purse.  \"`!Empty?!?!  How can you bet with no money??`3\" he shouts.  With that, he turns back to his carts, apparently having already forgotten his anger.");
		addnav("Return to the Main Room","$ret?op=tavern");
	}
	$session['user']['specialmisc']=serialize($cards);
	page_footer();
}
?>
