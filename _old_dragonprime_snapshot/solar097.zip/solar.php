<?php
/*  Solar Eclipse
	LoGD Forest Event for version 097
	Written by Robert of Maddnet
	INSTALL - EASY! - just drop into your Special Folder

*/
if (!isset($session)) exit(); 
if ($HTTP_GET_VARS[op]==""){ 
    output("`n`n`2 You come to notice a darkness in the middle of the day. "); 
    output("`n`n`2 You look up towards the SUN and notice there is a Solar Eclipse occurring at this very moment. "); 
    output("`n`n`& What will you do? "); 
    addnav("Solar Eclipse"); 
    addnav("(W) Watch the event","forest.php?op=watch"); 
    addnav("(C) Continue On!","forest.php?op=dont"); 
    $session[user][specialinc]="solar.php"; 
}else if ($HTTP_GET_VARS[op]=="watch"){
	$session[user][specialinc]="";
  if ($session[user][turns]>=3){ 
      output("`n`n`2 You watch as the `&MOON `2passes the `^SUN`2. `n`n");
        switch(e_rand(1,10)){ 
        case 1: 
           output("The event is beautiful and you will always remember this day. ");
           output("`n`n You feel a surge of energy pass through your veins. ");
           output("`n`n You gain 1 turn. ");
           $session[user][turns]++;
           break; 
        case 2: case 3: case 4:
           output("After you stare at this marvelous event, you find you are temporarily blinded."); 
           output("`n`n You lose 2 turns waiting to regain your eyesight. "); 
           $session[user][turns]-=2;
           break;
        case 5: case 6: case 7: case 8: case 9:
           output("You find this event to be forever ingrained into your memory.");
           output("`n`n You feel very tired and lose 1 turn. ");
           $session[user][turns]--;
           break; 
        case 10:
           output("After watching at this marvelous event, you find you possess great inner strength. ");
           $session[user][hitpoints]++;
           break; 
        } 
    }else{ 
      output("`n`n`2You watch as the `&MOON `2passes the `^SUN`2.`n`n "); 
      output("The event is beautiful and you will always remember this day. ");
    } 
}else{ 
  output("`n`n`2Not wanting to waste your time watching some silly solar event, you continue on your way. ");
  output("`n`n The path gets darker and darker, you stumble and fall ....maybe it was fate? ");
  $session[user][hitpoints]-=5;
} 
?>