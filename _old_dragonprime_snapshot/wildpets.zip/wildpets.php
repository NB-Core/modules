<?php
/**************
Name: Wild Pets
Author: Eth - ethstavern(at)gmail(dot)com 
Version: 2.0
Release Date: 02-24-2005
Rerelease Date: 12-24-2005 (for 1.0.x)
About: An Add-on for the Petshop pack. Find a random wild animal in the
	   forest and have a chance to make it a pet.    
Translation compatible.
*****************/
require_once("lib/villagenav.php");
require_once("lib/showform.php");
function wildpets_getmoduleinfo(){
	$info = array(
		"name"=>"Wild Pets",
		"version"=>"2.1",
		"author"=>"Eth",
		"category"=>"Pets",
		"download"=>"http://dragonprime.net/users/Eth/wildpets.zip",
		"vertxtloc"=>"http://dragonprime.net/users/Eth/",
		"requires"=>array(
			"petshop"=>"Pet Editor v3.8|By Eth",
		),
		"settings"=>array(
			"Wild Pets - Settings,title",
			"petchance"=>"Chance of finding a wild pet?,range,0,100,5|20"						
		),				
		"prefs"=>array(	
			"petid"=>"ID of pet found,int|0"				
		),
	);
	return $info;
}
function wildpets_install(){
	//cheap way to not have the default pets reinstalled
	//everytime this script is changed	
	if (is_module_active("wildpets")){		
		
	}else{
		$sql = array(	
			"INSERT INTO ".db_prefix("pets")." VALUES (0, '`QFox', 2, 300, 0, 50, 1, 0, 0, 'A small, wily fox which makes it\'s home in the deep, dark forest.', 'With a small yawn, the fox stretches and is ready for the day\'s adventure.', 'Your fox looks about the village with much apprehension', 'Your fox decides to take a nap among the bushes.', 'Tail between it\'s legs, your fox retreats to the underbrush.',0,0,0,0,0);",
			"INSERT INTO ".db_prefix("pets")." VALUES (0, '`^Golden Fox', 2, 550, 1, 75, 2, 1, 0, 'A small fox with a bright golden coat common to many forests.', 'The little golden fox yawns as the new day dawns.', 'Weary of the villagers, your fox sticks close to you.', 'Your pet fox plays happily among the bushes and flowers.', 'Frightened, your fox retreats to the forest as the battle begins.',0,0,0,0,0);",
			"INSERT INTO ".db_prefix("pets")." VALUES (0, '`7Wild Ferret', 2, 400, 0, 80, 1, 0, 0, 'A small gray ferret popular as pets among the younger crowd.', 'Emerging from your backpack with a yawn, your little ferret is ready for the day\'s travels.', 'Your ferret hides in your pack as you wander about the village.', 'Your ferret goes chasing after a grasshopper as you stroll through the gardens.', 'Your ferret buries itself in your backpack as the battle begins.',0,0,0,0,0);",
			"INSERT INTO ".db_prefix("pets")." VALUES (0, '`3Feral Cat', 2, 300, 0, 50, 1, 0, 1, 'A wild cat common in many alleyways and forests.', 'Your cat hacks up a hairball and brushes up against your leg as the new day starts.', 'Your wild cat hisses as villagers walk past.', 'Your little cat hunts for mice among the flower patches.', 'Back arched and claws out, your wild cat prepares for battle.',1,1,5,9,10);",
			"INSERT INTO ".db_prefix("pets")." VALUES (0, '`&Wild Dog', 2, 450, 1, 85, 1, 2, 1, 'A wild mutt who\'s like are usually found wandering in packs in the forest.', 'With an excited bark, your wild dog is ready for the new day\'s adventures.', 'Your wild dog barks at the passing villagers.', 'Your wild dog curls up for a nap under a bush as you stroll through the gardens.', 'Your wild dog growls as the enemy draws closer.',1,1,8,11,12);",
			"INSERT INTO ".db_prefix("pets")." VALUES (0, '`7Wombat', 2, 900, 2, 112, 2, 4, 0, 'A strange marsupial found in lands far from this one.', 'Your wombat greets the new day with a yawn.', 'Villagers stare quizically at your wombat as you stroll through.', 'Your pet wombat decides to take a nap among the flower patches.', 'Your wombat heads for the bushes as the battle begins.',0,0,0,0,0);",
			"INSERT INTO ".db_prefix("pets")." VALUES (0, '`&White Rabbit', 2, 200, 0, 90, 1, 3, 0, 'A small rabbit with a soft white coat. Popular among children.', 'Your rabbit hops around your feet as you prepare for the new day at hand.', 'Fearful of the villagers, your rabbit hides in your backpack.', 'Your pet rabbit hops among the flower patches, searching for a meal.', 'With a squeal, your rabbit hides among the bushes as the enemy draws closer.',0,0,0,0,0);",
		);	
		foreach ($sql as $statement) {
		db_query($statement);	
		}	
	}
	$chance = get_module_setting("petchance");			
	module_addeventhook("forest", "return $chance;");	
	return true;
}
function wildpets_uninstall(){	
	return true;
}
function wildpets_dohook($hookname,$args){	
}
function wildpets_runevent($type){
	global $session;
	$op = httpget('op');
	if ($type == "forest") $from = "forest.php?";			
	$session['user']['specialinc'] = "module:wildpets";	
	//some sql goodness
	$userdk = $session['user']['dragonkills'];
	$sql = "SELECT * FROM " . db_prefix("pets") . " WHERE petbreed=2 and petdk<='$userdk' ORDER BY rand(".e_rand().") LIMIT 1";
	$result = db_query($sql);
	$row = db_fetch_assoc($result);
	//convert to lower case for display reasons
	$animal = strtolower($row['petname']);	
	$anid = $row['petid'];
	//the ever important pet flag
	$pet = get_module_pref("petname","petshop");
	$pet = strtolower($pet);
	$haspet = get_module_pref("haspet","petshop");
	output("`n");	
	switch($type){
		case forest:
		if ($op=="" || $op=="search") {
			//let's add some random places to find the pet. 
			switch (e_rand(1,4)){
				case 1:
				output("`2While venturing through the forest, you stumble upon a small clearing.");
				output(" `2You see a `^%s `2resting in the shade of a towering oak tree!`n`n", $animal);				
				break;
				case 2:
				output("`2Stopping for a moment at the shore of a river to refill your canteen,"); 
				output(" `2you happen to notice a %s `2nearby grabbing a drink from the chilled waters.`n`n", $animal);				
				break;
				case 3:
				output("`2Taking a moment to rest your sore feet, you take a seat upon the trunk of a fallen tree.");
				output(" `2Looking ahead a ways, you happen to catch sight of a %s `2staring back at you quizically.`n`n", $animal);				
				break;
				case 4:
				output("`2While following a trail that leads deeper into the forest, a %s `2wanders across your path.", $animal);
				output(" `2It stands there silently, staring into your eyes.`n`n");				
				break;
			}
			//now, let's store the animal in the user prefs for THIS module
			set_module_pref("petid",$anid);
			addnav("Approach Animal",$from."op=choice&what=approach");
			addnav("Leave Alone",$from."op=choice&what=leavealone");
			
		}else if ($op=="choice"){
			//make a quick sql call
			$id = get_module_pref("petid");
			$sql = "SELECT * FROM " . db_prefix("pets") . " WHERE petid='$id'";
			$result = db_query($sql);
			$row = db_fetch_assoc($result);
			$animal = strtolower($row['petname']);
			switch (httpget('what')){
				case "approach":
				//if user has a pet, wild animal runs away
				if ($haspet == 1){
					output("`2Weary of your %s`2, the %s `2takes off running into the forest.", $pet,$animal);
					output(" `2You know giving chase would be futile, so you return to your journeys.`n`n");
					$session['user']['specialinc'] = "";
				//otherwise, random goodness ensues
				}else{
					//will the animal accept the user, or run away...or worse?
					switch(e_rand(1,4)){
						case 1: 
						case 2:
						output("`2The %s `2stares at you for a moment, and allows you to approach.", $animal);
						output(" `2It seems quite tame, and would make for a nice pet you think.`n`n");
						output("`2Would you like to keep the %s`2?", $animal);
						addnav("Yes",$from."op=choice&what=name");
						addnav("No",$from."op=choice&what=leavealone");
						break;
						case 3:
						output("`2Suddenly, the %s `2grows frightened of you and takes off running into the forest.", $animal);
						output(" `2You give chase for a moment, but realize it is futile as the animal is long gone by now.`n`n");
						output("`2With a brief sigh, you return to your travels.`n`n");
						$session['user']['specialinc'] = "";
						break;
						case 4:
						output("`2Approaching closer, you extend your hand towards the %s`2.",$animal);
						output(" However, the %s `2suddenly grows fearful and snaps at your hand and goes running off into the forest!", $animal);
						output(" `2As you nurse the wound on your wrist, you curse the animal.`n`n");
						$bite = round($session['user']['hitpoints']*.15);
							//just in case the user is down to their last hitpoint
							if ($session['user']['hitpoints']<2){
								$session['user']['hitpoints']=1;
								//otherwise, take a quarter of their hitpoints away!
								//just be glad I don't give you rabies too.
								}else{
								$session['user']['hitpoints']-=$bite;
							}
						$session['user']['specialinc'] = "";
						break;
					}				
				}	
				break;
				case "leavealone":
				//you don't want the pet? Aww, shucks
				output("`2Deciding to leave the wild animal alone, you return to your travels.");
				output(" `2The %s `2stares at you a moment before disappearing into the forest.`n`n", $animal);
				$session['user']['specialinc'] = "";
				break;
				case "name":
				//the pet is yours now, let's set it up in petshop.php
				set_module_pref("haspet",1,"petshop");
				set_module_pref("petid",$id,"petshop");
				set_module_pref("petname",$row['petname'],"petshop");													
				$session['user']['charm']+=$row['petcharm'];	
				//
				set_module_pref("petattack",$row['petattack'],"petshop");
				set_module_pref("attacktype",$row['attacktype'],"petshop");
				set_module_pref("mindamage",$row['mindamage'],"petshop");
				set_module_pref("maxdamage",$row['maxdamage'],"petshop");
				set_module_pref("petturns",$row['petturns'],"petshop");		
				//now, let's give him/her a name
				output("`2Looking into the %s`2's eyes, you try to think of a good name for it.`n`n",$animal);
				output("`3Choose a name and gender.`n`n");
				$petinfo = array(
				"petgender"=>"Pet Gender,enum,0,Male,1,Female",	
				"petname"=>"Pet Name"
				);
				rawoutput("<form action='".$from."op=choice&what=done' method='POST'>");
				showform($petinfo,$row);
				addnav("", $from . "op=choice&what=done");
				rawoutput("</form>");
				//in case the user is lazy...	
				addnav("Skip",$from."op=choice&what=done");			
				break;
				case "done":
				//set name and gender, and we're done!
				$gender = httppost('petgender');
				$name = httppost('petname');
				if ($name == "") { $name = "Socks"; }
				$petgender = translate_inline($gender?"her":"his");
				$petgender2 = translate_inline($gender?"her":"him");
				set_module_pref("customname", $name,"petshop");
				set_module_pref("petgender", $gender,"petshop");
				output("`2You decide to name the %s `2%s.", $animal,$name);
				output(" `2Seeming content with %s name, you and your new pet continue on your journey.`n`n",$petgender);
				//lets tell folks about your find, too
				addnews("%s `2discovered a `@%s `2in the forest today and kept %s as a pet!", $session['user']['name'],$animal,$petgender2);
				$session['user']['specialinc'] = "";
				break;
			}
		}
		break;
	}

}
function wildpets_run(){	
}
?>