****************************************************************
Name: Wild Pets
Author: Eth - ethstavern(at)gmail(dot)com 
Version: 2.0
Release Date: 12-24-2005
About: Readme file for wildpets.zip
Files: wildpets.php
Petshop v3.0 is Required for this to work.
***************************************************************

To install, drop into your modules directory and activate 
via the Modules Manager. 
