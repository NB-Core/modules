Race - Arachnus

Version 1.01
Written by RPGSL
Code snippets from Kendaer

Download: http://rpdragon.com/lotgd/racearachnus.zip
Mirror: http://rpgsl.com/lotgd/racearachnus.zip

Game: http://rpdragon.com/


Installation

1) Copy racearachnus.php into your LotGD modules folder
2) Log in to LotGD with your admin account
3) Enter the Superuser Grotto
4) Click Manage Modules
5) Install racearachnus.php (Race- Arachnus)
6) Configure settings and save
7) Activate


Questions/Comments?

alex@rpgsl.com


Visit www.rpgsl.com today for your RPG needs.