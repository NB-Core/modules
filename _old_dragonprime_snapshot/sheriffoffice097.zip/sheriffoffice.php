<? 
/***************************************
Sheriff's Office
Written by Robert for Maddnet.com LoGD
Belongs with Castle Gwen
22Feb2004
****************************************/
require_once "common.php"; 
checkday();
if ($session[user][drunkenness]>19) {
    page_header("Sheriff's Office");
	output("`n`n`2You enter the `3Sheriff's Office`2, he see's you in your current state of Drunkeness.");
	output(" `nand says, `n`%Don't you think you've had too much to drink today?");
	output(" `nYou leave me no choice but to put ye in Jail to sleep it off");
	output(" `n`2After sleeping it off - you find you are completely refeshed and very sober");
	addnav("Leave");
	addnav("(C) Return to Castle" ,"castlegwen.php");
	$session[user][hitpoints] = $session[user][maxhitpoints];
	$session[user][drunkenness]=0;
	$session[user][turns]--;
	}

else{

addnav("Remove Bounty"); 
addnav("(S) Service - 1 gem","sheriffoffice.php?op=bounty"); 
addnav(""); 
addnav("Leave"); 
addnav("(C) Return to Castle","castlegwen.php");
page_header("Sheriff's Office");  
if ($HTTP_GET_VARS[op]==""){
output("`c<font size='+1'>`3Sheriff's Office</font>`c`n",true);
output(" `n`2You enter the `3Sheriff's Office`2, the place is quite busy.`n"); 
output(" In the back you see a `3Deputy `2having a hard time subduing a drunken Troll.`n"); 
output(" In the Jail Cells you can see several `6Dwarfs`2, and a `3Warrior `2sleeping off a drunk.`n"); 
output(" Behind the counter is the `3Sheriff`2, he see's you're sober and has no worries about you.`n"); 
output(" He asks if you would like to have a bounty removed from your head.`n"); 
output(" If not, then please be on your way, as he is too busy to have visitors just drop in.`n"); 
	if ($session[user][bounty]>0){
		output("`n\"`3Well, it be lookin like ye have `^".$session[user][bounty]." gold`3 on yer head currently. Ye might wanna be watchin yourself.\"");
	}else{
		output("`n`3Ye don't have no bounty on ya.  I suggest ye be keepin' it that way");
	}
}else if ($_GET[op]=="bounty"){ 
if ($session[user][gems] > 1){ 
     
     $session[user][turns]--; 
     $session[user][gems]--; 
     output("`n`n`2The `3Sheriff `2gives you a form to fill out and takes 1 of your gems.`n"); 
     output("You fill out the form, hand it back to the `3Sheriff `2and he assures you the Bounty will be removed."); 
     addnews($session[user][name]." `2gets Bounty removed at the `3Sheriff's Office`2!");
     $session[user][bounty]=0;
     debuglog("gave 1 gem to Sheriff to remove bounty");
 } else { 
             output("`n`n`2The `3Sheriff `2laughs at your imaginary Gem - 'go get some gems,' he says!"); 
} 
}
}
page_footer();
?>