//--------------------------------------------------------------------------------------------------------
//| Written by:  Auron 
//| 
//| Village.php:**
//| **Find:**
//| output("`@New Day in: `^".date("G\\h, i\\m, s\\s \\(\\r\\e\\a\\l\\ \\t\\i\\m\\e\\)",strtotime("1970-01-01 //| 00:00:00 + $realsecstotomorrow seconds"))."`0");
//|
//| **Add Under:**
//| if ($session[user][questscomp]==0 && $session[user][qact]<1){
//| output("`4A Young Man walks up to you and says Would ye like to do me favor? There will be a reward if you //| complete my task.`n`0[<a href='quests.php?op=q1'>`\$Accept`0</a>]/[<a
//| href='quests.php?op=deny'>`\$Decline`0</a>]",true);
//| addnav("","quests.php?op=q1");
//| addnav("","quests.php?op=deny");
//|
//| **Find:**
//| The top addnav in your village
//| 
//| **Add Under:**
//| if ($session[user][qid]==1 && $session[user][quests]==1 && $session[user][qact]==4){
//| addnav("Quest #1: Act 4");
//| addnav("Give Auron His Book","quests.php?op=qa4");}**
//| 
//| 
//| **Inn.php:**
//| **Find:**
//| addnav("Things to do");
//| 
//| **Add Above:**
//| if ($session[user][qid]==1 && $session[user][quests]==1 && $session[user][qact]==1){
//| addnav("`2Quest #1: Act 1`0");
//| addnav("Search the Table","quests.php?op=qa1");}
//| if ($session[user][qid]==1 && $session[user][quests]==1 && $session[user][qact]==3){
//| addnav("`2Quest #1: Act 3`0");
//| addnav("Give Kira the Heirloom","quests.php?op=qa3");}**
//| 
//| **Gypsy.php:**
//| **Find:**
//| addnav("Pay to talk to the dead (Costs Gold)","gypsy.php?op=pay");
//| 
//| **Add Above:**
//| if ($session[user][qid]==1 && $session[user][quests]==1 && $session[user][qact]==2){
//| addnav("Quest #1: Act 2");
//| addnav("Search the Ground","quests.php?op=qa2");}
//| addnav("Things to Do");**
//|
//|
//|
//|
//|
//|
//|
//|
//| Database:
//| Add to Accounts:
//|   quests  int(11)  UNSIGNED No  0
//|   qid  int(11)  UNSIGNED No  0                
//|   qinfo  varchar(225)   No                  
//|   questscomp  int(11)  UNSIGNED No  0                
//|   qact  int(11)  UNSIGNED No  0    
//|
//--------------------------------------------------------------------------------------------------------