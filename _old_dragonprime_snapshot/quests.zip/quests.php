<?php
require_once "common.php";
page_header("Quests");	
$name=$session[user][name];
switch($HTTP_GET_VARS[op])
	{
case "":
	output("No one knows how you got here");
addnav("Back to Village","village.php");
break;

case "deny":
	output("Well if you decide to try a quest later you can!");
addnav("Back to Village","village.php");
break;

case "q1":
	output("`4The man is Auron! Thank you young sire! Your help will be much appreciated!");
$session[user][qid]+=1;
$session[user][quests]+=1;
$session[user][qact]+=1;
$session[user][qinfo]="You must help Auron find his PhP for Dummies book! Try checking the Inn and see if you can find anything.";
addnav("Back to the Village","village.php");
break;

case "yqa1":
	output("`#You see Auron's Book!! You go to grab it but a hand slaps you!");
output("A lady named Kira tells you that she found that book and she won't give it up unless you help her.");
output("After talking to her you find out that you need to find her family heirloom!");
output("She thinks that she may have dropped it somewhere in the market...");
$session[user][qinfo]="Find Kira's Heirloom!! Check the Market!";
$session[user][qact]+=1;
addnav("Back to the Village","village.php");
break;

case "yqa2":
	output("`@You search the ground looking for Kira's Heirloom....");
$Auron = e_rand (1,3);
      switch($Auron){
		  case 1:
			  output("You found nothing...");
		  break;
		  case 2:
			  output("You found nothing...");
		  break;
		  case 3:
			  output("You found the heirloom!!");
		  	  $session[user][qinfo]="Return the Heirloom to Kira!";
	          $session[user][qact]+=1;
		  break;
	  }
	  addnav("Return to the Village","village.php");
	  break;
	
case "yqa3":
	output("`3You hand Kira the heirloom and in return she gives you Auron's PhP for Dummies Book!!");
$session[user][qinfo]="Give Auron his PhP for Dummies Book! He can be found in the Village!";
$session[user][qact]+=1;
addnav("Back to the Village","village.php");
break;

case "yqa4":
	output("`\$You give Auron his PhP for Dummies Book back and he thanks you a lot! He also gives you 3 Donation Dollars!");
$session[user][donationdollars]+=3;
$session[user][questscomp]+=1;
$session[user][qact]-=4;
$session[user][quests]-=1;
$session[user][qid]-=1;
$session[user][qinfo]="";
addnews("$name Completed Auron's Quest!!");
addnav("Back to Village","village.php");

}
page_footer();	
?>