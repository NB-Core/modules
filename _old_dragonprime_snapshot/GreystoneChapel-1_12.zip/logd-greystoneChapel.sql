# Table structure for table `marriage`
# Used with the Greystone Chapel player marriage mod
#
CREATE TABLE marriage (
  id tinyint(4) NOT NULL auto_increment,
  suitor tinyint(4) NOT NULL default '0',
  proposed tinyint(4) NOT NULL default '0',
  date datetime NOT NULL default '0000-00-00 00:00:00',
  PRIMARY KEY  (id)
) TYPE=MyISAM;