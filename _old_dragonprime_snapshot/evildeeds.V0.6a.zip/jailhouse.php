<?
/*****************************************/
/* Wondering Sheriff                     */
/* -----------------                     */
/* Matt Bowman (www.mattsshack.com)      */
/* Filename jailhouse.php                */
/* Ver. 0.6 <-NOTICE NOT 1.0		 */
/* Read The readme.txt first!		 */
/*					 */
/* Jailhouse additions by Sixf00t4	 */
/* http://Sixf00t4.com/dragon		 */
/* bail out friends, bail yourself out,  */
/* soup, suicide			 */
/*****************************************/

require_once "common.php";
checkday();
addcommentary();
page_header ("Jail House");
if ($HTTP_GET_VARS[op]==""){

	$badguy = array(
		"creaturename"=>"`@Jail House Sheriff`0"
		,"creaturelevel"=>0
		,"creatureweapon"=>"Big Stick"
		,"creatureattack"=>1
		,"creaturedefense"=>2
		,"creaturehealth"=>2
	,"diddamage"=>0);
	$userlevel=$session['user']['level'];
	$userattack=$session['user']['attack'];
	$userhealth=$session['user']['hitpoints']*6;
	$userdefense=$session['user']['defense'];
	$badguy[creaturelevel]+=$userlevel;
	$badguy[creatureattack]+=$userattack;
	$badguy[creaturehealth]=$userhealth;
	$badguy[creaturedefense]+=$userdefense;
	$session[user][badguy]=createstring($badguy);

if ($session['user']['jail'] >=1 or $HTTP_GET_VARS['op'] == "newday"){
	    if ($HTTP_GET_VARS[op] == "newday"){
	        if ($session[user][jail] == 1) output("You wake up in Jail.`n");
	        if ($session[user][evildeeds] < 10){
	        output("The Constable says \"I think you have learned your lesson, I will let you go, ");
	        output("however I will be keeping my eye on you.  You had better straighten yourself up!\"`n");
		addnav("Continue","village.php");
	        $name=$session[user][name];
	        addnews("`1$name `1was released from jail today!");
	        }

	        else{
	    		output("`7You are in your jail cell, there is nothing to do.`n`n");
	    		viewcommentary("jail","Wine about being in Jail",20,"wines");
	    		addnav("Twiddle your thumbs","jailhouse.php?op=twiddle");
	    		addnav("Pay Bond","jailhouse.php?op=paybond");
	   		addnav("Attempt suicide","jailhouse.php?op=suicide");
	    		addnav("Ask for some soup - 1 gem","jailhouse.php?op=soup");
	    		addnav("Go to Sleep","login.php?op=logout",true);
	    		if($session[user][jail]==0){
	    	   	addnav("Grab your things and go","jailhouse.php");
		    }

	    if($session[user][superuser]>2){addnav("newday","newday.php");}
	    //if ($HTTP_GET_VARS[op] == "twiddle") output("`n`7You twiddle your thumbs for a while.`n");
	}
	    }else{
	    		output("`7You are in your jail cell, there is nothing to do.`n`n");
	    		viewcommentary("jail","Wine about being in Jail",20,"wines");
	    		addnav("Twiddle your thumbs","jailhouse.php?op=twiddle");
	    		addnav("Go to Sleep","login.php?op=logout",true);
	    		addnav("Pay Bond","jailhouse.php?op=paybond");
			addnav("Attempt suicide","jailhouse.php?op=suicide");
	    		addnav("Ask for some soup - 1 gem","jailhouse.php?op=soup");
	    	    	if($session[user][superuser]>2){addnav("newday","newday.php");}
	   // if ($HTTP_GET_VARS[op] == "twiddle") output("`n`7You twiddle your thumbs for a while.`n");
}
	}

if ($session['user']['jail'] <= 0){
	$sql = "SELECT count(acctid) AS c FROM accounts WHERE jail=1";
	$result = db_query($sql);
	$row = db_fetch_assoc($result);
	$jailedplayers = $row['c'];

	output("`n`3`c`bJail House`b`c `n `n");
	output(" `2You wonder into the Jail House and spot The Sheriff sitting at his desk.`n");
	output(" `2As you look around you notice a rusty old jail cell with $jailedplayers adventure(s) in it.`n");
	output("`n");
	output(" Players In Jail Cell:`n");
	output("<table border=0 cellpadding=2 cellspacing=1 bgcolor='#999999'>",true);
	output("<tr class='trhead'><td><b>Prisoner</b></td><td><b>Level</b></td><td><b>Bail Amount</b></td>",true);
		
	$sql = "SELECT * FROM accounts WHERE jail=1";
	$result = db_query($sql);
	for ($i=0;$i<db_num_rows($result);$i++){
        	$row = db_fetch_assoc($result);
		$injail = $row[name];
		$bailamount = $row['level'] *3000;
		$level = $row[level];
		
		output("<tr class='".($i%2?"trdark":"trlight")."'><td>",true);	
		output("`&$injail`n"); 
		output("</td><td>",true);
		output("`&$level`n");
		output("</td><td>",true);
		output("`&$bailamount`n");	
		output("</td>",true);
		
		}
	output("</table>",true);
	
	addnav("Sheriff");
	addnav("Bail out a friend","jailhouse.php?op=bailafriend");
	addnav("Talk to Sheriff","jailhouse.php?op=talk");
	addnav("Return to Village","village.php");
	output("`n`n");
    	viewcommentary("jail","Taunt those in Jail",20,"taunts");
}}

if ($HTTP_GET_VARS[op]=="paybond"){
$bondtotal = $session[user][dragonkills]*3000;
output("The Sheriff says you can post bail for `^$bondtotal`n ");
if ($session[user][gold]>=$bondtotal){
addnav("Pay it","jailhouse.php?op=postbail");
}addnav("Forget it","jailhouse.php");
}

if ($HTTP_GET_VARS[op]=="postbail"){
$bondtotal = $session[user][dragonkills]*3000;
$session[user][gold]-=$bondtotal;
output("The Sheriff let's you out of the cell.  He isn't happy about it.  You're on a steady watch from now on.");
$session['user']['jail']=0;
$session['user']['evildeeds']=9;
addnav("Continue","village.php");
}

if ($HTTP_GET_VARS[op]=="soup"){
if ($session[user][gems]==0){
output("Since you do not have a gem to give to the guard, he sits the warm, hearty, full bowl of your favorite soup, just out of reach from your cell.`n");
addnav("Back to your cell","jailhouse.php");
}
else{
output("The guard takes your gem, and hands you a warm bowl of soup.  You feel much better.`n");
addnav("Back to your cell","jailhouse.php");
$session[user][gems]--;
$session[user][hitpoints]+=5;
}}

if ($HTTP_GET_VARS[op]=="suicide"){
if($session[user][suicideattempts] >= 1){
output("You have tried to kill yourself once already today.  You must really be desperate.`n");
            $name=$session[user][name];
            addnews("$name `7is suicidal!");
            $oldname=$session[user][name];
            list($title, $name) = split('[ ]',$oldname);
            $title="Suicidal";
            $newname= array($title,$name);
            $session[user][title]="Suicidal";
            $session[user][name]=implode(" ",$newname);
	    addnav("Back to your cell","jailhouse.php");
	    }
	    else{
output("Climbing on a small stool, you take your sheets and tie them around a pipe in the ceiling.  You tie the sheet like a noose around you neck and kick out the stool from beneath you.`n");
switch(e_rand(1,10)){
case 1:
case 2:
output("The pipe was not strong enough to support your weight.  It breaks in half soaking you in water.  The guard rushes over and does not look very happy.  You are going to have to pay to repair that.`n");
addnav("Back to your cell","jailhouse.php");
$session[user][gold]=0;
$session[user][goldinbank]=0;
$session[user][suicideattempts]=1;
break;
case 3:
case 4:
case 5:
output("Just as you kick out the chair, the guard walks by and is quick to save you from death.  Is this life really so cruel?`n");
addnav("Back to your cell","jailhouse.php");
$session[user][suicideattempts]=1;
break;
case 6:
output("After about 2 minutes of not being able to breath, you heart ceases to pump.  Congratulations.  You are now dead.`n");
            $name=$session[user][name];
            addnews("$name `7committed suicide in the jail!");
	    addnav("To the shades","shades.php");
$session[user][hitpoints]=0;
$session[user][alive]=0;
$session[user][suicideattempts]=1;
break;
	 
case 7:
case 8:
case 9:
case 10:
		output("`3`c`bOuch!`b`c  `n");
output("`2You didn't tie that rope tight enough.  You fall right to the ground and bust your head off the toilet.`n");
$session[user][hitpoints]-=5;
$session[user][suicideattempts]=1;
addnav("Back to cell","jailhouse.php");
break;  

}}}


if($_GET[op]=="bailafriend"){
	output("`n`3`c`bJail House`b`c `n `n");
	output("`n`n`bThe Sheriff`b`7 pulls out his log book to show you who he has currently in a cell.`n`n");
	output("<table border=0 cellpadding=2 cellspacing=1 bgcolor='#999999'>",true);
	output("<tr class='trhead'><td><b>Prisoner</b></td><td><b>Level</b></td><td><b>Bail Amount</b></td><td><b>Action</b></td>",true);
	
	$sql="SELECT acctid, name, jail, login, level FROM accounts WHERE jail = 1 ORDER BY accounts.level DESC";
	$result = db_query($sql) or die(db_error(LINK));
	for ($i=0;$i<db_num_rows($result);$i++){
		$row = db_fetch_assoc($result);
		$injail = $row[name];
		$bailamount = $row['level'] *3000;
		$level = $row[level];
	
		output("<tr class='".($i%2?"trdark":"trlight")."'><td>",true);	
		output("<a href=\"mail.php?op=write&to=".rawurlencode($row['login'])."\" target=\"_blank\" onClick=\"".popup("mail.php?op=write&to=".rawurlencode($row['login'])."").";return false;\"><img src='images/newscroll.GIF' width='16' height='16' alt='Write Mail' border='0'></a>",true); 
		output("`&$injail`n");
		output("</td><td>",true);
		output("`&$level`n");
		output("</td><td>",true);
		output("`&$bailamount`n");
		output("</td><td>",true);
		output("<a href='jailhouse.php?op=bailout&player=".rawurlencode($row[acctid])."'>Bail Out</a>",true);	
		output("</td>",true);
		addnav("","jailhouse.php?op=bailout&player=".rawurlencode($row[acctid])."");
	}
	output("</table>",true);
	addnav("Back to Jail house","jailhouse.php");
}

if($_GET[op]=="viewbounty"){
	output("`n`3`c`bJail House`b`c `n `n");
	output("`n`n`bThe Sheriff`b`7 pulls out his log book to show you who currently has a bounty on thier head.`n`n");
	output("<table border=0 cellpadding=2 cellspacing=1 bgcolor='#999999'>",true);
	output("<tr class='trhead'><td><b>Name</b></td><td><b>Level</b></td><td><b>Dragon Kills</b></td><td><b>Bounty</b></td>",true);
	
	$sql="SELECT acctid, name, bounty, dragonkills, login, level FROM accounts WHERE bounty >= 1 ORDER BY accounts.level DESC";
	$result = db_query($sql) or die(db_error(LINK));
	for ($i=0;$i<db_num_rows($result);$i++){
		$row = db_fetch_assoc($result);
		$name = $row[name];
		$level = $row[level];
		$dragonkills = $row[dragonkills];
		$bounty = $row[bounty];
	
		output("<tr class='".($i%2?"trdark":"trlight")."'><td>",true);	
		output("<a href=\"mail.php?op=write&to=".rawurlencode($row['login'])."\" target=\"_blank\" onClick=\"".popup("mail.php?op=write&to=".rawurlencode($row['login'])."").";return false;\"><img src='images/newscroll.GIF' width='16' height='16' alt='Write Mail' border='0'></a>",true); 
		output("`&$name`n");
		output("</td><td>",true);
		output("`&$level`n");
		output("</td><td>",true);
		output("`&$dragonkills`n");
		output("</td><td>",true);
		output("`&$bounty`n");
		output("</td>",true);
		addnav("","jailhouse.php?op=bailout&player=".rawurlencode($row[acctid])."");
	}
	output("</table>",true);
	addnav("Back to Jail house","jailhouse.php");
}



if($_GET[op]=="bailout"){
	$player=$_GET[player];
	if($player != "")
	{
		$sql="SELECT acctid, name, jail, login, level FROM accounts WHERE acctid =".$player;
		$result = db_query($sql) or die(db_error(LINK));
		$row = db_fetch_assoc($result);

		$cost = $row['level'] *3000;

		if($_GET[action] == "yes"){
			if($session[user][gold] >= $cost){
				output("`n`n`7You decide to help ".$row['name']."`7 get out of jail.   So you hand over the ".$cost." and `4`bThe Sheriff`b`7 yells to the back for the guard to bring up ".$row['name'].".",true);
addnav("Back to Jail house","jailhouse.php");

				$sql="UPDATE accounts SET jail = 0 WHERE acctid = ".$row['acctid'];
				db_query($sql) or die(db_error(LINK));

				$session[user][gold] = $session[user][gold] - $cost;
 $name=$session[user][name];
				systemmail($HTTP_GET_VARS[userid],"`^lucky you!`0",$session[user][name]." has bailed you out of jail!",$session[user]['acctid']);
				addnews("$name has bailed  ".$row['name']." out of jail!");
			}else{
				output("`n`n`7You decide to help ".$row['name']."`7, but `4`bThe Sheriff`b`7 tells you that you don't have enough money.  ".$row['name']." will have to rot in their cell until the next day.",true);
			}
		}else if($_GET[action] == "no"){
			output("`n`n`7You decide that it's not worth it to get ".$row['name']." out of jail.   So you thank `4`bThe Seriff`b`7 and leave his office.",true);
addnav("Back to Jail house","jailhouse.php");
		}else{


			output("`n`n`4`bThe Seriff`b`7 tells you that it will take about ".$cost." to get ".$row['name']." out of jail.`n`n   Would you like to bailout ".$row['name']."?`n`n",true);
addnav("Back to Jail house","jailhouse.php");
			output("<a href=\"jailhouse.php?op=bailout&player=".$row['acctid']."&action=yes\">`^Yes</a> `^/ <a href=\"jailhouse.php?op=bailout&player=".$row['acctid']."&action=no\">`^No</a>", true);
			addnav("", "jailhouse.php?op=bailout&player=".$row['acctid']."&action=yes");
			addnav("", "jailhouse.php?op=bailout&player=".$row['acctid']."&action=no");
		}
	}
}

if ($HTTP_GET_VARS[op]=="talk"){
	output(" ");
	output(" `2You walk over to The Sheriff's desk and try to start up a conversation.`n");
	if ($session['user']['robbank'] >= 1){
	$underarrest=1;
	output(" `2After a few moments The Sheriff recognizes you from a wanted poster for robbing the bank.`n");
	output(" `2He draws his sword and starts to walk toward you.`n");
	output(" ");
	output(" `2What do you do?`n");
	addnav("Sheriff");
	addnav("Flee","jailhouse.php?op=flee");
	//addnav("Fight","jailhouse.php?op=fight");
	addnav("Give Up","jailhouse.php?op=giveup");

}
	if ($session['user']['evildeeds'] > 10){
	if ($underarrest==1){
	//Do nothing
		} else {
			$underarrest=1;
			output(" ");
			output(" `2After a few moments The Sheriff recognizes you from complains in the village.`n");
			output(" `2He draws his sword and starts to walk toward you.`n");
			output(" ");
			output(" `2What do you do?`n");
			addnav("Sheriff");
			addnav("Flee","jailhouse.php?op=flee");
			//addnav("Fight","jailhouse.php?op=fight");
			addnav("Give Up","jailhouse.php?op=giveup");
		}
}

	if ($underarrest==1){
	//Do nothing
		} else {
			output(" ");
			output("The sherrif looks busy studying some new wanted poseters he just got in. He looks up for a moment, smiles, and goes back to his work.");
			addnav("Bail out a friend","jailhouse.php?op=bailafriend");
			addnav("View Bounties","jailhouse.php?op=viewbounty");
			addnav("Back to Jail House","jailhouse.php");
			addnav("Return to Village","village.php");
		}
}

if ($HTTP_GET_VARS[op]=="giveup"){
	output("`n`3`c`bJail House`b`c `n `n");
	output(" ");
	output("You know you have been caught and do not feel the strenght the run from the law.");
	output("  The sherrif grabs you and takes you to your cell.");
	addnews("`%".$session[user][name]."`5 has given themselves up at the jail house.");
	$session['user']['jail']=1;
	addnav("Go to cell","jailhouse.php");
}

if ($HTTP_GET_VARS[op]=="flee"){
	$number = e_rand(1,10);
	if ($number > 8){
		output("`n`3`c`bJail House`b`c `n `n");
		output(" ");
		output(" `2Knowing the sheriff is onto you, you make a run for it.`n");
		output("The Sheriff does manage to hit you once before you flee.`n");
		$session[user][hitpoints]-=5;
		output(" `2After a few minutes you look back and do not see the sherrif anymore. You have escaped!`n");
		addnav("Return to Village","village.php");
	}else{
		output("`n`3`c`bJail House`b`c `n `n");
		output(" ");
		output(" `2Knowing the sheriff is onto you, you make a run for it.`n");
		output(" `2As you turn the sherrif grabs your shoulder.`n");
		addnav("Give up","jailhouse.php?op=giveup");
	}
}

if ($HTTP_GET_VARS[op]=="fight"){
$battle=true;
}

if ($battle) {
	include_once("battle.php");
	if($victory) {
		output("You have beaten `^".$badguy['creaturename'].".");
		$badguy=array();
		$session[user][badguy]="";
		addnav("Back to Village","village.php");
		addnews("`%".$session[user][name]."`5 has Beaten the Sheriff in the Jail House and has escaped...for now!");
	} else {
		if ($defeat){
			output("You are beaten. The`^".$badguy['creaturename']. "grabs you and take to the village jail.");
			addnews("`%".$session[user][name]."`5 has been arrested in the forest.");
			$session[user][hitpoints]=0;
			redirect("jailhouse.php");
		}
		else {
			fightnav(true,false);
		}
	}
}
	    if ($HTTP_GET_VARS[op] == "twiddle"){
	    output("`n`7You twiddle your thumbs for a while.`n");
	    	    output("`7You are in your jail cell, there is nothing to do.`n`n");
			    viewcommentary("jail","Wine about being in Jail",20,"wines");
			    addnav("Twiddle your thumbs","jailhouse.php?op=twiddle");
			    addnav("Go to Sleep","login.php?op=logout",true);
			    addnav("Pay Bond","jailhouse.php?op=paybond");
			    addnav("Attempt suicide","jailhouse.php?op=suicide");
			    addnav("Ask for some soup - 1 gem","jailhouse.php?op=soup");
    	    		    if($session[user][superuser]>2){addnav("newday","newday.php");}
	    	    	    if($session[user][jail]==0){
	    	    addnav("Grab your things and go","jailhouse.php");
		    }
	    }
page_footer();
?>