/*****************************************/
/* Read Me	                         */
/* -----------------                     */
/* Matt Bowman (www.mattsshack.com)      */
/* Filename Readme.txt                   */
/* Ver. 0.6 <-NOTICE NOT 1.0		 */
/*****************************************/

/**********************************************************************************/
/* First									  */
/* -----------------								  */
/* I can NOT take credit for robbank.php. I did modify it some from its 	  */
/* original, but I did NOT code the original. I believe that Moejo wrote the	  */
/* original robbank.php. If I am wrong let me know and I will give credit where	  */
/* credit is do.								  */
/*										  */
/* Intro                                                                          */
/* -----------------                                                              */
/* Thank you to all on Dragonprime. This is my fist addon to LoGD and I could not */
/* have made it with out all the other who contributed with their addons          */
/* This is my first mod for LoGD and I hope it not to be the last. Please use 	  */
/* these files as you like, but please remember to always give credit where       */
/* credit is due.							          */
/*										  */
/* Disclamer:                                                                     */
/* I am not responable if this addon hoses up your game. I works fine on my test  */
/* game. That's all of the disclamer :) Have fun...                               */
/* 										  */
/* About	                                                                  */
/* -----	                                                                  */
/* This mod creates a jail house and a wandering sherrif that roam the forest     */
/* looking for players that have robbed the bank or performed evil deeds          */
/* If a player it caught by the sherrif then they are in jail for the rest of 	  */
/* the game day. The player can not be PVP while in jail, but other players can   */
/* visit the jail house and see who is locked away. Players will now also show	  */
/* "Jailed" in the player listings.						  */
/* This can be a hard Mod to install. There may also be better ways to perform    */
/* some of these changes, however I am very new to LoGD modding and this is what  */
/* has worked for me. If you like to leave feedback please do thru dragonprime.   */
/*										  */
/* Changelog									  */
/* ---------									  */
/* Version 0.5									  */
/* (F)ixed Bounty in robbank.php						  */
/* (F)ixed band.php Adds. Now when less that 2 turns players can not robbank.     */
/*   (More of a chance they will get caught by the sheriff)			  */
/* (C)hange made sherrif and guard harder					  */
/* (F)ixed some typos								  */
/* (A)dded pvp.php Setup Instructions						  */
/*										  */
/* Version 0.6									  */
/* (A)dded Bail out friends, bail yourself out, soup, and suicide by SixFoot4     */
/* (C)hange Layout of Bail Display						  */
/* (F)ixed a few small bugs							  */
/* (F)ixed Bail A friend Nav (I hosed it sorry)					  */
/*										  */
/* Version 0.6a									  */
/* (C)hanged Guard at bank to be harder						  */
/* (A)dded View Bounties to Talk to Sheriff in Jail House			  */
/* (F)ixed Bug in robbank.php (Thx Romulus!)					  */
/* 										  */
/* Setup intructions                                                              */
/* -----------------                                                              */
/* Add robbank, evildeeds, suicideattempts, and jail to the end of the account    */
/* table. All tinyint. Place wonderingsherrif.php in your specials dir            */
/* Place jailhouse.php in your main dir                                           */
/*                                                                                */
/* login.php Changes								  */
/* Find:	  				 				  */
/* if (getsetting("logdnet",0)){						  */
/* //register with LoGDnet							  */
/* @file(getsetting("logdnetserver","http://lotgd.net/")."logdnet.php?addy=".	  */
/* URLEncode(getsetting("serverurl","http://".$_SERVER['SERVER_NAME'].dirname	  */
/* ($_SERVER['REQUEST_URI'])))."&desc=".URLEncode(getsetting("serverdesc",	  */
/* "Another LoGD Server"))."");							  */
/*  }										  */
/* Add After:                                                                     */
/* if ($session[user][jail] >="1"){ 						  */
/*	redirect("jailhouse.php");}                                               */
/*                                                                                */
/* newday.php Adds                                                                */
/* $session['user']['jail'] = 0;						  */
/* $session['user']['suicideattempts'] --;					  */
/* $session['user']['robbank'] = 0;						  */
/* if ($session['user']['evildeeds'] == 0){					  */
/* 	//Do Nothing								  */
/*		} else {							  */
/*		$session['user']['evildeeds'] --;				  */
/*		}                                                                 */
/*										  */
/*  bank.php Adds								  */
/* $rob = e_rand(1,10);								  */
/*  if ($rob > 5 and $session[user][robbank] < 1 and $session[user][turns] > 2 ){ */
/*  addnav("Special");								  */
/*  addnav("`4(O) Rob the Bank","robbank.php");}				  */
/*										  */
/* village.php Adds								  */
/* addnav("Jail House","jailhouse.php");					  */
/*										  */
/* pvp.php Changes								  */
/* Find:									  */
/* $sql = "SELECT name,alive,location,sex,level,laston,loggedin,login,pvpflag	  */
/* FROM accounts WHERE (locked=0) AND (age > $days OR dragonkills > 0 OR pk >	  */
/* 0 OR experience > $exp) AND (level >= ".($session[user][level]-1)." AND 	  */
/* level <= ".($session[user][level]+2).") AND (alive=1 AND location=0) AND 	  */
/* (laston < '".date("Y-m-d H:i:s",strtotime("-".getsetting("LOGINTIMEOUT",900)   */
/* ." sec"))."' OR loggedin=0) AND (acctid <> ".$session[user][acctid].")	  */
/* ORDER BY level DESC";							  */
/*     										  */
/* Replace With:								  */
/* $sql = "SELECT name,alive,location,sex,level,laston,loggedin,login,pvpflag	  */
/* FROM accounts WHERE (locked=0) AND (jail=0) AND (age > $days OR dragonkills	  */
/* > 0 OR pk > 0 OR experience > $exp) AND					  */
/*(level >= ".($session[user][level]-1)." AND level				  */
/* <= ".($session[user][level]+2).") AND (alive=1 AND location=0) AND		  */
/* (laston < '".date("Y-m-d H:i:s",strtotime("-".getsetting("LOGINTIMEOUT",900)." */
/* sec"))."' OR loggedin=0) AND (acctid <> ".$session[user][acctid].")		  */
/* ORDER BY level DESC";							  */
/*										  */
/* list.php Changes								  */
/* Find (about line 50):							  */
/* $sql = "SELECT name,login,alive,location,sex,level,laston,loggedin,lastip,	  */
/* uniqueid FROM accounts WHERE locked=0 AND loggedin=1 AND laston>'".		  */
/* date("Y-m-d H:i:s",strtotime("-".getsetting("LOGINTIMEOUT",900)." seconds")).  */
/* "' ORDER BY level DESC, dragonkills DESC, login ASC";			  */
/* Replace With:								  */
/* $sql = "SELECT name,login,alive,location,sex,level,laston,loggedin,lastip,	  */
/* uniqueid,jail FROM accounts WHERE locked=0 AND loggedin=1 AND laston>'".date   */
/* ("Y-m-d H:i:s",strtotime("-".getsetting("LOGINTIMEOUT",900)." seconds"))."'	  */
/* ORDER BY level DESC, dragonkills DESC, login ASC";				  */
/*										  */
/* Find (about line 53):							  */
/* $sql = "SELECT name,login,alive,location,sex,level,laston,loggedin,lastip,	  */	
/* uniqueid FROM accounts WHERE locked=0 $search ORDER BY level DESC,		  */
/* dragonkills DESC, login ASC $limit";						  */
/* Replace With:								  */
/* $sql = "SELECT name,login,alive,location,sex,level,laston,loggedin,lastip,	  */
/* uniqueid,jail FROM accounts WHERE locked=0 $search ORDER BY level DESC,	  */
/* dragonkills DESC, login ASC $limit";						  */
/*										  */
/* Find (about line 85):							  */
/*   output($row[location]							  */
/*		?"`3Boar's Head Inn`0"						  */
/*		:(								  */
/*			$loggedin						  */
/*			?"`#Online`0"						  */
/*			:"`3The Fields`0"					  */
/*			)							  */
/*	);									  */
/* Replace With:								  */
/*   output($row[location]							  */	
/*		?"`3Boar's Head Inn`0"						  */
/*		:(								  */
/*			$jailed ?"`3Jailed`0"					  */
/*				:(						  */
/*				   $loggedin					  */
/*				   ?"`#Online`0"				  */
/*				   :"`3The Fields`0"				  */
/*				)						  */
/*		   )								  */
/*	   );									  */
/*										  */
/* pvp.php Adds	  								  */
/* Find (About line 126):							  */
/* output("`#You recieve `^$badguy[creaturegold]`# gold!`n");			  */
/* Add After:									  */
/* $session[user][evildeeds] += 5;						  */
/* Find (About line 213):							  */
/* $session[user][hitpoints]=0;							  */
/* Add After:									  */
/* $session[user][evildeeds] += 5;						  */
/*										  */
/**********************************************************************************/