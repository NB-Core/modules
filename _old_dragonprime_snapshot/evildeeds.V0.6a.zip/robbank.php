<?
/*****************************************/
/*Original File by Moejo		 */
/* -----------------                     */
/* Moding by Matt Bowman for use with    */
/* evildeeds (www.mattsshack.com)	 */
/*****************************************/

require_once "common.php";
checkday();
page_header ("Ye Olde Bank");
if ($_GET[op]=="") {

        //Setup Guiedo.
        $badguy = array(        "creaturename"=>"`@Guiedo The Bank Gaurd`0"
                                ,"creaturelevel"=>0
                                ,"creatureweapon"=>"Bank Robber Beating Stick"
                                ,"creatureattack"=>1
                                ,"creaturedefense"=>2
                                ,"creaturehealth"=>2
                                ,"diddamage"=>0);


                                //buff Guiedo up a little
                                $userlevel=$session['user']['level'];
                                $userattack=$session['user']['attack'];
                                $userhealth=$session['user']['hitpoints']*5;
                                $userdefense=$session['user']['defense'];
                                $badguy[creaturelevel]+=$userlevel;
                                $badguy[creatureattack]+=$userattack;
                                $badguy[creaturehealth]=$userhealth;
                                $badguy[creaturedefense]+=$userdefense;

                                $session[user][badguy]=createstring($badguy);



        output("`^`c`bThe Temptation Is Killing You`b`c`6");
        output("`n`nThe banker stares at you blankly for a moment then walks into a back room.  When he does so, you see the safe door is open. Inside there unknown riches bulging from the bags.");
        output("`n`this could be an easy day indeed.");
        addnav("Grab The Loot","robbank.php?op=rob");
        addnav("Return To Village","robbank.php?op=chicken");

//You decide that the best course of action is to leave.        
        }else if($_GET['op']=='chicken'){
                output("`^`c`bChicken`b`c`6");
                output("Yah, there are always other opprotunities.");
                addnav("Return To Village","village.php");

//You let your evil side get to you.
        }else if ($_GET['op']=='rob') {
                output("`^`c`bOpprotunity Knocks`b`c`6");
                output("`n`nYou walk around to the back of the counter and grab as much gold as you can carry.");
                addnav("Return to Village","robbank.php?op=leave");

//Let em think they are getting away.
        }else if ($_GET['op']=='leave') {
                output("`^`c`bNot so Fast Pal`b`c`6");
                output("`n`nYou bolt toward the door. But as you are about to exit, a very large man steps into the doorway knocking you back.");
                output("\"May I help you return those to the safe?\" Guiedo asks.");
                addnav("Flee","robbank.php?op=run");
                addnav("Fight","robbank.php?op=fight");
       }

if ($_GET['op']=='battle' || $_GET['op']=='run') {

$session[user][robbank]++;


//how do they say?  You made your bed...
        if ($_GET['op']=='run') {
                output("\"Sorry, but I cannot allow you to leave.\" says Guiedo The Bank Gaurd.");
                $_GET[op]="fight";
        }
}

if ($_GET['op']=='fight') {
        $battle=true;
}

if ($battle) {
        include_once("battle.php");
        if($victory) {
                output("You have beaten `^".$badguy['creaturename'].".");
                $badguy=array();
                $session[user][badguy]="";
                addnav("Back to Village","village.php");
                $gold=0;
                $totalgold=0;
                $sql = "SELECT acctid,goldinbank,bounty,login FROM accounts";
                        $result = db_query($sql) or die(db_error(LINK));

                        if (db_num_rows($result)==0){
                                output("We have encountered a problem. No records found.");
                                addnav("Return to Village","village.php");
                        }
                        for ($i=0;$i<db_num_rows($result);$i++){
                                $takengold=0;
                                $row = db_fetch_assoc($result);

                                //You really dont want to Rob yourself. This takes care of that.
                                if ($row[acctid] != $session[user][acctid] || $row[goldinbank] >= 0){
                                
                                        //if the victim has 10 gold or less in thier account.  We just take it all. >:)
                                        if ($row[goldinbank]<=10)  {
                                                $takengold=$row[goldinbank];
                                                $row[goldinbank]=0;
                                                $totalgold=$takengold+$totalgold;

                                       //Otherwise we take 10 percent of the gold. (this might be a little liberal depending on your game.)
                                       } else {
                                                $takengold=round($row[goldinbank]*.10);
                                                if ($takengold > 5000) $takengold = 5000;
                                                $row[goldinbank]=$row[goldinbank]-$takengold;
                                                $totalgold=$takengold+$totalgold;
                                        }
                                //Send A Email to All victims
                                $sql2 = "UPDATE accounts SET goldinbank=goldinbank-$takengold WHERE login = '{$row['login']}'";
                                db_query($sql2);
                                $mailmessage = "`^".$session[user][name]." robbed the bank and has taken $takengold of your gold pieces.";
                                $mailmessage = str_replace("%p",($session['user']['sex']?"her":"his"),$mailmessage);
                                $mailmessage = str_replace("%o",($session['user']['sex']?"she":"he"),$mailmessage);
                                systemmail($row['acctid'],"`2Some of your Gold has been taken`2",$mailmessage);


                                }


                        }

                //Set bounty on user.
                $bountyissue=e_rand(100,1000);
                $bountyissue=($bountyissue*$session[user][level]);
                $session[user][bounty]=$bountyissue+$session[user][bounty];

                 addnews("`%".$session[user][name]."`5 has Robbed the Bank!!  ".($session[user][sex]?"she":"he")." got away with $totalgold in gold and now has a ".$session[user][bounty]." bounty on ".($session[user][sex]?"her":"his")." Head.");
                $session[user][gold]=$session[user][gold]+=$totalgold;
                //Add a column in your accounts table to take advantage of the Hall of Shame.
                $session[user][evildeeds] += 5;
                $session[user][robbank]=1;

                //Evil probably does not deserve hitpoint resoration but i put it in the code anyway.
                //$session[user][hitpoints]=$session[user][maxhitpoints];

        }else   {
                if ($defeat) {
                        output("As you hit the ground `^".$badguy['creaturename']. " swipes the stolen treasures from you.");
                        addnews("`%".$session[user][name]."`5 has been slain when ".($session[user][sex]?"she":"he")." attempted to rob the bank. They are now in jail");
                        $session[user][evildeeds] += 5;
                        $session[user][jail]=1;
                        redirect("jailhouse.php");
                        
                }else   {
                        fightnav(true,false);
                }

         }
}else {

}
page_footer();

?>
