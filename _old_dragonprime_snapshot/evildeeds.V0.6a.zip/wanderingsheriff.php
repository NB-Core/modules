<?
/*****************************************/
/* Wondering Sheriff                     */
/* -----------------                     */
/* Matt Bowman (www.mattsshack.com)      */
/* Filename wanderingsherrif.php         */
/* Ver. 0.6 <-NOTICE NOT 1.0		 */
/* Read The readme.txt first!		 */
/*****************************************/

require_once "common.php";
checkday();
page_header ("Wandering Sheriff");

if ($HTTP_GET_VARS[op]==""){

	//Modded from robbank.php
	$badguy = array(        
		"creaturename"=>"`@wandering Sheriff`0"
		,"creaturelevel"=>0
		,"creatureweapon"=>"Big Stick and Bad Breath"
		,"creatureattack"=>1
		,"creaturedefense"=>2
		,"creaturehealth"=>2
	,"diddamage"=>0);
	$userlevel=$session['user']['level'];
	$userattack=$session['user']['attack'];
	$userhealth=$session['user']['hitpoints']*5;
	$userdefense=$session['user']['defense'];
	$badguy[creaturelevel]+=$userlevel;
	$badguy[creatureattack]+=$userattack;
	$badguy[creaturehealth]=$userhealth;
	$badguy[creaturedefense]+=$userdefense;
	$session[user][badguy]=createstring($badguy);

	output("`n`3`c`bWandering Sheriff`b`c `n `n");
	output(" `2Has you walk through the forest a sherrif approches you.`n");
	output(" `2You can see he is looking for someone and he lookes at you with a cold stare`n");

	if ($session['user']['robbank'] >= 1){
		$sheriffwatch=1;
		output(" `2After a few moments the Sheriff recognizes you from a wanted poster for robbing the bank.`n");
		output(" `2He draws his sword and starts to walk toward you.`n");
		output(" ");
		output(" `2What do you do?`n");
		addnav("Sherrif");
		addnav("Flee","forest.php?op=flee");
		addnav("Fight","forest.php?op=fight");
		addnav("Give Up","forest.php?op=giveup");
		$session[user][specialinc] = "wanderingsheriff.php";
	}

	if ($session['user']['evildeeds']>=10){
		$sheriffwatch=1;
		output(" `2After a few moments the Sheriff recognizes you from a wanted poster for killing other players.`n");
		output(" `2He draws his sword and starts to walk toward you.`n");
		output(" ");
		output(" `2What do you do?`n");
		addnav("Sherrif");
		addnav("Flee","forest.php?op=flee");
		addnav("Fight","forest.php?op=fight");
		addnav("Give Up","forest.php?op=giveup");
		$session[user][specialinc] = "wanderingsheriff.php";
	} else {
		if ($session['user']['evildeeds']>=1){
			if ($sheriffwatch==1){
				//Do nothing
			} else {
				$sheriffwatch=1;
				output(" `2After a few moments the Sheriff frowns at you and says `&I got my eye on ya boy.`n");
				addnav("Return to Forest","forest.php");
			}
		}else{
			if (($session['user']['evildeeds']==0) && ($session['user']['robbank']==0)) {
				if ($sheriffwatch==1){
					//Do nothing
				}else{
					output(" `2After a few moments the Sheriff smiles at you and walks back into the forest.`n");
					addnav("Return to Forest","forest.php");
				}
			}
		}
	}
}

if ($HTTP_GET_VARS[op]=="flee"){
	$number = e_rand(1,10);
	if ($number > 6){
		output(" `2Knowing the sheriff is onto you, you make a run for it.`n");
		output(" `2After a few minutes you look back and do not see the sherrif anymore. You have excaped!`n");
		addnav("Return to Forest","forest.php");
		$session[user][evildeeds] ++;
	}else{
		output(" `2Knowing the sheriff is onto you, you make a run for it.`n");
		output(" `2As you turn the sherrif grabs your shoulder. You are forced to fight!`n");
		addnav("Fight","forest.php?op=fight");
	}
}

if ($HTTP_GET_VARS[op]=="giveup"){
	output("You know you have been caught and do not feel the strenght the run from the law.`n");
	output("The Sherrif grabes you and takes you to the village jail.`n");
	output("`^You have lost all your gold on hand.`n");
	addnews("`%".$session[user][name]."`5 has been arrested in the forest.");
	$session[user][jail]=1;
	$session[user][gold]=0;
	addnav("Head to Jail","jailhouse.php");
}

if ($HTTP_GET_VARS[op]=="fight"){
	$battle=true;
}

if ($battle) {
	include_once("battle.php");
	if($victory) {
		output("You have beaten `^".$badguy['creaturename'].".");
		$session[user][evildeeds] ++;
		$badguy=array();
		$session[user][badguy]="";
		addnav("Back to forest","forest.php");
		addnews("`%".$session[user][name]."`5 has Beaten the Sherrif in the Forest!");
	} else {
		if ($defeat){
			output("You are beaten. The`^".$badguy['creaturename']. "grabs you and take to the village jail.");
			addnews("`%".$session[user][name]."`5 has been arrested in the forest.");
			$session[user][gold]=0;
			$session[user][hitpoints]=0;
			redirect("jailhouse.php");
		}
		else {
			fightnav(true,false);
		}
	}
}