<?php
function findlp_getmoduleinfo(){
	$info = array(
		"name"=>"Find Lodge Points",
		"version"=>"1.0",
		"author"=>"umk, based on Find Gold by Eric Stevens",
		"category"=>"Forest Specials",
		"download"=>"http://dragonprime.net/users/umk/findlp.zip",
		"settings"=>array(
			"Find Lodge Points Event Settings,title",
			"minlpoints"=>"Minimum lodge points to find,range,0,100,1|10",
			"maxlpoints"=>"Maximum lodge points to find,range,20,150,1|50"
		),
	);
	return $info;
}

function findlp_install(){
	module_addeventhook("forest", "return 100;");
	module_addeventhook("travel", "return 20;");
	return true;
}

function findlp_uninstall(){
	return true;
}

function findlp_dohook($hookname,$args){
	return $args;
}

function findlp_runevent($type,$link)
{
	global $session;
	$chance = e_rand(1,100);
	if ($chance < 81) {
		$min = get_module_setting("minlpoints");
		$max = get_module_setting("maxlpoints");
		$points = e_rand($min, $max);
		output("`^You notice a colorful piece of paper on the ground, you pick it up and see that it is a coupon worth %s points in the lodge!`0", $points);
		$session['user']['donation']+=$points;
		debuglog("found $points lodge points in the dirt");
	}
	else {
		output("`^You notice a colorful piece of paper with the logo of the lodge lying half covered in the dirt.`0");
		output("`^You quickly pull it out only to notice that its already been torn in half!`0");
	}
	
}

function findlp_run(){
}
?>
