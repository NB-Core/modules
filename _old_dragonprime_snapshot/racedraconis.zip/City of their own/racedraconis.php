<?php
// This race is meant to mix things up, and build upon the Alignment system.  This race will not give out alignment points.
// That's up to other modules to handle.  What this module does, is add a new race to the game, whose power is determined
// by how evil their alignment gets.  I eventually intend to develop some more modules with alignment in mind, and I hope
// to encourage other developers to do the same.
//
// My initial inclination was to do two races, both Celestials.  One would be Angelic, and the other Demonic.  However, this
// not only didn't seem to fit in very well with LotGD, but the concept of Celestial creatures didn't seem to be on par with
// basic Humans and Elves.  Perhaps I may develop a powerful specialty you unlock with multiple DK's where you become an
// avatar of celestial creatures.  But for now, I think a Draconic race fits in very well with the LotGD setting, and also
// provides a new role-playing motivation for evil players.  Draconis aren't motivated by saving villages.  They seek their
// own personal power.  To do so, they must remove that which makes them weak (namely social conscious) and knock off the
// current top of the food chain, the Green Dragon.
//
// If this race is well received, I may do some sort of Titan race to be the mirror opposite for good players.  A Draconis
// isn't pure dragon, nor would a Titan be pure celestial.  A Titan would be a human/celestial cross-breed with a natural
// heroic disposition.
//
// This is only my second module, so be gentle.  I still don't know PHP at all, and my knowledge of the LotGD codebase
// is basic to say the least.  The fact that I can produce content is a testament to how wonderful the module system is.
// Kudos go to Eric Stevens & JT Traub.

function racedraconis_getmoduleinfo(){
	$info = array(
		"name"=>"Race - Draconis (city)",
		"version"=>"1.31",
		"author"=>"T. J. Brumfield - Enderandrew",
		"category"=>"Races",
		"description"=>"A evil, power-hungry race whose power grows as morality decreases.",
		"download"=>"http://dragonprime.net/users/enderwiggin/racedraconis.zip",
		"vertxtloc"=>"http://dragonprime.net/users/enderwiggin/",
		"settings"=>array(
			"Draconis Race Settings,title",
			"villagename"=>"Name for the Draconis village|Cecrops",
			"minedeathchance"=>"Chance for Draconis to die in the mine,range,0,100,1|75",
			"mindk"=>"How many DKs do you need before the race is available?,int|0",
			"cost"=>"How many Donation points do you need before the race is available?,int|0",
		),
		"requires"=>array(
			"alignment" => "1.71|`1Enderandrew, http://dragonprime.net/users/enderwiggin/alignment98.zip",
		),				
	);
	return $info;
}

function racedraconis_install(){
	if (!is_module_installed("alignment")) {
    		output("This module requires the alignment module to be installed.");
    		return false;
	}
	else {
		module_addhook("changesetting");
		module_addhook("charstats");
		module_addhook("chooserace");
		module_addhook("moderate");
		module_addhook("newday");
		module_addhook("pointsdesc");
		module_addhook("pvpadjust");
		module_addhook("setrace");
		module_addhook("raceminedeath");
		module_addhook("travel");
		module_addhook("validlocation");
		module_addhook("villagetext");

	// Update from commentary sections using village-$city to village-$race;
	// This is pretty much a one-time thing
	$sql = "UPDATE  " . db_prefix("accounts") . " SET race='Draconis' WHERE race='draconis'";
	db_query($sql);
	$sql = "UPDATE " . db_prefix("commentary") . " SET section='village-Draconis' WHERE section='village-Cecrops'";
	db_query($sql);
	}
}

function racedraconis_uninstall(){
	global $session;
	$vname = getsetting("villagename", LOCATION_FIELDS);
	$gname = get_module_setting("villagename");
	$sql = "UPDATE " . db_prefix("accounts") . " SET location='$vname' WHERE location = '$gname'";
	db_query($sql);
	if ($session['user']['location'] == $gname)
		$session['user']['location'] = $vname;
	$sql = "UPDATE  " . db_prefix("accounts") . " SET race='" . RACE_UNKNOWN . "' WHERE race='Draconis'";
	db_query($sql);
	if ($session['user']['race'] == 'Draconis')
		$session['user']['race'] = RACE_UNKNOWN;
	return true;
}

function racedraconis_dohook($hookname,$args){
	//yeah, the $resline thing is a hack.  Sorry, not sure of a better way
	// to handle this.
	// Pass it in via args?
	global $session,$badguy,$resline;
	$cost = get_module_setting("cost");
	$city = get_module_setting("villagename");
	$race = "Draconis";
	if (is_module_active('alignment')) {
		$al = get_align();
	}
	$draconis = (50-$al);
	switch($hookname){

	case "changesetting":
		// Ignore anything other than villagename setting changes
		if ($args['setting'] == "villagename" && $args['module']=="racedraconis") {
			if ($session['user']['location'] == $args['old'])
				$session['user']['location'] = $args['new'];
			$sql = "UPDATE " . db_prefix("accounts") .
				" SET location='" . $args['new'] .
				"' WHERE location='" . $args['old'] . "'";
			db_query($sql);
			if (is_module_active("cities")) {
				$sql = "UPDATE " . db_prefix("module_userprefs") .
					" SET value='" . $args['new'] .
					"' WHERE modulename='cities' AND setting='homecity'" .
					"AND value='" . $args['old'] . "'";
				db_query($sql);
			}
		}
		break;

	case "charstats":
		if ($session['user']['race']==$race){
			addcharstat("Vital Info");
			addcharstat("Race", $race);
		}
		break;

	case "chooserace":
		$pointsavailable = $session['user']['donation'] - $session['user']['donationspent'];
		if ($session['user']['dragonkills'] < get_module_setting("mindk") || get_module_setting("cost") > $pointsavailable)
			break;
		output("<a href='newday.php?setrace=$race$resline'>`2The Giger-esque city of %s</a>`2 lies before you in it's fetid, rank glory. `@Draconis`2 scurry about in inhuman fashion, their talons clicking and scraping across stone.`n`n",$city,true);
		addnav("`@Draconis`0","newday.php?setrace=$race$resline");
		addnav("","newday.php?setrace=$race$resline");
		break;

	case "moderate":
            if (is_module_active("cities")) {
               tlschema("commentary");
               $args["village-$race"]=sprintf_translate("City of %s", $city);
               tlschema();
               }
               break;

	case "newday":
		if ($session['user']['race']==$race){
			racedraconis_checkcity();
			if ($draconis<=0){
				apply_buff("racialbenefit",array(
				"name"=>"`@Draconic Curse`0",
	 			"atkmod"=>"(-1*(<attack>?(1+((1+floor(<level>/5))/<attack>)):0))",
				"allowinpvp"=>1,
				"allowintrain"=>1,
				"rounds"=>-1,
				"schema"=>"module-racedraconis",
				)
				);
				output("`n`@You have rejected your inner Dragon Strength by burdening yourself with foolish mortal morals!`0`n");
			} else {
				$session['user']['hitpoints']+=$draconis;
				$bonusturns=(int)$draconis/5;
				$session['user']['turns']+=$bonusturns;
				output("`nFor being a rather despicable Draconis, you receive %s extra hit points, and %s extra forest fights!`n", $draconis, $bonusturns);
				if ($draconis==50){
					apply_buff("racialbenefit",array(
					"name"=>"`@Draconic Power`0",
	 				"atkmod"=>"(<attack>?(1+((1+floor(<level>/5))/<attack>)):0)",
					"allowinpvp"=>1,
					"allowintrain"=>1,
					"rounds"=>-1,
					"schema"=>"module-racedraconis",
					)
					);
					output("`n`@For being the epitome of Draconic Power, you receive an additional blessing of inner Dragon Strength!`0`n");
				}
			}	
		}
		break;

	case "pointsdesc":
		if (get_module_setting("mindk")>0 || $cost>0)
		{
			$args['count']++;
			$format = $args['format'];
			$str = translate("The Draconis race is availiable upon reaching %s Dragon Kills and %s Donation points.");
			$str = sprintf($str, get_module_setting("mindk"),
					get_module_setting("cost"));
			output($format, $str, true);
		}
		break;

	case "pvpadjust":
	$enemyAL = get_module_pref('alignment','alignment',$badguy['acctid']);
		if($enemyAL >= 50) {
			$badguy['attack']-=(2+floor($badguy['level']/5));
		} else {
			$badguy['attack']+=(2+floor($badguy['level']/5));
		}
		if ($badguy['race'] == $race) {
			$baduy['hitpoints']+=(50-$enemyAL);
		}
		break;

	case "raceminedeath":
      	if ($session['user']['race'] == $race) {
            	$args['chance'] = get_module_setting("minedeathchance");
		$args['racesave'] = "It was your superior nature as a Draconis that allowed you to survive unscathed.`n";
		$args['schema']="module-racedraconis";
      	}
	      break;

	case "setrace":
		if ($session['user']['race']==$race){
			output("`n`2As a `@Draconis`2, you have Dragon blood running through your veins. ");
			output("`n`2You do not seek to save villages from the tyranny of the Dragon.  ");
			output("`2You understand it's role atop the food chain and seek to prove your superiority by supplanting it!`n");
			output("`2Your growth and bonuses as a `@Draconis`2 is tied directly to your morality.  ");
			output("`2While half dragon, you are half human as well.  You must shed your weak human inhibitions.  ");
			output("`2Humans hold themselves back out of consideration of others.  ");
			output("`2Their half-hearted and false beliefs of equality in an inequal world make them weak.  ");
			output("`2By shedding these social limitations, you will tap in more to your primal powers!`n");
			output("`2However, those of neutral alignments receive little to no bonus, and good aligned `@Draconis`2 are actually penalized.`n");
			if (is_module_active('alignment')) {
				align("-5");
			}
			if (is_module_active("cities")) {
				if ($session['user']['dragonkills']==0 &&
						$session['user']['age']==0){
					//new farmthing, set them to wandering around this city.
					set_module_setting("newest-$city",
							$session['user']['acctid'],"cities");
				}
				set_module_pref("homecity",$city,"cities");
				$session['user']['location']=$city;
			}
		}
		break;

	case "travel":
		$capital = getsetting("villagename", LOCATION_FIELDS);
		$hotkey = substr($city, 0, 1);
		tlschema("module-cities");
		if ($session['user']['location']==$capital){
			addnav("Safer Travel");
			addnav(array("%s?Go to %s", $hotkey, $city),"runmodule.php?module=cities&op=travel&city=$city");
		}
		elseif ($session['user']['location']!=$city){
			addnav("More Dangerous Travel");
			addnav(array("%s?Go to %s", $hotkey, $city),"runmodule.php?module=cities&op=travel&city=$city&d=1");
		}
		if ($session['user']['superuser'] & SU_EDIT_USERS){
			addnav("Superuser");
			addnav(array("%s?Go to %s", $hotkey, $city),"runmodule.php?module=cities&op=travel&city=$city&su=1");
		}
		tlschema();
		break;	

	case "validlocation":
		if (is_module_active("cities"))
			$args[$city] = "village-$race";
		break;

	case "villagetext":
		racedraconis_checkcity();
		if ($session['user']['location'] == $city){
			$args['text']=("`#`b`c$city, Home of the Draconis`c`b`n`2The air hangs wet and heavy on this draconic village.  Structures look more like husks and wombs than buildings, with viscous membranes serving as portals. No one seems to demonstrate and level of humanity or civility.  That is not to say the city is cast into anarchy.  What keeps people from walking on top of each other is a tangible dual sense of fear and aggression that pervades the entire town.  There is a definate pecking order here, not merely of social status, but of one's place on the food chain.`n");
			$args['schemas']['text'] = "module-racedraconis";
			$args['clock']="`n`6You deftly capture one of the tiny lights.`nThe dragonfly-esque fairy within tells you that it is `^%s`6 before disappearing in a tiny sparkle.`n";
			$args['schemas']['clock'] = "module-racedraconis";
			if (is_module_active("calendar")) {
				$args['calendar']="`n`6Another fairy buzzes in your ear, \"`^Today is `&%3\$s %2\$s`^, `&%4\$s`^.  It is `&%1\$s`^.`6\"`n";
				$args['schemas']['calendar'] = "modules-racedraconis";
			}
			$args['title']= array("%s City", $city);
			$args['schemas']['title'] = "module-racedraconis";
			$args['sayline']="mutters";
			$args['schemas']['sayline'] = "module-racedraconis";
			$args['talk']="`n`^People have been heard saying:`n";
			$args['schemas']['talk'] = "module-racedraconis";
			$new = get_module_setting("newest-$city", "cities");
			if ($new != 0) {
				$sql =  "SELECT name FROM " . db_prefix("accounts") .
					" WHERE acctid='$new'";
				$result = db_query_cached($sql, "newest-$city");
				$row = db_fetch_assoc($result);
				$args['newestplayer'] = $row['name'];
				$args['newestid']=$new;
			} else {
				$args['newestplayer'] = $new;
				$args['newestid']="";
			}
			if ($new == $session['user']['acctid']) {
				$args['newest']="`n`6You are released as a sheep amongst wolves in this village, staring up at the dark, husk-like architecture and the towering idols to the Dragon.";
			} else {
				$args['newest']="`n`6Looking at all the draconic buildings, and distracted is `^%s`6.";
			}
			$args['schemas']['newest'] = "module-racedraconis";
			$args['gatenav']="Town Gates";
			$args['schemas']['gatenav'] = "module-racedraconis";
			$args['fightnav']="Dragon Arena";
			$args['schemas']['fightnav'] = "module-racedraconis";
			$args['marketnav']="The Bazaar";
			$args['schemas']['marketnav'] = "module-racedraconis";
			$args['tavernnav']="The Wyrm in the Bottle";
			$args['schemas']['tavernnav'] = "module-racedraconis";
			$args['section']="village-$race";
		}
		break;

	}
	return $args;
}

function racedraconis_checkcity(){
	global $session;
	$race="Draconis";
	$city=get_module_setting("villagename");
	
	if ($session['user']['race']==$race && is_module_active("cities")){
		//if they're this race and their home city isn't right, set it up.
		if (get_module_pref("homecity","cities")!=$city){ //home city is wrong
			set_module_pref("homecity",$city,"cities");
		}
	}	
	return true;
}

function racedraconis_run(){

}
?>
