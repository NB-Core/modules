Race - Archdemon

Version 1.04
Written by RPGSL
Download: http://rpgsl.com/lotgd/racearchdemon_city.zip
Mirror: http://rpdragon.com/lotgd/racearchdemon_city.zip

Game: http://rpdragon.com/


Installation
 
1) Copy racearchdemon_city.php into your LotGD modules folder
2) Log in to LotGD with your admin account
4) Enter the Superuser Grotto
5) Click Manage Modules
6) Install racearchdemon_city.php (Race - Demon)
7) Configure settings and save
8) Activate


Questions/Comments?

alex@rpgsl.com


Visit www.rpgsl.com today for your RPG needs.