12-21-2005 Verified Uploader:admin Time:15:23:52
('fr','module-ghosttown','Name for the ghost town','Nom de la ville fant�me','Monyss','1.0.3');