12-21-2005 Verified Uploader:admin Time:15:23:52
('fr','module-inncoupons','\"`&Will this suit you?`7\"`n`n','\"`&Cela vous convient-il?`7\"`n`n','zveno','1.0.5'),
('fr','module-inncoupons','Hunter\'s Lodge','Hall du Chasseur','zveno','1.0.5'),
('fr','module-inncoupons','Inn Coupons (%s points)','Bons d\'Hotellerie (%s points)','zveno','1.0.5'),
('fr','module-inncoupons','L?Return to the Lodge','L?Retourner � la Loge','Sunnygirl','1.0.5'),
('fr','module-inncoupons','Ten free stays at the inn cost %s points','Dix s�jours gratuits � l\'auberge coutent %s points','Sunnygirl','1.0.5'),
('fr','module-inncoupons','The cost for ten free stays at the inn is %s points','Un s�jour de dix nuits  en hotellerie co�te %s points.','zveno','1.0.5'),
('fr','module-inncoupons','`7J. C. Petersen gives you a card that reads \"Coupon: Good for ten free stays at %s\"','`7J. C. Petersen vous tend une carte o� est �crit:\"Bon pour dix nuits gratuites � %s\"','zveno','1.0.5'),
('fr','module-inncoupons','`7J. C. Petersen turns to you. \"`&Ten free nights in %s will cost %s points,`7\" he says.','`7J. C. Petersen se tourne vers vous. \"`&Dix nuits gratuite � %s vous co�teront %s points,`7\" dit-il.','zveno','1.0.5');