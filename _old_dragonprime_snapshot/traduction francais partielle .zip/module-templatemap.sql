12-21-2005 Verified Uploader:admin Time:15:23:52
('fr','module-templatemap','Cartographer','Cartographe','Sunnygirl','1.0.5'),
('fr','module-templatemap','I\'ll take it!','Je vais le prendre!','Sunnygirl','1.0.5');