12-21-2005 Verified Uploader:admin Time:15:23:52
('fr','module-oldchurch','A flickering torch inhabits an iron holder to one side, above a dusty font.','Accroch� par un vieil anneau en fer, juste au dessus d\'un b�nitier poussi�reux, un torche �met une lumi�re tremblotante.','Vorkosigan','1.0.3'),
('fr','module-oldchurch','Enter the Church','Entrer dans l\'eglise','admin','1.0.2'),
('fr','module-oldchurch','O?The Old Church','O?La vieille eglise','admin','1.0.2'),
('fr','module-oldchurch','Old Church','Vieille Eglise','admin','1.0.2'),
('fr','module-oldchurch','Old Church - Settings','Vieille Eglise - Reglages','Monyss','1.0.3'),
('fr','module-oldchurch','Return to the Village','Retourner au village','admin','1.0.2'),
('fr','module-oldchurch','While the church has obviously been abandoned for a long time, the windows flicker with light from the inside and shadows can be seen dancing on the tall broken shards of glass which fill the windows.','Bien que l\'�glise soit abandonn�e depuis longtemps, les fen�tres clignotent avec des lumi�res venant de l\'int�rieur et les ombres peuvent �tre  vu sur les tessons qui remplissent fen�tres.','admin','1.0.2'),
('fr','module-oldchurch','`#`5Capelthwaite\'s Blessing `7(%s rounds left)`n','`#`5B�n�diction de Capelthwaite `7(valide %s tours)`n','zveno','1.0.5'),
('fr','module-oldchurch','`)Energy flows through you!`0`n','`)Une �nergie nouvelle court dans votre corps!`0`n','admin','1.0.2'),
('fr','module-oldchurch','`)The burst of energy passes.`0`n','`)Vous sentez disparaitre l\'�nergie suppl�mentaire.`0`n','admin','1.0.2'),
('fr','module-oldchurch','`7An ancient church stands alone, apart from the other buildings, centuries-old scorchmarks marring the once grand walls and curling round the belltower.','`7Une �glise antique , s�par�e des autres b�timents,se tient devant vous, avec ses murs tres grands et en mauvais etat.','admin','1.0.2'),
('fr','module-oldchurch','`nAs if from a long way away you hear a bell toll. A shiver runs down your spine.`n','`nDans le lointain, vous entendez sonner le glas. Un frisson parcours votre �chine.`n','admin','1.0.2'),
('fr','module-oldchurch','`n`nA thin path winds its way up the hill between sinister-looking memorials covered in mist.','`n`nUn etroit chemin  s\'enroule  vers le haut de la colline entre les memorials  couverts en brume.','admin','1.0.2');