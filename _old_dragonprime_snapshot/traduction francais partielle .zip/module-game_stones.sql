12-21-2005 Verified Uploader:admin Time:15:23:52
('fr','module-game_stones','Never Mind','Peu Importe','Monyss','1.0.3'),
('fr','module-game_stones','Other Games','Autres Jeux','Sunnygirl','1.0.5'),
('fr','module-game_stones','Play again?','Jouer encore?','Sunnygirl','1.0.5'),
('fr','module-game_stones','S?Play Stones Game','Jeu des Pierres','Vorkosigan','1.0.3'),
('fr','module-game_stones','`$red`3','`$rouge`3','zveno','1.0.5');