12-21-2005 Verified Uploader:admin Time:15:23:52
('fr','badword','Bad word editor','Editeur des mots interdits','Monyss','1.0.3'),
('fr','badword','Refresh the list','Mettre la liste � jour','Monyss','1.0.3'),
('fr','badword','Remove','Retirer','Monyss','1.0.3'),
('fr','badword','Test','Test','Monyss','1.0.3'),
('fr','badword','`7Add a word:`0','`7Ajouter un mot:`0','Monyss','1.0.3'),
('fr','badword','`7Remove a word:`0','`7Retirer un mot:`0','Monyss','1.0.3'),
('fr','badword','`7Test a word:`0','`7Tester un mot:`0','Monyss','1.0.3');