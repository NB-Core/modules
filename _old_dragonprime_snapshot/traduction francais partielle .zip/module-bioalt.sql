12-21-2005 Verified Uploader:admin Time:15:23:52
('fr','module-bioalt','- IP Filter: %s ','- Filtre IP: %s ','Monyss','1.0.3');