12-21-2005 Verified Uploader:admin Time:15:23:52
('fr','module-specialtychickenmage','Chicken Mage','Poule Mouill�','admin','1.0.5'),
('fr','module-specialtychickenmage','Link the availability to a full moon?','Lier la disponibilit� � la pleine lune?','zveno','1.0.5'),
('fr','module-specialtychickenmage','Minimum DKs required before available','Minimum Dragons tues avant acces','admin','1.0.5'),
('fr','module-specialtychickenmage','Working on a farm with a lot of chickens','Travaille sur une ferme o� il y a plein de poulets','Sunnygirl','1.0.5'),
('fr','module-specialtychickenmage','`#`^Swarm of Chicks `7(%s rounds left)`n','`#`^Essaim de poussins `7(%s tours restants)`n','Sunnygirl','1.0.5'),
('fr','module-specialtychickenmage','`%`^You summon forth several small chicks and direct them at %s.`0`n','`%`^Vous convoquez plusieurs petits poussins et les envoyer sur %s.`0`n','Sunnygirl','1.0.5'),
('fr','module-specialtychickenmage','`n`2For your interest in being a %s%s`2, you receive `^1`2 extra `&%s%s`2 use for today.`n','`n`2Pour votre interet dans l\'art de %s%s`2 vous recevez `^1`2  extra `&%s%s`2 a utiliser ce jours.`n','admin','1.0.5');