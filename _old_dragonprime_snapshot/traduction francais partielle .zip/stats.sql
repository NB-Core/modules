12-21-2005 Verified Uploader:admin Time:15:31:30
('fr','stats','Stats','Statistiques','Sunnygirl','1.0.5'),
('fr','stats','`@Average Page Gen Time: `^%s`n','`@Page g�n�r� en : `^%s`n','admin','1.0.0'),
('fr','stats','`@Total Accounts: `^%s`n','`@Comptes totaux: `^%s`n','admin','1.0.0');