12-21-2005 Verified Uploader:admin Time:15:23:52
('fr','module-forestturn','Man is that stuff potent!','Vous buvez le contenu de la bouteille','admin','1.0.2'),
('fr','module-forestturn','Since the sigils inscribed on the skin are those of someone you recognize as a very powerful warrior from the village, you decide that it would be safe to take a sip.`n`n`n','Vous la prenez et decouvrer dessus une inscription faisant r�ference a un ancien hero et vous d�cidez que ceci ne peut pas etre n�gatif.`n`n','admin','1.0.2'),
('fr','module-forestturn','Stopping to pick one, you inhale its scent.`n`n','En arr�tant pour en cueillir une, vous inspirez son odeur.`n`n','Sunnygirl','1.0.5'),
('fr','module-forestturn','You `%lose one `^turn!`0','Vous `%perdez un `^tour!`0','Sunnygirl','1.0.5'),
('fr','module-forestturn','You `%receive one`^ extra turn!`0','Vous `%recevez un `^ tour suppl�mentaire!`0','admin','1.0.2'),
('fr','module-forestturn','You feel `!hyper`^.`n`n','Vous vous sentez `!Hyper remont�`^.`n`n','admin','1.0.2'),
('fr','module-forestturn','You stumble off the path to take a nap.`n`n','Vous tr�buchez en dehors du chemin et en vous endormant.`n`n','Sunnygirl','1.0.5'),
('fr','module-forestturn','`$Yawn!','`$Ba�lle!','Sunnygirl','1.0.5'),
('fr','module-forestturn','`^Man, that flower scent made you really sleepy.','`^Ouf, l\'odeur de cette fleur vous rend vraiment somnolent.','Sunnygirl','1.0.5'),
('fr','module-forestturn','`^Walking along a path in the forest, you come upon a field of flowers.','`^Tout en marchant sur un chemin dans la for�t, vous arrivez pr�s d\'un champ de fleurs','Monyss','1.0.3'),
('fr','module-forestturn','`^You discover a skin of liquid hanging over the limb of a tree.','`^Vous decouvrer une petite bouteille cach� dans le tronc d\'un arbre centenaire.','admin','1.0.2');