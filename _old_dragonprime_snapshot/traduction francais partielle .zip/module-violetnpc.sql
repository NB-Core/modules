12-21-2005 Verified Uploader:admin Time:15:31:30
('fr','module-violetnpc','A Lot','Beaucoup','Sunnygirl','1.0.5'),
('fr','module-violetnpc','NPC Name','Nom du NPC','Sunnygirl','1.0.5'),
('fr','module-violetnpc','NPC Sex','Sexe du NPC','Sunnygirl','1.0.5'),
('fr','module-violetnpc','Quite a Bit','Quelque peu','Sunnygirl','1.0.5');