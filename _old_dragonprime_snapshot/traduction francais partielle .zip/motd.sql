12-21-2005 Verified Uploader:admin Time:15:31:30
('fr','motd','Add MoTD','ajouter un message','admin','1.0.0'),
('fr','motd','Add Poll','ajouter sondage','admin','1.0.0'),
('fr','motd','Are you sure you want to delete this item?','Etes vous sur de vouloir supprimer cette annonce?','Monyss','1.0.3'),
('fr','motd','Del','Supprimer','Monyss','1.0.3'),
('fr','motd','Edit','Editer','Monyss','1.0.3'),
('fr','motd','LoGD Message of the Day (MoTD)','Message du Jour de LoGD (MoTD)','zveno','1.0.5'),
('fr','motd','MoTD Archives:','MoTD Archives:','admin','1.0.0'),
('fr','motd','Poll:','Sondage:','Monyss','1.0.3'),
('fr','motd','Preview','Pr�vision','admin','1.0.0'),
('fr','motd','Return','Retour','admin','1.0.0'),
('fr','motd','Submit','Soumettre','Sunnygirl','1.0.5'),
('fr','motd','Vote','Voter','Monyss','1.0.3'),
('fr','motd','`n`@Commentary:`0`n','`n`@Commentaires:`0`n','admin','1.0.0');