12-21-2005 Verified Uploader:admin Time:15:23:52
('fr','module-spa','Booger\'s Spa','Spa de Booger','Sunnygirl','1.0.5'),
('fr','module-spa','How much gold does a visit cost per level','Combien d\'or par niveau co�te une visite','zveno','1.0.5');