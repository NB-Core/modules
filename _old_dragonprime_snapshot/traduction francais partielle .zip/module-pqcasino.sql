12-21-2005 Verified Uploader:admin Time:15:23:52
('fr','module-pqcasino','%s Casino','Casino de %s','Sunnygirl','1.0.5'),
('fr','module-pqcasino','Casino','Casino','Sunnygirl','1.0.5'),
('fr','module-pqcasino','Casino Module Settings','Reglages du module Casino','Monyss','1.0.3'),
('fr','module-pqcasino','`2You bet: `#100`2','`2Vous pariez: `#100`2','Sunnygirl','1.0.5'),
('fr','module-pqcasino','`4Un-Installing Casino Module.`n','`4D�sinstaller le module Casino.`n','Monyss','1.0.3'),
('fr','module-pqcasino','`7You stroll into the casino.. it\'s a busy place.  You look for a place to loose your gold.`n`n','`7Vous entrez dans le casino de cette cit�....Il y a encore de la place aux tables. Choissisez celle ou vous voulez perdre de l\'argent.`n`n','admin','1.0.3'),
('fr','module-pqcasino','`c`b`&Casino`0`b`c','`c`b`&Casino`0`b`c','Sunnygirl','1.0.5');