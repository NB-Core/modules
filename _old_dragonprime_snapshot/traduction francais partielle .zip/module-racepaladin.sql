12-21-2005 Verified Uploader:admin Time:15:23:52
('fr','module-racepaladin','Chance for Paladin to die in the mine','Chance pour un Paladin de mourir dans la mine','Sunnygirl','1.0.5'),
('fr','module-racepaladin','Paladin Race Settings','Param�tres de la Race de Paladin','Sunnygirl','1.0.5');