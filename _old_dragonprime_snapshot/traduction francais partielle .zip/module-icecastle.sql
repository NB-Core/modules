12-21-2005 Verified Uploader:admin Time:15:23:52
('fr','module-icecastle','The Ice Castle','Chateau de Glace','admin','1.0.4'),
('fr','module-icecastle','There\'s no way you\'re going near that place again today.','Il n\'est pas question que vous retourniez pr�s de cet endroit aujourd\'hui.','Sunnygirl','1.0.5'),
('fr','module-icecastle','What will you do?','Qu\'allez-vous faire?','Sunnygirl','1.0.5'),
('fr','module-icecastle','Which will you choose?`n`n','Lequel choisirez-vous?`n`n','Sunnygirl','1.0.5'),
('fr','module-icecastle','Yellow','Jaune','zveno','1.0.5'),
('fr','module-icecastle','You `4lose `7some of your hitpoints!`n','Vous `4perdez `7quelques uns de vos points de vie!`n','Sunnygirl','1.0.5'),
('fr','module-icecastle','You feel `@vigorous!','Vous vous sentez `@vigoureux!','Sunnygirl','1.0.5'),
('fr','module-icecastle','`7You run out of there in a hurry.`n`n','`7Vous courez � l\'ext�rieur en h�te.`n`n','Sunnygirl','1.0.5');