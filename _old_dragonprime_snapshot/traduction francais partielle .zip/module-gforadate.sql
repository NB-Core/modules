12-21-2005 Verified Uploader:admin Time:15:23:52
('fr','module-gforadate','(0 for unlimited)','(0 pour illimit�)','Sunnygirl','1.0.5');