12-21-2005 Verified Uploader:admin Time:15:23:52
('fr','module-cemetery','C?The Old Cemetery','C?Le vieux cimetiere','admin','1.0.0'),
('fr','module-cemetery','Cemetery','Cimeti�re','Sunnygirl','1.0.5'),
('fr','module-cemetery','G?Haunt %s','Hanter %s','Sunnygirl','1.0.5'),
('fr','module-cemetery','In this place you can hear the whispers and moans of the dead.`n`n','Dans cet endroit, vous pouvez entendre les chuchotements et les g�missements des morts.`n`n','Sunnygirl','1.0.5'),
('fr','module-cemetery','The strange silence no longer worries you.`n`n','L\'�trange long silence ne t\'inqui�tes plus.`n`n','Monyss','1.0.3'),
('fr','module-cemetery','You move among them, almost invisible.`n`n','Vous vous promenez au milieu de ceux ci, toujours invisible.`n`n','admin','1.0.3'),
('fr','module-cemetery','`&`c`bThe Old Cemetery`b`c','`&`c`bLe Vieux Cimeti�re`b`c','Sunnygirl','1.0.5'),
('fr','module-cemetery','`&`c`bThe Town of %s`b`c','`&`c`bLa Cit� de %s`b`c','zveno','1.0.5'),
('fr','module-cemetery','`n`)At the edge of the old town is a long-abandoned cemetery of broken headstones and sickly weeds.','`n`) Au bord de la vieille ville se trouve un cimeti�re remplie de pierres tombales cass�es et de mauvaises herbes; il a �t� abandonn� depuis bien longtemps d�j�.','Sunnygirl','1.0.5'),
('fr','module-cemetery','`n`)You are standing once again in the deserted ghost town, %s.','`n`)Tu es � nouveau dans la tour fant�me d�serte, %s.','Monyss','1.0.3');