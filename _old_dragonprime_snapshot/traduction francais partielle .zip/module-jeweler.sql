12-21-2005 Verified Uploader:admin Time:15:23:52
('fr','module-jeweler',' ?Sell Back Bracelet',' ?Revendre le Bracelet','Sunnygirl','1.0.5'),
('fr','module-jeweler',' ?Sell Back Ring',' ?Revendre l\'Anneau','Sunnygirl','1.0.5'),
('fr','module-jeweler','Amulet','Amulette','zveno','1.0.5'),
('fr','module-jeweler','Bracelet','Bracelet','zveno','1.0.5'),
('fr','module-jeweler','I keep these for special customers!`7\" he says with a wink.`n`n\"`&','Je garde ceux-ci pour les clients particuliers!`7\" dit-il en clignant de l\'oeil.`n`n\"`&','Sunnygirl','1.0.5'),
('fr','module-jeweler','Necklace','Collier','zveno','1.0.5'),
('fr','module-jeweler','Oliver\'s Jewelry','Bijouterie d\'Oliver','Sunnygirl','1.0.5'),
('fr','module-jeweler','Price of the jeweled ring','Prix de l\'anneau orn� de pierres','Sunnygirl','1.0.5'),
('fr','module-jeweler','Ring','Anneau','Sunnygirl','1.0.5'),
('fr','module-jeweler','`^Jewelry: ','`^Bijoux: ','zveno','1.0.5');