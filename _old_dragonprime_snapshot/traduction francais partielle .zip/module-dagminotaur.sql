12-21-2005 Verified Uploader:admin Time:15:23:52
('fr','module-dagminotaur','%s defeated a Minotaur in the Caves! The deaths of many travellers have been avenged!','%s a d�fait un Minotaure dans les Caves! La mort de plusieurs voyageurs a �t� veng�e!','Sunnygirl','1.0.5'),
('fr','module-dagminotaur','The Caves','Les Caves','Sunnygirl','1.0.5'),
('fr','module-dagminotaur','You have nowhere to run to, so you ready your %s`2 to fight!','Vous n\'avez nullepart o� vous r�fugier, vous pr�parez donc votre %s`2 pour vous battre!','Sunnygirl','1.0.5'),
('fr','module-dagminotaur','You quickly flee the scene, hoping that there are not more of them around.`n`n','Vous quittez rapidement la scene du combat ce d\'autant plus qu\'il n\'y a plus rien a combattre ici.`n`n','admin','1.0.2'),
('fr','module-dagminotaur','`&You gain %s experience from this fight!','`&Vous gagnez %s points d\'experience grace � ce combat!','admin','1.0.2'),
('fr','module-dagminotaur','`&You gain %s experience from this fight!`n`n','`&Vous gagnez %s points d\'experience grace � ce combat!`n`n','admin','1.0.2'),
('fr','module-dagminotaur','`2The lion collapses on the ground, bleeding from its wounds.','`2Le lion s\'affaise au sol dans un bain de sang.','admin','1.0.2'),
('fr','module-dagminotaur','`2You return to town, shaken by your experience.','`2Vous retournez en ville, enchant� par cet exp�rience.','admin','1.0.2');