12-21-2005 Verified Uploader:admin Time:15:23:52
('fr','module-emoticons','Change Keystroke to','Changer la touche de raccourci pour','Sunnygirl','1.0.5'),
('fr','module-emoticons','Emoticons Module User Preferences','Pr�f�rences de l\'Utilisateur pour le module Emoticons','zveno','1.0.5'),
('fr','module-emoticons','Submit','Soumettre','Sunnygirl','1.0.5'),
('fr','module-emoticons','`n`c`@-=-=Clickable Smilies=-=-`n','`n`c`@-=-=Smilies=-=-`n','Monyss','1.0.3');