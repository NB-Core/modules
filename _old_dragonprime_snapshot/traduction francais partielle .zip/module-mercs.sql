12-21-2005 Verified Uploader:admin Time:15:23:52
('fr','module-mercs',' The one who catches it will join you in battle...`n`n ','Celui qui l\'attrapera vous accompagnera dans la bataille.....`n`n','admin','1.0.3'),
('fr','module-mercs','Forget it','Continuer sans lui','admin','1.0.3'),
('fr','module-mercs','Grog the Drunken Dwarf falls on the gem and will fight with you for a while!','Grog le dwarf attrape la gemme et vous suit.','admin','1.0.3'),
('fr','module-mercs','Hire a Mercenary','Engager un Mercenaire','Monyss','1.0.3'),
('fr','module-mercs','What will you do?','Que faites vous?','admin','1.0.3'),
('fr','module-mercs','`#`#Knight `7(%s rounds left)`n','`#`#Chevalier `7(%s Tours restants)`n','Monyss','1.0.3'),
('fr','module-mercs','`#`#Paladin `7(%s rounds left)`n','`#`#Paladin `7(%s Tours Restants)`n','Monyss','1.0.3'),
('fr','module-mercs','`n`nFor the price of only %s %s, one of them will fight at your side for a while.`n`n','`n`nPour la modique somme de %s %s il vous accompagnera dasn vos combats.`n`n','admin','1.0.3'),
('fr','module-mercs','`n`n`%You are not sure which mercenary to choose, so you tell them to stand on the other side of the wagon, then toss a gem over the wagon.','`n`n`% En fin de compte, ce n\'est pas un mais des mercenaires que contient le chariot. Comme vous hesitez, vous decidez de jeter la gemme dans le chariot.','admin','1.0.3'),
('fr','module-mercs','`n`n`2You encounter a Covered Wagon filled with mercenary warriors who clamor loudly for your favor, eager to join you in battle.','`n`n`2Vous rencontrez une petite roulotte avec un mercenaire a l\'interieur qui reclame votre faveur afin que vous l\'engagiez pour vos futurs combats.','admin','1.0.3'),
('fr','module-mercs','gem','gemme','admin','1.0.3');