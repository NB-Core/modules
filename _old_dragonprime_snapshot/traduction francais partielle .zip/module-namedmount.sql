12-21-2005 Verified Uploader:admin Time:15:23:52
('fr','module-namedmount','Hunter\'s Lodge','Hall du Chasseur','zveno','1.0.5'),
('fr','module-namedmount','Name Your Mount (%s points)','Nommer votre Monture (%s points)','zveno','1.0.5'),
('fr','module-namedmount','The ability to name your mount (%s points for the first change, %s points thereafter)','Possibilit� de donner un nom � votre monture (%s points la premi�re fois, %s points ensuite).','zveno','1.0.5'),
('fr','module-namedmount','You have to have a mount in order to name it, silly!','Il faut une monture pour pouvoir li donner un nom, imb�cile!','zveno','1.0.5');