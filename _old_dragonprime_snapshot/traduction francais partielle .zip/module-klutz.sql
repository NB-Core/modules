12-21-2005 Verified Uploader:admin Time:15:23:52
('fr','module-klutz','You help her gather her belongings.`n`n','Vous aidez a rassembl� son equipement.`n`n','admin','1.0.0'),
('fr','module-klutz','`&\"Oh! Oh, I\'m terribly sorry! I mustn\'t have been watching where I was going...\"`n`n','`&\"Oh!  Ah, je suis terriblement d�sol�!  Je ne dois pas avoir observ� o� j\'�tais... \"`n`n ','admin','1.0.1'),
('fr','module-klutz','`7As a thank you, she hands you a `5gem`7!','`7Elle vous offre,en plus, une `5gemme`7!','admin','1.0.3'),
('fr','module-klutz','`7She scrambles on the ground, trying to collect all the things she has dropped.','`7Elle descent  par  terre, essayant de rassembler toutes les choses qu\'elle a laiss�es tomber.','admin','1.0.1'),
('fr','module-klutz','`7While you\'re minding your own business, a lady plows headlong into you.`n`n','`7Tandis que vous vous occupez de vos propres affaires, une charrette d\'une dame absorb� par ses pens�es vous percute.`n`n','admin','1.0.2'),
('fr','module-klutz','`^She is most grateful for your help!`n`n','`^Elle vous remercie tres aimablement de votre aide!`n`n','admin','1.0.1');