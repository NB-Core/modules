12-21-2005 Verified Uploader:admin Time:15:23:52
('fr','module-caravan',' ?Ride the Caravan to %s','Prendre la caravane pour %s','admin','1.0.5'),
('fr','module-caravan','Can players visit?','Les joueurs peuvent-ils visiter?','Sunnygirl','1.0.5'),
('fr','module-caravan','Caravan Settings','Caravanes options','admin','1.0.0'),
('fr','module-caravan','In the back of the wagon, excited villagers are discussing what the ghost town might be like.','Au fond de la caravane, des villageois excit�s se questionnent sur l\'allure de la ville fant�me.','Sunnygirl','1.0.5'),
('fr','module-caravan','R?Ride the Caravan back to %s','Prendre la caravane de retour a %s','admin','1.0.5');