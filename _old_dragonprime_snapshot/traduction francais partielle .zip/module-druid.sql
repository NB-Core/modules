12-21-2005 Verified Uploader:admin Time:15:23:52
('fr','module-druid','After a brief hesitation, you drink deeply.','Apr�s une br�ve h�sitation, vous en prenez une grande gorg�e.','zveno','1.0.5'),
('fr','module-druid','You receive `^two forest fights!`n','Vous recevez `^deux combats en for�t!`n','Sunnygirl','1.0.5'),
('fr','module-druid','`6 Your faith was well placed, pilgrim!`n`n','`6 Vous avez raison d\'avoir eu confiance, voyageur!`n`n','zveno','1.0.5'),
('fr','module-druid','`6Beneath the tree is a small cottage, an ancient figure standing before it.`n','`6Au pied de l\'arbre, vous distinguez la silhouette d\'un vieillard pr�s d\'une petite maison.`n','zveno','1.0.5'),
('fr','module-druid','`6Despite his elfin features, you instinctively know him to be a `%Druid Priest.`n`n','`6Malgr� son apparence d\'elfe, vous savez instinctivement que vous �tes en pr�sence d\'un`%Druide.`n`n','zveno','1.0.5'),
('fr','module-druid','`6You gain `^%s experience`6!`n','`6Vous gagnez `^%s experience`6!`n','zveno','1.0.5'),
('fr','module-druid','`6Your maximum hitpoints are `b%s`b `&increased`6 by 1!','`6Vos points de vie maximum sont `b%s`b `&augment�s`6 de 1!','Sunnygirl','1.0.5'),
('fr','module-druid','`@ You feel the `^Broth `@burning within you.`n`n ','`@ Vous sentez la chaleur du `^Bouillon`@ dans votre corps.','zveno','1.0.5'),
('fr','module-druid','`@He offers you a bowl of `^Hearty Broth.','`@Il vous offre un bol de `^Vigoureux Bouillon.','zveno','1.0.5'),
('fr','module-druid','`@Unsure of his benevolence, what do you do?','`@Peu confiant sur ses bonnes intentions, que d�cidez-vous de faire?','zveno','1.0.5'),
('fr','module-druid','`^You gain `^5 charm!','`^Vous gagnez `^5 points de charme!','Sunnygirl','1.0.5'),
('fr','module-druid','`n`2You enter a meadow, dominated by the largest `@Oak Tree `2you have ever seen.`n`n','`n`2Vous p�n�trez dans une clairi�re domin�e par le plus formidable `@Ch�ne`2 que vous ayez jamais vu.`n`n','zveno','1.0.5'),
('fr','module-druid','`n`@You take the `^Bowl of Broth`@ and raise it to your lips.','`n`@Vous prenez le `^Bol de Bouillon`@ et le porter � vos l�vres.','zveno','1.0.5');