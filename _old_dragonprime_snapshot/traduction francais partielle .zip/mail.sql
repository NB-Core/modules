12-21-2005 Verified Uploader:admin Time:15:23:52
('fr','mail','< Previous','< Pr�c�dent','zveno','1.0.5'),
('fr','mail','Check All','Tout s�lectionner','Vorkosigan','1.0.3'),
('fr','mail','Delete','Supprimer','zveno','1.0.5'),
('fr','mail','Delete Checked','Effacer s�lectionn�s','Vorkosigan','1.0.3'),
('fr','mail','Inbox','Re�us','Vorkosigan','1.0.3'),
('fr','mail','Mark Unread','Marquer comme Non Lu','zveno','1.0.5'),
('fr','mail','New LoGD Mail','Nouveau Message LoGD','Sunnygirl','1.0.5'),
('fr','mail','Next >','Suivant >','zveno','1.0.5'),
('fr','mail','Original Message','Message d\'origine','Sunnygirl','1.0.5'),
('fr','mail','Reply','R�pondre','zveno','1.0.5'),
('fr','mail','Report to Admin','Contacter l\'Administrateur','zveno','1.0.5'),
('fr','mail','Search','Rechercher','Sunnygirl','1.0.5'),
('fr','mail','Send','Envoyer','Sunnygirl','1.0.5'),
('fr','mail','To: ','�:','Sunnygirl','1.0.5'),
('fr','mail','Write','Ecrire','Vorkosigan','1.0.3'),
('fr','mail','Ye Olde Poste Office','La Poste du Jeu','admin','1.0.5'),
('fr','mail','You cannot reply to a system message.`n','Vous ne pouvez pas r�pondre � un message du Grand Ordinateur!!`n','zveno','1.0.5'),
('fr','mail','You have received new mail on LoGD at http://%s

-=-=-=-=-=-=-=-=-=-=-=-=-=-
From: %s
To: %s
Subject: %s
Body: 
%s
-=-=-=-=-=-=-=-=-=-=-=-=-=-
Do not respond directly to this email, it was sent from the game email address, and not the email address of the person who sent you the message.  If you wish to respond, log into Legend of the Green Dragon at http://%s .

You may turn off these alerts in your preferences page, available from the village square.','Vous avez re�u du courrier sur LoGD � http://%s

-=-=-=-=-=-=-=-=-=-=-=-=-=-
De: %s
�: %s','Uriell','1.0.5'),
('fr','mail','Your message was sent!`n','Votre message a �t� envoy�!`n','admin','1.0.5'),
('fr','mail','[description]','[description]','admin','1.0.0'),
('fr','mail','`#Max message size is `@%s`#, you have `^XX`# characters left.','`#Taille maximum du message est de `@%s`#, vous avez `^XX`# characteres possible.','admin','1.0.2'),
('fr','mail','`$Max message size is `@%s`$, you are over by `^XX`$ characters!','`$Taille maximum des messages est de `@%s`$, il vous reste `^XX`$ caract�res possibles.','Sunnygirl','1.0.5'),
('fr','mail','`2Body:`n','`2Message:`n','admin','1.0.2'),
('fr','mail','`2Notice: `^SVP, ne pas utiliser cette fonction pour reporter un bug a l\'administrateur du jeu. Pour cela, utiliser la fonction demande d\'aide, en haut de l\'ecran`n','`2Note: `^SVP, ne pas utiliser cette fonction pour reporter un bug a l\'administrateur du jeu. Pour cela, utiliser la fonction demande d\'aide, en haut de l\'ecran`n','Sunnygirl','1.0.5'),
('fr','mail','`2Someone has gifted you with `@%s`2 donator points. %s','`2Quelqu\'un vous a fait cadeau de `@%s`2 points de donation. %s','Sunnygirl','1.0.5'),
('fr','mail','`2Subject:','`2Sujet:','admin','1.0.2'),
('fr','mail','`2To: ','`2�:','Sunnygirl','1.0.5'),
('fr','mail','`2To: `^%s`n','`2A: `^%s`n','admin','1.0.2'),
('fr','mail','`2You have received %s donation points for %s.','`2Vous avez re�u un don de %s points pour %s.','zveno','1.0.5'),
('fr','mail','`2You were successful while you were in %s`2','`2Vous avez �t� vainqueur d\'un combat a %s`2','admin','1.0.3'),
('fr','mail','`@No one was found who matches \"%s\".  ','`@Personne n\'a �t� trouv� correspondant � \"%s\".  ','Sunnygirl','1.0.5'),
('fr','mail','`^%s`2 attacked you while you were in %s`2, but you were victorious!`n`nYou received `^%s`2 experience and `^%s`2 gold!`0','`^%s`2 vous a attqu� a %s`2, mias vous avez gagn�.`n`nVous recevez pour cette victoire `^%s`2 points d\'experience et `^%s`2 pieces d\'or!`0','admin','1.0.3'),
('fr','mail','`^%s`2 attacked you while you were in %s`2, but you were victorious!`n`nYou received `^%s`2 experience and `^%s`2 gold!`n%s`n`0','`^%s`2 vous a attaqu� dans %s`2, mais vous avez �t� victorieux!`n`nVous recevez pour cette grande victoire `^%s`2 points d\'exp�rience et `^%s`2 pieces d\'or!`n%s`n`0','ordicbm','1.0.5'),
('fr','mail','`^You have received a money transfer!`0','`^Vous avez re�u un virement!`0','zveno','1.0.5'),
('fr','mail','`b`#NEW`b`n','`b`#Nouvelle`b`n','admin','1.0.3'),
('fr','mail','`b`2Address:`b`n','`b`2Adresse:`b`n','Sunnygirl','1.0.5'),
('fr','mail','`b`2From:`b `^%s`n','`b`2De:`b `^%s`n','admin','1.0.3'),
('fr','mail','`b`2Sent:`b `^%s`n','`b`2Post� le:`b `^%s`n','admin','1.0.3'),
('fr','mail','`b`2Subject:`b `^%s`n','`b`2Sujet:`b `^%s`n','admin','1.0.3'),
('fr','mail','`b`iMail Box`i`b','`b`iBo�te aux lettres`i`b`n','zveno','1.0.5'),
('fr','mail','`i(No Subject)`i','pas de sujet','admin','1.0.3'),
('fr','mail','`iAww, you have no mail, how sad.`i','`iVous n\'avez aucun mail.`i','Sunnygirl','1.0.5'),
('fr','mail','`i`^System`0`i','`i`^Grand Ordinateur`0`i','zveno','1.0.5'),
('fr','mail','`n`n`iYou currently have %s messages in your inbox.`nYou will no longer be able to receive messages from players if you have more than %s messages in your inbox.  `nMessages are automatically deleted (read or unread) after %s days','`n`n`iVous avez actuellement %s messages dans votre bo�te de r�ception.`nVous ne pourrez plus recevoir de messages d\'autres joueurs si jamais votre boite de r�ception venait � d�passer le nombre maximum de %s messages.  `nLes messages sont effac�s automatiquement (qu\'ils soient lus ou non) apr�s %s jours.','Monyss','1.0.3'),
('fr','mail','`n`n`iYou currently have %s messages in your inbox.`nYou will no longer be able to receive messages from players if you have more than %s messages in your inbox.  `nMessages are automatically deleted (read or unread) after %s days.','`n`n`iVous avez en ce moment %s messages dans votre boite au lettres.`nVous ne pourrez plus recevoir de nouveaux messages si vous en avez plus de %s dans votre boite.  `nLes messages sont supprim�s (lu ou non lus) apr�s %s jours.','admin','1.0.3'),
('fr','mail','`n`n`iYou currently have %s messages in your inbox.`nYou will no longer be able to receive messages from players if you have more than %s unread messages in your inbox.  `nMessages are automatically deleted (read or unread) after %s days.','`n`n`iVous avez %s messages dans votre boite.`nVous ne pourrez plus recevoir de messages des autres joueurs si vous d�passez %s messages non lus.`nLes messages (lus et non lus) seront automatiquement supprim�s au bout de %s jours.','admin','1.0.5');