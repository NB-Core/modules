12-21-2005 Verified Uploader:admin Time:15:31:30
('fr','module-tucker','Choose your weapon','Choisissez votre arme','Sunnygirl','1.0.5'),
('fr','module-tucker','He reaches into the bag on his belt and hands you a `5gem!`n`n','Il fouille dans le sac accroch� � sa ceinture et vous donne `5 gemmes!`n`n','Sunnygirl','1.0.5'),
('fr','module-tucker','Play his game','Jouer � son jeu','Sunnygirl','1.0.5'),
('fr','module-tucker','Very puzzled, you remember a child\'s story your grandma used to tell you, about the infamous Tucker Prince.','Vraiment perplexe, vous vous souvenez d\'un veille histoire sur l\'inf�me Prince Tucker que vous racontait votre grand m�re quand vous �tiez enfant.','Vorkosigan','1.0.3'),
('fr','module-tucker','`@With these words he heads off, depression written all over his face.','`@Sur ces mots il se dirige au loin, la d�pression peinte sur son visage.','Sunnygirl','1.0.5'),
('fr','module-tucker','`@You decide to talk to the dwarf.`n`n','`@Vous d�cidez de parler au nain.`n`n','Sunnygirl','1.0.5'),
('fr','module-tucker','points','points','Sunnygirl','1.0.5');