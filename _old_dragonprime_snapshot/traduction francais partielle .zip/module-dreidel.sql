12-21-2005 Verified Uploader:admin Time:15:23:52
('fr','module-dreidel','Another child sees you watching, and invites you to play.`n`n','Un autre enfant vous voit regarder et vous invite � jouer.`n`n','Sunnygirl','1.0.5'),
('fr','module-dreidel','Peanut Stall','Comptoir d\'Arachides','Sunnygirl','1.0.5'),
('fr','module-dreidel','`&`c`bDreidel Games`b`c`n','`&`c`bJeux de Dreidel`b`c`n','Sunnygirl','1.0.5'),
('fr','module-dreidel','`3You don\'t have any peanuts to play with, at the moment.','`3En ce moment, vous n\'avez aucunes arachides avec lesquelles jouer.','Sunnygirl','1.0.5'),
('fr','module-dreidel','`7He smiles.`n`n','`7Il sourit.`n`n','Sunnygirl','1.0.5'),
('fr','module-dreidel','`7Several children are grouped in small circles around the peanut stall.','`7Plusieurs enfants sont group�s en petits cerclers autour du comptoir d\'arachides.','Sunnygirl','1.0.5'),
('fr','module-dreidel','`7She smiles.`n`n','`7Elle sourit.`n`n','Sunnygirl','1.0.5'),
('fr','module-dreidel','`7You smile and take half the pot leaving %s in the pot.`n`n','`7Vous souriez et prenez la moiti� de ce qu\'il y a dans le pot, y laissant %s.`n`n','Sunnygirl','1.0.5'),
('fr','module-dreidel','`7You upend a bag of the red sweets into your mouth, and grin at the flavor.`n`n','`7Vous videz un sac de bonbons rouges dans votre bouche et grimacez au go�t.`n`n','Sunnygirl','1.0.5'),
('fr','module-dreidel','`7You upend the rest of the red sweets into your mouth, and grin at the flavor.`n`n','`7Vous prenez le restant des bonbons rouge dans votre bouche et grimacez au go�t.`n`n','Sunnygirl','1.0.5');