12-21-2005 Verified Uploader:admin Time:15:23:52
('fr','module-pinata','You feel `&PERCEPTIVE!`0`n`n','Vous vous sentez `&PERCEPTIF!`0`n`n','Sunnygirl','1.0.5'),
('fr','module-pinata','`^You find a `%GEM`^!','`^Vous trouvez une `%GEMME`^!','Sunnygirl','1.0.5');