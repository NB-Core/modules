12-21-2005 Verified Uploader:admin Time:15:23:52
('fr','claneditor','Clan Listing','Liste des Clans','Sunnygirl','1.0.5'),
('fr','claneditor','Clans','Clans','Sunnygirl','1.0.5'),
('fr','claneditor','This is the clans current membership:`n','Liste actuelle des membres des clans:`n','zveno','1.0.5'),
('fr','claneditor','`&Leader`0','`&Chef`0','Sunnygirl','1.0.5'),
('fr','claneditor','`&`bCurrent Description:`b `#by %s`2`n','`&`bDescription Actuelle:`b `#par %s`2`n','Sunnygirl','1.0.5'),
('fr','claneditor','`b`&Name of Clan`b','`b`&Nom du Clan`b','Sunnygirl','1.0.5');