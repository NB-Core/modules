12-21-2005 Verified Uploader:admin Time:15:23:52
('fr','module-prizemount','Cr�ation Magique: Golem d\'os','Cr�ation Magique: Golem d\'os','Sunnygirl','1.0.5'),
('fr','module-prizemount','Cr�ature D�moniaque: Vrock','Cr�ature D�moniaque: Vrock','Sunnygirl','1.0.5'),
('fr','module-prizemount','Cr�ature Fantastique: P�gase','Cr�ature Fantastique: P�gase','Sunnygirl','1.0.5'),
('fr','module-prizemount','Cr�ature Fantastique: Satyre','Cr�ature Fantastique: Satyre','Sunnygirl','1.0.5'),
('fr','module-prizemount','Cr�ature Souterraine: Assassin Elfe Noir','Cr�ature Souterraine: Assassin Elfe Noir','Sunnygirl','1.0.5'),
('fr','module-prizemount','Cr�ature de la for�t: Ent','Cr�ature de la for�t: Ent','Sunnygirl','1.0.5'),
('fr','module-prizemount','Cr�ature �l�mentaire: Para-�l�mentaire de Magma','Cr�ature �l�mentaire: Para-�l�mentaire de Magma','Sunnygirl','1.0.5'),
('fr','module-prizemount','Cr�ature �l�mentaire: �l�mentaire de l\'Air','Cr�ature �l�mentaire: �l�mentaire de l\'Air','Sunnygirl','1.0.5'),
('fr','module-prizemount','Horses: licorne','Chevaux: Licorne','Sunnygirl','1.0.5');