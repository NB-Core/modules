12-21-2005 Verified Uploader:admin Time:15:23:52
('fr','module-drunkard','As you stand up, you catch %s\'s`5 eye and receive a big smile for your kindness.','Alors que vous vous relevez, vous captez un regard de %s`5 et recevez un grand sourire pour votre gentillesse.','Sunnygirl','1.0.5'),
('fr','module-drunkard','You escort him over to a chair where he can sit without running into everyone else.','Vous l\'escortez jusqu\'� une chaise pour qu\'il puisse s\'y asseoir sans foncer dans tout le monde.','Sunnygirl','1.0.5'),
('fr','module-drunkard','`5A very drunk patron stumbles into you as you make your way across the crowded room.`n`n','`5Un patron tr�s ivre tr�buche et tombe sur vous alors que vous tentez de faire votre chemin dans la pi�ce achaland�e.`n`n','Sunnygirl','1.0.5'),
('fr','module-drunkard','`5Fortunately his glass was already empty.','`5Heureusement son verre �tait d�j� vide.','Sunnygirl','1.0.5'),
('fr','module-drunkard','`n`n`&You `$lose 1`& charm point.','`n`n`&Vous `$perdez 1`& points de charme.','Monyss','1.0.3'),
('fr','module-drunkard','`n`n`&You gain `^1`& charm.','`n`n`&Vous gagnez `^1`& point de charme.','Sunnygirl','1.0.5');