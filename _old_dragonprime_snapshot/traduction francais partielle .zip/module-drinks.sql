12-21-2005 Verified Uploader:admin Time:15:23:52
('fr','module-drinks',' ?%s  (`^%s`0 gold)',' ?%s (`^%s`0 pi�ces)','Sunnygirl','1.0.5'),
('fr','module-drinks','Add a drink','Ajouter une boisson','Sunnygirl','1.0.5'),
('fr','module-drinks','`#`$Hot Hands `7(%s rounds left)`n','`#`$Mains chaudes `7(%s tours restant)`n','Sunnygirl','1.0.5'),
('fr','module-drinks','`n`n`7You now feel %s.`n`n','`n`n`7Vous vous sentez maintenant %s.`n`n','Sunnygirl','1.0.5'),
('fr','module-drinks','almost drunk','presque ivre','Sunnygirl','1.0.5'),
('fr','module-drinks','almost unconscious','presque inconscient','Sunnygirl','1.0.5'),
('fr','module-drinks','barely buzzed','un peu �tourdi','Sunnygirl','1.0.5'),
('fr','module-drinks','barely drunk','� peine ivre','Sunnygirl','1.0.5'),
('fr','module-drinks','hammered','assom�','Sunnygirl','1.0.5'),
('fr','module-drinks','pleasantly buzzed','agr�ablement �tourdi','Sunnygirl','1.0.5'),
('fr','module-drinks','quite sober','plut�t sobre','Sunnygirl','1.0.5'),
('fr','module-drinks','really hammered','tr�s assom�','Sunnygirl','1.0.5'),
('fr','module-drinks','solidly drunk','tr�s ivre','Sunnygirl','1.0.5');