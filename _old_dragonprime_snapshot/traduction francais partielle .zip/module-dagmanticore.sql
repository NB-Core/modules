12-21-2005 Verified Uploader:admin Time:15:23:52
('fr','module-dagmanticore','%s defeated a Manticore on the trails! The victims have been avenged!','%s a vaincu un Manticore en cours de route. Ses victimes ont �t� veng�es!','zveno','1.0.5'),
('fr','module-dagmanticore','Return to the News','Retourner aux Nouvelles','zveno','1.0.5'),
('fr','module-dagmanticore','You quickly flee the scene, hoping to avoid the rest of the pack.`n`n','Vous fuyez rapidement la sc�ne en esp�rant �viter le reste du groupe.`n`n','Sunnygirl','1.0.5'),
('fr','module-dagmanticore','`#`$Manticore Spikes `7(%s rounds left)`n','`#`$�pines de la Manticore `7(%s tours restants)`n','Sunnygirl','1.0.5');