12-21-2005 Verified Uploader:admin Time:15:23:52
('fr','badnav','Error','Erreur','admin','1.0.3'),
('fr','badnav','You are attempting to use a module which is no longer active, or has been uninstalled.','Vous avez tenter d\'acceder a un module inactiv� ou non install�.','admin','1.0.3'),
('fr','badnav','Your Navs Are Corrupted','Vos Navs sont corrompus','Monyss','1.0.3'),
('fr','badnav','Your navs are corrupted, please return to %s.','Votre demande est incomprise, retourner SVP a %s','admin','1.0.3');