12-21-2005 Verified Uploader:admin Time:15:23:52
('fr','donation','Add Donation','Faire un Don','Monyss','1.0.3'),
('fr','donation','Donator\'s Page','Page des donateurs','Monyss','1.0.3'),
('fr','donation','Name','Nom','Sunnygirl','1.0.5');