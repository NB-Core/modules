12-21-2005 Verified Uploader:admin Time:15:23:52
('fr','module-racecat','Felyne','F�line','admin','1.0.2'),
('fr','module-racecat','Fortunately your felyne athleticism lets you escape unscathed.`n','Heureusement la forme athletique de votre race de feline vous permet de vous echapper.`n','admin','1.0.3'),
('fr','module-racecat','You gain extra defense!`n','Vous gagnez de la d�fense!`n','Sunnygirl','1.0.5'),
('fr','module-racecat','`#`@Cat-like Reflexes`0`n','`#`@Reflexes de F�lin`0`n','admin','1.0.0'),
('fr','module-racecat','`&Your Felyne senses tingle, and you notice a `%gem`&!`n`0','`&Vos pouvoirs de F�line vous alerte, vous sentez une `%gemme`&!`n`0','admin','1.0.2');