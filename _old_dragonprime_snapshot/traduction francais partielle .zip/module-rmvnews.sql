12-21-2005 Verified Uploader:admin Time:15:23:52
('fr','module-rmvnews','Remove News','Retirer les Nouvelles','Sunnygirl','1.0.5'),
('fr','module-rmvnews','`#Are you sure that you wish to remove all news entries for this character?','`#�tes-vous sur de vouloir effacer toutes les nouvelles entr�es pour ce personnage?','Sunnygirl','1.0.5');