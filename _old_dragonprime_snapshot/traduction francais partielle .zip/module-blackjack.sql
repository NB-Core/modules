12-21-2005 Verified Uploader:admin Time:15:23:52
('fr','module-blackjack','Bet %s again','Miser %s encore','admin','1.0.4'),
('fr','module-blackjack','Change your Bet','Changer votre mise','admin','1.0.4'),
('fr','module-blackjack','Hit','tire une carte','admin','1.0.3'),
('fr','module-blackjack','Play Something Else','Jouer a autre chose','admin','1.0.4'),
('fr','module-blackjack','Stay','Servi','admin','1.0.3'),
('fr','module-blackjack','`4Bust!','`4D�pass�!','admin','1.0.4'),
('fr','module-blackjack','`4You must place a bet to play!`n','`4Vous devez placer un pari pour jouer!`n','Sunnygirl','1.0.5'),
('fr','module-blackjack','`@`cStake: %s gold`c','`@`cMise: %s pieces d\'or`c','admin','1.0.4'),
('fr','module-blackjack','`n`2Push! Playing Again.`n','`n`2Egalit�! Jouer encore.`n','admin','1.0.4'),
('fr','module-blackjack','`n`3You win %s gold!`n','`n`3Vous gagnez %s pieces!`n','admin','1.0.3'),
('fr','module-blackjack','`n`4You loose %s gold!`n','`n`4Vous perdez %s pieces!`n','admin','1.0.4'),
('fr','module-blackjack','`n`n`2Dealers Hand: ','`n`n`2Casino main:','admin','1.0.4'),
('fr','module-blackjack','`n`n`2Your Hand: ','`n`n`2Votre main:','admin','1.0.4');