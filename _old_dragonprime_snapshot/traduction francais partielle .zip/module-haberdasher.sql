12-21-2005 Verified Uploader:admin Time:15:23:52
('fr','module-haberdasher','You ask him, \"`3What would a hat do?`7\"','Vous lui demandez: \"`3Que me donnerait d\'acheter un chapeau?`7\"','Sunnygirl','1.0.5'),
('fr','module-haberdasher','Your hat, grand as it is, could stand some improving.','Votre chapeau, aussi beau soit-il, peut �tre encore am�lior�.','zveno','1.0.5'),
('fr','module-haberdasher','`$Deimos`7 looks at you and your hat and says, \"`$I suppose you\'re right.','`$Deimos`7 vous regarde puis jette un bref coup d\'oeil � votre chapeau avant de dire: \"`$Je suppose que vous avez raison.','Sunnygirl','1.0.5'),
('fr','module-haberdasher','`7How much gold do you want to spend on your hat?`n','`7Combien de pi�ces d\'or souhaitez-vous d�penser sur votre chapeau?`n','Sunnygirl','1.0.5'),
('fr','module-haberdasher','`7You have a size `@%s `7hat.','`7Vous avez un chapeau de taille `@%s.','Sunnygirl','1.0.5'),
('fr','module-haberdasher','`7You inform `$Deimos`7 that you want a bigger hat.`n`n','`7Vous informez `$Deimos`7 que vous voulez un chapeau plus grand.`n`n','zveno','1.0.5'),
('fr','module-haberdasher','`7You step into a respectable building, and see `$Deimos`7 hard at work on a hat, as usual.','`7Vous p�n�trez dans un large b�timent, et voyez `$Deimos`7 travailler d\'arrache-pied sur un chapeau, comme d\'habitude.','Vorkosigan','1.0.3'),
('fr','module-haberdasher','`^Hat Size: `@%s`n','`^Taille du Chapeau: `@%s`n','Monyss','1.0.3'),
('fr','module-haberdasher','`n`nYou find a hat nearby, somewhat burnt, but still wearable.','`n`nTout pr�s, vous trouvez un chapeau, quelque peu br�l�, mais encore portable.','Sunnygirl','1.0.5');