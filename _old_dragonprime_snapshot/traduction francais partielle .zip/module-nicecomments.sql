12-21-2005 Verified Uploader:admin Time:15:23:52
('fr','module-nicecomments','her','sa','Uriell','1.0.5'),
('fr','module-nicecomments','his','son','Uriell','1.0.5');