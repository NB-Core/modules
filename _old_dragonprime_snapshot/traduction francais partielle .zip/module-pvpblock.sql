12-21-2005 Verified Uploader:admin Time:15:23:52
('fr','module-pvpblock','PvP Notice!','PVP Annonce!','admin','1.0.3'),
('fr','module-pvpblock','You are in DK band `^%s`@ and `&%s`0 is in DK band `^%s`@!','Votre bande est de `^%s`0 et `&%s`0 est dans la bande DK de `^%s`@!','admin','1.0.3'),
('fr','module-pvpblock','`#`@PvP Revenge `7(%s rounds left)`n','`#`@PvP p�nalit� `7(%s tours encore)`n','admin','1.0.4'),
('fr','module-pvpblock','`@You are not allowed to attack users outside of your DK band!`n','`@Vous n\'etes pas autoris� a attaquer des joueurs qui sont dans une tranche de DK differente a la votre!`n','ordicbm','1.0.3'),
('fr','module-pvpblock','`n`%Shame on you! You really could have hurt `&%s`0`%.','`n`%Tant pis pour vous. vous ne pourrez pas attaquer `&%s`0`%.','admin','1.0.3'),
('fr','module-pvpblock','`n`%Your conscience haunts you...','`n`%Votre conscience vous hante.....','admin','1.0.3'),
('fr','module-pvpblock','`n`^You empty your purse completely, to assuage your conscience.','`n`^Vous videz votre bourse completement pour la calmer.','admin','1.0.3'),
('fr','module-pvpblock','`n`^You empty your purse of `@%s`^ gold to assuage your conscience.','`n`^Vous videz votre bourse de `@%s`^ piece pour la soulager.','admin','1.0.3');