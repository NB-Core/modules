12-21-2005 Verified Uploader:admin Time:15:23:52
('fr','module-pointstransfer','Send these points anonymously','Envoyer ces points anonymement','Sunnygirl','1.0.5'),
('fr','module-pointstransfer','`n`nAnonymous Transfer: `&%s`7','`n`nTransfert Anonyme: `&%s`7','Sunnygirl','1.0.5');