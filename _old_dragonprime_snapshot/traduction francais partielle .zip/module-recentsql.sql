12-21-2005 Verified Uploader:admin Time:15:23:52
('fr','module-recentsql','Recent PHP','Modif PHP recente','admin','1.0.0'),
('fr','module-recentsql','Recent SQL','Changement SQL recent','admin','1.0.0');