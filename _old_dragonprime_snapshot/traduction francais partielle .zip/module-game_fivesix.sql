12-21-2005 Verified Uploader:admin Time:15:23:52
('fr','module-game_fivesix','%s won %s gold after rolling 3 sixes in the %s.','%s a gagn� %s pi�ces d\'or grace � un triple six � %s.','zveno','1.0.5'),
('fr','module-game_fivesix','Last jackpot winner','Dernier gagnant du gros lot','Sunnygirl','1.0.5'),
('fr','module-game_fivesix','Play Sixes Dice Game','Jouer au jeu � Six D�s','Monyss','1.0.3'),
('fr','module-game_fivesix','The old man cackles.  You rolled %s %s...but that\'s not enough!`n`n','Le vieil homme caquette. Vous avez roul� %s %s... mais ce n\'est pas assez!`n`n','Sunnygirl','1.0.5'),
('fr','module-game_fivesix','`%\"I think you\'ve had enough for today.  Why don\'t you come back tomorrow?\"','`%\"Je pense que cela suffit pour aujourd\'hui.Pourquoi ne pas revenir demain?\"','zveno','1.0.5'),
('fr','module-game_fivesix','`@The jackpot has never been won - you could be the first!`n`n','`@Le jackpot n\'a jamais �t� gagn� - Serez-vous le premier!`n`n','admin','1.0.2'),
('fr','module-game_fivesix','`^It only costs you %s gold to play, and the current jackpot is %s gold pieces.`n`n','`^La partie coute seulement %s pieces d\'or pour jouer, et l\'actuel Jackpot est de %s pieces d\'or.`n`n','admin','1.0.2'),
('fr','module-game_fivesix','`^The old man hands you %s gold.','`^Le vieil homme vous donne %s pi�ces.','Sunnygirl','1.0.5');