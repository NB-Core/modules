12-21-2005 Verified Uploader:admin Time:15:31:30
('fr','module-translationwizard','Author','Auteur','Sunnygirl','1.0.5'),
('fr','module-translationwizard','Check all','Cocher tout','Sunnygirl','1.0.5'),
('fr','module-translationwizard','Delete','Effacer','Sunnygirl','1.0.5'),
('fr','module-translationwizard','Delete selected','Effacer la s�lection','Sunnygirl','1.0.5'),
('fr','module-translationwizard','Language','Langue','Monyss','1.0.3'),
('fr','module-translationwizard','Module','Module','Sunnygirl','1.0.5'),
('fr','module-translationwizard','Save','Sauvegarder','Sunnygirl','1.0.5'),
('fr','module-translationwizard','Uncheck all','D�cocher tout','Sunnygirl','1.0.5'),
('fr','module-translationwizard','`0There are %s entries who already have a translation in the translations table.`n`n','`0Il y a %s entr�es qui ont d�j� une traduction dans la table des traductions.`n`n','Sunnygirl','1.0.5'),
('fr','module-translationwizard','`^`cThere are `&%s`^ untranslated texts in the database.`c`n`n','`^`cIl y a `&%s`^ textes qui n\'ont pas �t� traduits dans la base de donn�es.`c`n`n','Sunnygirl','1.0.5'),
('fr','module-translationwizard','`bSwitch to %s view`b','`bBasculer %s vue`b','admin','1.0.5');