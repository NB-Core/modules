12-21-2005 Verified Uploader:admin Time:15:23:52
('fr','module-extlinks','Link 1','Lien 1','Sunnygirl','1.0.5'),
('fr','module-extlinks','Link 5','Lien 5','Sunnygirl','1.0.5'),
('fr','module-extlinks','LoGD Main Forums','LoGD Forums Principaux','Sunnygirl','1.0.5'),
('fr','module-extlinks','URL for Link 2','URL pour Lien 2','Sunnygirl','1.0.5');