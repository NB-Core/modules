12-21-2005 Verified Uploader:admin Time:15:23:52
('fr','module-riddles','Answer','R�ponse','zveno','1.0.5'),
('fr','module-riddles','Author','Auteur','Sunnygirl','1.0.5'),
('fr','module-riddles','Delete','Supprimer','zveno','1.0.5'),
('fr','module-riddles','Edit','Editer','zveno','1.0.5'),
('fr','module-riddles','He was a little bit creepy anyway.`n','De toute fa�on, il n\'�tait pas vraiment rassurant.`n','zveno','1.0.5'),
('fr','module-riddles','Id','N�','zveno','1.0.5'),
('fr','module-riddles','No','Non','zveno','1.0.5'),
('fr','module-riddles','Ops','Action','zveno','1.0.5'),
('fr','module-riddles','Riddle','�nigme','Sunnygirl','1.0.5'),
('fr','module-riddles','Riddle Editor','Enigmes editeur','admin','1.0.3'),
('fr','module-riddles','`6The strange gnome giggles hysterically as he disappears into the forest.','`6L\'�trange petit gnome ricanne comme un fou en disparaissant dans les fourr�s.','zveno','1.0.5'),
('fr','module-riddles','`6`nA short little gnome with leaves in his hair squats beside a small tree.','`6`nUn petit gnome avec des feuilles dans les cheveux est accroupi pr�s d\'un arbuste.','zveno','1.0.5'),
('fr','module-riddles','`6`nDo you accept his challenge?`n`n','`3Attention, pour le moment les enigmes ne sont pas traduites et sont assez difficiles. a vous de voir!!!!`n`n
`6Acceptez-vous le d�fi?`n`n','zveno','1.0.5'),
('fr','module-riddles','`^He gives you `%two gems`^!','`^Il vous donne `%deux gemmes`^!','Sunnygirl','1.0.5'),
('fr','module-riddles','`n`6Afraid to look the fool, you decline his challenge.','`n`6Ne d�sirant pas para�tre idiot, vous refusez la comp�tition.','zveno','1.0.5');