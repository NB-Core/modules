12-21-2005 Verified Uploader:admin Time:15:23:52
('fr','module-racevamp','D?Go to Deus Nocturnem','D?Aller � Deus Nocturnem','Monyss','1.0.3'),
('fr','module-racevamp','Go to Deus Nocturnem','Aller � Deus Nocturnem','admin','1.0.3'),
('fr','module-racevamp','`#`@Vampiric Elders`0`n','`#`@Forces antiques des vampires`0`n','Uriell','1.0.5'),
('fr','module-racevamp','`$V`4ampire`0','`$V`4ampire`0','Sunnygirl','1.0.5'),
('fr','module-racevamp','`^As a Vampire, you feel the powers of old, coursing in your veins.`nYou gain extra attack!','`^�tant Vampire, vous sentez le pouvoir des anciens couler dans vos veines.`nVous gagnez de l\'attaque suppl�mentaire!','Sunnygirl','1.0.5');