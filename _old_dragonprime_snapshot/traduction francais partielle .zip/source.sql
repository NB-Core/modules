12-21-2005 Verified Uploader:admin Time:15:31:30
('fr','source','View Source: ','Voir la Source:','Sunnygirl','1.0.5'),
('fr','source','� This file cannot be viewed: %s','- Ce document ne peut pas �tre vu: %s','Sunnygirl','1.0.5');