12-21-2005 Verified Uploader:admin Time:15:23:52
('fr','module-calletrader','He smiles and asks, `&\"And how can I be of assistance?\"','Il sourit et demande: `&\"Et comment puis-je vous aider?\"','Sunnygirl','1.0.5'),
('fr','module-calletrader','T?Buy Ticket to %s (`^%s gold`0)','Acheter un Billet pour %s (`^%s pi�ces`0)','Sunnygirl','1.0.5'),
('fr','module-calletrader','V?Vernon\'s Trade Stall','V?Comptoir commercial de Vernon','Sunnygirl','1.0.5'),
('fr','module-calletrader','Vernon\'s Trade Stall','Comptoir commercial de Vernon','Sunnygirl','1.0.5'),
('fr','module-calletrader','`&`c`bVernon, the Trader`b`c','`&`c`bVernon le commer�ant`b`c','Sunnygirl','1.0.5'),
('fr','module-calletrader','`7You walk up to Vernon\'s stall, to see what he has to offer today.','`7Vous marchez jusqu\'au comptoir de Vernon pour voir ce qu\'il a � offrir aujourd\'hui.','Sunnygirl','1.0.5'),
('fr','module-calletrader','`n`n`7Vernon shrugs, `&\"I don\'t seem to have anything you need today!\"','`n`n`7Vernon �ructe, `&\"Je n\'ai rien � vous proposer aujourd\'hui!\"','Sunnygirl','1.0.5');