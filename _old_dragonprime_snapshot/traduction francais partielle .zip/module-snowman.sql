12-21-2005 Verified Uploader:admin Time:15:23:52
('fr','module-snowman','`#`QFirst Prize `7(%s rounds left)`n','`#`QPremier Prix `7(%s tours restants)`n','Sunnygirl','1.0.5');