12-21-2005 Verified Uploader:admin Time:15:31:30
('fr','module-vessaclan','Buy Gems - %s gp','Acheter des gemmes - %s pieces','admin','1.0.4'),
('fr','module-vessaclan','Inquire Closer','Demander des renseignements','admin','1.0.4'),
('fr','module-vessaclan','Sell Gems - %s gp','Vendre des gemmes - %s pieces','admin','1.0.4'),
('fr','module-vessaclan','Talk to others','Parler aux autres membres','admin','1.0.4'),
('fr','module-vessaclan','`@You walk to the desk, inquiring a bit closer about her services.`n','`@Vous vous approchez du comptoir pour avoir des pr�cisions sur ce qu\'elle peut vous offrir.\'n','zveno','1.0.5'),
('fr','module-vessaclan','`^Vessa `3informs you, \"`&I\'ve bought %s Gems from you today, and I\'ve sold you %s Gems.`3\"`n','`^Vessa `3vous informe que \"`&je vous ait vendu %s gemme ce jours et acheter %s.`3\"`n','admin','1.0.4'),
('fr','module-vessaclan','`^Vessa `3notes, \"`&I\'ve got %s Gems stocked for your Clan.`3\"`n','`^Vessa `3pr�cise \"`& J\'ai a la dispostion du clan %s gemmes.`3\"`n','admin','1.0.4'),
('fr','module-vessaclan','`^Vessa `3reminds you, \"`&You\'ve got enough money to buy `%%s`& more Gems.`3\"','`^Vessa `3vous rappelle: \"`&Vous avez assez d\'or pour acheter `%%s`& gemmes de plus.`3\"','Sunnygirl','1.0.5'),
('fr','module-vessaclan','`^Vessa `3says, \"`&Gems cost %s Gold, and I\'ll buy them from you for %s Gold.`3\"`n','`^Vessa `3dit: \"`&Les Gemmes co�tent %s Pi�ces d\'Or et je les rach�tent pour %s Pi�ces d\'Or.`3\"`n','Sunnygirl','1.0.5'),
('fr','module-vessaclan','`^Vessa `3specifies, \"`&I\'ll sell %s more Gems to you today, and I\'ll buy up to %s more Gems from you.`3\"`n','`^Vessa `3ajoute \"`&Je peux vendre %s gemmes par jours et peux acqu�rrir un maximum de %s gemmes par jour aussi.`3\"`n','admin','1.0.4'),
('fr','module-vessaclan','`^Vessa`& gives you %s Gold in return for %s Gems.','`^Vessa`& vous donne %s pi�ces d\'or pour les %s gemmes.','Sunnygirl','1.0.5');