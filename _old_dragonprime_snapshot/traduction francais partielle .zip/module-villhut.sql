12-21-2005 Verified Uploader:admin Time:15:31:30
('fr','module-villhut','Eat 1','En Manger 1','Sunnygirl','1.0.5'),
('fr','module-villhut','Eat 2','En Manger 2','Sunnygirl','1.0.5'),
('fr','module-villhut','Eat 3','En Manger 3','Sunnygirl','1.0.5'),
('fr','module-villhut','Eat 4','En Manger 4','Sunnygirl','1.0.5'),
('fr','module-villhut','H?Villager\'s Hut','H?La Hutte du Villageois','Sunnygirl','1.0.5'),
('fr','module-villhut','How many bags should you take?`n`n','Combien de sacs prendrez-vous?`n`n
','Sunnygirl','1.0.5'),
('fr','module-villhut','M?Return for More','Retourner pour en Prendre Plus','Sunnygirl','1.0.5'),
('fr','module-villhut','The residents obviously aren\'t home.`n`n','Les r�sidents ne sont �videmment pas � la maison.`n`n','Sunnygirl','1.0.5'),
('fr','module-villhut','Villager\'s Hut','Hutte du Villageois','Sunnygirl','1.0.5'),
('fr','module-villhut','Where does the hut appear','O� la hutte appara�t-elle?','Sunnygirl','1.0.5'),
('fr','module-villhut','You feel `@energized!`n`n','Vous vous sentez `@�nergis�!`n`n','Sunnygirl','1.0.5'),
('fr','module-villhut','You feel `@healthy!`n`n','Vous vous sentez en `@sant�!`n`n','Sunnygirl','1.0.5'),
('fr','module-villhut','You feel miserable, and `4lose `7some hitpoints.`n`n','Vous vous sentez mis�rable et vous `4perdez`7 quelques points de vie.`n`n','Sunnygirl','1.0.5'),
('fr','module-villhut','You stand there for a moment, wondering what to do.','Vous restez l� un instant, ne sachant pas quoi faire.','Sunnygirl','1.0.5'),
('fr','module-villhut','`&`c`bThe Villager\'s Hut`b`c','`&`c`bTLa Hutte du Villageois`b`c','Vorkosigan','1.0.3'),
('fr','module-villhut','`7\"`%Hello Children!`7\" it reads.`n`n','`7Il est �crit: \"`%Bonjour les Enfants!`7\" .`n`n','Sunnygirl','1.0.5');