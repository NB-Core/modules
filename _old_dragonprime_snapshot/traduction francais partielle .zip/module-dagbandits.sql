12-21-2005 Verified Uploader:admin Time:15:23:52
('fr','module-dagbandits','%s\'s body turned up, filled with arrows!','On retrouve le corps de %s cribl� de fl�ches!','zveno','1.0.5'),
('fr','module-dagbandits','Fight the Beast','Combattre la B�te','Sunnygirl','1.0.5'),
('fr','module-dagbandits','The Bandits\' Camp','Le Camp des Bandits','Sunnygirl','1.0.5'),
('fr','module-dagbandits','You gain %s experience!','Vous gagnez %s points d\'exp�rience!','Sunnygirl','1.0.5'),
('fr','module-dagbandits','You have killed 5 Bandits! You have completed the quest!','Vous avez tu� 5 Bandits! Vous avez compl�t� la qu�te!','Sunnygirl','1.0.5'),
('fr','module-dagbandits','You lose %s hitpoints!`n`n','Vous perdez %s points de vie!`n`n','Sunnygirl','1.0.5'),
('fr','module-dagbandits','You lose 10% of your experience, and your gold is stolen by the bandits!','Vous perdez 10% de votre exp�rience et votre or est vol�e par les bandits!','Sunnygirl','1.0.5'),
('fr','module-dagbandits','`%You have died!','`%Vous �tes mort!','Sunnygirl','1.0.5'),
('fr','module-dagbandits','`&%s`^ has been heard boasting about defeating a huge group of bandits!`0','`&%s`^ a �t� entendu entrain de se vanter d\'avoir tu� un �norme groupe de bandits!`0','Sunnygirl','1.0.5'),
('fr','module-dagbandits','`&You gain %s experience from this fight!`n`n','`&Vous gagnez %s points d\'exp�rience pour ce combat!`n`n','Sunnygirl','1.0.5'),
('fr','module-dagbandits','`2Do you want to keep searching for a bandit to kill, or flee the woods?.','`2Souhaitez-vous continuer � chercher un bandit � tuer ou voulez-vous fuir les bois?','Sunnygirl','1.0.5'),
('fr','module-dagbandits','`n`n`&You gain %s experience from this fight!','`n`n`&Vous gagnez %s points d\'exp�rience de ce combat!','Sunnygirl','1.0.5');