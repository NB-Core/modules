12-21-2005 Verified Uploader:admin Time:15:23:52
('fr','module-charrestore','After date: ','Apres date:','admin','1.0.3'),
('fr','module-charrestore','Restore a deleted char','Restorer un caract�re effac�','Sunnygirl','1.0.5');