12-21-2005 Verified Uploader:admin Time:15:23:52
('fr','module-testmodule','Catch your balance','Reprendre votre �quilibre','Sunnygirl','1.0.5'),
('fr','module-testmodule','Uninstalling this module.`n','D�sinstaller ce module.`n','Sunnygirl','1.0.5'),
('fr','module-testmodule','You stumble on a loose floor board.','Vous tr�buchez sur un panneau l�che du plancher.','Sunnygirl','1.0.5'),
('fr','module-testmodule','You wrinkle your nose at the stench of some garbage.','Vous froncez votre nez aux odeurs de quelques ordures.','admin','1.0.2'),
('fr','module-testmodule','`nAnd the game masters are playing around with the test module.`n','`nEt les ma�tres de jeu jouent autour avec le module d\'essai.`n','admin','1.0.1'),
('fr','module-testmodule','`nThis is a low priority hook on newday.`n','`nceci est une priorit� basse.`n','admin','1.0.2'),
('fr','module-testmodule','`nThis is a top priority hook on newday.`n','`nc\'est la priorit� haute pour ce jour.`n','admin','1.0.2');