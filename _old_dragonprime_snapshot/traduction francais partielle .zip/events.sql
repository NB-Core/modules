12-21-2005 Verified Uploader:admin Time:15:23:52
('fr','events','Name','Nom','admin','1.0.0'),
('fr','events','Travel','Voyage','Sunnygirl','1.0.5'),
('fr','events','`^`c`bSomething Special!`c`b`0','`^`c`bQuelque chose de sp�cial!`c`b`0','ordicbm','1.0.2');