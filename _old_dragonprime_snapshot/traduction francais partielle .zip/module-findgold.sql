12-21-2005 Verified Uploader:admin Time:15:23:52
('fr','module-findgold','Find Gold Event Settings','Param�tres de l\'�v�nement Trouver de l\'Or','Sunnygirl','1.0.5'),
('fr','module-findgold','Maximum gold to find (multiplied by level)','Maximum d\'or � trouver (multiplier par le niveau)','Sunnygirl','1.0.5'),
('fr','module-findgold','Minimum gold to find (multiplied by level)','Minimum d\'or � trouver (multiplier par le niveau)','Sunnygirl','1.0.5'),
('fr','module-findgold','`^Fortune smiles on you and you find %s gold!`0','`^La chance vous sourit et vous trouvez %s piece d\'or!`0','admin','1.0.2');