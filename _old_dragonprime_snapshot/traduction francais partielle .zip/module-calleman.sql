12-21-2005 Verified Uploader:admin Time:15:23:52
('fr','module-calleman','It reads, `@\"Admit One\".`n`n','Dessus il est �crit: `@Personnel.`n`n','admin','1.0.4'),
('fr','module-calleman','`&\"YES! It is you! YES!\"`n`n','`&\"OUI! C\'est bien vous! OUI!\"`n`n','admin','1.0.4'),
('fr','module-calleman','`7As you\'re chatting with the other villagers, a strange man approaches you and grabs your wrist.`n`n','`7Alors que vous discutez avec d\'autres guerriers de vos dernieres aventures, un �tranges bonhomme s\'approche du groupe, et vous regarde, tout exit�.`n`n','admin','1.0.4'),
('fr','module-calleman','`7He places a small piece of paper in your hand.','`7Il place un petit bout de papier dans votre main.','Sunnygirl','1.0.5'),
('fr','module-calleman','`7You\'ve no idea what it is for, but it might be useful, so you place it in your purse.','`7Vous ne savez pas � quoi �a sert, mais �a pourrait �tre utile, vous le mettez donc dans votre bourse.','Sunnygirl','1.0.5'),
('fr','module-calleman','`n`n`7Without another word, he walks away, mumbling to himself.`n','`n`n`7Sans un mot de plus, il part en marmonnant pour lui-m�me.`n','Sunnygirl','1.0.5');