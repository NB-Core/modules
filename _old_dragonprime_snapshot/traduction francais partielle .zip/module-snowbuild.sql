12-21-2005 Verified Uploader:admin Time:15:23:52
('fr','module-snowbuild','Disappointed, you head back to the other villagers.','D�sappoint�, vous retournez avec les autres villageois.','Sunnygirl','1.0.5'),
('fr','module-snowbuild','Snowman Building','Construction de Bonhommes de neige','Sunnygirl','1.0.5'),
('fr','module-snowbuild','`n`QAn almost lifelike snowman sits in the village, with a shiny placard reading \"`&%s`Q\".`n','`n`QUn etrange petit bonhomme est assis dans le village, avec une pancarte sur laquelle on peut lire \"`&%s`Q\".`n','admin','1.0.3');