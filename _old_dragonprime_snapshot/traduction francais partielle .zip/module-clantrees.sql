12-21-2005 Verified Uploader:admin Time:15:23:52
('fr','module-clantrees','Is the tree decoration competitive?','Est-ce le concours de d�coration d\'arbre?','Sunnygirl','1.0.5'),
('fr','module-clantrees','Many of the other halls, also sport beautifully decorated trees in their windows.`n','On peut aussi voir des arbres d�cor�s aux fen�tres de nombreuses autres habitations.`n','zveno','1.0.5'),
('fr','module-clantrees','`@Your tree is the best tree in the Clan Halls!`n','`@Votre arbre d�cor� est le meilleur de tous les clans!`n','admin','1.0.3'),
('fr','module-clantrees','`nMany of the clan hall windows sport beautifully decorated trees!`n','`nA plusieurs des fen�tres des clan brillent les arbres admirablement d�cor�s!','admin','1.0.2'),
('fr','module-clantrees','`nThe biggest, sparkliest, twinkliest tree belongs to the %s clan!`n','`nL\'arbre le plus imposant, le plus �tincelant et le plus remarquable est celui du clan de \"%s\"!`n','zveno','1.0.5'),
('fr','module-clantrees','`n`&Outside the Clan Halls you can see %s selling Christmas trees to clans!`n','`n`&A l\'ext�rieur des Habitats des Clans vous pouvez voir %s vendre des arbres de No�l aux clans!','zveno','1.0.5');