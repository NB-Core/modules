12-21-2005 Verified Uploader:admin Time:15:23:52
('fr','module-clannews','`n`n`b`&Recent News for %s:`b`0`n','`n`n`b`&Exploits r�cents des membres de %s:`b`0`n','admin','1.0.3');