12-21-2005 Verified Uploader:admin Time:15:23:52
('fr','module-cedrikspotions','Gems','Gemmes','Sunnygirl','1.0.5'),
('fr','module-cedrikspotions','`)Bits of skin and bone reshape themselves like wax.`0`n','\')Des bouts de peau et d\'os se remod�lent par eux-m�me comme de la cire.`0`n','Sunnygirl','1.0.5'),
('fr','module-cedrikspotions','hitpoint','points de vie','Sunnygirl','1.0.5');