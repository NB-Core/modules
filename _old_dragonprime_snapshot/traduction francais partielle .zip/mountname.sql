12-21-2005 Verified Uploader:admin Time:15:31:30
('fr','mountname','Your %s','Votre %s','admin','1.0.0'),
('fr','mountname','your %s','votre %s','admin','1.0.2');