12-21-2005 Verified Uploader:admin Time:15:31:30
('fr','petition','From','De','admin','1.0.0'),
('fr','petition','Petition for Help','Demande d\'aide','Sunnygirl','1.0.5'),
('fr','petition','Petitions about problems we already know about just take up time we could be using to fix those problems.`b`c`n','`b`c`n','admin','1.0.5'),
('fr','petition','Please be as descriptive as possible in your petition.','S\'il vous pla�t, soyez aussi descriptif que possible dans votre demande.','Sunnygirl','1.0.5'),
('fr','petition','Previous %s','Pr�c�dent %s','Sunnygirl','1.0.5'),
('fr','petition','Your Character\'s Name: ','Votre Nom de joueur:','admin','1.0.5'),
('fr','petition','`@Date: `^`b%s`b (%s)`n','`@Date: `^`b%s`b (%s)`n','Sunnygirl','1.0.5'),
('fr','petition','`c`b`$Before sending a petition, please make sure you have read the motd.`n','`c`b`$Avant d\'envoyer un dol�ance, soyez sur d\'avoir lu le MjD (Message du Jour).`n','Vorkosigan','1.0.3'),
('fr','petition','`nDescription of the problem:`n','`nDescription du probleme:`n','admin','1.0.5'),
('fr','petition','`nYour email address: ','`nVotre adresse mail:','admin','1.0.5');