12-21-2005 Verified Uploader:admin Time:15:31:30
('fr','module-timeplayed','`^Estimated Time Played: `@%s`n','`^Temps de jeu Estim�: `@%s`n','Monyss','1.0.3');