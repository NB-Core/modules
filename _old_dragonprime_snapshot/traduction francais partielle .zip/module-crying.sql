12-21-2005 Verified Uploader:admin Time:15:23:52
('fr','module-crying','`&You gain a charm point!','`&Vous gagnez un point de charme!','Sunnygirl','1.0.5');