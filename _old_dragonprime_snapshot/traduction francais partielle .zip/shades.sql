12-21-2005 Verified Uploader:admin Time:15:31:30
('fr','shades','Each bears telltale signs of the means by which they met their end.`n`n','Chacun soutient les signes indicateurs des moyens par lesquels ils ont rencontr� leur extr�mit�.`n`n','admin','1.0.0'),
('fr','shades','Everywhere around you are the souls of those who have fallen in battle, in old age, and in grievous accidents. ','Partout autour de vous sont les �mes de ceux qui sont tomb�es dans la bataille, dans le vieil �ge, et dans des accidents p�nibles.','admin','1.0.0'),
('fr','shades','FAQs (Frequently Asked Questions)','FAQ','admin','1.0.0'),
('fr','shades','Land of the Shades','Terre des fantomes','admin','1.0.0'),
('fr','shades','Log out','Quitter','admin','1.0.0'),
('fr','shades','Places','Position','admin','1.0.0'),
('fr','shades','Return to the news','Retour aux nouvelles','admin','1.0.0'),
('fr','shades','The Graveyard','Le Cimeti�re','admin','1.0.0'),
('fr','shades','Their souls whisper their torments, haunting your mind with their despair:`n','Leurs �mes chuchotent leurs tourments, hantant votre esprit avec leur d�sespoir:`n','admin','1.0.0'),
('fr','shades','`$You walk among the dead now, you are a shade. ','`$Vous marchez parmi les morts maintenant, vous �tes un fantome.','admin','1.0.0'),
('fr','shades','`nA sepulchral voice intones, \"`QIt is now %s in the world above.`$\"`n`n','`une voix d\'outre tombe dit \"`Q C\'est un nouveau jour dans %s dans le monde au dessus.`$\"`n`n','admin','1.0.2'),
('fr','shades','`n`QNearby, some lost souls lament:`n','`n`QTout pres, quelques guerriers perdus se lamentent:`n','admin','1.0.0');