12-21-2005 Verified Uploader:admin Time:15:23:52
('fr','module-collapse','%s','%s','Sunnygirl','1.0.5'),
('fr','module-collapse','New %s','Nouveau %s','zveno','1.0.5');