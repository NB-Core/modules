12-21-2005 Verified Uploader:admin Time:15:23:52
('fr','module-innchat','Frequently Asked Questions','questions frequemment pos�es','Sunnygirl','1.0.5'),
('fr','module-innchat','YOU','VOUS','Sunnygirl','1.0.5'),
('fr','module-innchat','dwarf tossing','lancer des nains en l\'air','Sunnygirl','1.0.5'),
('fr','module-innchat','loneliness in town','solitude dans la ville','Sunnygirl','1.0.5'),
('fr','module-innchat','today\'s weather','la temp�rature d\'aujourd\'hui','Sunnygirl','1.0.5');