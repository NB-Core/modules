12-21-2005 Verified Uploader:admin Time:15:23:52
('fr','module-lotgdutil','%s - %s - %s - %s - %s - %s - %s`n','%s - %s - %s - %s - %s - %s - %s`n','Monyss','1.0.3'),
('fr','module-lotgdutil','%s players have logged in so far today.`n','%s joueurs sont venus aujourd\'hui.`n','zveno','1.0.5'),
('fr','module-lotgdutil','Back to the grotto','Retour � la grotte','Sunnygirl','1.0.5'),
('fr','module-lotgdutil','`$No results found`0','`$Pas de r�sultats trouv�s`0','Sunnygirl','1.0.5'),
('fr','module-lotgdutil','`2Your LoTGD Installation contains %s lines of code.`n`0','`2Votre Installation de LoTGD contient %s lignes de code.`n`0','Monyss','1.0.3'),
('fr','module-lotgdutil','`b`2From:`b `^%s`n','`b`2De:`b `^%s`n','Sunnygirl','1.0.5');