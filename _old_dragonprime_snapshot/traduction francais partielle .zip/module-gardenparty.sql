12-21-2005 Verified Uploader:admin Time:15:23:52
('fr','module-gardenparty','There\'s a party going on!  It\'s a %s!','Il y a une f�te en ce moment! C\'est un %s!','Sunnygirl','1.0.5'),
('fr','module-gardenparty','What is Cedrik wearing?','Comment est habill� Cedrik','Monyss','1.0.3'),
('fr','module-gardenparty','When does the part start','Quand la f�te commence-t-elle?','Sunnygirl','1.0.5');