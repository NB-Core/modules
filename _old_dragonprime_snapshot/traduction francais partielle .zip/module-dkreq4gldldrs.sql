12-21-2005 Verified Uploader:admin Time:15:23:52
('fr','module-dkreq4gldldrs','Apply for a new Clan','Appliquer pour cr�er un nouveau Clan','Sunnygirl','1.0.5');