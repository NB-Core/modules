12-21-2005 Verified Uploader:admin Time:15:23:52
('fr','module-findgem','`^Fortune smiles on you and you find a `%gem`^!`0','`^La chance vous sourit et vous trouvez une `%gemme`^!`0','Sunnygirl','1.0.5'),
('fr','module-findgem','`^Fortune smiles on you and you find a gem!`0','`^La chance est avec vous, vous trouvez une gemme!`0','admin','1.0.2');