12-21-2005 Verified Uploader:admin Time:15:23:52
('fr','module-dragonattack','Attack the Dragon','Attaque le Dragon','admin','1.0.0'),
('fr','module-dragonattack','Days until player is a potential victim','Nb de jours avant que le joueur soit attaquable de nouveau','admin','1.0.0'),
('fr','module-dragonattack','You are utterly astounded to see a very large, very angry `@Green Dragon`2 winging right toward you!`n`n','Vous �tes tout � fait �tonn�s de voir un tr�s un grand, tr�s f�ch� `@Green Dragon`2 s\'envolant`n`n','admin','1.0.0');