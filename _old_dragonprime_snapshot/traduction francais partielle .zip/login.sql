12-21-2005 Verified Uploader:admin Time:15:23:52
('fr','login','Sending you to %s, have a safe journey','en allant a %s, vous voyagerez tranquille','admin','1.0.0'),
('fr','login','`4Error, your login was incorrect`0','`4Erreur, votre login est incorrect`0','admin','1.0.3');