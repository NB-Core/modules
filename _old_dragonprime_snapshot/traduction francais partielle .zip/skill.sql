12-21-2005 Verified Uploader:admin Time:15:31:30
('fr','skill','`#`&GOD MODE `7(%s rounds left)`n','`#`&Mode DIEU `7(%s tours encore)`n','admin','1.0.3'),
('fr','skill','`%`&`bYou feel godlike.`b`0`n','`%`&`bVous vous sentez meilleur.`b`0`n','admin','1.0.5'),
('fr','skill','`%`&`bYou feel godlike`b`0`n','`%`&`bVous etes beni des dieux`b`0`n','admin','1.0.2'),
('fr','skill','`)You feel mortal again.`0`n','`)Vous etes mortel de nouveau.`0`n','admin','1.0.2');