12-21-2005 Verified Uploader:admin Time:15:23:52
('fr','module-ella','Ella\'s Dance Studio','Studio de Danse d\'Ella','Sunnygirl','1.0.5'),
('fr','module-ella','Partnered and solo dancers sway and spin in fast rhythms, matching their movements to the piano that sings from one side of the room, where a delicate Felyne moves her paws to create the sound.`n`n','Des danseurs seuls ou en couples tournent et virevoltent, au rythme du piano qui joue depuis un coin de la pi�ce.Sur son clavier, une d�licate F�lyne fait jouer ses doigts.','Vorkosigan','1.0.3'),
('fr','module-ella','Your maximum hitpoints have permanently decreased.','Votre maximum de points de vie a diminu� de fa�on permanente.','Sunnygirl','1.0.5'),
('fr','module-ella','girl','fille','Sunnygirl','1.0.5'),
('fr','module-ella','turns','tours','Sunnygirl','1.0.5');