12-21-2005 Verified Uploader:admin Time:15:23:52
('fr','module-goblinhotel','G?The Goblin Hotel','G?l\'hotel goblin','admin','1.0.0');