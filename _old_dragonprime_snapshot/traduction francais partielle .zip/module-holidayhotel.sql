12-21-2005 Verified Uploader:admin Time:15:23:52
('fr','module-holidayhotel','%s','%s','Sunnygirl','1.0.5'),
('fr','module-holidayhotel','The bartender places a glass of red liquid in front of you.','Le barman d�pose un verre de liquide rouge en face de vous.','Sunnygirl','1.0.5'),
('fr','module-holidayhotel','The bartender places a glass of white lumpy liquid in front of you.','Le barman d�pose un verre de liquide blanc parsem� de grumeaux devant vous.','Sunnygirl','1.0.5'),
('fr','module-holidayhotel','`#Corpse Cocktail Buzz `7(%s rounds left)`n','`#Effets de Cocktail Cadav�rique `7(%s tours restants)`n','Sunnygirl','1.0.5');