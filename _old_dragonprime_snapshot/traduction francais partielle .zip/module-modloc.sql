12-21-2005 Verified Uploader:admin Time:15:23:52
('fr','module-modloc','Glorfindal','Glorfindal','Sunnygirl','1.0.5'),
('fr','module-modloc','Glukmoore','Glukmoore','Sunnygirl','1.0.5'),
('fr','module-modloc','Polareia Borealis','Polareia Borealis','Sunnygirl','1.0.5'),
('fr','module-modloc','Qexelcrag','Qexelcrag','Sunnygirl','1.0.5'),
('fr','module-modloc','Show Errors','Montrer les erreurs','Vorkosigan','1.0.3'),
('fr','module-modloc','�le du D�but','�le du D�but','Sunnygirl','1.0.5');