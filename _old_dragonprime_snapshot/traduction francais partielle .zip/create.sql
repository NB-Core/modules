12-21-2005 Verified Uploader:admin Time:15:23:52
('fr','create','Create your character','Cr�er votre personnage','Sunnygirl','1.0.5'),
('fr','create','Email me my password','Envoyez-moi mon mot de passe par Email','zveno','1.0.5'),
('fr','create','Enter your character\'s name: ','Entrer votre nom de joueur:','admin','1.0.0'),
('fr','create','Enter your email address: ','Entrer votre adresse mail:','admin','1.0.0'),
('fr','create','Re-enter it for confirmation: ','Re rentrer votre mot de passe:','admin','1.0.0'),
('fr','create','Your account was created, your login name is `^%s`0.`n`n','Votre compte est cr�e, votre nom est `^%s`0.`n`n','admin','1.0.3'),
('fr','create','Your password must be at least 4 characters long.`n','Votre mot de passe doit faire 4 caracteres au minimum.`n','admin','1.0.3'),
('fr','create','`#Could not locate a character with that name.','`#Impossible de trouver ce nom.','admin','1.0.3'),
('fr','create','`&`c`bCreate a Character`b`c`0','`&`c`bCr�er un Personnage`b`c`0','admin','1.0.0'),
('fr','create','`^Characters that have never been logged into will be deleted after %s day(s) of no activity.`n`0','`^Les joueurs qui ne se seront pas connect�es apres %s jours seront suprim�s de la base.`n`0','admin','1.0.3'),
('fr','create','`^Characters that have never reached level 2 will be deleted after %s days of no activity.`n`0','`^Les joueurs ayant atteint au maximum  le niveau 2 seront detruit apres %s jours d\'inactivit�s.`n`0','admin','1.0.3'),
('fr','create','`^Characters that have reached level 2 at least once will be deleted after %s days of no activity.`n`0','`^Les personnages ayant atteint ou d�pass� le niveau 2 seront �ffac�s apres %s jours d\'inactivit�.`n`0','admin','1.0.3');