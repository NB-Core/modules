12-21-2005 Verified Uploader:admin Time:15:23:52
('fr','gypsy','\"`!For you, %s, the price is a trifling `^%s`! gold.`5\", she rasps','\"`!Pour vous, %s, le prix a payer est de `^%s`! pieces d\'or `5\" dit elle.','admin','1.0.2'),
('fr','gypsy','\"`!For you, %s, the price is a trifling `^%s`! gold.`5\", she rasps.','\"`!Pour vous, %s, le prix est de `^%s`! pi�ces d\'or.`5\", dit elle.','Monyss','1.0.3'),
('fr','gypsy','All of them promise to let you talk with the deceased, and most of them surprisingly seem to work.','Tous les gitans promettent de vous laissez parler avec les d�funts, et la plupart d\'entre eux semble serieux, mais, celle ci a l\'air plus sur que les autres.','admin','1.0.2'),
('fr','gypsy','Forget it','Renoncer','admin','1.0.2'),
('fr','gypsy','Gypsy Seer\'s tent','Tente de la voyante','admin','1.0.2'),
('fr','gypsy','In a deep trance, you talk with the shades','En pleine transe, vous parlez avec les ombres des morts','Monyss','1.0.3'),
('fr','gypsy','In typical gypsy style, the old woman sitting behind a somewhat smudgy crystal ball informs you that the dead only speak with the paying.','Dans le mod�le gitan typique, la vieille femme s\'asseyant derri�re une boule en cristal quelque peu poussiereuse vous informe que les morts parlent seulement avec ceux qui paient leur obole.','admin','1.0.2'),
('fr','gypsy','Pay to talk to the dead (%s gold)','Payer pour parler au morts (%s pieces d\'or)','Sunnygirl','1.0.5'),
('fr','gypsy','There are also rumors that the gypsy have the power to speak over distances other than just those of the afterlife.','Il y a �galement des rumeurs que les boh�miens ont le pouvoir de parler au-dessus des distances autre que juste ceux de la vie apr�s la mort.','admin','1.0.2'),
('fr','gypsy','`5You duck into a gypsy tent like many you have seen throughout the realm.','`5Vous arrivez devant une tente de gitane qui semble sortit d\'un reve.','admin','1.0.2'),
('fr','gypsy','my handsome','mon beau','Vorkosigan','1.0.3'),
('fr','gypsy','my pretty','mon joli','Sunnygirl','1.0.5'),
('fr','gypsy','projects','projets','Sunnygirl','1.0.5');