12-21-2005 Verified Uploader:admin Time:15:23:52
('fr','module-jewelmonster','Gorgon','Gorgon','Sunnygirl','1.0.5'),
('fr','module-jewelmonster','With this humiliation, you lose `^%s `3experience.`0','En plus de l\'humiliation, vous perdez `^%s `3points d\'exp�rience.`0','Sunnygirl','1.0.5'),
('fr','module-jewelmonster','`3The fight earns you `^%s `3experience.`0','`3Le combat vous fait gagner `^%s `3points d\'exp�rience.`0','Sunnygirl','1.0.5');