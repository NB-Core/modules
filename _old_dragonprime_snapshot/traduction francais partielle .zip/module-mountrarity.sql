12-21-2005 Verified Uploader:admin Time:15:23:52
('fr','module-mountrarity','`n%s','`3%s','admin','1.0.2'),
('fr','module-mountrarity','`nA sign by the door proclaims that the following mounts are out of stock for today:','`nUn panneau juste a l\'entr�e indique que les cr�atures suivantes ne sont pas disponibles aujourd\'hui:`n`n','zveno','1.0.5');