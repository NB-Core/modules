12-21-2005 Verified Uploader:admin Time:15:23:52
('fr','module-changename','Other players','Autres Joueurs','Monyss','1.0.3'),
('fr','module-changename','What should we use as the basis for the newname?','Que devons-nous utilisez comme base pour le nouveau nom?','Sunnygirl','1.0.5'),
('fr','module-changename','`n`n`n`b`@Current player name:`0 %s `b','`n`n`n`b`@Nom du joueur:`0 %s `b','Vorkosigan','1.0.3');