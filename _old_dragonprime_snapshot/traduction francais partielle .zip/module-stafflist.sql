12-21-2005 Verified Uploader:admin Time:15:23:52
('fr','module-stafflist','Arbitrary ranking number (higher means higher on list)','Nombre pour place dans le listing (le plus haut chiffre est en tete de listing)','admin','1.0.3'),
('fr','module-stafflist','Description','Fonctions','admin','1.0.3'),
('fr','module-stafflist','Name','Nom','admin','1.0.3'),
('fr','module-stafflist','Online','En Ligne','admin','1.0.3'),
('fr','module-stafflist','Sex','Sexe','admin','1.0.3'),
('fr','module-stafflist','Staff List','Liste des Gestionnaires','Sunnygirl','1.0.5'),
('fr','module-stafflist','`!Male`0','`!Homme`0','zveno','1.0.5'),
('fr','module-stafflist','`$No`0','`$Non`0','admin','1.0.3'),
('fr','module-stafflist','`%Female`0','`%Femme`0','Uriell','1.0.5'),
('fr','module-stafflist','`@Yes`0','`@Oui`0','admin','1.0.3'),
('fr','module-stafflist','`c`b`@Staff List`0`b`c`n`n','`c`b`@Liste des gestionnaires`0`b`c`n`n','admin','1.0.3');