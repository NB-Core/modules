12-21-2005 Verified Uploader:admin Time:15:23:52
('fr','module-dagquests','Ask About Special Bounties','Questionner � Propos des Primes Sp�ciales','Sunnygirl','1.0.5'),
('fr','module-dagquests','I?Return to the Inn','Retourner � l\'Auberge','Sunnygirl','1.0.5'),
('fr','module-dagquests','The Boar\'s Head Inn','L\'Auberge de la T�te de Sanglier','Sunnygirl','1.0.5');