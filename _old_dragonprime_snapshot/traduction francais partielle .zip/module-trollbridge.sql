12-21-2005 Verified Uploader:admin Time:15:31:30
('fr','module-trollbridge','A mossy wooden bridge crosses the gap.','Un pont en bois moisi traverse le vide.','Sunnygirl','1.0.5'),
('fr','module-trollbridge','Cross the Bridge','Traverser le Pont','Sunnygirl','1.0.5'),
('fr','module-trollbridge','Return to %s','Retourner � %s','Sunnygirl','1.0.5'),
('fr','module-trollbridge','What will you do?','Qu\'allez-vous faire?','Sunnygirl','1.0.5');