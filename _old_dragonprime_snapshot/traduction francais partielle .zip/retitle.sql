12-21-2005 Verified Uploader:admin Time:15:31:30
('fr','retitle','Add a Title','Ajouter un Titre','Sunnygirl','1.0.5'),
('fr','retitle','Are you sure you wish to delete this title?','Etes vous sur de vouloir supprimer ce titre?','admin','1.0.3');