12-21-2005 Verified Uploader:admin Time:15:23:52
('fr','module-namecolor','\"`&Because this will be your first name color change, it will cost you %s points.  Future name changes will only cost %s points.`7\"','\"`&Parce que ce sera la premi�re fois que vous changez votre nom de couleur, il vous en co�tera %s points. Par contre, vos prochains changement ne vous co�teront que %s points.`7\"','Sunnygirl','1.0.5'),
('fr','module-namecolor',', which looks like %s`7`n`n',', ce qui ressemble � %s`7`n`n','Sunnygirl','1.0.5'),
('fr','module-namecolor','A colored name costs %s points for the first change and %s points for subsequent changes.','Un nom en couleur co�te %s points la premi�re fois et %s points les fois suivantes.','zveno','1.0.5'),
('fr','module-namecolor','Colorize Name (%s points)','Colorer votre Nom (%s points)','Sunnygirl','1.0.5'),
('fr','module-namecolor','How would you like your name to look?`n','Comment voudriez-vous que votre nom soit?`n','Sunnygirl','1.0.5'),
('fr','module-namecolor','Your name currently is this:','Votre nom est pr�sentement comme cela:','Sunnygirl','1.0.5'),
('fr','module-namecolor','`7J. C. Petersen smiles at you,','`7J. C. Petersen vous sourit,','Sunnygirl','1.0.5');