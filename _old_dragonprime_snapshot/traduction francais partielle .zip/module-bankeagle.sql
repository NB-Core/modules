12-21-2005 Verified Uploader:admin Time:15:23:52
('fr','module-bankeagle','`^`b`nYou deposit `&1200`^ gold into your bank account. ','`^`b`nVous d�posez `&1200`^ pi�ces dans votre compte de banque.','Sunnygirl','1.0.5'),
('fr','module-bankeagle','`^`b`nYou deposit `&875`^ gold into your bank account. ','`^`b`nVous d�posez `&875`^ pi�ces dans votre compte de banque.','Sunnygirl','1.0.5');