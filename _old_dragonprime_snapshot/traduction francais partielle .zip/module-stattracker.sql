12-21-2005 Verified Uploader:admin Time:15:23:52
('fr','module-stattracker','Can the players see their own stats?','Les joueurs peuvent-ils voir leur propre stat?','admin','1.0.0'),
('fr','module-stattracker','Dragon Kill #','Dragon tu�s #','zveno','1.0.5'),
('fr','module-stattracker','Forest fight tallies that are kept','Contr�les de combat de for�t qui sont gard�s','admin','1.0.0'),
('fr','module-stattracker','In progress','En cours','zveno','1.0.5'),
('fr','module-stattracker','N/A','N/A','zveno','1.0.5'),
('fr','module-stattracker','Number of Forest Fights','Nombre de combats en for�t','zveno','1.0.5'),
('fr','module-stattracker','Pages','Pages','Sunnygirl','1.0.5'),
('fr','module-stattracker','Statistical Analysis','Statistiques','zveno','1.0.5'),
('fr','module-stattracker','Won PvP tallies that are kept','Contr�les gagn�s de PvP qui sont gard�s','admin','1.0.0'),
('fr','module-stattracker','`b`#Page %s`0 (%s-%s)`b','`b`#Page %s`0 (%s-%s)`b','Sunnygirl','1.0.5');