12-21-2005 Verified Uploader:admin Time:15:23:52
('fr','module-game_dice','D?Play Dice Game','D?Jouer aux D�s','Monyss','1.0.3'),
('fr','module-game_dice','Never mind','Peu Importe','Monyss','1.0.3');