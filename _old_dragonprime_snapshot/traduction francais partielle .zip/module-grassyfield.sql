12-21-2005 Verified Uploader:admin Time:15:23:52
('fr','module-grassyfield','Return to the forest','Retour en foret','admin','1.0.2'),
('fr','module-grassyfield','`n`^Your nap leaves you completely healed!','`n`^Vous etes, vous aussi, completement soign�!','admin','1.0.2'),
('fr','module-grassyfield','`n`c`#You Stumble Upon a Grassy Field`c`n`n','`n`c`#Vous entrez dans une belle clairiere`c`nTout autour de vous ce n\'est que calme et silence. c\'est endroit a l\'air d\'avoir une aura magique.En effet, vous et votre monture etes complement repos�. Quel dommage que vous n\'ayez pas reperer le chemin pour pouvoir y revenir quand vous le souhait�`n','admin','1.0.2'),
('fr','module-grassyfield','`n`n`^You lose a forest fight for today.','`n`n`^Vous perdez un tour de combat en foret!','admin','1.0.2'),
('fr','module-grassyfield','says','Dit','admin','1.0.2');