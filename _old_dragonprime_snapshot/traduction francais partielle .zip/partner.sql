12-21-2005 Verified Uploader:admin Time:15:31:30
('fr','partner','`%Violet','`%Violet','zveno','1.0.5'),
('fr','partner','`^Seth','`^Seth','Sunnygirl','1.0.5');