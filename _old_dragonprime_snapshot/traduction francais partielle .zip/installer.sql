12-21-2005 Verified Uploader:admin Time:15:23:52
('fr','installer','Calendar','Calendrier','Sunnygirl','1.0.5'),
('fr','installer','Cartographer','Cartographe','Sunnygirl','1.0.5'),
('fr','installer','Download from this Site','Telecharger depuis ce site','Monyss','1.0.3'),
('fr','installer','House System','Systeme des Maisons','Monyss','1.0.3'),
('fr','installer','NPC Characters - Violet','NPC Lettrage - Violet','zveno','1.0.5'),
('fr','installer','NPCs','NPCs','Sunnygirl','1.0.5'),
('fr','installer','Save Module Settings','Sauvegarder les Param�tres du Module','Sunnygirl','1.0.5'),
('fr','installer','Temple of Shadow and Light','Temple de l\'Ombre et de la Lumi�re','Sunnygirl','1.0.5'),
('fr','installer','The Lost Ruins','Les ruines perdues','admin','1.0.5'),
('fr','installer','`3Synchronizing table `#titles`3..`n','`3Synchronisation de la table `#titles`3..`n','Vorkosigan','1.0.3'),
('fr','installer','`3Uninstalling `#globalhp`3: ','`3D�sinstaller `#globalhp`3: ','Sunnygirl','1.0.5');