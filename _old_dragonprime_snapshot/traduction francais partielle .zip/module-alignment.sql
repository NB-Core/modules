12-21-2005 Verified Uploader:admin Time:15:23:52
('fr','module-alignment','Alignment','Alignement','admin','1.0.4'),
('fr','module-alignment','`2Good','`2Bon','admin','1.0.3'),
('fr','module-alignment','`4Evil','`4Mauvais','admin','1.0.3'),
('fr','module-alignment','`6Neutral','`6Neutre','admin','1.0.3'),
('fr','module-alignment','`n`bYou have destroyed a person... strangely, it makes you more good.`b`0','`n`bVous avez d�truit quelqu\'un... �trangement, cela vous rend meilleur.`b`0','Sunnygirl','1.0.5');