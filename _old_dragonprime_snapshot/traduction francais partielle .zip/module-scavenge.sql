12-21-2005 Verified Uploader:admin Time:15:23:52
('fr','module-scavenge','A shiver runs down your spine as you wonder who it was looking for and hasten on.','Un frisson vous traverse le dos pendant que vous vous demandez qui elle cherchait.`n','admin','1.0.3'),
('fr','module-scavenge','For a moment out of the corner of your eye you think you can see a ghostly figure, searching for someone, but a farmer passes in front of you, and in the next instant the figure has gone. ','Pendant un moment, du coin de l\'oeil ,vous pensez que vous pouvez voir une figure fantomatique, recherchant quelqu\'un, mais un fermier passe devant vous, et l\'instant suivant la figure a disparue','admin','1.0.2'),
('fr','module-scavenge','Free the soul','Liberer l\'�me','Monyss','1.0.3'),
('fr','module-scavenge','Ghostly Figure','figure fantomatique','dragoni','1.0.4'),
('fr','module-scavenge','Raw Chance of Pit Appearing in Graveyard?','Chance crue de puits apparaisse dans le cimeti�re?','admin','1.0.0'),
('fr','module-scavenge','`&By the time you stop running, you are exhausted!','`&Au moment o� vous arr�tez de courir, vous �tes �puis�!','Sunnygirl','1.0.5'),
('fr','module-scavenge','`&You gain `%%s gems`&!','`&Vous gagnez `%%s gemmes`&!','Sunnygirl','1.0.5'),
('fr','module-scavenge','`)You find it hard to stop from running!`0`n','`)Vous avez du mal � freiner votre course!`0`n','Sunnygirl','1.0.5');