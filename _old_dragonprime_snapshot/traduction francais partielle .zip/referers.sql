12-21-2005 Verified Uploader:admin Time:15:31:30
('fr','referers','Destination','Destination','Monyss','1.0.3'),
('fr','referers','Last','Dernier','admin','1.0.0');