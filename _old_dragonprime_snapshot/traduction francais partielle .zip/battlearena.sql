12-21-2005 Verified Uploader:admin Time:15:23:52
('fr','battlearena','`@The current Battle Arena Leader is: `&%s`@.`0`n','`@Le Leader actuel de l\'arene est : `&%s`@.`0`n`n','admin','1.0.5');