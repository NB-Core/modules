12-21-2005 Verified Uploader:admin Time:15:23:52
('fr','module-rspgnome','Better not','Renoncer','admin','1.0.3'),
('fr','module-rspgnome','Flee','Fuir','admin','1.0.3'),
('fr','module-rspgnome','He reaches into the bag on his belt and hands you %s gold.`n`n','Il fouille dans le sac � son �paule et vous tend %s pi�ces d\'Or.`n`n','zveno','1.0.5'),
('fr','module-rspgnome','Paper','papier','Monyss','1.0.3'),
('fr','module-rspgnome','Play his game','jouer au jeu','admin','1.0.3'),
('fr','module-rspgnome','Talk to him','Parler avec lui','admin','1.0.3'),
('fr','module-rspgnome','`n`n`#\"See, I told you I\'m the best.\"`@`n`n','`n`n`#\"Regardez ! Je vous ai dit que j\'�tais le meilleur !\"`@`n`n','Vorkosigan','1.0.3');