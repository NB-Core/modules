12-21-2005 Verified Uploader:admin Time:15:23:52
('fr','module-findring','Before you have a chance to remove it, the ring burns into your flesh.','Avant que vous ayez la chance de l\'enlever, l\'anneau vous br�le la peau.','Sunnygirl','1.0.5'),
('fr','module-findring','Leave it Alone','Laisser','admin','1.0.2'),
('fr','module-findring','Pick it up','Prendre','admin','1.0.2'),
('fr','module-findring','The pain is intense, but in a moment is gone, and as you look down, you see that the ring is gone too.`n`n','La douleur est intense, mais dispara�t aussit�t et alors que vous penchez la t�te pour regarder, vous r�alisez que l\'anneau a disparu aussi.`n`n','Sunnygirl','1.0.5'),
('fr','module-findring','Will you pick it up?`0','Voulez vous la prendre? `0','admin','1.0.2'),
('fr','module-findring','You know that the forest is full of surprises, some of them nasty.','Vous savez que dans cette foret il faut s\'attendre a tout, en bien ou en mal.','admin','1.0.2'),
('fr','module-findring','`#You `$lose `#some hitpoints!`n`n`0','`#Vous `$perdez `#quelques points de vie!`n`n`0','admin','1.0.2'),
('fr','module-findring','`2You don\'t think it\'s worth your time to pick up the ring, and you travel on your way.`0','`2Vous d�cidez de ne pas gaspiller votre pr�cieux temps pour prendre l\'anneau et continuer votre chemin.`0','Sunnygirl','1.0.5'),
('fr','module-findring','`2You lean down and place the ring on one finger.`n`n`0','`2Vous vous baisez, prenez la bague et la mettez a votre doigt.`n`n`0','admin','1.0.2'),
('fr','module-findring','`2You stumble upon a small pearl ring concealed under some leaves.`n`n','`2Vous tombez sur une petite bague cach�e au milieu d\'immondice.`n`n','admin','1.0.2'),
('fr','module-findring','`4A strange feeling comes over you.`n`n','`4Une �trange impression s\'empare de vous.`n`n','Sunnygirl','1.0.5'),
('fr','module-findring','`^You feel charming!`0','`^Vous gagnez du charme!`0','admin','1.0.3');