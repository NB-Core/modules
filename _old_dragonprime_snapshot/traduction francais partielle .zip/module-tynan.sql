12-21-2005 Verified Uploader:admin Time:15:31:30
('fr','module-tynan','Attack Points Gained','Points d\'attaque gagn�s','admin','1.0.0'),
('fr','module-tynan','Defense Points Gained','Points de D�fense Gagn�s','Sunnygirl','1.0.5'),
('fr','module-tynan','Hitpoints Gained','Points de Vie Gagn�s','Sunnygirl','1.0.5'),
('fr','module-tynan','Tynan\'s Gym','Salle de Gym de Tynan','Monyss','1.0.3'),
('fr','module-tynan','`&`c`bTynan\'s Gym`b`c','`&`c`bLa Salle de Gym de Tynan`b`c','zveno','1.0.5'),
('fr','module-tynan','`^You\'ve gained agility!','`^Vous avez gagn� de l\'agilit�!','Sunnygirl','1.0.5'),
('fr','module-tynan','`^You\'ve gained muscles!','`^Vous avez gagn� du muscle!','Sunnygirl','1.0.5');