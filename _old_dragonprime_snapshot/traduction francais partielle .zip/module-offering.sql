12-21-2005 Verified Uploader:admin Time:15:23:52
('fr','module-offering','\"`&For the offering!!!','\"`&Pour les oeuvres de Ramius!!!','admin','1.0.2'),
('fr','module-offering','\"`&No no no no no!!!','\"`&Non non non non non!!!','Sunnygirl','1.0.5'),
('fr','module-offering','%s gold!\"','%s Pieces d\'or!\"','admin','1.0.2'),
('fr','module-offering','Give her %s gold','Donner %s pieces d\'or','admin','1.0.2'),
('fr','module-offering','Walk away','Refuser','admin','1.0.2'),
('fr','module-offering','`7While you are listening to others chatting, a bizarrely-dressed woman approaches with an outstretched hand. `n`n','`7Tandis que vous ecoutez d\'une oreille distraite les conversation dans l\'auberge, une etrange femme s\'approche de vous`n`n','admin','1.0.2'),
('fr','module-offering','`7Without another word, she walks away.`n','`7Sans un autre mot, elle s\'en va.`n','Sunnygirl','1.0.5'),
('fr','module-offering','`7You decide not to give any gold to this strange woman.`n','`7Vous decidez ne pas pas donnez votre argent, si durement conquis, a cette etrange femme.`n','ordicbm','1.0.2');