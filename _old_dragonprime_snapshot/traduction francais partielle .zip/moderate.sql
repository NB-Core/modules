12-21-2005 Verified Uploader:admin Time:15:23:52
('fr','moderate','Clan Halls','Halls des clans','Monyss','1.0.3');