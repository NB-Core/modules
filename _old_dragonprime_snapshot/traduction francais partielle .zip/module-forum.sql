12-21-2005 Verified Uploader:admin Time:15:23:52
('fr','module-forum',' Delete this Thread','Supprimer sujet','admin','1.0.5'),
('fr','module-forum',' Last post at `@',' Dernier Msg `@','admin','1.0.5'),
('fr','module-forum',' `%%s`^ Replies.',' `%%s`^ Reponses.','admin','1.0.5'),
('fr','module-forum','Post Count: ','Nb de msg:','admin','1.0.5'),
('fr','module-forum','Post a Thread','Poster nouveau message','admin','1.0.5'),
('fr','module-forum','Reply','Repondre','admin','1.0.5'),
('fr','module-forum','Thread started at `@','Sujet demarr� le `@','admin','1.0.5'),
('fr','module-forum','View Thread','Voir message','admin','1.0.5'),
('fr','module-forum','`@Thread started at `^','`@sujet commenc� le `^','admin','1.0.5'),
('fr','module-forum','`^Forum Postcount: `@%s`0`n','`^Contributions au Forum: `@%s`0`n','zveno','1.0.5'),
('fr','module-forum','`^Replies: `&(`@%s`&)','`^Reponses: `&(`@%s`&)','admin','1.0.5');