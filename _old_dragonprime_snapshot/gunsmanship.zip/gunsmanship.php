<?
/* Begin File
End Begin File*/

function modulefilename_getmoduleinfo(){
  $info = array(
  "name" => "Gunsmanship",
  "author" => "Jeffrey D. Riddle",
  "version" => "1.0",
  "download" => "http://dragonprime.net/users/Jeffrey/gunsmanship.zip",
  "category" => "Specialties",
  "prefs" => array(
    "Specialty - Skill Set Name User Prefs,title",
    "skill"=>"Skill points in Skill Set Name,int|0",
    "uses"=>"Uses of Skill Set Name allowed,int|0",
    ),
  );
return $info;
} 

function modulefilename_install(){
  module_addhook("choose-specialty");
  module_addhook("set-specialty");
  module_addhook("fightnav-specialties");
  module_addhook("apply-specialties");
  module_addhook("newday");
  module_addhook("incrementspecialty");
  module_addhook("specialtynames");
  module_addhook("specialtymodules");
  module_addhook("specialtycolor");
  module_addhook("dragonkill");
  return true;
} 

function modulefilename_uninstall(){
  $sql = "UPDATE " . db_prefix("accounts") . " SET specialty='' WHERE specialty='GS'";
  db_query($sql);
  return true;
} 

function modulefilename_dohook($hookname,$args){
  global $session,$resline;
  $spec = "GS";
  $name = "Gunsmanship";
  $ccode = "Color Code (`!)"; 

  switch ($hookname) {
    case "dragonkill":
      set_module_pref("uses", 0);
      set_module_pref("skill", 0);
      break;
    case "choose-specialty":
      if ($session['user']['specialty'] == "" || $session['user']['specialty'] == '0') {
         addnav("$ccode$name`0","newday.php?setspecialty=".$spec."$resline");
         $t1 = translate_inline("Little Anecdote, to go alongside the Specialty Name");
         $t2 = appoencode(translate_inline("$ccode$name`0"));
         rawoutput("$t1 ($t2)");
         addnav("","newday.php?setspecialty=$spec$resline");
       }
       break;
    case "set-specialty":
       if($session['user']['specialty'] == $spec) {
         page_header($name);
         output("You were raised around guns.");
       }
       break;
    case "specialtycolor":
      $args[$spec] = $ccode;
      break;
    case "specialtynames":
      $args[$spec] = translate_inline($name);
      break;
    case "specialtymodules":
      $args[$spec] = "specialtygunsmanship";
      break;
    case "incrementspecialty":
      if($session['user']['specialty'] == $spec) {
        $new = get_module_pref("skill") + 1;
        set_module_pref("skill", $new);
        $name = translate_inline($name);
        $c = $args['color'];
        output("`n%sYou gain a level in `&%s%s to `#%s%s!",$c, $name, $c, $new, $c);
        $x = $new % 3;
          if ($x == 0){
            output("`n`^You gain an extra use point!`n");
            set_module_pref("uses", get_module_pref("uses") + 1);
          }else{
            if (3-$x == 1) {
            output("`n`^Only 1 more skill level until you gain an extra use point!`n");
          }else{
            output("`n`^Only %s more skill levels until you gain an extra use point!`n", (3-$x));
          }
        }
       output_notl("`0");
      }
      break;
    case "newday":
      $bonus = getsetting("specialtybonus", 1);
      if($session['user']['specialty'] == $spec) {
        $name = translate_inline($name);
        if ($bonus == 1) {
          output("`n`2For being interested in %s%s`2, you receive `^1`2 extra `&%s%s`2 use for today.`n", $ccode, $name, $ccode, $name);
        }else{
          output("`n`2For being interested in %s%s`2, you receive `^%s`2 extra `&%s%s`2 uses for today.`n", $ccode, $name, $bonus, $ccode, $name);
        }
      }
      $amt = (int)(get_module_pref("skill") / 3);
      if ($session['user']['specialty'] == $spec) $amt = $amt + $bonus;
      set_module_pref("uses", $amt);
      break;
    case "fightnav-specialties":
      $uses = get_module_pref("uses");
      $script = $args['script'];
      if ($uses > 0) {
        addnav(array("$ccode$name (%s points)`0", $uses), "");
        addnav(array("$ccode � Fast Reload`7 (%s)`0", 1), $script."op=fight&skill=$spec&l=1", true);
      }
      if ($uses > 1) {
        addnav(array("$ccode � Fright Shot`7 (%s)`0", 2), $script."op=fight&skill=$spec&l=2",true);
      }
      if ($uses > 2) {
        addnav(array("$ccode � Double-Barreled Shotgun`7 (%s)`0", 3), $script."op=fight&skill=$spec&l=3",true);
      }
      if ($uses > 4) {
        addnav(array("$ccode � Deadly Aim`7 (%s)`0", 5), $script."op=fight&skill=$spec&l=5",true);
      }
      break;
case "apply-specialties":
$skill = httpget('skill');
$l = httpget('l');
  if ($skill==$spec){
    if (get_module_pref("uses") >= $l){
       switch($l){
         case 1:
           apply_buff('ts1',array(
             "startmsg"=>"You quickly reload your gun and fire catching your ememy quickly",
             "name"=>"Fast Reload",
             "rounds"=>5,
             "wearoff"=>"You grow tired of reloading too fast and stop",
             "roundmsg"=>"With steadfast determination you reload fast again and fire",
             "badguydefmod"=>.5,
             "schema"=>"specialtygunsmanship"
           ));
         break;
       case 2:
         apply_buff('ts2',array(
           "startmsg"=>"You fire a bullet out and a bullet flies up by your head",
           "name"=>"Fright Shot",
           "rounds"=>5,
           "minioncount"=>1,
           "minbadguydamage"=>5,
           "maxbadguydamage"=>8,
           "effectmsg"=>"A bullet hits!",
           "effectnodmgmsg"=>"You missed!",
           "schema"=>"specialtygunsmanship"
         ));
       break;
     case 3:
       apply_buff('ts3', array(
         "startmsg"=>"You fire many bullets in a circle to make a forcefield allowing yourself to heal",
         "name"=>"Double-Barreled Shotgun",
         "rounds"=>5,
         "wearoff"=>"You stop healing",
         "roundmsg"=>"You heal at a tremendus rate",
         "regen"=>10,
         "schema"=>"specialtygunsmanship"
       ));
     break;
   case 5:
     apply_buff('ts5',array(
       "startmsg"=>"You take aim and fire the most deadly bullet to your oppenent,",
       "name"=>"Deadly Shot",
       "rounds"=>1,
       "wearoff"=>"Your bullet leaves a mark and you are satisfied",
       "atkmod"=>4,
       "roundmsg"=>"You fire and feel the recoil but feel your enemy groan",
       "schema"=>"specialtygunsmanship"
     ));
    break;}
  set_module_pref("uses", get_module_pref("uses") - $l);
}else{
  apply_buff('ts0', array(
    "startmsg"=>,
    "rounds"=>1,
    "schema"=>"specialtygunsmanship"
  ));
}
}
break;
   }
  return $args;
} 
function modulefilename_run(){
}
?> 


