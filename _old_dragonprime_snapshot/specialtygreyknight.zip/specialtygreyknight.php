<?php
//addnews ready
// mail ready
// translator ready

/*******************************************
This specialty, and those of the White and Black Knights are meant to have alignment restrictions
but, I can't seem to get those restrictions to happen for some reason, so they're currently not
part of the specialties.
*******************************************/

function specialtygreyknight_getmoduleinfo(){
    $info = array(
        "name" => "Specialty - Grey Knight",
        "author" => "`6Admin Lexington, `2Alignment Ready Fixed by `4Zelion",
        "version" => "1.0",
        "download" => "http://dragonprime.net/users/zelion/specialtygreyknight.zip",
        "category" => "Specialties",
        "settings"=> array(
             "Specialty - Grey Knight Settings,title",
             "lowalignment"=>"Above what alignment is required for this specialty?,int|33",
             "highalignment"=>"Below what alignment is required for this specialty?,int|66",
             "mindk"=>"How many DKs do you need before the specialty is available?,int|0",
             "cost"=>"How many points do you need before the specialty is available?,int|0",
             "gain"=>"How much Alignment is gained when specialty is chosen,int|5",
      ),
        "prefs" => array(
            "Specialty - Grey Knight User Prefs,title",
            "skill"=>"Skill points in Grey Knight,int|0",
            "uses"=>"Uses of Grey Knight allowed,int|0",
        ),
    );
    return $info;
}

function specialtygreyknight_install(){
    $sql = "DESCRIBE " . db_prefix("accounts");
    $result = db_query($sql);
    $specialty="GK";
    while($row = db_fetch_assoc($result)) {
        // Convert the user over
        if ($row['Field'] == "greyknight") {
            debug("Migrating greyknight field");
            $sql = "INSERT INTO " . db_prefix("module_userprefs") . " (modulename,setting,userid,value) SELECT 'specialtygreyknight', 'skill', acctid, greyknight FROM " . db_prefix("accounts");
            db_query($sql);
            debug("Dropping greyknight field from accounts table");
            $sql = "ALTER TABLE " . db_prefix("accounts") . " DROP greyknight";
            db_query($sql);
        } elseif ($row['Field']=="greyknightuses") {
            debug("Migrating greyknight uses field");
            $sql = "INSERT INTO " . db_prefix("module_userprefs") . " (modulename,setting,userid,value) SELECT 'specialtygreyknight', 'uses', acctid, greyknightuses FROM " . db_prefix("accounts");
            db_query($sql);
            debug("Dropping greyknightuses field from accounts table");
            $sql = "ALTER TABLE " . db_prefix("accounts") . " DROP greyknightuses";
            db_query($sql);
        }
    }
    debug("Migrating Greyknight Specialty");
    $sql = "UPDATE " . db_prefix("accounts") . " SET specialty='$specialty' WHERE specialty='1'";
    db_query($sql);

    module_addhook("choose-specialty");
    module_addhook("set-specialty");
    module_addhook("fightnav-specialties");
    module_addhook("apply-specialties");
    module_addhook("newday");
    module_addhook("incrementspecialty");
    module_addhook("specialtynames");
    module_addhook("specialtymodules");
    module_addhook("specialtycolor");
    module_addhook("dragonkill");
    module_addhook("pointsdesc");
    module_addhook("newday");
    return true;
}

function specialtygreyknight_uninstall(){
    // Reset the specialty of anyone who had this specialty so they get to
    // rechoose at new day
    $sql = "UPDATE " . db_prefix("accounts") . " SET specialty='' WHERE specialty='GK'";
    db_query($sql);
    return true;
}

function specialtygreyknight_dohook($hookname,$args){
    global $session,$resline;

    $spec = "GK";
    $name = "Grey Knight";
    $ccode = "`7";
    $cost = get_module_setting("cost");
    $gain = get_module_setting("gain");

    switch ($hookname) {
        case "pointsdesc":
            $args['count']++;
            $format = $args['format'];
            $str = translate("The Grey Knight Specialty is availiable upon reaching %s Dragon Kills and %s points.");
            $str = sprintf($str, get_module_setting("mindk"), $cost);
            output($format, $str, true);
        break;

        case "newday":
        $bonus = getsetting("specialtybonus", 1);

        if($session['user']['specialty'] == $spec) {
            if ($bonus == 1) {
                output("`n`3For being interested in %s%s`3, you gain `^1`3 extra use of `&%s%s`3 for today.`n",$ccode,$name,$ccode,$name);
            }
            else {
                output("`n`3For being interested in %s%s`3, you gain `^%s`3 extra uses of `&%s%s`3 for today.`n",$ccode,$name,$bonus,$ccode,$name);
            }
        }

        $amt = (int)(get_module_pref("skill") / 3);
        if ($session['user']['specialty'] == $spec) $amt++;
        set_module_pref("uses", $amt);
        if (is_module_active('alignment') && $session['user']['specialty'] == 'GK') {
                output("`nYour knightly calling has changed your alignment.`n");
                ($session['user']['alignment']==50);
        }
        break;

        case "dragonkill":
            set_module_pref("uses", 0);
            set_module_pref("skill", 0);
        break;

        case "choose-specialty":
	if (get_module_pref("alignment","alignment") > get_module_setting("lowalignment") && get_module_pref("alignment","alignment") < get_module_setting("highalignment")) {
            if ($session['user']['specialty'] == "" || $session['user']['specialty'] == '0') {
                $pointsavailable = $session['user']['donation'] - $session['user']['donationspent'];
                if ($session['user']['dragonkills'] < get_module_setting("mindk") || get_module_setting("cost") > $pointsavailable) break;
                addnav("$ccode$name`0","newday.php?setspecialty=".$spec."$resline");
                $t1 = translate_inline("Killing, because it's something to do. A thief who has learned from a swordmaster.");
                $t2 = appoencode(translate_inline("$ccode$name`0"));
                rawoutput("<a href='newday.php?setspecialty=$spec$resline'>$t1 ($t2)</a><br>");
                addnav("","newday.php?setspecialty=$spec$resline");
                }
            }
        break;

        case "set-specialty":
            if($session['user']['specialty'] == $spec) {
                page_header($name);
                $session['user']['donationspent'] = $session['user']['donationspent'] - $cost;
                output("`)The Grey Knights had always been believed to be nothing more than a legend.");
                output(" You proved them wrong when you found the abandoned temple, guarded by the last of their order.");
                output(" Knowing that his end was near, he forced you to learn the secrets of the Void.");
                output(" And just before his death, he dubbed you a Void Knight.");
                output(" Little did you know, that you were destined for so much more...");
                if (is_module_active('alignment')) {
                    set_module_pref('alignment',get_module_pref('alignment','alignment') + $gain,'alignment');
                }
            }
        break;

        case "specialtycolor":
            $args[$spec] = $ccode;
        break;

        case "specialtynames":
            $pointsavailable = $session['user']['donation'] - $session['user']['donationspent'];
            if ($session['user']['superuser'] & SU_EDIT_USERS || $session['user']['dragonkills'] >= get_module_setting("mindk") || get_module_setting("cost") <= $pointsavailable){
                $args[$spec] = translate_inline($name);
            }
        break;

        case "specialtymodules":
            $args[$spec] = "specialtygreyknight";
        break;

        case "incrementspecialty":
            if($session['user']['specialty'] == $spec) {
                $new = get_module_pref("skill") + 1;
                set_module_pref("skill", $new);
                $c = $args['color'];
                $name = translate_inline($name);
                output("`n%sYou gain a level in `&%s%s to `#%s%s!",
                $c, $name, $c, $new, $c);
                $x = $new % 3;
                if ($x == 0){
                    output("`n`^You gain an extra use point!`n");
                    set_module_pref("uses", get_module_pref("uses") + 1);
                }
                else{
                    if (3-$x == 1) {
                        output("`n`^Only 1 more skill level until you gain an extra use point!`n");
                    }
                    else {
                    output("`n`^Only %s more skill levels until you gain an extra use point!`n", (3-$x));
                    }
                }
            output_notl("`0");
            }
        break;

        case "fightnav-specialties":
            $uses = get_module_pref("uses");
            $script = $args['script'];
            if ($uses > 0) {
                addnav(array("$ccode$name (%s points)`0", $uses),"");
                addnav(array("$ccode &#149; The Void`7 (%s)`0", 1),
                    $script."op=fight&skill=$spec&l=1", true);
            }
            if ($uses > 1) {
                addnav(array("$ccode &#149; Backslash`7 (%s)`0", 2),
                    $script."op=fight&skill=$spec&l=2",true);
            }
            if ($uses > 2) {
                addnav(array("$ccode &#149; Void Attack`7 (%s)`0", 3),
                    $script."op=fight&skill=$spec&l=3",true);
            }
            if ($uses > 4) {
                addnav(array("$ccode &#149; Smite`7 (%s)`0", 5),
                    $script."op=fight&skill=$spec&l=5",true);
            }
        break;

        case "apply-specialties":
            $skill = httpget('skill');
            $l = httpget('l');
            if ($skill==$spec){
                if (get_module_pref("uses") >= $l){
                    switch($l){
                    case 1:
                        apply_buff('Gk1',
                            array(
                            "startmsg"=>"`)You transport yourself and {badguy} to plane known only as `bThe Void`b, lacking any form of life.",
                            "name"=>"`)The Void",
                            "rounds"=>round($session['user']['level']+2),
                            "wearoff"=>"`)You suck the very essence of your opponent's life into your own body.",
                            "regen"=>round($session['user']['level']/3,0)+1,
                            "effectmsg"=>"You regenerate for {damage} health, while your opponet suffers {damage} damage!",
                            "minioncount"=>1,
                            "maxbadguydamage"=>round($session['user']['level']/3,0)+1,
                            "minbadguydamage"=>round($session['user']['level']/3,0)+1,
                            "schema"=>"specialtygreyknight"
                            )
                        );
                    break;
                    case 2:
                        apply_buff('Gk2',
                            array(
                            "startmsg"=>"`)Using your skills you learned as a thief, you disappear behind the {badguy} and slide your {weapon} between its vertebrae!",
                            "name"=>"`)Backslash",
                            "rounds"=>10,
                            "wearoff"=>"`)Your victim won't be so likely to let you get behind it again!",
                            "atkmod"=>1.5,
                            "defmod"=>1.5,
                            "roundmsg"=>"Your attack is multiplied, as is your defense!",
                            "schema"=>"specialtygreyknight"
                            )
                        );
                    break;
                    case 3:
                        apply_buff('Gk3',
                            array(
                            "startmsg"=>"`)You step into the Void and disappear. Your attacks easily pass through the veil though, striking the {badguy} from a safer vantage point.",
                            "name"=>"`)Void Attack",
                            "rounds"=>10,
                            "wearoff"=>"`)Not wanting to get sucked into the Void with no way out, you return to the real world.",
                            "roundmsg"=>"`)The {badguy} `)has no clue where you are, and swings at nothing but air!",
                            "atkmod"=>2,
                            "defmod"=>2,
                            "badguyatkmod"=>0,
                            "schema"=>"specialtygreyknight"
                            )
                        );
                    break;
                    case 5:
                        apply_buff('Gk5',
                            array(
                            "startmsg"=>"`)Wanting to repay the Void which gives you strength, you promise to feed life into it...starting with the {badguy}.",
                            "name"=>"`)Smite",
                            "rounds"=>10,
                            "wearoff"=>"`)Unable to wield such an amazing power for any longer, you release it.",
                            "badguyatkmod"=>.1,
                            "badguydefmod"=>.1,
                            "atkmod"=>3,
                            "defmod"=>3,
                            "effectmsg"=>"`)Your `b`)Smite`b`) hits the {badguy}`) for `\${damage}`) damage.",
                            "roundmsg"=>"`)The {badguy} `)floats soundlessly in the air, with a look of intense pain on his face.",
                            "schema"=>"specialtygreyknight"
                            )
                        );
                    break;
                    }
                set_module_pref("uses", get_module_pref("uses") - $l);
                }else{
                    apply_buff('Gk0',
                        array(
                        "startmsg"=>"Lacking the strength to continue, you try to raise your sword to attack and defend yourself, but the {badguy} only laughs and lunges forward to attack!",
                        "rounds"=>1,
                        "schema"=>"specialtygreyknight"
                        )
                    );
                }
        }
        break;
    }
    return $args;
}

function specialtygreyknight_run(){
}
?>