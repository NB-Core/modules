Darton Text Skin for LoGD
MacBladez and SaucyWench

Put all these files exactly as they are, into your TEMPLATES folder

Feedback to SaucyWench -at- gmail DOT com