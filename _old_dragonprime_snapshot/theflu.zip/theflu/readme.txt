The Flu for %~Legend of the Green Dragon~%

A forest & travel special where a user can catch the flu. 
Also a user can get Infected if another Clansman is sick on A new day.

Auther => Mr Zone
Version"=> 1.3
Support or Bug reports for The FLu => http://dragonprime.net/index.php?topic=3080.0


Step 1) Copy theflu.php to your {LoGD folder}\modules folder
Step 2) Copy flu.php to your {LoGD folder}\modules\lib folder
	If your lib folder does not exist... well then create it :)
Step 3) Login to the Grotto and install The Flu (theflu.php)
Step 4) Sit back and watch everyone get sick... he he he







