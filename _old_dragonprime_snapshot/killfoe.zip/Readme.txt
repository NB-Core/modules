Kill a Foe 1.0
By Colin Harvie

Kill a Foe 1.0 creates another favor that Ramius will do for you. Basic settings gives you the ability to have Ramius kill a foe from your old life if you gain 500 favor with him.

This module cannot be used unless the code of graveyard.php is changed so that the line:

modulehook("favors");

is inserted just before the closing of the elseif ($op=="question") statement.

Enjoy!