<?php
/**
* Version: 1.3 - Added another outcome April 1,2005
* Version: 1.2 - Added Admin Config
* Version: 1.1 - Added another outcome
* Version: 1.0 - Made by Arune
* Date:    January 26, 2005
* Author:       Robert of Maddnet / Converted by: Kevin Hatfield - Arune
* Distro Site:  http://www.dragonprime.net
* LOGD VER:     Module for 0.9.8 beta & Version 1.0
*/
function sleeping_getmoduleinfo(){
        $info = array(
        "name"=>"Sleeping Dwarf",
        "version"=>"1.3",
        "author"=>"`2Robert `7- Coverted by: Arune",
        "download"=>"http://dragonprime.net/users/Robert/sleeping098.zip",
        "category"=>"Forest Specials",
        "settings"=>array(
		"Sleeping Dwarf Settings,title",
		"mingold"=>"Minimum gold to steal ( x's by level),range,4,20,2|10",
		"maxgold"=>"Maximum gold to steal ( x's by level),range,25,60,5|30"
		),
        );
        return $info;
}

function sleeping_install(){
        module_addeventhook("forest", "return 100;");
        return true;
}

function sleeping_uninstall(){
        return true;
}

function sleeping_dohook($hookname,$args){
        return $args;
}

function sleeping_runevent($type){
global $session;
$min = $session['user']['level']*get_module_setting("mingold");
$max = $session['user']['level']*get_module_setting("maxgold");

switch(e_rand(1,5)){
	case 1: case 4:
	$gold = e_rand($min, $max);
	output("`n`n`^ You have come across a sleeping Dwarf, you steal $gold of his gold! ");
	$session['user']['gold']+=$gold;
	debuglog(" stole $gold gold from a sleeping dwarf ");
	break;
	case 2: case 5:
	$gold = $min;
	output("`n`n`^ You have come across a sleeping Dwarf, you quietly try to steal his gold. ");
	output("`n`n He awakens, grabs his pouch and runs away dropping $gold of his gold! ");
	$session['user']['gold']+=$gold;
	debuglog(" gained $gold gold from a sleeping dwarf ");
	break;
	case 3: case 6:
	$gold = $max;
	output("`n`n`^ You have come across a sleeping Dwarf, you try to steal gold from his pouch. ");
	output("`n`n He rolls over in his sleep, hiding his pouch, but not before you nik $gold of his gold! ");
	$session['user']['gold']+=$gold;
	debuglog(" stole $gold gold from a sleeping dwarf ");
	break;
}
}
function sleeping_run(){
}
?>