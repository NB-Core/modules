<?php
/*
Meet Ero-Sennin in the woods...

you find him peeping at some bathing girls...

v1.01 minor fixes
v1.02 fix in the gain of attackpoints (forgot to add)


Ero Sennin - The Perverted Hermit",
  "author"=>"Oliver Brendel",
  "version"=>"1.02",
  "category"=>"Forest Specials",
   "Ero Sennin - Preferences, title",
   "Meet him and maybe the frog boss,note",
*/
$erosennin="`QEro-`!Sennin";//   "name"=>"Name (coloured) of Ero-Sennin,text|`QEro-`gSennin",
$charmmax=30; //   "charme"=>"Charm value for female players to get stalked,int|30",
$experienceloss = 10; //   "experienceloss"=>"Percentage: How many experience is lost/won after a fight,floatrange,1,100,1|10",
$username=$session['user']['name'];

	$link = "forest.php?";
	$specialbat = "erosennin097.php";
	$session[user][specialinc]=$specialbat;
	$op=$HTTP_GET_VARS[op];
	switch ($op)
	{
	case "":
		output("`3You walk along a peaceful road... after you walked a few minutes, you see a little bath house built near a hot spring right beside the road.");
		output(" You decide to get a bit closer... since it's on your way though.");
		$adj=($session['user']['sex']?"disgusting":"interesting");
		output("`n`nOh! That's $adj... an old man sits right at a wooden fence and peeks through a hole!");
		output("`n`nWhat do you want to do?");
		addnav("Call To Order",$link."op=disturb");
		addnav("Peek Together",$link."op=peek");
		addnav("Walk away",$link."op=walk");
		break;
	case "peek":
		output("`3You ask silently if you can take a look too... the old man realizes your presence and takes a look at you.`n`n");
		output("'`QShhh... get your own hole! I am gathering data right now!`3'");
		if ($session['user']['sex'] && $charmmax<$session['user']['charm'])
			{
			output("`n`nHe takes `$ very`3 good look at you... and starts to drool.");
			output("'`QOh... what ripe fruits you have brought with you... you have some awesome things...`3'");
			output(" You feel somehow ill to see that old geezer gaze at you.");
			$gold=e_rand(0,$session['user']['gold']);
			output("`n`nDu l�ufst weg, und verliert $gold Goldst�cke!");
			$session['user']['gold']-=$gold;
			$session['user']['specialinc'] = "";
			forest(true);
			}
		output("In fact, you find a nice hole to peek through.");						output(" You take a good look... and well.. what nice bodies... rrrr....");
		output(" fresh, young females... ready to be gazed at...");
		$randomchance=e_rand(1,3);
		switch ($randomchance)
		{
			case "1":
				output("You are amazed... nice bodies... freshly riped... you feel `%charming`3!`n`n");
				$session['user']['charm']+=2;
			break;
			case "2":
				output("You are not that satisfied... you have higher standards.`n`n");
			break;
			case "3":
				output("Oh my! You little oaf! You leaned against the fence too strongly!");
				output("The ladies are now a bit angry... and the old man is gone!");
				output("`n`n`$ You are beaten to a pulp by the bathing ladies!`n`n");
				addnews("$username`^ was beaten to a pulp for peeking by half-naked ladies!");
				$session['user']['hitpoints']=e_rand(1,$session['user']['hitpoints']/2);
			break;

		}
		$gendercall=(!$session['user']['sex']?"boy":"cutie");
		if (e_rand(1,3)==1 && $randomchance<>3)
			{
			output("'`QHey, $gendercall, I like your style. I will teach you a secret to let you gain some offensive power.`3'");
			output("`n`nYou ask him: '`@And what is your name?`3'... and it takes a few moments...");
			output(" then he says: '`QThank your asking! I am the `!Gama-Sennin`Q from the Myouboku Mountain!");
			output(" You ponder about him... and realize you have heard of him before: '`@You are no Gama-Sennin (frog hermit)! You are the legendary $erosennin`@!!!'`3");
			output("`n`nAfter a few hours of argument, you leave the place with some new secrets in your brain.");
			output("`n`nYou `^gain`3 `$ two `3temporary attackpoints! (will vanish after the DK)");
			$session['user']['attack']+=2;
			}
		$session['user']['specialinc'] = "";
		break;
	case "walk":
		output("`3You don't mind the old man peeping... and continue on your journey.`n`n");
		$session['user']['specialinc'] = "";
	break;
	case "disturb": //players who try to harm her have to fight against her protector ;) and they receive no mercy
		output("`3You walk towards him... he doesn't seem to realize anything except for nudity...`n");
		output("You utter loudly: '`@What are you doing here, old man? Peeking is a crime, you know?`3'");
		output(" He seems to be very surprised and turns around... he has some sad look in his eyes... but now he seems to be angry!`3`n`n");
		output("'`QBaka baka baka... You scared the nice ladies away... you need to be taught a lesson!`3'`n`n");
		output("`^Inu...Ii.. Tori... Saru... O-hitsuji... Ninpou Kuchiyose no Jutsu!`3`n`n");
		$selection=0;
		if ($session['user']['level']<5)
		 {
		 output("A small frog warrior appears right before you... and attackes immediately.");
		 	$badguy = array(
			"creaturename"=>"a small Frog Warrior",
            "creaturelevel"=>$session['user']['level']+1,
            "creatureweapon"=>"Frog Kiss",
			"creatureattack"=>$session['user']['level']+$session['user']['dragonkills']+1,
			"creaturedefense"=>$session['user']['defense'],
			"creaturehealth"=>($session['user']['level']*10+round(e_rand($session['user']['level'],($session['user']['maxhitpoints']-$session['user']['level']*10)))),
			"diddamage"=>0,);
		 } elseif ($session['user']['level']<10) {
			output("A big frog warrior appears right before you... and attackes immediately.");
		 	$badguy = array(
			"creaturename"=>"a Greater Frog Warrior",
            "creaturelevel"=>$session['user']['level']+1,
            "creatureweapon"=>"Two scimitars",
			"creatureattack"=>$session['user']['level']+$session['user']['dragonkills']+3,
			"creaturedefense"=>$session['user']['defense']+1,
			"creaturehealth"=>($session['user']['level']*10+round(e_rand($session['user']['level'],($session['user']['maxhitpoints']-$session['user']['level']*10)))),
			"diddamage"=>0,);
		 } else {
			output("Oh no! It seems that he summoned the frog boss! It's `^Gamabunta`3!");
				$badguy = array(
				"creaturename"=>"Gamabunta",
				"creaturelevel"=>$session['user']['level']+1,
				"creatureweapon"=>"Suiton Teppoudama",
				"creatureattack"=>$session['user']['level']+$session['user']['dragonkills']+5,
				"creaturedefense"=>$session['user']['level']+$session['user']['dragonkills'],
				"creaturehealth"=>($session['user']['level']*10+50+round(e_rand($session['user']['level']+50,($session['user']['maxhitpoints']-$session['user']['level']*10)))),
				"diddamage"=>0,);
				}
   	$battle=true;
	$session['user']['badguy'] = createstring($badguy);
	$op = "combat";
	case "combat": case "fight":
	include("battle.php");
	if ($victory){ //no exp at all for such a foul act
		output("`n`n`@...".$badguy['creaturename']."`^ dies by your hand. You have managed to survive...somehow.");
		addnews("$username`^ survived an encounter with $erosennin`^.");
		$session['user']['specialinc'] = "";
		$exploss = $session['user']['experience']*$experienceloss/100;
		if ($exploss>0) output(" You gain `^$experienceloss percent`@  experience!");
		$session['user']['experience']+=$exploss;
		$badguy=array();
		$session['user']['badguy']="";
    }elseif ($defeat){ //but a loss of course if you die
		$exploss = $session['user']['experience']*$experienceloss/100;
		output("`n`n`@You are dead... stroke down by ".$badguy['creaturename']." `@.`n");
		if ($exploss>0) output(" You lose `^$experienceloss percent`@  of your experience and all of your gold.");
		$session['user']['experience']-=$exploss;
		$session['user']['gold']=0;
		debuglog("lost $exploss experience and all gold to Ero-Sennin.");
		addnews("$username`^ was killed by ".$badguy['creaturename']."`^ sent out by $erosennin`^.");
		addnav("Return");
		addnav("Return to the Shades","shades.php");
		$session['user']['specialinc'] = "";
		$badguy=array();
		$session['user']['badguy']="";
    }else{
		fightnav(true,false);
		if ($session['user']['superuser']) addnav("Escape to Village","village.php");
    }
 }



?>