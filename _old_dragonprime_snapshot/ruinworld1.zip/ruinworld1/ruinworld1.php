<?php
	global $session;
	$op = httpget('op');
	$id = httpget('id');
	$cost = httpget('cost');
	$page = httpget('page');
	$skill = httpget('skill');
	$shopname=get_module_setting("shopname");
	page_header("%s",$shopname);
	$allowp=get_module_setting("allowp");
	$weapon1=get_module_setting("weapon1");
	$weapon2=get_module_setting("weapon2");
	$weapon3=get_module_setting("weapon3");
	$weapon4=get_module_setting("weapon4");
	$weapon5=get_module_setting("weapon5");
	$weapon6=get_module_setting("weapon6");
	
if ($op=="enter"){
	if ($session['user']['dragonkills']<get_module_setting("mindk","ruinworld1")){
		page_header("Ancient Ruins");
		output("Nope... turns out that it was nothing.");
		addnav("Return","runmodule.php?module=lostruins&op=enter");
	}elseif (get_module_pref("purchased")==1){
		output("`@You step through a shimmering haze and feel quite disoriented.");
		output("`n`nYou walk up to the door of a store called `&'%s'`@ but they appear to be closed.",$shopname);
		output("`n`nThere doesn't seem to be much you can do here.");
		addnav("Return","runmodule.php?module=lostruins&op=enter");
	}else{
		output("`b`c`&%s`b`c`n",$shopname);
		output("`@You step through a shimmering haze and feel quite disoriented.");
		output("`n`nAfter a couple minutes you look around and notice that you must have stepped through a worm hole entirely localized around your body.");
		output("`n`nYou must have been transported into a different world!  You look around and it seems like you're in some type of weapons store.");
		output("The disorienting part of this visit is that it's unlike any weapon store you've ever seen.");
		output("You study the wall and read `&'%s'`@.",$shopname);
		addnav("Continue","runmodule.php?module=ruinworld1&op=continue");
		$session['user']['specialinc']="module:ruinworld1";
	}
	set_module_setting("ruin1found",0,"lostruins");
	blocknav("runmodule.php?module=ruinworld1&op=leave");
}
if ($op=="continue"){
	output("`b`c`&%s`b`c`n",$shopname);
	output("`@You wander over to the counter and stare blankly at the store clerk. He looks like a rough and tumble type of guy.  I don't think you should mess with him.");
	output("`n`nHe looks you over but surprisingly doesn't seem very concerned about your appearance.");
	output("`n`n`#'You must be one of those `iRennaisance Festival`i types. Whatever floats your boat.  What can I do for you?'`n`n");
	addnav("Examine");
	addnav(array("%s",$weapon1),"runmodule.php?module=ruinworld1&op=buy&id=1");
	if (get_module_setting("goldw2")>0 && $session['user']['level']>=get_module_setting("levelw2") && $session['user']['dragonkills']>=get_module_setting("dkw2")) addnav(array("%s",$weapon2),"runmodule.php?module=ruinworld1&op=buy&id=2");
	if (get_module_setting("goldw3")>0 && $session['user']['level']>=get_module_setting("levelw3") && $session['user']['dragonkills']>=get_module_setting("dkw3")) addnav(array("%s",$weapon3),"runmodule.php?module=ruinworld1&op=buy&id=3");
	if (get_module_setting("goldw4")>0 && $session['user']['level']>=get_module_setting("levelw4") && $session['user']['dragonkills']>=get_module_setting("dkw4")) addnav(array("%s",$weapon4),"runmodule.php?module=ruinworld1&op=buy&id=4");
	if (get_module_setting("goldw5")>0 && $session['user']['level']>=get_module_setting("levelw5") && $session['user']['dragonkills']>=get_module_setting("dkw5")) addnav(array("%s",$weapon5),"runmodule.php?module=ruinworld1&op=buy&id=5");
	if (get_module_setting("goldw6")>0 && $session['user']['level']>=get_module_setting("levelw6") && $session['user']['dragonkills']>=get_module_setting("dkw6")) addnav(array("%s",$weapon6),"runmodule.php?module=ruinworld1&op=buy&id=6");
	$wname=translate_inline("`bName`b~~~~~~~~~~~~~~~~~~~~~");
	$wcost=translate_inline("`bPrice`b");
	//table heading
	rawoutput("<table border='0' cellpadding='0'>");
	rawoutput("<tr class='trhead'><td>");
	output_notl($wname);
	rawoutput("</td><td align='right'><center>");
	output_notl($wcost);
	rawoutput("</center></td></tr>");
	//Weapon 1
	rawoutput("<tr class='trlight'><td>");
	rawoutput("<a href='runmodule.php?module=ruinworld1&op=buy&id=1'>");
	addnav("","runmodule.php?module=ruinworld1&op=buy&id=1");
	output_notl("%s",$weapon1);
	rawoutput("</a>");
	rawoutput("</td><td align='right'>");
	output_notl("`@100 Dollars");
	rawoutput("</td></tr>");
	//Weapon 2
	if (get_module_setting("goldw2")>0 && $session['user']['level']>=get_module_setting("levelw2") && $session['user']['dragonkills']>=get_module_setting("dkw2")){
		rawoutput("<tr class='trlight'><td>");
		rawoutput("<a href='runmodule.php?module=ruinworld1&op=buy&id=2'>");
		addnav("","runmodule.php?module=ruinworld1&op=buy&id=2");
		output_notl("%s",$weapon2);
		rawoutput("</a>");
		rawoutput("</td><td align='right'>");
		output_notl("`@200 Dollars");
		rawoutput("</td></tr>");
	}
	//Weapon 3
	if (get_module_setting("goldw3")>0 && $session['user']['level']>=get_module_setting("levelw3") && $session['user']['dragonkills']>=get_module_setting("dkw3")){
		rawoutput("<tr class='trlight'><td>");
		rawoutput("<a href='runmodule.php?module=ruinworld1&op=buy&id=3'>");
		output_notl("%s",$weapon3);
		rawoutput("</a>");
		addnav("","runmodule.php?module=ruinworld1&op=buy&id=3");
		rawoutput("</td><td align='right'>");
		output_notl("`@300 Dollars");
		rawoutput("</td></tr>");
	}
	//Weapon 4
	if (get_module_setting("goldw4")>0 && $session['user']['level']>=get_module_setting("levelw4") && $session['user']['dragonkills']>=get_module_setting("dkw4")){
		rawoutput("<tr class='trlight'><td>");
		rawoutput("<a href='runmodule.php?module=ruinworld1&op=buy&id=4'>");
		output_notl("%s",$weapon4);
		rawoutput("</a>");
		addnav("","runmodule.php?module=ruinworld1&op=buy&id=4");
		rawoutput("</td><td align='right'>");
		output_notl("`@400 Dollars");
		rawoutput("</td></tr>");
	}
	//Weapon 5
	if (get_module_setting("goldw5")>0 && $session['user']['level']>=get_module_setting("levelw5") && $session['user']['dragonkills']>=get_module_setting("dkw5")){
		rawoutput("<tr class='trlight'><td>");
		rawoutput("<a href='runmodule.php?module=ruinworld1&op=buy&id=5'>");
		output_notl("%s",$weapon5);
		rawoutput("</a>");
		addnav("","runmodule.php?module=ruinworld1&op=buy&id=5");
		rawoutput("</td><td align='right'>");
		output_notl("`@850 Dollars");
		rawoutput("</td></tr>");
	}
	//Weapon 6
	if (get_module_setting("goldw6")>0 && $session['user']['level']>=get_module_setting("levelw6") && $session['user']['dragonkills']>=get_module_setting("dkw6")){
		rawoutput("<tr class='trlight'><td>");
		rawoutput("<a href='runmodule.php?module=ruinworld1&op=buy&id=6'>");
		output_notl("%s",$weapon6);
		rawoutput("</a>");
		addnav("","runmodule.php?module=ruinworld1&op=buy&id=6");
		rawoutput("</td><td align='right'>");
		output_notl("`@1300 Dollars");
		rawoutput("</td></tr>");
	}
	rawoutput("</table>");
	addnav("Other");
	if (get_module_pref("purchased")==1) addnav(array("`0More %s`0 Practice",$session['user']['weapon']),"runmodule.php?module=ruinworld1&op=practice");
}
if ($op=="buy"){
	output("`b`c`&%s`b`c`n",$shopname);
	if (get_module_pref("hearprice")==0){
		output("`@You ask what these `i'dollars'`i are and the %s`@ owner looks at you and rolls his eyes.",$shopname);
		output("`n`n`#'Listen buddy, I don't care what games you like to play on the weekend but if you ain't got the cash you don't get the stash.'");
		if ($session['user']['race'] == 'Dwarf') $language="elvish";
		else $language="dwarvish";
		output("`@You stare at him, thinking that he must have just spoken something in the %s language.",$language);
		output("`n`nThe shop owner mumbles something about `3'Why does every weirdo have to walk into MY store?'`@ He looks up at you and talks in a very slow and deliberate language:");
		output("`#'You need money.  You know, greenbacks? Bucks? Cash? Currency backed by `^gold`#?'");
		output("`n`n`@You hear the magic word `^gold`@ and suddenly you understand what he's talking about.");
		output("You smile and nod with a sudden clarity.  There may be some problem with currency exchange here.");
		set_module_pref("hearprice",1);
		addnav("Continue","runmodule.php?module=ruinworld1&op=buy&id=$id");
	}else{
		$weapon=get_module_setting("weapon".$id);
		if ($id==1){
			output("`#'Well, your %s`# there is your pretty standard weapon.'",$weapon);
			output("`n`n'It doesn't have a lot of power, but it does give you a nice warm feeling when you're being threatened.");
		}
		if ($id==2){
			output("`#'The %s`# was the favored weapon from long ago.  It's got a nice little kick and feels nice and natural in your hands.",$weapon);
			output("`n`n'It's definately stronger than a weapon like a %s.'",get_module_setting("weapon1"));
		}
		if ($id==3){
			output("`#'The nice thing about a %s`# is that even a beginner won't miss the target with this little beauty.",$weapon);
		}
		if ($id==4) {
			output("`#'Now this here %s`# is a real weapon.  You can punch a hole through a concrete wall with this big boy.",$weapon);
		}
		if ($id==5) {
			output("`#'Ah... good choice. The %s`# is a nice weapon for killing anything.  Yup.  You point, you wave, and call in the clean up crew.",$weapon);
		}
		if ($id==6) {
			output("`#'Oh yeah. The %s`#.  Nothing could be finer. I promise you. This will kill anything. Now, it can be a little rough to hold and it really has quite a kick.",$weapon);
			output("`#But don't worry.  Nothing will harm you when you've got one of these puppies hugging you at night.");
		}
		addnav("Return to the Display Case","runmodule.php?module=ruinworld1&op=continue");		
		addnav("Talk about the Price","runmodule.php?module=ruinworld1&op=buyweapon&id=$id");
		output("You interested?'");
		output("`n`n`@You really don't know what a %s`@ can do against a Green Dragon, but it sounds like it might be worth a try.",$weapon);
	}
}
if ($op=="buyweapon"){
	addnav("Return to the Display Case","runmodule.php?module=ruinworld1&op=continue");
	output("`b`c`&%s`b`c`n",$shopname);
	$usergold=$session['user']['gold'];
	$gem=get_module_setting("gemw".$id);
	$gold=get_module_setting("goldw".$id);
	$weapon=get_module_setting("weapon".$id);
	if ($usergold>=$gold){
		output("`@You discuss the price of these `idollars`i and pull out your `^gold`@ pouch.");
		output("After some negotiation, it seems like the owner willl accept `^%s gold`@ in exchange for the %s`@.",$gold,$weapon);
		addnav(array("Buy the %s",$weapon),"runmodule.php?module=ruinworld1&op=purchase&id=$id&cost=gold");
	}elseif ($session['user']['gems']>=$gem && $gem>0){
		if ($usergold>0) output("`@You can't negotiate a price in gold pieces that he finds reasonable.");
		if ($usergold==0) output("`@You realize you don't have any `^gold`@ to negotiate with.");
		output("In desperation, you take out some of your `%gems `@and show them to the store owner.");
		output("He looks them over and slowly starts to smile.");
		output("`n`n`#'I think this could do.  You give me `%%s gem%s`# and you can have this %s`#.'",$gem,translate_inline($gem>1?"s":""),$weapon);
		addnav(array("Buy the %s",$weapon),"runmodule.php?module=ruinworld1&op=purchase&id=$id&cost=gem");
	}else{
		output("`@Although you really like the %s`@, you can't negotiate a reasonable price for it.",$weapon);
	}
}
if ($op=="purchase"){
	output("`b`c`&%s`b`c`n",$shopname);
	set_module_pref("oldweapon",$session['user']['weapon']);
	$usergold=$session['user']['gold'];
	$session['user']['weapon']=get_module_setting("weapon".$id);
	$goldcost=get_module_setting("goldw".$id);
	$weapon=get_module_setting("weapon".$id);
	set_module_pref("weaponbuy",$id);
	$attack=get_module_setting("atkw".$id);
	$defense=get_module_setting("defw".$id);
	output("`@You hand over your");
	if ($cost=="gold"){
		output("`^%s gold",$goldcost);
		$session['user']['gold']-=$goldcost;
	}
	if ($cost=="gem"){
		output("`%%S gem%s",$gemcost,translate_inline($gemcost>1?"s":""));
		$session['user']['gems']-=$gemcost;
	}
	apply_buff("gunbuff",array(
		"name"=>$weapon,
	 	"atkmod"=>$attack,
	 	"defmod"=>$defense,
		"rounds"=>-1,
	));
	set_module_pref("purchased",1);
	output("`@and you gingerly pick up your %s`@ and whip it around feeling pretty tough.",$session['user']['weapon']);
	output("`n`n`#'WHOA WHOA there cowboy.  Don't go waving that thing around like that!");
	output("If you need some time at the practice range, you just head down the hall there.'");
	addnav("Practice Range","runmodule.php?module=ruinworld1&op=practice");
	if ($allowp==1)  addnav("Return to the Display Case","runmodule.php?module=ruinworld1&op=continue");
}
if ($op=="practice"){
	output("`@You head out to the practice room.  There's many different people practicing with their newly purchased weapons.`n`n");
	output("There are a couple of open spaces available.  You will be able to shoot at your target to see how well your weapon handles.");
	output("There's a board over in the corner showing the most accurate users of each weapon.  Perhaps you'll get on the board!");
	addnav("Shoot","runmodule.php?module=ruinworld1&op=attack");
	addnav("Review Records","runmodule.php?module=ruinworld1&op=top10");
}
if ($op=="weapstore"){
	page_header("MightyE's Weapons");
	output("`c`b`&MightyE's Weapons`0`c`b");
	output("`!MightyE`0 looks at your weapon and tells you to leave.");
	output("`n`n\"`#I don't like the looks of that weapon. I think you need to leave. Maybe you can come back tomorrow.`0\"");
	blocknav("runmodule.php?module=ruinworld1&op=leave");
	villagenav();
}
if ($op=="range"){
	$turns=get_module_pref("turns");
	$weapon=$session['user']['weapon'];
	$weaponbuy=get_module_pref("weaponbuy");
	$hofweapon="hof".$weaponbuy;
	output("`@You step back and look at the target with `Q%s holes`@ in it.",$turns);
	output("`n`nA burly man shooting next to you leans over.`^");
	if ($turns<=1) output("'Well now, that's some mighty fine shooting.'");
	if ($turns>=2 && $turns<5) output("'Nice job.  You handle your %s`^ pretty well.'",$weapon);
	if ($turns>=5 && $turns<10) output("'Well, you aren't the best, but I'd say you did reasonably well.'");
	if ($turns>=10 && $turns<20) output("'Yeah, not bad, but you should be glad that paper gun isn't firing at you.'");
	if ($turns>=20 && $turns<30) output("'Hmmm.  Maybe you need a bigger target.  Or a LOT more practice.'");
	if ($turns>=30) output("'I think there's a barn over on the other wall. Maybe you should try shooting that.'");
	output_notl("`n`n");
	if (get_module_pref($hofweapon)>$turns || get_module_pref($hofweapon)==0){
		set_module_pref($hofweapon,$turns);
		$sql = "SELECT name,acctid FROM " . db_prefix("accounts") . " INNER JOIN ".db_prefix("module_userprefs")." WHERE modulename='ruinworld1' AND setting='$hofweapon' AND value>0 ORDER BY (value+0) LIMIT 10";
		$result = db_query($sql);
		if (db_num_rows($result)<10) output("`@You have made it onto the top 10 score board.`n`n");
		else{
			for ($i=0;$i<db_num_rows($result);$i++){
				$row = db_fetch_assoc($result);
				$id = $row['acctid'];
				$name= $row['name'];
				if ($turns<get_module_pref($hofweapon,"ruinworld1",$id)) $madehof=1;
			}
			if ($madehof==1) output("`@You have made it onto the top 10 score board.`n`n");
		}
	}
	set_module_pref("turns",0);
	if ($allowp==1)  addnav("Return to the Display Case","runmodule.php?module=ruinworld1&op=continue");
	addnav(array("`0More %s`0 Practice",$weapon),"runmodule.php?module=ruinworld1&op=attack");
	addnav("Review Top 10 Lists","runmodule.php?module=ruinworld1&op=top10");
	//top 10 list
	output("`n`c`b%s Top 10 Target Practice`c`n",$weapon);
	$sql = "SELECT ".db_prefix("module_userprefs").".value, ".db_prefix("accounts").".name FROM " . db_prefix("module_userprefs") . "," . db_prefix("accounts") . " WHERE acctid = userid AND modulename = 'ruinworld1' AND setting = '$hofweapon' AND value > 0 ORDER BY (value+0) LIMIT 10";
	$result = db_query($sql);
	$rank = translate_inline("Rank");
	$name = translate_inline("Name");
	$shots = translate_inline("Shots");
	rawoutput("<table border='0' cellpadding='2' cellspacing='1' align='center' bgcolor='#999999'>");
	rawoutput("<tr class='trhead'><td>$rank</td><td>$name</td><td>$shots</td></tr>");
	for($i = 0; $i <db_num_rows($result); $i++) {
		$row = db_fetch_assoc($result);
		if ($row['name']==$session['user']['name']){
			rawoutput("<tr class='trhilight'><td>");
		}else{
			rawoutput("<tr class='".($i%2?"trdark":"trlight")."'><td>");
		}
		$j=$i+1;
		output_notl("$j.");
		rawoutput("</td><td>");
		output_notl("`&%s`0",$row['name']);
		rawoutput("</td><td>");
		output_notl("`c`b`Q%s`c`b`0",$row['value']);
		rawoutput("</td></tr>");
	}
	rawoutput("</table>");
}
if ($op=="top10"){
	$weap=$session['user']['weapon'];
	$hofweapon="hof".$id;
	$weapon=get_module_setting("weapon".$id);
	addnav("Top 10 List");
	addnav(array("%s",$weapon1),"runmodule.php?module=ruinworld1&op=top10&id=1");
	addnav(array("%s",$weapon2),"runmodule.php?module=ruinworld1&op=top10&id=2");
	addnav(array("%s",$weapon3),"runmodule.php?module=ruinworld1&op=top10&id=3");
	addnav(array("%s",$weapon4),"runmodule.php?module=ruinworld1&op=top10&id=4");
	addnav(array("%s",$weapon5),"runmodule.php?module=ruinworld1&op=top10&id=5");
	addnav(array("%s",$weapon6),"runmodule.php?module=ruinworld1&op=top10&id=6");
	addnav("Other");
	addnav(array("`0More %s`0 Practice",$weap),"runmodule.php?module=ruinworld1&op=attack");
	if ($allowp==1 || $id==0)  addnav("Return to the Display Case","runmodule.php?module=ruinworld1&op=continue");
	if ($id==0) output("`c`n`@Which list would you like to review?`c");
	else{
	output("`n`c`b%s Top 10 Target Practice`c`n",$weapon);
	$sql = "SELECT ".db_prefix("module_userprefs").".value, ".db_prefix("accounts").".name FROM " . db_prefix("module_userprefs") . "," . db_prefix("accounts") . " WHERE acctid = userid AND modulename = 'ruinworld1' AND setting = '$hofweapon' AND value > 0 ORDER BY (value+0) LIMIT 10";
	$result = db_query($sql);
	$rank = translate_inline("Rank");
	$name = translate_inline("Name");
	$shots = translate_inline("Shots");
	$none = translate_inline("No Scores Recorded Yet");
	rawoutput("<table border='0' cellpadding='2' cellspacing='1' align='center' bgcolor='#999999'>");
	rawoutput("<tr class='trhead'><td>$rank</td><td>$name</td><td>$shots</td></tr>");
	if (db_num_rows($result)==0) output_notl("<tr class='trlight'><td colspan='3' align='center'>`&$none`0</td></tr>",true);
	else{
		for($i = 0; $i <db_num_rows($result); $i++) {
			$row = db_fetch_assoc($result);
			if ($row['name']==$session['user']['name']){
				rawoutput("<tr class='trhilight'><td>");
			}else{
				rawoutput("<tr class='".($i%2?"trdark":"trlight")."'><td>");
			}
			$j=$i+1;
			output_notl("$j.");
			rawoutput("</td><td>");
			output_notl("`&%s`0",$row['name']);
			rawoutput("</td><td>");
			output_notl("`c`b`#%s`c`b`0",$row['value']);
			rawoutput("</td></tr>");
		}
	}
	rawoutput("</table>");
	}
}
if ($op=="leave") {
	$weaplose=get_module_setting("weaplose");
	$armolose=get_module_setting("armolose");
	$session['user']['specialinc']="";
	addnav("To the Forest","forest.php");
	output("`@You turn around and head towards the glowing light in the back of the shop.");
	if (get_module_pref("purchased")==1 && (($weaplose==1 && $session['user']['weapondmg']>0) || ($armolose==1 && $session['user']['armordef']>0))){
		output("`n`nYou try to step through but you don't fit!! It seems like you're carrying too much equipment.");
		output("`\$It looks like you'll have to leave your");
		if ($armolose==1 && $session['user']['armordef']>0) {
			output("old armor");
			$session['user']['defense']-=$session['user']['armordef'];
			$session['user']['armor']=get_module_setting("ndarmor");
			$session['user']['armorvalue']=0;
			$session['user']['armordef'] = 0;
			debuglog("lost their old armor leaving the gunshop.");
		}
		if (($weaplose==1 && $session['user']['weapondmg']>0) && ($armolose==1 && $session['user']['armordef']>0))output("and");
		if ($weaplose==1 && $session['user']['weapondmg']>0){
			output("old weapon");
			clear_module_pref("oldweapon");
		}
		output("behind in order to get back to your world!`@`n`n");
	}
	output("You step through and suddenly notice you're back in the forest!");
	blocknav("runmodule.php?module=ruinworld1&op=leave");
}

if ($op=="attack") {
	$level = $session['user']['level'];
	$badguy = array(
		"creaturename"=>"Practice Target",
		"creaturelevel"=>$level,
		"creatureweapon"=>"Painted Weapon",
		"creatureattack"=>0,
		"creaturedefense"=>$session['user']['defense'],
		"creaturehealth"=>$session['user']['maxhitpoints'],
		"type"=>"practicetarget");
	$session['user']['badguy']=createstring($badguy);
	apply_buff('practice', array(
		"name"=>"Practice Range",
		"rounds"=>-1,
		"invulnerable"=>1,
	));
	$op="fight";
}
if ($op=="fight") {
	$battle=true;
	blocknav("runmodule.php?module=ruinworld1&op=fight&auto=five");
	blocknav("runmodule.php?module=ruinworld1&op=fight&auto=ten");
	blocknav("runmodule.php?module=ruinworld1&op=fight&auto=full");
	increment_module_pref("turns",1);
}
if ($battle){       
	include("battle.php");
	blocknav("runmodule.php?module=ruinworld1&op=leave");
	if ($victory){
		apply_buff('practice', array());
		redirect("runmodule.php?module=ruinworld1&op=range");	
	}elseif($defeat){
		apply_buff('practice', array());
		addnav("Leave","runmodule.php?module=ruinworld1&op=leave");
		addnav("Return to the Display Case","runmodule.php?module=ruinworld1&op=continue");	
	}else{
		require_once("lib/fightnav.php");
		fightnav(false,false,"runmodule.php?module=ruinworld1");
	}
}
addnav("Other");
addnav("Leave","runmodule.php?module=ruinworld1&op=leave");

page_footer();
?>