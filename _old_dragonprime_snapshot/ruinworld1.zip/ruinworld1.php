<?php
/*
Module Name:  ruinworld1.php
Category:  Forest/LostRuins Addon
Worktitle:  Ruin World 1: Gun Shop
Author:  DaveS
Date:  May 10, 2006

Description:
Step into a strange world... Ours! You find yourself in a gun shop ready to buy
a weapon of the future to use in the past.  What will your choice be?

This module also ties into the Lost Ruins module.  It is triggered after a certain
number of counters in the Lost Ruins is hit.  See the Lost Ruins settings for the number.

v3.1	Changed from a Gun Shop into an Advanced Weapons Shop with everything customizable.
v3.11	typo fixed!
v3.12	ending fixed
*/

function ruinworld1_getmoduleinfo(){
	$info = array(
		"name"=>"Ruin World 1: Advanced Weapons Shop",
		"version"=>"3.12",
		"author"=>"DaveS",
		"category"=>"Forest Specials",
		"download"=>"",
		"settings"=>array(
			"Ruin World 1: Advanced Weapons Shop,title",
			"shopname"=>"What is the name of the shop?,text|Guns and Amo Store",
			"forest"=>"Chance to encounter in the forest:,range,1,100,1|100",
			"mindk"=>"Minimum dks for player to encounter the Advanced Weapons Shop:,int|0",
			"allowp"=>"Allow players to buy a different Advanced Weapon if they don't like the first one?,bool|0",
			"weaplose"=>"Make player lose old weapon when they leave the store?,bool|1",
			"ndweapon"=>"If they lost their weapon: Which weapon do they have at the next new day?,text|Fists",
			"armolose"=>"Make player lose armor when they leave the store?,bool|1",
			"ndarmor"=>"If they lost their armor: Which armor do they have upon leaving?,text|T-Shirt",
			"Weapon 1,title",
			"`%Set gem amount to zero to disable the option of paying with gems,note",
			"weapon1"=>"`^What is the name of Weapon 1?,text|`^Beretta",
			"goldw1"=>"`^How much gold does Weapon 1 cost?,int|100",
			"gemw1"=>"`^How many gems does Weapon 1 cost if no gold available?,int|1",
			"atkw1"=>"`^What is Weapon 1's Attack benefit modifier?,floatrange,1.0,3.0,0.1|1.2",
			"defw1"=>"`^What is Weapon 1's Defense penalty modifier?,floatrange,0.60,1.00,0.01|.97",
			"Weapon 2,title",
			"`^Set gold amount to zero to disable the sale of that weapon,note",
			"`%Set gem amount to zero to disable the option of paying with gems,note",
			"weapon2"=>"`@What is the name of Weapon 2?,text|`@Colt 45",
			"goldw2"=>"`@How much gold does Weapon 2 cost?,int|300",
			"gemw2"=>"`@How many gems does Weapon 2 cost if no gold available?,int|2",
			"levelw2"=>"`@Minimum level before player could buy Weapon 2:,int|3",
			"dkw2"=>"`@Minimum number of dks before player can buy Weapon 2:,int|0",
			"atkw2"=>"`@What is Weapon 2's Attack benefit modifier?,floatrange,1.0,3.0,0.1|1.4",
			"defw2"=>"`@What is Weapon 2's Defense penalty modifier?,floatrange,0.60,1.00,0.01|.95",
			"Weapon 3,title",
			"`^Set gold amount to zero to disable the sale of that weapon,note",
			"`%Set gem amount to zero to disable the option of paying with gems,note",
			"weapon3"=>"`!What is the name of Weapon 3?,text|`!Shotgun",
			"goldw3"=>"`!How much gold does Weapon 3 cost?,int|500",
			"gemw3"=>"`!How many gems does Weapon 3 cost if no gold available?,int|3",
			"levelw3"=>"`!Minimum level before player could buy Weapon 3:,int|5",
			"dkw3"=>"`!Minimum number of dks before player can buy Weapon 3:,int|0",
			"atkw3"=>"`!What is Weapon 3's Attack benefit modifier?,floatrange,1.0,3.0,0.1|1.6",
			"defw3"=>"`!What is Weapon 3's Defense penalty modifier?,floatrange,0.60,1.00,0.01|.93",
			"Weapon 4,title",
			"`^Set gold amount to zero to disable the sale of that weapon,note",
			"`%Set gem amount to zero to disable the option of paying with gems,note",
			"weapon4"=>"`%What is the name of Weapon 4?,text|`%Rifle",
			"goldw4"=>"`%How much gold does Weapon 4 cost?,int|850",
			"gemw4"=>"`%How many gems does Weapon 4 cost if no gold available?,int|4",
			"levelw4"=>"`%Minimum level before player could buy Weapon 4:,int|7",
			"dkw4"=>"`%Minimum number of dks before player can buy Weapon 4:,int|0",
			"atkw4"=>"`%What is Weapon 4's Attack benefit modifier?,floatrange,1.0,3.0,0.1|1.8",
			"defw4"=>"`%What is Weapon 4's Defense penalty modifier?,floatrange,0.60,1.00,0.01|.91",
			"Weapon 5,title",
			"`^Set gold amount to zero to disable the sale of that weapon,note",
			"`%Set gem amount to zero to disable the option of paying with gems,note",
			"weapon5"=>"`\$What is the name of Weapon 5?,text|`\$Uzi",
			"goldw5"=>"`\$How much gold does Weapon 5 cost?,int|1100",
			"gemw5"=>"`\$How many gems does Weapon 5 cost if no gold available?,int|5",
			"levelw5"=>"`\$Minimum level before player could buy Weapon 5:,int|9",
			"dkw5"=>"`\$Minimum number of dks before player can buy Weapon 5:,int|0",
			"atkw5"=>"`\$What is Weapon 5's Attack benefit modifier?,floatrange,1.0,3.0,0.1|2.0",
			"defw5"=>"`\$What is Weapon 5's Defense penalty modifier?,floatrange,0.60,1.00,0.01|.85",
			"Weapon 6,title",
			"`^Set gold amount to zero to disable the sale of that weapon,note",
			"`%Set gem amount to zero to disable the option of paying with gems,note",
			"weapon6"=>"`QWhat is the name of Weapon 6?,text|`QAK 47",
			"goldw6"=>"`QHow much gold does Weapon 6 cost?,int|2200",
			"gemw6"=>"`QHow many gems does Weapon 6 cost if no gold available?,int|6",
			"levelw6"=>"`QMinimum level before player could buy Weapon 6:,int|12",
			"dkw6"=>"`QMinimum number of dks before player can buy Weapon 6:,int|0",
			"atkw6"=>"`QWhat Weapon 4's Attack benefit modifier?,floatrange,1.0,3.0,0.1|2.2",
			"defw6"=>"`QWhat Weapon 4's Defense penalty modifier?,floatrange,0.60,1.00,0.01|.75",
		),
		"prefs"=>array(
			"Ruin World 1:  Advanced Weapon Shop Preferences,title",
			"oldweapon"=>"What was the player's old weapon,text|",
			"hearprice"=>"Has player heard the currency spiel?,bool|0",
			"purchased"=>"Has player purchased a weapon today?,bool|0",
			"weaponbuy"=>"Which weapon did the player buy,enum,0,None,1,Weapon 1,2,Weapon 2,3,Weapon 3,4,Weapon 4,5,Weapon 5,6,Weapon 6|0",
			"practice"=>"How many hits did the player use on the firing range?,int|0",
			"Wall of Fame,title",
			"hof1"=>"Record Wall for Weapon 1:,int|0",
			"hof2"=>"Record Wall for Weapon 2:,int|0",
			"hof3"=>"Record Wall for Weapon 3:,int|0",
			"hof4"=>"Record Wall for Weapon 4:,int|0",
			"hof5"=>"Record Wall for Weapon 5:,int|0",
			"hof6"=>"Record Wall for Weapon 6:,int|0",
		),
	);
	return $info;
}
function ruinworld1_chance() {
	global $session;
	$ret= get_module_setting('forest','ruinworld1');
	if ($session['user']['dragonkills']<get_module_setting("mindk","ruinworld1")||get_module_pref("purchased","ruinworld1",$session['user']['acctid'])==1) $ret=0;
	return $ret;
}
function ruinworld1_install(){
	module_addeventhook("forest","require_once(\"modules/ruinworld1.php\");
	return ruinworld1_chance();");
	module_addhook("newday");
	module_addhook("footer-weapons");	
	return true;
}
function ruinworld1_uninstall(){
	return true;
}
function ruinworld1_dohook($hookname,$args){
	global $session;
	switch($hookname){
		case "newday":
			if (get_module_pref("purchased")==1){
				output("`n`4You pick up your %s`4 and get ready to face the day. You suddenly notice that you're out of ammo! This weapon is useless!",$session['user']['weapon']);
				if (get_module_setting("weaplose")==1){
					$ndweapon=get_module_setting("ndweapon");
					output("`\$You remember that you had to leave your old weapon behind in the %s shop and now you've got to resort to your `0trusty %s`\$.`n",get_module_setting("shopname"),$ndweapon);
					$session['user']['attack']-=$session['user']['weapondmg'];
					$session['user']['weapon']=$ndweapon;
					$session['user']['weaponvalue']=0;
					$session['user']['weapondmg'] = 0;
				}else{
					$oldweapon=get_module_pref("oldweapon");
					output("`@Luckily you held onto your %s`@!`n",$oldweapon);
					$session['user']['weapon']=$oldweapon;
				}
				set_module_pref("hearprice",0);
				set_module_pref("purchased",0);
				set_module_pref("weaponbuy",0);
				set_module_pref("practice",0);
				apply_buff("gunbuff", array());
			}
		break;
		case "footer-weapons":
			if (get_module_pref("purchased")==1) redirect("runmodule.php?module=ruinworld1&op=weapstore");
		break;
	}
	return $args;
}
function ruinworld1_runevent($type) {
	redirect("runmodule.php?module=ruinworld1&op=enter");
}
function ruinworld1_run(){
	global $SCRIPT_NAME;
	if ($SCRIPT_NAME == "runmodule.php"){
		$module=httpget("module");
		if ($module == "ruinworld1"){
			include("modules/ruinworld1/ruinworld1.php");
		}
	}
}
?>