<?php
//module builder - put each builder in as a library.... store the module info in prefs as an array
function modulebuilder_getmoduleinfo(){
	global $session;
	$info = array(
		"name"=>"Module Builder",
		"author"=>"Lonny Luberts",
		"version"=>"0.57",
		"category"=>"PQ",
		"download"=>"http://www.pqcomp.com/modules/mydownloads/visit.php?cid=3&lid=175",
		"vertxtloc"=>"http://www.pqcomp.com/",
		"prefs" => array(
			"suaccess"=>"Access to Module Builder?,bool",
			"author"=>"Author Name,text|".$session['user']['name'],
			"usever"=>"Use version file?,bool",
			"vertxtloc"=>"Version file location.,text",
			"downfold"=>"Download folder.,text|http://www.pqcomp.com/modules/mydownloads/visit.php?cid=3&lid=175",
		),
	);
	return $info;
}

function modulebuilder_install(){
	module_addhook("superuser");
	return true;
}

function modulebuilder_uninstall(){
	return true;
}

function modulebuilder_dohook($hookname, $args){
	global $session;
	$card = get_module_pref("card","library");
	switch($hookname){
	case "superuser":
		if (get_module_pref("suaccess") == "1"){
			addnav("Editors");
			addnav("Module Builder", "runmodule.php?module=modulebuilder");
		}
		break;
	}
	return $args;
}

function modulebuilder_run(){
	foreach ($_GET as $key => $value) {
		$$key = $value;
	}
	foreach ($_POST as $key => $value) {
		$$key = $value;
	}
	global $session;
	page_header("Module Builder");
	addnav("Mechanics");
	addnav("`2Set your info","runmodule.php?module=modulebuilder&op=setinfo");
	addnav("`4Saved Modules","runmodule.php?module=modulebuilder&op=savedmodules");
	addnav("Build Modules");
	addnav("`2Book for Library","runmodule.php?module=modulebuilder&op=book");
	addnav("`2Race","runmodule.php?module=modulebuilder&op=race");
	addnav("`2City","runmodule.php?module=modulebuilder&op=city");
	addnav("`2Specialty","runmodule.php?module=modulebuilder&op=specialty");
	addnav("`2Special Event","runmodule.php?module=modulebuilder&op=event");
	addnav("`2Quest for Questpack","runmodule.php?module=modulebuilder&op=quest");
	addnav("`4Dag Quest","runmodule.php?module=modulebuilder&op=dagquest");
	//add a hook... 
	if ($op == "setinfo"){
		if ($author == ""){
			if ($author <> "") output("`4Required Information Missing! Try Again!`n");
			if (get_module_pref("author") <> "") $author = get_module_pref("author");
			if (get_module_pref("verloc") <> "") $verloc = get_module_pref("verloc");
			if (get_module_pref("downloc") <> "") $downloc = get_module_pref("downloc");
			if (get_module_pref("usever") == 1){
				$useveryes = " selected='selected'";
			}else{
				$useverno = " selected='selected'";
			}
			rawoutput("<form action='runmodule.php?module=modulebuilder&op=setinfo' method='post'>");
			rawoutput("Author Name: <input value='".$author."' size='40' name='author'><br>");
			rawoutput("Use Version File? <select name='vertext'><option".$useveryes." value='1'>Yes</option><option".$useverno."  value='0'>No</option></select><br>");
			rawoutput("Version File Location: <input value='".$verloc."' size='50' name='verloc'><br>");
			rawoutput("Download Folder: <input value='".$downloc."' size='50' name='downloc'><br>");
			rawoutput("<input name='Submit' value='Submit' type='submit'></form>");
			addnav("","runmodule.php?module=modulebuilder&op=setinfo");
		}else{
			//save the data
			set_module_pref("author", $author);
			set_module_pref("usever", $vertext);
			set_module_pref("vertxtloc", $verloc);
			set_module_pref("downfold", $downloc);
			output("Saved Settings");
		}
	}elseif ($op == "savedmodules"){
		//manage saved modules... load them, delete them
		//save to an array... first value stores the builder it is for... save as a pref....
	}elseif ($op == "book"){
		include_once("lib/bookbuilder.php");
	}elseif ($op == "specialty"){
		include_once("lib/specialtybuilder.php");
	}elseif ($op == "race"){
		include_once("lib/racebuilder.php");
	}elseif ($op == "event"){
		include_once("lib/eventbuilder.php");
	}elseif ($op == "quest"){
		include_once("lib/questbuilder.php");
	}elseif ($op == "dagquest"){
		//form asking for quest info
	}elseif ($op == "city"){
		include_once("lib/townbuilder.php");
	}
addnav("Navigation");
villagenav();
addnav("Return to Grotto","superuser.php");
page_footer();
}

?>