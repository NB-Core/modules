<?php

function drnknsbar_getmoduleinfo(){
	$info = array(
		"name"=>"Drunkness Bar",
		"version"=>"1.0",
		"author"=>"Death Dragon",
		"category"=>"Stat Display",
		"download"=>"http://dragonprime.net",
		
	);
	return $info;
}

function drnknsbar_install(){
	module_addhook("charstats");
    return true;
}

function drnknsbar_uninstall(){
	return true;
}

function drnknsbar_dohook($hookname,$args){
	global $session;
	switch($hookname){
	case "charstats":
		$drnkns = $session['user']['drunkness'];
	
if ($session['user']['drunkness'] < 21) {
  $i=0;
} elseif ($session['user']['drunkness'] > 20 AND $session['user']['drunkness'] < 41){
  $i=1;
}elseif ($session['user']['drunkness'] > 40 AND $session['user']['drunkness'] < 61){
  $i=2;
}elseif ($session['user']['drunkness'] > 60 AND $session['user']['drunkness'] < 81){
  $i=3;
}elseif ($session['user']['drunkness'] > 80 AND $session['user']['drunkness'] < 101){
  $i=4;
}

$drunk=array(0=>"Sober",1=>"Slightly Buzzed",2=>"Barely Drunk",3=>"Sloshed",4=>"Barely Conscious");

		
		setcharstat("Personal Info", "Drunkness", $drunk[$i]);
		break;
	}
	return $args;
}

function drnknsbar_run(){

}
?>
