NPC code 2.0+
You can upgrade your old NPC's and everything will work as before...

The major change.... the bulk of the code is not loaded into memmory unless it is needed.
So... you now have a lib folder that needs to go into the modules folder with the
included files.  You will then have an npc file in your modules folder and a matching one
in your modules/lib folder.  The file in the lib folder is only called when an NPC 
updates online status or makes a comment.

In short
Upload the NPC file to your modules folder and the lib file into modules/lib.

