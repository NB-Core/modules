<?php
//
function dagnpc_getmoduleinfo(){
	$info = array(
		"name"=>"NPC Characters - Dag",
		"version"=>"2.1",
		"author"=>"`#Lonny Luberts",
		"category"=>"NPCs",
		"download"=>"http://www.pqcomp.com/modules/mydownloads/visit.php?cid=3&lid=41",
		"vertxtloc"=>"http://www.pqcomp.com/",
		"settings"=>array(
			"NPC Characters - Dag Module Settings,title",
			"npcloc"=>"Where does Dag Hang Out?,location|".getsetting("villagename", LOCATION_FIELDS),
			"howmuch"=>"How much does Dag say?,enum,1500,A Lot,2000,Quite a Bit,2500,Less,3000,Seldom,4000,Very Seldom",
			"comment1"=>"Custom Commentary 1,text|Come to me to place a bounty on someone.",
			"comment2"=>"Custom Commentary 2,text|Don't mess with me.",
			"comment3"=>"Custom Commentary 3,text|So many bounties - so little time.",
			"npcid"=>"NPC User id,int",
			"sex"=>"NPC Sex,enum,0,Male,1,Female",
			"name"=>"NPC Name,text|`3Dag `#Durnik",
		),
	);
	return $info;
}

function dagnpc_install(){
	$password=$_POST['pw'];
	if (!is_module_active('dagnpc')){
		output("`4Installing NPC Characters - Dag Module.`n");
		if ($password){
		$sql = "INSERT INTO ".db_prefix("accounts")." (login,name,sex,specialty,level,defense,attack,alive,laston,hitpoints,maxhitpoints,gems,password,emailvalidation,title,weapon,armor,race) VALUES ('dagnpc','`3Dag `#Durnik','0','1','15','1000','1000','1','".date("Y-m-d H:i:s")."','1000','1000','10','".md5(md5("$password"))."','','`3Dag','`#Switch Blade','`!Body Guards','Human')";
		db_query($sql) or die(db_error(LINK));
			if (db_affected_rows(LINK)>0){
				output("`2Installed Dag!`n");
			}else{
				output("`4Dag install failed!`n");
			}
			$sql = "SELECT acctid FROM ".db_prefix("accounts")." where login = 'dagnpc'";
			$result = mysql_query($sql) or die(db_error(LINK));
			$row = db_fetch_assoc($result);
			if ($row['acctid'] > 0){
				set_module_setting("npcid",$row['acctid']);
				output("`2Set Accout ID for Dag to ".$row['acctid'].".`n");
			}else{
				output("`4Failed to Set Account ID for Dag!`n");
			}
		}else{
			$sqlz = "SELECT acctid FROM ".db_prefix("accounts")." where login = 'dagnpc'";
			$resultz = mysql_query($sqlz) or die(db_error(LINK));
			$rowz = db_fetch_assoc($resultz);
			if ($rowz['acctid'] > 0){
			}else{
				output("Dag's Login will be dagnpc.`n");
				output("What would you like the password for Dag's account to be?`n");
				$linkcode="<form action='modules.php?op=install&module=dagnpc' method='POST'>";
				output("%s",$linkcode,true);
				$linkcode="<p><input type=\"text\" name=\"pw\" size=\"37\"></p>";
				output("%s",$linkcode,true);
				$linkcode="<p><input type=\"submit\" value=\"Submit\" name=\"B1\"><input type=\"reset\" value=\"Reset\" name=\"B2\"></p>";
				output("%s",$linkcode,true);
				$linkcode="</form>";
				output("%s",$linkcode,true);
				addnav("","modules.php?op=install&module=dagnpc");
			}
		}
	}else{
		output("`4Updating NPC Characters - Dag Module.`n");
	}
	if (is_module_active('whoshere')){
		set_module_pref('playerloc',"village.php",'whoshere',get_module_setting('npcid'));
	}
	module_addhook("village");
	return true;
}

function dagnpc_uninstall(){
	output("`4Un-Installing NPC Characters - Dag Module.`n");
	$sql = "DELETE FROM ".db_prefix("accounts")." where acctid='".get_module_setting('npcid')."'";
	mysql_query($sql);
	output("Dag deleted.`n");
	return true;
}

function dagnpc_dohook($hookname,$args){
	global $session;
	if (get_module_setting('lastupdate') < date("Y-m-d H:i:s")){
		require_once("modules/lib/dagnpc.php");
		dagnpc_update();
	}
	if (get_module_setting('npcloc') == $session['user']['location'] AND e_rand(1,get_module_setting('howmuch')) < 21){
		require_once("modules/lib/dagnpc.php");
		dagnpc_comment();
	}
	return $args;
}
?>