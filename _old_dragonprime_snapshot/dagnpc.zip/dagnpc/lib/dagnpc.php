<?php
function dagnpc_update(){
	set_module_setting('lastupdate',date("Y-m-d H:i:s",strtotime("+ 300 seconds")));
	$sqlz2="UPDATE ".db_prefix("accounts")." SET laston = '".date("Y-m-d H:i:s",strtotime("+ 300 seconds"))."', alive = '1', loggedin = '1', lasthit = '".date("Y-m-d H:i:s",strtotime("+ 300 seconds"))."', location = '".get_module_setting('npcloc')."', hitpoints = '1000' WHERE acctid = '".get_module_setting('npcid')."'";
	mysql_query($sqlz2) or die(db_error(LINK));
	$sqlz2 = "DELETE FROM ".db_prefix("mail")." WHERE msgto='".get_module_setting('npcid')."'";
	mysql_query($sqlz2) or die(db_error(LINK));
}

function dagnpc_comment(){
	global $session,$texts;
	//now lets say something
	$howmuch = e_rand(1,get_module_setting('howmuch'));
	//set smilies
	$j = e_rand(1,20);
	$smile = array(1=>"*grin*",2=>"*happy*",3=>"*laugh*",4=>"*wink*",5=>"*slimer*",6=>"*biggrin*",7=>"*tongue*",8=>"*wink2*",9=>"*wink3*",10=>"",11=>"",12=>"",13=>"",14=>"",15=>"",16=>"",17=>"",18=>"",19=>"",20=>"");
	//end set smilies
	//setup commentary array
	$k = e_rand(1,51);
	$sayit = array(
				1=>get_module_setting('comment1'),
				2=>get_module_setting('comment1'),
				3=>get_module_setting('comment2'),
				4=>get_module_setting('comment2'),
				5=>get_module_setting('comment3'),
				6=>get_module_setting('comment3'),
				7=>"Hello everyone. ".$smile[$j]." ",
				8=>"What's up? *biggrin*",
				9=>"Whazzzzzzzup....",
				10=>"Is it just me, or does anyone else have a clue?",
				11=>"What is it with you people?",
				12=>"Get a life!",
				13=>"::gives ".$session['user']['name']." a hug",
				14=>"What has one got to do to get a little attention around here?",
				15=>"Ack....",
				16=>"::sits around waiting for words or wisdom to come from SOMEONE.",
				17=>"Beat it loser!",
				18=>"Is there anyone here with and IQ larger than their shoe size?",
				19=>"I think not.",
				20=>"Doh!",
				21=>":: slams an Ale ".$smile[$j]." ",
				22=>":: falls asleep ".$smile[$j]." ",
				23=>":: slaps ".$session['user']['name']." ".$smile[$j]." ",
				24=>":: wishes ".(get_module_setting('sex')?"she":"he")." were a real person ".$smile[$j]." ",
				25=>"What? ".$smile[$j]." ",
				26=>"Are you nuts? ".$smile[$j]." ",
				27=>"Are you crazy? ".$smile[$j]." ",
				28=>"Someone let me out of this game! ".$smile[$j]." ",
				29=>"This one time at Band Camp.... ".$smile[$j]." ",
				30=>"Huh? ".$smile[$j]." ",
				31=>"Hi ".$session['user']['name']." ".$smile[$j]." ",
				32=>"Hey ".$session['user']['name']." ".$smile[$j]." ",
				33=>"*news*".get_module_setting('name')." `7has fallen and can't get up.",
				34=>"*news*".$session['user']['name']." `7has fallen and can't get up.",
				35=>"*news*".get_module_setting('name')." `7has a few too many ale's at the inn.",
				36=>"::pokes ".$session['user']['name'],
				37=>":: kicks ".$session['user']['name']." ".$smile[$j]." ",
				38=>":: Gives ".$session['user']['name']." `&a wedgie. ".$smile[$j]." ",
				39=>":: puts a kick-me sign on ".$session['user']['name']."'s `&back ".$smile[$j]." ",
				40=>":: takes ".$session['user']['name']."'s ".$session['user']['weapon']." `&and shoves it up their nose. ".$smile[$j]." ",
				41=>"You want a piece of me ".$session['user']['name']."\? ".$smile[$j]." ",
				42=>"Do you smell something bad?  Oh it's just ".$session['user']['name']."\. ".$smile[$j]." ",
				43=>$session['user']['name']." may look like an idiot and talk like an idiot but don't let that fool you. ".($session['user']['sex']?"She":"He")." really is an idiot. ".$smile[$j]." ",
				44=>$session['user']['name']."  Are you always this stupid or are you making a special effort today? ".$smile[$j]." ",
				45=>$session['user']['name']."  Don't let you mind wander - it's far too small to be let out on its own ".$smile[$j]." ",
				46=>$session['user']['name']."  doesn't know the meaning of the word fear - but then again ".($session['user']['sex']?"she":"he")." doesn't know the meaning of most words. ".$smile[$j]." ",
				47=>$session['user']['name']."  Oh my God, look at you. Anyone else hurt in the accident? ".$smile[$j]." ",
				48=>"Hey ".$session['user']['name']." do you still love nature, despite what it did to you? ".$smile[$j]." ",
				49=>"Hey ".$session['user']['name']." I've seen people like you before, but I had to pay admission!  ".$smile[$j]." ",
				50=>"Hey ".$session['user']['name']." how did you get here? Did someone leave your cage open?  ".$smile[$j]." ",
				51=>"Hey ".$session['user']['name']." you've got the perfect weapon - yer face.  ".$smile[$j]." ",
				);
	//end setup commentary array
	if (strchr($sayit[$k],"*news*")){
		addnews(str_replace("*news*","",$sayit[$k]));
	}else{
		mysql_query("INSERT INTO ".db_prefix("commentary")." (postdate,section,author,comment) VALUES (now(),'".$texts['section']."','".get_module_setting('npcid')."',\"".$sayit[$k]."\")");
	}
}
?>