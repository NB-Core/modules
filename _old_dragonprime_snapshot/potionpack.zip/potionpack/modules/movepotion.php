<?php
/*
Details:
 * This allows users to buy potions and travel around the world
History Log:
 * Version 1.0:
   o Now being tested
 * Version 1.1:
   o Fixed to work with newbie island
 * Version 1.2:
   o Fixed bug with addnav
 * Version 1.3:
   o Admin can have access to all potions
 * Version 1.4:
   o Download link fixed
 * Version 1.5:
   o Works with the World Map (0.6-'worldmapen') module.
 * Version 1.6:
   o Now puts the potions into columns
 * Version 1.7:
   o Has two better potion pictures
   o CSS makes the links look better
 * Version 1.8:
   o New DHTML tooltip script.. with legal notice...
   o <REMOVED>
 * Version 1.9:
  o Now works with Webpixie's Backpack mod
 * Version 2.0:
  o Now allows other potions
 * Version 2.1:
  o Textual fix
 * Version 2.2:
  o Had the arguments mixed up for moderate
 * Version 2.3:
  o Potions didn't always disappear
 * Version 2.4:
  o Now uses the 'potionshop' module
*/
require_once("lib/commentary.php");
require_once("lib/villagenav.php");

function movepotion_getmoduleinfo(){
	$info = array(
		"name"=>"Motion Potions",
		"version"=>"2.4",
		"author"=>"`@CortalUX",
		"category"=>"Potions",
		"vertxtloc"=>"http://dragonprime.net/users/CortalUX/",
		"download"=>"http://dragonprime.net/users/CortalUX/movepotion.zip",
		"allowanonymous"=>true,
		"override_forced_nav"=>false,
		"settings"=>array(
			"Motion Potions - Settings,title",
			"movebuy"=>"Allow users to buy motion potions?,bool|1",
			"pCost"=>"Cost of potions?,int|1000",
			"invDemon"=>"Name of invalid location Demon?,text|Xaxziban",
			"adminPotion"=>"Admin have access to all potions?,bool|1",
			"(admin are those that can edit users),note",
			"allowMap"=>"Allow users to use this when viewing their map?,bool|1",
			"Motion Potions - Locations,title",
			"notAllowed"=>"Cannot travel to?,text|-=NONE=-",
			"(You can place a comma seperated list above of towns users cannot travel to),note",
		),
		"prefs"=>array(
			"Potions - Preferences,title",
			"potions"=>"Motion Potions?,text|",
			"freepot"=>"Free Motion Potions?,int|0",
		),
	);
	return $info;
}

function movepotion_install(){
	if (!is_module_active('movepotion')){
		output("`n`Q`b`cInstalling Motion Potions Module.`c`b`n");
	}else{
		output("`n`Q`b`cUpdating Motion Potions Module.`c`b`n");
	}
	if (file_exists('images/movepotion/potionclear.png')) {
		if (is_writable('images/movepotion/potionclear.png')) {
			unlink('images/movepotion/potionclear.png');
		} else {
			output("`n`@`b`cDelete file: `^images/movepotion/potionclear.png`c`b`n");
		}
	}
	module_addhook("potionshop-list");
	module_addhook("backpack");
	module_addhook("header-runmodule");
	module_addhook("charstats");
	return true;
}

function movepotion_uninstall(){
	output("`n`Q`b`cUninstalling Motion Potions Module.`c`b`n");
	return true;
}

function movepotion_dohook($hookname,$args){
	global $session,$SCRIPT_NAME;
	switch($hookname){
		case "potionshop-list":
			if (get_module_setting('movebuy')==1) {
				$price = get_module_setting('pCost');
				if ($price<=0) $price = 1;
				$mov=array();
				$mov['gold']=$price;
				$mov['name']=translate_inline("Motion Potions");
				$mov['avail']=translate_inline("In Stock");
				$mov['nav']=translate_inline("Buy a `%Motion`0 Potion");
				$mov['effects']=translate_inline("Allows you to transport from one city to another.");
				$mov['link']="runmodule.php?module=movepotion&op=shop";
				$args[]=$mov;
			}
		break;
		case "backpack":
			if (get_module_pref('check_show','potionshop')) {
				if (get_module_pref('potions')!='') {
					movepotion_potionshow();
				}
				if (get_module_pref('freepot')>0) {
					output("`n`^You can claim up to `@%s`^ free Motion Potions...`n",get_module_pref('freepot'));
				}
			}
		break;
		case "header-runmodule":
			$m = httpget('module');
			if ($m=='worldmapen'||$m=='worldmap') {
				$op = httpget('op');
				$su = httpget('su');
				if ($op=='viewmap'||$op=='beginjourney'||$su=='1') {
					if (get_module_setting('allowMap')==1) {
						if (get_module_pref('potions')!='') {
							$potions = movepotion_potions();
							$potion = "";
							$x = count($potions);
							$y = 0;
							$z = $x-1;
							output("`n`#Click on a name to use a Magical Motion Potion...`n`@");
							$string="";
							foreach ($potions as $name => $loc) {
								$y++;
	  							$string .= "<a border='0' class='colLtYellow' style='border:0;' href=\"runmodule.php?module=movepotion&op=use&w=".urlencode($loc)."\">".$loc."</a>";
	  							addnav("","runmodule.php?module=movepotion&op=use&w=".urlencode($loc));
	  							if ($y==$z) {
									$string.=" ".translate_inline("and")." ";
								} elseif ($y==$x) {
									$string.=".";
								} else {
									$string.=", ";
								}
							}
							rawoutput($string);
							rawoutput("<hr>");
						}	
					}
				}
			}
		break;
		case "charstats":
			if (get_module_setting('adminPotion')==1&&$session['user']['superuser']&SU_EDIT_USERS) {
				$vloc = array();
				$vname = getsetting("villagename", LOCATION_FIELDS);
				$vloc[$vname] = "village";
				$vloc = modulehook("validlocation", $vloc);
				if (is_module_active('newbieisland')) {
					$t = get_module_setting('villagename','newbieisland');
					unset($vloc[$t]);
				}
				$x=array();
				foreach ($vloc as $blah=>$v) {
					$x[]=$blah;
				}
				$pot = implode('|@^@|',$x);
				set_module_pref('potions',$pot);
			}
			if (get_module_pref('potions')!='') {
				$potions = movepotion_potions();
				$potion = "";
				$x = 0;
				$b = translate_inline("Potion");
				if (!strstr($SCRIPT_NAME, "village")&&!strstr($SCRIPT_NAME, "superuser")) {
					$c = translate_inline("Potions cannot be used here.");
					$potion .= "<div style='cursor: help;display:compact;' onMouseover=\"ddrivetip('$c', 'ffdf7b')\"; onMouseout=\"hideddrivetip()\">";
				}
				foreach ($potions as $name => $loc) {
					$x++;
					if (!strstr($SCRIPT_NAME, "village")&&!strstr($SCRIPT_NAME, "superuser")) {
						$potion.="<img src=\"./images/movepotion/potionclear.gif\" title=\"$b\" alt=\"$b\" style=\"width:14px; height:20px;\">";
					} else {
						$b = translate_inline("Potion for %s");
						$b = str_replace('%s',$loc,$b);
					  	$stuff = "<img src=\"./images/movepotion/potion.gif\" title=\"$b\" alt=\"$b\" style=\"width:14px; height:20px; border:0;\">";
					  	if ($session['user']['location']!=$loc) {
						  	$c=translate_inline("Takes you to ").$loc;
						  	$c=str_replace("'","\'",$c);
						  	$c=str_replace('"','\"',$c);
						  	$stuff="<a border='0' onMouseover=\"ddrivetip('$c', '94f394')\"; onMouseout=\"hideddrivetip()\" style='border:0;' href=\"runmodule.php?module=movepotion&op=use&w=".urlencode($loc)."\">".$stuff."</a>";
						  	addnav("","runmodule.php?module=movepotion&op=use&w=".urlencode($loc));
					  	} else {
						  	$stuff = "<img src=\"./images/movepotion/potionclear.gif\" title=\"$b\" alt=\"$b\" style=\"width:14px; height:20px; border:0;\">";
						  	$c=translate_inline("Your current location");
						  	$stuff="<a border='0' onMouseover=\"ddrivetip('$c', 'ffdf7b')\"; onMouseout=\"hideddrivetip()\" style='border:0;' href=\"runmodule.php?module=movepotion&op=use&w=".urlencode($loc)."\">".$stuff."</a>";
					  	}
					  	$potion.=$stuff;
					}
					if ($x>=4) {
						$x=0;
						$potion.="\n<br/>";
					}
				}
				if (!strstr($SCRIPT_NAME, "village")&&!strstr($SCRIPT_NAME, "superuser")) {
					$potion .= "</div>";
				}
				addcharstat("Click and use Items");
				addcharstat("Motion Potions", $potion);
			}
		break;
	}
	return $args;
}

function movepotion_potions() {
	$p = get_module_pref('potions');
	$p = explode('|@^@|',$p);
	$x = array();
	foreach ($p as $val) {
		if ($val!='') {
			$x[]=$val;
		}
	}
	return $x;
}

function movepotion_run(){
	global $session;
	$op = httpget('op');
	switch ($op) {
		case "use":
			$vloc = array();
			$vname = getsetting("villagename", LOCATION_FIELDS);
			$vloc[$vname] = "village";
			$vloc = modulehook("validlocation", $vloc);
			$w = urldecode(httpget('w'));
			$p = movepotion_potions();
			if (is_module_active('newbieisland')) {
				$t = get_module_setting('villagename','newbieisland');
				unset($vloc[$t]);
			}
			$b=0;
			$x = array();
			foreach ($p as $val) {
					if ($val==$w&&$b==0) {
						$b=1;
					} else {
						$x[]=$val;
					}
			}
			$x=implode('|@^@|',$x);
			set_module_pref('potions',$x);
			if (isset($vloc[$w])) {
				$session['user']['location']=$w;
				page_header("With the power of wind..");
				output("`@Gulping down an airy ethereal potion, summoning the power of wind, the universe is played as a mortal would strum a lute... the skein of realms shudders, and a great chord rings... a whirlwind of power, created by the ancients, appears to convey you across the great chasm of land...");
				addnav("Step into the Whirlwind","village.php");
			} else {
				page_header("Stopped by a barrier of fire..");
				output("`@Gulping down a burning potion, the world seems to burn in flames around ye, as a barrier of fire traps you in %s... a might Demon appears.`n`3\"`&I am `^%s`&. I am a mighty power... %s had no right to send you to my realm, though it was not yet your fault, puny being. I will speak with %s, and he will yet recompense you for your trouble.`3\" says %s.`n`@Shocked, you just numbly nod.",$session['user']['location'],get_module_setting('invDemon'),"`#CortalUX`&","`#CortalUX`&",get_module_setting('invDemon'));
				set_module_pref('freepot',get_module_pref('freepot')+1);
				villagenav();
			}
			page_footer();
		break;
		case "shop":
			page_header("Magical Potion Shoppe");
			$price = get_module_setting('pCost');
			if ($price<=0) $price = 1;
			$ty = urldecode(httpget('ty'));
			modulehook("potionshop-navs");
			if ($ty=='') {
				output("%s `3states, \"`%Motion Potions`& currently cost `%%s`& gold.`3\"","`#CortalUX",$price);
				if (get_module_pref('freepot')>0) {
					output("`n%s `3notes, \"`&Actually, I see that ye can claim up to `^%s`& free Motion Potions..`3\"`n`n","`#CortalUX",get_module_pref('freepot'));
				}
				output("`n`n`#`b`cWhere'd you wanna go to?`nChoose a potion.`c`b`0");
				movepotion_potionshow();
				addnav("Motion Potions");
				$price = get_module_setting('pCost');
				if ($price<=0) $price = 1;
				$vloc = array();
				$vname = getsetting("villagename", LOCATION_FIELDS);
				$vloc[$vname] = "village";
				$vloc = modulehook("validlocation", $vloc);
				if (is_module_active('newbieisland')) {
					$t = get_module_setting('villagename','newbieisland');
					unset($vloc[$t]);
				}
				ksort($vloc);
				reset($vloc);
				$i = explode(',',get_module_setting('notAllowed'));
				foreach ($i as $val) {
					if ($val!='') {
						if (isset($vloc[$val])) unset($vloc[$val]);
					}
				}
				foreach($vloc as $loc=>$val) {
					addnav(array("%s", $loc), "runmodule.php?module=movepotion&op=shop&ty=".urlencode($loc));
				}
			} else {
				if ($session['user']['gold']>=$price||get_module_pref('freepot')>0) {
					if (get_module_pref('freepot')>0) {
						set_module_pref('freepot',get_module_pref('freepot')-1);
						output("`@Attempting to hand `^%s`@ gold to `#CortalUX`@, he ignores you, speaks of demons and `&free potions`@, slowly moves to a shelf, and, with great difficulty, removes a dusty potion bottle..`n`3\"`&Careful! Take this within a village, and move from place to place...`3\"",$price);
					} else {
						$session['user']['gold']-=$price;
						output("`@Handing `^%s`@ gold to `#CortalUX`@, he slowly moves to a shelf, and, with great difficulty, removes a dusty potion bottle..`n`3\"`&Careful! Take this within a village, and move from place to place...`3\"",$price);
					}
					$p = movepotion_potions();
					$p[]=$ty;
					set_module_pref('potions',implode('|@^@|',$p));
				} else {
					output("`#CortalUX`@ stares at you.`n`3\"`&Ye do not have enough gold!`3\"");
				}
				output_notl('`n`n');
				movepotion_potionshow();
			}
			page_footer();
		break;
	}
}

function movepotion_potionshow() {
	$potions = movepotion_potions();
	$potion = "";
	$x = count($potions);
	$y = 0;
	$z = $x-1;
	$string="`n".translate_inline("`QYou have the following 'Motion Potions'..")."`n";
	foreach ($potions as $loc) {
		$y++;
		$string .= "`^$loc";
		if ($y==$z) {
			$string.=" ".translate_inline("and")." ";
		} elseif ($y==$x) {
			$string.=".`n";
		} else {
			$string.=", ";
		}
	}
	output_notl($string);
}
?>