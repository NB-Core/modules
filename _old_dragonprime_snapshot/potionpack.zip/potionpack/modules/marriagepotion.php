<?php
/*
Details:
 * This allows users to buy potions that take them to whatever city their spouse is in
History Log:
 * Version 1.0:
  o Seems Stable
*/
require_once('lib/e_rand.php');

function marriagepotion_getmoduleinfo(){
	$info = array(
		"name"=>"Marriage Potions",
		"version"=>"1.0",
		"author"=>"`@CortalUX",
		"category"=>"Potions",
		"vertxtloc"=>"http://dragonprime.net/users/CortalUX/",
		"download"=>"http://dragonprime.net/users/CortalUX/marriagepotion.zip",
		"settings"=>array(
			"Marriage Potions - Settings,title",
			"marbuy"=>"Allow users to buy marriage potions?,bool|1",
			"pCost"=>"`#Cost of the marriage potions?,int|1200",
			"adminPotion"=>"`@Admin have unlimited access to marriage potions?,bool|1",
		),
		"prefs"=>array(
			"Potions - Preferences,title",
			"marPot"=>"Marriage potions?,int|0",
		),
		"requires"=>array(
			"potionshop"=>"1.0|`@CortalUX, http://dragonprime.net/users/CortalUX/potionshop.zip",
		),
	);
	return $info;
}

function marriagepotion_install(){
	if (!is_module_active('marriagepotion')) {
		output("`n`Q`b`cInstalling Marriage Potions Module.`c`b`n");
	}else{
		output("`n`Q`b`cUpdating Marriage Potions Module.`c`b`n");
	}
	module_addhook("backpack");
	module_addhook("charstats");
	module_addhook("potionshop-list");
	return true;
}

function marriagepotion_uninstall(){
	output("`n`Q`b`cUninstalling Marriage Potions Module.`c`b`n");
	return true;
}

function marriagepotion_dohook($hookname,$args){
	global $session,$SCRIPT_NAME,$battle;
	switch($hookname){
		case "backpack":
			if (get_module_pref('check_show','potionshop')) {
				if (get_module_pref('marPot')>0) {
					output("`n`^You have `@%s`^ Marriage Potions...`n",get_module_pref('marPot'));
				}
			}
		break;
		case "charstats":
			$potion="";
			if (get_module_setting('adminPotion')==1&&$session['user']['superuser']&~SU_DOESNT_GIVE_GROTTO) {
				set_module_pref('marPot',1);
			}
			if (get_module_pref('marPot')>0&&$session['user']['marriedto']!=0&&$session['user']['marriedto']!=4294967295) {
				$i = false;
				if ($battle===false||!isset($battle)||empty($battle)) {
					if (httpget('module')==''&&$session['user']['specialinc']==''&&$session['user']['specialmisc']==''&&$session['user']['loggedin']==1&&isset($session['user']['loggedin'])) {
						$i=true;
					}
				}
				$c = translate_inline("Marriage Potions cannot be used here");
				$sql = "SELECT loggedin FROM `".db_prefix("accounts")."` WHERE acctid=".$session['user']['marriedto']." AND locked=0";
				$result = db_query($sql);
				$row=db_fetch_assoc($result);
				if ($i===false) {
					$potion .="<div style='cursor: help;display:compact;' onMouseover=\"ddrivetip('$c', 'ffdf7b')\"; onMouseout=\"hideddrivetip()\">";
					$potion .="<img src=\"./images/marriagepotion/potionclear.gif\" title=\"$c\" alt=\"$c\">";
					$potion .="</div>";
				} elseif ($row['loggedin']==0) {
					$c = translate_inline("Your spouse is not logged in");
					$potion .="<div style='cursor: help;display:compact;' onMouseover=\"ddrivetip('$c', 'ffdf7b')\"; onMouseout=\"hideddrivetip()\">";
					$potion .="<img src=\"./images/marriagepotion/potionclear.gif\" title=\"$c\" alt=\"$c\">";
					$potion .="</div>";
				} else {
					$x = get_module_pref('marPot');
					$y = 0;
					$c = translate_inline("Drink the Marriage Potion...");
					while ($x>0) {
						$y++;
						$x--;
						$potion.="<a style='border:0;' border='0' onMouseover=\"ddrivetip('$c', '94f394')\"; onMouseout=\"hideddrivetip()\" style='border:0;' href=\"runmodule.php?module=marriagepotion&op=use\"><img src=\"./images/marriagepotion/potion.gif\" style='border:0;' title=\"$c\" alt=\"$c\"></a>";
						addnav("","runmodule.php?module=marriagepotion&op=use");
						if ($y>=3) {
							$y=0;
							$potion.="\n<br/>";
						}
					}
				}
			}
			addcharstat("Click and use Items");
			if ($potion!="") addcharstat("Marriage Potions", $potion);
		break;
		case "potionshop-list":
			if (get_module_setting('marbuy')==1&&$session['user']['marriedto']!=0&&$session['user']['marriedto']!=4294967295) {
				$price = get_module_setting('pCost');
				if ($price<=0) $price = 1;
				$not=array();
				$not['gold']=$price;
				$not['name']=translate_inline("Marriage Potions");
				$not['link']="runmodule.php?module=marriagepotion&op=shop";
				$not['avail']=translate_inline("In Stock");
				$not['nav']=translate_inline("Buy a `!Marriage`0 Potion");
				$not['effects']=translate_inline("This potion will place you in the same town as your spouse.");
				$args[]=$not;
			}
		break;
	}
	return $args;
}

function marriagepotion_run(){
	global $session;
	$op = httpget('op');
	switch ($op) {
		case "use":
			page_header("Your Bond..");
			if ($session['user']['marriedto']!=0&&$session['user']['marriedto']!=4294967295) {
				$sql = "SELECT name,loggedin,location,sex FROM `".db_prefix("accounts")."` WHERE acctid=".$session['user']['marriedto']." AND locked=0";
				$result = db_query($sql);
				if (db_num_rows($result)>0) {
					$row=db_fetch_assoc($result);
					if ($row['loggedin']==1) {
						$vloc = array();
						$vname = getsetting("villagename", LOCATION_FIELDS);
						$vloc[$vname] = "village";
						$vloc = modulehook("validlocation", $vloc);
						$t=$row['location'];
						if (isset($vloc[$t])) {
							set_module_pref('marPot',get_module_pref('marPot')-1);
							$session['user']['location']=$t;
							output("`@You gulp down the boiling potion, and your bond of love is strengthened with %s`@, and you are drawn to %s`@ location... you are in %s`@.",$row['name'],($row['sex']?translate_inline("her"):translate_inline("his")),$row['location']);
							addnav("Your bond-mate's location..","village.php");
						} else {
							output("`@%s`@ isn't in a town...",$row['name']);
							villagenav();
						}
					} else {
						output("`@%s`@ isn't logged in...",$row['name']);
						villagenav();
					}
				} else {
					output("`@You aren't married to a real person..");
					villagenav();
				}
			} else {
				output("`@You aren't married..");
				villagenav();
			}
			page_footer();
		break;
		case "shop":
			page_header("Magical Potion Shoppe");
			$price = get_module_setting('pCost');
			if ($price<=0) $price = 1;
			if ($session['user']['gold']>=$price) {
				set_module_pref('marPot',get_module_pref('marPot')+1);
				$session['user']['gold']-=$price;
				output("`@Handing %s gold to %s, he hands you a potion, \"`&This is a marriage potion.. it will draw upon your bond of love, and unite yeh..`3\"",$price,"`#CortalUX`@");
			} else {
				output("%s stares at you.`n`3\"`&Ye do not have enough gold!`3\"","`#CortalUX`@");
			}
			modulehook("potionshop-navs");
			page_footer();
		break;
	}
}
?>