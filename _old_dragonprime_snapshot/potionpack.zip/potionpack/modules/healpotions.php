<?php
/*
Details:
 * This allows users to buy healing potions from Lonnyl's healing potions module
History Log:
 * Version 1.0
  o Seems Stable
*/

function healpotions_getmoduleinfo(){
	$info = array(
		"name"=>"Heal Potions",
		"version"=>"1.0",
		"author"=>"`@CortalUX",
		"category"=>"Potions",
		"vertxtloc"=>"http://dragonprime.net/users/CortalUX/",
		"download"=>"http://dragonprime.net/users/CortalUX/healpotions.zip",
		"requires"=>array(
			"potionshop"=>"1.0|`@CortalUX, http://dragonprime.net/users/CortalUX/potionshop.zip",
			"potions"=>"1.43|`#Lonny Luberts, http://www.pqcomp.com/modules/mydownloads/visit.php?cid=3&lid=12",
		),
	);
	return $info;
}

function healpotions_install(){
	if (!is_module_active('healpotions')) {
		output("`n`Q`b`cInstalling Heal Potions Module.`c`b`n");
	}else{
		output("`n`Q`b`cUpdating Heal Potions Module.`c`b`n");
	}
	module_addhook("potionshop-list");
	return true;
}

function healpotions_uninstall(){
	output("`n`Q`b`cUninstalling Heal Potions Module.`c`b`n");
	return true;
}

function healpotions_dohook($hookname,$args){
	global $session,$SCRIPT_NAME;
	switch($hookname){
		case "potionshop-list":
			$price = (log($session['user']['level']) * ($session['user']['maxhitpoints'])) + (log($session['user']['level'])*10);
			if ($price == 0) $potioncost=$session['user']['dragonkills']*5;
			$upotion  = get_module_pref("potion",'potions');
			$not=array();
			$not['gold']=round(100*$price/100,0);
			$not['name']=translate_inline("Healing Potions");
			if ($upotion<5){
				$not['link']="runmodule.php?module=healpotions&op=shop";
				$not['avail']=translate_inline("In Stock`nFlown in from the Healers Hut");
			} else {
				$not['link']="";
				$not['avail']=translate_inline("Out of Stock");
			}
			$not['nav']=translate_inline("Buy a `&Healing`0 Potion");
			$not['effects']=translate_inline("Allows you to Heal yourself.");
			$args[]=$not;
		break;
	}
	return $args;
}

function healpotions_run(){
	global $session;
	$op = httpget('op');
	switch ($op) {
		case "shop":
			page_header("Magical Potion Shoppe");
			$price = (log($session['user']['level']) * ($session['user']['maxhitpoints'])) + (log($session['user']['level'])*10);
			if ($price <= 0) $potioncost=$session['user']['dragonkills']*5;
			$price=round(100*$price/100,0);
			if ($session['user']['gold']>=$price) {
				set_module_pref('potion',get_module_pref('potion','potions')+1,'potions');
				$session['user']['gold']-=$price;
				output("`@Handing %s gold to %s, he hands you a healing potion, \"`&This is a healing potion... I get em flown in from the forest, by carrier dragon!..`3\"",$price,"`#CortalUX`@");
			} else {
				output("%s stares at you.`n`3\"`&Ye do not have enough gold!`3\"","`#CortalUX`@");
			}
			modulehook("potionshop-navs");
			page_footer();
		break;
	}
}

function healpotions_form() {
	global $session;
	$n = httppost("n");
	rawoutput("<form action='runmodule.php?module=healpotions&op=use&stage=1' method='POST'>");
	addnav("","runmodule.php?module=healpotions&op=use&stage=1");
	if ($n!="") {
		$string="%";
		for ($x=0;$x<strlen($n);$x++){
			$string .= substr($n,$x,1)."%";
		}
		$sql = "SELECT login,name,acctid FROM ".db_prefix("accounts")." WHERE name LIKE '%$string%' AND acctid<>".$session['user']['acctid']." ORDER BY level,login";
		$result = db_query($sql);
		if (db_num_rows($result)!=0) {
			output("`@The potion will disappear when you spy..");
			output("`@These users were found `^(click on a name to spy`@):`n");
			rawoutput("<table cellpadding='3' cellspacing='0' border='0'>");
			rawoutput("<tr class='trhead'><td>Name</td></tr>");
			for ($i=0;$i<db_num_rows($result);$i++){
			$row = db_fetch_assoc($result);
			rawoutput("<tr class='".($i%2?"trlight":"trdark")."'><td><a href='runmodule.php?module=healpotions&op=use&stage=2&ac=".$row['acctid']."'>");
			output_notl($row['name']);
			rawoutput("</td></tr>");
			addnav("","runmodule.php?module=healpotions&op=use&stage=2&ac=".$row['acctid']);
			}
			rawoutput("</table>");
		} else {
			output("`c`@`bA user was not found with that name.`b`c");
		}
		output_notl("`n");
	}
	output("`^`b`cNotion Potions..`c`b");
	output("`nWho do you want to spy upon? (Don't worry about funny names.. you'll be asked to confirm it)");
	output("Name of user: ");
	rawoutput("<input name='n' id='n' maxlength='50' value=\"".htmlentities(stripslashes(httppost('n')))."\">");
	$apply = translate_inline("Visualize");
	rawoutput("<input type='submit' class='button' value='$apply'></form>");
	rawoutput("<script language='JavaScript'>document.getElementById('n').focus();</script>");
}
?>