<?php
/*
Details:
 * This allows users to buy potions that plonk them in their house
History Log:
 * Version 1.0
  o Seems Stable
 * Version 1.1
  o Erm.. it wasn't actually removing potions..
*/
require_once("lib/villagenav.php");

function homepotions_getmoduleinfo(){
	$info = array(
		"name"=>"Home Potions",
		"version"=>"1.1",
		"author"=>"`@CortalUX",
		"category"=>"Potions",
		"vertxtloc"=>"http://dragonprime.net/users/CortalUX/",
		"download"=>"http://dragonprime.net/users/CortalUX/homepotions.zip",
		"settings"=>array(
			"Home Potions - Settings,title",
			"hombuy"=>"Allow users to buy home potions?,bool|1",
			"pCost"=>"Cost of home potions?,int|1500",
			"adminPotion"=>"Admin have unlimited access to home potions?,bool|1",
			"(admin are those that can edit users),note",
		),
		"prefs"=>array(
			"Potions - Preferences,title",
			"homPot"=>"Home potions?,int|0",
			"potHome"=>"Potion home?,int|0",
			"subs"=>"Subscribed?,bool|0",
		),
		"requires"=>array(
			"potionshop"=>"1.0|`@CortalUX, http://dragonprime.net/users/CortalUX/potionshop.zip",
			"house"=>"1.75|by Chris Vorndran and Kujaku, http://dragonprime.net/users/Sichae/house.zip",
		),
	);
	return $info;
}

function homepotions_install(){
	if (!is_module_active('homepotions')) {
		output("`n`Q`b`cInstalling Home Potions Module.`c`b`n");
	}else{
		output("`n`Q`b`cUpdating Home Potions Module.`c`b`n");
	}
	module_addhook("backpack");
	module_addhook("housenavs");
	module_addhook("charstats");
	module_addhook("potionshop-list");
	module_addhook("footer-runmodule");
	module_addhook("newday");
	return true;
}

function homepotions_uninstall(){
	output("`n`Q`b`cUninstalling Home Potions Module.`c`b`n");
	return true;
}

function homepotions_dohook($hookname,$args){
	global $session,$SCRIPT_NAME;
	switch($hookname){
		case "backpack":
			if (get_module_pref('check_show','potionshop')) {
				if (get_module_pref('homPot')>0) {
					output("`n`^You have `@%s`^ Home Potions...`n",get_module_pref('homPot'));
				}
			}
		break;
		case "housenavs":
			$subject = translate_inline("`\$Uh oh!");
			$message = translate_inline("`@It looks like you aren't allowed in that house any more, so your potion home has been reset.");
			if (get_module_pref('potHome')!=0) {
				$check = homepotions_check(get_module_pref('potHome'));
				if ($check===false) {
					require_once("lib/systemmail.php");
					systemmail($session['user']['acctid'],$subject,$message);
					set_module_pref('potHome',0);
				}
			}
		break;
		case "charstats":
			$potion="";
			if (get_module_setting('adminPotion')==1&&$session['user']['superuser']&SU_EDIT_USERS) {
				set_module_pref('homPot',1);
			}
			if (get_module_pref('homPot')>0) {
				$c = translate_inline("Home Potions cannot be used here");
				if (!strstr($SCRIPT_NAME, "village")&&!strstr($SCRIPT_NAME, "forest")&&!strstr($SCRIPT_NAME, "superuser")||$session['user']['specialinc']!=""&&$session['user']['specialmisc']!="") {
					$potion .="<div style='cursor: help;display:compact;' onMouseover=\"ddrivetip('$c', 'ffdf7b')\"; onMouseout=\"hideddrivetip()\">";
					$potion .="<img src=\"./images/homepotions/potionclear.gif\" title=\"$c\" alt=\"$c\">";
					$potion .="</div>";
				} else {
					$x = get_module_pref('homPot');
					$y = 0;
					$c = translate_inline("Drink the Home Potion...");
					while ($x>0) {
						$y++;
						$x--;
						$potion.="<a style='border:0;' border='0' onMouseover=\"ddrivetip('$c', '94f394')\"; onMouseout=\"hideddrivetip()\" style='border:0;' href=\"runmodule.php?module=homepotions&op=use\"><img src=\"./images/homepotions/potion.gif\" style='border:0;' title=\"$c\" alt=\"$c\"></a>";
						addnav("","runmodule.php?module=homepotions&op=use");
						if ($y>=3) {
							$y=0;
							$potion.="\n<br/>";
						}
					}
				}
			}
			addcharstat("Click and use Items");
			if ($potion!="") addcharstat("Home Potions", $potion);
		break;
		case "potionshop-list":
			if (get_module_setting('hombuyloc')==0&&get_module_setting('hook','potionshop')==1) set_module_setting('hombuyloc',0);
			if (get_module_setting('hombuy')==1) {
				$price = get_module_setting('pCost');
				if ($price<=0) $price = 1;
				$hom=array();
				$hom['gold']=$price;
				$hom['name']=translate_inline("Home Potions");
				$hom['link']="runmodule.php?module=homepotions&op=shop";
				$hom['avail']=translate_inline("In Stock");
				$hom['nav']=translate_inline("Buy a `3Home`0 Potion");
				$hom['effects']=translate_inline("Returns you to your Vizualized home...");
				$args[]=$hom;
			}
		break;
		case "footer-runmodule":
			if (httpget('module')=='house') {
				if (httpget('lo')=='house') {
    				$id = httpget("id");
    				addnav("Potions");
    				if (get_module_pref('potHome')==0) {
    					addnav("`^`bSet your Potion Home`b","runmodule.php?module=homepotions&op=set&house=".$id);
					} elseif (get_module_pref('potHome')!=$id) {
						addnav("`^`bChange your Potion Home`b","runmodule.php?module=homepotions&op=set&house=".$id);
					}
				}
			}
		break;
		case "newday":
			$subject = translate_inline("`\$Uh oh!");
			$message = translate_inline("`@Your subscription for home potions, has been cancelled... you didn't have enough gold.");
			if (get_module_pref('subs')==1) {
				$price = get_module_setting('pCost');
				if ($price<=0) $price = 1;
				$b=true;
				output_notl('`n`b`c`^');
				$all=$session['user']['gold']+$session['user']['goldinbank'];
				if ($session['user']['gold']>=$price) {
					$session['user']['gold']-=$price;
					output("You have another home potion.. paid for out of your hand.");
				} elseif ($session['user']['goldinbank']>=$price) {
					$session['user']['goldinbank']-=$price;
					output("You have another home potion.. paid for out of the bank.");
				} elseif ($all>=$price) {
					$session['user']['goldinbank']=0;
					$all-=$price;
					$session['user']['gold']=$all;
					output("You have another home potion.. the rest of your gold is in your hand.");
				} else {
					$b=false;
					set_module_pref('subs',0);
					require_once("lib/systemmail.php");
					systemmail($session['user']['acctid'],$subject,$message);
					output("`%Your subscription for home potions has been CANCELLED.");
				}
				if ($b) {
					set_module_pref('homPot',get_module_pref('homPot')+1);
				}
				output_notl('`0`c`b');
			}
		break;
	}
	return $args;
}

function homepotions_run(){
	global $session;
	$op = httpget('op');
	switch ($op) {
		case "use":
			page_header("You gulp a potion..");
			output("`@You drink a lukewarm, silver potion that feels as silky as the flow of moonlight over a cold sea, and as comforting as a breeze on a warm summers night... you have thoughts of home, and your roaming mind moves to take you home..");
			$sql = "SELECT name FROM `".db_prefix('accounts')."` WHERE locked=0 AND acctid=".get_module_pref('potHome');
			$res = db_query($sql);
			if (db_num_rows($res)>0&&get_module_pref('potHome')!=0) {
				$row=db_fetch_assoc($res);
				$size=get_module_pref('housesize','house',get_module_pref('potHome'));
				if ($size>0) {
					$loc=get_module_pref('village','house',get_module_pref('potHome'));
					$session['user']['location']=$loc;
					output("`n`^And your mind lets you MindMove to your Vizualized potion home..");
					addnav("MindMove","runmodule.php?module=house&lo=house&id=".get_module_pref('potHome'));
					set_module_pref('homPot',get_module_pref('homPot')-1);
				} else {
					output("`n`%But your roaming mind cannot find the house..");
					villagenav();
				}
			} else {
				output("`n`%But your roaming mind cannot find the house..");
				villagenav();
			}
			page_footer();
		break;
		case "shop":
			page_header("Magical Potion Shoppe");
			$ty = httpget('ty');
			$price = get_module_setting('pCost');
			if ($price<=0) $price = 1;
			modulehook("potionshop-navs");
			switch ($ty) {
				case "subs":
					if (get_module_pref('subs')==0) {
						if (httpget('i')=='yes') {
							set_module_pref('subs',1);
							output("%s nods, `3\"`&Ye will have to pay %s gold at each new day, and ye will get a home potion.`3\"","`#CortalUX`@",$price);
						} else {
							output("%s explains, `3\"`&If ye subscribe, ye will get a potion to return to yer home at each new day.`3\"","`#CortalUX`@");
						}
					} else {
						if (httpget('i')=='no') {
							set_module_pref('subs',0);
							output("%s nods, `3\"`&Ye have been unsubscribed.`3\"","`#CortalUX`@",$price);
						} else {
							output("%s asks, `3\"`&Unsubscribe?`3\"","`#CortalUX`@");
						}
					}
					addnav("Subscription Options");
					if (get_module_pref('subs')==0) {
						addnav("Subscribe","runmodule.php?module=homepotions&op=shop&ty=subs&i=yes");
					} else {
						addnav("Unsubscribe","runmodule.php?module=homepotions&op=shop&ty=subs&i=no");
					}
				break;
				case "buy":
					if ($session['user']['gold']>=$price) {
						set_module_pref('homPot',get_module_pref('homPot')+1);
						$session['user']['gold']-=$price;
						output("`@Handing %s gold to %s, he hands you a home potion, \"`&This is a home potion.. I explained it te yeh already..`3\"",$price,"`#CortalUX`@");
					} else {
						output("%s stares at you.`n`3\"`&Ye do not have enough gold! They cost %s gold!`3\"","`#CortalUX`@",$price);
					}
				break;
				default:
					output("`@%s says, \"`&Will ye subscribe to gain home potions, and have em' delivered lek milk?`3\"","`#CortalUX`@");
				break;
			}
			addnav("Actions");
			addnav("Subscription Options","runmodule.php?module=homepotions&op=shop&ty=subs");
			addnav("Buy a Potion","runmodule.php?module=homepotions&op=shop&ty=buy");
			page_footer();
		break;
		case "set":
			page_header("Potion.. Visualization");
			if (get_module_pref('potHome')==0) {
				output("`@You leave your Vizualization... your home is memorized... your potions safe..");
			} else {
				output("`@You change your Vizualization... your home is memorized... your potions safe..");
			}
			output("`nYou now know where your home potions will take you.");
			set_module_pref('potHome',httpget('house'));
			addnav("Leave your Trance","runmodule.php?module=house&lo=house&id=".httpget('house'));
			page_footer();
		break;
	}
}

function homepotions_check($id) {
	global $session;
	$b=false;
	$sql = "SELECT ownerid FROM ".db_prefix("housekeys")." WHERE houseid=$id";
	$result = db_query($sql);
	for ($i=0;$i<db_num_rows($result);$i++){
		$x = db_fetch_assoc($result);
		if ($x['ownerid']==$session['user']['acctid']) $b=true;
	}
	return $b;
}
?>