<?

function popcities_getmoduleinfo(){
    $info = array(
        "name"=>"Most Populated Cities",
        "author"=>"<a href='http://www.sixf00t4.com' target=_new>Sixf00t4</a>",
        "version"=>"20050909",
        "category"=>"General",
        "download"=>"http://dragonprime.net/users/sixf00t4/popcities.zip",
		"description"=>"Shows the most populated villages in the HoF.",
        "vertxtloc"=>"http://dragonprime.net/users/sixf00t4/",
		"requires"=>array(
			"cities"=>"1.0|Eric Stevens,core_download",
		),
	);
    return $info;
}

function popcities_install(){
    module_addhook("footer-hof"); 
    return true;
}

function popcities_uninstall(){
    return true;
}

function popcities_dohook($hookname, $args){
    
    switch($hookname) {
        case "footer-hof":
            addnav("Cities");
            addnav("Most Populated","runmodule.php?module=popcities");
        break;
    }
    return $args;
}

function popcities_run() {
page_header("Most Populated Cities");
    $sql="select p.value as city, count(*) as count from ".db_prefix("module_userprefs")." p where p.modulename = 'cities' and p.setting = 'homecity' group by p.value order by count desc"; 
    $result = db_query($sql) or die(db_error(LINK)); 
    $rank=translate_inline("Rank");
    $city=translate_inline("City");
    $pop=translate_inline("Population");
    rawoutput("<center><table cellspacing='0' cellpadding='2' align='center'><tr class='trhead'><td>$rank</td><td>$city</td><td>$pop</td></tr>");
    for ($i=0;$i<db_num_rows($result)-1;$i++){    
        $row = db_fetch_assoc($result);
		$y=$i+1;
	rawoutput("<tr class='".($i%2?"trlight":"trdark")."'>");
        rawoutput("<td>$y</td><td>".$row['city']."</td><td align='right'>".$row['count']."</td></tr>");
    }
        rawoutput("</center></table>");
    addnav("Return To HoF","hof.php");
page_footer();
}
?>