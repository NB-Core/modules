<?php
// translator ready
// addnews ready
// mail ready

function raceklingon_getmoduleinfo(){
	$info = array(
		"name"=>"Race - klingon",
		"version"=>"1.0",
		"author"=>"Daniel Cannon",
		"category"=>"Races",
		"settings"=>array(
			"Klingon Race Settings,title",
			"villagename"=>"Name for the Klingon village|Quo'nos",
			"minedeathchance"=>"Chance for Klingons to die in the mine,range,0,100,1|90",
		),
	);
	return $info;
}

function raceklingon_install(){
	module_addhook("chooserace");
	module_addhook("setrace");
	module_addhook("newday");
	module_addhook("villagetext");
	module_addhook("stabletext");
	module_addhook("travel");
	module_addhook("charstats");
	module_addhook("validlocation");
	module_addhook("moderate");
	module_addhook("changesetting");
	module_addhook("raceminedeath");
	module_addhook("stablelocs");
	return true;
}

function raceklingon_uninstall(){
	global $session;
	$vname = getsetting("villagename", LOCATION_FIELDS);
	$gname = get_module_setting("villagename");
	$sql = "UPDATE " . db_prefix("accounts") . " SET location='$vname' WHERE location = '$gname'";
	db_query($sql);
	if ($session['user']['location'] == $gname)
		$session['user']['location'] = $vname;
	// Force anyone who was a klingon to rechoose race
	$sql = "UPDATE  " . db_prefix("accounts") . " SET race='" . RACE_UNKNOWN . "' WHERE race='Klingon'";
	db_query($sql);
	if ($session['user']['race'] == 'Klingon')
		$session['user']['race'] = RACE_UNKNOWN;
	return true;
}

function raceklingon_dohook($hookname,$args){
	//yeah, the $resline thing is a hack.  Sorry, not sure of a better way
	// to handle this.
	// Pass it as an arg?
	global $session,$resline;
	$city = get_module_setting("villagename");
	$race = "Klingon";
	switch($hookname){
	case "raceminedeath":
		if ($session['user']['race'] == $race) {
			$args['chance'] = get_module_setting("minedeathchance");
		}
		break;
	case "changesetting":
		// Ignore anything other than villagename setting changes
		if ($args['setting'] == "villagename" && $args['module']=="raceklingon") {
			if ($session['user']['location'] == $args['old'])
				$session['user']['location'] = $args['new'];
			$sql = "UPDATE " . db_prefix("accounts") .
				" SET location='" . $args['new'] .
				"' WHERE location='" . $args['old'] . "'";
			db_query($sql);
			if (is_module_active("cities")) {
				$sql = "UPDATE " . db_prefix("module_userprefs") .
					" SET value='" . $args['new'] .
					"' WHERE modulename='cities' AND setting='homecity'" .
					"AND value='" . $args['old'] . "'";
				db_query($sql);
			}
		}
		break;
	case "charstats":
		if ($session['user']['race']==$race){
			addcharstat("Vital Info");
			addcharstat("Race", translate_inline($race));
		}
		break;
	case "chooserace":
		output("`0<a href='newday.php?setrace=$race$resline'>On the plains in the city of %s</a>, the city of `&men`0; always following your father and looking up to his every move, until he sought out the `@Green Dragon`0, never to be seen again.`n`n", $city, true);
		addnav("`&Klingon`0","newday.php?setrace=$race$resline");
		addnav("","newday.php?setrace=$race$resline");
		break;
	case "setrace":
		if ($session['user']['race']==$race){
			output("`&As a Klingon, your size and strength permit you the ability to effortlessly wield weapons, tiring much less quickly than other races.`n`^You gain an extra forest fight each day!");
			if (is_module_active("cities")) {
				if ($session['user']['dragonkills']==0 &&
						$session['user']['age']==0){
					//new farmthing, set them to wandering around this city.
					set_module_setting("newest-$city",
							$session['user']['acctid'],"cities");
				}
				set_module_pref("homecity",$city,"cities");
				if ($session['user']['age'] == 0)
					$session['user']['location']=$city;
			}
		}
		break;
	case "newday":
		if ($session['user']['race']==$race){
			raceklingon_checkcity();
			$args['turnstoday'] .= ", Race (klingon): 1";
			$session['user']['turns']++;
			output("`n`&Because you are Klingon, you gain `^an extra`& forest fight for today!`n`0");
		}
		break;
	case "validlocation":
		if (is_module_active("cities"))
			$args[$city]="village-$race";
		break;
	case "moderate":
		if (is_module_active("cities")) {
			tlschema("commentary");
			$args["village-$race"]=sprintf_translate("City of %s", $city);
			tlschema();
		}
		break;
	case "travel":
		$capital = getsetting("villagename", LOCATION_FIELDS);
		$hotkey = substr($city, 0, 1);
		tlschema("module-cities");
		if ($session['user']['location']==$capital){
			addnav("Safer Travel");
			addnav(array("%s?Go to %s", $hotkey, $city),"runmodule.php?module=cities&op=travel&city=$city");
		}elseif ($session['user']['location']!=$city){
			addnav("More Dangerous Travel");
			addnav(array("%s?Go to %s", $hotkey, $city),"runmodule.php?module=cities&op=travel&city=$city&d=1");
		}
		if ($session['user']['superuser'] & SU_EDIT_USERS){
			addnav("Superuser");
			addnav(array("%s?Go to %s", $hotkey, $city),"runmodule.php?module=cities&op=travel&city=$city&su=1");
		}
		tlschema();
		break;	
	case "villagetext":
		raceklingon_checkcity();
		if ($session['user']['location'] == $city){
			$args['text']=array("`&`c`b%s, City of Klingons`b`c`n`7You are standing in the heart of %s.  This colony of Klingons is located in a giant space city high above LotGD.  The city's advanced anti-dragon defensive forcefields are surrounded by space, and lots of it.  Some residents are engaged in conversation around the replicator in the city square.`n", $city, $city);
			$args['schemas']['text'] = "module-raceklingon";
			$args['clock']="`n`7The great sundial at the heart of the city reads `&%s`7.`n";
			$args['schemas']['clock'] = "module-raceklingon";
			if (is_module_active("calendar")) {
				$args['calendar'] = "`n`7A smaller contraption next to it reads `&%s`7, `&%s %s %s`7.`n";
				$args['schemas']['calendar'] = "module-raceklingon";
			}
			$args['title']=array("%s, City of klingons", $city);
			$args['schemas']['title'] = "module-raceklingon";
			$args['sayline']="says";
			$args['schemas']['sayline'] = "module-raceklingon";
			$args['talk']="`n`&Nearby some villagers talk:`n";
			$args['schemas']['talk'] = "module-raceklingon";
			$new = get_module_setting("newest-$city", "cities");
			if ($new != 0) {
				$sql =  "SELECT name FROM " . db_prefix("accounts") .
					" WHERE acctid='$new'";
				$result = db_query_cached($sql, "newest-$city");
				$row = db_fetch_assoc($result);
				$args['newestplayer'] = $row['name'];
				$args['newestid']=$new;
			} else {
				$args['newestplayer'] = $new;
				$args['newestid']="";
			}
			if ($new == $session['user']['acctid']) {
				$args['newest']="`n`7As you wander your new home, you feel your jaw dropping at the wonders around you.";
			} else {
				$args['newest']="`n`7Wandering the village, jaw agape, is `&%s`7.";
			}
			$args['schemas']['newest'] = "module-raceklingon";
			$args['section']="village-$race";
			$args['stablename']="Bertold's Bestiary";
			$args['schemas']['stablename'] = "module-raceklingon";
			$args['gatenav']="Village Gates";
			$args['schemas']['gatenav'] = "module-raceklingon";
			unblocknav("stables.php");
		}
		break;
	case "stabletext":
		if ($session['user']['location'] != $city) break;
		$args['title'] = "Bertold's Bestiary";
		$args['schemas']['title'] = "module-raceklingon";
		$args['desc'] = "`6Just outside the outskirts of the village, a training area and riding range has been set up.  Many people from all across the land mingle as Bertold, a strapping man with a wind-weathered face, extols the virtues of each of the creatures in his care.  As you approach, Bertold smiles broadly, \"`^Ahh!, how can I help you today, my %s?`6\", he asks in a booming voice.";
		$args['schemas']['desc'] = "module-raceklingon";
		$args['lad']="friend";
		$args['schemas']['lad'] = "module-raceklingon";
		$args['lass']="friend";
		$args['schemas']['lass'] = "module-raceklingon";
		$args['nosuchbeast']="`6\"`^I'm sorry, I don't stock any such animal.`6\", Bertold say apologetically.";
		$args['schemas']['nosuchbeast'] = "module-raceklingon";
		$args['finebeast']=array(
			"`6\"`^Yes, yes, that's one of my finest beasts!`6\", says Bertold.`n`n",
			"`6\"`^Not even Merick has a finer speciman than this!`6\", Bertold boasts.`n`n",
			"`6\"`^Doesn't this one have fine musculature?`6\". he asks.`n`n",
			"`6\"`^You'll not find a better trained creature in all the land!`6\". exclaims Bertold.`n`n",
			"`6\"`^And a bargain this one'd be at twice the price!`6\", booms Bertold.`n`n",
			);
		$args['schemas']['finebeast'] = "module-raceklingon";
		$args['toolittle']="`6Bertold looks over the gold and gems you offer and turns up his nose, \"`^Obviously you misheard my price.  This %s will cost you `&%s `^gold  and `%%s`^ gems and not a penny less.`6\"";
		$args['schemas']['toolittle'] = "module-raceklingon";
		$args['replacemount']="`6Patting %s`6 on the rump, you hand the reins as well as the money for your new creature, and Bertold hands you the reins of a `&%s`6.";
		$args['schemas']['replacemount'] = "module-raceklingon";
		$args['newmount']="`6You hand over the money for your new creature, and Bertold hands you the reins of a new `&%s`6.";
		$args['schemas']['newmount'] = "module-raceklingon";
		$args['nofeed']="`6\"`^I'm terribly sorry %s, but I don't stock feed here.  I'm not a common stable after all!  Perhaps you should look elsewhere to feed your creature.`6\"";
		$args['schemas']['nofeed'] = "module-raceklingon";
		$args['nothungry']="`&%s`6 picks briefly at the food and then ignores it.  Bertold, being honest, shakes his head and hands you back your gold.";
		$args['schemas']['nothungry'] = "module-raceklingon";
		$args['halfhungry']="`&%s`6dives into the provided food and gets through about half of it before stopping.  \"`^Well, it wasn't as hungry as you thought.`6\" says Bertold as he hands you back all but %s gold.";
		$args['schemas']['halfhungry'] = "module-raceklingon";
		$args['hungry']="`6%s`6 seems to inhale the food provided.  %s`6, the greedy creature that it is, then goes snuffling at Bertold's pockets for more food.`nBertold shakes his head in amusement and collects `&%s`6 gold from you.";
		$args['schemas']['hungry'] = "module-raceklingon";
		$args['mountfull']="`n`6\"`^Well, %s, your %s`^ was truly hungry today, but we've got it full up now.  Come back tomorrow if it hungers again, and I'll be happy to sell you more.`6\", says Bertold with a genial smile.";
		$args['schemas']['mountfull'] = "module-raceklingon";
		$args['nofeedgold']="`6\"`^I'm sorry, but that is just not enough money to pay for food here.`6\"  Bertold turns his back on you, and you lead %s away to find other places for feeding.";
		$args['schemas']['nofeedgold'] = "module-raceklingon";
		$args['confirmsale']="`n`n`6Bertold eyes your mount up and down, checking it over carefully.  \"`^Are you quite sure you wish to part with this creature?`6\"";
		$args['schemas']['confirmsale'] = "module-raceklingon";
		$args['mountsold']="`6With but a single tear, you hand over the reins to your %s`6 to Bertold's stableboy.  The tear dries quickly, and the %s in hand helps you quickly overcome your sorrow.";
		$args['schemas']['mountsold'] = "module-raceklingon";
		$args['offer']="`n`n`6Bertold strokes your creature's flank and offers you `&%s`6 gold and `%%s`6 gems for %s`6.";
		$args['schemas']['offer'] = "module-raceklingon";
		break;
	case "stablelocs":
		tlschema("mounts");
		$args[$city]=sprintf_translate("The Village of %s", $city);
		tlschema();
		break;
	}
	return $args;
}

function raceklingon_checkcity(){
	global $session;
	$race="klingon";
	$city=get_module_setting("villagename");
	
	if ($session['user']['race']==$race && is_module_active("cities")){
		//if they're this race and their home city isn't right, set it up.
		if (get_module_pref("homecity","cities")!=$city){ //home city is wrong
			set_module_pref("homecity",$city,"cities");
		}
	}	
	return true;
}

function raceklingon_run(){

}
?>