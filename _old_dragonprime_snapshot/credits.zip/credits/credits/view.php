<?php
if (httpget("author")) {
	$author = httpget("author");
	popup_header("Author, $author");
	rawoutput("<table width='600' border='0' align='center' cellpadding='0' cellspacing='0'>");
		rawoutput("<tr><td>");
			rawoutput("<table width='100%' border='0' cellpadding='4' cellspacing='2'>");
				rawoutput("<tr class='trhead'>");
					rawoutput("<td><b>Author, $author</b></td>");
				rawoutput("</tr>");
				$result = db_query("SELECT * FROM " .
					db_prefix("modules"). " " .
						"WHERE moduleauthor='$author'");
				for ($i = 0; $i < db_num_rows($result); $i ++)
				{	
					$row = db_fetch_assoc($result);
					rawoutput("<tr class='trhead'>");
						rawoutput("<td>");
						if (isset($row['formalname'])) {
							output('%s',$row['formalname']);
						} else {
							output('None.');
						}
						rawoutput("</td>");
					rawoutput("</tr>");
					$class = $i%2?'trdark':'trlight';
					rawoutput("<tr class='$class'>");
						rawoutput("<td>");
							rawoutput("<table width='100%' border='0' cellpadding='2' cellspacing='2'>");
							if (isset($row['modulename'])) {
								$modulename = $row['modulename'];
								if (@include_once("modules/$modulename.php")) {
									include_once("modules/$modulename.php");
									$func = $modulename."_getmoduleinfo";
									$info = $func();
									
									if (is_array($info['credits'])) {
										$credits = $info['credits'];
										rawoutput("<tr><td>Description: ");
												output("%s",$credits['description']);
											rawoutput("</td></tr>");
										rawoutput("<tr><td>Initial Release: ");
												output("%s",$credits['release']);
											rawoutput("</td></tr>");
										rawoutput("<tr><td>Contributors: ");
												output("%s",$credits['contributors']);
											rawoutput("</td></tr>");
									}
								}
							}
							rawoutput("</table>");
						rawoutput("</td>");
					rawoutput("</tr>");
				}
			rawoutput("</table>");
		rawoutput("</td></tr>");
	rawoutput("</table>");
	popup_footer();
}
?>