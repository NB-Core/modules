<?php
popup_header("Credits");
	rawoutput("<table width=\"600\" border=\"0\" align=\"center\" cellpadding=\"0\" cellspacing=\"0\">");
		rawoutput("<tr><td>");
			rawoutput("<table width=\"100%\" border=\"0\" cellpadding=\"4\" cellspacing=\"2\">");
				rawoutput("<tr class=\"trhead\">");
					rawoutput("<td width=\"20%\"><b>" .translate_inline("?Information"). "</b></td>");
					rawoutput("<td width=\"20%\"><b>" .translate_inline("#Installed"). "</b></td>");
					rawoutput("<td width=\"60%\"><b>" .translate_inline("&copy; Author"). "</b></td>");
				rawoutput("</tr>");
			rawoutput("</table>");
		rawoutput("</td></tr>");						
		rawoutput("<tr><td>");
			rawoutput("<table width=\"100%\" border=\"0\" cellpadding=\"4\" cellspacing=\"2\">");
				$result = db_query("SELECT moduleauthor FROM " .
					db_prefix("modules"). " " .
						"WHERE active='1' ORDER BY moduleauthor");
				$authors = array();
				for ($i=0; $i<db_num_rows($result); $i++)
				{
					$row = db_fetch_assoc($result);
					foreach ($row as $value)
					{
						$authors[$i]=strip_tags($value); 
					}
				}
				$authors = array_unique($authors);
				require_once("notallowed.php");
				$authors = notallowed_docredits($authors);
				$authors = array_values($authors);
				$i=0;
				foreach ($authors as $author)
				{
					$class = $i%2?"trlight":"trdark";
					$result = db_query("SELECT * FROM " .
						db_prefix("modules"). " " .
							"WHERE moduleauthor='" .
								mysql_real_escape_string($author). "'");
					$row = db_fetch_assoc($result);
					$num = db_num_rows($result);
					$view = "<a href=\"runmodule.php?module=credits&op=view&author=$author\">View</a>";
					rawoutput("<tr class=\"$class\">");
						rawoutput("<td width=\"20%\">$view</td>");
						rawoutput("<td width=\"20%\">");
							output("%s",$num);
						rawoutput("</td>");
						rawoutput("<td width=\"60%\">");
							output("%s",$author);
						rawoutput("</td>");
					rawoutput("</tr>");
					$i++;
				}
			rawoutput("</table>");
		rawoutput("</td></tr>");
	rawoutput("</table>");
popup_footer();
?>