<?php
function notallowed_docredits(
	)
{
	if (@func_get_arg(0)) {
		$arg = func_get_arg(0);
		if (is_array($arg)) {
			$replace = array(
				"/`1/i",
				"/`!/i",
				"/`2/i",
				"/`@/i",
				"/`3/i",
				"/`#/i",
				"/`4/i",
				"/`$/i",
				"/`5/i",
				"/`%/i",
				"/`6/i",
				"/`^/i",
				"/`7/i",
				"/`&/i",
				"/`q/i",
				"/`Q/i",
				"/`b/i",
				"/`i/i"
			);
			$arg = preg_replace(
				$replace,"",$arg);
			return $arg;
		} else {
			return $arg;
		}
	}
}
?>