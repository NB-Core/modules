<?php
function credits_getmoduleinfo(
	)
{
	$info = array(
		"name"=>"Credits",
		"author"=>"Twisted.",
		"version"=>"2005.10.25",
		"category"=>"General",
		"allowanonymous"=>true,
		"allowforcednav"=>true,
		"settings"=>array(
		
		),
		"credits"=>array(
			"description"=>"Provides viewers with a list of authors and the number of modules each has installed and active. Including optional statistic�s on installed modules. Allows viewer the ability to select author and list each authors installed and active modules. Providing descriptions, initial release, and contributors.",
			"release"=>"October 25th 2005.",
			"contributors"=>"None."
		)
	);
	return $info;
}
function credits_install(
	)
{
	module_addhook(
		"everyfooter");
	return true;
}
function credits_uninstall(
	)
{
	return true;
}
function credits_dohook(
	$hookname,
	$args
	)
{
	global $session;
	switch($hookname)
	{
		case "everyfooter":
			if (!isset($args['paypal'])) {
				$args['paypal'] = array();
			} elseif (!is_array($args['paypal'])) {
				$args['paypal'] = array($args['paypal']);
			}
			array_push($args['paypal'],
				"<a href=\"runmodule.php?module=credits&op=list\" target=\"_blank\"><center>Credits</center></a>");
			addnav("","runmodule.php?module=credits&op=list");
			break;
		default:
	}
	return $args;
}
function credits_run(
	)
{
	if (httpget("op") == "list") {
		require_once("credits/list.php");
	}
	if (httpget("op") == "view") {
		require_once("credits/view.php");
	}
}
?>