This is a little mod I made so Admins can see users stuff without having to go to the user editor

--open: bio.php--

find: output("`^Specialty: `@".$specialty[$row[specialty]]."`n");

after add:
if ($session['user']['superuser']>1){
	$result2 = db_query("SELECT gold,goldinbank,gems,deathpower,experience,drunkenness,charm,attack,defence,weapon,armor,hitpoints,maxhitpoints,soulpoints,turns,gravefights,playerfights,laston FROM accounts WHERE login='$_GET[char]'");
	$row2 = db_fetch_assoc($result2);
	$row2[login] = rawurlencode($row2[login]);
	
	output("`^Gold: `@$row2[gold]`n");
	output("`^Gold in Bank: `@$row2[goldinbank]`n");
	output("`^Gems: `@$row2[gems]`n");
	output("`^Favor: `@$row2[deathpower]`n");
	output("`^Experience: `@$row2[experience]`n");
	output("`^Charm: `@$row2[charm]`n");
	output("`^Drunkenness: `@$row2[drunkenness]`n");
	output("`^Weapon: `@$row2[weapon]`n");
	output("`^Attack: `@$row2[attack]`n");
	output("`^Armor: `@$row2[armor]`n");
	output("`^Defence: `@$row2[defence]`n");
	output("`^Hitpoints: `@$row2[hitpoints]`n");
	output("`^Maxhitpoints: `@$row2[maxhitpoints]`n");
	output("`^Soulpoints: `@$row2[soulpoints]`n");
	output("`^Turns: `@$row2[turns]`n");
	output("`^Grave Fights: `@$row2[turns]`n");
	output("`^Player Fights: `@$row2[playerfights]`n");
	output("`^Last On: `@$row2[laston]`n");
}

--Save bio.php 