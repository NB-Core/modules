<?php

require_once("lib/datetime.php");

function movietheater_getmoduleinfo(){
	$info = array(
		"name"=>"Movie Theater",
		"version"=>"0.2",
		"author"=>"Lee Thomas<br>based on Movies (v 1.0) by Zachary Bridges ",
		"category"=>"Village",
		"download"=>"http://lotgd.escutcheonsoft.com/download/movietheater.zip",
		"settings"=>array(
			"Movie Theater - Settings,title",
			"movietheaterall"=>"Is there a movie theater in every village?,bool|1",
			"movietheaterloc"=>"If not&#44; where does the theater appear?,location|".getsetting("villagename", LOCATION_FIELDS),
			"movietheateropen"=>"What time does the theater open?`n0 = midnight`n1-11 = am`n12 = noon`n13-23 = pm,range,0,23,1|11",
			"movietheaterclose"=>"What time does the theater close?`n1-11 = am`n12 = noon`n13-23 = pm`n24 = midnight,range,1,24,1|23",
			"movietheatermatinee"=>"Is matinee pricing available until 4pm?,bool|1",
			"Concession Stand - Settings,title",
			"concessionitem1"=>"Menu Item #1,string|Buttered Popcorn",
			"concessionprice1"=>"Price (in gold),range,10,100,5|15",
			"concessionitem2"=>"Menu Item #2,string|Caramel Corn",
			"concessionprice2"=>"Price (in gold),range,10,100,5|20",
			"concessionitem3"=>"Menu Item #3,string|Candy",
			"concessionprice3"=>"Price (in gold),range,10,100,5|25",
			"concessionitem4"=>"Menu Item #4,string|Soda",
			"concessionprice4"=>"Price (in gold),range,10,100,5|10",
			"Action Movie - Settings,title",
			"actiontitle"=>"Action Movie Title,string|Troll with a Vengeance",
			"Horror Movie - Settings,title",
			"horrortitle"=>"Horror Movie Title,string|Bath-Time in Dwarf Village",
			"Comedy Movie - Settings,title",
			"comedytitle"=>"Comedy Movie Title,string|Paladin Academy VII"
		),
		"prefs"=>array(
			"Movie Theater User Preferences,title",
			"actionseen"=>"Has the Action Movie been seen today?,bool|0",
			"horrorseen"=>"Has the Horror Movie been seen today?,bool|0",
			"comedyseen"=>"Has the Comedy Movie been seen today?,bool|0",
			"matinee"=>"Is it currently matinee time,bool|0",
			"concessionbought"=>"Which Menu Item was last purchased today?,range,0,4,1|0",
		)
	);
	return $info;
}
function movietheater_install(){
	module_addhook("changesetting");
	module_addhook("newday");
	module_addhook("village");
	module_addhook("village-desc");
	return true;
}

function movietheater_uninstall(){
	return true;
}

function formatmovietime($timevalue){
	$timetemp = $timevalue;
	$returnstring = "";
	switch($timetemp){
		case 0:
		case 24:
			$timetemp = 12;
		case 1:
		case 2:
		case 3:
		case 4:
		case 5:
		case 6:
		case 7:
		case 8:
		case 9:
		case 10:
		case 11:
			$returnstring = $timetemp . " am";
			break;
		case 12:
			$timetemp = 24;
		case 13:
		case 14:
		case 15:
		case 16:
		case 17:
		case 18:
		case 19:
		case 20:
		case 21:
		case 22:
		case 23:
			$timetemp -= 12;
			$returnstring = $timetemp . " pm";
			break;
	}
	return $returnstring;
}

function movietheater_dohook($hookname,$args){
	global $session;
	$opentime = get_module_setting("movietheateropen");
	$opentimestring = formatmovietime($opentime);
	$closetime = get_module_setting("movietheaterclose");
	$gamehour = intval(gmdate("g",gametime()));
	$theateropen = 0;
	if ($gamehour == 12)
	{
		$gamehour = 0;
	}
	if (gmdate("a",gametime()) == "pm")
	{
		$gamehour += 12;
	}
	if ($closetime < $opentime)
	{
		if ($gamehour < $closetime || $gamehour >= $opentime)
		{
			$theateropen = 1;
		}
	} else {
		if ($gamehour >= $opentime && $gamehour < $closetime)
		{
			$theateropen = 1;
		}
	}
	$horrortitle = get_module_setting("horrortitle");
	if (!$horrortitle)
	{
		$horrortitle = "Bath-Time in Dwarf Village";
		set_module_setting("horrortitle", "Bath-Time in Dwarf Village");
	}
	$actiontitle = get_module_setting("actiontitle");
	if (!$actiontitle)
	{
		$actiontitle = "Troll with a Vengeance";
		set_module_setting("actiontitle", "Troll with a Vengeance");
	}
	$comedytitle = get_module_setting("comedytitle");
	if (!$comedytitle)
	{
		$comedytitle = "Paladin Academy VII";
		set_module_setting("comedytitle", "Paladin Academy VII");
	}
	$menuitem1 = get_module_setting("concessionitem1");
	if (!$menuitem1)
	{
		$menuitem1 = "Buttered Popcorn";
		set_module_setting("concessionitem1", "Buttered Popcorn");
	}
	$menuitem2 = get_module_setting("concessionitem2");
	if (!$menuitem2)
	{
		$menuitem2 = "Caramel Corn";
		set_module_setting("concessionitem2", "Caramel Corn");
	}
	$menuitem3 = get_module_setting("concessionitem3");
	if (!$menuitem3)
	{
		$menuitem3 = "Candy";
		set_module_setting("concessionitem3", "Candy");
	}
	$menuitem4 = get_module_setting("concessionitem4");
	if (!$menuitem4)
	{
		$menuitem4 = "Soda";
		set_module_setting("concessionitem4", "Soda");
	}
	switch($hookname){
		case "newday":
			set_module_pref("matinee", false);
			if (get_module_setting("movietheatermatinee") && $gamehour >= $opentime && $gamehour < 16)
			{
				set_module_pref("matinee", true);
			}
			set_module_pref("actionseen", false);
			set_module_pref("horrorseen", false);
			set_module_pref("comedyseen", false);
			set_module_pref("concessionbought", 0);
			break;
		case "changesetting":
			if ($args['setting'] == "villagename") {
				if ($args['old'] == get_module_setting("movietheaterloc")) {
					set_module_setting("movietheaterloc", $args['new']);
				}
			}
			break;
		case "village":
			if (($session['user']['location'] == get_module_setting("movietheaterloc") || get_module_setting("movietheaterall")) && $theateropen) {
				tlschema($args['schemas']['tavernnav']);
				addnav($args['tavernnav']);
				tlschema();
				set_module_pref("matinee", false);
				if (get_module_setting("movietheatermatinee") && $gamehour >= $opentime && $gamehour < 16)
				{
					set_module_pref("matinee", true);
				}
				addnav("v?" . $session['user']['location'] . " Movie Theater","runmodule.php?module=movietheater");
			}
			break;
		case "village-desc":
			if ($session['user']['location'] == get_module_setting("movietheaterloc") || get_module_setting("movietheaterall")){
				if ($theateropen)
				{
					output("`n`&Now Showing at the " . $session['user']['location'] . " `#Movie Theater`&`n`n");
					output("`c`\$%s`& (horror)`n`@%s`& (action)`n`!%s`& (comedy)`c`n", $horrortitle, $actiontitle, $comedytitle);
				} else {
					output("`n`c`&The `#Movie Theater`& is closed.`n");
					output("`&It will reopen at %s`c`n", $opentimestring);
				}
			}
			break;
	}
	return $args;
}

function movietheater_run() {
	global $session;
	$op = httpget('op');
	$concessionbought = httpget('cb');
	$moviegold = 25;
	if (get_module_pref("matinee"))
	{
		$moviegold = 15;
	}
	$horrortitle = get_module_setting("horrortitle");
	if (!$horrortitle)
	{
		$horrortitle = "Bath-Time in Dwarf Village";
		set_module_setting("horrortitle", "Bath-Time in Dwarf Village");
	}
	$actiontitle = get_module_setting("actiontitle");
	if (!$actiontitle)
	{
		$actiontitle = "Troll with a Vengeance";
		set_module_setting("actiontitle", "Troll with a Vengeance");
	}
	$comedytitle = get_module_setting("comedytitle");
	if (!$comedytitle)
	{
		$comedytitle = "Paladin Academy VII";
		set_module_setting("comedytitle", "Paladin Academy VII");
	}
	$menuitem1 = get_module_setting("concessionitem1");
	if (!$menuitem1)
	{
		$menuitem1 = "Buttered Popcorn";
		set_module_setting("concessionitem1", "Buttered Popcorn");
	}
	$menuitem2 = get_module_setting("concessionitem2");
	if (!$menuitem2)
	{
		$menuitem2 = "Caramel Corn";
		set_module_setting("concessionitem2", "Caramel Corn");
	}
	$menuitem3 = get_module_setting("concessionitem3");
	if (!$menuitem3)
	{
		$menuitem3 = "Candy";
		set_module_setting("concessionitem3", "Candy");
	}
	$menuitem4 = get_module_setting("concessionitem4");
	if (!$menuitem4)
	{
		$menuitem4 = "Soda";
		set_module_setting("concessionitem4", "Soda");
	}
	$snacknum = get_module_pref("concessionbought");
	$snackitem = "";
	if ($snacknum != 0)
	{
		$snackitem = get_module_setting("concessionitem" . $snacknum);
	}
	if ($op == "" || $op == "snacks") {
		$gametime = getgametime();
		$gamehour = gmdate("g",gametime());
		if ($gamehour == 12)
		{
			$gamehour = 0;
		}
		if (gmdate("a",gametime()) == "pm")
		{
			$gamehour += 12;
		}
		$opentime = get_module_setting("movietheateropen");
		$opentimestring = formatmovietime($opentime);
		$closetime = get_module_setting("movietheaterclose");
		$closetimestring = formatmovietime($closetime);

		set_module_pref("concessionbought", 0);

		$theateropen = 0;
		if ($closetime < $opentime)
		{
			if ($gamehour < $closetime || $gamehour >= $opentime)
			{
				$theateropen = 1;
			}
		} else {
			if ($gamehour >= $opentime && $gamehour < $closetime)
			{
			$theateropen = 1;
			}
		}
		if ($theateropen || $op == "snacks")
		{
			page_header($session['user']['location'] . "Movie Theater Lobby");
			output("`&`c`bWelcome to the " . $session['user']['location'] . " Movie Theater!`b`c");
			output("`7You walk into the Movies.`n`n");
			if ($op == "snacks")
			{
				$concessionboughtnum = (int)$concessionbought;
				if ($concessionbought == "")
				{
					output("The elf working at the concession stand smiles at you as you decide what you want.`n`n");
					output("`c`#Concession Stand Menu`n`n`\$%s`n`@%s`n`!%s`n`^%s`&`c`n`n", $menuitem1, $menuitem2, $menuitem3, $menuitem4);
				} else if ($concessionboughtnum < 1 || $concessionboughtnum > 4)
				{
					output("The concession stand elf looks at you for a moment, the points at the sign...`n`n");
					output("`c`#Concession Stand Menu`n`n`\$%s`n`@%s`n`!%s`n`^%s`&`c`n`n", $menuitem1, $menuitem2, $menuitem3, $menuitem4);
					$concessionbought = "";
				} else {
					$concessionprice = get_module_setting("concessionprice" . $concessionboughtnum);
					$concessionitem = get_module_setting("concessionitem" . $concessionboughtnum);
					if ($session['user']['gold'] >= $concessionprice)
                                        {
						$session['user']['gold'] -= $concessionprice;
						set_module_pref("concessionbought", $concessionboughtnum);
						output("The elf happily hands you your `&%s`7, then you head back over to the ticket booth.`n`n", $concessionitem);
					} else {
						output("With a sad look on her face, the elf reminds you that you don't have enough money for any `&%s`7.`n`n", $concessionitem);
					}
				}
				if ($concessionbought == "")
				{
					addnav("Concession Stand");
					for ($counter = 1; $counter <= 4; $counter++)
					{
						$concessionprice = get_module_setting("concessionprice" . $counter);
						$concessionitem = get_module_setting("concessionitem" . $counter);
						addnav("Buy " . $concessionitem . " (`^" . $concessionprice ."`0 gold)","runmodule.php?module=movietheater&op=snacks&cb=" . $counter);
					}
				}
			} else {
				output("As you look around you see a concession stand off to one side.`n`n");
			}
			output("On the wall, several posters advertise the movies which are currently showing.`n`n");
			output("`&Now Showing at the " . $session['user']['location'] . " `#Movie Theater`&`n`n");
			output("`c`\$%s`& (horror)`n`@%s`& (action)`n`!%s`& (comedy)`c`n`n", $horrortitle, $actiontitle, $comedytitle);
			$available = 0;
			if (!get_module_pref("horrorseen"))
			{
				$available += 1;
			}
			if (!get_module_pref("actionseen"))
			{
				$available += 2;
			}
			if (!get_module_pref("comedyseen"))
			{
				$available += 4;
			}
			if ($available > 0)
			{
				addnav("Ticket Booth");
			} else {
				output("You have seen all of the movies today. Please try back tomorrow.`n`n");
			}
			switch ($available) {
				case 1:
				case 3:
				case 5:
				case 7:
					addnav("Watch Horror Movie (`^" . $moviegold ."`0 gold)","runmodule.php?module=movietheater&op=horror");
					break;
			}
			switch ($available) {
				case 2:
				case 3:
				case 6:
				case 7:
					addnav("Watch Action Movie (`^" . $moviegold ."`0 gold)","runmodule.php?module=movietheater&op=action");
					break;
			}
			switch ($available) {
				case 4:
				case 5:
				case 6:
				case 7:
					addnav("Watch Comedy Movie (`^" . $moviegold ."`0 gold)","runmodule.php?module=movietheater&op=comedy");
					break;
			}
			if ($op != "snacks")
			{
				addnav("Concession Stand");
				addnav("Buy Snacks","runmodule.php?module=movietheater&op=snacks");
			}
		} else {
			page_header($session['user']['location'] . " Movie Theater");
			output("`&`c`bThe " . $session['user']['location'] . " Movie Theater is now closed!`b`c");
			output("`n`2When you try to enter the Movie Theater Lobby, you notice a sign on the door:`n`n");
			output("`&The time is %s`n`n", $gametime);
			output("`&Hours of operation are %s - %s`n`n", $opentimestring, $closetimestring);
		}
	} elseif ($op == "horror"){
		if ($session['user']['gold'] >= $moviegold)
		{
			set_module_pref("horrorseen", true);
			$session['user']['gold'] -= $moviegold;
			page_header($horrortitle);
			output("`7You decide to see %s. You are so excited for the horror movie!`n`n", $horrortitle); 
			output("You walk into the dark room. You decide to seat in front room.");
			if ($snacknum > 0)
			{
	                  output("You reach for your `&%s`7 as the movie starts.`n`n", $snackitem);
			} else {
      	            output("As the movie begins to play, you which you had a snack.`n`n");
			}
			output("You watch the movie and right in the middle the movie shows an old dwarf wearing nothing but a small towel.`n`n");  
			output("You begin to shiver and you hide under your seat shivering in fear!`n`n You look over and find a gem under your seat!`n`n");
			$session['user']['gems']++;
			debuglog("You found a gem under your seat");
		} else {
			page_header($session['user']['location'] . "Movie Theater Lobby");
			output("`7The fairy selling tickets at the counter notices that you don't have enough gold to see %s.`n`n", $horrortitle); 
		}
	} elseif ($op == "action"){
		if ($session['user']['gold'] >= $moviegold)
		{
			set_module_pref("actionseen", true);
			$session['user']['gold'] -= $moviegold;
			page_header($actiontitle);
			output("`7You decide to see %s.`n`n", $actiontitle);
			if ($snacknum > 0)
			{
				output("You take your `&%s`7 and enter the dark movie. You LOVE `&%s`7!`n`n", $snackitem, $snackitem);
			} else {
				output("As you enter the dark movie, you smell the `&Caramel Corn`7 and the `&Buttered Popcorn`7, and you regret not stopping for some.`n`n");
			}
			output("The action movie begins. You watch it to the end. All the action pumps you up!`n`n`");
			output("You gain a forestfight.`n`n");
			$session['user']['turns']++; 
			debuglog("You gained some turns");
		} else {
			page_header($session['user']['location'] . "Movie Theater Lobby");
			output("`7You don't have enough gold to see %s. The goblin usher stops you as you try to sneak in.`n`n", $actiontitle); 
		}
	} elseif ($op == "comedy"){
		if ($session['user']['gold'] >= $moviegold)
		{
			set_module_pref("comedyseen", true);
			$session['user']['gold'] -= $moviegold;
			page_header($comedytitle);
			output("`7You decide to see %s. You haven't had a good laugh lately.`n`n", $comedytitle);
			if ($snacknum > 0)
			{
				output("The slapstick antics of the goofballs on the screen make you laugh so hard you spill your `&%s`7 on the floor.`n`n`", $snackitem);
				output("When you bend down to clean it up, you find a small bag of gold.`n`n`");
			} else {
				output("The slapstick antics of the goofballs on the screen make you laugh so hard you roll helplessly on the floor.`n`n`");
				output("As you try to recompose yourself, you find a small bag of gold.`n`n`");
			}
			output("You find `^150`7 gold.`n`n");
			$session['user']['gold'] += 150; 
			debuglog("You find some gold in the theater");
		} else {
			page_header($session['user']['location'] . "Movie Theater Lobby");
			output("`7You don't have enough gold to see %s. You wait in the lobby, listening to everyone else laughing.`n`n", $actiontitle); 
		}
	}
	addnav("Theater Exit");
	villagenav();
	page_footer();
}
?>