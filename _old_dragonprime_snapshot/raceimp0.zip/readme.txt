-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
Race - Imp - A module for Legend of the Green Dragon 1.0.3

Legend of the Green Dragon
by  Eric "MightyE" Stevens (http://www.mightye.org)
and JT "Kendaer" Traub (http://www.dragoncat.net)

Software Project Page:
http://sourceforge.net/projects/lotgd

Modification Community Page:
http://dragonprime.net

Author of this Module:
Original Author - Chris Vorndran (Sichae)
Altered by - Enderandrew (enderandrew@gmail.com)

Enderandrew's LoGD game:
http://enderandrew.com/lotgd/

Download the latest version of this module from:
http://dragonprime.net/index.php?action=viewfiles&user=enderwiggin

----------------------------------------------
-- STATUS: -----------------------------------
----------------------------------------------
This module is STABLE.

----------------------------------------------
-- INFORMATION: ------------------------------
----------------------------------------------
This is Sichae's module.  I've altered what city the Imps live in,
and made some rather minute changes.  I thought some of the cities
were getting cramped, so I moved the Imps in with my new race, the
Draconis.  I don't advertise this module, because I'm not trying to
suggest people should run this one rather than Sichae's version.

This version also requires the alignment module, as chosing such a
dark and devilish race drops your alignment right off the bat.

This version of the module includes the description field, which
means it will only work with 1.0.3 and later versions of LotGD.

Hope you enjoy!

----------------------------------------------
-- INSTALLATION: -----------------------------
----------------------------------------------
Copy the raceimp.php file within this zip into your modules
directory.

Login to the Superuser Grotto and Install / Activate it.

-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-


