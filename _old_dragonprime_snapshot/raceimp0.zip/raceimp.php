<?php

function raceimp_getmoduleinfo(){
	$info = array(
		"name"=>"Race - Imp",
		"version"=>"1.2",
		"author"=>"Chris Vorndran<br>Altered by `!Enderandrew",
		"category"=>"Races",
		"description"=>"A race of dark, devilish creatures.",
		"download"=>"http://dragonprime.net/users/enderwiggin/raceimp.zip",
		"requires"=>array(
			"racedraconis" => "1.31|`1Enderandrew, http://dragonprime.net/users/enderwiggin/racedraconis.zip",
			"alignment" => "1.71|`1Enderandrew, http://dragonprime.net/users/enderwiggin/alignment98.zip",
		),			
		"vertxtloc"=>"http://dragonprime.net/users/enderwiggin/",
		"settings"=>array(
			"Imp Race Settings,title",
			"minedeathchance"=>"Chance for Imp to die in the mine,range,0,100,1|25",
			"divide"=>"Charm is divided by this value to give buff,int|5",
			"mindk"=>"How many DKs do you need before the race is available?,int|5",
			"cost"=>"How many Donation points do you need before the race is available?,int|0",
		),
	);
	return $info;
}

function raceimp_install(){
	if (!is_module_installed("racedraconis")) {
		output("The Imp only choose to live with Draconis.   You must install that race module.");
		return false;
	}
	module_addhook("charstats");
	module_addhook("chooserace");
	module_addhook("newday");
	module_addhook("pointsdesc");
	module_addhook("pvpadjust");
	module_addhook("raceminedeath");
	module_addhook("setrace");
	return true;
}

function raceimp_uninstall(){
	global $session,$badguy;
	$vname = getsetting("villagename", LOCATION_FIELDS);
	$gname = get_module_setting("villagename");
	$sql = "UPDATE " . db_prefix("accounts") . " SET location='$vname' WHERE location = '$gname'";
	db_query($sql);
	if ($session['user']['location'] == $gname)
		$session['user']['location'] = $vname;
	$sql = "UPDATE  " . db_prefix("accounts") . " SET race='" . RACE_UNKNOWN . "' WHERE race='Imp'";
	db_query($sql);
	if ($session['user']['race'] == 'Imp')
		$session['user']['race'] = RACE_UNKNOWN;
	return true;
}

function raceimp_dohook($hookname,$args){
	//yeah, the $resline thing is a hack.  Sorry, not sure of a better way
	//to handle this.
	// It could be passed as a hook arg?
	global $session,$badguy,$resline;
	if (is_module_active("racedraconis")) {
		$city = get_module_setting("villagename", "racedraconis");
	} else {
		$city = getsetting("villagename", LOCATION_FIELDS);
	}
	$race = "Imp";
	$cost = get_module_setting("cost");
	$city = get_module_setting("villagename");
	$divide = get_module_setting("divide");
	$imp = $session['user']['charm']/$divide;
	switch($hookname){

	case "charstats":
	if ($session['user']['race']==$race){
		addcharstat("Vital Info");
		addcharstat("Race", $race);
        }
        break;

	case "chooserace":
	if ($session['user']['sex']==SEX_FEMALE)
		break;
		$pointsavailable = $session['user']['donation'] - $session['user']['donationspent'];
		if ($session['user']['dragonkills'] < get_module_setting("mindk") || get_module_setting("cost") > $pointsavailable)
			break;
		output("<a href='newday.php?setrace=Imp$resline'>The land of Imps</a> Hellshade, `5hidden away from the world. `^Impish`0 `5 houses, crafted out of molten rock. Hidden in the deepest of crags, protected from the world of the normal folk. You are a very small being, only able to fly. You feel the need to trick others.`n`n",true);
		addnav("`\$I`)mp`0","newday.php?setrace=Imp$resline");
		addnav("","newday.php?setrace=Imp$resline");
		break;

	case "newday":
	if ($session['user']['race']==$race){
		raceimp_checkcity();
		apply_buff("racialbenefit",array(
			"name"=>"`@Imp Trickery`0",
			"atkmod"=>"(<attack>?(1+((1+floor($imp))/<attack>)):0)",
			"allowintrain"=>1,
			"allowinpvp"=>1,
			"rounds"=>-1,
		));
	}
	break;

	case "pointsdesc":
		if (get_module_setting("mindk")>0 || $cost>0)
		{
			$args['count']++;
			$format = $args['format'];
			$str = translate("The Imp race is availiable upon reaching %s Dragon Kills and %s Donation points.");
			$str = sprintf($str, get_module_setting("mindk"),
					get_module_setting("cost"));
			output($format, $str, true);
		}
		break;

	case "pvpadjust":
		if ($args['race'] == $race) {
			$badguy['attack']-=(2+floor($badguy['level']/5));
		}
		break;

	case "raceminedeath":
        if ($session['user']['race'] == $race) {
		$args['chance'] = get_module_setting("minedeathchance");
		$args['racesave'] = "Fortunately your Imp skill let you escape unscathed.`n";
        }
	break;

	case "setrace":
	if ($session['user']['race']==$race){
		output("`^As an Imp, you feel your matured skin protect you.`nYou gain extra attack, but you are also more evil!");
		if (is_module_active('alignment')) {
			align("-5");
		}
		if (is_module_active("cities")) {
			if ($session['user']['dragonkills']==0 && $session['user']['age']==0){
				//new farmthing, set them to wandering around this city.
				set_module_setting("newest-$city",
				$session['user']['acctid'],"cities");
			}
                set_module_pref("homecity",$city,"cities");
                $session['user']['location']=$city;
		}
        }
        break;

    }
    return $args;
}

function raceimp_checkcity(){
	global $session;
	$race="Imp";
	if (is_module_active("racedraconis")) {
		$city = get_module_setting("villagename", "racedraconis");
	} else {
		$city = getsetting("villagename", LOCATION_FIELDS);
	}
	
	if ($session['user']['race']==$race && is_module_active("cities")){
		//if they're this race and their home city isn't right, set it up.
		if (get_module_pref("homecity","cities")!=$city){ //home city is wrong
			set_module_pref("homecity",$city,"cities");
		}
	}
    return true;
}

function raceimp_run(){
}
?>