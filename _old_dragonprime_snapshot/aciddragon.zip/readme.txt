Acid Dragon

Version 1.01
Written by RPGSL
Download: http://dragon.com/lotgd/aciddragon.zip
Mirror: http://rpgsl.com/lotgd/aciddragon.zip

Game: http://rpdragon.com/


Installation

1) Copy aciddragon.php into your LotGD modules folder
2) Log in to LotGD with your admin account
3) Enter the Superuser Grotto
4) Click Manage Modules
5) Install aciddragon.php (Acid Dragon)
6) Configure settings and save
7) Activate


Questions/Comments?

alex@rpgsl.com


Visit www.rpgsl.com today for your RPG needs