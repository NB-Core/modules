<?php

function aciddragon_getmoduleinfo()
{
	$info = array
	(
		"name"		=> "Acid Dragon",
		"version"	=> "1.01",
		"author"	=> "RPGSL",
		"category"	=> "RPGSL",
		"download"	=> "http://www.rpdragon.com/lotgd/aciddragon.zip",
		"vertxtloc" => "http://www.rpdragon.com/",
		"description"=>"The Acid Dragon will attack only those characters with too much charm. You set the limit in the Module Manager.",
		"settings"	=> array
		(
			"Acid Dragon Settings,title",
			"maxcharmperdk"		=>	"What is the maximum amount of charm per DK that is allowed?,int|30",
			"maxpercentlost"	=>	"What is the maximum percentage of charm (above the max allowed for their DK) lost?,int|50",
			"acidchance"		=>	"What is chance the dragon will spit acid if they have above the max charm?,int|25",
		),
	);
	return $info;
}

function aciddragon_install()
{
	if (!is_module_installed("acidragon"))
	{
		output("Installing `bAcid Dragon`b (aciddragon.php) module by Role Play Game Story Lines (www.rpgsl.com)`n`n");
	}
	else
	{
		output("Updating `bAcid Dragon`b (aciddragon.php) module by Role Play Game Story Lines (www.rpgsl.com)`n`n");
	}
	module_addeventhook("forest", "return 85;");
	return true;
}

function aciddragon_uninstall()
{
	output("Uninstalling `bAcid Dragon`b (aciddragon.php) module by Role Play Game Story Lines (www.rpgsl.com)`n");
	return true;
}

function aciddragon_dohook($hookname, $args)
{
	return $args;
}

function aciddragon_runevent($type)
{
	global $session;
	$op = httpget('op');
	$from = "forest.php?";
	$session['user']['specialinc'] = "module:aciddragon";
	if ($op == "" || $op == "search")
	{
		output("A thunderous footfall echoes throughout the forest. The sheer immensity of the sound is enough for you to turn tail and run.");
		output("As you turn to high tail it out of there, you are overtaken by a massive dragon that swoops above you and then lands, snapping some saplings as he does.`n`n");
		addnav("Run like the wind!", $from . "op=run");
	}
	elseif ($op == "run")
	{
		output("You run like there's no tomorrow...");
		if ($session['user']['charm'] > $session['user']['dragonkills'] * get_module_setting("maxcharmperdk"))
		{
			if (e_rand(1,100) <= get_module_setting("acidchance"))
			{
				$charmloss = ceil(($session['user']['charm'] - $session['user']['dragonkills'] * get_module_setting("maxcharmperdk")) * e_rand(1,get_module_setting("maxpercentlost")) / 100);
				output("`n`nUnfortunately, you can't outrun the swift dragon. It plummets in front of you and lets loose a torrent of acid!");
				output("`n`nThe beast sprays its acid directly over your face! You lose %s charm!", $charmloss);
				addnews("%s was attacked in the forest by an acid spitting dragon and lost %s charm from the burns!!!", $session['user']['name'], $charmloss); 
				debuglog("lost $charmloss charm from getting sprayed by the acid dragon in the forest.");
				$session['user']['charm'] -= $charmloss;
				$session['user']['specialinc']="";
				addnav("Continue", "forest.php");				
			}
			else
			{
				output("`n`nThe horrendous creature is but a hair away from you as you dive into the underbrush, barely escaping the acidic spray!");
				$session['user']['specialinc']="";
				addnav("Continue", "forest.php");
			}
		}
		else
		{
			output("`n`nYou're lucky this time and manage to elude the horrid beast!");
			$session['user']['specialinc']="";
			addnav("Continue", "forest.php");
		}
	}

//Below is added in case something funky happens with the $op variable.

	else
	{
		output("`n`nYou're lucky this time and manage to elude the terrible creature!");
		$session['user']['specialinc']="";
		addnav("Continue", "forest.php");
	}
}

function aciddragon_run()
{
}
?>