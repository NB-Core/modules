<?php

function fallensam2_getmoduleinfo(){
	$info = array(
	"name"=>"Fallen Samurai II",
	"version"=>"1.0",
	"author"=>"`6Harry B and Kenny Chu",
	"category"=>"Forest Specials",
	"download"=>"http://dragonprime.net/users/Harry%20B/fallensam2.zip",
	"settings"=>array(
	"Fallen Samurai II Settings,title",
	"mingold"=>"Minimum gold to find (multiplied by level),range,200,300,1|10",
	"maxgold"=>"Maximum gold to find (multiplied by level),range,800,1500,1|100"
	),
	);
	return $info;
}

function fallensam2_install(){
	module_addeventhook("forest","return 100;");
	return true;
}

function fallensam2_uninstall(){
	return true;
}

function fallensam2_dohook($hookname,$args){
	return $args;
}

function fallensam2_runevent($type)
{
	global $session;
	$min = $session['user']['level']*get_module_setting("mingold");
	$max = $session['user']['level']*get_module_setting("maxgold");
	$gold = e_rand($min, $max);
	output("`n`2You stumble over the remains of a fallen Samurai.`n`n You search his pouch and find %s gold!", $gold);
	output("`n`n You search further and find his journal. `n`n Reading his journal, you learn many secrets of warfare. ");
	$session['user']['gold']+=$gold;
	$session['user']['attack']+=2;
	$session['user']['defense']+=2;
	$session['user']['experience']+=1000;
	debuglog("found $gold gold in the forest");
}

function fallensam2_run(){
}
?>