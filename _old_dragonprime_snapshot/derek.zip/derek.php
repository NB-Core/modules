<?php
function derek_getmoduleinfo(){
$info = array(
"name"=>"Derek's Stat Shop",
"version"=>"2.0",
"author"=>"Derek0,Reznarth",
"category"=>"Village",
"download"=>"http://dragonprime.net/users/Derek/derek.txt",
"settings"=>array(
"Derek Settings,title",
"statinventory"=>"Amount of Stat Points in stock,int|1000",
"statcost"=>"Gold needed to buy Stat,int|2000",
"statsell"=>"Gold paid to sell Stat,int|500",
"statsdailyb"=>"Max Stats allowed to buy per new day,int|50",
"statsdailys"=>"Max Stats allowed to sell per new day,int|50",
"showhp"=>"Allow user to buy HP?,bool|1",
"showff"=>"Allow user to buy Forest Fights?,bool|1",
"showch"=>"Allow user to buy Charm?,bool|1",
"enterlevel"=>"Min level needed to enter statshop,int|5",
"maxlevel"=>"Max level allowed to enter statshop,int|14",
"maxmessage"=>"Not allowed max level message,text|Don't you think it's time to kill the dragon?",
),
"prefs"=>array(
"Derek User Preferences,title",
"statsbuytoday"=>"How many stats bought today?,int|0",
"statsselltoday"=>"How many stats sold today?,int|0",
),
);
return $info;
}
function derek_install(){
module_addhook("village");
module_addhook("newday");
return true;
}

function derek_uninstall(){
return true;
}

function derek_dohook($hookname,$args){
global $session;
switch($hookname){

case "newday":
if ($args['resurrection'] != 'true') {
set_module_pref("statsbuytoday",0);
set_module_pref("statsselltoday",0);
}
break;

case "village":
addnav($args["marketnav"]);
addnav("Derek's Stat Shop","runmodule.php?module=derek");
break;

}
return $args;
}

function derek_run(){
global $session;
$op = httpget('op');
page_header("Derek's Stat Exchange");
$statinventory = get_module_setting("statinventory");
$statcost = get_module_setting("statcost");
$statsell = get_module_setting("statsell");
$statsdailyb = get_module_setting("statsdailyb");
$showhp = get_module_setting("showhp");
$showff = get_module_setting("showff");
$showch = get_module_setting("showch");
$statsdailys = get_module_setting("statsdailys");
$enterlevel = get_module_setting("enterlevel");
$maxlevel = get_module_setting("maxlevel");
$maxmessage = get_module_setting("maxmessage");
if ($session['user']['level']<$enterlevel) {
output("Derek tells you to come back after you haved gained a few levels.`n`n");
}else{
if ($session['user']['level']<=$maxlevel){

if ($op == ""){
output("Derek has stats for sale, they cost %s gold.",$statcost);
output("He will also buy them from you for %s gold.`n",$statsell);
output("You can buy as many as %s stats today ",$statsdailyb);
output("and you can sell as many as %s stats today.`n",$statsdailys);
output("`n There are %s stat points in stock.`n",$statinventory);
}

if ($op == "statbuy"){
if (get_module_pref("statsbuytoday")<get_module_setting("statsdailyb")){
output("`%How many stat points would you like to buy?`n");
output("<form action='runmodule.php?module=derek&op=statbuy2' method='POST'><input name='buy' id='buy'><BR><INPUT TYPE=RADIO NAME='type' VALUE='A' CHECKED >Attack +1<BR>
<INPUT TYPE=RADIO NAME='type' VALUE='D'>Defence +1<BR>",true);
if ($showhp == "1"){
output("<INPUT TYPE=RADIO NAME='type' VALUE='H'>Hit Points +5<BR>",true);
}
if ($showff == "1"){
output("<INPUT TYPE=RADIO NAME='type' VALUE='F'>Forest Fights +1<BR>",true);
}
if ($showch == "1"){
output("<INPUT TYPE=RADIO NAME='type' VALUE='C'>Charm +1<BR>",true);
}
output("<input type='submit' class='button' value='buy'></form>",true);
addnav("","runmodule.php?module=derek&op=statbuy2");
}else{ output("You can't buy anymore stats today`n");}
}

if ($op == "statbuy2"){
$max=(get_module_setting("statsdailyb") - get_module_pref("statsbuytoday"));
$stock=(get_module_setting("statinventory"));
$buy = httppost('buy');
$type = httppost('type');
if ($buy < 0) $buy = 0;
if ($buy >= $max) $buy = ($max);
if ($buy >= $stock) $buy = ($stock);
if ($session['user']['gold'] < ($buy * $statcost)) {output("Derek gives you the finger after you attempt to pay him less than his stat points are worth.`n`n"); }
else{
$cost=($buy * $statcost);
$session['user']['gold']-=$cost;
if ($type == "A") {
	$session['user']['attack']+=$buy;
} elseif ($type == "D") {
	$session['user']['defense']+=$buy;
} elseif ($type == "H") {
	$session['user']['maxhitpoints']+=($buy * 5);
	$session['user']['hitpoints']+=($buy * 5);
} elseif ($type == "F") {
	$session['user']['turns']+=$buy;
} elseif ($type == "C") {
	$session['user']['charm']+=$buy;
}
set_module_pref("statsbuytoday",get_module_pref("statsbuytoday")+$buy);
set_module_setting("statinventory",get_module_setting("statinventory")-$buy);
output("Derek takes your %s gold",$cost);
output(" and hands you %s stat potions.",$buy);
output(" You drink the potions, and you feel more power!");
debuglog("spent $cost gold buying $buy stat potions from Derek");
}
}

if ($op == "statsell"){
if (get_module_pref("statsselltoday")<get_module_setting("statsdailys")){
output("`%How many stat points would you like to sell?`n");
output("<form action='runmodule.php?module=derek&op=statsell2' method='POST'><input name='sell' id='sell'><BR><INPUT TYPE=RADIO NAME='type' VALUE='A' CHECKED >Attack -1<BR>
<INPUT TYPE=RADIO NAME='type' VALUE='D'>Defence -1<BR>",true);
if ($showhp == 1){
output("<INPUT TYPE=RADIO NAME='type' VALUE='H'>Hit Points -5<BR>",true);
}
if ($showff == 1){
output("<INPUT TYPE=RADIO NAME='type' VALUE='F'>Forest Fights -1<BR>",true);
}
if ($showch == 1){
output("<INPUT TYPE=RADIO NAME='type' VALUE='C'>Charm -1<BR>",true);
}
output("<input type='submit' class='button' value='buy'></form>",true);
addnav("","runmodule.php?module=derek&op=statsell2");
}else{output("You can't sell anymore stat points today`n");}
}

if ($op == "statsell2"){
$max=(get_module_setting("statsdailys") - get_module_pref("statsselltoday"));
$sell = httppost('sell');
$type = httppost('type');
if ($sell < 0) $sell = 0;
if ($sell >= $max) $sell = ($max);
if ($session['user']['attack'] < $sell) {output("Derek raises his fist at you knowing you do not have that many stat points.`n`n"); }
else{
$cost=($sell * $statsell);
if ($type == "A") {
	$session['user']['attack']-=$sell;
} elseif ($type == "D") {
	$session['user']['defense']-=$sell;
} elseif ($type == "H") {
	$session['user']['maxhitpoints']-=($sell * 5);
	$session['user']['hitpoints']-=($sell * 5);
} elseif ($type == "F") {
	$session['user']['turns']-=$sell;
} elseif ($type == "C") {
	$session['user']['charm']-=$sell;
}
$session['user']['gold']+=$cost;
set_module_pref("statsselltoday",get_module_pref("statsselltoday")+$sell);
set_module_setting("statinventory",get_module_setting("statinventory")+$sell);
output("Derek gives you %s gold",$cost);
output(" and then casts a ritual that steals %s of you stat points and forms a potion.",$sell);
debuglog("got $cost gold selling $sell stat points to Derek");
}
}

}else{
output("$maxmessage");}
}

addnav("Buy a stat point - $statcost gp","runmodule.php?module=derek&op=statbuy");
addnav("Sell a stat point - $statsell gp","runmodule.php?module=derek&op=statsell");
require_once("lib/villagenav.php");
villagenav();
page_footer();
}
?>
