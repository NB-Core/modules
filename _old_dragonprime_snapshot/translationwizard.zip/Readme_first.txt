Okay, how you install this module:

extract the content WITH structure to any folder.

copy the /*.* files to your /modules
copy the /translationwizard/*.* files to your /modules/translationwizard
(you simply copy it with structure, just to make sure)

Then go to the grotto and install it using "manage modules".

Newbieisland before 1.1.0 blocks every extra nav in the grotto. deactivate it.

You must have translator rights. user editor -> your acc -> superuser prefs -> enable translation

This module won't do all the work for you, but it will greatly enhance and automatize work. The Central Translations help in some languages and have translations stored, though not all.

Finally, read the FAQs available at Dragonprime, Forum "Translation Assistance" as well as the help page of the wizard in grotto -> translationwizard.



The Wizard is complex bit of work, so be careful and READ everything first before doing.