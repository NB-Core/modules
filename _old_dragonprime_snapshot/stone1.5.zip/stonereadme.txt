Sword in the Stone v1.5
Thanks to Drenac from Dragonprime for the input

Add this to newday.php at the end of the file before the footer:
//sword in the stone code
$sql="SELECT * FROM custom WHERE area='swordGuy'";
$result=db_query($sql);   
$dep = db_fetch_assoc($result);
$lastchose=strtotime($dep['dTime']);
$now=strtotime(date("H:i:s"));
		if (($now-$lastchose)>21600){
			$sql="SELECT * FROM accounts ORDER BY RAND() LIMIT 1";
		    $result = db_query($sql);
		    $dep = db_fetch_assoc($result);
            $swordguy=$dep['acctid']; 
		    //update sword account id
		    $sql="UPDATE `custom` SET `amount` = $swordguy WHERE `area` = 'swordGuy'";
		    $result=db_query($sql);
	        //update time sword was goten
		    $sql="UPDATE `custom` SET `dTime` = now() WHERE `area` = 'swordGuy'";
		    $result = db_query($sql);
			}
//end sword code

add a new database table called custom.  
create 3 fields, area (varchar(255)),amount(int), and dTime(time)

add a nav for the stone.php in village.php

enjoy!


-bapenguin
nick@happyapplefarm.net