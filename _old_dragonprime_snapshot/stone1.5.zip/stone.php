<?
require_once "common.php";
checkday();

page_header("Sword in the Stone");
output("`c`b`&Sword in the Stone`0`b`c");
$tradeinvalue = round(($session[user][weaponvalue]*.75),0);
if ($HTTP_GET_VARS[op]==""){
    output("`@Many brave ".($session[user][gender]?"women":"men")." have tried to retrieve the sword.  None could do it.`n`n");
    output("`2Will you, `4".($session[user][name])." `2 retrieve the sword in the stone?");
    $session[user][specialmisc]=e_rand(1,100);
    addnav("Attempt to pull the sword","stone.php?op=pull");
    addnav("Return to the village","village.php");
}else if ($HTTP_GET_VARS[op]=="pull"){
        addnav("Return to the village","village.php");
        if ($session[user][turns]<=0){output("`\$`bYou are too tired to try to pull the sword.  It seems futile.`b`0", true);}
             else {
                $session[user][turns]--;
                $sql="SELECT * FROM custom WHERE area='swordGuy'";
		$result = db_query($sql);
		$dep = db_fetch_assoc($result);
		$userid=$dep['amount'];
		$acctid=$session[user][acctid];
				if ($acctid==$userid){
					addnav("Daily news","news.php");
                  	                output("`!C`@O`#N`5G`3R`^A`4T`1U`2L`2T`4I`6O`5N`7S`3!  `2You've successfully pulled the sword.  You've got one shot on making good use of it though, so use it wisely!",true);
                 	                addnews("`%".$session[user][name]."`3 has pulled the sword from the stone!!");
                 	                $session[bufflist][101] = array("name"=>"`&Sword in the Stone","rounds"=>1,"wearoff"=>"The sword in the stone crumbles in your hand, damn did that kick ass!","atkmod"=>20,"roundmsg"=>"Prepare to die!!","activate"=>"offense");
				        $sql="SELECT * FROM accounts ORDER BY RAND() LIMIT 1";
					    $result = db_query($sql);
					    $dep = db_fetch_assoc($result);
					    $swordguy=$dep['acctid']; 
					    //update sword account id
					$sql="UPDATE `custom` SET `amount` = $swordguy WHERE `area` = 'swordGuy'";
					    $result=db_query($sql);
						//update time sword was goten
					    $sql="UPDATE `custom` SET `dTime` = now() WHERE `area` = 'swordGuy'";
					    $result = db_query($sql);
				} else {
			               output("`3You place both feet on the rock, and prepare to give it a huge tug.  You yank on the sword...",true);
				       output("`^WHOA!!! You fly end over end off the rock and land on your back. Ouch, that was `2too hard a pull!`n`n", true);
				       output("`3I guess you weren't the chosen one today!",true);
				       output("`2You lose 1 forrest fight.", true);
				      }
		 }     
}

page_footer();
?>