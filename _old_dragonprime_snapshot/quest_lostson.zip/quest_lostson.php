<?php

/*
This is Copyright 2004 (C) Christopher Phillips.
Contact me on dragonprime.net.
Developed under the CCL.
Version 1.0
The code is based upon a template Copyright 2004 by Christian Rutsch who you can contact at christian-DOT-rutsch-AT-gmx-DOT-de
*/

require_once("lib/villagenav.php");
require_once("lib/quests.php");

function quest_lostson_getmoduleinfo(){
	$info = array(
		"name"=>"Quest - Lost Son",
		"version"=>"1.0",
		"author"=>"Peter Corcoran",
		"category"=>"Quest",
		"download"=>"http://dragonprime.net/users/R4000/quest_lostson.txt",
		"requires"=>array(
			"questbasics" => "1.0|XChrisX, http://beta.lotgd.de/downloads/questpack.zip",
			"cities" => "1.0|Eric Stevens, core_module",
			"racehuman" => "1.0|Eric Stevens, core_module",
			"racetroll" => "1.0|Eric Stevens, core_module",
			"alchemy" => "1.3, core_module",
		),
		"vertxtloc"=>"http://dragonprime.net/users/R4000/",
		"settings"=>array(
			"req_min_hw" => "Required Hero Points to receive the quest, int|10",
			"req_max_hw" => "Maximum Hero Points to receive the quest, int|20",
			"req_min_dk" => "Required Dragon Kills to receive the quest, int|2",
			"req_max_dk" => "Maximum Dragon Kills to receive the quest, int|2",
			"req_min_lev" => "Minimum level to receive the quest, int|3",
			"req_max_lev" => "Maximum level to receive the quest, int|15",
			"req_quest" => "Is another quest required before starting this quest?, string|",
			"req_superuser" => "Can the quest be done by superusers at any time?, bool|true",
			"reward_exp" => "Reward (Experience), int|10000",
			"reward_explevel" => "Additional experience points per level, int|75",
			"reward_gems" => "Reward (Gems), int|1000",
			"reward_gold" => "Reward (Gold), int|10000",
			"reward_goldlevel" => "Additional gold per level, int|7500",
			"reward_quest" => "Number of quest points the player receives?, int|50",
		),
		"prefs" => array(
			"queststarted" => "Has the player accepted the quest?, bool|false",
			"queststation" => "What point in the quest is the player at?, int|0",
		),
	);
	return $info;
}

function quest_lostson_chance($where){
	global $session;
	$evname = get_module_setting("villagename", "racehuman");
	$dvname = get_module_setting("villagename", "racetroll");
	$queststation = get_module_pref("queststation", "quest_lostson");
	if (requirements_met("quest_lostson") || get_module_pref("queststarted", "quest_lostson")) {
		if ($where == "village") {
			if ($queststation == 0 && $session['user']['location'] == $evname) {
				$encounter = 50;
			}
			if ($queststation == 2 && $session['user']['location'] == $dvname) {
				$encounter = 50;
			}			
		} else if ($where == "forest" && $queststation == 1) {
			$encounter = 100;
		} else if ($where == "forest" && $queststation == 4) {
			$encounter = 100;
		} else {
			$encounter = 0;
		}
		return $encounter;
	} else {
		return 0;
	}
}

function quest_lostson_install() {

	$station = array(
		"-2" => "`\$The Hero failed to return the Child to Angul.`0",
		"-1" => "`@The Hero returned the Child to Angul`0",
		"0" => "`6 -Anguls Child - `0",
		"1" => "`6The Hero met Angul in the Troll village.`0",
		"2" => "`6In the forest the Hero found a clue.`0",
		"3" => "`6In the Human village, the Hero found another clue.`0",
		"4" => "`6The Hero returned the clue to Angul and figured out where the Child is.`0",
		"5" => "`6The Hero battled a Cone Clown Marionette to find the Child.`0",
	);
	$questfilename = "quest_lostson";
	db_query("DELETE FROM quests WHERE questname = '".$questfilename."'");
	foreach($station as $outputstation => $entry) {
		$sql = "INSERT INTO quests (questname, queststation, questdescription) VALUES ('".$questfilename."', '".$outputstation."', '".$entry."')";
		db_query($sql);
	}

	module_addeventhook("village", "require_once(\"modules/quest_lostson.php\"); return quest_lostson_chance(\"village\");");
	module_addeventhook("forest", "require_once(\"modules/quest_lostson.php\"); return quest_lostson_chance(\"forest\");");
	module_addhook("footer-runmodule");	
	return true;
}

function quest_lostson_uninstall(){
	return true;
}

function quest_lostson_dohook($hookname,$args) {
	global $session, $SCRIPT_NAME;
	$script = substr($SCRIPT_NAME,0,strpos($SCRIPT_NAME,"."));
	if ($script == "runmodule") $script = httpget('module');
	$queststation = get_module_pref("queststation", "quest_lostson");
	if ($hookname == "footer-runmodule" && $queststation == 3 && $script == "alchemy") {
		addnav("Lost Son");
		addnav("Show Angul the phone book", "runmodule.php?module=quest_lostson&step=gunk");
	} elseif ($hookname == "footer-runmodule" && $queststation == 4 && $script == "alchemy") {
		addnav("Lost Son");
		addnav("Return the Child to Angul", "runmodule.php?module=quest_lostson&step=greturn");
	} elseif ($hookname == "battle-defeat") {
		// If they have a special inc set for the dragon and they just
		// lost, reset it so they don't keep coming back here!
		if ($session['user']['specialinc'] == "module:quest_lostson") {
			$session['user']['specialinc'] = "";
		}
	}
	return $args;
}

function quest_lostson_runevent($type) {
	global $session;
	$evname = get_module_setting("villagename", "racehuman");
	$dvname = get_module_setting("villagename", "racetroll");
	$queststation = get_module_pref("queststation", "quest_lostson");
	$questinprogress = get_module_pref("questinprogress", "questbasics");

	if ($type == "village" && $session['user']['location'] == $evname && $queststation == 0 && $questinprogress < 1) {
		output("`7As you walk past the Alchemy, you are grabbed by a woman wearing red, who pulls you into an alleyway and pulls down her hood.`n`n");
		output("`3\"`@I am Angul. We have a crisis- when my son was playing in ".$dvname.", he suddenly disappeared while i wasnt looking.`3\" says `&Angul`3.`n`n");
		output("`3\"`^What has that to do with me?`3\" you ask.`n`n");
		output("`3\"`@I would like YOU to find him please, please. Do you accept?`3\" says `&Angul`3.`n`n");
		output("`3\"`^I accept.`3\" you say.`n`n");
		output("`3\"`@Thankyou. You are a kind ".($session['user']['sex']?"wo":"")."man. All I know, is that you may find help in the woods.`3\" says `&Elessa`3.`n`n");
		start_quest("quest_lostson");
	} elseif ($type == "forest" && $queststation == 1) {
		output("`7You step cautiously through the underbrush when you notice a small piece of paper flapping around on the floor.`n`n");
		output("`6You pick it up for a closer look`n`n");
		output("`&It reads: `n`n");
		output("`601994423445 - Simon`7`n");
		output("`601994733452 - Amy`7`n");
		output("`604378298664 - Phantasm`7`n");
		output("`609266646662 - Luke`7`n");
		output("`n`6Looks like a page from a phone book!");
		advance_quest("quest_lostson");		
	} elseif ($type == "forest" && $queststation == 4) {
		output("`@You wander around the Forest aimlessly, when a bright light illuminates everything.. a crashing noise ensues, and something attacks you!`n`n");
		output("`c`b`\$You have found the Cone Clown Marionette!`b`c");
		addnav("Attack it!","runmodule.php?module=quest_lostson&step=phantbattle");
	} elseif ($type == "village" && $session['user']['location'] == $dvname && $queststation == 2) {
		output("`@As you walk through the caverns of ".$dvname.", you spot a little book with a scribble on the front`n`n");
		output("`@Its a phone book!!!`n`n");
		output("`@The scribble reads '`^ITS THE CLOWN MUMMY!!!!!`@'.`n`n");
		output("`@You pick it up and decide to take it to Angul`n`n");
		output("`@Maybe she could tell you something about it?`n");
		advance_quest("quest_lostson");
	}
}

function quest_lostson_run(){
	global $session;
	$step = httpget('step');
	$op = httpget('op');
	$evname = get_module_setting("villagename", "racehuman");
	$dvname = get_module_setting("villagename", "racetroll");
	if ($step == "gunk") {
		page_header("Angul's Child");
			output("`7You talk to Angul, and ask if she can tell anything from the book you brought back..`n`n");
			output("`3\"`@OH MY GOD! This is my child's phone book`3\" `&Elessa`3 cries!`n`n");
			output("`3\"`^Really? What do the scribbles mean`3\" you intelligently say.`n`n");
			output("`3\"`@OH NO!!!!!! The clown has her! When we was living in Qexelcrag we upset a marionette called 'Cone Clown'. He swore he would steal my child one day!`3\" `&Angul`3 explains.`n`n");
			output("`3\"`@If you can find the clown, and defeat it, Could you bring my child back please! Pleaseee!.`3\" `&Angul`3 says.`n`n");
			output("`3\"`^I will defeat it.`3\" you swear.`n`n");
			advance_quest("quest_lostson");
		addnav("Back to $evname","village.php");
	} elseif ($step == "greturn") {
		page_header("Angul's Child");
			output("`3\"`^Here is your child Angul!`3\" you exclaim, as you hand the child to her.`n`n");
			output("`3\"`@Thankyou! I cannot thankyou enough! Please take this`3\" `&Angul`3 says, as she hands you a small bag.`n`n");
			end_quest("quest_lostson");
		addnav("Back to $evname","village.php");
	} elseif ($step=="phantbattle"){
		require_once("lib/forestoutcomes.php");
		restore_buff_fields();
		// Lets challenge you properly. Max HP is essential.
		$badguy = array();
		$badguy['creaturename']="An evil Cone Clown Marionette...";
		$badguy['creatureweapon']="Strings";
		$badguy['creaturelevel']= $session['user']['level'];
		$badguy['creaturegold']=1000;
		$badguy['creatureexp'] = round($session['user']['experience']/10, 0);
		$badguy['creaturehealth']=$session['user']['maxhitpoints']-2;
		$badguy['creatureattack']=$session['user']['attack']-2;
		$badguy['creaturedefense']=$session['user']['defense']-2;
		calculate_buff_fields();
		$badguy['playerstarthp']=$session['user']['hitpoints'];
		$badguy['diddamage']=0;
		$badguy['type'] = 'quest';
		$session['user']['badguy']=createstring($badguy);
		$battle = true;
	} elseif ($op=="fight" || $op=="run"){
		$skill = httpget('skill');
		$f = httpget('f');
		if ($op == "run" && e_rand(1, 5) < 3) {
			// They managed to get away.
			page_header("Escape");
			output("You set off running through the forest at a breakneck pace heading back the way you came.`n`n");
			output("In your terror, you lose your way and become lost, losing time for a forest fight.`n`n");
			if ($session['user']['turns']>0) { $session['user']['turns']--; }
			output("After running for what seems like hours, you finally arrive back at %s.", $session['user']['location']);
			addnav(array("Enter %s",$session['user']['location']), "village.php");
			output("`$`c`b`iYou have failed the quest.`i`b`c`0");
			end_quest_failure("quest_lostson");
			$battle=false;
		} else {
			$battle = true;
		}
	}
	if ($battle){
		page_header("Clown Battle!");
		require_once("battle.php");
		if ($victory){
			require_once("lib/forestoutcomes.php");
			forestvictory($badguy,false);
			output("`n`n`^You pick up the small child...`)");
			advance_quest("quest_lostson");
			villagenav();
		}elseif ($defeat){
			output("`n`n`^It ate your Gold...`)");
			$session['user']['gold']=0;
			require_once("lib/forestoutcomes.php");
			forestdefeat($badguy,"in the lost son quest");
			end_quest_failure("quest_lostson");
		}else{
			require_once("lib/fightnav.php");
			fightnav(true,true,"runmodule.php?module=quest_lostson&f=yes");
		}
	}
	page_footer();
}

?>