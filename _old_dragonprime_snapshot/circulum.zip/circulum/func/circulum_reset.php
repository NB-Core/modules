<?
//some parts from dragon.php
function do_reset() {
	require_once("./modules/circulum/func/circulum_nochange.php");
	$set=get_account_nochanges();
	$sql = "DESCRIBE " . db_prefix("accounts");
	$result = db_query($sql);
	for ($i=0;$i<db_num_rows($result);$i++){
		$row = db_fetch_assoc($result);
		if (array_key_exists($row['Field'],$nochange) &&
				$nochange[$row['Field']]){
		}else{
			$session['user'][$row['Field']] = $row["Default"];
		}
	}
	if (!array_key_exists("gold",$nochange) || !$nochange['gold'])
				{$session['user']['gold'] = get_module_setting("startgold",50);
	if (!array_key_exists("gems",$nochange) || !$nochange['gems'])
		$session['user']['gems'] = get_module_setting("startgems",50);
	if (!array_key_exists("title",$nochange) || !$nochange['title']) {	
		$newtitle = get_dk_title($session['user']['dragonkills'], $session['user']['sex']);
		$newname = change_player_title($newtitle);
		$session['user']['title'] = $newtitle;
		$session['user']['name'] = $newname;
	}
	if (!array_key_exists("maxhitpoints",$nochange) || !$nochange['maxhitpoints']) {
		$session['user']['maxhitpoints'] = get_module_setting("maxhitpoints",10);
		$session['user']['hitpoints']=$session['user']['maxhitpoints'];
	}
	set_module_pref('circuli')=get_module_pref('circuli')+1;
}

?>