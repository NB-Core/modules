<?php
//the first occurrence of a module that works like this is running at lotgd.de with many more options and the like
//the general idea is very good and people with a hundred dks are rather unbalanced
// so a global reset (at some time) with a bonus would be nice



function circulum_getmoduleinfo(){
	$info = array(
	    "name"=>"Circulum Vitae",
		"description"=>"This gives players the opportunity to start anew with benefits",
		"version"=>"1.0",
		"author"=>"`4Oliver Brendel`0",
		"category"=>"General",
		"download"=>"http://dragonprime.net/users/Nightborn/circulum.zip",
		"settings"=>array(
		"Circulum Vitae - Preferences,title",
		"dks"=>"At how many DKs will the CV be available?,range,1,100,1|50",
		"showcirculum"=>"Show a title in the users bioinfo?,bool|1",
		"Note: These setting will be overridden once you select the field to be kept in the editor,note",
		"startgold"=>"How many gold will the resetted player have,int|500",
		"startgems"=>"How many gems will the resetted player have,int|0",
		"maxhitpoints"=>"How many maxhitpoints will the resetted player have,int|10",
		
		/*"blocktrans"=>"Block the Untranslated Text in the grotto,bool|0",
		"query"=>"Use nested query (don't works with lower mysql servers),bool|0",
		"page"=>"How many results per page for fixing/checking,int|20",
		"Restrictions are: search+edit the translations table + truncate untranslated,note",
		"restricted"=>"Has the wizard restrictions for some users?,bool|0",
		"This is only for skilled users! Its not finding everything yet,note",
		"and your untranslated gets filled quickly if you begin to use this at start,note",
		"but if you want to scan new modules automatically on install - here it is,note",
		"autoscan"=>"Scan automatically modules upon install and insert into untranslated,bool|0",
		"translationdelete"=>"Ask if translations should be deleted at uninstallation of a module,bool|0",
		*/),
		"prefs"=>array(
		    "Circulum Vitae - User prefs,title",
			"circuli"=>"Number of CVs the player did,int|0",
			"Note: don't change this if you don't need to... it is changed by the module!,note",
			/*"allowed"=>"Does this user have unrestricted access to the wizard?,bool|0",
			"Note: This is only active if the restriction settings is 'true' in the module settings,note",
			"coding"=>"What is your coding table,enum,KS_C_5601-1987,KS_C_5601-1987 Korean,cp-866,cp-866 Cyrillic,win-1251,win-1251 Russian,KOI8-R,KOI8-R Russian,iso-8859-1,iso-8859-1 general,iso-8859-2,iso-8859-2 Polish,win-1250,win-1250 Polish,UTF-8, UTF-8,BIG5, BIG5 traditional Chinese,GB2312,GB2312 simplified Chinese,Shift_JIS,Shift_JIS Japanese,EUC-JP,EUC-JP Japanese",
			"view"=>"Use advanced view (shows more),bool|0",*/
		),
		);
    return $info;
}

function circulum_install(){
	module_addhook_priority("dk-preserve",1);
	module_addhook("superuser");
	module_addhook_priority("bioinfo",50);
	if (is_module_active("circulum")) debug("Circulum vitae updated");

	return true;
}

function circulum_uninstall()
{
  output_notl ("Performing Uninstall on Circulum Vitae. Thank you for using!`n`n");
  return true;
}


function circulum_dohook($hookname, $args){
	global $session;
		debug($args);
		switch($hookname) {
			case "superuser":
				addnav("Editors");
				addnav("Circulum Vitae Editor","runmodule.php?module=circulum&op=editor");
				break;
			case "bioinfo":
				if (get_module_pref('circuli') & get_module_setting('showcirculus')) {
					require_once("./modules/circulum/func/circulum_nochange.php");
					output("`^Honourable Title: `\$%s`n",get_title(get_title(get_module_pref('circuli'),($session['user']['sex']?"male":"female"))));
				}
				break;
		}
	return $args;
}

function circulum_run(){
	global $session;
	$dks=get_module_setting("dks");
	$op=httpget('op');
	$mode=httpget('mode');
	if ($op=="")  $op="default";
	require("./modules/circulum/$op.php");
/*	check_su_access(SU_IS_TRANSLATOR); //check again Superuser Access
	$op = httpget('op');
	page_header("Translation Wizard");
	//get some standards
	$languageschema=get_module_pref("language","translationwizard");
	$coding=get_module_pref("coding","translationwizard");
	if (!$coding) $coding="ISO-8859-1";
	$viewsimple=get_module_pref("view","translationwizard");
	$mode = httpget('mode');
	$namespace = httppost('ns');
	$from = httpget('from');
	$page = get_module_setting(page);
	debug("Language:".$languageschema." -- From:".$from);
	if (httpget('ns')<>"" && $namespace=="") $namespace=httpget('ns'); //if there is no post then there is maybe something to get
	$trans = httppost("transtext");
	if (is_array($trans))  //setting for any intexts you might receive
		{
		$transintext = $trans;
		}else
		{
		if ($trans) $transintext = array($trans);
		else $transintext = array();
		}
	$trans = httppost("transtextout");
	if (is_array($trans)) //setting for any outtexts you might receive
		{
		$transouttext = $trans;
		}else
		{
		if ($trans) $transouttext = array($trans);
		else $transouttext = array();
		}
	debug("Mode currently: ".$mode." -- Operation: ".$op);
	//end of the header
	if ($op=="")  $op="default";
	require("./modules/translationwizard/errorhandler.php");	
	require("./modules/translationwizard/$op.php");
	require_once("lib/superusernav.php");
	superusernav();
	require("./modules/translationwizard/build_nav.php");*/
	//page_footer();
}

?>
