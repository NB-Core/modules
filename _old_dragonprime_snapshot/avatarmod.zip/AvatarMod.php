///Genis' Avatar Mod///////////////
///Just fixed up the//////////////
///code to make it///////////////
///work better on///////////////
///any board, not just/////////
///mine, thus if something////
///is wrong, let me know/////
////////////////////////////

This is the only feild that must be added to the accounts table.(execute the below query)

ALTER TABLE `accounts` ADD `avatar` VARCHAR( 75 ) DEFAULT 'http://vespersoft.net/rpg/images/default.jpg' NOT NULL ;





Then you must edit the following in common.php///Displays Avatars in the various chat areas


After:

for ($i=0;$i < db_num_rows($result);$i++){
$row = db_fetch_assoc($result);


Add:////This code is a tad odd, but it was the only way I was able to get the avatar and emoting to work at the same time

$sql = "SELECT * FROM accounts WHERE acctid ='$row[author]'";
$avaResult = db_query($sql) or die(db_error(LINK));
$ava = db_fetch_assoc($avaResult);
$row[comment]=$row[comment]."~#|".$ava[avatar]."~#|";


After:

reset($v);
while (list($key,$val)=each($v)){

Add:

$val = explode("~#|", $val);
if($val[1]!="http://vespersoft.net/rpg/images/default.jpg"){
output("<img src='$val[1]'>",true );
}
output($val[0].$val[2],true);
		

Now edit inn.php adding the below lines into the large switch statement of choices.

switch($HTTP_GET_VARS[op]){
case "avatar":

if($HTTP_GET_VARS[act]==""){
output("`3Avatars cost $7000 you want one?");
addnav("Yes","inn.php?op=avatar&act=avay");
addnav("No","inn.php?op=avatar&act=avan");
}else if($HTTP_GET_VARS[act]=="avay"){
output("Type the URL for the avatar below");
output("<form action='inn.php?op=avatar&act=avayc' method ='POST'>",true);
addnav("","inn.php?op=avatar&act=avayc");
output("`n<input name='theAvatar' type='text' >",true);
output("<input type='Submit' type='button' value='Ok'>",true);
output("</form>",true);
}else if($HTTP_GET_VARS[act]=="avayc"){	
if ($session[user][gold]>=7000){
$session[user][avatar]=$_POST[theAvatar];
$session[user][gold]=$session[user][gold]-7000;
output("`7Thanks for shopping");
}else{
output("`7You need more money!!");
}
}else if($HTTP_GET_VARS[act]=="avan"){
output("`7k,Good-Day"); 
}
break;


You will also need to add this navigation to the menu somewhere:

addnav("Get an Avatar","inn.php?op=avatar");


Lastly in list.php add this:

After:

output("<table border=0 cellpadding=2 cellspacing=1 bgcolor='#999999'>",true);

Modify the FOllowing Line To:

output("<tr class='trhead'><td><b>Avatar</b></td><td><b>Alive</b></td><td><b>Level</b></td><td><b>Name</b></td><td><b>Location</b></td><td><b>Sex</b></td><td><b>Last on</b></tr>",true);

After:

output("<tr class='".($i%2?"trdark":"trlight")."'><td>",true);

Add:

output("<img src='$row[avatar]'>",true);
output("</td><td>",true);



And there you go, A Semi Decent Avatar Mod, Not as good as the other one probably, but still I thought Id contribute it 
just incase someone was interested.