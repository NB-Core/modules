<?

function marriagechocolates_getmoduleinfo(){
	$info = array(
		"name"=>"Chocolates for Marriage",
		"version"=>"1.0",
		"author"=>"`@`bCortalUX`b`n`2overhauled by Oliver Brendel",
		"override_forced_nav"=>true,
		"category"=>"Marriage",
		"download"=>"http://dragonprime.net/users/Nightborn/cortal_marriage.zip",
		"settings"=>array(
			"Chocolates for Marriage,title",
			"cost-chocolates"=>"How much gold do chocolates cost?,int|60",
			"points-chocolates"=>"How much points will chocolates donate?,int|15",
			"shortcut"=>"Show chocolates in javascript shortcut at flirt selection?,bool|1",
			"0 sets to -no bonus-,note",
			),
		"requires"=>array(
			"marriage"=>"1.0|by `@`bCortalUX`b`2overhauled by Oliver Brendel",
			),
		);

	return $info;
}

function marriagechocolates_install(){
	if (!is_module_active('marriagechocolates')){
		output_notl("`n`c`b`QChocolates for Marriage Module - Installed`0`b`c");
	}else{
		output_notl("`n`c`b`QChocolates for Marriage Module - Updated`0`b`c");
	}
	module_addhook("marriage-items");

	return true;
}

function marriagechocolates_uninstall(){
	return true;
}

function marriagechocolates_dohook($hookname, $args){
	global $session;
	switch($hookname){
		case "marriage-items":
			addnav("Flirt Actions");
			addnav("Buy someone some chocolates","runmodule.php?module=marriage&op=loveshack&op2=flirt&flirtitem=chocolates");
			$args['mailheader-chocolates']="`)Yummy`^ chocolates from {mname}";
			$args['chocolates']="`%{mname}`^ bought you a `)yummy chocolates`^ at the loveshack!`n{mname}`^'s flirt points increased by `@{pts}`^ with you!";
			$args['cost-chocolates']=get_module_setting('cost-chocolates');
			$points=get_module_setting('points-chocolates');
			if ($points) $args['points-chocolates']=$points;
			$args['output-chocolates']="{name}`@ emphatically thanks you for the `)yummy chocolates`@.`nYour points with {name}`@ increase by `^{pts}`@.";
			if (get_module_setting('shortcut')) array_push($args['shortcut'],array("chocolates"=>"Buy chocolates"));
		break;
	}
	return $args;
}

function marriagechocolates_run(){

}
?>