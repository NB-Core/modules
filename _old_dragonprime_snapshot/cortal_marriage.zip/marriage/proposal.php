<?
function marriage_pform($backoperation) {
	global $session;
	$whom = httppost("whom");
	rawoutput("<form action='runmodule.php?module=marriage&op=".$backoperation."&op2=propose&stage=0' method='POST'>");
	addnav("","runmodule.php?module=marriage&op=".$backoperation."&op2=propose&stage=0");
	if ($whom!="") {
		$string="%";
		for ($x=0;$x<strlen($whom);$x++){
			$string .= substr($whom,$x,1)."%";
		}
		if (get_module_setting('sg')==1) {
			$sql = "SELECT login,name,acctid FROM ".db_prefix("accounts")." WHERE login LIKE '%$whom%' AND acctid<>".$session['user']['acctid']." AND marriedto=0 ORDER BY level,login";
		} else {
			$sql = "SELECT login,name,acctid FROM ".db_prefix("accounts")." WHERE name LIKE '%$string%' AND acctid<>".$session['user']['acctid']." AND sex<>".$session['user']['sex']." AND marriedto=0 ORDER BY level,login";
		}
		$result = db_query($sql);
		if (db_num_rows($result)!=0) {
			output("`@These users were found `^(click on a name`@):`n");
			rawoutput("<table cellpadding='3' cellspacing='0' border='0'>");
			rawoutput("<tr class='trhead'><td>Name</td></tr>");
			for ($i=0;$i<db_num_rows($result);$i++){
			$row = db_fetch_assoc($result);
			rawoutput("<tr class='".($i%2?"trlight":"trdark")."'><td><a href='runmodule.php?module=marriage&op2=propose&op=".$backoperation."&stage=1&target=".$row['acctid']."'>");
			output_notl($row['name']);
			rawoutput("</td></tr>");
			addnav("","runmodule.php?module=marriage&op2=propose&op=".$backoperation."&stage=1&target=".$row['acctid']);
			}
			rawoutput("</table>");
		} else {
			output("`c`@`bA user was not found with that name.`b`c");
		}
		output_notl("`n");
	}
	output("`^`b`cMarriage..`c`b");
	output("`nWho do you want to propose to?");
	output("Name of user (cannot be married already): ");
	rawoutput("<input name='whom' maxlength='50' value=\"".htmlentities(stripslashes($whom))."\">");
	$apply = translate_inline("Propose");
	rawoutput("<input type='submit' class='button' value='$apply'></form>");
}

function marriage_plist($op) {
	$stuff = explode(',',get_module_pref('proposals'));
	$n = 0;
	if (count($stuff)>0) {
		output("`@The following people have proposed to you... click to marry, or reject them!");
		rawoutput("<table><tr class='trhead'><td>");
		output("Operations");
		rawoutput("</td></tr>");
		$marry=translate_inline("Marry");
		$reject=translate_inline("Reject");		
		foreach ($stuff as $val) {
			if ($val!="") {
				$n++;
				$sql = "SELECT name FROM ".db_prefix("accounts")." WHERE acctid='$val' AND locked=0";
				$res = db_query($sql);
				if (db_num_rows($res)!=0) {
					$row = db_fetch_assoc($res);
					rawoutput("<tr ".($n%2?"trlight":"trdark")."><td>[<a href='runmodule.php?module=marriage&op=".$op."&target=".$val."&op2=marry'>$marry ".sanitize($row['name']));
					rawoutput("</a>] - [<a href='runmodule.php?module=marriage&op=".$op."&target=".$val."&op2=reject'>$reject ".sanitize($row['name'])."</a>]");
					addnav("","runmodule.php?module=marriage&op=".$op."&target=".$val."&op2=marry");
					addnav("","runmodule.php?module=marriage&op=".$op."&target=".$val."&op2=reject");
				}
			}
		}
	} else {
		rawoutput("<tr class='trhilight'><td>");
		output("`^Aww! No-one wants to marry you.");
		rawoutput("</td></tr>");
	}
	output_notl('</table>',true);
}
?>