<?
$operation = httpget('op2');
if ($operation=="") $operation="general";
page_header("Marriage Counselling");
addnav("Actions");
switch($operation) {
	case "general":
		output("`@Walking to the edge of town, you look around for `^Professor van Lipvig`@'s office.");
		output("`nNot finding it, you walk back, and see a large wooden building that you had never noticed before.");
		output("`nWalking up to it, you see a sign, and a voice yells out 'Come in,' from a nearby window.");
		villagenav();
		addnav("Enter the Office","runmodule.php?module=marriage&op=counselling&op2=enter");
		break;
	case "enter":
		output("`@Pushing the carved door open ever so quitely, you enter into a spacious, yet opulent chamber.");
		output("`nLooking around, you see chairs, plush rugs, and hunting trophies.");
		output("`nWalking to the end of the warm room, you see many herbal candles, and a burning fire.");
		output("`nBehind you, a melodious voice says '`^Van Lipvig's office, how may I help you.`@'");
		output("`nAlmost jumping out of your skin, you turn around to see a small woman sat at her desk.");
		output("`nNodding imperceptibly, she speaks, '`^Ah, %s`0`^. Van Lipvig is with someone else at the moment. Please sit down.`@'",$session['user']['name']);
		villagenav();
		addnav("To the waiting Area","runmodule.php?module=marriage&op=counselling&op2=wait");
		break;
	case "wait":
		addnews("%s`0`@ had to go to a Social Counsellor, due to a rejected Marriage Proposal!",$session['user']['name']);
		set_module_pref('counsel',0);
		output("`@Sitting on a stuffed bear, you study the room and it's paintings, many of which you feel you have seen before.");
		output("`nOne is of a Green Dragon fighting a constant battle, and yet another contains a scene of a street hawker....");
		output("`n`nClosing one eye to study the painting, you start to feel drowsy.. then someone wakes you up. '`^%s`0`^, the Doctor will see you now.`@",$session['user']['name']);
		addnav("See Van Lipvig","runmodule.php?module=marriage&op=counselling&op2=checkin");
		break;
	case "checkin":
		output("`@Standing up, you walk past the same painting of a Dragon that you saw earlier, and through a brass door.");
		output("`nEmerging through it, you see yet another spacious chamber, and walk through it.");
		output("`nIf the other was Plush, this could only be described as minimalist.");
		output("`nAs you exit this chamber, you walk into an office where a short stumpy man sits at a large desk, with a moustache that stretches out on either side of him, while a couch and a clock stand at the other end of the chamber.");
		output("`n'`&Ah, mah fviend. Ah am here to prevent another Socielle Incident.. but fahgive me, I ahm Professor Van Lipvig, socielle extraordinaire.`@'");
		output("`n`6As he says this, you are reminded of a large toad, and have to stop yourself from laughing.");
		output("`n`@'`&Vell, mah tachitarn fah-wend, puh-lease seet on mah couch.`@'");
		addnav("Sit on the Couch","runmodule.php?module=marriage&op=counselling&op2=couch");
		break;
	case "couch":
		$array=array("a green dragon","a set of frolicking sheep","a large piece of cake","a pixie","a gem");
		$array=$array[array_rand($array)];
		output("`@Once you are sitting on the couch, he asks you to stare at his clock, and tell him what you see..");
		output("`n'`^I see %s,`@' you say.",translate_inline($array));
		output("`n'`&Really? That is vierd. This is supposed to be a previliminary eye test.`@'");
		addnav("Stare into a Candle","runmodule.php?module=marriage&op=counselling&op2=see");
		break;
	case "see":
		$array=array("a green dragon","a tan dragon","a large swamp","an elephant with green pixies jumping around it","a troll","a vivid sunset");
		$array=$array[array_rand($array)];
		output("`@With you still sitting on the couch, he asks you to stare at a candle, and tell him what you see..");
		output("`n'`^I see %s,`@' you say.",translate_inline($array));
		output("`n'`&Keep that in mind as ve do ze next stage.`@'");
		addnav("The next stage","runmodule.php?module=marriage&op=counselling&op2=dream");
		break;
	case "dream":
		output("`@'`&Please lie down and try to go to sleep.`@' Lipvig says.");
		output("`nNot sure about going to sleep in the same room as this weird person, you manage to clear your head, and you are soon in the land of sleep..");
		output("`nHalfway through a weird dream, you are woken up and asked to explain what you saw.");
		output("`n'`^I saw a large room, filled with riches,`@' you say.");
		addnav("The next stage","runmodule.php?module=marriage&op=counselling&op2=materi");
		break;
	case "materi":
		output("`@'`&I have it!`@' Lipvig exclaims.");
		output("`n'`&I think you hunger for material riches..`@' Lipvig states.");
		output("`n'`&I must help you on your road.. I was ordered..`@' Lipvig says, in an unhappy tone.");
		output("`nLipvig throws a powder over you..");
		output_notl("`c`b");
		$outcome=e_rand(1,4);
		switch ($outcome) {
			case "1":
				$session['user']['gems']++;
				output("`n`%You feel richer.");
			break;
			case "2":
				$session['user']['level']++;
				output("`n`%You feel wiser.");
			break;
			case "3":
				$session['user']['experience']+=1500;
				output("`n`%You feel more experienced.");
			break;
			case "4":
				$session['user']['gold']+=1500;
				output("`n`%You feel richer.");
			break;
		}
		output_notl("`b`c");
		addnav("Leave","runmodule.php?module=marriage&op=counselling&op2=l");
		break;
	default:
		output("`@You stand up, not really sure how this helped you, but you are sure it must have done.");
		output("`nYou leave..");
		villagenav();
		break;
}
page_footer();
?>