<?
function marriage_divorce() {
	global $session;
	$who = $session['user']['marriedto'];
	$session['user']['marriedto'] = 0;
	if ($who==0) {
		return;
	} else if ($who==INT_MAX) {
		require_once("lib/partner.php");
		addnews("`&%s`% and `&%s`% were divorced today...", $session['user']['name'],get_partner());
		return;
	}

	$sql = "SELECT name,sex FROM ".db_prefix("accounts")." WHERE acctid='$who' AND locked=0";
	$res = db_query($sql);
	if (db_num_rows($res)<1) return;
	$row = db_fetch_assoc($res);
	$sql = "UPDATE " . db_prefix("accounts") . " SET marriedto='0' WHERE acctid='$who'";
	db_query($sql);
	$mailmessage=array("%s`@ has divorced you.",$session['user']['name']);
	$mailmessagg=array("%s`@ has divorced you.`nYou get %s gold.",$session['user']['name'],$session['user']['gold']);
	$t = array("`@Divorce!");
	addnews("`&%s`0`% and `&%s`% were divorced today...", $session['user']['name'],$row['name']);
	debuglog("divorce from {$row['name']}");
	require_once("lib/systemmail.php");
	if (get_module_setting('dmoney')==1&&$session['user']['gold']>0) {
		$sql = "UPDATE " . db_prefix("accounts") . " SET gold=gold + ".$session['user']['gold']." WHERE acctid='$who'";
		$session['user']['gold']=0;
		db_query($sql);
		systemmail($who,$t,$mailmessagg);
		output_notl("`n`n");
		output("`@You notice also that all your gold at hand is gone... \"`&I need this to make myself a new home, thanks...`@\"`n");
	} else {
		systemmail($who,$t,$mailmessage);
	}
	output("`n`@You feel guilty about the divorce.");
	invalidatedatacache("marriage-marriedonline");
	invalidatedatacache("marriage-marriedrealm");
	set_module_objpref("marriage",$session['user']['marriedto'],"marriagedate","0000-00-00 00:00:00");
	set_module_objpref("marriage",$session['user']['acctid'],"marriagedate","0000-00-00 00:00:00");
	apply_buff('marriage-divorce',
		array(
			"name"=>"`4Divorce Guilt",
			"rounds"=>100,
			"wearoff"=>"`\$You feel no longer guilty about your divorce.",
			"defmod"=>0.83,
			"survivenewday"=>1,
			"roundmsg"=>"`\$Guilt haunts you.",
			)
	);
	}
?>