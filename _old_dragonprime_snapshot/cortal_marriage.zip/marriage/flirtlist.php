<?
function marriage_flist($items) {
	global $session;
	$list = unserialize(get_module_pref('flirtsreceived'));
	if ($list=="") $list=array();
	if (sizeof($list)>0) {
		output("`@The following people have flirted with you... go ahead, flirt back, break hearts!");
		output("`nIf a user has at least `^%s`@ flirt points with you, you can propose.`nIgnoring will wipe that user from your list.",get_module_setting('flirtmuch'));
		rawoutput("<table><tr class='trhead'><td>");
		output("Data");
		rawoutput("</td></tr>");
		$n=0;
		$stage=((get_module_setting('cost')>0&&get_module_pref('buyring')==1) || get_module_setting('cost')==0);
		//debug("Stage:".$stage);
		reset($list);
		while (list($name,$points)=each ($list)) {
			$sql = "SELECT name,acctid FROM ".db_prefix("accounts")." WHERE acctid='".substr($name,1)."' AND locked=0";
			$res = db_query($sql);
			if (db_num_rows($res)!=0) {
				$row = db_fetch_assoc($res);
				rawoutput("<tr ".($n%2?"trlight":"trdark")."><td>");
				output_notl("`@[`^".$row['name']."`@]");
				output("`^%s`@ has `^%s`@ flirt points with you.",$row['name'],$points);
				$links = translate_inline("Links: ");
				$links .= " [".marriage_flink($row['acctid'],"Buy a Drink","drink")."]";
				$links .= " - [".marriage_flink($row['acctid'],"Buy some Roses","roses")."]";
				$links .= " - [".marriage_flink($row['acctid'],"Kiss","kiss")."]";
				foreach ($items['shortcut'] as $key=>$val){
					list($itemname,$navname)= each($val);
					//debug($val);
					//debug("Name:".$itemname." nav:".$navname);
					$links .= " - [".marriage_flink($row['acctid'],$navname,$itemname)."]";
				}
				$links .= " - [".marriage_flink($row['acctid'],"Slap","slap")."]";
				$links .= " - [".marriage_flink($row['acctid'],"Ignore","ignore")."]";
				if ($points>=get_module_setting('flirtmuch')&&$session['user']['marriedto']==0) {
					$blah = "";
					if ($session['user']['location'] == get_module_setting("chapelloc")&&get_module_setting("all")==0&&get_module_setting('oc')==0) {
						$blah = 'chapel';
					} elseif (get_module_setting("all")==1&&get_module_setting('oc')==0) {
						$blah = 'chapel';
					} elseif (get_module_setting('oc')==1) {
						$blah = 'oldchurch';
					}
					//stage is set above
					if ($blah!='') {
						$links.=" - [<a href='runmodule.php?module=marriage&op2=propose&op=$blah&stage=$stage&target=".$row['acctid']."'>".translate_inline("Propose")."</a>]";
						addnav("","runmodule.php?module=marriage&op2=propose&op=$blah&stage=$stage&target=".$row['acctid']);
					} else {
						$links.=" - [<a href='runmodule.php?module=marriage&op2=propose&op=chapel&stage=$stage&target=".$row['acctid']."'>".translate_inline("Propose")."</a>]";
						addnav("","runmodule.php?module=marriage&op2=propose&op=chapel&stage=$stage&target=".$row['acctid']);
					}
				}
				rawoutput(marriage_hidedata($links));
				rawoutput("</td></tr>");
			}
		}
		rawoutput("</table><br>");
	} else {
		rawoutput("<table><tr class='trhilight'><td>");
		output_notl("`^");
		output("Aww! No-one has flirted with you.");
		rawoutput("</td></tr></table><br>");
	}
	$list = unserialize(get_module_pref('flirtssent'));
	//debug($list);
	if ($list=="") $list=array();
	if (sizeof($list)>0) {
		output("`@You've flirted with the following people.");
		output("`nIf you send least `^%s`@ flirt points, a person can propose to you.",get_module_setting('flirtmuch'));
		rawoutput("<table><tr class='trhead'><td>");
		output("Data");
		rawoutput("</td></tr>");
		$n=0;
		while (list($name,$points)=each ($list)) {
			$n++;
			$name=substr($name,1);
			$sql = "SELECT name FROM ".db_prefix("accounts")." WHERE acctid='$name' AND locked=0";
			$res = db_query($sql);
			if (db_num_rows($res)!=0) {
				$row = db_fetch_assoc($res);
				rawoutput("<tr ".($n%2?"trlight":"trdark")."><td>");
				output_notl("`@[`^".$row['name']."`@]");
				output("You have `^%s`@ flirt points with `^%s`@.",$points,$row['name']);
				rawoutput("</td></tr>");
			}
		}
		rawoutput("</table><br>");
	} else {
		rawoutput("<table><tr class='trhilight'><td>");
		output_notl("`^");
		output("Aww! You haven't flirted with anyone.");
		rawoutput("</td></tr></table><br>");
	}

}
?>