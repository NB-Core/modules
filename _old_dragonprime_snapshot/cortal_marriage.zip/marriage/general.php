<?
$operation = httpget('op2');
$target = httpget('target');
$vicar = '`5Capelthwaite';
$gendervicar = translate_inline('He');
$gendervicarpersonal = translate_inline('himself');
if ($op=='oldchurch') {
	page_header("The Marriage Wing");
} else {
	page_header("The Chapel");
	$vicar = get_module_setting('vicarname');
	$gendervicar = (get_module_setting('gendervicar')?translate_inline("She"):translate_inline("He"));
	$gendervicarpersonal = (get_module_setting('gendervicar')?translate_inline("herself"):translate_inline("himself"));

}
switch ($operation) {
	case "proposelist":
		require_once("./modules/marriage/proposal.php");
		marriage_plist($op);
		break;
	case "propose":
		if (get_module_setting('flirttype')) output("`n`@Having run to your local vicar, you propose..`n");
		if (httpget('stage')==1) {
			$i = get_module_pref('proposals','marriage',$target);
			$h = explode(',',$i);
			if (in_array($session['user']['acctid'],$h)) {
				output("`n`^%s `3frowns, \"`&You've already proposed to that person.`3\"",$vicar);
			} else {
				$mailmessage=array("%s`0`@ has proposed to you.",$session['user']['name']);
				$t = array("`@Proposal!");
				require_once("lib/systemmail.php");
				systemmail($target,$t,$mailmessage);
				array_push($h,$session['user']['acctid']);
				$i .= implode(",",$h);
				set_module_pref('proposals',$i,'marriage',$target);
				set_module_pref('buyring',0);
				debuglog("proposed to player number $target");
				if (get_module_setting('cost')>0) {
					output("`n`^%s `3says, \"`&Ah, right! I forgot.. I sent them that wedding ring for you.`3\"",$vicar);
				} else {
					output("`n`^%s `3says, \"`&Ah, right! I forgot.. I sent them a wedding ring for you.`3\"",$vicar);
				}
			}
		} elseif ((get_module_setting('cost')>0&&get_module_pref('buyring')==1) || get_module_setting('cost')==0) {
			output("`^%s `3says, \"`&Sorry, who was it you wanted to propose to?`3\"`n",$vicar);
			require_once("./modules/marriage/proposal.php");
			marriage_pform($op);
		} else {
			output("`^%s `3says, \"`&You haven't bought an engagement ring! You can't propose.`3\"",$vicar);
			output("`n`^%s `3offers, \"`&I have some I could sell, and I'll sell you one.. for a small fee.`3\"",$vicar);
			addnav("Actions");
			addnav("Ask about a Ring","runmodule.php?module=marriage&op=".$op."&op2=ringbuy&stage=0");
		}
		break;
	case "ringbuy":
		if (httpget('stage')==1) {
			set_module_pref('buyring',1);
			$session['user']['gold']-=get_module_setting('cost');
			output("`n`^%s `3takes %s gold from you, and hands you the Ring.",$vicar,get_module_setting('cost'));
			addnav("Actions");
			addnav("Propose","runmodule.php?module=marriage&op2=propose&op=chapel&stage=0");
		} else {
			output("`^%s `3reaches into a pocket and takes out a ring.",$vicar);
			output("`^%s `3says, \"`&This ring costs %s gold.`3\"",$vicar,get_module_setting('cost'));
			if ($session['user']['gold']<get_module_setting('cost')) {
				output("`n`^%s `3looks at your gold pouch and says, \"`&You haven't got enough for this ring.`3\"",$vicar);
			} else {
				output("`n`^%s `3looks at your gold pouch and says, \"`&You've got enough for this ring.`3\"",$vicar);
				addnav("Actions");
				addnav("Buy a Ring","runmodule.php?module=marriage&op=".$op."&op2=ringbuy&stage=1");
			}
		}
		break;
	case "talk":
		require_once("lib/commentary.php");
		addcommentary();
		output("`@You hear people whispering...`n",$vicar);
		viewcommentary("marriage","`#Whisper?`@",25,"whisper");
		break;
	case "marry":
		set_module_pref('flirtsfaith',0);
		$stuff = explode(',',get_module_pref('proposals'));
		$i = "";
		foreach ($stuff as $val) {
			if ($val!=""&&$val!=$target&&$val!=$session['user']['acctid']) {
				$i .= ",".$val;
			}
		}
		set_module_pref('proposals',$i);
		$stuff = explode(',',get_module_pref('proposals','marriage',$target));
		$i = "";
		foreach ($stuff as $val) {
			if ($val!=""&&$val!=$target&&$val!=$session['user']['acctid']) {
				$i .= ",".$val;
			}
		}
		set_module_pref('proposals',$i,'marriage',$target);
		$mailmessage=array("%s`0`@ has married you!",$session['user']['name']);
		$t = array("`@Marriage!");
		require_once("lib/systemmail.php");
		systemmail($target,$t,$mailmessage);
		$session['user']['marriedto']=$target;
		$sql = "UPDATE " . db_prefix("accounts") . " SET marriedto=".$session['user']['acctid']." WHERE acctid='$target'";
		db_query($sql);
		$sql = "SELECT name,sex FROM ".db_prefix("accounts")." WHERE acctid='$target' AND locked=0";
		$res = db_query($sql);
		$row = db_fetch_assoc($res);
		addnews("`&%s`0`& and %s`0`& were joined today, in joyous matrimony.", $session['user']['name'],$row['name']);
		$first = ($session['user']['sex']?translate_inline("Wife"):translate_inline("Husband"));
		$second = ($row['sex']?translate_inline("Wife"):translate_inline("Husband"));
		output("`^%s `3says \"`&And I pronounce thee %s and %s.. yada yada.`3\"",$vicar,$first,$second);
		output("`n`^%s `3says \"`&Don't look so suprised! Nothing is sacred anymore...`3\"",$vicar);
		set_module_pref('buyring',0,'marriage',$session['user']['acctid']);
		set_module_pref('buyring',0,'marriage',$session['user']['marriedto']);
		invalidatedatacache("marriage-marriedonline");
		invalidatedatacache("marriage-marriedrealm");
		require_once("lib/datetime.php");
		$time=date("Y-m-d H:i:s");
		set_module_objpref("marriage",$session['user']['marriedto'],"marriagedate",$time);
		set_module_objpref("marriage",$session['user']['acctid'],"marriagedate",$time);
		apply_buff('marriage-start',
			array(
				"name"=>"`@Marriage",
				"rounds"=>100,
				"wearoff"=>"`&The elation wears off.",
				"defmod"=>1.83,
				"survivenewday"=>1,
				"roundmsg"=>"`@You are elated at your marriage",
				)
		);
		debuglog("proposal accepted from {$row['name']}");
		break;
	case "reject":
		$stuff = explode(',',get_module_pref('proposals'));
		$i = "";
		foreach ($stuff as $val) {
			if ($val!=""&&$val!=$target&&$val!=$session['user']['acctid']) {
				$i .= ",".$val;
			}
		}
		set_module_pref('proposals',$i);
		$stuff = explode(',',get_module_pref('proposals','marriage',$target));
		$i = "";
		foreach ($stuff as $val) {
			if ($val!=""&&$val!=$target&&$val!=$session['user']['acctid']) {
				$i .= ",".$val;
			}
		}
		set_module_pref('proposals',$i,'marriage',$target);
		$mailmessage=array("%s`0`@ has rejected you as unfit for marriage! You lose some charm.",$session['user']['name']);
		$t = array("`@Rejection!");
		require_once("lib/systemmail.php");
		systemmail($target,$t,$mailmessage);
		if (get_module_setting('counsel')==1) {
			$mailmessage=array(translate_inline("`@Hallo. I am Professor van Lipvig, and I haf been paid by.. benefactors, to counsel you due to your Mishap vith %s`@.`nPlease visit me in ze village."),$session['user']['name']);
			$t = array("`@Professor");
			require_once("lib/systemmail.php");
			systemmail($target,$t,$mailmessage);
			set_module_pref('counsel',1,'marriage',$target);
		}
		$sql = "SELECT name,sex,charm FROM ".db_prefix("accounts")." WHERE acctid='$target' AND locked=0";
		$res = db_query($sql);
		$row = db_fetch_assoc($res);
		if (get_module_setting('flirtCharis')==1&&$row['charm']!=0) {
			$row['charm']--;
			$sql = "UPDATE " . db_prefix("accounts") . " SET charm=".$row['charm']." WHERE acctid='$target'";
			db_query($sql);
		}
		addnews("`&%s`0`& got a marriage proposal from %s`0`&, which %s`0`& rejected, seeing %s`0`& as '`@Unfit for Marriage.`&'",$session['user']['name'],$row['name'],$session['user']['name'],$row['name']);
		addnews("`&%s`0`& is currently moping around the inn.",$row['name']);
		$x = ($row['sex']?translate_inline("she's"):translate_inline("he's"));
		output("`@You say `3\"`&I don't want to marry %s`0`&.. %s.. not my type..`3\"",$vicar,$session['user']['name'],$x);
		if (get_module_setting('cansell')!=1) {
			output("`^%s `3takes the wedding ring from %s`0`& from you, and throws it into the Garderobe.",$vicar,$row['name']);
			output("`n`^%s `3grins, and says \"`&No second thoughts now.`3\"",$vicar);
		} else {
			output("`^%s `3takes the wedding ring from %s`0`& from you, and says `3\"`&Do you want to sell it back to me?`3\".",$vicar,$row['name']);
			addnav("Actions");
			addnav("Sell the Ring","runmodule.php?module=marriage&op=".$op."&op2=sellr&i=s&target=".$target);
			addnav("Keep the Ring as a Memento","runmodule.php?module=marriage&op=".$op."&op2=sellr&i=m&target=".$target);
		}
		break;
	case "sellr":
		$sql = "SELECT name,sex FROM ".db_prefix("accounts")." WHERE acctid='$target' AND locked=0";
		$res = db_query($sql);
		$row = db_fetch_assoc($res);
		if (httpget('i')=='s') {
			output("`^%s `3pockets the wedding ring from %s`0`& and gives you %s gold.",$vicar,$row['name'],get_module_setting('cost'));
			$session['user']['gold']+=get_module_setting('cost');
		} else {
			set_module_pref('buyring',1);
			output("`^%s `3gives you thr wedding ring from %s`0`& back, and ties it on a string around your neck.",$vicar,$row['name']);
		}
		break;
	case "divorce":
		require_once("./modules/marriage/divorce.php");
		output("`^%s `&nods..",$vicar);
		output("`n`^%s `3chants, \"`&Egairram siht dne ekactiurf taerg fo dog.`3\"",$vicar);
		output("`n`^%s `3chants, \"`&Aet rof snub yccohc ekil uoy dluow.`3\"",$vicar);
		output("`n`^%s `3bows solemnly, and a `^`bLightning Bolt`b`3 arches from the sky, hitting the ground before your feet..",$vicar);
		output("`n`@The Marriage is annulled!");
		marriage_divorce();
		break;
	default:
		if ($op=='oldchurch') {
			output("`n`@Going through a small door in the side of the Church, you enter a vast side-wing..");
			output("`nAs you enter, %s `@enters, and walks over to a somewhat shabby bench, sits down, and stares at you.",$vicar);
			output("`nExamining the floor, under %s's`@ beady eye, you see bits of old confetti.",$vicar);
			output("`n%s `3says, \"`&This is our Marriage chamber. What do you wish me to do?`3\"",$vicar);
			if (get_module_setting('flirttype')) output("`n`^%s `3reminds you, \"`&You must have been proposed to already.. maybe the Loveshack can help you out.`3\"",$vicar);
		} else {
			output("`@In the centre of town stands a small Chapel..");
			output("`nAs you enter, a Minister walks over and introduces %s as `^%s`@. %s then walks you over to a somewhat shabby bench, sits down, and invites you to sit.",$gendervicarpersonal,$vicar,$gendervicar);
			output("`n`^%s `3says, \"`&This is a Marriage chapel. What do you wish me to do?`3\"",$vicar);
			if (get_module_setting('flirttype')) output("`n`^%s `3reminds you, \"`&You must have been proposed to already.. maybe the Loveshack can help you out.`3\"",$vicar);
			}
		break;
	}
	addnav("Navigation");
	addnav("Return to the Gardens","gardens.php");
	addnav("Actions");
	addnav("Talk to Others","runmodule.php?module=marriage&op=".$op."&op2=talk");
	if ($session['user']['marriedto']==0) {
		if (get_module_setting('flirttype')==0) addnav("Propose","runmodule.php?module=marriage&op=".$op."&op2=propose");
		addnav("View Proposals","runmodule.php?module=marriage&op=".$op."&op2=proposelist");
	} else {
		addnav("Get a Divorce!","runmodule.php?module=marriage&op=".$op."&op2=divorce");
	}
	page_footer();
?>