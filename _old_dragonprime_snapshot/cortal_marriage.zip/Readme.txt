->Use the abigail ONLY with this version of the marriage. *NOT* with the old one as the functions have other names.

->Use marriageconvert if you want to convert the present flirtpoints if you upgrade vom cortalUX marriage 3.0 module (original)


Notes:
you have a hook "marriage-items" in the loveshack where you can hook in your own modules. if you want to know how you do that, review the marriagechocolates.php as it is using this.

If you want to have the flirtform in your module, require() the flirtform.php and call the form with the second argument as return path. 
You have then a full "plug-in" module that can be easily hooked into the marriage module.