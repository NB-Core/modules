<?
//version information in readme.txt

function marriage_getmoduleinfo(){
	require("modules/marriage/marriage_getinfo.php");
	return $info;
}

function marriage_install(){
	if (!is_module_active('marriage')){
		output_notl("`n`c`b`QMarriage Module - Installed`0`b`c");
	}else{
		output_notl("`n`c`b`QMarriage Module - Updated`0`b`c");
	}
	module_addhook("drinks-text");
	module_addhook("drinks-check");
	module_addhook("moderate");
	module_addhook("newday");
	module_addhook("changesetting");
	module_addhook_priority("footer-inn",1);
	module_addhook("village");
	//module_addhook("footer-runmodule"); //disabled, performance
	module_addhook("footer-oldchurch"); //better, will only work on lotgd 1.0.7 or higher
	module_addhook("footer-gardens");
	module_addhook("delete_character");
	module_addhook("charstats");
	module_addhook("faq-toc");
	module_addhook("biostat");
	if ($SCRIPT_NAME == "modules.php"){
		$module=httpget("module");
		if ($module == "marriage"){
			require_once("modules/marriage/lovedrinks.php");
			marriage_lovedrinks();
		}
	}
	return true;
}

function marriage_uninstall(){
	require_once("modules/marriage/lovedrinks.php");
	marriage_lovedrinksrem();
	output_notl("`n`c`b`QMarriage Module - Uninstalled`0`b`c");
	return true;
}

function marriage_dohook($hookname, $args){
	global $session;
	require("modules/marriage/marriage_dohook.php");
	return $args;
}

function marriage_run(){
	global $session;
	require_once("modules/marriage/marriage_func.php");
	$op = httpget('op');
	if ($op==''|| $op=='chapel' || $op=='oldchurch') 
		require("./modules/marriage/general.php");
		else
		require("./modules/marriage/$op.php");
}
?>