<?
if ($_GET['op']=="download"){ // this offers the module on every server for download
 $dl=join("",file("marriageconvert.php"));
 echo $dl;
}else{

function marriageconvert_getmoduleinfo(){
	$info = array(
		"name"=>"MarriageConvert",
		"version"=>"1.0",
		"author"=>"`2Oliver Brendel",
		"override_forced_nav"=>true,
		"category"=>"Marriage",
		"download"=>"/modules/marriageconvert.php?op=download",
		"settings"=>array(
			"MarriageConvert - General,title",
			"keep"=>"Keep the old prefs,bool|1",
			"Note: This will convert the flirtpoints into the new prefs but leave the old (swith back possible),note",
		),
		"requires"=>array(
			"marriage"=>"1.0|by `@`bCortalUX`b`2overhauled by Oliver Brendel",
		),

	);
	return $info;
}

function marriageconvert_install(){
	module_addhook("superuser");
	return true;
}

function marriageconvert_uninstall(){
	return true;
}

function marriageconvert_dohook($hookname, $args){
	global $session;
	switch($hookname){
		case "superuser":
			addnav("Editors");
			addnav("Convert old Flirtpoints","runmodule.php?module=marriageconvert");
		break;
	}
	return $args;
}

function marriageconvert_run(){
	global $session;
	require_once("./lib/superusernav.php");
	$op = httpget('op');
	page_header("Conversion of flirtpoints");
	superusernav();
	switch ($op) {
		case "commence":
			$sql="SELECT acctid FROM ".db_prefix("accounts");
			$result=db_query($sql);
			$keep=get_module_setting('keep');
			while ($currentuser=db_fetch_assoc($result)) {
				$mysentpoints = get_module_pref('flirtsrec','marriage',$currentuser['acctid']);
				$mysentpoints = explode(',',$mysentpoints);
				foreach ($mysentpoints as $val) {
					if ($val!='') {
						$stf = explode('|',$val);
						if ($stf[1]) {
							marriage_modifyflirtpoints($currentuser['acctid'],$stf[1],$stf[0]); //using a modified version below
						}
					if (!$keep) {
						set_module_pref('flirtssen','','marriage',$currentuser['acctid']);
						set_module_pref('flirtsrec','','marriage',$currentuser['acctid']);
						}
					}
				}
			}
			output("Operation complete.");
			break;
		default:
		output("Do you really want to convert the flirtpoints? Hit the Navigation to commence the progress.");
		output_notl("`n`n");
		if (get_module_setting('keep')) {
			output("Old flirtpoints will be kept!");
		} else {
			output("Old flirtpoints won't be kept!");
		}
		output_notl("`n`n");
		output("`b`\$There is no further warning!`b");
		addnav("Commence");
		addnav("Commence the Conversion","runmodule.php?module=marriageconvert&op=commence");
	}
	page_footer();
}

function marriage_modifyflirtpoints($who=1,$amount=0,$from=-1) {
	global $session;
	//now update the sent
	if ($from==-1) $from=$session['user']['acctid'];
	$list=get_module_pref('flirtssent','marriage',$from);
	$list=unserialize($list);
	if ($list=="") $list=array();
	if (array_key_exists("S".$who,$list)) {
		$list["S".$who]+=$amount; //even when negative
		} else {
		$list=array_merge(array("S".$who=>$amount),$list);
		}
	//if ($list["S".$who]<1) $list=array_splice($list,"S".$who,1); //clean up, not working
	set_module_pref('flirtssent',serialize($list),'marriage',$from);
	//now for the received ones
	$list=get_module_pref('flirtsreceived','marriage',$who);
	$list=unserialize($list);
	if ($list=="") $list=array();
	if (array_key_exists("S".$from,$list)) {
		$list["S".$from]+=$amount; //even when negative
		} else {
		$list=array_merge(array("S".$from=>$amount),$list);
		}
	set_module_pref('flirtsreceived',serialize($list),'marriage',$who);
}
}
?>