<?php
//2.0 Dog wants bones every once in a while.
//2.5 Dog runs away sometimes.
//2.51 fixed negative purchase cheat.
function poveas_getmoduleinfo(){
	$info = array(
	"name"=>"Poveas's Pheasant Hunt",
	"version"=>"3.0",
	"author"=>"Reznarth <br>`3Updates by Lonny Luberts",
	"category"=>"Forest",
	"download"=>"http://www.pqcomp.com/modules/mydownloads/visit.php?cid=3&lid=82",
	"vertxtloc"=>"http://www.pqcomp.com/",
	"settings"=>array(
	"Poveas Settings,title",
	"huntingturns"=>"Hunting turns per day,int|5",
	"dogcost"=>"How much does dog cost?,int|250",
	"bowcost"=>"How much does bow cost?,int|50",
	"arrowcost"=>"How much does arrow cost?,int|5",
	"bonecost"=>"How much does bone cost?,int|2",
	),
	"prefs"=>array(
	"Poveas User Preferences,title",
	"usedhuntingturns"=>"How many times did they hunt today?,int|0",
	"hasdog"=>"Do they own a dog?,bool|0",
	"hasbow"=>"Do they have a bow?,bool|0",
	"arrows"=>"How many arrows do they have?,int|0",
	"feedbone"=>"Needs to feed the dog a bone?,bool|0",
	),
	);
	return $info;
}
function poveas_install(){
	module_addhook("forest");
	module_addhook("newday");
	module_addhook("dragonkill");
	return true;
}

function poveas_uninstall(){
	return true;
}

function poveas_dohook($hookname,$args){
	global $session;
	switch($hookname){
		case "newday":
			if ($args['resurrection'] != 'true') {
				set_module_pref("usedhuntingturns",0);
			}
		break;
		case "dragonkill":
			set_module_pref("hasdog",0);
			set_module_pref("hasbow",0);
			set_module_pref("arrows",0);
			set_module_pref("feedbone",0);
		break;
		case "forest":
			addnav("Poveas's Pheasant Hunt","runmodule.php?module=poveas&op=enter");
		break;
	}
	return $args;
}

function poveas_run(){
	global $SCRIPT_NAME;
	if ($SCRIPT_NAME == "runmodule.php"){
		$module=httpget("module");
		if ($module == "poveas"){
			include("modules/lib/poveas.php");
		}
	}
}
?>