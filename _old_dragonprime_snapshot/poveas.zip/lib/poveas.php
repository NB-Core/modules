<?php
global $session;
$op = httpget('op');
$dogcost = get_module_setting("dogcost");
$bowcost = get_module_setting("bowcost");
$bonecost = get_module_setting("bonecost");
$arrowcost = get_module_setting("arrowcost");
$arrows = get_module_setting("arrows");
$huntingturns = get_module_setting("huntingturns");
page_header("Poveas's Pheasant Hunt");

if ($op == "enter"){ 

if (get_module_pref("feedbone")==1){
output("Your dog wants a bone and Poveas just happens to have some dog bones for sale.`n They only cost %s gold.",$bonecost);
addnav("Buy a bone - $bonecost gold","runmodule.php?module=poveas&op=bone");
}
else{

if (get_module_pref("usedhuntingturns")<get_module_setting("huntingturns")){
output("Poveas will let you hunt on her lands for free, but you need a few things.`n`n");
output("First you have to have a hunting dog to bring back the birds you kill. `n`n");
output("After you have a dog you can purchase a bow, without the bow you can't hunt.`n`n");
output("After you have a bow you can purchase arrows, without arrows you can't hunt.`n`n");
output("After you have a dog, a bow and arrows you may hunt %s times per new day.`n`n",$huntingturns);
output("`n`bYour Hunting Status:`b`n`n");

if (get_module_pref("hasdog")==0){
output("You need a hunting dog`n`n");
}
else{
output("You have a hunting dog.`n`n");
}

if (get_module_pref("hasbow")==0){
output("You need a hunting bow.`n`n");
}
else{
output("You have a hunting bow.`n`n");
}

if (get_module_pref("arrows")==0){
output("You need some hunting arrows.`n`n");
}
else{
output("You have some hunting arrows.`n`n");
}

if (get_module_pref("hasdog")==0) addnav("Buy hunting dog - $dogcost gold","runmodule.php?module=poveas&op=dog");
if ((get_module_pref("hasbow")==0) && (get_module_pref("hasdog")==1)) addnav("Buy hunting bow - $bowcost gold","runmodule.php?module=poveas&op=bow");
if ((get_module_pref("hasdog")==1) && (get_module_pref("hasbow")==1) && (get_module_pref("arrows")>=1)) addnav("Let's go hunting","runmodule.php?module=poveas&op=hunt");
if ((get_module_pref("hasbow")==1)&& (get_module_pref("arrows")==0)) addnav("Buy arrows - $arrowcost gold","runmodule.php?module=poveas&op=arrow");
}
else{
output("Your are out of hunting turns for today.");
}
}
}

if ($op == "continue"){ 

if (get_module_pref("feedbone")==1){
output("Poveas just happens to have some dog bones for sale, would you like to buy a bone?`n They only cost %s gold.",$bonecost);
addnav("Buy a bone - $bonecost gold","runmodule.php?module=poveas&op=bone");
}
else{

if (get_module_pref("usedhuntingturns")<get_module_setting("huntingturns")){
if (get_module_pref("hasbow")==0) output("After you have a dog you can purchase a bow, without the bow you can't hunt.`n`n");
if ((get_module_pref("arrows")==0) && (get_module_pref("hasbow")==1))output("You have to purchase arrows, without arrows you can't hunt.`n`n");
if ((get_module_pref("hasdog")==1) && (get_module_pref("hasbow")==1) && (get_module_pref("arrows")>=1)) output("Good Luck Hunting!!`n`n");
if ((get_module_pref("hasbow")==0) && (get_module_pref("hasdog")==1)) addnav("Buy hunting bow - $bowcost gold","runmodule.php?module=poveas&op=bow");
if ((get_module_pref("hasdog")==1) && (get_module_pref("hasbow")==1) && (get_module_pref("arrows")>=1)) addnav("Let's go hunting","runmodule.php?module=poveas&op=hunt");
if ((get_module_pref("hasbow")==1)&& (get_module_pref("arrows")==0)) addnav("Buy arrows - $arrowcost gold","runmodule.php?module=poveas&op=arrow");
}
else{
output("Your are out of hunting turns for today.");
}
}
}

if ($op == "huntagain"){ 

if (get_module_pref("feedbone")==1){
output("Poveas just happens to have some dog bones for sale, would you like to buy a bone?`n They only cost %s gold.",$bonecost);
addnav("Buy a bone - $bonecost gold","runmodule.php?module=poveas&op=bone");
}
else{

if (get_module_pref("usedhuntingturns")<get_module_setting("huntingturns")){

if ((get_module_pref("hasdog")==1) && (get_module_pref("hasbow")==1) && (get_module_pref("arrows")>=1)){
output("Good Luck Hunting!!`n`n");
}
else{
if (get_module_pref("hasdog")==0) output("You need a hunting dog.");
if (get_module_pref("arrows")==0) output("You need arrows to hunt.");
}
if ((get_module_pref("hasdog")==1) && (get_module_pref("hasbow")==1) && (get_module_pref("arrows")>=1)) addnav("Let's go hunting","runmodule.php?module=poveas&op=hunt");
if (get_module_pref("hasdog")==0) addnav("Buy hunting dog - $dogcost gold","runmodule.php?module=poveas&op=dog");
if ((get_module_pref("hasbow")==1)&& (get_module_pref("arrows")==0)) addnav("Buy arrows - $arrowcost gold","runmodule.php?module=poveas&op=arrow");
}
else{
output("Your are out of hunting turns for today.");
}
}
}

if ($op == "dog"){ 
if($session['user']['gold'] >= $dogcost){
output("You are now the happy owner of a great hunting dog. `nPoveas thanks you for your business and ask's you to take good care of the dog.");
set_module_pref("hasdog",1);
$session['user']['gold'] -= $dogcost;
addnav("Continue","runmodule.php?module=poveas&op=continue");
}else{
output("You need more gold."); 
}
}

if ($op == "bow"){ 
if($session['user']['gold'] >= $bowcost){
output("You hold your new hunting bow in your hands and you feel like you could shoot anything that moves.");
set_module_pref("hasbow",1);
$session['user']['gold'] -= $bowcost;
addnav("Continue","runmodule.php?module=poveas&op=continue");
}else{
output("You need more gold.");
}
}

if ($op == "arrow"){ 
addnav("Continue","runmodule.php?module=poveas&op=continue");
output("`%How many arrows would you like to buy?`n");
output("<form action='runmodule.php?module=poveas&op=arrowbuy2' method='POST'><input name='buy' id='buy'><input type='submit' class='button' 
value='buy'></form>",true);
addnav("","runmodule.php?module=poveas&op=arrowbuy2");
}

if ($op == "arrowbuy2"){
addnav("Continue","runmodule.php?module=poveas&op=continue");
$buy = httppost('buy');
if ($buy < 1){
	output("`4What are you trying to do?  Cheat?");
}else{
if ($session['user']['gold'] < ($buy * $arrowcost)) {output("Poveas can't give her arrows away for free.`n`n"); }
else{
$cost=($buy * $arrowcost);
$session['user']['gold']-=$cost;
set_module_pref("arrows",get_module_pref("arrows")+$buy);
output("Poveas takes your %s gold",$cost);
output(" and hands you %s arrows.",$buy);
}
}
}

if ($op == "bone"){ 
if($session['user']['gold'] >= $bonecost){
output("You have made your dog very happy, he is ready to hunt again.");
set_module_pref("feedbone",0);
$session['user']['gold'] -= $bonecost;
addnav("Continue","runmodule.php?module=poveas&op=continue");
}else{
output("You need more gold."); 
}
}

if ($op == "hunt"){ 
addnav("Continue","runmodule.php?module=poveas&op=huntagain");
if (get_module_pref("arrows")>=1) {
output("You shoot your arrow.....`n`n");
$huntresults = e_rand(1,200);   

if ($huntresults >= 1 && $huntresults <= 25) {
$session['user']['gold']+=10;
output("..... and hit a pheasant. Your dog runs out to retrieve it. He brings back an old purse, there's 10 gold in it.`n");
}

if ($huntresults >= 26 && $huntresults <= 50) {
set_module_pref("feedbone",1);
output("..... and your dog doesn't move. He wants a dog bone. If you don't get him one he will not hunt anymore.`n");
}

if ($huntresults >= 51 && $huntresults <= 75) {
output("..... and hit a pheasant. Your dog runs out to retrieve it. He brings back a dead bird!`n");
}

if ($huntresults >= 76 && $huntresults <= 99) {
output("..... and miss a pheasant. Your dog runs out to retrieve nothing. He comes back and pee's on your leg.`n");
}

if ($huntresults == 100) {
$total=$session['user']['level'] * 5;
$session['user']['gold']+=$total;
output("..... and hit a pheasant. Your dog runs out to retrieve it.  He brings back a large sack with %s gold in it.`n",$total);
}

if ($huntresults >= 101 && $huntresults <= 109) {
$session['user']['charm']--;
output("..... and miss a pheasant. Your dog runs out to retrieve nothing. He comes back and bites your face, you lose a charm point.`n");
}

if ($huntresults == 110) {
$total=$session['user']['level'] * 5;
$session['user']['experience']+=$total;
output("..... and hit a pheasant. Your dog runs out to retrieve it.  He brings back a dead bird in perfect shape for cooking, you gain %s experience for having a good hunting trip.`n",$total);
}


if ($huntresults >= 111 && $huntresults <= 129) {
$session['user']['turns']--;
output("..... and miss a pheasant. Your dog runs out to retrieve it. He comes back and takes a dump at your feet. The sight of the crap makes you sick, you lose a forest fight.`n");
}

if ($huntresults == 130) {
$total=$session['user']['level'] * 2;
$session['user']['deathpower']+=$total;
output("..... and hit a pheasant. Your dog runs out to retrieve it. He brings back a mug of magical ale. You drink it and gain %s favor with Ramius.`n",$total);
}

if ($huntresults >= 131 && $huntresults <= 139) {
$session['user']['gold']+=2;
output("..... and hit a pheasant. Your dog runs out to retrieve it. He brings back a dead bird. After examining the bird, you find a couple of gold coins tucked away in it's feathers.`n");
}

if ($huntresults == 140) {
$total=$session['user']['level'] * 5;
$session['user']['experience']-=$total;
output("..... and miss a pheasant. Your dog runs out to retrieve it.  He comes back and knocks you down in the mud. You lose %s experience points from the bad ordeal.`n",$total);
}

if ($huntresults >= 141 && $huntresults <= 149) {
$session['user']['turns']++;
output("..... and hit a pheasant. Your dog runs out to retrieve it.  He brings back a nice ripe pear, you eat it and gain a forest fight.`n");
}

if ($huntresults == 150) {
$session['user']['maxhitpoints']++;
output("..... and hit a pheasant. Your dog runs out to retrieve it.  He brings back a vial of liquid, you drink it and gain a permanent hit point.`n");
}

if ($huntresults >= 151 && $huntresults <= 159) {
$session['user']['hitpoints'] = $session['user']['maxhitpoints'];
output("..... and hit a pheasant. Your dog runs out to retrieve it. He comes back with a cooked t-bone steak, you eat it and are fully healed.`n");
}

if ($huntresults == 160) {
$session['user']['maxhitpoints']--;
output("..... and hit a pheasant. Your dog runs out to retrieve it.  He brings back a vial of liquid, you drink it and lose a permanent hit point.`n");
}

if ($huntresults >= 161 && $huntresults <= 169) {
$session['user']['gold']+=5;
output("..... and hit a pheasant. Your dog runs out to retrieve it. He comes back with a golden egg worth 5 gold.`n");
}

if ($huntresults == 170) {
$session['user']['attack']++;
output("..... and hit a pheasant. Your dog runs out to retrieve it.  He brings back a vial of liquid, you drink it and gain extra attack power.`n");
}

if ($huntresults >= 171 && $huntresults <= 179) {
$session['user']['hitpoints']+=10;
output("..... and hit a pheasant. Your dog runs out to retrieve it. He comes back with a strawberry, you eat and gain some hit points.`n");
}

if ($huntresults == 180) {
$session['user']['defence']++;
output("..... and hit a pheasant. Your dog runs out to retrieve it.  He brings back a vial of liquid, you drink it and gain extra defense power.`n");
}

if ($huntresults >= 181 && $huntresults <= 185) {
output("..... and miss a pheasant. Your dog runs out to retrieve nothing. He comes back with a stick.`n");
}

if ($huntresults >= 186 && $huntresults <= 189) {
output("..... and miss a pheasant. Your dog runs out to retrieve nothing. `n`n`bHe never comes back, you have to get a new dog.`b`n");
set_module_pref("hasdog",0);
}

if ($huntresults == 190) {
$session['user']['gems']++;
output("..... and hit a pheasant. Your dog runs out to retrieve it.  He brings back a sack, there is a GEM inside!!`n");
}

if ($huntresults >= 191 && $huntresults <= 199) {
if($session['user']['hitpoints']>=11){
$session['user']['hitpoints']-=10;
}
else
{
$session['user']['hitpoints']=1;
}
output("..... and miss a pheasant. Your dog runs out to retrieve nothing. He comes back and bites you, you lose some hit points.`n");
}

if ($huntresults == 200) {
$session['user']['gems']+=2;
output("..... and hit a pheasant. Your dog runs out to retrieve it.  He brings back a sack, there's  TWO GEMS inside!!`n");
addnews($session['user']['name']." found two gems while hunting for pheasants.");

}

set_module_pref("arrows",get_module_pref("arrows")-1);
set_module_pref("usedhuntingturns",get_module_pref("usedhuntingturns")+1);

}else{
output("You need arrows to hunt.");
}
}
addnav("Return to the forest","forest.php"); 
page_footer();
?>