<?php
/*
Module Name:  White Screen of Death
Category:  Forest Specials
Worktitle:  whitesod
Date:  November 17, 2005
Author:  DaveS

Description:
We've been running into an evil beast on the server I play... occassionally you'll get a white screen and lose a forest
fight. 

Now it's here in Monster form!!!

*/

function whitesod_getmoduleinfo(){
	$info = array(
		"name"=>"White Screen of Death",
		"version"=>"3.0",
		"author"=>"DaveS",
		"category"=>"Forest Specials",
		"download"=>"http://dragonprime.net/index.php?module=Downloads;sa=dlview;id=186",
		"vertxtloc"=>"",
		"settings"=>array(
			"forestf"=>"one in x chance to lose a turn during the attack:,int|8",
			"levellimit"=>"What level must player be before encountering the WSoD?,int|5",
		),
		"prefs"=>array(
			"White Screen of Death - Preferences,title",
			"whitescreen"=>"Seen the White Screen today?,bool|0",
		),
	);
	return $info;
}
function whitesod_chance() {
	global $session;
	if (get_module_pref('whitescreen','whitesod',$session['user']['acctid'])==1|| $session['user']['level']<=get_module_setting('levellimit','whitesod',$session['user']['acctid'])) return 0;
	return 100;
}
function whitesod_install(){
	module_addeventhook("forest","require_once(\"modules/whitesod.php\"); 
	return whitesod_chance();");
	module_addhook("newday");
	return true;
}
function whitesod_uninstall(){
	return true;
}
function whitesod_dohook($hookname,$args){
	global $session;
	switch ($hookname) {
		case "newday":
			set_module_pref("whitescreen",0);
		break;
	}
	return $args;
}
function whitesod_runevent($type) {
	global $session;
	$session['user']['specialinc']="module:whitesod";
	$op = httpget('op');
if ($op==""){
	output("`n`n`c`&Oh No! You've encountered the `bDreaded White Beast of LogD`b!`c");
	set_module_pref("whitescreen",1);
	addnav("`\$Fight the `&WSoD`\$!","forest.php?op=attack");
}
if ($op=="attack") {
	$rand=e_rand(95,104)/100;
	$level = $session['user']['level']-1;
	if ($level<=0) $level=1;
	$badguy = array(
		"creaturename"=>"`&`bWhite Screen of Death`b",
		"creaturelevel"=>$level,
		"creatureweapon"=>"a `&blank stare",
		"creatureattack"=>$session['user']['attack'],
		"creaturedefense"=>round($session['user']['defense']*0.9),
		"creaturehealth"=>round($session['user']['maxhitpoints']*$rand),
		"diddamage"=>0,
		"type"=>"spelingbee");
	$session['user']['badguy']=createstring($badguy);
	$op="fight";
}
if ($op=="fight"){
	$forestf=get_module_setting("forestf");
	$randnumb=e_rand(1,$forestf);
	blocknav("runmodule.php?module=strigoitower&op=fight&auto=five");
	blocknav("runmodule.php?module=strigoitower&op=fight&auto=ten");
	blocknav("runmodule.php?module=strigoitower&op=fight&auto=full");
	if ($session['user']['turns']>5 && $randnumb==get_module_setting("forestf")){
		output("`n`c`&Oh no!! You are stuck and the `bWSoD`b takes a `@turn`& from you!`c`n");
		$session['user']['turns']--;
	}else{
		output("`n`c`&The `bWSoD`b tries to steal a turn from you but fails!`c`n");
	}
	$battle=true;
}
if ($battle){       
	include("battle.php");  
	if ($victory){
		$session['user']['specialinc'] = "";
		$expbonus=$session['user']['dragonkills']*4;
		$expgain =($session['user']['level']*44+$expbonus);
		$session['user']['experience']+=$expgain;
		output("`n`&You have finished off the `bWhite Screen of Death`b!  All Rejoice!`n`n You turn to walk away when you 
			see a bit of white creep off.  I have a feeling it will be back.`n`n");
		output("`&You gain `#%s `&experience.`n",$expgain);
		$session['user']['gold']+=250;
		$session['user']['turns']++;
		output("`&You gain `^250 `&gold and an extra `@turn`&.`n`n");
		addnews("%s`& erased the `bWhite Screen of Death`b!",$session['user']['name']);
	}elseif($defeat){
		$session['user']['specialinc'] = "";
		require_once("lib/taunt.php");
		$taunt = select_taunt_array();
		$exploss = round($session['user']['experience']*.1);
		output("`n`n`&You have been erased from life.  All your gold goes with you.`n");
		output(" You lose `^%s `&experience.`n",$exploss);
		output("`n`c`bYou may begin fighting again tomorrow.`c`b");
		addnav("Daily news","news.php");
		$session['user']['experience']-=$exploss;
		$session['user']['alive'] = false;
		$session['user']['hitpoints'] = 0;
		$session['user']['gold']=0;
		addnews("%s `&disappeared behind a `bWhite Screen of Death`b.`n%s",$session['user']['name'],$taunt);
	}else{
		fightnav(true,true);
	}
} 
}
?>