<?php
require_once("common.php");
require_once("lib/http.php");

function restoresoul_getmoduleinfo(){
    $info = array(
        "name"=>"Restore Soul from Graveyard",
        "version"=>"1.0",
        "author"=>"SexyCook",
        "category"=>"Shades",
        "download"=>"",
        );
    return $info;

}
    
function restoresoul_install(){
  	module_addhook("footer-graveyard");
    return true;
    }
    
function restoresoul_uninstall(){
    return true;
    }

function restoresoul_dohook($hookname,$args){
		global $session;
		$max = $session['user']['level'] * 5 + 50;
    $favortoheal = round(10 * ($max-$session['user']['soulpoints'])/$max);

	$op = httpget("op");
	$act = httpget("act");

  	if($op == "" && $act != "attack" && $favortoheal>0){
	     switch($hookname){
		      case "footer-graveyard":
			       addnav("Ramius");
        		 addnav(array("Restore Your Soul (%s favor)", $favortoheal),"runmodule.php?module=restoresoul&op=restore");
  		    break;
  	   }
  	}
	return $args;
}  	
  	
function restoresoul_run(){
    global $session;
		$max = $session['user']['level'] * 5 + 50;
    $favortoheal = round(10 * ($max-$session['user']['soulpoints'])/$max);

    page_header("The Graveyard");
    switch (httpget("op")) {
        case "restore":

        	output("`)`b`cThe Graveyard`c`b");
        	if ($session['user']['soulpoints']<$max){
        	   if ($session['user']['deathpower']>=$favortoheal){
        	   output("`\$Ramius`) calls you weak for needing restoration, but as you have enough favor with him, he grants your request at the cost of `4%s`) favor.", $favortoheal);
            	$session['user']['deathpower']-=$favortoheal;
            	$session['user']['soulpoints']=$max;
            	}else{
        	      output("`\$Ramius`) curses you and throws you from the Mausoleum, you must gain more favor with him before he will grant restoration.");
            	}
        	}else{
        	   output("`\$Ramius`) sighs and mumbles something about, \"`7just 'cause they're dead, does that mean they don't have to think?`)\"`n`n");
        	   output("Perhaps you'd like to actually `ineed`i restoration before you ask for it.");
        	}

          if ($session['user']['gravefights']) {
          		addnav("Look for Something to Torment","graveyard.php?op=search");
	        }
          addnav("Places");
          addnav("W?List Warriors","list.php");
          addnav("S?Return to the Shades","shades.php");
          addnav("M?Enter the Mausoleum","graveyard.php?op=enter");

		      page_footer();
    }
}    
?>
