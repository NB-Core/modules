<?php

require_once("common.php");
require_once("lib/http.php");
require_once("lib/commentary.php");

function streets_getmoduleinfo(){
		$info = array(
				"name"=>"Streets",
				"author"=>"`b`@Radioactivebloke`b",
				"version"=>"1.0",
				"category"=>"Village",
				"download"=>"",
				"description"=>"A street add-on to reduce the crowding in the village.",
				"settings"=>array(
						"Text for Main Street,title",
						"msa1"=>"Main Street Addnav 1 Text,text|",
						"msa2"=>"Main Street Addnav 2 Text,text|",
						"msa3"=>"Main Street Addnav 3 Text,text|",
						"msa4"=>"Main Street Addnav 4 Text,text|",
						"msa5"=>"Main Street Addnav 5 Text,text|",
						"msa6"=>"Main Street Addnav 6 Text,text|",
						"msa7"=>"Main Street Addnav 7 Text,text|",
						"msa8"=>"Main Street Addnav 8 Text,text|",
						"msa9"=>"Main Street Addnav 9 Text,text|",
						"msa10"=>"Main Street Addnav 10 Text,text|",
														
						"Links for Main Street,title",
						"msl1"=>"Main Street Addnav 1 Link,text|",
						"msl2"=>"Main Street Addnav 2 Link,text|",
						"msl3"=>"Main Street Addnav 3 Link,text|",
						"msl4"=>"Main Street Addnav 4 Link,text|",
						"msl5"=>"Main Street Addnav 5 Link,text|",
						"msl6"=>"Main Street Addnav 6 Link,text|",
						"msl7"=>"Main Street Addnav 7 Link,text|",
						"msl8"=>"Main Street Addnav 8 Link,text|",
						"msl9"=>"Main Street Addnav 9 Link,text|",
						"msl10"=>"Main Street Addnav 10 Link,text|",
						#####
						"Text for Blades Boulevard,title",
						"bba1"=>"Blades Boulevard Addnav 1 Text,text|",
						"bba2"=>"Blades Boulevard Addnav 2 Text,text|",
						"bba3"=>"Blades Boulevard Addnav 3 Text,text|",
						"bba4"=>"Blades Boulevard Addnav 4 Text,text|",
						"bba5"=>"Blades Boulevard Addnav 5 Text,text|",
						"bba6"=>"Blades Boulevard Addnav 6 Text,text|",
						"bba7"=>"Blades Boulevard Addnav 7 Text,text|",
						"bba8"=>"Blades Boulevard Addnav 8 Text,text|",
						"bba9"=>"Blades Boulevard Addnav 9 Text,text|",
						"bba10"=>"Blades Boulevard Addnav 10 Text,text|",
														
						"Links for Blades Boulevard,title",
						"bbl1"=>"Blades Boulevard Addnav 1 Link,text|",
						"bbl2"=>"Blades Boulevard Addnav 2 Link,text|",
						"bbl3"=>"Blades Boulevard Addnav 3 Link,text|",
						"bbl4"=>"Blades Boulevard Addnav 4 Link,text|",
						"bbl5"=>"Blades Boulevard Addnav 5 Link,text|",
						"bbl6"=>"Blades Boulevard Addnav 6 Link,text|",
						"bbl7"=>"Blades Boulevard Addnav 7 Link,text|",
						"bbl8"=>"Blades Boulevard Addnav 8 Link,text|",
						"bbl9"=>"Blades Boulevard Addnav 9 Link,text|",
						"bbl10"=>"Blades Boulevard Addnav 10 Link,text|",
						#####
						"Text for Market Street,title",
						"ma1"=>"Market Street Addnav 1 Text,text|",
						"ma2"=>"Market Street Addnav 2 Text,text|",
						"ma3"=>"Market Street Addnav 3 Text,text|",
						"ma4"=>"Market Street Addnav 4 Text,text|",
						"ma5"=>"Market Street Addnav 5 Text,text|",
						"ma6"=>"Market Street Addnav 6 Text,text|",
						"ma7"=>"Market Street Addnav 7 Text,text|",
						"ma8"=>"Market Street Addnav 8 Text,text|",
						"ma9"=>"Market Street Addnav 9 Text,text|",
						"ma10"=>"Market Street Addnav 10 Text,text|",
															
						"Links for Market Street,title",
						"ml1"=>"Market Street Addnav 1 Link,text|",
						"ml2"=>"Market Street Addnav 2 Link,text|",
						"ml3"=>"Market Street Addnav 3 Link,text|",
						"ml4"=>"Market Street Addnav 4 Link,text|",
						"ml5"=>"Market Street Addnav 5 Link,text|",
						"ml6"=>"Market Street Addnav 6 Link,text|",
						"ml7"=>"Market Street Addnav 7 Link,text|",
						"ml8"=>"Market Street Addnav 8 Link,text|",
						"ml9"=>"Market Street Addnav 9 Link,text|",
						"ml10"=>"Market Street Addnav 10 Link,text|",
						#####
						"Text for Tavern Street,title",
						"ta1"=>"Tavern Street Addnav 1 Text,text|",
						"ta2"=>"Tavern Street Addnav 2 Text,text|",
						"ta3"=>"Tavern Street Addnav 3 Text,text|",
						"ta4"=>"Tavern Street Addnav 4 Text,text|",
						"ta5"=>"Tavern Street Addnav 5 Text,text|",
						"ta6"=>"Tavern Street Addnav 6 Text,text|",
						"ta7"=>"Tavern Street Addnav 7 Text,text|",
						"ta8"=>"Tavern Street Addnav 8 Text,text|",
						"ta9"=>"Tavern Street Addnav 9 Text,text|",
						"ta10"=>"Tavern Street Addnav 10 Text,text|",
														
						"Links for Tavern Street,title",
						"tl1"=>"Tavern Street Addnav 1 Link,text|",
						"tl2"=>"Tavern Street Addnav 2 Link,text|",
						"tl3"=>"Tavern Street Addnav 3 Link,text|",
						"tl4"=>"Tavern Street Addnav 4 Link,text|",
						"tl5"=>"Tavern Street Addnav 5 Link,text|",
						"tl6"=>"Tavern Street Addnav 6 Link,text|",
						"tl7"=>"Tavern Street Addnav 7 Link,text|",
						"tl8"=>"Tavern Street Addnav 8 Link,text|",
						"tl9"=>"Tavern Street Addnav 9 Link,text|",
						"tl10"=>"Tavern Street Addnav 10 Link,text|",
														
						"Text for Info Alley,title",
						"ia1"=>"Info Alley Addnav 1 Text,text|",
						"ia2"=>"Info Alley Addnav 2 Text,text|",
						"ia3"=>"Info Alley Addnav 3 Text,text|",
						"ia4"=>"Info Alley Addnav 4 Text,text|",
						"ia5"=>"Info Alley Addnav 5 Text,text|",
						"ia6"=>"Info Alley Addnav 6 Text,text|",
						"ia7"=>"Info Alley Addnav 7 Text,text|",
						"ia8"=>"Info Alley Addnav 8 Text,text|",
						"ia9"=>"Info Alley Addnav 9 Text,text|",
						"ia10"=>"Info Alley Addnav 10 Text,text|",
													
						"Links for Info Alley ,title",
						"il1"=>"Info Alley Addnav 1 Link,text|",
						"il2"=>"Info Alley Addnav 2 Link,text|",
						"il3"=>"Info Alley Addnav 3 Link,text|",
						"il4"=>"Info Alley Addnav 4 Link,text|",
						"il5"=>"Info Alley Addnav 5 Link,text|",
						"il6"=>"Info Alley Addnav 6 Link,text|",
						"il7"=>"Info Alley Addnav 7 Link,text|",
						"il8"=>"Info Alley Addnav 8 Link,text|",
						"il9"=>"Info Alley Addnav 9 Link,text|",
						"il10"=>"Info Alley Addnav 10 Link,text|",
				),
		);
		return $info;
}

function streets_install(){
		module_addhook("header-village");
		module_addhook("superuser");
		return true;
}

function streets_uninstall(){
		return true;
}
		
function streets_dohook($hookname, $args){
		global $session;
		switch($hookname){
				case "header-village":
						for ($i = 1; $i <= 40; $i++) {
								switch($i){
										case ($i<=10):
												$c = $i;
												$abrv = "bb";
												$name = "Blades Boulevard";
										break;
										case ($i<=20):
												$c = $i - 10;
												$abrv = "m";
												$name = "Market Street";
										break;
										case ($i<=30):
												$c = $i - 20;
												$abrv = "t";
												$name = "Tavern Street";
										break;
										case ($i<=40):
												$c = $i - 30;
												$abrv = "i";
												$name = "Info Alley";
										break;
								}
								if(get_module_setting($abrv."a".$c)!=null) blocknav(get_module_setting($abrv."l".$c));
						}
						$texts = array(
								"fightnav"=>"Blades Boulevard",
								"marketnav"=>"Market Street",
								"tavernnav"=>"Tavern Street",
								"infonav"=>"Info Alley",
						);
						addnav("City Gates");
						
						addnav("Main Street");
						for($i = 1; $i <= 10; $i++){
								if(get_module_setting("msa".$i)!=null) addnav(get_module_setting("msa".$i),"runmodule.php?module=streets&op=redir&url=".get_module_setting("msl".$i));
						}
						
						addnav("Avella Streets");
						addnav("`$`b".$texts['fightnav']."`b`0","runmodule.php?module=streets&op=strtbb");
						addnav("`@`b".$texts['marketnav']."`b`0","runmodule.php?module=streets&op=strtm");
						addnav("`^`b".$texts['tavernnav']."`b`0","runmodule.php?module=streets&op=strtt");
						addnav("`!`b".$texts['infonav']."`b`0","runmodule.php?module=streets&op=strti");
				break;
				case "superuser":
						if($session['user']['superuser'] & SU_EDIT_CONFIG){
								addnav("Mechanics");
								addnav("Street Configuration", "configuration.php?op=modulesettings&module=streets");
						}
				break;
		}
		return $args;
}

function streets_run(){
page_header("Avella Streets");

				$texts = array(
						"fightnav"=>"Blades Boulevard",
						"marketnav"=>"Market Street",
						"tavernnav"=>"Tavern Street",
						"infonav"=>"Info Alley",
				);
				$op = httpget('op');
				addcommentary();
		switch($op){
						case "redir":
								redirect(httpget('url'));
						break;
						case "strtbb":
										addnav("`$`b".$texts['fightnav']."`b`0");
										for($i = 1; $i <= 10; $i++){
														if(get_module_setting("bba".$i)!=null){
																		addnav(get_module_setting("bba".$i),get_module_setting("bbl".$i));
														}
										}
										commentdisplay("","streets","Speak",25,"says","streets");
						break;
						case "strtm":
										addnav("`@`b".$texts['marketnav']."`b`0");
										for($i = 1; $i <= 10; $i++){
														if(get_module_setting("ma".$i)!=null){
																		addnav(get_module_setting("ma".$i),get_module_setting("ml".$i));
														}
										}
										commentdisplay("","streets","Speak",25,"says","streets");
						break;
						case "strtt":
										addnav("`^`b".$texts['tavernnav']."`b`0");
										for($i = 1; $i <= 10; $i++){
														if(get_module_setting("ta".$i)!=null){
																		addnav(get_module_setting("ta".$i),get_module_setting("tl".$i));
														}		
										}
										commentdisplay("","streets","Speak",25,"says","streets");
						break;
						case "strti":
										addnav("`!`b".$texts['infonav']."`b`0");
										for($i = 1; $i <= 10; $i++){
														if(get_module_setting("ia".$i)!=null){
																		addnav(get_module_setting("ia".$i),get_module_setting("il".$i));
														}
										}
										commentdisplay("","streets","Speak",25,"says","streets");
						break;
		}
				addnav("Return");
				addnav("Return to the Village","village.php");
		page_footer();
}
?>
