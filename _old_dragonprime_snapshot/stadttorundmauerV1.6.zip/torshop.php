<?php
// Idee und Umsetzung
// Apollon, 2005
// gewidmet meiner geliebten Blume.
// ab Version 1.1 mit freundlicher Unterst�tzung, Mithilfe und Erg�nzung von BansheeElhayn
function torshop_getmoduleinfo(){
    $info = array(
        "name"=>"Der Torshop",
        "version"=>"1.4",
        "author"=>"Apollon und BansheeElhayn",
        "category"=>"Stadttor",
        "download"=>"http://dragonprime.net/users/BansheeElhayn/stadttor-1.0.X.zip",
		"requires"=>array(
			"stadttor"=>"1.6 by Apollon und BansheeElhayn",
		),
        "settings"=>array(
			"Torshop Einstellungen,title",
			"name"=>"Wie hei�t der H�ndler im Shop?,text|Luzius",
			"cost"=>"Mit wieviel Gold wird der Preis der g�ttlichen Buffs multipliziert?,int|500",
			"apollon"=>"Wieviel Tage wirkt Apollons Segen?,int|3",
			"athene"=>"Wieviel Tage wirkt Athenes Schild?,int|3",
			"morpheus"=>"Wieviel Tage wirkt Morpheus Schlafhauch?,int|3",
		),
	"prefs"=>array(
			"Torshop Pr�ferenzen,title",	
			"hatgekauft"=>"Wie oft hat der Spieler schon gekauft?,int|0",
			"wirkung"=>"Wie lange wirkt Apollons Segen noch?,int|0",
			"wirkung1"=>"Wie lange wirkt Athenes Schild noch?,int|0",
			"wirkung2"=>"Wie lange wirkt Morpheus Schlafhauch noch?,int|0",
			"apokauf"=>"Hat der Spieler noch Apollons Segen?,bool|0",
			"athkauf"=>"Hat der Spieler noch Athenes Schild?,bool|0",
			"morkauf"=>"Hat der Spieler noch Morpheus Hauch?,bool|0",
			),
    );
    return $info;
}

function torshop_install(){
		module_addhook("newday");
		module_addhook("stadttor");
		module_addhook("stadttor_beschreibung");
		return true;
}

function torshop_uninstall(){
	output("Das Torshopmodul Modul wird deinstalliert.");
	return true;
}

function torshop_dohook($hookname, $args){
	global $session;
	switch($hookname){
	case "newday":
		$wirkung=get_module_pref("wirkung");
		if ($wirkung>1) {
			$wirkung--;
			set_module_pref("wirkung",$wirkung);
			output("`n`1Apollons Kraft ist mit Dir!`n");
        		apply_buff('apollons',
		        	array(
        			"name"=>"`1Apollons Segen",
        			"rounds"=>50,
					"wearoff" => "Apolons Segen l�sst nach",
        			"atkmod"=>1.1,
					"badguydefmod" => "0.95",
        			"minioncount"=>1,
					"roundmsg" => "Apollon leitet Deine Hand und gibt Dir Kraft",
					"activate" => "offense",
        			"schema"=>"module-torshop",
        		));
		} elseif (get_module_pref("wirkung")==1) {
			set_module_pref("wirkung",0);
			set_module_pref("apokauf",0);
			output("`n`1Apollons Kraft hat Dich verlassen.`n");
		}
		$wirkung1=get_module_pref("wirkung1");
		if ($wirkung1>1) {
			$wirkung1--;
			set_module_pref("wirkung1",$wirkung1);
			output("`n`6Athenes Schild sch�tzt Dich!`n");
        		apply_buff('athenes',
		        	array(
        			"name"=>"`6Athenes Schild",
        			"rounds"=>50,
					"wearoff" => "Athenes Schild l�st sich auf",
        			"defmod"=>1.1,
					"badguyatkmod" => "0.95",
        			"minioncount"=>1,
					"roundmsg" => "Athenes Schild sch�tzt Dich",
					"activate" => "defense",
        			"schema"=>"module-torshop",
        			));
		} elseif (get_module_pref("wirkung1")==1) {
			set_module_pref("wirkung1",0);
			set_module_pref("athkauf",0);
			output("`n`6Athenes Schild l�st sich ganz auf.`n");
		}
		$wirkung2=get_module_pref("wirkung2");
		if ($wirkung2>1) {
			$wirkung2--;
			set_module_pref("wirkung2",$wirkung2);
			output("`n`4Der Hauch des Morpheus ist mit Dir!`n");
        		apply_buff('morpheuses',
		        	array(
        			"name"=>"`4Morpheus Schlafhauch",
        			"rounds"=>50,
					"wearoff" => "Die Wirkung des Schlafhauchs verblasst",
        			"defmod"=>1.1,
					"badguyatkmod" => "0.9",
					"badguydefmod" => "0.9",
        			"minioncount"=>1,
					"roundmsg" => "Morpheus schl�fert Deinen Gegner ein",
					"activate" => "offense,defense", 
        			"schema"=>"module-torshop",
        		));
		} elseif (get_module_pref("wirkung2")==1) {
			set_module_pref("wirkung2",0);
			set_module_pref("morkauf",0);
			output("`n`4Der Hauch des Morpheus verfliegt.`n");
		}
		set_module_pref("hatgekauft",0);
		break;
		
		case "stadttor":
		addnav("L�den");
		addnav("Torshop","runmodule.php?module=torshop");
		break;
		
		case "stadttor_beschreibung":
		output("`3%s, ein H�ndler, hat hier seinen Laden er�ffnet um Reisenden letztmalig vor dem Verlassen der Stadt die M�glichkeit zu geben sich mit seinen Zaubertr�nken einzudecken.`n",get_module_setting("name"));
		break;
		
	}
	return $args;
}

function torshop_run() {
	global $session;
	require_once("lib/http.php");
	$op=httpget('op');
	$cost = get_module_setting("cost");
	$buffcost = (($session['user']['dragonage']+10)*$cost);
	$apo = get_module_setting("apollon");
	$ath = get_module_setting("athene");
	$mor = get_module_setting("morpheus");
	$hak = get_module_setting("hatgekauft");
	$name = get_module_setting("name");
	require_once("lib/commentary.php");
	require_once("common.php");
	require_once("lib/villagenav.php");
		page_header("%s's Torshop",$name);
		if($op=="") {
		output("`c`4%s's Torshop`c`n",$name);
		output("`3 In einem der T�rme ist ein kleiner Laden untergebracht, der von au�en recht unscheinbar wirkt, im Inneren aber ger�umiger scheint, als Du zuerst dachtest.");
		output("`3 Es gibt nur ein kleines Fenster, das wenig Licht hereinl�sst und der Raum wird beleuchtet von Fakeln, die an den W�nden h�ngen.");
		output("`3 Hinter einem Tresen, im hinteren Raumteil, stehen Regale mit Amphoren in verschiedenen Gr��en und hinter dem Tresen steht ein kleiner, eher zwergenhafter Elf: %s, der Besitzer des Ladens.`n",$name);
		output("`3 %s l�chelt Dich verschmitzt an:`n`2\"Sei gegr��t Krieger, was kann ich Dir verkaufen?",$name);
		output("`2 Mein Angebot umfasst folgende Zaubertr�nke:\"");
		output("`n`n`1 Apollons Segen:`2 dieser Trank h�lt %s Tage und wirkt Wunder auf Deine Muskeln, er kostet nur`^ %s gold`n`n",$apo,$buffcost);
		output("`6 Athenes Schild:`2 dieser Trank h�lt %s Tage und wirkt Wunder auf Deine Abwehrkraft, er kostet nur`^ %s gold`n`n",$ath,$buffcost);
		output("`4 Morpheus Schlafhauch:`2 dieser Trank h�lt %s Tage und wirkt hart auf Deine Gegner, er kostet nur`^ %s gold`n`n",$mor,$buffcost);
		output("`%Herkules St�rketrunk:`2 Er gibt Dir mehr Ausdauer und es gibt ihn in 3 Varianten:`n`n");	
		output("`2Schwach: Er gibt Ausdauer f�r 1 zus�tzlichen Waldkampf -- `^4500 Gold`n`n");
		output("`2Mittel: Er gibt Ausdauer f�r 2 zus�tzliche Waldk�mpfe -- `^9000 Gold`n`n");
		output("`2Stark: Er gibt Ausdauer f�r 3 zus�tzliche Waldk�mpfe -- `^12500 Gold`n`n");
		output("`n`n`2Nun Krieger, was darf es sein?`");
		addnav("Trank w�hlen");
		addnav("`1Apollons Segen`0","runmodule.php?module=torshop&op=apseka");
		addnav("`6Athenes Schild`0","runmodule.php?module=torshop&op=atscka");
		addnav("`4Morpheus Schlafhauch`0","runmodule.php?module=torshop&op=moscka");
		addnav("`%Herkules St�rketrunk `2schwach`0","runmodule.php?module=torshop&op=hescka");
		addnav("`%Herkules St�rketrunk `2mittel`0","runmodule.php?module=torshop&op=hemika");
		addnav("`%Herkules St�rketrunk `2stark`0","runmodule.php?module=torshop&op=hestka");
		addnav("Zur�ck");
		addnav("`QZur�ck zum Stadttor`0","runmodule.php?module=stadttor");
		} 
		
	if($op=="apseka") {
		$x = translate_inline("Apollons Segen");
		$xk = $buffcost;
		$xd = $apo;
		$xs = "wirkung";
		$xds = "apokauf";
		$op = "wahl";
		}
	if($op=="atscka") {
		$x = translate_inline("Athenes Schild");
		$xk = $buffcost;
		$xd = $ath;
		$xs = "wirkung1";
		$xds = "athkauf";
		$op = "wahl";
		}
	if($op=="moscka") {
		$x = translate_inline("Morpheus Schlafhauch");
		$xk = $buffcost;
		$xd = $mor;
		$xs = "wirkung2";
		$xds = "morkauf";
		$op = "wahl";
		}
	if($op=="hescka") {
		$x = translate_inline("Herkules St�rketrunk `6schwach");
		$xk = 4500;
		$xd = translate_inline("Ausdauer fuer 1 zus�tzlichen Waldkampf");
		$xt = 1;
		$op = "wahl1";
		}
	if($op=="hemika") {
		$x = translate_inline("Herkules St�rketrunk `6mittel");
		$xk = 9000;
		$xd = translate_inline("Ausdauer fuer 2 zus�tzliche Waldk�mpfe");
		$xt = 2;
		$op = "wahl1";
		}
	if($op=="hestka") {
		$x = translate_inline("Herkules St�rketrunk `6stark");
		$xk = 12500;
		$xd = translate_inline("Ausdauer fuer 3 zus�tzliche Waldk�mpfe");
		$xt = 3;
		$op = "wahl1";
		}
		
	if($op=="wahl") {
		$hak = get_module_pref("hatgekauft");
		if ($hak>1) {
			output("`3%s schuettelt den Kopf:`2 Tut mir leid, Du hast heute schon zwei mal hier eingekauft!",$name);
			addnav("Zurueck","runmodule.php?module=torshop");
		}
	 	else{
			page_header("%s's Torshop - Auswahl",$name);
			output("`2 Gut Krieger, Du hast Dich also f�r folgendes entschieden:");
			output("`3 `6 %s`n",$x);
			output("`3 Wirkung:`\$  %s Tage`n",$xd);
			output("`3 Kosten:`^ %s Gold`n",$xk);
			output("`3 Ist das richtig?`n");
			addnav("Ja, genau das","runmodule.php?module=torshop&op=kauf&xk=$xk&xd=$xd&xs=$xs&xds=$xds");
			addnav("Nein, lieber was anderes","runmodule.php?module=torshop");
		}
	}
	
	if($op=="wahl1") {
		$hak = get_module_pref("hatgekauft");
		if ($hak>1) {
			output("`3%s sch�ttelt den Kopf:`2 Tut mir leid, Du hast heute schon zwei mal hier eingekauft!",$name);
			addnav("Zur�ck","runmodule.php?module=torshop");
		}
	 	else{
			page_header("%s's Torshop - Auswahl",$name);
			output("`2 Gut Krieger, Du hast Dich also f�r folgendes entschieden:");
			output("`3 `6 %s`n",$x);
			output("`3 Wirkung:`\$  %s`n",$xd);
			output("`3 Kosten:`^ %s Gold`n",$xk);
			output("`3 Ist das richtig?`n");
			addnav("Ja, genau das","runmodule.php?module=torshop&op=kauf1&xk=$xk&xt=$xt");
			addnav("Nein, lieber was anderes","runmodule.php?module=torshop");
		}
	}
	
	if($op=="kauf") {
		$xk = httpget('xk');
		$xd = httpget('xd');
		$xs = httpget('xs');
		$xds = httpget('xds');
		if ($session['user']['gold']<$xk) {
			output("`3%s sch�ttelt den Kopf:`2 Tja, da hast Du wohl zu wenig `^Gold `2dabei, ich hab hier nichts zu verschenken!",$name);
			addnav("Zur�ck","runmodule.php?module=torshop");
		}
		else{
			output("`3%s reibt sich die H�nde, nimmt Dein Gold und gibt Dir eine kleine Amphore.",$name);
			$session['user']['gold']-=$xk;
			set_module_pref("$xs",$xd);
			set_module_pref("$xds",1);
			set_module_pref("hatgekauft", get_module_pref("hatgekauft")+1);
			if ($xs=="wirkung") {
        			apply_buff('apollons',
		        		array(
        				"name"=>"`1Apollons Segen",
        				"rounds"=>50,
						"wearoff" => "Apolons Segen l�sst nach",
        				"atkmod"=>1.1,
						"badguydefmod" => "0.95",
        				"minioncount"=>1,
						"roundmsg" => "Apollon leitet Deine Hand und gibt Dir Kraft",
						"activate" => "offense",
        				"schema"=>"module-torshop",
        				));
			}
			elseif ($xs=="wirkung1") {
        			apply_buff('athenes',
		        		array(
        				"name"=>"`6Athenes Schild",
        				"rounds"=>50,
						"wearoff" => "Athenes Schild l�st sich auf",
        				"defmod"=>1.1,
						"badguyatkmod" => "0.95",
        				"minioncount"=>1,
						"roundmsg" => "Athenes Schild sch�tzt Dich",
						"activate" => "defense",
        				"schema"=>"module-torshop",
        				));
			}
			elseif ($xs=="wirkung2") {
        			apply_buff('morpheuses',
		        		array(
        				"name"=>"`4Morpheus Schlafhauch",
        				"rounds"=>50,
						"wearoff" => "Die Wirkung des Schlafhauchs verblasst",
        				"defmod"=>1.1,
						"badguyatkmod" => "0.9",
						"badguydefmod" => "0.9",
        				"minioncount"=>1,
						"roundmsg" => "Morpheus schl�fert Deinen Gegner ein",
						"activate" => "offense,defense",
        				"schema"=>"module-torshop",
        				));
			}
			addnav("Zur�ck","runmodule.php?module=torshop");
		}
	}
	
	if($op=="kauf1") {
		$xk = httpget('xk');
		$xt = httpget('xt');
		if ($session['user']['gold']<$xk) {
			output("`3%s sch�ttelt den Kopf:`2 Tja, da hast Du wohl zu wenig `^Gold `2dabei, ich habe hier nichts zu verschenken!",$name);
			addnav("Zur�ck","runmodule.php?module=torshop");
	 	}
	 	else{
			output("`3%s reibt sich die H�nde, nimmt Dein Gold und gibt Dir eine kleine Amphore.",$name);
			$session['user']['gold']-=$xk;
			$session['user']['turns']+=$xt;
			addnav("Zur�ck","runmodule.php?module=torshop");
		}
	}
	page_footer();
}
?>