<?php
// Idee und Umsetzung
// Apollon, 2005
// gewidmet meiner geliebten Blume.
// ab Version 1.1 mit freundlicher Unterst�tzung, Mithilfe und Erg�nzung von BansheeElhayn
function stadttor_getmoduleinfo(){
    $info = array(
        "name"=>"Das Stadttor",
        "version"=>"1.6",
        "author"=>"Apollon und BansheeElhayn",
        "category"=>"Stadttor",
        "download"=>"http://dragonprime.net/users/BansheeElhayn/stadttor-1.0.X.zip",
        "settings"=>array(
			"Stadttor Einstellungen,title",
			"ort"=>"Wo soll das Stadttor erscheinen?,location|".getsetting("villagename", LOCATION_FIELDS),
			"alle"=>"Stadttor f�r ALLE St�dte verf�gbar machen?,bool|1",
			"Anmerkung: Verf�gbarkeit f�r ALLE St�dte setzt die Einstellung des Stadtnames au�er Kraft,note",
			"Der Kommandant,title",
			"minleben"=>"Mindestwert der Lebenspunkte des Kommandanten pro Spielerlevel:,int|10",
			"maxleben"=>"H�chstwert  der Lebenspunkte des Kommandanten pro Spielerlevel:,int|15",
			"dk"=>"Steigt die St�rke des Kommandanten mit jedem DragonKill des Spielers?,bool|1",
			"abonus"=>"Angriffsbonus des Kommandanten zum Spielerangriff,range,1,10,1|2",
			"dbonus"=>"Verteidigungsbonus des Kommandanten zur Spielerverteidigung,range,1,10,1|2",
			"Kopfgeld,title",
			"kopfgeld"=>"Ab welcher Kopfgeldsumme wird der Spieler f�r die Stadtwache interessant?,int|100",
			"anzeige"=>"Kopfgeld f�r den jeweiligen Spieler in den Infos anzeigen?,bool|1",
		),
		"pref"=>array(
			"woher"=>"Von wo kommt der Spieler zum Tor,text|Neuinstallation",
		),
		"requires"=>array(
		"cities"=>" -- Teil des Core-Codes"
		),
    );
    return $info;
}

function stadttor_install(){
	output("Das Stadttormodul Modul wird installiert.");
	module_addhook("village");
	module_addhook("changesetting");
	module_addhook("forest");
	module_addhook("travel");
	module_addhook("worldnav");
	module_addhook("potion");
	module_addhook("charstats");
	return true;
	
}

function stadttor_uninstall(){
	output("Das Stadttormodul Modul wird deinstalliert.");
	return true;
}

function stadttor_dohook($hookname, $args){
	global $session;
	
	switch($hookname){
		
		case "village":
			$woher=get_module_pref("woher");
			if (((get_module_setting("alle")==false) && ($session['user']['location'] == get_module_setting("ort"))) || (get_module_setting("alle")==true)) {   
				if ($session['user']['location'] != $woher) {
				page_header("%s",$session['user']['location']);
				blocknav("runmodule.php",true);
				blocknav("pvp.php",true);
				blocknav("forest.php");
				blocknav("login.php",true);
				blocknav("lodge.php");
				blocknav("gypsy.php");
				blocknav("pavilion.php");
				blocknav("inn.php");
				blocknav("stables.php");
				blocknav("gardens.php");
				blocknav("rock.php");
				blocknav("clan.php");
				blocknav("train.php");
				blocknav("bank.php");
				blocknav("weapons.php");
				blocknav("armor.php");
				blocknav("hof.php");
				blocknav("healer.php",true);
				blocknav("petition.php?op=faq");
				blocknav("news.php");
				blocknav("list.php");
				blocknav("prefs.php");
				unblocknav("runmodule.php?module=stadttor");
				unblocknav("runmodule.php?module=stadttor&op=mauer2");
				$wo=$args['gatenav'];
				addnav("$wo");
				addnav("`QDas Stadttor`0", "runmodule.php?module=stadttor");
				addnav("`QDie Stadtmauer`0", "runmodule.php?module=stadttor&op=mauer2");
				output("`c`\$Die Stadt %s`c`n",$session['user']['location']);
				output("`3Du erreichst `^%s`3, und stehst vor den Toren der Stadt.",$session['user']['location']);
				output("Zum Betreten der Stadt musst Du entweder durch");
				output("das bewachte Stadttor gehen, oder Dir einen Weg durch die Stadtmauer suchen.`n`n");
				set_module_pref("woher",$session['user']['location']);
				if (module_events("village", getsetting("villagechance", 0)) != 0) {
				if (checknavs()) {
				page_footer();
				} 
				else {
				$session['user']['specialinc'] = "";
				$session['user']['specialmisc'] = "";
				$skipvillagedesc=true;
				}
				}
				page_footer();
				}
			if ($session['user']['location'] == $woher) {			
				$wo=$args['gatenav'];
				addnav("$wo");
				addnav("`QDas Stadttor`0", "runmodule.php?module=stadttor");
				addnav("`QDie Stadtmauer`0", "runmodule.php?module=stadttor&op=mauer1");
				blocknav("pvp.php",true);
				blocknav("forest.php");
				blocknav("runmodule.php?module=cities",true);
				blocknav("login.php",true);
				if (is_module_active('worldmapen')) blocknav("runmodule.php?module=worldmapen",true);
				}
		  } 
		  else {
			set_module_pref("woher",$session['user']['location']);
		  }
		break;
		
		case "changesetting":
			if ($args['setting'] == "villagename"){ 
				if ($args['old'] == get_module_setting("ort")) {
					set_module_setting("ort", $args['new']);
				}
			}
		break;
		
		case "forest":
			if (((get_module_setting("alle")==false) && ($session['user']['location'] == get_module_setting("ort"))) || (get_module_setting("alle")==true)) {
				blocknav("village.php",true);
				addnav("Zur�ck");
				addnav("`QDas Stadttor`0", "runmodule.php?module=stadttor");
				addnav("`QDie Stadtmauer`0", "runmodule.php?module=stadttor&op=mauer");
			} 
			else {}
		break;
		  
		case "travel":
			blocknav("village.php",true);
			addnav(array("Stadt %s",$session['user']['location']));
			addnav("`QBetrete das Stadttor`0","runmodule.php?module=stadttor");
			addnav("`QBetrete die Stadtmauer`0", "runmodule.php?module=stadttor&op=mauer2");
		break;
			
		case "worldnav":
			blocknav("village.php",true);
			if ($session['user']['location'] != "World") {
				addnav(array("Stadt %s",$session['user']['location']));
				addnav("`QBetrete das Stadttor`0","runmodule.php?module=stadttor");
				addnav("`QBetrete die Stadtmauer`0", "runmodule.php?module=stadttor&op=mauer2");
			} else {}
		break;
		
		case "potion":
			blocknav("village.php",true);
		break;
		
		case "charstats":
		if (get_module_setting("anzeige")) {
			$sql="SELECT amount FROM ". db_prefix("bounty") ." WHERE status=0 and target=".$session['user']['acctid'];
			$ergebnis = db_query($sql) or die(sql_error($sql));
			for ($i=0;$i<db_num_rows($ergebnis);$i++){
   			$row = db_fetch_assoc($ergebnis);
  		    $bounty+=$row[amount];
			}
			if ($bounty=="") $bounty=0;
			setcharstat("Vital Info","Kopfgeld",$bounty);
		}
		break;
				
	}																			
	return $args;
}


function stadttor_run() {
	global $session;
	$op = httpget('op');
	$kopfgeld=get_module_setting("kopfgeld");
	$sql="SELECT amount FROM ". db_prefix("bounty") ." WHERE status=0 and target=".$session['user']['acctid'];
	$ergebnis = db_query($sql) or die(sql_error($sql));
	for ($i=0;$i<db_num_rows($ergebnis);$i++){
    $row = db_fetch_assoc($ergebnis);
    $bounty+=$row[amount];
	}
	if ($bounty=="") $bounty=0;
	require_once("lib/commentary.php");
	require_once("common.php");
	require_once("lib/villagenav.php");
	require_once("lib/fightnav.php");
	
	page_header("Das Stadttor");
	if($op=="") {
		output("`c`b`4Das Stadttor`b`c`n");
		output("`3Du kommst zu einem grossen Stadttor, das an seinen Seiten je einen Turm hat, von dem aus die Umgebung beobachtet werden kann.");
		if ($session['user']['location'] == getsetting("villagename", LOCATION_FIELDS)) {
		output("`3Innerhalb des Tores liegt `^%s`3, die Hauptstadt des Reiches. Du kannst Menschen erkennen, die gesch�ftig umher laufen, aus einigen Schornsteinen steigt Rauch empor und der Geruch von Essen und Stadt erreicht Deine Nase.",getsetting("villagename", LOCATION_FIELDS));
		}
		else {
		output("`3Innerhalb des Tores liegt `^%s`3. Du kannst Kreaturen erkennen, die gesch�ftig umher laufen, aus einigen Schornsteinen steigt Rauch empor und der Geruch von Essen und Stadt erreicht Deine Nase.`n",$session['user']['location']);
		}
		modulehook("stadttor_beschreibung");
		output("`3Eine breite, gut ausgebaute Strasse f�hrt weiter in andere St�dte.`n");
		output("`3Au�erhalb der Stadtmauer haben Abenteurer und K�mpfer ein Lager errichtet und ihre Zelte aufgeschlagen.`n");
		output("`3Rechts und Links des Tores stehen, jeweils innen und aussen, je 2 m�chtige Trollkrieger, die die Uniform der Stadtwache tragen, welche vom Sheriff befehligt wird, und beobachten jeden, egal ob er die Stadt betritt oder verl��t.`n`n");
		if ($bounty>$kopfgeld) {
			output("`3Du gehst durch das Tor");
			if (is_module_active("jail")) $rand=24; 
			else $rand=22;
				switch(e_rand(1,$rand)){
					case 1:
					case 2:
					case 3:
					case 4:
					case 5:
					case 6:
					case 7:
					case 8:
					case 9:
					case 10:
					case 11:
					case 12:
					case 13:
	   				case 14:
	   				output("`3und nickst den Stadtwachen freundlich zu, aber sie ignorieren Dein L�cheln und betrachten Dich ganz genau.");
	   				output("`3Bevor sie Dich noch erkennen legst Du unauf�llig einen Schritt zu und passierst das Tor.`n");
	   				output("`@Puh, das ist noch mal gut gegangen!.");
					addnav("In der Stadtmauer");
					addnav("`QZur�ck in die Stadt`0","village.php");
					if (is_module_active('worldmapen')) addnav("Reisen","runmodule.php?module=worldmapen&op=beginjourney");
					else addnav("Reisen","runmodule.php?module=cities&op=travel");
					modulehook("stadttor");
					addnav("Vor dem Stadttor");
					$session['user']['specialinc']="";
					$session['user']['specialmisc']="";
					addnav("Zu den Feldern","runmodule.php?module=stadttor&op=felder");
					if ($session['user']['location'] != getsetting("villagename", LOCATION_FIELDS) && $session['user']['location'] != get_module_setting("villagename","ghosttown") && $session['user']['location'] != get_module_setting("villagename","icetown")) addnav("In den Wald","forest.php");
	   				break;
	   				case 15:
	   				case 16:
					case 17:
					case 18:
	   				output("`3und nickst der Stadtwache freundlich zu, aber die ignorieren Dein L�cheln und betrachten Dich ganz genau.");
					output("`3Pl�tzlich ruft einer der Trolle:`4\"Hey, Dich kenne ich doch, auf Dich ist ein Kopfgeld ausgesetzt!\"`3, st�rmt auf Dich zu und h�lt Dich am Arm.");
	   				output("`3Du windest Dich aus seinem Griff, wobei Du Dich verletzt, nimmst dann die Beine in die Hand und l�ufst. Noch bevor die anderen Trolle reagieren k�nnen, bist Du schon in den Menschenmassen untergetaucht.");
					$session['user']['hitpoints']*=0.9;
					addnews("`2%s `4wurde verletzt, als %s sich der Verhaftung durch die Stadtwache entzog.",$session['user']['name'],translate_inline($session['user']['sex']?"sie":"er"));
					addnav("In der Stadtmauer");
					addnav("`QZur�ck in die Stadt`0","village.php");
					if (is_module_active('worldmapen')) addnav("Reisen","runmodule.php?module=worldmapen&op=beginjourney");
					else addnav("Reisen","runmodule.php?module=cities&op=travel");
					modulehook("stadttor");
					addnav("Vor dem Stadttor");
					$session['user']['specialinc']="";
					$session['user']['specialmisc']="";
					addnav("Zu den Feldern","runmodule.php?module=stadttor&op=felder");
					if ($session['user']['location'] != getsetting("villagename", LOCATION_FIELDS) && $session['user']['location'] != get_module_setting("villagename","ghosttown") && $session['user']['location'] != get_module_setting("villagename","icetown")) addnav("In den Wald","forest.php");
					break;
					case 19:
					case 20: 
	   				output("`3und nickst der Stadtwache freundlich zu, aber die ignorieren Dein L�cheln und betrachten Dich ganz genau.");
					output("`3Pl�tzlich ruft einer der Trolle:`4\"Hey, Dich kenne ich doch, auf Dich ist ein Kopfgeld ausgesetzt!\"`3, st�rmt auf Dich zu und h�lt Dich am Arm.");
	   				output("`3Du windest Dich aus seinem Griff und rennst los, doch die Trolle haben bereits zu ihren Bogen gegrifen und spiken Dich mit Pfeilen.");
		output("`3Das Letzte, was Du noch h�rst, ist das Lachen der Trolle, die sich auf das `6Kopfgeld`3 freuen.");
					$session['user']['alive']=false;
					$session['user']['deathpower']+=15;
					$session['user']['hitpoints']=0;
					$session['user']['gold']=0;
					$session['user']['experience']*0.97;
					addnews("`2%s `4starb bei dem Versuch, der Verhaftung durch die Stadtwache zu entkommen.`nDie Stadtwache hat nat�rlich auch die `6%s`4 Goldst�cke Kopfgeld kassiert.",$session['user']['name'],$bounty);
					$sql = "UPDATE ". db_prefix("bounty") ." SET status=1 WHERE target=".$session['user']['acctid'];
					db_query($sql);
					addnav("T�gliche News","news.php");
					break;
					case 21:
					case 22:
	   				output("`3und nickst der Stadtwache freundlich zu, aber die ignorieren Dein L�cheln und betrachten Dich ganz genau.");
					output("`3Pl�tzlich ruft einer der Trolle:`4\"Hey, Dich kenne ich doch, auf Dich ist ein Kopfgeld ausgesetzt!\"`3, st�rmt auf Dich zu und h�lt Dich am Arm.");
	   				output("`3Du windest Dich aus seinem Griff, nimmst dann die Beine in die Hand und l�ufst los so schnell Du kannst.");
	   				output("`3Schnell biegst Du um eine Ecke, blickst vorsichtig zur�ck und kannst keinen der Trolle mehr sehen.");
	   				output("`3Du atmest tief aus, wischst den Schwei� von der Stirn, drehst Dich rum und willst gehen, als Du Dich pl�tzlich dem Kommandanten der Torwache gegen�ber siehst, der mit gez�ckter Waffe vor Dir steht.");
					addnav("K�mpfe","runmodule.php?module=stadttor&op=fighting");
					break; 
					case 23:
					case 24:
					$sname=(get_module_setting("sheriffname","jail"));
					output("`3, doch pl�tzlich steht `4%s `3vor Dir. Du blickst in seine Augen, die Dir verraten, dass eine Flucht sinnlos w�re",$sname);
					output("und Dich lediglich Dein Leben kosten w�rde. Mit gesenktem Kopf und niedergeschlagenen Schritten folgst Du `4%s `3ins `\$Gef�ngnis`3,",$sname);
					output("wo Du wohl die n�chste Zeit verbringen wirst. Das Positive daran ist lediglich, dass nun kein Kopfgeld mehr auf Dich ausgesetzt ist.");
					set_module_pref("wantedlevel",0,"jail");
					set_module_pref("injail",1,"jail");
					set_module_pref("village",$session['user']['location'],"jail");
					addnews("`4%s `2wurde von `4Scheriff %s`2 am Stadttor verhaftet und ins Gef�ngnis gesteckt.`nDie `6%s Goldst�cke Kopfgeld `2erh�lt die Staatskasse.",$session['user']['name'],$sname,$bounty);
					$sql = "UPDATE ". db_prefix("bounty") ." SET status=1 WHERE target=".$session['user']['acctid'];
					db_query($sql);
					addnav("Weiter");
					addnav("Ab ins Gef�ngis","runmodule.php?module=jail");
					break;
				}
		}else{
			output("`3Du gehst durch das Tor und nickst der Stadtwache freundlich zu, diese erwiedern Dein Nicken und widmen sich dann wieder, unverz�glich, der Kontrolle des Stadtzugangs.");
			addnav("In der Stadtmauer");
			addnav("`QZur�ck in die Stadt`0","village.php");
			if (is_module_active('worldmapen')) addnav("Reisen","runmodule.php?module=worldmapen&op=beginjourney");
			else addnav("Reisen","runmodule.php?module=cities&op=travel");
			modulehook("stadttor");
			addnav("Vor dem Stadttor");
			$session['user']['specialinc']="";
			$session['user']['specialmisc']="";
			addnav("Zu den Feldern","runmodule.php?module=stadttor&op=felder");
			if ($session['user']['location'] != getsetting("villagename", LOCATION_FIELDS) && $session['user']['location'] != get_module_setting("villagename","ghosttown") && $session['user']['location'] != get_module_setting("villagename","icetown")) addnav("In den Wald","forest.php");
		}
}
if($op=="felder"){
	page_header("Die Felder");
	output("`3 Du gehst in das Feldlager, dass sich vor dem Tor befindet und schlenderst an vielen Zelten vorbei.");
	output("`3 Vor einigen sitzen Krieger, von denen Dich manche misstrauisch beobachten, andere wiederum Dich zu ihrem Lagerfeuer einladen.");
	output("`3Bei einem der Krieger machst Du dann halt und nimmst seine Einladung an, seinen Geschichten am Lagerfeuer zu lauschen:`n`n");
	addcommentary();
	viewcommentary("Felder","prahlt",20,"erz�hlt");
	addnav("Wege");
	addnav("Zur�ck zum Stadttor","runmodule.php?module=stadttor");
	$session['user']['specialinc']="";
	$session['user']['specialmisc']="";
	if ($session['user']['location'] != getsetting("villagename", LOCATION_FIELDS) && $session['user']['location'] != get_module_setting("villagename","ghosttown") && $session['user']['location'] != get_module_setting("villagename","icetown")) addnav("In den Wald","forest.php");
	addnav("Die Felder");
		if (getsetting("pvp",1))
		{
		addnav("Spieler t�ten","pvp.php");
		}
	addnav("Nachtlager aufschlagen `5(Logout)`0","login.php?op=logout",true);
	}
	
if ($op == "fighting"){
		$min=get_module_setting("minleben");
		$max=get_module_setting("maxleben");
		$leben=(e_rand($min,$max)*$session['user']['level']);
		if (get_module_setting("dk")) $bonus=$session['user']['dragonkills']*10;
		$gesamtleben=$leben+=$bonus;
		$abonus=get_module_setting("abonus");
		$dbonus=get_module_setting("dbonus");
		$badguy = array(        "creaturename"=>translate_inline("`4Kommandant der Torwache`0")
                                ,"creaturelevel"=>$session['user']['level']+1
                                ,"creatureweapon"=>translate_inline("Gro�e Hellebarde")
                                ,"creatureattack"=>$session['user']['attack']+=$abonus
                                ,"creaturedefense"=>$session['user']['defense']+=$dbonus
                                ,"creaturehealth"=>$gesamtleben
                                ,"creaturegold"=>0
                                ,"diddamage"=>0);
    $session['user']['badguy']=createstring($badguy);
    $op="fight";
    $battle=true;
	}
	
if ($op == "fight"){
		require_once("lib/fightnav.php");
		include("battle.php");
		
		if ($victory){
		output("`2Mit einem m�chtigen Hieb gibst Du dem Kommandanten den Todesstoss, nimmst die Beine in die Hand und verschwindest.`n`n");
		$erfahrung=round($session['user']['experience']*1.1) - $session['user']['experience'];
		$session['user']['experience']*=1.1;
		addnav("Weiter","runmodule.php?module=stadttor&op=weiter");
		output("Du erh�ltst `^%s`2 Erfahrungspunkte f�r Deinen Sieg.`n`n", $erfahrung);
		addnews("%s war im Kampf mit dem Kommandanten der Stadtwache siegreich.",$session['user']['name']);
	}
		elseif ($defeat){
		$session['user']['alive']=false;
		$session['user']['hitpoints']=0;
		$session['user']['gold']=0;
		$session['user']['experience']*=0.9;
		output("`4Du bist `bTOT`b!!!`nDu verlierst all Dein Gold und etwas Erfahrung.");
		addnav("T�gliche News","news.php");
		addnews("`2%s `4unterlag im Kampf dem Kommandant der Torwache.`nDieser hat hat nat�rlich auch die `6%s`4 Goldst�cke Kopfgeld kassiert.",$session['user']['name'],$bounty);
		$sql = "UPDATE ". db_prefix("bounty") ." SET status=1 WHERE target=".$session['user']['acctid'];
		db_query($sql);
	}
		else { fightnav(true,true,"runmodule.php?module=stadttor");
		}
}

elseif ($op == "run") {
		output("`4`c`bEin Wegrennen in diesem Kampf ist aussichtslos!`b`c`n`n");
		fightnav(true,true,"runmodule.php?module=stadttor");
}
			
if($op=="weiter"){
		output("`3Nach diesem schweren Kampf �berlegst Du Dir nun, wie es weiter gehen soll. Du lehnst Dich einen Moment an die Mauer und schaust Dir Deine M�glichkeiten nochmals genau an!`n`n");
			addnav("In der Stadtmauer");
			addnav("`QZur�ck in die Stadt`0","village.php");
			if (is_module_active('worldmapen')) addnav("Reisen","runmodule.php?module=worldmapen&op=beginjourney");
			else addnav("Reisen","runmodule.php?module=cities&op=travel");
			modulehook("stadttor");
			addnav("Vor dem Stadttor");
			$session['user']['specialinc']="";
			$session['user']['specialmisc']="";
			addnav("Zu den Feldern","runmodule.php?module=stadttor&op=felder");
			if ($session['user']['location'] != getsetting("villagename", LOCATION_FIELDS) && $session['user']['location'] != get_module_setting("villagename","ghosttown") && $session['user']['location'] != get_module_setting("villagename","icetown")) addnav("In den Wald","forest.php");
		}
		
if($op=="mauer"){
	page_header("Die Stadtmauer");
		output("`3 Du gehst, vom `2Wald `3kommend, zur Stadtmauer, da Du etwas zu verbergen hast und bef�rchtest, von den Torwachen gestellt zu werden, weshalb Du eine geheime T�r in der Mauer nutzen m�chtest, die nicht immer von den Stadwachen bewacht wird.");
		output("`3 Jetzt stehst Du vor der Stadtmauer, die stellenweise mit B�schen und Efeu dicht verwachsen ist und kannst die Stelle schon sehen, an der sich die T�r befinden mu�.");
		output("`@`n`nWas willst Du tun?`n`n");
		addnav("Die Stadtmauer");
		addnav("Versuchen, in die Stadt zu schleichen","runmodule.php?module=stadttor&op=schleichen");
		addnav("Vielleicht schaffe ich es ja doch durch das Stadttor","runmodule.php?module=stadttor");
		addnav("Doch lieber zur�ck in den Wald","forest.php");
		}

if($op=="schleichen"){
	page_header("Die Stadtmauer");
		output("`3 Langsam trittst Du naeher an die Mauer und dr�ckst dichte Efeub�schel nach rechts und links zur Seite, worunter eine massiver Stahlt�r zum Vorscheinen kommt.");
		output("`3 �ngstlich blickst Du Dich noch einmal um, ob auch keine der Stadtwachen in der N�he ist und Dich auch sonst niemand beobachtet.`n");
		output("`3 Die Luft ist rein, Du trittst n�her an die T�r, dr�ckst die Klinke nieder, �ffnest die T�r,");
		if ($bounty>$kopfgeld) {
			if (is_module_active("jail")) $rand=21; 
			else $rand=20;
				switch(e_rand(1,$rand)){
					case 1:
					case 2:
					case 3:
					case 4:
					case 5:
					case 6:
					case 7:
					case 8:
					case 9:
					case 10:
					case 11:
					case 12:
					case 13:
	   				case 14:
	   				case 15:
	   				case 16:
					case 17:
					case 18:
	   				output("`3passierst sie schnell, machst sie von innen wieder zu und gehst schnell gen Marktplatz.`n");
	   				output("`@Hui, das ging noch mal gut!");
					addnav("Zum Marktplatz","village.php");
	   				break;
					case 19:
	   				output("`3passierst sie schnell, machst sie von innen wieder zu und willst grade gen Marktplatz laufen, als eine Stadtwache auf Dich zu st�rzt, die in einem Schatten stand: : `4\"Hey, Dich kenne ich doch, auf Dich ist ein Kopfgeld ausgesetzt!\"");
					output("`3Du ziehst Deine Waffe, schl�gst nach der Wache und diese f�llt ohnm�chtig zu Boden, w�hrend Du schnell das Weite suchst, wobei Du Dich allerdings auch verletzt.");
					$session['user']['hitpoints']*=0.9;
					addnews("`2%s `4wurde verletzt, als %s in die Stadt schlich.",$session['user']['name'], translate_inline($session['user']['sex']?"sie":"er"));
					addnav("Zum Marktplatz","village.php");
					break;
					case 20: 
	   				output("`3passierst sie schnell, machst sie von innen wieder zu und willst grade gen Marktplatz laufen, als eine Stadtwache auf Dich zu st�rzt, die in einem Schatten stand: : `4\"Hey, Dich kenne ich doch, auf Dich ist ein Kopfgeld ausgesetzt!\"");
	   				output("`3Du greifst nach Deiner Waffe und willst auf ihn einschlagen, doch er ist schneller und streckt Dich mit einem gezielten Schwerthieb nieder.");
					output("`3T�dlich getroffen sinkst Du zu Boden.");
					$session['user']['alive']=false;
					$session['user']['deathpower']+=15;
					$session['user']['hitpoints']=0;
					$session['user']['gold']=0;
					$session['user']['experience']*0.97;
					addnews("`2%s `4starb bei dem Versuch, in die Stadt zu schleichen. Die Stadtwache freut sich �ber die `6%s`4 Goldst�cke Kopfgeld.",$session['user']['name'],$bounty);
					$sql = "UPDATE ". db_prefix("bounty") ." SET status=1 WHERE target=".$session['user']['acctid'];
					db_query($sql);
					addnav("T�gliche News","news.php");
					break;
					case 21:
					$sname=(get_module_setting("sheriffname","jail"));
					output("`3doch pl�tzlich steht `4%s `3vor Dir. Du blickst in seine Augen, die Dir verraten, dass eine Flucht sinnlos w�re",$sname);
					output("und Dich lediglich Dein Leben kosten w�rde. Mit gesenktem Kopf und niedergeschlagenen Schritten folgst Du `4%s `3ins `\$Gef�ngnis`3,",$sname);
					output("wo Du wohl die n�chste Zeit verbringen wirst. Das Positive daran ist lediglich, dass nun kein Kopfgeld mehr auf Dich ausgesetzt ist.");
					set_module_pref("wantedlevel",0,"jail");
					set_module_pref("injail",1,"jail");
					set_module_pref("village",$session['user']['location'],"jail");
					addnews("`4%s `2wurde von `4Scheriff %s`2 in der Stadtmauer verhaftet und ins Gef�ngnis gesteckt.`nDie `6%s Goldst�cke Kopfgeld `2erh�lt die Staatskasse.",$session['user']['name'],$sname,$bounty);
					$sql = "UPDATE ". db_prefix("bounty") ." SET status=1 WHERE target=".$session['user']['acctid'];
					db_query($sql);
					addnav("Weiter");
					addnav("Ab ins Gef�ngis","runmodule.php?module=jail");
					break;
					}
				}
		else {
			output("`3passierst sie schnell, machst sie von innen wieder zu und gehst schnell gen Marktplatz.");
	   		output("`3Hui, das ging noch mal gut!");
			addnav("Zum Marktplatz","village.php");
		}
}

if($op=="mauer1"){
	page_header("Die Stadtmauer");
		output("`3 Du gehst, vom Marktplatz kommend, zu einer einsamen, verdeckten Stelle an der Stadtmauer, da Du etwas zu verbergen hast und bef�rchtest, von den Torwachen gestellt zu werden, weshalb Du eine geheime T�r in der Mauer nutzen m�chtest, die nicht immer von den Stadwachen bewacht wird.");
		output("`3 Jetzt stehst Du vor der Stadtmauer, die stellenweise mit B�schen und Efeu dicht verwachsen ist und kannst die Stelle schon sehen, an der sich die T�r befinden mu�.");
		output("`@`n`nWas willst Du tun?`n`n");
		addnav("Die Stadtmauer");
		addnav("Versuchen, aus Stadt zu schleichen","runmodule.php?module=stadttor&op=schleichen1");
		addnav("Vielleicht schaffe ich es ja doch durch das Stadttor","runmodule.php?module=stadttor");
		addnav("Doch lieber zur�ck zum Marktplatz","village.php");
		}
		
if($op=="schleichen1"){
	page_header("Die Stadtmauer");
		output("`3 Langsam trittst Du naeher an die Mauer und dr�ckst dichte Efeub�schel nach rechts und links zur Seite, worunter eine massiver Stahlt�r zum Vorscheinen kommt.");
		output("`3 �ngstlich blickst Du Dich noch einmal um, ob auch keine der Stadtwachen in der N�he ist und Dich auch sonst niemand beobachtet.`n");
		output("`3 Die Luft ist rein, Du trittst n�her an die T�r, dr�ckst die Klinke nieder, �ffnest die T�r,");
		if ($bounty>$kopfgeld) {
			if (is_module_active("jail")) $rand=21; 
			else $rand=20;
				switch(e_rand(1,$rand)){
					case 1:
					case 2:
					case 3:
					case 4:
					case 5:
					case 6:
					case 7:
					case 8:
					case 9:
					case 10:
					case 11:
					case 12:
					case 13:
	   				case 14:
	   				case 15:
	   				case 16:
					case 17:
					case 18:
	   				output("`3passierst sie schnell und machst sie von au�en wieder zu..`n");
	   				output("`@Hui, das ging noch mal gut!");
					addnav("Hinter der Stadtmauer");
					addnav("`QZur�ck in die Stadt`0","village.php");        
					if (is_module_active('worldmapen')) addnav("Reisen","runmodule.php?module=worldmapen&op=beginjourney");
					else addnav("Reisen","runmodule.php?module=cities&op=travel");
					addnav("Vor dem Stadttor");
					$session['user']['specialinc']="";
					$session['user']['specialmisc']="";
					addnav("Zu den Feldern","runmodule.php?module=stadttor&op=felder");
					if ($session['user']['location'] != getsetting("villagename", LOCATION_FIELDS) && $session['user']['location'] != get_module_setting("villagename","ghosttown") && $session['user']['location'] != get_module_setting("villagename","icetown")) addnav("In den Wald","forest.php");
	   				break;
					case 19:
	   				output("`3passierst sie schnell, machst sie von au�en wieder zu und willst grade gen `2Wald `3laufen, als eine Stadtwache auf Dich zu st�rzt, die in einem Schatten stand: : `4\"Hey, Dich kenne ich doch, auf Dich ist ein Kopfgeld ausgesetzt!\"");
					output("`3Du ziehst Deine Waffe, schl�gst nach der Wache und diese f�llt ohnm�chtig zu Boden, w�hrend Du schnell das Weite suchst, wobei Du Dich allerdings auch verletzt.");
					$session['user']['hitpoints']*=0.9;
					addnews("`2%s `4wurde verletzt, als %s aus der Stadt schlich.",$session['user']['name'],translate_inline($session['user']['sex']?"sie":"er"));
					addnav("Hinter der Stadtmauer");
					addnav("`QZur�ck in die Stadt`0","village.php");        
					if (is_module_active('worldmapen')) addnav("Reisen","runmodule.php?module=worldmapen&op=beginjourney");
					else addnav("Reisen","runmodule.php?module=cities&op=travel");
					addnav("Vor dem Stadttor");
					$session['user']['specialinc']="";
					$session['user']['specialmisc']="";
					addnav("Zu den Feldern","runmodule.php?module=stadttor&op=felder");
					if ($session['user']['location'] != getsetting("villagename", LOCATION_FIELDS) && $session['user']['location'] != get_module_setting("villagename","ghosttown") && $session['user']['location'] != get_module_setting("villagename","icetown")) addnav("In den Wald","forest.php");
					break;
					case 20: 
	   				output("`3passierst sie schnell, machst sie von au�en wieder zu und willst grade gen Marktplatz laufen, als eine Stadtwache auf Dich zu st�rzt, die in einem Schatten stand: : `4\"Hey, Dich kenne ich doch, auf Dich ist ein Kopfgeld ausgesetzt!\"");
	   				output("`3Du greifst nach Deiner Waffe und willst auf ihn einschlagen, doch er ist schneller und streckt Dich mit einem gezielten Schwerthieb nieder.");
					output("`3T�dlich getroffen sinkst Du zu Boden.");
					$session['user']['alive']=false;
					$session['user']['deathpower']+=15;
					$session['user']['hitpoints']=0;
					$session['user']['gold']=0;
					$session['user']['experience']*0.97;
					addnews("`2%s `4starb bei dem Versuch, sich aus der Stadt zu schleichen.`nDie Stadtwache freut sich �ber die `6%s`4 Goldst�cke Kopfgeld.",$session['user']['name'],$bounty);
					$sql = "UPDATE ". db_prefix("bounty") ." SET status=1 WHERE target=".$session['user']['acctid'];
					db_query($sql);
					addnav("T�gliche News","news.php");
					break;
					case 21:
					$sname=(get_module_setting("sheriffname","jail"));
					output("`3doch pl�tzlich steht `4%s `3vor Dir. Du blickst in seine Augen, die Dir verraten, dass eine Flucht sinnlos w�re",$sname);
					output("und Dich lediglich Dein Leben kosten w�rde. Mit gesenktem Kopf und niedergeschlagenen Schritten folgst Du `4%s `3ins `\$Gef�ngnis`3,",$sname);
					output("wo Du wohl die n�chste Zeit verbringen wirst. Das Positive daran ist lediglich, dass nun kein Kopfgeld mehr auf Dich ausgesetzt ist.");
					set_module_pref("wantedlevel",0,"jail");
					set_module_pref("injail",1,"jail");
					set_module_pref("village",$session['user']['location'],"jail");
					addnews("`4%s `2wurde von `4Scheriff %s`2 in der Stadtmauer verhaftet und ins Gef�ngnis gesteckt.`nDie `6%s Goldst�cke Kopfgeld `2erh�lt die Staatskasse.",$session['user']['name'],$sname,$bounty);
					$sql = "UPDATE ". db_prefix("bounty") ." SET status=1 WHERE target=".$session['user']['acctid'];
					db_query($sql);
					addnav("Weiter");
					addnav("Ab ins Gef�ngis","runmodule.php?module=jail");
					break;
					}
				}
				else {
					output("`3passierst sie schnell und machst sie von au�en wieder zu..`n");
	   				output("`@Hui, das ging noch mal gut!");
					addnav("Hinter der Stadtmauer");							
					addnav("`QZur�ck in die Stadt`0","village.php");        
					if (is_module_active('worldmapen')) addnav("Reisen","runmodule.php?module=worldmapen&op=beginjourney");
					else addnav("Reisen","runmodule.php?module=cities&op=travel");
					addnav("Vor dem Stadttor");
					$session['user']['specialinc']="";
					$session['user']['specialmisc']="";
					addnav("Zu den Feldern","runmodule.php?module=stadttor&op=felder");   
					if ($session['user']['location'] != getsetting("villagename", LOCATION_FIELDS) && $session['user']['location'] != get_module_setting("villagename","ghosttown") && $session['user']['location'] != get_module_setting("villagename","icetown")) addnav("In den Wald","forest.php");
			}
		}

if($op=="mauer2"){
	page_header("Die Stadtmauer");
		output("`3 Du gehst, aus `2der Wildnis `3kommend, zur Stadtmauer, da Du etwas zu verbergen hast und bef�rchtest, von den Torwachen gestellt zu werden, weshalb Du eine geheime T�r in der Mauer nutzen m�chtest, die nicht immer von den Stadwachen bewacht wird.");
		output("`3 Jetzt stehst Du vor der Stadtmauer, die stellenweise mit B�schen und Efeu dicht verwachsen ist und kannst die Stelle schon sehen, an der sich die T�r befinden mu�.");
		output("`@`n`nWas willst Du tun?`n`n");
		addnav("Die Stadtmauer");
		addnav("Versuchen, in die Stadt zu schleichen","runmodule.php?module=stadttor&op=schleichen");
		addnav("Vielleicht schaffe ich es ja doch durch das Stadttor","runmodule.php?module=stadttor");
		if (is_module_active('worldmapen')) addnav("Doch lieber sonst wohin reisen","runmodule.php?module=worldmapen&op=beginjourney");
		else addnav("Doch lieber sonst wohin reisen","runmodule.php?module=cities&op=travel");
		}

	page_footer();
}
?>