===============================================================================================================================

*** Kurzbeschreibung: ***

Diese zip-Datei beinhaltet die Umsetzung von Apollons Stadttor aus 0.9.7 f�r 1.0.X Server incl. eines dazugeh�rigen Shops. 

===============================================================================================================================

*** Installation: ***

Beide Dateien ins Modulverzeichnis kopieren.
Anschlie�end in die Grotte wechseln und zuerst das Modul "stadttor.php", anschlie�end das Modul "torshop.php" installieren.
Beide Module aktivieren.

===============================================================================================================================

*** Einstellungen: ***

Das Stadttor ist wahlweise f�r EINE Stadt oder ALLE St�dte einstellbar. (Admin-Einstellung in der Grotte).
Die Funktionen, die das Stadttor bietet, wurde in den entsprechenden Modulen geblockt, so dass diese NUR NOCH �ber das Modul
verf�gbar sind.
Per Admin-Einstellung k�nnen nun auch die St�rke des Kommandanten und das erforderliche Kopfgeld einfach an die St�rke
des Servers angepa�t werden. Wahlweise (Admin-Setting) kann auch das Kopfgeld in den Infos f�r den Spieler angezeigt werden.

Sowohl das Verlassen der Stadt/St�dte, als auch deren Betreten, erfolgt nunmehr ausschlie�lich �ber das Stadttor.

===============================================================================================================================

*** Erweiterungen: ***

Die neuen modulehooks "stadttor" und "stadttor_beschreibung" erlauben in einfacher Form das Hinzuf�gen von eigenen Modulen 
in der Stadtmauer.
Module m�ssen mit add_modulehook("stadtmauer"); verlinkt werden.
Die Beschreibung kann beliebig durch add_modulehook("stadtmauer_beschreibung); erg�nzt werden.
Beide hooks einfach durch cases in der function dohook aufrufen.
Somit ist ein "unbegrenzter" Ausbau der Stadtmauer in Zukunft gew�hrleistet.
Daher wurde eine neue Kategorie geschaffen, die sich "Stadtmauer-Modules" nennt. Somit k�nnen zugeh�rige Module k�nftig dort
eingeordnet werden und sind damit klar als solche erkennbar.

===============================================================================================================================


Viel Spa�! :)
Apollon und BansheeElhayn.


**************************

Versionshistorie:

13.12.2005 -- Ver�ffentlichung der V1.0 in Betaversion durch Apollon
18.12.2005 -- Update auf V1.1,  Korrektur der Navigationsprobleme und Schaffung des modulehook ("stadttor")
18.12.2005 -- Update auf V1.11, Korrektur diverser Rechtschreibefehler und kleine �nderung der Navigation; translation ready
19.12.2005 -- Update auf V1.2,  Korrektur des Bugs, dass St�dte nach dem Reisen nicht zwingend durch das Stadttor betreten werden mussten,
	      Einbindung der Weltkarte(worldmapen.php) als Reisealternative.
20.12.2005 -- Update auf V1.3,  Einf�gung des modulhook ("stadttor_beschreibung"), damit weitere Zusatz-Module Texte in der Beschreibung
	      beim Betreten des Stadttores erzeugen k�nnen. Zus�tzliche Admin-Einstellung f�r die St�rke des Kommandanten und das Kopfgeld.
	      Korrektur eines Bugs bei der Einstellung des Stadttors bei nur EINER Stadt und dem Betreten von St�dten, sowie der Navigation
	      beim Heiler im Wald. Korrektur eines Bugs bei den Buffs im Torshop, wonach die �bersetzung durcheinander kam.
21.12.2005 -- Update auf V1.4,  Korrektur des Bugs, dass das Kopfgeld falsch abgefragt wurde und immer 0 war. Hinzuf�gung einer
	      Admin-Einstellung zur Anzeige des Kopfgeldes in den Spieler-Infos.
22.12.2005 -- Update auf V1.5 Korrektur eines kleinen Bugs, wonach auf der Weltkarte die Stadttornavigation immer verf�gbar war. 
	      Korrektur der SQL-Abfrage f�r Datenbanken mit prefixes. 
22.12.2005 -- Update auf V1.51 Korrektur der Navigation f�r die Weltkarte.
23.12.2005 -- Update auf V1.6, zus�tzliches Ereignis eingef�gt, wenn Modul "jail.php" aktiv ist (Gef�ngnis).



Dank an Mindbender, SpiderPOH und XChisX f�r ihre Hinweise auf die Bugs und ihre Vorschl�ge.