<? 
/* ******************* 
Temple of the gods 
Written by Romulus von Grauhaar 
    Visit http://www.scheibenwelt-logd.de.vu

This Special adds an event where players can donate to a temple in the forest. 
When the donated gold reachs the limit, a random event happens.
This limit can be set at the beginning of the skript and the names of the gods too.

Before Using this Special-event you have to do the following SQL: 

ALTER TABLE `accounts` ADD `tempelgold` INT( 30 ) DEFAULT '0' NOT NULL ;

As an option, you can add to the user.php the following line:
	"tempelgold"=>"Gold donated in the temple,int",
so that superusers can edit the amount donated by the player in the superuser grotto.



******************* */  


// The following lines are for configuration od the script. $spendenbetrag ist the
// limit of gold a player must reach to get an event from the gods.
// The other values are the names of the gods.

$spendenbetrag = "10000";
$gott_gem = "The Lady";
$gott_defense = "Om";
$gott_hp = "Fate";
$gott_attack = "Offler";
$gott_charm = "Aphrodante";
$gott_fight = "Nuggan";
$gott_kill = "Bel-Shamharoth";
$gott_hurt = "Saint Frenzy";


$session[user][specialinc]="temple.php"; 
if ($HTTP_GET_VARS[op]==""){ 
    output("`@On your journey you pass a temple in the forest. An imposing but dilapidated building. you enter the sacred place, and you see that the temple needs a renovation. The only thing that seems to be intact is the poor-box over which a sign is placed: `n`&\"Dear visitor, our temple is decaying, I'm afraid. please donate a few coins for the renovation. The Gods may thank you. The Archpriest.\"`@"); 
    output("`n`nWhat do you do?"); 
    addnav("Donate","forest.php?op=spenden");
    addnav("Leave the temple","forest.php?op=verlassen");
$session[user][specialinc]="temple.php"; 
}
else if ($HTTP_GET_VARS[op]=="verlassen"){    
	output("`@You leave the old, dilapidated Temple behind you.");
	$session[user][specialinc]="";
	addnav("Back to the forest","forest.php");	
}
else if ($HTTP_GET_VARS[op]=="spenden"){    
$session[user][specialinc]="temple.php"; 
addnav("Donate");
addnav("100 gold","forest.php?op=spendeneingang&betrag=100");
addnav("500 gold","forest.php?op=spendeneingang&betrag=500");
addnav("1000 gold","forest.php?op=spendeneingang&betrag=1000");
addnav("5000 gold","forest.php?op=spendeneingang&betrag=5000");
addnav("Nothing","forest.php?op=verlassen");
output("You have ".($session[user][tempelgold]>0?" ":"not")."donated gold in this temple yet.`n How many goldpieces do you want to donate for the temple-renovation?",true);
}
else if ($HTTP_GET_VARS[op]=="spendeneingang"){
if ($HTTP_GET_VARS[betrag]>$session[user][gold])

	{
		output("`@Oooops. You don't have so much gold with you. Pray, that the gods didn't notice this try.`n`n");
		output("You leave the temple before the Gods will notice your little mistake.");
		$session[user][specialinc]=""; 
		addnav("Back to the Forest","forest.php");
	}
if ($HTTP_GET_VARS[betrag]<=$session[user][gold])
	{
		$betrag=$HTTP_GET_VARS[betrag];
		output("`^`bYou donate `&$betrag`^ gold for the temple-renovation. ");
		debuglog("donated $betrag gold for the temple-renovation");
		$session[user][tempelgold]+=$betrag;
		$session[user][gold]-=$betrag;
		output("The god of the temple has registered your donation.`b");
		$session[user][specialinc]="";
		addnav("Leave the temple","forest.php");
if($session[user][tempelgold] >= $spendenbetrag) 
	{
	output("`@When you throw the golden coins into the poor-box, suddenly thunder rolls. It seems that the god of the temple has noticed your noble donations.`n`n");
	switch(e_rand(1,8))
		{
          case 1:
              output("`@The god of the temple, `^$gott_gem`@,appears in front of you. You are lucky to get `$5 gems`@ for your donations!");
	$session[user][gems]+=5;
	$session[user][tempelgold]=0;
	addnews("`%".$session[user][name]."`7 got from $gott_gem in a temple big richness.");
                break;
          case 2:
              output("`@The god of the temple, `^$gott_defense`@ ,appears in front of you.  With the powers of the god you get better `$defense`@ pemanently for our donations!");
	$session[user][defence]+=2;
	$session[user][tempelgold]=0;
	addnews("`%".$session[user][name]."`7's Skin was made more resistand by $gott_defense.");
                break;
          case 3:
              output("`@The god of the temple, `^$gott_attack`@, appears in front of you. With the powers of the god your `$attack`@ is strengthened permanently for your donations!");
	$session[user][attack]+=2;
	$session[user][tempelgold]=0;
	addnews("`%".$session[user][name]."'s`7 muscles are strengthened by $gott_attack.");
                break;
          case 4:
              output("`@The god of the temple, `^$gott_hp`@, appears in front of you. Your fate, to get additional `$hitpoints`@, is fullfilled!");
	$session[user][maxhitpoints]+=2;
	$session[user][tempelgold]=0;
	addnews("`%".$session[user][name]."`7 gained additional vital powers from $gott_hp.");
                break;
          case 5:
              output("`@The god of the temple, `^$gott_fight`@, appears in front of you. With the powers of the god you get today several `$extra-fights`@ for your donations!");
	$session[user][turns]+=10;
	$session[user][tempelgold]=0;
	addnews("`%".$session[user][name]."`7 got serveral extra-fights from $gott_fight.");
                break;
          case 6:
              output("`@The god of the temple, `^$gott_charm`@, appears in front of you. With the powers of the god, you look much better. You gain `$4 charmpoints`@ for our donations!");
	$session[user][charm]+=4;
	$session[user][tempelgold]=0;
	addnews("`%".$session[user][name]."`7 was made to a better looking person by $gott_charm.");
                break;
          case 7:
              output("`@The god of the temple, `^$gott_hurt`@, appears in front of you. What did you think to conjure a godhood famous for its cruelty? After a hard`$ Punch`@ you wake from a blackout and lost nearly all of your hitpoints.");
	$session[user][hitpoints]=1;
	$session[user][tempelgold]=0;
	addnews("`%".$session[user][name]."`7 was hurt bad in a temple by $gott_hurt. They should not play with the powers of gods.");
                break;
          case 8:
              output("`@The god of the temple, `^$gott_kill`@, appears in front of you. What did you think to conjure a godhood which is a notorius killer? $gott_kill touches you and immediatly it's over!");
	$session[user][hitpoints]=0;
	$session[user][tempelgold]=0;
	$session[user][alive]=false; 
	$session[user][gold]=0;
	$session[user][experience]*=0.95;
	addnews("`%".$session[user][name]."`7 was killed in a temple by $gott_kill. They should not play with the powers of gods.");
                break;
		} //switch
	} // ben�tigten betrag erreicht?
	} //spendeneingang
$session[user][specialinc]=""; 
}
        page_footer(); 
?>