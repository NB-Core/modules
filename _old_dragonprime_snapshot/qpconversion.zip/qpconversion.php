<?php

/***************************************************************************/
/* Name: Quest point to donation point conversion                          */
/* ver 1.1                                                                 */
/* Billie Kennedy => dannic06@gmail.com                                    */
/*                                                                         */
/*4-8-05                                                                   */
/*  Added donation to quest conversion                                     */
/***************************************************************************/

function qpconversion_getmoduleinfo(){
	$info = array(
		"name"=>"Quest to Points Conversion",
		"author"=>"Billie Kennedy",
		"version"=>"1.1",
		"download"=>"http://www.nuketemplate.com/modules.php?name=Downloads&d_op=viewdownload&cid=33",
        "vertxtloc"=>"http://dragonprime.net/users/Dannic/",
		"category"=>"Questhut",
		"requires"=>array(
			"questbasics"=>"1.0|XChrisX, http://beta.lotgd.de/downloads/questpack.zip",
			) ,
		"settings"=>array(
			"QP Module Settings,title",
			"qpallow"=>"Allow Quest point conversion?,bool|1",
			"ratio"=>"How many Quest points does it cost per Donation point?,int|5",
			"dpallow"=>"Allow Donation point conversion?,bool|0",
			"lratio"=>"How many Quest points will a player recieve for a Donation point?,int|5",
		),
		
	);
	return $info;
}

function qpconversion_install(){
	module_addhook("questhut");
	module_addhook("questhutpointsdesc");
	module_addhook("lodge");
	module_addhook("pointsdesc");
	return true;
}
function qpconversion_uninstall(){
	return true;
}

function qpconversion_dohook($hookname,$args){
	global $session;
	$ratio = get_module_setting("ratio");
	$lratio = get_module_setting("lratio");
	
	switch($hookname){
		case "questhutpointsdesc":
			if(get_module_setting("qpallow")){
				$args['count']++;
				$format = $args['format'];
				$str = translate("Convert Quest points to Donation points at a %s to one ratio.");
				$str = sprintf($str, $ratio);
				output($format, $str, true);
			}
		break;
		case "questhut":
			if(get_module_setting("qpallow")){
				addnav("Convert to Donation Points","runmodule.php?module=qpconversion&op=convert");
			}
			break;
		
		case "pointsdesc":
			if(get_module_setting("dpallow")){
				$args['count']++;
				$format = $args['format'];
				$str = translate("Convert Donation points to Quest points at a %s to one ratio.");
				$str = sprintf($str, $cost);
				output($format, $str, true);
			}
		break;
		
		case "lodge":
			if(get_module_setting("dpallow")){
				addnav("Convert to Quest Points","runmodule.php?module=qpconversion&op=lconvert");
			}		
		break;
		
		}
	return $args;
}

function qpconversion_run(){
	global $session;
	$op = httpget("op");
	$convert = $_POST['qp'];
	$cost = get_module_setting("ratio");
	$pointsavailable = get_module_pref("questpoint", "questbasics") - get_module_pref("questpointspent", "questbasics");
	$dconvert = $_POST['qp'];
	$dcost = get_module_setting("lratio");
	$dpointsavailable = $session['user']['donation'] - $session['user']['donationspent'];
	
	if ($op=="convert"){
		page_header("Mysterious Hut");
		addnav("H?Return to the Hut","runmodule.php?module=questbasics");
		output("`#You have `^%s`# points you can spend.`n`n",$pointsavailable);
		output("`%At a ratio of %s Quest point(s) to one Donation point.  How many Quest points do you wish to spend?`n`0", $cost);
        $linkcode="<form action='runmodule.php?module=qpconversion&op=convert2' method='POST'><input name='qp' id='qp'><br /><input type='submit' class='button' value='Submit'></form>";
        output("%s",$linkcode,true);
        $linkcode="<script language='JavaScript'>document.getElementById('bet').focus();</script>";
        output("%s",$linkcode,true);
        addnav("","runmodule.php?module=qpconversion&op=convert2");		
	}
	if ($op=="convert2"){
		page_header("Mysterious Hut");
		addnav("H?Return to the Hut","runmodule.php?module=questbasics");
		$totalpoints = $convert / $cost;
		if ($convert > $pointsavailable){
			output("`!You get an errie feeling.  It was as if someone or something was trying to pull something out of you but couldn't.`n");
			output("You must not be quite the hero you thought.  Maybe you should try to gain more quest points before doing that again.`n");

		}else{
		
			output("`!A man in a blue cloak acknowledges your request.  He places his hand on your chest.  The world suddenly spins and you can feel that some of your Quest points have been converted to `^%s Donation points.`0",$totalpoints);
			$session['user']['donation'] += $totalpoints;
			set_module_pref('questpointspent',get_module_pref('questpointspent', 'questbasics')+ $convert, 'questbasics');
			debuglog("spent $convert Quest points on $totalpoints Donation points");
		}
		
    }
    if ($op=="lconvert"){
		page_header("Hunter's Lodge");
		addnav("H?Return to the Lodge","lodge.php");
		output("`#You have `^%s`# points you can spend.`n`n",$dpointsavailable);
		output("`%For every Donation point you will recieve %s Quest point(s).  How many Donation points do you wish to spend?`n`0", $dcost);
        $linkcode="<form action='runmodule.php?module=qpconversion&op=lconvert2' method='POST'><input name='qp' id='qp'><br /><input type='submit' class='button' value='Submit'></form>";
        output("%s",$linkcode,true);
        $linkcode="<script language='JavaScript'>document.getElementById('bet').focus();</script>";
        output("%s",$linkcode,true);
        addnav("","runmodule.php?module=qpconversion&op=lconvert2");		
	}
	if ($op=="lconvert2"){
		page_header("Hunter's Lodge");
		addnav("H?Return to the Lodge","lodge.php");
		$totalpoints = $dconvert * $cost;
		if ($dconvert > $dpointsavailable){
			output("`!You get an errie feeling.  It was as if someone or something was trying to pull something out of you but couldn't.`n");
			output("You must not be quite the hero you thought.  Maybe you should try to gain more donation points before doing that again.`n");

		}else{
			output("`!From out of the back room, a small man in a blue cloak appears.");
			output("`!The man in a blue cloak acknowledges your request.  He places his hand on your chest.  The world suddenly spins and you can feel that some of your Donation points have been converted to `^%s Quest points.`0",$totalpoints);
			$session['user']['donation'] -= $dconvert;
			set_module_pref('questpoint',get_module_pref('questpoint', 'questbasics')+ $totalpoints, 'questbasics');
			debuglog("spent $convert Donation points on $totalpoints Quest points");
		}
		
    }
	page_footer();
}