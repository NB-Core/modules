<? 
require_once "common.php"; 

isnewday(2); 

if ($_GET['op']=="block"){ 
    $sql = "UPDATE accounts SET avatar='' WHERE acctid='{$_GET['userid']}'"; 
    systemmail($_GET['userid'],"Your Avatar was blocked","The system administrators have decided that your avatar is inappropriate, so it has been blocked.`n`nIf you wish to appeal this decision, you may do so with the petition link."); 
    db_query($sql); 
} 
$sql = "SELECT name,acctid,avatar FROM accounts WHERE avatar>'' ORDER BY acctid DESC LIMIT 100"; 
$result = db_query($sql); 
page_header("Player Avatars"); 
output("`b`&Player Avatars:`0`b`n"); 
for ($i=0;$i<db_num_rows($result);$i++){ 
    $row = db_fetch_assoc($result); 
    output("`![<a href='avatars.php?op=block&userid={$row['acctid']}'>Remove</a>]",true); 
    addnav("","avatars.php?op=block&userid={$row['acctid']}"); 
    output("`&{$row['name']}: `^"); 
    $pic_size = @getimagesize($row[avatar]); 
    $pic_width = $pic_size[0]; 
    $pic_height = $pic_size[1]; 
    output("<img src=\"$row[avatar]\" ",true); 
    if ($pic_width > 200) output("width=\"200\" ",true ); 
    if ($pic_height > 200) output("height=\"200\" ",true ); 
    output("alt=\"$row[name]\">&nbsp;`n`n",true); 

} 
db_free_result($result); 
addnav("G?Return to Grotto","superuser.php"); 
addnav("W?Return to Village","village.php"); 
addnav("Bios","bios.php"); 
page_footer(); 
?> 

