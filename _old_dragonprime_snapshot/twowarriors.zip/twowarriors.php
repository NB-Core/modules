<?php

require_once("lib/http.php");

function twowarriors_getmoduleinfo(){
	$info = array(
		"name"=>"Adventures of 2 Warriors",
		"author"=>"Kyle Spence (Ignatus)",
		"version"=>"1.0",
		"category"=>"Forest Specials",
		"description"=>"Find an old house to recount the adventures of Two Warriors",
		"download"=>"http://dragonprime.net/users/Ignatus/twowarriors.zip".
		"settings"=>array(
			"Adventures of The Two Warriors, title",
			"warrior1"=>"Who is the first Warrior,text|Lykidy",
			"warrior2"=>"Who is the second Warrior,text|Nightsflame",
			"hitpointslost"=>"Percentage of hitpoints lost ,range,5,50,5|30",
			"charmlost"=>"How much charm is lost ,range,1,5,1|2",
			"gemsgained"=>"Number of gems found ,int|1",
			"goldgained"=>"Amount of gold found ,int|50",
		),
	);
	return $info;
}
function twowarriors_install() {
	module_addeventhook("forest", "return 60;");
	return true;
}
function twowarriors_uninstall(){
	return true;
}
function twowarriors_dohook($hookname,$args){
	return $args;
}
function twowarriors_runevent($type){
	global $session;
	$from = "forest.php?";
	$op = httpget('op');
	$warrior1=get_module_setting("warrior1");
	$warrior2=get_module_setting("warrior2");
	$gemsgained=get_module_pref("gemsgained");
	$charmlost=get_module_pref("charmlost");
	$goldlost=get_module_pref("goldlost");
	$session['user']['specialinc']="module:twowarriors";
	$hplost=get_module_pref("hitpointslost");
	$juicechance = e_rand(1,3);
	$firechance = e_rand(1,3);
	$acchance = e_rand(1,3);
	$farmchance = e_rand(1,3);
	output("`n`^");
	if($op==""){
		output("You find an old tree house.`n`n");
		output("You wonder if it has any treasure inside...`n`n");
		output("Do you want to find out what's up there?");
		addnav("Yes", $from . "op=enter");
		addnav("No", $from . "op=leave");
	}
	if($op=="leave"){
		output("You decide it's nothing and walk away.`n`n");
		$session['user']['specialinc']="";
	}
	if($op=="enter"){
		output("You climb up the ladder and explore.`n`n");
		output("You have a strong feeling like `&%s`^ and `\$%s`^ have been here before...",$warrior1,$warrior2);
		output("`n`nPerhaps when they were younger.`n`n");
		output("To your left you notice a small book listing all the adventures of `&%s`^ and `\$%s`^.",$warrior1,$warrior2);
		output("`n`nTo your right you see a Wooden Chicken.");
		addnav("Look through the book", $from . "op=book");
		addnav("Walk towards the Wooden Chicken", $from . "op=chicken");
		addnav("Leave", $from . "op=leave");
		}
	if($op=="book"){
		output("You start reading through the book and peruse the table of contents:");
		addnav("Juice Making", $from . "op=juice");
		addnav("The Fire Days", $from . "op=fire");
		addnav("Acronyms", $from . "op=ac");
		addnav("Tim Hortons?", $from . "op=tim");
		addnav("Farmie beating",  $from . "op=farm");
		addnav("Knights Order of the Black Rose", $from . "op=br");
		addnav("Leave", $from . "op=leave");
		}
	if($op=="juice"){
		output("You start reading the chapter and it starts listing how `&%s`^ and `\$%s`^",$warrior1,$warrior2);
		output("made their famous Half-used apple juice.`n`n");
		// Half Used is suppose to be in there
		output("It suddenly dawns on you what vile ingredients they put in that nasty concoction... and then...`n`n");
		output("You remember that you drank some of it!! Oh gross! You really shouldn't have drank it when they offered it to ya!`n`n");
		output("Anyway, you look down and it says you must earn the right to know the other secrets...");
		output("Looking around the book to find some more of the strange secrets you find a piece of paper");
		output("It tell you to mix the red drink with the black");
		switch ($juicechance){
			case 1: 
				output("You put the red in the purple one you fool");
				output("Your surprise you came out of that alive and you notice that your a bit hurt");
				$hitpointslost= round($session['user']['hitpoints']*get_module_pref("hitpointslost")/100);
				$session['user']['hitpoints']-=$hitpointslost;
				if ($session['user']['hitpoints'] < 1) {
				$session['user']['hitpoints'] = 1;
				output("`6You lose all your  hitpoints except one");
			}else{
				output("`6You take `4%s`6 point of damage",$hitpointslost);
				}
				output("and will be `4hobbling`6 around for a while until your leg heals.");
				addnav("Leave", $from . "op=leave");
				break;
             case 2:
			 	output("You look at the red and black drinks and decide to try something different you mix red with red");
				output("You're shocked that you didn't die when you drank the strange concoction...`n`n");
				output("You grew hair on your chest");
				addnews("%s grew hair on %s chest.  ",$session['user']['name'],translate_inline($session['user']['sex']?"her":"his") );
				addnav("Leave", $from . "op=leave");
				break;
			case 3:
				output("You put the black in the purple creating a concoction that will change the world");
				output("The effects start with suddenly being aware that your in a tree house made for little kids");
				output("You suddenly feel that you should leave, so you jump out of the tree house and land with out getting hurt but you feel healthy");
				if ($session['user']['hitpoints']<$session['user']['maxhitpoints'])
					$session['user']['hitpoints']=$session['user']['maxhitpoints'];
				output("You realize that the potion must have healed you");
				addnav("Leave", $from . "op=leave");
				break;
			}
		}
	if($op=="fire"){
		output("You start reading the story of Fire and it tells you how to make a wide selection of explosives!");
		output("`n`nYou reach a part that lists all the places those peculiar warriors have burned down.");
		output("`n`nYou wonder to yourself on how much money you can get by turning in `&%s`^ and `\$%s`^",$warrior1,$warrior2);
		output("to the authorities for burning down the inn 3 times... but who's going to believe a story that you read in a tree house?!?");
		switch ($firechance){
			case 1:
				output("You decide that its worth a shot to try to give the ploice as much info as you can");
				output("You walk over to the station feeling that your doing the right thing");
				output("The police are great full for you your information and give you some gold");
				$session['user']['gold']+=$goldgained;
				addnav("leave", $from . "op=leave");
				break;
			case 2:
				output("You thought to yourself that burning the inn could be fun you");
				output("While searching for materials to burn the inn you came across a warning sign on the side of a case");
				output("Highly explosive Warning");
				output("You think to your self that you found it you open the box");
				output("a clown pops out at you, you fall down losing some charm");
				$session['user']['charm']-=$charmlost;
				addnav("Leave", $from . "op=leave");
				break;
			case 3:
				output("You just wonder if you should rely on the books source of information");
				output("so you just ignore the burning of the inn part and move on");
				addnav("leave", $from . "op=leave");
				break;
			}
		}
	if($op=="ac"){
		output("This is the guide to `#'The Acronyms of `&%s`# and `\$%s`#'.`^",$warrior1,$warrior2);
		output("`n`nFirst just slam your quill against the parchment randomly...");
		output("Then try to make sense out of it!");
		output("`n`nOne day you might become a pro at it just like `&%s`^ and `\$%s`^!",$warrior1,$warrior2);
		switch ($acchance){
			case 1:
				output("Feeling as if you should give it a shot you start slamming your quill against the parchment randomly");
				output("You start feeling a slight pain in your leg");
				output("You look down and realized that you stabbed through the paper with you quill into your leg");
				$hitpointslost= round($session['user']['hitpoints']*get_module_pref("hitpointslost")/100);
				$session['user']['hitpoints']-=$hitpointslost;
				if ($session['user']['hitpoints'] < 1) {
				$session['user']['hitpoints'] = 1;
				output("`6You lose all your  hitpoints except one");				
			}else{
				output("`6You take `4%s`6 point of damage",$hitpointslost);
				}
				output("and will be `4hobbling`6 around for a while until your leg heals.");
				addnews("%s stab himself with a quill while trying to make Acronyms.",$session['user']['name']);
				addnav("Leave", $from . "op=leave");
				break;
			case 2:
				output("Looking around your notice that others have tried this with some success");
				output("One of the Acronyms says look to the left");
				output("Forgetting that it is a Acronyms you look to the left and found a gem");
				$session['user']['gems']+=$gemsgained;
				addnav("Leave", $from . "op=leave");
				break;
			case 3:
				output("Looking down at what others have done your start to read the means of stuff");
				output("tcyccit really caught your eye");
				output("You looked at what it meant The Chicken you can carve in to");
				output("You think you might need to check that out sometime");
				addnav("Leave", $from . "op=leave");
				break;
				}
		}
	if($op=="tim"){
		output("When you are hurt or injured do what must be done!`n");
		output("Run as fast as you can to a near buy Tim Hortons`n");
		output("For a coffee break and doughnuts`n`n");
		output("Sometimes you think that the warriors really were more slackers than great heroes.");		
		addnav("Leave", $from . "op=leave");
		}
	if($op=="farm"){
		output("When ever you have a chance, beat up a farmie.`n`n");
		output("The greatest reason to attack another player is BECAUSE they are a farmie!`n`n");
		output("It puts hair on their chest... now go out there and beat them up!");
		switch ($farmchance){
			case 1:
				output("Feeling like you have a need to go out there and beat up a farmie");
				output("You start yelling Hey farmies beware here I come");
				output("Unfortunately there was a farmie behind you and he knocked you out cold");
				output("because of such a defeat you lost charm");
				$session['user']['charm']-=$charmlost;
				addnav("Leave", $from . "op=leave");
				break;
			case 2:
				output("Realizing that farmies are week and only need help you feel a strong emotion for");
				output("helping out farmies");
				output(" The Gods have taken favor with your kindness and granted you some gold");
				$session['user']['gold']+=$goldgained;
				output("After receiving the gold your forgot all about helping the farmies and go off to kill some");
				addnav("Leave", $from . "op=leave");
				break;
			case 3:
				output("You just decide that there are enough hairy chest out there so you just walk away");
				addnav("Leave", $from . "op=leave");
				break;
			}					
		}
	if($op=="br"){
		output("The knights are true people`n`n");
		output("They were once called the Half Knights created by Xen`n");
		output(" But when `&%s`^ and `\$%s`^ took it over it became",$warrior1,$warrior2);
		output("know as the legendary `\$Knights Order of the Black Rose`^.`n`n");
		output(" The leaders are strong and wise, `&%s`^ and `\$%s`^!`n`n",$warrior1,$warrior2);
		output("Err... Maybe not wise but strong... err... strong smelling.  Bah... just forget it!");
		addnav("Leave", $from . "op=leave");
		}
	if($op=="chicken"){
		output("You walk over to the wooden chicken and look at the carvings:`n`n");
		require_once("lib/commentary.php");
		addcommentary();
		viewcommentary("chickenscratch","Carve Here",30,"scratches in");
		addnav("Leave", $from . "op=leave");
		}
    }
?>			