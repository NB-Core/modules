Module Name: quizgame2.php
Category: Village
Worktitle: Quiz Game 2: Gods and Goddesses
Version: 3.0
Author: DaveS
Date:  May 2, 2006

Description: 
Gods and Goddesses - Learn about ancient Pantheons!

There are 3 ways to use this Quiz:

1.  Use the Module
Open the folder: quizegame2 Module
Copy all the files in the folder into your modules folder.
There is a setting to require a certain number of dks before players can do the quiz.
This will work with or without the quizload.php module.

2.  Upgrade the quizload module quiz
Open the folder: Upgrade Quiz
This will overwrite the old quiz in the quizload.php module.
Take the quizgame2.php module from the "Upgrade Quiz" folder and place it in
your modules folder. Install it and it will AUTOMATICALLY turn off the Quiz 
Headquarters and the program will restart with the next system newday.
You do NOT need to activate it.  You can uninstall it right away.
Requires: quizload.php

3. Upgrade the quizload module backup quiz
Open the  folder: Upgrade Backup Quiz
This will overwrite the old backup quiz in the quizload.php module.
Take the quizgame2.php module from the "Upgrade Quiz" folder and place it in
your modules folder.  Install it and it will replace the Backup Quiz with a new one;
you will have to manually change to the new quiz when you are ready.
You do NOT need to activate it.  You can uninstall it right away.
Requires: quizload.php