<?php
/*
Module Name: quizgame2.php
Category: Village
Worktitle: Quiz Game 2
Version: 3.0
Author: DaveS
Date:  May 2, 2006

Description: 
Gods and Goddesses - Learn about ancient Pantheons!
*/
require_once("lib/villagenav.php");
require_once("lib/titles.php");
require_once("lib/names.php");
function quizgame2_getmoduleinfo() {
	$info = array(
		"name"=>"Quiz Game 2: Gods and Goddesses",
		"author"=>"DaveS",
		"version"=>"3.0",
		"category"=>"Village",
		"download"=>"",
		"settings"=>array(
			"Quiz Game 2,title",
			"goldaward"=>"Gold Awarded,int|100",
			"gemaward"=>"Gems Awarded,int|1",
			"dkmin"=>"Minimum Dks player must have before this quiz is available?,int|10",
			"quizname"=>"What is the name of the quiz?,text|Gods and Goddesses",
			"announce1"=>"First line of your description of this quiz,text|Do not play lightly with Gods",
			"announce2"=>"Second line of your description of this quiz,text|For they do not like the weak.",
			"announce3"=>"Third line of your description of this quiz,text|You must answer with care",
			"announce4"=>"Fourth line of your description of this quiz,text|And with reverence you must speak.",
			"riddlenum"=>"How many riddles will be in this quiz?,range,1,8,1|8",
			"quizgame2loc"=>"Where does the Quiz Office appear?,location|".getsetting("villagename", LOCATION_FIELDS),
			"Only needed if not using quizload module,note",
			"titleyes"=>"Would you like to offer a title for completing this quiz?,bool|1",
			"titleto"=>"What title would you like to use? (no spaces),text|TheDivine",
			"limitwin"=>"If you wish to limit to a certain number of winners; how many?,int|-1",
			"Set to -1 if you do not want a limit to the number of winners,note",
			"currentwin"=>"How many winners are there so far?,int|0",
			"limitlong"=>"If you wish to autoclose the quiz; how many game days until it closes?,int|-1",
			"Set to -1 if you do not want the quiz to autoclose,note",
			"currentlong"=>"How many days has this quiz been open so far?,int|0",
			"quizhold"=>"Close the quiz?,bool|0",
			"resetquiz"=>"Reload the quiz at the next day?,bool|0",
			"This will reset and open everything at next newday so use it only if you are ready with a new quiz,note",
			"Question 1,title",
			"Leave extra lines blank if there is no additional text,note",
			"riddle1a"=>"What is the first line of riddle 1?,text|The Druids prayed to Gods of old",
			"riddle1b"=>"What is the second line of riddle 1?,text|And Legends grew of which you're told",
			"riddle1c"=>"What is the third line of riddle 1?,text|This God was known for his healing skills",
			"riddle1d"=>"What is the fourth line of riddle 1?,text|In Celtic lore he cured all ills.",
			"riddle1e"=>"What is the fifth line of riddle 1?,text|Which God do I speak of?",
			"answer1"=>"What is the correct answer?,text|Diancecht",
			"reminder1"=>"Where is the answer to this question from?,text|Celtic Mythology",
			"wrong1a"=>"What is wrong answer 1?,text|Arawn",
			"wrong1b"=>"What is wrong answer 2?,text|Dagda",
			"wrong1c"=>"What is wrong answer 3?,text|Brigit",
			"wrong1d"=>"What is wrong answer 4?,text|Cu Chulainn",
			"wrong1e"=>"What is wrong answer 5?,text|Oghma",
			"wrong1f"=>"What is wrong answer 6?,text|Nuada",
			"wrong1g"=>"What is wrong answer 7?,text|Morrigan",
			"wrong1h"=>"What is wrong answer 8?,text|Lugh",
			"wrong1i"=>"What is wrong answer 9?,text|Silvanus",
			"quizzer1"=>"Person asking question 1,text|Druid Doug",
			"sexofq1"=>"What is the sex of Person 1?,enum,0,Female,1,Male|1",
			"Question 2,title",
			"Leave extra lines blank if there is no additional text,note",
			"riddle2a"=>"What is the first line of riddle 2?,text|In Central America the Gods held sway",
			"riddle2b"=>"What is the second line of riddle 2?,text|And molded lives and influenced the day.",
			"riddle2c"=>"What is the third line of riddle 2?,text|But death was controlled without sparring the rod",
			"riddle2d"=>"What is the fourth line of riddle 2?,text|The ruler of the afterlife was this god.",
			"riddle2e"=>"What is the fifth line of riddle 2?,text|",
			"answer2"=>"What is the correct answer?,text|Mictlantecuhtli",
			"reminder2"=>"Where is the answer to this question from?,text|Central American Mythology",
			"wrong2a"=>"What is wrong answer 1?,text|Itzamna",
			"wrong2b"=>"What is wrong answer 2?,text|Quetzalcoatl",
			"wrong2c"=>"What is wrong answer 3?,text|Camazotz",
			"wrong2d"=>"What is wrong answer 4?,text|Huhueteotl",
			"wrong2e"=>"What is wrong answer 5?,text|Chalchiuhtlicue",
			"wrong2f"=>"What is wrong answer 6?,text|Camaxtli",
			"wrong2g"=>"What is wrong answer 7?,text|Huitzipochtli",
			"wrong2h"=>"What is wrong answer 8?,text|Tlaloc",
			"wrong2i"=>"What is wrong answer 9?,text|Tezcatlipoca",
			"quizzer2"=>"Person asking question 2,text|Eagle",
			"sexofq2"=>"What is the sex of Person 2?,enum,0,Female,1,Male|0",
			"Question 3,title",
			"Leave extra lines blank if there is no additional text,note",
			"riddle3a"=>"What is the first line of riddle 3?,text|Moradin protects this race with pride",
			"riddle3b"=>"What is the second line of riddle 3?,text|But he requires that his followers abide",
			"riddle3c"=>"What is the third line of riddle 3?,text|To never surrender and never collide.",
			"riddle3d"=>"What is the fourth line of riddle 3?,text|To which race does he provide?",
			"riddle3e"=>"What is the fifth line of riddle 3?,text|",
			"answer3"=>"What is the correct answer?,text|Dwarves",
			"reminder3"=>"Where is the answer to this question from?,text|Dwarven Mythology",
			"wrong3a"=>"What is wrong answer 1?,text|Elves",
			"wrong3b"=>"What is wrong answer 2?,text|Ogres",
			"wrong3c"=>"What is wrong answer 3?,text|Centaurs",
			"wrong3d"=>"What is wrong answer 4?,text|Giants",
			"wrong3e"=>"What is wrong answer 5?,text|Ettins",
			"wrong3f"=>"What is wrong answer 6?,text|Drow",
			"wrong3g"=>"What is wrong answer 7?,text|Hobgoblins",
			"wrong3h"=>"What is wrong answer 8?,text|Halflings",
			"wrong3i"=>"What is wrong answer 9?,text|Orcs",
			"quizzer3"=>"Person asking question 3,text|The Cleric of Moradin",
			"Question 4,title",
			"Leave extra lines blank if there is no additional text,note",
			"riddle4a"=>"What is the first line of riddle 4?,text|Some horses can fly",
			"riddle4b"=>"What is the second line of riddle 4?,text|Some have a horn",
			"riddle4c"=>"What is the third line of riddle 4?,text|But this horse has 8 legs...",
			"riddle4d"=>"What is the fourth line of riddle 4?,text|The fastest ever born.",
			"riddle4e"=>"What is the fifth line of riddle 4?,text|",
			"answer4"=>"What is the correct answer?,text|Sleipner",
			"reminder4"=>"Where is the answer to this question from?,text|Norse Mythology",
			"wrong4a"=>"What is wrong answer 1?,text|Shadowfax",
			"wrong4b"=>"What is wrong answer 2?,text|Gregnor",
			"wrong4c"=>"What is wrong answer 3?,text|Reinglaze",
			"wrong4d"=>"What is wrong answer 4?,text|Cliffnie",
			"wrong4e"=>"What is wrong answer 5?,text|Princel",
			"wrong4f"=>"What is wrong answer 6?,text|Knoplit",
			"wrong4g"=>"What is wrong answer 7?,text|Tin",
			"wrong4h"=>"What is wrong answer 8?,text|Pendleton",
			"wrong4i"=>"What is wrong answer 9?,text|Arintin",
			"quizzer4"=>"Person asking question 4,text|Hugin",
			"Question 5,title",
			"Leave extra lines blank if there is no additional text,note",
			"riddle5a"=>"What is the first line of riddle 5?,text|Few Mages would challenge",
			"riddle5b"=>"What is the second line of riddle 5?,text|This goddess whose realm is Magic.",
			"riddle5c"=>"What is the third line of riddle 5?,text|To attack her on a night with a full moon",
			"riddle5d"=>"What is the fourth line of riddle 5?,text|Would be nothing short of tragic.",
			"riddle5e"=>"What is the fifth line of riddle 5?,text|Who is this Goddess?",
			"answer5"=>"What is the correct answer?,text|Hecate",
			"reminder5"=>"Where is the answer to this question from?,text|Greek Mythology",
			"wrong5a"=>"What is wrong answer 1?,text|Hera",
			"wrong5b"=>"What is wrong answer 2?,text|Alecto",
			"wrong5c"=>"What is wrong answer 3?,text|Crius",
			"wrong5d"=>"What is wrong answer 4?,text|Coeus",
			"wrong5e"=>"What is wrong answer 5?,text|Epimetheus",
			"wrong5f"=>"What is wrong answer 6?,text|Circe",
			"wrong5g"=>"What is wrong answer 7?,text|Artemis",
			"wrong5h"=>"What is wrong answer 8?,text|Athena",
			"wrong5i"=>"What is wrong answer 9?,text|Nike",
			"quizzer5"=>"Person asking question 5,text|Hellhound",
			"Question 6,title",
			"Leave extra lines blank if there is no additional text,note",
			"riddle6a"=>"What is the first line of riddle 6?,text|There are many Gods of War",
			"riddle6b"=>"What is the second line of riddle 6?,text|For every race stuggles with pain.",
			"riddle6c"=>"What is the third line of riddle 6?,text|The Red dragon represents this God",
			"riddle6d"=>"What is the fourth line of riddle 6?,text|In Japan is where he holds his reign.",
			"riddle6e"=>"What is the fifth line of riddle 6?,text|",
			"answer6"=>"What is the correct answer?,text|Hachiman",
			"reminder6"=>"Where is the answer to this question from?,text|Japanese Mythology",
			"wrong6a"=>"What is wrong answer 1?,text|Ebisu",
			"wrong6b"=>"What is wrong answer 2?,text|Daikoku",
			"wrong6c"=>"What is wrong answer 3?,text|Amaterasu",
			"wrong6d"=>"What is wrong answer 4?,text|Raiden",
			"wrong6e"=>"What is wrong answer 5?,text|Tsukiyomi",
			"wrong6f"=>"What is wrong answer 6?,text|Yamamoto",
			"wrong6g"=>"What is wrong answer 7?,text|Susanowo",
			"wrong6h"=>"What is wrong answer 8?,text|Raiko",
			"wrong6i"=>"What is wrong answer 9?,text|Kishijoten",
			"quizzer6"=>"Person asking question 6,text|The Cricket",
			"Question 7,title",
			"Leave extra lines blank if there is no additional text,note",
			"riddle7a"=>"What is the first line of riddle 7?,text|With a head of a jackal",
			"riddle7b"=>"What is the second line of riddle 7?,text|And an evil grin",
			"riddle7c"=>"What is the third line of riddle 7?,text|To not fear this God",
			"riddle7d"=>"What is the fourth line of riddle 7?,text|May be seen as a sin.",
			"riddle7e"=>"What is the fifth line of riddle 7?,text|",
			"answer7"=>"What is the correct answer?,text|Set",
			"reminder7"=>"Where is the answer to this question from?,text|Egyptian Mythology",
			"wrong7a"=>"What is wrong answer 1?,text|Fefnut",
			"wrong7b"=>"What is wrong answer 2?,text|Shu",
			"wrong7c"=>"What is wrong answer 3?,text|Ptah",
			"wrong7d"=>"What is wrong answer 4?,text|Osiris",
			"wrong7e"=>"What is wrong answer 5?,text|Isis",
			"wrong7f"=>"What is wrong answer 6?,text|Horus",
			"wrong7g"=>"What is wrong answer 7?,text|Bes",
			"wrong7h"=>"What is wrong answer 8?,text|Geb",
			"wrong7i"=>"What is wrong answer 9?,text|Bast",
			"quizzer7"=>"Person asking question 2,text|Pharoah",
			"Question 8,title",
			"Leave extra lines blank if there is no additional text,note",
			"riddle8a"=>"What is the first line of riddle 8?,text|Perseus was able to kill Medusa,",
			"riddle8b"=>"What is the second line of riddle 8?,text|Athena will often hold this shield.",
			"riddle8c"=>"What is the third line of riddle 8?,text|If you wish to be a hero",
			"riddle8d"=>"What is the fourth line of riddle 8?,text|What is the name you will wield?",
			"riddle8e"=>"What is the fifth line of riddle 8?,text|",
			"answer8"=>"What is the correct answer?,text|Aegis",
			"reminder8"=>"Where is the answer to this question from?,text|Greek Mythology",
			"wrong8a"=>"What is wrong answer 1?,text|Tyche",
			"wrong8b"=>"What is wrong answer 2?,text|Hyperion",
			"wrong8c"=>"What is wrong answer 3?,text|Adamant",
			"wrong8d"=>"What is wrong answer 4?,text|Argos",
			"wrong8e"=>"What is wrong answer 5?,text|Hecantoncheire",
			"wrong8f"=>"What is wrong answer 6?,text|Thetis",
			"wrong8g"=>"What is wrong answer 7?,text|Chimera",
			"wrong8h"=>"What is wrong answer 8?,text|Morg",
			"wrong8i"=>"What is wrong answer 9?,text|Amphitrite",
			"quizzer8"=>"Person asking question 2,text|The Seer",
		),
		"prefs"=>array(
			"Quiz Game 2 User Preferences,title",
			"heardthis"=>"Has the player heard the opening Spiel?,bool|0",
			"current"=>"What riddle is the player currently solving?,int|0",
			"solved1"=>"Solved Riddle 1?,bool|0",
			"solved2"=>"Solved Riddle 2?,bool|0",
			"solved3"=>"Solved Riddle 3?,bool|0",
			"solved4"=>"Solved Riddle 4?,bool|0",
			"solved5"=>"Solved Riddle 5?,bool|0",
			"solved6"=>"Solved Riddle 6?,bool|0",
			"solved7"=>"Solved Riddle 7?,bool|0",
			"solved8"=>"Solved Riddle 8?,bool|0",
			"triedtoday"=>"Tried Today?,bool|0",
		),
	);
	return $info;
}

function quizgame2_install() {
	module_addhook("village");
	module_addhook("newday");
	module_addhook("newday-runonce");
	module_addhook("changesetting");
	module_addhook("bioinfo");
    module_addhook("footer-prefs");
    module_addhook("quiznav-quizload");
    module_addhook("quizload");
	return true;
}
function quizgame2_uninstall() {
	return true;
}

function quizgame2_dohook($hookname,$args) {
	global $session;
	switch($hookname) {
		case "changesetting":
			if ($args['setting'] == "villagename") {
				if ($args['old'] == get_module_setting("quizgame2loc")) set_module_setting("quizgame2loc", $args['new']);
			}
		break;
		case "quiznav-quizload":
			if (get_module_pref("solved8")==0 && get_module_setting("dkmin")<=$session['user']['dragonkills']) addnav(array("%s`0",get_module_setting("quizname")),"runmodule.php?module=quizgame2&op=quizgo");
		break;
		case "village":
			if (is_module_active('quizload')){
			}elseif (get_module_setting("dkmin")<=$session['user']['dragonkills'] && get_module_pref("solved8")==0 && $session['user']['location'] == get_module_setting("quizgame2loc")){
				tlschema($args["schemas"]["marketnav"]);
				addnav($args["marketnav"]);
				tlschema();
				addnav(array("%s Quiz`0",get_module_setting("quizname")),"runmodule.php?module=quizgame2&op=quizgo");
			}
		break;
		case "newday":
			set_module_pref("triedtoday",0);
		break;
		case "newday-runonce":
			increment_module_setting("currentlong",1);
			if (get_module_setting("resetquiz")==1){
       			$sql = "update ".db_prefix("module_userprefs")." set value=0 where value<>0 and setting='heardthis' and modulename='quizgame2'";
       			db_query($sql);
       			$sql = "update ".db_prefix("module_userprefs")." set value=0 where value<>0 and setting='triedtoday' and modulename='quizgame2'";
       			db_query($sql);				
       			$sql = "update ".db_prefix("module_userprefs")." set value=0 where value<>0 and setting='solved1' and modulename='quizgame2'";
       			db_query($sql);				
       			$sql = "update ".db_prefix("module_userprefs")." set value=0 where value<>0 and setting='solved2' and modulename='quizgame2'";
       			db_query($sql);				
       			$sql = "update ".db_prefix("module_userprefs")." set value=0 where value<>0 and setting='solved3' and modulename='quizgame2'";
       			db_query($sql);				
       			$sql = "update ".db_prefix("module_userprefs")." set value=0 where value<>0 and setting='solved4' and modulename='quizgame2'";
       			db_query($sql);				
       			$sql = "update ".db_prefix("module_userprefs")." set value=0 where value<>0 and setting='solved5' and modulename='quizgame2'";
       			db_query($sql);				
       			$sql = "update ".db_prefix("module_userprefs")." set value=0 where value<>0 and setting='solved6' and modulename='quizgame2'";
       			db_query($sql);				
       			$sql = "update ".db_prefix("module_userprefs")." set value=0 where value<>0 and setting='solved7' and modulename='quizgame2'";
       			db_query($sql);				
       			$sql = "update ".db_prefix("module_userprefs")." set value=0 where value<>0 and setting='solved8' and modulename='quizgame2'";
       			db_query($sql);				
				set_module_setting("resetquiz",0);
				set_module_setting("quizhold",0);
				set_module_setting("currentlong",0);
				set_module_setting("currentwin",0);
			}
		break;
	}
	return $args;
}

function quizgame2_run(){
	$op = httpget('op');
	global $SCRIPT_NAME;
	if ($SCRIPT_NAME == "runmodule.php"){
		$module=httpget("module");
		if ($module == "quizgame2"){
			include("modules/quizgame2/quizgame2.php");
		}
	}
}
?>