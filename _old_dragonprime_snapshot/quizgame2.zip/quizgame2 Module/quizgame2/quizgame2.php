	<?php
	$page = httpget('page');
	global $session;
	$op = httpget('op');
	page_header("The Quiz");
	$quizname=get_module_setting("quizname");
	$quizzer1=get_module_setting("quizzer1");
	if (get_module_setting("sexofq1")==0) $sexofq1="she";
	else $sexofq1="he";
	$quizzer2=get_module_setting("quizzer2");
	if (get_module_setting("sexofq2")==0) $sexofq2="she";
	else $sexofq2="he";
	$solved1=(get_module_pref("solved1"));
	$solved2=(get_module_pref("solved2"));
	$solved3=(get_module_pref("solved3"));
	$solved4=(get_module_pref("solved4"));
	$solved5=(get_module_pref("solved5"));
	$solved6=(get_module_pref("solved6"));
	$solved7=(get_module_pref("solved7"));
	$solved8=(get_module_pref("solved8"));
	$solvednum=$solved1+$solved2+$solved3+$solved4+$solved5+$solved6+$solved7+$solved8;
	$riddlenum=get_module_setting("riddlenum");
	$currentwin=get_module_setting("currentwin");
	$limitwin=get_module_setting("limitwin");
	$currentlong=get_module_setting("currentlong");
	$limitlong=get_module_setting("limitlong");	
	$titleto=get_module_setting("titleto");
	villagenav();
	if (is_module_active('quizload')) addnav("Return to Quiz HQ","runmodule.php?module=quizload&op=quizload");
if ($op=="quizgo"){
	output("`c`b`^Quiz Headquarters`b`c`n");
	output("`#`c%s`c",get_module_setting("announce1"));
	output("`c%s`c",get_module_setting("announce2"));
	output("`c%s`c",get_module_setting("announce3"));
	output("`c%s`c`0`n",get_module_setting("announce4"));
	if ($limitwin>-1 || $limitlong>-1)output("`c`b`^Additional Rules:`b`c`n");
	if ($limitwin>-1) output("`c`7This quiz will be limited to `\$%s winners`7.`c",$limitwin);
	if ($currentwin==0) output("`c`7Nobody has completed this quiz yet.`c`n");
	if ($currentwin==1) output("`c`7Only `@one person`7 has successfully completed this quiz so far.`c`n");
	if ($currentwin>1) output("`c`@%s players`7 have successfully completed the quiz.`c`n",$currentwin);
	if ($limitlong>-1) output("`cThis quiz will be open for `\$%s days`7.`c",$limitlong);
	if ($currentlong==0) output("`c`7The quiz just started `@today`7.`c`n");
	if ($curretlong==1) output("`c`7The quiz just started `@yesterday`7.`c`n");
	if ($currentlong>1) output("`c`@%s days`7 have passed since the start of this quiz.`c`n",$currentlong);
	if (get_module_pref("triedtoday")==1) {
		output("`^`c`bRiddle Attempted Today Already!`c`b`n");
		output("`#'I'm so sorry, but you're only allowed to attempt one riddle a day.");
		output("I'll see you tomorrow, okay?'`n`n");
		output("`7You hustle away, trying not to let the door hit you on your way out.");
	}else{
		if ($riddlenum==1) output("`7`cThere is only `@One Riddle`7 in this quiz.`c`n`n",$riddlenum);
		if ($riddlenum>1) output("`7`cThere are `@%s riddles`7 in this quiz.`c`n`n",$riddlenum);
		output("`c`b`^Your Progress So Far`b`n`n");
		addnav("Riddles");
		if ($solvednum==0) output("You haven't solved any riddles yet!");
		if ($solved1==0) addnav("1?Riddle 1","runmodule.php?module=quizgame2&op=riddle1");
		else output("You've solved Riddle #1`n`n");
		if ($solved2==0 && $riddlenum>1) addnav("2?Riddle 2","runmodule.php?module=quizgame2&op=riddle2");
		if ($solved2==1) output("You've solved Riddle #2`n`n");
		if ($solved3==0 && $riddlenum>2) addnav("3?Riddle 3","runmodule.php?module=quizgame2&op=riddle3");
		if ($solved3==1) output("You've solved Riddle #3`n`n");
		if ($solved4==0 && $riddlenum>3) addnav("4?Riddle 4","runmodule.php?module=quizgame2&op=riddle4");
		if ($solved4==1) output("You've solved Riddle #4`n`n");
		if ($solved5==0 && $riddlenum>4) addnav("5?Riddle 5","runmodule.php?module=quizgame2&op=riddle5");
		if ($solved5==1) output("You've solved Riddle #5`n`n");
		if ($solved6==0 && $riddlenum>5) addnav("6?Riddle 6","runmodule.php?module=quizgame2&op=riddle6");
		if ($solved6==1) output("You've solved Riddle #6`n`n");
		if ($solved7==0 && $riddlenum>6) addnav("7?Riddle 7","runmodule.php?module=quizgame2&op=riddle7");
		if ($solved7==1) output("You've solved Riddle #7`n`n");
		if ($solved8==0 && $riddlenum>7) addnav("8?Riddle 8","runmodule.php?module=quizgame2&op=riddle8");
		if ($solved8==1) output("You've solved Riddle #8`n`n");
		output("`c");
	}
}
if($op=="riddleaway"){
	if ($limitwin>-1 || $limitlong>-1)output("`c`b`^Additional Rules:`b`c`n");
	if ($limitwin>-1) output("`c`7This quiz will be limited to `\$%s winners`7.`c",$limitwin);
	if ($currentwin==0) output("`c`7Nobody has completed this quiz yet.`c`n");
	if ($currentwin==1) output("`c`7Only `@one person`7 has successfully completed this quiz so far.`c`n");
	if ($currentwin>1) output("`c`@%s players`7 have successfully completed the quiz.`c`n",$currentwin);
	if ($limitlong>-1) output("`cThis quiz will be open for `\$%s days`7.`c",$limitlong);
	if ($currentlong==0) output("`c`7The quiz just started `@today`7.`c`n");
	if ($currentlong==1) output("`c`7The quiz just started `@yesterday`7.`c`n");
	if ($currentlong>1) output("`c`@%s days`7 have passed since the start of this quiz.`c`n",$currentlong);
    output("`c`b`^Your Progress So Far`b`n`n");
    if ($solved8<7)output("`b`^(Remember, the 8th riddle will only appear after you've completed the first 7!)`b`n`n");
    addnav("Riddles");
    if ($solved8==0) output("You haven't solved any riddles yet!");
	if ($solved1==0) addnav("1?Riddle 1","runmodule.php?module=quizgame2&op=riddle1");
	else output("You've solved Riddle #1`n`n");
	if ($solved2==0) addnav("2?Riddle 2","runmodule.php?module=quizgame2&op=riddle2");
	else output("You've solved Riddle #2`n`n");
	if ($solved3==0) addnav("3?Riddle 3","runmodule.php?module=quizgame2&op=riddle3");
	else output("You've solved Riddle #3`n`n");
	if ($solved4==0) addnav("4?Riddle 4","runmodule.php?module=quizgame2&op=riddle4");
	else output("You've solved Riddle #4`n`n");
	if ($solved5==0) addnav("5?Riddle 5","runmodule.php?module=quizgame2&op=riddle5");
	else output("You've solved Riddle #5`n`n");
	if ($solved6==0) addnav("6?Riddle 6","runmodule.php?module=quizgame2&op=riddle6");
	else output("You've solved Riddle #6`n`n");
	if ($solved7==0) addnav("7?Riddle 7","runmodule.php?module=quizgame2&op=riddle7");
	else output("You've solved Riddle #7`n`n");
	if ($solved8==0) addnav("8?Riddle 8","runmodule.php?module=quizgame2&op=riddle8");
	else output("You've solved Riddle #8`n`n");
	output("`c");
}
if($op=="riddle1"){
	set_module_pref("current",1);
	output("`c`b`^Riddle #1`b`c`n");
	output("`@%s `7asks you the following riddle:`n`n",$quizzer1);	
	output("`Q%s`n",get_module_setting("riddle1a"));
	output("%s`n",get_module_setting("riddle1b"));
	output("%s`n",get_module_setting("riddle1c"));
	output("%s`n",get_module_setting("riddle1d"));
	output("%s`n",get_module_setting("riddle1e"));
	addnav("Answers");
	switch(e_rand(1,3)){
		case 1:
			addnav(array("%s",get_module_setting("wrong1a")),"runmodule.php?module=quizgame2&op=99hjk4vnkl46");
			addnav(array("%s",get_module_setting("wrong1b")),"runmodule.php?module=quizgame2&op=99hkj4nvlk46");
			addnav(array("%s",get_module_setting("wrong1c")),"runmodule.php?module=quizgame2&op=99hjknv4kl46");
			addnav(array("%s",get_module_setting("wrong1d")),"runmodule.php?module=quizgame2&op=99hkjnv4lk46");
			addnav(array("%s",get_module_setting("wrong1e")),"runmodule.php?module=quizgame2&op=99hkj4vnkl46");
			addnav(array("%s",get_module_setting("wrong1f")),"runmodule.php?module=quizgame2&op=99hjkv4nlk46");
			addnav(array("%s",get_module_setting("answer1")),"runmodule.php?module=quizgame2&op=99hkj4knvl46");
			addnav(array("%s",get_module_setting("wrong1g")),"runmodule.php?module=quizgame2&op=99hjkvn4kl46");
			addnav(array("%s",get_module_setting("wrong1h")),"runmodule.php?module=quizgame2&op=99hkjn4vlk46");
			addnav(array("%s",get_module_setting("wrong1i")),"runmodule.php?module=quizgame2&op=99hjk4nkvl46");
		break;
		case 2:
			addnav(array("%s",get_module_setting("wrong1f")),"runmodule.php?module=quizgame2&op=99hjkv4nlk46");
			addnav(array("%s",get_module_setting("wrong1c")),"runmodule.php?module=quizgame2&op=99hjknv4kl46");
			addnav(array("%s",get_module_setting("answer1")),"runmodule.php?module=quizgame2&op=99hkj4knvl46");
			addnav(array("%s",get_module_setting("wrong1d")),"runmodule.php?module=quizgame2&op=99hkjnv4lk46");
			addnav(array("%s",get_module_setting("wrong1b")),"runmodule.php?module=quizgame2&op=99hkj4nvlk46");
			addnav(array("%s",get_module_setting("wrong1i")),"runmodule.php?module=quizgame2&op=99hjk4nkvl46");
			addnav(array("%s",get_module_setting("wrong1a")),"runmodule.php?module=quizgame2&op=99hjk4vnkl46");
			addnav(array("%s",get_module_setting("wrong1h")),"runmodule.php?module=quizgame2&op=99hkjn4vlk46");
			addnav(array("%s",get_module_setting("wrong1e")),"runmodule.php?module=quizgame2&op=99hkj4vnkl46");
			addnav(array("%s",get_module_setting("wrong1g")),"runmodule.php?module=quizgame2&op=99hjkvn4kl46");
		break;
		case 3:
			addnav(array("%s",get_module_setting("wrong1d")),"runmodule.php?module=quizgame2&op=99hkjnv4lk46");
			addnav(array("%s",get_module_setting("answer1")),"runmodule.php?module=quizgame2&op=99hkj4knvl46");
			addnav(array("%s",get_module_setting("wrong1f")),"runmodule.php?module=quizgame2&op=99hjkv4nlk46");
			addnav(array("%s",get_module_setting("wrong1a")),"runmodule.php?module=quizgame2&op=99hjk4vnkl46");
			addnav(array("%s",get_module_setting("wrong1g")),"runmodule.php?module=quizgame2&op=99hjkvn4kl46");
			addnav(array("%s",get_module_setting("wrong1h")),"runmodule.php?module=quizgame2&op=99hkjn4vlk46");
			addnav(array("%s",get_module_setting("wrong1i")),"runmodule.php?module=quizgame2&op=99hjk4nkvl46");
			addnav(array("%s",get_module_setting("wrong1c")),"runmodule.php?module=quizgame2&op=99hjknv4kl46");
			addnav(array("%s",get_module_setting("wrong1b")),"runmodule.php?module=quizgame2&op=99hkj4nvlk46");
			addnav(array("%s",get_module_setting("wrong1e")),"runmodule.php?module=quizgame2&op=99hkj4vnkl46");
		break;
	}
}
if($op=="riddle2"){
	set_module_pref("current",2);
	output("`c`b`^Riddle #2`b`c`n");
	output("`c`^(You'll need to remember the %s%s letter to your answer!)`c`n",get_module_setting("letter2"),$numberpost[get_module_setting("letter2")]);
	output("`@%s `7asks you the following riddle:`n`n",$quizzer2);
	output("`Q%s`n",get_module_setting("riddle2a"));
	output("%s`n",get_module_setting("riddle2b"));
	output("%s`n",get_module_setting("riddle2c"));
	output("%s`n",get_module_setting("riddle2d"));
	output("%s`n",get_module_setting("riddle2e"));
	addnav("Answers");
	switch(e_rand(1,3)){
		case 1:
			addnav(array("%s",get_module_setting("wrong2a")),"runmodule.php?module=quizgame2&op=99hkjnv4lk46");
			addnav(array("%s",get_module_setting("wrong2b")),"runmodule.php?module=quizgame2&op=99hjkv4nlk46");
			addnav(array("%s",get_module_setting("wrong2c")),"runmodule.php?module=quizgame2&op=99hjk4vnkl46");
			addnav(array("%s",get_module_setting("wrong2d")),"runmodule.php?module=quizgame2&op=99hjkvn4kl46");
			addnav(array("%s",get_module_setting("wrong2e")),"runmodule.php?module=quizgame2&op=99hkjn4vlk46");
			addnav(array("%s",get_module_setting("wrong2f")),"runmodule.php?module=quizgame2&op=99hjk4nkvl46");
			addnav(array("%s",get_module_setting("wrong2g")),"runmodule.php?module=quizgame2&op=99hjknv4kl46");
			addnav(array("%s",get_module_setting("wrong2h")),"runmodule.php?module=quizgame2&op=99hkj4nvlk46");
			addnav(array("%s",get_module_setting("answer2")),"runmodule.php?module=quizgame2&op=99hkj4knvl46");
			addnav(array("%s",get_module_setting("wrong2i")),"runmodule.php?module=quizgame2&op=99hkj4vnkl46");
		break;
		case 2:
			addnav(array("%s",get_module_setting("answer2")),"runmodule.php?module=quizgame2&op=99hkj4knvl46");
			addnav(array("%s",get_module_setting("wrong2f")),"runmodule.php?module=quizgame2&op=99hjk4nkvl46");
			addnav(array("%s",get_module_setting("wrong2a")),"runmodule.php?module=quizgame2&op=99hkjnv4lk46");
			addnav(array("%s",get_module_setting("wrong2c")),"runmodule.php?module=quizgame2&op=99hjk4vnkl46");
			addnav(array("%s",get_module_setting("wrong2g")),"runmodule.php?module=quizgame2&op=99hjknv4kl46");
			addnav(array("%s",get_module_setting("wrong2b")),"runmodule.php?module=quizgame2&op=99hjkv4nlk46");
			addnav(array("%s",get_module_setting("wrong2h")),"runmodule.php?module=quizgame2&op=99hkj4nvlk46");
			addnav(array("%s",get_module_setting("wrong2i")),"runmodule.php?module=quizgame2&op=99hkj4vnkl46");
			addnav(array("%s",get_module_setting("wrong2d")),"runmodule.php?module=quizgame2&op=99hjkvn4kl46");
			addnav(array("%s",get_module_setting("wrong2e")),"runmodule.php?module=quizgame2&op=99hkjn4vlk46");
		break;
		case 3:
			addnav(array("%s",get_module_setting("wrong2g")),"runmodule.php?module=quizgame2&op=99hjknv4kl46");
			addnav(array("%s",get_module_setting("wrong2a")),"runmodule.php?module=quizgame2&op=99hkjnv4lk46");
			addnav(array("%s",get_module_setting("wrong2d")),"runmodule.php?module=quizgame2&op=99hjkvn4kl46");
			addnav(array("%s",get_module_setting("wrong2f")),"runmodule.php?module=quizgame2&op=99hjk4nkvl46");
			addnav(array("%s",get_module_setting("wrong2e")),"runmodule.php?module=quizgame2&op=99hkjn4vlk46");
			addnav(array("%s",get_module_setting("wrong2c")),"runmodule.php?module=quizgame2&op=99hjk4vnkl46");
			addnav(array("%s",get_module_setting("wrong2h")),"runmodule.php?module=quizgame2&op=99hkj4nvlk46");
			addnav(array("%s",get_module_setting("answer2")),"runmodule.php?module=quizgame2&op=99hkj4knvl46");
			addnav(array("%s",get_module_setting("wrong2b")),"runmodule.php?module=quizgame2&op=99hjkv4nlk46");
			addnav(array("%s",get_module_setting("wrong2i")),"runmodule.php?module=quizgame2&op=99hkj4vnkl46");
		break;
	}

}
if($op=="riddle3"){
	set_module_pref("current",3);
	output("`c`b`^Riddle #3`b`c`n");
	output("`c`^(You'll need to remember the %s%s letter to your answer!)`c`n",get_module_setting("letter3"),$numberpost[get_module_setting("letter3")]);
	output("`@%s `7asks you the following riddle:`n`n",get_module_setting("quizzer3"));
	output("`Q%s`n",get_module_setting("riddle3a"));
	output("%s`n",get_module_setting("riddle3b"));
	output("%s`n",get_module_setting("riddle3c"));
	output("%s`n",get_module_setting("riddle3d"));
	output("%s`n",get_module_setting("riddle3e"));
	addnav("Answers");
	switch(e_rand(1,3)){
		case 1:
			addnav(array("%s",get_module_setting("wrong3a")),"runmodule.php?module=quizgame2&op=99hjknv4kl46");
			addnav(array("%s",get_module_setting("wrong3b")),"runmodule.php?module=quizgame2&op=99hkjnv4lk46");
			addnav(array("%s",get_module_setting("wrong3c")),"runmodule.php?module=quizgame2&op=99hjkvn4kl46");
			addnav(array("%s",get_module_setting("wrong3d")),"runmodule.php?module=quizgame2&op=99hjk4nkvl46");
			addnav(array("%s",get_module_setting("wrong3e")),"runmodule.php?module=quizgame2&op=99hkjn4vlk46");
			addnav(array("%s",get_module_setting("wrong3f")),"runmodule.php?module=quizgame2&op=99hjk4vnkl46");
			addnav(array("%s",get_module_setting("wrong3g")),"runmodule.php?module=quizgame2&op=99hkj4nvlk46");
			addnav(array("%s",get_module_setting("answer3")),"runmodule.php?module=quizgame2&op=99hkj4knvl46");
			addnav(array("%s",get_module_setting("wrong3h")),"runmodule.php?module=quizgame2&op=99hjkv4nlk46");
			addnav(array("%s",get_module_setting("wrong3i")),"runmodule.php?module=quizgame2&op=99hkj4vnkl46");
		break;
		case 2:
			addnav(array("%s",get_module_setting("wrong3g")),"runmodule.php?module=quizgame2&op=99hkj4nvlk46");
			addnav(array("%s",get_module_setting("wrong3h")),"runmodule.php?module=quizgame2&op=99hjkv4nlk46");
			addnav(array("%s",get_module_setting("wrong3c")),"runmodule.php?module=quizgame2&op=99hjkvn4kl46");
			addnav(array("%s",get_module_setting("wrong3d")),"runmodule.php?module=quizgame2&op=99hjk4nkvl46");
			addnav(array("%s",get_module_setting("wrong3a")),"runmodule.php?module=quizgame2&op=99hjknv4kl46");
			addnav(array("%s",get_module_setting("answer3")),"runmodule.php?module=quizgame2&op=99hkj4knvl46");
			addnav(array("%s",get_module_setting("wrong3f")),"runmodule.php?module=quizgame2&op=99hjk4vnkl46");
			addnav(array("%s",get_module_setting("wrong3b")),"runmodule.php?module=quizgame2&op=99hkjnv4lk46");
			addnav(array("%s",get_module_setting("wrong3e")),"runmodule.php?module=quizgame2&op=99hkjn4vlk46");
			addnav(array("%s",get_module_setting("wrong3i")),"runmodule.php?module=quizgame2&op=99hkj4vnkl46");
		break;
		case 3:
			addnav(array("%s",get_module_setting("wrong3e")),"runmodule.php?module=quizgame2&op=99hkjn4vlk46");
			addnav(array("%s",get_module_setting("wrong3f")),"runmodule.php?module=quizgame2&op=99hjk4vnkl46");
			addnav(array("%s",get_module_setting("wrong3a")),"runmodule.php?module=quizgame2&op=99hjknv4kl46");
			addnav(array("%s",get_module_setting("wrong3d")),"runmodule.php?module=quizgame2&op=99hjk4nkvl46");
			addnav(array("%s",get_module_setting("wrong3h")),"runmodule.php?module=quizgame2&op=99hjkv4nlk46");
			addnav(array("%s",get_module_setting("wrong3g")),"runmodule.php?module=quizgame2&op=99hkj4nvlk46");
			addnav(array("%s",get_module_setting("wrong3b")),"runmodule.php?module=quizgame2&op=99hkjnv4lk46");
			addnav(array("%s",get_module_setting("wrong3i")),"runmodule.php?module=quizgame2&op=99hkj4vnkl46");		
			addnav(array("%s",get_module_setting("wrong3c")),"runmodule.php?module=quizgame2&op=99hjkvn4kl46");
			addnav(array("%s",get_module_setting("answer3")),"runmodule.php?module=quizgame2&op=99hkj4knvl46");
		break;
	}
}
if($op=="riddle4"){
	set_module_pref("current",4);
	output("`c`b`^Riddle #4`b`c`n");
	output("`c`^(You'll need to remember the %s%s letter to your answer!)`c`n",get_module_setting("letter4"),$numberpost[get_module_setting("letter4")]);
	output("`@%s `7asks you the following riddle:`n`n",get_module_setting("quizzer4"));
	output("`Q%s`n",get_module_setting("riddle4a"));
	output("%s`n",get_module_setting("riddle4b"));
	output("%s`n",get_module_setting("riddle4c"));
	output("%s`n",get_module_setting("riddle4d"));
	output("%s`n",get_module_setting("riddle4e"));
	addnav("Answers");
	switch(e_rand(1,3)){
		case 1:	
			addnav(array("%s",get_module_setting("wrong4a")),"runmodule.php?module=quizgame2&op=99hkjn4vlk46");
			addnav(array("%s",get_module_setting("wrong4b")),"runmodule.php?module=quizgame2&op=99hjk4vnkl46");
			addnav(array("%s",get_module_setting("wrong4c")),"runmodule.php?module=quizgame2&op=99hjknv4kl46");
			addnav(array("%s",get_module_setting("wrong4d")),"runmodule.php?module=quizgame2&op=99hjk4nkvl46");
			addnav(array("%s",get_module_setting("wrong4e")),"runmodule.php?module=quizgame2&op=99hjkv4nlk46");
			addnav(array("%s",get_module_setting("wrong4f")),"runmodule.php?module=quizgame2&op=99hkj4nvlk46");
			addnav(array("%s",get_module_setting("wrong4g")),"runmodule.php?module=quizgame2&op=99hkjnv4lk46");
			addnav(array("%s",get_module_setting("wrong4h")),"runmodule.php?module=quizgame2&op=99hkj4vnkl46");
			addnav(array("%s",get_module_setting("answer4")),"runmodule.php?module=quizgame2&op=99hkj4knvl46");
			addnav(array("%s",get_module_setting("wrong4i")),"runmodule.php?module=quizgame2&op=99hjkvn4kl46");
		break;
		case 2:
			addnav(array("%s",get_module_setting("wrong4f")),"runmodule.php?module=quizgame2&op=99hkj4nvlk46");
			addnav(array("%s",get_module_setting("answer4")),"runmodule.php?module=quizgame2&op=99hkj4knvl46");		
			addnav(array("%s",get_module_setting("wrong4g")),"runmodule.php?module=quizgame2&op=99hkjnv4lk46");
			addnav(array("%s",get_module_setting("wrong4e")),"runmodule.php?module=quizgame2&op=99hjkv4nlk46");
			addnav(array("%s",get_module_setting("wrong4h")),"runmodule.php?module=quizgame2&op=99hkj4vnkl46");
			addnav(array("%s",get_module_setting("wrong4a")),"runmodule.php?module=quizgame2&op=99hkjn4vlk46");
			addnav(array("%s",get_module_setting("wrong4c")),"runmodule.php?module=quizgame2&op=99hjknv4kl46");
			addnav(array("%s",get_module_setting("wrong4b")),"runmodule.php?module=quizgame2&op=99hjk4vnkl46");
			addnav(array("%s",get_module_setting("wrong4d")),"runmodule.php?module=quizgame2&op=99hjk4nkvl46");
			addnav(array("%s",get_module_setting("wrong4i")),"runmodule.php?module=quizgame2&op=99hjkvn4kl46");
		break;
		case 3:
			addnav(array("%s",get_module_setting("wrong4b")),"runmodule.php?module=quizgame2&op=99hjk4vnkl46");
			addnav(array("%s",get_module_setting("wrong4d")),"runmodule.php?module=quizgame2&op=99hjk4nkvl46");
			addnav(array("%s",get_module_setting("wrong4c")),"runmodule.php?module=quizgame2&op=99hjknv4kl46");
			addnav(array("%s",get_module_setting("answer4")),"runmodule.php?module=quizgame2&op=99hkj4knvl46");		
			addnav(array("%s",get_module_setting("wrong4g")),"runmodule.php?module=quizgame2&op=99hkjnv4lk46");
			addnav(array("%s",get_module_setting("wrong4a")),"runmodule.php?module=quizgame2&op=99hkjn4vlk46");
			addnav(array("%s",get_module_setting("wrong4h")),"runmodule.php?module=quizgame2&op=99hkj4vnkl46");
			addnav(array("%s",get_module_setting("wrong4e")),"runmodule.php?module=quizgame2&op=99hjkv4nlk46");
			addnav(array("%s",get_module_setting("wrong4f")),"runmodule.php?module=quizgame2&op=99hkj4nvlk46");
			addnav(array("%s",get_module_setting("wrong4i")),"runmodule.php?module=quizgame2&op=99hjkvn4kl46");
		break;
	}
}
if($op=="riddle5"){
	set_module_pref("current",5);
	output("`c`b`^Riddle #5`b`c`n");
	output("`c`^(You'll need to remember the %s%s letter to your answer!)`c`n",get_module_setting("letter5"),$numberpost[get_module_setting("letter5")]);
	output("`@%s `7asks you the following riddle:`n`n",get_module_setting("quizzer5"));
	output("`Q%s`n",get_module_setting("riddle5a"));
	output("%s`n",get_module_setting("riddle5b"));
	output("%s`n",get_module_setting("riddle5c"));
	output("%s`n",get_module_setting("riddle5d"));
	output("%s`n",get_module_setting("riddle5e"));
	addnav("Answers");
	switch(e_rand(1,3)){
		case 1:
			addnav(array("%s",get_module_setting("wrong5a")),"runmodule.php?module=quizgame2&op=99hjk4vnkl46");
			addnav(array("%s",get_module_setting("wrong5b")),"runmodule.php?module=quizgame2&op=99hjk4nkvl46");
			addnav(array("%s",get_module_setting("wrong5c")),"runmodule.php?module=quizgame2&op=99hjknv4kl46");
			addnav(array("%s",get_module_setting("wrong5d")),"runmodule.php?module=quizgame2&op=99hkjnv4lk46");
			addnav(array("%s",get_module_setting("wrong5e")),"runmodule.php?module=quizgame2&op=99hkjn4vlk46");
			addnav(array("%s",get_module_setting("answer5")),"runmodule.php?module=quizgame2&op=99hkj4knvl46");
			addnav(array("%s",get_module_setting("wrong5f")),"runmodule.php?module=quizgame2&op=99hkj4vnkl46");
			addnav(array("%s",get_module_setting("wrong5g")),"runmodule.php?module=quizgame2&op=99hjkv4nlk46");
			addnav(array("%s",get_module_setting("wrong5h")),"runmodule.php?module=quizgame2&op=99hkj4nvlk46");
			addnav(array("%s",get_module_setting("wrong5i")),"runmodule.php?module=quizgame2&op=99hjkvn4kl46");
		break;
		case 2:
			addnav(array("%s",get_module_setting("wrong5g")),"runmodule.php?module=quizgame2&op=99hjkv4nlk46");
			addnav(array("%s",get_module_setting("wrong5e")),"runmodule.php?module=quizgame2&op=99hkjn4vlk46");
			addnav(array("%s",get_module_setting("wrong5f")),"runmodule.php?module=quizgame2&op=99hkj4vnkl46");
			addnav(array("%s",get_module_setting("wrong5i")),"runmodule.php?module=quizgame2&op=99hjkvn4kl46");
			addnav(array("%s",get_module_setting("wrong5c")),"runmodule.php?module=quizgame2&op=99hjknv4kl46");
			addnav(array("%s",get_module_setting("wrong5b")),"runmodule.php?module=quizgame2&op=99hjk4nkvl46");
			addnav(array("%s",get_module_setting("answer5")),"runmodule.php?module=quizgame2&op=99hkj4knvl46");
			addnav(array("%s",get_module_setting("wrong5a")),"runmodule.php?module=quizgame2&op=99hjk4vnkl46");
			addnav(array("%s",get_module_setting("wrong5h")),"runmodule.php?module=quizgame2&op=99hkj4nvlk46");
			addnav(array("%s",get_module_setting("wrong5d")),"runmodule.php?module=quizgame2&op=99hkjnv4lk46");
		break;
		case 3:
			addnav(array("%s",get_module_setting("answer5")),"runmodule.php?module=quizgame2&op=99hkj4knvl46");
			addnav(array("%s",get_module_setting("wrong5c")),"runmodule.php?module=quizgame2&op=99hjknv4kl46");
			addnav(array("%s",get_module_setting("wrong5d")),"runmodule.php?module=quizgame2&op=99hkjnv4lk46");
			addnav(array("%s",get_module_setting("wrong5i")),"runmodule.php?module=quizgame2&op=99hjkvn4kl46");
			addnav(array("%s",get_module_setting("wrong5f")),"runmodule.php?module=quizgame2&op=99hkj4vnkl46");
			addnav(array("%s",get_module_setting("wrong5a")),"runmodule.php?module=quizgame2&op=99hjk4vnkl46");
			addnav(array("%s",get_module_setting("wrong5b")),"runmodule.php?module=quizgame2&op=99hjk4nkvl46");
			addnav(array("%s",get_module_setting("wrong5h")),"runmodule.php?module=quizgame2&op=99hkj4nvlk46");
			addnav(array("%s",get_module_setting("wrong5e")),"runmodule.php?module=quizgame2&op=99hkjn4vlk46");
			addnav(array("%s",get_module_setting("wrong5g")),"runmodule.php?module=quizgame2&op=99hjkv4nlk46");
		break;
	}
}
if($op=="riddle6"){
	set_module_pref("current",6);
	output("`c`b`^Riddle #6`b`c`n");
	output("`c`^(You'll need to remember the %s%s letter to your answer!)`c`n",get_module_setting("letter6"),$numberpost[get_module_setting("letter6")]);
	output("`@%s `7asks you the following riddle:`n`n",get_module_setting("quizzer6"));
	output("`Q%s`n",get_module_setting("riddle6a"));
	output("%s`n",get_module_setting("riddle6b"));
	output("%s`n",get_module_setting("riddle6c"));
	output("%s`n",get_module_setting("riddle6d"));
	output("%s`n",get_module_setting("riddle6e"));
	addnav("Answers");
	switch(e_rand(1,3)){
		case 1:	
			addnav(array("%s",get_module_setting("wrong6h")),"runmodule.php?module=quizgame2&op=99hkjn4vlk46");
			addnav(array("%s",get_module_setting("wrong6f")),"runmodule.php?module=quizgame2&op=99hjk4nkvl46");
			addnav(array("%s",get_module_setting("wrong6e")),"runmodule.php?module=quizgame2&op=99hjk4vnkl46");
			addnav(array("%s",get_module_setting("wrong6a")),"runmodule.php?module=quizgame2&op=99hjknv4kl46");
			addnav(array("%s",get_module_setting("wrong6i")),"runmodule.php?module=quizgame2&op=99hjkv4nlk46");
			addnav(array("%s",get_module_setting("wrong6b")),"runmodule.php?module=quizgame2&op=99hkjnv4lk46");
			addnav(array("%s",get_module_setting("answer6")),"runmodule.php?module=quizgame2&op=99hkj4knvl46");
			addnav(array("%s",get_module_setting("wrong6c")),"runmodule.php?module=quizgame2&op=99hjkvn4kl46");
			addnav(array("%s",get_module_setting("wrong6d")),"runmodule.php?module=quizgame2&op=99hkj4vnkl46");
			addnav(array("%s",get_module_setting("wrong6g")),"runmodule.php?module=quizgame2&op=99hkj4nvlk46");
		break;
		case 2:
			addnav(array("%s",get_module_setting("wrong6b")),"runmodule.php?module=quizgame2&op=99hkjnv4lk46");
			addnav(array("%s",get_module_setting("wrong6g")),"runmodule.php?module=quizgame2&op=99hkj4nvlk46");
			addnav(array("%s",get_module_setting("wrong6a")),"runmodule.php?module=quizgame2&op=99hjknv4kl46");
			addnav(array("%s",get_module_setting("wrong6h")),"runmodule.php?module=quizgame2&op=99hkjn4vlk46");
			addnav(array("%s",get_module_setting("wrong6e")),"runmodule.php?module=quizgame2&op=99hjk4vnkl46");
			addnav(array("%s",get_module_setting("wrong6i")),"runmodule.php?module=quizgame2&op=99hjkv4nlk46");
			addnav(array("%s",get_module_setting("wrong6f")),"runmodule.php?module=quizgame2&op=99hjk4nkvl46");
			addnav(array("%s",get_module_setting("answer6")),"runmodule.php?module=quizgame2&op=99hkj4knvl46");
			addnav(array("%s",get_module_setting("wrong6c")),"runmodule.php?module=quizgame2&op=99hjkvn4kl46");
			addnav(array("%s",get_module_setting("wrong6d")),"runmodule.php?module=quizgame2&op=99hkj4vnkl46");
		break;
		case 3:
			addnav(array("%s",get_module_setting("wrong6g")),"runmodule.php?module=quizgame2&op=99hkj4nvlk46");
			addnav(array("%s",get_module_setting("wrong6d")),"runmodule.php?module=quizgame2&op=99hkj4vnkl46");
			addnav(array("%s",get_module_setting("wrong6i")),"runmodule.php?module=quizgame2&op=99hjkv4nlk46");
			addnav(array("%s",get_module_setting("wrong6e")),"runmodule.php?module=quizgame2&op=99hjk4vnkl46");
			addnav(array("%s",get_module_setting("wrong6h")),"runmodule.php?module=quizgame2&op=99hkjn4vlk46");
			addnav(array("%s",get_module_setting("wrong6f")),"runmodule.php?module=quizgame2&op=99hjk4nkvl46");
			addnav(array("%s",get_module_setting("wrong6b")),"runmodule.php?module=quizgame2&op=99hkjnv4lk46");
			addnav(array("%s",get_module_setting("wrong6a")),"runmodule.php?module=quizgame2&op=99hjknv4kl46");
			addnav(array("%s",get_module_setting("answer6")),"runmodule.php?module=quizgame2&op=99hkj4knvl46");
			addnav(array("%s",get_module_setting("wrong6c")),"runmodule.php?module=quizgame2&op=99hjkvn4kl46");
		break;
	}	
}
if($op=="riddle7"){
	set_module_pref("current",7);
	output("`c`b`^Riddle #7`b`c`n");
	output("`c`^(You'll need to remember the %s%s letter to your answer!)`c`n",get_module_setting("letter7"),$numberpost[get_module_setting("letter7")]);
	output("`@%s `7asks you the following riddle:`n`n",get_module_setting("quizzer7"));
	output("`Q%s`n",get_module_setting("riddle7a"));
	output("%s`n",get_module_setting("riddle7b"));
	output("%s`n",get_module_setting("riddle7c"));
	output("%s`n",get_module_setting("riddle7d"));
	output("%s`n",get_module_setting("riddle7e"));
	addnav("Answers");
	switch(e_rand(1,3)){
		case 1:	
			addnav(array("%s",get_module_setting("wrong7a")),"runmodule.php?module=quizgame2&op=99hkj4nvlk46");
			addnav(array("%s",get_module_setting("wrong7b")),"runmodule.php?module=quizgame2&op=99hkj4vnkl46");
			addnav(array("%s",get_module_setting("wrong7c")),"runmodule.php?module=quizgame2&op=99hjkv4nlk46");
			addnav(array("%s",get_module_setting("wrong7d")),"runmodule.php?module=quizgame2&op=99hjk4vnkl46");
			addnav(array("%s",get_module_setting("answer7")),"runmodule.php?module=quizgame2&op=99hkj4knvl46");
			addnav(array("%s",get_module_setting("wrong7e")),"runmodule.php?module=quizgame2&op=99hkjn4vlk46");
			addnav(array("%s",get_module_setting("wrong7f")),"runmodule.php?module=quizgame2&op=99hjk4nkvl46");
			addnav(array("%s",get_module_setting("wrong7g")),"runmodule.php?module=quizgame2&op=99hkjnv4lk46");
			addnav(array("%s",get_module_setting("wrong7h")),"runmodule.php?module=quizgame2&op=99hjknv4kl46");
			addnav(array("%s",get_module_setting("wrong7i")),"runmodule.php?module=quizgame2&op=99hjkvn4kl46");
		break;
		case 2:
			addnav(array("%s",get_module_setting("wrong7b")),"runmodule.php?module=quizgame2&op=99hkj4vnkl46");
			addnav(array("%s",get_module_setting("answer7")),"runmodule.php?module=quizgame2&op=99hkj4knvl46");
			addnav(array("%s",get_module_setting("wrong7f")),"runmodule.php?module=quizgame2&op=99hjk4nkvl46");
			addnav(array("%s",get_module_setting("wrong7d")),"runmodule.php?module=quizgame2&op=99hjk4vnkl46");
			addnav(array("%s",get_module_setting("wrong7h")),"runmodule.php?module=quizgame2&op=99hjknv4kl46");
			addnav(array("%s",get_module_setting("wrong7c")),"runmodule.php?module=quizgame2&op=99hjkv4nlk46");
			addnav(array("%s",get_module_setting("wrong7a")),"runmodule.php?module=quizgame2&op=99hkj4nvlk46");
			addnav(array("%s",get_module_setting("wrong7i")),"runmodule.php?module=quizgame2&op=99hjkvn4kl46");
			addnav(array("%s",get_module_setting("wrong7e")),"runmodule.php?module=quizgame2&op=99hkjn4vlk46");
			addnav(array("%s",get_module_setting("wrong7g")),"runmodule.php?module=quizgame2&op=99hkjnv4lk46");
		break;
		case 3:
			addnav(array("%s",get_module_setting("wrong7i")),"runmodule.php?module=quizgame2&op=99hjkvn4kl46");
			addnav(array("%s",get_module_setting("wrong7f")),"runmodule.php?module=quizgame2&op=99hjk4nkvl46");
			addnav(array("%s",get_module_setting("wrong7e")),"runmodule.php?module=quizgame2&op=99hkjn4vlk46");
			addnav(array("%s",get_module_setting("wrong7d")),"runmodule.php?module=quizgame2&op=99hjk4vnkl46");
			addnav(array("%s",get_module_setting("wrong7b")),"runmodule.php?module=quizgame2&op=99hkj4vnkl46");
			addnav(array("%s",get_module_setting("answer7")),"runmodule.php?module=quizgame2&op=99hkj4knvl46");
			addnav(array("%s",get_module_setting("wrong7h")),"runmodule.php?module=quizgame2&op=99hjknv4kl46");
			addnav(array("%s",get_module_setting("wrong7c")),"runmodule.php?module=quizgame2&op=99hjkv4nlk46");
			addnav(array("%s",get_module_setting("wrong7a")),"runmodule.php?module=quizgame2&op=99hkj4nvlk46");
			addnav(array("%s",get_module_setting("wrong7g")),"runmodule.php?module=quizgame2&op=99hkjnv4lk46");
		break;
	}
}
if($op=="riddle8"){
	set_module_pref("current",8);
	output("`c`b`^Riddle #8`b`c`n");
	output("`@%s `7asks you the following riddle:`n`n",get_module_setting("quizzer7"));
	output("`Q%s`n",get_module_setting("riddle8a"));
	output("%s`n",get_module_setting("riddle8b"));
	output("%s`n",get_module_setting("riddle8c"));
	output("%s`n",get_module_setting("riddle8d"));
	output("%s`n",get_module_setting("riddle8e"));
	addnav("Answers");
	switch(e_rand(1,3)){
		case 1:	
			addnav(array("%s",get_module_setting("wrong8i")),"runmodule.php?module=quizgame2&op=99hkjnv4lk46");
			addnav(array("%s",get_module_setting("wrong8f")),"runmodule.php?module=quizgame2&op=99hjknv4kl46");
			addnav(array("%s",get_module_setting("wrong8c")),"runmodule.php?module=quizgame2&op=99hkjn4vlk46");
			addnav(array("%s",get_module_setting("wrong8d")),"runmodule.php?module=quizgame2&op=99hjk4vnkl46");
			addnav(array("%s",get_module_setting("answer8")),"runmodule.php?module=quizgame2&op=99hkj4knvl46");
			addnav(array("%s",get_module_setting("wrong8b")),"runmodule.php?module=quizgame2&op=99hjk4nkvl46");
			addnav(array("%s",get_module_setting("wrong8e")),"runmodule.php?module=quizgame2&op=99hkj4vnkl46");
			addnav(array("%s",get_module_setting("wrong8a")),"runmodule.php?module=quizgame2&op=99hjkvn4kl46");
			addnav(array("%s",get_module_setting("wrong8g")),"runmodule.php?module=quizgame2&op=99hjkv4nlk46");
			addnav(array("%s",get_module_setting("wrong8h")),"runmodule.php?module=quizgame2&op=99hkj4nvlk46");
		break;
		case 2:
			addnav(array("%s",get_module_setting("wrong8h")),"runmodule.php?module=quizgame2&op=99hkj4nvlk46");
			addnav(array("%s",get_module_setting("wrong8f")),"runmodule.php?module=quizgame2&op=99hjknv4kl46");
			addnav(array("%s",get_module_setting("wrong8b")),"runmodule.php?module=quizgame2&op=99hjk4nkvl46");
			addnav(array("%s",get_module_setting("wrong8i")),"runmodule.php?module=quizgame2&op=99hkjnv4lk46");
			addnav(array("%s",get_module_setting("answer8")),"runmodule.php?module=quizgame2&op=99hkj4knvl46");
			addnav(array("%s",get_module_setting("wrong8a")),"runmodule.php?module=quizgame2&op=99hjkvn4kl46");
			addnav(array("%s",get_module_setting("wrong8e")),"runmodule.php?module=quizgame2&op=99hkj4vnkl46");
			addnav(array("%s",get_module_setting("wrong8d")),"runmodule.php?module=quizgame2&op=99hjk4vnkl46");
			addnav(array("%s",get_module_setting("wrong8g")),"runmodule.php?module=quizgame2&op=99hjkv4nlk46");
			addnav(array("%s",get_module_setting("wrong8c")),"runmodule.php?module=quizgame2&op=99hkjn4vlk46");
		break;
		case 3:
			addnav(array("%s",get_module_setting("wrong8b")),"runmodule.php?module=quizgame2&op=99hjk4nkvl46");
			addnav(array("%s",get_module_setting("wrong8f")),"runmodule.php?module=quizgame2&op=99hjknv4kl46");
			addnav(array("%s",get_module_setting("wrong8e")),"runmodule.php?module=quizgame2&op=99hkj4vnkl46");
			addnav(array("%s",get_module_setting("wrong8a")),"runmodule.php?module=quizgame2&op=99hjkvn4kl46");
			addnav(array("%s",get_module_setting("wrong8h")),"runmodule.php?module=quizgame2&op=99hkj4nvlk46");
			addnav(array("%s",get_module_setting("wrong8d")),"runmodule.php?module=quizgame2&op=99hjk4vnkl46");
			addnav(array("%s",get_module_setting("wrong8i")),"runmodule.php?module=quizgame2&op=99hkjnv4lk46");
			addnav(array("%s",get_module_setting("answer8")),"runmodule.php?module=quizgame2&op=99hkj4knvl46");
			addnav(array("%s",get_module_setting("wrong8c")),"runmodule.php?module=quizgame2&op=99hkjn4vlk46");
			addnav(array("%s",get_module_setting("wrong8g")),"runmodule.php?module=quizgame2&op=99hjkv4nlk46");
		break;
	}
}
if($op=="99hjk4vnkl46" || $op=="99hkj4nvlk46" || $op=="99hjknv4kl46" || $op=="99hkjnv4lk46" || $op=="99hkj4vnkl46" || $op=="99hjkv4nlk46" || $op=="99hjkvn4kl46" || $op=="99hkjn4vlk46" || $op=="99hjk4nkvl46" ){
	output("`c`b`^Wrong Answer!`#`c`b`n");
	switch(e_rand(1,9)){
		case 1:
			output("Good heavens, did you really think that was the answer?!? No more ale for you!");
		break;
		case 2:
			output("What? You're kidding right? Maybe you should try again, next time with your eyes open.");
		break;
		case 3:
			output("Come on now! An imp could do better than that! Really, they have!");
		break;
		case 4:
			output("I'm sure that was just a silly accident right? That wasn't really your guess, was it?");
		break;
		case 5:
			output("Don't worry, lots of people make mistakes...  usually not that bad though... but hey, now you're the best at something!");
		break;
		case 6:
			output("It's obvious that you aren't giving this your best shot.");
		break;
		case 7:
			output("Bummer...that answer sucketh. Don't you know anything?");
		break;
		case 8:
			output("Hello? Are we awake? That is so wrong!  Why not try laying off those funny mushrooms!");
		break;
		case 9:
			output("Apparently someone hasn't had their daily supply of chocolate.  That answer was so very wrong!");
		break;
	}
	output("`n`nTry again tomorrow!");
	set_module_pref("triedtoday",1);
}
if($op=="99hkj4knvl46"){
	set_module_pref("triedtoday",1);
	if (get_module_pref("current")==1) set_module_pref("solved1",1);
	if (get_module_pref("current")==2) set_module_pref("solved2",1);
	if (get_module_pref("current")==3) set_module_pref("solved3",1);
	if (get_module_pref("current")==4) set_module_pref("solved4",1);
	if (get_module_pref("current")==5) set_module_pref("solved5",1);
	if (get_module_pref("current")==6) set_module_pref("solved6",1);
	if (get_module_pref("current")==7) set_module_pref("solved7",1);
	if (get_module_pref("current")==8) set_module_pref("solved8",1);
	if ($solvednum>=(get_module_setting("riddlenum")-1)){
		addnews("%s `7has solved the `@%s `7and won a prize!!!",$session['user']['name'],$quizname);
		output("`c`b`^%s Solved!`c`b`n`n",$quizname);
		output("Excellent! You have answered all the riddles for this quiz correctly.`n`n");
		output("`@%s`7 smiles at you. `#'Congratulations!",$quizzer1);
		output("You've solved the %s.",$quizname);
		if (get_module_setting("titleyes")==1) {
			blocknav ("village.php");
			blocknav ("runmodule.php?module=quizgame2&op=quizgame2");
			output("Your first award is the option of changing your title to '%s'.  Would you like that?'`n`n",$titleto);
			output("`@Yes`7, I would like the title of %s`n",$titleto);
			output("`\$No`7, I would like to keep my current title`n");
			addnav(array("Yes, Make Me %s",$titleto),"runmodule.php?module=quizgame2&op=titleyes");
			addnav("No, Leave My Title Alone","runmodule.php?module=quizgame2&op=titleno");
		}else{
			quizgame2_correct();
		}
	}else{
		output("`c`b`^Right Answer!`c`b`n");
		output("`#Congratulations! You did it, you've answered that riddle correctly!`n`n");
		output("See you tomorrow for another riddle!");
	}
}
if($op=="titleyes"){
	$newname = change_player_title($titleto);
	$session['user']['title'] = $titleto;
	$session['user']['name'] = $newname;
	output("`c`b`^Riddle Quiz Solved!`c`b`n`n");
	output("`@%s`7 presents you with your new title. `#'And now for the rest of the award!'`n`n",$quizzer1);
	quizgame2_correct();
}
if($op=="titleno"){
	output("`c`b`^Riddle Quiz Solved!`c`b`n`n");
	output("`7You decide to keep your old title and look at `@%s`7 with anticipation.  Then %s turns to `@%s`7  excitedly...  `#'Get the Reward!'`n`n",$quizzer1,$sexofq1,$quizzer2);
	quizgame2_correct();
}
function quizgame2_wrongans(){
	output("`c`b`^Wrong Answer!`#`c`b`n");
	switch(e_rand(1,9)){
		case 1:
			output("Good heavens, did you really think that was the answer?!? No more ale for you!");
		break;
		case 2:
			output("What? You're kidding right? Maybe you should try again, next time with your eyes open.");
		break;
		case 3:
			output("Come on now! An imp could do better than that! Really, they have!");
		break;
		case 4:
			output("I'm sure that was just a silly accident right? That wasn't really your guess, was it?");
		break;
		case 5:
			output("Don't worry, lots of people make mistakes...  usually not that bad though... but hey, now you're the best at something!");
		break;
		case 6:
			output("It's obvious that you aren't giving this your best shot.");
		break;
		case 7:
			output("Bummer...that answer sucketh. Don't you know anything?");
		break;
		case 8:
			output("Hello? Are we awake? That is so wrong!  Why not try laying off those funny mushrooms!");
		break;
		case 9:
			output("Apparently someone hasn't had their daily supply of chocolate.  That answer was so very wrong!");
		break;
	}
	output("`n`nTry again tomorrow!");
}
function quizgame2_correct(){
	global $session;
	$gems=get_module_setting("gemaward");
	$gold=get_module_setting("goldaward");
	$quizzer1=get_module_setting("quizzer1");
	$quizname=get_module_setting("quizname");
	output("`7With a happy smirk you accept your reward from `@%s`7 and count your bounty.`n`n",$quizzer1);
	if ($gems>0 && $gold>0){
		output("You gain");
		if ($gems==1) output("`%one gem");
		else output("`%%s gems",$gems);
		if ($gold==1) output("`7and `^one stinky little gold piece");
		else output("`7and `^%s gold",$gold);
		output("`7for completing the `#%s`7.",$quizname);
		debuglog("gained %s gems by completing the Quiz.",$gems);
	}
	if ($gems<=0 && $gold>0){
		output("You gain");
		if ($gold==1) output("`^one stinky little gold piece");
		else output("`^%s gold",$gold);
		output("`7for completing the `#%s`7.",$quizname);
		debuglog("gained %s gold by completing the Quiz.",$gold);
	}
	if ($gems>0 && $gold<=0){
		output("You gain");
		if ($gems==1) output("`%one gem");
		else output("`%%s gems",$gems);
		output("`7for completing the `#%s`7.",$quizname);
		debuglog("gained %s gems and %s gold by completing the Quiz.",$gems,$gold);
	}
	if ($gems<=0 && $gold<=0){
		output("Hey wait! The bag is empty.  It appears that the Quiz Coffers are a bit low on funds.  Perhaps the next quiz will offer a better award.");
		debuglog("completed The Quiz but no award was offered.");
	}
	output("`n`n`c`b`^Congratulations!`c`b`n`n");
	set_module_pref("solved8",1);
	increment_module_setting("currentwin",1);
	if (is_module_active("quizgame2")){ 
		increment_module_pref("quiztotal",1,"quizgame2");
		$i=get_module_pref("quiztotal","quizgame2");
		if ($i>20) $i=1;
		set_module_pref("quizsolv".$i,$quizname,"quizgame2");
	}
	if ($gems>0) $session['user']['gems']+=$gems;
	if ($gold>0) $session['user']['gold']+=$gold;
}
page_footer();
?>