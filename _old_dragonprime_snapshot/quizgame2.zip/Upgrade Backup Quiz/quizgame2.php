<?php

function quizgame2_getmoduleinfo(){
	$info = array(
		"name"=>"Quiz Game 2: Gods and Goddesses UPGRADE BACKUP",
		"version"=>"3.0",
		"author"=>"DaveS",
		"category"=>"Village",
		"download"=>"",
		"requires"=>array(
			"quizload"=>"Quiz Loader by DaveS",
		),
	);
	return $info;
}
function quizgame2_install(){
	set_module_setting("quiznamea","Gods and Goddesses","quizload");
	set_module_setting("announce1a","Do not play lightly with Gods","quizload");
	set_module_setting("announce2a","For they do not like the weak.","quizload");
	set_module_setting("announce3a","You must answer with care","quizload");
	set_module_setting("announce4a","And with reverence you must speak.","quizload");
	set_module_setting("riddlenuma",8,"quizload");
	set_module_setting("titletoa","TheDivine","quizload");
	set_module_setting("riddle1aa","The Druids prayed to Gods of old","quizload");
	set_module_setting("riddle1bb","And Legends grew of which you're told","quizload");
	set_module_setting("riddle1cc","This God was known for his healing skills","quizload");
	set_module_setting("riddle1dd","In Celtic lore he cured all ills.","quizload");
	set_module_setting("riddle1ee","Which God do I speak of?","quizload");
	set_module_setting("answer11","Diancecht","quizload");
	set_module_setting("wrong1aa","Arawn","quizload");
	set_module_setting("wrong1bb","Dagda","quizload");
	set_module_setting("wrong1cc","Brigit","quizload");
	set_module_setting("wrong1dd","Cu Chulainn","quizload");
	set_module_setting("wrong1ee","Oghma","quizload");
	set_module_setting("wrong1ff","Nuada","quizload");
	set_module_setting("wrong1gg","Morrigan","quizload");
	set_module_setting("wrong1hh","Lugh","quizload");
	set_module_setting("wrong1ii","Silvanus","quizload");
	set_module_setting("reminder1a","Celtic Mythology","quizload");
	set_module_setting("quizzer11","Druid  Doug","quizload");
	set_module_setting("sexofq11",1,"quizload");
	set_module_setting("riddle2aa","In Central America the Gods held sway","quizload");
	set_module_setting("riddle2bb","And molded lives and influenced the day.","quizload");
	set_module_setting("riddle2cc","But death was controlled without sparring the rod","quizload");
	set_module_setting("riddle2dd","The ruler of the afterlife was this god.","quizload");
	set_module_setting("riddle2ee"," ","quizload");
	set_module_setting("answer21","Mictlantecuhtli","quizload");
	set_module_setting("wrong2aa","Itzamna","quizload");
	set_module_setting("wrong2bb","Quetzalcoatl","quizload");
	set_module_setting("wrong2cc","Camazotz","quizload");
	set_module_setting("wrong2dd","Huhueteotl","quizload");
	set_module_setting("wrong2ee","Chalchiuhtlicue","quizload");
	set_module_setting("wrong2ff","Camaxtli","quizload");
	set_module_setting("wrong2gg","Huitzipochtli","quizload");
	set_module_setting("wrong2hh","Tlaloc","quizload");
	set_module_setting("wrong2ii","Tezcatlipoca","quizload");
	set_module_setting("reminder2a","Central American Mythology","quizload");
	set_module_setting("quizzer21","Eagle","quizload");
	set_module_setting("riddle3aa","Moradin protects this race with pride","quizload");
	set_module_setting("riddle3bb","But he requires that his followers abide","quizload");
	set_module_setting("riddle3cc","To never surrender and never collide.","quizload");
	set_module_setting("riddle3dd","To which race does he provide?","quizload");
	set_module_setting("riddle3ee"," ","quizload");
	set_module_setting("answer31","Dwarves","quizload");
	set_module_setting("wrong3aa","Elves","quizload");
	set_module_setting("wrong3bb","Ogres","quizload");
	set_module_setting("wrong3cc","Centaurs","quizload");
	set_module_setting("wrong3dd","Giants","quizload");
	set_module_setting("wrong3ee","Ettins","quizload");
	set_module_setting("wrong3ff","Drow","quizload");
	set_module_setting("wrong3gg","Hobgoblins","quizload");
	set_module_setting("wrong3hh","Halflings","quizload");
	set_module_setting("wrong3ii","Orcs","quizload");
	set_module_setting("reminder3a","Dwarf Mythology","quizload");
	set_module_setting("quizzer31","The Cleric of Moradin","quizload");
	set_module_setting("riddle4aa","Some horses can fly","quizload");
	set_module_setting("riddle4bb","Some have a horn","quizload");
	set_module_setting("riddle4cc","But this horse has 8 legs...","quizload");
	set_module_setting("riddle4dd","The fastest ever born.","quizload");
	set_module_setting("riddle4ee"," ","quizload");
	set_module_setting("answer41","Sleipner","quizload");
	set_module_setting("wrong4aa","Shadowfax","quizload");
	set_module_setting("wrong4bb","Gregnor","quizload");
	set_module_setting("wrong4cc","Reinglaze","quizload");
	set_module_setting("wrong4dd","Cliffnie","quizload");
	set_module_setting("wrong4ee","Princel","quizload");
	set_module_setting("wrong4ff","Knoplit","quizload");
	set_module_setting("wrong4gg","Tin","quizload");
	set_module_setting("wrong4hh","Pendleton","quizload");
	set_module_setting("wrong4ii","Arintin","quizload");
	set_module_setting("reminder4a","Norse Mythology","quizload");
	set_module_setting("quizzer41","Hugin","quizload");
	set_module_setting("riddle5aa","Few Mages would challenge","quizload");
	set_module_setting("riddle5bb","This goddess whose realm is Magic.","quizload");
	set_module_setting("riddle5cc","To attack her on a night with a full moon","quizload");
	set_module_setting("riddle5dd","Would be nothing short of tragic.","quizload");
	set_module_setting("riddle5ee","Who is this Goddess?","quizload");
	set_module_setting("answer51","Hecate","quizload");
	set_module_setting("wrong5aa","Hera","quizload");
	set_module_setting("wrong5bb","Alecto","quizload");
	set_module_setting("wrong5cc","Crius","quizload");
	set_module_setting("wrong5dd","Coeus","quizload");
	set_module_setting("wrong5ee","Epimetheus","quizload");
	set_module_setting("wrong5ff","Circe","quizload");
	set_module_setting("wrong5gg","Artemis","quizload");
	set_module_setting("wrong5hh","Athena","quizload");
	set_module_setting("wrong5ii","Nike","quizload");
	set_module_setting("reminder5a","Greek Mythology","quizload");
	set_module_setting("quizzer51","Hellhound","quizload");
	set_module_setting("riddle6aa","There are many Gods of War","quizload");
	set_module_setting("riddle6bb","For every race stuggles with pain.","quizload");
	set_module_setting("riddle6cc","The Red dragon represents this God","quizload");
	set_module_setting("riddle6dd","In Japan is where he holds his reign.","quizload");
	set_module_setting("riddle6ee"," ","quizload");
	set_module_setting("answer61","Hachiman","quizload");
	set_module_setting("wrong6aa","Ebisu","quizload");
	set_module_setting("wrong6bb","Daikoku","quizload");
	set_module_setting("wrong6cc","Amaterasu","quizload");
	set_module_setting("wrong6dd","Raiden","quizload");
	set_module_setting("wrong6ee","Tsukiyomi","quizload");
	set_module_setting("wrong6ff","Yamamoto","quizload");
	set_module_setting("wrong6gg","Susanowo","quizload");
	set_module_setting("wrong6hh","Raiko","quizload");
	set_module_setting("wrong6ii","Kishijoten","quizload");
	set_module_setting("reminder6a","Japanese Mythology","quizload");
	set_module_setting("quizzer61","The Cricket","quizload");
	set_module_setting("riddle7aa","With a head of a jackal","quizload");
	set_module_setting("riddle7bb","And an evil grin","quizload");
	set_module_setting("riddle7cc","To not fear this God","quizload");
	set_module_setting("riddle7dd","May be seen as a sin.","quizload");
	set_module_setting("riddle7ee"," ","quizload");
	set_module_setting("answer71","Set","quizload");
	set_module_setting("wrong7aa","Fefnut","quizload");
	set_module_setting("wrong7bb","Shu","quizload");
	set_module_setting("wrong7cc","Ptah","quizload");
	set_module_setting("wrong7dd","Osiris","quizload");
	set_module_setting("wrong7ee","Isis","quizload");
	set_module_setting("wrong7ff","Horus","quizload");
	set_module_setting("wrong7gg","Bes","quizload");
	set_module_setting("wrong7hh","Geb","quizload");
	set_module_setting("wrong7ii","Bast","quizload");
	set_module_setting("reminder7a","Egyptian Mythology","quizload");
	set_module_setting("quizzer71","Pharoah","quizload");
	set_module_setting("riddle8aa","Perseus was able to kill Medusa,","quizload");
	set_module_setting("riddle8bb","Athena will often hold this shield.","quizload");
	set_module_setting("riddle8cc","If you wish to be a hero","quizload");
	set_module_setting("riddle8dd","What is the name you will wield?","quizload");
	set_module_setting("riddle8ee"," ","quizload");
	set_module_setting("answer81","Aegis","quizload");
	set_module_setting("wrong8aa","Tyche","quizload");
	set_module_setting("wrong8bb","Hyperion","quizload");
	set_module_setting("wrong8cc","Adamant","quizload");
	set_module_setting("wrong8dd","Argos","quizload");
	set_module_setting("wrong8ee","Hecantoncheire","quizload");
	set_module_setting("wrong8ff","Thetis","quizload");
	set_module_setting("wrong8gg","Chimera","quizload");
	set_module_setting("wrong8hh","Morg","quizload");
	set_module_setting("wrong8ii","Amphitrite","quizload");
	set_module_setting("reminder8a","Greek Mythology","quizload");
	set_module_setting("quizzer81","The Seer","quizload");
	output("Quizload.php has been upgraded.`n`n");
	output("You may now uninstall this module. You `\$DO NOT`0 need to activate it.`n`n");
	return true;
}
function quizgame2_uninstall(){
	return true;
}
function quizgame2_dohook($hookname,$args){
	return $args;
}
function quizgame2_run(){
}
?>