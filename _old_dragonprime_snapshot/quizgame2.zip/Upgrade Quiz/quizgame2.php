<?php
function quizgame2_getmoduleinfo(){
	$info = array(
		"name"=>"Quiz Game 2: Gods and Goddesses UPGRADE",
		"version"=>"3.0",
		"author"=>"DaveS",
		"category"=>"Village",
		"download"=>"",
		"requires"=>array(
			"quizload"=>"Quiz Loader by DaveS",
		),
	);
	return $info;
}
function quizgame2_install(){
	set_module_setting("quizname","Gods and Goddesses","quizload");
	set_module_setting("announce1","Do not play lightly with Gods","quizload");
	set_module_setting("announce2","For they do not like the weak.","quizload");
	set_module_setting("announce3","You must answer with care","quizload");
	set_module_setting("announce4","And with reverence you must speak.","quizload");
	set_module_setting("riddlenum",8,"quizload");
	set_module_setting("titleto","TheDivine","quizload");
	set_module_setting("riddle1a","The Druids prayed to Gods of old","quizload");
	set_module_setting("riddle1b","And Legends grew of which you're told","quizload");
	set_module_setting("riddle1c","This God was known for his healing skills","quizload");
	set_module_setting("riddle1d","In Celtic lore he cured all ills.","quizload");
	set_module_setting("riddle1e","Which God do I speak of?","quizload");
	set_module_setting("answer1","Diancecht","quizload");
	set_module_setting("wrong1a","Arawn","quizload");
	set_module_setting("wrong1b","Dagda","quizload");
	set_module_setting("wrong1c","Brigit","quizload");
	set_module_setting("wrong1d","Cu Chulainn","quizload");
	set_module_setting("wrong1e","Oghma","quizload");
	set_module_setting("wrong1f","Nuada","quizload");
	set_module_setting("wrong1g","Morrigan","quizload");
	set_module_setting("wrong1h","Lugh","quizload");
	set_module_setting("wrong1i","Silvanus","quizload");
	set_module_setting("reminder","Celtic Mythology","quizload");
	set_module_setting("quizzer","Druid Doug","quizload");
	set_module_setting("sexofq1",1,"quizload");
	set_module_setting("riddle2a","In Central America the Gods held sway","quizload");
	set_module_setting("riddle2b","And molded lives and influenced the day.","quizload");
	set_module_setting("riddle2c","But death was controlled without sparring the rod","quizload");
	set_module_setting("riddle2d","The ruler of the afterlife was this god.","quizload");
	set_module_setting("riddle2e"," ","quizload");
	set_module_setting("answer2","Mictlantecuhtli","quizload");
	set_module_setting("wrong2a","Itzamna","quizload");
	set_module_setting("wrong2b","Quetzalcoatl","quizload");
	set_module_setting("wrong2c","Camazotz","quizload");
	set_module_setting("wrong2d","Huhueteotl","quizload");
	set_module_setting("wrong2e","Chalchiuhtlicue","quizload");
	set_module_setting("wrong2f","Camaxtli","quizload");
	set_module_setting("wrong2g","Huitzipochtli","quizload");
	set_module_setting("wrong2h","Tlaloc","quizload");
	set_module_setting("wrong2i","Tezcatlipoca","quizload");
	set_module_setting("reminder2","Central American Mythology","quizload");
	set_module_setting("quizzer2","Eagle","quizload");
	set_module_setting("riddle3a","Moradin protects this race with pride","quizload");
	set_module_setting("riddle3b","But he requires that his followers abide","quizload");
	set_module_setting("riddle3c","To never surrender and never collide.","quizload");
	set_module_setting("riddle3d","To which race does he provide?","quizload");
	set_module_setting("riddle3e"," ","quizload");
	set_module_setting("answer3","Dwarves","quizload");
	set_module_setting("wrong3a","Elves","quizload");
	set_module_setting("wrong3b","Ogres","quizload");
	set_module_setting("wrong3c","Centaurs","quizload");
	set_module_setting("wrong3d","Giants","quizload");
	set_module_setting("wrong3e","Ettins","quizload");
	set_module_setting("wrong3f","Drow","quizload");
	set_module_setting("wrong3g","Hobgoblins","quizload");
	set_module_setting("wrong3h","Halflings","quizload");
	set_module_setting("wrong3i","Orcs","quizload");
	set_module_setting("reminder3","Dwarf Mythology","quizload");
	set_module_setting("quizzer3","The Cleric of Moradin","quizload");
	set_module_setting("riddle4a","Some horses can fly","quizload");
	set_module_setting("riddle4b","Some have a horn","quizload");
	set_module_setting("riddle4c","But this horse has 8 legs...","quizload");
	set_module_setting("riddle4d","The fastest ever born.","quizload");
	set_module_setting("riddle4e"," ","quizload");
	set_module_setting("answer4","Sleipner","quizload");
	set_module_setting("wrong4a","Shadowfax","quizload");
	set_module_setting("wrong4b","Gregnor","quizload");
	set_module_setting("wrong4c","Reinglaze","quizload");
	set_module_setting("wrong4d","Cliffnie","quizload");
	set_module_setting("wrong4e","Princel","quizload");
	set_module_setting("wrong4f","Knoplit","quizload");
	set_module_setting("wrong4g","Tin","quizload");
	set_module_setting("wrong4h","Pendleton","quizload");
	set_module_setting("wrong4i","Arintin","quizload");
	set_module_setting("reminder4","Norse Mythology","quizload");
	set_module_setting("quizzer4","Hugin","quizload");
	set_module_setting("riddle5a","Few Mages would challenge","quizload");
	set_module_setting("riddle5b","This goddess whose realm is Magic.","quizload");
	set_module_setting("riddle5c","To attack her on a night with a full moon","quizload");
	set_module_setting("riddle5d","Would be nothing short of tragic.","quizload");
	set_module_setting("riddle5e","Who is this Goddess?","quizload");
	set_module_setting("answer5","Hecate","quizload");
	set_module_setting("wrong5a","Hera","quizload");
	set_module_setting("wrong5b","Alecto","quizload");
	set_module_setting("wrong5c","Crius","quizload");
	set_module_setting("wrong5d","Coeus","quizload");
	set_module_setting("wrong5e","Epimetheus","quizload");
	set_module_setting("wrong5f","Circe","quizload");
	set_module_setting("wrong5g","Artemis","quizload");
	set_module_setting("wrong5h","Athena","quizload");
	set_module_setting("wrong5i","Nike","quizload");
	set_module_setting("reminder5","Greek Mythology","quizload");
	set_module_setting("quizzer5","Hellhound","quizload");
	set_module_setting("riddle6a","There are many Gods of War","quizload");
	set_module_setting("riddle6b","For every race stuggles with pain.","quizload");
	set_module_setting("riddle6c","The Red dragon represents this God","quizload");
	set_module_setting("riddle6d","In Japan is where he holds his reign.","quizload");
	set_module_setting("riddle6e"," ","quizload");
	set_module_setting("answer6","Hachiman","quizload");
	set_module_setting("wrong6a","Ebisu","quizload");
	set_module_setting("wrong6b","Daikoku","quizload");
	set_module_setting("wrong6c","Amaterasu","quizload");
	set_module_setting("wrong6d","Raiden","quizload");
	set_module_setting("wrong6e","Tsukiyomi","quizload");
	set_module_setting("wrong6f","Yamamoto","quizload");
	set_module_setting("wrong6g","Susanowo","quizload");
	set_module_setting("wrong6h","Raiko","quizload");
	set_module_setting("wrong6i","Kishijoten","quizload");
	set_module_setting("reminder6","Japanese Mythology","quizload");
	set_module_setting("quizzer6","The Cricket","quizload");
	set_module_setting("riddle7a","With a head of a jackal","quizload");
	set_module_setting("riddle7b","And an evil grin","quizload");
	set_module_setting("riddle7c","To not fear this God","quizload");
	set_module_setting("riddle7d","May be seen as a sin.","quizload");
	set_module_setting("riddle7e"," ","quizload");
	set_module_setting("answer7","Set","quizload");
	set_module_setting("wrong7a","Fefnut","quizload");
	set_module_setting("wrong7b","Shu","quizload");
	set_module_setting("wrong7c","Ptah","quizload");
	set_module_setting("wrong7d","Osiris","quizload");
	set_module_setting("wrong7e","Isis","quizload");
	set_module_setting("wrong7f","Horus","quizload");
	set_module_setting("wrong7g","Bes","quizload");
	set_module_setting("wrong7h","Geb","quizload");
	set_module_setting("wrong7i","Bast","quizload");
	set_module_setting("reminder7","Egyptian Mythology","quizload");
	set_module_setting("quizzer7","Pharoah","quizload");
	set_module_setting("riddle8a","Perseus was able to kill Medusa,","quizload");
	set_module_setting("riddle8b","Athena will often hold this shield.","quizload");
	set_module_setting("riddle8c","If you wish to be a hero","quizload");
	set_module_setting("riddle8d","What is the name you will wield?","quizload");
	set_module_setting("riddle8e"," ","quizload");
	set_module_setting("answer8","Aegis","quizload");
	set_module_setting("wrong8a","Tyche","quizload");
	set_module_setting("wrong8b","Hyperion","quizload");
	set_module_setting("wrong8c","Adamant","quizload");
	set_module_setting("wrong8d","Argos","quizload");
	set_module_setting("wrong8e","Hecantoncheire","quizload");
	set_module_setting("wrong8f","Thetis","quizload");
	set_module_setting("wrong8g","Chimera","quizload");
	set_module_setting("wrong8h","Morg","quizload");
	set_module_setting("wrong8i","Amphitrite","quizload");
	set_module_setting("reminder8","Greek Mythology","quizload");
	set_module_setting("quizzer8","The Seer","quizload");
	output("`b`n`nQuizload.php has been upgraded.`n`n");
	output("You may now uninstall this module. You `\$DO NOT`0 need to activate it.`b`n`n");
	return true;
}
function quizgame2_uninstall(){
	return true;
}
function quizgame2_dohook($hookname,$args){
	return $args;
}
function quizgame2_run(){
}
?>