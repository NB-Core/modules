<?php
/**
 * flirt.php - Flirt with Others module for Legend of the Green Dragon 0.9.8+
 * by James M Burke (jburke -at- jbctech -dot- com)
 * Version 1.01 released on November 17, 2004
 * Slight Modifications by: Kevin Hatfield - Arune
 */
require_once("lib/http.php");

function flirt_getmoduleinfo(){
   $info = array(
      "name"=>"Flirt with Others",
      "author"=>"James M Burke Updated by <a href=\"http://logd.ecsportal.com\" target=_new>Arune - Kevin Hatfield</a>",
      "version"=>"1.02",
      "category"=>"Inn",
      "download"=>"http://dragonprime.net/users/khatfield/flirt.zip",
      "prefs"=>array(
         "Flirt with Others User Preferences,title",
         "hasflirted"=>"Has Flirted,bool|0",
         "flirtfromname"=>"Incoming Flirt From,int|0",
         "flirtfromtype"=>"Incoming Flirt Type,int|0",
         "flirttoname"=>"Outgoing Flirt To,int|0",
         "flirttotype"=>"Outgoing Flirt Type,int|0",
         "flirttoresult"=>"Outgoing Flirt Result,int|0"
      )
   );
   return $info;
}

function flirt_install(){
   module_addhook("inn");
   module_addhook("newday");
   module_addhook("village");
   return true;
}

function flirt_uninstall(){
   return true;
}

function flirt_dohook($hookname, $args){
   global $session;

   switch($hookname){	
      case "newday":
         set_module_pref("hasflirted",0);
         break;
      case "inn":
         addnav("Things to do");
         addnav("Flirt with Others", "runmodule.php?module=flirt&from=inn");
         break;
      case "village":
         addnav($args['infonav']);
         addnav("Conjugality List", "runmodule.php?module=flirt&from=village");
         break;
   }
   return $args;
}

function flirt_run(){
   global $session;
   require_once("lib/villagenav.php");

   switch(httpget('from')){
      case "inn":
         page_header("Flirt with Other Players");
         $canflirt = !get_module_pref("hasflirted");
         $op = httpget('op');
         if ($session['user']['marriedto']!=0 && ($op!="divorce"))
         {
            addnav("D?Divorce","runmodule.php?module=flirt&from=inn&op=divorce");
            addnav("I?Return to the Inn","inn.php");
            if ($session['user']['marriedto']==4294967295) 
            {
               output ("`2 You cheater!  You cannot flirt with other players...you must remain faithful to %s `2 !!",$session['user']['sex']?"`@Seth":"`%Violet");
            }else{
               $sql = "SELECT name FROM ".db_prefix("accounts")." WHERE acctid=".$session['user']['marriedto'];
               $result = db_query($sql) or die(sql_error($sql));
               $row=db_fetch_assoc($result);
               output ("`2 You cheater!  You cannot flirt with other players...you must remain faithful to `@ %s `2 !!",$row['name']);
            }
			page_footer();
         }
         else
         {
            if (get_module_pref("flirtfromname")!=0 && $op==""){
               $sql = "SELECT acctid,name,charm,sex FROM ".db_prefix("accounts")." WHERE acctid=".get_module_pref("flirtfromname");
               $result = db_query($sql) or die(sql_error($sql));
               $row=db_fetch_assoc($result);
               output (" `2Romantic Message from `@%s",$row['name']);
               output (" `2`n-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-`n");
               output (" `@%s `2is flirting with you; %s ",$row['name'],$row['sex']?"she":"he");
               if (get_module_pref("flirtfromtype")==1) output ("`2attempts to flatter you by saying \"Your lips are like roses!\"");
               else if (get_module_pref("flirtfromtype")==2) output ("`2attempts to kiss you by saying \"Kiss me you fool!\"");
               else if (get_module_pref("flirtfromtype")==3) output ("`2asks if you would like to join %s for dinner.",$row['sex']?"her":"him");
               else if (get_module_pref("flirtfromtype")==4) output ("`2invites you to %s room.",$row['sex']?"her":"his");
               else if (get_module_pref("flirtfromtype")==5) output ("`2gets down on one knee and says \"`@%s`2, will you marry me?\"",$session['user']['name']);
               else output ("`2attemps to flirt with you, but you can't make out what %s  saying. (%s)",$row['sex']?"she's":"he's",get_module_pref("flirtfromtype"));
               output("`n`n");
               if ($row['charm']<=5)
               {
                  output("`4 WARNING: %s charm rating is only `& %s `4 !`n`n",$row['sex']?"Her":"His",$row['charm']);
                  if ($row['sex']==1) output("`2 She looks like a cow - Not even a good looking one...`n`n");
                  else output("`2 He looks like a fresh piece of troll dung.`n`n");
               }
               else if ($row['charm']>=20)
               {
                  output("`4 NOTE: %s charm rating is `& %s `4 !`n`n",$row['sex']?"Her":"His",$row['charm']);
                  if ($row['sex']==1) output("`2 She looks like a supermodel...`n`n");
                  else output("`2 He looks like a God.`n`n");
               }
               addnav("Smile hugely, accepting","runmodule.php?module=flirt&from=inn&op=accept");
               addnav("Pointedly Ignore Them","runmodule.php?module=flirt&from=inn&op=decline");
               addnav("I?Return to the Inn","inn.php");
            }
            else if (get_module_pref("flirttoname")!=0 && get_module_pref("flirttoresult")==-1 && $op=="")
            {
               $sql = "SELECT acctid,name FROM ".db_prefix("accounts")." WHERE acctid=".get_module_pref("flirttoname");
               $result=db_query($sql) or die(sql_error($sql));
               $row=db_fetch_assoc($result);
               output("`2You are still waiting for a response from `@%s `2!`n`n",$row['name']);
               addnav("R?Remove current flirt","runmodule.php?module=flirt&from=inn&op=reset");
               addnav("I?Return to the Inn","inn.php");
            }
            else if (get_module_pref("flirttoname")!=0 && get_module_pref("flirttoresult")!=-1)
            {
               require_once("lib/addnews.php");
               $sql = "SELECT acctid,name FROM ".db_prefix("accounts")." WHERE acctid=".get_module_pref("flirttoname");
               $result=db_query($sql) or die(sql_error($sql));
               $row=db_fetch_assoc($result);
               if (get_module_pref("flirttoresult")==0)
               {
                  $loseamt = $session['user']['level']*5*get_module_pref("flirttotype");
                  output ("`@%s `2ignores you!  You are snubbed good!`n`n`2You `4LOSE `& %s `2 experience!",$row['name'],$loseamt);
                  $session['user']['experience']-=$loseamt;;
                  set_module_pref("flirttoname",0);
                  set_module_pref("flirttotype",0);
                  set_module_pref("flirttoresult",-1);
                  addnews("`$ %s `4 was snubbed by `$ %s `4!",$session['user']['name'],$row['name']);
               }
               else
               {
                  require_once("lib/addnews.php");
                  $gainamt = $session['user']['level']*5*get_module_pref("flirttotype");
                  output ("`@%s `2smiles back, encouragingly.  Apparently you both had a great time!`n`n`2You `@GAIN `& %s `2 experience!",$row['name'],$gainamt);
                  $session['user']['experience']+=$gainamt;
                  set_module_pref("flirttoname",0);
                  if (get_module_pref("flirttotype")==1) addnews("`@ %s `2has accepted a flatter from `@ %s `2.",$row['name'],$session['user']['name']);
                  else if (get_module_pref("flirttotype")==2) addnews("`@ %s `2and `@ %s `2were seen kissing near the inn.",$row['name'],$session['user']['name']);
                  else if (get_module_pref("flirttotype")==3) addnews("`@ %s `2and `@ %s `2were seen having dinner together.",$row['name'],$session['user']['name']);
                  else if (get_module_pref("flirttotype")==4) addnews("`@ %s `2and `@ %s `2were seen heading up the stairs in the inn together.",$row['name'],$session['user']['name']);
                  else if (get_module_pref("flirttotype")==5) 
                  {
                     addnews("`@%s `2and `@ %s `2are joined today in joyous matrimony!!!",$row['name'],$session['user']['name']);
                     $session['user']['marriedto']=$row['acctid'];
                     $sqls = "UPDATE accounts SET marriedto=".$session['user']['acctid']." WHERE acctid=".$row['acctid'];
                     db_query($sqls) or die(sql_error($sqls));
                  }
                  set_module_pref("flirttotype",0);
                  set_module_pref("flirttoresult",-1);
               }
            addnav("I?Return to the Inn","inn.php");
			page_footer();
            }
            else if ($op=="" && !$canflirt)
            {
               output("`2Sorry, you have already flirted for today.  Try your skills again tomorrow.");
               addnav("I?Return to the Inn","inn.php");
            }
            else if ($op=="" && $canflirt)
            {
               addnav("I?Return to the Inn","inn.php");
               $playersperpage=50;
               $sql = "SELECT count(acctid) AS c FROM ".db_prefix("accounts")." WHERE locked=0 AND sex!=".$session['user']['sex'];
               $result = db_query($sql);
               $row = db_fetch_assoc($result);
               $totalplayers = $row['c'];
               $pageoffset = (int)httpget('page');
               if ($pageoffset>0) $pageoffset--;
               $pageoffset*=$playersperpage;
               $from = $pageoffset+1;
               $to = min($pageoffset+$playersperpage,$totalplayers);
               $limit=" LIMIT $pageoffset,$playersperpage ";
               addnav("Pages");
               for ($i=0;$i<$totalplayers;$i+=$playersperpage)
               {
                  addnav("Page ".($i/$playersperpage+1)." (".($i+1)."-".min($i+$playersperpage,$totalplayers).")","runmodule.php?module=flirt&from=inn&page=".($i/$playersperpage+1));
               }
               if (httpget('page')=="")
               {
                  output("`c`bWho do you want to send a Romantic Message to?`b`c");
                  $sql = "SELECT acctid,name,login,beta,sex,marriedto FROM ".db_prefix("accounts")." WHERE locked=0 AND sex!=".$session['user']['sex'].$limit;
               }
               else
               {
                  output("`c`bSend Romantic Message to Whom? (Page ".($pageoffset/$playersperpage+1).": $from-$to of $totalplayers)`b`c");
                  $sql = "SELECT acctid,name,login,beta,sex,marriedto FROM ".db_prefix("accounts")." WHERE locked=0 AND sex!=".$session['user']['sex'].$limit;
               }
               $result = db_query($sql) or die(sql_error($sql));
               $max = db_num_rows($result);
               output("<center><table border=0 cellpadding=2 cellspacing=1 bgcolor='#999999'>",true);
               output("<tr class='trhead'><td><b>Name</b></td><td><b>Sex</b></td></tr>",true);
               for($i=0;$i<$max;$i++)
               {
                  $row = db_fetch_assoc($result);

                  output("<tr class='".($i%2?"trdark":"trlight")."'><td>",true);
                  if ($row['marriedto']==0 && (get_module_pref("flirtfromname",false,$row['acctid'])==0))
                  {
                     output("<a href=\"runmodule.php?module=flirt&from=inn&op=true&with=".$row['acctid']."\">".$row['name']."</a>",true);
                     addnav("","runmodule.php?module=flirt&from=inn&op=true&with=".$row['acctid']);
                  }
                  else
                  {
                     output($row['name'],true);
                  }
                  output("</td><td>",true);
                  output($row['sex']?"`%F`0":"`1M`0");
                  output("</td></tr>",true);
               }
               output("</table></center>",true);
            }
            else if($op=="divorce")
            {
               require_once("lib/addnews.php");
               if ($session['user']['marriedto']==4294967295) 
               {
                  $spouse=($session['user']['sex']?"Seth":"Violet");
               }
               else 
               {
                  $sql = "SELECT name FROM ".db_prefix("accounts")." WHERE acctid=".$session['user']['marriedto'];
                  $result = db_query($sql) or die(sql_error($sql));
                  $row = db_fetch_assoc($result);
                  $spouse=$row['name'];
                  $sqls = "UPDATE ".db_prefix("accounts")." SET marriedto=0 WHERE acctid=".$session['user']['marriedto'];
                  db_query($sqls) or die(sql_error($sqls));
               }
               $session['user']['marriedto']=0;
               output("`2You file for a divorce from `@%s`2.  In court, your ex-spouse is awarded half of everything you own.",$spouse);
               addnews("`@ %s `2 and `@ %s `2 have filed for a divorce.",$session['user']['name'],$spouse);
               $session['user']['gold']*=0.5;
               $session['user']['goldinbank']*=0.5;
               $session['user']['gems']*=0.5;
               addnav("I?Return to the Inn","inn.php");
            }
            else if($op=="accept")
            { 
               require_once("lib/systemmail.php");
               $sql = "SELECT acctid,name FROM ".db_prefix("accounts")." WHERE acctid=".get_module_pref("flirtfromname")." LIMIT 1";
               $result = db_query($sql) or die(sql_error($sql));
               $row = db_fetch_assoc($result);
               output ("`2 You have accepted `@%s`@'s `2flirt.  Message sent.",$row['name']);
               set_module_pref("flirtfromname",0);
               set_module_pref("flirtfromtype",0);
               systemmail($row['acctid'],"Romantic Message","`@{$session['user']['name']}`2 has responded to your flirt! Please visit the Inn!");
               set_module_pref("flirttoresult",1,false,$row['acctid']);
               addnav("I?Return to the Inn","inn.php");
            }
            else if($op=="decline")
            {
               require_once("lib/systemmail.php");
               $sql = "SELECT acctid,name,charm,login,sex FROM ".db_prefix("accounts")." WHERE acctid=".get_module_pref("flirtfromname")." LIMIT 1";
               $result = db_query($sql) or die(sql_error($sql));
               $row = db_fetch_assoc($result);
               output ("`2You have ignored `@%s`2's flirt.  Message sent.",$row['name']);
               set_module_pref("flirtfromname",0);
               set_module_pref("flirtfromtype",0);
               systemmail($row['acctid'],"Romantic Message","`@{$session['user']['name']}`2 has responded to your flirt! Please visit the Inn!");
               set_module_pref("flirttoresult",0,false,$row['acctid']);
               addnav("I?Return to the Inn","inn.php");
            }
            else if($op=="true")
            {
               $sql = "SELECT acctid,name,charm,login,sex FROM ".db_prefix("accounts")." WHERE acctid=".httpget('with')." LIMIT 1";
               $result = db_query($sql) or die(sql_error($sql));
               $row = db_fetch_assoc($result);
               addnav("Never Mind.","runmodules.php?module=flirt");
               addnav("Flatter","runmodule.php?module=flirt&from=inn&op=flatter&with=".$row['acctid']);
               addnav("Ask for a Kiss","runmodule.php?module=flirt&from=inn&op=kiss&with=".$row['acctid']);
               addnav("Buy Dinner","runmodule.php?module=flirt&from=inn&op=dinner&with=".$row['acctid']);
               addnav("Invite to Room at the Inn","runmodule.php?module=flirt&from=inn&op=room&with=".$row['acctid']);
               addnav("Ask ".($row['sex']?"her":"him")." to marry you","runmodule.php?module=flirt&from=inn&op=marry&with=".$row['acctid']);
               output("`2Your hand trembles as you try to conjure up something to stir up your beloved `@%s`2 `n`n",$row[name]);;
               if ($row['charm']<=5)
               {
                  output("`4 WARNING: %s charm rating is only `& %s `4 !`n`n",$row['sex']?"Her":"His",$row['charm']);
                  if ($row['sex']==1) output("`2 She looks like a cow - Not even a good looking one...`n");
                  else output("`2 He looks like a fresh piece of troll dung.`n");
               }
               else if ($row['charm']>=20)
               {
                  output("`4 NOTE: %s charm rating is `& %s `4 !`n`n",$row['sex']?"Her":"His",$row['charm']);
                  if ($row['sex']==1) output("`2 She looks like a supermodel...`n");
                  else output("`2 He looks like a God.`n");
               }
            }
            else if ($op=="flatter")
            {
               require_once("lib/systemmail.php");
               $sql = "SELECT acctid,name,login,sex FROM ".db_prefix("accounts")." WHERE acctid=".httpget('with')." LIMIT 1";
               $result = db_query($sql) or die(sql_error($sql));
               $row = db_fetch_assoc($result);
               output("`2Your flatter was sent to `@%s`2.  You anxiously await %s response! `n",$row['name'],$row['sex']?"her":"his");
               set_module_pref("flirttoname",$row['acctid']);
               set_module_pref("flirttotype",1);
               set_module_pref("flirttoresult",-1);
               systemmail($row['acctid'],"Romantic Message","`@{$session['user']['name']}`2 is flirting with you! Review this flirt in the Inn!");
               set_module_pref("flirtfromname",$session['user']['acctid'],false,$row['acctid']);
               set_module_pref("flirtfromtype",1,false,$row['acctid']);
               set_module_pref("hasflirted",1);
               addnav("I?Return to Inn","inn.php");
            }
            else if ($op=="kiss")
            { 
               require_once("lib/systemmail.php");
               $sql = "SELECT acctid,name,login,sex FROM ".db_prefix("accounts")." WHERE acctid=".httpget('with')." LIMIT 1";
               $result = db_query($sql) or die(sql_error($sql));
               $row = db_fetch_assoc($result);
               output("`2Your kiss was sent to `@%s`2.  You anxiously await %s response! `n",$row['name'],$row['sex']?"her":"his");
               set_module_pref("flirttoname",$row['acctid']);
               set_module_pref("flirttotype",2);
               set_module_pref("flirttoresult",-1);
               systemmail($row['acctid'],"Romantic Message","`@{$session['user']['name']}`2 is flirting with you! Review this flirt in the Inn!");
               set_module_pref("flirtfromname",$session['user']['acctid'],false,$row['acctid']);
               set_module_pref("flirtfromtype",2,false,$row['acctid']);
               set_module_pref("hasflirted",1);
               addnav("I?Return to Inn","inn.php");
            }
            else if ($op=="dinner")
            {
               require_once("lib/systemmail.php");
               $sql = "SELECT acctid,name,login,sex FROM ".db_prefix("accounts")." WHERE acctid=".httpget('with')." LIMIT 1";
               $result = db_query($sql) or die(sql_error($sql));
               $row = db_fetch_assoc($result);
               output("`2Your invitation to dinner was sent to `@%s`2.  You anxiously await %s response!`n",$row['name'],$row['sex']?"her":"his");
               set_module_pref("flirttoname",$row['acctid']);
               set_module_pref("flirttotype",3);
               set_module_pref("flirttoresult",-1);
               systemmail($row['acctid'],"Romantic Message","`@{$session['user']['name']}`2 is flirting with you! Review this flirt in the Inn!");
               set_module_pref("flirtfromname",$session['user']['acctid'],false,$row['acctid']);
               set_module_pref("flirtfromtype",3,false,$row['acctid']);
               set_module_pref("hasflirted",1);
               addnav("I?Return to Inn","inn.php");
            }
            else if ($op=="room")
            {
               require_once("lib/systemmail.php");
               $sql = "SELECT acctid,name,login,sex FROM ".db_prefix("accounts")." WHERE acctid=".httpget('with')." LIMIT 1";
               $result = db_query($sql) or die(sql_error($sql));
               $row = db_fetch_assoc($result);
               output("`2You have invited `@%s `2to your private room.  You anxiously await %s response!`n",$row['name'],$row['sex']?"her":"his");
               set_module_pref("flirttoname",$row['acctid']);
               set_module_pref("flirttotype",4);
               set_module_pref("flirttoresult",-1);
               systemmail($row['acctid'],"Romantic Message","`@{$session['user']['name']}`2 is flirting with you! Review this flirt in the Inn!");
               set_module_pref("flirtfromname",$session['user']['acctid'],false,$row['acctid']);
               set_module_pref("flirtfromtype",4,false,$row['acctid']);
               set_module_pref("hasflirted",1);
               addnav("I?Return to Inn","inn.php");
            }
            else if ($op=="marry")
            {
               require_once("lib/systemmail.php");
               $sql = "SELECT acctid,name,login,sex FROM ".db_prefix("accounts")." WHERE acctid=".httpget('with')." LIMIT 1";
               $result = db_query($sql) or die(sql_error($sql));
               $row = db_fetch_assoc($result);
               output("`2You have asked `@%s `2to marry you!! You anxiously await %s response!`n",$row['name'],$row['sex']?"her":"his");
               set_module_pref("flirttoname",$row['acctid']);
               set_module_pref("flirttotype",5);
               set_module_pref("flirttoresult",-1);
               systemmail($row['acctid'],"Romantic Message","`@{$session['user']['name']}`2 is flirting with you! Review this flirt in the Inn!");
               set_module_pref("flirtfromname",$session['user']['acctid'],false,$row['acctid']);
               set_module_pref("flirtfromtype",5,false,$row['acctid']);
               set_module_pref("hasflirted",1);
               addnav("I?Return to Inn","inn.php");
            }
            else if ($op=="reset") {
               require_once("lib/systemmail.php");
               if (get_module_pref("flirttoname")!=0)
               {
                  $sql = "SELECT acctid,name,login FROM ".db_prefix("accounts")." WHERE acctid=".get_module_pref("flirttoname")." LIMIT 1";
                  $result = db_query($sql) or die(sql_error($sql));
                  $row = db_fetch_assoc($result);
                  systemmail($row['acctid'],"Stood up","`@{$session['user']['name']}`2 has stood you up.  :(");
                  set_module_pref("flirtfromname",0,false,$row['acctid']);
                  set_module_pref("flirtfromtype",0,false,$row['acctid']);
                  set_module_pref("flirttoresult",-1);
                  set_module_pref("flirttoname",0);
                  set_module_pref("flirttotype",0);
                  output("`2You have just stood up `@%s`2.  I hope you feel terrible.",$row['name']);
               }
               else
               {
                  output("`2There was no flirt to remove - wonder how you got here?");
               }
               addnav("I?Return to the Inn","inn.php");
            }
         }
         break;
      
      case "village":
         page_header("Conjugality List");
         villagenav();
         $sql = "SELECT name,marriedto,sex FROM ".db_prefix("accounts")." WHERE marriedto>0 ORDER BY name ASC";
         $result = db_query($sql) or die(sql_error($sql));
         $max = db_num_rows($result);
         output("`c`& *** CONJUGALITY LIST *** `n");
         output("`2-=-=-=-=-=-=-=-=-=-=-=-=-`n`n`c");
         for ($i=0;$i<$max;$i++){
            $row = db_fetch_assoc($result);
            if ($row['marriedto']==4294967295)
               output("`@%s `2belongs to `@%s`2.`n",$row['name'],$row['sex']?"`@Seth":"`%Violet");
            else
            {
               $sqls = "SELECT name FROM ".db_prefix("accounts")." WHERE acctid=".$row['marriedto']; 
               $results = db_query($sqls) or die(sql_error($sqls));
               $rows=db_fetch_assoc($results);
               output("`@%s `2belongs to `@%s`2.`n",$row['name'],$rows['name']);
            }
         }
         break;
   }
   page_footer();
}
?>
