<?php

/***************************************************************************/
/* Name: Faq Addon                                                         */
/* ver 1.4                                                                 */
/* Billie Kennedy => dannic06@gmail.com                                    */
/*                                                                         */
/*2-15-2005                                                                */
/*  - added index page option to allow you to choose to show your FAQ on   */
/*    the index page.                                                      */
/*  - added ability to make a FAQ available to specific users.             */
/*2-19-2005                                                                */
/*  - Added support for the Check Module Version module.                   */
/*4-1-2005                                                                 */
/*  - Fixed return $args that was broken with upgrade.                     */
/*6-26-2005                                                                */
/*  - Fixed missing parameter in table creation.                           */
/***************************************************************************/

require_once("lib/showform.php");
require_once("lib/http.php");

function faqaddon_getmoduleinfo(){
	$info = array(
		"name"=>"Faq Addon",
		"version"=>"1.41",
		"author"=>"Billie Kennedy",
		"download"=>"http://www.nuketemplate.com/modules.php?name=Downloads&d_op=viewdownload&cid=30",
		"vertxtloc"=>"http://dragonprime.net/users/Dannic/",
		"allowanonymous"=>true,
		"category"=>"Administrative",
		"allowanonymous"=>true,
		"override_forced_nav"=>true,
		"settings"=>array(
			"Faq Addon Module Settings,title",
			"onindex"=>"Shows up on the Index page?,bool|1",
		),
		"prefs"=>array(
			"Faq Addon Module User Settings,title",
			"special"=>"Allow viewing of Admin only FAQ's,bool|0",
		),
	);
	return $info;
}

function faqaddon_install(){
	if (db_table_exists(db_prefix("faqs"))) {
		debug("Faq table already exists");
	}else{
		debug("Creating Faqs table");
		$sqls = array("CREATE TABLE " . db_prefix("faqs") . " (
				faqid smallint(6) NOT NULL auto_increment,
				topic varchar(100) NOT NULL default '',
				active tinyint(4) NOT NULL default '0',
				adminonly tinyint(4) NOT NULL default '0',
				PRIMARY KEY  (faqid)) TYPE=MyISAM",
				"CREATE TABLE " . db_prefix("faq_questions") . " (
				questionid smallint(6) NOT NULL auto_increment,
				faqid smallint(6) NOT NULL default '0',
				question varchar(100) NOT NULL default '',
				answer longtext NOT NULL default '',
				active tinyint(4) NOT NULL default '0',
				PRIMARY KEY  (questionid)) TYPE=MyISAM"
				);
		while (list($key,$sql)=each($sqls)){
			db_query($sql);
		}
	}
	module_addhook("faq-toc");
	module_addhook("superuser");
	module_addhook("index");
	return true;
}

function faqaddon_uninstall(){
	debug("Dropping table faqs");
	$sql = "DROP TABLE IF EXISTS " . db_prefix("faqs");
	db_query($sql);
	debug("Dropping table faq questions");
	$sql = "DROP TABLE IF EXISTS " . db_prefix("faq_questions");
	db_query($sql);
	debug("Dropping objprefs related to faqs");
	$sql = "DELETE FROM " . db_prefix("module_objprefs") .
		" WHERE objtype='faqs'";
	db_query($sql);
	return true;
}

function faqaddon_dohook($hooktitle,$args){
	global $session;
	switch($hooktitle){
	
		case "faq-toc":
		
			$sql = "SELECT faqid,active,topic,adminonly FROM " . db_prefix("faqs") . " WHERE active = 1 ORDER BY topic";
			$result= db_query($sql);
			for ($i=0;$i<db_num_rows($result);$i++){
				$row = db_fetch_assoc($result);
				$t = $row['topic'];
				$id = $row['faqid'];
				$adminonly = $row['adminonly'];
				if($adminonly && !get_module_pref("special")){
					break;
				}
				output_notl("&#149;<a href='runmodule.php?module=faqaddon&op=faq&faqid=$id'>$t</a><br/>", true);
			}
			break;
		
		case "superuser":
			if (($session['user']['superuser'] & SU_EDIT_USERS)) {
				addnav("Module Configurations");
				// Stick the admin=true on so that when we call runmodule it'll
				// work to let us edit faqs even when the module is deactivated.
				addnav("Faq Editor","runmodule.php?module=faqaddon&op=list&admin=true");
			}
		break;
		
		case "index":
			if(get_module_setting("onindex")){
				addnav ("??F.A.Q. (newbies start here)","petition.php?op=faq",false,true);
			}
		break;
		
	}
	return $args;
}

function faqaddon_run(){

	global $session;
	$op = httpget("op");
	switch($op){
		case "list":
			faqaddon_list();
			break;
		case "activate":
		case "deactivate":
		case "delete":
			faqaddon_status();	
			faqaddon_list();
			break;
		case "add":
		case "edit":
		case "save":
			faqaddon_edit();
			break;
		case "qactivate":
		case "qdeactivate":
		case "qdelete":
			faqaddon_qstatus();	
			break;
		case "qadd":
		case "qedit":
		case "qsave":
			faqaddon_qedit();
			break;
		case "faq":
			faqaddon_faq();
			break;
		default:
			require_once("lib/forcednavigation.php");
			do_forced_nav(false, false);
			break;
	}

}

function faqaddon_faq() {

	tlschema("faq");
	popup_header("Legend of the Green Dragon FAQ's");
	$c = translate_inline("Contents");
	rawoutput("<a href='petition.php?op=faq'>$c</a>");
	$faqid = httpget('faqid');
	$sql = "SELECT topic FROM " . db_prefix("faqs") . " WHERE faqid='$faqid'";
	$result= db_query($sql);
	$row = db_fetch_assoc($result);
	$topic = $row['topic'];
	output("`n`n`c`b$topic`b`c`n`n");
	$sql = "SELECT question,answer FROM " . db_prefix("faq_questions") . " WHERE faqid ='$faqid' AND active = '1' ORDER BY questionid";
	$result= db_query($sql);
	for ($i=0;$i<db_num_rows($result);$i++){
		$row = db_fetch_assoc($result);
		$question = $row['question'];
		$answer = $row['answer'];
		output("`^%s. %s`n",$i+1,$question);
		output("`@%s`n`n",$answer);
	}
	
	popup_footer();

}

function faqaddon_list(){
	if (!get_module_pref("faqaddon")) {
		check_su_access(SU_EDIT_USERS);
		}
		
	page_header("Faq Editor");
	require_once("lib/superusernav.php");
	superusernav();
	addnav("Faq Editor");
	addnav("Add a Faq","runmodule.php?module=faqaddon&op=add");
	$header = translate_inline("Current Faq Addon Editor");
	output_notl("`&<h3>$header`0</h3>", true);

	$op = translate_inline("Ops");
	$id = translate_inline("Id");
	$nm = translate_inline("Topic");
	$edit = translate_inline("Edit");
	$deac = translate_inline("Deactivate");
	$act = translate_inline("Activate");
	$conf = translate_inline("Are you sure you wish to delete this Faq?");
	$del = translate_inline("Del");
	$adminonly = translate_inline("Admin Only");
	
	rawoutput("<table border=0 cellpadding=2 cellspacing=1 bgcolor='#999999'>");
	rawoutput("<tr class='trhead'>");
	rawoutput("<td>$op</td><td>$id</td><td>$nm</td><td>$adminonly</td>");
	rawoutput("</tr>");
	$sql = "SELECT faqid,active,topic,adminonly FROM " . db_prefix("faqs") . " ORDER BY faqid";
	$result= db_query($sql);
	for ($i=0;$i<db_num_rows($result);$i++){
		$row = db_fetch_assoc($result);
		$id = $row['faqid'];
		rawoutput("<tr class='".($i%2?"trlight":"trdark")."'>");
		rawoutput("<td nowrap>[ <a href='runmodule.php?module=faqaddon&op=edit&faqid=$id'>$edit</a>");
		addnav("","runmodule.php?module=faqaddon&op=edit&faqid=$id");
		if ($row['active']) {
			rawoutput(" | <a href='runmodule.php?module=faqaddon&op=deactivate&faqid=$id'>$deac</a>");
			addnav("","runmodule.php?module=faqaddon&op=deactivate&faqid=$id");
		} else {
			rawoutput(" | <a href='runmodule.php?module=faqaddon&op=activate&faqid=$id'>$act</a>");
			addnav("","runmodule.php?module=faqaddon&op=activate&faqid=$id");
		}
		rawoutput(" | <a href='runmodule.php?module=faqaddon&op=delete&faqid=$id' onClick='return confirm(\"$conf\");'>$del</a> ]</td>");
		addnav("","runmodule.php?module=faqaddon&op=delete&faqid=$id");
		output_notl("<td>`^%s</td>`0", $id, true);
		output_notl("<td>`&%s`0</td>", $row['topic'], true);
		if($row['adminonly']){
			output_notl("<td>`&Yes`0</td>", true);
		}else{
			output_notl("<td>`&No`0</td>", true);
		}
		rawoutput("</tr>");
	}
	rawoutput("</table>");
	
	page_footer();		
}

function faqaddon_status(){

	page_header("Faq Editor");
	global $session;
	$header = translate_inline($status);
	$faqid = httpget('faqid');
	$op = httpget('op');

	if ($op == "activate") {
		$sql = "UPDATE " . db_prefix("faqs") . " SET active=1 WHERE faqid='$faqid'";
		db_query($sql);
	}
	if ($op == "deactivate") {
		$sql = "UPDATE " . db_prefix("faqs") . " SET active=0 WHERE faqid='$faqid'";
		db_query($sql);
	}
	if ($op == "delete") {
		$sql = "DELETE FROM " . db_prefix("faqs") . " WHERE faqid='$faqid'";
		db_query($sql);
	}
	return true;
}

function faqaddon_edit(){
	global $mostrecentmodule;
	if (!get_module_pref("faqaddon")) {
		check_su_access(SU_EDIT_USERS);
		}
		
	page_header("Faq Addon Editor");
	require_once("lib/superusernav.php");
	superusernav();
	addnav("Faq Editor");
	addnav("List faqs","runmodule.php?module=faqaddon&op=list&admin=true");
	addnav("Add a Faq","runmodule.php?module=faqaddon&op=add&admin=true");
	$header = "";
	$op = httpget('op');
	$faqid = httpget('faqid');
	if ($op != "") {
		if ($op == 'add') {
			$header = translate_inline("Adding a new faq");
		} else if ($op == 'edit') {
			$header = translate_inline("Editing a faq");
		}
	} else {
		$header = translate_inline("Current Faqs");
	}
	
	output_notl("`&<h3>$header`0</h3>", true);
	$faqsarray=array(
		"Faq editor,title",
		"faqid"=>"Faq ID,hidden",
		"topic"=>"Faq topic",
		"adminonly"=>"Make Admin Only?",
	);
	if($op=="save"){
		$subop = httpget("subop");
		if ($subop=="") {
			$faqid = httppost("faqid");
			list($sql, $keys, $vals) = postparse($faqsarray);
			if ($faqid > 0) {
				$sql = "UPDATE " . db_prefix("faqs") . " SET $sql WHERE faqid='$faqid'";
			} else {
				$sql = "INSERT INTO " . db_prefix("faqs") . " ($keys) VALUES ($vals)";
			}

			db_query($sql);
			if (db_affected_rows()> 0) {
				output("`^Faq saved!");
			} else {
				output("`^Faq not saved: `\$%s`0", $sql);
			}
		} elseif ($subop == "module") {
			$faqid = httpget("faqid");
			// Save module settings
			$module = httpget("editmodule");
			$post = httpallpost();
			reset($post);
			while(list($key, $val)=each($post)) {
				set_module_objpref("faqs", $faqid,$key, $val, $module);
			}
			output("`^Saved.");
		}
		if ($faqid) {
			$op = "edit";
			httpset("faqid", $faqid, true);
		} else {
			$op = "";
		}
		httpset('op', $op);
	}
		
	if($op=="edit"){
		if ($subop=="module") {
			$module = httpget("editmodule");
			$oldmodule = $mostrecentmodule;
			rawoutput("<form action='runmodule.php?module=faqaddon&op=save&subop=module&editmodule=$module&faqid=$faqid&admin=true' method='POST'>");
			module_objpref_edit('faqs', $module, $faqid);
			$mostrecentmodule = $oldmodule;
			rawoutput("</form>");
			addnav("", "runmodule.php?module=faqaddon&op=save&subop=module&editmodule=$module&faqid=$faqid&admin=true");
		} elseif ($subop=="") {
			$sql = "SELECT * FROM " . db_prefix("faqs") . " WHERE faqid='".httpget('faqid')."'";
			$result = db_query($sql);
			$row = db_fetch_assoc($result);
			rawoutput("<form action='runmodule.php?module=faqaddon&op=save&admin=true' method='POST'>");
			addnav("","runmodule.php?module=faqaddon&op=save&admin=true");
			if ($op = "edit"){
				addnav("Add Question","runmodule.php?module=faqaddon&op=qadd&faqid=$faqid&admin=true");
			}
			showform($faqsarray,$row);
			rawoutput("</form>");
			
			$ops = translate_inline("Ops");
			$id = translate_inline("Id");
			$qu = translate_inline("Question");
			$an = translate_inline("Answer");
			$edit = translate_inline("Edit");
			$deac = translate_inline("Deactivate");
			$act = translate_inline("Activate");
			$conf = translate_inline("Are you sure you wish to delete this question?");
			$del = translate_inline("Del");
			rawoutput("<table border=0 cellpadding=2 cellspacing=1 bgcolor='#999999'>");
			rawoutput("<tr class='trhead'>");
			rawoutput("<td>$ops</td><td>$id</td><td>$qu</td><td>$an</td>");
			rawoutput("</tr>");
			$sql = "SELECT questionid,question,answer,active FROM " . db_prefix("faq_questions") . " WHERE faqid ='".httpget('faqid')."' ORDER BY questionid";
			$result= db_query($sql);
			for ($i=0;$i<db_num_rows($result);$i++){
				$row = db_fetch_assoc($result);
				$id = $row['questionid'];
				rawoutput("<tr class='".($i%2?"trlight":"trdark")."'>");
				rawoutput("<td nowrap>[ <a href='runmodule.php?module=faqaddon&op=qedit&questionid=$id&faqid=$faqid'>$edit</a>");
				addnav("","runmodule.php?module=faqaddon&op=qedit&questionid=$id&faqid=$faqid");
				if ($row['active']) {
					rawoutput(" | <a href='runmodule.php?module=faqaddon&op=qdeactivate&questionid=$id&faqid=$faqid'>$deac</a>");
					addnav("","runmodule.php?module=faqaddon&op=qdeactivate&questionid=$id&faqid=$faqid");
				} else {
					rawoutput(" | <a href='runmodule.php?module=faqaddon&op=qactivate&questionid=$id&faqid=$faqid'>$act</a>");
					addnav("","runmodule.php?module=faqaddon&op=qactivate&questionid=$id&faqid=$faqid");
				}
				rawoutput(" | <a href='runmodule.php?module=faqaddon&op=qdelete&questionid=$id&faqid=$faqid' onClick='return confirm(\"$conf\");'>$del</a> ]</td>");
				addnav("","runmodule.php?module=faqaddon&op=qdelete&questionid=$id&faqid=$faqid");
				output_notl("<td>`^%s</td>`0", $id, true);
				output_notl("<td>`&%s`0</td>", $row['question'], true);
				output_notl("<td>`&%s`0</td>", $row['answer'], true);
				rawoutput("</tr>");
			}
			rawoutput("</table>");
			}
	}elseif ($op=="add"){
		/* We're adding a new Faq, make an empty row */
		$row = array();
		$row['faqid'] = 0;
		rawoutput("<form action='runmodule.php?module=faqaddon&op=save&admin=true' method='POST'>");
		addnav("","runmodule.php?module=faqaddon&op=save&admin=true");
		showform($faqsarray,$row);
		rawoutput("</form>");
	}

	page_footer();			
}

function faqaddon_qedit(){
	global $mostrecentmodule;
	if (!get_module_pref("faqaddon")) {
		check_su_access(SU_EDIT_USERS);
		}
		
	page_header("Faq Addon Question Editor");
	require_once("lib/superusernav.php");
	superusernav();
	addnav("Faq Editor");
	addnav("List faqs","runmodule.php?module=faqaddon&op=list&admin=true");
	addnav("Add a Faq","runmodule.php?module=faqaddon&op=add&admin=true");
	$header = "";
	$op = httpget('op');
	$questionid = httpget('questionid');
	$faqid = httpget('faqid');
	if ($op != "") {
		if ($op == 'qadd') {
			$header = translate_inline("Adding a new question");
		} else if ($op == 'qedit') {
			$header = translate_inline("Editing a question");
		}
	} else {
		$header = translate_inline("Current questions");
	}
	addnav("Return to the Faq","runmodule.php?module=faqaddon&op=edit&faqid=$faqid");
	output_notl("`&<h3>$header`0</h3>", true);
	$faqsarray=array(
		"Question editor,title",
		"questionid"=>"Question ID,hidden",
		"faqid"=>"Faq ID, hidden",
		"question"=>"Question",
		"answer" =>"Answer",
	);
	if($op=="qsave"){
		$subop = httpget("subop");
		if ($subop=="") {
			$questionid = httppost("questionid");
			list($sql, $keys, $vals) = postparse($faqsarray);
			if ($questionid > 0) {
				$sql = "UPDATE " . db_prefix("faq_questions") . " SET $sql WHERE questionid='$questionid'";
			} else {
				$sql = "INSERT INTO " . db_prefix("faq_questions") . " ($keys) VALUES ($vals)";
			}

			db_query($sql);
			if (db_affected_rows()> 0) {
				output("`^Question saved!");
			} else {
				output("`^Question not saved: `\$%s`0", $sql);
			}
		} elseif ($subop == "module") {
			$questionid = httpget("questionid");
			// Save module settings
			$module = httpget("editmodule");
			$post = httpallpost();
			reset($post);
			while(list($key, $val)=each($post)) {
				set_module_objpref("faq_questions", $questionid,$key, $val, $module);
			}
			output("`^Saved.");
		}
		if ($questionid) {
			$op = "qedit";
			httpset("questionid", $questionid, true);
		} else {
			$op = "";
		}
		httpset('op', $op);
	}
		
	if($op=="qedit"){
		if ($subop=="module") {
			$module = httpget("editmodule");
			$oldmodule = $mostrecentmodule;
			rawoutput("<form action='runmodule.php?module=faqaddon&op=qsave&subop=module&editmodule=$module&questionid=$questionid&admin=true' method='POST'>");
			module_objpref_edit('faq_questions', $module, $questionid);
			$mostrecentmodule = $oldmodule;
			rawoutput("</form>");
			addnav("", "runmodule.php?module=faqaddon&op=qsave&subop=module&editmodule=$module&questionid=$questionid&admin=true");
		} elseif ($subop=="") {
			$sql = "SELECT * FROM " . db_prefix("faq_questions") . " WHERE questionid='".httpget('questionid')."'";
			$result = db_query($sql);
			$row = db_fetch_assoc($result);
			rawoutput("<form action='runmodule.php?module=faqaddon&op=qsave&admin=true' method='POST'>");
			addnav("","runmodule.php?module=faqaddon&op=qsave&admin=true");
			if ($op = "qedit"){
				addnav("Add Question","runmodule.php?module=faqaddon&op=qadd&admin=true");
			}
			showform($faqsarray,$row);
			rawoutput("</form>");
			
			}
	}elseif ($op=="qadd"){
		/* We're adding a new Faq, make an empty row */
		$row = array();
		$row['questionid'] = 0;
		$row['faqid'] = $faqid;
		rawoutput("<form action='runmodule.php?module=faqaddon&op=qsave&admin=true' method='POST'>");
		addnav("","runmodule.php?module=faqaddon&op=qsave&admin=true");
		showform($faqsarray,$row);
		rawoutput("</form>");
	}
	
	page_footer();			
}

function faqaddon_qstatus(){

	page_header("Faq Editor");
	global $session;
	$header = translate_inline($status);
	$questionid = httpget('questionid');
	$faqid = httpget('faqid');
	$op = httpget('op');
	require_once("lib/superusernav.php");
	superusernav();
	addnav("Faq Editor");
	addnav("List faqs","runmodule.php?module=faqaddon&op=list&admin=true");
	addnav("Add a Faq","runmodule.php?module=faqaddon&op=add&admin=true");

	if ($op == "qactivate") {
		$sql = "UPDATE " . db_prefix("faq_questions") . " SET active=1 WHERE questionid='$questionid'";
		db_query($sql);
	}
	if ($op == "qdeactivate") {
		$sql = "UPDATE " . db_prefix("faq_questions") . " SET active=0 WHERE questionid='$questionid'";
		db_query($sql);
	}
	if ($op == "qdelete") {
		$sql = "DELETE FROM " . db_prefix("faq_questions") . " WHERE questionid='$questionid'";
		db_query($sql);
	}
	addnav("Return to the Faq","runmodule.php?module=faqaddon&op=edit&faqid=$faqid");
	page_footer();
	return true;
}
?>