<?php
function turns_getmoduleinfo(){
	$info = array(
		"name"=>"Carry over turns",
		"author"=>"`%kickme`0",
		"download"=>"http://dragonprime.net/index.php?module=Downloads;sa=dlview;id=161",
		"vertxtloc"=>"http://dragonprime.net/users/kickme/",
		"settings"=>array(
			"Carry over turns - settings,title",
			"max"=>"Is the max how much turns are carried over or the total amount of turns?,enum,0,Carried over,1,Total|0",
			"amount"=>"Max amount of turns allowed?,int|200"
			),
		"prefs"=>array(
			"turns"=>"Should be zero,int|0"
			),
		"category"=>"General",
		"version"=>"1.3.0"
		);
	return $info;
}
function turns_install(){
	module_addhook("newday-intercept");
	module_addhook_priority("newday",1);
	return true;
}
function turns_uninstall(){
	return true;
}
function turns_dohook($where,$args){
	global $session;
	if(!(get_module_setting("amount") > getsetting("turns",10)) && get_module_setting("max") == 1) return $args;
	switch($where){
		case "newday-intercept":
			set_module_pref("turns",$session['user']['turns']);
			break;
		case "newday":
			if(get_module_setting("max") == 1){
				$turns = $session['user']['turns'] + get_module_pref("turns");
				if($turns > get_module_setting("amount")){
					$turns2 = get_module_setting("amount") - $session['user']['turns'];
					set_module_pref("turns",$turns2);
				}
				$session['user']['turns'] += get_module_pref("turns");
				if($session['user']['turns'] >= get_module_setting("amount")) output("`@You would gain more forest fights but you all ready have to much!`0");
				elseif(get_module_pref("turns") == 0);
				else output("`@You gain `^%s`@ forest fights due to not using them yesterday!`0",get_module_pref("turns"));
				set_module_pref("turns",0);
				break;
			}else{
				$turns = get_module_pref("turns");
				if($turns > get_module_setting("amount")) $turns = get_module_setting("amount");
				$session['user']['turns'] += $turns;
				if($turns != 0) output("`@You gain `^%s`@ forest fights due to not using them yesterday!`0",get_module_pref("turns"));
				set_module_pref("turns",0);
			}
			$args['turnstoday'] = $session['user']['turns'];
	}
	return $args;
}
function turns_run(){}
?>