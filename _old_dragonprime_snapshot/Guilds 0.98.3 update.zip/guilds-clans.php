<?php
//
// ----------------------------------------------------------------------------
//
// Clans/Guilds Pages
// CR#Dasher#004
// 25th March 2004
// Version: 0.98 beta
// The latest version is always runnning at: www.sembrance.uni.cc/rpg
// (c) Dasher [david.ashwood@inspiredthinking.co.uk] 2004
// This module is relased under the LOTGD GNU public license
// You may change/modify this module and it's associated modules as you wish but
// this copyright MUST be retained.
//
// I would apprechiate feedback/updates on how it works and changes you make.
// Dasher
//
// ----------------------------------------------------------------------------
//
// This module processes the user actions, the included funcs module
// provides the main/supporting functionality.
//
// The activities are in the form:
//     op= Activity type {SU|Manage|member|nonmember}
//     action= Action to be performed
//     task=sub task
//
//     ID=The guild|Clan ID
//     who=The member affected
//     type=Where functionality depends if it's a guild or a clan
//     stage=When a multi stage action is being performed - keeps track of progress
//
// A Nav Management system has been implemented to simplify functionality
// in this and the funcs module, and to aid customisation.
// The nav system is for User Display of Nav's and isn't used for hidden Nav's (HTML Forms/Display URL's)
//
// The following examples illustrate how it works:
//     NavSystem["Separator"]="";
//     NavSystem["DisplayName"]="url";
//     NavSystem["Separator"]["DisplayName"]="url";
//
// ----------------------------------------------------------------------------
// Changelog:
//   Ranks, NavSysem, Split into 2 modules: guilds-clans.php and guildclanfuncs.php
//   Many functions:
//          now support a dymanic return path
//          are aware of the guilds/clans diff
//          Deleting a user now changes the management team if they are a member
//   Pay guild funds to members
//   Simplified the URL paths
//   SU can now modify the management team
//   Promote members to the management team
//   Ranks can now be assigned
//   Tidied up the display in many funcs - still needs more work
//   Custom Weapons & Armor can now be defined in each guild
//   Going into the Weaponry/Armoury via the guilds (setting the guild=GuildID attribute in the URL) now activates guild functionality
//   with guild discounts on standard items, access to Special Guild Items and extra earned on trade in price
//   Now you can spend SitePoints on discounts and revamped the display of Discounts
//   Interest earned on Guild Funds (just gold), interest is accrued once per real day on management member entering
//   The Guild TLA can now be a prefix/suffix next to the display name in chat
//   ViewCommentary code now links to the display summary info for the guild
//   Fixed a bug with the default ranks (rankorder 0 & 20), now created if they don't exist in PopulateRanks
//   Fixed a bug in the weapon/Armor upgrade
//   Fixed a bug in the spying
//   Fixed a return path problem in Armor.php/Weapons.php
//   Modified common: Checkday, If passed true, checks if the user is dead, clears the output buffers if set and redirects to the shades if they are dead
//   and now checks for newday in guilds-clans.php
//   Updated the Healer to use the same stage process
//   Removed some latent debug info
//   Updated common: loadsettings/getsettings/savesettings to always use a lowercase settingname
//   Cost of upgrading weapons/armor is progressively more expensive and the weapon/armor value increases by 10% of the upgrade cost
//
// Settings used with GetSettings:
//      MaxInterest - Max Bank Interest, Default:10
//      MaxFightPercent - Maximum % from fights (FF/PvP), Default: $MaxInterest
//      RatioOfSitePoints - Ratio of SitePoints to % increase, Default: 5
//      WeaponUpgradeCost - Cost of Upgrading Weapons, Default: 500
//      ArmourUpgradeCost - Cost of Upgrading Armour, Default: 500
// ----------------------------------------------------------------------------
//
// ToDO:
//  Differentiate Clans from Guilds - High Priority
//  Mail other management team members when a management member leaves - low Priority
//  Spending of SitePoints needs to be a little more balanced and there needs to be some way of unspending SitePoints
//  Partially done - currently Each DK in dragon.php earns 1 sitepoint for a normal kill and 2 SitePoints for a flawless fight
//                 - PvP earns sitepoints:
//                       -2 => killing somebody on your clan
//                       +1 => standard kill
//                       +1 => Member on your guild hitlist
//                       +1 => You are on their hitlist
//                       +1 => Their guild in on your guild hitlist (Guild Wars)
//
//  Council Management
//      Assign some kind of reason when an application is denied - low Priority
//  Guild Management
//      Define votes - medium Priority
//      Currently there are no limits on how much you can upgrade weapons/armor - the cost is progressivly more expensive
//  Member Options
//      Vote - medium Priority
//  Site changes
//      Guild Discounts, update the other pages to support the discounts - background
//      Bio update - high Priority
//
require_once "common.php";
require_once "guildclanfuncs.php";

page_header("Guilds/Clans");
output("`c`& ~ Guilds/Clans ~ `c",true);
addcommentary();
checkday(true);
populate_guilds();  // Ensures we always have the most up to date info in the session

// Debug
//output("`n`n Clan ID: ".$session[user]['clanID']);
//output("`n Guild ID: ".$session[user]['guildID']);
//output("`nCount: ".count($session['guilds']));
//output("`nOP: ".$HTTP_GET_VARS['op']);
//print_r("Vars: ");
//print_r($HTTP_GET_VARS);
//print_r("\n");
//print_r($session['guilds']);

global $NavSystem;

// Are they a superuser?
//if ($session['user']['superuser']>=$SU_Level_For_Management) {
if (SU_Admin_Allowed()) {
    // Display the superuser management pages
   $NavSystem["Council Options"]["X?Display Applications"]="guilds-clans.php?op=SU&type=applications";
   $NavSystem[]="~";
}


// ----------------------------------------------------------------------------
// Main decision tree
// ----------------------------------------------------------------------------
switch ($HTTP_GET_VARS['op']) {
    case "manage": // Management functions for members who are on the management team
             $action=$HTTP_GET_VARS['action'];
             $guildID=$HTTP_GET_VARS['id'];
             $ManageGuild=&$session['guilds'][$guildID];
             $who=$HTTP_GET_VARS['who'];

             $NavSystem["Management Options"]["M?Manage Members"]="guilds-clans.php?op=manage&action=members&id=".$guildID;
             $NavSystem["Management Options"]["S?Manage SitePoints"]="guilds-clans.php?op=manage&action=sitepoints&id=".$guildID;
             $NavSystem["Management Options"]["H?Manage HitList"]="guilds-clans.php?op=manage&action=hitlist&id=".$guildID;
             $NavSystem["Management Options"]["G?Update Guild Info"]="guilds-clans.php?op=manage&action=guildinfo&id=".$guildID;
             $NavSystem["Management Options"]["k?Manage Ranks"]="guilds-clans.php?op=manage&action=manageranks&id=".$guildID."";
             $NavSystem["Management Options"]["W?Custom Guild Weapons"]="guilds-clans.php?op=manage&action=weapons&id=".$guildID."";
             $NavSystem["Management Options"]["A?Custom Guild Armor"]="guilds-clans.php?op=manage&action=armor&id=".$guildID."";
             $NavSystem[]="~";
             $NavSystem["Return"]["R?Return to the Commons"]="guilds-clans.php?op=member&action=enter&id=".$guildID;

//             $val=CalcInterestEarned($guildID);
//             if ($val!=0) output("`nThe guild has earned `^".$val."gp interest on it's gold reserves!`n");

             switch ($action) {
                case "sitepoints":
                    ManageSitePoints($guildID);
                break;

                case "weapons":
                    WeaponEditor($guildID);
                break;

                case "armor":
                    ArmorEditor($guildID);
                break;

                 case "create":
                    // Changes to the Guild Information
                    // Gotta work on this section to simplify, currently lifted from the new guild/clan routine
                    //###
                     $type=$HTTP_GET_VARS['type'];
                     //switch ($type){
                     //case "guild":
                     output("Guilds`n");
                     $status=$HTTP_GET_VARS['status'];
                     switch ($status) {
                         case "verifyInfo":
                             // Display data entered by the user, verify for bad language or missing information
                             $Info=$_POST['info'];
                             $Info['GuildLeader']=$session['user']['acctid'];
                             display_guild_info($Info);
                         break;

                         case "submit":
                             // Submit data to the council, update the information
                             $tmp=base64_decode($_POST['info']);
                             $Info=unserialize($tmp);
                             if ($Info!=true) {
                                 output("`n`nProblem getting data from Verify Form`n");
                             } else {
                                   if ($Info['BadLanguage']!=0) {
                                          output("`n`%*sigh* `&Invalid Language - Try again`n");
                                        display_edit_guild($Info);
                                   } else {
                                     if ($Info['MissingVitalInfo']==true) {
                                         output("`n`&You are missing mandatory information! Try again.");
                                         display_edit_guild($Info);
                                     } else {
                                         unset($Info['BadLanguage']);
                                         unset($Info['MissingVitalInfo']);
                                         $Info['IsGuild']=1;
                                         // Save the Guild info
                                         if (!isset($Info['ID']) or $Info['ID']==0) {
                                             $id=create_guild_info($Info);  // Returns the identity of the user
                                             $session['user']['guildID']=$id;  // Assign the user to the guild
                                             PopulateRanks($guildID);
                                             output("`n`0The Council Clark looks over the information you have supplied him `&'Humm, everything looks in order.  I'll pass the information onto the Ruling council - they will contact you shortly'");
                                             output("`n`0With a sigh he throws your stack of application forms onto the pile and walks off to get himself a coffee, mumbling under his breath about the paperless office.");
                                         } else {
                                             update_guild_info($Info);
                                             output("`n`0The Council Clark looks over the information you have supplied him `&'Humm, everything looks in order.  I'll update the information now..'");
                                         }
                                     }
                                   }
                                 }
                             break;

                             default:
                                 if (($session['user']['gems']>=$GuildPurchaseCostGems) && ($session['user']['gold']>=$GuildPurchaseCostGold)) {
                                     // Grab the cash
                                     $session['user']['gems']-=$GuildPurchaseCostGems;
                                     $session['user']['gold']-=$GuildPurchaseCostGold;
                                     $Info=array();
                                     // Load them the cash into the guild
                                     $Info['gems']=$GuildPurchaseCostGems;
                                     $Info['gold']=$GuildPurchaseCostGold;
                                     display_edit_guild($Info);
                                 } else {
                                     output("`n`0You don't have enough to start a guild - you need `%".$GuildPurchaseCostGems." `0Gems and `^".$GuildPurchaseCostGold." `0Gold");
                                 }
                             break;
                         }
                     break;

                case "manageranks":
                    // Add/modify/remove the ranks of this guild
                    ManageRanks($guildID);
                break;

                case "approveapplicant":
                    // Approve a pending applicant
                    if ($who=="") {
                        // Nothing has been passed
                        output("You didn't tell me who to approve!`n");
                    } else {
                        $Applicants=&$ManageGuild['ApplicantList'];
                        unset($Applicants[$who]);
                        update_guild_info($ManageGuild);
                        $sql="select name, guildID from accounts where acctid=".$who;
                        $result = db_query($sql);
                        $row = db_fetch_assoc($result);
                        if ($row['guildID']==0) {
                            $sql="update accounts set guildID=".$guildID." where acctid=".$who;
                            db_query($sql);
                            output("Applicant approved and they have been notified by mail!");
                            systemmail($who,"`%Re: application to join the ".$ManageGuild['Name']." Guild!`0",
                                   ($session['user']['name'])." `0has approved your application to join the ".$ManageGuild['Name']." Guild!!`n`n Congratulations", $session['user']['acctid']);
                        } else {
                            output($row['name']." `0has already been accepted by the ".$session['guilds'][$row['guildID']]['Name'],true);
                            output("`0They have been removed from the list of applicants");
                        }
                    }
                break;

                case "denyapplicant":
                    // Deny an pending applicant
                    if ($who!="") {
                        $Applicants=&$ManageGuild['ApplicantList'];
                        unset($Applicants[$who]);
                        update_guild_info($ManageGuild);
                        output("Applicant denied");
                        systemmail($who,"`%Re: Application to join the ".$ManageGuild['Name']." Guild!`0",
                                       ($session['user']['name'])." `0has `idenied`i your application to join the ".$ManageGuild['Name']." Guild!!`n`n Bad luck`nReply to this message for more information regarding why your application was unsuccessful", $session['user']['acctid']);
                    } else {
                        output("You cannot deny membership to anybody until you select them!");
                    }
                break;

                case "revokemember":
                    // Kick somebody out
                    if ($who!="") {
                        $sql="update accounts set guildID=0 where acctid=".$who;
                        db_query($sql);
                        systemmail($who,"`%Re: Membership of the ".$ManageGuild['Name']." Guild!`0",
                                       ($session['user']['name'])." `0has `&`irevoked`i `0your membership of the ".$ManageGuild['Name']." `0Guild!!`n`nReply to this message for more information", $session['user']['acctid']);
                        output("Member Revoked");
                    } else {
                        output("You cannot revoke membership to anybody until you select them!");
                    }
                break;

                case "assignrank":
                    // Assign one or more members to a rank
                    AssignRank($guildID);
                break;

                case "pay":
                    // Pay a stipend to one or more members
                    PayMember($guildID, $who);
                break;

                case "promotemember":
                    // Promote somebody to the management team
                    PromoteMember($guildID);
                break;

                case "members":
                    // Display/Manage members
                    GuildMembers($guildID,true);
                break;

                case "guildinfo":
                    // Display the guild Information for editing
                    display_edit_guild($ManageGuild,true,false);
                break;

                case "hitlist":
                    //### Verify
                    // Display/Manage the current Hitlist
                    edit_hitlist($guildID);
                break;

                case "guildinfo":
                    // Edit the guild information
                    display_edit_guild($ManageGuild,true,false);
                break;

                default:
                    // Should not have got here!
                    output("Should not have got here - Option: ".$action);
                break;
             }
    break;  // End of op=manage

    case "SU": // Super User management
        $guildID=$HTTP_GET_VARS['id'];
        $ManageGuild=&$session['guilds'][$guildID];
        switch ($HTTP_GET_VARS['type']){
            case "applications":
                  switch ($HTTP_GET_VARS['action']){
                  case "delete":
                    switch ($HTTP_GET_VARS['stage']) {
                        case "2":
                            output("`nRemoving all the Ranks associated with this Guild");
                            $sql="delete from lotbd_guildranks where GuildID=".$guildID;
                            db_query($sql);
                            output("`nAll Ranks Deleated");
                            output("`nUpdating all accounts...");
                            $sql="select count(*) as affected from accounts where guildID=".$guildID;
                            $result=db_query($sql);
                            $row=db_fetch_assoc($result);
                            output("`n ...... there are ".$row['affected']." accounts affected");
                            db_free_result($result);
                            // Update any acocunts that have the guildID set to this guild
                            $sql="update accounts set guildID=0, guildrank=0 where guildid=".$guildID;
                            db_query($sql);
                            output("`nAccounts have been changed!");
                            output("`nDeleting Guild Info");
                            $sql="delete from lotbd_guilds where ID=".$guildID;
                            db_query($sql);
                            output("`nGuild has been deleted");
                        break;
                        default:
                            output("`nAre you sure you wish to delete ".$ManageGuild['Name']." Guild?");
                            output("`nDeleting is a one time operation and cannot be undone!");
                            $NavSystem["Options"]["Y?Yes I am sure"]="guilds-clans.php?op=SU&type=applications&action=delete&id=".$guildID."&stage=2";
                            $NavSystem["Options"]["N?No - Changed my mind"]="guilds-clans.php?op=SU&type=applications";
                        break;
                    }
                  break;
                  case "save":
                        $Info=($_POST["info"]);
                        update_guild_info($Info);
                        output("`n`&Information has been saved`n");
                  break;
                  case "edit":
                        display_edit_guild($ManageGuild,true,true);//####
                  break;
                  case "pending": //###
                        $ManageGuild['Status']=0;
                        update_guild_info($ManageGuild);
                        output("Guild application marked as pending");
                        systemmail($ManageGuild['GuildLeader'],"`%Guild Status changed `&[".$ManageGuild['Name']."`&]",
                            ($session['user']['name'])." `0has changed the status of ".$ManageGuild['Name']."`0 Guild to Pending.`n`nReply to this mail for more information", $session['user']['acctid']);

                  break;
                  case "approve": //###
                        $ManageGuild['Status']=1;
                        update_guild_info($ManageGuild);
                          output("Guild application Approved");
                        // Inform the owner
                        systemmail($ManageGuild['GuildLeader'],"`%Guild Status changed `&[".$ManageGuild['Name']."`&]",
                            ($session['user']['name'])." `0has changed the status of ".$ManageGuild['Name']."`0 Guild to Approved.`n Congrats people can now apply to join the guild.  Good luck!", $session['user']['acctid']);

                  break;
                  case "deny": //###
                        $ManageGuild['Status']=-999;
                        update_guild_info($ManageGuild);
                          output("Guild application Deny");
                        systemmail($ThisGuild['GuildLeader'],"`%Guild Status changed `&[".$ManageGuild['Name']."`&]",
                            ($session['user']['name'])." `0has changed the status of ".$ManageGuild['Name']."`0 Guild to Denied.`n`nReply to this mail for more information", $session['user']['acctid']);
                  break;

                  default:
                    $guildID=$HTTP_GET_VARS['id'];
                    $ManageGuild=&$session['guilds'][$guildID];

                    switch ($HTTP_GET_VARS['display']){

                          case "item":
                                $NavSystem["Actions"]["Edit"]="guilds-clans.php?op=SU&type=applications&action=edit&id=".$guildID;
                                 switch ($ManageGuild['Status']) {
                                         case "-999":
                                          $NavSystem["Status"]["Approve"]="guilds-clans.php?op=SU&type=applications&action=approve&id=".$guildID;
                                          $NavSystem["Status"]["Pending"]="guilds-clans.php?op=SU&type=applications&action=pending&id=".$guildID;
                                          $NavSystem["Status"]["Delete"]="guilds-clans.php?op=SU&type=applications&action=delete&id=".$guildID;
                                         break;
                                         case "0":
                                          $NavSystem["Status"]["Approve"]="guilds-clans.php?op=SU&type=applications&action=approve&id=".$guildID;
                                          $NavSystem["Status"]["Deny"]="guilds-clans.php?op=SU&type=applications&action=deny&id=".$guildID;
                                         break;
                                         case "1":
                                          $NavSystem["Status"]["Deny"]="guilds-clans.php?op=SU&type=applications&action=deny&id=".$guildID;
                                          $NavSystem["Status"]["Pending"]="guilds-clans.php?op=SU&type=applications&action=pending&id=".$guildID;
                                         break;
                                         default:
                                         break;
                                 }
                            Display_Record($ManageGuild);

                          break;

                          default:
                              // Display outstanding applications
                            $i=1;
                            if (count($session['guilds'])==0) {
                                output("`n`n`0There are no guilds to manage!");
                                output("`nGet out there and spread the word!!");
                            } else {
                                output("`n`n`0There are currently `&".count($session['guilds'])."`0 Guild".((count($session['guilds'])==1)?"":"s")." to manage!");
                                output("<table border=0 cellpadding=4 cellspacing=1 bgcolor='#999999' align='center'>",true);
                                output("<tr class='trhead'><td>`bName`b</td><td>`bStatus`b</td>",true);
                                foreach ($session['guilds'] as $ThisGuild){
                                     switch ($ThisGuild['Status']) {
                                             case "-999":
                                               $statustext="`4Denied";
                                             break;
                                             case "0":
                                               $statustext="`%Pending";
                                             break;
                                             case "1":
                                               $statustext="`2Active";
                                             break;
                                             default:
                                               $statustext="`0Unknown";
                                             break;
                                     }
                                     output("<tr class='".($i%2?"trlight":"trdark")."'><td><a href='guilds-clans.php?op=SU&type=applications&display=item&id=".$ThisGuild['ID']."'>".$ThisGuild['Name']."</td><td>`i".$statustext."`i</td></a>",true);
                                     addnav("","guilds-clans.php?op=SU&type=applications&display=item&id=".$ThisGuild['ID']);
                                  }
                                output("</table>",true);

                            }
                          break;
                      }

                  break;

                  }

            break;

            default:
                //output("Display other options");
            break;
        }

    break;

    case "member":
        $action=$HTTP_GET_VARS['action'];
        $guildID=$HTTP_GET_VARS['id'];
        $ThisGuild=$session['guilds'][$guildID];

        switch ($action) {
            case "suggestions":
                output("`n`0Welcome to the ".$ThisGuild['Name']."`0 suggestion room.",true);
                output("`n`n`0A Sign Overhead reads:");
                output("`c`i`&The `bManagement`b reserve the right to ignore `n(or just not see) `nany suggestions you leave here`i`c",true);
                output("`n`0On the wall you see hundreds of tiny `^`iPost-its`i `0with suggestions for the management team`n`n",true);
                // Display the welcome intro
                viewcommentary("GuildSuggest:".$guildID,"Suggests", 25,"suggests");
            break;

            case "donate":
                transfer_cash($guildID, $stage);
            break;

            case "shop":
                $ExpandedLinks=true;
                $NavSystem["~Shops~"]["Display Guild Discounts"]="guilds-clans.php?op=member&action=shop&type=discounts&id=".$guildID;
                $NavSystem["~Shops~"]["Weapon Upgrade"]="guilds-clans.php?op=member&action=shop&type=weapon&id=".$guildID;
                $NavSystem["~Shops~"]["Armour Upgrade"]="guilds-clans.php?op=member&action=shop&type=armour&id=".$guildID;
                $NavSystem["~Shops~"]["Dr Zeus"]="guilds-clans.php?op=member&action=shop&type=doctors&id=".$guildID;
                $NavSystem["~Shops~"]["Practice Field"]="guilds-clans.php?op=member&action=shop&type=practice&id=".$guildID;
                $NavSystem["~Shops~"]["Weapon Shop"]="weapons.php?guild=".$guildID."&return=".urlencode(CalcReturnPath(true))."";
                $NavSystem["~Shops~"]["Armor Shop"]="armor.php?guild=".$guildID."&return=".urlencode(CalcReturnPath(true))."";

                switch ($HTTP_GET_VARS['type']){
                    case "discounts":
                        display_guild_discounts($guildID);
                    break;
                    case "weapon":
                        display_weapon_upgrade($guildID);
                    break;
                    case "armour":
                        display_armour_upgrade($guildID);
                    break;
                    case "doctors":
                        display_healer($guildID);
                    break;
                    case "practice":
                        display_practice_field($guildID);
                    break;
                    default:
                        output("`0`nYou wander into a small courtyard of master craftsmen and women who have set up shop, supplying tools and services to the ".$ThisGuild['Name']." `0Guild");
                    break;
                }

            break;

            case "leaveguild":
                switch ($HTTP_GET_VARS['choice']){
                    case "yes":
                        if (IsOnManagementTeam($guildID)) {
                            $ThisGuild=&$session['guilds'][$guildID];
                            // Send mail to other management - ?also to the members
                            if ($ThisGuild['GuildLeader']==$session['user']['acctid']) $ThisGuild['GuildLeader']=0;
                            if ($ThisGuild['HeadOfWar']==$session['user']['acctid']) $ThisGuild['HeadOfWar']=0;
                            if ($ThisGuild['HeadOfMembership']==$session['user']['acctid']) $ThisGuild['HeadOfMembership']=0;
                            update_guild_info($ThisGuild);
                        }
                        $session['user']['guildID']=0;
                        $session['user']['guildrank']=0;
                        output("`n`0You decide it's time to spend some more time in just your own company");
                        output("`n`0You walk up to the porter at the front desk and hand in your membership card");
                        output("`n`n`0Walking out you remember, with a pang of regret, the good times you had with the other warriors after facing the darkness of the forest.");
                        output("`n In a few seconds you find yourself back into the vilage");
                        // ### Send a mail to the GuildLeader or the head of membership
                        clearnav();
                        header("Refresh: 10; URL=village.php");
                        addnav("","village.php");
                    break;
                    case "no":
                        output("`n`0You back away from the resigning from the guild, thinking it's not that bad here");
                        output("`n`0You sit in a comfy armchair and the barman brings you another drink");
                    break;
                    default:
                        if (IsOnManagementTeam($guildID)) {
                            output("`nYou are on the Management Team!!!");
                            output("`nHow will they benefit from you years of experience?");
                        }
                        output("`n`n`0Are you sure you wish to leave the Guild?");
                        $NavSystem["~Options~"]["Y?Yes - get me outta this dump"]="guilds-clans.php?op=member&action=leaveguild&choice=yes&id=".$guildID;
                        $NavSystem["~Options~"]["N?No  - I wanna stay"]="guilds-clans.php?op=member&action=leaveguild&choice=no&id=".$guildID;
                    break;
                }
            break;

            case "viewrules":
                output("`n`n`&`cRules of the Guild`c",true);
                output("`n`c~~~`c",true);
                output("`n`c".$ThisGuild['RulesText']."`c",true);
            break;

            case "showstatus":
                  output("`n`c`iStatus of the Guild`i`c`n");
                  GuildsHOF($guildID);
            break;

            case "showmembers":
                GuildMembers($guildID);
            break;

            case "enter":
                $guildID=$HTTP_GET_VARS['id'];
                $ThisGuild=&$session['guilds'][$guildID];
                $ExpandedLinks=false;
                $onTeam=IsOnManagementTeam($guildID);
                if ($onTeam) {
                    $NavSystem["Management Options"]["M?Manage Members"]="guilds-clans.php?op=manage&action=members&id=".$guildID;
                    $NavSystem["Management Options"]["S?Manage SitePoints"]="guilds-clans.php?op=manage&action=sitepoints&id=".$guildID;
                    $NavSystem["Management Options"]["H?Manage HitList"]="guilds-clans.php?op=manage&action=hitlist&id=".$guildID;
                    $NavSystem["Management Options"]["G?Update Guild Info"]="guilds-clans.php?op=manage&action=guildinfo&id=".$guildID;
                    $NavSystem["Management Options"]["k?Manage Ranks"]="guilds-clans.php?op=manage&action=manageranks&id=".$guildID."";
                    $NavSystem["Management Options"]["W?Custom Guild Weapons"]="guilds-clans.php?op=manage&action=weapons&id=".$guildID."";
                    $NavSystem["Management Options"]["A?Custom Guild Armor"]="guilds-clans.php?op=manage&action=armor&id=".$guildID."";
                }
            // Wanna fall into default!

            default:
                // We have entered the mightly guild
                output("`n`0Welcome to the ".$ThisGuild['Name']."`0 commons.`n`n",true);
                $news=fetchNews($ThisGuild['ID']);
                if (isset($news)) output("The latest Guild News:`n`n`0`c`i".$news['newstext']."`i`c`n`0",true);

                // Display the welcome intro
                viewcommentary("GuildChat:".$guildID,"Chat", 25);
            break;
        }

       // Display the links
        if (!$ExpandedLinks) {
            $NavSystem["Guild Options"]["Commons"]="guilds-clans.php?op=member&action=enter&id=".$guildID;
            $NavSystem["Guild Options"]["S?Suggestions Room"]="guilds-clans.php?op=member&action=suggestions&id=".$guildID;
            $NavSystem["Guild Options"]["Donate to the Cause"]="guilds-clans.php?op=member&action=donate&id=".$guildID;
            $NavSystem["Guild Options"]["S?Guild Shopping"]="guilds-clans.php?op=member&action=shop&id=".$guildID;
            $NavSystem["Info"]["Guild Rules"]="guilds-clans.php?op=member&action=viewrules&id=".$guildID;
            $NavSystem["Info"]["Status of Guild"]="guilds-clans.php?op=member&action=showstatus&id=".$guildID;
            $NavSystem["Info"]["List of members"]="guilds-clans.php?op=member&action=showmembers&id=".$guildID;
            $NavSystem["Info"]["External Pages"]="".$ThisGuild['ExternalPagesLink']."";
            $NavSystem["Other"]["Leave the Guild"]="guilds-clans.php?op=member&action=leaveguild&id=".$guildID;
            //  External Page link
        } else {
             $NavSystem["Return"]["R?Return to the Commons"]="guilds-clans.php?op=member&action=enter&id=".$guildID;
        }

    break;

    case "nonmember":
        $action=$HTTP_GET_VARS['action'];
        switch ($action) {
            case "join":
                switch ($HTTP_GET_VARS['task']) {
                    default:
                        // You wish to join the Guild
                        $guildID=$HTTP_GET_VARS['id'];
                        $ApplyGuild=&$session['guilds'][$guildID];
                        if ($session['user']['guildID']!=0) {
                            // You are a member of one already
                            $ThisGuild=&$session['guilds'][$session['user']['guildID']];
                            if ($session['user']['guildID']==$guildID){
                                StrollIn();
                                output("Duh! You are already a member of this Guild!");
                            } else {
                                if ($ThisGuild['Status']<>1) {
                                    // You cannot spy unless the guild is approved
                                } else {
                                    // Include the option to spy
                                    addnav("Spy on ".$ApplyGuild['Name'],"guilds-clans.php?op=nonmember&action=join&task=spy&id=".$guildID);
                                    output("`0You are already a member of the ".$ThisGuild['Name']."`0 Guild",true);
                                    output("`n`0But you can try and spy - you might get lucky!");
                                }
                            }
                        } else {
                            // You are not a member of any other Guild
                            output("`n`nIf you join the Guild you will be required to adhere to the rules");
                            output("`n`n`&`cRules`c",true);
                            output("`n`c~~~`c",true);
                            output("`n`c".$ApplyGuild['RulesText']."`c",true);
                            output("`0<form action='guilds-clans.php?op=nonmember&action=join&task=submit&id=".$guildID."' method='POST'>",true);
                            output("`n`n`c<input type='submit' name='submit' class='button' value='Apply'>`c",true);
                            output("`n`c<input type='submit' name='submit' class='button' value='Forget it'>`c",true);
                            addnav("","guilds-clans.php?op=nonmember&action=join&task=submit&id=".$guildID);
                        }
                    break;

                    case "submit":
                        $buttonClicked=$_POST['submit'];
                        $guildID=$HTTP_GET_VARS['id'];

                        if ($buttonClicked=="Apply") {
                            $ApplyGuild=&$session['guilds'][$guildID];
                            // This won't handle applications to multiple Guilds!
                            $ApplicantList=array(); $ApplicantList=&$ApplyGuild['ApplicantList'];
                            if (array_key_exists($session['user']['acctid'],$ApplicantList)==true) {
                                output("You have already applied to join this guild");
                            } else {
                                $ApplicantList[$session['user']['acctid']]="";
                                update_guild_info($ApplyGuild);
                                if ($ApplyGuild['HeadOfMembership']!=0) {
                                    $MailTo=$ApplyGuild['HeadOfMembership'];
                                } else {
                                    $MailTo=$ApplyGuild['GuildLeader'];
                                }

                                systemmail($MailTo,"`%You have an application to join the Guild!`0",
                                    ($session['user']['name'])."`& has applied to join the ".$ApplyGuild['Name']." `&Guild", $session[user]['acctid']);
                                $sql="select name from accounts where acctid=".$MailTo; // Determine the name of the person - makes the mail pretty
                                $result=db_query($sql);
                                $row=db_fetch_assoc($result);

                                systemmail($session['user']['acctid'],"`%You have applied to join the ".$ApplyGuild['Name']." `%Guild!`0",
                                    "Your application has been submitted to ".$row['name'],$MailTo);
                                output("`nYour Application for membership has been submitted");
                                output("`nCheck your mail for notification of your membership");
                            } // Array_Key_Exists
                        } else {
                            $ApplyGuild=&$session['guilds'][$guildID];
                            output("`n`0You decide to back away from joining the ".$ApplyGuild['Name']." `0Guild",true);
                            strollin();
                        } // Button clicked = Apply

                    break;

                    case "spy":
                        $Success = (e_rand(50,100)==76);
                        $guildID=$HTTP_GET_VARS['id'];
                        $SpyGuild=&$session['guilds'][$guildID];
                        output("`n`0You try to spy!");
                        if ($Success) {
                            output("`n`n`0You sneak past the Guild Guards into the office of the management team");
                            output("`n`0With stealth and cunning you manage to open the safe without setting off the alarms!!");
                            $gold = e_rand(($SpyGuild['gold']/10),$SpyGuild['gold']);
                            $gems = e_rand(($SpyGuild['gems']/10),$SpyGuild['gems']);
                            output("`n`nYou manage to steal `^".$gold."`0 Gold and `%".$gems."`0 Gems");
                            $SpyGuild['gold']-=$gold;
                            $SpyGuild['gems']-=$gems;
                            $session['user']['gold']+=$gold;
                            $session['user']['gems']+=$gems;
                            $hitpoints=e_rand(2,20);
                            $experience=e_rand(100,3000);
                            output("`n`0For your bravery you gain an extra `&".$hitpoints." `0Max HitPoints and `&".$experience." `0experience");
                            $session['maxhitpoints']+=$hitpoints;
                            $session['user']['experience']+=$experience;
                            update_guild_info($SpyGuild);
                            $Discovered=(e_rand(1,20)==17);
                            output("`n`nOutside you hear a noise of somebody approaching");
                            output("`n`0You manage to leave through the window before you are seen - but did you put everything back as you should of??");
                            if ($Discovered) {
                                // Inform the leader and head of war about being spied upon
                                systemmail($SpyGuild['GuildLeader'],"`0A Spy has snuck into your guild!!`0",
                                   ($session['user']['name'])."`0 sneaked into the guild offices and managed to steal `^".$gold." `0Gold and `%".$gems."`0 Gems", 0);
                                systemmail($SpyGuild['HeadOfWar'],"`0A Spy has snuck into your guild!!`0",
                                   ($session['user']['name'])."`0 sneaked into the guild offices and managed to steal `^".$gold." `0Gold and `%".$gems."`0 Gems", 0);
                            }

                        } else {
                            output("`n`n`&Yikes..   Spying isn't looked upon lightly by the ".$SpyGuild['Name']." `&Guild",true);
                            output("`n`n`0You are suddently surrounded by warriors, who guard the entrance, carrying short sharp pikes.  The angry ends appear to be pointing at you!!");

                            // Determine the name of the person - makes the mail pretty
                            if ($SpyGuild['HeadOfWar']!=0) {
                                $PersonID=$SpyGuild['HeadOfWar'];
                                $PrettyTitle = "Head of War";
                            } else {
                                $PersonID=$SpyGuild['GuildLeader'];
                                $PrettyTitle = "Guild Leader";
                            }

                            $sql="select name from accounts where acctid=".$PersonID;
                            $result=db_query($sql);
                            $row=db_fetch_assoc($result);

                            output("`n`n`0From the shadows the ".$PrettyTitle." - ".$row['name']." `0walks up with an angry scowl and barks a command to the guards.",true);
                            output("`n`0They grin and suddenly jump you!!");

                            $HPLoss = e_rand(1,$session['user']['hitpoints']);
                            $goldLoss= e_rand(1,$session['user']['gold']);
                            $session['user']['hitpoints']-=$HPLoss;
                            $session['user']['gold']-=$goldLoss;

                            $SpyGuild['gold']+=$goldLoss; //###
                            $SpyGuild['SitePoints']+=(int)($HPLoss/1000);
                            update_guild_info($SpyGuild);

                            output("`n`n`&You lose `4".$HPLoss." `&Hitpoints and `^".$goldLoss." `&gold!!");
                            output("`n`&Bad Luck!!");
                            if ($SpyGuild['GuildLeader']<>0) {
                                systemmail($SpyGuild['GuildLeader'],"`0A Spy has snuck into your guild!!`0",
                                   ($session['user']['name'])."`0 sneaked into the guild offices but your patrols managed detect him and he was caught!", 0);
                            }
                            if ($SpyGuild['HeadOfWar']<>0) {
                                systemmail($SpyGuild['HeadOfWar'],"`0A Spy has snuck into your guild!!`0",
                                   ($session['user']['name'])."`0 sneaked into the guild offices but your patrols managed detect him and he was caught!", 0);
                            }
                            addnews($session['user']['name']." was caught trying to spy on the ".$SpyGuild['Name']."`n They were dealth with severely by the Guards and ".$PrettyTitle."!!");
                        }
                    break;
                }
            break;

            case "examine":
            case "viewintro":
                strollin();
                // View the intro info for a guild
                $guildID=$HTTP_GET_VARS['id'];
                $ThisGuild=&$session['guilds'][$guildID];
                $return=$HTTP_GET_VARS['return'];
                if (isset($return)) {
                    $NavSystem=array();
                    $NavSystem['Return to whence you came']=$return;
                }
                // We have a guild name
                output("`n`n`n`0You wander up to the guild headquarters for the ".$ThisGuild['Name']. "`0 Guild and examine the notice board, looking for information on joining.",true);
                output("`n`n`&`c`iWelcome board`i`c",true);
                output("`n`n`&`c`i`bInformation about our Guild`b`i`c",true);
                output("`%`c~~`c",true);
                output("`&`c".$ThisGuild['PublicText']."`c",true);

                output("`n`n`&`c`i`bInformation for Applicants`b`i`c",true);
                output("`%`c~~`c",true);
                output("`&`c".$ThisGuild['ApplyText']."`c",true);
                $NavSystem[]="~";
                $NavSystem["Applications Entrance"]["`b`qApply to ".$ThisGuild['Name']."`b"]="guilds-clans.php?op=nonmember&action=join&id=".$guildID;
            break;

            case "list":
                strollin();
                if ($HTTP_GET_VARS['type']!="") {
                    $type=($HTTP_GET_VARS['type']=="guilds"?1:0);
                } else {
                    $type=-1;
                }
                switch ($type) {
                    case -1:
                        output("`n`n`&`bGuilds & Clans Available:`b `n`n",true);
                    break;
                    case 0:
                        output("`n`n`&`bClans Available:`b `n`n",true);
                    break;
                    case 1:
                        output("`n`n`&`bGuilds Available:`b `n`n",true);
                    break;
                }

                $sql="SELECT Count(guildID) AS Players, lotbd_guilds.Name as Name, lotbd_guilds.ID as ID, lotbd_guilds.gems as Gems, lotbd_guilds.gold as Gold, lotbd_guilds.Status, lotbd_guilds.IsGuild".
                   " FROM accounts".
                   " RIGHT JOIN lotbd_guilds ON accounts.guildID = lotbd_guilds.ID".
                   " GROUP BY accounts.guildID".
                   " ORDER BY Players Desc, ID DESC";

                $result=db_query($sql);
                $rows=db_num_rows($result);

                $AllGuilds=$session['guilds'];
                if ($rows==0) {
                    output("`nThere are no Guilds or Clans available!");
                    output("Have you considered starting one?");
                } else {
                        output("<table border=0 cellpadding=2 cellspacing=1 bgcolor='#999999' align='center'>",true);
                        output("<tr class='trhead'><td>`bStatus&nbsp;&nbsp;`b</td><td>`bName&nbsp;&nbsp;`b</td><td>`bMembers`b&nbsp;&nbsp;</td>",true);
                    for ($i=0; $i<$rows; $i++) {
                        $row=db_fetch_assoc($result);
                        $ThisGuild=$AllGuilds[$row['ID']];
                        // Guild/Clan Status
                         switch ($row['Status']) {
                                 case "-999":
                                   $statustext="`i`4Denied`i";
                                 break;
                                 case "0":
                                   $statustext="`i`%Pending`i";
                                 break;
                                 case "1":
                                   $statustext="`i`2Active`i";
                                 break;
                                 default:
                                   $statustext="`i`0Unknown`i";
                                 break;
                         }
                        if ($type<0) {
                            output("<tr class='".($i%2?"trlight":"trdark")."'><td>".$statustext."</td><td><a href='guilds-clans.php?op=nonmember&action=examine&id=".$row['ID']."'>".$row['Name']."</td></a><td>".$row['Players']."</td></tr>",true);
                            addnav("","guilds-clans.php?op=nonmember&action=examine&id=".$row['ID']);
                        } else {
                            if ($row['IsGuild']==$type) {
                                output("<tr class='".($i%2?"trlight":"trdark")."'><td>".$statustext."`0</td><td><a href='guilds-clans.php?op=nonmember&action=examine&id=".$row['ID']."'>".$row['Name']."</td></a><td>".$row['Players']."</td></tr>",true);
                                addnav("","guilds-clans.php?op=nonmember&action=examine&id=".$row['ID']);
                            }
                        }
                    }
                    output("</Table>",true);
                }
            break;

            case "create":
                $type=$HTTP_GET_VARS['type'];
                //switch ($type){
                //case "guild":
                output("Guilds`n");
                $status=$HTTP_GET_VARS['status'];
                switch ($status) {
                    case "verifyInfo":
                        // Display data entered by the user
                        $Info=$_POST['info'];
                        $Info['GuildLeader']=$session['user']['acctid'];
                        display_guild_info($Info);

                    break;

                    case "submit":
                        // Submit data to the council
                        $tmp=base64_decode($_POST['info']);
                        $Info=unserialize($tmp);
                        if ($Info!=true) {
                            output("`n`nProblem getting data from Verify Form`n");
                        } else {
                              if ($Info['BadLanguage']!=0) {
                                     output("`n`%*sigh* `&Invalid Language - Try again`n");
                                   display_edit_guild($Info);
                              } else {
                                if ($Info['MissingVitalInfo']==true) {
                                    output("`n`&You are missing mandatory information! Try again.");
                                    display_edit_guild($Info);
                                } else {
                                    unset($Info['BadLanguage']);
                                    unset($Info['MissingVitalInfo']);
                                    $Info['IsGuild']=1;
                                    // Save the Guild info
                                    if (!isset($Info['ID']) or $Info['ID']==0) {
                                        $id=create_guild_info($Info);  // Returns the identity of the user
                                        $session['user']['guildID']=$id;  // Assign the user to the guild

                                        // Define the 2 most basic ranks - apprentice and leader
                                        $ThisRank=array();
                                        $ThisRank['GuildID']=$id;
                                        $ThisRank['RankOrder']=0;
                                        $ThisRank['DisplayTitle']="Apprentice";
                                        $ThisRank['DKRequired']=0;
                                        $ThisRank['AssignedByMgmt']=0;
                                        create_guildrank_info($ThisRank);

                                        $ThisRank=array();
                                        $ThisRank['GuildID']=$id;
                                        $ThisRank['RankOrder']=20;
                                        $ThisRank['DisplayTitle']="Leader";
                                        $ThisRank['DKRequired']=0;
                                        $ThisRank['AssignedByMgmt']=0;
                                        $id=create_guildrank_info($ThisRank);
                                        $session['user']['guildrank']=$id;

                                        output("`n`0The Council Clark looks over the information you have supplied him `&'Humm, everything looks in order.  I'll pass the information onto the Ruling council - they will contact you shortly'");
                                        output("`n`0With a sigh he throws your stack of application forms onto the pile and walks off to get himself a coffee, mumbling under his breath about the paperless office.");
                                    } else {
                                        update_guild_info($Info);
                                        output("`n`0The Council Clark looks over the information you have supplied him `&'Humm, everything looks in order.  I'll update the information now..'");
                                    }
                                }
                              }
                            }
                        break;

                        default:
                            output("[Default]");
                            if (($session['user']['gems']>=$GuildPurchaseCostGems) && ($session['user']['gold']>=$GuildPurchaseCostGold)) {
                                // Grab the cash
                                $session['user']['gems']-=$GuildPurchaseCostGems;
                                $session['user']['gold']-=$GuildPurchaseCostGold;
                                $Info=array();
                                // Load them the cash into the guild
                                $Info['gems']=$GuildPurchaseCostGems;
                                $Info['gold']=$GuildPurchaseCostGold;
                                display_edit_guild($Info);
                            } else {
                                output("`n`0You don't have enough to start a guild - you need `%".$GuildPurchaseCostGems." `0Gems and `^".$GuildPurchaseCostGold." `0Gold");
                            }
                        break;
                    }
                break;

                default:
                break;
            }

        break;



    break;

    default:
        // Are they a member of a guild/Clan
        output("`n`n`0You wander into a majestic street, on either side magestic tall buildings of the guilds and clans loom over you.");
        // Work out what nav's to display
        StrollIn();

    break;
}

    $NavSystem[]="~";
    $NavSystem["D?Display All Guilds/Clans"]="guilds-clans.php?op=nonmember&action=list";
    $NavSystem[]="~";
    $NavSystem["R?Return to Village"]="village.php";

    PopulateNavs();

page_footer();
?>