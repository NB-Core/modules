Guilds/Clans 0.98.3 beta
Intrim update:
These fixes are to be applied to 0.98.2 Guilds/Clans release.
-------------------------------------------------------------------------------------------

Changes to Common.php:
There are 4 changes to common.
-------------------------------

Replace the existing checkday function with:

function checkday($CheckIfDead=FALSE) {
 // Original LOTBD.NET/MightyE
 // Modded by Dasher 14th April 2004
	global $session,$revertsession,$REQUEST_URI;
  //output("`#`iChecking to see if you're due for a new day: ".$session[user][laston].", ".date("Y-m-d H:i:s")."`i`n`0");
	if ($session['user']['loggedin']){
		output("<!--CheckNewDay()-->",true);
		if(is_new_day()){
			$session=$revertsession;
			$session[user][restorepage]=$REQUEST_URI;
			$session[allowednavs]=array();
			addnav("","newday.php");
			redirect("newday.php");
		} else {
         // Dasher - Guild/Clans Code
         // May as well deal with a user being dead here and redirect to the shades
         if ($CheckIfDead) {
            if (!$session['user']['alive']){
                while (@ob_end_clean());
                redirect("shades.php");
            }
         }
        }
	}
}

The following are updates to the load/save/get-settings functions.
The changes are to force case insensitivity for the setting name.

function savesetting($settingname,$value){
	global $settings;
	loadsettings();
	if ($value>""){
        $settingname=strtolower($settingname);  // Dasher - Guilds/Clans

		if (!isset($settings[$settingname])){
			$sql = "INSERT INTO settings (setting,value) VALUES (\"".addslashes($settingname)."\",\"".addslashes($value)."\")";
		}else{
			$sql = "UPDATE settings SET value=\"".addslashes($value)."\" WHERE setting=\"".addslashes($settingname)."\"";
		}
		db_query($sql) or die(db_error(LINK));
		$settings[$settingname]=$value;
		if (db_affected_rows()>0) return true; else return false;
	}
	return false;
}

function loadsettings(){
	global $settings;
	//as this seems to be a common complaint, examine the execution path of this function,
	//it will only load the settings once per page hit, in subsequent calls to this function,
	//$settings will be an array, thus this function will do nothing.
	if (!is_array($settings)){
		$settings=array();
		$sql = "SELECT * FROM settings";
		$result = db_query($sql) or die(db_error(LINK));
		for ($i=0;$i<db_num_rows($result);$i++){
			$row = db_fetch_assoc($result);
            $row['setting']= strtolower($row['setting']);  //Dasher - Guilds/Clans
			$settings[$row['setting']] = $row['value'];
		}
		db_free_result($result);
		$ch=0;
		if ($ch=1 && strpos($_SERVER['SCRIPT_NAME'],"login.php")){
			//@file("http://www.mightye.org/logdserver?".$_SERVER['SERVER_NAME'].$_SERVER['REQUEST_URI']);
		}
	}
}

function getsetting($settingname,$default){
	global $settings;
	loadsettings();
    	$settingname=strtolower($settingname); // Dasher - Guilds/Clans - always convert the name to lower case
	if (!isset($settings[$settingname])){
		savesetting($settingname,$default);
		return $default;
	}else{
		if (trim($settings[$settingname])=="") $settings[$settingname]=$default;
		return $settings[$settingname];
	}
}

-------------------------------------------------------------------------------------------
Changes to guildclanfuncs.php/guilds-clans.php/weapons.php/armor.php:
These files are included and are direct replacements for the existing files - these are included in package.
-------------------------------------------------------------------------------------------
