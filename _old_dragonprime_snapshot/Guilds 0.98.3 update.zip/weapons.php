<?
global $NavSystem;

require_once "common.php";
require_once "guildclanfuncs.php";
checkday();
//
// ----------------------------------------------------------------------------
//
// Weapon.php
// -> Original work by LOTGD.NET/MightyE
// -> Updated to work with the Guilds & Clans Pages & custom weapons
// CR#Dasher#004
// 14th April 2004
// Version: 0.98.2 beta
// The latest version is always runnning at: www.sembrance.uni.cc/rpg
// (c) Dasher [david.ashwood@inspiredthinking.co.uk] 2004
// This module is relased under the LOTGD GNU public license
// You may change/modify this module and it's associated modules as you wish but
// this copyright MUST be retained.
//
// I would apprechiate feedback/updates on how it works and changes you make.
// Dasher
// ------------------------------------
// david.ashwood@inspiredthinking.co.uk
// MSNM: david@ashwood.net
// ----------------------------------------------------------------------------
//
// Has a dynamic return path using &return
// Called witht he &guild=GuildID to activate the guild functionality
// Supports Custom Guild Weapons using the standard weapons table.
// Uses an offset of 1024 in the level field by 1014+(GuildID*10)
// Uses the name of the Head Of War or Guild Leader as the Weapon Smith
// Defaults to MightyE if not called with the guild=GuildID set
// Uses the NavSystem talked about in the Guilds-Clans Pages
//
// ChangeLog
// 14th April 2004
// Fixed some minor bugs around the cost of items
//

If (isset($HTTP_GET_VARS['guild'])) {
    // If we have come here from the guilds pages - &guild=GuildID will be set
    $url_mod="&guild=".$HTTP_GET_VARS['guild'];  // Save the guild ID to return
    $MyGuild=$session['guilds'][$HTTP_GET_VARS['guild']];
    $MgmtTeam=ManagementTeam($MyGuild['ID'],true);
//    $return=$HTTP_GET_VARS['return'];
    $return="guilds-clans.php?op=member&action=shop&id=".$MyGuild['ID'];
    $url_mod.="&return=".urlencode($return);
}

// Determine the Weapon Smith Name
$WeaponSmith=(isset($MyGuild)?
    ($MgmtTeam['Head Of War']!=0?
        $MgmtTeam['Head Of War']['name']:
        $MgmtTeam['Guild Leader']['name']):
    "`!Rex");

// Determine Sex
$sex=(isset($MyGuild)?
    ($MgmtTeam['Head Of War']!=0?
        $MgmtTeam['Head Of War']['sex']:
        $MgmtTeam['Guild Leader']['sex']):
    0);


// Determine the store name as the Guild Name if the Guild Functionality is being used, otherwise uses MightyE
$StoreName=(isset($MyGuild)?
    $MyGuild['Name']:
    "Rex");

// Gives an improved trade in percentage when used from guild pages
$TradeInRatio=(isset($MyGuild)?
    0.85:
    0.75);

// Determines the purchase discount, as set by the guild.
// They can spend SitePoints to get a better discount
// See the Guild/Clans pages for more information
$GuildDiscount=(isset($MyGuild)?
    ($MyGuild['WeaponDiscount']==0?
        0:
        ($MyGuild['WeaponDiscount']/100)):
    0);

page_header(color_sanitize($StoreName)."'s Weapons");
output("`c`b`&".$StoreName."'s Weapons`b`nManaged by ".$WeaponSmith."`c`0`n",true);
$tradeinvalue = round(($session[user][weaponvalue]*$TradeInRatio),0);

$NavSystem["Return"]["Return to the village"]="village.php";

if (isset($MyGuild)) {
    // Links back to the guild and provides an option to display the Guild Defined Weapons
    $NavSystem["Return"]["Return to ".$MyGuild['Name']]=$return;
    $NavSystem["Shop"]["Special Guild Weapons"]="weapons.php?op=guildweapons".$url_mod;
}

switch ($HTTP_GET_VARS['op']) {
    case "peruse":
        // Standard peruse list or normal weapons
        // The weapon cost takes into account any discount from the Guild
        $sql = "SELECT max(level) AS level FROM weapons WHERE level<=".(int)$session[user][dragonkills];
        $result = db_query($sql) or die(db_error(LINK));
        $row = db_fetch_assoc($result);

        $sql = "SELECT * FROM weapons WHERE level = ".(int)$row[level]." ORDER BY damage ASC";
        $result = db_query($sql) or die(db_error(LINK));
        output("`7You stroll up the counter and try your best to look like you know what most of these contraptions do. ");
        output("".$WeaponSmith."`7 looks at you and says, \"`#I'll give you `^".$tradeinvalue." gp `# ");
        output("tradein value for your `5".$session[user][weapon]."`#.  Just click on the weapon you wish to buy, what ever 'click' means`7,\" and ");
        output("looks utterly confused.  ".(($sex==1)?"She":"He")." stands there a few seconds, snapping his fingers and wondering if that is what ");
        output("is meant by \"click,\" before returning to his work: standing there and looking good.");
        output("<table border='0' cellpadding='0'>",true);
        output("<tr class='trhead'><td>`bName`b</td><td align='center'>`bDamage`b</td><td align='right'>`bCost`b</td></tr>",true);
        for ($i=0;$i<db_num_rows($result);$i++){
          $row = db_fetch_assoc($result);
            $bgcolor=($i%2==1?"trlight":"trdark");
            $cost=round($row['value'] * (1-$GuildDiscount),0);
            if ($cost<=($session[user][gold]+$tradeinvalue)){
                output("<tr class='$bgcolor'><td><a href='weapons.php?op=buy&id=".$row[weaponid].$url_mod."'>$row[weaponname]</a></td><td align='center'>$row[damage]</td><td align='right'>".$cost."</td></tr>",true);
                addnav("","weapons.php?op=buy&id=".$row[weaponid].$url_mod."");
            }else{
                output("<tr class='$bgcolor'><td>$row[weaponname]</td><td align='center'>$row[damage]</td><td align='right'>".$cost."</td></tr>",true);
                addnav("","weapons.php?op=buy&id=$row[weaponid]");
            }
        }
        output("</table>",true);
    break;

    case "guildweapons":
        // Displays the custom Weapons defined by the Guild
        $GuildWeaponRef=1014+($MyGuild['ID']*10);  // Determine the offset in the Weapon table Level field
        $sql = "SELECT * FROM weapons WHERE level >= ".$GuildWeaponRef." and level<=".($GuildWeaponRef+9)." ORDER BY damage ASC";
        $result = db_query($sql) or die(db_error(LINK));
        output("`7You stroll up the counter and try your best to look like you know what most of these contraptions do. ");
        output("".$WeaponSmith."`7 smiles slyly and walks to one of the walls, pushing a secret button, a section of wall swings back to display weapons designed specifically by the guild weaponsmith");
        output("".$WeaponSmith."`7 looks at you and says, \"`#I'll give you `^".$tradeinvalue." gp`# ");
        output("tradein value for your `5".$session[user][weapon]."`#.  Just click on the weapon you wish to buy, what ever 'click' means`7,\" and ");
        output("looks utterly confused.  ".(($sex==1)?"She":"He")." stands there a few seconds, snapping his fingers and wondering if that is what ");
        output("is meant by \"click,\" before returning to his work: standing there and looking good.");
        $RowCount=db_num_rows($result);
        if ($RowCount!=0) {
            output("<table border='0' cellpadding='0'>",true);
            output("<tr class='trhead'><td>`bName`b</td><td align='center'>`bDamage`b</td><td align='right'>`bCost`b</td></tr>",true);

            for ($i=0;$i<$RowCount;$i++){
              $row = db_fetch_assoc($result);
                $bgcolor=($i%2==1?"trlight":"trdark");
                $cost=round($row['value'] * (1-$GuildDiscount),0);
                if ($cost<=($session[user][gold]+$tradeinvalue)){
                    output("<tr class='$bgcolor'><td><a href='weapons.php?op=buy&id=".$row[weaponid].$url_mod."'>$row[weaponname]</a></td><td align='center'>$row[damage]</td><td align='right'>".$cost."</td></tr>",true);
                    addnav("","weapons.php?op=buy&id=".$row[weaponid].$url_mod."");
                }else{
                    output("<tr class='$bgcolor'><td>$row[weaponname]</td><td align='center'>$row[damage]</td><td align='right'>".$cost."</td></tr>",true);
                    addnav("","weapons.php?op=buy&id=$row[weaponid]");
                }
            }
            output("</table>",true);
        } else {
            output("`n`n".$WeaponSmith." `7 looks at the empty spaces on the walls and frowns.  \"It looks like I haven't got around to sorting out the weapons yet\" ".(($sex==1)?"she":"he")." mumbles.");
            output("You decide to come back later when things might be better organised.");
        }

    break;

    case "buy":
        // Standard Buy Code, modded to handle discounts for clans
        $sql = "SELECT * FROM weapons WHERE weaponid='$HTTP_GET_VARS[id]'";
        $result = db_query($sql) or die(db_error(LINK));
        if (db_num_rows($result)==0){
            output("".$WeaponSmith."`7 looks at you, confused for a second, then realizes that you've apparently taken one too many bonks on the head, and nods and smiles.");
            $NavSystem["Try again?"]="weapons.php";
        }else{
          $row = db_fetch_assoc($result);
            if ($row[value]>($session[user][gold]+$tradeinvalue)){
              output("Waiting until ".$WeaponSmith."`7 looks away, you reach carefully for the `5$row[weaponname]`7, which you silently remove from the rack upon which ");
                output("it sits.  Secure in your theft, you turn around and head for the door, swiftly, quietly, like a ninja, only to discover that upon reaching ");
                output("the door, the ominous ".$WeaponSmith."`7 stands, blocking your exit.  You execute a flying kick.  Mid flight, you hear the \"SHING\" of a sword ");
                output("leaving its sheath.... your foot is gone.  You land on your stump, and ".$WeaponSmith."`7 stands in the doorway, claymore once again in its back holster, with ");
                output("no sign that it had been used, his arms folded menacingly across ".(($sex==1)?"her ample chest":"his burly chest").".  \"`#Perhaps you'd like to pay for that?`7\" is all he has ");
                output("to say as you collapse at his feet, lifeblood staining the planks under your remaining foot.");
                $session[user][alive]=false;
                debuglog("lost " . $session['user']['gold'] . " gold on hand due to stealing from ".$WeaponSmith."");
                $session[user][gold]=0;
                $session[user][hitpoints]=0;
                $session[user][experience]=round($session[user][experience]*.9,0);
                output("`b`&You have been slain by ".$WeaponSmith."`&!!!`n");
                output("`4All gold on hand has been lost!`n");
                output("`410% of experience has been lost!`n");
                output("You may begin fighting again tomorrow.");
                $NavSystem=array();
                $NavSystem["Daily news"]="news.php";
                addnews("`%".$session[user][name]."`5 has been slain for trying to steal from ".$WeaponSmith."`5's Weapons Shop.");
            }else{
                output("".$WeaponSmith."`7 takes your `5".$session[user][weapon]."`7 and promptly puts a price on it, setting it out for display with the rest of his weapons. ");
                $cost=round($row['value'] * (1-$GuildDiscount),0);
                debuglog("spent " . ($cost-$tradeinvalue) . " gold on the " . $row['weaponname'] . " weapon");
                $session[user][gold]-=$cost;
                $session[user][weapon] = $row[weaponname];
                $session[user][gold]+=$tradeinvalue;
                $session[user][attack]-=$session[user][weapondmg];
                $session[user][weapondmg] = $row[damage];
                $session[user][attack]+=$session[user][weapondmg];
                $session[user][weaponvalue] = $cost;
                output("`n`nIn return, ".(($sex==1)?"she":"he")." hands you a shiny new `5$row[weaponname]`7 which you swoosh around the room, nearly taking off ".$WeaponSmith."'s `7head, which he ");
                output("deftly ducks; you're not the first person to exuberantly try out a new weapon.");
                unset($NavSystem['Shop']);
            }
        }
    break;

    case "":
    default;
        // Standard default code
        if (isset($MyGuild)) output("`n`%Your Guild is Generously giving you a `&".($GuildDiscount*100)."%`% discount on purchases today!`n`n`0");
        output("".$WeaponSmith." `7stands behind a counter and appears to pay little attention to you as you enter, ");
        output("but you know from experience that ".(($sex==1)?"she":"he")." has ".(($sex==1)?"her":"his")." eye on every move you make.  ".(($sex==1)?"She":"He")." may be a humble ");
        output("weapons merchant, but he still carries himself with the grace of a man who has used his weapons ");
        output("to kill mightier ".($session[user][gender]?"women":"men")." than you.`n`n");
        output("The massive hilt of a claymore protrudes above ".(($sex==1)?"her":"his")." shoulder; its gleam in the torch light not ");
        output("much brighter than the gleam off of ".$WeaponSmith."'s`7 bald forehead, kept shaved mostly as a strategic ");
        output("advantage, but in no small part because nature insisted that some level of baldness was necessary. ");
        output("`n`n".$WeaponSmith."`7 finally nods to you, stroking ".(($sex==1)?"her":"his")." goatee and looking like ".(($sex==1)?"she":"he")." wished he could ");
        output("have an opportunity to use one of these weapons.");
        $NavSystem["Shop"]["Peruse Weapons"]="weapons.php?op=peruse".$url_mod;
    break;
}

PopulateNavs();  // The part of the Nav Management System that displays the Nav's
page_footer();
?>
