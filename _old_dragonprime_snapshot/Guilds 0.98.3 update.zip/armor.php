<?
global $NavSystem;

require_once "common.php";
require_once "guildclanfuncs.php";
checkday();

//
// ----------------------------------------------------------------------------
//
// armor.php
// -> Original work by LOTGD.NET/MightyE
// -> Updated to work with the Guilds & Clans Pages & custom weapons
// CR#Dasher#004
// 14th April 2004
// Version: 0.98.2 beta
// The latest version is always runnning at: www.sembrance.uni.cc/rpg
// (c) Dasher [david.ashwood@inspiredthinking.co.uk] 2004
// This module is relased under the LOTGD GNU public license
// You may change/modify this module and it's associated modules as you wish but
// this copyright MUST be retained.
//
// I would apprechiate feedback/updates on how it works and changes you make.
// Dasher
// ------------------------------------
// david.ashwood@inspiredthinking.co.uk
// MSNM: david@ashwood.net
// ----------------------------------------------------------------------------
//
// Has a dynamic return path using &return
// Called witht he &guild=GuildID to activate the guild functionality
// Supports Custom Guild Armor using the standard armor table.
// Uses an offset of 1024 in the level field by 1014+(GuildID*10)
// Uses the name of the Head Of War or Guild Leader as the Weapon Smith
// Defaults to MightyE if not called with the guild=GuildID set
// Uses the NavSystem talked about in the Guilds-Clans Pages
//
// ChangeLog
// 14th April 2004
// Fixed some minor bugs around the cost of items
//

If (isset($HTTP_GET_VARS['guild'])) {
    // If we have come here from the guilds pages - &guild=GuildID will be set
    $url_mod="&guild=".$HTTP_GET_VARS['guild'];  // Save the guild ID to return
    $MyGuild=$session['guilds'][$HTTP_GET_VARS['guild']];
    $MgmtTeam=ManagementTeam($MyGuild['ID'],true);
//    $return=$HTTP_GET_VARS['return'];
    $return="guilds-clans.php?op=member&action=shop&id=".$MyGuild['ID'];
    $url_mod.="&return=".urlencode($return);
}

// Determine the Weapon Smith Name
$Smithy=(isset($MyGuild)?
    ($MgmtTeam['Head Of War']!=0?
        $MgmtTeam['Head Of War']['name']:
        $MgmtTeam['Guild Leader']['name']):
    "`!Sedina");

// Determine Sex
$sex=(isset($MyGuild)?
    ($MgmtTeam['Head Of War']!=0?
        $MgmtTeam['Head Of War']['sex']:
        $MgmtTeam['Guild Leader']['sex']):
    1);

// Determine the store name as the Guild Name if the Guild Functionality is being used, otherwise uses MightyE
$StoreName=(isset($MyGuild)?
    $MyGuild['Name']:
    "Sedina");

// Gives an improved trade in percentage when used from guild pages
$TradeInRatio=(isset($MyGuild)?
    0.85:
    0.75);

// Determines the purchase discount, as set by the guild.
// They can spend SitePoints to get a better discount
// See the Guild/Clans pages for more information
$GuildDiscount=(isset($MyGuild)?
    ($MyGuild['ArmourDiscount']==0?
        0:
        ($MyGuild['ArmourDiscount']/100)):
    0);

page_header(color_sanitize($StoreName)."'s Armory");
output("`c`b`&".$StoreName."'s Armory `b`nManaged by ".$Smithy."`c`0`n",true);
$tradeinvalue = round(($session['user']['armorvalue']*$TradeInRatio),0);

$NavSystem["Return"]["Return to the village"]="village.php";

if (isset($MyGuild)) {
    // Links back to the guild and provides an option to display the Guild Defined Weapons
    $NavSystem["Return"]["Return to ".$MyGuild['Name']]=$return;
    $NavSystem["Shop"]["Special Guild Armor"]="armor.php?op=guildarmor".$url_mod;
}


switch ($HTTP_GET_VARS['op']) {

    case "guildarmor":
        // Displays the custom Armor defined by the Guild
        $GuildRef=1014+($MyGuild['ID']*10);  // Determine the offset in the  table Level field
        $sql = "SELECT * FROM armor WHERE level >= ".$GuildRef." and level<=".($GuildRef+9)." ORDER BY defense ASC";
        $result = db_query($sql) or die(db_error(LINK));
        output("`7You stroll up the counter and try your best to look like you know what most of these contraptions do. ");
        output("".$Smithy."`7 smiles slyly and walks to one of the walls, pushing a secret button, a section of wall swings back to display armor designed specifically by the guild BlackSmith",true);
        output("".$Smithy."`7 looks at you and says, \"`#I'll give you `^".$tradeinvalue." gp`# ",true);
        output("tradein value for your `5".$session['user']['armor']."`#.  Just click on the weapon you wish to buy, what ever 'click' means`7,\" and ");
        output("looks utterly confused.  ".(($sex==1)?"She":"He")." stands there a few seconds, snapping his fingers and wondering if that is what ");
        output("is meant by \"click,\" before returning to his work: standing there and looking good.");
        $RowCount=db_num_rows($result);
        if ($RowCount!=0) {
            output("<table border='0' cellpadding='0'>",true);
            output("<tr class='trhead'><td>`bName`b</td><td align='center'>`bDefense`b</td><td align='right'>`bCost`b</td></tr>",true);

            for ($i=0;$i<$RowCount;$i++){
              $row = db_fetch_assoc($result);
                $bgcolor=($i%2==1?"trlight":"trdark");
                $cost=round($row['value'] * (1-$GuildDiscount),0);
                if ($cost<=($session['user']['gold']+$tradeinvalue)){
                    output("<tr class='$bgcolor'><td><a href='armor.php?op=buy&id=".$row['armorid'].$url_mod."'>".$row['armorname']."</a></td><td align='center'>".$row['defense']."</td><td align='right'>".$cost."</td></tr>",true);
                    addnav("","armor.php?op=buy&id=".$row['armorid'].$url_mod."");
                }else{
                    output("<tr class='$bgcolor'><td>".$row['armorname']."</td><td align='center'>".$row['defense']."</td><td align='right'>".$cost."</td></tr>",true);
                    addnav("","armor.php?op=buy&id=".$row['armorid'].$url_mod);
                }
            }
            output("</table>",true);
        } else {
            output("`n`n".$Smithy." `7 looks at the empty spaces on the walls and frowns.  \"It looks like I haven't got around to sorting out armor yet\" ".(($sex==1)?"she":"he")." mumbles.",true);
            output("You decide to come back later when things might be better organised.");
        }
        unset($NavSystem["Special Guild Armor"]);

    break;

     case "buy":
        $sql = "SELECT * FROM armor WHERE armorid='$HTTP_GET_VARS[id]'";
        $result = db_query($sql) or die(db_error(LINK));
        if (db_num_rows($result)==0){
          output("`#".$Smithy."`5 looks at you, confused for a second, then realizes that you've apparently taken one too many bonks on the head, and nods and smiles.");
            $NavSystem["Try again?"]="armor.php".$url_mod;
        }else{
          $row = db_fetch_assoc($result);
            if ($row['value']>($session['user']['gold']+$tradeinvalue)){
               output("`5Waiting until `#".$Smithy."`5 looks away, you reach carefully for the `%".$row['armorname']."`5, which you silently remove from the stack of clothes on which ",true);
                output("it sits.  Secure in your theft, you begin to turn around only to realize that your turning action is hindered by a fist closed tightly around your ");
                output("throat.  Glancing down, you trace the fist to the arm on which it is attached, which in turn is attached to a very muscular `!MightyE`5.  You try to ");
                output("explain what happened here, but your throat doesn't seem to be able to open up to let your voice through, let alone essential oxygen.  ");
                output("`n`nAs darkness creeps in on the edge of your vision, you glance pleadingly, but futilly at `%".$Smithy."`5 who is staring dreamily at `!MightyE`5, ".(($sex==1)?"her":"his")."",true);
                output("hands clutched next to her face, which is painted with a large admiring smile.");
                $session['user']['alive']=false;
                debuglog("lost " . $session['user']['gold'] . " gold on hand due to stealing from ".$Smithy."");
                $session['user']['gold']=0;
                $session['user']['hitpoints']=0;
                $session['user']['experience']=round($session['user']['experience']*.9,0);
                output("`b`&You have been slain by `!".$Smithy."`&!!!`n",true);
                output("`4All gold on hand has been lost!`n");
                output("`410% of experience has been lost!`n");
                output("You may begin fighting again tomorrow.");
                $NavSystem=array();
                $NavSystem["Daily news"]="news.php";
                addnews("`%".$session['user']['name']."`5 has been slain by `!".$Smithy."`5 for trying to steal from `#".$StoreName."`5' Armor Wagon.");
            }else{
                output("`#".$Smithy."`5 takes your gold, and much to your surprise ".(($sex==1)?"she":"he")." also takes your `%".$session['user']['armor']."`5 and promptly puts a price on it, setting it neatly on another stack of clothes. ",true);
                output("`n`nIn return, you are handed a beautiful  new `%".$row['armorname']."`5.");
                output("`n`nYou begin to protest, \"`@Won't I look silly wearing nothing but a `&".$row['armorname']."`@?`5\" you ask.  You ponder it a moment, and then realize that everyone else in ");
                output("the town is doing the same thing.  \"`@Oh well, when in Rome...`5\"");
                $cost=round($row['value'] * (1-$GuildDiscount),0);
                debuglog("spent " . ($cost-$tradeinvalue) . " gold on the " . $row['armorname'] . " armor");
                $session['user']['gold']-=$cost;
                $session['user']['armor'] = $row['armorname'];
                $session['user']['gold']+=$tradeinvalue;
                $session['user']['defence']-=$session['user']['armordef'];
                $session['user']['armordef'] = $row['defense'];
                $session['user']['defence']+=$session['user']['armordef'];
                $session['user']['armorvalue'] = $cost;
                unset($NavSystem['Shop']);
            }
        }
    break;
    case "browse":
        $sql = "SELECT max(level) AS level FROM armor WHERE level<=".$session['user']['dragonkills'];
        $result = db_query($sql) or die(db_error(LINK));
        $row = db_fetch_assoc($result);

        $sql = "SELECT * FROM armor WHERE level=".$row['level']." ORDER BY value";
        $result = db_query($sql) or die(db_error(LINK));
        output("`5You look over the various pieces of apparal, and wonder if `#".$Smithy."`5 would be so good as to try some of them ",true);
        output("on for you, when you realize that ".(($sex==1)?"she":"he")." is busy staring dreamily at `!MightyE`5 through the window of his shop ");
        output("as he, barechested, demonstrates the use of one of his fine wares to a customer.  Noticing for a moment that ");
        output("you are browsing her wares, ".(($sex==1)?"she":"he")." glances at your ".$session['user']['armor']." and says that ".(($sex==1)?"she":"he")."'ll give you `^".$tradeinvalue." gp`5 for them.");
        output("<table border='0' cellpadding='0'>",true);
        output("<tr class='trhead'><td>`bName`b</td><td align='center'>`bDefense`b</td><td align='right'>`bCost`b</td></tr>",true);
        for ($i=0;$i<db_num_rows($result);$i++){
          $row = db_fetch_assoc($result);
            $bgcolor=($i%2==1?"trlight":"trdark");
            $cost=round($row['value'] * (1-$GuildDiscount),0);
            if ($cost<=($session['user']['gold']+$tradeinvalue)){
                output("<tr class='$bgcolor'><td>
                    <a href='armor.php?op=buy&id=".$row['armorid'].$url_mod."'>".$row['armorname']."</a></td>
                    <td align='center'>".$row['defense']."</td><td align='right'>".$cost."</td></tr>",true);
                addnav("","armor.php?op=buy&id=".$row['armorid'].$url_mod."");
            }else{
                output("<tr class='$bgcolor'><td>".$row['armorname']."</td>
                    <td align='center'>".$row['defense']."</td><td align='right'>".$cost."</td></tr>",true);
                addnav("","armor.php?op=buy&id=".$row['armorid'].$url_mod."");
            }
        }
        output("</table>",true);
    break;

    case "":
    default:
        if (isset($MyGuild)) output("`n`%Your Guild is Generously giving you a `&".($GuildDiscount*100)."%`% discount on purchases today!`n`n`0");
        output("`5The fair and beautiful `#".$Smithy."`5 greets you with a warm smile as you stroll over to ".(($sex==1)?"her":"his")." brightly colored ",true);
        output("gypsy wagon, which is placed, not out of coincidence, right next to `!MightyE`5's weapon shop.  ".(($sex==1)?"Her":"His")." outfit is ");
        output("as brightly colored and outrageous as her wagon, and it is almost (but not quite) enough to make you look away from ".(($sex==1)?"her":"his")." huge ");
        output("gray eyes and flashes of skin between ".(($sex==1)?"her":"his")." not-quite-sufficent gypsy clothes.");
        output("`n`n");
        $NavSystem["Shop"]["Browse `#".$Smithy."`0' wares"]="armor.php?op=browse".$url_mod;
    break;
}


PopulateNavs();  // The part of the Nav Management System that displays the Nav's
Page_footer();
?>
