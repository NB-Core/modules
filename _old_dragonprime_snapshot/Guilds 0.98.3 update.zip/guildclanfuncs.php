<?php
//
// ----------------------------------------------------------------------------
//
// Clans/Guilds Pages: guildclanfuncs.php
// CR#Dasher#004
// 25th March 2004
// Version: 0.98 beta
// The latest version is always runnning at: www.sembrance.uni.cc/rpg
// (c) Dasher [david.ashwood@inspiredthinking.co.uk] 2004
// This module is relased under the LOTGD GNU public license
// You may change/modify this module and it's associated modules as you wish but
// this copyright MUST be retained.
//
// I would apprechiate feedback/updates on how it works and changes you make.
// Dasher
//
// ----------------------------------------------------------------------------
//
require_once "common.php";

// Setting for the guilds/clans - when not set in the settings table
// Purchase cost
$GuildPurchaseCostGems=50;
$GuildPurchaseCostGold=10000;
// Default gold cost for weapon/armour upgrade per lvl
$DefaultWeaponUpgrade=500;
$DefaultArmourUpgrade=500;
// Ratio of the healing cost for guilds
$HealingGuildDiscount=0.95; // Changed to be 0.95 from 0.75, now that the SitePoints can be spent

// Used for the Nav Management system
$NavSystem=array();

function PopulateNavs() {
// Populate the display Nav's for users based on the $NavSystem array

// Examples of use:
//     NavSystem["Separator/Heading"]="";
//     NavSystem["DisplayName"]="url";
//     NavSystem["Separator/Heading"]["DisplayName"]="url";
//
// The array will look after the order and grouping under the headings
// Thinking about adding Separator/heading tags to determine placement
// something like ["Separator/Heading"]["Attributes"]
//     "order"= {[0,1..n]|Top|First|Bottom|Last}
//
    global $NavSystem;
    reset($NavSystem);

    // If the previous is the same, don't display it again
    $key_old=""; $val_old="";
    while (list($key,$val) = each($NavSystem)) {

        if (is_array($val)) {
            addnav($key);
            while (list($key_inner,$val_inner)= each($val)) {
                if (($key_old==$key_inner) and ($val_old==$val_inner)) {
                } else {
                 $key_old=$key_inner; $val_old=$val_inner;
                 addnav($key_inner,$val_inner,true);
                }
            }
        } else {
            if ($val=="") {
                if ($key_old!=$key) {
                    addnav($key);
                    $key_old=$key;
                }
            } else {
                if (is_int($key)) {
                    if ($val_old!=$val) {
                        addnav($val);
                        $val_old=$val;
                    }
                } else {
                    if (($key_old==$key) and ($val_old==$val)) {
                    } else {
                     $key_old=$key; $val_old=$val;
                     addnav($key,$val,true);
                    }
                }
            }
        }
    }
    $s=su_Admin_Allowed(true);
}


function CalcInterestEarned($guildID) {

 global $session;
 $ThisGuild=&$session['guilds'][$guildID];
 $current = mktime(0,0,0,date("m"),date("d"),date("Y"));
 $interest=0;

 if (isset($ThisGuild['PercentOfFightsEarned']['last-interest'])) {
    $prev=$ThisGuild['PercentOfFightsEarned']['last-interest'];
    $daycount=intval(($current-$prev)/(60*60*24));
    if ($daycount>0) {
     if (isset($ThisGuild['PercentOfFightsEarned']['Bank'])) {
        for ($i=$daycount;$i>0;$i--) {
            $interest+=$ThisGuild['gold']*($ThisGuild['PercentOfFightsEarned']['Bank']/100);
        }
        $ThisGuild['gold']+=$interest;
     }
    }
 }
 $ThisGuild['PercentOfFightsEarned']['last-interest']=$current;
 update_guild_info($ThisGuild);
 return $interest;
}

function DisplaySitePoints($guildID) {

 global $session, $HTTP_GET_VARS;
 $ThisGuild=&$session['guilds'][$guildID];
 $MaxInterest=getsetting("maxinterest",10);
 $MaxFightPercent=getsetting("maxfightpercent",$MaxInterest);
 $RatioOfSitePoints=(int)getsetting('RatioOfSitePoints',5);

 $SitePointArray=array(
         "Current Site Point Allocations,title",
         "Bank"=>"Banking Interest,viewonly",
         "FF"=>"Percent Earned from FF,viewonly",
         "PvP"=>"Percent Earned from PvP,viewonly",
         "HealDiscount"=>"Healing Discount,viewonly",
         "TrainDiscount"=>"Training Discount,viewonly",
         "PvPDiscount"=>"PvP Purchase Discount,viewonly",
         "GemPurchaseDiscount"=>"Gem Discount,viewonly",
         "PotionDiscount"=>"Potion Discount,viewonly",
         "WeaponDiscount"=>"Weapon Purchase Discount,viewonly",
         "ArmorDiscount"=>"Armor Purchase Discount,viewonly",
         " ,title"
         );
 $FlatArray=array("Bank"=>$ThisGuild['PercentOfFightsEarned']['Bank'],
    "FF"=>$ThisGuild['PercentOfFightsEarned']['FF'], "PvP"=>$ThisGuild['PercentOfFightsEarned']['PvP'],
    "WeaponDiscount"=>$ThisGuild['WeaponDiscount'], "ArmorDiscount"=>$ThisGuild['ArmourDiscount'],
    "HealDiscount"=>$ThisGuild['HealDiscount'], "TrainDiscount"=>$ThisGuild['TrainDiscount'],
    "PvPDiscount"=>$ThisGuild['PvPDiscount'], "GemPurchaseDiscount"=>$ThisGuild['GemPurchaseDiscount'],
    "PotionDiscount"=>$ThisGuild['PotionDiscount']);

 showform($SitePointArray,$FlatArray,true);

}

function ManageSitePoints($guildID) {
// Spend those site points
global $session, $HTTP_GET_VARS;

$ThisGuild=&$session['guilds'][$guildID];
$stage=$HTTP_GET_VARS['stage'];
$return=CalcReturnPath(true);
$MaxInterest=getsetting("maxinterest",10);
$MaxFightPercent=getsetting("maxfightpercent",$MaxInterest);
$RatioOfSitePoints=(int)getsetting('RatioOfSitePoints',5);

output("`n`&`cCurrent Discounts and SitePoint Allocations`c`n");
displaySitePoints($guildID);

    switch ($stage) {
             default:
                if ($HTTP_GET_VARS['msg']!="") {
                    output("`n`&".$HTTP_GET_VARS['msg']);
                }
                output("`n`n`0You have `&".$ThisGuild['SitePoints']." `0Site Points to spend");
                output("`nFor each ".$RatioOfSitePoints." Site Points spent you get 1% discount`n");
                $checked=false;
                if ($ThisGuild['SitePoints']>0) {
                    output("<form action='".$return."&stage=2' method='POST'>",true);
                    if ((int)$ThisGuild['PercentOfFightsEarned']['Bank']<$MaxInterest) {
                        $checked=true;
                        output("<input type=radio name='type' value='BankInterest' checked> Interest from bank [".$MaxInterest." Max]<br>",true);
                    } else {
                        output("<input type=radio name='type' disabled value='BankInterest'> Interest from bank [".$MaxInterest." Max]<br>",true);
                    }
                    if ($ThisGuild['PercentOfFightsEarned']['PvP']<$MaxFightPercent) {
                        output("<input type=radio name='type' value='FightPercent-PvP' ".((isset($checked) && $checked==true)?"":"checked")."> Percentage Earned from PvP [".$MaxFightPercent." Max]<br>",true);
                    } else {
                        output("<input type=radio name='type' disabled value='FightPercent-PvP'> Percentage Earned from PvP [".$MaxFightPercent." Max]<br>",true);
                    }

                    if ($ThisGuild['PercentOfFightsEarned']['FF']<$MaxFightPercent) {
                        output("<input type=radio name='type' value='FightPercent-FF' ".((isset($checked) && $checked==true)?"":"checked")."> Percentage Earned from FF [".$MaxFightPercent." Max]<br>",true);
                    } else {
                        output("<input type=radio name='type' disabled value='FightPercent-FF'> Percentage Earned from FF [".$MaxFightPercent." Max]<br>",true);
                    }

                    output("<input type=radio name='type' value='HealDiscount' > Healing Discount<br>",true);
                    output("<input type=radio name='type' value='TrainDiscount' > Training Discount<br>",true);
                    output("<input type=radio name='type' value='PvPDiscount' > PvP Purchase Discount<br>",true);
                    output("<input type=radio name='type' value='GemDiscount' > Gem Discount<br>",true);
                    output("<input type=radio name='type' value='PotionDiscount' > Potion Discount<br>",true);
                    output("<input type=radio name='type' value='WeaponDiscount' > Weapon Discount<br>",true);
                    output("<input type=radio name='type' value='ArmorDiscount' > Armor Discount<br>",true);

                    output("<select name=amount>",true);
                    for ($i=0; $i<=((((int)$ThisGuild['SitePoints'])>=4)?4:((int)$ThisGuild['SitePoints'])); $i++) {
                        output("<option value=".$i.">".$i,true);
                    }
                    for ($i=5; $i<=((int)$ThisGuild['SitePoints']); $i=$i+($RatioOfSitePoints)) {
                        output("<option value=".$i.">".$i,true);
                    }
                    output("</Select>",true);

                    output("`n<input type='submit' class='button' value='Transfer'></form>",true);
                    output("<script language='javascript'>document.getElementById('amount').focus();</script>",true);
                    addnav("",$return."&stage=2");
                    return;
                } else {
                    output("`nYou have nothing left to spend");
                }
            break;

            case "2":
                $amt=(int)$_POST['amount'];
                $spendOn=$_POST['type'];
                $change=$amt/5;

                switch ($spendOn) {
                  case "HealDiscount":
                    $change=$amt/5;
                    $ThisGuild['HealDiscount']+=$change;
                    $msg="cheaper healing for your warriors";
                  break;
                  case "TrainDiscount":
                    $change=$amt/5;
                    $ThisGuild['TrainDiscount']+=$change;
                    $msg="discounted training to gain experience";
                  break;
                  case "PvPDiscount":
                    $change=$amt/5;
                    $ThisGuild['PvPDiscount']+=$change;
                    $msg="discounts on buying PvP";
                  break;
                  case "GemDiscount":
                    $change=$amt/5;
                    $ThisGuild['GemPurchaseDiscount']+=$change;
                    $msg="discounts when converting Gems to Gold and back";
                  break;
                  case "PotionDiscount":
                    $change=$amt/5;
                    $ThisGuild['PotionDiscount']+=$change;
                    $msg="discounts when buying potions & buffs";
                  break;

                  case "BankInterest":
                    $msg="better Interest at the bank";
                    if ($change>($MaxInterest-$ThisGuild['PercentOfFightsEarned']['Bank'])) {
                        $change=($MaxInterest-$ThisGuild['PercentOfFightsEarned']['Bank']);
                    }
                    $ThisGuild['PercentOfFightsEarned']['Bank']+=$change;
                  break;
                  case "FightPercent-PvP":
                    if ($change>($MaxFightPercent-$ThisGuild['PercentOfFightsEarned']['PvP'])) {
                        $change=$MaxFightPercent-$ThisGuild['PercentOfFightsEarned']['PvP'];
                    }
                    $ThisGuild['PercentOfFightsEarned']['PvP']+=$change;
                    $msg="getting a higher percent from your members fights in PvP";
                  break;
                  case "FightPercent-FF":
                    if ($change>($MaxFightPercent-$ThisGuild['PercentOfFightsEarned']['FF'])) {
                        $change=$MaxFightPercent-$ThisGuild['PercentOfFightsEarned']['FF'];
                    }
                    $ThisGuild['PercentOfFightsEarned']['FF']+=$change;
                    $msg="getting a higher percent from your members fights in the Forest";
                  break;
                  case "WeaponDiscount":
                    $change=$amt/5;
                    $ThisGuild['WeaponDiscount']+=$change;
                    $msg="cheaper weapons and weapon upgrades";
                  break;
                  case "ArmorDiscount":
                    $change=$amt/5;
                    $ThisGuild['ArmourDiscount']+=$change;
                    $msg="cheaper armor and armor upgrades";
                  break;
                  default:
                    output("Unknown type!");
                    $amt=0;
                    $change=0;
                    $msg="unknown option";
                  break;
                }
                $amt=$change*5;
                $ThisGuild['SitePoints']-=$amt;
                update_guild_info($ThisGuild);
                $return.="&msg=".urlencode("You have spent ".$amt." Site Points to get ".$change."% on ".$msg);
                redirect($return);
            break;
    }

}

function StrollIn() {
// This function ensures members always have the option to enter the guild when using nonmember menu options

global $session, $NavSystem;

        if ($session[user]['guildID']!=0) {
            $ThisGuild=$session['guilds'][$session['user']['guildID']];
            if (IsOnManagementTeam($session['user']['guildID'])) {
                // Allow them in to update the guild Info
                $NavSystem["`0Enter ".$ThisGuild['Name']." `0Guild"]="guilds-clans.php?op=member&action=enter&id=".$session['user']['guildID'];
                output("`n`n`0You are on the management team of the ".$ThisGuild['Name']." `0Guild",true);
            }

            switch ($ThisGuild['Status']) {
                case -999:
                    output("`nThe Guild has been Banned by the Ruling Council");
                    if (!IsOnManagementTeam($session['user']['guildID'])) {
                        $session['user']['guildID']=0;  // unset thier guild
                    } else {
                        output("`nYou may enter and update the guild information, and appeal the decision of the Concil");
                    }
                break;
                case 0:
                    output("`n`nThe Guild is still pending with the Ruling Council");
                    if (IsOnManagementTeam($session['user']['guildID'])) {
                        // On the management team - let them in to manage some functions
                        output("`n`0You may enter and continue to update your Guild.",true);
                    } else {
                        // Come back later
                        output("`nTry again later...");
                    }
                break;
                case 1:
                    if (!IsOnManagementTeam($session['user']['guildID'])) {
                        $NavSystem["`0Enter ".$ThisGuild['Name']." `0Guild"]="guilds-clans.php?op=member&action=enter&id=".$session['user']['guildID'];
                        output("`n`0You are a member of the ".$ThisGuild['Name']." `0Guild",true);
                    }
                break;
            }
        } else {
            $NavSystem["Applications Entrance"]["Join a Guild"]="guilds-clans.php?op=nonmember&action=list&type=guilds";
            $NavSystem["Council Buildings"]["Create a Guild"]="guilds-clans.php?op=nonmember&action=create&type=guild";
        }


        if ($session[user]['clanID']!=0) {
        // Member of a Clan
            $ThisClan=$session['guilds'][$session['user']['clanID']];
            switch ($ThisClan['Status']) {
                case -999:
                    output("`nThe Clan has been Banned by the Ruling Council");
                    $session['user']['guildID']=0;
                break;
                case 0:
                    output("`nThe Clan is still pending with the Ruling Council");
                    output("`nTry again later...");
                break;
                case 1:
                    $NavSystem["`0Enter ".$ThisClan['Name']." `0Clan"]="guilds-clans.php?op=enter&id=".$session['user']['clanID'];
                    output("`n`n`0You are a member of the ".$ThisClan['Name']." `0Clan",true);
                break;
            }
        } else {
            $NavSystem[]="~";
            $NavSystem["Applications Entrance"]["Join a Clan"]="guilds-clans.php?op=nonmember&action=list&type=clans";
            $NavSystem["Council Buildings"]["Create a Clan"]="guilds-clans.php?op=nonmember&action=create&type=clan";
        }

}


function create_guildrank_info($Info) {
    // Create Guild
    // Populate the array information first

     $sql="insert into lotbd_guildranks SET ";
     reset($Info);
     while(list($key,$val)=each($Info)){
         if (substr($key,0,1)!="."){
             if (is_array($val)){
                   $sql.="$key='".addslashes(serialize($val))."', ";
               }else{
                   $sql.="$key='".addslashes($val)."', ";
               }
       }
     }
     $sql = substr($sql,0,strlen($sql)-2);
     $id=db_insert($sql);  // db_insert returns the ID for the new Guild
     return $id;  // Return it - allows the user information to tbe updated
}

function update_guildrank_info($Info) {
// Update the guild information

      $sql="UPDATE lotbd_guildranks SET ";
      reset($Info);
      while(list($key,$val)=each($Info)){
          if (substr($key,0,1)!="."){
              if (is_array($val)){
                    $sql.="$key='".addslashes(serialize($val))."', ";
                }else{
                    $sql.="$key='".addslashes($val)."', ";
                }
        }
      }
      $sql = substr($sql,0,strlen($sql)-2);
      $sql.=" WHERE RankID= ".$Info['rankid'];
      db_query($sql);
}


function WeaponEditor($guildID) {
// Core code taken from the weaponeditor.php page from LOTGD.NET/MightyE
// Modified to enable custom weapons in Guilds/Clans
// Dasher March 2004
global $session, $NavSystem, $_GET,$_POST, $HTTP_GET_VARS,$HTTP_POST_VARS;

    $weaponlevel = (int)$HTTP_GET_VARS['level'];
    $weaponID=$HTTP_GET_VARS['weaponid'];
    $ThisGuild=&$session['guilds'][$guildID];
    $return=CalcReturnPath(true);

    $values = array(1=>48,225,585,990,1575,2250,2790,3420,4230,5040,5850,6840,8010,9000,10350);
    output("`&<h3>Custom Weapons for the ".$ThisGuild['Name']." Guild</h3>`0",true);

     $weaponarray=array(
         "Weapon,title",
         "weaponid"=>"Weapon ID,veryhidden",
         "weaponname"=>"Weapon Name",
         "damage"=>"Damage,enum,1,1,2,2,3,3,4,4,5,5,6,6,7,7,8,8,9,9,10,10,11,11,12,12,13,13,14,14,15,15",
         "Weapon,title");

     switch ($HTTP_GET_VARS['stage']) {
        case "edit":
            output("`nYou pick up one of the gleaming weapons and take it to a nearby bench, for a few modifications.`n`n");
            $sql = "SELECT * FROM weapons WHERE weaponid='".$weaponID."'";
        case "add":
            // Bit of kludge - but it works! ;)
            if ($sql=="") {
                $sql = "SELECT max(damage+1) AS damage FROM weapons WHERE level=".$weaponlevel."";
                output("Pulling a piece of hardened steel, you sit next to the forge, at a handy anvil and begin to craft something new and deadly.`n`n");
            }
             $result = db_query($sql);
             $row = db_fetch_assoc($result);
             output("<form action='".$return."&stage=save&level=".$weaponlevel."' method='POST'>",true);
             addnav("",$return."&stage=save&level=".$weaponlevel);
             showform($weaponarray,$row);
             output("</form>",true);
        break;
        case "del":
            $sql = "DELETE FROM weapons WHERE weaponid='".$weaponID."'";
            db_query($sql);
            redirect($return);
        break;
        case "save":
            if ((int)$HTTP_POST_VARS['weaponid']!=0){
                $damage=(int)$HTTP_POST_VARS['damage'];
                $weaponName=$HTTP_POST_VARS['weaponname'];
                $weaponID=$HTTP_POST_VARS['weaponid'];
                $sql = "UPDATE weapons SET weaponname=\"".$weaponName."\",damage=\"".$damage."\",value=".$values[$damage]." WHERE weaponid='".$weaponID."'";
                db_query($sql);
            }else{
             // Work out the space to fit it into
               $max = 1014+($ThisGuild['ID']*10);
               $full=range($max,($max+9));  // Populate a list of possible values
               $full=array_flip($full); // Switch the values with the keys
               reset($full); // Start from the beginings
               $sql = "SELECT level FROM weapons WHERE level>=".$max." and level<=".($max+9)." ORDER BY level ASC";
               $result=db_query($sql);  // Lets grab what weapons have been defined already
               $RowCount=db_num_rows($result);
               for ($i=0; $i<$RowCount; $i++) {
                    // You are only allowed 9 weapons - $max => $max+9
                    // As you can delete any item in the list, you're going to be left with gaps
                    // We may as well fill these gaps
                    $row=db_fetch_assoc($result);
                    $ID=$row['level'];
                    unset($full[$ID]);
               }
               // We are left with keys in $full which are the gaps available
               $keys=array_keys($full);
               if (count($keys)!=0) {
                   $key=$keys[0];  // Grap the first one available
                   $damage=(int)$HTTP_POST_VARS['damage'];
                   $weaponName=$HTTP_POST_VARS['weaponname'];
                   $weaponID=$HTTP_POST_VARS['weaponid'];
                   $sql = "INSERT INTO weapons (level,damage,weaponname,value) VALUES (".$key.",\"".$damage."\",\"".$weaponName."\",".$values[$damage].")";
                   db_query($sql);
               } else {
                    // NO keys, therefore - we are full up of weapons - max of 9
                   output("You are only allowed 9 custom Weapons!`n Delete an existing one or rename it!");
               }
            }
            redirect($return);
        break;
        case "":
        default:
            output("`n`nYou wander into the Guild Weapon Factory and see the Guilds' master weapon smith busy, at work next to the furnace.");
            output("`nYou begin to think of the victories your warriors could achieve, only if they had the best weapons at their disposal.");
            output("`n`nOn a nearby rack you see the weapons that have already been crafted, gleaming brightly in the flickering torch light.`n");
            $max = 1014+($ThisGuild['ID']*10);
            $sql = "SELECT * FROM weapons WHERE level>=".$max." and level<=".($max+9)." ORDER BY damage";
            $result= db_query($sql) or die(db_error(LINK));
            $RowCount=db_num_rows($result);
            output("`n`n<table border=0 cellpadding=2 cellspacing=1 bgcolor='#999999' align='center'>",true);
            output("<tr class='trhead'>
                    <td>`0`b`cAction`c`b</td>
                    <td>`0`bWeapon Name`b</td><td>`b`^Gold `0Cost`b</td><td>`0`bDamage`b</td><td>`0`b`cGuild Weapon Ref`c`b</td></tr>",true);
            for ($i=0;$i<$RowCount;$i++){
                $row = db_fetch_assoc($result);
                output("<tr class=trlight><td>&nbsp;&nbsp;
                    <a href='".$return."&stage=edit&weaponid=".$row['weaponid']."'>Edit</a>
                    &nbsp;|&nbsp;<a href='".$return."&stage=del&weaponid=".$row['weaponid']."'
                            onClick='return confirm(\"Are you sure you wish to remove this weapon from your arsnel?\");'>Remove</a>&nbsp;&nbsp;</td>",true);
                addnav("",$return."&stage=edit&weaponid=".$row[weaponid]);
                addnav("",$return."&stage=del&weaponid=".$row[weaponid]);
//                    output("<td>`c".$row['weaponid']."`c</td>",true);
                output("<td>".$row['weaponname']."</td>",true);
                output("<td>`c".$row['value']."`c</td>",true);
                output("<td>`c".$row['damage']."`c</td>",true);
                output("<td>`c".$row['level']."`c</td>",true);
                output("</tr>",true);
            }
            output("<tr class=trlight align='center' colspan='5'><td colspan='5' width='100%'><a href='".$return."&stage=add'/>Add New Weapon</a></td></tr>",true);
            addnav("",$return."&stage=add");
            output("</table>",true);
        break;
     }
}

function ArmorEditor($guildID) {
// Core code taken from the armoureditor.php page from LOTGD.NET/MightyE
// Modified to enable custom Armor in Guilds/Clans
// Dasher March 2004
global $session, $NavSystem, $_GET,$_POST, $HTTP_GET_VARS,$HTTP_POST_VARS;

    $armorlevel = (int)$HTTP_GET_VARS['level'];
    $armorID=$HTTP_GET_VARS['armorid'];
    $ThisGuild=&$session['guilds'][$guildID];
    $return=CalcReturnPath(true);

    $values = array(1=>48,225,585,990,1575,2250,2790,3420,4230,5040,5850,6840,8010,9000,10350);
    output("`&<h3>Custom Armor for the ".$ThisGuild['Name']." Guild</h3>`0",true);

    $armorarray=array(
        "Armor,title",
        "armorid"=>"Armor ID,veryhidden",
        "armorname"=>"Armor Name",
        "defense"=>"Defense,enum,1,1,2,2,3,3,4,4,5,5,6,6,7,7,8,8,9,9,10,10,11,11,12,12,13,13,14,14,15,15",
        "Armor,title");

     switch ($HTTP_GET_VARS['stage']) {
        case "edit":
            output("`nYou pick up one of the gleaming pieces of Armor and take it to a nearby bench, for a few modifications.`n`n");
            $sql = "SELECT * FROM armor WHERE armorid='".$armorID."'";
        case "add":
            // Bit of kludge - but it works! ;)
            if ($sql=="") {
                $sql = "SELECT max(defense+1) AS defense FROM armor WHERE level=".$armorlevel."";
                output("Pulling a piece of hardened steel, you sit next to the forge, at a handy anvil and begin to craft something new and protective.`n`n");
            }
             $result = db_query($sql);
             $row = db_fetch_assoc($result);
             output("<form action='".$return."&stage=save&level=".$armorlevel."' method='POST'>",true);
             addnav("",$return."&stage=save&level=".$armorlevel);
             showform($armorarray,$row);
             output("</form>",true);
        break;
        case "del":
            $sql = "DELETE FROM armor WHERE armorid='".$armorID."'";
            db_query($sql);
            redirect($return);
        break;
        case "save":
            if ((int)$HTTP_POST_VARS['armorid']!=0){
                $defense=(int)$HTTP_POST_VARS['defense'];
                $armorName=$HTTP_POST_VARS['armorname'];
                $armorID=$HTTP_POST_VARS['armorid'];
                $sql = "UPDATE armor SET armorname=\"".$armorName."\",defense=\"".$defense."\",value=".$values[$defense]." WHERE armorid='".$armorID."'";
                db_query($sql);
            }else{
             // Work out the space to fit it into
               $max = 1014+($ThisGuild['ID']*10);
               $full=range($max,($max+9));  // Populate a list of possible values
               $full=array_flip($full); // Switch the values with the keys
               reset($full); // Start from the beginings
               $sql = "SELECT level FROM armor WHERE level>=".$max." and level<=".($max+9)." ORDER BY level ASC";
               $result=db_query($sql);  // Lets grab what weapons have been defined already
               $RowCount=db_num_rows($result);
               for ($i=0; $i<$RowCount; $i++) {
                    // You are only allowed 9 weapons - $max => $max+9
                    // As you can delete any item in the list, you're going to be left with gaps
                    // We may as well fill these gaps
                    $row=db_fetch_assoc($result);
                    $ID=$row['level'];
                    unset($full[$ID]);
               }
               // We are left with keys in $full which are the gaps available
               $keys=array_keys($full);
               if (count($keys)!=0) {
                   $key=$keys[0];  // Grap the first one available
                   $defense=(int)$HTTP_POST_VARS['defense'];
                   $armorName=$HTTP_POST_VARS['armorname'];
                   $armorID=$HTTP_POST_VARS['armorid'];
                   $sql = "INSERT INTO armor (level,defense,armorname,value) VALUES (".$key.",\"".$defense."\",\"".$armorName."\",".$values[$defense].")";
                   db_query($sql);
               } else {
                    // NO keys, therefore - we are full up of weapons - max of 9
                   output("You are only allowed 9 custom Armor Items!`n Delete an existing one or rename it!");
               }
            }
            redirect($return);
        break;
        case "":
        default:
            output("`n`nYou wander into the Guild Blacksmith and see the Guilds' master armourer busy, at work next to the furnace.");
            output("`nYou begin to think of the victories your warriors could achieve, only if they had the best armor at their disposal.");
            output("`n`nOn a nearby rack you see the armor that have already been crafted, gleaming solidly in the flickering torch light.`n");
            $max = 1014+($ThisGuild['ID']*10);
            $sql = "SELECT * FROM armor WHERE level>=".$max." and level<=".($max+9)." ORDER BY defense";
            $result= db_query($sql) or die(db_error(LINK));
            $RowCount=db_num_rows($result);
            if ($RowCount!=0) {
                output("`n`n<table border=0 cellpadding=2 cellspacing=1 bgcolor='#999999' align='center'>",true);
                output("<tr class='trhead'>
                        <td>`0`b`cAction`c`b</td>
                        <td>`0`bArmor Item Name`b</td><td>`b`^Gold `0Cost`b</td><td>`0`bdefense`b</td><td>`0`b`cGuild Armor Ref`c`b</td></tr>",true);
                for ($i=0;$i<$RowCount;$i++){
                    $row = db_fetch_assoc($result);
                    output("<tr class=trlight><td>&nbsp;&nbsp;
                        <a href='".$return."&stage=edit&armorid=".$row['armorid']."'>Edit</a>
                        &nbsp;|&nbsp;<a href='".$return."&stage=del&armorid=".$row['armorid']."'
                                onClick='return confirm(\"Are you sure you wish to remove this armor from your stores?\");'>Remove</a>&nbsp;&nbsp;</td>",true);
                    addnav("",$return."&stage=edit&armorid=".$row['armorid']);
                    addnav("",$return."&stage=del&armorid=".$row['armorid']);
//                    output("<td>`c".$row['weaponid']."`c</td>",true);
                    output("<td>".$row['armorname']."</td>",true);
                    output("<td>`c".$row['value']."`c</td>",true);
                    output("<td>`c".$row['defense']."`c</td>",true);
                    output("<td>`c".$row['level']."`c</td>",true);
                    output("</tr>",true);
                }
                output("<tr class=trlight align='center' colspan='5'><td colspan='5' width='100%'><a href='".$return."&stage=add'/>Add New Armor</a></td></tr>",true);
                addnav("",$return."&stage=add");
                output("</table>",true);
            } else {
                // We have no records
                output("No custom Armor has been defined`n`n");
                output("`n`n<table border=0 cellpadding=2 cellspacing=1 bgcolor='#999999' align='center'>",true);
                output("<tr class='trhead'>
                        <td>`0`b`cAction`c`b</td>
                        <td>`0`bArmor Item Name`b</td><td>`b`^Gold `0Cost`b</td><td>`0`bdefense`b</td><td>`0`b`cGuild Armor Ref`c`b</td></tr>",true);
                output("<tr class=trlight colspan='5'><td colspan='5' width='100%'>&nbsp;</td></tr>",true);
                output("<tr class=trlight align='center' colspan='5'><td colspan='5' width='100%'><a href='".$return."&stage=add'/>Add New Armor</a></td></tr>",true);
                addnav("",$return."&stage=add");
                output("</table>",true);
            }
        break;
     }
}

function display_guild_discounts($guildID) {
    //
    // Dicounts that the guild have purchased
    // The idea is that the guild have a membership card, which can be presented to stores on the site
    // they then get a discount
    // Helps promote guilds and shows that the guilds are doing something for the member
    //
    output("`n`0Discounts purchased by the Guild");
    output("`c",true);
    displaySitePoints($guildID);
    output("`c",true);
}

function AssignRank($guildID) {

// Assign one or more members to a rank

 global $HTTP_GET_VARS, $_POST;
 $stage=$HTTP_GET_VARS['stage'];

 switch ($stage) {
    case "2":
        $who=$_POST['who'];
        if ($who!="") {
            $toRankID=$_POST['sections'];
            $sql="update accounts set guildrank=".$toRankID." where acctid in (".$who.")";
            db_query($sql);
            output("`nMembers have been assigned the new rank!");
        } else {
            output("You need to select somebody first!!");
        }
    break;

    default:
        $return=CalcReturnPath();
        $who=$HTTP_GET_VARS['who'];
        if (isset($who)) {
            $friendlyName = ListToNames($who);
            output("`0Assign ".$friendlyName." `0to a new rank",true);
        } else {
            $who=$_POST['checked'];
            if ($who!="") {
                $keys=array_keys($_POST['checked']);
                $who="";
                for ($i=0; $i<count($keys);$i++) {
                    $who.=$keys[$i].(($i==count($keys)-1)? "":",");
                }
                $PeopleToPromote=ListToNames($who, false);
                output("`n`0Assign ".$PeopleToPromote." `0to a new rank",true);
            } else {
                // Nobody has been selected at all!
                output("Nobody has been selected!");
                return;
            }
        }
        $ranks=populateranks($guildID);
        output("<form action='".$return."&stage=2' method='POST'>",true);
        addnav("",$return."&stage=2");
        output("`n`nAssign Members to the Rank of: ");
        output("<input type='hidden' name='who' value='".$who."'/>",true);
        output("<SELECT NAME=sections >",true);
        foreach ($ranks as $rank) {
            output("<OPTION value='".$rank['rankid']."'>".$rank['displaytitle']."</OPTION>",true);
        }
        output("</SELECT>",true);
        output("<script language='javascript'>document.getElementById('sections').focus();</script>",true);
        output("`n<input type='submit' class='button' value='Save'/>",true);
        output("</form>",true);
    break;
 }
}


function PromoteMember($guildID) {

// Promote member to the management team

 global $HTTP_GET_VARS, $_POST, $session;
 $stage=$HTTP_GET_VARS['stage'];

 switch ($stage) {
    case "2":
        $who=$_POST['who'];
        if ($who!="") {
            $toPosition=$_POST['sections'];
            $ThisGuild=&$session['guilds'][$guildID];
            switch ($toPosition) {
                case "leader":
                    $ThisGuild['GuildLeader']=$who;
                break;
                case "how":
                    $ThisGuild['HeadOfWar']=$who;
                break;
                case "hom":
                    $ThisGuild['HeadOfMembership']=$who;
                break;
            }
            update_guild_info($ThisGuild);
            output("The member has been promoted!!!");
        } else {
            output("You need to select somebody first!!");
        }
    break;

    default:
        $who=$HTTP_GET_VARS['who'];
        $return=CalcReturnPath();
        if (isset($who)) {
             output("<form action='".$return."&stage=2' method='POST'>",true);
             addnav("",$return."&stage=2");
             output("`n`nPromote Member to the Rank of: ");
             output("<input type='hidden' name='who' value='".$who."'/>",true);
             // Promote member to the management team
             output("`n`nPromote Member to: ");
             // Display a list of ranks in a drop down box that the member can be promoted to.
             output("<SELECT NAME=sections >",true);
             output("<OPTION value=leader>Leader</OPTION>",true);
             output("<OPTION value=how>Head of War</OPTION>",true);
             output("<OPTION value=hom>Head of Membership</OPTION>",true);
             output("</SELECT>",true);
             output("<script language='javascript'>document.getElementById('sections').focus();</script>",true);
             output("`n<input type='submit' class='button' value='Save'/>",true);
             output("</form>",true);
        } else {
            // Nobody has been selected at all!
            output("Nobody has been selected!");
            return;
        }
    break;
 }
}


function ManageRanks($guildID) {
    // Display and manage the ranks for this guild
    global $session, $HTTP_POST_VARS, $HTTP_GET_VARS, $_POST, $_GET;

    $ranks=PopulateRanks($guildID);

    $ThisGuild=&$session['guilds'][$guildID];
    $ThisRankID = $HTTP_GET_VARS['item'];
    $stage=$HTTP_GET_VARS['stage'];

    output("`n`c~~ Manage Ranks ~~`c");

    switch ($stage) {
        case "save":
            $ThisRank = $HTTP_POST_VARS['SaveRank'];
            if (isset($ThisRank['assignedbymgmt'])) $ThisRank['assignedbymgmt']=1;
            if (isset($HTTP_POST_VARS['newitem'])) {
                if (($ThisRank['rankorder']<=0) or ($ThisRank['rankorder']>=20)) {
                    // You cannot add something which conflicts with the defaults
                    output("`nYou cannot add a Rank with a Rank Order less than 1 or greater then 19");
                } else {
                    $ThisRank['guildid']=$guildID;
                    $id=create_guildrank_info($ThisRank);
                    redirect("guilds-clans.php?op=manage&action=manageranks&id=".$guildID);
                }
            } else {
                // Save changes
                if (($ThisRank['rankorder']<0) or ($ThisRank['rankorder']>20)) {
                    output("`nYou cannot add ranks with a Rank Order less than 1 or greater then 19");
                } else {
                    update_guildrank_info($ThisRank);
                    redirect("guilds-clans.php?op=manage&action=manageranks&id=".$guildID);
                }
            }
        break;

        case "edit":
            $ThisRank=$ranks[$ThisRankID];
            $return=CalcReturnPath(true);
            output("<form action='".$return."&stage=save' method='POST'>",true);
            output("<input type='hidden' name='SaveRank[rankid]' value='".$ThisRank['rankid']."'/>",true);
            output("Title: <input name='SaveRank[displaytitle]' id='Title' width='20' value='".safedisplaystring($ThisRank['displaytitle'])."'/>`n",true);
            if (($ThisRank['rankorder']==0) or ($ThisRank['rankorder']==20)){
                output("<input type=hidden name='SaveRank[rankorder]' width='5' value='".$ThisRank['rankorder']."'/>",true);
                output("Order: `idefault`i`n",true);
            } else {
                output("Order: <input name='SaveRank[rankorder]' width='10' value='".$ThisRank['rankorder']."'/>`n",true);
            }
            output("DK's Require for Rank: <input name='SaveRank[dkrequired]' width='10' value='".$ThisRank['dkrequired']."'/>`n",true);
            output("Assigned by Mgmt: <input type='checkbox' name='SaveRank[assignedbymgmt]' ".(($ThisRank[assignedbymgmt]==true)?"CHECKED":"").">`n",true);
            output("<script language='javascript'>document.getElementById('Title').focus();</script>",true);
            output("`n<input type='submit' class='button' value='Save'/>",true);
            output("</form>",true);
            addnav("",$return."&stage=save");

        break;

        case "remove":
            // Remove this Rank
            // First update all users with this rankID to the rank below this one
            // You cannot remove 0- apprentice or 20-Leader
            $oldRankID=$HTTP_GET_VARS['item'];
            if (($oldRankID==0) or ($oldRankID==20)) {
                output("`nYou cannot remove the default Guild Ranks");
            } else {
                $oldRank=$ranks[$oldRankID];
                $sql = "select RankID from lotbd_guildranks where guildID=".$guildID." and rankorder < ".$oldRank['rankorder']." order by rankorder desc limit 0,1";
                $result = db_query($sql);
                $row = db_fetch_assoc($result);
                $NewRankID = $row['RankID'];
                $newRank=$ranks[$NewRankID];
                $sql="update accounts set guildrank=".$NewRankID." where guildid=".$guildID." and GuildRank=".$oldRankID;
                output("Changing Warriors from ".$oldRank['displaytitle']." to ".$newRank['displaytitle'].".");
                // Remove this Rank from the table
                db_query($sql);
                $sql = "delete from lotbd_guildranks where guildid=".$guildID." and rankid=".$oldRankID;
                db_query($sql);
            }
            header("Refresh: 5; URL=guilds-clans.php?op=manage&action=manageranks&id=".$guildID);
            addnav("","guilds-clans.php?op=manage&action=manageranks&id=".$guildID);
        break;

        case "add":
            $return=CalcReturnPath();
            output("<form action='".$return."&stage=save' method='POST'>",true);
            output("<input type='hidden' name='newitem' value='true'/>",true);
            output("Title: <input name='SaveRank[displaytitle]' id='Title' width='20' value='".$ThisRank['displaytitle']."'/>`n",true);
            output("Order: <input name='SaveRank[rankorder]' width='10' value='".$ThisRank['rankorder']."'/>`n",true);
            output("DK's Require for Rank: <input name='SaveRank[dkrequired]' width='10' value='".$ThisRank['dkrequired']."'/>`n",true);
            output("Assigned by Mgmt: <input type='checkbox' name='SaveRank[assignedbymgmt]' >`n",true);
            output("<script language='javascript'>document.getElementById('Title').focus();</script>",true);
            output("`n<input type='submit' class='button' value='Save'/>",true);
            output("</form>",true);
            addnav("",$return."&stage=save");
        break;

        default:
            // Display the ranks that have been defined
            // Ranks with a RankOrder of 0 & 20 are default and cannot be removed

            // Display the people at this rank
            $sql="select accounts.guildid, count(accounts.guildrank), lotbd_guildranks.rankid, lotbd_guildranks.rankorder
                    from accounts left join lotbd_guildranks on accounts.guildrank=lotbd_guildranks.rankid
                    where accounts.guildid=".$guildID."
                    group by accounts.guildrank
                    order by lotbd_guildranks.rankorder DESC";


            output("`n`n<table border=0 cellpadding=2 cellspacing=1 bgcolor='#999999' align='center'>",true);
            output("<tr class='trhead'><td>`bAction`b</td><td>Rank Order</td><td>`bTitle`b</td><td>`bDK Required`b</td><td>`bAssigned by Mgmt`b</td></tr>",true);

            $i=0;
            foreach ($ranks as $ThisRank){
                output("<tr class='".($i%2?"trlight":"trdark")."'><td>",true);
                output("<a href='guilds-clans.php?op=manage&action=manageranks&stage=edit&id=".$guildID."&item=".$ThisRank['rankid']."'>&nbsp;&nbsp;Edit&nbsp;</a>",true);
                if (($ThisRank['rankorder']==0) or ($ThisRank['rankorder']==20)) {
                    // Special Rank
                    output("</td><td>default (".$ThisRank['rankorder'].")</td>",true);
                } else {
                    // Standard Rank
                    output("<a href='guilds-clans.php?op=manage&action=manageranks&stage=remove&id=".$guildID."&item=".$ThisRank['rankid']."'>&nbsp;Remove</a></td?>",true);
                    output("<td>".$ThisRank['rankorder']."</td>",true);
                }
                output("<td>".$ThisRank['displaytitle']."</td>",true);
                output("<td>".$ThisRank['dkrequired']."</td>",true);
                output("<td><input type='checkbox' disabled name='SaveRank[assignedbymgmt]' ".(($ThisRank[assignedbymgmt]==true)?"CHECKED":"")."></td>",true);
                addnav("","guilds-clans.php?op=manage&action=manageranks&stage=remove&id=".$guildID."&item=".$ThisRank['rankid']);
                addnav("","guilds-clans.php?op=manage&action=manageranks&stage=edit&id=".$guildID."&item=".$ThisRank['rankid']);
                $i++;
            }
            output("<tr class='trlight'><td>".
                "<a href='guilds-clans.php?op=manage&action=manageranks&stage=add&id=".$guildID."'>&nbsp;Add New</a></td></tr>",true);
            addnav("","guilds-clans.php?op=manage&action=manageranks&stage=add&id=".$guildID);
            output("</TABLE>`n",true);
        break;
    }
}

function PayMember($guildID, $who) {

// Pay a member a some gold/gems from the guild funds

    global $session, $HTTP_GET_VARS;
    $stage=$HTTP_GET_VARS['stage'];
    $ThisGuild=&$session['guilds'][$guildID];
    $MemberName = ListToNames($who, true);
    switch ($stage) {
             default:
// Transfer Sequence
                if (($ThisGuild['gold']<=0) and ($ThisGuild['gems'])) {
                    output("`6The little transfer gnome tells you that he refuses to transfer money for someone who is in debt.");
                    return;
                }
                output("`6`bTransfer To Member`b:`n");
                output("You may transfer Gold or Gems to your Guild `^".$MemberName."",true);
                // Unlimited transfer
                $return=CalcReturnPath();
                output("<form action='".$return."&who=".$who."&stage=2' method='POST'>",true);
                if ($ThisGuild['gold']>0) output("<input type=radio name='type' value='gold' checked> Gold<br>",true);
                if ($ThisGuild['gems']>0) output("<input type=radio name='type' value='gems'> Gems<br>",true);
                output("Transfer <u>h</u>ow much: <input name='amount' id='amount' accesskey='h' width='5'>`n",true);
                output("`n<input type='submit' class='button' value='Transfer'></form>",true);
                output("<script language='javascript'>document.getElementById('amount').focus();</script>",true);
                addnav("",$return."&who=".$who."&stage=2");
            break;

            case "2":
                $amt = abs((int)$_POST['amount']);
                $type = $_POST['type'];
                output("`6`bTransfer Completion`b`n");
                switch ($type) {
                    case "gold":
                        if ($ThisGuild['gold']<$amt){
                            output("`6How can you transfer `^$amt`6 gold when you only possess ".($ThisGuild['gold'])."`6?");
                        }else{
                            debuglog(" `&from the ".$ThisGuild['Name']." transferred ".$amt." gold to ".$MemberName,$who);
                            $ThisGuild['gold']-=$amt;
                            $sql= "update accounts set gold=gold+".$amt." where acctid=".$who;
                            db_query($sql);
                            update_guild_info($ThisGuild);
                            output("`6Transfer Completed!");
                        }
                    break;
                    case "gems":
                        if ($ThisGuild['gems']<$amt){
                            output("`6How can you transfer `%$amt`6 gems when you only possess ".($ThisGuild['gems'])."`6?");
                        }else{
                            debuglog("`& from the ".$ThisGuild['Name']." transferred ".$amt." gems to ".$MemberName,$who);
                            $ThisGuild['gems']-=$amt;
                            $sql= "update accounts set gems=gems+".$amt." where acctid=".$who;
                            db_query($sql);
                            update_guild_info($ThisGuild);
                            output("`6Transfer Completed!");
                        }

                    break;
                }
                break;
            }

}

function transfer_cash($guildID, $stage=0) {

// Allows members to donate to the guild/clan

    global $session, $HTTP_GET_VARS, $_POST;
    $stage=$HTTP_GET_VARS['stage'];

    $ThisGuild=&$session['guilds'][$guildID];
    switch ($stage) {
             default:
// Transfer Sequence
                output("`&`bTransfer Money`b:`n`0");
                if ($session['user']['goldinbank']>=0){
                    output("`0You may transfer `^Gold `0or `%Gems `0to your Guild `^".$ThisGuild['Name']."`0");
                    // Unlimited transfer
                    $return=CalcReturnPath(true);
                    output("<form action='".$return."&stage=2' method='POST'>",true);
                    output("<input type=radio name='type' value='gold' checked> `^Gold`0<br>",true);
                    output("<input type=radio name='type' value='gems'> `%Gems`0<br>",true);
                    output("`0Transfer <u>h</u>ow much: <input name='amount' id='amount' accesskey='h' width='5'>`n",true);
                    output("`n<input type='submit' class='button' value='Transfer'></form>",true);
                    output("<script language='javascript'>document.getElementById('amount').focus();</script>",true);
                    addnav("",$return."&stage=2");
                }else{
                    output("`&The little gnome tells you that he refuses to transfer money for someone who is in debt.");
                }
                break;

            case "2":
                $amt = abs((int)$_POST['amount']);
                $type = $_POST['type'];
                output("`&`bTransfer Completion`b`n`0");
                switch ($type) {
                    case "gold":
                        if ($session['user']['gold']+$session['user']['goldinbank']<$amt){
                            output("`6How can you transfer `^$amt`6 gold when you only possess ".($session['user']['gold']+$session['user']['goldinbank'])."`6?");
                        }else{
                            debuglog($session['user']['Name']."transferred ".$amt." gold to ".$ThisGuild['Name']);
                            $session['user']['gold']-=$amt;
                            if ($session['user']['gold']<0){ //withdraw in case they don't have enough on hand.
                                $session['user']['goldinbank']+=$session['user']['gold'];
                                $session['user']['gold']=0;
                            }
                            $session['user']['amountouttoday']+= $amt;
                            $ThisGuild['gold']+=$amt;
                            update_guild_info($ThisGuild);
                            output("`n`&You have sucessfully transferred `^".$amt." `&Gold!");
                        }
                    break;
                    case "gems":
                        if ($session['user']['gems']+$session['user']['gemsinbank']<$amt){
                            output("`6How can you transfer `^$amt`6 gems when you only possess ".($session['user']['gems']+$session['user']['gemsinbank'])."`6?");
                        }else{
                            debuglog($session['user']['Name']."transferred ".$amt." gems to ".$ThisGuild['Name']);
                            $session['user']['gems']-=$amt;
                            if ($session['user']['gems']<0){ //withdraw in case they don't have enough on hand.
                                $session['user']['gemsinbank']+=$session['user']['gold'];
                                $session['user']['gems']=0;
                            }
                            $ThisGuild['gems']+=$amt;
                            update_guild_info($ThisGuild);
                            output("`n`&You have sucessfully transferred `%".$amt." `&Gems!");
                        }

                    break;
                }
                break;
            }
}

function display_weapon_upgrade($guildID) {
//
// Upgrade a weapon
// Cost of upgrading is progressively more expensive
//

 global $session, $DefaultWeaponUpgrade, $HTTP_GET_VARS;
 $UpgradePrice=((getsetting("WeaponUpgradeCost",$DefaultWeaponUpgrade)*$session['user']['level'])*0.9);
 $logInc=log($session['user']['weapondmg']+2);
 $UpgradePrice=round($UpgradePrice*$logInc,0);
 $stage=(isset($HTTP_GET_VARS['stage']))?$HTTP_GET_VARS['stage']:"1";

 switch ($stage){
    case "2":
        output("`0You dig into your pouch ");
        if ($session['user']['gold']>=$UpgradePrice){
            // They can afford it
            output(" and pull out `^".$UpgradePrice." `0in Gold");
            $session['user']['gold']-=$UpgradePrice;
            $session['user']['weaponvalue']+=round(($UpgradePrice*0.1),1);
            $session['user']['attack']++;
            $session['user']['weapondmg']++;
            if (strpos($session['user']['weapon'],"Guild Hardened")==false) {
                $session['user']['weapon']=$session['user']['weapon']." `&[`2Guild Hardened`&]";
            }
            output("`n`0You hand over your trusty weapon to the smithy and after a few deft modifications he hands back your ".$session['user']['weapon'],true);
            output("`n`n`0New wizzy `&`i`bslic'ing and dic'ing`b`i `0widgets have been added");
            output("`n`n`0You feel excited to try it out in the fields - or what about checking out the Guild Hit List!!");
        } else {
            // They cannot
            output("`0and find nothing....");
            output("`n`n`&It's cheap here - but it's not free!!`n Come back when you can afford it.");
        }
    break;

    case "1":
    default:
        $return=CalcReturnPath();
        output("`n`0You wander down into the bowls of the guild where an old, gnarled smithy works at a hot furnace.");
        output("`n`0Here you can buy discounted additions to your weapon");
        output("`n`n`0This day you can upgrade your weapon an extra point for the meager sum of `^".$UpgradePrice."`0 Gold - a discount of 10% on the usual upgrade price");
        output("`0<form action='".$return."&stage=2' method='POST'>",true);
        output("`n`n<input type='submit' class='button' value='Upgrade Weapon'>",true);
        addnav("",$return."&stage=2");
    break;
 }

}

function display_armour_upgrade($guildID) {
//
// Upgrade the armour
// Cost of upgrading is progressively more expensive
//

 global $session,$DefaultArmourUpgrade, $HTTP_GET_VARS;
 $UpgradePrice=((getsetting("ArmourUpgradeCost",$DefaultArmourUpgrade)*$session['user']['level'])*0.9);
 $logInc=log($session['user']['armordef']+2);
 $UpgradePrice=round($UpgradePrice*$logInc,0);
 $stage=(isset($HTTP_GET_VARS['stage']))?$HTTP_GET_VARS['stage']:"1";

 switch ($stage){
    case "2":
        output("`0You dig into your pouch ");
        if ($session['user']['gold']>=$UpgradePrice){
            // They can afford it
            output(" and pull out `^".$UpgradePrice." in Gold");
            $session['user']['gold']-=$UpgradePrice;
            $session['user']['armorvalue']+=round(($UpgradePrice*0.1),1);
            $session['user']['defence']++;
            $session['user']['armordef']++;
            if (strpos($session['user']['armor'],"Guild Hardened")==false) {
                $session['user']['armor']=$session['user']['armor']." `&[`2Guild Hardened`&]";
            }
            output("`n`0You hand over your trusty armour to the smithy and after a few deft modifications he updates your ".$session['user']['armor']);
            output("`n`n`0New wizzy `&`b`ideflective plating`i`b `0have been added to protect you in battle.");
        } else {
            // They cannot
            output("and find nothing....");
            output("`n`&It's cheap here - but it's not free!!`n Come back when you can afford it.");
        }
    break;

    case "1":
    default:
        $return=CalcReturnPath();
        output("`n`0You wander down into the bowls of the guild where an old, gnarled smithy works at a hot furnace.");
        output("`n`0Here you can buy discounted modifications to your armour");
        output("`n`n`0This day you can upgrade your armour an extra point for the meager sum of `^".$UpgradePrice."`0 Gold - a discount of 10% on the usual upgrade price");
        output("`0<form action='".$return."&stage=2' method='POST'>",true);
        output("`n`n<input type='submit' class='button' value='Upgrade Armour'>",true);
        addnav("",$return."&stage=2");
    break;
 }
}

function display_healer($guildID) {

// Guild healing
// Main code taken from the LOTGD code - modded by Dasher
// Updated to use the stage system developed for functions
// Fixed a bug in the cost of fixes
// Added the code to use guild discounts for healing
//
    global $session, $HTTP_GET_VARS, $NavSystem, $HealingGuildDiscount;
    $ThisGuild=$session['guilds'][$guildID];

    $loglev = log($session['user']['level']);
    $cost = ($loglev * ($session['user']['maxhitpoints']-$session['user']['hitpoints'])) + ($loglev*10);
    if ($ThisGuild['HealDiscount']==0) {
        $cost*=$HealingGuildDiscount;
    } else {
        $cost*=1-($ThisGuild['HealDiscount']/100);
    }
    $cost=round($cost,0);
    $stage=(isset($HTTP_GET_VARS['stage']))?$HTTP_GET_VARS['stage']:"0";
    $return=CalcReturnPath(true);

    switch ($stage) {
        case "0":
            output("`3A very petite and beautiful brunette looks up as you enter.  \"`6Ahh.. You must be {$session['user']['name']}.`6  I was thought you might be heading my way.  Come in.. come in!`3\" she exclaims.`n`nYou make your way deeper into the surgery.`n`n");
            if ($session['user']['hitpoints'] < $session['user']['maxhitpoints']){
                output("`3\"`6Now.. Let's see here.  Hmmm. Hmmm. You're a bit banged up it seems.`3\"`n`n\"`5Uh, yeah.  I guess.  What will this cost me?`3\" you ask, looking sheepish. \"`5I don't normally get this hurt you know.`3\"`n`n\"`6I know.  I know.  None of you `^ever`6 does.  Anyhow, I can set you right as rain for `$`b$cost`b`6 gold pieces.  I can also give you partial doses at a lower price if you cannot afford a full potion,`3\" says Golinda, smiling.");
                $NavSystem["Potions"]["`^Complete Healing`0"]=$return."&stage=100";
                for ($i=90;$i>0;$i-=10){
                    $NavSystem["Potions"]["$i% - ".round($cost*$i/100,0)."gp"]=$return."&stage=".$i;
                }
            } else {
                output("`3Dr Zeus looks you over carefully.  \"`6Well, you do have that hangnail there, but other than that, you seem in perfect health! `^I`6 think you just came in here because you were lonely,`3\" she chuckles.`n`nRealizing that she is right, and that you are keeping her from other patients, you wander back to the Guild shops.");
            }
        break;

        default:
            $newcost=round($stage*$cost/100,0);
            if ($session['user']['gold']>=$newcost){
                $session['user']['gold']-=$newcost;
                $diff = round(($session['user']['maxhitpoints']-$session['user']['hitpoints'])*$stage/100,0);
                $session['user']['hitpoints'] += $diff;
                output("`3Expecting a foul concoction you begin to up-end the potion.  As it slides down your throat however, you taste cinnamon, honey, and a fruit flavor.  You feel warmth spread throughout your body as your muscles knit themselves back together.  Clear-headed and feeling much better, you hand Golinda the gold you owe and head back to the Guild.");
                output("`n`n`#You have been healed for $diff points!");
                if ($session['user']['hitpoints'] < $session['user']['maxhitpoints']){
                    $NavSystem["Potions"]["`^Complete Healing`0"]=$return."&stage=100";
                    for ($i=90;$i>0;$i-=10){
                        $NavSystem["Potions"]["$i% - ".round($newcost*$i/100,0)."gp"]=$return."&stage=".$i;
                    }
                }
            }else{
                output("`3\"`6Tsk, tsk!`3\" she murmers.  \"`6Maybe you should go visit the Bank and return when you have `b`\$$newcost`6`b gold?`3\" she asks.`n`nYou stand there feeling sheepish for having wasted her time.`n`n\"`6Or maybe a cheaper potion would suit you better?`3\" she suggests kindly.");
            }
        break;
    }
}

function display_practice_field($guildID) {
// Allow users to increase their experience
// Random HP/Attack/Defence upgrades

    output("`nDiscounts purchased by the Guild");
    output("`nThese discounts can be purchased at retailers throughout the empire");
    output("`n`nNone have been purchased (aka not coded yet!)");
}

function edit_hitlist($guildID) {

// Edit the guild hitlist
// Won't display members of the guild/clan in the list of available members

global $session, $HTTP_GET_VARS;
$stage=$HTTP_GET_VARS['stage'];
if ($stage=="") $stage=0;

    $ThisGuild=&$session['guilds'][$guildID];
    $HitListMembers=HitlistToNames($ThisGuild['Hitlist'], true);

    if (count($HitListMembers)==0) {
        output("`n`0There are currently no warriors on the hitlist`n`n");
    } else {
        output("`nThere ".((count($HitListMembers)==1)?"is":"are")." currently ".count($HitListMembers)." warrior".((Count($HitListMembers)==1)?"":"s")." on the hitlist`n`n");
        output("<table border=0 cellpadding=2 cellspacing=1 bgcolor='#999999' align='center'>",true);
        output("<tr class='trhead'><td>`bAction`b</td><td>`bRank`b</td><td>`bName`b</td><td>`bBounty`b</td></tr>",true);
        $return=CalcReturnPath(true);

        foreach ($HitListMembers as $ThisName){
            output("<tr class='".($i%2?"trlight":"trdark")."'><td>".
                "<a href='".$return."&type=remove&id=".$guildID."&who=".$ThisName['acctid']."&stage=2'>Remove</a>".
                "</td><td>".($i+1)."</td><td>",true);
                $link = "bio.php?char=".rawurlencode($ThisName['login']) . "&ret=".URLEncode($_SERVER['REQUEST_URI']);
                output("<a href='".$link."'>",true);
                addnav("",$link);
                output($ThisName['name']);
                output("</a>",true);
                output("</td><td>`^".$ThisName['bounty']."`0 gp</td></tr>",true);

            addnav("",$return."&type=remove&id=".$guildID."&who=".$ThisName['acctid']."&stage=2");
        }
        output("</TABLE>`n",true);
    }

    switch ($stage) {
        case "1":
            // Display results
            $searchname=$_POST['searchname'];
            // Expand name with %
            for ($x=0;$x<strlen($searchname);$x++){
                $search .= substr($searchname,$x,1)."__";
                }
            $searchname="%".$search."%";

            if (!is_array($ThisGuild['Hitlist'])) $ThisGuild['Hitlist']=array();
            $exclusion=implode(",",array_keys($ThisGuild['Hitlist']));  // Remove people currently in the hitlist

            $MyMembers=implode(",",array_keys(FindGuildMembers($guildID,true)));  // You cannot put a bounty on your own members
            if ($exclusion!="") $exclusion.=",";  // Handles when the HitList is empty
            $exclusion.= $MyMembers;    // Exclude guild members
            if ($exclusion=="") {
                // There is ALWAYS a member of the guild
                output("This shouldn't happen - BUG!!!");
            }

            $sql="select * from accounts where name like '%".$searchname."%' and acctid not in (".$exclusion.")";

            $result=db_query($sql);
            $rows=db_num_rows($result);
            if ($rows==0) {
                output("The Search didn't find any results!");
            } else {
                output("The search has found ".$rows." Warrior".(($rows==1)?"":"s").".`n`n");
                output("<table border=0 cellpadding=2 cellspacing=1 bgcolor='#999999' align='center'>",true);
                output("<tr class='trhead'><td>Action</td><td><b>Alive</b></td><td><b>Level</b></td><td><b>Name</b></td><td><b>Location</b></td><td><b>Sex</b></td><td><b>Bounty</b></td>",true);
                $return=CalcReturnPath(true);
                for($i=0;$i<$rows;$i++){
                    $row = db_fetch_assoc($result);
                    output("<tr class='".($i%2?"trdark":"trlight")."'><td>",true);
                    output("<a href='".$return."&type=add&who=".$row['acctid']."&stage=2'>Add to Hitlist</a>",true);
                    addnav("",$return."&type=add&who=".$row['acctid']."&stage=2");
                    output("</td><td>",true);
                    output($row['alive']?"`1Yes`0":"`4No`0");
                    output("</td><td>",true);
                    output("`^".$row['level']."`0");
                    output("</td><td>",true);
                    output("<a href=\"mail.php?op=write&to=".rawurlencode($row['login'])."\" target=\"_blank\" onClick=\"".popup("mail.php?op=write&to=".rawurlencode($row['login'])."").";return false;\"><img src='images/newscroll.GIF' width='16' height='16' alt='Write Mail' border='0'></a>",true);
                    $link = "bio.php?char=".rawurlencode($row[login]) . "&ret=".URLEncode($_SERVER['REQUEST_URI']);
                    output("<a href='".$link."'>",true);
                    addnav("",$link);

                    output("`&".$row['name']."`0");
                    output("</a>",true);
                    output("</td><td>",true);
                    $loggedin=(date("U") - strtotime($row['laston']) < getsetting("LOGINTIMEOUT",900) && $row['loggedin']);
                    output($row['location']
                                ?"`3Boar's Head Inn`0"
                                :(
                                    $loggedin
                                    ?"`#Online`0"
                                    :"`3The Fields`0"
                                    )
                            );
                    output("</td><td>",true);
                    output($row['sex']?"`!Female`0":"`!Male`0");
                    output("</td>",true);
                    output("<td>`^".$row['bounty']."`0 gp</td>",true);
                    output("</tr>",true);
                }
                output("</table>",true);

            }
        break;
        case "2":
            $type=$HTTP_GET_VARS['type'];
            $who=$HTTP_GET_VARS['who'];
            switch ($type) {
                case "add":
                    // Add them to HitList
                    $ThisGuild['Hitlist'][$who]="";
                break;
                case "remove":
                    // Add them to HitList
                    $HitList=&$ThisGuild['Hitlist'];
                    unset($HitList[$who]);
                break;
                default:
                    output("Humm... Now how did we get here?");
                break;
            }

            update_guild_info($ThisGuild);
            redirect("guilds-clans.php?op=manage&action=hitlist&id=".$guildID."&stage=0");

        break;

        case "0":
        default:
            $return=CalcReturnPath();
            output("`0<form action='".$return."&stage=1' method='POST'>",true);
            output("`nName to Search for? <input name='searchname' size=50>",true);
            output("<input type='submit' class='button' value='Seek them out'>",true);
            addnav("",$return."&stage=1");
        break;
    }
}

function display_guild_intro($guildname) {
output("`n`%Guild information for prospective initiates");
}

function ManagementTeam($guildID, $IncludeNames=false) {

// Return the management team (acctid's)
// Guilds have 3 members
// Clans have 1 member
// The keys of the returned array are the table display headings

global $session;
$ThisGuild=&$session['guilds'][$guildID];

    if ($ThisGuild['IsGuild']==1) {
        $mgmt=array();
        $mgmt['Guild Leader']=$ThisGuild['GuildLeader'];
        $mgmt['Head Of War']=$ThisGuild['HeadOfWar'];
        $mgmt['Head Of Membership']=$ThisGuild['HeadOfMembership'];
    } else {
        $mgmt=array();
        $mgmt['Clan Leader']=$ThisGuild['GuildLeader'];
    }

    if ($IncludeNames) {
        $sql_include=implode(",", array_values($mgmt));
        $sql="select accounts.name, accounts.acctid, accounts.guildid, lotbd_guildranks.displaytitle
                        from accounts left join lotbd_guildranks on accounts.guildrank=lotbd_guildranks.rankid and accounts.guildid=lotbd_guildranks.guildid
                        where acctid in (".$sql_include.")";
        $result=db_query($sql);
        $RowCount=db_num_rows($result);

        $results['Guild Leader']=$ThisGuild['GuildLeader'];
        $results['Head Of War']=$ThisGuild['HeadOfWar'];
        $results['Head Of Membership']=$ThisGuild['HeadOfMembership'];

        for ($i=0; $i<$RowCount; $i++) {
            $row=db_fetch_assoc($result);
            $key=array_search($row['acctid'], $mgmt);
            $results[$key]=$row;
        }
        return $results;
    } else {
        return $mgmt;
    }
}

function FindGuildMembers($guildID, $ReturnAsArray=false, $IncludeManagement=true) {

// Return members and their associated rank
// If no rank exists - use the default rank (rankorder=0)
    $ranks = PopulateRanks($guildID);
    // Gotta find the default display title
    foreach ($ranks as $key => $item) {
        if ($item['rankorder']==0) {
            $defaultRankID=$key;
            break;
        }
    }

    if (!$IncludeManagement) {
        // Exclude the management team
        $mgmt=ManagementTeam($guildID);
        $mgmtExclude=implode(",",array_values($mgmt));
        $mgmtExclude=" and accounts.acctid not in (".$mgmtExclude.") ";
    } else {
        // The management team are included
        $mgmtExclude="";
    }

    $sql="select accounts.acctid, accounts.name, accounts.guildid, accounts.guildrank, lotbd_guildranks.displaytitle, accounts.guildrank
            from accounts left join lotbd_guildranks
                on accounts.guildrank=lotbd_guildranks.rankID
                and accounts.guildid=lotbd_guildranks.guildid
            where accounts.guildid=".$guildID." ".$mgmtExclude."
            order by lotbd_guildranks.rankorder desc, accounts.dragonkills Desc, accounts.level DESC, accounts.playerkills DESC";

    $MembersResult=db_query($sql);

    $ListNames="";
    $ArrayResult=array();
    $RowCount=db_num_rows($MembersResult);

    if ($RowCount!=0) {
        for ($i=0;$i<$RowCount;$i++){
            $NameRows = db_fetch_assoc($MembersResult);
            if (!isset($NameRows['displaytitle'])) $NameRows['displaytitle']=$ranks[$defaultRankID]['displaytitle'];
            $ArrayResult[$NameRows['acctid']]=$NameRows;
            $ListNames.=$NameRows['displaytitle']." `&- ".$NameRows['name'];
        }
    } else {
        $ListNames="None";
    }

//db_free_result($NameResult);
  if ($ReturnAsArray!=false) {
    return $ArrayResult;
  } else {
       return $ListNames;
  }
}


function GuildMembers($guildID, $Manage=false) {

// Member Management of the Guilds & Clans
// Manages Management team, Members, applicants and banished warriors
// Need to add an invite to guild option
//###

  global $session;
  $ThisGuild=&$session['guilds'][$guildID];

  // First - work out who the management team is
  //##
  $mgmt=ManagementTeam($guildID,true);
//  $mgmtDetails=ListToNames(array_values($mgmt), true);

  output("`nManagement of the ".$ThisGuild['Name'].(($ThisGuild['IsGuild']==1)?" `0Guild":" `0Clan")."`n`n");
  output("<table border=0 cellpadding=2 cellspacing=1 bgcolor='#999999' align='center'>",true);
  $ManagementTableHeadings = "<tr class='trhead'>";
  $ManagementTableMembers = "<tr class='trdark'>";
  $ManagementTableActions = "<tr class='trlight'>";

  // The headings of the management Team are Dynamic - depending if it is a Guild or a Clan
  while (list($key, $val) = each($mgmt)) {
    // Build up the heading
    $ManagementTableHeadings .= "<td>`b".$key."`b</td>";
    // Build up the members
    if ($val['acctid']==0) {
        $ManagementTableMembers .= "<td>`iVacant`i</td>";
    } else {
        $ManagementTableMembers .= "<td>".$val['name']."</td>";
    }
    // Build up the actions
    // Demote, Banished, Hitlist
    if ($Manage) {
        $ManagementTableActions.="<td><a href='guilds-clans.php?op=manage&action=demote&id=".$guildID."&who=".$val['acctid']."'>[demote]&nbsp;</a>";
        $ManagementTableActions.="<a href='guilds-clans.php?op=manage&action=banish&id=".$guildID."&who=".$val['acctid']."'>[banish]&nbsp;</a>";
        $ManagementTableActions.="<a href='guilds-clans.php?op=manage&action=addtohitlist&id=".$guildID."&who=".$val['acctid']."'>[Add to Hitlist]&nbsp;</a></td>";
        addnav("","guilds-clans.php?op=manage&action=demote&id=".$guildID."&who=".$val['acctid']);
        addnav("","guilds-clans.php?op=manage&action=banish&id=".$guildID."&who=".$val['acctid']);
        addnav("","guilds-clans.php?op=manage&action=addtohitlist&id=".$guildID."&who=".$val['acctid']);
    } else {
        $ManagementTableActions.="";
    }
  }
  output($ManagementTableHeadings."</tr>",true);
  output($ManagementTableMembers."</tr>",true);
  output($ManagementTableActions."</tr>",true);
  output("</table>",true);

  // List all the members of the guild - excluding the management team
  $members=FindGuildMembers($guildID, true, false);
  $MemberCount=count($members);

  if ($MemberCount==0) {
        output("`n`n`i You have no members!`i");
        output("`nIt looks like the management team just sit and talk to themselves.");
  } else {
      output("`n`nMembers of ".$ThisGuild['Name']."`n");
      output("`n`0There ".(($MemberCount==1)?"is":"are")." ".$MemberCount." noble warrior".(($MemberCount==1)?"":"s")." in the Guild`n`n");
      output("<form action='guilds-clans.php?op=manage&action=assignrank&id=".$guildID."' method='POST'>",true);
      addnav("","guilds-clans.php?op=manage&action=assignrank&id=".$guildID."");
      output("<table border=0 cellpadding=2 cellspacing=1 bgcolor='#999999' align='center'>",true);

      if ($Manage) {
        output("<tr class='trhead'><td></td><td>`bAction`b</td><td>`bRank`b</td><td>`bName`b</td></tr>",true);
      } else {
        output("<tr class='trhead'><td>`bRank`b</td><td>`bName`b</td></tr>",true);
      }

      $i=0;
      foreach ($members as $ThisMember){
            if ($Manage) {
                output("<tr class='".($i%2?"trlight":"trdark")."'><td><input id='checked[".$ThisMember['acctid']."]' type='checkbox' name='checked[".$ThisMember['acctid']."]'</></td><td>".
                "<a href='guilds-clans.php?op=manage&action=promotemember&id=".$guildID."&who=".$ThisMember['acctid']."'>[Promote]</a>".
                "<a href='guilds-clans.php?op=manage&action=assignrank&id=".$guildID."&who=".$ThisMember['acctid']."'>&nbsp;[Assign Rank]</a>".
                "<a href='guilds-clans.php?op=manage&action=revokemember&id=".$guildID."&who=".$ThisMember['acctid']."'>&nbsp;[Revoke]</a>".
                "<a href='guilds-clans.php?op=manage&action=pay&id=".$guildID."&who=".$ThisMember['acctid']."'>&nbsp;[Stipend]</a>".
                "</td><td>".$ThisMember['guildrank'].".</td><td>".$ThisMember['displaytitle']." ".$ThisMember['name']."</td></tr>",true);
                addnav("","guilds-clans.php?op=manage&action=promotemember&id=".$guildID."&who=".$ThisMember['acctid']);
                addnav("","guilds-clans.php?op=manage&action=revokemember&id=".$guildID."&who=".$ThisMember['acctid']);
                addnav("","guilds-clans.php?op=manage&action=assignrank&id=".$guildID."&who=".$ThisMember['acctid']);
                addnav("","guilds-clans.php?op=manage&action=pay&id=".$guildID."&who=".$ThisMember['acctid']."");
            } else {
                output("<tr class='".($i%2?"trlight":"trdark")."'><td>".$ThisMember['guildrank'].".</td><td>".$ThisMember['displaytitle']." ".$ThisMember['name']."</td></tr>",true);
            }
            $check_all_out.="document.getElementById(\"checked[".$ThisMember['acctid']."]\").checked=true;";
            $check_none_out.="document.getElementById(\"checked[".$ThisMember['acctid']."]\").checked=false;";
            $i++;
      }
      output("</TABLE>`n",true);

      if ($Manage) {
          output("<table align='center'>",true);
          output("<tr><td><input type='submit' value='Assign Rank' class='button'>",true);
          output("<input type='button' value='Check All' class='button' onClick='".$check_all_out."'>",true);
          output("<input type='button' value='UnCheck All' class='button' onClick='".$check_none_out."'></td></tr>",true);
          output("</table>",true);
      }
      output("</form>",true);

  }


  // List the applicants to the guild
  if (count($ThisGuild['ApplicantList'])==0) {
      output("`n`n`0There are no applicants applying to join the Guild!",true);
  } else {
      $ApplicantList=implode(",",array_keys($ThisGuild['ApplicantList']));
      $applicants=HitlistToNames($ApplicantList,true);

      output("`n`n`0There are ".count($applicants)." applying to be members of the Guild`n",true);
      output("<table border=0 cellpadding=2 cellspacing=1 bgcolor='#999999' align='center'>",true);
      if ($Manage) {
        output("<tr class='trhead'><td>`bAction`b</td><td>`bRank`b</td><td>`bName`b</td></tr>",true);
      } else {
        output("<tr class='trhead'><td>`bRank`b</td><td>`bName`b</td></tr>",true);
      }
      for ($i=0;$i<count($applicants);$i++){
            if ($Manage) {
                output("<tr class='".($i%2?"trlight":"trdark")."'><td>".
                "<a href='guilds-clans.php?op=manage&action=approveapplicant&id=".$guildID."&who=".$applicants[$i]['acctid']."'>Approve</a>".
                "<a href='guilds-clans.php?op=manage&action=denyapplicant&id=".$guildID."&who=".$applicants[$i]['acctid']."'>&nbsp;Deny</a>".
                "</td><td>".($i+1).".</td><td>".$applicants[$i]['name']."</td></tr>",true);
                addnav("","guilds-clans.php?op=manage&action=approveapplicant&id=".$guildID."&who=".$applicants[$i]['acctid']);
                addnav("","guilds-clans.php?op=manage&action=denyapplicant&id=".$guildID."&who=".$applicants[$i]['acctid']);
            } else {
                output("<tr class='".($i%2?"trlight":"trdark")."'><td>".
                "</td><td>".($i+1).".</td><td>".$applicants[$i]['name']."</td></tr>",true);
            }
      }
      output("</TABLE>",true);
  }
  // List the banned members of the guild

  if (count($ThisGuild['BannedPeople'])==0) {
      output("`n`n`0There are no people who are `ibanished`i from the Guild",true);
  } else {
      $BannedPlayers=implode(",",array_keys($ThisGuild['BannedPeople']));
      $BannedPlayers=HitlistToNames($BannedPlayers,true);

      output("`n`n`0There are ".count($BannedPlayers)." people who are `ibanished`i from the Guild`n",true);
      output("`c<table border=0 cellpadding=2 cellspacing=1 bgcolor='#999999' align='center'>`c",true);

      if ($Manage) {
        output("<tr class='trhead'><td>`bAction`b</td><td>`bRank`b</td><td>`bName`b</td></tr>",true);
      } else {
        output("<tr class='trhead'><td>`bRank`b</td><td>`bName`b</td></tr>",true);
      }

      for ($i=0;$i<count($BannedPlayers);$i++){
        if ($Manage) {
            output("<tr class='".($i%2?"trlight":"trdark")."'><td>".
            "<a href='guilds-clans.php?op=manage&action=revokeban&id=".$guildID."&who=".$BannedPlayers[$i]['acctid']."'>Revoke</a>".
            "<a href='guilds-clans.php?op=manage&action=addtohitlist&id=".$guildID."&who=".$BannedPlayers[$i]['acctid']."'>&nbsp;Add to Hitlist</a>".
            "</td><td>".($i+1).".</td><td>".$BannedPlayers[$i]['name']."</td></tr>",true);
            addnav("","guilds-clans.php?op=manage&action=revokeban&id=".$guildID."&who=".$BannedPlayers[$i]['acctid']);
            addnav("","guilds-clans.php?op=manage&action=addtohitlist&id=".$guildID."&who=".$BannedPlayers[$i]['acctid']);
        } else {
             output("<tr class='".($i%2?"trlight":"trdark")."'><td>".($i+1).".</td><td>".$BannedPlayers[$i]['name']."</td></tr>",true);
        }
      }
      output("</TABLE>",true);
  }
}


function GuildsHOF($guildID) {

// Display the Hall of fame for guilds/clans
// Order by players (wanna promote membership)

global $session;
global $HTTP_GET_VARS;
$returnTo=CalcReturnPath();

        $sql="SELECT Count(GUILDid) AS Players, lotbd_guilds.Name, lotbd_guilds.ID, lotbd_guilds.gems, lotbd_guilds.gold".
                " FROM accounts RIGHT JOIN lotbd_guilds ON accounts.guildID = lotbd_guilds.ID".
                " GROUP BY accounts.guildID order by players desc, lotbd_guilds.gems desc, lotbd_guilds.gold desc";
        $result=db_query($sql);
        $RowCount=db_num_rows($result);

        output("<table border=0 cellpadding=2 cellspacing=1 bgcolor='#999999' align='center'>",true);
        output("<tr class='trhead'><tr><td>`bRank`b</td><td>`bName`b</td><td>`bPlayers`b</td><td>`bGems`b</td><td>`bGold`b</td></tr>",true);

        for ($i=0;$i<$RowCount;$i++){
             $rows = db_fetch_assoc($result);
                output("<tr class='".($i%2?"trlight":"trdark")."'><td>".($i+1).".</td><td>{$rows[Name]}</td><td>{$rows[Players]}</td><td>`i{$rows['gems']}`i</td><td>`i{$rows['gold']}`i</td></a>",true);
        }
        output("</table>",true);

}

function GuildStatus($guildID) {
    // Show a summary of the guild
    // - Gold/Gems/Members list
}

function IsOnManagementTeam($guildID, $who=""){

// Is the passed in member or the current user on the management team of the guild

  global $session;
  $onTeam=0;
  if ($who=="") $who=$session['user']['acctid'];

  $TestGuild=&$session['guilds'][$guildID];

  $pos=strpos(":".$TestGuild['GuildLeader'].":".$TestGuild['HeadOfMembership'].":".$TestGuild['HeadOfWar'].":",":".$who.":");
  if ($pos===false) {
     $onTeam=false;
  } else {
     $onTeam=true;
  }

return $onTeam;
}

function display_edit_guild($Info,$Admin=false, $SU=false) {

// Edit the guild info

    $HasData=(count($Info)!=0);
    if ($HasData!=true) $Info=array();

    output("`&`c`bCreate a Guild`b`c");
    output("`n`n*`iindicates Mandatory information`i`n",true);

    if ($SU) {
        output("`0<form action='guilds-clans.php?op=SU&type=applications&action=save' method='POST'>",true);
        addnav("","guilds-clans.php?op=SU&type=applications&action=save");
    } else {
        output("`0<form action='guilds-clans.php?op=manage&action=create&type=guild&status=verifyInfo&id=".$Info['ID']."' method='POST'>",true);
        addnav("","guilds-clans.php?op=manage&action=create&type=guild&status=verifyInfo&id=".$Info['ID']);
    }
    output("<input name='info[ID]'  type='hidden' value='".$Info['ID']."'>",true);
    output("`nWhat is the name of the noble Guild*? <input name='info[Name]' size=100 value='".SafeDisplayString(($HasData)? $Info['Name']: "" )."'>`n",true);
//##

    if (!isset($Info['GuildPrefix']['pre'])) $Info['GuildPrefix']['pre']=1;
    $pre=$Info['GuildPrefix']['pre'];
    $GuildPrefix=$Info['GuildPrefix']['display'];

    output("<input type=radio name='info[GuildPrefix][pre]' value='1' ".(($pre==1)?"checked":"")."> Prefix<br>",true);
    output("<input type=radio name='info[GuildPrefix][pre]' value='0' ".(($pre==0)?"checked":"")."> Suffix<br>",true);

    output("`nWhat Prefix would your like for your Warriors Names (9 Chars inc colour)? <input name='info[GuildPrefix][display]' length=9 size=10 value='".SafeDisplayString(($HasData)? $GuildPrefix: "" )."'>`n",true);
    output("`nDescription*: `n<textarea name='info[PublicText]' size=10 cols=75 rows=5 title='Enter what will be displayed to outsiders'>".SafeDisplayString(($HasData)? $Info['PublicText']: "" )."</textarea>`n",true);
    output("`nText for Applicants*: `n<textarea name='info[ApplyText]' cols=75 rows=5 title='Enter what will be displayed to outsiders'>".SafeDisplayString(($HasData)? $Info['ApplyText']: "" )."</textarea>`n",true);
    output("`nRules*:`n <textarea name='info[RulesText]' cols=75 rows=5 title='Enter what will be displayed to outsiders'>".SafeDisplayString(($HasData)? $Info['RulesText']: "" )."</textarea>`n",true);
    output("`nLink: `n<input name='info[ExternalPagesLink]' size=100 value='".SafeDisplayString(($HasData)? $Info['ExternalPagesLink']: "" )."'>",true);
//    output("And are you a <input type='radio' name='sex' value='1'>Female or a <input type='radio' name='sex' value='0' checked>Male?`n",true);

    if ($SU) {
        output("`nAccount ID's of:");
        output("`n&nbsp;&nbsp;Guild Leader: `n<input name='info[GuildLeader]' length=9 size=10 value='".SafeDisplayString(($HasData)? $Info['GuildLeader']: "" )."'>`n",true);
        output("`n&nbsp;&nbsp;Head Of War: `n<input name='info[HeadOfWar]' length=9 size=10 value='".SafeDisplayString(($HasData)? $Info['HeadOfWar']: "" )."'>`n",true);
        output("`n&nbsp;&nbsp;Head Of Membership: `n<input name='info[HeadOfMembership]' length=9 size=10 value='".SafeDisplayString(($HasData)? $Info['HeadOfMembership']: "" )."'>`n",true);
    }

    if ($Admin) {
     $type="";
    } else {
     $type=" type='hidden' ";
    }


//    output(dump_item($Info['Hitlist']), true);
    if (!is_array($Info['Hitlist'])) $Info['Hitlist']=array();
    $HitListDisplay=HitlistToNames($Info['Hitlist'], false);
    output("`nHitList: `n<input name='info[Hitlist]' readonly ".$type."size=100 value='".SafeDisplayString($HitListDisplay)."'>",true);

    DisplaySitePoints($Info['ID']);

//    output("`nHeal Discount: `n<input name='info[HealDiscount]' ".$type."size=10 value='".(($HasData)? $Info['HealDiscount']: "" )."'>",true);
//    output("`nTrain Discount: `n<input name='info[TrainDiscount]' ".$type." size=10 value='".(($HasData)? $Info['TrainDiscount']: "" )."'>",true);
//    output("`nPvP Discount: `n<input name='info[PvPDiscount]' ".$type."size=10 value='".(($HasData)? $Info['PvPDiscount']: "" )."'>",true);
//    output("`nGem Purchase Discount: `n<input name='info[GemPurchaseDiscount]' ".$type."size=10 value='".(($HasData)? $Info['GemPurchaseDiscount']: "" )."'>",true);
//    output("`nPotion Discount: `n<input name='info[PotionDiscount]' ".$type." size=10 value='".(($HasData)? $Info['PotionDiscount']: "" )."'>",true);
//    output("`nWeapon Discount: `n<input name='info[WeaponDiscount]' ".$type."size=10 value='".(($HasData)? $Info['WeaponDiscount']: "" )."'>",true);
//    output("`nArmour Discount: `n<input name='info[ArmourDiscount]' ".$type."size=10 value='".(($HasData)? $Info['ArmourDiscount']: "" )."'>",true);

    if ($SU) {
     $type="";
    } else {
     $type=" readonly ";
    }

    output("`nGold: `n<input name='info[gold]' ".$type." size=10 value='".(($HasData)? $Info['gold']: "" )."'>",true);
    output("`nGems: `n<input name='info[gems]' ".$type." size=10 value='".(($HasData)? $Info['gems']: "" )."'>",true);
    output("`nSitePoints: `n<input name='info[SitePoints]' ".$type." size=5 value='".(($HasData)? $Info['SitePoints']: "" )."'>",true);

    if ($Admin) {
        output("`n`n<input type='submit' class='button' value='Save'>",true);
    } else {
        output("`n`nOnce you are happy with the information - click apply - you will have a chance to check the info before you submit it to the ruling council");
        output("`n`n<input type='submit' class='button' value='Apply'>",true);
    }
}

function display_guild_info($Info) {

// Display and verify the Guild Information
// Checks if the mandatory information has been entered and checks for bad language

    $InvalidLanguage=0;
    $MissingVitalInfo=false;
    if (soap($GuildName=$Info['Name'])!=$GuildName) {
        $Info['guildname'].=" `4[Contains inappropriate langauge]";
        $InvalidLangauge=1;
    } else {
        if ($GuildName=="") $MissingVitalInfo=true;
    }

    if (soap($Description=$Info['PublicText'])!=$Description) {
        $Description.=" `4[Contains inappropriate langauge]";
        $InvalidLangauge=1;
    } else {
        if ($Description=="") $MissingVitalInfo=true;
    }

    if (soap($ApplicantText=$Info['ApplyText'])!=$ApplicantText) {
        $ApplicantText.=" `4[Contains inappropriate langauge]";
        $InvalidLangauge=1;
    } else {
         if ($ApplicantText=="") $MissingVitalInfo=true;
    }

    if (soap($RulesText=$Info['RulesText'])!=$RulesText) {
        $RulesText.=" `4[Contains inappropriate langauge]";
        $InvalidLangauge=1;
    } else {
        if ($RulesText=="") $MissingVitalInfo=true;
    }

    if (soap($Link=$Info['link'])!=$Link) {
        $Link.=" `4[Contains inappropriate langauge]";
        $InvalidLangauge=1;
    }

    $GuildPrefix_display=$Info['GuildPrefix']['display'];
    if (strlen(color_sanitize($GuildPrefix_display))>3) {
        $Info['GuildPrefix']['display']= substr(color_sanitize($GuildPrefix_display),0,3);
    }

    output("<form action='guilds-clans.php?op=manage&action=create&type=guild&status=submit&id=".$Info['ID']."' method='POST'>",true);
    output("`n`0Name: ".$Info['Name']);
    output("`n`0Member Name Prefix: ".$Info['GuildPrefix']['display']);
    output("`n`0Description: ".$Info['PublicText']);
    output("`n`0Applicant Text: ".$Info['ApplyText']);
    output("`n`0Rules: ".$Info['RulesText']);
    output("`n`0Link: ".$Info['ExternalPagesLink']);
    $sql="select name from accounts where acctid=".$Info['GuildLeader'];
    $result=db_query($sql);
    $row=db_fetch_assoc($result);
    output("`n`0Guild Leader: ".$row['name']);
    $Info['BadLanguage']=$InvalidLangauge;
    $Info['MissingVitalInfo']=$MissingVitalInfo;
    $tmp=base64_encode(serialize($Info));
    output("<input type='hidden' name='info' value='$tmp'>",true);
    if ($InvalidLangauge!=true) {
        if (!isset($Info['ID']) or ($Info['ID']=="")) {
            output("`n`n<input type='submit' class='button' value='Submit for Approval'>",true);
        } else {
            output("`n`n<input type='submit' class='button' value='Update Records'>",true);
        }
    } else {
        output("`n`n`i`bYou have invalid language in your submission - start again!`b`i",true);
    }

    output("`n`n<input type='submit' class='button' value='Discard'>",true);
    addnav("","guilds-clans.php?op=manage&action=create&type=guild&status=submit&id=".$Info['ID']);
}

function HitlistToNames($Hitlist, $ReturnAsArray=false) {

// Turns the passed in list (string in the form of {n[,n]} where n is the acctid | array of acctid's)
// tuned to returning names and bounties
// Use list to names if you want more information

    if (is_array($Hitlist)) {
     $UserSearch=implode(",",array_keys($Hitlist));
    } else {
     $UserSearch=$Hitlist;
    }

    if ($UserSearch!=""){
        $sql = "select acctid, name, bounty, login from accounts where acctid in (".$UserSearch.")";
        $NameResult = db_query($sql);
        $HitListNames="";
        $ArrayResult=array();
        $RowCount=db_num_rows($NameResult);

        for ($i=0;$i<$RowCount;$i++){
             $NameRows = db_fetch_assoc($NameResult);
             $ArrayResult[]=$NameRows;
             $HitListNames.=$NameRows['name']." `&- `^".$NameRows['bounty']."`& Gold".(($i<($RowCount-1))? ", ":".");
        }
    } else {
        $HitListNames="None";
    }

//db_free_result($NameResult);
  if ($ReturnAsArray!=false) {
    return $ArrayResult;
  } else {
       return $HitListNames;
  }
}

function ListToNames($SearchList, $ReturnAsArray=false) {

// Turns the passed in list (string in the form of {n[,n]} where n is the acctid | array of acctid's)
// tuned to returning names, rank

    if (is_array($SearchList)) {
     $UserSearch=implode(",",array_keys($SearchList));
    } else {
     $UserSearch=$SearchList;
    }

    if ($UserSearch!=""){
        $sql = "select accounts.acctid, accounts.name, accounts.guildid, accounts.guildrank, lotbd_guildranks.displaytitle  from accounts left join lotbd_guildranks on accounts.guildrank=lotbd_guildranks.rankID and accounts.guildid=lotbd_guildranks.guildid where accounts.acctid in (".$UserSearch.")";

        $NameResult = db_query($sql);
        $ListNames="";
        $ArrayResult=array();
        $RowCount=db_num_rows($NameResult);

        for ($i=0;$i<$RowCount;$i++){
             $NameRows = db_fetch_assoc($NameResult);
             $ArrayResult[$NameRows['acctid']]=$NameRows;
             $ListNames.=$NameRows['name']."".(($i<($RowCount-1))? ", ":".");
        }
    } else {
        $ListNames="None";
    }

//db_free_result($NameResult);
  if ($ReturnAsArray!=false) {
    return $ArrayResult;
  } else {
       return $ListNames;
  }
}

function PopulateRanks($guildID) {

// Return the defined ranks for this guild

    $sql="select rankorder, rankid, displaytitle, dkrequired, assignedbymgmt from lotbd_guildranks where guildID=".$guildID." order by RankOrder ASC, RankID Asc";
    $result=db_query($sql);
    $rowCount=db_num_rows($result);
    $ArrayResult=array();

    if ($rowCount==0) {
        // Create the 2 most default ranks
        $ThisRank=array();
        $ThisRank['GuildID']=$guildID;
        $ThisRank['RankOrder']=0;
        $ThisRank['DisplayTitle']="Apprentice";
        $ThisRank['DKRequired']=0;
        $ThisRank['AssignedByMgmt']=0;
        create_guildrank_info($ThisRank);

        $ThisRank=array();
        $ThisRank['GuildID']=$guildID;
        $ThisRank['RankOrder']=20;
        $ThisRank['DisplayTitle']="Leader";
        $ThisRank['DKRequired']=0;
        $ThisRank['AssignedByMgmt']=0;
        create_guildrank_info($ThisRank);

        return populateranks($guildID);
    } else {

        for ($i=0;$i<$rowCount;$i++){
            $row = db_fetch_assoc($result);
            $ArrayResult[$row['rankid']]=$row;
        }
    }

return $ArrayResult;
}

function FindRankForPerson($guildID, $who) {
// Returns the rank for a person passed in as an acctid

global $session;

$sql="SELECT lotbd_guildranks.displaytitle, accounts.name
        FROM accounts
            INNER JOIN lotbd_guildranks
                ON accounts.guildrank=lotbd_guildranks.rankid
                AND accounts.guildid=lotbd_guildranks.guildid
        WHERE accounts.acctid=".$who;

$result=db_query($sql);
$RowCount=db_fetch_assoc($result);
$row=db_fetch_assoc($result);

if ($RowCount<1) {
    $ranks=PopulateRanks($guildID);

    while (list($key, $val) = each($ranks)) {
        if ($val['rankorder']==0) return $val['displaytitle'];
    }
    return "Bugger";
}

return $row['displaytitle'];
}


function Display_Record($ThisGuild){

// Names of Leaders
$UserSearch=$ThisGuild['HeadOfWar'].",".$ThisGuild['GuildLeader'].",".$ThisGuild['HeadOfMembership'];
$sql = "select acctid, name from accounts where acctid in (".$UserSearch.")";
$NameResult = db_query($sql);
$GuildLeaderName="`iUndefined`i";
$HeadOfMembershipName="`iUndefined`i";
$HeadOfWarName ="`iUndefined`i";

for ($i=0;$i<db_num_rows($NameResult);$i++){
     $NameRows = db_fetch_assoc($NameResult);
     if ($NameRows['acctid']==$ThisGuild['GuildLeader']) $GuildLeaderName=$NameRows['name'];
     if ($NameRows['acctid']==$ThisGuild['HeadOfMembership']) $HeadOfMembershipName=$NameRows['name'];
     if ($NameRows['acctid']==$ThisGuild['HeadOfWar']) $HeadOfWarName=$NameRows['name'];
}

// Guild/Clan Status
 switch ($ThisGuild['Status']) {
         case "-999":
           $statustext="`4Denied";
         break;
         case "0":
           $statustext="`%Pending";
         break;
         case "1":
           $statustext="`2Active";
         break;
         default:
           $statustext="`0Unknown";
         break;
 }

// Hitlist
//output("`nHitList: ".$ThisGuild['Hitlist']);
$HitListNames = HitlistToNames($ThisGuild['Hitlist']);

    output("`n`0Guild Info:`n");
    output("`n`0Name: `%".$ThisGuild['Name'],true);
    output("`n`0Warrior Name Prefix: `%".$ThisGuild['GuildPrefix'],true);
    output("`n`0Status: `%".$statustext,true);
    output("`n`0Clan or Guild: `%".(($ThisGuild['IsGuild']==1)? "Guild": "Clan"));
    output("`n`0Description: `%".$ThisGuild['PublicText'],true);
    output("`n`0Applicant Text: `%".$ThisGuild['ApplyText'],true);
    output("`n`0Rules: `%".$ThisGuild['RulesText'],true);
    output("`n`0Link: `%<a href='".$ThisGuild['ExternalPagesLink']."'>".$ThisGuild['ExternalPagesLink']."</a>",true);
    output("`n`0Leader: `%".$GuildLeaderName,true);
    output("`n`0Head of Membership: `%".$HeadOfMembershipName,true);
    output("`n`0Head of War: `%".$HeadOfWarName,true);
    output("`n`0Hit List: `%`i".$HitListNames."`i",true);
    $members=FindGuildMembers($ThisGuild['ID'], true);
    $display="";
    $ranks=PopulateRanks($ThisGuild['ID']); // handles when no rank has been set
    output("`n`0Members of this guild: `n");
    output("<table cellpadding=2 cellspacing=1 bgcolor='#999999' align='left'>",true);
    output("<tr class='trhead'>&nbsp;&nbsp;&nbsp;<td>`bRank`b</td><td>`bName`b</td></tr>",true);

    foreach ($members as $member) {
     // Traverse the array and display the names ane their rank
        if (!isset($member['displaytitle'])) {
            output("<tr class='".($i%2?"trlight":"trdark")."'><td>".$ranks[0]['DisplayTitle']."</td><td>".$member['name']."</td>",true);
        } else {
            output("<tr class='".($i%2?"trlight":"trdark")."'><td>".$member['displaytitle']."</td><td>".$member['name']."</td>",true);
        }
    }
    output("</TABLE>`n`n`n`n`n",true);

    output("`n`0Site Points Left: `%".$ThisGuild['SitePoints']);
    output("`n`0Gold: `%".$ThisGuild['gold']);
    output("`n`0Gems: `%".$ThisGuild['gems']);
    output("`n`0Discounts: ");
    output("`n`0Heal: `%".$ThisGuild['HealDiscount']);
    output("`n`0Train: `%".$ThisGuild['TrainDiscount']);
    output("`n`0PvP: `%".$ThisGuild['PvPDiscount']);
    output("`n`0Gem: `%".$ThisGuild['GemPurchaseDiscount']);
    output("`n`0Potion: `%".$ThisGuild['PotionDiscount']);
    output("`n`0Weapon: `%".$ThisGuild['WeaponDiscount']);
    output("`n`0Armour: `%".$ThisGuild['ArmourDiscount']);
}

function RemoveUserFromMgmt($who) {

// Removes somebody from the management team - aimed to be used from User.php for Superusers
// If a Guild:
//   If the user being removed is the GuildLeader then try and assign the guild leader from the other mgmt members
//   If this cannot be done then pick a random member if possible
//   Otherwise set the GuildLeader to 0
// If a clan:
//   Pick a random member if one exists
//

global $session;

    $sql = "select guildID, ClanID from accounts where acctid=".$who;
    $result = db_query($sql);
    $row = db_fetch_assoc($result);
    $guildID = $row['guildID']; $clanID = $row['clanID'];
    if (IsOnManagementTeam($guildID,$who)) {
        $ThisGuild=&$session['guilds'][$guildID];
        if ($ThisGuild['GuildLeader']==$who) {
            if ($ThisGuild['HeadOfWar']<>0) {
                $ThisGuild['GuildLeader']=$ThisGuild['HeadOfWar'];
            } else {
                if ($ThisGuild['HeadOfMembership']<>0) {
                    $ThisGuild['GuildLeader']=$ThisGuild['HeadOfMembership'];
                } else {
                    // There are no management members
                    $NewMgr=RandomGuildMember($guildID,$who);
                    $ThisGuild['GuildLeader']=$NewMgr;
                }
            }
        }
        if ($ThisGuild['HeadOfWar']==$who) {
            $ThisGuild['HeadOfWar']=0;
        }

        if ($ThisGuild['HeadOfMembership']==$who) {
            $ThisGuild['HeadOfMembership']=0;
        }
    update_guild_info($ThisGuild);
    }

    if (IsOnManagementTeam($clanID,$who)) {
        $ThisClan=$session['guilds'][$clanID];
        if ($ThisClan['GuildLeader']==$who) {
            $ThisClan['GuildLeader']=RandomGuildMember($clanID,$who);
        }
    update_guild_info($ThisClan);
    }
}

function RandomGuildMember($guildID, $exclude="") {

//
// Find a random member of a guild
// optionally exclude one or more people
//

global $session;

    if ($exclude!="") $exclude=" and acctid not in (".$exclude.")";

    $ThisGroup=&$session['guilds'][$guildID];
    if ($ThisGroup['IsGuild']==1) {
        $sqlType=" guildID=".$guildID;
    } else {
        $sqlType=" clanID=".$guildID;
    }

    // How many players are we talking about?
    $sql="select count(*) as Players from accounts where ".$sqlType.$exclude;
    $result=db_query($sql);
    $row=db_fetch_assoc($result);
    $players=$row['Players'];
    // Pick a number between 1 and the size of the pot
    if ($players>1) {
        $val=e_rand(1,$players);
        if ($val==0) return 0;
        $sql="select acctid from accounts where ".$sqlType.$exclude." limit ".$val.",1";
    } else {
        if ($players==1) {
            // There is only one choice!
            $sql="select acctid from accounts where ".$sqlType.$exclude;
        } else {
            // There is nobody to select
            return 0;
        }
    }

    $result=db_query($sql);
    $row=db_fetch_assoc($result);
    $who=$row['acctid'];

    return $who;
}

?>