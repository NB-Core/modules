<?php

function fallensam_getmoduleinfo(){
	$info = array(
	"name"=>"Fallen Samurai",
	"version"=>"1.0",
	"author"=>"`6Harry B and Kenny Chu",
	"category"=>"Forest Specials",
	"download"=>"http://dragonprime.net/users/Harry%20B/fallensam.zip",
	"settings"=>array(
	"Fallen Samurai Settings,title",
	"mingold"=>"Minimum gold to find (multiplied by level),range,100,200,1|10",
	"maxgold"=>"Maximum gold to find (multiplied by level),range,500,1000,1|100"
	),
	);
	return $info;
}

function fallensam_install(){
	module_addeventhook("forest","return 100;");
	return true;
}

function fallensam_uninstall(){
	return true;
}

function fallensam_dohook($hookname,$args){
	return $args;
}

function fallensam_runevent($type)
{
	global $session;
	$min = $session['user']['level']*get_module_setting("mingold");
	$max = $session['user']['level']*get_module_setting("maxgold");
	$gold = e_rand($min, $max);
	output("`n`2You stumble over the remains of a fallen Samurai.`n`n You search his pouch and find %s gold!`0", $gold);
	$session['user']['gold']+=$gold;
	debuglog("found $gold gold in the forest");
}

function fallensam_run(){
}
?>