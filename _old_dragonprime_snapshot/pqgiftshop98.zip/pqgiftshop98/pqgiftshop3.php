<?
//V2.22  Minor Spelling Changes by DaveS
function pqgiftshop3_getmoduleinfo(){
	$info = array(
		"name"=>"PQ Gift Shop 3",
		"version"=>"2.22",
		"author"=>"`#Lonny Luberts",
		"category"=>"PQcomp",
		"download"=>"http://www.pqcomp.com/modules/mydownloads/visit.php?cid=3&lid=14",
		"settings"=>array(
			"PQ Gift Shop Module Settings,title",
			"gsloc"=>"Where does the Gift Shop appear,location|".getsetting("villagename", LOCATION_FIELDS),
			"gsowner"=>"Gift Shop Clerk Name,text|Moejo",
			"gsheshe"=>"Gift Shop Owner Sex,text|he",
			"special"=>"Shop Specialty,text|Fellow Warriors",
			"If you use the word -Card- the gift show will assume it is a greeting card,note",
			"gift1"=>"Gift1,text|Piece of Petrified Pony Dung",
			"gift1price"=>"Gift1 Price,int|0",
			"gift2"=>"Gift2,text|Lizard Skull",
			"gift2price"=>"Gift2 Price,int|10",
			"gift3"=>"Gift3,text|Weapon Sharpener",
			"gift3price"=>"Gift3 Price,int|20",
			"gift4"=>"Gift4,text|Nice Kill Card",
			"gift4price"=>"Gift4 Price,int|40",
			"gift5"=>"Gift5,text|Squirrel Powered Razor",
			"gift5price"=>"Gift5 Price,int|60",
			"gift6"=>"Gift6,text|Metal Skull Cap",
			"gift6price"=>"Gift6 Price,int|100",
			"gift7"=>"Gift7,text|Bottle of Worm Juice Cologne",
			"gift7price"=>"Gift7 Price,int|200",
			"gift8"=>"Gift8,text|Monogrammed Ale Grail",
			"gift8price"=>"Gift8 Price,int|500",
			"gift9"=>"Gift9,text|Tablet of Emotive Stones",
			"gift9price"=>"Gift9 Price,int|1000",
			"gift10"=>"Gift10,text|Buddha Mirror",
			"gift10price"=>"Gift10 Price,int|1500",
			"gift11"=>"Gift11,text|Dragon Crystal Ball",
			"gift11price"=>"Gift11 Price,int|2000",
			"gift12"=>"Gift12,text|Stained Glass Pentacle",
			"gift12price"=>"Gift12 Price,int|3000",
		),
	);
	return $info;
}

function pqgiftshop3_install(){
	if (!is_module_active('pqgiftshop3')){
		output("`4Installing Gift Shop (3) Module.`n");
	}else{
		output("`4Updating Gift Shop (3) Module.`n");
	}
	module_addhook("village");
	return true;
}

function pqgiftshop3_uninstall(){
	output("`4Un-Installing Gift Shop (3) Module.`n");
	return true;
}

function pqgiftshop3_dohook($hookname,$args){
	global $session;
	switch($hookname){
		case "village":
			if ($session['user']['location'] == get_module_setting("gsloc")){
				tlschema($args['schemas']['marketnav']);
    			addnav($args['marketnav']);
    			tlschema();
				addnav(array("%s's Gift Shop",get_module_setting('gsowner')), "runmodule.php?module=pqgiftshop3");
			}
		break;
	}
	return $args;
}

function pqgiftshop3_run(){
	global $SCRIPT_NAME;
	if ($SCRIPT_NAME == "runmodule.php"){
		$module=httpget("module");
		if ($module == "pqgiftshop3"){
			$shope = "pqgiftshop3";
			include("modules/lib/pqgiftshop.php");
		}
	}
}
?>