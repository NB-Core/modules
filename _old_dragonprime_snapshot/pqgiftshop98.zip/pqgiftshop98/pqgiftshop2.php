<?
//V2.21 Minor Spelling Change by DaveS
function pqgiftshop2_getmoduleinfo(){
	$info = array(
		"name"=>"PQ Gift Shop 2",
		"version"=>"2.22",
		"author"=>"`#Lonny Luberts",
		"category"=>"PQcomp",
		"download"=>"http://www.pqcomp.com/modules/mydownloads/visit.php?cid=3&lid=14",
		"settings"=>array(
			"PQ Gift Shop Module Settings,title",
			"gsloc"=>"Where does the Gift Shop appear,location|".getsetting("villagename", LOCATION_FIELDS),
			"gsowner"=>"Gift Shop Clerk Name,text|Blayze",
			"gsheshe"=>"Gift Shop Owner Sex,text|he",
			"special"=>"Shop Specialty,text|enemies",
			"If you use the word -Card- the gift show will assume it is a greeting card,note",
			"gift1"=>"Gift1,text|Lump of Coal",
			"gift1price"=>"Gift1 Price,int|0",
			"gift2"=>"Gift2,text|Sorry I am going to slay you card",
			"gift2price"=>"Gift2 Price,int|10",
			"gift3"=>"Gift3,text|Bag of Cow chips",
			"gift3price"=>"Gift3 Price,int|20",
			"gift4"=>"Gift4,text|Smelly Gym Sock",
			"gift4price"=>"Gift4 Price,int|40",
			"gift5"=>"Gift5,text|You stink Card",
			"gift5price"=>"Gift5 Price,int|60",
			"gift6"=>"Gift6,text|Gross warted frog",
			"gift6price"=>"Gift6 Price,int|100",
			"gift7"=>"Gift7,text|Stick of Deodorant",
			"gift7price"=>"Gift7 Price,int|200",
			"gift8"=>"Gift8,text|Mask to cover your face",
			"gift8price"=>"Gift8 Price,int|500",
			"gift9"=>"Gift9,text|How to battle and win manual",
			"gift9price"=>"Gift9 Price,int|1000",
			"gift10"=>"Gift10,text|Bucket of Putrid Mud",
			"gift10price"=>"Gift10 Price,int|1500",
			"gift11"=>"Gift11,text|Cartload of Horse Manure",
			"gift11price"=>"Gift11 Price,int|2000",
			"gift12"=>"Gift12,text|Coffin for you",
			"gift12price"=>"Gift12 Price,int|3000",
		),
	);
	return $info;
}

function pqgiftshop2_install(){
	if (!is_module_active('pqgiftshop2')){
		output("`4Installing Gift Shop (2) Module.`n");
	}else{
		output("`4Updating Gift Shop (2) Module.`n");
	}
	module_addhook("village");
	return true;
}

function pqgiftshop2_uninstall(){
	output("`4Un-Installing Gift Shop (2) Module.`n");
	return true;
}

function pqgiftshop2_dohook($hookname,$args){
	global $session;
	switch($hookname){
		case "village":
			if ($session['user']['location'] == get_module_setting("gsloc")){
				tlschema($args['schemas']['marketnav']);
    			addnav($args['marketnav']);
    			tlschema();
				addnav(array("%s's Gift Shop",get_module_setting('gsowner')), "runmodule.php?module=pqgiftshop2");
			}
		break;
	}
	return $args;
}

function pqgiftshop2_run(){
	global $SCRIPT_NAME;
	if ($SCRIPT_NAME == "runmodule.php"){
		$module=httpget("module");
		if ($module == "pqgiftshop2"){
			$shope = "pqgiftshop2";
			include("modules/lib/pqgiftshop.php");
		}
	}
}
?>