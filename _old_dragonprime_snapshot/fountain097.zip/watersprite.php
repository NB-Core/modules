<? 
// rewrite of anonymous file
// to be included with The Fountain of Youth: fountain.php
require_once "common.php"; 
page_header("The Water Sprite"); 
if ($HTTP_GET_VARS[op]==""){ 

        $badguy = array("creaturename"=>"`^a Water Sprite`0","creaturelevel"=>12,"creatureweapon"=>"Sprays of Water","creatureattack"=>20,"creaturedefense"=>25,"creaturehealth"=>100, "diddamage"=>0); 
        $session[user][badguy]=createstring($badguy); 
        $battle=true; 
} 

if ($HTTP_GET_VARS[op]=="run"){ 
  output("`^Your so silly! You can not run from this fight!"); 
        $HTTP_GET_VARS[op]="fight"; 
} 
if ($HTTP_GET_VARS[op]=="fight" || $HTTP_GET_VARS[op]=="run"){ 
        $battle=true; 
} 
if ($battle){ 
  include("battle.php"); 
        if ($victory){ 
                $flawless = 0; 
                if ($badguy['diddamage'] != 1) $flawless = 1; 
                $badguy=array(); 
                $session[user][badguy]=""; 

                $newtitle="Soaked"; 
                 
                if ($session[user][ctitle] == "") 
                { 
                if ($session[user][title]!="") 
                { 

                        $n = $session[user][name]; 
                        $x = strpos($n,$session[user][title]); 
                        if ($x!==false){ 
                                $regname=substr($n,$x+strlen($session[user][title])); 
                                $session['user']['name'] = substr($n,0,$x).$newtitle.$regname; 
                                $session['user']['title'] = $newtitle; 
                        }else{ 
                                $regname = $session['user']['name']; 
                                $session['user']['name'] = $newtitle." ".$session['user']['name']; 
                                $session['user']['title'] = $newtitle; 
                        } 
                } 
                else 
                { 
                        $regname = $session['user']['name']; 
                        $session[user][name] = $newtitle." ".$session[user][name]; 
                        $session[user][title] = $newtitle; 
                        $session[user][turns]--; 
                } 
                } 
                else 
                { 
                $regname = substr($session['user']['name'], strlen($session['user']['title'])); 
                $session[user][title] = $newtitle; 
                } 
                $session[user][turns]--; 
                $session[user][bounty]+=700; 
                $session[user][gold]+=250; 
                output("`n`n`^With fury, You slash and hack the Water Sprite into thousands of droplets! `n`n"); 
                output("`n`n`^Within the murky water, you spot some gold. `n`n"); 
                output("`n`n`^You find yourself `4SOAKED to the bone`^!!. `n`n"); 
                output("`bIt appears you were seen destroying Diamond Hills property and the people are not happy!.`b `n`n"); 
                addnews("`6Vandals smash Fountain to pieces! A `4reward `6for the culprit's head is being offered.`0"); 
                addnav("Oops!!"); 
                addnav("(R) Run away","diamondhills.php"); 

        }else{ 
                if($defeat){ 
                        addnews("`6The body of `%".$session[user][name]."`6 was found dead in Diamond Hills near the Fountain."); 
                        $session[user][alive]=false; 
                        debuglog("lost {$session['user']['gold']} gold when they were slain"); 
                        $session[user][gold]=0; 
                        $session[user][hitpoints]=0; 
                        $session[user][badguy]=""; 
                        addnav("Daily news","news.php"); 
                        output("`b`&You have been slain by `%$badguy[creaturename]`&!!!`n"); 
                        output("`4You lose all your gold!`n"); 
                        output("You may begin fighting again tomorrow."); 

                        page_footer();  
                }else{ 
                  fightnav(true,true); 
                } 
        } 
} 
page_footer(); 
?> 