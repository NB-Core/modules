<? 
/********************
Fountain of Youth - belongs with Diamond Hills 
Diamond Hills is an area for our veteran players.
Written by Robert for Maddnet LoGD
Text changes using Fairy1
requires the use of watersprite.php
*********************/
require_once "common.php"; 
addcommentary(); 
checkday(); 

if ($session['user']['level']>14) {
    page_header("Fountain of Youth");
	output("`n`nYou start to approach the Fountain when a few shady characters come out of nowhere. One of them brushes against your shoulder and whispers
	`%'Don't you think it's time to kill the dragon?'");
	addnav("(F) Find the Dragon" ,"forest.php");}
else{

addnav("Fountain of Youth"); 
addnav(""); 
if ($session['user']['dragonkills']>7) addnav("(T) Get Closer","watersprite.php"); 
if ($session['user']['dragonkills']>7) addnav("(W) Make a Wish","fountain.php?op=wish"); 
addnav("");
addnav("path leading");
addnav("(C) to Castle Gwen","castlegwen.php");    
addnav("(D) to Diamond Hills","diamondhills.php");    
 
page_header("The Fountian of Youth"); 
output("`^`c`bThe Fountain of Youth`b`c `n");
output("`3`cThe estate of the late Lady Dianne of Castle Gwen`c `n`n");
output(" `2You approach a Fountain made of fine White Marble. `n"); 
output(" In the middle of the fountain there are figures of gnome's spraying water in every direction.`n"); 
output(" The pose of the figures almost seem threatening. `n");
output(" You ponder your curiosity and wonder if you should toss in 2 Gems and make a wish. `n");
output("`2You can also see the clock tower of `3Diamond Hills `2, tall majestic tower with a clock.`n"); 
}
if ($_GET[op]=="wish"){ 
if ($session[user][gems] > 1){  
      $session[user][gems]-=2; 
      $session[user][turns]--; 
      output("`2You toss in 2 of your hard-earned gems.  Close you eyes and make a wish, ");  
      output("You discover that ...`n`n`^"); 
      $session[user][gems]--; 
      debuglog("gave 2 gem to fountain of youth"); 
        switch(e_rand(1,7)){ 
          case 1: 
              $buff = array("name"=>"`1Magic Water","rounds"=>20,"wearoff"=>"`!The Magic Water effects fade as you return to normal", "defmod"=>1.2,"roundmsg"=>"You feel good!","activate"=>"defense");
              $session[bufflist][magicweak] = $buff;
              $session[user][drunkenness]+=70; 
              output("Nothing happened! `n`nNot wanting to waste your time here, you take a drink from the fountain`n ");  
              output("and discover a mystical energy flowing through your entire body, seems almost like your drunk!"); 
                break; 
            case 2: case 3: case 4:
                output("You feel perceptive and notice `%TWO`^ gems nearby!"); 
                $session[user][gems]+=2; 
                debuglog("got 2 gem from a fountain"); 
                break; 
            case 5: 
                output("Your maximum hitpoints are `bpermanently`b increased by 1!"); 
                $session[user][maxhitpoints]++; 
                $session[user][hitpoints]++; 
                break; 
            case 6: case 7: 
                increment_specialty(); 
                break; 
    } 
    }else{ 
      output("`n`n You toss an imaginary gem into the water and get back an imaginary bonus.`n "); 
      output("Don't you feel silly? ");  
      addnav("(D) Diamond Hills","diamondhills.php");
      $session[user][turns]--; 
}  }   
page_footer(); 
?> 