<?php
/*
* Date:     April 10, 2006
* Author:   Robert of Maddrio dot com
*/
function thunderstorm_getmoduleinfo(){
	$info = array(
	"name"=>"Thunder Storm",
	"version"=>"1.0",
	"author"=>"`2Robert",
	"category"=>"Forest Specials",
	"download"=>"http://dragonprime.net/index.php?module=Downloads;sa=dlview;id=568",
	"settings"=>array(
		"Thunder Storm Settings,title",
		"minloss"=>"Minimum turns to lose if catch a cold,range,1,10,1|1",
		"maxloss"=>"Maximum turns to lose if catch the flu,range,2,20,1|3",
		"colddays"=>"How many days will a COLD last?,range,1,20,1|2",
		"fludays"=>"How many days will a FLU last?,range,1,20,1|4",
		),
		"prefs"=>array(
			"Thunder Storm - User Prefs,title",
			"hascold"=>"Does player have a COLD?,bool|0",
			"cdaysleft"=>"How many more days will COLD last?,int|0",
			"hasflu"=>"Does player have a FLU?,bool|0",
			"fdaysleft"=>"How many more days will FLU last?,int|0",
		)
	);
	return $info;
}

function thunderstorm_install(){
	module_addeventhook("forest","return 100;");
	module_addhook("newday");
	return true;
}

function thunderstorm_uninstall(){
	return true;
}

function thunderstorm_dohook($hookname,$args){
	$minloss = get_module_setting("minloss");
	$maxloss = get_module_setting("maxloss");
	switch($hookname){
	case "newday":
	if (get_module_pref("cdaysleft") >=1){
		increment_module_pref("hascold",-1);
		increment_module_pref("cdaysleft",-1);
		output("`n`!You `Qcough`! and`6 sniffle`! as you have a terrible cold.`n");
		output("`7 Your cold causes your turn lose to be %s `n`0",$minloss);
		$session['user']['turns'] -= $minloss;
	}
	if (get_module_pref("fdaysleft") >=1){
		increment_module_pref("hasflu",-1);
		increment_module_pref("fdaysleft",-1);
		output("`n`!Your `Qhead`! and`6 body`! hurts like heck, you have the Flu.`n");
		output("`7 Your flu causes your turn loss to be %s `n`0",$maxloss);
		$session['user']['turns'] -= $maxloss;
	}
	break;
	}
	return $args;
}
function thunderstorm_runevent($type){
global $session;

$colddays = get_module_setting("colddays");
$fludays = get_module_setting("fludays");

output("`n`n`2 Dark clouds suddenly appear and blacken the sky, `n`n an unexpected Thunder storm is upon you! `n`n ");
output(" You try to seek shelter, but are caught in a torrential downpour! `n`n");
output("`^ You are soaked to the bone by the shivering cold rain. `n`n");
	switch(e_rand(1,6)){
	case 1: output("`7 You can only hope you dont catch a terrible cold! "); break;
	case 2: case 4:
		output("`7 You can only hope you dont catch a terrible cold or worse! `n`n");
		output(" You can feel a tickle in the back of your throat, you may be sick tomorrow. ");
		increment_module_pref("hascold",$colddays);
		increment_module_pref("cdaysleft",$colddays);
	break;
	case 3: case 5:
		output("`7 You can only hope you dont catch a terrible cold or worse! `n`n");
		output(" You can feel some aches and pains brewing, you may be sick tomorrow. ");
		increment_module_pref("hasflu",$fludays);
		increment_module_pref("fdaysleft",$fludays);
		
	break;
	case 6: output("`7 You can only hope you dont catch a horrid flu! "); break;
	case 7:
		
	break;
	}
}

function thunderstorm_run(){
}
?>