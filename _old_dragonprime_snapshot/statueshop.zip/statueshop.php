<?php

function statueshop_getmoduleinfo(){
	$info = array(
		"name"=>"Configurable Statue Shoppe",
		"author"=>"Chris Vorndran",
		"version"=>"1.26",
		"category"=>"Village",
		"download"=>"http://dragonprime.net/index.php?module=Downloads;sa=dlview;id=32",
		"vertxtloc"=>"http://dragonprime.net/users/Sichae/",
		"description"=>"Almost Completely configurable shoppe.",
		"settings"=>array(
			"Configurable Statue Shoppe Settings,title",
			"max"=>"Total Amount of Times that this can be used a day,int|2",
			"color"=>"Color code used throughout the shoppe and all,int|`2",
			"shoppe"=>"The name of the Shoppe,text|The Statue Shoppe",
			"owner"=>"The name of the Owner of the Shoppe,text|Celindra",
			"sex"=>"The gender of the owner,enum,0,Female,1,Male|1",
			"descrip"=>"Description of the Shoppe Owner<br>`istart with an adjective`i,textarea|fat pig",
			"dragonkill"=>"Text that comes after a Dragon Kill,textarea|You lose your Statues!",
			"Configurable Statue Shoppe Inner Settings,title",
			"open"=>"Opening Text in the Shoppe,textarea|You enter the Shoppe.",
			"nostatue"=>"Message given after person is booted for having no Statues,text|You have no Statues!",
			"noleft"=>"Message given after person is booted for already using services,text|You already did this!",
			"next"=>"Text in the Next Area,textarea|You proceed to the next section",
			"Configurable Statue Shoppe Outcome Options,title",
			"onetrade"=>"Message for trading in First Statue,text|You trade in your First Statue",
			"onegive"=>"What does Statue One give,enum,0,Experience,1,Gems,2,Max Hitpoints|1",
			"twotrade"=>"Message for trading in Second Statue,text|You trade in your Second Statue",
			"twogive"=>"What does Statue Two give,enum,0,Experience,1,Gems,2,Max Hitpoints|0",
			"threetrade"=>"Message for trading in Third Statue,text|You trade in your Third Statue",
			"threegive"=>"What does Statue Three give,enum,0,Experience,1,Gems,2, Max Hitpoints|2",
			"Configurable Statue Shoppe Newday Options,title",
			"onehave"=>"Message given when you have the first at newday,text|You have the First Statue",
			"onenew"=>"What does Statue One give at Newday,enum,0,Gold,1,Turns,2,Hitpoints|2",
			"twohave"=>"Message given when you have the second at newday,text|You have the Second Statue",
			"twonew"=>"What does Statue Two give at Newday,enum,0,Gold,1,Turns,2,Hitpoints|1",
			"threehave"=>"Message given when you have the third at newday,text|You have the Third Statue",
			"threenew"=>"What does Statue Three give at Newday,enum,0,Gold,1,Turns,2,Hitpoints|0",
			"Configurable Statue Shoppe Statue Name,title",
			"onename"=>"Name of the First Statue,text|Boohbah",
			"twoname"=>"Name of the Second Statue,text|Teletubbie",
			"threename"=>"Name of the Third Statue,text|Barney",
			"Make sure that all of these names line up with all of your other outputs,note",
			"Configurable Statue Shoppe Location,title",
			"mindk"=>"What is the minimum DK before this shop will appear to a user?,int|0",
			"shoploc"=>"Where does the shoppe appear,location|".getsetting("villagename", LOCATION_FIELDS)
			),
		"prefs"=>array(
			"Configurable Statue Shoppe Preferences,title",
			"times"=>"Times used today,int|0",
			"one"=>"Does this user have the First Statue,bool|0",
			"two"=>"Does this user have the Second Statue,bool|0",
			"three"=>"Does this user have the Third Statue,bool|0",
			)
		);
	return $info;
}
function statueshop_install(){
	module_addeventhook("forest","return 100;");
	module_addhook("village");
	module_addhook("dragonkilltext");
	module_addhook("newday");
	module_addhook("changesetting");
	return true;
}
function statueshop_uninstall(){
	return true;
}
function statueshop_dohook($hookname,$args){
	global $session;
	switch ($hookname){	
				case "changesetting":
			    if ($args['setting'] == "villagename") {
			    if ($args['old'] == get_module_setting("shoploc")) {
		       set_module_setting("shoploc", $args['new']);
		       }
			    }
			    break;
			  	case "village":
					if ($session['user']['location'] == get_module_setting("shoploc")
					&& $session['user']['dragonkills'] >= get_module_setting("mindk")) {
					tlschema($args['schemas']['marketnav']);
			        addnav($args['marketnav']);
					tlschema();
			        addnav(array("%s",get_module_setting("shoppe")),"runmodule.php?module=statueshop&op=enter");
					}	
		        break;
			case "dragonkilltext":
				statueshop_dragon();
				break;
			case "newday":
				statueshop_newday();
				set_module_pref("times",0);
				break;
		}
	return $args;
}
function statueshop_run(){
	global $session;
	$one = get_module_pref("one");
	$two = get_module_pref("two");
	$three = get_module_pref("three");
	$times = get_module_pref("times");

	$onetrade = get_module_setting("onetrade");
	$twotrade = get_module_setting("twotrade");
	$threetrade = get_module_setting("threetrade");

	$onegive = get_module_setting("onegive");
	$twogive = get_module_setting("twogive");
	$threegive = get_module_setting("threegive");

	$onename = get_module_setting("onename");
	$twoname = get_module_setting("twoname");
	$threename = get_module_setting("threename");

	$shoppe = get_module_setting("shoppe");
	$owner = get_module_setting("owner");
	$sex = get_module_setting("sex");
	$c = get_module_setting("color");
	$max = get_module_setting("max");
	$descrip = get_module_setting("descrip");

	$open = get_module_setting("open");
	$nostatue = get_module_setting("nostatue");
	$noleft = get_module_setting("noleft");
	$next = get_module_setting("next");

	$maxgain = e_rand(2,5);

	$op = httpget('op');
	page_header("%s",$shoppe);

	switch($op){
		case "enter":
			if ($one == 1 || $two == 1 || $three == 1){
			output("%sYou notice a %s. %s introduces %s as %s.`n",$c,$descrip,translate_inline($sex==0?"She":"He"), translate_inline($sex==0?"herself":"himself"),$owner);
			output("`n`n%s%s.",$c,$open);
			if ($one > 0) output("`c%sYou have the `&%s %sStatue`n`c`0",$c,$onename,$c);
			if ($two > 0) output("`c%sYou have the `&%s %sStatue`n`c`0",$c,$twoname,$c);
			if ($three > 0) output("`c%sYou have the `&%s %sStatue`n`c`0",$c,$threename,$c);
			if ($times >=$max){
				output("`n`n%s%s",$c,$noleft);
			}else{
				addnav("Head Deeper Into Shoppe","runmodule.php?module=statueshop&op=next");
			}
			villagenav();
			}else{
				output("%s%s",$c,$nostatue);
				villagenav();
		}
			break;
		case "next":
			output("%s%s guides you into the next room.",$c,$owner);
			output("%s%s.",$c,$next);
			output("%s %snotes to you, that in the trading of a Statue, you shall lose something dear.",$owner,$c);
			if ($one == 1) addnav(array("Trade In %s",$onename),"runmodule.php?module=statueshop&op=first");
			if ($two == 1) addnav(array("Trade In %s",$twoname),"runmodule.php?module=statueshop&op=second");
			if ($three == 1) addnav(array("Trade In %s",$threename),"runmodule.php?module=statueshop&op=third");
			villagenav();
			break;
		case "first":
			output("%sYou hand %s your %s Statue.",$c,translate_inline($sex==0?"her":"him"),$onename);
			output(" %s%s.`n`n",$c,$onetrade);
			if ($onegive == 0){
				statueshop_exp();
			}
			if($onegive == 1){
				statueshop_gems();
			}
			if($onegive == 2){
				statueshop_hp();
			}
			set_module_pref("one",0);
			$times++;
			set_module_pref("times",$times);
			if ($times < $max) addnav("Return to Storefront","runmodule.php?module=statueshop&op=enter");
			villagenav();
			break;
		case "second":
			output("%sYou hand %s your %s Statue.",$c,translate_inline($sex==0?"her":"him"),$twoname);
			output(" %s%s.`n`n",$c,$twotrade);
			if ($twogive == 0){
				statueshop_exp();
			}
			if($twogive == 1){
				statueshop_gems();
			}
			if($twogive == 2){
				statueshop_hp();
			}
			set_module_pref("two",0);
			$times++;
			set_module_pref("times",$times);
			if ($times < $max) addnav("Return to Storefront","runmodule.php?module=statueshop&op=enter");
			villagenav();
			break;
		case "third":
			output("%sYou hand %s your %s Statue.",$c,translate_inline($sex==0?"her":"him"),$threename);
			output(" %s%s.`n`n",$c,$threetrade);
			if ($threegive == 0){
				statueshop_exp();
			}
			if($threegive == 1){
				statueshop_gems();
			}
			if($threegive == 2){
				statueshop_hp();
			}
			set_module_pref("three",0);
			$times++;
			set_module_pref("times",$times);
			if ($times < $max) addnav("Return to Storefront","runmodule.php?module=statueshop&op=enter");
			villagenav();
			break;
	}
page_footer();
}
function statueshop_runevent($type){
	global $session;
	$one = get_module_pref("one");
	$two = get_module_pref("two");
	$three = get_module_pref("three");

	$onename = get_module_setting("onename");
	$twoname = get_module_setting("twoname");
	$threename = get_module_setting("threename");

	$c = get_module_setting("color");
	switch ($type){
		case "forest":
	switch (e_rand(1,3)){
	case 1:
		if ($one == 0){
		output("%sYou look around in the bullrushes, and find a `^%s %sStatue.",$c,$onename,$c);
		set_module_pref("one",1);
	}else{
		output("%sYou have already acquired the `^%s %sStatue.",$c,$onename,$c);
	}
		break;
	case 2:
		if ($two == 0){
		output("%sYou look near the base of a tree, and find a `^%s %sStatue.",$c,$twoname,$c);
		set_module_pref("two",1);
	}else{
		output("%sYou have already acquired the `^%s %sStatue.",$c,$twoname,$c);
	}
		break;
	case 3:
		if ($three == 0){
		output("%sYou look near the river bed, and find a `^%s %sStatue.",$c,$threename,$c);
		set_module_pref("three",1);
	}else{
		output("%sYou have already acquired the `^%s %sStatue.",$c,$threename,$c);
	}
		break;

}
break;
}
}
function statueshop_newday(){
	global $session;
	$one = get_module_pref("one");
	$two = get_module_pref("two");
	$three = get_module_pref("three");

	$onename = get_module_setting("onename");
	$twoname = get_module_setting("twoname");
	$threename = get_module_setting("threename");

	$onenew = get_module_setting("onenew");
	$twonew = get_module_setting("twonew");
	$threenew = get_module_setting("threenew");

	$onehave = get_module_setting("onehave");
	$twohave = get_module_setting("twohave");
	$threehave = get_module_setting("threehave");
	$c = get_module_setting("color");

	$hpgain = e_rand(2,10);
	$turngain = e_rand(2,5);
	$goldgain = e_rand(2,500);
	switch (e_rand(1,3)){
					case 1:
						if ($one == 1){
					output("`n`n%s%s.",$c,$onehave);
					if ($onenew == 2){
						output(" %sThe `&%s %s Statue resonates and gives you `\$%s %shitpoints.`0",$c ,$onename ,$c ,$hpgain ,$c);
					$session['user']['hitpoints']+=$hpgain;
					}
					if ($onenew == 1){
						output(" %sThe `&%s %s Statue resonates and gives you `@%s %s%s.`0", $c, $twoname, $c, $turngain, $c, translate_inline($turngain > 1?"turns":"turn"));
						$session['user']['turns']+=$turngain;
					}
					if ($onenew == 0){
						output(" %sThe `&%s %s Statue resonates and gives you `^%s %sgold.`0",$c ,$threename,$c , $goldgain, $c);
						$session['user']['gold']+=$goldgain;
					}
					}
					break;
					case 2:
						if ($two == 1){
					output("`n`n%s%s.",$c,$twohave);
					if ($twonew == 2){
						output(" %sThe `&%s %s Statue resonates and gives you `\$%s %shitpoints.`0",$c ,$twoname ,$c ,$hpgain ,$c);
					$session['user']['hitpoints']+=$hpgain;
					}
					if ($twonew == 1){
						output(" %sThe `&%s %s Statue resonates and gives you `@%s %s%s.`0", $c, $twoname, $c, $turngain, $c, translate_inline($turngain > 1?"turns":"turn"));
						$session['user']['turns']+=$turngain;
					}
					if ($twonew == 0){
						output(" %sThe `&%s %s Statue resonates and gives you `^%s %sgold.`0",$c ,$twoname,$c , $goldgain, $c);
						$session['user']['gold']+=$goldgain;
					}
					}
					break;
					case 3:
						if ($three == 1){
					if ($threenew == 2){
						output(" %sThe `&%s %s Statue resonates and gives you `\$%s %shitpoints.`0",$c ,$threename ,$c ,$hpgain ,$c);
					$session['user']['hitpoints']+=$hpgain;
					}
					if ($threenew == 1){
						output(" %sThe `&%s %s Statue resonates and gives you `@%s %s%s.`0", $c, $threename, $c, $turngain, $c, translate_inline($turngain > 1?"turns":"turn"));
						$session['user']['turns']+=$turngain;
					}
					if ($threenew == 0){
						output(" %sThe `&%s %s Statue resonates and gives you `^%s %sgold.`0",$c ,$threename,$c , $goldgain, $c);
						$session['user']['gold']+=$goldgain;
					}
					}
					break;
			}
}
function statueshop_dragon(){
	global $session;
	$one = get_module_pref("one");
	$two = get_module_pref("two");
	$three = get_module_pref("three");
	$c = get_module_setting("color");
	$dragonkill = get_module_setting("dragonkill");
	if ($one == 1 || $two == 1 || $three == 1){
					output("`n`n%s%s.`0",$c,$dragonkill);
					set_module_pref("one",0);
					set_module_pref("two",0);
					set_module_pref("three",0);
			}
}
function statueshop_exp(){
	global $session;

	$c = get_module_setting("color");
	$owner = get_module_setting("owner");

	$defloss = round($session['user']['level']/7,0);
    $expgain = round($session['user']['experience']*(e_rand(1,2)/10));

	output(" %s%s teaches you new ways to fight, this giving you `^%s %sExperience for the Statue.",$c,$owner,$expgain,$c);
	output(" The knowledge of the books, leaves you feeling a bit weaker.");
	$session['user']['experience']+=$expgain;
	$session['user']['defense']-=$defloss;
	$session['user']['armor'] = "Savage Book Incantation";
}
function statueshop_gems(){
	global $session;

	$c = get_module_setting("color");
	$owner = get_module_setting("owner");

	$maxgain = e_rand(2,5);
	$loss = $maxgain*$session['user']['level'];

	output(" %s%s hands you `^%s %sGems for the Statue.",$c,$owner,$maxgain,$c);
	output(" The weight of the new Gems, leaves you feeling a bit weaker.");
	$session['user']['gems']+=$maxgain;
	$session['user']['hitpoints']-=$loss;
	if ($session['user']['hitpoints']<1){
		$session['user']['hitpoints']=1;
	}
}
function statueshop_hp(){
	global $session;

	$c = get_module_setting("color");
	$owner = get_module_setting("owner");

	$atkloss = round($session['user']['level']/7,0);
	$maxgain = e_rand(2,5);

	output(" %s%s taps you with a wand, and you acquire `^%s %s Max Hitpoints for the Statue.",$c,$owner,$maxgain,$c);
	output(" The imprint of the wand, leaves you feeling a bit weaker.");
	$session['user']['maxhitpoints']+=$maxgain;
	$session['user']['attack']-=$atkloss;
	$session['user']['weapon'] = "Faerie Wand Scar";
}
?>