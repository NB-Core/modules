<?php
/*
Details:
 * This allows your site to have up to 5 custom FaQs.
History Log:
 v1.0:
 o Seems to be Stable
*/
require_once('lib/superusernav.php');
require_once('lib/nltoappon.php');

function sitefaq_getmoduleinfo(){
	$info = array(
		"name"=>"Site FaQs",
		"version"=>"1.0",
		"author"=>"`@CortalUX",
		"category"=>"Administrative",
		"override_forced_nav"=>true,
		"download"=>"http://dragonprime.net/users/CortalUX/sitefaq.zip",
		"settings"=>array(
			"Site FaQs - General,title",
			"(Edit the FaQs in the Grotto! Not here!),note",
			"Site FaqS - Miscellaneous,title",
			"otitle"=>",hidden|",
			"olink"=>",hidden|",
			"odata"=>",hidden|",
			"oemot"=>",hidden|0",
			"ttitle"=>",hidden|",
			"tlink"=>",hidden|",
			"tdata"=>",hidden|",
			"temot"=>",hidden|0",
			"thtitle"=>",hidden|",
			"thlink"=>",hidden|",
			"thdata"=>",hidden|",
			"themot"=>",hidden|0",
			"ftitle"=>",hidden|",
			"flink"=>",hidden|",
			"fdata"=>",hidden|",
			"femot"=>",hidden|0",
			"fhtitle"=>",hidden|",
			"fhlink"=>",hidden|",
			"fhdata"=>",hidden|",
			"fhemot"=>",hidden|0",
		),
	);
	return $info;
}

function sitefaq_install(){
	if (!is_module_active('sitefaq')){
		output("`c`b`QSite FaQ Module - Installed`0`b`c");
		output("`n`\$NOTICE: `^You must set up your FaQs in the Grotto.");
	}else{
		output("`n`c`b`QSite FaQ - Updated`0`b`c");
	}
	module_addhook("superuser");
	module_addhook("faq-toc");
	return true;
}

function sitefaq_uninstall(){
	output("`n`c`b`QSite FaQ Module - Uninstalled`0`b`c");
	return true;
}

function sitefaq_dohook($hookname,$args){
	global $session;
	switch($hookname){
		case "superuser":
			addnav("Module Configurations");
			addnav("Edit FaQs","runmodule.php?module=sitefaq&op=list&admin=true");
		break;
		case "faq-toc":
			sitefaq_link('o');
			sitefaq_link('t');	
			sitefaq_link('th');	
			sitefaq_link('f');	
			sitefaq_link('fi');	
		break;
	}
	return $args;
}

function sitefaq_run(){
	global $session;
	$op = httpget("op");
	$dt = httpget('dt');
	if ($op=='save'||$op=='form') page_header("FaQ Editing");
	switch ($op) {
		case "faq":
			sitefaq_faq($dt);
			die();
		break;
		case "list":
			page_header("FaQ List");
			sitefaq_list();
		break;
		case "save":
			$link = httppost('link');
			$title = httppost('title');
			$faq = httppost('faq');
			$emot = httppost('emot');
			set_module_setting($dt.'title',$title);
			set_module_setting($dt.'link',$link);
			set_module_setting($dt.'data',$faq);
			set_module_setting($dt.'emot',$emot);
			output("`c`b`@FaQ saved.`n`b`c");
		case "form":
			sitefaq_form($dt);
		break;
	}
	superusernav();
	page_footer();
}

function sitefaq_faq($dt) {
	global $session;
	$emot = get_module_setting($dt."emot");
	$title = sitefaq_r(get_module_setting($dt."title"));
	$data = sitefaq_r(get_module_setting($dt."data"));
	if ($emot==1&&is_module_active('emoticons')) {
		$data = sitefaq_emotrepl($data);
	}
	tlschema("faq");
	popup_header($title);
	$c = translate_inline("Contents");
	rawoutput("<center><strong><a href='petition.php?op=faq'>$c</a></strong></center>");
	output("`n`c`b%s`b`c`n",$title);
	output_notl(nltoappon($data),true);
	popup_footer();
}

function sitefaq_form($dt) {
	addnav("FaQs");
	addnav("FaQ List","runmodule.php?module=sitefaq&op=list&admin=true");
	modulehook("collapse{");
	rawoutput("<form name='emotform' action='runmodule.php?module=sitefaq&op=save&admin=true&dt=$dt' method='POST'>");
	addnav("","runmodule.php?module=sitepaq&op=save&admin=true&dt=$dt");
	output("`&`bFaQ Link:`b ");
	rawoutput("<input name='link' value=\"".htmlentities(sitefaq_r(get_module_setting($dt."link")))."\" maxlength=\"30\"><br/>");
	output("`%Leave the link empty, and it won't be displayed.`n");
	output("`&`bFaQ Title:`b ");
	rawoutput("<input name='title' value=\"".htmlentities(sitefaq_r(get_module_setting($dt."title")))."\" maxlength=\"30\"><br/>");
	output("`&`bFaQ Data:`b`n");
	rawoutput("<textarea name='faq' cols='50' rows='3'>".htmlentities(sitefaq_r(get_module_setting($dt."data")))."</textarea><br>");
	rawoutput("");
	$save = translate_inline("Save");
	rawoutput("<input type='submit' class='button' value=\"$save\">");
	sitefaq_emot(get_module_setting($dt."emot"));
	rawoutput("</form>");
	modulehook("}collapse");
	if (is_module_active('emoticons')) {
		modulehook("collapse{");
		sitefaq_emoclick();
		modulehook("}collapse");
	}
	modulehook("collapse{");
	output("`nFaQ's are normally in this format:`n");
	$i = htmlentities("`^");
	$g = htmlentities("`@");
	rawoutput("$i<span class='colLtYellow'>".translate_inline("1. Question?")."</span><br>");
	rawoutput("$g<span class='colLtGreen'>".translate_inline("Answer.")."</span><br><br>");
	rawoutput("$i<span class='colLtYellow'>".translate_inline("2. Another Question?")."</span><br>");
	rawoutput("$g<span class='colLtGreen'>".translate_inline("Another Answer.")."</span><br><br>");
	output("`%And so on.");
	modulehook("}collapse");
}

function sitefaq_list() {
	addnav("FaQs");
	addnav("Edit FaQ 1","runmodule.php?module=sitefaq&op=form&admin=true&dt=o");
	addnav("Edit FaQ 2","runmodule.php?module=sitefaq&op=form&admin=true&dt=t");
	addnav("Edit FaQ 3","runmodule.php?module=sitefaq&op=form&admin=true&dt=th");
	addnav("Edit FaQ 4","runmodule.php?module=sitefaq&op=form&admin=true&dt=f");
	addnav("Edit FaQ 5","runmodule.php?module=sitefaq&op=form&admin=true&dt=fi");
	output("`@FaQs:");
	output("`n`^FaQ 1: `&%s",sitefaq_r(get_module_setting('otitle')));
	output("`n`^FaQ 2: `&%s",sitefaq_r(get_module_setting('ttitle')));
	output("`n`^FaQ 3: `&%s",sitefaq_r(get_module_setting('thtitle')));
	output("`n`^FaQ 4: `&%s",sitefaq_r(get_module_setting('ftitle')));
	output("`n`^FaQ 5: `&%s",sitefaq_r(get_module_setting('fititle')));
}

function sitefaq_link($dt) {
	if (get_module_setting($dt.'link')!="") {
		output_notl("&#149;<a href='runmodule.php?module=sitefaq&dt=".$dt."&op=faq'>`@%s</a><br/>",sitefaq_r(get_module_setting($dt.'link')),true);
		addnav("","runmodule.php?module=sitefaq&dt=".$dt."&op=faq");
	}
}

function sitefaq_emot($emot) {
	if (is_module_active('emoticons')) {
		$yes = translate_inline("Yes");
		$no = translate_inline("No");
		output("`n`bShow emoticons in the FaQ:`b");
		rawoutput("<select name='emot'>");
		rawoutput("<option value='0'".($emot==0?" selected":"").">$no</option>");
		rawoutput("<option value='1'".($emot==1?" selected":"").">$yes</option>");
		rawoutput("</select>", true);
	} else {
		rawoutput("<input type='hidden' name='emot' value='0'>");
	}
}

function sitefaq_emotrepl($data) {
	$data = str_replace("*frown*","<IMG SRC=\"images/frown.gif\">",$data);
	$data = str_replace("*grin*","<IMG SRC=\"images/grin.gif\">",$data);
	$data = str_replace("*biggrin*","<IMG SRC=\"images/grin2.gif\">",$data);
	$data = str_replace("*happy*","<IMG SRC=\"images/happy.gif\">",$data);
	$data = str_replace("*laugh*","<IMG SRC=\"images/laugh.gif\">",$data);
	$data = str_replace("*love*","<IMG SRC=\"images/loveface.gif\">",$data);
	$data = str_replace("*angry*","<IMG SRC=\"images/mad.gif\">",$data);
	$data = str_replace("*mad*","<IMG SRC=\"images/mad2.gif\">",$data);
	$data = str_replace("*music*","<IMG SRC=\"images/musicface.gif\">",$data);
	$data = str_replace("*order*","<IMG SRC=\"images/order.gif\">",$data);
	$data = str_replace("*purple*","<IMG SRC=\"images/purpleface.gif\">",$data);
	$data = str_replace("*red*","<IMG SRC=\"images/redface.gif\">",$data);
	$data = str_replace("*rofl*","<IMG SRC=\"images/rofl.gif\">",$data);
	$data = str_replace("*rolleyes*","<IMG SRC=\"images/rolleyes.gif\">",$data);
	$data = str_replace("*shock*","<IMG SRC=\"images/shock.gif\">",$data);
	$data = str_replace("*shocked*","<IMG SRC=\"images/shocked.gif\">",$data);
	$data = str_replace("*slimer*","<IMG SRC=\"images/slimer.gif\">",$data);
	$data = str_replace("*spineyes*","<IMG SRC=\"images/spineyes.gif\">",$data);
	$data = str_replace("*sarcastic*","<IMG SRC=\"images/srcstic.gif\">",$data);
	$data = str_replace("*tongue*","<IMG SRC=\"images/tongue.gif\">",$data);
	$data = str_replace("*tongue2*","<IMG SRC=\"images/tongue2.gif\">",$data);
	$data = str_replace("*wink*","<IMG SRC=\"images/wink.gif\">",$data);
	$data = str_replace("*wink2*","<IMG SRC=\"images/wink2.gif\">",$data);
	$data = str_replace("*wink3*","<IMG SRC=\"images/wink3.gif\">",$data);
	$data = str_replace("*confused*","<IMG SRC=\"images/confused.gif\">",$data);
	$data = str_replace("*embarassed*","<IMG SRC=\"images/embarassed.gif\">",$data);
	$data = str_replace("*rose*","<IMG SRC=\"images/rose.gif\">",$data);
	$data = str_replace("*drool*","<IMG SRC=\"images/drool.gif\">",$data);
	$data = str_replace("*sick*","<IMG SRC=\"images/sick.gif\">",$data);
	$data = str_replace("*kiss*","<IMG SRC=\"images/kiss.gif\">",$data);
	$data = str_replace("*brokeheart*","<IMG SRC=\"images/brokeheart.gif\">",$data);
	$data = str_replace("*wimper*","<IMG SRC=\"images/wimper.gif\">",$data);
	$data = str_replace("*whew*","<IMG SRC=\"images/whew.gif\">",$data);
	$data = str_replace("*cry*","<IMG SRC=\"images/cry.gif\">",$data);
	$data = str_replace("*angel*","<IMG SRC=\"images/angel.gif\">",$data);
	$data = str_replace("*nerd*","<IMG SRC=\"images/nerd.gif\">",$data);
	$data = str_replace("*stop*","<IMG SRC=\"images/stop.gif\">",$data);
	$data = str_replace("*zzz*","<IMG SRC=\"images/zzz.gif\">",$data);
	$data = str_replace("*shhh*","<IMG SRC=\"images/shhh.gif\">",$data);
	$data = str_replace("*nottalking*","<IMG SRC=\"images/nottalking.gif\">",$data);
	$data = str_replace("*party*","<IMG SRC=\"images/party.gif\">",$data);
	$data = str_replace("*yawn*","<IMG SRC=\"images/yawn.gif\">",$data);
	$data = str_replace("*doh*","<IMG SRC=\"images/doh.gif\">",$data);
	$data = str_replace("*clap*","<IMG SRC=\"images/clap.gif\">",$data);
	$data = str_replace("*lie*","<IMG SRC=\"images/lie.gif\">",$data);
	$data = str_replace("*bateyes*","<IMG SRC=\"images/bateyes.gif\">",$data);
	$data = str_replace("*pray*","<IMG SRC=\"images/pray.gif\">",$data);
	$data = str_replace("*peace*","<IMG SRC=\"images/peace.gif\">",$data);
	$data = str_replace("*nono*","<IMG SRC=\"images/nono.gif\">",$data);
	$data = str_replace("*bow*","<IMG SRC=\"images/bow.gif\">",$data);
	$data = str_replace("*groove*","<IMG SRC=\"images/groove.gif\">",$data);
	$data = str_replace("*giggle*","<IMG SRC=\"images/giggle.gif\">",$data);
	$data = str_replace("*yakyak*","<IMG SRC=\"images/yakyak.gif\">",$data);
	return $data;
}

function sitefaq_emoclick() {
	output("`n`c`2-=-=Clickable Smilies=-=-`n");
	rawoutput("<a onClick=\"addSmiley(' *frown* ')\"><img src='./images/frown.gif'></a> ");
	rawoutput("<a onClick=\"addSmiley(' *grin* ')\"><img src='./images/grin.gif'></a> ");
	rawoutput("<a onClick=\"addSmiley(' *biggrin* ')\"><img src='./images/grin2.gif'></a> ");
	rawoutput("<a onClick=\"addSmiley(' *happy* ')\"><img src='./images/happy.gif'></a> ");
	rawoutput("<a onClick=\"addSmiley(' *laugh* ')\"><img src='./images/laugh.gif'></a> ");
	rawoutput("<a onClick=\"addSmiley(' *love* ')\"><img src='./images/loveface.gif'></a> ");
	rawoutput("<a onClick=\"addSmiley(' *angry* ')\"><img src='./images/mad.gif'></a> ");
	rawoutput("<a onClick=\"addSmiley(' *mad* ')\"><img src='./images/mad2.gif'></a> ");
	rawoutput("<a onClick=\"addSmiley(' *music* ')\"><img src='./images/musicface.gif'></a> ");
	rawoutput("<a onClick=\"addSmiley(' *order* ')\"><img src='./images/order.gif'></a> ");
	rawoutput("<a onClick=\"addSmiley(' *purple* ')\"><img src='./images/purpleface.gif'></a> ");
	rawoutput("<a onClick=\"addSmiley(' *red* ')\"><img src='./images/redface.gif'></a> ");
	rawoutput("<a onClick=\"addSmiley(' *rofl* ')\"><img src='./images/rofl.gif'></a> ");
	rawoutput("<a onClick=\"addSmiley(' *rolleyes* ')\"><img src='./images/rolleyes.gif'></a> ");
	rawoutput("<a onClick=\"addSmiley(' *shock* ')\"><img src='./images/shock.gif'></a> ");
	rawoutput("<a onClick=\"addSmiley(' *shocked* ')\"><img src='./images/shocked.gif'></a> ");
	rawoutput("<a onClick=\"addSmiley(' *slimer* ')\"><img src='./images/slimer.gif'></a> ");
	rawoutput("<a onClick=\"addSmiley(' *spineyes* ')\"><img src='./images/spineyes.gif'></a> ");
	rawoutput("<a onClick=\"addSmiley(' *sarcastic* ')\"><img src='./images/srcstic.gif'></a> ");
	rawoutput("<a onClick=\"addSmiley(' *tongue* ')\"><img src='./images/tongue.gif'></a> ");
	rawoutput("<a onClick=\"addSmiley(' *tongue2* ')\"><img src='./images/tongue2.gif'></a> ");
	rawoutput("<a onClick=\"addSmiley(' *wink* ')\"><img src='./images/wink.gif'></a> ");
	rawoutput("<a onClick=\"addSmiley(' *wink2* ')\"><img src='./images/wink2.gif'></a> ");
	rawoutput("<a onClick=\"addSmiley(' *wink3* ')\"><img src='./images/wink3.gif'></a> ");
	rawoutput("<a onClick=\"addSmiley(' *confused* ')\"><img src='./images/confused.gif'></a> ");
	rawoutput("<a onClick=\"addSmiley(' *embarassed* ')\"><img src='./images/embarassed.gif'></a> ");
	rawoutput("<a onClick=\"addSmiley(' *rose* ')\"><img src='./images/rose.gif'></a> ");
	rawoutput("<a onClick=\"addSmiley(' *drool* ')\"><img src='./images/drool.gif'></a> ");
	rawoutput("<a onClick=\"addSmiley(' *sick* ')\"><img src='./images/sick.gif'></a> ");
	rawoutput("<a onClick=\"addSmiley(' *bow* ')\"><img src='./images/bow.gif'></a> ");
	rawoutput("<a onClick=\"addSmiley(' *kiss* ')\"><img src='./images/kiss.gif'></a> ");
	rawoutput("<a onClick=\"addSmiley(' *brokeheart* ')\"><img src='./images/brokeheart.gif'></a> ");
	rawoutput("<a onClick=\"addSmiley(' *wimper* ')\"><img src='./images/wimper.gif'></a> ");
	rawoutput("<a onClick=\"addSmiley(' *whew* ')\"><img src='./images/whew.gif'></a> ");
	rawoutput("<a onClick=\"addSmiley(' *cry* ')\"><img src='./images/cry.gif'></a> ");
	rawoutput("<a onClick=\"addSmiley(' *angel* ')\"><img src='./images/angel.gif'></a> ");
	rawoutput("<a onClick=\"addSmiley(' *nerd* ')\"><img src='./images/nerd.gif'></a> ");
	rawoutput("<a onClick=\"addSmiley(' *stop* ')\"><img src='./images/stop.gif'></a> ");
	rawoutput("<a onClick=\"addSmiley(' *zzz* ')\"><img src='./images/zzz.gif'></a> ");
	rawoutput("<a onClick=\"addSmiley(' *yakyak* ')\"><img src='./images/yakyak.gif'></a> ");
	rawoutput("<a onClick=\"addSmiley(' *shhh* ')\"><img src='./images/shhh.gif'></a> ");
	rawoutput("<a onClick=\"addSmiley(' *nottalking* ')\"><img src='./images/nottalking.gif'></a> ");
	rawoutput("<a onClick=\"addSmiley(' *party* ')\"><img src='./images/party.gif'></a> ");
	rawoutput("<a onClick=\"addSmiley(' *yawn* ')\"><img src='./images/yawn.gif'></a> ");
	rawoutput("<a onClick=\"addSmiley(' *doh* ')\"><img src='./images/doh.gif'v></a> ");
	rawoutput("<a onClick=\"addSmiley(' *clap* ')\"><img src='./images/clap.gif'></a> ");
	rawoutput("<a onClick=\"addSmiley(' *lie* ')\"><img src='./images/lie.gif'></a> ");
	rawoutput("<a onClick=\"addSmiley(' *bateyes* ')\"><img src='./images/bateyes.gif'></a> ");
	rawoutput("<a onClick=\"addSmiley(' *pray* ')\"><img src='./images/pray.gif'></a> ");
	rawoutput("<a onClick=\"addSmiley(' *peace* ')\"><img src='./images/peace.gif'></a> ");
	rawoutput("<a onClick=\"addSmiley(' *nono* ')\"><img src='./images/nono.gif'></a> ");
	rawoutput("<a onClick=\"addSmiley(' *groove* ')\"><img src='./images/groove.gif'></a> ");
	rawoutput("<a onClick=\"addSmiley(' *giggle* ')\"><img src='./images/giggle.gif'></a> ");
	rawoutput("<script language=\"JavaScript\" type=\"text/javascript\">\n");
	rawoutput("function addSmiley(textToAdd)\n");
	rawoutput("{\n");
	rawoutput("document.emotform.faq.value += textToAdd;");
	rawoutput("document.emotform.faq.focus();\n");
	rawoutput("}\n");
	rawoutput("</script>\n");
	output_notl("`c");
}

function sitefaq_r($f) {
	$x = str_replace('\"','"',$f);
	$y = str_replace("\'","'",$x);
	return $y;
}
?>