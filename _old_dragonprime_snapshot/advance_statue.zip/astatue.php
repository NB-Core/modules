<?php
/* What kickme added:
User can turn statue off,
Admin can turn statue off per user,
Statue is now finished after a certain amount of days,
The amount of days till the statue is finished can be defined by the admin,
If the hero slays the dragon, the statue doesn't have to be rebuilt,
If the hero is deleted, the hero is reset to MightyE,
The statue of MightyE takes half as much time to make as other statues,
User can destroy statue,
Admin settable: chance of breaking statue,
Admin settable: Put user in stocks after breaking statue,
If user breaks statue, they lose all gold and gems, their armor and weapon, some charm and most hps
*/
function astatue_getmoduleinfo(){
	$info = array(
		"name"=>"Advance Village Statue",
		"author"=>"`%kickme`#<br />Based on Village Statue by Eric Stevens`0",
		"version"=>"1.2.1",
		"category"=>"Village",
		"download"=>"http://dragonprime.net/users/kickme/advance_statue.zip",
		"vertxtloc"=>"http://dragonprime.net/users/kickme/",
		"settings"=>array(
			"Advance Village Statue Settings,title",
			"hero"=>"Who is the statue of?|",
			"days"=>"How many days until a new statue is created?,range,1,10,1|5",
			"time"=>"How many days has the statue been under construction for?,int|0",
			"showonindex"=>"Should the last dragonkill be shown on the home page?,bool|1",
			"Destroy Statue Settings,title",
			"adestroy"=>"Allow user to destroy statue?,bool|1",
			"stocks"=>"If user breaks statue put them in the stocks?,bool|1",
			"chance"=>"Chance of breaking the statue? (%),range,1,100,1|50",
		),
		"prefs"=>array(
			"Advance Village Statue - User Prefs,title",
			"user_see"=>"Show Statue?,bool|1",
			"If set to no you can't be the hero.,note",
			"Superuser can overrule this.,note",
			"asee"=>"Superuser: Show Statue,bool|1",			
		),
	);
	return $info;
}
function astatue_install(){
	module_addhook("village-desc");
	module_addhook("dragonkill");
	module_addhook("namechange");
	module_addhook("index");
	module_addhook("newday-runonce");
	return true;
}
function astatue_uninstall(){
	debug("Uninstalling module.");
	return true;
}
function astatue_dohook($hookname, $args) {
	global $REQUEST_URI;
	global $session;
	$capital = getsetting("villagename", LOCATION_FIELDS);
	$hero = get_module_setting("hero");
	$time = get_module_setting("time");
	$day = get_module_setting("days");
	$see = get_module_pref("user_see");
	$asee = get_module_pref("asee");
	$chance = get_module_setting("chance");
	$sql = "SELECT name FROM " . db_prefix("accounts") . " WHERE acctid='$hero'";
	$result = db_query_cached($sql, "lasthero");
	$row = db_fetch_assoc($result);
	if($row['name'] == "" && $hero != 0) {
		$hero = 0;
		$time = 0;
		set_module_setting("time", $time);
		set_module_setting("hero", $hero);
	}
	if($row['name'] == "") $row['name'] = "MightyE";
	if(!$see) return $args;
	if(!$asee) return $args;
	switch($hookname){
	case "newday-runonce":
			$time++;
			set_module_setting("time", $time);
		break;
	case "village-desc":
		// copied from Village Stocks by Eric Stevens
		if ($session['user']['location']!=$capital) break;
		$op = httpget("op");
		if ($op == "astatue") {
			// Get rid of the op=stocks bit from the URI
			$REQUEST_URI = preg_replace("/[&?]?op=astatue/","",$REQUEST_URI);
			$_SERVER['REQUEST_URI'] = preg_replace("/[&?]?op=astatue/","",$_SERVER['REQUEST_URI']);
			// end copy
			$break = rand(1,100);
			if($break>$chance) {
				output("`n`@You take a closer look at the statue of `&%s`@. From the amount of detail in the statue, you think that the people of %s must love `&%s`@.`0`n",$row['name'],$session['user']['location'],$row['name']);
				break;
			} else {
				output("`n`@You take a closer look at the statue of `&%s`@. As you lean closer for a better view, you stumble and smash the statue.`n`7The people of %s take all your gold and gems, beat you up then, publicly, strip you of your armor and weapon.",$row['name'],$session['user']['location']);
				if(get_module_setting("stocks")) {
					output("`7%s`7 watches the whole thing before walking back into the inn. The last thing you can remember before losing consciousness is the sound of the hard wood of the stocks crashing together around your neck!`n",$session['user']['sex']?"`^Seth":"`%Violet");
					set_module_setting("victim",$session['user']['acctid'], "stocks");
				} else {
					output("The last thing you can remember before losing consciousness is %s watches the whole thing before walking back into the inn.",$session['user']['sex']?"`^Seth":"`%Violet");
				}
				addnews("`&%s `7broke the statue!",$session['user']['name']);
				$session['user']['gems'] = 0;
				$session['user']['gold'] = 0;
				$session['user']['charm'] -= 10;
				$session['user']['hitpoints'] = 1;
				$session['user']['armor'] = "T-Shirt";
				$session['user']['weapon'] = "Fists";
				$session['user']['weaponvalue'] = 0;
				$session['user']['armorvalue'] = 0;
				$session['user']['defense'] -= $session['user']['armordef'];
				$session['user']['armordef'] = 0;
				$session['user']['attack'] -= $session['user']['weapondmg'];
				$session['user']['weapondmg'] = 0;
				$time = 0;
				set_module_setting("time", $time);
				output("`^You `\$lose`^ some charm!`n `^You `\$lose`^ all of your onhand gold and gems!`n`^You `\$lose`^ your armor!`n`^You `\$lose`^ your weapon!`n`^You `\$lose`^ some hitpoints!`n");
			break;
			}
		}
		if ($hero == 0 && $time >= $day/2) {
			output("`n`@The people wandering past periodically stop to admire a statue of the ancient hero, `&MightyE`@.`0`n");
		} elseif ($hero == 0 && $time < $day/2) {
			output("`n`@The inhabitants of %s are busy re-erecting a statue for their ancient hero, `&MightyE`@ on the only statue pedestal around.  The remains of the statue that had stood there before lie in such ruins around the pedestal that it is no longer recognizable.`0`n",$session['user']['location'],$row['name']);
		} else {
			if ($time < $day) {
				output("`n`@The inhabitants of %s are busy erecting a statue for their newest hero, `&%s`@ on the only statue pedestal around.  The remains of the statue that had stood there before lie in such ruins around the pedestal that it is no longer recognizable.`0`n",$session['user']['location'],$row['name']);
			} else {
				output("`n`@The inhabitants of %s have erected a statue for their newest hero, `&%s`@ on the only statue pedestal around.  The remains of the statue that had stood there before have been removed.`0`n",$session['user']['location'],$row['name']);
			}
		}
		// copied from Village Stocks by Eric Stevens
		$examine = translate_inline("Examine Statue");
		output_notl(" [");
		rawoutput("<a href='village.php?op=astatue'>$examine</a>");
		output_notl("]`0`n");
		addnav("", "village.php?op=astatue");
		// end copy
		break;
	case "index":
		if (!get_module_setting("showonindex")) break;
		$heroname = "MightyE";
		if ($hero != 0) {
			$heroname = $row['name'];
			output("`@The most recent hero of the realm is: `&%s`0`n`n",$heroname);
		}
		else output("`@There is no hero at the moment, will you be the first?`0`n`n");
		break;
	case "dragonkill":
		if(get_module_setting("hero") != $session['user']['acctid']) {
			set_module_setting("time", "0");
		}
		set_module_setting("hero", $session['user']['acctid']);
		invalidatedatacache("lasthero");
		break;
	case "namechange":
		if ($hero == $session['user']['acctid']) {
			invalidatedatacache("lasthero");
		}
		break;
	}
return $args;
}
?>