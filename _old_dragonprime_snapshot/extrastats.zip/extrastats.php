<?
require_once("lib/http.php");

function extrastats_getmoduleinfo(){
	$info = array(
		"name"=>"Extra Stats",
		"author"=>"UnderDark",
		"version"=>"1.0",
		"category"=>"User Interface",
		"download"=>"http://dragonprime.net/users/underdark/extrastats.zip"
	);
	return $info;
}

function extrastats_install(){
	debug("Installing this module.`n");
	module_addhook("charstats");
	return true;
}

function extrastats_uninstall(){
	output("Uninstalling this module.`n");
	return true;
}

function extrastats_dohook($hookname, $args){
  global $session;
	setcharstat("Equipment Info","Weapon Damage", $session[user][weapondmg]);
	setcharstat("Equipment Info","Armor Strength", $session[user][armordef]);
	setcharstat("Vital Info","Drunkenness", $session[user][drunkenness]);
	return $args;
}
?>
