<?php
//Alignment added by WebPixie
//V2.1  Minor Spelling changes by DaveS
function voodoopriestess_getmoduleinfo(){
	$info = array(
		"name"=>"Voodoo Priestess",
		"version"=>"2.1",
		"author"=>"`#Lonny Luberts",
		"category"=>"PQcomp",
		"download"=>"http://www.pqcomp.com/modules/mydownloads/visit.php?cid=3&lid=25",
		"vertxtloc"=>"http://www.pqcomp.com/",
		"prefs"=>array(
			"Voodoo Priestess Module User Preferences,title",
			"curse"=>"Curse,text|",
			"cast"=>"Cast Curse,bool|0",
			"ctoday"=>"Cursed Today,bool|0",
		),
		"settings"=>array(
			"Voodoo Priestess Module Settings,title",
			"death"=>"Allow Death Curse,bool|0",
			"voodooloc"=>"Where does the Voodoo Priestess appear,location|".getsetting("villagename", LOCATION_FIELDS),
		),
	);
	return $info;
}

function voodoopriestess_install(){
	if (!is_module_active('voodoopriestess')){
		output("`4Installing Voodoo Priestess Module.`n");
	}else{
		output("`4Updating Voodoo Priestess Module.`n");
	}
	module_addhook("newday");
	module_addhook("village");
	return true;
}

function voodoopriestess_uninstall(){
	output("`4Un-Installing Voodoo Priestess Module.`n");
	return true;
}

function voodoopriestess_dohook($hookname,$args){
	global $session;
	switch($hookname){
		case "newday":
			set_module_pref('cast', false);
			set_module_pref('ctoday', false);
		break;
		case "village":
			if ($session['user']['location'] == get_module_setting("voodooloc")){
				tlschema($args['schemas']['tavernnav']);
    			addnav($args['tavernnav']);
    			tlschema();
				addnav("Voodoo Priestess", "runmodule.php?module=voodoopriestess");
			}
			$curse = get_module_pref('curse');
                if ($curse != NULL){
                switch($curse){
                	case "poverty":
                    	output("`4A Curse of Poverty has been cast on you!  You lose 500 gold!");
			   			$session['user']['goldinbank']-=500;
                    break;
                    case "ugliness":
                        output("`4A Curse of Ugliness has been cast on you!  You lose 2 Charm!");
			   			$session['user']['charm']-=2;
			   		break;
                    case "sleep":
                        output("`4A Curse of Sluggishness has been cast on you!  You lose 3 Forest Fights!");
                        $session['user']['turns']-=3;
                    break;
                    case "weak":
                        output("`4A Curse of Weakness has been cast on you!  You lose 1 Max Hitpoint");
                        if ($session['user']['maxhitpoints'] > $session['user']['level'] * 10) $session['user']['maxhitpoints']-=1;
                    break;
                    case "death":
			            set_module_pref('curse',"");
                    	redirect("runmodule.php?module=voodoopriestess&op=dead");
			        break;
                    case "drunk":
	                   	output("`4A Curse of Drunkeness has been cast on you!  You are plastered!");
			   			$session['user']['drunkenness']=80;
			   		break;
                    case "wealth":
                        output("`@A Spell of Wealth has been cast on you!  You gain 500 gold!");
                        $session['user']['gold']+=500;
                    break;
                    case "beauty":
                        output("`@A Spell of Beauty has been cast on you!  You gain 3 Charm!");
			   			$session['user']['charm']+=3;
			   		break;
                    case "vitality":
                        output("`@A Spell of Vitality has been cast on you!  You gain 3 Forest Fights!");
			   			$session['user']['turns']+=3;
			   		break;
                    case "strength":
                        output("`@A Spell of Strength has been cast on you!  You gain 1 Max Hitpoint!");
                        $session['user']['maxhitpoints']+=1;
                    break;
                    case "odor";
                    	output("`4A Curse of Odor has been cast on you!  You stink!");
                    	set_module_pref('odor',get_module_pref('odor','odor') + 10,'odor');
                    break;
                    case "hunger":
                    	output("`4A Curse of Hunger has been cast on you!  You are starving!");
                    	set_module_pref('hunger',get_module_pref('hunger','usechow') + 60,'usechow');
                    break;
                    case "bladder":
                    	output("`4A Curse of WeeWee has been cast on you!  You have to go potty really bad!");
                    	set_module_pref('bladder',get_module_pref('bladder','bladder') + 10,'bladder');
                    break;
                    default:
                        output("You feel strange, but you don't know why...");
                }
            set_module_pref('curse',"");
            }
		break;
	}
	return $args;
}

function voodoopriestess_run(){
	global $SCRIPT_NAME;
	if ($SCRIPT_NAME == "runmodule.php"){
		$module=httpget("module");
		if ($module == "voodoopriestess") include("modules/lib/voodoopriestess.php");
	}
}
?>