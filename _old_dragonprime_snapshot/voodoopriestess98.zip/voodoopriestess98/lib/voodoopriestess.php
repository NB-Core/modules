<?
global $session;
$op = httpget('op');
page_header("Voodoo Priestess");
$myname=$session['user']['name'];
if ($op=="dead"){
	output("`4A Curse of Death has been cast on you!  You are dead!");
	$session['user']['hitpoints']=0;
	$session['user']['alive']=0;
	addnav("Continue","shades.php");
}
if ($op==""){
    if (get_module_pref('cast')){
	    output("`@`c`bVoodoo Priestess`b`c`n");
	    output("`3She looks up and you and says...`n");
        output("`7Welcome %s.`n`n",$myname);
	    output("`@You have already cast a spell today.");
	    addnav("Return to Village","village.php");
    }else{
		output("`@`c`bVoodoo Priestess`b`c`n");
		output("`&`cYou step into the grass hut, and notice a haggard old woman sitting in the center of a circle made of strange bone fragments and rocks.`c`n`n");
		output("`3She looks up and you and says...`n");
		output("`7Welcome %s.`n`n",$myname);
		output("`7I can cast a curse or a spell on anyone that you would like.`n");
		output("`7For a price of course.`n");

		if ($session['user']['gold'] > 999){
			addnav("`%Curse of Poverty `^(1000 Gold)","runmodule.php?module=voodoopriestess&op=precast&spell=poverty&cost=1000&align=bad");
		}
		if ($session['user']['gold'] > 999 and is_module_active('odor')){
			addnav("`%Curse of Stench `^(1000 Gold)","runmodule.php?module=voodoopriestess&op=precast&spell=odor&cost=1000&align=bad");
		}
		if ($session['user']['gold'] > 999 and is_module_active('usechow')){
			addnav("`%Curse of Famine `^(1000 Gold)","runmodule.php?module=voodoopriestess&op=precast&spell=hunger&cost=1000&align=bad");
		}
		if ($session['user']['gold'] > 999 and is_module_active('bladder')){
			addnav("`%Curse of WeeWee `^(1000 Gold)","runmodule.php?module=voodoopriestess&op=precast&spell=bladder&cost=1000&align=bad");
		}
		if ($session['user']['gold'] > 1999){
			addnav("`%Curse of Ugliness `^(2000 Gold)","runmodule.php?module=voodoopriestess&op=precast&spell=ugliness&cost=2000&align=bad");
		}
		if ($session['user']['gold'] > 2999){
			addnav("`%Curse of Sleep `^(3000 Gold)","runmodule.php?module=voodoopriestess&op=precast&spell=sleep&cost=3000&align=bad");
		}
		if ($session['user']['gold'] > 3999){
			addnav("`%Curse of Drunkeness `^(4000 Gold)","runmodule.php?module=voodoopriestess&op=precast&spell=drunk&cost=4000&align=bad");
		}
		if ($session['user']['gold'] > 4999){
			addnav("`%Curse of Weakness `^(5000 Gold)","runmodule.php?module=voodoopriestess&op=precast&spell=weak&cost=5000&align=bad");
		}
		if ($session['user']['gold'] > 19999 and get_module_setting('death')){
		addnav("`%Curse of Death `^(20000 Gold)","runmodule.php?module=voodoopriestess&op=precast&spell=death&cost=20000&align=bad");
		}
		if ($session['user']['gold'] > 999){
			addnav("`@Spell of Wealth `^(1000 Gold)","runmodule.php?module=voodoopriestess&op=precast&spell=wealth&cost=1000&align=good");
		}
		if ($session['user']['gold'] > 1999){
			addnav("`@Spell of Beauty `^(2000 Gold)","runmodule.php?module=voodoopriestess&op=precast&spell=beauty&cost=2000&align=good");
		}
		if ($session['user']['gold'] > 3999){
			addnav("`@Spell of Vitality `^(4000 Gold)","runmodule.php?module=voodoopriestess&op=precast&spell=vitality&cost=4000&align=good");
		}
		if ($session['user']['gold'] > 7999){
			addnav("`@Spell of Strength `^(8000 Gold)","runmodule.php?module=voodoopriestess&op=precast&spell=strength&cost=8000&align=good");
		} if ($session['user']['gold'] <= 999) {
output("`n`0You don't have enough for my services. Come back when you can pay me what I am worth.`n`n"); }

addnav("Return to Village","village.php");
}

		
	
	//I cannot make you keep this line here but would appreciate it left in.
	rawoutput("<div style=\"text-align: left;\"><a href=\"http://www.pqcomp.com\" target=\"_blank\">Voodoo Priestess by Lonny @ http://www.pqcomp.com</a><br>");
}

if($op=="precast"){
	output("Who would you like to Curse?`n");
		rawoutput("<form action='runmodule.php?module=voodoopriestess&op=cast&spell=".$_GET['spell']."&cost=".$_GET['cost']."&align=".$_GET['align']."&name=".HTMLEntities($row['login'])."' method='POST'>");
		rawoutput("<p><input type=\"text\" name=\"whom\" size=\"37\"></p>");
		rawoutput("<p><input type=\"submit\" value=\"Submit\" name=\"B1\"><input type=\"reset\" value=\"Reset\" name=\"B2\"></p>");
		rawoutput("</form>");
		addnav("","runmodule.php?module=voodoopriestess&op=cast&spell=".$_GET['spell']."&cost=".$_GET['cost']."&align=".$_GET['align']."&name=".HTMLEntities($row['login']));
		addnav("Go Back","runmodule.php?module=voodoopriestess");
}
if($op=="cast"){
addnav("Reconsider this Curse","runmodule.php?module=voodoopriestess");
$string="%";
for ($x=0;$x<strlen($_POST['name']);$x++){
	$string .= substr($_POST['name'],$x,1)."%";
}
$whom=$_POST['whom'];
$whom = stripslashes(rawurldecode($whom));
        $name="%";
        for ($x=0;$x<strlen($whom);$x++){
            $name.=substr($whom,$x,1)."%";
        }
        $whom = addslashes($name);
$sql = "SELECT login,name,level FROM ".db_prefix("accounts")." WHERE name LIKE '%".$whom."%' AND acctid <> ".$session['user']['acctid']." AND locked=0 ORDER BY level,login";
$result = db_query($sql);
		        output("`\$Voodoo Priestess`) will allow you to curse these people:`n");
		        rawoutput("<table cellpadding='3' cellspacing='0' border='0'>");
		        rawoutput("<tr class='trhead'><td>Name</td><td>Level</td></tr>");
		          for ($i=0;$i<db_num_rows($result);$i++){
			      $row = db_fetch_assoc($result);
			      rawoutput("<tr class='".($i%2?"trlight":"trdark")."'><td><a href='runmodule.php?module=voodoopriestess&op=cast2&spell=".$_GET['spell']."&cost=".$_GET['cost']."&align=".$_GET['align']."&name=".HTMLEntities($row['login'])."'>");
			      output_notl($row['name']);
			      rawoutput("</a></td><td>");
			      output_notl($row['level']);
			      rawoutput("</td></tr>");
			      addnav("","runmodule.php?module=voodoopriestess&op=cast2&spell=".$_GET['spell']."&cost=".$_GET['cost']."&align=".$_GET['align']."&name=".HTMLEntities($row['login']));
		          }
		          rawoutput("</table>");
}

if($op=="cast2"){
	output("`c`bVoodoo Priestess`b`c");
	$sql = "SELECT name,level,acctid FROM ".db_prefix("accounts")." WHERE login='".$_GET['name']."'";
	$result = db_query($sql);
	if (db_num_rows($result)>0){
		$row = db_fetch_assoc($result);
		if (get_module_pref('today','voodoopriestess',$row['acctid'])){
			output("`4That person has already been cursed, please select another target.");
			addnav("Continue","runmodule.php?module=voodoopriestess");
		}
		else{
			$session['user']['gold']-=$_GET['cost'];
			if ($_GET['align'] =='good'){
				$which = "spell";
				if (is_module_active('alignment')) {
					align("2");
				}
			}elseif ($_GET['align'] =='bad'){
				$which = "curse";
				if (is_module_active('alignment')) {
					align("-2");
				}
			}
			output("`@You have successfully placed a %s of %s on`7 %s !",$which,$_GET['spell'],$row['name']);
			set_module_pref('curse', $_GET['spell'], 'voodoopriestess', $row['acctid']);
			set_module_pref('ctoday', true, 'voodoopriestess', $row['acctid']);
			set_module_pref('cast', 1);
			addnews("`7 %s cast a spell of %s on`7 %s !",$session['user']['name'],$_GET['spell'],$row['name']);
		 	require_once("lib/systemmail.php");
			$mailmessage="A spell of ".$_GET['spell']." has been cast on you by ".$session['user']['name']."!";
		 	systemmail($row['acctid'],"You are spellbound!",$mailmessage);
            addnav("Return to Village","village.php");
        }
    }

}
page_footer();
?>