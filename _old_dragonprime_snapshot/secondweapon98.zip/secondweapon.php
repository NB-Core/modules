<?php
function secondweapon_getmoduleinfo(){
	$modsettings = array("Secondweapon Module Settings,title");
			$modsettings['bowshoploc'] = "Where does the Bow Shop appear,location|".getsetting("villagename", LOCATION_FIELDS);
			$modsettings['bowshopowner'] = "Name of the Bow Shop owner,text|Warnick";
			$modsettings['bowshopsex'] = "Sex of Bow Shop Owner,enum,he,Male,she,Female";
			$modsettings['crossbowshoploc'] = "Where does the Crossbow Shop appear,location|".getsetting("villagename", LOCATION_FIELDS);
			$modsettings['crossbowshopowner'] = "Name of the Crossbow Shop owner,text|Wepnick";
			$modsettings['crossbowshopsex'] = "Sex of Crossbow Shop Owner,enum,he,Male,she,Female";
			$modsettings['slingshoploc'] = "Where does the Sling Shop appear,location|".getsetting("villagename", LOCATION_FIELDS);
			$modsettings['slingshopowner'] = "Name of the Sling Shop owner,text|Wagnick";
			$modsettings['slingshopsex'] = "Sex of Sling Shop Owner,enum,he,Male,she,Female";
			$modsettings['weapcost'] = "Weapon Cost in Gems,int|10";
			$modsettings['trainloc'] = "Where does the Weapons Training appear,location|".getsetting("villagename", LOCATION_FIELDS);
			$modsettings['trainowner'] = "Name of the Weapons Training Shop owner,text|Borenick";
			$modsettings['trainsex'] = "Sex of Weapons Training Owner,enum,he,Male,she,Female";
			$modsettings['skillkeep'] = "Percent of Skill to keep at dragonkill,enum,.33,33,0,None,.25,25,.50,50";
			$modsettings['keepammo'] = "Allow player to keep ammo past dragon kill?,bool|0";
			$modsettings['keepweapon'] = "Allow player to keep weapon past dragon kill?,bool|0";
		if (is_module_active('altcurrency')){
			$modsettings['usealtcurrency'] = "Use Alternative Currency,bool|0";
			if (get_module_setting('usealtcurrency') == 1){
				require_once("modules/altcurrency.php");
				$currencylist = altcurrency_buildlist();
				$modsettings['bowshopcurrency'] = "Bow Shop Which Currency to use?,enum".$currencylist;
				$modsettings['bowcost'] = "Cost for Bow in Alt Currency,int|0";
				$modsettings['arrowcost'] = "Cost for Arrow in Alt Currency,int|0";
				$modsettings['crossbowshopcurrency'] = "CrossBow Shop Which Currency to use?,enum".$currencylist;
				$modsettings['crossbowcost'] = "Cost for Crossbow in Alt Currency,int|0";
				$modsettings['boltcost'] = "Cost for Bolt in Alt Currency,int|0";
				$modsettings['slingshopcurrency'] = "Sling Shop Which Currency to use?,enum".$currencylist;
				$modsettings['slingcost'] = "Cost for Sling in Alt Currency,int|0";
				$modsettings['stonecost'] = "Cost for Stone in Alt Currency,int|0";
			}
		}
	$info = array(
		"name"=>"Secondaryweapon",
		"version"=>"2.21",
		"author"=>"`#Lonny Luberts",
		"category"=>"PQcomp",
		"download"=>"http://www.pqcomp.com/modules/mydownloads/visit.php?cid=3&lid=16",
		"vertxtloc"=>"http://www.pqcomp.com/",
		"prefs"=>array(
			"Secondweapon Module User Preferences,title",
			"weapon"=>"Weapon Name,text|",
			"ammo"=>"Arrows,int|0",
			"weaponskill"=>"Players skill,int|1",
		),
		"settings"=>$modsettings
	);
	return $info;
}

function secondweapon_install(){
	if (!is_module_active('secondweapon')){
		output("`4Installing Secondweapon Module.`n");
	}else{
		output("`4Updating Secondweapon Module.`n");
	}
	module_addhook("village");
	module_addhook("dragonkill");
	module_addhook("charstats");
	module_addhook("fightnav");
	module_addhook("apply-specialties");
	module_addeventhook("forest", "return 100;");
	module_addeventhook("travel", "return 20;");
	return true;
}

function secondweapon_uninstall(){
	output("`4Installing Secondweapon Module.`n");
	return true;
}

function secondweapon_dohook($hookname,$args){
	global $session;
	switch($hookname){
	case "charstats":
		if ($session['user']['alive'] == 1) include("modules/lib/secondweapon_stat.php");
	break;
	case "dragonkill":
		if (get_module_setting("keepweapon") == 0) set_module_pref('weapon', '');
		if (get_module_setting("keepammo") == 0) set_module_pref('ammo', 0);
		set_module_pref('weaponskill',round(get_module_pref('weaponskill') * get_module_setting('skillkeep')));
	break;
	case "fightnav":
		if ($session['user']['alive'] == 1) include("modules/lib/secondweapon_fightnav.php");
	break;
	case "apply-specialties":
		if ($session['user']['alive'] == 1) include("modules/lib/secondweapon_spec.php");
	break;
	case village:
		include("modules/lib/secondweapon_nav.php");
	break;
	}
	return $args;
}

function secondweapon_run(){
	global $SCRIPT_NAME;
	if ($SCRIPT_NAME == "runmodule.php"){
		include("modules/lib/secondweapon.php");
	}
}

function secondweapon_runevent($type){
	global $SCRIPT_NAME;
	if ($SCRIPT_NAME == "forest.php" or $SCRIPT_NAME == "runmodule.php"){
		include("modules/lib/secondweapon_event.php");
	}
}
?>