<?php
global $SCRIPT_NAME;
	if ($type == "forest"){
		output("`3While wandering the forest, ");
	}else{
		output("`3While traveling, ");
	}
	if (e_rand(1,10) < 6){
		if (get_module_pref('weapon') <> ""){
			switch (get_module_pref('weapon')){
				case "Bow":
					output("`3you find an Arrow!`n");
				break;
				case "Crossbow":
					output("`3you find a Bolt!`n");
				break;
				case "Sling":
					output("`3you find a Stone!`n");
				break;
			}
			set_module_pref('ammo',get_module_pref('ammo')+1);
		}
	}else{
		switch (e_rand(1,3)){
			case 1:
				output("`3you find an Arrow!`n");
			break;
			case 2:
				output("`3you find a Bolt!`n");
			break;
			case 3:
				output("`3you find a Stone!`n");
			break;
		}
		output("`3You pick it up, only to find it is broken.`n");
	}
?>