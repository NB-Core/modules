<?php
		if (get_module_setting('bowshoploc') == $session['user']['location']){
			tlschema($args['schemas']['marketnav']);
    		addnav($args['marketnav']);
    		tlschema();
			addnav(array("%s's Weapons", get_module_setting('bowshopowner')),"runmodule.php?module=secondweapon&owner=".get_module_setting('bowshopowner')."&weap=Bow&ammo=arrow&heshe=".get_module_setting('bowshopsex'));
		}
		if (get_module_setting('crossbowshoploc') == $session['user']['location']){
			tlschema($args['schemas']['marketnav']);
    		addnav($args['marketnav']);
    		tlschema();
			addnav(array("%s's Weapons", get_module_setting('crossbowshopowner')),"runmodule.php?module=secondweapon&owner=".get_module_setting('crossbowshopowner')."&weap=Crossbow&ammo=bolt&heshe=".get_module_setting('crossbowshopsex'));
		}
		if (get_module_setting('slingshoploc') == $session['user']['location']){
			tlschema($args['schemas']['marketnav']);
    		addnav($args['marketnav']);
    		tlschema();
			addnav(array("%s's Weapons", get_module_setting('slingshopowner')),"runmodule.php?module=secondweapon&owner=".get_module_setting('slingshopowner')."&weap=Sling&ammo=stone&heshe=".get_module_setting('slingshopsex'));
		}
		if (get_module_setting('trainloc') == $session['user']['location']){
			tlschema($args['schemas']['marketnav']);
    		addnav($args['marketnav']);
    		tlschema();
			addnav(array("%s's Weapon Training", get_module_setting('trainowner')),"runmodule.php?module=secondweapon&mode=train&owner=".get_module_setting('trainowner')."&heshe=".get_module_setting('trainsex'));
		}
?>