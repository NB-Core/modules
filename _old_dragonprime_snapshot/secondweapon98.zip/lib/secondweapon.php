<?php
	global $session;
	if (is_module_active('altcurrency')) require_once("modules/altcurrency.php");
	$op = httpget('op');
	$weap=httpget('weap');
	$ammo=httpget('ammo');
	$owner=httpget('owner');
	$heshe=httpget('heshe');
	$mode=httpget('mode');
	if ($mode == "train"){
		page_header("%s's Weapon's Training",$owner);
		output("`c`b`&Weapon's Training`0`b`c`n`n");
		if ($op == "go"){
			$session['user']['turns']-=2;
			switch (get_module_pref('weapon')){
				case "Bow":
				$ammo="Arrow";
				break;
				case "Crossbow":
				$ammo="Bolt";
				break;
				case "Sling":
				$ammo="Stone";
				break;
			}
			output("`2%s hands you 10 practice %ss and leads you over to the practice range.`n",$owner,$ammo);
			output("`2You take aim and start.`n"); 
			$gain = 0;
			for ($i=1;$i<11;$i+=1){
				$weapskill = round(get_module_pref('weaponskill')/6);
				if ($weapskill < 1) $weapskill = 1;
				if ($weapskill > 10) $weapskill = 10;
				$success = e_rand($weapskill,10);
				output("`!%s number %s",$ammo,$i);
				switch ($success){
				case 1:
				case 2:
				case 3:
				output(" `5Misses!`n");
				break;
				case 4:
				case 5:
				case 6:
				case 7:
				output("`!hits the `6Outer Zone`n");
				$gain+=1;
				break;
				case 8:
				case 9:
				output("`!hits the `2Inner Zone!`n");
				$gain+=2;
				break;
				case 10:
				output("`!hits the `4Bullseye!`n");
				$gain+=4;
				break;	
				}
			}
			if ($gain < 10){
				switch(e_rand(1,10)){
					case 1:
					output("`7You weren't sober where you?`n");
					break;
					case 2:
					output("`7Too bad they haven't invented eyeglasses yet.`n");
					break;
					case 3:
					output("`7You were aiming at the target right?`n");
					break;
					case 4:
					output("`7Maybe we should find the broad side of a barn, but then you couldn't hit that either.`n");
					break;
					case 5:
					output("`7Don't quit your day job, ok.`n");
					break;
					case 6:
					output("`7Maybe you should open your eyes next time.`n");
					break;
					case 7:
					output("`7Maybe you should take up a different hobby.`n");
					break;
					case 8:
					output("`7Well, if that target were a fierce creature you would be dead by now.`n");
					break;
					case 9:
					output("`7Maybe you should practice more.... Alot more!`n");
					break;
					case 10:
					output("`7You have got to be the worst shot I have ever seen!`n");
					break;
				}
			}elseif ($gain < 20){
				switch(e_rand(1,4)){
					case 1:
					output("`7Maybe some more practice is in order.`n");
					break;
					case 2:
					output("`7I wouldn't try using that in battle.`n");
					break;
					case 3:
					output("`7Well, at least maybe you could hit the broad side of a barn.`n");
					break;
					case 4:
					output("`7You still need alot of trianing Grasshoppa.`n");
					break;
				}
			}elseif ($gain < 30){
				switch(e_rand(1,3)){
					case 1:
					output("`7Not Bad!`n");
					break;
					case 2:
					output("`7Not too Shabby!`n");
					break;
					case 3:
					output("`7Nice Job!`n");
					break;
				}
			}else{
				switch(e_rand(1,2)){
					case 1:
					output("`7Great Shooting!`n");
					break;
					case 2:
					output("`7Excellent!`n");
					break;
				}
			}
			$gain = round($gain/10);
			set_module_pref('weaponskill',get_module_pref('weaponskill') + $gain);
			addnav("Continue","runmodule.php?module=secondweapon&mode=train&owner=$owner&heshe=$heshe");
		}else{
		output("`2%s trains warriors in the fine arts of aiming Bows and Arrows, Crossbows, and Slings.`n",$owner);
		if (get_module_pref('weapon') <> ""){
			output("`2%s can train you how to aim better using your %s.`n",$owner,get_module_pref('weapon'));
			output("`2Training takes 2 turns per session.`n");
			if ($session['user']['turns'] > 1){
				output("`2Would you like to train for 2 turns?`n");
				addnav("Train for 2 turns","runmodule.php?module=secondweapon&mode=train&op=go&owner=$owner&heshe=$heshe");
			}else{
				output("`2You are too tired to train, come back when you have more turns.`n");
			}
		}else{
			output("`2Since you have none of these weapons there is no reason for you to be here.`n");
		}
		}
		villagenav();
		//I cannot make you keep this line here but would appreciate it left in.
		rawoutput("<br><br><br><div style=\"text-align: left;\"><a href=\"http://www.pqcomp.com\" target=\"_blank\">Secondary Weapon by Lonny @ http://www.pqcomp.com</a><br>");
		page_footer();
	}else{
	$usealt = get_module_setting('usealtcurrency');
	if (!is_module_active('altcurrency')){
		$usealt = 0; //do this just in case the altcurrency module is deactived or uninstalled
		set_module_setting('usealtcurrency',0);
	}
	if ($usealt == 1){
		//Bow,Crossbow,Sling
		$shopcurrency = strtolower($weap)."shopcurrency";
		$wcost = strtolower($weap)."cost";
		$acost = strtolower($ammo)."cost";
		$currency = get_module_setting($shopcurrency);
		$weapcost = get_module_setting($wcost);
		$ammocost = get_module_setting($acost);
		$amnthave = altcurrency_checkamt($currency);
	}else{
		$currency = "gems";
		$weapcost = get_module_setting('weapcost');
		$ammocost = 1;
		$amnthave = $session['user']['gems'];
	}
	page_header("%s Shop",$weap);
	output("`c`b`&%s Shop`0`b`c`n`n",$weap);
	if ($op == ""){
	output("`2You look around and see %s standing behind the counter polishing a %s,`n",$owner,$weap);
	output("`2%s looks up at you and flashes you a ",$heshe);
	switch(e_rand(1,13)){
		case 1:
		output("big grin.`n");
		break;
		case 2:
		output("sheepish smile.`n");
		break;
		case 3:
		output("wry grin.`n");
		break;
		case 4:
		output("blank stare.`n");
		break;
		case 5:
		output("dazed look.`n");
		break;
		case 6:
		output("small frown.`n");
		break;
		case 7:
		output("confused look.`n");
		break;
		case 8:
		output("crooked smile.`n");
		break;
		case 9:
		output("dirty look.`n");
		break;
		case 10:
		output("evil glare.`n");
		break;
		case 11:
		output("quick glance.`n");
		break;
		case 12:
		output("harried look.`n");
		break;
		case 13:
		output(", well let's just say %s flashed you.`n",$heshe);
		output("You quickly try to get that awful image out of your head.`n");
		break;
	}
	output("`2%s says, `#\"Welcome to my %s shop.\"`n",$owner,$weap);
	if (get_module_pref('weapon') == $weap){
		output("`#\"I hope that your %s has been working well for you.\"`n",$weap);
		output("`#\"Are you in need of some ammo?\"`n");
		output("`#\"2 %ss cost 1 %s.\"`n",$ammo,$currency);
		if ($amnthave < $ammocost){
			output("`#\"Too bad you can't afford any.\"`n");
		}
	}elseif (get_module_pref('weapon') <> "" and $weap <> get_module_pref('weapon')){
		if ($amnthave >= round($weapcost * .33)){
		output("`#\"I see you can afford one of my fine %s's.\"`n",$weap);
		output("`#\"At %s %s they are a great deal!\"`n",$weapcost,$currency);
		output("\"I also can give you %s %s tradein for your %s.\"`n",round($weapcost * .66),$currency,get_module_pref('weapon'));
		if ($weap == "Bow"){
				$newammo="arrow";
			}elseif($weap == "Crossbow"){
				$newammo="bolt";
			}elseif($weap == "Sling"){
				$newammo="stone";
			}
			if (get_module_pref('weapon') == "Bow"){
				$oldammo="arrow";
			}elseif(get_module_pref('weapon') == "Crossbow"){
				$oldammo="bolt";
			}elseif(get_module_pref('weapon') == "Sling"){
				$oldammo="stone";
			}
		if (get_module_pref('ammo') > 1){
			output("\"I'll even trade your %ss for %ss.\"",$oldammo,$newammo);
		}elseif (get_module_pref('ammo') == 1){
			output("\"I'll even trade your %s for a %s.\"",$oldammo,$newammo);
		}
		}else{
			output("`#\"It's too bad you can't afford one of my fine %s's.\"`n",$weap);
			output("`#\"At %s %s they are a great deal!\"`n",$weapcost,$currency);	
		}
	}else{
	if ($amnthave >= $weapcost){
			output("`#\"I see you can afford one of my fine %s's.\"`n",$weap);
			output("`#\"At %s %s they are a great deal!\"`n",$weapcost,$currency);
		}else{
			output("`#\"It's too bad you can't afford one of my fine %s's.\"`n",$weap);
			output("`#\"At %s %s they are a great deal!\"`n",$weapcost,$currency);	
		}
	}
	if ($tradein > 0 and get_module_pref('weapon') <> $weap and $amnthave >= $weapcost){
		output("`#\"I can give you %s %s for your %s and ammo.\"`n",$tradein,$currency,get_module_setting('weapon'));
	}
	if (get_module_pref('weapon') <> $weap){
		if ($amnthave >= $weapcost or (get_module_pref('weapon') <> "" and $weap <> get_module_pref('weapon') and $amnthave >= round($weapcost * .33))){
			addnav(array("Buy %s",$weap),"runmodule.php?module=secondweapon&op=buyweap&weap=$weap&ammo=$ammo&owner=$owner&heshe=$heshe");
		}
	}else{
		if ($amnthave >= $ammocost and $weap == get_module_pref('weapon')){
			addnav(array("Buy %ss",$ammo),"runmodule.php?module=secondweapon&op=buyammo&weap=$weap&ammo=$ammo&owner=$owner&heshe=$heshe");
		}elseif (($usealt == 1 AND get_module_setting($currency,'altcurrency') >= $ammocost) AND $weap == get_module_pref('weapon')){
			addnav(array("Buy %ss",$ammo),"runmodule.php?module=secondweapon&op=buyammo&weap=$weap&ammo=$ammo&owner=$owner&heshe=$heshe");
		}
	}
	}elseif ($op == "buyweap"){
		if (get_module_pref('weapon') <> ""){
			if ($weap == "Bow"){
				$newammo="arrow";
			}elseif($weap == "Crossbow"){
				$newammo="bolt";
			}elseif($weap == "Sling"){
				$newammo="stone";
			}
			if (get_module_pref('weapon') == "Bow"){
				$oldammo="arrow";
			}elseif(get_module_pref('weapon') == "Crossbow"){
				$oldammo="bolt";
			}elseif(get_module_pref('weapon') == "Sling"){
				$oldammo="stone";
			}
			$tradein="yes";
		}
		if ($tradein == "yes"){
		output("`2%s takes your %s and %s %s and hands you a shiny new %s.",$owner,get_module_pref('weapon'),round($weapcost * .33),$currency,$weap);
		if (get_module_pref('ammo') > 0){
			output("`2%s also takes your %ss and trades for %ss.",$owner,$oldammo,$newammo);
		}
		if ($usealt == 0){
			$session['user']['gems']-=round($weapcost * .33);
		}else{
			altcurrency_adjustdown($currency,round($weapcost * .33));
		}
		set_module_pref('weapon',$weap);
		addnav("Continue","runmodule.php?module=secondweapon&weap=$weap&ammo=$ammo&owner=$owner&heshe=$heshe");
		}else{
			output("`2%s takes your %s %s and hands you a shiny new %s.",$owner,$weapcost,$currency,$weap);
			if ($usealt == 0){
				$session['user']['gems']-=$weapcost;
			}else{
				altcurrency_adjustdown($currency,$weapcost);
			}
			set_module_pref('weapon',$weap);
			addnav("Continue","runmodule.php?module=secondweapon&weap=$weap&ammo=$ammo&owner=$owner&heshe=$heshe");
		}
	}elseif ($op == "buyammo"){
		if (get_module_pref($ammo) < 9){
			output("`2%s takes your %s and hands you 2 %ss, which you quickly place in your pack.",$owner,$currency,$ammo);
			if ($usealt == 0){
				$session['user']['gems']-=$ammocost;
			}else{
				altcurrency_adjustdown($currency,$ammocost);
			}
			set_module_pref('ammo',get_module_pref('ammo')+2);
			addnav("Continue","runmodule.php?module=secondweapon&weap=$weap&ammo=$ammo&owner=$owner&heshe=$heshe");
		}else{
			output("You are already carrying your limit of %s.",$ammo);
			addnav("Continue","runmodule.php?module=secondweapon&weap=$weap&ammo=$ammo&owner=$owner&heshe=$heshe");
		}
	}
	villagenav();
	//I cannot make you keep this line here but would appreciate it left in.
	rawoutput("<br><br><br><div style=\"text-align: left;\"><a href=\"http://www.pqcomp.com\" target=\"_blank\">Secondary Weapon by Lonny @ http://www.pqcomp.com</a><br>");
	page_footer();
}
?>