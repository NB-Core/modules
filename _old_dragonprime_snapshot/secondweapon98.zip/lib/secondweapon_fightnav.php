<?php
		$script = $args['script'];
		$ammo = get_module_pref('ammo');
		if (get_module_pref('weapon') == "Bow" AND $ammo > 0){
			addnav("Second Weapon");
			addnav("`bBow`b","");
			addnav(array("Shoot Arrow! (%s)",$ammo),$script."op=fight&skill=arrow", true);
		}elseif (get_module_pref('weapon') == "Crossbow" AND $ammo > 0){
			addnav("Second Weapon");
			addnav("`bCrossbow`b","");
			addnav(array("Shoot Bolt! (%s)",$ammo),$script."op=fight&skill=bolt", true);
		}elseif (get_module_pref('weapon') == "Sling" AND $ammo > 0){
			addnav("Second Weapon");
			addnav("`bSling`b","");
			addnav(array("Fling Stone! (%s)",$ammo),$script."op=fight&skill=stone", true);
		}
?>