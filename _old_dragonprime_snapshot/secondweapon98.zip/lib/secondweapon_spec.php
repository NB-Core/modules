<?php
$skill = httpget('skill');
		$weaponskill = get_module_pref('weaponskill');
		if ($skill=="arrow"){
			set_module_pref('ammo',get_module_pref('ammo')-1);
				if ($weaponskill > 50 or e_rand(1,50) < $weaponskill){	
				apply_buff('arrow',array(
						 "startmsg"=>"`n`^You fire an Arrow!",
                   		 "name"=>"`%Arrow",
                  		 "rounds"=>1,
                  		 "minioncount"=>1,
                  		 "effectmsg"=>"`)Your Arrow hits {badguy}`) for `^{damage}`) damage.",
			 			 "minbadguydamage"=>$session['user']['level']*3,
                   		 "maxbadguydamage"=>$session['user']['level']*3.9,
                   		 "effectnodmgmsg"=>"`4Your arrow `\$MISSES`)!",
                   		 "activate"=>"offense"
					));
				}else{
					apply_buff('arrow',array(
						 "startmsg"=>"`n`^You fire an Arrow!",
                   		 "name"=>"`%Arrow",
                  		 "rounds"=>1,
                  		 "minioncount"=>1,
                  		 "effectmsg"=>"`)Your Arrow hits {badguy}`) for `^{damage}`) damage.",
			 			 "minbadguydamage"=>$session['user']['level']*0,
                   		 "maxbadguydamage"=>$session['user']['level']*0,
                   		 "effectnodmgmsg"=>"`4Your arrow `\$MISSES`)!",
                   		 "activate"=>"offense"
					));
				}
		}
		if ($skill=="bolt"){
			set_module_pref('ammo',get_module_pref('ammo')-1);
				if ($weaponskill > 50 or e_rand(1,50) < $weaponskill){		
				apply_buff('bolt',array(
						 "startmsg"=>"`n`^You fire a Bolt!",
                   		 "name"=>"`%Bolt",
                  		 "rounds"=>1,
                  		 "minioncount"=>1,
                  		 "effectmsg"=>"`)Your Bolt hits {badguy}`) for `^{damage}`) damage.",
			 			 "minbadguydamage"=>$session['user']['level']*3,
                   		 "maxbadguydamage"=>$session['user']['level']*4,
                   		 "effectnodmgmsg"=>"`4Your bolt `\$MISSES`)!",
                   		 "activate"=>"offense"
					));
				}else{
					apply_buff('bolt',array(
						 "startmsg"=>"`n`^You fire a Bolt!",
                   		 "name"=>"`%Bolt",
                  		 "rounds"=>1,
                  		 "minioncount"=>1,
                  		 "effectmsg"=>"`)Your Bolt hits {badguy}`) for `^{damage}`) damage.",
			 			 "minbadguydamage"=>$session['user']['level']*0,
                   		 "maxbadguydamage"=>$session['user']['level']*0,
                   		 "effectnodmgmsg"=>"`4Your bolt `\$MISSES`)!",
                   		 "activate"=>"offense"
					));
				}
		}
		if ($skill=="stone"){
			set_module_pref('ammo',get_module_pref('ammo')-1);
				if ($weaponskill > 50 or e_rand(1,50) < $weaponskill){	
				apply_buff('stone',array(
						 "startmsg"=>"`n`^You Fling a Stone!",
                   		 "name"=>"`%Stone",
                  		 "rounds"=>1,
                  		 "minioncount"=>1,
                  		 "effectmsg"=>"`)Your Stone hits {badguy}`) for `^{damage}`) damage.",
			 			 "minbadguydamage"=>$session['user']['level']*2.9,
                   		 "maxbadguydamage"=>$session['user']['level']*3.8,
                   		 "effectnodmgmsg"=>"`4Your stone `\$MISSES`)!",
                   		 "activate"=>"offense"
					));
				}else{
					apply_buff('stone',array(
						 "startmsg"=>"`n`^You Fling a Stone!",
                   		 "name"=>"`%Stone",
                  		 "rounds"=>1,
                  		 "minioncount"=>1,
                  		 "effectmsg"=>"`)Your Stone hits {badguy}`) for `^{damage}`) damage.",
			 			 "minbadguydamage"=>$session['user']['level']*0,
                   		 "maxbadguydamage"=>$session['user']['level']*0,
                   		 "effectnodmgmsg"=>"`4Your stone `\$MISSES`)!",
                   		 "activate"=>"offense"
					));
				}
		}
?>