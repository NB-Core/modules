<?php
		if (get_module_pref('weapon') <> ""){
			$weaponammo=get_module_pref('ammo');
			if (get_module_pref('weapon') == "Bow"){
				$weaponammo.=" arrow";
			}elseif(get_module_pref('weapon') == "Crossbow"){
				$weaponammo.=" bolt";
			}elseif(get_module_pref('weapon') == "Sling"){
				$weaponammo.=" stone";
			}
			if (get_module_pref('ammo') <> 1) $weaponammo.="s";
			addcharstat("Equipment Info");
			addcharstat(get_module_pref('weapon'), $weaponammo);
		}
?>