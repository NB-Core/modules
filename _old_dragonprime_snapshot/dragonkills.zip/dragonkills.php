<?php
//Based on goldinbank script by Mike Counts (almost exact =P)
function dragonkills_getmoduleinfo(){
	$info = array(
		"name"=>"DragonKill Display",
		"version"=>"0.2",
		"author"=>"Michael Tartre",
		"category"=>"Stat Display",
		"download"=>"http://dragonprime.net/users/SpiritOfFire/dragonkills.zip",
		"prefs"=>array(
			"Show DragonKills Preferences,title",
			"user_showdks"=>"Do you wish for DKs to be shown,bool|0",
		),
		"settings"=>array(
			"allow_showdks"=>"Allow users to see DragonKills in their stats?,bool|1",
		),
	);
	return $info;
}

function dragonkills_install(){
	module_addhook("charstats");
    return true;
}

function dragonkills_uninstall(){
	return true;
}

function dragonkills_dohook($hookname,$args){
	global $session;
	switch($hookname){
	case "charstats":
		if (get_module_pref("user_showdks") == 1 && get_module_setting('allow_showdks')){
			$title = translate_inline("Personal Info");
 		    $stat = translate_inline("DragonKills");
			$new = $session['user']['dragonkills'];
			setcharstat("Personal Info",$stat,$new);
			break;
		}
	default:
		//nuthing	
	}
}

function dragonkills_run(){

}
?>
