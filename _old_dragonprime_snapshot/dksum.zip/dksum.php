<?php

function dksum_getmoduleinfo(){
	$info = array(
		"name"=>"Dragonkill Sum Display",
		"author"=>"Chris Vorndran<br>Idea by: Robert",
		"category"=>"General",
		"version"=>"1.0",
		"download"=>"http://dragonprime.net/index.php?module=Downloads;sa=dlview;id=73",
		"vertxtloc"=>"http://dragonprime.net/users/Sichae/",
		"description"=>"Shows the sum of the Dragonkills in a realm, and displays them on the Index Page.",
		"settings"=>array(
			"color"=>"Color of Text,enum,`1,Dark Blue,`!,Bright Blue,`2,Dark Green,`@,Bright Green,`3,Dark Cyan,`3,Bright Cyan,`4,Dark Red,`\$,Bright Red,`5,Dark Purple,`%,Bright Purple,`6,Dark Yellow,`^,Bright Yellow,`7,Gray,`),Dark Grey,`&,White,`Q,Orange,`q,Brown|`3",
			"string"=>"String that is displayed,text|Soaring high over {city}, you can see {count} Dragon {type} whipped about in the wind.",
			"Make sure to have the {city} {count} and {type} in that string.,note",
			"type"=>"How are Dks shown?,text|banners",
			"This can be skulls teeth or anything you wish,note",
		),
	);
	return $info;
}
function dksum_install(){
	module_addhook("index");
	return true;
}
function dksum_uninstall(){
	return true;
}
function dksum_dohook($hookname,$args){
	global $session;
	switch ($hookname){
		case "index":
			$sql = "SELECT sum(dragonkills) AS sum FROM ".db_prefix("accounts")."";
			$res = db_query($sql);
			$row = db_fetch_assoc($res);
			$sum = number_format($row['sum']);
			$city = getsetting("villagename", LOCATION_FIELDS);
			$string = get_module_setting("string");
			$a = str_replace("{city}",$city,$string);
			$b = str_replace("{type}",get_module_setting("type"),$a);
			$c = str_replace("{count}",$sum,$b);
			output("`n%s%s`0`n`n",get_module_setting("color"),$c);
			break;
		}
	return $args;
}
?>