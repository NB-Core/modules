<? 
/********************
the Rogue Warrior - one tough cookie!
Written by Robert for Maddnet LoGD
Version 2.0
renamed to Rogue Warrior from Rogue Lonstrider
Written with the help of the guys at DragonPrime
http://dragonprime.cawsquad.net/
*********************/
if (!isset($session)) exit(); 
if ($HTTP_GET_VARS[op]==""){ 
	// Change the name to any you desire
    output("`n`2You encounter `4Rogue Warrior `2in the forest. `n`b Give me your pouch he demands`b. `n"); 
    // Change the story line to suit
    output("`n`2You know by fighting with the `4Rogue Warrior `2you can take his Gold and Gems `&IF `2he has any. `n"); 
    output("`2Then again, losing such a fight will result in a great loss. `n`n `&What will you do?"); 
    addnav("(F) Fight Rogue Warrior","forest.php?op=fight1"); 
    addnav("(R) Run Away","forest.php?op=run"); 
    $session[user][specialinc]="rogue.php"; 
    
}else if ($HTTP_GET_VARS[op]=="fight1"){
        $badguy = array(        "creaturename"=>"Rogue Warrior" 
                                ,"creaturelevel"=>1 
                                ,"creatureweapon"=>"Rogue Sword" 
                                ,"creatureattack"=>2 
                                ,"creaturedefense"=>2 
                                ,"creaturehealth"=>1 
                                ,"diddamage"=>0); 

                                //buff badguy up a little or tone him down
                                $userlevel=$session['user']['level']+3; 
                                $userattack=$session['user']['attack']+e_rand(19,29); 
                                $userhealth=$session['user']['hitpoints']+e_rand(25,40); 
                                $userdefense=$session['user']['defense']+e_rand(29,39); 
                                $badguy[creaturelevel]+=$userlevel; 
                                $badguy[creatureattack]+=$userattack; 
                                $badguy[creaturehealth]=$userhealth; 
                                $badguy[creaturedefense]+=$userdefense; 
                                $session[user][badguy]=createstring($badguy);
        $fight=true;
    }else{
        if ($_GET['op'] == "fight1") {
            $fight=true;
        } elseif ($_GET['op'] == "run") {
	        //change to suit your realm
            $ff = e_rand(2,5); 
            output("`n`^You lose $ff turns for running from this battle!");
            addnav("(R) Run Like a Wimp","forest.php"); 
            $session[user][turns]-=$ff;
            if ($session[user][turns]<=0) $session[user][turns]=0;            
            $fight=false;
        }
    }
    if ($fight){
        include "battle.php";
        $session[user][specialinc]="";
        if ($victory){
            $session[user][specialinc]="";
            $gems = e_rand(2,3);
            $gold = e_rand($session[user][level]*9,$session[user][level]*16);
            $session[user][gems]+=$gems;
            $session[user][gold]+=$gold;
            $session[user][turns]--;
            output("`n`2You have killed the `4Rogue Warrior`2!  `n`^You find in his pouch, he had $gems Gems and $gold gold! `n");
            debuglog ("Win $gold gold and $gems gems Fighting the Rogue Warrior");
            addnav("(R) Return to Forest","forest.php");
            addnews($session[user][name]." `2has killed the `4Rogue Warror `2in the Forest!");
            
        }elseif ($defeat){
	        $session['user']['specialinc']="";
            $session[user][gems]= 0;
            $session[user][gold]= 0;
	        addnews($session[user][name]." `2was killed in the Forest by the `4Rogue Warrior`2.");
            output("`&You have been killed by the `4Rogue Warrior`&! He steals all your `^Gold and Gems`&!");
            debuglog ("Lost all gold and all gems to Rogue LoneStrider");
            addnav("(G) Go to Shades","shades.php");
            }else{
            fightnav();
        } 
 }
?> 