<?php

function villagetokyo_getmoduleinfo(){
        $info = array(
                "name"=>"Village - Tokyo",
                "version"=>"1.0",
                "author"=>"Haku",
                "category"=>"St�dte",
                "download"=>"http://dragonprime.net/users/chicu/villagetokyo.txt",
                "settings"=>array(
                        "Tokyo Settings,title",
                        "villagename"=>"Name der Stadt|Tokyo",
                        "stablename"=>"Name der St�lle|Yueki's St�lle",
                        "allowtravel"=>"Standard' reisen erlauben ?,bool|1",
                ),
                "prefs"=>array(
                        "Tokyo User Einstellungen,title",
                        "allow"=>"User erlaubt hinzureisen?,bool|1",
                ),
        );
        return $info;
}

function villagetokyo_install(){
        module_addhook("villagetext");
     	  module_addhook("stabletext");
        module_addhook("travel");
        module_addhook("validlocation");
        module_addhook("moderate");
        module_addhook("changesetting");
	  module_addhook("stablelocs");
        module_addhook("pvpstart");
        module_addhook("pvpwin");
        module_addhook("pvploss");
        return true;
}

function villagetokyo_uninstall(){
        global $session;
        $vname = getsetting("villagename", LOCATION_FIELDS);
        $gname = get_module_setting("villagename");
        $sql = "UPDATE " . db_prefix("accounts") . " SET location='$vname' WHERE location = '$gname'";
        db_query($sql);
        if ($session['user']['location'] == $gname)
                $session['user']['location'] = $vname;
        return true;
}

function villagetokyo_dohook($hookname,$args){
        global $session,$resline;
        $city = get_module_setting("villagename");
        switch($hookname){
        case "pvpwin":
                if ($session['user']['location'] == $city) {
                        $args['handled']=true;
                        addnews("`4%s`3 besiegt `4%s`3 in einem fairen Kampf in den Feldern von %s.", $session['user']['name'],$args['badguy']['creaturename'], $args['badguy']['location']);
                }
                break;
        case "pvploss":
                if ($session['user']['location'] == $city) {
                        $args['handled']=true;
                        addnews("`%%s`5 wurde bei einem Angriff auf `^%s`5 in den Felder von `&%s besiegt`5.`n%s`0", $session['user']['name'], $args['badguy']['creaturename'], $args['badguy']['location'], $args['taunt']);
                }
                break;
        case "pvpstart":
                if ($session['user']['location'] == $city) {
                        $args['atkmsg'] = "`4Du wanderst durch die Stadttore Tokyo's und siehst eine gro�e Gruppe Krieger die um ein Lagerfeuer sitzen. Etwas weiter weg von diesen, liegen Krieger in den dunklen Feldern und schlafen...`n`nDu hast noch `^%s`4 PvP's f�r heute �brig.`n`n";
                        $args['schemas']['atkmsg'] = 'module-villagetokyo';
                }
                break;
        case "travel":
                $allow = get_module_pref("allow") || get_module_setting("allowtravel");
                $capital = getsetting("villagename", LOCATION_FIELDS);
                $hotkey = substr($city, 0, 1);
                tlschema("module-cities");
                if ($session['user']['location']!=$city && $allow){
                        addnav("More Dangerous Travel");
                        addnav(array("%s?Go to %s", $hotkey, $city),
                                        "runmodule.php?module=cities&op=travel&city=$city&d=1");
                }
                if ($session['user']['superuser'] & SU_EDIT_USERS && $allow){
                        addnav("Superuser");
                        addnav(array("%s?Go to %s", $hotkey, $city),
                                        "runmodule.php?module=cities&op=travel&city=$city&su=1");
                }
                tlschema();
                break;
        case "changesetting":
                if ($args['setting']=="villagename" && $args['module']=="villagetokyo") {
                        if ($session['user']['location'] == $args['old']) {
                                $session['user']['location'] = $args['new'];
                        }
                        $sql = "UPDATE " . db_prefix("accounts") . " SET location='" .
                                $args['new'] . "' WHERE location='" . $args['old'] . "'";
                        db_query($sql);
                }
                break;
        case "validlocation":
                $canvisit = 0;
                if (is_module_active("caravan") &&
                                get_module_setting("canvisit", "caravan"))
                        $canvisit = 1;
                if(get_module_pref("allow") || get_module_setting("allowtravel"))
                        $canvisit = 1;
                if (!$canvisit && (!isset($arg['all']) || !$args['all'])) break;
                if (is_module_active("cities"))
                        $args[$city]="village-villagetokyo";
                break;
        case "moderate":
                if (is_module_active("cities")) {
                        tlschema("commentary");
                        $args["village-villagetokyo"]=sprintf_translate("City of %s", $city);
                        tlschema();
                }
                break;
        case "villagetext":
                if ($session['user']['location'] == $city){
                        $args['text']=array("`&`c`b%s`b`c`n`6Du stehst in mitten Tokyos und betrachtest die Geb�ude und die vielfalt der Bauarten, du siehst die G�rten, die wundervoll gestalltet sind und denkst gleich das du hier leben k�nntest.`n", $city, $city, $deface);
                        $args['schemas']['text'] = "module-villagetokyo";
                        $args['clock']="`n`7Die Uhr der Taverne zeigt dir, es ist `&%s`7.`n";
                        $args['schemas']['clock'] = "module-villagetokyo";
                        if (is_module_active("calendar")) {
                                $args['calendar']="`n`7Eine freundliche Lady sagt dir heute sei der `&%s`7, `&%s %s %s`7.`n";
                                $args['schemas']['calendar'] = "module-villagetokyo";
                        }
                        $args['title']=array("%s, die Stadt des Wohlstands", $city);
                        $args['schemas']['title'] = "module-villagetokyo";
                        $args['sayline']="whispers";
                        $args['schemas']['sayline'] = "module-villagetokyo";
                        $args['talk']="`n`&In der N�he h�rst du ein paar Einwohner Tokyo's reden:`n";
                        $args['schemas']['talk'] = "module-villagetokyo";
                        $args['newest'] = "";
                        $args['schemas']['newest'] = "module-villagetokyo";
                        $args['gatenav']="Tokyo's Tore";
                        $args['schemas']['gatenav'] = "module-villagetokyo";
                        $args['fightnav']="Tokyo's Felder";
                        $args['schemas']['fightnav'] = "module-villagetokyo";
                        $args['marketnav']="J�gergasse";
                        $args['schemas']['marketnav'] = "module-villagetokyo";
                        $args['tavernnav']="Tokyotaverne";
                        $args['schemas']['tavernnav'] = "module-villagetokyo";
                        $args['section']="village-villagetokyo";
                        $args['infonav']="Infostein";
                        $args['schemas']['infonav'] = "module-villagetokyo";
                        unblocknav("stables.php");
                  }
                  break;
        case "stabletext":
		      if ($session['user']['location'] != $city) break;
                  $args['title']=get_module_setting("stablename");
                  $args['schemas']['title'] = "module-villagetokyo";
                  $args['desc'] = "`6Au�erhalb der Stadt hat sich Yueki eine Range erbaut, eine Trainingsarena f�r ihre Tiere.  Viele Leute kommen aus dem ganzen Lande umher um `3Yueki's `6Tiere zu kaufen. Yueki ist eine aufreizende, sehr h�bsche Elfin, die sich sehr gut mit Tieren und vorallem mit W�lfen versteht.  Als du Ihren Laden betrittst, l�chelt dich `3Yueki `6an, "`^Ahh!,wie kann ich dir helfen?`6\", fragt sie mit freundlicher Stimme.";
                  $args['schemas']['desc'] = "module-villagetokyo";
                  $args['lad']="friend";
                  $args['schemas']['lad'] = "module-villagetokyo";
                  $args['lass']="friend";
                  $args['schemas']['lass'] = "module-villagetokyo";
                  $args['nosuchbeast']="`6\"`^Es tut mir leid, Solch ein Tier habe ich leider nicht.`6\", sagt `3Yueki `6etwas ent�uscht.";
                  $args['schemas']['nosuchbeast'] = "module-villagetokyo";
                  $args['finebeast']=array(
                          "`6\"`^Gute Wahl, dies ist eines meiner besten Tiere!`6\" sagt `3Yueki.`n`n",
                          "`6\"`^Nicht einmal Merick hat ein solch feines Tier!`6\" prahlt `3Yueki.`n`n",
                          "`6\"`^Hat dieses nicht eine gute Muskulatur??`6\" fragt sie.`n`n",
                          "`6\"`^Du findest kein besser trainiertes Tier im ganzen Lande!`6\" erkl�rt `3Yueki `6dir stolz.`n`n",
                          "`6\"`^Eigentlich m�sste ich dieses Tier f�r den doppelten Preis verkaufen!`6\" spasst `3Yueki.`n`n",
                          );
                  $args['schemas']['finebeast'] = "module-villagetokyo";
                  $args['toolittle']="`3Yueki `6schaut dein Gold und deine Edelsteine an die du ihr anbietest, \"`^Ich glaube du hast den Preis missverstanden.  Dieser %s kostet dich `&%s `^Gold  und `%%s`^ Edelsteine und nicht dein l�cherliches Kleingeld.`6\"";
                  $args['schemas']['toolittle'] = "module-villagetokyo";
                  $args['replacemount']=" `6Den %s am R�cken streichelnd,�bergiebst du `3 Yueki `6den Preis f�r dieses Tier und sie �bergiebt dir deinen neuen `&%s`6.";
                  $args['schemas']['replacemount'] = "module-villagetokyo";
                  $args['newmount']="`6Du �bergiebst den Preis f�r das Tier und `3Yueki `�bergiebt dir deinen neuen `&%s `6.";
                  $args['schemas']['newmount'] = "module-villagetokyo";
                  $args['nofeed']="`6\"`^Es tut mir schrecklich leid %s, aber ich habe kein Futter hier.  Das hier ist kein Allgemeinstall!  Vieleicht solltest du in einer anderen Stadt nach dem Futter f�r dein Tier suchen.`6\"";
                  $args['schemas']['nofeed'] = "module-villagetokyo";
                  $args['nothungry']="`&%s`6 schaut fl�chtig auf das Futter und ignoriert es. `3Yueki, `6 sch�ttelt den Kopf und giebt dir dein Gold zur�ck.";
                  $args['schemas']['nothungry'] = "module-villagetokyo";
                  $args['halfhungry']="`&%s`6 st�rzt sich auf das Futter und stoppt ca. vor der H�lfte.  \"`^Nunja, %s war nicht so hungirig wie ich dachte.`6\" sagt `3Yueki `6 als sie dir dein Gold, bis auf %s Goldst�cken, wiedergeibt.";
                  $args['schemas']['halfhungry'] = "module-villagetokyo";
                  $args['hungry']="`6%s`6 scheint das Futer regelrecht zu inhalieren.  %s`6, ist jetzt richtig hungrig, und schn�ffelt an `3Yueki's `6 Taschen, f�r mehr Futter.`n `3Yueki `6sch�ttelt ihren Kopf und sammelt nochmal `&%s`6 Gold von dir ein.";
                  $args['schemas']['hungry'] = "module-villagetokyo";
                  $args['mountfull']="`n`6\"`^So %s, dein %s`^ ist jetz vollgefressen.  Komm morgen wieder, wenn es wieder Hunger hat, und ich freue mich, dir mehr verkaufen zu d�rfen.`6\" sagt `3Yueki mit einem s��en l�cheln.";
                  $args['schemas']['mountfull'] = "module-villagetokyo";
                  $args['nofeedgold']="`6\"`^Es tut mir leid, aber du hast nicht genung Gold um das Fuuter f�r dein Tier kaufen zu k�nnen.`6\"  `3Yueki `6dreht dir den R�cken zu und du zeigst deinem %s den Weg nach drau�en, um nach neuem Futter zu suchen.";
                  $args['schemas']['nofeedgold'] = "module-villagetokyo";
                  $args['confirmsale']="`n`n`3Yueki `6 mustert dein Tier sehr g�ndlich.  \"`^Bist du sicher das du dein Tier verkaufen willst?`6\"";
                  $args['schemas']['confirmsale'] = "module-villagetokyo";
                  $args['mountsold']="`6Mit einer Tr�ne �bergiebst du dein %s`6 an `3Yueki's `6Stalljungen.  Die Tr�ne trocknet schnell, und der %s hilft dir schnell wieder dar�ber hinweg zu kommen.";
                  $args['schemas']['mountsold'] = "module-villagetokyo";
                  $args['offer']="`n`n`3Yueki `6streichelt dein Tier fl�chtig und bietet dir `&%s`6 Gold und `%%s`6 Edelsteine f�r deinen %s`6.";
                  $args['schemas']['offer'] = "module-villagetokyo";
                  break;
	  case "stablelocs":
		  tlschema("mounts");
		  $args[$city]=sprintf_translate("The Village of %s", $city);
		  tlschema();
		  break;
          }
          return $args;
}

function villagetokyo_run(){
}
?>