<?
/********************
Mayor's House
Players report game problems to admin here.
Written by Robert for Maddnet LoGD
*********************/
require_once "common.php";

page_header("Mayors House");

addcommentary();
checkday();

output("`c<font size='+1'>`2The Mayor's House</font>`c",true);
output("`n`n `2You walk the path that leads up the Hill, overlooking the Village is the Mayors House.`n");
output(" There is flowerbeds and topiary hedges along the way.`n`n");
output(" Upon entering the Mayor's House you find a place for towns people and Dragon Slayer's`n");
output(" to tell of the trouble's they encounter within the Village or Forest `n");
output(" To your left you see the bulletin board - The Town Scrolls - `n");
output(" Teddy the Troll say's you also can make a *Petition for Help* elsewhere if public viewing is not best.`n");
// Admin will handle all game problems and foward all server related problems to server owner
output(" The Mayor will address serious issues and report major problems to King Squeeky of Maddnet.`n`n");
// place notice of your LoGD forum if you have one:
output(" `#Town Notice: `#The forum for this LoGD is found at:  maddnet.com `n");
// Place notice of most recent events as New Flash - realm specific
output(" `&NEWS FLASH: `&Travellers of the Forest report being robbed by `2Leprechauns `&and `6Dwarves`&.`n");
output("`&NEWS FLASH:  `3Warriors `2in Forest attacked by Hordes of Imps!.`n");
output("`&NEWS FLASH:  `@Green Dragon `2said to be mightier - slayers need to be prepared!.`n`n");
output(" `2A Fairy reminds you please do make out-of-character comments here.");
output("`n`n");
viewcommentary("mayor","Tell the Mayor",12,"whispers");
// need to have both files; mayor.php and townscrolls.php
addnav("(T) Town Scrolls","townscrolls.php");
addnav("(R) Return to Village","village.php");

page_footer();
?>