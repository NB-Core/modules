<?php

function tunneloflove_getmoduleinfo(){
	$info = array(
		"name" => "Tunnel of Love",
		"author" => "`b`&Ka`6laza`&ar`b, Tweaks by DaveS",
		"version" => "1.11",
		"category" => "Amusement Park",
		"download"=>"http://dragonprime.net/index.php?module=Downloads;sa=dlview;id=1041",
		"description" => "Tunnel of Love",
		"settings"=>array(
			"Drop Zone settings,title",
			"name" => "What is the Name of the stall?,text|Tunnel of Love",
			"owner" => "Who runs the ride (female)?,text|`b`%Laurana`b",
			"gold" => "Cost in gold, int|1000",
			),
		"prefs"=>array(
			"Tunnel of Love User Preferences, title",
			"visit"=>"visited Tunnel:,int|0",
			"rand"=>"Has player encountered the random event today?,bool|0",
			"randname"=>"What is the name of the random rider?,text|",
			),
		"requires"=>array(
			"amusementpark" => "Amusement Park by Kalazaar (Amusement Park Package)",
			"parkprizes" => "Park Prizes by Kalazaar (Amusement Park Package)",
		),
	);
	return $info;
}
function tunneloflove_install(){
	module_addhook("amusementpark-street2");
	module_addhook("newday");
	module_addeventhook("amusementpark","return 100;");
	return true;
}
function tunneloflove_uninstall(){
	return true;
}
function tunneloflove_dohook($hookname,$args){
	global $session;
	$name=get_module_setting("name");
	switch($hookname){
		case "amusementpark-street2":
			addnav(array("%s",$name),"runmodule.php?module=tunneloflove&op=tunnel");
		break;
		case "newday":
			if (get_module_pref("rand")==1) module_addeventhook("amusementpark","return 100;");
			set_module_pref("rand",0);
			set_module_pref("visit",0);
		break;
	}
	return $args;
}
function tunneloflove_runevent(){
	global $session;
	$op=httpget('op');
	$owner=get_module_setting("owner");
	$session['user']['specialinc']= "module:tunneloflove";
	if (get_module_pref("entered","parkprizes")==0){
		addnav("Where Will You Go");
		$gold = get_module_setting("parkgold","amusementpark");
		$gems = get_module_setting("parkgem","amusementpark");
		output("`n`@You see a ticket booth with a sign reading:`n");
		output("`n`c`&Tickets for One Day of Entry:`n");
		if ($gold>0) output("`^%s Gold`n",$gold);
		if ($gems>0) output("`%%s Gem%s`n",$gems,translate_inline($gems>1?"s":""));
		if ($gold==0 && $gems==0) output("Free Entrance Today`n");
		output("`c`n`@If you're interested in going in then perhaps you should stop by and purchase a ticket.`n`n");
		output("%s`@ walks over to you and tells you to come visit the Tunnel of Love when you get into the park.`n`n",$owner);
		addnav("Tickets");
		addnav("T?Ticket Booth","runmodule.php?module=amusementpark&op=ticket");
		if (get_module_pref("entered","parkprizes")==0 || get_module_pref("stamped","amusementpark")==1) villagenav();
		else addnav("Leave the Park","runmodule.php?module=amusementpark&op=leave");
		$session['user']['specialinc'] = "";
	}elseif($op=="street1"||$op=="amusementpark" || $op=="street2" || $op=="street3" || $op=="street4"|| $op==""){
		output("`n`@You have been selected to go on a Tunnel of Love Ride!");
		set_module_pref("rand",1);
		module_addeventhook("amusementpark","return 0;");
		addnav("Tunnel of Love","runmodule.php?module=tunneloflove&op=ridefree");
	}
}
function tunneloflove_run(){
	global $session;
	page_header("Tunnel of Love");
	$name=get_module_setting("name");
	$owner=get_module_setting("owner");
	$gold = get_module_setting("gold");
	$hploss=$session['user']['hitpoints']*0.5;
	$marriedto = $session['user']['marriedto'];
	$sql = "SELECT * FROM ".db_prefix ("accounts"). " WHERE acctid = '$marriedto'";
	$res = db_query($sql);
	$row = db_fetch_assoc($res);
	$partner = $row['name'];
	$id = $session['user']['acctid'];
	$sqlr = "SELECT acctid,name FROM ".db_prefix("accounts")." WHERE alive=1 and acctid<>'$id' and acctid<>'$marriedto' ORDER BY rand(".e_rand().") LIMIT 1";
    $resr = db_query($sqlr);
    $rowr = db_fetch_assoc($resr);
    $random = $rowr['name'];
	$op=httpget('op');
	output("`b`c`5Tunnel of  Love`b`c`n");
	if ($op=="tunnel"){
		output("`5You approach %s`5 and the lovely %s `5beckons you onto a ride.",$name,$owner);
		output("`n`nYou notice a sign stating `^%s gold`5 per ride.",$gold);
		addnav(array("%s",$name));
		addnav("Get on the ride","runmodule.php?module=tunneloflove&op=ride");
		addnav("Return to Rides N Stuff", "runmodule.php?module=amusementpark&op=street2");
		addnav("Return to Amusement Park","runmodule.php?module=amusementpark");
	}
	if ($op=="ride"){
		addnav(array("%s",$name));
		if ($session['user']['gold']<$gold){
			output("%s `5smiles sadly at you and asks you to come back when you have `^%s gold`5 for the ride.",$owner,$gold);
			addnav("Return to Rides N Stuff", "runmodule.php?module=amusementpark&op=street2");
			addnav("Return to Amusement Park","runmodule.php?module=amusementpark");
		}elseif (get_module_pref("visit")==1){
			output("%s `5 smiles at you and shakes her finger.  `#'I'm sorry, only one ride per day.'",$owner);
			addnav("Return to Rides N Stuff", "runmodule.php?module=amusementpark&op=street2");
			addnav("Return to Amusement Park","runmodule.php?module=amusementpark");
		}else{
			set_module_pref("visit",1);
			if ($marriedto<>0){
			addnav("Continue","runmodule.php?module=tunneloflove&op=ride2");
			output("%s `5beckons you forward into a boat with your love `^%s`5.",$owner,$partner);
			output_notl("`n`n");
			output("`5You snuggle up together as the boat moves forward through the gates of %s`5.",$name);
			}
			if ($marriedto==0){
			set_module_pref("randname",$random);
			output("%s `5pushes  you forward into a boat with  `^%s`5.",$owner,$random);
			output_notl("`n`n");
			output("`5You snuggle up together as the boat moves forward through the gates of %s`5.",$name);	
			addnav("Continue","runmodule.php?module=tunneloflove&op=freeride2");
			}
		}
	}
	if ($op=="ride2"){
		output("`5Travelling along slowly, there is music playing quietly in the background. The scent of roses surrounds you both, rising from the petals scattered upon the water.");
		output_notl("`n`n");
		output("As the gates close behind you, the light dims, slowly fading through hue's of reds and oranges to pinks, until finally dimming to show a smattering of stars above you.");
		output_notl("`n`n");
		output("The boat slowly rounds a curve and a shower of rose petals falls from above and you cuddle up to %s `5some more",$partner);
		addnav("Continue","runmodule.php?module=tunneloflove&op=ride3");
	}
	if ($op=="ride3"){
		output("`5A second set of gates swings open, allowing your boat to pass through into a sunlit meadow with daffodils and tulips swaying gently in the breeze. Some clouds are moving slowly across the sky above you.");
		output_notl("`n`n");
		output("There's a certain air of Magic about this place. You relax back and steal a few kisses and some more cuddles from your beloved.");
		output_notl("`n`n");
		output("All too soon, your boat winds its way towards the exit gates, slowing down and finally coming to a stop near the lovely %s`5. You and %s`5 thank her for the wonderful experience and leave arm in arm.",$owner,$partner);
		addnav("Return to Rides N Stuff", "runmodule.php?module=amusementpark&op=street2");
		addnav("Return to Amusement Park","runmodule.php?module=amusementpark");
	}
	if ($op=="ridefree"){
		addnav(array("%s",$name));
		set_module_pref("randname",$random);
		output("%s `5pushes  you forward into a boat with `^%s`5.",$owner,$random);
		output_notl("`n`n");
		output("`5You snuggle up together as the boat moves forward through the gates of %s`5.",$name);
		addnav("Continue","runmodule.php?module=tunneloflove&op=freeride2");
		$session['user']['specialinc']="";
	}		
	if ($op=="freeride2"){
		$random=get_module_pref("randname");
		output("`5Travelling along slowly, there is music playing quietly. In the background, the scent of roses surrounds you both, rising from the petals scattered upon the water.");
		output_notl("`n`n");
		output("As the gates close behind you, the light dims, slowly fading through hue's of reds and oranges to pinks, until finally dimming to show a smattering of stars above you.");
		output_notl("`n`n");
		output("The boat slowly rounds a curve and a shower of rose petals falls from above and you scream as you find yourself being cuddled by `^%s`5.",$random);
		addnav("Continue","runmodule.php?module=tunneloflove&op=freeride3");
	}
	if ($op=="freeride3"){
		$random=get_module_pref("randname");
		addnews("%s `5was seen kissing `^%s `5in a boat.",$session['user']['name'],$random);
		output("`5A second set of gates swings open, allowing your boat to pass through into a sunlight meadow. Daffodils and tulips sway gently in the breeze and some clouds are moving slowly across the sky above you.");
		output_notl("`n`n");
		output("There's a certain air of Magic about this place, you turn to find you are now with `^%s `5and try to get away only to find yourself in a deep kiss. You struggle to get free to no avail.",$random);
		output_notl("`n`n");
		output("All too soon, your boat winds its way towards the exit gates, slowing down and finally coming to a stop near the lovely %s`5. You and`^ %s`5 just look at her and each other in stunned silence.",$owner,$random);
		addnav("Return to Rides N Stuff", "runmodule.php?module=amusementpark&op=street2");
		addnav("Return to Amusement Park","runmodule.php?module=amusementpark");
	}
	page_footer();
}
?>