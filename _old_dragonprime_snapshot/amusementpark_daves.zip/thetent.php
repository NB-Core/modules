<?php

function thetent_getmoduleinfo(){
	$info = array(
		"name" => "The Tent",
		"author" => "`b`&Ka`6laza`&ar`b, Tweaks by DaveS",
		"version" => "1.11",
		"category" => "Amusement Park",
		"download"=>"http://dragonprime.net/index.php?module=Downloads;sa=dlview;id=1041",
		"description" => "Tent with Dancing",
		"settings"=>array(
			"The Tent settings,title",
			"name" => "What is the Name of the stall?,text|The Tent",
			"owner" => "Who runs the Tent?,text|`b`&Ka`6laza`&ar`b",
			"gold" => "Cost in gold:,int|200",
			"maxvisit" => "Maximum number of times to try a day:,int|3",
			"malesexy"=>"What is the name of a sexy male character?,text|Adonis",
			"femalesexy"=>"What is the name of a sexy female character?,text|Venus",
		),
		"prefs"=>array(
			"The Tent user preferences, title",
			"visit"=>"Number of times player visited the Tent:,int|0",
			"permhp"=>"Has player received a permanent hitpoint this dk?,bool|0",
		),
		"requires"=>array(
			"amusementpark" => "Amusement Park by Kalazaar (Amusement Park Package)",
			"parkprizes" => "Park Prizes by Kalazaar (Amusement Park Package)",
		),
	);
	return $info;
}
function thetent_install(){
	module_addhook("amusementpark-street1");
	module_addhook("newday");
	module_addhook("dragonkill");
	return true;
}
function thetent_uninstall(){
	return true;
}
function thetent_dohook($hookname,$args){
	global $session;
	$name=get_module_setting("name");
	
	switch($hookname){
		case "amusementpark-street1":
			addnav(array("%s",$name),"runmodule.php?module=thetent&op=thetent");
			break;
		case "newday":
			set_module_pref("visit",0);
			break;
		case "dragonkill":
			set_module_pref("permhp",0);
		break;
	}
	return $args;
}
function thetent_run(){
	global $session;
	page_header("The Tent");
	$name=get_module_setting("name");
	$owner=get_module_setting("owner");
	$gold = get_module_setting("gold");
	$maxvisit = get_module_setting("maxvisit");
	$visit = get_module_pref("visit");
	$op=httpget('op');
	output("`c`b`@The Tent`b`c`n");
	if ($op=="thetent"){
		output("Venturing towards the tent you see %s`@ ushering various people through some curtains. Wondering what's going on, you head on up and ask.",$owner);
		output_notl("`n`n");
		output("%s`@ tells you that there's a dance show behind each curtain and asks if you'd like to pick one for only `^%s gold`@.",$owner,$gold);
		addnav("The Tent");
		addnav("Choose a Curtain", "runmodule.php?module=thetent&op=choosecurtain");
		addnav("Return to Midway", "runmodule.php?module=amusementpark&op=street1");
		addnav("Return to Amusement Park","runmodule.php?module=amusementpark");
	}
	if ($op=="choosecurtain"){
		addnav("The Tent");
		if ($session['user']['gold']<$gold){
			output("%s`@ looks at your empty hand. Feeling somewhat foolish, you turn and leave.",$owner);
			addnav("Return to Midway", "runmodule.php?module=amusementpark&op=street1");
			addnav("Return to Amusement Park","runmodule.php?module=amusementpark");
		}
		if ($visit==$maxvisit){
			output("%s`@ looks at you, smiling in recognition.  Gulping, you realize you may have been here a little too often. In an effort to appear indifferent you decide to leave.",$owner);
			addnav("Return to Midway", "runmodule.php?module=amusementpark&op=street1");
			addnav("Return to Amusement Park","runmodule.php?module=amusementpark");
		}else{
			output("%s`@ collects your `^gold `@ and asks if you're sure that you wish to choose a curtain.",$owner);
			$session['user']['gold']-=$gold;
			increment_module_pref("visit",1);
			addnav("Choose Curtain 1", "runmodule.php?module=thetent&op=curtain&op2=1");
			addnav("Choose Curtain 2", "runmodule.php?module=thetent&op=curtain&op2=2");
			addnav("Choose Curtain 3", "runmodule.php?module=thetent&op=curtain&op2=3");
			addnav("Maybe not", "runmodule.php?module=thetent&op=not");
		}
	}
	if ($op=="not"){
		output("As you turn to leave, you see `b`)Rommel`b`@ and `b`#Cryshalsing`b `@standing near %s`@.`n`n",$name);
		$rand=e_rand(1,10);
		if (get_module_pref("permhp")==0 && $rand==1){
			output("`b`)Rommel`b `@nods to you and congratulates you on a good choice, `b`#Cryshalsing`b`@ smiles and they give you a permanent hitpoint as a reward.");
			$session['user']['maxhitpoints']++;
			set_module_pref("permhp",1);
		}else output("`b`)Rommel`b `@looks at you and laughs about how you just wasted `^%s gold`@. `#'No Refunds!' `@ he yells at you and points you to the exit.",$gold);
		addnav("The Tent");
		addnav("Return to Midway", "runmodule.php?module=amusementpark&op=street1");
		addnav("Return to Amusement Park","runmodule.php?module=amusementpark");
	}
	if ($op=="curtain"){
		$hploss=round($session['user']['hitpoints']*0.05);
		output("%s`@, ushers you through one of the curtains.  The curtain rises!  There before you stands",$owner);
		$curtain=e_rand(1,3);
		if ($curtain == 1){
			if ($session['user']['sex']==1) $sexy=get_module_setting("malesexy");
			else $sexy=get_module_setting("femalesexy");
			output("%s`@!",$sexy);
			output("`n`nA sudden icy blast hits you, and you find yourself frozen to the spot and a very large, very angry `b`#Cryshalsing`b`@ advancing on you.");
			output("You would run, but you apparently are frozen to the spot....");
			$session['user']['charm']+=2;
			$session['user']['hitpoints']-=$hploss;
			$session['user']['turns']--;
			output("`n`nSome considerable time later you defrost, feeling a little more charming from being in the presence of the lovely %s`@, however, you have lost a lot of time today, and you don't feel too good.",$sexy);
		}
		if ($curtain==2 || $curtain==3){
			output("`b`)Rommel`b`@ in a `%Pink Thong`@!");
			output("`n`nPanicking, you try to run out of the tent, only to find that the flap is sealed tight and `b`)Rommel`b`@ is approaching fast.");
			output("`n`nYou find yourself backed up against the tent flap, with `b`)Rommel`b`@ gyrating in front of you singing loudly `%\"DONTCHA YAH WISH YOUR GIRLFRIEND WAS HAWT LIKE ME, DONTCHA\"`@");
			output("`n`n`b`)Rommel`b`@ slowly teases (or is that tortures) you by starting to pull his `%Pink Thong `@ down, you feel really ill as the smell hits you, and start to wish you'd never entered a tent");
			output("`n`nFinally, after an hour of `b`)Rommel`b`@ chasing you round the tent, singing and gyrating, you pass out.  You awaken suddenly to the feel of icy water, and find yourself headfirst in a water trough.");
			if ($session['user']['turns']>1) $session['user']['turns']=1;
			$session['user']['charm']--;
			$session['user']['hitpoints']=1;
		}
		addnav(array("The Tent"));
		addnav("Return to Midway", "runmodule.php?module=amusementpark&op=street1");
		addnav("Return to Amusement Park","runmodule.php?module=amusementpark");
	}
	page_footer();
}
?>
			