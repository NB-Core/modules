<?php  

function parkprizes_getmoduleinfo(){
 	$info = array(
 		"name" => "Amusement Park Prize Stall",
 		"author" => "`b`&Ka`6laza`&ar`b, Tweaks by DaveS",
 		"version" => "1.3",
 		"category" => "Amusement Park",
 		"download"=>"http://dragonprime.net/index.php?module=Downloads;sa=dlview;id=1041",
		"description" => "Claim Prizes",
 		"settings"=>array(
 			"Prize Stall setting, title",
 			"name"=>"Stall name:,text|Prize Stall",
 			"owner"=>"Who runs the Prize Stall?,text|Priestly",
 			"list"=>"How many players listed on the hof?,int|25",
	 		),
 		"prefs"=>array(
 			"Prize Stall preferences,title",
 			"voucher"=>"How many vouchers does the player have left:,int|0",
 			"won"=>"Total prizes bought:,int|0",
 			"canedit"=>"Can the player access the prizes editor?,bool|0",
 			"entered"=>"Has the player entered the park today?,bool|0",
 		),
	);
	return $info;
}

function parkprizes_chance(){
	global $session;
	if (get_module_setting("parkopen","amusementpark")==0) return 0;
	if (get_module_pref('entered','parkprizes',$session['user']['acctid'])==1) return 0;
	else return 100;
}

function parkprizes_install(){
	require_once("lib/tabledescriptor.php");
	$populate = false;
	if (!db_table_exists(db_prefix("parkprizes"))) {
		$populate = true;
	}
	$parkprizes = array(
		'prizeid'=>array('name'=>'prizeid', 'type'=>'int unsigned',	'extra'=>'not null auto_increment'),
		'name'=>array('name'=>'name', 'type'=>'text'),
		'voucher'=>array('name'=>'voucher', 'type'=>'int unsigned',	'extra'=>'not null'),
		'key-PRIMARY'=>array('name'=>'PRIMARY', 'type'=>'primary key',	'unique'=>'1', 'columns'=>'prizeid'));
		synctable(db_prefix('parkprizes'), $parkprizes, true);
		//code copied and modified from Gift Shoppe by JT Traub
		if ($populate) {
			// Create some basic prizes
			$baseprizes = array(
				"INSERT INTO " . db_prefix("parkprizes") . " VALUES (0, '`QStuffed Penguin Small`0', 1)",
				"INSERT INTO " . db_prefix("parkprizes") . " VALUES (0, '`QStuffed Penguin Large`0', 5)",
				"INSERT INTO " . db_prefix("parkprizes") . " VALUES (0, '`qTeddy Bear Small`0', 1)",
				"INSERT INTO " . db_prefix("parkprizes") . " VALUES (0, '`qTeddy Bear Large`0', 5)",
				"INSERT INTO " . db_prefix("parkprizes") . " VALUES (0, '`&Giant Panda`0', 10)"
			);
			while (list($key,$sql)=each($baseprizes)){
				db_query($sql);
			}
		}
		//end of copied code
		module_addhook("amusementpark-street1");
		module_addhook("amusementparkhof-footer");
		module_addhook("superuser");
		module_addeventhook("forest","require_once(\"modules/parkprizes.php\");
			return parkprizes_chance();");
		module_addhook("newday");
	return true;
}
function parkprizes_uninstall(){
	debug("Dropping parkprizes table");
	$sql = "DROP TABLE IF EXISTS " . db_prefix("parkprizes");
	db_query($sql);
	return true; 
} 

function parkprizes_dohook($hookname,$args){
	global $session; 	switch ($hookname){
		case "amusementpark-street1":
			addnav("Prize Stall","runmodule.php?module=parkprizes");
		break;
		//code copied from giftshoppe by JT Traub
		case "superuser":
			if (get_module_pref("canedit")==1) {
				addnav("Module Configurations");
				// Stick the admin=true on so that when we call runmodule it'll
				// work to let us edit supplys even when the module is deactivated.
				addnav("Park Prizes Editor", "runmodule.php?module=parkprizes&op=editor&admin=true");
			}
		break;
		//end of copied code
		case "amusementparkhof-footer":
			addnav("Park Prizes","runmodule.php?module=parkprizes&op=hof");
		break;
		case "newday":
			set_module_pref("entered",0);
		break;
	}
	return $args; 
} 

function parkprizes_runevent(){
	global $session;
	$op=httpget('op');
	$session['user']['specialinc'] = "module:parkprizes";
	page_header("Free Ticket");
	if ($op=="" || $op=="search"){
		output("You have received a free ticket to the Amusement Park for today, and may enter free of charge.");
		set_module_pref("entered",1);
		addnav("Forest","forest.php?");
		$session['user']['specialinc'] = "";
	}
	page_footer(); 
}

function parkprizes_run(){
	global $session;
	$op=httpget('op');
	$owner=get_module_setting("owner");
	$ticket=get_module_pref("voucher");
 	if ($op =="editor"){
		parkprizes_editor();
	}
	if ($op==""){
		page_header("Amusement Park Prizes");
		output("`c`b`@Prize Stall`b`c`n");
		output("`^You look around at all the prizes that line the shelves!`n`n");
		output("`&As you gaze around trying to decide what to pick as your prize the shopkeeper clears his throat as there seems to be queue growing behind you.");
		output_notl("`n`n");
		if ($ticket>0){
			output("You dig around in your pocket and pull out your `@%s voucher%s`&.`n",$ticket,translate_inline($ticket>1?"s":""));
			output("You decide you should hurry up.. What will you choose?`n`n");
		}else output("You dig around in your pocket and find that you don't have any vouchers.  Perhaps you should go to the Midway and play a game or two.`n`n");
		addnav("The Prize Stall");
		$sql = "SELECT * FROM " . db_prefix("parkprizes");
		$res = db_query($sql);
		while($row = db_fetch_assoc($res)) {
			if ($row['gems'] == 1) $str = "gem";
			else $str = "gems";
			$item = $row['prizeid'];
			$sid = translate_inline("");
			$nm = translate_inline("Toy");
			$voucher=translate_inline("Vouchers");
			$choose = translate_inline("Select");
			output_notl("`c");
			rawoutput("<table border=0 cellpadding=2 cellspacing=1 bgcolor='#999999'>");
			rawoutput("<tr class='trhead'>");
			rawoutput("<td>$nm</td><td>$voucher</td>");
			rawoutput("</tr>");
			$sql = "SELECT * FROM " . db_prefix("parkprizes") . " ORDER BY prizeid";
			$res= db_query($sql);
			for ($i=0;$i<db_num_rows($res);$i++){
				$row = db_fetch_assoc($res);
				$item = $row['prizeid'];
				$id = $row['prizeid'];
				$name=$row['name'];
				$voucher=$row['voucher'];
				rawoutput("<tr class='".($i%2?"trlight":"trdark")."'><td>");
				output_notl("<a href='runmodule.php?module=parkprizes&op=choose&item=$item'>$name</a></td><td>",true);
				addnav("","runmodule.php?module=parkprizes&op=choose&item=$item");
				output_notl("<a href='runmodule.php?module=parkprizes&op=choose&item=$item'><center>$voucher</center></a>",true);
				addnav("","runmodule.php?module=parkprizes&op=choose&item=$item");
				rawoutput("</tr>");
			}
			rawoutput("</table>");
			output_notl("`c");
		}
		addnav("Return to Midway", "runmodule.php?module=amusementpark&op=street1");
		addnav("Return to Amusement Park", "runmodule.php?module=amusementpark");
		addnav("Hall of Fame", "runmodule.php?module=amusementpark&op=hof");
		page_footer();
	}
	if ($op == "choose") {
		page_header("Prizes");
		$id = httpget("item");
		output("`c`b`@Prize Stall`&`b`c`n");
		addnav("The Prize Stall");
		addnav("Return to Prizes", "runmodule.php?module=parkprizes");
		addnav("Return to Midway", "runmodule.php?module=amusementpark&op=street1");
		addnav("Return to Amusement Park", "runmodule.php?module=amusementpark");
		$sql = "SELECT * FROM " . db_prefix("parkprizes") . " WHERE prizeid='$id'";
		$row = db_fetch_assoc(db_query($sql));
		$vouchers = get_module_pref("voucher");
		$name = $row['name'];
		if (!$row['prizeid']) {
			output("\"`\$That is ONE of our most popular items! We seem to have run out of stock!  Is there something else you would like?`&\"");
		}elseif ($row['voucher'] > $vouchers) {
			output("`^You realize you don't have the necessary vouchers to purchase a %s`^.`n`n", $row['name']);
			output("The shopkeeper looks at you impatiently and suggests that there might be something a little smaller you would like.");
		}else{
			output("`\$\"Oh what a wonderful choice. Would you like to keep this yourself or send it to a friend?  Enter their name below if you wish to send it.\"");
			addnav("Keep", "runmodule.php?module=parkprizes&op=keep");
			set_module_pref("item",$id);
			rawoutput("<form action='runmodule.php?module=parkprizes&op=checkname' method='POST'>");
			addnav("", "runmodule.php?module=parkprizes&op=checkname");
			output("`^Recipient: ");
			rawoutput("<input name='recip'>");
			rawoutput("<input type='hidden' value='".$row['voucher']."' name='voucher'>");
			rawoutput("<input type='hidden' value='".rawurlencode(addslashes($row['name']))."' name='prize'>");
			rawoutput("<input type='hidden' value='$id' name='prizeid'>");
			$sname = translate_inline("Send Prize To");
			rawoutput("<input type='submit' class='button' value='$sname'>");
			rawoutput("</form>");
		}
		page_footer();
	}
 	if ($op == "checkname") {
		page_header("Prizes");
		addnav("The Prize Stall");
		addnav("Return to Prizes", "runmodule.php?module=parkprizes");
		addnav("Return to Midway", "runmodule.php?module=amusementpark&op=street1");
		addnav("Return to Amusement Park", "runmodule.php?module=amusementpark");
		output("`c`b`@Prize Stall`b`c`n");
		//$item = httpget('id');
		$item = get_module_pref("item");
		$name = stripslashes(rawurldecode(httppost('recip')));
		if (httpget('subfinal')==1){
			$sql = "SELECT acctid,name FROM " . db_prefix("accounts") . " WHERE name='".addslashes($name) . "'";
		}else{
			$search = "%";
			for ($x = 0; $x < strlen($name); $x++) {
				$search .= substr($name, $x,1)."%";
			}
			$sql = "SELECT acctid,name FROM " . db_prefix("accounts") . " WHERE name LIKE '".addslashes($search) . "'";
		}
		$result = db_query($sql);
		$count = db_num_rows($result);
		if ($count == 0) {
			output("`&The Shopkeeper opens a book and looks through it.`n`n");
			output("\"`\$I'm so sorry, but I don't know who you're talking about.  Would you like to try again?`&\"`n`n");
			addnav("Correct error");
			addnav("Re-enter name","runmodule.php?module=parkprizes&op=choose&item=$item");
		}elseif ($count > 100) {
			output("`&The Shopkeeper opens a book and spends quite a bit of time looking through it.`n`n");
			output("\"`\$I'm so sorry, but I don't know who you're talking about.  The name you gave me could be any of %d people. Would you like to try again?`&\"`n`n", $count);
			$item = httppost('id');
			addnav("Correct error");
			addnav("Re-enter name","runmodule.php?module=parkprizes&op=choose&item=$item");
		}elseif ($count > 1) {
			// It matches a small number of people, list them.
			output("`&%s opens a book and spends some time looking through it.`n`n",$owner);
			output("\"`\$I'm sorry, but you could be talking about any of %d people. Can you be more specific?`&\"`n`n", $count);
			rawoutput("<form action='runmodule.php?module=parkprizes&op=checkname&subfinal=1' method='POST'>");
			addnav("", "runmodule.php?module=parkprizes&op=checkname&subfinal=1");
			output("`^Recipient: ");
			rawoutput("<select name='recip'>");
			for ($i = 0; $i < $count; $i++) {
				$row = db_fetch_assoc($result);
				rawoutput("<option value='".rawurlencode(addslashes($row['name']))."'>".full_sanitize($row['name'])."</option>");
			}
			rawoutput("</select>");
			rawoutput("<input type='hidden' value='".httppost('prize')."' name='prize'>");
			rawoutput("<input type='hidden' value='".httppost('voucher')."' name='voucher'>");
			rawoutput("<input type='hidden' value='$item' name='id'>");
			$sname = translate_inline("Send Prize To");
			rawoutput("<input type='submit' class='button' value='$sname'>");
			rawoutput("</form>");
		}else{
			$row = db_fetch_assoc($result);
			// Okay, we've got the name! And exactly one.          	$gift = stripslashes(rawurldecode(httppost('prize')));
			output("`&The Shopkeeper opens a book and looks through it.`n");
			output("`&\"`\$Ahh wonderful!  We'll be happy to send the %s`\$ that you picked out to `&%s`\$. Now, we just need you to enter a note to go along with it.`&\"`n`n", $gift, $row['name']);
			output("He turns the form over and points out the things you still need to enter, and then waits patiently.");
			addnav("Change Recipient","runmodule.php?module=parkprizes&op=choose&item=$item");
			$form = array(
				"note"=>"What should the note say?,textarea,40");
			require_once("lib/showform.php");
			rawoutput("<form action='runmodule.php?module=parkprizes&op=send' method='POST'>");
			addnav("", "runmodule.php?module=parkprizes&op=send");
			rawoutput("<input type='hidden' value='".httppost('prize')."' name='prize'>");
			rawoutput("<input type='hidden' value='".httppost('voucher')."' name='voucher'>");
			$recip = $row['acctid'];
			rawoutput("<input type='hidden' value='$recip' name='recip'>");
			rawoutput("<input type='hidden' value='$item' name='id'>");
			showform($form, array(), true);
			$sname = translate_inline("Send Prize");
			rawoutput("<input type='submit' class='button' value='$sname'>");
			rawoutput("</form>");
		}
		page_footer();
	}
	if ($op == "send"){
		output("`c`b`@Prize Stall`b`c`n");
		page_header("Prizes");
		$cost = httppost("voucher");
		$vouchers=get_module_pref("voucher");
		addnav("The Prize Stall");
		addnav("Return to Prizes", "runmodule.php?module=parkprizes");
		addnav("Return to Midway", "runmodule.php?module=amusementpark&op=street1");
		addnav("Return to Amusement Park", "runmodule.php?module=amusementpark");
		$gname = urldecode(httppost('prize'));
		$mess = httppost("note");
		$name = httppost("recip");
		output("`&The Shopkeeper collects the form with all the information and the %s`& to the back of the shop.",stripslashes($gname));
		output("Then returns a moment later and smiles, \"`\$Okay, it'll get there!`&\"`n`n");
		output("Lastly, he collects the vouchers for the prize.`n");
		$voucherleft = $vouchers-$cost;
		set_module_pref("voucher",$voucherleft);
		$won=get_module_pref("won")+1;
		set_module_pref("won",$won);
		$mailmessage=$session['user']['name'];
		$mailmessage.="`@ has sent you something from The Amusement Park. When you open it you see it is a `6";
		$mailmessage.=$gname;
		$mailmessage.="`@ from The Prize Stall.`n`n";
		if ($mess <> ""){
			if (strchr(strtolower($prize),"card")){
				$mailmessage.="Inside the card it says`# \"";
			}else{
				$mailmessage.="The attached note says`# \"";
			}
			$mailmessage.=$mess;
			$mailmessage.=".\"";
		}
		require_once("lib/systemmail.php");
		systemmail($name,"`^You have received a surprise!`2",$mailmessage);
		page_footer();
	}
	if ($op=="keep"){
		output("`c`b`@Prize Stall`b`c`n");
		page_header("Prizes");
		$won=get_module_pref("won")+1;
		set_module_pref("won",$won);
		$id=get_module_pref("item");
		$sql = "SELECT * FROM " . db_prefix("parkprizes") . " WHERE prizeid='$id'";
		$row = db_fetch_assoc(db_query($sql));
		$cost = $row['voucher'];
		$vouchers=get_module_pref("voucher");
		$voucherleft = $vouchers-$cost;
		set_module_pref("voucher",$voucherleft);
		output("`&The Shopkeeper hands you your Prize, you tuck it under your arm and walk out into the crowds.");
		addnav("The Prize Stall");
		addnav("Return to Prizes", "runmodule.php?module=parkprizes");
		addnav("Return to Midway", "runmodule.php?module=amusementpark&op=street1");
		addnav("Return to Amusement Park", "runmodule.php?module=amusementpark");
		page_footer();
	}
	if ($op=="hof"){
		page_header("Park Prizes Won");
		$acc = db_prefix("accounts");
		$mp = db_prefix("module_userprefs");
		$sql = "SELECT $acc.name AS name,
			$acc.acctid AS acctid,
			$mp.value AS won,
			$mp.userid FROM $mp INNER JOIN $acc
			ON $acc.acctid = $mp.userid
			WHERE $mp.modulename = 'parkprizes'
			AND $mp.setting = 'won'
			AND $mp.value > 0 ORDER BY ($mp.value+0)
			DESC limit ".get_module_setting("list")."";
		$result = db_query($sql);
		$rank = translate_inline("Prizes");
		$name = translate_inline("Name");
		output("`n`b`c`@Number of Prizes Won`n`n`c`b");
		rawoutput("<table border='0' cellpadding='2' cellspacing='1' align='center'>");
		rawoutput("<tr class='trhead'><td align=center>$name</td><td align=center>$rank</td></tr>");
		for ($i=0;$i < db_num_rows($result);$i++){
			$row = db_fetch_assoc($result);
			if ($row['name']==$session['user']['name']){
				rawoutput("<tr class='trhilight'><td>");
			}else{
				rawoutput("<tr class='".($i%2?"trdark":"trlight")."'><td align=left>");
			}
			output_notl("%s",$row['name']);
			rawoutput("</td><td align=right>");
			output_notl("%s",$row['won']);
			rawoutput("</td></tr>");
		}
		rawoutput("</table>");
		addnav("Back to Hall of Fame", "runmodule.php?module=amusementpark&op=hof");
		page_footer();
	}
}
//copied and modified from JT Traubs Gift Shoppe 
function parkprizes_editor(){
global $mostrecentmodule;
page_header("Park Prizes Editor");
require_once("lib/superusernav.php");
superusernav();
addnav("Park Prizes Editor");
addnav("Add a Prize","runmodule.php?module=parkprizes&op=editor&subop=add&admin=true");
$subop = httpget('subop');
$prizeid = httpget('prizeid');
$header = "";
if ($subop != "") {
	addnav("Prizes Editor Main","runmodule.php?module=parkprizes&op=editor&admin=true");
	if ($subop == 'add') {
		$header = translate_inline("Adding a new prize");
	}elseif ($subop == 'edit'){
		$header = translate_inline("Editing a prize");
	}
}else{
	$header = translate_inline("Current Prizes");
}
output_notl("`&<h3>$header`0</h3>", true);
$prizearray=array(
	"prize,title",
	"prizeid"=>"prize ID,hidden",
	"name"=>"prize Name",
	"voucher"=>"Voucher cost,int",
);
if($subop=="del"){
	$sql = "DELETE FROM " . db_prefix("parkprizes") . " WHERE prizeid='$prizeid'";
	db_query($sql);
	$subop = "";
	httpset('subop', "");
}
if($subop=="save"){
	$prizeid = httppost("prizeid");
	list($sql, $keys, $vals) = postparse($prizearray);
	if ($prizeid > 0) {
		$sql = "UPDATE " . db_prefix("parkprizes") . " SET $sql WHERE prizeid='$prizeid'";
	}else{
		$sql = "INSERT INTO " . db_prefix("parkprizes") . " ($keys) VALUES ($vals)";
	}
	db_query($sql);
	if (db_affected_rows()> 0) {
		output("`^prize saved!");
	} else {
		output("`^prize not saved: `\$%s`0", $sql);
	}
	if ($prizeid) {
		$subop = "edit";
		httpset("prizeid", $prizeid, true);
	} else {
		$subop = "";
	}
	httpset('subop', $subop);
}
if ($subop==""){
	$ops = translate_inline("Ops");
	$id = translate_inline("Id");
	$nm = translate_inline("Name");
	$voucher = translate_inline("Voucher Cost");
	$edit = translate_inline("Edit");
	$conf = translate_inline("Are you sure you wish to delete this prize?");
	$del = translate_inline("Del");
	rawoutput("<table border=0 cellpadding=2 cellspacing=1 bgcolor='#999999'>");
	rawoutput("<tr class='trhead'>");
	rawoutput("<td>$ops</td><td>$id</td><td>$nm</td><td>$voucher</td>");
	rawoutput("</tr>");
	$sql = "SELECT * FROM " . db_prefix("parkprizes") . " ORDER BY prizeid";
	$result= db_query($sql);
	for ($i=0;$i<db_num_rows($result);$i++){
		$row = db_fetch_assoc($result);	
		$id = $row['prizeid'];
		rawoutput("<tr class='".($i%2?"trlight":"trdark")."'>");
		rawoutput("<td nowrap>[ <a href='runmodule.php?module=parkprizes&op=editor&subop=edit&prizeid=$id&admin=true'>$edit</a>");
		addnav("","runmodule.php?module=parkprizes&op=editor&subop=edit&prizeid=$id&admin=true");
		rawoutput(" | <a href='runmodule.php?module=parkprizes&op=editor&subop=del&prizeid=$id&admin=true' onClick='return confirm(\"$conf\");'>$del</a> ]</td>");
		addnav("","runmodule.php?module=parkprizes&op=editor&subop=del&prizeid=$id&admin=true");
		output_notl("<td>`^%s</td>`0", $id, true);
		output_notl("<td>`&%s`0</td>", $row['name'], true);
		output_notl("<td>`^%s`0</td>", $row['voucher'], true);
		rawoutput("</tr>");
	}
	rawoutput("</table>");
}
if($subop=="edit"){
	$sql="SELECT * FROM " . db_prefix("parkprizes") . " WHERE prizeid='$prizeid'";
	$result = db_query($sql);
	$row = db_fetch_assoc($result);
}elseif ($subop=="add"){
	$row = array();
	$row['prizeid'] = 0;
}
if ($subop == "edit" || $subop == "add") {
	require_once("lib/showform.php");
	rawoutput("<form action='runmodule.php?module=parkprizes&op=editor&subop=save&admin=true' method='POST'>");
	addnav("","runmodule.php?module=parkprizes&op=editor&subop=save&admin=true");
	showform($prizearray,$row);
	rawoutput("</form>");
}
page_footer();
}
//end of copied code
?>