<?php

function strengthtest_getmoduleinfo(){
	$info = array(
		"name" => "Test Your Strength",
		"author" => "`b`&Ka`6laza`&ar`b, Tweaks by DaveS",
		"version" => "1.11",
		"category" => "Amusement Park",
		"download"=>"http://dragonprime.net/index.php?module=Downloads;sa=dlview;id=1041",
		"description" => "Test Your Strength Booth",
		"settings"=>array(
			"Test Your Strength settings,title",
			"name" => "What is the Name of the stall,text|Test Your Strength",
			"owner" => "Who runs the booth?,text|`b`\$STANG`b",
			"gold" => "Cost in gold, int|1000",
			"hp"=>"Hitpoint multiplier lost/gained by this event:,floatrange,0.02,0.48,0.2|.14",
			"charm"=>"Charm gained/lost by this event:,int|2",
			"gems"=>"Gems gained/lost by this event:,int|2",
			"goldwin"=>"Gold gained/lost by this event:,int|4000",
			"maxvisit" => "Maximum number of times to try a day:,int|3",
			),
		"prefs"=>array(
			"Test Your Strength user preferences, title",
			"visit"=>"visited booth:,int|0",
			"rand"=>"Has player encountered the random event today?,bool|0",
			),
		"requires"=>array(
			"amusementpark" => "Amusement Park by Kalazaar (Amusement Park Package)",
			"parkprizes" => "Park Prizes by Kalazaar (Amusement Park Package)",
		),
	);
	return $info;
}

function strengthtest_install(){
	module_addhook("amusementpark-street1");
	module_addhook("newday");
	module_addeventhook("amusementpark","return 100;");
	return true;
}
function strengthtest_uninstall(){
	return true;
}
function strengthtest_dohook($hookname,$args){
	global $session;
	$name = get_module_setting("name");
	switch ($hookname){
		case "amusementpark-street1";
			addnav(array("%s",$name),"runmodule.php?module=strengthtest&op=strengthtest");
		break;
		case "newday":
			if (get_module_pref("rand")==1) module_addeventhook("amusementpark","return 100;");
			set_module_pref("rand",0);
			set_module_pref("visit",0);
		break;
	}
	return $args;
}
function strengthtest_runevent(){
	global $session;
	$op=httpget('op');
	$session['user']['specialinc']="module:strengthtest";
	$hp=round($session['user']['hitpoints']*get_module_setting("hp"));
	if (get_module_pref("entered","parkprizes")==0){
		addnav("Where Will You Go");
		$gold = get_module_setting("parkgold","amusementpark");
		$gems = get_module_setting("parkgem","amusementpark");
		output("`n`@You see a ticket booth with a sign reading:`n");
		output("`n`c`&Tickets for One Day of Entry:`n");
		if ($gold>0) output("`^%s Gold`n",$gold);
		if ($gems>0) output("`%%s Gem%s`n",$gems,translate_inline($gems>1?"s":""));
		if ($gold==0 && $gems==0) output("Free Entrance Today`n");
		output("`c`n`@If you're interested in going in then perhaps you should stop by and purchase a ticket.`n`n");
		output("%s`@ walks over to you and tells you to come visit the Test of Strength Game at the Midway when you get into the park.`n`n",$owner);
		addnav("Tickets");
		addnav("T?Ticket Booth","runmodule.php?module=amusementpark&op=ticket");
		if (get_module_pref("entered","parkprizes")==0 || get_module_pref("stamped","amusementpark")==1) villagenav();
		else addnav("Leave the Park","runmodule.php?module=amusementpark&op=leave");
		$session['user']['specialinc'] = "";
	}elseif($op=="street1"||$op=="amusementpark" || $op=="street2" || $op=="street3" || $op=="street4"|| $op==""){
		output_notl("`n`@");
		switch (e_rand(1,2)){
			case 1:
			output("You pick up a prize voucher someone has lost.");
			increment_module_pref("voucher",1,"parkprizes");
			break;
			case 2:
			if (get_module_pref("voucher","parkprizes")<>0){
				output("You trip over and loose a prize voucher.");
				increment_module_pref("voucher",-1,"parkprizes");
			}else{
				output("You trip over a weight, you think may have come from the Test Your Strength Stand in the Midway.");
				$session['user']['hitpoints']-=$hp;
				if ($hp>0) output("`n`n`@You `\$lose %s hitpoint%s`@!",$hp,translate_inline($hp>1?"s":""));
				else output("`n`n`@Luckily it doesn't hurt you.");
			}
			break;
		}
		set_module_pref("rand",1);
		module_addeventhook("amusementpark","return 0;");
		addnav("Return to Amusement Park","runmodule.php?module=amusementpark");
	}
	$session['user']['specialinc'] = "";
}	
			
function strengthtest_run(){
	global $session;
	page_header("Test Your Strength");
	$name = get_module_setting("name");
	$visit = get_module_pref("visit");
	$owner = get_module_setting("owner");
	$gold = get_module_setting("gold");
	$maxvisit = get_module_setting("maxvisit");
	$op = httpget('op');
	output("`Q`c`bTest of Strength`b`c`n");
	if ($op=="strengthtest"){
		output("`QWandering around you spot the %s. `QThinking this looks like fun, you walk up to the booth. Standing slightly to one side is the local Toughman, %s`Q.",$name,$owner);
		output_notl("`n`n");
		output("`QYou notice a sign that issues the challenge:  `n`n`c`#Wager `^%s gold`# for a chance to beat %s`n`#Maximum %s tries per day`n`c`n`Q",$gold,$owner,get_module_setting("maxvisit"));
		output("`^\"So you THINK `%PUNY `^you can beat ME?\" `Qhe says. You mumble your response...");
		addnav(array("%s",$name));
		addnav("Yeah I do", "runmodule.php?module=strengthtest&op=tryit");
		addnav("Ummm Nope", "runmodule.php?module=amusementpark");
	}
	if ($op=="tryit"){
		if ($session['user']['gold']<$gold){
			output("%s `QLooks at you like you're nuts. Realizing you don't have the `^%s gold `Qon you, you back away.",$owner,$gold);
			addnav(array("%s",$name));
			addnav("Run!!", "runmodule.php?module=amusementpark");
		}
		if ($visit==$maxvisit){
			output("%s `QHefts the hammer in his hands and cracks you fair on the head with it. `^\"Don't you think you've been here enough today?\"",$owner);
			if ($session['user']['turns']>1){
				$session['user']['turns']=1;
			}
			addnews("%s `#was knocked out at the Amusement Park",$session['user']['name']);
			addnav(array("%s",$name));
			addnav("Return to Midway", "runmodule.php?module=amusementpark&op=street1");
			addnav("Return to Amusement Park","runmodule.php?module=amusementpark");
		}else{
			output("%s`Q takes your gold and tosses you the hammer. `^\"Can you even LIFT the hammer?\"`Q he says to you and watches as you attempt to catch the hammer.",$owner);
			output_notl("`n`n");
			$session['user']['gold']-=$gold;
			$charm=get_module_setting("charm");
			$gems=get_module_setting("gems");
			$hp=round($session['user']['hitpoints']*get_module_setting("hp"));
			$visitnew=get_module_pref("visit")+1;
			set_module_pref("visit",$visitnew);
			$swingtry = (e_rand(1,10));
			if ($swingtry==1){
				output("You swing the hammer right over your head and topple over backwards, looking quite silly.");
				output("`n`n`QYou `&lose %s charm`Q.",$charm);
				$session['user']['charm']-=$charm;
			}
			if ($swingtry==2){
				output("You swing the hammer and bring it down hard, just off center and watch it glance off your foot. %s `Qlaughs at you.",$owner);
				$session['user']['hitpoints']-=$hp;
				if ($hp>0) output("`n`n`QYou `\$lose %s hitpoint%s`Q!",$hp,translate_inline($hp>1?"s":""));
				else output("`n`n`QLuckily it doesn't hurt you.");
			}
			if ($swingtry==3){
				output("You swing the hammer hard, and hit the plate dead centre. You've WON!!");
				$session['user']['gold']+=get_module_setting("goldwin");
				$session['user']['gems']+=$gems;
				$session['user']['turns']+3;
				output("`n`nYou win `^%s gold`Q, `%%s gem%s`Q, and `@3 turns`Q!",get_module_setting("goldwin"),$gems,translate_inline($gems>1?"s":""));
				addnews("%s, `#won the Test of Strength at the Amusement Park!!!",$session['user']['name']);
			}
			if ($swingtry==10){
				output("You bring the hammer crashing down and the little weight zooms straight off and up into the air. For your great effort you are awarded a Prize Voucher, redeemable at the Prize Stall.");
				addnav("Go to Prize Stall Now","runmodulephp?module=parkprizes","parkprizes");
				increment_module_pref("voucher",1,"parkprizes");
			}
			if ($swingtry==4 || $swingtry==5 || $swingtry==6 || $swingtry==7 || $swingtry==9){
				output("`QYou drop the hammer. %s `Qlooks at you. `^\"Nope, you couldn't even lift it.\"",$owner);
			}
			if ($swingtry==8){
				output("You drop the hammer straight on %s's `Qfoot. You laugh so hard you can barely run away.",$owner);
				output("`n`n`@You `&gain %s charm`@.",$charm);
				$session['user']['charm']+=$charm;
			}
			addnav(array("%s",$name));
			if (get_module_pref("visit")<get_module_setting("maxvisit")) addnav("Play Again","runmodule.php?module=strengthtest&op=strengthtest"); 
			addnav("Return to Midway", "runmodule.php?module=amusementpark&op=street1");
			addnav("Return to Amusement Park","runmodule.php?module=amusementpark");
		}
	}
	page_footer();
}
?>
			
	