<?php

function whackadragon_getmoduleinfo(){
	$info = array(
		"name" => "Whack a Dragon",
		"author" => "`b`&Ka`6laza`&ar`b`# from an idea by Amon, Tweaks by DaveS",
		"version" => "1.11",
		"category" => "Amusement Park",
		"download"=>"http://dragonprime.net/index.php?module=Downloads;sa=dlview;id=1041",
		"settings"=>array(
			"Whack a Dragon setting, title",
			"name"=>"Stall name:,text|Whack A Dragon",
			"list"=>"How many players on the HoF:,int|25",
			"owner"=>"Who runs the stall (female)?,int|`b`6Ka`4l`)az`4a`6ar`b",
			"gold"=>"Gold to play:,int|1000",
			"gems"=>"Gems to play:,int|0",
		),
		"prefs"=>array(
			"Whack a Dragon Preferences,title",
			"highscore"=>"Player's high score:,int|0",
			"score"=>"Score this round:,int|0",
			"rand"=>"Has player encountered the random event today?,bool|0",
		),
		"requires"=>array(
			"amusementpark" => "Amusement Park by Kalazaar (Amusement Park Package)",
			"parkprizes" => "Park Prizes by Kalazaar (Amusement Park Package)",
		),
	);
	return $info;
}
function whackadragon_install(){
	module_addhook("amusementpark-street1");
	module_addhook("amusementparkhof-header");
	module_addhook("newday");
	module_addeventhook("amusementpark","return 50;");
	return true;
}
function whackadragon_uninstall(){
	return true;
}
function whackadragon_dohook($hookname,$args){
	global $session;
	$name = get_module_setting("name");
	$op=httpget('op');
	switch($hookname){
		case "amusementpark-street1":
			addnav(array("%s",$name),"runmodule.php?module=whackadragon&op=enter");
			break;
		case "amusementparkhof-header":
			addnav("Whack A Dragon", "runmodule.php?module=whackadragon&op=hof");
			break;
		case "newday":
			if (get_module_pref("rand")==1) {
				module_addeventhook("amusementpark","return 50;");
				set_module_pref("rand",0);
			}
		break;
	}
	return $args;
}
function whackadragon_runevent(){
	global $session;
	$op==httpget('op');
	$owner = get_module_setting("owner");
	$session['user']['specialinc'] = "module:whackadragon";	
	if (get_module_pref("entered","parkprizes")==0){
		addnav("Where Will You Go");
		$gold = get_module_setting("parkgold","amusementpark");
		$gems = get_module_setting("parkgem","amusementpark");
		output("`n`@You see a ticket booth with a sign reading:`n");
		output("`n`c`&Tickets for One Day of Entry:`n");
		if ($gold>0) output("`^%s Gold`n",$gold);
		if ($gems>0) output("`%%s Gem%s`n",$gems,translate_inline($gems>1?"s":""));
		if ($gold==0 && $gems==0) output("Free Entrance Today`n");
		output("`c`n`@If you're interested in going in then perhaps you should stop by and purchase a ticket.`n`n");
		output("%s`@ walks over to you and tells you to come visit the Whack-a-Dragon Game at the Midway when you get into the park.`n`n",$owner);
		addnav("Tickets");
		addnav("T?Ticket Booth","runmodule.php?module=amusementpark&op=ticket");
		if (get_module_pref("entered","parkprizes")==0 || get_module_pref("stamped","amusementpark")==1) villagenav();
		else addnav("Leave the Park","runmodule.php?module=amusementpark&op=leave");
		$session['user']['specialinc'] = "";
	}elseif($op=="street1"||$op=="amusementpark" || $op=="street2" || $op=="street3" || $op=="street4" || $op==""){
		output("`n`@Nothing much happens.");
		module_addeventhook("amusementpark","return 0;");
		set_module_pref("rand",1);
		addnav("Return to Amusement Park","runmodule.php?module=amusementpark");
		$session['user']['specialinc']="";
	}
}
function whackadragon_run(){
	global $session;
	$op=httpget('op');
	$name = get_module_setting("name");
	$owner = get_module_setting("owner");
	$gold = get_module_setting("gold");
	$gems = get_module_setting("gems");
	if ($op=="enter"){
		page_header("Whack A Dragon");
		output("`c`b`@Whack A Dragon`b`c`n");
		addnav("Whack A Dragon");
		addnav("Play","runmodule.php?module=whackadragon&op=play");
		addnav("View HoF", "runmodule.php?module=whackadragon&op=hof");
		addnav("Return to Midway", "runmodule.php?module=amusementpark&op=street1");		addnav("Return to Amusement Park","runmodule.php?module=amusementpark");
		if (get_module_pref("stamped","amusementpark")==1) villagenav();
		else addnav("Leave the Park","runmodule.php?module=amusementpark&op=leave");
		output("You enter %s`@. %s `@greets you.  `@\"Can you Whack-A-Dragon better than anyone else?",$name,$owner);
		if ($gold>0 || $gems>0){
			output("It costs");
			if ($gold>0) output("`^%s gold`@",$gold);
			if ($gold>0&&$gems>0) output("and");
			if ($gems>0) output("`%%s gem%s`@",$gems,translate_inline($gems>1?"s":""));
			output("to play.\"");
		}
		if ($gold==0 && $gems==0) output("Lucky you... You get to play for free today.\"`@");
		output_notl("`n`n");
		output("`@\"Oh yeah, did I mention we have a Hall of Fame? The highest scorers get to have their names up in lights, so to speak. So what do you want to do? Play, or just stand there looking round?\"");
	}
	if ($op=="play"){
		page_header("Whack A Dragon");
		output("`c`b`@Whack A Dragon`b`c`n");
		$hs = get_module_pref("highscore");
		$sc = get_module_pref("score");
		if ($hs<$sc){
			set_module_pref("highscore",$sc);
		}
		addnav(array("%s",$name));
		set_module_pref("score",0);
		if ($session['user']['gold']<$gold || $session['user']['gems']<$gems){
			output("%s`@ just looks you up and down a moment. `^\"What, you think thin air is gonna buy ya a shot here? Nuh uh! Now vamoose, and don't come back til you have enough to pay to play.\"",$owner);
			addnav("Return to Amusement Park","runmodule.php?module=amusementpark");
		}
		if ($session['user']['gold']>=$gold && $session['user']['gems']>=$gems){
			output("%s`@ takes the game charges off your hand and passes you a hammer.  She pushes you in the direction of the %s`@ with the admonishment `^\"Be Careful what you whack in there!\"",$owner,$name);
			addnav("Continue","runmodule.php?module=whackadragon&op=continue");
			$session['user']['gold']-=$gold;
			$session['user']['gems']-=$gems;
		}
	}
if ($op=="continue"){
	page_header("Play");
	output("`c`b`@Whack A Dragon`b`c`n");
	addnav(array("%s",$name));
	$hit=e_rand(1,60);
	switch($hit){
		case 1: //miss
		case 4:
		case 8:
		case 12:
		case 14:
		case 26:
		case 29:
		output("You miss the dragon.");
		addnav("Continue","runmodule.php?module=whackadragon&op=continue");
		break;
		case 31: // game over
		case 33:
		case 39:
		case 42:
		case 47:
		output("You miss the dragon. Oh no! Your game is over.");
		addnav("Score","runmodule.php?module=whackadragon&op=score");
		break;
		case 2: //hit
		case 7:
		case 16:
		case 22:
		case 30:
		case 32:
		case 34:
		case 35:
		case 36:
		case 37:
		case 41:
		case 45:
		case 46:
		case 48:
		case 49:
		case 50:
		case 51:
		case 52:
		case 53:
		case 54:
		case 55:
		case 56:
		case 57:
		case 58:
		case 59:
		case 60:
		case 19:
		case 20:
		case 23:
		case 24:
		case 9:
		case 10:
		case 11:
		case 15:
		case 17:
		case 25:
		case 27:
		output("You hit the pesky Green Dragon. You've scored a point.");
		addnav("Continue","runmodule.php?module=whackadragon&op=continue");
		increment_module_pref("score",+1);
		break;
		case 3: // near miss
		case 5:
		case 6:		
		case 28:
		case 40:
		case 43:
		case 44:
		output("You almost hit the dragon. In fact, you are quite sure it dodged!");
		addnav("Continue","runmodule.php?module=whackadragon&op=continue");
		break;
		case 13: //hit Crysh
		case 18:		
		output("Uh oh, you've hit our resident Silver Dragon, `b`#Cryshalsing`b`@. I think you're lunch... GAME OVER!!");
		addnav("Score","runmodule.php?module=whackadragon&op=score");
		break;
		case 21: // hit Rommel
		case 38:		
		output("Oh Crap, that wasn't even a dragon! That was what is now a Very ANGRY and Very MAD `b`)Rommel`b`@. I think you'd better run!!... GAME OVER!!");
		addnav("Score","runmodule.php?module=whackadragon&op=score");
		break;
	}
}
if ($op=="score"){
	page_header("Your Score");
	$hs = get_module_pref("highscore");
	$sc = get_module_pref("score");
	$vcr = round($sc*0.25);
	increment_module_pref("voucher",+$vcr,"parkprizes");
	output("`c`b`@Whack A Dragon`b`c`n");
	if ($sc<>0){
		
	if ($hs<$sc){
		output("%s`@ congratulates you. You've passed your previous highscore of `^%s`@ and achieved a score of `^%s`@.",$owner,$hs,$sc);
		output_notl("`n`n");
	}
	if ($hs>=$sc){
		output("%s`@ congratulates you on your score of `^%s`@. Unfortunately you haven't passed your highscore of `^%s`@.",$owner,$sc,$hs);
		output_notl("`n`n");
	}
	if ($vcr==0){
		output("Sorry, you haven't won any vouchers.");
	}
	if($vcr<>0){
		output("You've won `^%s voucher%s`@, redeemable at our prize stall.",$vcr,translate_inline($vcr>1?"s":""));
	}
	}
	if ($sc==0){
		output("Unfortunately you failed to score anything.");
	}
	addnav(array("%s",$name));
	addnav("Play again", "runmodule.php?module=whackadragon&op=play");
	addnav("Hall of Fame","runmodule.php?module=whackadragon&op=hof");
	addnav("Return to Midway", "runmodule.php?module=amusementpark&op=street1");
	addnav("Return to Amusement Park","runmodule.php?module=amusementpark");
	if (get_module_pref("stamped","amusementpark")==1) villagenav();
	else addnav("Leave the Park","runmodule.php?module=amusementpark&op=leave");
}
if ($op=="hof"){
	page_header("Whack a Dragon");
	$hs = get_module_pref("highscore");
	$sc = get_module_pref("score");
	if ($hs<$sc){
		set_module_pref("highscore",$sc);
	}
	$acc = db_prefix("accounts");
	$mp = db_prefix("module_userprefs");
	$sql = "SELECT $acc.name AS name,
	$acc.acctid AS acctid,
	$mp.value AS highscore,
	$mp.userid FROM $mp INNER JOIN $acc
	ON $acc.acctid = $mp.userid 
	WHERE $mp.modulename = 'whackadragon' 
	AND $mp.setting = 'highscore' 
	AND $mp.value > 0 ORDER BY ($mp.value+0)	
	DESC limit ".get_module_setting("list")."";
	$result = db_query($sql);
	$rank = translate_inline("High Score");
	$name = translate_inline("Name");
	$none = translate_inline("No Winners Yet");
	output("`n`b`c`%Whack A Dragon High Scores`n`n`c`b");
	rawoutput("<table border='0' cellpadding='2' cellspacing='1' align='center'>");
	rawoutput("<tr class='trhead'><td align=center>$name</td><td align=center>$rank</td></tr>");
	if (db_num_rows($result)==0) output_notl("<tr class='trlight'><td colspan='2' align='center'>`&$none`0</td></tr>",true);
	else{
		for ($i=0;$i < db_num_rows($result);$i++){ 
		$row = db_fetch_assoc($result);
		if ($row['name']==$session['user']['name']){
			rawoutput("<tr class='trhilight'><td>");
		}else{
			rawoutput("<tr class='".($i%2?"trdark":"trlight")."'><td align=left>");
		}
		output_notl("%s",$row['name']);
		rawoutput("</td><td align=right>");
		output_notl("%s",$row['highscore']);
		rawoutput("</td></tr>");
	}
}
rawoutput("</table>");
addnav("Hall of Fame");
addnav("Back to Hall of Fame", "runmodule.php?module=amusementpark&op=hof");
addnav("Return to Whack A Dragon", "runmodule.php?module=whackadragon&op=enter");
addnav("Return to Midway", "runmodule.php?module=amusementpark&op=street1");addnav("Return to Amusement Park","runmodule.php?module=amusementpark");
if (get_module_pref("stamped","amusementpark")==1) villagenav();
else addnav("Leave the Park","runmodule.php?module=amusementpark&op=leave");
}
page_footer();
}