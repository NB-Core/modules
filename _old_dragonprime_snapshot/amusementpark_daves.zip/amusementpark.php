<?php 
function amusementpark_getmoduleinfo(){
	$info = array(
		"name" => "Amusement Park",
		"author" => "`b`&Ka`6laza`&ar`b modularized by sixf00t4, debugged by DaveS",
		"version" => "1.11",
		"download"=>"http://dragonprime.net/index.php?module=Downloads;sa=dlview;id=1041",
		"category" => "Amusement Park",
		"description" => "Amusement Park",
		"settings"=>array(
			"Amusement Park Setup,title",
			"parkopen"=>"Is Park open?,bool",
			"oneloc"=>"Only show the link in one location?,bool",
			"loc"=>"If one location - Where does it appear?,location|".getsetting("villagename", LOCATION_FIELDS),
			"parkname"=>"Park Name,text|`b`^T`6he `^A`6musement `^P`6ark`b",
			"ticketname"=>"What is the name of the ticket seller?,text|Laurana",
			"ticketsex"=>"What is the sex of the ticket seller?,enum,0,Male,1,Female|1",
			"parkgold"=>"Gold to enter Park,int|1000",
			"parkgem"=>"Gems to enter Park,int|1",
			"parkchance"=>"What is the chance of an event?,range,0,100,1|10",
			),
		"prefs"=>array(
			"stamped"=>"Did the player get their hand stamped for the day?,bool|0",
			),
		);
	return $info;
}

function amusementpark_install(){
	module_addhook("village");
	module_addhook("newday");
	return true;
}

function amusementpark_uninstall(){
	return true;
}
function amusementpark_dohook($hookname,$args){
	global $session;
	$name = get_module_setting("name");
	switch ($hookname){
		case "village":
			if (get_module_setting("parkopen") && (($session['user']['location'] == get_module_setting("loc") && get_module_setting("oneloc")==1) || get_module_setting("oneloc")==0)) {
				tlschema($args['schemas']['marketnav']);
				addnav($args['marketnav']);
				tlschema();
				$name = get_module_setting("parkname");
				addnav(array("%s",$name),"runmodule.php?module=amusementpark&op2=stamp");
			}
		break;
		case "newday":
			if (get_module_pref("stamped")==1){
				output("`n`@You wash your hand and the amusement park stamp washes off.`n");
				set_module_pref("stamped",0);
			}
		break;
	}
	return $args;
}

function amusementpark_run(){
require_once("lib/events.php");
global $session;
tlschema('amusementpark'); 	
$origtexts = array(
	"text"=>$basetext,
	"talk"=>"`n`%`@Nearby some others talk:`n",
	"sayline"=>"says",
	"allnav"=>"Where Will You Go",
	"section"=>"amusementpark",
);
$schemas = array(
	"text"=>"amusementpark",
	"talk"=>"amusementpark",
	"sayline"=>"amusementpark",
	"allnav"=>"amusementpark",
	"section"=>"amusementpark",
);
$gold = get_module_setting("parkgold");
$gems = get_module_setting("parkgem");
$origtexts['schemas'] = $schemas;
$texts = modulehook("parktext",$origtexts);
$name = get_module_setting("parkname");
$header= color_sanitize($name);
page_header("%s",$header);
$sex=get_module_setting("ticketsex");
$skipamusementparkdesc=handle_event("amusementpark"); 
if (module_events("amusementpark", get_module_setting("parkchance")) != 0) {
	if (checknavs()) {
		page_footer();
	}else{
		$session['user']['specialinc'] = "";
		$session['user']['specialmisc'] = "";
		$skipamusementparkdesc=true;
		$op = "";
		httpset("op", "");
	}
}
if ($session['user']['alive']<1) redirect("shades.php");
$op = httpget('op');
$op2 = httpget('op2');
if (get_module_pref("entered","parkprizes")==0 && $op!="ticket"){
	output("`@`b`cThe Main Gate`c`b");
	output("`n`@You see a ticket booth with a sign reading:`n");
	output("`n`c`&Tickets for One Day of Entry:`n");
	if ($gold>0) output("`^%s Gold`n",$gold);
	if ($gems>0) output("`%%s Gem%s`n",$gems,translate_inline($gems>1?"s":""));
	if ($gold==0 && $gems==0) output("Free Entrance Today`n");
	output("`c`n`@If you're interested in going in then perhaps you should stop by and purchase a ticket.`n`n");
	tlschema($schemas['ticketnav']);
	addnav($texts['ticketnav']);
	tlschema();
	addnav("Tickets");
	addnav("T?Ticket Booth","runmodule.php?module=amusementpark&op=ticket");
}
if (!$skipamusementparkdesc){
	if (get_module_pref("entered","parkprizes")==1){
		tlschema($schemas['allnav']);
		addnav($texts['allnav']);
		tlschema();
		addnav("Midway","runmodule.php?module=amusementpark&op=street1");
		addnav("Rides N Stuff","runmodule.php?module=amusementpark&op=street2");
		addnav("Refreshments","runmodule.php?module=amusementpark&op=street3");
		modulehook("amusementpark-footer");
		addnav("Hall of Fame","runmodule.php?module=amusementpark&op=hof");
		tlschema('nav');
	}
	$runby = get_module_setting("ticketname");
	if ($op=="ticket"){
		output("`b`c%s`b`c`0",$name);
		output_notl("`n");
		addnav("Where Will You Go");
		if ($gold==0 && $gems==0){
			output("%s`@ tells you that the park is free today and hands you an entry ticket, gesturing towards the Park. `#\"Have Fun!\"",$runby);
			blocknav("runmodule.php?module=amusementpark&op=ticket");	
			set_module_pref("entered",1,"parkprizes");
			addnav("Amusement Park","runmodule.php?module=amusementpark");
		}elseif ($session['user']['gold']==0 && $session['user']['gems']==0){
			if (e_rand(1,40)==1){
				output("%s`@ looks at you and has a sudden wave of pity at your poverty. She hands you an entry ticket, gesturing towards the Park. `#\"Don't tell anyone I gave you that. Have Fun!\"",$runby);
				blocknav("runmodule.php?module=amusementpark&op=ticket");
				set_module_pref("entered",1,"parkprizes");
				addnav("Amusement Park","runmodule.php?module=amusementpark");
			}else output("%s`@ tells you that you'll need to have something more than pocket lint to get into the park today.",$runby);
		}elseif ($session['user']['gold']<$gold || $session['user']['gems']<$gems){
			output("`@Looking at your outstretched hand, %s`@ suggests you come back when you have",$runby);
			if ($session['user']['gold']<$gold) output("`^%s gold`@",$gold);
			if ($session['user']['gold']<$gold && $session['user']['gems']<$gems) output("and");
			if ($session['user']['gems']<$gems) output("`%%s gem`%`@",$gems,translate_inline($gems>1?"s":""));
			output("to get in."); 	
		}else{
			output("%s`@ takes your `^%s gold `@and `%%s gem%s`@ and hands you an entry ticket. %se gestures towards the Park, `#\"Have Fun!\"",$runby,$gold,$gems,translate_inline($gems>1?"s":""),translate_inline($sex>0?"Sh":"H"));
			blocknav("runmodule.php?module=amusementpark&op=ticket");
			set_module_pref("entered",1,"parkprizes");
			$session['user']['gold']-=$gold;
			$session['user']['gems']-=$gems;
			addnav("Amusement Park","runmodule.php?module=amusementpark");
		}
	}
	if ($op==""){
		if (get_module_pref("entered","parkprizes")==1) {
			require_once("lib/commentary.php");
			addcommentary();
			output("`@`c`bThe Entrance`b`c");
			if ($op2=="stamp") output("`nYou show your stamp to the attendant at the gate and you get the nod to go in.`n");
			output("`nYou stand in the middle of a busy Square with several side streets.  ");
			output("You see the lights of various attractions and games flickering out from these streets.  You can hear the excited voices of the crowd around you.`n`n");
			output("You wonder where to go first.`n`n");
			$args = modulehook("blockcommentarea", array("section"=>$texts['section']));
			if (!isset($args['block']) || $args['block'] != 'yes') {
				tlschema($schemas['talk']);
				output($texts['talk']);
				tlschema();
				viewcommentary("Park","Talk with others",20,"says");
			}
		}
	}
	if ($op=="leave"){
		output("`c`b`@Exit Gate`b`c`n");
		
		output("You stop by to get your hand stamped so you can come back in later. Then you exit through the turnstile.");
		set_module_pref("stamped",1);
		blocknav("runmodule.php?module=amusementpark&op=street1");
		blocknav("runmodule.php?module=amusementpark&op=street2");
		blocknav("runmodule.php?module=amusementpark&op=street3");
		blocknav("runmodule.php?module=amusementpark&op=street4");
		blocknav("runmodule.php?module=amusementpark&op=hof");
	}
	if (get_module_pref("entered","parkprizes")==0 || get_module_pref("stamped","amusementpark")==1) villagenav();
	else addnav("Leave the Park","runmodule.php?module=amusementpark&op=leave");
	if ($op=="street1"){
		output("`b`c`@Midway`b`c`n");
		addnav("Where Will You Go");
		modulehook("amusementpark-street1");
		output("You can see several people in front of various sideshows, hawking their wares. Where will you go first?");
		addnav("Return to Amusement Park", "runmodule.php?module=amusementpark");
		blocknav("runmodule.php?module=amusementpark&op=street1");
		blocknav("runmodule.php?module=amusementpark&op=street2");
		blocknav("runmodule.php?module=amusementpark&op=street3");
		blocknav("runmodule.php?module=amusementpark&op=street4");
		blocknav("runmodule.php?module=amusementpark&op=hof");
		output_notl("`n`n");
	}
	if ($op=="street2"){
		output("`c`b`@Rides N Stuff`b`c`n");
		addnav("Where Will You Go");
		modulehook("amusementpark-street2");
		output("You can see others on various rides, which one will you go on first?");
		addnav("Return to Amusement Park", "runmodule.php?module=amusementpark");
		blocknav("runmodule.php?module=amusementpark&op=street1");
		blocknav("runmodule.php?module=amusementpark&op=street2");
		blocknav("runmodule.php?module=amusementpark&op=street3");
		blocknav("runmodule.php?module=amusementpark&op=street4");
		blocknav("runmodule.php?module=amusementpark&op=hof");
		output_notl("`n`n");
	}
	if ($op=="street3"){
		addnav("Where Will You Go");
		modulehook("amusementpark-street3");
		output("`c`b`@Refreshments`b`c`n");
		output("You feel Hungry? or maybe Thirsty? What will it be?");
		addnav("Return to Amusement Park", "runmodule.php?module=amusementpark");
		blocknav("runmodule.php?module=amusementpark&op=street1");
		blocknav("runmodule.php?module=amusementpark&op=street2");
		blocknav("runmodule.php?module=amusementpark&op=street3");
		blocknav("runmodule.php?module=amusementpark&op=street4");
		blocknav("runmodule.php?module=amusementpark&op=hof");
		output_notl("`n`n");
	}	
	if ($op=="street4"){
		addnav("Where Will You Go");
		modulehook("amusementpark-street4");
		output("Gazing around you ponder your choices.");
		addnav("Return to Amusement Park", "runmodule.php?module=amusementpark");
		blocknav("runmodule.php?module=amusementpark&op=street1");
		blocknav("runmodule.php?module=amusementpark&op=street2");
		blocknav("runmodule.php?module=amusementpark&op=street3");
		blocknav("runmodule.php?module=amusementpark&op=street4");
		blocknav("runmodule.php?module=amusementpark&op=hof");
		output_notl("`n`n");
	}
	if ($op=="hof"){
		output("`b`c`@Hall of Fame`b`c`n");
		output("You stand before lists of winners.  Which would you like to see?");
		addnav("Hall of Fame");
		modulehook("amusementparkhof-header");
		modulehook("amusementparkhof-footer");
		addnav("Return to Amusement Park", "runmodule.php?module=amusementpark");
		blocknav("runmodule.php?module=amusementpark&op=street1");
		blocknav("runmodule.php?module=amusementpark&op=street2");
		blocknav("runmodule.php?module=amusementpark&op=street3");
		blocknav("runmodule.php?module=amusementpark&op=street4");
		blocknav("runmodule.php?module=amusementpark&op=hof");
	}
	module_display_events("amusementpark", "runmodule.php?module=amusementpark");
}
addnav("Superuser");
if ($session['user']['superuser']&~SU_DOESNT_GIVE_GROTTO){
	addnav("X?`bSuperuser Grotto`b","superuser.php");
}
if ($session['user']['superuser'] & SU_INFINITE_DAYS){
	addnav("/?New Day","newday.php");
}
tlschema();
page_footer();
}
?>