<?php

function broomsticks_getmoduleinfo(){
	$info = array(
		"name" => "Broomstick Ride",
		"author" => "`b`&Ka`6laza`&ar`b, Tweaks by DaveS",
		"version" => "1.11",
		"category" => "Amusement Park",
		"download"=>"http://dragonprime.net/index.php?module=Downloads;sa=dlview;id=1041",
		"description" => "Broomsticks Ride",
		"settings"=>array(
			"Broomsticks settings,title",
			"name" => "What is the Name of the stall?,text|The Broomstick Ride",
			"owner" => "Who runs the ride (female)?,text|Angela",
			"rides"=>"How many times can a player ride this ride per day?,int|3",
			"hp"=>"Hitpoint multiplier lost/gained by this event:,floatrange,0.02,0.48,0.2|.14",
			"charm"=>"Charm gained/lost by this event:,int|2",
			"gold" => "Cost in gold:, int|1000",
			"mingem" =>"Minimum gems given:,int|1",
			"maxgem" =>"Maximum gems given:,int|2",
			),
		"prefs"=>array(
			"Broomstick Ride preferences,title",
			"rides"=>"How many times has the player ridden this ride today?,int|0",
			"rand"=>"Has player encountered the random event today?,bool|0",
		),	
		"requires"=>array(
			"amusementpark" => "Amusement Park by Kalazaar (Amusement Park Package)",
			"parkprizes" => "Park Prizes by Kalazaar (Amusement Park Package)",
		),
	);
	return $info;
}
function broomsticks_install(){
	module_addhook("amusementpark-street2");
	module_addhook("newday");
	module_addeventhook("amusementpark","return 100;");
	
	return true;
}
function broomsticks_uninstall(){
	return true;
}
function broomsticks_dohook ($hookname, $args){
	global $session;
	$name = get_module_setting("name");
	switch($hookname){
		case "amusementpark-street2":
			addnav(array("%s",$name),"runmodule.php?module=broomsticks&op=broomsticks");
			break;
		case "newday":
			if (get_module_pref("rand")==1) module_addeventhook("amusementpark","return 100;");
			set_module_pref("rand",0);
			set_module_pref("rides",0);
		break;
	}
	return $args;
}
function broomsticks_runevent(){
	global $session;
	$op==httpget('op');
	$owner=get_module_setting("owner");
	$session['user']['specialinc'] = "module:Broomsticks";
	if (get_module_pref("entered","parkprizes")==0){
		addnav("Where Will You Go");
		$gold = get_module_setting("parkgold","amusementpark");
		$gems = get_module_setting("parkgem","amusementpark");
		output("`n`@You see a ticket booth with a sign reading:`n");
		output("`n`c`&Tickets for One Day of Entry:`n");
		if ($gold>0) output("`^%s Gold`n",$gold);
		if ($gems>0) output("`%%s Gem%s`n",$gems,translate_inline($gems>1?"s":""));
		if ($gold==0 && $gems==0) output("Free Entrance Today`n");
		output("`c`n`@If you're interested in going in then perhaps you should stop by and purchase a ticket.`n`n");
		output("%s`@ walks over to you and tells you to come visit the Broomsticks Ride over by Rides N Stuff when you get into the park.`n`n",$owner);
		addnav("Tickets");
		addnav("T?Ticket Booth","runmodule.php?module=amusementpark&op=ticket");
		if (get_module_pref("entered","parkprizes")==0 || get_module_pref("stamped","amusementpark")==1) villagenav();
		else addnav("Leave the Park","runmodule.php?module=amusementpark&op=leave");
		$session['user']['specialinc'] = "";
	}elseif($op=="street1"||$op=="amusementpark" || $op=="street2" || $op=="street3" || $op=="street4" || $op==""){
		$charm=get_module_setting("charm");
		output("`n`@An out of control Broomstick from the Broomstick Ride suddenly flies");
		switch (e_rand(1,5)){
			case 1:
			output("straight over your head. The rider, hanging on for dear life, accidentally kicks you!");
			$hp=round($session['user']['hitpoints']*get_module_setting("hp"));
			$session['user']['hitpoints']-=$hp;
			if ($hp>0) output("`n`n`@You `\$lose %s hitpoint%s`@!",$hp,translate_inline($hp>1?"s":""));
			else output("`n`n`@Luckily it doesn't hurt you.");
			break;
			case 2:
			output("straight into you. You feel somewhat groggy and stumble around for a little while.");
			if ($session['user']['turns']>1){
				$session['user']['turns']=1;
			}
			break;
			case 3:
			output("past you and bursts into flames.  Your hair is on fire!! You're less charming.");
			output("`n`n`@You `&lose %s charm`@.",$charm);
			$session['user']['charm']-=$charm;
			break;
			case 4:
			output("close and almost hits you. Luckily, you dodge and a crowd of onlookers applaud your agility.");
			output("`n`n`@You `&gain %s charm`@.",$charm);
			$session['user']['charm']+=$charm;
			break;
			case 5:
			output("Over your head. You thank your lucky stars that it didn't hit you.");
			$session['user']['turns']+=1;
			break;
		}
		set_module_pref("rand",1);
		module_addeventhook("amusementpark","return 0;");
		addnav("Return to Amusement Park", "runmodule.php?module=amusementpark");
	}
	$session['user']['specialinc'] = "";
}
function broomsticks_run(){
	global $session;
	page_header("Broomsticks Ride");
	$name=get_module_setting("name");
	$owner=get_module_setting("owner");
	$gold = get_module_setting("gold");
	$mingem = get_module_setting("mingem");
	$maxgem = get_module_setting("maxgem");
	$hp=round($session['user']['hitpoints']*get_module_setting("hp"));
	$op=httpget('op');
	if($op=="broomsticks"){
		output("`c`b`5Broomstick Ride`b`c`n");
		if (get_module_pref("rides")>=get_module_setting("rides")){
			output("%s`5 looks at you and then looks at her brooms.  `&\"No no no no.  You're wearing out my brooms! No more today.\"",$owner);
		}else{
			output("%s `5rubs her hands together, cackling wildly. `&\"So you want a ride on The Broomstick eh?\"  `5Looking around, you see several others riding Broomsticks.`n`n",$owner);
			if ($gold>0 || $gems>0){
				output("`&\"It costs");
				if ($gold>0) output("`^%s gold`&",$gold);
				if ($gold>0&&$gems>0) output("and");
				if ($gems>0) output("`%%s gem%s`&",$gems,translate_inline($gems>1?"s":""));
				output("for a ride.\"");
			}
			if ($gold==0 && $gems==0) output("Lucky you... You get to ride for free today.\"`0");
			addnav("The Broomstick Ride");
			addnav("Ride A Broomstick","runmodule.php?module=broomsticks&op=ride"); 
		}
		addnav("Return to Rides N Stuff", "runmodule.php?module=amusementpark&op=street2");
		addnav("Return to Amusement Park", "runmodule.php?module=amusementpark");
	}
	if ($op=="ride"){
		output("`c`b`5Broomstick Ride`b`c`n");
		if ($session['user']['gold']<$gold || $session['user']['gems']<$gems){
			output("%s `5picks up one of The Broomsticks and thwaps you over the head with it cackling wildly.  You realize you tried to pay her with thin air!",$owner);
		}else{
			$session['user']['gold']-=$gold;
			$session['user']['gems']-=$gems;
			if ($gold>0 || $gems>0) output("%s`5 smirks at you as she collects your payment.`n`n",$owner);
			else output("%s`5 lets you take a ride for free.`n`n",$owner);
			output("You jump on a pretty tame looking Broomstick, only to have its tail explode in flame and it starts bucking wildly.");
			$ride=e_rand(1,9);
			if ($ride==1 || $ride==4){
				output("You fall off the bucking Broomstick, face first! You are a little less charming.");
				$session['user']['charm']-=2;
			}
			if ($ride==2 || $ride==5){
				output("Wow this is great! The Broomstick bucks and flames for a while, before coming to a snap of %s's`5 fingers.  You get off feeling great!",$owner);
				$session['user']['turns']+=3;
			}
			if ($ride==3){
				$gemgain=e_rand($mingem,$maxgem);
				output("You hang on tightly to the Broomstick. Out of the corner of your eye, you spot something sparkling on top of a nearby building you should be able to just reach it, leaning over you grab `%%s gem%s`5!",$gemgain,translate_inline($gemgain>1?"s":""));
				$session['user']['gems']+=$gemgain;
			}
			if ($ride==6 || $ride==7){
				output("Your Broomstick starts to cough and in a large PUFF of Smoke suddenly disappears scaring you half to death.");
				if ($hp>0) output("`n`n`@You `\$lose %s hitpoint%s`@!",$hp,translate_inline($hp>1?"s":""));
				else output("`n`n`@Luckily it doesn't hurt you.");
				$session['user']['hitpoints']-=$hp;
			}
			if ($ride==8 || $ride==9){
				output("The Broomstick gives you the ride of your life, bucking and twisting. You feel exhilarated.");
				apply_buff('Broomsticks',array(
						"name"=>"`^Broomsticks",
						"rounds"=>15,
						"wearoff"=>"`&You finally get over that ride!",
						"defmod"=>1.05,
						"roundmsg"=>"`^That ride was exhilarating!",
						));
			}
		}
		increment_module_pref("rides",1);
		addnav("The Broomstick Ride");
		if (get_module_pref("rides")<get_module_setting("rides")) addnav("Ride Again!","runmodule.php?module=broomsticks&op=broomsticks"); 
		addnav("Return to Rides N Stuff", "runmodule.php?module=amusementpark&op=street2");
		addnav("Return to Amusement Park", "runmodule.php?module=amusementpark"); 
	}
	page_footer();
}
?>