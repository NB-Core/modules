The Amusement Park
By Kalazaar

modularized by sixf00t4
Tweaks by DaveS


This readme file is for tracking changes to the amusement park package.

Here are the current versions of all files in this package:

amusementpark.php	v1.11
archery.php			v1.11
broomsticks.php		v1.11
cottoncandy.php		v1.11
dragonride.php		v1.11
drinksbooth.php		v1.11	(modifications by Vanessa)
dropzone.php		v1.11
dunkem.php			v1.2
parkprizes.php		v1.3
piestall.php		v1.11
popcorn.php			v1.11	(modifications by Vanessa)
strengthtest.php	v1.11
thetent.php			v1.11


