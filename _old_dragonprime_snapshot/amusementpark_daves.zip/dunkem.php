<?php
function dunkem_getmoduleinfo(){
	$info = array(
	"name" => "Dunk Em",
	"author" => "`b`&Ka`6laza`&ar`b, Tweaks by DaveS",
	"version" => "1.2",
	"category" => "Amusement Park",
	"download"=>"http://dragonprime.net/index.php?module=Downloads;sa=dlview;id=1041",
	"settings"=>array(
		"Dunk Em settings,title",
			"name" => "What is the Name of the stall,text|Dunk Em",
			"owner" => "Who runs the ride?,text|ShadowRaven",
			"tank" =>"Who is in the Tank?,text|Douglas",
			"hp"=>"Hitpoint multiplier lost/gained by this event:,floatrange,0.02,0.48,0.2|.14",
			"charm"=>"Charm gained/lost by this event:,int|2",
			"gold" => "Cost in gold, int|1000",
			"maxvisit" => "Maximum number of times to try a day,int|3",
		),
		"prefs"=>array(
			"Dunk Em user preferences, title",
			"visit"=>"Times player has played Dunk Em today:,int|0",
			"rand"=>"Has player encountered the random event today?,bool|0",
		),
		"requires"=>array(
			"amusementpark" => "Amusement Park by Kalazaar (Amusement Park Package)",
			"parkprizes" => "Park Prizes by Kalazaar (Amusement Park Package)",
		),
	);		
	return $info;
}
function dunkem_install(){
	module_addhook("amusementpark-street1");
	module_addhook("newday");
	module_addeventhook("amusementpark","return 100;");
	return true;
}
function dunkem_uninstall(){
	return true;
}
function dunkem_dohook($hookname,$args){
	global $session;	
	$tank=get_module_setting("tank");
	
	switch ($hookname){
	case "amusementpark-street1":
	addnav(array("Dunk %s",$tank),"runmodule.php?module=dunkem&op=dunkem");
	
	break;
	case "newday":
			if (get_module_pref("rand")==1) module_addeventhook("amusementpark","return 100;");
			set_module_pref("rand",0);
			set_module_pref("visit",0);
	break;
	
	}
	
	return $args;
}
function dunkem_runevent(){
	global $session;
	$op=httpget('op');
	$session['user']['specialinc'] = "module:dunkem";	
	$name=get_module_setting("name");
	$owner=get_module_setting("owner");
	$tank=get_module_setting("tank");
	$hp=round($session['user']['hitpoints']*get_module_setting("hp"));
	if (get_module_pref("entered","parkprizes")==0){
		addnav("Where Will You Go");
		$gold = get_module_setting("parkgold","amusementpark");
		$gems = get_module_setting("parkgem","amusementpark");
		output("`n`@You see a ticket booth with a sign reading:`n");
		output("`n`c`&Tickets for One Day of Entry:`n");
		if ($gold>0) output("`^%s Gold`n",$gold);
		if ($gems>0) output("`%%s Gem%s`n",$gems,translate_inline($gems>1?"s":""));
		if ($gold==0 && $gems==0) output("Free Entrance Today`n");
		output("`c`n`@If you're interested in going in then perhaps you should stop by and purchase a ticket.`n`n");
		output("%s`@ walks over to you and tells you to come visit the Dunk-Em tank by the Midway when you get into the park.`n`n",$owner);
		addnav("Tickets");
		addnav("T?Ticket Booth","runmodule.php?module=amusementpark&op=ticket");
		if (get_module_pref("entered","parkprizes")==0 || get_module_pref("stamped","amusementpark")==1) villagenav();
		else addnav("Leave the Park","runmodule.php?module=amusementpark&op=leave");
		$session['user']['specialinc'] = "";
	}elseif($op=="street1"||$op=="amusementpark" || $op=="street2" || $op=="street3" || $op=="street4"|| $op==""){
	switch (e_rand(1,3)){
		case 1:
			output("`@A stranger runs past you and pushes a ticket into your hand. You take a look at it and realize it's a free shot at the dunk tank!");
			addnav("Free Dunk");
			addnav(array("Dunk %s",$tank),"runmodule.php?module=dunkem&op=dunkemfree");
			$session['user']['specialinc'] = "";
		break;
		case 2:
			output("`@You are almost knocked over by someone being chased by a very angry `)%s`@. Your nimble moves make you feel more powerful.",$tank);
			output("`n`n`@You `bgain %s hitpoint%s`b!",$hp,translate_inline($hp>1?"s":""));
			$session['user']['hitpoints']+=$hp;
		break;
		case 3:
			output("`@You get knocked down by someone being chased by a very wet, very angry `)%s`@.",$tank);
			if ($hp>0) output("`n`n`@You `\$lose %s hitpoint%s`@!",$hp,translate_inline($hp>1?"s":""));
			else output("`n`n`@Luckily it doesn't hurt you.");
			$session['user']['hitpoints']-=$hp;
		break;
	}
	increment_module_pref("rand");
	module_addeventhook("amusementpark","return 0;");
	addnav("Return to Amusement Park", "runmodule.php?module=amusementpark");
	}
	$session['user']['specialinc'] = "";
}
function dunkem_run(){
	global $session;
	page_header("Dunk Em");
	$name=get_module_setting("name");
	$owner=get_module_setting("owner");
	$gold = get_module_setting("gold");
	$tank=get_module_setting("tank");
	$op=httpget('op');
	$charm=get_module_setting("charm");
	output("`b`c`@Dunk 'Em`b`c`n");
	if ($op=="dunkem"){
		output("You approach a booth to see %s`@ smiling to herself. Beside her is a sign:  `n`cDunk %s for only %s Gold`c`n`@This could be fun... what will you do?",$owner,$tank,$gold);
		addnav("Dunk Em");
		addnav(array("Dunk %s",$tank),"runmodule.php?module=dunkem&op=dunk");
		addnav("Return to Midway", "runmodule.php?module=amusementpark&op=street1");
		addnav("Return to Amusement Park","runmodule.php?module=amusementpark");
	}
	if ($op=="dunk"){
		addnav(array("%s",$name));
		if ($session['user']['gold']<$gold){
			output("%s`@ looks at your empty hand.",$owner);
			addnav("Return to Midway", "runmodule.php?module=amusementpark&op=street1");
			addnav("Return to Amusement Park","runmodule.php?module=amusementpark");
		}else{
			output("%s`@, tosses you a ball and points you to where `)%s `@is sitting precariously on a plank of wood, balancing over a pool full of some sort of liquid.`n`n",$owner,$tank);
			increment_module_pref("visit");
			$dunk = e_rand(1,10);
			$hp=round($session['user']['hitpoints']*get_module_setting("hp"));
			$session['user']['gold']-=$gold;
			if ($dunk==1){
				output("Throwing a ball, you totally miss!  %s`@ looks at you in disgust.`n`n",$owner);
				output("`)%s`@, on the other hand, almost falls off the plank laughing and jeering at you.`n`n",$tank);
				$session['user']['hitpoints']-=$hp;
				$session['user']['charm']-=2;
				output("You notice several others staring in your direction and as you try to slink off you trip over a tent peg.");
			}
			if ($dunk==5){
				output("Tossing the ball, you miss by just a fraction. %s`@ looks at you sadly, `#'So close!'",$owner);
				output("`n`n`)%s`@, on the other hand looks slightly `2Green`@. You feel somewhat pleased with the effect you've had.",$tank);
				output("`n`nStrolling off, you receive a few admiring glances.");
				$session['user']['charm']+=2;
			}
			if ($dunk==10){
				output("Your aim is true! The board collapses and `)%s`@ falls into the ",$tank);
				switch (e_rand(1,3)){
					case 1:
					output("water below him with a large splash!!  He clambers out and reaches for a nearby Smite Stick.  %s`@ quickly ushers you from the booth",$owner);
					output("`n`nYou realize you'd better get out of here and fast, but you feel great!");
					$session['user']['hitpoints']+=$hp;
					break;
					case 2:
					output("acid below him.  He screams in pain while %s`@ giggles and applauds.",$owner);
					output("`n`nYou watch as a claw drags the now unconscious form of `)%s`@ from the pool and wander off wondering how long until he recovers enough to come after you.",$tank);
					output("`n`nYou `bgain %s hitpoint%s`b!",$hp,translate_inline($hp>1?"s":""));
					output("`n`n`@You `&gain %s charm`@.",$charm);
					$session['user']['hitpoints']+=$hp;
					$session['user']['charm']+=$charm;
					break;
					case 3:
					output("Empty Pool!!  He lands with a loud thud. Looking over, you realize that %s`@ pulled the release valve and emptied the pool. She giggles to herself and ignores `)%s's`@ threats and curses.",$owner,$tank);
					output("`n`nYou decide that running is a good idea and %s`@ gives you a quick smooch on your way past",$owner);
					output("`n`n`@You `&gain %s charm`@.",$charm);
					$session['user']['charm']+=$charm;
					break;
				}
			}
			if ($dunk==2 || $dunk==3 || $dunk==4 || $dunk==6 || $dunk==7 || $dunk==8 || $dunk==9){
				output("You miss!");
			}
			addnav("Dunk 'Em");
			if (get_module_pref("visit")<get_module_setting("maxvisit")) addnav("Throw Again!","runmodule.php?module=dunkem&op=dunkem"); 
			addnav("Return to Midway", "runmodule.php?module=amusementpark&op=street1");
			addnav("Return to Amusement Park","runmodule.php?module=amusementpark");
	}
}
if ($op=="dunkemfree"){
	$dunk = e_rand(1,10);
	$hp=round($session['user']['hitpoints']*get_module_setting("hp"));
	addnav(array("%s",$name));
	output("%s`@, tosses you a ball and points you to where `)%s `@is sitting precariously on a plank of wood, balancing over a pool full of some sort of liquid.`n`n",$owner,$tank);
	increment_module_pref("visit");
	$dunk = e_rand(1,10);
	$hp=round($session['user']['hitpoints']*get_module_setting("hp"));
	$session['user']['gold']-=$gold;
	if ($dunk==1){
		output("Throwing a ball, you totally miss!  %s`@ looks at you in disgust.",$owner);
		output("`n`n`)%s`@, on the other hand, almost falls off the plank laughing and jeering at you.",$tank);
		$session['user']['hitpoints']-=$hp;
		output("`n`nYou notice several others staring in your direction and as you try to slink off you trip over a tent peg.");
		if ($hp>0) output("`n`n`@You `\$lose %s hitpoint%s`@!",$hp,translate_inline($hp>1?"s":""));
		else output("`n`n`@Luckily it doesn't hurt you.");
		output("`n`n`@You `&lose %s charm`@.",$charm);
		$session['user']['charm']-=$charm;
	}
	if ($dunk==5){
		output("Tossing the ball, you miss by just a fraction. %s`@ looks at you sadly, `#'So close!'",$owner);
		output("`n`n`)%s`@, on the other hand looks slightly `2Green`@. You feel somewhat pleased with the effect you've had.",$tank);
		output("`n`nStrolling off, you receive a few admiring glances.");
		output("`n`n`@You `&gain %s charm`@.",$charm);
		$session['user']['charm']+=$charm;
	}
	if ($dunk==10){
		output("Your aim is true! The board collapses and `)%s`@ falls into the ",$tank);
		switch (e_rand(1,3)){
			case 1:
				output("water below him with a large splash!!  He clambers out and reaches for a nearby Smite Stick.  %s`@ quickly ushers you from the booth",$owner);
				output("`n`nYou realize you'd better get out of here and fast, but you feel great!");
				output("`n`nYou `bgain %s hitpoint%s`b!",$hp,translate_inline($hp>1?"s":""));
				$session['user']['hitpoints']+=$hp;
			break;
			case 2:
				output("acid below him.  He screams in pain while %s`@ giggles and applauds.",$owner);
				output("`n`nYou watch as a claw drags the now unconscious form of `)%s`@ from the pool and wander off wondering how long until he recovers enough to come after you.",$tank);
				output("`n`nYou `bgain %s hitpoint%s`b!",$hp,translate_inline($hp>1?"s":""));
				$session['user']['hitpoints']+=$hp;
				output("`n`n`@You `&gain %s charm`@.",$charm);
				$session['user']['charm']+=$charm;
			break;
			case 3:
				output("Empty Pool!!  He lands with a loud thud. Looking over, you realize that %s`@ pulled the release valve and emptied the pool. She giggles to herself and ignores `)%s's`@ threats and curses.",$owner,$tank);
				output_notl("`n`n");
				output("You decide that running is a good idea and %s`@ gives you a quick smooch on your way past",$owner);
				output("`n`n`@You `&gain %s charm`@.",$charm);
				$session['user']['charm']+=$charm;
			break;
		}
	}
	if ($dunk==2 || $dunk==3 || $dunk==4 || $dunk==6 || $dunk==7 || $dunk==8 || $dunk==9){
		output("You miss!");
	}
	addnav(array("%s",$name));
	addnav("Return to Amusement Park","runmodule.php?module=amusementpark");
}
page_footer();
}
?>			