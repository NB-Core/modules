<?php

function archery_getmoduleinfo(){
	$info = array(
		"name" => "Archery",
		"author" => "`b`&Ka`6laza`&ar`b, Tweaks by DaveS",
		"version" => "1.11",
		"category" => "Amusement Park",
		"download"=>"http://dragonprime.net/index.php?module=Downloads;sa=dlview;id=1041",
		"settings"=>array(
			"Archery setting, title",
			"name"=>"Stall name:,text|Archery",
			"list"=>"How many on hof?,int|25",
			"owner"=>"Who runs the stall?,text|`b`&Q`)uinne `&W`)olfe`b",
			"hp"=>"Hitpoint multiplier lost/gained by this event:,floatrange,0.02,0.48,0.2|.14",
			"charm"=>"Charm gained/lost by this event:,int|2",
			"gold"=>"Gold to play:,int|100",
			"gems"=>"Gems to play:,int|0",
		),
		"prefs"=>array(
			"Archery preferences,title",
			"highscore"=>"Player's high score:,int|0",
			"score"=>"Score this round:,int|0",
			"peek"=>"Has player had a chance to peek today?,bool|0",
		),
		"requires"=>array(
			"amusementpark" => "Amusement Park by Kalazaar (Amusement Park Package)",
			"parkprizes" => "Park Prizes by Kalazaar (Amusement Park Package)",
		),
	);
	return $info;
}
function archery_install(){
	module_addhook("amusementpark-street1");
	module_addhook("amusementparkhof-header");
	module_addhook("newday");
	module_addeventhook("amusementpark","return 50;");
	return true;
}
function archery_uninstall(){
	return true;
}
function archery_dohook($hookname,$args){
	global $session;
	$name = get_module_setting("name");
	$op=httpget('op');
	switch($hookname){
		case "amusementpark-street1":
			addnav(array("%s",$name),"runmodule.php?module=archery&op=enter");
		break;
		case "amusementparkhof-header":
			addnav("Archery", "runmodule.php?module=archery&op=hof");
		break;
		case "newday":
			if (get_module_pref("peek")==1) {
				module_addeventhook("amusementpark","return 50;");
				set_module_pref("peek",0);
			}
		break;
	}
	return $args;
}
function archery_runevent(){
	global $session;
	$op==httpget('op');
	$owner = get_module_setting("owner");
	$session['user']['specialinc'] = "module:archery";
	if (get_module_pref("entered","parkprizes")==0){
		addnav("Where Will You Go");
		$gold = get_module_setting("parkgold","amusementpark");
		$gems = get_module_setting("parkgem","amusementpark");
		output("`n`@You see a ticket booth with a sign reading:`n");
		output("`n`c`&Tickets for One Day of Entry:`n");
		if ($gold>0) output("`^%s Gold`n",$gold);
		if ($gems>0) output("`%%s Gem%s`n",$gems,translate_inline($gems>1?"s":""));
		if ($gold==0 && $gems==0) output("Free Entrance Today`n");
		output("`c`n`@If you're interested in going in then perhaps you should stop by and purchase a ticket.`n`n");
		output("%s`@ walks over to you and tells you to come visit the Archery Game at the Midway when you get into the park.`n`n",$owner);
		addnav("Tickets");
		addnav("T?Ticket Booth","runmodule.php?module=amusementpark&op=ticket");
		if (get_module_pref("entered","parkprizes")==0 || get_module_pref("stamped","amusementpark")==1) villagenav();
		else addnav("Leave the Park","runmodule.php?module=amusementpark&op=leave");
		$session['user']['specialinc'] = "";
	}elseif($op=="street1"||$op=="amusementpark" || $op=="street2" || $op=="street3" || $op=="street4" || $op==""){
		output("`@`nYou see a small hole about eye level in the fence ahead of you, there is a lot of giggling going on behind there, what do you do?");
		addnav("Peek","runmodule.php?module=archery&op=peek");
		addnav("Return to Amusement Park","runmodule.php?module=amusementpark");
		module_addeventhook("amusementpark","return 0;");
		set_module_pref("peek",1);
		$session['user']['specialinc']="";
	}
}
function archery_run(){
	global $session;
	$op=httpget('op');
	$name = get_module_setting("name");
	$owner = get_module_setting("owner");
	$gold = get_module_setting("gold");
	$gems = get_module_setting("gems");
	$hp=round($session['user']['hitpoints']*get_module_setting("hp"));
	$charm=get_module_setting("charm");
	if ($op=="peek"){
		page_header("Peek");
		output("`c`b`@Archery`b`c`n");
		$peek=e_rand(1,10);
		switch ($peek){
			case 1: //hp loss
			case 3:
			case 5:
			case 6:
				output("OUCH!! You are apparently looking through behind the Archery Booth. You've just got an arrow straight through your eye!");
				$session['user']['hitpoints']-=$hp;
				if ($hp>0) output("`n`n`@You `\$lose %s hitpoint%s`@!",$hp,translate_inline($hp>1?"s":""));
				else output("`n`n`@Luckily it doesn't hurt you.");
			break;
			case 2: // small buff
			case 4:
			case 10:
			output("You're behind The tent and can see inside one of them. Ohhhh you feel great!");
			apply_buff('tent',array(
						"name"=>"The Tent",
						"rounds"=>15,
						"wearoff"=>"`&You slowly forget what you've seen!",
						"defmod"=>1.1,
						"roundmsg"=>"Wow what a View!",
						));
			break;
			case 7: //charm loss
			case 8:
			case 9:
			output("You're at the back of the Pie Stall! Unfortunately, you chose to look just as they were tossing some old pies out and now you definately feel less charming.");
			output("`n`n`@You `&lose %s charm`@.",$charm);
			$session['user']['charm']-=$charm;
			break;
		}
		addnav("Return to Amusement Park", "runmodule.php?module=amusementpark"); 
	}
	if ($op=="enter"){
		page_header("Archery");
		output("`c`b`@Archery`b`c`n");
		addnav("Archery");
		addnav("Play","runmodule.php?module=archery&op=play");
		addnav("View HoF", "runmodule.php?module=archery&op=hof");
		addnav("Return to Midway", "runmodule.php?module=amusementpark&op=street1");		addnav("Return to Amusement Park","runmodule.php?module=amusementpark");
		if (get_module_pref("stamped","amusementpark")==1) villagenav();
		else addnav("Leave the Park","runmodule.php?module=amusementpark&op=leave");
		output("You enter %s`0. %s`@ sizes you up.  `@\"So you think you're William Tell?",$name,$owner);
		if ($gold>0 || $gems>0){
			output("It costs");
			if ($gold>0) output("`^%s gold`@",$gold);
			if ($gold>0&&$gems>0) output("and");
			if ($gems>0) output("`%%s gem%s`@",$gems,translate_inline($gems>1?"s":""));
			output("to play.\"");
		}
		if ($gold==0 && $gems==0) output("Lucky you... You get to play for free today.\"`0");
		
		output_notl("`n`n");
		output("`@\"Keep in mind, we're looking for the best of the best. There's a Hall of Fame that we keep for the high scorer's list. Are you going to play?\"");
	}
if ($op=="play"){
	output("`c`b`@Archery`b`c`n");
	$hs = get_module_pref("highscore");
	$sc = get_module_pref("score");
	if ($hs<$sc) set_module_pref("highscore",$sc);
	page_header("Archery");
	addnav("Archery");
	set_module_pref("score",0);
	if ($session['user']['gold']<$gold || $session['user']['gems']<$gems){
		output("%s,`@ raises an eyebrow, `@\"This isn't a free game you know; you need",$owner);
		if ($gold>0 || $gems>0){
			if ($gold>0) output("`^%s gold`@",$gold);
			if ($gold>0&&$gems>0) output("and");
			if ($gems>0) output("`%%s gem%s`@",$gems,translate_inline($gems>1?"s":""));
			output("to play.");
		}
		output("Stop by when you've got the funds.\"");
		addnav("Return to Midway", "runmodule.php?module=amusementpark&op=street1");		addnav("Return to Amusement Park","runmodule.php?module=amusementpark");
		if (get_module_pref("stamped","amusementpark")==1) villagenav();
		else addnav("Leave the Park","runmodule.php?module=amusementpark&op=leave");
	}
	if ($session['user']['gold']>=$gold && $session['user']['gems']>=$gems){
		output("%s,`@ takes your money and passes you a bow and quiver of arrows.  He nudges you in the general direction of the target.",$owner);
		addnav("Continue","runmodule.php?module=archery&op=continue");
		$session['user']['gold']-=$gold;
		$session['user']['gems']-=$gems;
	}
}
if ($op=="continue"){
	page_header("Play");
	addnav("Archery");
	output("`c`b`@Archery`b`c`n");
	$hit=e_rand(1,60);
	switch($hit){
		case 1: //miss
		case 4:
		case 8:
		case 12:
		case 14:
		case 26:
		case 29:
		output("You miss the target entirely.");
		addnav("Continue","runmodule.php?module=archery&op=continue");
		break;
		case 31: // game over
		case 33:
		case 39:
		case 42:
		case 47:
		output("You've missed the target and your quiver is empty. Oh no! Your game is over.");
		if (get_module_pref("score")==0) output("`n`nWell, that's too bad.  You didn't even hit the target once.");
		addnav("Score","runmodule.php?module=archery&op=score");
		break;
		case 2: // small hit
		case 7:
		case 16:
		case 22:
		case 30:
		case 32:
		case 34:
		output("You hit the target. You've scored `^1 point`@.");
		addnav("Continue","runmodule.php?module=archery&op=continue");
		increment_module_pref("score",+1);
		break;
		case 35: // medium hit
		case 36:
		case 37:
		case 41:
		case 45:
		case 46:
		case 48:
		case 49:
		output("You hit the target. You've scored `^2 points`@.");
		addnav("Continue","runmodule.php?module=archery&op=continue");
		increment_module_pref("score",+2);
		break;
		case 50:
		case 51:
		case 52:
		case 53:
		case 54:
		case 55:
		case 56:
		case 57:
		case 58:
		case 59:
		case 60:
		case 19:
		case 20:
		case 23:
		case 24:
		output("You almost hit the bullseye. You've scored `^3 points`@.");
		addnav("Continue","runmodule.php?module=archery&op=continue");
		increment_module_pref("score",+3);
		break;
		case 9://bullseye
		case 10:
		case 11:
		case 15:
		case 17:
		case 25:
		case 27:
		output("You hit the bullseye. You've scored `^5 points`@.");
		addnav("Continue","runmodule.php?module=archery&op=continue");
		increment_module_pref("score",+5);
		break;
		case 3: // near miss
		case 5:
		case 6:
		
		case 28:
		case 40:
		case 43:
		case 44:
		output("You almost hit the target. You are quite sure it moved!");
		addnav("Continue","runmodule.php?module=archery&op=continue");
		break;
		case 13: //hit Quinne
		case 18:
		
		output("Uh oh, you've hit our resident Casanova, `b`&Q`)uinne`& W`)olf`b`@. I don't think you'll be getting smooches for a while. GAME OVER!!");
		addnav("Score","runmodule.php?module=archery&op=score");
		break;
		case 21: // hit Stang
		case 38:
		
		output("Oh Crap, that was a very big, very mean`b`$ STANG`b`@! Running would be a good idea!! GAME OVER!!");
		addnav("Score","runmodule.php?module=archery&op=score");
		break;
	}
}
if ($op=="score"){
	page_header("Your Score");
	$hs = get_module_pref("highscore");
	$sc = get_module_pref("score");
	$vcr = round($sc*0.1);
	increment_module_pref("voucher",+$vcr,"parkprizes");
	output("`c`bArchery`b`c`n");
	if ($sc<>0){
		
	if ($hs<$sc){
		output("%s`@ congratulates you. You've passed your previous highscore of `^%s`@ and achieved a score of `^%s`@.",$owner,$hs,$sc);
		output_notl("`n`n");
	}
	if ($hs>=$sc){
		output("%s`@ Congratulates you on your score of `^%s`@. Unfortunately you haven't passed your highscore of `^%s`@.",$owner,$sc,$hs);
		output_notl("`n`n");
	}
	if ($vcr==0){
		output("Sorry, you haven't won any vouchers.");
	}
	if($vcr<>0){
		output("You've won `%%s voucher%s`@, redeemable at our prize stall.",$vcr,translate_inline($vcr>1?"s":""));
	}
	}
	if ($sc==0){
		output("Unfortunately you failed to score anything.");
	}
	addnav("Archery");
	addnav("Play again", "runmodule.php?module=archery&op=play");
	addnav("Hall of Fame","runmodule.php?module=archery&op=hof");
	addnav("Return to Midway", "runmodule.php?module=amusementpark&op=street1");	addnav("Return to Amusement Park","runmodule.php?module=amusementpark");
	if (get_module_pref("stamped","amusementpark")==1) villagenav();
	else addnav("Leave the Park","runmodule.php?module=amusementpark&op=leave");
}
if ($op=="hof"){
	page_header("Archery");
	$hs = get_module_pref("highscore");
	$sc = get_module_pref("score");
	if ($hs<$sc){
		set_module_pref("highscore",$sc);
	}
	$acc = db_prefix("accounts");
	$mp = db_prefix("module_userprefs");
	$sql = "SELECT $acc.name AS name,
	$acc.acctid AS acctid,
	$mp.value AS highscore,
	$mp.userid FROM $mp INNER JOIN $acc
	ON $acc.acctid = $mp.userid 
	WHERE $mp.modulename = 'archery' 
	AND $mp.setting = 'highscore' 
	AND $mp.value > 0 ORDER BY ($mp.value+0)	
	DESC limit ".get_module_setting("list")."";
	$result = db_query($sql);
	$rank = translate_inline("High Score");
	$name = translate_inline("Name");
	$none = translate_inline("No Archers Yet");
	output("`n`b`c`%Archery High Scores`n`n`c`b");
	rawoutput("<table border='0' cellpadding='2' cellspacing='1' align='center'>");
	rawoutput("<tr class='trhead'><td align=center>$name</td><td align=center>$rank</td></tr>");
	if (db_num_rows($result)==0) output_notl("<tr class='trlight'><td colspan='2' align='center'>`&$none`0</td></tr>",true);
	else{
		for ($i=0;$i < db_num_rows($result);$i++){ 
		$row = db_fetch_assoc($result);
		if ($row['name']==$session['user']['name']){
			rawoutput("<tr class='trhilight'><td>");
		}else{
			rawoutput("<tr class='".($i%2?"trdark":"trlight")."'><td align=left>");
		}
		output_notl("%s",$row['name']);
		rawoutput("</td><td align=right>");
		output_notl("%s",$row['highscore']);
		rawoutput("</td></tr>");
	}
}
rawoutput("</table>");
addnav("Hall of Fame");
addnav("Back to Hall of Fame", "runmodule.php?module=amusementpark&op=hof");
addnav("Return to Archery", "runmodule.php?module=archery&op=enter");
addnav("Return to Midway", "runmodule.php?module=amusementpark&op=street1");addnav("Return to Amusement Park","runmodule.php?module=amusementpark");
if (get_module_pref("stamped","amusementpark")==1) villagenav();
else addnav("Leave the Park","runmodule.php?module=amusementpark&op=leave");
}
page_footer();
}