<?php

function dropzone_getmoduleinfo(){
	$info = array(
		"name" => "DropZone",
		"author" => "`b`&Ka`6laza`&ar`b, Tweaks by DaveS",
		"version" => "1.11",
		"category" => "Amusement Park",
		"download"=>"http://dragonprime.net/index.php?module=Downloads;sa=dlview;id=1041",
		"description" => "Medieval style DropZone",
		"settings"=>array(
			"Drop Zone settings,title",
			"name" => "What is the Name of the stall,int|Ye Olde DropZone",
			"owner" => "Who runs the ride (female)?,int|`b`\$Can`&uck`b",
			"hp"=>"Hitpoint multiplier lost/gained by this event:,floatrange,0.02,0.48,0.2|.14",
			"gold" => "Cost in gold:, int|1000",
			"maxvisit" => "Maximum number of times to try a day:,int|3",
			),
		"prefs"=>array(
			"DropZone user preferences, title",
			"visit"=>"Times player has ridden the DropZone today:,int|0",
			"rand"=>"Has player encountered the random event today?,bool|0",
			),
		"requires"=>array(
			"amusementpark" => "Amusement Park by Kalazaar (Amusement Park Package)",
			"parkprizes" => "Park Prizes by Kalazaar (Amusement Park Package)",
		),
	);
	return $info;
}
function dropzone_install(){
	module_addhook("amusementpark-street2");
	module_addhook("newday");
	module_addeventhook("amusementpark","return 100;");
	return true;
}
function dropzone_uninstall(){
	return true;
}
function dropzone_dohook ($hookname, $args){
	global $session;
	$name = get_module_setting("name");
	switch($hookname){
		case "amusementpark-street2":
			addnav("Ye Olde DropZone","runmodule.php?module=dropzone&op=dropzone");
			break;
		case "newday":
			if (get_module_pref("rand")==1) module_addeventhook("amusementpark","return 100;");
			set_module_pref("rand",0);
			set_module_pref("visit",0);
			break;
	}
	return $args;
}
function dropzone_runevent(){
	global $session;
	$name=get_module_setting("name");
	$owner=get_module_setting("owner");
	$hp=round($session['user']['hitpoints']*get_module_setting("hp"));
	$op=httpget('op');
	$session['user']['specialinc'] = "module:dropzone";	
	if (get_module_pref("entered","parkprizes")==0){
		addnav("Where Will You Go");
		$gold = get_module_setting("parkgold","amusementpark");
		$gems = get_module_setting("parkgem","amusementpark");
		output("`n`@You see a ticket booth with a sign reading:`n");
		output("`n`c`&Tickets for One Day of Entry:`n");
		if ($gold>0) output("`^%s Gold`n",$gold);
		if ($gems>0) output("`%%s Gem%s`n",$gems,translate_inline($gems>1?"s":""));
		if ($gold==0 && $gems==0) output("Free Entrance Today`n");
		output("`c`n`@If you're interested in going in then perhaps you should stop by and purchase a ticket.`n`n");
		output("%s`@ walks over to you and tells you to come visit the DropZone Ride over by Rides N Stuff when you get into the park.`n`n",$owner);
		addnav("Tickets");
		addnav("T?Ticket Booth","runmodule.php?module=amusementpark&op=ticket");
		if (get_module_pref("entered","parkprizes")==0 || get_module_pref("stamped","amusementpark")==1) villagenav();
		else addnav("Leave the Park","runmodule.php?module=amusementpark&op=leave");
		$session['user']['specialinc'] = "";
	}elseif($op=="street1"||$op=="amusementpark" || $op=="street2" || $op=="street3" || $op=="street4"|| $op==""){
		switch (e_rand(1,3)){
			case 1:
			output("`n`@You are crushed beneath a falling cage.   You `\$lose all hitpoints except 1`@.");
			$session['user']['hitpoints']=1;
			break;
			case 2:
			output("`n`@A falling cage lands beside you scaring, you half to death!");
			if ($hp>0) output("`n`n`@You `\$lose %s hitpoint%s`@!",$hp,translate_inline($hp>1?"s":""));
			else output("`n`n`@Luckily it doesn't hurt you.");
			$session['user']['hitpoints']-=$hp;
			break;
			case 3:
			output("`n`@You watch as a large cage drops from above, laughing at the sheer terror on the occupants faces, your spirits are lifted.");
			$session['user']['spirits']=2;
			break;
		}
		addnav("Return to Amusement Park", "runmodule.php?module=amusementpark");
		set_module_pref("rand",1);
		module_addeventhook("amusementpark","return 0;");
	}
	$session['user']['specialinc'] = "";
}
function dropzone_run(){
	global $session;
	page_header("DropZone");
	$name=get_module_setting("name");
	$owner=get_module_setting("owner");
	$gold = get_module_setting("gold");
	$hp=round($session['user']['hitpoints']*get_module_setting("hp"));
	$maxvisit = get_module_setting("maxvisit");
	$visit = get_module_pref("visit");
	$op=httpget('op');
	output("`c`b`@Ye Olde Dropzone`b`c`n");
	addnav("Ye Olde DropZone");
	if ($op=="dropzone"){
		output("You stand at the bottom of a huge tower and notice a sign:");
		output_notl("`n`n");
		output("`b`c`2%s`2: Only`^ %s gold`@ a ride`b`c",$name,$gold);
		output_notl("`n`n");
		output("`@Could be fun, what do you do?");
		addnav("Climb the tower","runmodule.php?module=dropzone&op=climb");
	}
	if ($op=="climb"){
		output("Slowly you climb up the tower. Hey! This thing isn't exactly safe; it's wobbling all over the place.");
		output_notl("`n`n");
		output("As you reach the top, you take a quick look down. WOW! This is way up there. Looking sideways, you can see a Dragon swoop past with someone on his back.");
		output_notl("`n`n");
		output("%s `@approaches you and enquires whether you'd like to take a ride.  `#'A ride on what?'`@ you ask. She points towards a cage, teetering on the edge of the tower, attached to a winch and a rope.",$owner);
		addnav(array("%s",$name));
		addnav("Take a ride","runmodule.php?module=dropzone&op=ride");
	}
	if ($op=="ride"){
		if ($session['user']['gold']<$gold){
			output("%s `@looks at you oddly and you realize you don't have enough gold. Turning, you trudge all the way down to the bottom of the tower.",$owner);
		}elseif ($visit>=$maxvisit){
			output("%s`@ thinks you look familiar. `#'Hey! You've had enough rides for one day!' `@Gulping, you realize you better get going before you get pushed off the tower.",$owner);
		}else{
			increment_module_pref("visit",1);
			if (get_module_pref("visit")<get_module_setting("maxvisit")) addnav("Ride Again!","runmodule.php?module=dropzone&op=dropzone"); 
			output("Gulping, you pay your gold and climb into the cage. It sways precariously as you climb in.");
			output_notl("`n`n");
			$session['user']['gold']-=$gold;
			output("%s`@ pulls a lever and the cage starts to plummet",$owner);
			$cage=e_rand(1,3);
			if ($cage==1){
				output("Glancing up you notice the rope is fraying! You hope it holds...`n`n`n Luckily, the cage jolts to a halt a couple of feet above the ground.  Unluckily, the jolt is too much for the rope, and it snaps, hurling you to the ground.");
				if ($hp>0) output("`n`n`@You `\$lose %s hitpoint%s`@!",$hp,translate_inline($hp>1?"s":""));
				else output("`n`n`@Luckily it doesn't hurt you.");
				$session['user']['hitpoints']-=$hp;
			}
			if ($cage==2){
				output("Glancing up you notice the rope is fraying! You hope it holds...`n`n`n Luckily, the cage jolts to a halt a couple of feet above the ground.  Even more luckily, the rope holds! You feel Exhilarated.");
				apply_buff('dropzone',array(
						"name"=>"`^DropZone",
						"rounds"=>15,
						"wearoff"=>"`&You finally get over that ride!",
						"defmod"=>1.05,
						"roundmsg"=>"`^That ride was exhilarating!",
						));
			}
			if ($cage==3){
				output("Glancing up you notice the rope is fraying! You hope it holds...`n`n`nLuckily, the cage jolts to a halt a couple of feet above the ground.  Even more luckily, the rope holds.  Unluckily, the whole experience makes you feel quite ill.");
				apply_buff('dropzone',array(
						"name"=>"`^DropZone",
						"rounds"=>15,
						"wearoff"=>"`&You finally get over that ride!",
						"defmod"=>0.95,
						"roundmsg"=>"`^That ride made you ill!",
						));
			}
		}
	}
	addnav("Return to Rides N Stuff", "runmodule.php?module=amusementpark&op=street2");
	addnav("Return to Amusement Park", "runmodule.php?module=amusementpark");
	page_footer();
}
?>
				
				