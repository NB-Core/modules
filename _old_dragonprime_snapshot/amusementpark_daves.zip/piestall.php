<?php

function piestall_getmoduleinfo(){
	$info = array(
		"name" => "Pie Throwing Stall",
		"author" => "`b`&Ka`6laza`&ar`b, Tweaks by DaveS",
		"version" => "1.11",
		"category" => "Amusement Park",
		"download"=>"http://dragonprime.net/index.php?module=Downloads;sa=dlview;id=1041",
		"description" => "Pie Throwing Stall",
		"settings"=>array(
			"Pie Throwing Stall setting, title",
			"name"=>"Stall name:,text|Pie Toss",
			"gold"=>"Cost of a pie:,int|100",
			"charm"=>"Charm gained/lost by this event:,int|2",
			"throwmax"=>"Maximum number of times a player can throw a pie:,int|3",
		),
		"prefs"=>array(
			"Pie Throwing Stall preferences,title",
			"thrown"=>"How many times has user thrown a pie?,int|0",
			"hit"=>"Has player been hit?,bool|0",
			"rand"=>"Has player encountered the random event today?,bool|0",
		),
		"requires"=>array(
			"amusementpark" => "Amusement Park by Kalazaar (Amusement Park Package)",
			"parkprizes" => "Park Prizes by Kalazaar (Amusement Park Package)",
		),
	);
	return $info;
}

function piestall_install(){

	module_addhook("amusementpark-street1");
	module_addhook("newday");
	module_addhook("village");
	module_addeventhook("amusementpark","return 100;");
	return true;
}
function piestall_uninstall(){
	return true;
}
function piestall_dohook($hookname,$args){
	global $session;
	$name = get_module_setting("name");
	switch ($hookname){
		case "amusementpark-street1":
			addnav(array("%s",$name),"runmodule.php?module=piestall&op=piestall");
			break;
		case "newday":
			if (get_module_pref("rand")==1) module_addeventhook("amusementpark","return 100;");
			set_module_pref("rand",0);
			set_module_pref("thrown",0);
			break;
		case "village":
			if (get_module_pref("hit")==1){
				output_notl("`@`n");
				$charm=get_module_setting("charm");
				switch (e_rand(1,6)){
					case 1:
					output("You've been hit with a Cream Pie! You're less charming.");
					output("`n`n`@You `&lose %s charm`@.`n",$charm);
					$session['user']['charm']-=$charm;
					break;
					case 2:
					output("You've been hit with a Cream Pie! It's going to take some time to clean up.");
					output("`n`n`@You `&lose 2 turns`@.`n");
					$session['user']['turns']-=2;
					break;
					case 3:
					output("You've been hit with a Cream Pie! Several villagers start licking cream off you. You're more charming.");
					output("`n`n`@You `&gain %s charm`@.`n",$charm);
					$session['user']['charm']+=$charm;
					break;
					case 4:
					output("You've been hit with a Cream Pie and it gives you some protection!`n");
					apply_buff('creampie',array(
						"name"=>"`&Cream Pie",
						"rounds"=>15,
						"wearoff"=>"`&The remains of the Cream Pie finally fall off you!",
						"defmod"=>1.05,
						"roundmsg"=>"`^The Cream Coating protects you!",
						));
					break;
					case 5:
					output("You've been hit with a Cream Pie and it makes your weapon slippery.`n");
					apply_buff('creampie',array(
						"name"=>"`&Cream Pie",
						"rounds"=>15,
						"wearoff"=>"`&The remains of the Cream Pie finally fall off you!",
						"atkmod"=>0.95,
						"roundmsg"=>"`^The Cream Coating causes your weapon to slip in your grasp!",
						));
					break;
					case 6:
					output("You've had a Cream Pie thrown at you. Luckily, you dodge it.");
					output("`n`n`@You `&gain 2 turns`@.`n");
					$session['user']['turns']+=2;
					break;
				}
				set_module_pref("hit",0);
			}
			break;
	}
	return $args;
}
function piestall_runevent(){
	global $session;
	$op==httpget('op');
	$session['user']['specialinc'] = "module:piestall";	
	$charm=get_module_setting("charm");
	if (get_module_pref("entered","parkprizes")==0){
		addnav("Where Will You Go");
		$gold = get_module_setting("parkgold","amusementpark");
		$gems = get_module_setting("parkgem","amusementpark");
		output("`n`@You see a ticket booth with a sign reading:`n");
		output("`n`c`&Tickets for One Day of Entry:`n");
		if ($gold>0) output("`^%s Gold`n",$gold);
		if ($gems>0) output("`%%s Gem%s`n",$gems,translate_inline($gems>1?"s":""));
		if ($gold==0 && $gems==0) output("Free Entrance Today`n");
		output("`c`n`@If you're interested in going in then perhaps you should stop by and purchase a ticket.`n`n");
		output("%s`@ walks over to you and tells you to come visit the Pie Stall over by the Midway when you get into the park.`n`n",$owner);
		addnav("Tickets");
		addnav("T?Ticket Booth","runmodule.php?module=amusementpark&op=ticket");
		if (get_module_pref("entered","parkprizes")==0 || get_module_pref("stamped","amusementpark")==1) villagenav();
		else addnav("Leave the Park","runmodule.php?module=amusementpark&op=leave");
		$session['user']['specialinc'] = "";
	}elseif($op=="street1"||$op=="amusementpark" || $op=="street2" || $op=="street3" || $op=="street4"|| $op==""){
		output_notl("`n`@");
		switch (e_rand(1,6)){
			case 1:
				output("You've been hit with a Cream Pie! You're less charming.");
				output("`n`n`@You `&lose %s charm`@.",$charm);
				$session['user']['charm']-=$charm;
			break;
			case 2:
				output("You've been hit with a Cream Pie! It's going to take some time to clean up.");
				output("`n`n`@You `&lose 2 turns`@.");
				$session['user']['turns']-=2;
			break;
			case 3:
				output("You've been hit with a Cream Pie! Several villagers start licking cream off you. You're more charming.");
				output("`n`n`@You `&gain %s charm`@.",$charm);
				$session['user']['charm']+=$charm;
			break;
			case 4:
				output("You've been hit with a Cream Pie and it gives you some protection!");
				apply_buff('creampie',array(
					"name"=>"`&Cream Pie",
					"rounds"=>15,
					"wearoff"=>"`&The remains of the Cream Pie finally fall off you!",
					"defmod"=>1.05,
					"roundmsg"=>"`^The Cream Coating protects you!",
				));
			break;
			case 5:
				output("You've been hit with a Cream Pie and it makes your weapon slippery.");
				apply_buff('creampie',array(
					"name"=>"`&Cream Pie",
					"rounds"=>15,
					"wearoff"=>"`&The remains of the Cream Pie finally fall off you!",
					"atkmod"=>0.95,
					"roundmsg"=>"`^The Cream Coating causes your weapon to slip in your grasp!",
				));
			break;
			case 6:
				output("You've had a Cream Pie thrown at you. Luckily, you dodge it.");
				output("`n`n`@You `&gain 2 turns`@.");
				$session['user']['turns']+=2;
			break;
		}
		increment_module_pref("rand");
		module_addeventhook("amusementpark","return 0;");
		addnav("Return to Amusement Park", "runmodule.php?module=amusementpark");
	}
	$session['user']['specialinc'] = "";	
}
function piestall_run(){
	global $session;
	page_header("The Pie Toss");
	$op=httpget('op');
	$gold=get_module_setting("gold");
	$name=get_module_setting("name");
	$thrown = get_module_pref("thrown");
	$hit = get_module_pref("hit");
	$throwmax = get_module_setting("throwmax");
	output("`b`c`@Pie Toss`b`c`n");
	if ($op=="piestall"){
		output("You look around the %s Tent`@ full of Cream Pies. The stall owner slyly suggests that you must know someone to throw one at.",$name);
		output_notl("`n`n");
		output("Then you notice the sign:`n`n");
		output("`c`#Throw a Pie for `^%s gold`@`c",$gold);
		addnav(array("%s",$name));
		addnav("Choose a Victim","runmodule.php?module=piestall&op=victim");
		addnav("Return to Midway", "runmodule.php?module=amusementpark&op=street1");
		addnav("Return to Amusement Park","runmodule.php?module=amusementpark");
	}
	if ($op=="victim"){
		addnav(array("%s",$name));
		if ($session['user']['gold']<$gold){
			output("You search through your pockets only to find you don't have the needed gold. Sighing, you leave the shop.");
			addnav("Return to Midway", "runmodule.php?module=amusementpark&op=street1");
			addnav("Return to Amusement Park","runmodule.php?module=amusementpark");
		}
		if ($thrown>=$throwmax){
			output("Sorry, you've reached the maximum number of throws today.");
			addnav("Return to Midway", "runmodule.php?module=amusementpark&op=street1");
			addnav("Return to Amusement Park","runmodule.php?module=amusementpark");
		}elseif ($thrown<$throwmax && $session['user']['gold']>=$gold){
			output("Taking your gold, the stall owner enquires who you have in mind.");
			$session['user']['gold']-=$gold;
			output_notl("`n`n");
			$victim = translate_inline("Victim");
			rawoutput("<form action='runmodule.php?module=piestall&op=victim1' method='POST'>");
			addnav("","runmodule.php?module=piestall&op=victim1");
			rawoutput("<input name='name' id='name'> <input type='submit' class='button' value='$victim'>");
			rawoutput("</form>");
			rawoutput("<script language='JavaScript'>document.getElementById('name').focus()</script>");
			addnav("Return to Midway", "runmodule.php?module=amusementpark&op=street1");
			addnav("Return to Amusement Park","runmodule.php?module=amusementpark");
		}
	}
	if ($op=="victim1"){
		addnav(array("%s",$name));
		$sql = "SELECT login,name,level,acctid FROM ".db_prefix("accounts"). " WHERE name = '".addslashes($_POST['name'])."' and acctid != ".$session['user']['acctid']." AND locked=0 ORDER BY level,login";
		$result = db_query($sql);
		if (db_num_rows($result) <> 1) {
			$string="%";
		for ($x=0;$x<strlen(httppost('name'));$x++){
			$string .= substr(httppost('name'),$x,1)."%";
   		}
		$sql = "SELECT login,name,level,acctid FROM ".db_prefix("accounts"). " WHERE name LIKE '".addslashes($string)."' and acctid != ".$session['user']['acctid']." AND locked=0 ORDER BY level,login";
		$result = db_query($sql);
		}
		if (db_num_rows($result)<=0){
			output("`2There is no one with that name.");
		}elseif(db_num_rows($result)>100){
			output("There are too many matches. Please try to narrow the search down a bit.`n`n");
			rawoutput("<form action='runmodule.php?module=piestall&op=victim1' method='POST'>");
			addnav("","runmodule.php?module=piestall&op=victim1");
			output("`2Choose your Victim?`n`n");
			rawoutput("<input name='name' id='name'> <input type='submit' class='button' value='Suchen'>",true);
			rawoutput("</form>");
			rawoutput("<script language='JavaScript'>document.getElementById('name').focus()</script>");
		}else{
			output("Which player did you mean?`n`n");
			rawoutput("<table cellpadding='3' cellspacing='0' border='0'>");
	   		rawoutput("<tr class='trhead'><td>Name</td><td>Level</td></tr>");
			for ($i=0;$i<db_num_rows($result);$i++){
				$row = db_fetch_assoc($result);
			rawoutput("<tr class='".($i%2?"trlight":"trdark")."'><td>");
			rawoutput("<a href='runmodule.php?module=piestall&op=victim3&victim=".HTMLEntities($row['acctid'])."'>");
			output_notl($row['name']);
			rawoutput("</a></td><td>");
			output($row['level']);
			rawoutput("</td></tr>");
			addnav("","runmodule.php?module=piestall&op=victim3&victim=".HTMLEntities($row['acctid']));
			}
		rawoutput("</table>",true);
		}
		addnav("Back to Stall", "runmodule.php?module=piestall&op=piestall");
		addnav("Return to Midway", "runmodule.php?module=amusementpark&op=street1");
		addnav("Return to Amusement Park","runmodule.php?module=amusementpark");
	}
	if ($op=="victim3"){
		addnav(array("%s",$name));
		$victim = httpget('victim');
		$sql = "SELECT * FROM ".db_prefix("accounts")." WHERE acctid = '$victim'";
		$res = db_query($sql);
		$row = db_fetch_assoc($res);
		$vname = $row['name'];
		set_module_pref("hit",1,"piestall",$victim);
		$thrownnew=$thrown+1;
		set_module_pref("thrown",$thrownnew);
		require_once("lib/systemmail.php");
		output("You have thrown a Cream Pie at %s`@!", $vname);
		systemmail($victim,"`^You have been Creamed!`@",array("`&%s`@ has thrown a Cream Pie at you!",$session['user']['name']));
		addnews("%s `#had some fun with %s `#at the Amusement Park",$session['user']['name'],$vname);
		addnav("Back to Stall", "runmodule.php?module=piestall&op=piestall");
		addnav("Return to Midway", "runmodule.php?module=amusementpark&op=street1");
		addnav("Return to Amusement Park","runmodule.php?module=amusementpark");
	}
	page_footer();
}
?>