<?php

function cottoncandy_getmoduleinfo(){
	$info = array(		"name" => "Cotton Candy",		"author" => "`b`&Ka`6laza`&ar`b, Tweaks by DaveS",		"version" => "1.1",		"category" => "Amusement Park",		"download"=>"http://dragonprime.net/index.php?module=Downloads;sa=dlview;id=1041",
		"description" => "Cotton Candy Stall",		"settings"=>array(			"Cotton Candy settings,title",			"name" => "What is the Name of the stall,int|`%Cotton `5Candy",
			"hp"=>"Hitpoint multiplier lost/gained by this event:,floatrange,0.02,0.48,0.2|.14",
			"charm"=>"Charm gained/lost by this event:,int|2",			"gold" => "Cost in gold, int|100",			"owner" => "Who runs this,int|`%Am`5ber`%le",			"maxvisit"=>"maximum number of visits,int|4",			),		"prefs"=>array(			"Cotton Candy user preferences, title",			"eaten"=>"Amount eaten:,int|0",
			"freecc"=>"How much free cotton candy has the player had today?,int|0",			),		"requires"=>array(
			"amusementpark" => "Amusement Park by Kalazaar (Amusement Park Package)",
			"parkprizes" => "Park Prizes by Kalazaar (Amusement Park Package)",
		),
	);	return $info;}
function cottoncandy_install(){	module_addhook("amusementpark-street3");	module_addhook("newday");	module_addeventhook("amusementpark","return 100;");	return true;}
function cottoncandy_uninstall(){	return true;}
function cottoncandy_dohook($hookname,$args){	global $session;	$name = get_module_setting("name");	switch ($hookname){		case "amusementpark-street3":			addnav(array("%s",$name),"runmodule.php?module=cottoncandy&op=cottoncandy");		break;		case "newday":
			if (get_module_pref("freecc")>0){
				module_addeventhook("amusementpark","return 100;");				set_module_pref("freecc",0);
			}
			set_module_pref("eaten",0);
		break;	}	return $args;}
function cottoncandy_runevent(){	global $session;	$op==httpget('op');	$session['user']['specialinc'] = "module:cottoncandy";		$name=get_module_setting("name");	$owner=get_module_setting("owner");	$hp=round($session['user']['hitpoints']*get_module_setting("hp"));
	$charm=get_module_setting("charm");	if (get_module_pref("entered","parkprizes")==0){
		addnav("Where Will You Go");
		$gold = get_module_setting("parkgold","amusementpark");
		$gems = get_module_setting("parkgem","amusementpark");
		output("`n`@You see a ticket booth with a sign reading:`n");
		output("`n`c`&Tickets for One Day of Entry:`n");
		if ($gold>0) output("`^%s Gold`n",$gold);
		if ($gems>0) output("`%%s Gem%s`n",$gems,translate_inline($gems>1?"s":""));
		if ($gold==0 && $gems==0) output("Free Entrance Today`n");
		output("`c`n`@If you're interested in going in then perhaps you should stop by and purchase a ticket.`n`n");
		output("%s`@ walks over to you and tells you to come visit the Cotton Candy Stand over by the Refreshments when you get into the park.`n`n",$owner);
		addnav("Tickets");
		addnav("T?Ticket Booth","runmodule.php?module=amusementpark&op=ticket");
		if (get_module_pref("entered","parkprizes")==0 || get_module_pref("stamped","amusementpark")==1) villagenav();
		else addnav("Leave the Park","runmodule.php?module=amusementpark&op=leave");
		$session['user']['specialinc'] = "";
	}elseif($op=="street1"||$op=="amusementpark" || $op=="street2" || $op=="street3" || $op=="street4"|| $op==""){		output("`n`@You Step in some Cotton Candy left on the ground");		switch (e_rand(1,6)){		case 1:			output("and you try to scrape it off. Unfortunately, you loose your balance and fall.");			if ($hp>0) output("`n`n`@You `\$lose %s hitpoint%s`@!",$hp,translate_inline($hp>1?"s":""));
			else output("`n`n`@Luckily it doesn't hurt you.");		break;		case 2:			output(" and you try to scrape it off. A couple of school girls giggle at you and you end up looking a little foolish.");			output("`n`n`@You `&lose %s charm`@.",$charm);
			$session['user']['charm']-=$charm;		break;		case 3:			output("and you look around quickly.  You realise nobody else has noticed so you walk quickly to the nearest public amenity and wash up.");			output("`n`n`@You `&gain %s charm`@.",$charm);
			$session['user']['charm']+=$charm;		break;		case 4:			output(" and have memories of your childhood. Mmmmmmm... Cotton Candy, wonder where that booth is?");			addnav(array("To %s",$name),"runmodule.php?module=cottoncandy&op=cottoncandy");			$session['user']['specialinc'] = "";		break;		case 5:			output(" ewwww! You look up to see %s `@watching you. She comes over and offers you a free cotton candy!",$owner);			addnav("Collect Freebie", "runmodule.php?module=cottoncandy&op=free");			$session['user']['specialinc'] = "";		break;		case 6:			output(" and with a great show of strength you pull your foot away from the mess, you feel great. You gain `@%s hitpoints`%.",$hp);
			$sesson['user']['hitpoints']+=$hp;		break;		}		increment_module_pref("freecc",1);
		if (get_module_pref("freecc")==1) module_addeventhook("amusementpark","return 66;");
		elseif (get_module_pref("freecc")==2) module_addeventhook("amusementpark","return 33;");
		elseif (get_module_pref("freecc")>=3) module_addeventhook("amusementpark","return 0;");
		addnav("Return to Amusement Park","runmodule.php?module=amusementpark"); 	 
	}	$session['user']['specialinc'] = "";}function cottoncandy_run(){	global $session;	$op=httpget('op');	$name=get_module_setting("name");	$owner=get_module_setting("owner");	$gold = get_module_setting("gold");	$maxvisit = get_module_setting("maxvisit");
	$hp=round($session['user']['hitpoints']*get_module_setting("hp"));
	$charm=get_module_setting("charm");	page_header("Cotton Candy");
	output("`%`c`bCotton Candy`b`c`n");	if ($op=="cottoncandy"){		if (get_module_pref("eaten")>=$maxvisit){			output("%s looks at you, \"You know too much is bad for you.\"",$owner);			output("`n`n`@You `&lose %s charm`@ and 2 turns.",$charm);
			$session['user']['charm']-=$charm;			$session['user']['turns']-=2;			apply_buff('greed',array(						"name"=>"`#Cotton Candy Greed",						"rounds"=>15,						"wearoff"=>"`&You shouldn't be so Greedy!",						"defmod"=>0.95,						"roundmsg"=>"`#The Curse of Greed affects your fighting!",						));			addnews("%s `#got greedy at the Amusement Park.",$session['user']['name']);
			addnav("Return to Refreshments","runmodule.php?module=amusementpark&op=street3");				addnav("Return to Amusement Park","runmodule.php?module=amusementpark");		}else{						output("`5You approach %s`5 and she points to a sign which tells you `^%s gold`5.",$owner,$gold);
			addnav("Cotton Candy"); 			addnav("Buy some Cotton Candy","runmodule.php?module=cottoncandy&op=buy");
			addnav("Return to Refreshments","runmodule.php?module=amusementpark&op=street3");				addnav("Return to Amusement Park","runmodule.php?module=amusementpark");		}	}	if ($op=="buy"){		if ($session['user']['gold']<$gold){			output("Digging through your pockets you find you don't have the gold, sighing you turn away");		}else{			$session['user']['gold']-=$gold;			output("%s,`5 passes you a giant blob of Cotton Candy on a stick",$owner);			increment_module_pref("eaten");			switch(e_rand(1,6)){				case 1:				output("You quickly gobble down all the Cotton Candy, oh you've got a sugar rush");				apply_buff('sugarrushes',array(						"name"=>"`#Sugar Rush",						"rounds"=>5,						"wearoff"=>"`&Your Sugar Rush wears off!",						"defmod"=>1.1,						"roundmsg"=>"`#Whoa that Cotton Candy packs a punch!",						));				break;				case 2:				output("You munch away on your Cotton Candy, noticing something sparkling out the corner of your eye. You wander over and pick up a `%gem`@!");				$session['user']['gems']++;				break;				case 3:				output("Wandering off happily eating your Cotton Candy, you suddenly crunch on something hard, you've chipped a tooth.");				output("`n`n`@You `&lose %s charm`@.",$charm);
				$session['user']['charm']-=$charm;				break;				case 4:				output("You start to gobble up your Cotton Candy, moments later, your stomach starts to ache.");				apply_buff('sugar',array(						"name"=>"`#Cotton Candy Stomach Ache",						"rounds"=>15,						"wearoff"=>"`&The pains subside!",						"defmod"=>0.95,						"roundmsg"=>"`#You double over in pain and cannot fight as well!",						));				break;				case 5:				output("Wandering off dreamily eating your Cotton Candy, you stumble over a rock on the ground and hit your head, loosing consciousness.");				if ($session['user']['turns']>2) $session['user']['turns']-=2;
				else $session['user']['turns']=0;				break;				case 6:				output("The sugar in the Cotton Candy makes you feel great, you think you could take on a whole hoard of creatures.");				$session['user']['turns']+=2;				break;			}		}
		addnav("Cotton Candy");		addnav("Return to Refreshments","runmodule.php?module=amusementpark&op=street3");		addnav("Return to Amusement Park","runmodule.php?module=amusementpark");
		if (get_module_pref("entered","parkprizes")==0) villagenav();
		else addnav("Leave the Park","runmodule.php?module=amusementpark&op=leave");	}	if ($op=="free"){		output("%s,`5 passes you a giant blob of Cotton Candy on a stick",$owner);			switch(e_rand(1,6)){				case 1:				output("You quickly gobble down all the Cotton Candy, oh you've got a sugar rush");				apply_buff('sugarrush',array(						"name"=>"`#Sugar Rush",						"rounds"=>15,						"wearoff"=>"`&Your Sugar Rush wears off!",						"defmod"=>1.05,						"roundmsg"=>"`#Whoa that Cotton Candy packs a punch!",						));				break;				case 2:				output("You munch away on your Cotton Candy, noticing something sparkling out the corner of your eye. You wander over and pick up a `%gem`@!");				$session['user']['gems']+=1;				break;				case 3:				output("Wandering off happily eating your Cotton Candy, you suddenly crunch on something hard. You've chipped a tooth!");				output("`n`n`@You `&lose %s charm`@.",$charm);
				$session['user']['charm']-=$charm;				break;				case 4:				output("You start to gobble up your Cotton Candy. Moments later, your stomach starts to ache.");				apply_buff('sugar',array(						"name"=>"`#Cotton Candy Stomach Ache",						"rounds"=>15,						"wearoff"=>"`&The pains subside!",						"defmod"=>0.95,						"roundmsg"=>"`#You double over in pain and cannot fight as well!",						));				break;				case 5:				output("Wandering off dreamily eating your Cotton Candy, you stumble over a rock on the ground and hit your head, loosing consciousness.");				if ($session['user']['turns']>2) $session['user']['turns']-=2;
				else $session['user']['turns']=0;				break;				case 6:				output("The sugar in the Cotton Candy makes you feel great. You think you could take on a whole hoard of creatures!");				$session['user']['turns']+=2;				break;			}
		addnav("Cotton Candy"); 
		if (get_module_pref("entered","parkprizes")==1){
			addnav("Return to Refreshments","runmodule.php?module=amusementpark&op=street3");			addnav("Return to Amusement Park","runmodule.php?module=amusementpark");
		}
		if (get_module_pref("entered","parkprizes")==0 || get_module_pref("stamped","amusementpark")==1) villagenav();
		else addnav("Leave the Park","runmodule.php?module=amusementpark&op=leave");	}	page_footer();}?>