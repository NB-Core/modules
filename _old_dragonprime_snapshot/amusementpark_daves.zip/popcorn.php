<?php  

function popcorn_getmoduleinfo(){ 	
	$info = array( 		
		"name" => "Popcorn",
		"author" => "`b`&Ka`6laza`&ar`b, with text edits by Vanessa, Tweaks by DaveS",
		"version" => "1.11",
		"category" => "Amusement Park",
		"download"=>"http://dragonprime.net/index.php?module=Downloads;sa=dlview;id=1041",
		"description" => "Popcorn Stall",
		"settings"=>array( 
			"Popcorn settings,title",
			"name" => "What is the Name of the stall?,text|`^P`&o`^pcorn`@",
			"gold" => "Cost in gold:,int|20",
			"owner" => "Who runs this Stall?,text|`\$Rosey",
			"maxvisit"=>"Maximum number of visits:,int|4",
		),
		"prefs"=>array(
			"Popcorn user preferences, title",
			"eaten"=>"Amount Eaten:,int|0",
			"freepopcorn"=>"How much free popcorn has the player had today?,int|0",
		),
		"requires"=>array(
			"amusementpark" => "Amusement Park by Kalazaar (Amusement Park Package)",
			"parkprizes" => "Park Prizes by Kalazaar (Amusement Park Package)",
		),
	); 
	return $info;
} 

function popcorn_install(){
 	module_addhook("amusementpark-street3");
	module_addhook("newday");
	module_addeventhook("amusementpark","return 100;");
	return true;
}

function popcorn_uninstall(){
 	return true;
}

function popcorn_dohook($hookname,$args){
 	global $session;
	$name = get_module_setting("name");
	switch ($hookname){
		case "amusementpark-street3":
			addnav(array("%s",$name),"runmodule.php?module=popcorn&op=popcorn");
		break;
		case "newday":
			set_module_pref("eaten",0);
			if (get_module_pref("freepopcorn")>0){
				set_module_pref("freepopcorn",0);
				module_addeventhook("amusementpark","return 100;");
			}
		break;
	 }
	return $args; 
}

function popcorn_runevent(){
 	global $session;
	$op==httpget('op');
	$session['user']['specialinc'] = "module:popcorn";
	$name=get_module_setting("name");
	$owner=get_module_setting("owner");
	$hp=round($session['user']['hitpoints']*0.06);
	if (get_module_pref("entered","parkprizes")==0){
		addnav("Where Will You Go");
		$gold = get_module_setting("parkgold","amusementpark");
		$gems = get_module_setting("parkgem","amusementpark");
		output("`n`@You see a ticket booth with a sign reading:`n");
		output("`n`c`&Tickets for One Day of Entry:`n");
		if ($gold>0) output("`^%s Gold`n",$gold);
		if ($gems>0) output("`%%s Gem%s`n",$gems,translate_inline($gems>1?"s":""));
		if ($gold==0 && $gems==0) output("Free Entrance Today`n");
		output("`c`n`@If you're interested in going in then perhaps you should stop by and purchase a ticket.`n`n");
		output("%s`@ walks over to you and tells you to come visit the Popcorn Stand over by the Refreshments when you get into the park.`n`n",$owner);
		addnav("Tickets");
		addnav("T?Ticket Booth","runmodule.php?module=amusementpark&op=ticket");
		if (get_module_pref("entered","parkprizes")==0 || get_module_pref("stamped","amusementpark")==1) villagenav();
		else addnav("Leave the Park","runmodule.php?module=amusementpark&op=leave");
		$session['user']['specialinc'] = "";
	}elseif($op=="street1"||$op=="amusementpark" || $op=="street2" || $op=="street3" || $op=="street4"|| $op==""){
		output("`@`nYou step in some Popcorn left on the ground");
		switch (e_rand(1,6)){
		case 1:
			output("and cringe hearing the crunch. You lose `\$%s hitpoints`@.",$hp); 
			$session['user']['hitpoints']-=$hp;
		break;
		case 2:
			output("and you try to scrape it off, looking a little foolish.");
			$session['user']['charm']-=2;
		break; 
		case 3:
			output("and look around quickly. You realise nobody else has noticed so you walk quickly to the nearest public amenity and wash up.");
			$session['user']['charm']+=2;
 		break; 		
		case 4: 		
			output("and it releases a lovely aroma. Mmmmm popcorn, wonder where that booth is?"); 		
			addnav(array("To Popcorn"),"runmodule.php?module=popcorn&op=popcorn"); 		
			$session['user']['specialinc'] = "";
		break; 		
		case 5: 		
			output("ewwww! You look up and see %s `@watching you. She comes over and offers you a free Popcorn.",$owner); 		
			addnav("Collect Freebie", "runmodule.php?module=popcorn&op=free"); 		
			$session['user']['specialinc'] = "";
		break; 		
		case 6: 		
			output("and with a great show of strength you pull your foot away from the mess, you feel great. You gain `@%s hitpoints`@.",$hp);		
			$sesson['user']['hitpoints']+=$hp;
		break; 	
		} 
		increment_module_pref("freepopcorn",1);
		if (get_module_pref("freepopcorn")==1) module_addeventhook("amusementpark","return 66;");
		elseif (get_module_pref("freepopcorn")==2) module_addeventhook("amusementpark","return 33;");
		elseif (get_module_pref("freepopcorn")>=3) module_addeventhook("amusementpark","return 0;");
		addnav("Return to Amusement Park","runmodule.php?module=amusementpark"); 	 
	}
	$session['user']['specialinc'] = ""; 
} 		 		 

function popcorn_run(){ 	
	global $session; 	
	$op=httpget('op'); 	
	$name=get_module_setting("name"); 	
	$owner=get_module_setting("owner"); 	
	$gold = get_module_setting("gold"); 	
	$maxvisit = get_module_setting("maxvisit"); 	
	page_header("Popcorn");
	output("`b`c`%Popcorn`b`c`n");
	if ($op=="popcorn"){ 		
		if (get_module_pref("eaten")>=$maxvisit){ 			
			output("%s looks at you, \"You know too much is bad for you.\"",$owner); 			
			$session['user']['charm']-=2; 			
			$session['user']['turns']-=1; 			
			apply_buff('greed',array( 						
				"name"=>"Popcorn Greed", 						
				"rounds"=>15, 						
				"wearoff"=>"`&You shouldn't be so Greedy!", 						
				"defmod"=>0.95, 						
				"roundmsg"=>"The Curse of Greed effects your fighting!",
				)); 			
			addnews("%s `#got greedy at the Amusement Park",$session['user']['name']);
			addnav("Popcorn");
			addnav("Return to Refreshments","runmodule.php?module=amusementpark&op=street3");			
			addnav("Return to Amusement Park","runmodule.php?module=amusementpark"); 		
		}else{			 			
			output("`5You approach %s`5 and she points to a sign which tells you`^ %s`5 gold`%.",$owner,$gold); 			
			addnav("Popcorn"); 			
			addnav("Buy some Popcorn","runmodule.php?module=popcorn&op=buy"); 
			addnav("Return to Refreshments","runmodule.php?module=amusementpark&op=street3");			
			addnav("Return to Amusement Park","runmodule.php?module=amusementpark"); 		
			} 	
		} 	
	if ($op=="buy"){
					
		if ($session['user']['gold']<$gold){ 				
			output("Digging through your pockets you find you don't have the gold, sighing you turn away."); 			 		
		}else{ 			
			$session['user']['gold']-=$gold; 			
			output("%s`5 passes you a large box of Popcorn.",$owner); 			
			$eaten = get_module_pref("eaten")+1; 			
			set_module_pref("eaten",$eaten); 			
			switch(e_rand(1,3)){ 				
				case 1: 				
					output("You quickly gobble down all the Popcorn. Oh, you've got a Crunching rush!"); 				
					apply_buff('crunchcrunch',array( 						
						"name"=>"Crunch Crunch", 						
						"rounds"=>12, 						
						"wearoff"=>"`&Your Crunch Crunch wears off!", 						
						"defmod"=>1.05, 						
						"roundmsg"=>"Whoa that Popcorn packs a punch!", 						
						)); 				
				break; 				
				case 2: 				
					output("You munch away on your Popcorn, noticing something sparkling out the corner of your eye. You wander over and pick up a `%gem`5."); 				
					$session['user']['gems']++; 				
				break; 				
						
				case 3: 				
					output("The butter in the Popcorn makes you feel great. You think you could take on a whole hoard of creatures."); 				
					$session['user']['turns']++; 				
				break; 			
			} 		
		}
		addnav("Popcorn"); 
		addnav("Return to Refreshments","runmodule.php?module=amusementpark&op=street3");
		addnav("Return to Amusement Park","runmodule.php?module=amusementpark"); 	
	} 	
	if ($op=="free"){ 		
		addnav(array("%s",$name)); 		
		output("%s,`5 passes you a large box of Popcorn.",$owner); 			
		switch(e_rand(1,3)){ 				
			case 1: 				
				output("Wandering off happily eating your Popcorn, you suddenly crunch on something hard, you've chipped a tooth"); 				
				$session['user']['charm']-=2; 				
			break; 				
			case 2: 				
				output("You start to gobble up your Popcorn, moments later, your stomach starts to ache"); 				
				apply_buff('popcornsickness',array( 						
					"name"=>"Popcorn Sickness", 						
					"rounds"=>15, 						
					"wearoff"=>"`&The pains subside!", 						
					"defmod"=>0.85, 						
					"roundmsg"=>"You double over in pain and cannot fight as well!", 						
					)); 				
			break; 				
			case 3: 				
				output("Wandering off dreamily eating your Popcorn, you stumble over a rock and spill all your Popcorn."); 				
				$session['user']['charm']--; 				
			break; 				
					
		}
		addnav("Popcorn"); 
		if (get_module_pref("entered","parkprizes")==1){
			addnav("Return to Refreshments","runmodule.php?module=amusementpark&op=street3");			addnav("Return to Amusement Park","runmodule.php?module=amusementpark");
		}
		if (get_module_pref("entered","parkprizes")==0 || get_module_pref("stamped","amusementpark")==1) villagenav();
		else addnav("Leave the Park","runmodule.php?module=amusementpark&op=leave");
	}
page_footer(); 
} 
?>		