<?php

function dragonride_getmoduleinfo(){
	$info = array(
		"name" => "Dragon Ride",
		"author" => "`b`&Ka`6laza`&ar`b, Tweaks by DaveS",
		"version" => "1.11",
		"category" => "Amusement Park",
		"download"=>"http://dragonprime.net/index.php?module=Downloads;sa=dlview;id=1041",
		"description" => "Dragon Ride",
		"settings"=>array(
			"Dragon Ride settings,title",
			"name" => "What is the name of the stall?,text|Dragon Rides",
			"owner" => "Who runs the ride?,text|`b`#Cryshalsing`b",
			"dname"=>"What is the name of the dragon?,text|`b`\$C`^h`!r`&o`)m`6o`@s`b`0",
			"hp"=>"Hitpoint multiplier lost/gained by this event:,floatrange,0.02,0.48,0.2|.14",
			"charm"=>"Charm gained/lost by this event:,int|2",
			"gold" => "Cost in gold:, int|1000",
			"maxvisit" => "Maximum number of times to try a day:,int|3",
			),
		"prefs"=>array(
			"Dragon Ride user preferences, title",
			"visit"=>"Times player has ridden the Dragon today:,int|0",
			"rand"=>"Has player encountered the random event today?,bool|0",
			),
		"requires"=>array(
			"amusementpark" => "Amusement Park by Kalazaar (Amusement Park Package)",
			"parkprizes" => "Park Prizes by Kalazaar (Amusement Park Package)",
		),
	);
	return $info;
}
function dragonride_install(){
	module_addhook("amusementpark-street2");
	module_addhook("newday");
	module_addeventhook("amusementpark","return 100;");
	return true;
}
function dragonride_uninstall(){
	return true;
}
function dragonride_dohook($hookname,$args){
	global $session;
	switch ($hookname){
		case "amusementpark-street2":
			addnav("Dragon Ride","runmodule.php?module=dragonride&op=dragonride");
			break;
		case "newday":
			if (get_module_pref("rand")==1) module_addeventhook("amusementpark","return 100;");
			set_module_pref("rand",0);
			set_module_pref("visit",0);
			break;
	}
	return $args;
}
function dragonride_runevent(){
	global $session;
	$op=httpget('op');
	$session['user']['specialinc'] = "module:dragonride";	
	$name=get_module_setting("name");
	$owner=get_module_setting("owner");
	$dname=get_module_setting("dname");
	$hp=round($session['user']['hitpoints']*0.15);
	if (get_module_pref("entered","parkprizes")==0){
		addnav("Where Will You Go");
		$gold = get_module_setting("parkgold","amusementpark");
		$gems = get_module_setting("parkgem","amusementpark");
		output("`n`@You see a ticket booth with a sign reading:`n");
		output("`n`c`&Tickets for One Day of Entry:`n");
		if ($gold>0) output("`^%s Gold`n",$gold);
		if ($gems>0) output("`%%s Gem%s`n",$gems,translate_inline($gems>1?"s":""));
		if ($gold==0 && $gems==0) output("Free Entrance Today`n");
		output("`c`n`@If you're interested in going in then perhaps you should stop by and purchase a ticket.`n`n");
		output("%s`@ walks over to you and tells you to come visit the Dragon Ride over by Rides N Stuff and take a ride on %s`@ when you get into the park.`n`n",$owner,$dname);
		addnav("Tickets");
		addnav("T?Ticket Booth","runmodule.php?module=amusementpark&op=ticket");
		if (get_module_pref("entered","parkprizes")==0 || get_module_pref("stamped","amusementpark")==1) villagenav();
		else addnav("Leave the Park","runmodule.php?module=amusementpark&op=leave");
		$session['user']['specialinc'] = "";
	}elseif($op=="street1"||$op=="amusementpark" || $op=="street2" || $op=="street3" || $op=="street4"|| $op==""){
		output("`n`@You look up to see %s`@ the Dragon flying  gracefully with someone riding on his back.",$dname);
		switch (e_rand(1,3)){
			case 1:
			output("A stranger runs up to you and pushes a ticket into your hand!");
			addnav("What Will You Do");
			addnav("Free DragonRide!","runmodule.php?module=dragonride&op=dragonridefree");
			$session['user']['specialinc'] = "";
			break;
			case 2:
			output("Suddenly, someone falls off %s`@ and you nimbly dodge the body. You feel invigorated and `bgain %s hitpoints`b!",$dname,$hp);
			$session['user']['hitpoints']+=$hp;
			break;
			case 3:
			output("Suddenly, someone falls off %s`@ but you fail to move out of the way! You lose `\$%shitpoints`@.",$dname,$hp);
			$session['user']['hitpoints']-=$hp;
			break;
		}
		set_module_pref("rand",1);
		module_addeventhook("amusementpark","return 0;");
		addnav("Return to Amusement Park", "runmodule.php?module=amusementpark"); 
	}
	$session['user']['specialinc'] = "";
}
function dragonride_run(){
	global $session;
	page_header("Dragon Ride");
	$name=get_module_setting("name");
	$owner=get_module_setting("owner");
	$dname=get_module_setting("dname");
	$gold = get_module_setting("gold");
	$maxvisit = get_module_setting("maxvisit");
	$visit = get_module_pref("visit");
	$charm=get_module_setting("charm");
	$hp=round($session['user']['hitpoints']*get_module_setting("hp"));
	$park = get_module_setting("parkname","amusementpark");
	$op=httpget('op');
	output("`b`c`@Dragon Ride`b`c`n");
	if ($op=="dragonride"){
		output("You see %s`@ grinning at you, a keg of Mead beside him (it looks empty!)",$owner);
		output("`n`nHe looks up at you and smiles. `#'Would you like to take a ride on the great dragon %s`#?'`@",$dname);
		output("`n`nYou look over and notice a huge ancient dragon with a flimsy harness on his back.");
		output("`n`n`#'It only costs `^%s gold`# for the ride of your lifetime.'",$gold);
		addnav("Dragon Ride");
		addnav("Take a Ride", "runmodule.php?module=dragonride&op=ride");
		addnav("Ummm I don't think so", "runmodule.php?module=amusementpark");
	}
	if ($op=="ride"){
		addnav(array("%s",$name));
		if ($session['user']['gold']<$gold){
			output("%s`@ looks at your empty hand and as you turn to leave, %s`@ tries to eat you.",$owner,$dname);
			addnav("Run!!", "runmodule.php?module=amusementpark"); 
		}elseif ($visit>=$maxvisit){
			output("%s`@ thinks you look familiar. `#'Hey! You've had enough rides for one day!' `@Gulping, you realize you may be lunch and hightail it out of there.",$owner);
			addnav("Run!!", "runmodule.php?module=amusementpark");
		}else{
		output("%s`@, invites you to hop on.",$owner);
		$session['user']['gold']-=$gold;
		increment_module_pref("visit");
		$ride = e_rand(1,3);
		$ffloss=round($session['user']['turns']*0.2);
		$goldloss = round($session['user']['gold']*0.2);
		output("Climbing up on the huge Dragon's back you prepare yourself for the ride. Turning to look at you over his shoulder, %s`@ suddenly launches himself into the air.`n`n",$dname);
			if ($ride==1){
				output("Feeling slightly queasy from the take-off, you look upon the forest, it seems so small from so high up.... GULP!!");
				output_notl("`n`n");
				output("Circling a few times %s `@comes in to land. You get a case of 'air sickness'.",$dname);
				$session['user']['hitpoints']-=$hp;
				$session['user']['turns']-=$ffloss;
				$session['user']['gold']-=$goldloss;
				output_notl("`n`n");
				output("Clambering down from %s's `@back, you realize you really don't feel all that well.",$dname);
				output("You stumble over to a nearby fence and clutch onto it for support.");
				if($goldloss>0) output("You don't notice that your gold pouch has worked its way open and you `^lose %s gold`@.",$goldloss);
				if ($goldloss>0) output("`n`nWhen you go to pick up the gold, you hit your head on the fence.");
				else output("`n`nYou bend over with a stomach ache and hit your head on the fence.");
				if($hp>0) output("You `\$lose %s hitpoint%s`@!",$hp,translate_inline($hp>1?"s":""));
				else output("Luckily, it didn't hurt you too much.");
				if ($ffloss>0) output("`n`nYou spend `\$%s turn%s`@ rubbing your head.",$ffloss,translate_inline($ffloss>1?"s":""));
			}
			if ($ride==2){
				output("Wow, this is great, you feel so exhilarated! Punching the air, you let %s`@ know how great this feels. He does a barrel roll and swoops down in a sudden nose dive towards the forest.",$dname);
				output_notl("`n`n");
				output("Holding on tightly, you feel a slight sense of foreboding as %s`@plummets towards the ground.. Just as suddenly he veers to the left and upwards. You whoop for joy; this is the Best!!",$dname);
				output_notl("`n`n");
				output("Slowing down slightly, %s`@ heads back to %s`@. Suddenly he swerves to the left, and then drops from the sky, skidding to a sudden halt, almost throwing you from his back!",$dname,$park);
				output_notl("`n`n");
				output("Clambering off you thank him for such a great ride, and head back to %s.",$park);
				$session['user']['turns']+=5;
				$session['user']['charm']+=2;
			}
			if ($ride==3){
				output("Wow, this is great, you feel so exhilarated.. punching the air you let %s`@ know how great this feels, he does a barrel roll and swoops down in a sudden nose dive, towards the forest.",$dname);
				output_notl("`n`n");
				output("You suddenly find yourself freefalling towards the forest. %s`@ swoops down, faster and faster, and you can see his jaws opening. Oh no! You're lunch!",$dname);
				output_notl("`n`n");
				output("Just as %s`@ is about to take a bite out of you, you grab the harness to swing out of those perilous jaws and slow your landing. You still hit the ground pretty hard.");
				if ($hp>0) output("`n`nYou `\$lose %s hitpoint%s`@.",$hp,translate_inline($hp>1?"s":""));
				output("`n`nYou `&lose 2 charm`@ because you're very dusty now.");
				$session['user']['hitpoints']-=$hp;
				$session['user']['charm']-=2;
			}
		if (get_module_pref("visit")<get_module_setting("maxvisit")) addnav("Ride Again!","runmodule.php?module=dragonride&op=dragonride"); 
		addnav("Return to Rides N Stuff", "runmodule.php?module=amusementpark&op=street2");
		addnav("Return to Amusement Park", "runmodule.php?module=amusementpark"); 
	}
}
if ($op=="dragonridefree"){
	output("%s`@ invites you to hop on %s`@ for a free ride.",$owner,$dname);
		output_notl("`n`n");
		$ride = e_rand(1,3);
		$hp=round($session['user']['hitpoints']*get_module_setting("hp"));
		$ffloss=round($session['user']['turns']*0.2);
		$goldloss = round($session['user']['gold']*0.2);
		output("Climbing up on the huge Dragon's back you prepare yourself for the ride. Turning to look at you over his shoulder, %s`@ suddenly launches himself into the air.`n`n",$dname);
			if ($ride==1){
				output("Feeling slightly queasy from the take-off, you look upon the forest, it seems so small from so high up.... GULP!!");
				output_notl("`n`n");
				output("Circling a few times %s `@comes in to land. You get a case of 'air sickness'.",$dname);
				$session['user']['hitpoints']-=$hp;
				$session['user']['turns']-=$ffloss;
				$session['user']['gold']-=$goldloss;
				output_notl("`n`n");
				output("Clambering down from %s's `@back, you realize you really don't feel all that well.",$dname);
				output("You stumble over to a nearby fence and clutch onto it for support.");
				if($goldloss>0) output("You don't notice that your gold pouch has worked its way open and you `^lose %s gold`@.",$goldloss);
				if ($goldloss>0) output("`n`nWhen you go to pick up the gold, you hit your head on the fence.");
				else output("`n`nYou bend over with a stomach ache and hit your head on the fence.");
				if($hp>0) output("You `\$lose %s hitpoint%s`@!",$hp,translate_inline($hp>1?"s":""));
				else output("Luckily, it didn't hurt you too much.");
				if ($ffloss>0) output("`n`nYou spend `\$%s turn%s`@ rubbing your head.",$ffloss,translate_inline($ffloss>1?"s":""));
			}
			if ($ride==2){
				output("Wow, this is great, you feel so exhilarated! Punching the air, you let %s`@ know how great this feels. He does a barrel roll and swoops down in a sudden nose dive towards the forest.",$dname);
				output_notl("`n`n");
				output("Holding on tightly, you feel a slight sense of foreboding as %s`@plummets towards the ground.. Just as suddenly he veers to the left and upwards. You whoop for joy; this is the Best!!",$dname);
				output_notl("`n`n");
				output("Slowing down slightly, %s`@ heads back to %s`@. Suddenly he swerves to the left, and then drops from the sky, skidding to a sudden halt, almost throwing you from his back!",$dname,$park);
				output_notl("`n`n");
				output("Clambering off you thank him for such a great ride, and head back to %s.",$park);
				$session['user']['turns']+=5;
				output("`n`n`@You `&gain %s charm`@.",$charm);
				$session['user']['charm']+=$charm;
			}
			if ($ride==3){
				output("Wow, this is great, you feel so exhilarated.. punching the air you let %s`@ know how great this feels, he does a barrel roll and swoops down in a sudden nose dive, towards the forest.",$dname);
				output_notl("`n`n");
				output("You suddenly find yourself freefalling towards the forest. %s`@ swoops down, faster and faster, and you can see his jaws opening. Oh no! You're lunch!",$dname);
				output_notl("`n`n");
				output("Just as %s`@ is about to take a bite out of you, you grab the harness to swing out of those perilous jaws and slow your landing. You still hit the ground pretty hard.");
				if ($hp>0) output("`n`nYou `\$lose %s hitpoint%s`@.",$hp,translate_inline($hp>1?"s":""));
				output("`n`nYou `&lose 2 charm`@ because you're very dusty now.");
				$session['user']['hitpoints']-=$hp;
				output("`n`n`@You `&lose %s charm`@.",$charm);
				$session['user']['charm']-=$charm;
			}
			addnav("Dragon Ride");
			addnav("Return to Amusement Park", "runmodule.php?module=amusementpark"); 
	}

	page_footer();
}
?>