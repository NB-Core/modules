<?php

function drinksbooth_getmoduleinfo(){
	$info = array(
		"name" => "Drinks Booth",
		"author" => "`b`&Ka`6laza`&ar`b, Tweaks by Vanessa and DaveS",
		"version" => "1.11",
		"category" => "Amusement Park",
		"download"=>"http://dragonprime.net/index.php?module=Downloads;sa=dlview;id=1041",
		"description" => "Drinks Booth",
		"settings"=>array(
			"Drinks Booth settings,title",
			"gold" => "Gold cost per drink:, int|15",
			"hp"=>"Hitpoint multiplier lost/gained by this event:,floatrange,0.02,0.48,0.2|.14",
			"charm"=>"Charm gained/lost by this event:,int|2",
			"owner" => "Who runs the Drinks Booth (male)?,text|`i`!Hector`i",
			),
		"prefs"=>array(
			"drinksbooth"=>"Has the user had a drink today?,bool|0",
			"freedrink"=>"How many free drinks has the player had today?,int|0",
		),
		"requires"=>array(
			"amusementpark" => "Amusement Park by Kalazaar (Amusement Park Package)",
			"parkprizes" => "Park Prizes by Kalazaar (Amusement Park Package)",
		),
	);
	return $info;
}
function drinksbooth_install(){
	module_addhook("amusementpark-street3");
	module_addeventhook("amusementpark","return 100;");
	module_addhook("newday");
	return true;
}
function drinksbooth_uninstall(){
	return true;
}
function drinksbooth_dohook($hookname,$args){
	global $session;
	switch ($hookname){
		case "amusementpark-street3":
			addnav("Drinks Booth","runmodule.php?module=drinksbooth&op=booth");
		break;
		case "newday":
			set_module_pref("drinksbooth",0);
			if (get_module_pref("freedrink")>0){
				set_module_pref("freedrink",0);
				module_addeventhook("amusementpark","return 100;");
			}
		break;
	}
	return $args;
}
function drinksbooth_runevent(){
	global $session;
	$op==httpget('op');
	$session['user']['specialinc'] = "module:drinksbooth";
	$owner=get_module_setting("owner");
	$hp=round($session['user']['hitpoints']*get_module_setting("hp"));
	$charm=get_module_setting("charm");
	if (get_module_pref("entered","parkprizes")==0){
		addnav("Where Will You Go");
		$gold = get_module_setting("parkgold","amusementpark");
		$gems = get_module_setting("parkgem","amusementpark");
		output("`n`@You see a ticket booth with a sign reading:`n");
		output("`n`c`&Tickets for One Day of Entry:`n");
		if ($gold>0) output("`^%s Gold`n",$gold);
		if ($gems>0) output("`%%s Gem%s`n",$gems,translate_inline($gems>1?"s":""));
		if ($gold==0 && $gems==0) output("Free Entrance Today`n");
		output("`c`n`@If you're interested in going in then perhaps you should stop by and purchase a ticket.`n`n");
		output("%s`@ walks over to you and tells you to come visit the Drinks Booth over by the Refreshments when you get into the park.`n`n",$owner);
		addnav("Tickets");
		addnav("T?Ticket Booth","runmodule.php?module=amusementpark&op=ticket");
		if (get_module_pref("entered","parkprizes")==0 || get_module_pref("stamped","amusementpark")==1) villagenav();
		else addnav("Leave the Park","runmodule.php?module=amusementpark&op=leave");
		$session['user']['specialinc'] = "";
	}elseif($op=="street1"||$op=="amusementpark" || $op=="street2" || $op=="street3" || $op=="street4"|| $op==""){
		output("`n%s`@ offers you a free drink. You",$owner);
		switch (e_rand(1,4)){
			case 1:
				output("decline the offer and %s `@ pings you with a Skittle. `\$Ouch!`@",$owner);
				if ($hp>0) output("`n`n`@You `\$lose %s hitpoint%s`@!",$hp,translate_inline($hp>1?"s":""));
				else output("`n`n`@Luckily it doesn't hurt you.");
			break;
			case 2:
				output("politely explain you've had enough to drink today.  That's so charming!");
				output("`n`n`@You `&gain %s charm`@.",$charm);
				$session['user']['charm']+=$charm;
			break;
			case 3:
				output("accept and drink it down.  Suddenly, you don't feel so good.");
				if ($session['user']['turns']>1){
					output("`n`nYou lose 2 turns.");
					$session['user']['turns']-=2;
				}else{
					if ($hp>0) output("`n`n`@You `\$lose %s hitpoint%s`@!",$hp,translate_inline($hp>1?"s":""));
					else output("`n`n`@Luckily it doesn't hurt you.");
					$session['user']['hitpoints']-=$hp;
				}
			break;
			case 4:
				output("accept the drink and you feel great!!");
				output("`n`nYou `bgain %s hitpoint%s`b!",$hp,translate_inline($hp>1?"s":""));
				$sesson['user']['hitpoints']+=$hp;
			break;
		}
		increment_module_pref("freedrink",1);
		$session['user']['specialinc'] = "";
		addnav("Return to Amusement Park", "runmodule.php?module=amusementpark");
		if (get_module_pref("freedrink")==1) module_addeventhook("amusementpark","return 66;");
		elseif (get_module_pref("freedrink")==2) module_addeventhook("amusementpark","return 33;");
		elseif (get_module_pref("freedrink")>=3) module_addeventhook("amusementpark","return 0;");
	}
}
function drinksbooth_run(){
	global $session;
	$op=httpget('op');
	$op2=httpget('op2');
	$owner=get_module_setting("owner");
	$gold = get_module_setting("gold");
	page_header("Drinks Booth");
	output("`b`c`%Drinks Booth`b`c`n");
	if ($op=="booth"){
		if (get_module_pref("drinksbooth")==1) output("You approach %s`@ but he recognizes you... Hey! You've had enough to drink today.`n`n",$owner);
		else{
			output("You approach %s`%. He points to a sign and tells you `#'Drinks cost `^%s`# gold each, so tell me what you want.'`@",$owner,$gold);
			addnav("Drinks Booth");
			addnav("S?Ye Old Soda","runmodule.php?module=drinksbooth&op=drink&op2=soda");
			addnav("C?Coco","runmodule.php?module=drinksbooth&op=drink&op2=coco");
			addnav("L?Lemonade","runmodule.php?module=drinksbooth&op=drink&op2=lemonade");
			addnav("o?Coffee","runmodule.php?module=drinksbooth&op=drink&op2=coffee");
		}
	}
	if ($op=="drink"){
		if ($session['user']['gold']<$gold) output("You dig through your pockets and find you don't have the gold. Suddenly, %s `@throws you out of the booth.",$owner);
		else{
			if ($op2=="soda") output("You take your soda and gulp it down.`n`n");
			if ($op2=="coco") output("You sip on your coco, it hitting the spot on this cold day.`n`n");
			if ($op2=="lemonade") output("Your face puckers at the sourness of the lemonade.`n`n");
			if ($op2=="coffee") output("You walk around drinking your coffee, looking for some doughnuts.`n`n");
			set_module_pref("drinksbooth",1);
			$session['user']['gold']-=$gold;
		}
	}
	addnav("Leave");
	addnav("Return to Refreshments", "runmodule.php?module=amusementpark&op=street3");
	addnav("Return to Amusement Park", "runmodule.php?module=amusementpark");
	if (get_module_pref("entered","parkprizes")==0 || get_module_pref("stamped","amusementpark")==1) villagenav();
	else addnav("Leave the Park","runmodule.php?module=amusementpark&op=leave");
	page_footer();
}
?>