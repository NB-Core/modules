<?php

function adveqedit_getmoduleinfo(){
	$info = array(
		"name"=>"Advanced Equipment Editor",
		"author"=>"Chris Vorndran",
		"category"=>"Administrative",
		"version"=>"1.01",
		"download"=>"http://dragonprime.net/index.php?module=Downloads;sa=dlview;id=50",
		"vertxtloc"=>"http://dragonprime.net/users/Sichae/",
		"settings"=>array(
			"Advanced Equipment Editor,title",
				"top"=>"How many open boxes are shown in editing?,int|15",
				"ahead"=>"How far ahead can weapons be created?,int|5",
				"dk"=>"Display DK Titles?,bool|1",
				"Turning this off should reduce server load.,note",
		),
	);
	return $info;
}
function adveqedit_install(){
	module_addhook("superuser");
	return true;
}
function adveqedit_uninstall(){
	return true;
}
function adveqedit_dohook($hookname,$args){
	global $session;
	switch ($hookname){
		case "superuser":
			if ($session['user']['superuser'] & SU_EDIT_EQUIPMENT){
				addnav("Editors");
				addnav("Weapon/Armor Editor","runmodule.php?module=adveqedit");
				blocknav("armoreditor.php");
				blocknav("weaponeditor.php");
			}
			break;
		}
	return $args;
}
function adveqedit_run(){
	global $session;
	
	$op = httpget('op');
	$level = (int)httpget('level');
	$eq_type = httpget('eq_type');
	$id = httppost('id');
	
	$header = $eq_type;
	if ($header == "") $header = translate_inline("Equipment");
	
	$db = $eq_type;
	if ($db == "weapon") $db = "weapons";

	if ($eq_type == "weapon"){
		$id = "weaponid";
		$name = "weaponname";
		$type = "damage";
	}else{
		$id = "armorid";
		$name = "armorname";
		$type = "defense";
	}
	$values = array(1=>48,225,585,990,1575,2250,2790,3420,4230,5040,5850,6840,8010,9000,10350);
	
	page_header(array("%s Editor",ucfirst($header)));
	require_once("lib/superusernav.php");
	superusernav();
	addnav("Equipment Editor");
	addnav("Weaponry","runmodule.php?module=adveqedit&eq_type=weapon");
	addnav("Armory","runmodule.php?module=adveqedit&eq_type=armor");
	if ($op == "edit"){
		$sql = "SELECT * FROM ".db_prefix($db)." WHERE level='$level' ORDER BY $type ASC";
		$res = db_query($sql);
		rawoutput("<form action='runmodule.php?module=adveqedit&op=save-edit&subop=edit&eq_type=$eq_type&level=$level' method='post'>");
		$top = db_num_rows($res);
		if ($top < get_module_setting("top")) $top = get_module_setting("top");
		for ($i = 1; $i <= $top; $i++){
			$row = db_fetch_assoc($res);
			output("%s Name: `n",translate_inline(ucfirst($eq_type)));
			rawoutput("<textarea rows='1' name='name-$i'>".$row[$name]."</textarea><br>");
			output("%s: ",translate_inline(ucfirst($type)));
			rawoutput(adveqedit_bar($i,$row[$type]));
			if ($i <= $top) rawoutput("<br><br>");
		}
		rawoutput("<input type='submit' class='button' value='".translate_inline("Save")."'>");
		rawoutput("</form>");
		addnav("","runmodule.php?module=adveqedit&op=save-edit&subop=edit&eq_type=$eq_type&level=$level");
	}
	if ($op == "add"){
		// Borrowed from armoreditor.php
		if ($eq_type == "weapon"){
			$array = array(
				"Weapon,title",
				"weaponid"=>"Weapon ID,hidden",
				"weaponname"=>"Weapon Name",
				"damage"=>"Damage,range,1,15,1"
			);
		}elseif($eq_type == "armor"){
			$array = array(
				"Armor,title",
				"armorid"=>"Armor ID,hidden",
				"armorname"=>"Armor Name",
				"defense"=>"Defense,range,1,15,1"
			);
		}
		$sql = "SELECT max($type+1) AS $type FROM ".db_prefix($db)." WHERE level=$level";
		$res = db_query($sql);
		$row = db_fetch_assoc($res);
		rawoutput("<form action='runmodule.php?module=adveqedit&op=save-add&eq_type=$eq_type&level=$level' method='POST'>");
		addnav("","runmodule.php?module=adveqedit&op=save-add&eq_type=$eq_type&level=$level");
		require_once("lib/showform.php");
		showform($array,$row);
		rawoutput("</form>");
	}
	if ($op == "save-edit"){
		$all = httpallpost();
		$names = array();
		$sub = array();
		foreach($all AS $name => $value){
			$a = explode("-",$name);
			if ($a[0] == "sub") array_push($sub,$value);
			if ($a[0] == "name") array_push($names,$value);
		}
		$sub = array_unique($sub);
		$names = array_unique($names);
		$eq_name = $eq_type."name";
		foreach($names AS $key => $val){
			$a = $key+1;
			if ($val == "") db_query("DELETE FROM ".db_prefix($db)." WHERE level=$level AND $type='$a'");
			$sql = "SELECT $id FROM ".db_prefix($db)." WHERE $eq_name='$val'";
			$res = db_query($sql);
			$row = db_fetch_assoc($res);
			if (db_num_rows($res) > 0){
				$sql = "UPDATE ".db_prefix($db)." 
				SET $eq_name='$val',
				$type='$sub[$key]'
				WHERE $id={$row[$id]}";
			}elseif($val != ""){
				$b = $sub[$key];
				$sql = "INSERT INTO ".db_prefix($db)." 
				(level,$type,$eq_name,value) 
				VALUES ($level,$b,\"$val\",".$values[$b].")";
			}
			db_query($sql);
		}
		$op = "";
		httpset('op',$op);
	}
	if ($op == "save-add"){
		if ($eq_type == "weapon"){
			$b = httppost('weaponname');
			$c = httppost('damage');
		}elseif($eq_type == "armor"){
			$b = httppost('armorname');
			$c = httppost('defense');		
		}
		$sql = "INSERT INTO ".db_prefix($db)." 
		(level,$type,$name,value) 
		VALUES ($level,\"$c\",\"$b\",".$values[$c].")";
		db_query($sql);
		$op = "";
		httpset('op',$op);
	}
	if ($eq_type != "" && $op == ""){
		$eq_name = $eq_type."name";
		$eq_sub = ($eq_type == "weapon"?"damage":"defense");
		$sql = "DELETE FROM ".db_prefix($db)." WHERE $eq_name='' OR $eq_sub=''";
		db_query($sql);
		$sql = "SELECT DISTINCT level FROM ".db_prefix($db)." ORDER BY level ASC";
		$res = db_query($sql);
		$ops = translate_inline("Ops");
		$dk = translate_inline("DK");
		$amount = translate_inline("Amount");
		$delconfirm = sprintf("Are you sure you wish to delete these %ss?",$eq_type);
		$dk_title = translate_inline("DK Title (M/F)");
		$td = "<td align='center'>";
		output("`#Here you shall be able to edit the armor and weapons of certain DKs.");
		if (get_module_setting("dk")) output("We provide you with the current DK title, so that you may select a certain type of weapons/armor to fit the DK title.");
		output("If you wish to delete entries, simply leave them blank or remove either the weapon/armor name or the damage/defense.`n`n");
		rawoutput("<table align='center' border=0 cellpadding=2 width='85%' cellspacing=1 bgcolor='#999999'>");
		rawoutput("<tr class='trhead'>$td$ops</td>$td$dk</td>$td$amount</td>");
		if (get_module_setting("dk")) rawoutput("$td$dk_title</td>");
		rawoutput("</tr>");
		$i = 0;
		while($row = db_fetch_assoc($res)){
			$i++;
			rawoutput("<tr class='".($i%2?"trdark":"trlight")."'>");
			rawoutput("$td");
			rawoutput("[ <a href='runmodule.php?module=adveqedit&op=edit&eq_type=$eq_type&level={$row['level']}'>");
			output("Edit ");
			rawoutput("</a> ]");
			addnav("","runmodule.php?module=adveqedit&op=edit&eq_type=$eq_type&level=".$row['level']);
			rawoutput("</td>$td");
			output_notl("%s",$row['level']);
			rawoutput("</td>$td");
			$sql_a = "SELECT count(*) AS count FROM ".db_prefix($db)." WHERE level='{$row['level']}'";
			$res_a = db_query($sql_a);
			$row_a = db_fetch_assoc($res_a);
			output_notl("%s",$row_a['count']);
			if (get_module_setting("dk")){
				rawoutput("</td>$td");
				require_once("lib/titles.php");
				$male = get_dk_title($row['level'],0);
				require_once("lib/titles.php");
				$female = get_dk_title($row['level'],1);
				output_notl("%s`0/%s`0",$male,$female);
			}
			rawoutput("</td></tr>");
		}
		rawoutput("</table>");
		$sql = "SELECT max(level+1) AS level FROM ".db_prefix($db);
		$res = db_query($sql);
		$row = db_fetch_assoc($res);
		$max = $row['level'];
		addnav("Add");
		addnav(array("Add %s at %s DKs",
			ucfirst($eq_type),
			($max)),
			"runmodule.php?module=adveqedit&eq_type=$eq_type&op=add&level=".($max));
	}
	page_footer();
}
function adveqedit_bar($i,$cur){
	$bar = "<select name='sub-$i'>";
	for ($i = 1; $i <= 15; $i++){
		$bar .= ("<option value='$i'".($i==$cur?" selected":"").">".HTMLEntities("$i")."</option>");
	}
	$bar .= "</select>";
	return $bar;
}
?>