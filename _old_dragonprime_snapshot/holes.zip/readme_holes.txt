/****************************************************
	Game: 		LotGD
	Version:	0.9.7/0.9.7+jt
	Patch: 		Holes (special)
	Author: 	Borge Alvestad aka BraveBrain
	Date: 		February 20th 2004

	Upload this file as:
				/special/holes.php
	Affected files:
				/patchsettings.php
	Required files:
				/patchsettings.php

	Description:
	This patch is to act as a special.
	It adds a certain amount of holes (5 by default)
	in which players can fall and loose random hp.
	If the players die their gold is left in the specific hole.
	If the players survive they get any gold (up to max) that
	might be in the hole, and they get an option to check another hole.
	There's a 1 in 30 chance that the players find a gem if he/she survives.

	Note! This patch is full of comments in order to help newbies learn to make their own patches or at least get a better understanding of what this script does.

*//****************************************************/

Changes syntax:
CHANGE HELP:
[IN FILE] => The file to modify
[FIND (#)] => The code to find. Closed with [/FIND]
              If a number is present this indicates the line number in an original unchanged file
[ADD BEFORE] => Code to insert BEFORE the found code. Closed with [/ADD BEFORE]

CHANGES:
Note! If the patchsettings.php is as original this is already done and you only need to upload this file as /special/holes.php
and make sure patchsettings.php is uploaded.

[IN FILE]
patchsettings.php
[FIND (EOF)]
?>
[/FIND]
[ADD BEFORE]
// BEGIN Holes patch settings
//	(by BraveBrain. Made as an example of usage for patchsettings.php) 
// To make this work you will also need the Holes patch (holes.php) uploaded to your 'special' directory 
$setup["BB_holes"] = "Number of holes in game,int";
$setup["BB_holesGold"] = "Maximum gold to find (Multiplied with player's level (0=unlimited)),int"; // If this is set one player can't find more than this amount
$holes = getsetting("BB_holes",5); // Get the amount of holes if set. If not set it defaults to 5
for ($i=0;$i<$holes;$i++) {  // Adds three game settings per hole (BB_holes)
	$tmp = $i+1;
	$setup["BB_holeGold".$tmp] = "Money currently in hole # $tmp,int"; // If a player dies money will go here for the specific hole
	$setup["BB_holeMax".$tmp] = "Max HP lost from hole # $tmp (%),int"; // The Max % of damage this hole can do (% of users max hp)
	$setup["BB_holeMin".$tmp] = "Min HP lost from hole # $tmp (%),int"; // The Min % of damage this hole can do (% of users max hp)
}
// END Holes patch settings 
[/ADD BEFORE]

[SETTINGS]
OPTIONAL!
Only needed if you want to change the default settings.
Default settings are:
Number of holes in game: 	5
Maximum gold to find: 		0 (0=unlimited. Any value will multiply itself with the user's level. I.e. If set to 1000 a level 1 player can find a maximum of 1000 gold while a level 7 player can find up to 7000)
Money currently in hole: 	(not meant to be set, defaults to 0 if not set, updates itself when players fall into the holes)
Minimum HP lost from hole: 	(not set, defaults to 25(%) if not set)
Minimum HP lost from hole: 	(not set, defaults to 75(%) if not set)
If you change the number of holes it will appear in the settings after clicking the Save button
[/SETTINGS]
