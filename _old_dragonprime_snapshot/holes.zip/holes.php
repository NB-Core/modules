<?
/****************************************************
	Game: 		LotGD
	Version:	0.9.7/0.9.7+jt
	Patch: 		Holes
	Author: 	Borge Alvestad aka BraveBrain
	Date: 		February 20th 2004

	Upload this file as:
				/special/holes.php
	Affected files:
				/patchsettings.php
	Required files:
				/patchsettings.php

	Description:
	This patch is to act as a special.
	It adds a certain amount of holes (5 by default)
	in which players can fall and loose random hp.
	If the players die their gold is left in the specific hole.
	If the players survive they get any gold (up to max) that
	might be in the hole, and they get an option to check another hole.
	There's a 1/30 chance that the players find a gem.

*//****************************************************/
// Any comments from THIS LINE and to the end of file (EOF) may be removed, 
// as they are only meant as aid to change the script, or as tutorial for those wanting to create their own patches.
if (!$HTTP_GET_VARS['retry']) { // First visit. They come from the forest
	if ($HTTP_GET_VARS['type']) {
		$lookingfor = ($HTTP_GET_VARS['type']=='slum') ? "an easy match" : "one of the bigger creatures";
	} else {
		$lookingfor = "something to kill";
	}
	output("`n`%You walk deeper into the forest looking for $lookingfor! `nAs you try to focus on a something dark ahead you trip and fall down a hole.`n");
} else { // Second visit. They come from a hole
	output("`n`%You explore the area hoping that you can find gold in other holes. `nA sudden sound from nearby makes you careless, and you find another hole the hard way! `nOuch ouch!!`n");
}
// How many holes are there in this game?
$holes = getsetting("BB_holes",5); 
// What's the maximum amount of gold one can find?
$maxgold = getsetting("BB_holesGold",0)*$session[user][level]; 
// Which hole is this?
$thishole = rand(1,$holes); 
// Is there any gold in this hole?
$holegold = getsetting("BB_holeGold".$thishole,0); 
// Let's set another variable for how much gold there were
$foundgold = $holegold; 
// Is there a limit for how much one player can find? If so let's follow that rule...
if (($maxgold!=0)&&($holegold>$maxgold)) { $foundgold=$maxgold; } 
// What's the maximum percent of HP to be lost
$hplossmax = getsetting("BB_holeMax".$thishole,75); 
// What's the minimum percent of HP one can loose
$hplossmin = getsetting("BB_holeMin".$thishole,25); 
// Find the hp loss factor
$hploss = round((rand($hplossmin,$hplossmax)/100),2); 
// Calculate the actual loss
$holedmg = round($session[user][maxhitpoints]*$hploss,0); 
// Make sure they don't loose more than they have
if ($holedmg>$session[user][hitpoints]) $holedmg=$session[user][hitpoints]; 
// Do the damage
$session[user][hitpoints]-=$holedmg; 
output("`n`4You lose `$$holedmg`4 hitpoints!`n"); 
if ($session[user][hitpoints]<=0) { // Are they dead yet?
	// How much gold did they have?
	$lostgold = $session[user][gold]; 
	// Well, take it all away from them. They're dead...
	$session[user][gold] -= $lostgold; 
	// Leave their gold in this particular hole
	$holegold += $lostgold;
    output("`4You're `$`bDEAD`b!!!`4`n".($lostgold?"":"You also lost `^$lostgold`6 gold!"));
    addnav("To the News","news.php");
    addnews($session[user][name]." fell into a hole and died. ".($session[user][sex]?"She":"He")." also lost $lostgold gold which most likely is still in the hole.");
} else { // They're still alive!
	// Do they find a gem or not? Only if the random value is less than ONE
	$gemfound = (rand(0,30)<1) ? true : false;
	// Make sure they actually receive the gem if they found one...
	if ($gemfound) { $session[user][gems]++; }
	// Decide which text to display if they did NOT find gold. Based on found or not found gem.
	$nogoldfound=($gemfound)?"`n`#You look around and find a GEM!`n":"`n`#You decide to look around but find nothing.`n";
	// Decide which text to display if they FOUND gold. Based on found or not found gem.
	$goldfound=($gemfound)?"`n`#You decide to look around and find `^$holegold `6gold`#, lost by unlucky adventurers. On your way out of there you also find `7ONE GEM`0``#!`n":"`n`#You decide to look around and find `^$holegold `6gold`#, lost by adventurers that didn't make it.`n";
	if ($foundgold>0) { // Did they find gold?
		// Output the text we decided earlier
		output($goldfound);
		// Give them the gold	
		$session[user][gold]+=$foundgold; 
		// Remove the gold from the hole
		$holegold-=$foundgold;
	    addnews($session[user][name]." fell into a hole. ".($session[user][sex]?"She":"He")." got a bit shaken but found `^$foundgold`0 `6gold`0".($gemfound?" and `&1`0 `7gem`0!":"."));
	} else { // They found nothing! HAHA!
		// Output the text we decided to give them if they didn't find any gold
		output($nogoldfound);
	}
	if (!$HTTP_GET_VARS['retry']) { // Ok. They're still alive AND this was their first hole
	// Let's give them an option; Do they want to try their luck and look for another hole?
	addnav("Look for other holes","forest.php?specialinc=holes.php&retry=1");
	addnav("Return to the Forest","forest.php");
	output("`#You wonder if you should get a bit greedy and look for other holes in the area.`n`%You'll never know what you'll find...");
	}
}
// Last but not least, let's make sure gold is added or removed from this hole's settings!
savesetting("BB_holeGold".$thishole,stripslashes($holegold));
// EOF
?>  