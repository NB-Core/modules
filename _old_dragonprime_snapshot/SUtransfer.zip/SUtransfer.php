<?
/*

SUtransfer.php
-based on bank.php

This allows you to give your players rewards without having to go to the database.

Add this link somewhere in your Superuser Grotto:
if ($session['user']['superuser']>=3) addnav("Player Rewards","SUtransfer.php");

*/ 
require_once "common.php"; 
isnewday(2);
checkday(); 
page_header("Reward Players"); 
addnav("Retun to Grotto","superuser.php");
addnav("Give Attack","SUtransfer.php?op=attack");
addnav("Give Defense","SUtransfer.php?op=defense");
addnav("Give Experience","SUtransfer.php?op=experience");
addnav("Give Max Hit Points","SUtransfer.php?op=maxhitpoints");
addnav("Give Ramius Favor","SUtransfer.php?op=deathpower");
switch($HTTP_GET_VARS[op]) 
{ 

case "attack": 
output("`6`bGive Attack`b:`n");
output("<form action='SUtransfer.php?op=attacktransfer2' method='POST'>Give <u>h</u>ow much: <input name='amount' id='amount' accesskey='h' width='5'>`n",true);
output("T<u>o</u>: <input name='to' accesskey='o'> (partial names are ok, you will be asked to confirm the transaction before it occurs).`n",true);
output("<input type='submit' class='button' value='Preview Giving'></form>",true);
output("<script language='javascript'>document.getElementById('amount').focus();</script>",true);
addnav("","SUtransfer.php?op=attacktransfer2");
break;

case "attacktransfer2":
output("`6`bConfirm Giving`b:`n");
$string="%";
for ($x=0;$x<strlen($_POST['to']);$x++){
$string .= substr($_POST['to'],$x,1)."%";}
$sql = "SELECT name,login FROM accounts WHERE name LIKE '".addslashes($string)."'";
$result = db_query($sql);
$amt = abs((int)$_POST['amount']);
if (db_num_rows($result)==1){
$row = db_fetch_assoc($result);
output("<form action='SUtransfer.php?op=attacktransfer3' method='POST'>",true);
output("`6Give `^$amt`6 attack to `&$row[name]`6.");
output("<input type='hidden' name='to' value='".HTMLEntities($row['login'])."'><input type='hidden' name='amount' value='$amt'><input type='submit' class='button' value='Complete Giving'></form>",true);
addnav("","SUtransfer.php?op=attacktransfer3");
}elseif(db_num_rows($result)>1){
output("<form action='SUtransfer.php?op=attacktransfer3' method='POST'>",true);
output("`6Give `^$amt`6 attack to <select name='to' class='input'>",true);
for ($i=0;$i<db_num_rows($result);$i++){
$row = db_fetch_assoc($result);
output("<option value=\"".HTMLEntities($row['login'])."\">".preg_replace("'[`].'","",$row['name'])."</option>",true);}
output("</select><input type='hidden' name='amount' value='$amt'><input type='submit' class='button' value='Complete Giving'></form>",true);
addnav("","SUtransfer.php?op=attacktransfer3");
}
break;

case "attacktransfer3":
$amt = abs((int)$_POST['amount']);
$sql = "SELECT name,acctid,level FROM accounts WHERE login='{$_POST['to']}'";
$result = db_query($sql);
if (db_num_rows($result)==1){
$row = db_fetch_assoc($result);
$sql = "UPDATE accounts SET attack=attack+$amt WHERE acctid='{$row['acctid']}'";
db_query($sql);
output("`6Giving Completed!");
systemmail($row['acctid'],"`^You have received a attack point boost!`0","`&{$session['user']['name']}`6 has boosted your attack by `^$amt`6 !");}
break; 

case "defense": 
output("`6`bGive Defense`b:`n");
output("<form action='SUtransfer.php?op=defencetransfer2' method='POST'>Give <u>h</u>ow much: <input name='amount' id='amount' accesskey='h' width='5'>`n",true);
output("T<u>o</u>: <input name='to' accesskey='o'> (partial names are ok, you will be asked to confirm the transaction before it occurs).`n",true);
output("<input type='submit' class='button' value='Preview Giving'></form>",true);
output("<script language='javascript'>document.getElementById('amount').focus();</script>",true);
addnav("","SUtransfer.php?op=defencetransfer2");
break;

case "defencetransfer2":
output("`6`bConfirm Giving`b:`n");
$string="%";
for ($x=0;$x<strlen($_POST['to']);$x++){
$string .= substr($_POST['to'],$x,1)."%";}
$sql = "SELECT name,login FROM accounts WHERE name LIKE '".addslashes($string)."'";
$result = db_query($sql);
$amt = abs((int)$_POST['amount']);
if (db_num_rows($result)==1){
$row = db_fetch_assoc($result);
output("<form action='SUtransfer.php?op=defencetransfer3' method='POST'>",true);
output("`6Give `^$amt`6 defence to `&$row[name]`6.");
output("<input type='hidden' name='to' value='".HTMLEntities($row['login'])."'><input type='hidden' name='amount' value='$amt'><input type='submit' class='button' value='Complete Giving'></form>",true);
addnav("","SUtransfer.php?op=defencetransfer3");
}elseif(db_num_rows($result)>1){
output("<form action='SUtransfer.php?op=defencetransfer3' method='POST'>",true);
output("`6Give `^$amt`6 defence to <select name='to' class='input'>",true);
for ($i=0;$i<db_num_rows($result);$i++){
$row = db_fetch_assoc($result);
output("<option value=\"".HTMLEntities($row['login'])."\">".preg_replace("'[`].'","",$row['name'])."</option>",true);}
output("</select><input type='hidden' name='amount' value='$amt'><input type='submit' class='button' value='Complete Giving'></form>",true);
addnav("","SUtransfer.php?op=defencetransfer3");
}
break;

case "defencetransfer3":
$amt = abs((int)$_POST['amount']);
$sql = "SELECT name,acctid,level FROM accounts WHERE login='{$_POST['to']}'";
$result = db_query($sql);
if (db_num_rows($result)==1){
$row = db_fetch_assoc($result);
$sql = "UPDATE accounts SET defence=defence+$amt WHERE acctid='{$row['acctid']}'";
db_query($sql);
output("`6Giving Completed!");
systemmail($row['acctid'],"`^You have received a defense point boost!`0","`&{$session['user']['name']}`6 has boosted your defense by `^$amt`6 !");}
break; 

case "experience": 
output("`6`bGive Experience`b:`n");
output("<form action='SUtransfer.php?op=experiencetransfer2' method='POST'>Give <u>h</u>ow much: <input name='amount' id='amount' accesskey='h' width='5'>`n",true);
output("T<u>o</u>: <input name='to' accesskey='o'> (partial names are ok, you will be asked to confirm the transaction before it occurs).`n",true);
output("<input type='submit' class='button' value='Preview Giving'></form>",true);
output("<script language='javascript'>document.getElementById('amount').focus();</script>",true);
addnav("","SUtransfer.php?op=experiencetransfer2");
break;

case "experiencetransfer2":
output("`6`bConfirm Giving`b:`n");
$string="%";
for ($x=0;$x<strlen($_POST['to']);$x++){
$string .= substr($_POST['to'],$x,1)."%";}
$sql = "SELECT name,login FROM accounts WHERE name LIKE '".addslashes($string)."'";
$result = db_query($sql);
$amt = abs((int)$_POST['amount']);
if (db_num_rows($result)==1){
$row = db_fetch_assoc($result);
output("<form action='SUtransfer.php?op=experiencetransfer3' method='POST'>",true);
output("`6Give `^$amt`6 experience to `&$row[name]`6.");
output("<input type='hidden' name='to' value='".HTMLEntities($row['login'])."'><input type='hidden' name='amount' value='$amt'><input type='submit' class='button' value='Complete Giving'></form>",true);
addnav("","SUtransfer.php?op=experiencetransfer3");
}elseif(db_num_rows($result)>1){
output("<form action='SUtransfer.php?op=experiencetransfer3' method='POST'>",true);
output("`6Give `^$amt`6 experience to <select name='to' class='input'>",true);
for ($i=0;$i<db_num_rows($result);$i++){
$row = db_fetch_assoc($result);
output("<option value=\"".HTMLEntities($row['login'])."\">".preg_replace("'[`].'","",$row['name'])."</option>",true);}
output("</select><input type='hidden' name='amount' value='$amt'><input type='submit' class='button' value='Complete Giving'></form>",true);
addnav("","SUtransfer.php?op=experiencetransfer3");
}
break;

case "experiencetransfer3":
$amt = abs((int)$_POST['amount']);
$sql = "SELECT name,acctid,level FROM accounts WHERE login='{$_POST['to']}'";
$result = db_query($sql);
if (db_num_rows($result)==1){
$row = db_fetch_assoc($result);
$sql = "UPDATE accounts SET experience=experience+$amt WHERE acctid='{$row['acctid']}'";
db_query($sql);
output("`6Giving Completed!");
systemmail($row['acctid'],"`^You have received a experience point boost!`0","`&{$session['user']['name']}`6 has boosted your experience by `^$amt`6 !");}
break; 

case "maxhitpoints": 
output("`6`bGive Max Hitpoints`b:`n");
output("<form action='SUtransfer.php?op=maxhitpointstransfer2' method='POST'>Give <u>h</u>ow much: <input name='amount' id='amount' accesskey='h' width='5'>`n",true);
output("T<u>o</u>: <input name='to' accesskey='o'> (partial names are ok, you will be asked to confirm the transaction before it occurs).`n",true);
output("<input type='submit' class='button' value='Preview Giving'></form>",true);
output("<script language='javascript'>document.getElementById('amount').focus();</script>",true);
addnav("","SUtransfer.php?op=maxhitpointstransfer2");
break;

case "maxhitpointstransfer2":
output("`6`bConfirm Giving`b:`n");
$string="%";
for ($x=0;$x<strlen($_POST['to']);$x++){
$string .= substr($_POST['to'],$x,1)."%";}
$sql = "SELECT name,login FROM accounts WHERE name LIKE '".addslashes($string)."'";
$result = db_query($sql);
$amt = abs((int)$_POST['amount']);
if (db_num_rows($result)==1){
$row = db_fetch_assoc($result);
output("<form action='SUtransfer.php?op=maxhitpointstransfer3' method='POST'>",true);
output("`6Give `^$amt`6 maxhitpoints to `&$row[name]`6.");
output("<input type='hidden' name='to' value='".HTMLEntities($row['login'])."'><input type='hidden' name='amount' value='$amt'><input type='submit' class='button' value='Complete Giving'></form>",true);
addnav("","SUtransfer.php?op=maxhitpointstransfer3");
}elseif(db_num_rows($result)>1){
output("<form action='SUtransfer.php?op=maxhitpointstransfer3' method='POST'>",true);
output("`6Give `^$amt`6 maxhitpoints to <select name='to' class='input'>",true);
for ($i=0;$i<db_num_rows($result);$i++){
$row = db_fetch_assoc($result);
output("<option value=\"".HTMLEntities($row['login'])."\">".preg_replace("'[`].'","",$row['name'])."</option>",true);}
output("</select><input type='hidden' name='amount' value='$amt'><input type='submit' class='button' value='Complete Giving'></form>",true);
addnav("","SUtransfer.php?op=maxhitpointstransfer3");
}
break;

case "maxhitpointstransfer3":
$amt = abs((int)$_POST['amount']);
$sql = "SELECT name,acctid,level FROM accounts WHERE login='{$_POST['to']}'";
$result = db_query($sql);
if (db_num_rows($result)==1){
$row = db_fetch_assoc($result);
$sql = "UPDATE accounts SET maxhitpoints=maxhitpoints+$amt WHERE acctid='{$row['acctid']}'";
db_query($sql);
output("`6Giving Completed!");
systemmail($row['acctid'],"`^You have received a max hitpoints boost!`0","`&{$session['user']['name']}`6 has boosted your max hitpoints by `^$amt`6 !");}
break; 

case "deathpower": 
output("`6`bGive Ramius Favor`b:`n");
output("<form action='SUtransfer.php?op=deathpowertransfer2' method='POST'>Give <u>h</u>ow much: <input name='amount' id='amount' accesskey='h' width='5'>`n",true);
output("T<u>o</u>: <input name='to' accesskey='o'> (partial names are ok, you will be asked to confirm the transaction before it occurs).`n",true);
output("<input type='submit' class='button' value='Preview Giving'></form>",true);
output("<script language='javascript'>document.getElementById('amount').focus();</script>",true);
addnav("","SUtransfer.php?op=deathpowertransfer2");
break;

case "deathpowertransfer2":
output("`6`bConfirm Giving`b:`n");
$string="%";
for ($x=0;$x<strlen($_POST['to']);$x++){
$string .= substr($_POST['to'],$x,1)."%";}
$sql = "SELECT name,login FROM accounts WHERE name LIKE '".addslashes($string)."'";
$result = db_query($sql);
$amt = abs((int)$_POST['amount']);
if (db_num_rows($result)==1){
$row = db_fetch_assoc($result);
output("<form action='SUtransfer.php?op=deathpowertransfer3' method='POST'>",true);
output("`6Give `^$amt`6 deathpower to `&$row[name]`6.");
output("<input type='hidden' name='to' value='".HTMLEntities($row['login'])."'><input type='hidden' name='amount' value='$amt'><input type='submit' class='button' value='Complete Giving'></form>",true);
addnav("","SUtransfer.php?op=deathpowertransfer3");
}elseif(db_num_rows($result)>1){
output("<form action='SUtransfer.php?op=deathpowertransfer3' method='POST'>",true);
output("`6Give `^$amt`6 deathpower to <select name='to' class='input'>",true);
for ($i=0;$i<db_num_rows($result);$i++){
$row = db_fetch_assoc($result);
output("<option value=\"".HTMLEntities($row['login'])."\">".preg_replace("'[`].'","",$row['name'])."</option>",true);}
output("</select><input type='hidden' name='amount' value='$amt'><input type='submit' class='button' value='Complete Giving'></form>",true);
addnav("","SUtransfer.php?op=deathpowertransfer3");
}
break;

case "deathpowertransfer3":
$amt = abs((int)$_POST['amount']);
$sql = "SELECT name,acctid,level FROM accounts WHERE login='{$_POST['to']}'";
$result = db_query($sql);
if (db_num_rows($result)==1){
$row = db_fetch_assoc($result);
$sql = "UPDATE accounts SET deathpower=deathpower+$amt WHERE acctid='{$row['acctid']}'";
db_query($sql);
output("`6Giving Completed!");
systemmail($row['acctid'],"`^You have received a Ramius Favor  boost!`0","`&{$session['user']['name']}`6 has boosted your Ramius Favor by `^$amt`6 !");}
break; 

}
page_footer(); 
?> 