<?php
/*******************************************
/ gnomogemme.php - The Gem's Gnome V1.0
/ Originally by Excalibur (www.ogsi.it)
/ 14 October 2004

----install-instructions--------------------
DIFFICULTY SCALE: extremely easy

Forest Event for LotGD 0.9.7
Drop into your "Specials" folder
--------------------------------------------

Version History:
Ver. 1.0 created by Excalibur (www.ogsi.it)
Original Version posted to DragonPrime
********************************************
Originally by: Excalibur
English clean-up:XChrisX
29 October 2004
*/
require_once "common.php";
checkday();
if (!isset($session)) exit();
//This is the number of faces on the first dice
$basedice = 6;
//This is the number of gems the gnome has at minimum
$basegemgnome = 50;
if (getsetting("gnomogemme",0) < $basegemgnome) savesetting("gnomogemme",$basegemgnome);
page_header("The Gnome of Gems");
output("`c<font size='+2'>`%The Gnome of Gems</font>`c`n`n",true);
srand ((double) microtime() * 10000000);
if ($HTTP_GET_VARS['op']=="") {
   $session['gemwin'] = 0;
   $session['gemtopay'] = 0;
   output("`2Wandering through the forest you meet a gnome that is looking at you with a clever gaze from high above a rock.`n");
   output("Tied to his belt you notice a bag full of precious gems.`n");
   output("Your eyes glare at seeing all those gems  and some spittle drops from the sides of your mouth.`n");
   output("The gnome, noticing your greediness, jumps off the rock and magically takes a table from nowhere, ");
   output("placing it in front of you, and shows you a series of dice that differ from 6 faces dice and says to you: `n");
   //The gnome talk in a strange english ... I hope to give you an idea of it
   output("\"`#Aye, hello mi young uarrior, I've noticed you gaze when ya sin mi prescious gems, ");
   output("and I want too give ya the chance to ya to win a rilly biggest amount.`2\"`n`n");
   addnav("`@Continue","forest.php?op=goon");
   addnav("`\$Nah, not interested","forest.php?op=leave");
   $session['user']['specialinc']="gnomogemme.php";
}else if ($HTTP_GET_VARS['op']=="leave") {
   output("`5You wont waste your time, so you tell the gnome it's a long time since you last believed in fairy-tales. ");
   output("You leave him behind going back to the forest, knowing that you've lost a forest fight listening ");
   output("to gnome's tale.`n");
   $session['user']['turns'] -= 1;
   $session['user']['specialinc']="";
   addnav("Return to forest","forest.php");
}else if ($HTTP_GET_VARS['op']=="goon") {
      output("`2The small gnome continues: `n\"`#Ach well, ya be a mighty warrior for sure !! ");
      output("I rilly admire ya. The game is simple much, I have a series of dice much very special. ");
      output("They have from $basedice to ".($basedice+5)." faces. Ya begin with the $basedice faces dice, then ya continue with ");
      output(($basedice+1)." faces dice in the following turn and again then with one more face to conclude with ty ".($basedice+5)." faces dice.`n");
      output("Before to roll my dice you have to give me a nice gem, you choose a number and if after the drop your number equal to ");
      output("dice number ya multiply the stake by three but if your number is adjacent to dice's number ya double it, else I win ");
      output("and yooo lose hihihihi.`2\"`n`n");
      output("The gnome take a pause and then again starts to talk before you can do or say anything: `n\"`#");
      output("Forgetting I was, the first 2 rolls are mandatory, ya do not withdraw. After roll following ya can ");
      output("decide to continue or to stop. I don't give ya gems immediatly, I put gems in a stake and ya can see in lower ");
      output("right corner gems I have in my bag and gems ya win if ya stop after two rolls.`n");
      output("Verrry importantest thing I can't give ya more gems then I have in my bag, even if ya should win more. `n");
      output("If ya lose you can ter ... ryt ... retry again and test your luck more times, but for each more try my cost will ");
      output("increase by one gem.`2\"`n`n");
      output("`^What do ya wanna do?");
      addnav("`@I wanna play","forest.php?op=anothergem");
      addnav("`\$Nah, I'm not interested","forest.php?op=exit");
      $session['user']['specialinc']="gnomogemme.php";
}else if ($HTTP_GET_VARS['op']=="anothergem") {
   $session['gemtopay'] +=1;
   if ($session['user']['gems'] < $session['gemtopay']){
      output("`2\"`#Ya don't have no more gems, you don't breil up me ! I small gnome but big brain!`2\"`n");
      output("Saying this he cast a spell on you and run away like a lightning into the forest!!`n");
      $loseturn = e_rand(2,4);
      if ($loseturn > $session['user']['turns']) $loseturns = $session['user']['turns'];
      $session['user']['turns'] -= $loseturn;
      output("You feel weak and you realize you've lost $loseturn forest fights because of the spell.");
       $session['user']['specialinc']="";
      addnav("Back to Forest","forest.php");
   }else{
      $session['user']['gems'] -= $session['gemtopay'];
      debuglog("pay {$session['gemtopay']} gems to play with the gnome");
      $newgem = getsetting("gnomogemme",0) + $session['gemtopay'];
      savesetting("gnomogemme",$newgem);
      output("`2The gnome's eyes laugh looking the gems and he tells: `n\"`#Well-well-well, begin the game we do. Take ");
      output("this $basedice faces dice, you choose lucky number before.`2\".`n");
      $session['user']['specialinc']="gnomogemme.php";
      addnav("Choose number between 1 - $basedice","forest.php?op=number6");
   }
// First try with 6 faces dice
}else if ($HTTP_GET_VARS['op']=="number6") {
   output("`2Write in the box your guess.`n");
   output("<form action='forest.php?op=number6bis' method='POST'><input name='number' value='0'><input type='submit' class='button' value='Choose Number'>`n",true);
   $session['user']['specialinc']="gnomogemme.php";
   addnav("","forest.php?op=number6bis");
}else if ($HTTP_GET_VARS['op']=="number6bis") {
   $number = intval($HTTP_POST_VARS['number']);
   if ($number < 1 OR $number > $basedice){
      output("`2The gnome looks angrily at you and say \"`#Number between 1 and $basedice choose ya must. Ya choosen `b`%$number`b`# that is wrong number!`2\"`n");
       $session['user']['specialinc']="gnomogemme.php";
      addnav("Choose number between 1 - $basedice","forest.php?op=number6");
   }else{
      output("`2\"`#Choosen ya had `b`%$number`b`#, now ya roll the dice and we see if won ya have.`2\"`n`n");
      $match = rand(1,$basedice);
      dot($match);
      output("`6The dice stop his run and shows the number `\$$match `^on the upper face.`n`n");
      if ($match == $number) {
         $session['gemwin'] += 3;
         output("`\$Arghhh !! `#Won you have. I give ya {$session['gemwin']} gems you have won, but you must do another round mandatory, only after retire you can.`n");
         $session['user']['specialinc']="gnomogemme.php";
         addnav("Choose number between 1 and ".($basedice+1),"forest.php?op=number7");
      }else if (($number-1) == $match OR ($number+1) == $match) {
         $session['gemwin'] += 2;
         output("`\$Arghhh !! `#Your number is adjacent to dice's number. I give ya {$session['gemwin']} you won have, but you must do another round mandatory, only after retire you can.`n");
         $session['user']['specialinc']="gnomogemme.php";
         addnav("Choose number between 1 and ".($basedice+1),"forest.php?op=number7");
      }else {
         output("`#Eh eh eh, lose you have! I give ya another possibility if ya wanna try again, or ya can go back to forest if ya hate game! Ya must give me ".($session['gemtopay']+1)." gems to try luck again.`n`n");
         output("`2What do ya wanna do?`n");
         $session['gemwin'] = 0;
         $session['user']['specialinc']="gnomogemme.php";
         addnav("Let me try again","forest.php?op=anothergem");
         addnav("You're a cheater, I leave!","forest.php?op=exit");
      }
   }
//Second try with 7 faces dice
}else if ($HTTP_GET_VARS['op']=="number7") {
   output("`2Write in the box your guess`n");
   output("<form action='forest.php?op=number7bis' method='POST'><input name='number' value='0'><input type='submit' class='button' value='Choose Number'>`n",true);
   $session['user']['specialinc']="gnomogemme.php";
   addnav("","forest.php?op=number7bis");
}else if ($HTTP_GET_VARS['op']=="number7bis") {
   $number = intval($HTTP_POST_VARS['number']);
   if ($number < 1 OR $number > ($basedice+1)){
      output("`2The gnome looks angrily at you and says \"`#Number between 1 and ".($basedice+1)." choose ya must. Ya choosen `b`%$number`b`# that is wrong number!`2\"`n");
       $session['user']['specialinc']="gnomogemme.php";
      addnav("Choose number between 1 and ".($basedice+1),"forest.php?op=number7");
   }else{
      output("`2\"`#Choosen ya had `b`%$number`b`#, now ya roll the dice and we see if won ya have.`2\"`n`n");
      $match = rand(1,($basedice+1));
      dot($match);
      output("`6The dice stops his run and shows the number `\$$match `^on the upper face.`n`n");
      if ($match == $number) {
         $session['gemwin'] *= 3;
         output("`\$Arghhh !! `#Won you have. I give ya {$session['gemwin']} you won have, if ya want you can continue to play or retire from game and grab the gems ya won.`n");
         output("to play or retire from game and grab the gems ya won.`n");
         $session['user']['specialinc']="gnomogemme.php";
         addnav("I retire, I've won enough","forest.php?op=exit");
         addnav("I feel lucky, go on","forest.php?op=number8");
      }else if (($number-1) == $match OR ($number+1) == $match) {
         $session['gemwin'] *= 2;
         output("`\$Arghhh !! `#Your number is adjacent to dice's number. I give ya {$session['gemwin']} you won have, if ya want you can continue to play or retire from game and grab the gems ya won.`n");
         $session['user']['specialinc']="gnomogemme.php";
         addnav("I retire, I've won enough","forest.php?op=exit");
         addnav("I feel lucky, go on","forest.php?op=number8");
      }else {
         output("`#Eh eh eh, lose you have! I give ya another possibility if ya wanna try again, or ya can go back to forest if ya hate game! Ya must give me ".($session['gemtopay']+1)." gems to try luck again.`n`n");
         output("`2What do ya wanna do?`n");
         $session['gemwin'] = 0;
         $session['user']['specialinc']="gnomogemme.php";
         addnav("Let me try again","forest.php?op=anothergem");
         addnav("You're a cheater, I leave!","forest.php?op=exit");
      }
   }
//Third try with 8 faces dice
}else if ($HTTP_GET_VARS['op']=="number8") {
   output("`2Write in the box your guess.`n");
   output("<form action='forest.php?op=number8bis' method='POST'><input name='number' value='0'><input type='submit' class='button' value='Choose Number'>`n",true);
   $session['user']['specialinc']="gnomogemme.php";
   addnav("","forest.php?op=number8bis");
}else if ($HTTP_GET_VARS['op']=="number8bis") {
   $number = intval($HTTP_POST_VARS['number']);
   if ($number < 1 OR $number > ($basedice+2)){
      output("`2`2The gnome looks angrily at you and says \"`#Number between 1 and ".($basedice+2)." choose ya must. Ya choosen `b`%$number`b`# that is wrong number!`2\"`n");
       $session['user']['specialinc']="gnomogemme.php";
      addnav("Choose number between 1 and ".($basedice+2),"forest.php?op=number8");
   }else{
      output("`2\"`#Choosen ya had `b`%$number`b`#, now ya roll the dice and we see if won ya have.`2\"`n`n");
      $match = rand(1,($basedice+2));
      dot($match);
      output("`6The dice stops his run and shows the number `\$$match `^on the upper face.`n`n");
      if ($match == $number) {
         $session['gemwin'] *= 3;
         output("`\$Arghhh !! `#Won you have. I give ya {$session['gemwin']} you won have, if ya want you can continue to play or retire from game and grab the gems ya won.`n");
         $session['user']['specialinc']="gnomogemme.php";
         addnav("I retire, I've won enough","forest.php?op=exit");
         addnav("I feel lucky, go on","forest.php?op=number9");
      }else if (($number-1) == $match OR ($number+1) == $match) {
         $session['gemwin'] *= 2;
         output("`\$Arghhh !! `#Your number is adjacent to dice's number. I give ya {$session['gemwin']} you won have, if ya want you can continue to play or retire from game and grab the gems ya won.`n");
         $session['user']['specialinc']="gnomogemme.php";
         addnav("I retire, I've won enough","forest.php?op=exit");
         addnav("I feel lucky, go on","forest.php?op=number9");
      }else {
         output("`#Eh eh eh, lose you have! I give ya another possibility if ya wanna try again, or ya can go back to forest if ya hate game! Ya must give me ".($session['gemtopay']+1)." gems to try luck again.`n`n");
         output("`2What do ya wanna do?`n");
         $session['gemwin'] = 0;
         $session['user']['specialinc']="gnomogemme.php";
         addnav("Let me try again","forest.php?op=anothergem");
         addnav("You're a cheater, I leave!","forest.php?op=exit");
      }
   }
//Forth try with 9 faces dice
}else if ($HTTP_GET_VARS['op']=="number9") {
   output("`2Write in the box your guess.`n");
   output("<form action='forest.php?op=number9bis' method='POST'><input name='number' value='0'><input type='submit' class='button' value='Choose Number'>`n",true);
   $session['user']['specialinc']="gnomogemme.php";
   addnav("","forest.php?op=number9bis");
}else if ($HTTP_GET_VARS['op']=="number9bis") {
   $number = intval($HTTP_POST_VARS['number']);
   if ($number < 1 OR $number > ($basedice+3)){
      output("`2`2The gnome looks angrily at you and says \"`#Number between 1 and ".($basedice+3)." choose ya must. Ya choosen `b`%$number`b`# that is wrong number!`2\"`n");
       $session['user']['specialinc']="gnomogemme.php";
      addnav("Choose number between 1 and ".($basedice+3),"forest.php?op=number9");
   }else{
      output("`2\"`#Choosen ya had `b`%$number`b`#, now ya roll the dice and we see if won ya have.`2\"`n`n");
      $match = rand(1,($basedice+3));
      dot($match);
      output("`6The dice stops his run and shows the number `\$$match `^on the upper face.`n`n");
      if ($match == $number) {
         $session['gemwin'] *= 3;
         output("`\$Arghhh !! `#Won you have. I give ya {$session['gemwin']} you won have, if ya want you can continue to play or retire from game and grab the gems ya won.`n");
         $session['user']['specialinc']="gnomogemme.php";
         addnav("I retire, I've won enough","forest.php?op=exit");
         addnav("I feel lucky, go on","forest.php?op=number10");
      }else if (($number-1) == $match OR ($number+1) == $match) {
         $session['gemwin'] *= 2;
         output("`\$Arghhh !! `#Your number is adjacent to dice's number. I give ya {$session['gemwin']} you won have, if ya want you can continue to play or retire from game and grab the gems ya won.`n");
         $session['user']['specialinc']="gnomogemme.php";
         addnav("I retire, I've won enough","forest.php?op=exit");
         addnav("I feel lucky, go on","forest.php?op=number10");
      }else {
         output("`#Eh eh eh, lose you have! I give ya another possibility if ya wanna try again, or ya can go back to forest if ya hate game! Ya must give me ".($session['gemtopay']+1)." gems to try luck again.`n`n");
         output("`2What do ya wanna do?`n");
         $session['gemwin'] = 0;
         $session['user']['specialinc']="gnomogemme.php";
         addnav("Let me try again","forest.php?op=anothergem");
         addnav("You're a cheater, I leave!","forest.php?op=exit");
      }
   }
//Fifth try with 10 faces dice
}else if ($HTTP_GET_VARS['op']=="number10") {
   output("`2Write in the box your guess.`n");
   output("<form action='forest.php?op=number10bis' method='POST'><input name='number' value='0'><input type='submit' class='button' value='Choose Number'>`n",true);
   $session['user']['specialinc']="gnomogemme.php";
   addnav("","forest.php?op=number10bis");
}else if ($HTTP_GET_VARS['op']=="number10bis") {
   $number = intval($HTTP_POST_VARS['number']);
   if ($number < 1 OR $number > ($basedice+4)){
      output("`2`2The gnome looks angrily at you and says \"`#Number between 1 and ".($basedice+4)." choose ya must. Ya choosen `b`%$number`b`# that is wrong number!`2\"`n");
       $session['user']['specialinc']="gnomogemme.php";
      addnav("Choose number between 1 and ".($basedice+4),"forest.php?op=number10");
   }else{
      output("`2\"`#Choosen ya had `b`%$number`b`#, now ya roll the dice and we see if won ya have.`2\"`n`n");
      $match = rand(1,($basedice+4));
      dot($match);
      output("`6The dice stop his run and shows the number `\$$match `^on the upper face.`n`n");
      if ($match == $number) {
         $session['gemwin'] *= 3;
         output("`\$Arghhh !! `#Won you have. I give ya {$session['gemwin']} you won have, if ya want you can continue to play or retire from game and grab the gems ya won.`n");
         $session['user']['specialinc']="gnomogemme.php";
         addnav("I retire, I've won enough","forest.php?op=exit");
         addnav("I feel lucky, go on","forest.php?op=number11");
      }else if (($number-1) == $match OR ($number+1) == $match) {
         $session['gemwin'] *= 2;
         output("`\$Arghhh !! `#Your number is adjacent to dice's number. I give ya {$session['gemwin']} you won have, if ya want you can continue to play or retire from game and grab the gems ya won.`n");
         $session['user']['specialinc']="gnomogemme.php";
         addnav("I retire, I've won enough","forest.php?op=exit");
         addnav("I feel lucky, go on","forest.php?op=number11");
      }else {
         output("`#Eh eh eh, lose you have! I give ya another possibility if ya wanna try again, or ya can go back to forest if ya hate game! Ya must give me ".($session['gemtopay']+1)." gems to try luck again.`n`n");
         output("`2What do ya wanna do?`n");
         $session['gemwin'] = 0;
         $session['user']['specialinc']="gnomogemme.php";
         addnav("Let me try again","forest.php?op=anothergem");
         addnav("You're a cheater, I leave!","forest.php?op=exit");
      }
   }
// Sixth try with 11 faces dice
}else if ($HTTP_GET_VARS['op']=="number11") {
   output("`2Write in the box your guess.`n");
   output("<form action='forest.php?op=number11bis' method='POST'><input name='number' value='0'><input type='submit' class='button' value='Choose Number'>`n",true);
   $session['user']['specialinc']="gnomogemme.php";
   addnav("","forest.php?op=number11bis");
}else if ($HTTP_GET_VARS['op']=="number11bis") {
   $number = intval($HTTP_POST_VARS['number']);
   if ($number < 1 OR $number > ($basedice+5)){
      output("`2The gnome looks angrily at you and says \"`#Number between 1 and ".($basedice+5)." choose ya must. Ya choosen `b`%$number`b`# that is wrong number!`2\"`n");
       $session['user']['specialinc']="gnomogemme.php";
      addnav("Choose number between 1 and ".($basedice+5),"forest.php?op=number11");
   }else{
      output("`2\"`#Choosen ya had `b`%$number`b`#, now ya roll the dice and we see if won ya have.`2\"`n`n");
      $match = rand(1,($basedice+5));
      dot($match);
      output("`6The dice stop his run and shows the number `\$$match `^on the upper face.`n`n");
      if ($match == $number) {
         $session['gemwin'] *= 3;
         output("`\$Arghhh !! `#Won you have. I give ya {$session['gemwin']} you won have, if ya want you can continue to play or retire from game and grab the gems ya won.`n");
         $session['user']['specialinc']="gnomogemme.php";
         addnav("Grab Gems","forest.php?op=exit");
      }else if (($number-1) == $match OR ($number+1) == $match) {
         $session['gemwin'] *= 2;
         output("`\$Arghhh !! `#Your number is adjacent to dice's number. I give ya {$session['gemwin']} you won have, if ya want you can continue to play or retire from game and grab the gems ya won.`n");
         $session['user']['specialinc']="gnomogemme.php";
         addnav("Grab Gems","forest.php?op=exit");
      }else {
         output("`#Eh eh eh, lose you have! I give ya another possibility if ya wanna try again, or ya can go back to forest if ya hate game! Ya must give me ".($session['gemtopay']+1)." gems to try luck again.`n`n");
         output("`2What do ya wanna do?`n");
         $session['gemwin'] = 0;
         $session['user']['specialinc']="gnomogemme.php";
         addnav("Let me try again","forest.php?op=anothergem");
         addnav("You're a cheater, I leave!","forest.php?op=exit");
      }
   }
}else if ($HTTP_GET_VARS['op']=="exit") {
   if ($session['gemwin'] == 0) {
      output("`%Feeling sad for the defeat, you turn back to forest and slowly walk away, while the gnome laughs loudly looking at the gems that he has stolen from you!`n");
   } else {
      output("`@Feeling happy for the glorious victory over such tiny creature, you turn back to forest and walk away. You hear the screams of the gnome for a long time while you enter deeply in the forest.`n");
      if ($session['gemwin'] > getsetting("gnomogemme",0)) {
         $session['gemwin'] = getsetting("gnomogemme",0);
      }
      $session['user']['gems'] += $session['gemwin'];
      debuglog("win {$session['gemwin']} gems from the Gem's Gnome");
      $newgem = getsetting("gnomogemme",0) - $session['gemwin'];
      savesetting("gnomogemme",$newgem);
   }
   $session['user']['specialinc']="";
   addnav("F?Back to Forest","forest.php");
}

if ($HTTP_GET_VARS['op']!="") {
   output("<big><div align=right>`n`n`b`^Gnome's Gems`b:`#".getsetting("gnomogemme",0)."`n</big></div>",true);
   output("<big><div align=right>`b`^Stack`b:`#{$session['gemwin']}`n</big></div>",true);
}else {
   output("<big><div align=right>`n`n`b`^Gnome's Gems`b:`#".getsetting("gnomogemme",0)."`n</big></div>",true);
}
function dot($match)
   {
    for ($i = 0; $i < $match;$i++) {
        output("`\$...........`%...........`!...........`#...........`@...........`^...........`n`n");
   }
   }
//I cannot make you keep this line here but would appreciate it left in.
rawoutput("<br><div style=\"text-align: right ;\"><a href=\"http://www.ogsi.it\" target=\"_blank\"><font color=\"#33FF33\">Gem's Gnome by Excalibur @ http://www.ogsi.it</font></a><br>");
page_footer();
?>