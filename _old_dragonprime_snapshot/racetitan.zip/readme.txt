-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
Race - Titan - A module for Legend of the Green Dragon 1.0.3

Legend of the Green Dragon
by  Eric "MightyE" Stevens (http://www.mightye.org)
and JT "Kendaer" Traub (http://www.dragoncat.net)

Software Project Page:
http://sourceforge.net/projects/lotgd

Modification Community Page:
http://dragonprime.net

Author of this Module:
Enderandrew (enderandrew@gmail.com)

Enderandrew's LoGD game:
http://enderandrew.com/lotgd/

Download the latest version of this module from:
http://dragonprime.net/index.php?action=viewfiles&user=enderwiggin

----------------------------------------------
-- STATUS: -----------------------------------
----------------------------------------------
This module is STABLE.

----------------------------------------------
-- INFORMATION: ------------------------------
----------------------------------------------
There are two versions of this module, and I will likely release all race
modules like this.  The first gives the Titans their own city.  The second
version has the Gnomes sharing a city with the Trolls, and thusly they need
to be installed and active for the second version to work.  The choice is
yours on which to use.  I was considering creating a setting in the module
to allow you to change whether or not there was a city.  However, this is
the easiest way to go.  If someone has a better method of handling the option
of city versus shared city, please drop me a line on the Dragonprime forums
or at enderandrew@gmail.com

This module was originally developed for prerelease 12.  This module may not
work with earlier, or later versions.  I intend to update this module to stay
current with each new release of LotGD.

This race is meant to mix things up, and build upon the Alignment system.
This race will not give out alignment points. That's up to other modules to
handle.  What this module does, is add a new race to the game, whose power is
determined by how evil their alignment gets.  I eventually intend to develop
some more modules with alignment in mind, and I hope to encourage other de-
velopers to do the same.

My initial inclination was to do two races, both Celestials.  One would be
Angelic, and the other Demonic.  However, this not only didn't seem to fit in
very well with LotGD, but the concept of Celestial creatures didn't seem to be
on par with basic Humans and Elves.  Perhaps I may develop a powerful specialty
you unlock with multiple DK's where you become an avatar of celestial creatures.
But for now, I think a Titan race fits in very well with the LotGD setting,
since they are the very essense of a hero.

The Titan race is half human, and half deity.  They are meant to be used in con-
junction with the Draconis race, who are half human and half dragon.

This version of the module requires version 1.0.3 or later of LotGD.

Hope you enjoy!


----------------------------------------------
-- INSTALLATION: -----------------------------
----------------------------------------------
Copy your preferred version of racetitan.php within this zip into your modules
directory.

Login to the Superuser Grotto and Install / Activate it.

-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-