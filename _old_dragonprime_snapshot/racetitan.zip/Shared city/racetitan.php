<?php
// This race is meant to mix things up, and build upon the Alignment system.  This race will not give out alignment points.
// That's up to other modules to handle.  What this module does, is add a new race to the game, whose power is determined
// by how good their alignment gets.  I eventually intend to develop some more modules with alignment in mind, and I hope
// to encourage other developers to do the same.
//
// My initial inclination was to do two races, both Celestials.  One would be Angelic, and the other Demonic.  However, this
// not only didn't seem to fit in very well with LotGD, but the concept of Celestial creatures didn't seem to be on par with
// basic Humans and Elves.  Perhaps I may develop a powerful specialty you unlock with multiple DK's where you become an
// avatar of celestial creatures.  But for now, I think a Titan race fits in very well with the LotGD setting, since they
// are the very essense of a hero.
//
// The Titan race is half human, and half deity.  They are meant to be used in conjunction with the Draconis race, who are
// half human and half dragon.

function racetitan_getmoduleinfo(){
	$info = array(
		"name"=>"Race - Titan (no city)",
		"version"=>"1.31",
		"author"=>"T. J. Brumfield - Enderandrew",
		"category"=>"Races",
		"description"=>"A race of half-gods that grow in power as their morality is affirmed.",
		"download"=>"http://dragonprime.net/users/enderwiggin/racetitan.zip",
		"vertxtloc"=>"http://dragonprime.net/users/enderwiggin/",
		"requires"=>array(
			"alignment" => "1.71|`1Enderandrew, http://dragonprime.net/users/enderwiggin/alignment98.zip",
			"racehuman" => "1.00|Eric Stephens, core module",
		),
		"settings"=>array(
			"Titan Race Settings,title",
			"minedeathchance"=>"Chance for Titan to die in the mine,range,0,100,1|75",
			"mindk"=>"How many DKs do you need before the race is available?,int|0",
			"cost"=>"How many Donation points do you need before the race is available?,int|0",
		),
	);
	return $info;
}

function racetitan_install(){
	if (!is_module_installed("alignment") || !is_module_installed("racehuman")) {
    		output("This module requires both the alignment module and the Human race both be installed.");
    		return false;
	}
	else {
		module_addhook("charstats");
		module_addhook("chooserace");
		module_addhook("newday");
		module_addhook("pointsdesc");
		module_addhook("pvpadjust");
		module_addhook("raceminedeath");
		module_addhook("setrace");
	$sql = "UPDATE  " . db_prefix("accounts") . " SET race='Titan' WHERE race='titan'";
	db_query($sql);
	}
}

function racetitan_uninstall(){
	global $session, $badguy;
	$vname = getsetting("villagename", LOCATION_FIELDS);
	$gname = get_module_setting("villagename");
	$sql = "UPDATE " . db_prefix("accounts") . " SET location='$vname' WHERE location = '$gname'";
	db_query($sql);
	if ($session['user']['location'] == $gname)
		$session['user']['location'] = $vname;
	$sql = "UPDATE  " . db_prefix("accounts") . " SET race='" . RACE_UNKNOWN . "' WHERE race='Titan'";
	db_query($sql);
	if ($session['user']['race'] == 'Titan')
		$session['user']['race'] = RACE_UNKNOWN;
	return true;
}

function racetitan_dohook($hookname,$args){
	//yeah, the $resline thing is a hack.  Sorry, not sure of a better way
	// to handle this.
	// Pass it in via args?
	global $session,$badguy,$resline;
	if (is_module_active("racehuman")) {
		$city = get_module_setting("villagename", "racehuman");
	} else {
		$city = getsetting("villagename", LOCATION_FIELDS);
	}
	$cost = get_module_setting("cost");
	$race = "Titan";
	if (is_module_active('alignment')) {
		$al = get_align();
	}
	$titan = ($al-50);
	switch($hookname){

	case "charstats":
		if ($session['user']['race']==$race){
			addcharstat("Vital Info");
			addcharstat("Race", $race);
		}
		break;

	case "chooserace":
		$pointsavailable = $session['user']['donation'] - $session['user']['donationspent'];
		if ($session['user']['dragonkills'] < get_module_setting("mindk") || get_module_setting("cost") > $pointsavailable)
			break;
		output("<a href='newday.php?setrace=$race$resline'>`&The towering city of `!%s</a>`& lies before you in all its glory. `!Titans`& proudly walk the halls and streets, not merely as villagers, but as vigilant protectors of their homes and ideals.`n`n",$city,true);
		addnav("`@Titan`0","newday.php?setrace=$race$resline");
		addnav("","newday.php?setrace=$race$resline");
		break;

	case "newday":
		if ($session['user']['race']==$race){
			racetitan_checkcity();
			if ($titan<=0){
				apply_buff("racialbenefit",array(
				"name"=>"`!Titanic Burden`0",
	 			"atkmod"=>"(-1*(<attack>?(1+((1+floor(<level>/5))/<attack>)):0))",
				"allowinpvp"=>1,
				"allowintrain"=>1,
				"rounds"=>-1,
				"schema"=>"module-racetitan",
				));
				output("`n`!The weight of Atlas's burden is upon your shoulders!  To be great, first you must prove your greatness!`0`n");
			} else {
				$session['user']['hitpoints']+=$titan;
				$bonusturns=(int)$titan/5;
				$session['user']['turns']+=$bonusturns;
				output("`n`&For being a rather heroic `!Titan`&, you receive %s extra hit points, and %s extra forest fights!`n", $titan, $bonusturns);
				if ($titan==50){
					apply_buff("racialbenefit",array(
					"name"=>"`!Titanic Power`0",
	 				"atkmod"=>"(<attack>?(1+((1+floor(<level>/5))/<attack>)):0)",
					"allowinpvp"=>1,
					"allowintrain"=>1,
					"rounds"=>-1,
					"schema"=>"module-racetitan",
					));
					output("`n`&For being the avatar of `!Titanic`& heroism, you receive an additional blessing of `!Celestial Strength!`0`n");
				}
			}	
		}
		break;

	case "pointsdesc":
		if (get_module_setting("mindk")>0 || $cost>0)
		{
			$args['count']++;
			$format = $args['format'];
			$str = translate("The Titan race is available upon reaching %s Dragon Kills and %s Donation points.");
			$str = sprintf($str, get_module_setting("mindk"),
					get_module_setting("cost"));
			output($format, $str, true);
		}
		break;

	case "pvpadjust":
	$enemyAL = get_module_pref('alignment','alignment',$badguy['acctid']);
		if($enemyAL >= 50) {
			$badguy['attack']+=(2+floor($badguy['level']/5));
		} else {
			$badguy['attack']-=(2+floor($badguy['level']/5));
		}
		if ($badguy['race'] == $race) {
			$baduy['hitpoints']+=($enemyAL-50);
		}
		break;

	case "raceminedeath":
      	if ($session['user']['race'] == $race) {
            	$args['chance'] = get_module_setting("minedeathchance");
		$args['racesave'] = "It was your superior nature as a Titan that allowed you to survive unscathed.`n";
		$args['schema']="module-racetitan";
      	}
	      break;

	case "setrace":
		if ($session['user']['race']==$race){
			output("`n`&As a `!Titan`&, you have the blood of gods running through your veins. `n");
			output("`^As such, you are held to a higher standard.  ");
			output("Both mortals and gods expect more from you.  ");
			output("You have the power and potential to challenge the fates, and rewrite history as you choose.  ");
			output("However, if you prove too mortal and flawed, the gods will turn their backs on you.  ");
			output("Do you have the strength of Atlas to take on the role of a hero?`n");
			output("Your growth and bonuses as a `!Titan`& is tied directly to your morality.  While half deity, you are half human as well.  ");
			output("You must shed your weak human weaknesses and vices.  Humans instinctually think of themselves first.  ");
			output("Their base and self-serving motives keep them from being truly great.  By turning your back on these vices, you will tap in to your celestial powers!`n");
			output("However, those of neutral alignments receive little to no bonus, and good aligned Titans are actually penalized.`n");
			if (is_module_active('alignment')) {
				align("5");
			}
			if (is_module_active("cities")) {
				if ($session['user']['dragonkills']==0 &&
						$session['user']['age']==0){
					//new farmthing, set them to wandering around this city.
					set_module_setting("newest-$city",
							$session['user']['acctid'],"cities");
				}
				set_module_pref("homecity",$city,"cities");
				$session['user']['location']=$city;
			}
		}
		break;

	}
	return $args;
}

function racetitan_checkcity(){
    global $session;
    $race="Titan";
    if (is_module_active("racehuman")) {
		$city = get_module_setting("villagename", "racehuman");
	} else {
		$city = getsetting("villagename", LOCATION_FIELDS);
	}
	
	if ($session['user']['race']==$race && is_module_active("cities")){
		//if they're this race and their home city isn't right, set it up.
		if (get_module_pref("homecity","cities")!=$city){ //home city is wrong
			set_module_pref("homecity",$city,"cities");
		}
	}
    return true;
}

function racetitan_run(){

}
?>
