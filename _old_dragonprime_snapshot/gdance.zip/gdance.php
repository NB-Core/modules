<?php
// addnews ready
// mail ready
// translator ready

// Gypsy Dance Hut, programmed by Niksolo
// 4/26/05
require_once("common.php");
require_once("lib/sanitize.php");
require_once("lib/http.php");
require_once("lib/villagenav.php");

function gdance_getmoduleinfo(){
	$info = array(
		"name"=>"Aura's Gypsy Dance Hut",
		"version"=>"1.0",
		"author"=>"Niksolo",
		"category"=>"Village",
		"download"=>"http://dragonprime.net/users/Finwe/gdance.zip",
		"settings"=>array(
			"gdanceloc"=>"Where does the Hut appear,location|".getsetting("villagename", LOCATION_FIELDS)
		),
		"prefs"=>array(
			"dancetoday"=>"Has the user danced today?,bool|0",
		)
	);
	return $info;
}

function gdance_install(){
	module_addhook("changesetting");
	module_addhook("newday");
	module_addhook("village");
	return true;
}

function gdance_uninstall(){
	return true;
}

function gdance_dohook($hookname,$args){
	global $session;
	switch($hookname){
	case "newday":
		set_module_pref("dancetoday",0,"gdance");
		break;
	case "changesetting":
		if ($args['setting'] == "villagename") {
			if ($args['old'] == get_module_setting("gdanceloc")) {
				set_module_setting("gdanceloc", $args['new']);
			}
		}
		break;
	case "village":
		if ($session['user']['location'] == get_module_setting("gdanceloc")) {
			tlschema($args['schemas']['marketnav']);
			addnav($args['marketnav']);
			tlschema();
			addnav("A?Aura's Gypsy Dance Hut","runmodule.php?module=gdance");
		}
		break;
	}
	return $args;
}

function gdance_run(){
	global $session;
	$price= (($session['user']['level']*($session['user']['dragonkills']+1))+250);
	$op = httpget("op");
	$dancetoday=get_module_pref("dancetoday");
	page_header("Aura's Gypsy Dance Hut");
	output("`7`c`bAura's Gypsy Dance Hut`b`c");
	$op = httpget('op');
	if ($op==""){
		checkday();
		output("`7You enter the large grassy hut.  You notice Aura standing off to the side with some students.`n`n");
		output("`7She notices you and comes over.`n`n");
		output("`3\"`&Greetings, %s,`3\" `7Aura says with a Neko smile.",$session['user']['sex']?"Madam":"Sir");
		if ($dancetoday==0 && $session['user']['gold']<$price){
		output("`3\"You seem to be short on gold, perhaps when you can afford my services I will teach you.`3\"`n`n");
		}elseif ($dancetoday==1){
		output("`3\"I'm sorry, but I must teach other students besides you today, come back tomorrow.`3\"`n`n");
		}
	}elseif($op=="rak" && $dancetoday==0){
		output("`7You dance around to the tune of the Raks al Sharki.`n`n");
		output("`7The dance makes you feel like you can dodge more attacks now.`n`n");
		apply_buff('gdance',array("name"=>"Gypsy Agility","rounds"=>20,"defmod"=>1.02));
		set_module_pref("dancetoday",1);
	}elseif($op=="duffali" && $dancetoday==0){
		output("`7You dance around to the tune of the Duffali.`n`n");
		output("`7The beats pump through your blood and you feel stronger within.`n`n");
		apply_buff('gdance',array("name"=>"Gypsy Strength","rounds"=>20,"atkmod"=>1.05));
		set_module_pref("dancetoday",1);
	}elseif($op=="banjara" && $dancetoday==0){
		output("`7You dance around to the tune of the Banjara.`n`n");
		output("`7With your heartrate up, you feel like you can endure more.`n`n");
		$session['user']['hitpoints']+=200;
		set_module_pref("dancetoday",1);
	}elseif($op=="madrigal" && $dancetoday==0){
		output("`7You dance around to the tune of the Romany Madrigal.`n`n");
		output("`7You become more graceful and charming.`n`n");
		$session['user']['charm']+=5;
		set_module_pref("dancetoday",1);
	}else{
		output("`7You feel that you have had enough dancing for now.`n`n");
	}
	villagenav();
	addnav("Dance");
	if ($dancetoday==0 && $session['user']['gold']>=$price){
		addnav("R?Raks al Sharki","runmodule.php?module=gdance&op=rak");
		addnav("D?Duffali Dance","runmodule.php?module=gdance&op=duffali");
		addnav("B?Banjara Dance","runmodule.php?module=gdance&op=banjara");
		addnav("o?Romany Madrigal","runmodule.php?module=gdance&op=madrigal");
	}
	page_footer();
}

?>

