<?php
/*
Module Name:  ruinworld2.php
Category:  Forest/LostRuins Addon
Worktitle:  Ruin World 2: Dinosaur World
Author:  DaveS
Date:  May 22, 2006

Based on an idea by Eph

Works as one of the locations that can be discovered in the Lost Ruins.  Also, can be encountered in the forest.

Description:
Step into a strange world of dinosaurs.  Go to the village to buy goods from the natives,
fight a dinosaur in a cave, search after a pterodactyl, or pick flowers in the plains.

v3.01	Fixed broken dinosaurs
v3.02	Pterodactyl gems op fixed
v3.03	Specialinc clearance was missing in defeat
v3.04 	Fixed the Deadly Exotic Flower 
*/

function ruinworld2_getmoduleinfo(){
	$info = array(
		"name"=>"Ruin World 2: Dinosaur World",
		"version"=>"3.04",
		"author"=>"DaveS",
		"category"=>"Forest Specials",
		"download"=>"",
		"settings"=>array(
			"Ruin World 2: Dinosaur World,title",
			"mindk"=>"Minimum dks for player to encounter the Dinosaur World:,int|1",
			"forest"=>"Chance to encounter in the forest:,range,5,100,5|100",
			"dkreset"=>"Dks since starting the module to reset the module?,range,1,30,1|8",
			"usepics"=>"Allow player to see pictures?,bool|1",
			"random"=>"How many times can players run into a random dinosaur,range,0,10,1|3",
			"permhp"=>"Allow chance to gain a permanent hp from healer?,bool|1",
			"healerstall"=>"Dks since starting the module needed to visit the Healer's Stall?,range,1,30,1|1",
			"weaponstall"=>"Dks since starting the module needed to visit the Weapon Stall?,range,1,30,1|3",
			"foodstall"=>"Dks since starting the module needed to visit the Food Stall?,range,1,30,1|4",
			"mysticstall"=>"Dks since starting the module needed to visit the Mystic Stall?,range,1,30,1|5",
			"pterodk"=>"Dks since starting the module needed to hunt the Pterodactyl?,range,1,30,1|4",
			"pterogold"=>"Maximum gold that could be stolen from the Pterodactyl nest?,int|1000",
			"pterogem"=>"Maximum gems that could be stolen from the Pterodactyl nest?,int|3",
			"permhppter"=>"Allow chance to gain a permanent hp from eating pterodactyl egg?,bool|1",
			"Cave Dinosaur,title",
			"dlhp"=>"Multiplier for Cave Dinosaur's hitpoints:,floatrange,1.0,2.0,0.1|1.2",
			"dlatt"=>"Multiplier for Cave Dinosaur's attack:,floatrange,1.0,2.0,0.1|1.2",
			"dldef"=>"Multiplier for Cave Dinosaur's defense:,floatrange,1.0,2.0,0.1|1.2",
			"Pterodactyl Pet,title",
			"dbabyid1"=>"Baby Pterodactyl Mount ID,viewonly",
			"djuvenileid1"=>"Juvenile Pterodactyl Mount ID,viewonly",
			"dadultid1"=>"Adult Pterodactyl Mount ID,viewonly",
			"Raptor Pet, title",
			"dbabyid2"=>"Baby Raptor Mount ID,viewonly",
			"djuvenileid2"=>"Juvenile Raptor Mount ID,viewonly",
			"dadultid2"=>"Adult Raptor Mount ID,viewonly",
			"Triceratops Pet,title",
			"dbabyid3"=>"Baby Triceratops Mount ID,viewonly",
			"djuvenileid3"=>"Juvenile Triceratops Mount ID,viewonly",
			"dadultid3"=>"Adult Triceratops Mount ID,viewonly",
		),
		"prefs"=>array(
			"Ruin World 2: Dinosaur World,title",
			"encountered"=>"Has player been to Dinosaur World today?,bool|0",
			"first"=>"Has player ever been to Dinosaur World?,bool|0",
			"random"=>"How many times has the player run into a random dinosaur?,int|0",
			"rdinofight"=>"Is the player currently fighting a random dino?,bool|0",
			"randop2"=>"Where was the player when they ran into the random dinosaur?,viewonly",
			"dkstart"=>"Dks since starting Dinosaur World?,int|0",
			"Pterodactyl Hunt,title",
			"pterodactyl"=>"Has the player considered the Pterodactyl Hunt?,bool|0",
			"pteroday"=>"Has the player hunted the Pterodactyl today?,bool|0",
			"pterofight"=>"Has the player killed the Pterodactyl?,enum,0,No,1,Yes,2,in Process|0",
			"pteronest"=>"Has the player ransacked the Pterodactyl Nest?,bool|0",
			"pterocliffg"=>"Has the player received gold/gem for throwing rocks at the nest?,bool|0",
			"pterothrow"=>"How many times have they throw rocks at the nest?,enum,0,0,1,1,2,2,3,3,4,4,5,Done|0",
			"Plain,title",
			"plain"=>"Has the player been to the Plain?,bool|0",
			"shaman"=>"Has the player killed the Shaman?,enum,0,No,1,Yes,2,in Process,3,Lost the Fight|0",
			"Village,title",
			"village"=>"Has the player been to the Village?,bool|0",
			"gemtrade"=>"Has the player learned about trading gems?,bool|0",
			"buyelixir"=>"Has the player purchased an elixir today?,bool|0",
			"buyfood"=>"Has the player purchased food today?,bool|0",
			"buyweapon"=>"Has the player purchased a new weapon?,bool|0",
			"mystic"=>"Has the player visited the mystic?,bool|0",
			"Cave,title",
			"cavevisit"=>"Has the player been to the cave?,bool|0",
			"haslight"=>"Did the player find a light source for the Cave?,bool|0",
			"cave2"=>"Has the player been to the fork in the cave?,bool|0",
			"cavefind"=>"Has the player found a gold/gem in the cave?,bool|0",
			"killdino"=>"Has the player killed the Cave Dino?,enum,0,No,1,Yes,2,in Process|0",
			"dinoegg"=>"Did the player get a dinosaur egg from the cave?,enum,0,No,1,Yes,2,Used|0",
			"Dinosaur Pet,title",
			"whichdino"=>"Which Dinosaur Egg did the player get?,enum,0,None,1,Pterodactyl,2,Raptor,3,Triceratops|0",
			"deggage1"=>"Pterodactyl Egg Age,int|0",
			"deggage2"=>"Raptor Egg Age,int|0",
			"deggage3"=>"Triceratops Egg Age,int|0",
		),
	);
	return $info;
}
function ruinworld2_chance() {
	global $session;
	$ret= get_module_setting('forest','ruinworld2');
	if ($session['user']['dragonkills']<get_module_setting("mindk","ruinworld2")||get_module_pref("encountered","ruinworld2",$session['user']['acctid'])==1) $ret=0;
	return $ret;
}
function ruinworld2_install(){
	if (!is_module_active('ruinworld2')){
		include("modules/ruinworld2/ruinworld2_install.php");
	}
	module_addeventhook("forest","require_once(\"modules/ruinworld2.php\");
	return ruinworld2_chance();");
	module_addhook("dragonkill");
	module_addhook("newday");	
	return true;
}
function ruinworld2_uninstall(){
	//Modified from Lonny Luberts' Garland's Stable
	$sql = "DELETE FROM ".db_prefix("mounts")." where mountname='Baby Pterodactyl'";
	db_query($sql);
	output("Baby Pterodactyl Mount deleted.`n");
	$sql = "DELETE FROM ".db_prefix("mounts")." where mountname='Young Pterodactyl'";
	db_query($sql);
	output("Young Pterodactyl Mount deleted.`n");
	$sql = "DELETE FROM ".db_prefix("mounts")." where mountname='Pterodactyl'";
	db_query($sql);
	output("Pterodactyl Mount deleted.`n");
	$sql = "DELETE FROM ".db_prefix("mounts")." where mountname='Baby Raptor'";
	db_query($sql);
	output("Baby Raptor Mount deleted.`n");
	$sql = "DELETE FROM ".db_prefix("mounts")." where mountname='Young Raptor'";
	db_query($sql);
	output("Young Raptor Mount deleted.`n");
	$sql = "DELETE FROM ".db_prefix("mounts")." where mountname='Raptor'";
	db_query($sql);
	output("Raptor Mount deleted.`n");
	$sql = "DELETE FROM ".db_prefix("mounts")." where mountname='Baby Triceratops'";
	db_query($sql);
	output("Baby Triceratops Mount deleted.`n");
	$sql = "DELETE FROM ".db_prefix("mounts")." where mountname='Young Triceratops'";
	db_query($sql);
	output("Young Triceratops Mount deleted.`n");
	$sql = "DELETE FROM ".db_prefix("mounts")." where mountname='Triceratops'";
	db_query($sql);
	output("Triceratops Mount deleted.`n");
	//end Lonny's code
	return true;
}
function ruinworld2_dohook($hookname,$args){
	global $session;
	switch($hookname){
		case "newday":
			set_module_pref("encountered",0);
			set_module_pref("buyelixir",0);
			set_module_pref("buyfood",0);
			set_module_pref("pteroday",0);
			include("modules/ruinworld2/ruinworld2_newday.php");
		break;
		case "dragonkill":
			if (get_module_pref("first")==1) increment_module_pref("dkstart",1);
			if (get_module_pref("dkstart")>=get_module_setting("dkreset")){
				clear_module_pref("encountered");
				clear_module_pref("first");
				clear_module_pref("random");
				clear_module_pref("rdinofight");
				clear_module_pref("randop2");
				clear_module_pref("dkstart");
				clear_module_pref("pterodactyl");
				clear_module_pref("pteroday");
				clear_module_pref("pterofight");
				clear_module_pref("pteronest");
				clear_module_pref("pterocliffg");
				clear_module_pref("pterothrow");
				clear_module_pref("plain");
				clear_module_pref("shaman");
				clear_module_pref("village");
				clear_module_pref("gemtrade");
				clear_module_pref("buyelixir");
				clear_module_pref("buyfood");
				clear_module_pref("buyweapon");
				clear_module_pref("mystic");
				clear_module_pref("cavevisit");
				clear_module_pref("haslight");
				clear_module_pref("cave2");
				clear_module_pref("cavefind");
				clear_module_pref("killdino");
				clear_module_pref("dinoegg");
			}
		break;
	}
	return $args;
}
function ruinworld2_runevent($type) {
	redirect("runmodule.php?module=ruinworld2&op=enter1");
}
function ruinworld2_run(){
	global $SCRIPT_NAME;
	if ($SCRIPT_NAME == "runmodule.php"){
		$module=httpget("module");
		if ($module == "ruinworld2"){
			include("modules/ruinworld2/ruinworld2.php");
		}
	}
}
?>