<?php
global $playermount;
$i=get_module_pref("whichdino");
if ($i==1) $dino="Pterodactyl";
if ($i==2) $dino="Raptor";
if ($i==3) $dino="Triceratops";
	//Modified from Lonny Luberts' Garland's Stable
	if (get_module_pref('deggage'.$i) <> 0){
		if ($playermount['mountid'] == get_module_setting("dbabyid".$i) or $playermount['mountid'] == get_module_setting("djuvenileid".$i) or $playermount['mountid'] == get_module_setting("dadultid".$i)){
			increment_module_pref('deggage'.$i,1);
			output("`n`#Your %s ages another day.`n",$playermount['mountname']);
		}else{
			set_module_pref('deggage'.$i,0);
		}
	}
	if (get_module_pref('deggage'.$i) > 25 and $session['user']['hashorse']==get_module_setting('dbabyid'.$i)){
		//let's make him a juvenile
		output("Your %s is maturing!`n",$dino);
		output("Your %s is now a Juvenile.`7`n",$dino);
		$session['user']['hashorse']=get_module_setting('djuvenileid'.$i);
		$sql = "SELECT * FROM ".db_prefix("mounts")." where mountid='".get_module_setting('djuvenileid'.$i)."'";
		$result = db_query($sql);
		$mount = db_fetch_assoc($result);
		$session['bufflist']['mount']=unserialize($mount['mountbuff']);
	}
	if (get_module_pref('deggage'.$i) > 50 and $session['user']['hashorse']==get_module_setting('djuvenileid'.$i)){
		//let's make him adult
		//now we need to clear eggage
		output("Your %s is maturing!`n",$dino);
		output("Your %s has fully Matured!`7`n",$dino);
		$session['user']['hashorse']=get_module_setting('dadultid'.$i);
		$sql = "SELECT * FROM ".db_prefix("mounts")." where mountid='".get_module_setting('dadultid'.$i)."'";
		$result = db_query($sql);
		$mount = db_fetch_assoc($result);
		$session['bufflist']['mount']=unserialize($mount['mountbuff']);
		$playermount = getmount($mount['mountid']);
		set_module_pref('deggage',0);
	}
	//End Lonny's Code
?>