<?php
	global $session,$playermount;
	$op = httpget('op');
	$op2= httpget('op2');
	$op3= httpget('op3');
	$id = httpget('id');
	$cost = httpget('cost');
	$page = httpget('page');
	$skill = httpget('skill');
	page_header("Paleozene World");
	$dkstart=get_module_pref("dkstart");
if ($op=="enter"){
	set_module_setting("ruin2found",0,"lostruins");
	redirect("runmodule.php?module=ruinworld2&op=enter1");
}

if ($op=="enter1"){
	output("`#`c`bPaleozene World`c`b`n`3");
	output("You step into a very disorienting mist.");
	if (get_module_pref("first")==0){
		output("`n`nYour head starts to ache and you rub your eyes. When you open them the mist obscures your vision.");
		output("Then, you notice that the air is much more humid than what you're used to.");
		output("The mist lifts slowly and you start to notice that the trees are different here. They appear much more tropical.");
		output("It seems like you've stepped into a different world. You hesitate and turn around to make sure you can get out, but there's nothing behind you.");
	}else{
		output("You recognize where you are and turn to try to secure your exit but as the mist fades, so does your exit.");
	}
	$session['user']['specialinc']="module:ruinworld2";
	set_module_pref("encountered",1);
	addnav("Continue","runmodule.php?module=ruinworld2&op=c&op2=continue");	
	blocknav("runmodule.php?module=ruinworld2&op=c&op2=leave");
}
if ($op=="c"){
//Random encounters start here:
$rand=e_rand(1,120);
if (($rand==119 || $rand==118) && get_module_pref("haslight")==0){
	output("`#`c`bPaleozene World`c`b`n`3");
	output("You step in something nasty with a stick poking out of it.");
	output("`n`nYou smell the stick and realize there's tar on it.");
	output("After thinking it through for a moment, you realize that this could make a great torch!`n`n");
	set_module_pref("haslight",1);
	addnav("Continue","runmodule.php?module=ruinworld2&op=c&op2=$op2");
}elseif ($rand==120 && get_module_pref("random")<=get_module_setting("random")){
	output("`#`c`bPaleozene World`c`b`n`3");
	output("Suddenly you're attacked by a dinosaur!!");
	set_module_pref("rdinofight",1);
	increment_module_pref("random",1);
	set_module_pref("randop2",$op2);
	addnav("Fight Dinosaur","runmodule.php?module=ruinworld2&op=attack");
}else{
if ($op2=="continue"){
	output("`#`c`bPaleozene World`c`b`n`3");
	if (get_module_pref("first")==0){
		output("It takes a little while for you to figure out what's going on here... You've stepped into a world that time forgot.");
		output("`n`nYou hear a huge piercing cry from a creature flying over head.  You look up, ready to face the `@Green Dragon`3 but are perplexed by a much stranger creature.");
		output("You recall stories that your mother used to tell you of huge reptiles from millions of years ago and you realize that the flying creature is a pterodactyl.");
		output("You've stepped into the Land of Dinosaurs!");
		output("`n`nYou wander around a little and take note of some of the surroundings.");
		set_module_pref("first",1);
	}
	output("There appears to be a large cave off to your right.");
	output("Over to your left you see a wide open plain with a huge bed of flowers.");
	output("Down a hill in front of you there is a small village.");
	output("You could also chase after a pterodactyl.");
	if (get_module_setting("usepics")==1) rawoutput("<br><center><table><tr><td align=center><img src=modules/ruinworld2img/start.gif></td></tr></table></center><br>"); 
	addnav("Explore");
	addnav("The Cave","runmodule.php?module=ruinworld2&op=c&op2=cave");
	addnav("Open Plain","runmodule.php?module=ruinworld2&op=c&op2=plain");
	addnav("Down the Hill","runmodule.php?module=ruinworld2&op=c&op2=hill");
	if ($dkstart>=get_module_setting("pterodk"))addnav("Find the Pterodactyl","runmodule.php?module=ruinworld2&op=c&op2=pterodactyl");
	if (get_module_pref("cavevisit")==1&& get_module_pref("plain")==1 && get_module_pref("village")==1){
		output("`n`nYou look around and notice a hazy area where you first came to this world.");
		addnav("Try to Leave","runmodule.php?module=ruinworld2&op=exit&op2=try");
	}
	modulehook ("ruinworld2-continue"); 
}
if ($op2=="pterodactyl"){
	output("`#`c`bPterodactyl Hunt`c`b`n`3");
	if (get_module_pref("pteroday")==1){
		output("You decide that it's not a good idea to try to track down the pterodactyl more than once in a day.");
	}else{
		set_module_pref("pteroday",1);
		set_module_pref("pterodactyl",1);
		if ($session['user']['turns']<3){
			output("You start after the pterodactyl but realize that you'll need about `@3 turns`3 to track it down.");
			output("Since you don't have enough turns right now, you might as well head back.");	
		}else{
			output("As soon as you catch site of how far away the pterodactyl is, you calculate that it will probably take about `@3 turns`3 to track it down.");
			output("`n`nAre you ready to go after it?");
			addnav("Pterodactyl Hunt","runmodule.php?module=ruinworld2&op=c&op2=pterihunt1");
		}
	}
	addnav("Go Back","runmodule.php?module=ruinworld2&op=c&op2=continue");
}
if ($op2=="pterihunt1"){
	output("`#`c`bPterodactyl Hunt`c`b`n`3");
	$session['user']['turns']--;
	output("You start to cautionsly track the pterodactyl. Although the terrain is a little more overgrown than what you're used to in the forest, you find yourself doing a rather admirable job at tracking down the great reptile.");
	addnav("Continue","runmodule.php?module=ruinworld2&op=c&op2=pterihunt2");
}
if ($op2=="pterihunt2"){
	output("`#`c`bPterodactyl Hunt`c`b`n`3");
	$session['user']['turns']--;
	output("Soon enough you're coming up to a steep cliff. You look up and notice a nest high above you.");
	output("`n`nWhat will you do?");
	if (get_module_pref("pterothrow")<5) addnav("Throw Rocks at the Nest","runmodule.php?module=ruinworld2&op=pterirocks");
	addnav("Climb the Cliff","runmodule.php?module=ruinworld2&op=ptericliff");
	addnav("Leave","runmodule.php?module=ruinworld2&op=pteriretreat");
}
if ($op2=="hill"){
	output("`#`c`bHabilis Village`c`b`n`3");
	set_module_pref("village",1);
	output("You enter a small village.  There is a nervous activity here with people on their guard.  It looks like a small market is open.");
	if ($dkstart==0) output("`n`nIt seems like there may be more stalls to visit, but the villagers block you from going to them all.  Perhaps after you've killed the dragon a couple more times you'll be able to look for more to buy.");
	$mystic=e_rand(1,3);
	addnav("The Market");
	addnav("General Items Stall","runmodule.php?module=ruinworld2&op=generalstall");
	if ($dkstart>=get_module_setting("healerstall")) addnav("Healing Stall","runmodule.php?module=ruinworld2&op=healingstall");
	if ($dkstart>=get_module_setting("foodstall")) addnav("Food Stall","runmodule.php?module=ruinworld2&op=foodstall");
	if ($dkstart>=get_module_setting("weaponstall")) addnav("Weapons Stall","runmodule.php?module=ruinworld2&op=weaponstall");
	if (get_module_pref("mystic")==0 && $mystic==1 && $dkstart>=get_module_setting("mysticstall")) addnav("Mystic Stall","runmodule.php?module=ruinworld2&op=mysticstall");
	modulehook ("ruinworld2-hill"); 
	addnav("Other");
	addnav("Leave the Village","runmodule.php?module=ruinworld2&op=c&op2=continue");
}
if ($op2=="plain"){
	output("`#`c`bThe Plain`c`b`n`3");
	set_module_pref("plain",1);
	output("You travel down to the plain to look around. You're a bit nervous and on guard with every step.");
	output("`n`nYou get down and look around.  There is an amazing patch of flowers; more exotic and beautiful than any you've ever seen before.");
	addnav("Pick Flowers","runmodule.php?module=ruinworld2&op=c&op2=pickfl");
	if (get_module_pref("shaman")==0){
		output("`n`nYou're slightly distracted as you stare at the flowers when suddenly an old shaman taps you on your shoulder.");
		addnav("Talk to the Old Shaman","runmodule.php?module=ruinworld2&op=c&op2=talksham");
		addnav("Attack the Old Shaman","runmodule.php?module=ruinworld2&op=c&op2=attsham");
	}
	modulehook ("ruinworld2-plain"); 
	addnav("Leave the Plain","runmodule.php?module=ruinworld2&op=c&op2=continue");
}
if ($op2=="talksham"){
	output("`#`c`bThe Shaman`c`b`n`3");
	if ($session['user']['turns']>0){
		output("Since the Shaman does not speak your language, you spend a turn trying to figure a communication system.");
		$session['user']['turns']--;
	}
	output("You start communicating with simple hand gestures and you're soon understanding most things that the Shaman is trying to tell you.");
	output("`n`n`@'I knew you come. Help you?'");
	ruinworld2_shamannavs();
}
if ($op2=="shamlight"){
	output("`#`c`bThe Shaman`c`b`n`3");
	output("`@'Light is good.'");
	switch(e_rand(1,10)){
		case 1: case 2: case 3: case 4: case 5: case 6: case 7: case 8: case 9:
		break;
		case 10:
			output("`n`n`3A bit confused, you ask for more information.  The Shaman, getting a little frustrated, tears a bit of cloth off his robe and breaks his staff in half.`n`n");
			output("He hands you the make-shift torch and you nod thankfully to him.");
			set_module_pref("haslight",1);
		break;
	}
	blocknav("runmodule.php?module=ruinworld2&op=c&op2=shamlight");
	ruinworld2_shamannavs();
}
if ($op2=="shamdino"){
	output("`#`c`bThe Shaman`c`b`n`3");
	output("`@'Three types of dinosaurs:'");
	output("`n`n'Pterodactyls fly.  Speed makes difficult to defeat in battle.'");
	output("`n`n'Raptors eat meat.  Aggressive and strong.'");
	output("`n`n'Triceratops eat plants.  Tough armor, slow, but strong.'");
	blocknav("runmodule.php?module=ruinworld2&op=c&op2=shamdino");
	ruinworld2_shamannavs();
}
if ($op2=="shamleave"){
	output("`#`c`bThe Shaman`c`b`n`3");
	output("`@'I do not know.'");
	blocknav("runmodule.php?module=ruinworld2&op=c&op2=shamleave");
	ruinworld2_shamannavs();
}
if ($op2=="shampeople"){
	output("`#`c`bThe Shaman`c`b`n`3");
	output("`@'My people called Habilis. We live in small village down hill. Perhaps you visit and trade.'");
	blocknav("runmodule.php?module=ruinworld2&op=c&op2=shampeople");
	ruinworld2_shamannavs();
}
if ($op2=="shamflowers"){
	output("`#`c`bThe Shaman`c`b`n`3");
	output("`@'Flowers beautiful. Strong medicine.  Some offer blessings.  Some are dangerous.'");
	blocknav("runmodule.php?module=ruinworld2&op=c&op2=shamflowers");
	ruinworld2_shamannavs();
}
if ($op2=="attsham"){
	set_module_pref("shaman",2);
	redirect("runmodule.php?module=ruinworld2&op=attack");
}
if ($op2=="pickfl"){
	output("`#`c`bFlowers`c`b`n`3");
	output("You decide to pick some of the flowers.  You have the choice of keeping a flower for yourself or bringing it home and giving it to anyone you would like to.");
	addnav("Keep Flower","runmodule.php?module=ruinworld2&op=c&op2=keepfl");
	addnav("Send Flower","runmodule.php?module=ruinworld2&op=sendfl");
	addnav("Leave the Plain","runmodule.php?module=ruinworld2&op=c&op2=continue");
}
if ($op2=="keepfl"){
	output("`#`c`bFlowers`c`b`n`3");
	output("How can you pass up the opportunity of keeping this amazing flower?`n`n");
	addnav("Continue","runmodule.php?module=ruinworld2&op=exit");
	switch(e_rand(2,2)){
		case 1:
			output("The flower makes you feel stronger!");
			apply_buff('dinoflower',array(
				"name"=>"`5Exotic Flower",
				"rounds"=>15,
				"wearoff"=>"Your pretty flower dies.",
				"atkmod"=>1.3,
				"defmod"=>1.4,
				"roundmsg"=>"`4You sniff your flower and gather strength from it.",
			));
		break;
		case 2:
			output("The flower looks up at you and smiles.`n`n");
			output("`@'I think I can help you!'");
			output("`n`n`3Not only did you find a talking flower, but you found one that will fight by your side!");
			apply_buff('dinoflower',array(
				"name"=>"`5Exotic Flower",
				"rounds"=>10,
				"wearoff"=>"Your pretty flower dies.",
				"minioncount"=>1,
				"minbadguydamage"=>1,
				"maxbadguydamage"=>$session['user']['level']+3,
				"effectmsg"=>"`5Your opponent takes `^{damage} `5damage from the flower!`0",
				"startmsg"=>"`4Your flower starts fighting by your side!",
			));
		break;
		case 3:
			output("You pick the flower and start sneezing. Oh no! You're allergic to it!");
			apply_buff('dinoflower',array(
				"name"=>"`5Flower Allergy",
				"rounds"=>25,
				"wearoff"=>"The rash finally goes away.",
				"atkmod"=>.97,
				"defmod"=>.96,
				"roundmsg"=>"`4You sneeze in the middle of the fight and lose some of your concentration.",
				"startmsg"=>"`4You're allergic to the flower!",
			));
		break;
		case 4:
			output("As soon as you try to pick it, it slaps your hand!! It causes you to lose");
			if ($session['user']['hitpoints']<=20) {
				output("`\$all of your hitpoints except 1`3.");
				$session['user']['hitpoints']=1;
			}else{
				output("`\$20 hitpoints`3.");
				$session['user']['hitpoints']-=20;
			}
			output("`n`nThese are some tough flowers!");
		break;
		case 5:
			output("You take the flower and eventually sell it for `^200 gold`3!");
			$session['user']['gold']+=200;
		break;
		case 6:
			output("You put the flower in your hair.");
			if ($session['user']['sex']==0){
				require_once("lib/titles.php");
				require_once("lib/names.php");
				$newtitle = "`%Pretty`^Boy`0";
				$newname = change_player_title($newtitle);
				$session['user']['title'] = $newtitle;
				$session['user']['name'] = $newname;
				output("You really look like a `%Pretty `^Boy`3!!`n`n");
			}
			output("Your `&charm`3 increases by `&2`3!");
			$session['user']['charm']+=2;
		break;
	}
}
if ($op2=="cave"){
	output("`#`c`bThe Cave`c`b`n`3");
	if ($op3=="abandon") output("You abandon the egg.`n`n");
	if (get_module_pref("dinoegg")==1){
		set_module_pref("dinoegg",2);
		output("You make it to the cave entrance with the egg. You'll have to decide what you would like to do.");
		output("`n`nIf you would like to keep this egg, it will grow into a dinosaur and will replace your current mount.");
		output("Otherwise, if you abandon the egg it will probably be eaten by a predator.  Of course, you don't know for sure what kind of dinosaur egg this is.");
		output("`n`nWhat would you like to do?");
		addnav("Raise the Egg","runmodule.php?module=ruinworld2&op=raiseegg");
		addnav("Abandon the Egg","runmodule.php?module=ruinworld2&op=c&op2=cave&op3=abandon");
	}else{
		if (get_module_pref("cavevisit")==0){
			set_module_pref("cavevisit",1);
			output("Never one to pass up a cave full of untold danger, you decide to venture into the cave.");
			output("`n`nThe first thing you notice is some strange cave paintings.");
			output("The cave gets dark very quickly. It's probably best not to venture into the cave without some source of light.`n`n");	
		}
		output("Each moment you spend standing in the cave entrance makes you more nervous.`n`n");
		require_once("lib/commentary.php");
		addcommentary();
		viewcommentary("lostcave","Scrawl on the Cave",20,"writes");
		addnav("Examine the Drawings","runmodule.php?module=ruinworld2&op=c&op2=cavedrawings");
		addnav("Go Deeper Into the Cave","runmodule.php?module=ruinworld2&op=cavedeep1");
		addnav("Exit the Cave","runmodule.php?module=ruinworld2&op=c&op2=continue");
		modulehook ("ruinworld2-cave"); 
	}
}
if ($op2=="cavedrawings"){
	output("`#`c`bThe Cave`c`b`n`3");
	if (get_module_setting("usepics")==1){
		rawoutput("<br><center><table><tr><td align=center><img src=modules/ruinworld2img/cave1.gif></td></tr></table></center><br>"); 
	}
	output("Clearly the drawings tell some type of story.`n`n");
	if (get_module_setting("usepics")==0){
		output("The first one shows a battle.  A warrior carries a spear and seems to be attacking a dinosaur.");
	}
	addnav("Next Picture","runmodule.php?module=ruinworld2&op=c&op2=cavedrawings2");
	addnav("Cave Entrance","runmodule.php?module=ruinworld2&op=c&op2=cave");
	addnav("Exit the Cave","runmodule.php?module=ruinworld2&op=c&op2=continue");
}
if ($op2=="cavedrawings2"){
	output("`#`c`bThe Cave`c`b`n`3");
	if (get_module_setting("usepics")==1){
		rawoutput("<br><center><table><tr><td align=center><img src=modules/ruinworld2img/cave2.gif></td></tr></table></center><br>"); 
	}else{
		output("The second shows the warrior successfully killing the dinosaur.");
	}
	addnav("Next Picture","runmodule.php?module=ruinworld2&op=c&op2=cavedrawings3");
	addnav("Previous Picture","runmodule.php?module=ruinworld2&op=c&op2=cavedrawings");
	addnav("Cave Entrance","runmodule.php?module=ruinworld2&op=c&op2=cave");
}
if ($op2=="cavedrawings3"){
	output("`#`c`bThe Cave`c`b`n`3");
	if (get_module_setting("usepics")==1) {
		rawoutput("<br><center><table><tr><td align=center><img src=modules/ruinworld2img/cave3.gif></td></tr></table></center><br>"); 
	}else{
		output("The third shows the warrior kneeling before a set of eggs.");
	}
	addnav("Next Picture","runmodule.php?module=ruinworld2&op=c&op2=cavedrawings4");
	addnav("Previous Picture","runmodule.php?module=ruinworld2&op=c&op2=cavedrawings2");
	addnav("Cave Entrance","runmodule.php?module=ruinworld2&op=c&op2=cave");
}
if ($op2=="cavedrawings4"){
	output("`#`c`bThe Cave`c`b`n`3");
	if (get_module_setting("usepics")==1){
		rawoutput("<br><center><table><tr><td align=center><img src=modules/ruinworld2img/cave4.gif></td></tr></table></center><br>"); 
		addnav("Next Picture","runmodule.php?module=ruinworld2&op=c&op2=cavedrawings5");
	}else{
		output("The final pictures shows the warrior apparently carrying the egg and fleeing.");
		addnav("Back to the Cave Entrance","runmodule.php?module=ruinworld2&op=c&op2=cave");
	}
	addnav("Previous Picture","runmodule.php?module=ruinworld2&op=c&op2=cavedrawings3");
	addnav("Cave Entrance","runmodule.php?module=ruinworld2&op=c&op2=cave");
}
if ($op2=="cavedrawings5"){
	output("`#`c`bThe Cave`c`b`n`3");
	rawoutput("<br><center><table><tr><td align=center><img src=modules/ruinworld2img/cave5.gif></td></tr></table></center><br>"); 
	addnav("Next Picture","runmodule.php?module=ruinworld2&op=c&op2=cavedrawings6");
	addnav("Previous Picture","runmodule.php?module=ruinworld2&op=c&op2=cavedrawings4");
	addnav("Cave Entrance","runmodule.php?module=ruinworld2&op=c&op2=cave");
}
if ($op2=="cavedrawings6"){
	output("`#`c`bThe Cave`c`b`n`3");
	rawoutput("<br><center><table><tr><td align=center><img src=modules/ruinworld2img/cave6.gif></td></tr></table></center><br>"); 
	addnav("Next Picture","runmodule.php?module=ruinworld2&op=c&op2=cavedrawings7");
	addnav("Previous Picture","runmodule.php?module=ruinworld2&op=c&op2=cavedrawings5");
	addnav("Cave Entrance","runmodule.php?module=ruinworld2&op=c&op2=cave");
}
if ($op2=="cavedrawings7"){
	output("`#`c`bThe Cave`c`b`n`3");
	rawoutput("<br><center><table><tr><td align=center><img src=modules/ruinworld2img/cave7.gif></td></tr></table></center><br>"); 
	addnav("First Picture","runmodule.php?module=ruinworld2&op=c&op2=cavedrawings");
	addnav("Previous Picture","runmodule.php?module=ruinworld2&op=c&op2=cavedrawings6");
	addnav("Cave Entrance","runmodule.php?module=ruinworld2&op=c&op2=cave");
}
}
}
if ($op=="pterirocks"){
	output("`#`c`bPterodactyl Cliff`c`b`n`3");
	if ($id>=5){
		output("You can't find anymore rocks to throw.");
	}else{
		increment_module_pref("pterothrow",1);
		$id=get_module_pref("pterothrow");
		addnav("Throw More Rocks","runmodule.php?module=ruinworld2&op=pterirocks&id=$id");
		output("You grab a rock and throw it as high as you can!`n`nThe rock goes");
		$rand=1;
		if ($session['user']['attack']>10) $rand++;
		if ($session['user']['attack']>15) $rand++;
		if ($session['user']['attack']>20) $rand++;
		if ($session['user']['attack']>25) $rand++;
		$upper=20;
		if (get_module_pref("pterocliffg")==1) $upper=18;
		switch(e_rand($rand,$upper)){
			case 1:
			case 2:
			case 3:
			case 4:
			case 5:	
			case 6:
			case 7:
				output("up and rapidly comes down! (You know... Newton's First Law of Motion...)`n`n");
				$rand=1;
				if ($session['user']['defense']>10) $rand++;
				if ($session['user']['defense']>15) $rand++;
				if ($session['user']['defense']>20) $rand++;
				if ($session['user']['defense']>25) $rand++;
				switch(e_rand($rand,10)){
					case 1:
					case 2:
					case 3:
					case 4:
					case 5:
						output("And hits you on the head. You lose");
						if ($session['user']['hitpoints']<=50) {
							output("`\$all of your hitpoints except 1`3.");
							$session['user']['hitpoints']=1;
						}else{
							output("`\$50 hitpoints`3.");
							$session['user']['hitpoints']-=50;
						}
					break;
					case 6:
					case 7:
					case 8:
						output("And hits you on the shoulder. You lose");
						if ($session['user']['hitpoints']<=20) {
							output("`\$all of your hitpoints except 1`3.");
							$session['user']['hitpoints']=1;
						}else{
							output("`\$20 hitpoints`3.");
							$session['user']['hitpoints']-=20;
						}
					break;
					case 9:
					case 10:
						output("And hits you on the toe.");
						if ($session['user']['hitpoints']<=1) output("Luckily, it doesn't hurt you.");
						else{
							output("You lose `\$one hitpoint`3.");
							$session['user']['hitpoints']--;
						}
					break;
				}
			break;
			case 8: case 9: case 10: case 11: case 12: case 13: case 14: 
				output("up and up!!!");
				output("`n`nThen the rock starts to come down and down and down!");
				output("You move away just in time to avoid getting hit by the rock.");
			break;
			case 15: case 16:
				output("up and up and up!!");
				output("`n`nIt dislodges the carcass of a dead bird.  The bones fall to the ground next ot you.");
			break;
			case 17: case 18:
				output("up and up and up!");
				output("`n`nIt hits the nest and disldoges a stick... the stick falls down and lands next to you.");
				output("`n`nYou smell the stick and realize there's tar on it.");
				if (get_module_pref("haslight")==0){
					set_module_pref("haslight",1);
					output("After thinking it through for a moment, you realize that this could make a great torch.`n`n");
				}else{
					output("You probably have no use for the stick.`n`n");
				}
			break;
			case 19:
				output("up and up and up and up!!!");
				output("`n`nIt hits the nest and dislodges a bag! You hold out your hand to catch it...");
				output("`n`nYou've found `^55 gold pieces!");
				$session['user']['gold']+=55;
				set_module_pref("pterocliffg",1);
			break;
			case 20:
				output("up and up and up and up!!!");
				output("`n`nIt hits the nest and dislodges something shiny! You hold out your hand to catch it...");
				output("`n`nYou catch a `%gem`3!");
				$session['user']['gems']++;
				set_module_pref("pterocliffg",1);
			break;		
		}
	}
	addnav("Climb the Cliff","runmodule.php?module=ruinworld2&op=ptericliff");
	addnav("Leave","runmodule.php?module=ruinworld2&op=pteriretreat");
}
if ($op=="ptericliff"){
	output("`#`c`bPterodactyl Cliff`c`b`n`3");
	$session['user']['turns']--;
	output("You start climbing up the cliff, making sure you don't fall.  It takes some time but you do well.");
	output("`n`nFinally, you're close to the nest.");
	$ptero=e_rand(1,4);
	if (get_module_pref("pterofight")==0){
		output("You look around one last time for the pterodactyl");
		if ($ptero==1){
			output("and suddenly you see it flying right at you!!");
			addnav("Pterodactyl Fight","runmodule.php?module=ruinworld2&op=attack");
			set_module_pref("pterofight",2);
		}else{
			output("but don't see it.");
			addnav("Search the Nest","runmodule.php?module=ruinworld2&op=searchnest");
		}
	}else{
		output("`n`nNow's your chance to see if there's anything of value in it.");
		addnav("Search the Nest","runmodule.php?module=ruinworld2&op=searchnest");
	}
}
if ($op=="pteriretreat"){
	output("`#`c`bRetreat!`c`b`n`3");
	output("You decide it's a good idea to head back.`n`n");
	$rand=10;
	if (get_module_pref("pterofight")==1) $rand=9;
	switch(e_rand(1,$rand)){
		case 1:
		case 2:
		case 3:
		case 4:
			output("You make it back feeling a little disappointed in yourself.  Maybe you weren't ready to track down the pterodactyl quite yet.");
			addnav("Continue","runmodule.php?module=ruinworld2&op=c&op2=continue");
		break;
		case 5:
		case 6:
		case 7:
			output("You get lost trying to find your way back and `\$lose a turn`3.");
			$session['user']['turn']--;
			addnav("Continue","runmodule.php?module=ruinworld2&op=c&op2=continue");
		break;
		case 8:
		case 9:
			output("You make it back in record time.  In fact, you feel like you could spend more time looking around. You `@gain 2 extra turns`3.");
			$session['user']['turn']+=2;
			addnav("Continue","runmodule.php?module=ruinworld2&op=c&op2=continue");
		break;
		case 10:
			output("You are just about to get back when suddenly you hear an ear splitting squawk. It seems like the Pterodactyl has been tracking you!");
			output("`n`nYou don't have a chance to escape.  You'll have to fight!");
			set_module_pref("pterofight",2);
			addnav("Fight the Pterodactyl","runmodule.php?module=ruinworld2&op=attack");
		break;
	}
}
if ($op=="mysticstall"){
	output("`#`c`bThe Mystic`c`b`n`3");
	output("You enter a tent and your eyes adjust to the darkness.  A very old woman motions for you to sit down at a chair by her.");
	addnav("Sit by the Mystic","runmodule.php?module=ruinworld2&op=mystic1");
	addnav("Back to the Village","runmodule.php?module=ruinworld2&op=c&op2=hill");
}
if ($op=="mystic1"){
	output("`#`c`bThe Mystic`c`b`n`3");
	output("You hesitate but decide to find out what she wants.");
	output("`n`nShe grabs your hand before you have a chance to react and holds it tightly.");
	output("She squeezes and you feel a sharp pain that surprises you.  Her grip is a steel vice and you feel her fingernails piercing your flesh.");
	addnav("Continue","runmodule.php?module=ruinworld2&op=mystic2");
}
if ($op=="mystic2"){
	output("`#`c`bThe Mystic`c`b`n`3");
	output("You give her a pleading look for release but she ignores you.  You have to close your eyes due to the pain.  As soon as you do, bright lights flash before you.");
	output("`n`nImages appear in your mind and you realize that you're looking into the future. You see choices you will make and mistakes you will avoid.");
	output("`n`nYou open your eyes to find yourself standing back in the village center.  The mystic tent is gone. Your wrist feels normal.  You have learned from the images you saw in the Mystic Tent.`n`n");
	set_module_pref("mystic",1);
	$expbonus=$session['user']['dragonkills']*4;
	$expgain =($session['user']['level']*25+$expbonus);
	output("`@`bYou've gained `#%s experience`@.`b`n`n",$expgain);
	$session['user']['experience']+=$expgain;
	addnav("Continue","runmodule.php?module=ruinworld2&op=exit");
}
if ($op=="foodstall"){
	output("`#`c`bFood Stall`c`b`n`3");
	output("You enter a stall that seems to be selling poached eggs.  This seems a little peculiar, but smells rather delicious.`n`n");
	if (get_module_pref("buyfood")==0){
		ruinworld2_gemtrade ();
		output("A young girl looks at you expectantly and you negotiate that a serving of egg will cost you `%one gem`3.");
		addnav("Purchase Poached Egg","runmodule.php?module=ruinworld2&op=stallpegg");
	}else output("The young girl makes it clear that you should only take one egg a day.  It seems she's worried about the cholesterol in your diet or something like that. Either way, it's best that you not purchase another one today.");	
	addnav("Back to the Village","runmodule.php?module=ruinworld2&op=c&op2=hill");
}
if ($op=="stallpegg"){
	output("`#`c`bFood Stall`c`b`n`3");
	if ($session['user']['gems']>0){
		set_module_pref("buyfood",1);
		$session['user']['gems']--;
		switch(e_rand(1,6)){
			case 1:
			case 2:
				output("You enjoy the egg and feel invigorated.`n`nYou `@gain 2 forest fights`3!");
				$session['user']['turns']+=2;
			break;
			case 3:
				output("You find the egg electrifies you!`n`nYou `@gain 3 forest fights`3!");
				$session['user']['turns']+=3;
			break;
			case 4:
				if ($session['user']['turns']<=0) output("Yup, it tastes like chicken egg.  You don't find too much more interesting about it.");
				else{
					output("Ewww! It tastes horrible! You `4spend a turn`3 spitting it out!");
					$session['user']['turns']--;
				}
			break;
			case 5:
				output("Yup, it tastes like chicken egg.  You don't find too much more interesting about it.");
			break;
			case 6;
				output("You start choking on the egg.  It's horrible!! You look at the girl who gave you the egg and she seems apologetic.");
				output("`n`nShe gives you back your `%gem`3 and gives you an `%extra one`3 for your troubles!");
				$session['user']['gems']+=2;
			break;
		}
	}else output("It seems like you're a little short on gems.  Perhaps if you can find one you can come back for some food.");	
	addnav("Back to the Village","runmodule.php?module=ruinworld2&op=c&op2=hill");
}
if ($op=="generalstall"){
	output("`#`c`bGeneral Stall`c`b`n`3");
	output("An old woman motions for you to come in and look around at the items she has for sale.");
	output("You look around at the primitive tools and items.  You don't see much that would be of any use to you.");
	if (get_module_pref("haslight")==0 && get_module_pref("cavevisit")==1){
		output("`n`nSuddenly, you notice what looks like a torch.  This may be useful in the cave.`n`n");
		ruinworld2_gemtrade ();
		output("The old woman negotiates a price and it seems like the torch will cost you `%two gems`3.");
		addnav("Purchase the Torch","runmodule.php?module=ruinworld2&op=gentorch");
	}
	addnav("Back to the Village","runmodule.php?module=ruinworld2&op=c&op2=hill");
}
if ($op=="gentorch"){
	output("`#`c`bGeneral Stall`c`b`n`3");
	if ($session['user']['gems']>=2){
		set_module_pref("haslight",1);
		$session['user']['gems']-=2;
		output("You hand over `%two gems`3 and take the torch. The old woman seems happy with the transaction.");
		addnav("Continue","runmodule.php?module=ruinworld2&op=exit");
	}else{
		output("You don't seem to have enough gems to purchase the torch.");
		addnav("Back to the Village","runmodule.php?module=ruinworld2&op=c&op2=hill");
	}
}
if ($op=="weaponstall"){
	output("`#`c`bWeapon Stall`c`b`n`3");
	if (get_module_pref("buyweapon")==0){
		output("You enter the little weapon stall and don't really expect much from such a primitive culture.");
		output("`n`nHowever, you're soon surprised by the quality of the weapons available.");
		output("A rather huge looking weaponsmith starts showing you what he has for sale.  Although you can't understand what he's saying, you can tell he's proud of his handiwork.");
		output("`n`nYou pick up a rather hefty looking club spiked with the fangs of a sabertooth tiger.");
		output("After comparing it to your weapon, you realize that the `QSabertooth Club`3 is a slightly better weapon than yours.");
		ruinworld2_gemtrade();
		output("`n`nThe weaponsmith indicates that for `%3 gems`3 more, he will trade you the `QSabertooth Club`3 for your %s`3.",$session['user']['weapon']);
		addnav("Exchange Weapons","runmodule.php?module=ruinworld2&op=weapexch");
	}else output("The weaponsmith does not seem to have anything better than your %s`3 available.",$session['user']['weapon']);
	addnav("Back to the Village","runmodule.php?module=ruinworld2&op=c&op2=hill");
}
if ($op=="weapexch"){
	output("`#`c`bWeapon Stall`c`b`n`3");
	if ($session['user']['gems']>=3){
		$session['user']['gems']-=3;
		set_module_pref("buyweapon",1);
		output("You hand over your %s`3 and pick up the `QSabertooth Club`3.  You smile and give him `%3 gems`3.`n`n",$session['user']['weapon']);
		output("This was a good deal!");
		addnav("Continue","runmodule.php?module=ruinworld2&op=exit");
		$session['user']['weapon']="`QSabertooth Club`0";
		$session['user']['weapondmg']++;
		$session['user']['attack']++;
	}else{
		output("You don't seem to have enough gems for the exchange.");
		addnav("Back to the Village","runmodule.php?module=ruinworld2&op=c&op2=hill");
	}
}
if ($op=="healingstall"){
	output("`#`c`bShaman Healer`c`b`n`3");
	if (get_module_pref("shaman")>0){
		output("A young apprentice healer looks up at you and sees murder in your eyes.  Somehow he knows that you've");
		if (get_module_pref("shaman")==1) output("killed");
		else output("fought with");
		output("the Ancient Shaman.");
		output("`n`nHe starts yelling loudly at you and you decide it would be best to leave before he makes more of a scene.");	
	}else{
		if (get_module_pref("buyelixir")==0){
			output("You look around and notice what appears to be healing elixir.");
			output("A young shaman looks up at you expectantly hoping to trade with you for one of the elixirs. Although you don't speak the same language, you're able to communicate with hand gestures.");
			output("You discover that the Village Shaman is in the plains gathering some flowers for the healing elixirs.`n`n");
			output("The elixirs on display are held in very flimsy bamboo containers and are not likely to travel well.  You'd have to drink it down right away for it to be of any use.`n`n");
			ruinworld2_gemtrade ();
			output("The young shaman negotiates a price and it seems like an elixir will cost you `%one gem`3.");
			addnav("Purchase Elixir","runmodule.php?module=ruinworld2&op=elixir");
		}else output("The young shaman makes it clear that you should only take one elixir a day. It's best that you not purchase another one today.");	
	}
	addnav("Back to the Village","runmodule.php?module=ruinworld2&op=c&op2=hill");
}
if ($op=="elixir"){
	output("`#`c`bShaman Healer`c`b`n`3");
	if ($session['user']['gems']>0){
		set_module_pref("buyelixir",1);
		$session['user']['gems']--;
		switch(e_rand(1,6)){
			case 1:
			case 2:
				if ($session['user']['hitpoints']<$session['user']['maxhitpoints']){
					$session['user']['hitpoints']=$session['user']['maxhitpoints'];
					output("You drink the elixir and it `@heals you back to full`3!");
				}else output("You drink the elixir but nothing happens.");
			break;
			case 3:
				if (get_module_setting("permhp")==1){
					$session['user']['maxhitpoints']++;
					$session['user']['hitpoints']=$session['user']['maxhitpoints'];
					output("You drink the elixir and you `@gain on permanent hitpoint`3 and it `@heals you back to full`3!");
				}else output("You drink the elixir but nothing happens.");
			break;
			case 4:
				if ($session['user']['hitpoints']>1){
					$session['user']['hitpoints']=1;
					output("You drink the elixir. Something goes wrong and you `\$lose all your hitpoints except 1`3!");
				}else output("You drink the elixir but nothing happens.");
			break;
			case 5:
				if ($session['user']['hitpoints']<($session['user']['maxhitpoints']*1.5)){
					$session['user']['hitpoints']=round($session['user']['maxhitpoints']*1.5);
					output("You drink the elixir and you feel invigorated`3!");
				}else output("You drink the elixir but nothing happens.");
			break;
			case 6;
				if ($session['user']['level']<5) $heal=5;
				else $heal=$session['user']['level'];
				apply_buff('exlixir',array(
						 "startmsg"=>"`n`3The Healing Elixir makes you feel better!",
                   		 "name"=>"`3Healing Elixir",
                  		 "rounds"=>10,
                  		 "minioncount"=>1,
                  		 "regen"=>$heal,
                  		 "effectmsg"=>"`!You heal for ".$heal." hitpoints!",
                   		 "activate"=>"offense"
				));
				output("You drink the elixir and feel a strength flow through you.  You know that in your next encounter the elixir will help you in your battle.");
			break;
		}
	}else output("It seems like you're a little short on gems.  Perhaps if you can find one you can come back for an elixir.");	
	addnav("Back to the Village","runmodule.php?module=ruinworld2&op=c&op2=hill");
}
if ($op=="cavedeep1"){
	output("`#`c`bThe Cave`c`b`n`3");	
	$max=17;
	if (get_module_pref("cavefind")==1) $max=15;
	$rand=(e_rand(1,$max));
	switch($rand){
		case 1: case 2: case 3: case 4: case 5: case 6: case 7: case 8: case 9: case 10: case 11: case 12:
		break;
		case 13:
			output("You look down and notice the bones of a dead penguin.");
			output("That's very strange.`n`n");
		break;
		case 14:
		case 15:
			output("You find a femur bone with some oily cloth.");
			if (get_module_pref("haslight")==0){
				set_module_pref("haslight",1);
				output("After thinking it through for a moment, you realize that this could make a great torch.`n`n");
			}else{
				output("Since you already have a light source, you decide not to mess with the cloth.`n`n");
			}
		break;
		case 16: case 17:
			set_module_pref("cavefind",1);
			output("A bright object catches your eye. You find a");
			if ($rand==17) {
				output("`%gem`3!`n`n");
				$session['user']['gems']++;
			}else{
				output("`^piece of gold`3.`n`n");
				$session['user']['gold']++;
			}
		break;
	}
	if (get_module_pref("haslight")==0){
		output("You start to take a couple steps into the cave but you suddenly hear some very ominous sounding noises.");
		output("Perhaps you should come back with some kind of torch or something.");
	}else{
		addnav("Left","runmodule.php?module=ruinworld2&op=cleft");
		addnav("Right","runmodule.php?module=ruinworld2&op=cright");
		if (get_module_pref("cave2")==0){
			set_module_pref("cave2",1);
			output("Now that you have a light source, you feel much safer going into the cave.  You walk in slowly and hear deep growling which makes you walk even more slowly.");
			output("`n`nSoon enough, you find you've come to a fork in the passage.");
			output("`n`nWhich direction will you go?");
		}else{
			output("You're back at the fork in the cave.");
		}
	}
	addnav("Back to the Entrance","runmodule.php?module=ruinworld2&op=c&op2=cave");
}
if ($op=="cleft"){
	output("`#`c`bThe Cave`c`b`n`3");
	output("Having always found 'left' to be more fun, you wander down the passage way to the left.");
	output("Soon enough, you find yourself at a dead end.");
	output("`n`nMaybe going left isn't as fun as you'd thought.`n`n");
	addnav("Go Back to the Fork","runmodule.php?module=ruinworld2&op=cavedeep1");
	$max=17;
	if (get_module_pref("cavefind")==1) $max=15;
	$rand=(e_rand(1,$max));
	switch($rand){
		case 1: case 2: case 3: case 4: case 5: case 6: case 7: case 8: case 9: case 10: case 11: case 12:
		break;
		case 13:
			output("You look down and notice the bones of a dead polar bear.");
			output("That's very strange.");
		break;
		case 14:
		case 15:
			output("You find a femur bone with some oily cloth.");
			output("Since you already have a light source, you decide not to mess with the cloth.");
		break;
		case 16: case 17:
			set_module_pref("cavefind",1);
			output("A bright object catches your eye. You find a");
			if ($rand==17) {
				output("`%gem`3!");
				$session['user']['gems']++;
			}else{
				output("`^piece of gold`3.");
				$session['user']['gold']++;
			}
		break;
	}
}
if ($op=="cright"){
	output("`#`c`bThe Cave`c`b`n`3");
	if (get_module_pref("killdino")==0) output("As you walk through the cave you hear the growling get louder.");
	else output("You wander through the cave.");
	addnav("Go Back to the Fork","runmodule.php?module=ruinworld2&op=cavedeep1");
	addnav("Continue Deeper into the Cave","runmodule.php?module=ruinworld2&op=cdeep2");
}
if ($op=="cdeep2"){
	output("`#`c`bThe Cave`c`b`n`3");
	if (get_module_pref("killdino")==0){
		output("Your light falls on the snout of a sleeping dinosaur.`n`n");
		$case=5;
		if (get_module_pref("dinoegg")>=1) $case=4;
		switch(e_rand(1,$case)){
			case 1: case 2: case 3: case 4:
				output("Suddenly, the dinosaur awakens!");
				addnav("Run Away","runmodule.php?module=ruinworld2&op=runaway");
				addnav("Kill the Dinosaur","runmodule.php?module=ruinworld2&op=dinofight");
			break;
			case 5:
				output("You see a beautiful dinosaur egg.  Would you like to take it?");
				addnav("Take the Egg","runmodule.php?module=ruinworld2&op=eggsteal");
				addnav("Leave the Cave","runmodule.php?module=ruinworld2&op=cright");
				addnav("Kill the Dinosaur","runmodule.php?module=ruinworld2&op=dinofight");
			break;
		}
	}else{
		output("You look around at the corpse of the dead dinosaur.  There's nothing here of any value.");
		addnav("Leave the Cave","runmodule.php?module=ruinworld2&op=cright");
	}
}
if ($op=="eggsteal"){
	output("`#`c`bThe Cave`c`b`n`3");
	output("You cautiously try to grab one of the eggs as the dinosaur sleeps...");
	switch(e_rand(1,5)){
		case 1: case 2: case 3: case 4:
			output("Suddenly, the dinosaur awakens before you can grab an egg!");
			addnav("Run Away","runmodule.php?module=ruinworld2&op=runaway");
		break;
		case 5:
			output("And somehow you're able to grab it without disturbing the dinosaur!");
			set_module_pref("dinoegg",1);
			addnav("Quietly Leave","runmodule.php?module=ruinworld2&op=cright");
		break;
	}
	addnav("Kill the Dinosaur","runmodule.php?module=ruinworld2&op=dinofight");
}
if ($op=="raiseegg"){
	output("`#`c`bThe Cave`c`b`n`3");
	//fix mount id to egg id
	$i=e_rand(1,3);
	if ($i==1) $dino="Pterodactyl";
	if ($i==2) $dino="Raptor";
	if ($i==3) $dino="Triceratops";
	set_module_pref("whichdino",$i);
	$dino=get_module_setting('dbabyid'.$i);
	//Modified from Lonny Luberts' Garland's Stable
	$sql = "SELECT * FROM ".db_prefix("mounts")." where mountid=$dino";
	$result = db_query($sql);
	$mount = db_fetch_assoc($result);
	if ($session['user']['hashorse']>0) output("You give one last hug to your %s and leave it in the cave.`n`nYou turn to look at the egg.",$playermount['mountname']);
	output("You give a gentle hug to your egg and it hatches!`n`n");
	output("You look down and realize that it's a `@%s`3.",$mount['mountname']);
	$session['user']['hashorse']=$mount['mountid'];
	set_module_pref('deggage'.$i,e_rand(1,5));
	$session['bufflist']['mount']=unserialize($mount['mountbuff']);
	//end Lonny's code
	set_module_pref("dinoegg",2);
	addnav("Continue","runmodule.php?module=ruinworld2&op=exit");
}
if ($op=="sendfl"){
	output("`#`c`bFlowers`c`b`n`3");
	$who = httpget('who');
	if ($who==""){
		output("`nWho will receive the flower?`n`n");
		$subop = httpget('subop');
		if ($subop!="search"){
			$search = translate_inline("Search");
			rawoutput("<form action='runmodule.php?module=ruinworld2&op=sendfl&subop=search' method='POST'><input name='name' id='name'><input type='submit' class='button' value='$search'></form>");
			addnav("","runmodule.php?module=ruinworld2&op=sendfl&subop=search");
			addnav("Search","runmodule.php?module=ruinworld2&op=sendfl");
			rawoutput("<script language='JavaScript'>document.getElementById('name').focus();</script>");
		}else{
			addnav("Search Again","runmodule.php?module=ruinworld2&op=sendfl");
			$search = "%";
			$name = httppost('name');
			for ($i=0;$i<strlen($name);$i++){
				$search.=substr($name,$i,1)."%";
			}
			$sql = "SELECT name,level,login FROM " . db_prefix("accounts") . " WHERE (locked=0 AND name LIKE '$search') ORDER BY level DESC";
			$result = db_query($sql);
			$max = db_num_rows($result);
			if ($max > 100) {
				output("`n`nPlease choose from this list of names:");
				$max = 100;
			}
			$n = translate_inline("");
			rawoutput("<table border=0 cellpadding=0><tr><td>$n</td></tr>");
			for ($i=0;$i<$max;$i++){
				$row = db_fetch_assoc($result);
				rawoutput("<tr><td><a href='runmodule.php?module=ruinworld2&op=sendfl&who=".rawurlencode($row['login'])."'>");
				output_notl("%s", $row['name']);
				rawoutput("</a></td></tr>");
				addnav("","runmodule.php?module=ruinworld2&op=sendfl&who=".rawurlencode($row['login']));
			}
		rawoutput("</table>");
		}
	}else{
		$sql = "SELECT name,acctid FROM " . db_prefix("accounts") . " WHERE login='$who'";
		$result = db_query($sql);
		if (db_num_rows($result)>0){
			$row = db_fetch_assoc($result);
			$id = $row['acctid'];
			$name = $row['name'];
			addnav("Continue","runmodule.php?module=ruinworld2&op=exit");
			if ($name==$session['user']['name']) output("Well, that's cute.  You've decided to send yourself a flower!");
			else output("You decide to send your flower to %s`3. That was very nice of you!",$name);
			require_once("lib/systemmail.php");
			$subj = sprintf("`5A `#Gift`5 from the World of Dinosaurs");
			$body = sprintf("`^Dear %s`^,`n`n`3You have received a beautiful and `#exotic `5f`2l`5o`2w`5e`2r`3 from `^%s`3. May it bring you adventure and luck!",$name,$session['user']['name']);
			systemmail($id,$subj,$body);
		}else{
			output("There is nobody with that name.");
        }
	}
}
if ($op=="runaway"){
	output("`#`c`bThe Cave`c`b`n`3");
	output("You decide that you will run away.  How brave is that?`n`n");
	switch(e_rand(1,4)){
		case 1:
			output("The dinosaur thinks it is particularily cowardly and gets a bite out of you before you can escape.");
			output("`n`nYou're badly wounded!`n`n");
			$exploss = round($session['user']['experience']*.05);
			$session['user']['experience']-=$exploss;
			$session['user']['hitpoints']=1;
			$session['user']['gold']*=.5;
			output("`b`^ You lose `#%s experience`^`b.`n`n",$exploss);
			output("`@You must drop `^1/2 your gold`@ to get away.  By the time you get a chance to rest you notice that you've only got `\$1 hitpoint left`@.");
			addnav("Continue","runmodule.php?module=ruinworld2&op=cright");
		break;
		case 2:
			output("A band of minstrels sees you retreat and decides to follow you around.");
			output("`n`n`%Brave Sir %s `%ran away,`n",$session['user']['name']);
			output("Bravely ran away, away.`n");
			output("When danger reared its ugly head,`n %s `%bravely turned tail and fled.`n",$session['user']['name']);
			output("Yes, brave Sir %s `%turned about`n",$session['user']['name']);
			output("And gallantly, chickened out.`n Bravely taking to feet,`n");
			output("%s `%beat a very brave retreat,`n",$session['user']['name']);
			output("Bravest of the brave, Sir %s`%.`n`n",$session['user']['name']);
			output("`^I think those minstrels will be following you around for a while.`n`n");
			set_module_pref("phase",1);
			apply_buff('robinminstrels',array(
				"name"=>"`5(Not so)`% Helpful Minstrels",
				"rounds"=>10,
				"wearoff"=>"`%Suspicous that the minstrels were mocking you, you send them away.",
				"atkmod"=>.95,
				"roundmsg"=>"`5The Minstrels sing`%' When danger reared its ugly head, you bravely turned your tail and fled!'",
			));
			addnav("Continue","runmodule.php?module=ruinworld2&op=cright");
		break;
		case 3:
			output("You get away without harm.");
			addnav("Continue","runmodule.php?module=ruinworld2&op=cright");
		break;
		case 4:
			output("You get ready to run away but realize you won't make it.  You might as well try to take a stand.");
			addnav("Dinosaur Fight","runmodule.php?module=ruinworld2&op=dinofight");	
		break;
	}
}
if ($op=="shamandefeat"){
	output("`#`c`bThe Plain`c`b`n`3");
	output("You have killed the shaman.");
	if (is_module_active('alignment')){
		set_module_pref("alignment",get_module_pref("alignment","alignment")-3,"alignment");
		output("Upon reflection you realize your rash actions have made your more `\$evil`3.");
	}
	addnav("Continue","runmodule.php?module=ruinworld2&op=exit");
}
if ($op=="dinodefeat"){
	output("`#`c`bThe Cave`c`b`n`3");
	if (get_module_pref("dinoegg")==0){
		output("You succeed in killing the dinosaur.  You have a chance to look around and you see several dinosaur eggs.");
		output("Would you like to take one?");
		addnav("Grab Egg","runmodule.php?module=ruinworld2&op=egg");
	}else{
		output("The dinosaur has been defeated. All the remaining eggs in the cave have been destroyed during the battle.  There's not much here to see.");
	}
	addnav("Continue","runmodule.php?module=ruinworld2&op=cright");
}
if ($op=="pteridrops"){
	output("`#`c`bPterodactyl Flight`c`b`n`3");
	output("`i`&The Pterodactyl tries to pick you up and fly away...`i`n`n");
	output("`3You're unable to break free and soon you find yourself high above the clouds in the talons of a very upset pterodactyl.");
	output("`n`nIn a move of desperation (stupidity?) you bite the talon!");
	output("You find yourself falling to the ground at a rapidly accelerating rate.");
	output("`n`nFor some reason you wonder if two unladened African Swallows would be able to rescue you... but then you notice the ground rapidly coming to meet you.");
	addnav("Continue","runmodule.php?module=ruinworld2&op=pteridrops2");
}
if ($op=="pteridrops2"){
	output("`#`c`bFalling`c`b`n`3");
	if ($id==0) output("You're still falling...");
	if ($id==1) output("Nope... still falling...");
	if ($id==2) output("Seriously... it's a long way down... you're still falling...");
	$id=$id+1;
	if ($id>=3) addnav("Continue","runmodule.php?module=ruinworld2&op=pteridrops3");
	else addnav("Continue","runmodule.php?module=ruinworld2&op=pteridrops2&id=$id");
}
if ($op=="pteridrops3"){
	output("`#`c`bLanding`c`b`n`3");
	$dropped=e_rand(1,5);
	output("You realize that you're going to die from the fall. You close your eyes, say some very poetic final words...");
	if ($dropped<=4){
		output("`n`nAnd land in a large pile of... err... well... how can I put this?");
		output("`n`nI'd rather not talk about what you landed in.  However, it's not pretty.  And neither are you anymore.");
		output("`n`nYou `&lose 3 charm`3.");
		output("`n`nLuckily, you don't sustain any significant injuries.");
		addnews("%s smells like they jumped into a large pile of triceratops manure.",$session['user']['name']);
		apply_buff('exlixir',array(
			"startmsg"=>"`n`3Your opponent cringes at your smell.",
			"name"=>"`3Dinosaur Manure Smell",
			"rounds"=>-1,
		));
		addnav("Continue","runmodule.php?module=ruinworld2&op=exit");
	}else{
		output("`n`nAnd land in what appears to be a nest!");
		output("`n`nYou look around, a little bit shocked by your luck, and realize where you are...");
		output("It looks like you've been dropped into the nest of the pterodactyl!!!");
		if (get_module_pref("pteronest")==0){
			output("`n`nThe pterodactyl is nowhere to be found!");
			output("What would you like to do next?");
			addnav("Search the Nest","runmodule.php?module=ruinworld2&op=searchnest");
		}else{
			output("`n`nYou suddenly recognize that you've been in this nest before.  You try to find anything of value but all you can see are broken eggshells and degraded armor.");
			$chance=e_rand(1,4);
			if ($chance==4) {
				ruinworld2_ptero();
				blocknav("runmodule.php?module=ruinworld2&op=exit");
			}
		}
		addnav("Leave the Nest","runmodule.php?module=ruinworld2&op=exit");
	}
}
if ($op=="searchnest"){
	output("`#`c`bPterodactyl Nest`c`b`n`3");
	if (get_module_pref("pteronest")==0){
		if (get_module_pref("pterofight")==1){
			output("Knowing that the pterodactyl has been defeated gives you a chance to look through the nest pretty thoroughly.");
			output("However, as soon as you're starting to feel comfortable, you hear another pterodactyl squawking! Oh no! It must be the mate!");
		}else output("You realize that there's not much time... That pterodactyl could be back any minute!  After a quick search you find several things you could take.");
		output("You'll only have a chance to pick one.");
		output("`n`nWhat will you take?");
		if (get_module_setting("pterogold")>0){
			output("`n`n`c`^Pouch of Gold`c");
			addnav("Pouch of Gold","runmodule.php?module=ruinworld2&op=pouchgold");		
		}
		if (get_module_setting("pterogem")>0){
			output("`c`%Pouch of Gems`c");
			addnav("Pouch of Gems","runmodule.php?module=ruinworld2&op=pouchgems");
		}
		output("`c`QPterodactyl Egg`c");
		addnav("Pterodactyl Egg","runmodule.php?module=ruinworld2&op=pterodactylegg");
		addnav("Leave the Nest","runmodule.php?module=ruinworld2&op=exit");	
	}else{
		output("You try to search through the nest for anything of value.  However, this nest has been picked clean.");
		$chance=e_rand(1,4);
		if (get_module_pref("pterofight")==0 && $chance==4){
			ruinworld2_ptero();
			blocknav("runmodule.php?module=ruinworld2&op=exit");
		}
		addnav("Leave the Nest","runmodule.php?module=ruinworld2&op=exit");
	}
}
if ($op=="pouchgold"){
	output("`#`c`bPterodactyl Nest`c`b`n`3");
	$chance=e_rand(1,4);
	if (get_module_pref("pterofight")==0 && $chance==4){
		ruinworld2_ptero();
		output("You're not even able to grab the gold before the fight starts!");
	}else{
		$pgold=get_module_setting("pterogold");
		$gold=round(e_rand($pgold/2,$pgold));
		output("You gather up `^%s gold`3 before you have to leave the nest.",$gold);
		$session['user']['gold']+=$gold;
		set_module_pref("pteronest",1);
		addnav("Leave the Nest","runmodule.php?module=ruinworld2&op=exit");
	}
}
if ($op=="pouchgems"){
	output("`#`c`bPterodactyl Nest`c`b`n`3");
	$chance=e_rand(1,4);
	if (get_module_pref("pterofight")==0 && $chance==4){
		ruinworld2_ptero();
		output("You're not even able to grab the gems before the fight starts!");
	}else{
		$pgem=get_module_setting("pterogem");
		$gem=round(e_rand($pgem/2,$pgem));
		if ($gem==0) $gem=1;
		output("You gather up `%%s gem%s`3 before you have to leave the nest.",$gem,translate_inline($gem>1?"s":""));
		$session['user']['gems']+=$gem;
		set_module_pref("pteronest",1);
		addnav("Leave the Nest","runmodule.php?module=ruinworld2&op=exit");
	}
}
if ($op=="pterodactylegg"){
	output("`#`c`bPterodactyl Nest`c`b`n`3");
	$chance=e_rand(1,4);
	if (get_module_pref("pterofight")==0 && $chance==4){
		ruinworld2_ptero();
		output("You're not even able to grab the egg before the fight starts!");
	}else{
		set_module_pref("pteronest",1);
		switch(e_rand(1,3)){
			case 1: 
				output("You grab the egg and leave.  Suddenly, you're enveloped in a thick fog!");
				$pgold=round(get_module_setting("pterogold")/2);
				if ($pgold<=0) $pgold=100;
				output("`n`nWhen you make it home, you're able to sell the egg for `^%s gold`3!",$pgold);
				$session['user']['gold']+=$pgold;
				$session['user']['specialinc']="";
				addnav("To the Forest","forest.php");
				addnews("%s `3sold a pterodactyl egg for`^ %s gold`3!",$session['user']['name'],$pgold);
			break;
			case 2:
				output("You grab the egg and leave.  Suddenly, you're enveloped in a thick fog!");
				$pgem=round(get_module_setting("pterogem")/2);
				if ($pgem<=0) $pgem=1;
				output("`n`nWhen you make it home, you're able to sell the egg for `%%s gem%s`3!",$pgem,translate_inline($pgem>1?"s":""));
				$session['user']['gold']+=$pgem;
				$session['user']['specialinc']="";
				addnav("To the Forest","forest.php");
				addnews("%s `3sold a pterodactyl egg for `%%s gem%s`3!",$session['user']['name'],$pgem,translate_inline($pgem>1?"s":""));
			break;
			case 3: 
				output("You grab the egg and leave. However, you lose your balance carrying it!");
				output("You drop the egg and watch it fall to the ground below.  It splits open and lands on top of a hot spring.");
				addnav("Continue","runmodule.php?module=ruinworld2&op=poachedegg");
			break;
		}
	}
}
if ($op=="poachedegg"){
	output("`#`c`bPoached Pterodactyl Egg`c`b`n`3");
	output("You get to the bottom of the mountain and find your egg cooking up quite nicely.");
	output("`n`nWould you like some?");
	addnav("Yes, Please","runmodule.php?module=ruinworld2&op=poacheggyes");
	addnav("No Thank You","runmodule.php?module=ruinworld2&op=poacheggno");
}
if ($op=="poacheggyes"){
	output("`#`c`bPoached Pterodactyl Egg`c`b`n`3");
	output("You settle down to eat a nice little poached egg.`n`n");
	switch(e_rand(1,9)){
		case 1:
		case 2:
			output("The egg settles nicely.  You feel strengthened!");
			output("`n`nYou `&Gain One Attack`3!!");
			$session['user']['attack']++;
		break;
		case 3:
		case 4:
			output("The egg settles nicely.  You feel invigorated!");
			output("`n`nYou `&Gain One Defense`3!!");
			$session['user']['defense']++;
		break;
		case 5:
		case 6:
			output("The egg settles nicely.  You feel powerful!");
			output("`n`nYou `@Gain 50 Hitpoints`3!!");
			$session['user']['hitpoints']+=50;
		break;
		case 7:
		case 8:
			if (get_module_setting("permhppter")==1){
				output("The egg settles nicely.  You feel tougher!");
				output("`n`nYou `@Gain a Permanent Hitpoint`3!!");
				$session['user']['maxhitpoints']++;
			}else{
				output("The egg settles in your stomach, but really doesn't do much for you.");
			}
		break;
		case 9:
			output("The egg settles in your stomach, but really doesn't do much for you.");
		break;
	}
	addnav("Continue","runmodule.php?module=ruinworld2&op=exit");
}
if ($op=="poacheggno"){
	output("`#`c`bPoached Pterodactyl Egg`c`b`n`3");
	output("Since you're not into the whole 'poached egg' scene, you decide there's probably something more interesting to do around here.");
	addnav("Continue","runmodule.php?module=ruinworld2&op=exit");
}
if ($op=="egg"){
	output("`#`c`bThe Cave`c`b`n`3");
	output("You decide to take an egg with you.  You look around and find one that looks healthy.");
	set_module_pref("dinoegg",1);
	addnav("Continue","runmodule.php?module=ruinworld2&op=cright");
}
if ($op=="exit"){
	output("`#`c`bPaleozene World`c`b`n`3");
	if ($op2=="try"){
		if ($session['user']['turns']>=1){
			output("You `@spend a turn`3 trying to find an exit.");
			$session['user']['turns']--;
		}
		output("After searching around for a while, you find a suspicious area that may hold an exit.`n`n");
	}
	output("You turn to leave and suddenly you're enveloped in a thick mist. You take another step and realize that your back in the `@forest`3.");
	$session['user']['specialinc']="";
	addnav("To the Forest","forest.php");
}
if ($op=="dinofight"){
	set_module_pref("killdino",2);
	redirect("runmodule.php?module=ruinworld2&op=attack");	
}
if ($op=="attack") {
if (get_module_pref("rdinofight")==1){
	$targetlevel=$session['user']['level'];
	$sql = "SELECT * FROM " . db_prefix("creatures") . " WHERE creaturelevel = $targetlevel AND forest=1 ORDER BY rand(".e_rand().") LIMIT 1";
	$result = db_query($sql);
	$badguy = db_fetch_assoc($result);
	$badguy = modulehook("buffbadguy", $badguy);
	$randmonster=e_rand(1,4);
	if ($randmonster==1){
		$badguy['creaturename']="Tyranosaurus Rex";
		$badguy['creatureweapon']="Huge Claws";
	}elseif ($randmonster==2){
		$badguy['creaturename']="Apatosaurus";
		$badguy['creatureweapon']="huge whipping tail";
	}elseif ($randmonster==3){
		$badguy['creaturename']="Stegosaurus";
		$badguy['creatureweapon']="a spiked tail";
	}elseif ($randmonster==4){
		$badguy['creaturename']="Iguanodon";
		$badguy['creatureweapon']="sharp claws";
	}
	$session['user']['badguy']=createstring($badguy);
	$op="fight";
}
if (get_module_pref("killdino")==2){
	$level=$session['user']['level']+1;
	$hitpoints=$session['user']['maxhitpoints'];
	$badguy = array(
		"creaturename"=>"Mother Dinosaur",
		"creatureweapon"=>"Razor Sharp Claws",
		"creaturelevel"=>$level,
		"creatureattack"=>($session['user']['attack']+e_rand(1,3))*get_module_setting("dlatt"),
		"creaturedefense"=>($session['user']['defense']+e_rand(1,3))*get_module_setting("dldef"),
		"creaturehealth"=>round($hitpoints*get_module_setting("dlhp")),
		"diddamage"=>0);
	$session['user']['badguy']=createstring($badguy);
	$op="fight";
}
if (get_module_pref("shaman")==2){
	$level=$session['user']['level']+1;
	$hitpoints=$session['user']['maxhitpoints'];
	$badguy = array(
		"creaturename"=>"Ancient Shaman",
		"creatureweapon"=>"Shaman's Club",
		"creaturelevel"=>$level,
		"creatureattack"=>$session['user']['attack']+e_rand(1,3),
		"creaturedefense"=>$session['user']['defense']+e_rand(1,3),
		"creaturehealth"=>$hitpoints,
		"diddamage"=>0);
	$session['user']['badguy']=createstring($badguy);
	$op="fight";
}
if (get_module_pref("pterofight")==2){
	$level=$session['user']['level']-1;
	if ($level==0) $level=1;
	$hitpoints=round($session['user']['maxhitpoints']*.95);
	$badguy = array(
		"creaturename"=>"Pterodactyl",
		"creatureweapon"=>"Sharp Talons",
		"creaturelevel"=>$level,
		"creatureattack"=>$session['user']['attack']-e_rand(1,3),
		"creaturedefense"=>$session['user']['defense']-e_rand(1,3),
		"creaturehealth"=>$hitpoints,
		"diddamage"=>0);
	$session['user']['badguy']=createstring($badguy);
	$op="fight";
}
}
if ($op=="fight") {
	$battle=true;
	if (get_module_pref("pterofight")==2){
		blocknav("runmodule.php?module=ruinworld2&op=fight&auto=five");
		blocknav("runmodule.php?module=ruinworld2&op=fight&auto=ten");
		blocknav("runmodule.php?module=ruinworld2&op=fight&auto=full");
		$swoop=e_rand(1,20);
		if ($swoop==20){
			set_module_pref("pterofight",0);
			redirect("runmodule.php?module=ruinworld2&op=pteridrops");
		}elseif ($swoop>10){
			output("`i`&The Pterodactyl tries to pick you up and fly away...`i`n`n");
			if ($swoop>17){
				output("`band it successfully grabs you! You struggle to get away`b");
				output("`band you're able to break the grip of its talons.`b");
			}else output("`bbut it can't grab a hold of you.`b");
		}
	}
}
if ($battle){       
	include("battle.php");
	if ($victory){
		if (get_module_pref("rdinofight")==1){
			$expbonus=$session['user']['dragonkills']*2;
			$expgain =($session['user']['level']*15+$expbonus);
			output("`n`@`bYou've gained `#%s experience`@.`b`n`n",$expgain);
			set_module_pref("rdinofight",0);
			$op2=get_module_pref("randop2");
			clear_module_pref("randop2");
			addnav("Continue","runmodule.php?module=ruinworld2&op=c&op2=$op2");
		}
		if (get_module_pref("shaman")==2){
			$expbonus=$session['user']['dragonkills']*3;
			$expgain =($session['user']['level']*25+$expbonus);
			set_module_pref("shaman",1);
			output("`n`@`bYou've gained `#%s experience`@.`b`n`n",$expgain);
			addnav("Continue","runmodule.php?module=ruinworld2&op=shamandefeat");		
		}
		if (get_module_pref("killdino")==2){
			$expbonus=$session['user']['dragonkills']*4;
			$expgain =($session['user']['level']*34+$expbonus);
			output("`n`@`bYou've gained `#%s experience`@.`b`n`n",$expgain);
			set_module_pref("killdino",1);
			addnav("Continue","runmodule.php?module=ruinworld2&op=dinodefeat");
		}
		if (get_module_pref("pterofight")==2){
			$expbonus=$session['user']['dragonkills']*2;
			$expgain =($session['user']['level']*19+$expbonus);
			output("`n`@`bYou've gained `#%s experience`@.`b`n`n",$expgain);
			set_module_pref("pterofight",1);
			set_module_pref("pterohps",0);
			addnav("Continue","runmodule.php?module=ruinworld2&op=exit");
		}
		$session['user']['experience']+=$expgain;
	}elseif($defeat){
		require_once("lib/taunt.php");
		$taunt = select_taunt_array();
		if (get_module_pref("rdinofight")==1){
			set_module_pref("rdinofight",0);
			clear_module_pref("randop2");
			$exploss = round($session['user']['experience']*.1);
			output("`b`4You lose `#%s experience`4.`b`n`n",$exploss);
			output("`^You lose all your gold.`n`n");
			output("The dinosaur enjoys your remains.");
			addnews("%s `@was eaten by a dinosaur.`n%s",$session['user']['name'],$taunt);
		}
		if (get_module_pref("killdino")==2){
			set_module_pref("killdino",0);
			$exploss = round($session['user']['experience']*.1);
			output("`b`4You lose `#%s experience`4.`b`n`n",$exploss);
			output("`^You lose all your gold.`n`n");
			output("The dinosaur enjoys your remains and sleeps comfortably.");
			addnews("%s `@was eaten by a Dinosaur.`n%s",$session['user']['name'],$taunt);
		}
		if (get_module_pref("shaman")==2){
			set_module_pref("shaman",3);
			$exploss = round($session['user']['experience']*.15);
			output("`b`4You lose `#%s experience`4.`b`n`n",$exploss);
			output("`^You lose all your gold.`n`n");
			output("The Shaman looks down at you and sadness sweeps over him.");
			addnews("%s `@was killed by an Ancient Shaman.`n%s",$session['user']['name'],$taunt);
		}
		if (get_module_pref("pterofight")==2){
			set_module_pref("pterofight",0);
			$exploss = round($session['user']['experience']*.08);
			set_module_pref("pterohps",0);
			output("`b`4You lose `#%s experience`4.`b`n`n",$exploss);
			output("`^You lose all your gold.`n`n");
			output("The pterodactyl picks up your body to feed to its hungry babies.");
			addnews("%s `@was killed by a Pterodactyl.`n%s",$session['user']['name'],$taunt);
		}
		addnav("Daily news","news.php");
		$session['user']['specialinc']="";
		$session['user']['experience']-=$exploss;
		$session['user']['alive'] = false;
		$session['user']['hitpoints'] = 0;
		$session['user']['gold']=0;
	}else{
		require_once("lib/fightnav.php");
		fightnav(true,false,"runmodule.php?module=ruinworld2");
	}
}

page_footer();

function ruinworld2_shamannavs (){
	addnav("Questions");
	if (get_module_pref("cavevisit")==1 && get_module_pref("haslight")==0) addnav("A Light Source","runmodule.php?module=ruinworld2&op=c&op2=shamlight");
	addnav("Dinosaurs","runmodule.php?module=ruinworld2&op=c&op2=shamdino");
	addnav("How to Leave","runmodule.php?module=ruinworld2&op=c&op2=shamleave");
	addnav("People of the Land","runmodule.php?module=ruinworld2&op=c&op2=shampeople");
	addnav("The Flowers in the Plains","runmodule.php?module=ruinworld2&op=c&op2=shamflowers");
	addnav("Other");
	addnav("Attack the Old Shaman","runmodule.php?module=ruinworld2&op=c&op2=attsham");
	addnav("Pick Flowers","runmodule.php?module=ruinworld2&op=c&op2=pickfl");
	addnav("Leave the Plain","runmodule.php?module=ruinworld2&op=c&op2=continue");
}
function ruinworld2_gemtrade(){
	if (get_module_pref("gemtrade")==0){
		if ($session['user']['gold']>0) output("`3You pull out some `^gold`3 and show it. It's clear that your `^gold`3 is not useful currency here.`n`n");
		if ($session['user']['gems']>0) output("`3You show some of your `%gems`3. It seems like that is a currency that would be useful here.`n`n");
		set_module_pref("gemtrade",1);
	}
}
function ruinworld2_ptero(){
	output("As you search, you're attack by the Pterodactyl!!");
	set_module_pref("pterofight",2);
	addnav("Fight the Pterodactyl","runmodule.php?module=ruinworld2&op=attack");
}
?>