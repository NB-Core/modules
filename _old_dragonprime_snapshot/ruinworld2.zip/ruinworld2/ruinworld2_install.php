<?php
	//Pterodactyl Egg
	//from Lonny Luberts' Garland's Stable
	$sql = "SELECT mountname FROM ".db_prefix("mounts")." where mountname = 'Baby Pterodactyl'";
	$result = mysql_query($sql);
	if (db_num_rows($result) < 1){
		output("Installing Dinosaur Mounts!");
		$sql = "INSERT INTO ".db_prefix("mounts")."  (mountname,mountdesc,mountcategory,mountbuff,mountcostgems,mountcostgold,mountactive,mountforestfights,newday,recharge,partrecharge) VALUES ('Baby Pterodactyl',' Baby Pterodactyl ','Exotic Creatures','a:7:{s:4:\"name\";s:16:\"Baby Pterodactyl\";s:8:\"roundmsg\";s:44:\"Your Baby Pterodactyl pecks at your Opponent\";s:7:\"wearoff\";s:31:\"Your Baby Pterodactyl is tired.\";s:6:\"rounds\";s:2:\"50\";s:6:\"atkmod\";s:3:\"1.2\";s:6:\"defmod\";s:3:\"1.1\";s:8:\"activate\";s:15:\"offense,defense\";}',5,1200,0,2,'You strap your {weapon} to your baby pterodactyl, and head out for some adventure!','`&Remembering that is has been quite some time since you last fed your baby pterodactyl, you decide this is a perfect time to relax and allow it to hunt in the field a bit. You doze off enjoying this peaceful serenity.`0','`&You dismount in the field to allow your baby pterodactyl to hunt for a moment even though it has recently been fully fed.  As you lean back in the grass to watch the clouds, your pterodactyl squawks softly and flies off into the sky.  You search for a while before returning to the fields hoping that it\'ll return.  A short time later, your pterodactyl flies back into the clearing holding its head high, looking much more energized and with a very excited grin on its face.`0')";
		db_query($sql) or die(db_error(LINK));
		if (db_affected_rows(LINK)>0){
			output("`2Installed Baby Pterodactyl Mount!`n");
		}else{
			output("`4Baby Pterodactyl Mount install failed!`n");
		}
		$sql = "INSERT INTO ".db_prefix("mounts")."  (mountname,mountdesc,mountcategory,mountbuff,mountcostgems,mountcostgold,mountactive,mountforestfights,newday,recharge,partrecharge) VALUES ('Young Pterodactyl','Young Pterodactyl','Exotic Creatures','a:7:{s:4:\"name\";s:17:\"Young Pterodactyl\";s:8:\"roundmsg\";s:42:\"Your Young Pterodactyl bites your Opponent\";s:7:\"wearoff\";s:32:\"Your Young Pterodactyl is tired.\";s:6:\"rounds\";s:2:\"65\";s:6:\"atkmod\";s:3:\"1.3\";s:6:\"defmod\";s:3:\"1.2\";s:8:\"activate\";s:15:\"offense,defense\";}',8,1700,0,4,'You strap your {weapon} to your young pterodactyl, and head out for some adventure!','`&Remembering that is has been quite some time since you last fed your young pterodactyl, you decide this is a perfect time to relax and allow it to fly around the field a bit. You doze off enjoying this peaceful serenity.`0','`&You dismount in the field to allow your young pterodactyl to graze for a moment even though it has recently been fully fed.  As you lean back in the grass to watch the clouds, your pterodactyl squawks softly and flies off into the sky.  You search for a while before returning to the fields hoping that it\'ll return.  A short time later, your pterodactyl flies back into the clearing holding its head high, looking much more energized and with a very excited grin on its face.`0')";
		db_query($sql) or die(db_error(LINK));
		if (db_affected_rows(LINK)>0){
			output("`2Installed Young Pterodactyl Mount!`n");
		}else{
			output("`4Young Pterodactyl Mount install failed!`n");
		}
		$sql = "INSERT INTO ".db_prefix("mounts")."  (mountname,mountdesc,mountcategory,mountbuff,mountcostgems,mountcostgold,mountactive,mountforestfights,newday,recharge,partrecharge) VALUES ('Pterodactyl','Pterodactyl','Exotic Creatures','a:7:{s:4:\"name\";s:11:\"Pterodactyl\";s:8:\"roundmsg\";s:53:\"Your Pterodactyl flies around and bites your Opponent\";s:7:\"wearoff\";s:26:\"Your Pterodactyl is tired.\";s:6:\"rounds\";s:2:\"80\";s:6:\"atkmod\";s:3:\"1.4\";s:6:\"defmod\";s:3:\"1.3\";s:8:\"activate\";s:15:\"offense,defense\";}',11,2100,0,6,'You strap your {weapon} to your pterodactyl, and head out for some adventure!','`&Remembering that is has been quite some time since you last fed your pterodactyl, you decide this is a perfect time to relax and allow it to fly around the field a bit. You doze off enjoying this peaceful serenity.`0','`&You dismount in the field to allow your pterodactyl to hunt for a moment even though it has recently been fully fed.  As you lean back in the grass to watch the clouds, your pterodactyl squawks softly and trots off into the underbrush.  You search for a while before returning to the fields hoping that it\'ll return.  A short time later, your pterodactyl flies back into the clearing holding its head high, looking much more energized and with a very excited grin on its face.`0')";
		db_query($sql) or die(db_error(LINK));
		if (db_affected_rows(LINK)>0){
			output("`2Installed Pterodactyl Mount!`n");
		}else{
			output("`4Pterodactyl Mount install failed!`n");
		}
		$sql = "SELECT mountid FROM ".db_prefix("mounts")." where mountname = 'Baby Pterodactyl'";
		$result = db_query($sql) or die(db_error(LINK));
		$row = db_fetch_assoc($result);
		if ($row['mountid'] > 0){
			set_module_setting("dbabyid1",$row['mountid']);
			output("`2Set ID for Baby Pterodactyl to ".$row['mountid'].".`n");
		}else{
			output("`4Failed to Set ID for Baby Pterodactyl!`n");
		}
		$sql = "SELECT mountid FROM ".db_prefix("mounts")." where mountname = 'Young Pterodactyl'";
		$result = db_query($sql) or die(db_error(LINK));
		$row = db_fetch_assoc($result);
		if ($row['mountid'] > 0){
			set_module_setting("djuvenileid1",$row['mountid']);
			output("`2Set ID for Young Pterodactyl to ".$row['mountid'].".`n");
		}else{
			output("`4Failed to Set ID for Young Pterodactyl!`n");
		}
		$sql = "SELECT mountid FROM ".db_prefix("mounts")." where mountname = 'Pterodactyl'";
		$result = db_query($sql) or die(db_error(LINK));
		$row = db_fetch_assoc($result);
		if ($row['mountid'] > 0){
			set_module_setting("dadultid1",$row['mountid']);
			output("`2Set ID for Pterodactyl to ".$row['mountid'].".`n");
		}else{
			output("`4Failed to Set ID for Pterodactyl!`n");
		}
	}
	//Raptor Egg
	//mountname=degg2
	$sql = "SELECT mountname FROM ".db_prefix("mounts")." where mountname = 'Baby Raptor'";
	$result = mysql_query($sql);
	if (db_num_rows($result) < 1){
		output("Installing Raptor Mounts!");
		$sql = "INSERT INTO ".db_prefix("mounts")."  (mountname,mountdesc,mountcategory,mountbuff,mountcostgems,mountcostgold,mountactive,mountforestfights,newday,recharge,partrecharge) VALUES ('Baby Raptor','Baby Raptor ','Exotic Creatures','a:7:{s:4:\"name\";s:11:\"Baby Raptor\";s:8:\"roundmsg\";s:39:\"Your Baby Raptor bites at your Opponent\";s:7:\"wearoff\";s:26:\"Your Baby Raptor is tired.\";s:6:\"rounds\";s:2:\"40\";s:6:\"atkmod\";s:3:\"1.2\";s:6:\"defmod\";s:3:\"1.1\";s:8:\"activate\";s:15:\"offense,defense\";}',5,1200,0,2,'You strap your {weapon} to your baby raptor, and head out for some adventure!','`&Remembering that is has been quite some time since you last fed your baby raptor, you decide this is a perfect time to relax and allow it to hunt in the field a bit. You doze off enjoying this peaceful serenity.`0','`&You dismount in the field to allow your baby raptor to hunt for a moment even though it has recently been fully fed.  As you lean back in the grass to watch the clouds, your raptor growls softly and trots off into the underbrush.  You search for a while before returning to the fields hoping that it\'ll return.  A short time later, your raptor trots back into the clearing holding its head high, looking much more energized and with a very reptilian grin on its face.`0')";
		db_query($sql) or die(db_error(LINK));
		if (db_affected_rows(LINK)>0){
			output("`2Installed Baby Raptor Mount!`n");
		}else{
			output("`4Baby Raptor Mount install failed!`n");
		}
		$sql = "INSERT INTO ".db_prefix("mounts")."  (mountname,mountdesc,mountcategory,mountbuff,mountcostgems,mountcostgold,mountactive,mountforestfights,newday,recharge,partrecharge) VALUES ('Young Raptor','Young Raptor','Exotic Creatures','a:7:{s:4:\"name\";s:12:\"Young Raptor\";s:8:\"roundmsg\";s:37:\"Your Young Raptor bites your Opponent\";s:7:\"wearoff\";s:27:\"Your Young Raptor is tired.\";s:6:\"rounds\";s:2:\"45\";s:6:\"atkmod\";s:3:\"1.4\";s:6:\"defmod\";s:3:\".95\";s:8:\"activate\";s:15:\"offense,defense\";}',8,1700,0,4,'You strap your {weapon} to your young raptor, and head out for some adventure!','`&Remembering that is has been quite some time since you last fed your young raptor, you decide this is a perfect time to relax and allow it to hunt the field a bit. You doze off enjoying this peaceful serenity.`0','`&You dismount in the field to allow your young raptor to hunt for a moment even though it has recently been fully fed.  As you lean back in the grass to watch the clouds, your raptor growls softly and trots off into the underbrush.  You search for a while before returning to the fields hoping that it\'ll return.  A short time later, your raptor trots back into the clearing holding its head high, looking much more energized and with a very reptilian grin on its face.`0')";
		db_query($sql) or die(db_error(LINK));
		if (db_affected_rows(LINK)>0){
			output("`2Installed Young Raptor Mount!`n");
		}else{
			output("`4Young Raptor Mount install failed!`n");
		}
		$sql = "INSERT INTO ".db_prefix("mounts")."  (mountname,mountdesc,mountcategory,mountbuff,mountcostgems,mountcostgold,mountactive,mountforestfights,newday,recharge,partrecharge) VALUES ('Raptor','Raptor','Exotic Creatures','a:7:{s:4:\"name\";s:6:\"Raptor\";s:8:\"roundmsg\";s:31:\"Your Raptor bites your Opponent\";s:7:\"wearoff\";s:21:\"Your Raptor is tired.\";s:6:\"rounds\";s:2:\"50\";s:6:\"atkmod\";s:3:\"1.6\";s:6:\"defmod\";s:3:\".92\";s:8:\"activate\";s:15:\"offense,defense\";}',11,2100,0,6,'You strap your {weapon} to your Raptor, and head out for some adventure!','`&Remembering that is has been quite some time since you last fed your raptor, you decide this is a perfect time to relax and allow it to hunt in the field a bit. You doze off enjoying this peaceful serenity.`0','`&You dismount in the field to allow your raptor to hunt for a moment even though it has recently been fully fed.  As you lean back in the grass to watch the clouds, your raptor growls softly and trots off into the underbrush.  You search for a while before returning to the fields hoping that it\'ll return.  A short time later, your raptor trots back into the clearing holding its head high, looking much more energized and with a very reptilian grin on its face.`0')";
		db_query($sql) or die(db_error(LINK));
		if (db_affected_rows(LINK)>0){
			output("`2Installed Raptor Mount!`n");
		}else{
			output("`4Raptor Mount install failed!`n");
		}
		$sql = "SELECT mountid FROM ".db_prefix("mounts")." where mountname = 'Baby Raptor'";
		$result = db_query($sql) or die(db_error(LINK));
		$row = db_fetch_assoc($result);
		if ($row['mountid'] > 0){
			set_module_setting("dbabyid2",$row['mountid']);
			output("`2Set ID for Baby Raptor to ".$row['mountid'].".`n");
		}else{
			output("`4Failed to Set ID for Baby Raptor!`n");
		}
		$sql = "SELECT mountid FROM ".db_prefix("mounts")." where mountname = 'Young Raptor'";
		$result = db_query($sql) or die(db_error(LINK));
		$row = db_fetch_assoc($result);
		if ($row['mountid'] > 0){
			set_module_setting("djuvenileid2",$row['mountid']);
			output("`2Set ID for Young Raptor to ".$row['mountid'].".`n");
		}else{
			output("`4Failed to Set ID for Young Raptor!`n");
		}
		$sql = "SELECT mountid FROM ".db_prefix("mounts")." where mountname = 'Raptor'";
		$result = db_query($sql) or die(db_error(LINK));
		$row = db_fetch_assoc($result);
		if ($row['mountid'] > 0){
			set_module_setting("dadultid2",$row['mountid']);
			output("`2Set ID for Raptor to ".$row['mountid'].".`n");
		}else{
			output("`4Failed to Set ID for Raptor!`n");
		}
	}
	//Triceratops Egg
	//mountname=degg3
	$sql = "SELECT mountname FROM ".db_prefix("mounts")." where mountname = 'Baby Triceratops'";
	$result = mysql_query($sql);
	if (db_num_rows($result) < 1){
		output("Installing Triceratops Mounts!");
		$sql = "INSERT INTO ".db_prefix("mounts")."  (mountname,mountdesc,mountcategory,mountbuff,mountcostgems,mountcostgold,mountactive,mountforestfights,newday,recharge,partrecharge) VALUES ('Baby Triceratops','Baby Triceratops ','Exotic Creatures','a:7:{s:4:\"name\";s:16:\"Baby Triceratops\";s:8:\"roundmsg\";s:42:\"Your Baby Triceratops nudges your Opponent\";s:7:\"wearoff\";s:31:\"Your Baby Triceratops is tired.\";s:6:\"rounds\";s:2:\"60\";s:6:\"atkmod\";s:3:\"1.1\";s:6:\"defmod\";s:3:\"1.2\";s:8:\"activate\";s:15:\"offense,defense\";}',5,1200,0,2,'You strap your {weapon} to your baby triceratops, and head out for some adventure!','`&Remembering that is has been quite some time since you last fed your baby triceratops, you decide this is a perfect time to relax and allow it to graze the field a bit. You doze off enjoying this peaceful serenity.`0','`&You dismount in the field to allow your baby triceratops to graze for a moment even though it has recently been fully fed.  As you lean back in the grass to watch the clouds, your triceratops growls softly and trots off into the underbrush.  You search for a while before returning to the fields hoping that it\'ll return.  A short time later, your triceratops trots back into the clearing holding its head high, looking much more energized and with a very reptilian grin on its face.`0')";
		db_query($sql) or die(db_error(LINK));
		if (db_affected_rows(LINK)>0){
			output("`2Installed Baby Triceratops Mount!`n");
		}else{
			output("`4Baby Triceratops Mount install failed!`n");
		}
		$sql = "INSERT INTO ".db_prefix("mounts")."  (mountname,mountdesc,mountcategory,mountbuff,mountcostgems,mountcostgold,mountactive,mountforestfights,newday,recharge,partrecharge) VALUES ('Young Triceratops','Young Triceratops','Exotic Creatures','a:7:{s:4:\"name\";s:17:\"Young Triceratops\";s:8:\"roundmsg\";s:41:\"Your Young Triceratops rams your Opponent\";s:7:\"wearoff\";s:32:\"Your Young Triceratops is tired.\";s:6:\"rounds\";s:2:\"80\";s:6:\"atkmod\";s:3:\"1.2\";s:6:\"defmod\";s:4:\"1.35\";s:8:\"activate\";s:15:\"offense,defense\";}',8,1700,0,4,'You strap your {weapon} to your young triceratops, and head out for some adventure!','`&Remembering that is has been quite some time since you last fed your young triceratops, you decide this is a perfect time to relax and allow it to graze the field a bit. You doze off enjoying this peaceful serenity.`0','`&You dismount in the field to allow your young triceratops to graze for a moment even though it has recently been fully fed.  As you lean back in the grass to watch the clouds, your triceratops growls softly and trots off into the underbrush.  You search for a while before returning to the fields hoping that it\'ll return.  A short time later, your triceratops trots back into the clearing holding its head high, looking much more energized and with a very reptilian grin on its face.`0')";
		db_query($sql) or die(db_error(LINK));
		if (db_affected_rows(LINK)>0){
			output("`2Installed Young Triceratops Mount!`n");
		}else{
			output("`4Young Triceratops Mount install failed!`n");
		}
		$sql = "INSERT INTO ".db_prefix("mounts")."  (mountname,mountdesc,mountcategory,mountbuff,mountcostgems,mountcostgold,mountactive,mountforestfights,newday,recharge,partrecharge) VALUES ('Triceratops','Triceratops','Exotic Creatures','a:7:{s:4:\"name\";s:11:\"Triceratops\";s:8:\"roundmsg\";s:35:\"Your Triceratops rams your Opponent\";s:7:\"wearoff\";s:26:\"Your Triceratops is tired.\";s:6:\"rounds\";s:3:\"100\";s:6:\"atkmod\";s:3:\"1.2\";s:6:\"defmod\";s:3:\"1.5\";s:8:\"activate\";s:15:\"offense,defense\";}',11,2100,0,6,'You strap your {weapon} to your Triceratops, and head out for some adventure!','`&Remembering that is has been quite some time since you last fed your triceratops, you decide this is a perfect time to relax and allow it to graze the field a bit. You doze off enjoying this peaceful serenity.`0','`&You dismount in the field to allow your triceratops to graze for a moment even though it has recently been fully fed.  As you lean back in the grass to watch the clouds, your triceratops growls softly and trots off into the underbrush.  You search for a while before returning to the fields hoping that it\'ll return.  A short time later, your triceratops trots back into the clearing holding its head high, looking much more energized and with a very reptilian grin on its face.`0')";
		db_query($sql) or die(db_error(LINK));
		if (db_affected_rows(LINK)>0){
			output("`2Installed Triceratops Mount!`n");
		}else{
			output("`4Triceratops Mount install failed!`n");
		}
		$sql = "SELECT mountid FROM ".db_prefix("mounts")." where mountname = 'Baby Triceratops'";
		$result = db_query($sql) or die(db_error(LINK));
		$row = db_fetch_assoc($result);
		if ($row['mountid'] > 0){
			set_module_setting("dbabyid3",$row['mountid']);
			output("`2Set ID for Baby Triceratops to ".$row['mountid'].".`n");
		}else{
			output("`4Failed to Set ID for Baby Triceratops!`n");
		}
		$sql = "SELECT mountid FROM ".db_prefix("mounts")." where mountname = 'Young Triceratops'";
		$result = db_query($sql) or die(db_error(LINK));
		$row = db_fetch_assoc($result);
		if ($row['mountid'] > 0){
			set_module_setting("djuvenileid3",$row['mountid']);
			output("`2Set ID for Young Triceratops to ".$row['mountid'].".`n");
		}else{
			output("`4Failed to Set ID for Young Triceratops!`n");
		}
		$sql = "SELECT mountid FROM ".db_prefix("mounts")." where mountname = 'Triceratops'";
		$result = db_query($sql) or die(db_error(LINK));
		$row = db_fetch_assoc($result);
		if ($row['mountid'] > 0){
			set_module_setting("dadultid3",$row['mountid']);
			output("`2Set ID for Triceratops to ".$row['mountid'].".`n");
		}else{
			output("`4Failed to Set ID for Triceratops!`n");
		}
	}
	//End Lonny's Code
?>
