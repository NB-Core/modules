<?php
/**
* Version:  1.0
* Date:     January 26, 2005
* Author:   Robert of Maddrio dot com / Converted by: Kevin Hatfield - Arune
* v 1.1     cleaned code
* v 1.2     optimized code
*/
function travelers_getmoduleinfo(){
	$info = array(
	"name"=>"Travelers",
	"version"=>"1.2",
	"author"=>"`2Robert `7- Converted by: Arune",
	"download"=>"http://dragonprime.net/users/robert/travelers098.zip",
	"category"=>"Forest Specials",
	);
	return $info;
}

function travelers_install(){
	module_addeventhook("forest", "return 100;");
	return true;
}

function travelers_uninstall(){
	return true;
}

function travelers_dohook($hookname,$args){
	return $args;
}

function travelers_runevent($type){
global $session;
output(" `n`n`2You come upon a small stream of `&sparkling clear water`2. `n");
output(" Your thirst is immediate, so you kneel and bend over to take a drink. `n");
output(" `&Another traveler `2appears and asks if the water is as good as it looks. `n");
output(" You turn to him and tell him it is cold and delicious. `n The traveler bends down to drink also. `n");
output(" He tells you his tales of woe and the treacherous thieves at `6Dwarf Village`2. `n");
output(" You agree one needs to be on their guard whenever Dwarfs are around.  `n");
output(" To go near their Village is like a fly wanting to visit the spider. `n");
output(" Pressed for time, you bid the traveler a good day and walk away feeling a little better. `n");
$session['user']['charm']++;
}

function travelers_run(){
}
?>