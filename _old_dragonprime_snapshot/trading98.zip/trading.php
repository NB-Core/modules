<?php
function trading_getmoduleinfo(){
	$info = array(
		"name"=>"Trading",
		"version"=>"2.2",
		"author"=>"`#Lonny Luberts",
		"category"=>"PQcomp",
		"download"=>"http://www.pqcomp.com/modules/mydownloads/visit.php?cid=3&lid=21",
		"vertxtloc"=>"http://www.pqcomp.com/",
		"prefs"=>array(
			"Trading Module User Preferences,title",
			"fox"=>"Fox Pelts,int|0",
			"fish"=>"Fish Eyes,int|0",
			"worms"=>"Worms,int|0",
			"bat"=>"Bat Wings,int|0",
			"newt"=>"Eye of Newt,int|0",
			"dog"=>"Puppy Dog Tails,int|0",
			"frog"=>"Frog Legs,int|0",
			"wort"=>"Wort,int|0",
			"heads"=>"Shrunken Heads,int|0",
			"wool"=>"Wool,int|0",
			"cloth"=>"Cloth,int|0",
			"leather"=>"Leather,int|0",
			"foxprice"=>"Fox Pelts Price,int|0",
			"fishprice"=>"Fish Eyes Price,int|0",
			"wormsprice"=>"Worms Price,int|0",
			"batprice"=>"Bat Wings Price,int|0",
			"newtprice"=>"Eye of Newt Price,int|0",
			"dogprice"=>"Puppy Dog Tails Price,int|0",
			"frogprice"=>"Frog Legs Price,int|0",
			"wortprice"=>"Wort Price,int|0",
			"headsprice"=>"Shrunken Heads Price,int|0",
			"woolprice"=>"Wool Price,int|0",
			"clothprice"=>"Cloth Price,int|0",
			"leatherprice"=>"Leather Price,int|0",
			"foxavail"=>"Fox Pelts Available,int|0",
			"fishavail"=>"Fish Eyes Available,int|0",
			"wormsavail"=>"Worms Available,int|0",
			"batavail"=>"Bat Wings Available,int|0",
			"newtavail"=>"Eye of Newt Available,int|0",
			"dogavail"=>"Puppy Dog Tails Available,int|0",
			"frogavail"=>"Frog Legs Available,int|0",
			"wortavail"=>"Wort Available,int|0",
			"headsavail"=>"Shrunken Heads Available,int|0",
			"woolavail"=>"Wool Available,int|0",
			"clothavail"=>"Cloth Available,int|0",
			"leatheravail"=>"Leather Available,int|0",
			"dailytrades"=>"Daily Trades,int|20",
			"shop"=>"Last visited Shop,text|",
		),
		"settings"=>array(
			"Trading Module Settings,title",
			"trades"=>"Daily Trades,int|20",
			"robberhp"=>"Robber Hitpoints,enum,1.5,Medium,.75,Low,1,Medium-Low,2,Medium-High,3,High,4,Very High",
			"singletown"=>"Is this a single town installation,bool|0",
		),
	);
	return $info;
}

function trading_install(){
	if (!is_module_active('trading')){
		output("`4Installing Trading Module.`n");
	}else{
		output("`4Updating Trading Module.`n");
	}
	module_addhook("charstats");
	module_addhook("dragonkill");
	module_addhook("newday");
	module_addhook("village");
	module_addeventhook("forest", "return 100;");
	return true;
}

function trading_uninstall(){
	output("`4Un-Installing Trading Module.`n");
	return true;
}

function trading_dohook($hookname,$args){
	global $session;
	switch($hookname){
		case "charstats":
			if ($session['user']['alive'] == 1){
				if (is_module_active('backpack')){
					modulehook("tradebackpack",$args);
				}else{
					if (get_module_pref('fox') > 0 or get_module_pref('fish') > 0 or get_module_pref('worms') > 0 or get_module_pref('bat') > 0 or get_module_pref('newt') >0 or get_module_pref('dog') > 0 or  get_module_pref('frog') > 0 or get_module_pref('wort') > 0 or get_module_pref('heads') > 0 or get_module_pref('wool') > 0 or get_module_pref('cloth') > 0 or get_module_pref('leather') > 0) addcharstat("Inventory");
					if (get_module_pref('fox') > 0) addcharstat("Fox Pelts", get_module_pref('fox'));
					if (get_module_pref('fish') > 0) addcharstat("Fish Eyes", get_module_pref('fish'));
					if (get_module_pref('worms') > 0) addcharstat("Worms", get_module_pref('worms'));
					if (get_module_pref('bat') > 0) addcharstat("Bat Wings", get_module_pref('bat'));
					if (get_module_pref('newt') > 0) addcharstat("Eye of Newt", get_module_pref('newt'));
					if (get_module_pref('dog') > 0) addcharstat("Puppy Dog Tails", get_module_pref('dog'));
					if (get_module_pref('frog') > 0) addcharstat("Frog Legs", get_module_pref('frog'));
					if (get_module_pref('wort') > 0) addcharstat("Wort", get_module_pref('wort'));
					if (get_module_pref('heads') > 0) addcharstat("Shrunken Heads", get_module_pref('heads'));
					if (get_module_pref('wool') > 0) addcharstat("Wool", get_module_pref('wool'));
					if (get_module_pref('cloth') > 0) addcharstat("Cloth", get_module_pref('cloth'));
					if (get_module_pref('leather') > 0) addcharstat("Leather", get_module_pref('leather'));
				}
			}
		break;
		case "dragonkill":
			set_module_pref('fox',0);
			set_module_pref('fish',0);
			set_module_pref('worms',0);
			set_module_pref('bat',0);
			set_module_pref('newt',0);
			set_module_pref('dog',0);
			set_module_pref('frog',0);
			set_module_pref('wort',0);
			set_module_pref('heads',0);
			set_module_pref('wool',0);
			set_module_pref('cloth',0);
			set_module_pref('leather',0);
		break;
		case "newday":
			set_module_pref('dailytrades', get_module_setting('trades'));
			if (get_module_setting('singletown')==1) set_module_pref('shop',' ');
		break;
		case "village":
			//add a diffent trading post to each village
			$town = $session['user']['location'];
			tlschema($args['schemas']['marketnav']);
    		addnav($args['marketnav']);
    		tlschema();
			addnav(array("%s Trading Post",$town),"runmodule.php?module=trading");
		break;
	}
	return $args;
}

function trading_runevent(){
	global $SCRIPT_NAME;
	if ($SCRIPT_NAME == "forest.php"){
		include("modules/lib/trading_event.php");
	}
}

function trading_run(){
	global $SCRIPT_NAME;
	if ($SCRIPT_NAME == "runmodule.php"){
		$module=httpget("module");
		if ($module == "trading") include("modules/lib/trading.php");
	}
}
?>