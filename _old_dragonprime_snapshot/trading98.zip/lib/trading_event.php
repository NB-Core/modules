<?php
global $session;
$op = httpget('op');
page_header("Robbers");
output("`@`c`bA Band of Robbers`b`c`n");
output("You are being robbed, by a band of robbers!");
if ($op==""){
	$badguy = array(        "creaturename"=>"`@Band of Robbers`0"
                                ,"creaturelevel"=>0
                                ,"creatureweapon"=>"Swords"
                                ,"creatureattack"=>1
                                ,"creaturedefense"=>2
                                ,"creaturehealth"=>2
                                ,"diddamage"=>0);


                                //buff badguy up a little
                                $userlevel=$session['user']['level'] + 1;
                                $userattack=$session['user']['attack']+e_rand(1,3);
                                $userhealth=$session['user']['hitpoints']*get_module_setting('robberhp');
                                $userdefense=$session['user']['defense']+e_rand(1,3);
                                $badguy['creaturelevel']+=$userlevel;
                                $badguy['creatureattack']+=$userattack;
                                $badguy['creaturehealth']=$userhealth;
                                $badguy['creaturedefense']+=$userdefense;
                                $session['user']['badguy']=createstring($badguy);
	$session['user']['specialinc']="module:trading";
output("What would you like to do?");
addnav("Fight","forest.php?op=fight");
addnav("Run","forest.php?op=fight");
addnav("Give them what they want","forest.php?op=give");
}
if ($op=="win"){
	$session['user']['specialinc']="";
	redirect("forest.php");
}
if ($op=="fight"){
$battle=true;

// battle him                               
if ($battle){
    include_once ("battle.php");
    $session['user']['specialinc']="module:trading";
        if ($victory){
                output("You have beaten `^%s.",$badguy['creaturename']);
                $badguy=array();
                $session['user']['badguy']="";
                addnav("Continue","forest.php?op=win");
	}
	elseif ($defeat){
         		output("As you hit the ground `^%s take your stuff.",$badguy['creaturename']);
                addnews("`% %s`5 has been slain when %s fought %s.",$session['user']['name'],translate_inline($session['user']['sex']?"she":"he"),$badguy['creaturename']);
                $badguy=array();
                $session['user']['badguy']="";  
                $session['user']['hitpoints']=0;
                addnav("Continue","forest.php?op=lost");
	}
	else{
                fightnav(true,false);
	}
}
}
if ($op=="lost" or $op=="give"){
$name = $session['user']['name'];
$inventory=0;
$fox=get_module_pref('fox');
	$inventory=get_module_pref('fox');
	$fish=get_module_pref('fish');
	$inventory+=get_module_pref('fish');
	$worms=get_module_pref('worms');
	$inventory+=get_module_pref('worms');
	$bat=get_module_pref('bat');
	$inventory+=get_module_pref('bat');
	$newt=get_module_pref('newt');
	$inventory+=get_module_pref('newt');
	$dog=get_module_pref('dog');
	$inventory+=get_module_pref('dog');
	$frog=get_module_pref('frog');
	$inventory+=get_module_pref('frog');
	$wort=get_module_pref('wort');
	$inventory+=get_module_pref('wort');
	$heads=get_module_pref('heads');
	$inventory+=get_module_pref('heads');
	$wool=get_module_pref('wool');
	$inventory+=get_module_pref('wool');
	$cloth=get_module_pref('cloth');
	$inventory+=get_module_pref('cloth');
	$leather=get_module_pref('leather');
	$inventory+=get_module_pref('leather');
addnews("%s was robbed in the forest by a band of robbers!",$name);
output("They have taken:`n");
$number = e_rand(1,3);
if ($number > 1 and $inventory > 0){
$robbed = e_rand(1,$inventory);
$number = e_rand(1,4);
// rob expensive stuff first
if ($number > 3){
	if (get_module_pref('leather') > 0){
	$steal = e_rand(1,$robbed);
	if ($steal > get_module_pref('leather')) $steal=get_module_pref('leather');
	set_module_pref('leather', (get_module_pref('leather') - $steal));
	$robbed-=$steal;
	if ($steal > 0) addnews("%s lost %s Leather to the robbers!",$name,$steal);
	output("`4%s - Leather`n",$steal);
}
if (get_module_pref('cloth') > 0 and $robbed > 0){
	$steal = e_rand(1,$robbed);
	if ($steal > get_module_pref('cloth')) $steal=get_module_pref('cloth');
	set_module_pref('cloth', (get_module_pref('cloth') - $steal));
	$robbed-=$steal;
	if ($steal > 0) addnews("%s lost %s Cloth to the robbers!",$name,$steal);
	output("`4%s - Cloth`n",$steal);
}
if (get_module_pref('wool') > 0 and $robbed > 0){
	$steal = e_rand(1,$robbed);
	if ($steal > get_module_pref('wool')) $steal=get_module_pref('wool');
	set_module_pref('wool', (get_module_pref('wool') - $steal));
	$robbed-=$steal;
	if ($steal > 0) addnews("%s lost %s Wool to the robbers!",$name,$steal);
	output("`4%s - Wool`n",$steal);
}
if (get_module_pref('heads') > 0 and $robbed > 0){
	$steal = e_rand(1,$robbed);
	if ($steal > get_module_pref('heads')) $steal=get_module_pref('heads');
	set_module_pref('heads', (get_module_pref('heads') - $steal));
	$robbed-=$steal;
	if ($steal > 0) addnews("%s lost %s Shrunken Heads to the robbers!",$name,$steal);
	output("`4%s - Shrunken Heads`n",$steal);
}
if (get_module_pref('wort') > 0 and $robbed > 0){
	$steal = e_rand(1,$robbed);
	if ($steal > get_module_pref('wort')) $steal=get_module_pref('wort');
	set_module_pref('wort', (get_module_pref('wort') - $steal));
	$robbed-=$steal;
	if ($steal > 0) addnews("%s lost %s Wort to the robbers!",$name,$steal);
	output("`4%s - Wort`n",$steal);
}
if (get_module_pref('frog') > 0 and $robbed > 0){
	$steal = e_rand(1,$robbed);
	if ($steal > get_module_pref('frog')) $steal=get_module_pref('frog');
	set_module_pref('frog', (get_module_pref('frog') - $steal));
	$robbed-=$steal;
	if ($steal > 0) addnews("%s lost %s Frog Legs to the robbers!",$name,$steal);
	output("`4%s - Frog Legs`n",$steal);
}
if (get_module_pref('dog') > 0 and $robbed > 0){
	$steal = e_rand(1,$robbed);
	if ($steal > get_module_pref('dog')) $steal=get_module_pref('dog');
	set_module_pref('dog', (get_module_pref('dog') - $steal));
	$robbed-=$steal;
	if ($steal > 0) addnews("%s lost %s Puppy Dog Tails to the robbers!",$name,$steal);
	output("`4%s - Puppy Dog Tails`n",$steal);
}
if (get_module_pref('newt') > 0 and $robbed > 0){
	$steal = e_rand(1,$robbed);
	if ($steal > get_module_pref('newt')) $steal=get_module_pref('newt');
	set_module_pref('newt', (get_module_pref('newt') - $steal));
	$robbed-=$steal;
	if ($steal > 0) addnews("%s lost %s Eye of Newt to the robbers!",$name,$steal);
	output("`4%s - Eye of Newt`n",$steal);
}
if (get_module_pref('bat') > 0 and $robbed > 0){
	$steal = e_rand(1,$robbed);
	if ($steal > get_module_pref('bat')) $steal=get_module_pref('bat');
	set_module_pref('bat', (get_module_pref('bat') - $steal));
	$robbed-=$steal;
	if ($steal > 0) addnews("%s lost %s Bat Wings to the robbers!",$name,$steal);
	output("`4%s - Bat Wings`n",$steal);
}
if (get_module_pref('worms') > 0 and $robbed > 0){
	$steal = e_rand(1,$robbed);
	if ($steal > get_module_pref('worms')) $steal=get_module_pref('worms');
	set_module_pref('worms', (get_module_pref('worms') - $steal));
	$robbed-=$steal;
	if ($steal > 0) addnews("%s lost %s Worms to the robbers!",$name,$steal);
	output("`4%s - Worms`n",$steal);
}
if (get_module_pref('fish') > 0 and $robbed > 0){
	$steal = e_rand(1,$robbed);
	if ($steal > get_module_pref('fish')) $steal=get_module_pref('fish');
	set_module_pref('fish', (get_module_pref('fish') - $steal));
	$robbed-=$steal;
	if ($steal > 0) addnews("%s lost %s Fish Eyes to the robbers!",$name,$steal);
	output("`4%s - Fish Eyes`n",$steal);
}
if (get_module_pref('fox') > 0 and $robbed > 0){
	$steal = e_rand(1,$robbed);
	if ($steal > get_module_pref('fox')) $steal=get_module_pref('fox');
	set_module_pref('fox', (get_module_pref('fox') - $steal));
	$robbed-=$steal;
	if ($steal > 0) addnews("%s lost %s Fox Pelts to the robbers!",$name,$steal);
	output("`4%s - Fox Pelts`n",$steal);
}
}
// end rob expensive stuff
else{
// rob cheap things first
if (get_module_pref('fox') > 0){
	$steal = e_rand(1,$robbed);
	if ($steal > get_module_pref('fox')) $steal=get_module_pref('fox');
	set_module_pref('fox', (get_module_pref('fox') - $steal));
	$robbed-=$steal;
	if ($steal > 0) addnews("%s lost %s Fox Pelts to the robbers!",$name,$steal);
	output("`4%s - Fox Pelts`n",$steal);
}
if (get_module_pref('fish') > 0 and $robbed > 0){
	$steal = e_rand(1,$robbed);
	if ($steal > get_module_pref('fish')) $steal=get_module_pref('fish');
	set_module_pref('fish', (get_module_pref('fish') - $steal));
	$robbed-=$steal;
	if ($steal > 0) addnews("%s lost %s Fish Eyes to the robbers!",$name,$steal);
	output("`4%s - Fish Eyes`n",$steal);
}
if (get_module_pref('worms') > 0 and $robbed > 0){
	$steal = e_rand(1,$robbed);
	if ($steal > get_module_pref('worms')) $steal=get_module_pref('worms');
	set_module_pref('worms', (get_module_pref('worms') - $steal));
	$robbed-=$steal;
	if ($steal > 0) addnews("%s lost %s Worms to the robbers!",$name,$steal);
	output("`4%s - Worms`n",$steal);
}	
if (get_module_pref('bat') > 0 and $robbed > 0){
	$steal = e_rand(1,$robbed);
	if ($steal > get_module_pref('bat')) $steal=get_module_pref('bat');
	set_module_pref('bat', (get_module_pref('bat') - $steal));
	$robbed-=$steal;
	if ($steal > 0) addnews("%s lost %s Bat Wings to the robbers!",$name,$steal);
	output("`4%s - Bat Wings`n",$steal);
}
if (get_module_pref('newt') > 0 and $robbed > 0){
	$steal = e_rand(1,$robbed);
	if ($steal > get_module_pref('newt')) $steal=get_module_pref('newt');
	set_module_pref('newt', (get_module_pref('newt') - $steal));
	$robbed-=$steal;
	if ($steal > 0) addnews("%s lost %s Eye of Newt to the robbers!",$name,$steal);
	output("`4%s - Eye of Newt`n",$steal);
}
if (get_module_pref('dog') > 0 and $robbed > 0){
	$steal = e_rand(1,$robbed);
	if ($steal > get_module_pref('dog')) $steal=get_module_pref('dog');
	set_module_pref('dog', (get_module_pref('dog') - $steal));
	$robbed-=$steal;
	if ($steal > 0) addnews("%s lost %s Puppy Dog Tails to the robbers!",$name,$steal);
	output("`4%s - Puppy Dog Tails`n",$steal);
}
if (get_module_pref('frog') > 0 and $robbed > 0){
	$steal = e_rand(1,$robbed);
	if ($steal > get_module_pref('frog')) $steal=get_module_pref('frog');
	set_module_pref('frog', (get_module_pref('frog') - $steal));
	$robbed-=$steal;
	if ($steal > 0) addnews("%s lost %s Frog Legs to the robbers!",$name,$steal);
	output("`4%s - Frog Legs`n",$steal);
}
if (get_module_pref('wort') > 0 and $robbed > 0){
	$steal = e_rand(1,$robbed);
	if ($steal > get_module_pref('wort')) $steal=get_module_pref('wort');
	set_module_pref('wort', (get_module_pref('wort') - $steal));
	$robbed-=$steal;
	if ($steal > 0) addnews("%s lost %s Wort to the robbers!",$name,$steal);
	output("`4%s - Wort`n",$steal);
}
if (get_module_pref('heads') > 0 and $robbed > 0){
	$steal = e_rand(1,$robbed);
	if ($steal > get_module_pref('heads')) $steal=get_module_pref('heads');
	set_module_pref('heads', (get_module_pref('heads') - $steal));
	$robbed-=$steal;
	if ($steal > 0) addnews("%s lost %s Shrunken Heads to the robbers!",$name,$steal);
	output("`4%s - Shrunken Heads`n",$steal);
}
if (get_module_pref('wool') > 0 and $robbed > 0){
	$steal = e_rand(1,$robbed);
	if ($steal > get_module_pref('wool')) $steal=get_module_pref('wool');
	set_module_pref('wool', (get_module_pref('wool') - $steal));
	$robbed-=$steal;
	if ($steal > 0) addnews("%s lost %s Wool to the robbers!",$name,$steal);
	output("`4%s - Wool`n",$steal);
}
if (get_module_pref('cloth') > 0 and $robbed > 0){
	$steal = e_rand(1,$robbed);
	if ($steal > get_module_pref('cloth')) $steal=get_module_pref('cloth');
	set_module_pref('cloth', (get_module_pref('cloth') - $steal));
	$robbed-=$steal;
	if ($steal > 0) addnews("%s lost %s Cloth to the robbers!",$name,$steal);
	output("`4%s - Cloth`n",$steal);
}
if (get_module_pref('leather') > 0 and $robbed > 0){
	$steal = e_rand(1,$robbed);
	if ($steal > get_module_pref('leather')) $steal=get_module_pref('leather');
	set_module_pref('leather', (get_module_pref('leather') - $steal));
	$robbed-=$steal;
	if ($steal > 0) addnews("%s lost %s Leather to the robbers!",$name,$steal);
	output("`4%s - Leather`n",$steal);
}
}
//end rob cheap things first
	
$fox=get_module_pref('fox');
$fish=get_module_pref('fish');
$worms=get_module_pref('worms');
$bat=get_module_pref('bat');
$newt=get_module_pref('newt');
$dog=get_module_pref('dog');
$frog=get_module_pref('frog');
$wort=get_module_pref('wort');
$heads=get_module_pref('heads');
$wool=get_module_pref('wool');
$cloth=get_module_pref('cloth');
$leather=get_module_pref('leather');
addnav("`@Return to Forest","forest.php");
output("`n`2You now have in your pack.`n");
output("`1Fox Pelts - %s`n",$fox);
output("`!Fish Eyes - %s`n",$fish);
output("`1Worms - %s`n",$worms);
output("`!Bat Wings - %s`n",$bat);
output("`1Eye of Newt - %s`n",$newt);
output("`!Puppy Dog Tails - %s`n",$dog);
output("`1Frog Legs - %s`n",$frog);
output("`!Wort - %s`n",$wort);
output("`1Shrunken Heads - %s`n",$heads);
output("`!Wool - %s`n",$wool);
output("`1Cloth - %s`n",$cloth);
output("`!Leather - %s`n",$leather);
}else{
	$gold = $session['user']['gold'];
	$robbed = e_rand(1,$gold);
	$session['user']['gold']-=$robbed;
	output("`4%s - `^gold`n",$robbed);
	if ($robbed > 0) addnews("%s lost %s gold to the robbers!",$name,$robbed);
	$gems = $session['user']['gems'];
	$robbed = e_rand(1,$gmes);
	$session['user']['gems']-=$robbed;
	output("`4%s - `%gems`n",$robbed);
	if ($robbed > 0) addnews("%s lost %s gems to the robbers!",$name,$robbed);
	$session['user']['specialinc']="";
	if ($session['user']['hitpoints'] > 0) addnav("`@Return to Forest","forest.php");
	if ($session['user']['hitpoints'] < 1) redirect("shades.php");
	}
}
?>