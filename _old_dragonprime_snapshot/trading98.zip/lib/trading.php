<?php
global $session;
$op = httpget('op');
$buy = $_POST['buy'];
if ($buy < 0) $buy = 0;
$sell = $_POST['sell'];
if ($sell < 0) $sell = 0;
$town = $session['user']['location'];
page_header("$town Trading Post");
output("`@`c`bTrading Post`b`c`n");
$myname=$session['user']['name'];
//check and display inventory
	output("`2You have in your pack.`n");
	$fox=get_module_pref('fox');
	output("`1Fox Pelts - %s`n",$fox);
	$inventory=get_module_pref('fox');
	$fish=get_module_pref('fish');
	output("`!Fish Eyes - %s`n",$fish);
	$inventory+=get_module_pref('fish');
	$worms=get_module_pref('worms');
	output("`1Worms - %s`n",$worms);
	$inventory+=get_module_pref('worms');
	$bat=get_module_pref('bat');
	output("`!Bat Wings - %s`n",$bat);
	$inventory+=get_module_pref('bat');
	$newt=get_module_pref('newt');
	output("`1Eye of Newt - %s`n",$newt);
	$inventory+=get_module_pref('newt');
	$dog=get_module_pref('dog');
	output("`!Puppy Dog Tails - %s`n",$dog);
	$inventory+=get_module_pref('dog');
	$frog=get_module_pref('frog');
	output("`1Frog Legs - %s`n",$frog);
	$inventory+=get_module_pref('frog');
	$wort=get_module_pref('wort');
	output("`!Wort - %s`n",$wort);
	$inventory+=get_module_pref('wort');
	$heads=get_module_pref('heads');
	output("`1Shrunken Heads - %s`n",$heads);
	$inventory+=get_module_pref('heads');
	$wool=get_module_pref('wool');
	output("`!Wool - %s`n",$wool);
	$inventory+=get_module_pref('wool');
	$cloth=get_module_pref('cloth');
	output("`1Cloth - %s`n",$cloth);
	$inventory+=get_module_pref('cloth');
	$leather=get_module_pref('leather');
	output("`!Leather - %s`n",$leather);
	$inventory+=get_module_pref('leather');
	output("`7You have %s transactions left.`n",get_module_pref('dailytrades'));
	$space=(50 - $inventory);
	if ($space == 1){
		$items = "item";
	}else{
		$items = "items";
	}
  	if ($inventory < 50) output("`2You have space left for %s more %s.`n`n",$space,$items);
	if ($inventory > 49) output("`4You notice that your Pack is full.`n`n");
//build first time navigation
if ($op==""){
	if (get_module_pref('dailytrades') > 0 and get_module_pref('shop')<>$town){
		$foxgold = e_rand(1,5);
		set_module_pref('foxprice',$foxgold);
		$fishgold = e_rand(5,10);
		set_module_pref('fishprice',$fishgold);
		$wormsgold = e_rand(3,8);
		set_module_pref('wormsprice',$wormsgold);
		$batgold = e_rand(8,13);
		set_module_pref('batprice',$batgold);
		$newtgold = e_rand(10,15);
		set_module_pref('newtprice',$newtgold);
		$doggold = e_rand(15,20);
		set_module_pref('dogprice',$doggold);
		$froggold = e_rand(13,18);
		set_module_pref('frogprice',$froggold);
		$headsgold = e_rand(100,200);
		set_module_pref('headsprice',$headsgold);
		$wortgold = e_rand(20,60);
		set_module_pref('wortprice',$wortgold);
		$woolgem = e_rand(3,4);
		set_module_pref('woolprice',$woolgem);
		$clothgem = e_rand(3,4);
		set_module_pref('clothprice',$clothgem);
		$leathergem = e_rand(4,6);
		set_module_pref('leatherprice',$leathergem);
		$foxavail = e_rand(1,20);
		set_module_pref('foxavail',$foxavail);
		$fishavail = e_rand(1,20);
		set_module_pref('fishavail',$fishavail);
		$wormsavail = e_rand(1,20);
		set_module_pref('wormsavail',$wormsavail);
		$batavail = e_rand(1,20);
		set_module_pref('batavail',$batavail);
		$newtavail = e_rand(1,20);
		set_module_pref('newtavail',$newtavail);
		$dogavail = e_rand(1,20);
		set_module_pref('dogavail',$dogavail);
		$frogavail = e_rand(1,20);
		set_module_pref('frogavail',$frogavail);
		$wortavail = e_rand(1,20);
		set_module_pref('wortavail',$wortavail);
		$headsavail = e_rand(1,20);
		set_module_pref('headsavail',$headsavail);
		$woolavail = e_rand(1,24);
		set_module_pref('woolavail',$woolavail);
		$clothavail = e_rand(1,24);
		set_module_pref('clothavail',$clothavail);
		$leatheravail = e_rand(1,24);
		set_module_pref('leatheravail',$leatheravail);
		if ($town <> get_module_pref('shop')) set_module_pref('shop',$town);
	}
}
//cancelled buy or sell navigation
if ($op=="trade" or (get_module_pref('shop')==$town and $op=="")){
	set_module_pref('shop',$town);
	if (get_module_pref('dailytrades') > 0){
		if ($op=="") output("`5There's a pretty Teenage girl behind the counter, she says \"`6May I help you?`5\"`n");
		if ($op=="trade") output("`5The teenage girl says \"`6Is there anything else I can do for you?`5\"`n");
		$foxgold=get_module_pref('foxprice');
		$fishgold=get_module_pref('fishprice');
		$wormsgold=get_module_pref('wormsprice');
		$batgold=get_module_pref('batprice');
		$newtgold=get_module_pref('newtprice');
		$doggold=get_module_pref('dogprice');
		$froggold=get_module_pref('frogprice');
		$wortgold=get_module_pref('wortprice');
		$headsgold=get_module_pref('headsprice');
		$woolgem=get_module_pref('woolprice');
		$clothgem=get_module_pref('clothprice');
		$leathergem=get_module_pref('leatherprice');
		if (get_module_pref('foxavail') > 1) addnav(array("`!Fox Pelts `^(%s gold)",$foxgold),"runmodule.php?module=trading&op=fox");
		if (get_module_pref('fishavail') > 3) addnav(array("`!Fish Eyes `^(%s gold)",$fishgold),"runmodule.php?module=trading&op=fish");
		if (get_module_pref('wormsavail') > 5) addnav(array("`!Worms `^(%s gold)",$wormsgold),"runmodule.php?module=trading&op=worms");
		if (get_module_pref('batavail') > 8) addnav(array("`!Bat Wings `^(%s gold)",$batgold),"runmodule.php?module=trading&op=bat");
		if (get_module_pref('newtavail') > 10) addnav(array("`!Eye of Newt `^(%s gold)",$newtgold),"runmodule.php?module=trading&op=newt");
		if (get_module_pref('dogavail') > 12) addnav(array("`!Puppy Dog Tails `^(%s gold)",$doggold),"runmodule.php?module=trading&op=dog");
		if (get_module_pref('frogavail') > 14) addnav(array("`!Frog Legs `^(%s gold)",$froggold),"runmodule.php?module=trading&op=frog");
		if (get_module_pref('wortavail') > 15) addnav(array("`!Wort `^(%s gold)",$wortgold),"runmodule.php?module=trading&op=wort");
		if (get_module_pref('wortavail') > 16) addnav(array("`!Shrunken Heads `^(%s gold)",$headsgold),"runmodule.php?module=trading&op=heads");
		if (get_module_pref('woolavail') > 17) addnav(array("`!Wool `5(%s gems)",$woolgem),"runmodule.php?module=trading&op=wool");
		if (get_module_pref('clothavail') > 19) addnav(array("`!Cloth `5(%s gems)",$clothgem),"runmodule.php?module=trading&op=cloth");
		if (get_module_pref('leatheravail') > 21) addnav(array("`!Leather `5(%s gems)",$leathergem),"runmodule.php?module=trading&op=leather");
	}else{
		output("`4You Cannot Trade anymore today.`n");
	}
	villagenav();
}

//buy or sell
if ($op=="fox"){
	$foxgold=get_module_pref('foxprice');
	output("`3Fox Pelts are going for %s gold, would you like to buy or sell?`n",$foxgold);
	addnav("Fox Pelts");
	addnav("`2Buy","runmodule.php?module=trading&op=foxbuy");
	addnav("`4Sell","runmodule.php?module=trading&op=foxsell");
	addnav("`!Trade Something Else","runmodule.php?module=trading&op=trade");
	villagenav();
}
if ($op=="fish"){
	$fishgold=get_module_pref('fishprice');
	output("`3Fish Eyes are going for %s gold, would you like to buy or sell?`n",$fishgold);
	addnav("Fish Eyes");
	addnav("`2Buy","runmodule.php?module=trading&op=fishbuy");
	addnav("`4Sell","runmodule.php?module=trading&op=fishsell");
	addnav("`!Trade Something Else","runmodule.php?module=trading&op=trade");
	villagenav();
}
if ($op=="worms"){
	$wormsgold=get_module_pref('wormsprice');
	output("`3Worms are going for %s gold, would you like to buy or sell?`n",$wormsgold);
	addnav("Worms");
	addnav("`2Buy","runmodule.php?module=trading&op=wormsbuy");
	addnav("`4Sell","runmodule.php?module=trading&op=wormssell");
	addnav("`!Trade Something Else","runmodule.php?module=trading&op=trade");
	villagenav();
}
if ($op=="bat"){
	$batgold=get_module_pref('batprice');
	output("`3Bat Wings are going for %s gold, would you like to buy or sell?`n",$batgold);
	addnav("Bat Wings");
	addnav("`2Buy","runmodule.php?module=trading&op=batbuy");
	addnav("`4Sell","runmodule.php?module=trading&op=batsell");
	addnav("`!Trade Something Else","runmodule.php?module=trading&op=trade");
	villagenav();
}
if ($op=="newt"){
	$newtgold=get_module_pref('newtprice');
	output("`3Eye of Newt is going for %s gold, would you like to buy or sell?`n",$newtgold);
	addnav("Eye of Newt");
	addnav("`2Buy","runmodule.php?module=trading&op=newtbuy");
	addnav("`4Sell","runmodule.php?module=trading&op=newtsell");
	addnav("`!Trade Something Else","runmodule.php?module=trading&op=trade");
	villagenav();
}
if ($op=="dog"){
	$doggold=get_module_pref('dogprice');
	output("`3Puppy Dog Tails are going for %s gold, would you like to buy or sell?`n",$doggold);
	addnav("Puppy Dog Tails");
	addnav("`2Buy","runmodule.php?module=trading&op=dogbuy");
	addnav("`4Sell","runmodule.php?module=trading&op=dogsell");
	addnav("`!Trade Something Else","runmodule.php?module=trading&op=trade");
	villagenav();
}
if ($op=="frog"){
	$froggold=get_module_pref('frogprice');
	output("`3Frog Legs are going for %s gold, would you like to buy or sell?`n",$froggold);
	addnav("Frog Legs");
	addnav("`2Buy","runmodule.php?module=trading&op=frogbuy");
	addnav("`4Sell","runmodule.php?module=trading&op=frogsell");
	addnav("`!Trade Something Else","runmodule.php?module=trading&op=trade");
	villagenav();
}
if ($op=="wort"){
	$wortgold=get_module_pref('wortprice');
	output("`3Wort is going for %s gold, would you like to buy or sell?`n",$wortgold);
	addnav("Wort");
	addnav("`2Buy","runmodule.php?module=trading&op=wortbuy");
	addnav("`4Sell","runmodule.php?module=trading&op=wortsell");
	addnav("`!Trade Something Else","runmodule.php?module=trading&op=trade");
	villagenav();
}
if ($op=="heads"){
	$headsgold=get_module_pref('headsprice');
	output("`3Shrunken Heads are going for %s gold, would you like to buy or sell?`n",$headsgold);
	addnav("Shrunken Heads");
	addnav("`2Buy","runmodule.php?module=trading&op=headsbuy");
	addnav("`4Sell","runmodule.php?module=trading&op=headssell");
	addnav("`!Trade Something Else","runmodule.php?module=trading&op=trade");
	villagenav();
}
if ($op=="wool"){
	$woolgem=get_module_pref('woolprice');
	output("`3Wool is going for %s gems, would you like to buy or sell?`n",$woolgem);
	addnav("Wool");
	addnav("`2Buy","runmodule.php?module=trading&op=woolbuy");
	addnav("`4Sell","runmodule.php?module=trading&op=woolsell");
	addnav("`!Trade Something Else","runmodule.php?module=trading&op=trade");
	villagenav();
    }
if ($op=="cloth"){
	$clothgem=get_module_pref('clothprice');
	output("`3Cloth is going for %s gems, would you like to buy or sell?`n",$clothgem);
	addnav("Cloth");
	addnav("`2Buy","runmodule.php?module=trading&op=clothbuy");
	addnav("`4Sell","runmodule.php?module=trading&op=clothsell");
	addnav("`!Trade Something Else","runmodule.php?module=trading&op=trade");
	villagenav();
}
if ($op=="leather"){
	$leathergem=get_module_pref('leatherprice');
	output("`3Leather is going for %s gems, would you like to buy or sell?`n",$leathergem);
	addnav("Leather");
	addnav("`2Buy","runmodule.php?module=trading&op=leatherbuy");
	addnav("`4Sell","runmodule.php?module=trading&op=leathersell");
	addnav("`!Trade Something Else","runmodule.php?module=trading&op=trade");
	villagenav();
}
    
//buy products
if ($op=="buy3"){
	output_notl(get_module_pref('message'));
	addnav("`!Trade Something Else","runmodule.php?module=trading&op=trade");
	villagenav(); 
}
if ($op=="foxbuy"){
	if ($inventory>49){
		output("`!You cannot carry any more in your pack.  You need to sell something first.`n");
	}else{
		output("`%How many Fox Pelts would you like to buy?`n"); 
	    $linkcode="<form action='runmodule.php?module=trading&op=foxbuy2' method='POST'><input name='buy' id='buy'><input type='submit' class='button' value='buy'></form>";
		output("%s",$linkcode,true);
	    $linkcode="<script language='JavaScript'>document.getElementById('bet').focus();</script>";
		output("%s",$linkcode,true);
	    addnav("","runmodule.php?module=trading&op=foxbuy2");
    }
    addnav("`!Trade Something Else","runmodule.php?module=trading&op=trade");
	villagenav(); 
}
if ($op=="foxbuy2"){
	if ($buy > (50 - $inventory)) $buy = (50 - $inventory);
	if ($buy < 0) $buy = 0;
	if ($session['user']['gold'] < ($buy * get_module_pref('foxprice'))){
		set_module_pref('message',"You can't afford that!");
	}else{
		set_module_pref('message',"`!The man takes your money and hands you $buy Fox Pelts.");
		$cost=($buy * get_module_pref('foxprice'));
		$session['user']['gold']-=$cost;
		set_module_pref('fox', (get_module_pref('fox') + $buy));
		set_module_pref('dailytrades', (get_module_pref('dailytrades') - 1));
	}
	redirect("runmodule.php?module=trading&op=buy3");
}
if ($op=="fishbuy"){
	if ($inventory>49){
		output("`!You cannot carry any more in your pack.  You need to sell something first.`n");
	}else{
		output("`%How many Fish Eyes would you like to buy?`n"); 
	    $linkcode="<form action='runmodule.php?module=trading&op=fishbuy2' method='POST'><input name='buy' id='buy'><input type='submit' class='button' value='buy'></form>";
		output("%s",$linkcode,true);
	    $linkcode="<script language='JavaScript'>document.getElementById('bet').focus();</script>";
		output("%s",$linkcode,true);
	    addnav("","runmodule.php?module=trading&op=fishbuy2");
    }
    addnav("`!Trade Something Else","runmodule.php?module=trading&op=trade");
	villagenav(); 
}
if ($op=="fishbuy2"){
	if ($buy > (50 - $inventory)) $buy = (50 - $inventory);
	if ($buy < 0) $buy = 0;
	if ($session['user']['gold'] < ($buy * get_module_pref('fishprice'))){
		set_module_pref('message',"You can't afford that!");
	}else{
		set_module_pref('message',"`!The man takes your money and hands you $buy Fish Eyes.");
		$cost=($buy * get_module_pref('fishprice'));
		$session['user']['gold']-=$cost;
		set_module_pref('fish', (get_module_pref('fish') + $buy));
		set_module_pref('dailytrades', (get_module_pref('dailytrades') - 1));
	}
	redirect("runmodule.php?module=trading&op=buy3");
}
if ($op=="wormsbuy"){
	if ($inventory>49){
		output("`!You cannot carry any more in your pack.  You need to sell something first.`n");
	}else{
		output("`%How many Worms would you like to buy?`n"); 
	    $linkcode="<form action='runmodule.php?module=trading&op=wormsbuy2' method='POST'><input name='buy' id='buy'><input type='submit' class='button' value='buy'></form>";
		output("%s",$linkcode,true);
	    $linkcode="<script language='JavaScript'>document.getElementById('bet').focus();</script>";
		output("%s",$linkcode,true);
	    addnav("","runmodule.php?module=trading&op=wormsbuy2");
    }
    addnav("`!Trade Something Else","runmodule.php?module=trading&op=trade");
	villagenav(); 
}
if ($op=="wormsbuy2"){
	if ($buy > (50 - $inventory)) $buy = (50 - $inventory);
	if ($buy < 0) $buy = 0;
	if ($session['user']['gold'] < ($buy * get_module_pref('wormsprice'))){
		set_module_pref('message',"You can't afford that!");
	}else{
		set_module_pref('message',"`!The man takes your money and hands you $buy Worms.");
		$cost=($buy * get_module_pref('wormsprice'));
		$session['user']['gold']-=$cost;
		set_module_pref('worms', (get_module_pref('worms') + $buy));
		set_module_pref('dailytrades', (get_module_pref('dailytrades') - 1));
	}
	redirect("runmodule.php?module=trading&op=buy3");
}
if ($op=="batbuy"){
	if ($inventory>49){
		output("`!You cannot carry any more in your pack.  You need to sell something first.`n");
	}else{
		output("`%How many Bat Wings would you like to buy?`n"); 
	    $linkcode="<form action='runmodule.php?module=trading&op=batbuy2' method='POST'><input name='buy' id='buy'><input type='submit' class='button' value='buy'></form>";
		output("%s",$linkcode,true);
	    $linkcode="<script language='JavaScript'>document.getElementById('bet').focus();</script>";
		output("%s",$linkcode,true);
	    addnav("","runmodule.php?module=trading&op=batbuy2");
    }
    addnav("`!Trade Something Else","runmodule.php?module=trading&op=trade");
	villagenav(); 
}
if ($op=="batbuy2"){
	if ($buy > (50 - $inventory)) $buy = (50 - $inventory);
	if ($buy < 0) $buy = 0;
	if ($session['user']['gold'] < ($buy * get_module_pref('batprice'))){
		set_module_pref('message',"You can't afford that!");
	}else{
		set_module_pref('message',"`!The man takes your money and hands you $buy Bat Wings.");
		$cost=($buy * get_module_pref('batprice'));
		$session['user']['gold']-=$cost;
		set_module_pref('bat', (get_module_pref('bat') + $buy));
		set_module_pref('dailytrades', (get_module_pref('dailytrades') - 1));
	}
	redirect("runmodule.php?module=trading&op=buy3");
}
if ($op=="newtbuy"){
	if ($inventory>49){
		output("`!You cannot carry any more in your pack.  You need to sell something first.`n");
	}else{
		output("`%How many Eye of Newt would you like to buy?`n"); 
	    $linkcode="<form action='runmodule.php?module=trading&op=newtbuy2' method='POST'><input name='buy' id='buy'><input type='submit' class='button' value='buy'></form>";
		output("%s",$linkcode,true);
	    $linkcode="<script language='JavaScript'>document.getElementById('bet').focus();</script>";
		output("%s",$linkcode,true);
	    addnav("","runmodule.php?module=trading&op=newtbuy2");
    }
    addnav("`!Trade Something Else","runmodule.php?module=trading&op=trade");
	villagenav(); 
}
if ($op=="newtbuy2"){
	if ($buy > (50 - $inventory)) $buy = (50 - $inventory);
	if ($buy < 0) $buy = 0;
	if ($session['user']['gold'] < ($buy * get_module_pref('newtprice'))){
		set_module_pref('message',"You can't afford that!");
	}else{
		set_module_pref('message',"`!The man takes your money and hands you $buy Eye of Newt.");
		$cost=($buy * get_module_pref('newtprice'));
		$session['user']['gold']-=$cost;
		set_module_pref('newt', (get_module_pref('newt') + $buy));
		set_module_pref('dailytrades', (get_module_pref('dailytrades') - 1));
	}
	redirect("runmodule.php?module=trading&op=buy3");
}
if ($op=="dogbuy"){
	if ($inventory>49){
		output("`!You cannot carry any more in your pack.  You need to sell something first.`n");
	}else{
		output("`%How many Puppy Dog Tails would you like to buy?`n"); 
	    $linkcode="<form action='runmodule.php?module=trading&op=dogbuy2' method='POST'><input name='buy' id='buy'><input type='submit' class='button' value='buy'></form>";
		output("%s",$linkcode,true);
	    $linkcode="<script language='JavaScript'>document.getElementById('bet').focus();</script>";
		output("%s",$linkcode,true);
	    addnav("","runmodule.php?module=trading&op=dogbuy2");
    }
    addnav("`!Trade Something Else","runmodule.php?module=trading&op=trade");
	villagenav(); 
}
if ($op=="dogbuy2"){
	if ($buy > (50 - $inventory)) $buy = (50 - $inventory);
	if ($buy < 0) $buy = 0;
	if ($session['user']['gold'] < ($buy * get_module_pref('dogprice'))){
		set_module_pref('message',"You can't afford that!");
	}else{
		set_module_pref('message',"`!The man takes your money and hands you $buy Puppy Dog Tails.");
		$cost=($buy * get_module_pref('dogprice'));
		$session['user']['gold']-=$cost;
		set_module_pref('dog', (get_module_pref('dog') + $buy));
		set_module_pref('dailytrades', (get_module_pref('dailytrades') - 1));
	}
	redirect("runmodule.php?module=trading&op=buy3");
}
if ($op=="frogbuy"){
	if ($inventory>49){
		output("`!You cannot carry any more in your pack.  You need to sell something first.`n");
	}else{
		output("`%How many Frog Legs would you like to buy?`n"); 
	    $linkcode="<form action='runmodule.php?module=trading&op=frogbuy2' method='POST'><input name='buy' id='buy'><input type='submit' class='button' value='buy'></form>";
		output("%s",$linkcode,true);
	    $linkcode="<script language='JavaScript'>document.getElementById('bet').focus();</script>";
		output("%s",$linkcode,true);
	    addnav("","runmodule.php?module=trading&op=frogbuy2");
    }
    addnav("`!Trade Something Else","runmodule.php?module=trading&op=trade");
	villagenav(); 
}
if ($op=="frogbuy2"){
	if ($buy > (50 - $inventory)) $buy = (50 - $inventory);
	if ($buy < 0) $buy = 0;
	if ($session['user']['gold'] < ($buy * get_module_pref('frogprice'))){
		set_module_pref('message',"You can't afford that!");
	}else{
		set_module_pref('message',"`!The man takes your money and hands you $buy Frog Legs.");
		$cost=($buy * get_module_pref('frogprice'));
		$session['user']['gold']-=$cost;
		set_module_pref('frog', (get_module_pref('frog') + $buy));
		set_module_pref('dailytrades', (get_module_pref('dailytrades') - 1));
	}
	redirect("runmodule.php?module=trading&op=buy3");
}
if ($op=="headsbuy"){
	if ($inventory>49){
		output("`!You cannot carry any more in your pack.  You need to sell something first.`n");
	}else{
		output("`%How many Shrunken Heads would you like to buy?`n"); 
	    $linkcode="<form action='runmodule.php?module=trading&op=headsbuy2' method='POST'><input name='buy' id='buy'><input type='submit' class='button' value='buy'></form>";
		output("%s",$linkcode,true);
	    $linkcode="<script language='JavaScript'>document.getElementById('bet').focus();</script>";
		output("%s",$linkcode,true);
	    addnav("","runmodule.php?module=trading&op=headsbuy2");
    }
    addnav("`!Trade Something Else","runmodule.php?module=trading&op=trade");
	villagenav(); 
}
if ($op=="headsbuy2"){
	if ($buy > (50 - $inventory)) $buy = (50 - $inventory);
	if ($buy < 0) $buy = 0;
	if ($session['user']['gold'] < ($buy * get_module_pref('headsprice'))){
		set_module_pref('message',"You can't afford that!");
	}else{
		set_module_pref('message',"`!The man takes your money and hands you $buy Shrunken Heads.");
		$cost=($buy * get_module_pref('headsprice'));
		$session['user']['gold']-=$cost;
		set_module_pref('heads', (get_module_pref('heads') + $buy));
		set_module_pref('dailytrades', (get_module_pref('dailytrades') - 1));
	}
	redirect("runmodule.php?module=trading&op=buy3");
}
if ($op=="wortbuy"){
	if ($inventory>49){
		output("`!You cannot carry any more in your pack.  You need to sell something first.`n");
	}else{
		output("`%How many Wort would you like to buy?`n"); 
	    $linkcode="<form action='runmodule.php?module=trading&op=wortbuy2' method='POST'><input name='buy' id='buy'><input type='submit' class='button' value='buy'></form>";
		output("%s",$linkcode,true);
	    $linkcode="<script language='JavaScript'>document.getElementById('bet').focus();</script>";
		output("%s",$linkcode,true);
	    addnav("","runmodule.php?module=trading&op=wortbuy2");
    }
    addnav("`!Trade Something Else","runmodule.php?module=trading&op=trade");
	villagenav(); 
}
if ($op=="wortbuy2"){
	if ($buy > (50 - $inventory)) $buy = (50 - $inventory);
	if ($buy < 0) $buy = 0;
	if ($session['user']['gold'] < ($buy * get_module_pref('wortprice'))){
		set_module_pref('message',"You can't afford that!");
	}else{
		set_module_pref('message',"`!The man takes your money and hands you $buy Wort.");
		$cost=($buy * get_module_pref('wortprice'));
		$session['user']['gold']-=$cost;
		set_module_pref('wort', (get_module_pref('wort') + $buy));
		set_module_pref('dailytrades', (get_module_pref('dailytrades') - 1));
	}
	redirect("runmodule.php?module=trading&op=buy3");
}
if ($op=="woolbuy"){
	if ($inventory>49){
		output("`!You cannot carry any more in your pack.  You need to sell something first.`n");
	}else{
		output("`%How many Wool would you like to buy?`n"); 
	    $linkcode="<form action='runmodule.php?module=trading&op=woolbuy2' method='POST'><input name='buy' id='buy'><input type='submit' class='button' value='buy'></form>";
		output("%s",$linkcode,true);
	    $linkcode="<script language='JavaScript'>document.getElementById('bet').focus();</script>";
		output("%s",$linkcode,true);
	    addnav("","runmodule.php?module=trading&op=woolbuy2");
    }
    addnav("`!Trade Something Else","runmodule.php?module=trading&op=trade");
	villagenav(); 
}
if ($op=="woolbuy2"){
	if ($buy > (50 - $inventory)) $buy = (50 - $inventory);
	if ($buy < 0) $buy = 0;
	if ($session['user']['gems'] < ($buy * get_module_pref('woolprice'))){
		set_module_pref('message',"You can't afford that!");
	}else{
		set_module_pref('message',"`!The man takes your money and hands you $buy Wool.");
		$cost=($buy * get_module_pref('woolprice'));
		$session['user']['gems']-=$cost;
		set_module_pref('wool', (get_module_pref('wool') + $buy));
		set_module_pref('dailytrades', (get_module_pref('dailytrades') - 1));
	}
	redirect("runmodule.php?module=trading&op=buy3");
}
if ($op=="clothbuy"){
	if ($inventory>49){
		output("`!You cannot carry any more in your pack.  You need to sell something first.`n");
	}else{
		output("`%How many Cloth would you like to buy?`n"); 
	    $linkcode="<form action='runmodule.php?module=trading&op=clothbuy2' method='POST'><input name='buy' id='buy'><input type='submit' class='button' value='buy'></form>";
		output("%s",$linkcode,true);
	    $linkcode="<script language='JavaScript'>document.getElementById('bet').focus();</script>";
		output("%s",$linkcode,true);
	    addnav("","runmodule.php?module=trading&op=clothbuy2");
    }
    addnav("`!Trade Something Else","runmodule.php?module=trading&op=trade");
	villagenav(); 
}
if ($op=="clothbuy2"){
	if ($buy > (50 - $inventory)) $buy = (50 - $inventory);
	if ($buy < 0) $buy = 0;
	if ($session['user']['gems'] < ($buy * get_module_pref('clothprice'))){
		set_module_pref('message',"You can't afford that!");
	}else{
		set_module_pref('message',"`!The man takes your money and hands you $buy Cloth.");
		$cost=($buy * get_module_pref('clothprice'));
		$session['user']['gems']-=$cost;
		set_module_pref('cloth', (get_module_pref('cloth') + $buy));
		set_module_pref('dailytrades', (get_module_pref('dailytrades') - 1));
	}
	redirect("runmodule.php?module=trading&op=buy3");
}
if ($op=="leatherbuy"){
	if ($inventory>49){
		output("`!You cannot carry any more in your pack.  You need to sell something first.`n");
	}else{
		output("`%How many Leather would you like to buy?`n"); 
	    $linkcode="<form action='runmodule.php?module=trading&op=leatherbuy2' method='POST'><input name='buy' id='buy'><input type='submit' class='button' value='buy'></form>";
		output("%s",$linkcode,true);
	    $linkcode="<script language='JavaScript'>document.getElementById('bet').focus();</script>";
		output("%s",$linkcode,true);
	    addnav("","runmodule.php?module=trading&op=leatherbuy2");
    }
    addnav("`!Trade Something Else","runmodule.php?module=trading&op=trade");
	villagenav(); 
}
if ($op=="leatherbuy2"){
	if ($buy > (50 - $inventory)) $buy = (50 - $inventory);
	if ($buy < 0) $buy = 0;
	if ($session['user']['gems'] < ($buy * get_module_pref('leatherprice'))){
		set_module_pref('message',"You can't afford that!");
	}else{
		set_module_pref('message',"`!The man takes your money and hands you $buy Leather.");
		$cost=($buy * get_module_pref('leatherprice'));
		$session['user']['gems']-=$cost;
		set_module_pref('leather', (get_module_pref('leather') + $buy));
		set_module_pref('dailytrades', (get_module_pref('dailytrades') - 1));
	}
	redirect("runmodule.php?module=trading&op=buy3");
}
    
//sell
if ($op=="sell3"){
	output_notl(get_module_pref('message'));
	addnav("`!Trade Something Else","runmodule.php?module=trading&op=trade");
	villagenav(); 
}
if ($op=="foxsell"){
	if (get_module_pref('fox')<1){
		output("`!You don't have any Fox Pelts to sell.`n");
	}else{
		output("You have $fox fox to sell.`n");
	    output("`%How many Fox Pelts would you like to sell?`n"); 
	    $linkcode="<form action='runmodule.php?module=trading&op=foxsell2' method='POST'><input name='sell' id='sell'><input type='submit' class='button' value='sell'></form>";
	    output("%s",$linkcode,true);
	    $linkcode="<script language='JavaScript'>document.getElementById('bet').focus();</script>";
	    output("%s",$linkcode,true);
	    addnav("","runmodule.php?module=trading&op=foxsell2");
    }
    addnav("`!Trade Something Else","runmodule.php?module=trading&op=trade");
	villagenav(); 
}
if ($op=="foxsell2"){
	if (get_module_pref('fox') < $sell){
		output("`%You don't have that many!`n");
	}else{
		$cost=($sell * get_module_pref('foxprice'));
		set_module_pref('message',"`!The man takes your $sell fox and hands you $cost gold.`n");
		$session['user']['gold']+=$cost;
		set_module_pref('fox', (get_module_pref('fox') - $sell));
		set_module_pref('dailytrades', (get_module_pref('dailytrades') - 1));
	}
	redirect("runmodule.php?module=trading&op=sell3");
}
if ($op=="fishsell"){
	if (get_module_pref('fish')<1){
		output("`!You don't have any Fish Eyes to sell.`n");
	}else{
		output("You have $fish Fish Eyes to sell.`n");
		output("`%How many Fish Eyes would you like to sell?`n"); 
	    $linkcode="<form action='runmodule.php?module=trading&op=fishsell2' method='POST'><input name='sell' id='sell'><input type='submit' class='button' value='sell'></form>";
		output("%s",$linkcode,true); 
	    $linkcode="<script language='JavaScript'>document.getElementById('bet').focus();</script>";
		output("%s",$linkcode,true);
	    addnav("","runmodule.php?module=trading&op=fishsell2");
    }
    addnav("`!Trade Something Else","runmodule.php?module=trading&op=trade");
	villagenav(); 
}
if ($op=="fishsell2"){
	if (get_module_pref('fish') < $sell){
		output("`%You don't have that many!`n");
	}else{
		$cost=($sell * get_module_pref('fishprice'));
		set_module_pref('message',"`!The man takes your $sell Fish Eyes and hands you $cost gold.`n");
		$session['user']['gold']+=$cost;
		set_module_pref('fish', (get_module_pref('fish') - $sell));
		set_module_pref('dailytrades', (get_module_pref('dailytrades') - 1));
	}
	redirect("runmodule.php?module=trading&op=sell3");
}
if ($op=="wormssell"){
	if (get_module_pref('worms')<1){
		output("`!You don't have any worms to sell.`n");
	}else{
		output("You have $worms worms to sell.`n");
		output("`%How many Worms would you like to sell?`n"); 
	    $linkcode="<form action='runmodule.php?module=trading&op=wormssell2' method='POST'><input name='sell' id='sell'><input type='submit' class='button' value='sell'></form>";
		output("%s",$linkcode,true);
	    $linkcode="<script language='JavaScript'>document.getElementById('bet').focus();</script>";
		output("%s",$linkcode,true);
	    addnav("","runmodule.php?module=trading&op=wormssell2");
    }
    addnav("`!Trade Something Else","runmodule.php?module=trading&op=trade");
	villagenav(); 
}
if ($op=="wormssell2"){
	if (get_module_pref('worms') < $sell){
		output("`%You don't have that many!`n");
	}else{
		$cost=($sell * get_module_pref('wormsprice'));
		set_module_pref('message',"`!The man takes your $sell Worms and hands you $cost gold.`n");
		$session['user']['gold']+=$cost;
		set_module_pref('worms', (get_module_pref('worms') - $sell));
		set_module_pref('dailytrades', (get_module_pref('dailytrades') - 1));
	}
	redirect("runmodule.php?module=trading&op=sell3");
}
if ($op=="batsell"){
	if (get_module_pref('bat')<1){
		output("`!You don't have any Bat Wings to sell.`n");
	}else{
		output("You have $bat Bat Wings to sell.`n");
		output("`%How many Bat Wings would you like to sell?`n"); 
	    $linkcode="<form action='runmodule.php?module=trading&op=batsell2' method='POST'><input name='sell' id='sell'><input type='submit' class='button' value='sell'></form>";
		output("%s",$linkcode,true);
	    $linkcode="<script language='JavaScript'>document.getElementById('bet').focus();</script>";
		output("%s",$linkcode,true);
	    addnav("","runmodule.php?module=trading&op=batsell2");
    }
    addnav("`!Trade Something Else","runmodule.php?module=trading&op=trade");
	villagenav(); 
}
if ($op=="batsell2"){
	if (get_module_pref('bat') < $sell){
		output("`%You don't have that many!`n");
	}else{
		$cost=($sell * get_module_pref('batprice'));
		set_module_pref('message',"`!The man takes your $sell Bat Wings and hands you $cost gold.`n");
		$session['user']['gold']+=$cost;
		set_module_pref('bat', (get_module_pref('bat') - $sell));
		set_module_pref('dailytrades', (get_module_pref('dailytrades') - 1));
	}
	redirect("runmodule.php?module=trading&op=sell3"); 
}
if ($op=="newtsell"){
	if (get_module_pref('newt')<1){
		output("`!You don't have any Eye of Newt to sell.`n");
	}else{
		output("You have $newt Eye of Newt to sell.`n");
		output("`%How many Eye of Newt would you like to sell?`n"); 
	    $linkcode="<form action='runmodule.php?module=trading&op=newtsell2' method='POST'><input name='sell' id='sell'><input type='submit' class='button' value='sell'></form>";
		output("%s",$linkcode,true);
	    $linkcode="<script language='JavaScript'>document.getElementById('bet').focus();</script>";
		output("%s",$linkcode,true);
	    addnav("","runmodule.php?module=trading&op=newtsell2");
    }
    addnav("`!Trade Something Else","runmodule.php?module=trading&op=trade");
	villagenav(); 
}
if ($op=="newtsell2"){
	if (get_module_pref('newt') < $sell){
		output("`%You don't have that many!`n");
	}else{
		$cost=($sell * get_module_pref('newtprice'));
		set_module_pref('message',"`!The man takes your $sell Eye of Newt and hands you $cost gold.`n");
		$session['user']['gold']+=$cost;
		set_module_pref('newt', (get_module_pref('newt') - $sell));
		set_module_pref('dailytrades', (get_module_pref('dailytrades') - 1));
	}
	redirect("runmodule.php?module=trading&op=sell3");
}
if ($op=="dogsell"){
	if (get_module_pref('dog')<1){
		output("`!You don't have any Puppy Dog Tails to sell.`n");
	}else{
		output("You have $dog Puppy Dog Tails to sell.`n");
		output("`%How many Puppy Dog Tails would you like to sell?`n"); 
	    $linkcode="<form action='runmodule.php?module=trading&op=dogsell2' method='POST'><input name='sell' id='sell'><input type='submit' class='button' value='sell'></form>";
		output("%s",$linkcode,true);
	    $linkcode="<script language='JavaScript'>document.getElementById('bet').focus();</script>";
		output("%s",$linkcode,true);
	    addnav("","runmodule.php?module=trading&op=dogsell2");
    }
    addnav("`!Trade Something Else","runmodule.php?module=trading&op=trade");
	villagenav(); 
}
if ($op=="dogsell2"){
	if (get_module_pref('dog') < $sell){
		output("`%You don't have that many!`n");
	}else{
		$cost=($sell * get_module_pref('dogprice'));
		set_module_pref('message',"`!The man takes your $dog Puppy Dog Tails and hands you $cost gold.`n");
		$session['user']['gold']+=$cost;
		set_module_pref('dog', (get_module_pref('dog') - $sell));
		set_module_pref('dailytrades', (get_module_pref('dailytrades') - 1));
	}
	redirect("runmodule.php?module=trading&op=sell3");
}
if ($op=="frogsell"){
	if (get_module_pref('frog')<1){
		output("`!You don't have any Frog Legs to sell.`n");
	}else{
		output("You have $frog Frog Legs to sell.`n");
		output("`%How many Frog Legs would you like to sell?`n"); 
	    $linkcode="<form action='runmodule.php?module=trading&op=frogsell2' method='POST'><input name='sell' id='sell'><input type='submit' class='button' value='sell'></form>";
		output("%s",$linkcode,true);
	    $linkcode="<script language='JavaScript'>document.getElementById('bet').focus();</script>";
		output("%s",$linkcode,true);
	    addnav("","runmodule.php?module=trading&op=frogsell2");
    }
    addnav("`!Trade Something Else","runmodule.php?module=trading&op=trade");
	villagenav(); 
}
if ($op=="frogsell2"){
	if (get_module_pref('frog') < $sell){
		output("`%You don't have that many!`n");
	}else{
		$cost=($sell * get_module_pref('frogprice'));
		set_module_pref('message',"`!The man takes your $sell Frog Legs and hands you $cost gold.`n");
		$session['user']['gold']+=$cost;
		set_module_pref('frog', (get_module_pref('frog') - $sell));
		set_module_pref('dailytrades', (get_module_pref('dailytrades') - 1));
	}
	redirect("runmodule.php?module=trading&op=sell3");
}
if ($op=="headssell"){
	if (get_module_pref('heads')<1){
		output("`!You don't have any Shrunken Heads to sell.`n");
	}else{
		output("You have $heads Shrunken Heads to sell.`n");
		output("`%How many Shrunken Heads would you like to sell?`n"); 
	    $linkcode="<form action='runmodule.php?module=trading&op=headssell2' method='POST'><input name='sell' id='sell'><input type='submit' class='button' value='sell'></form>";
		output("%s",$linkcode,true);
	    $linkcode="<script language='JavaScript'>document.getElementById('bet').focus();</script>";
		output("%s",$linkcode,true);
	    addnav("","runmodule.php?module=trading&op=headssell2");
    }
    addnav("`!Trade Something Else","runmodule.php?module=trading&op=trade");
	villagenav(); 
}
if ($op=="headssell2"){
	if (get_module_pref('heads') < $sell){
		output("`%You don't have that many!`n");
	}else{
		$cost=($sell * get_module_pref('headsprice'));
		set_module_pref('message',"`!The man takes your $sell Shrunken Heads and hands you $cost gold.`n");
		$session['user']['gold']+=$cost;
		set_module_pref('heads', (get_module_pref('heads') - $sell));
		set_module_pref('dailytrades', (get_module_pref('dailytrades') - 1));
	}
	redirect("runmodule.php?module=trading&op=sell3");
}
if ($op=="wortsell"){
	if (get_module_pref('wort')<1){
		output("`!You don't have any Wort to sell.`n");
	}else{
		output("You have $wort Wort to sell.`n");
		output("`%How many Wort would you like to sell?`n"); 
	    $linkcode="<form action='runmodule.php?module=trading&op=wortsell2' method='POST'><input name='sell' id='sell'><input type='submit' class='button' value='sell'></form>";
		output("%s",$linkcode,true); 
	    $linkcode="<script language='JavaScript'>document.getElementById('bet').focus();</script>";
		output("%s",$linkcode,true);
	    addnav("","runmodule.php?module=trading&op=wortsell2");
    }
    addnav("`!Trade Something Else","runmodule.php?module=trading&op=trade");
	villagenav(); 
}
if ($op=="wortsell2"){
	if (get_module_pref('wort') < $sell){
		output("`%You don't have that many!`n");
	}else{
		$cost=($sell * get_module_pref('wortprice'));
		set_module_pref('message',"`!The man takes your $sell Wort and hands you $cost gold.`n");
		$session['user']['gold']+=$cost;
		set_module_pref('wort', (get_module_pref('wort') - $sell));
		set_module_pref('dailytrades', (get_module_pref('dailytrades') - 1));
	}
	redirect("runmodule.php?module=trading&op=sell3");
}
if ($op=="woolsell"){
	if (get_module_pref('wool')<1){
		output("`!You don't have any Wool to sell.`n");
	}else{
		output("You have $wool Wool to sell.`n");
		output("`%How many Wool would you like to sell?`n"); 
	    $linkcode="<form action='runmodule.php?module=trading&op=woolsell2' method='POST'><input name='sell' id='sell'><input type='submit' class='button' value='sell'></form>";
		output("%s",$linkcode,true);
	    $linkcode="<script language='JavaScript'>document.getElementById('bet').focus();</script>";
		output("%s",$linkcode,true);
	    addnav("","runmodule.php?module=trading&op=woolsell2");
    }
    addnav("`!Trade Something Else","runmodule.php?module=trading&op=trade");
	villagenav(); 
}
if ($op=="woolsell2"){
	if (get_module_pref('wool') < $sell){
		output("`%You don't have that many!`n");
	}else{
		$cost=($sell * get_module_pref('woolprice'));
		set_module_pref('message',"`!The man takes your $sell Wool and hands you $cost gems.`n");
		$session['user']['gems']+=$cost;
		set_module_pref('wool', (get_module_pref('wool') - $sell));
		set_module_pref('dailytrades', (get_module_pref('dailytrades') - 1));
	}
	redirect("runmodule.php?module=trading&op=sell3");
}
if ($op=="clothsell"){
	if (get_module_pref('cloth')<1){
		output("`!You don't have any Cloth to sell.`n");
	}else{
		output("You have $cloth Cloth to sell.`n");
		output("`%How many Cloth would you like to sell?`n"); 
	    $linkcode="<form action='runmodule.php?module=trading&op=clothsell2' method='POST'><input name='sell' id='sell'><input type='submit' class='button' value='sell'></form>";
		output("%s",$linkcode,true);
	    $linkcode="<script language='JavaScript'>document.getElementById('bet').focus();</script>";
		output("%s",$linkcode,true);
	    addnav("","runmodule.php?module=trading&op=clothsell2");
    }
    addnav("`!Trade Something Else","runmodule.php?module=trading&op=trade");
	villagenav(); 
}
if ($op=="clothsell2"){
	if (get_module_pref('cloth') < $sell){
		output("`%You don't have that many!`n");
	}else{
		$cost=($sell * get_module_pref('clothprice'));
		set_module_pref('message',"`!The man takes your $sell Cloth and hands you $cost gems.`n");
		$session['user']['gems']+=$cost;
		set_module_pref('cloth', (get_module_pref('cloth') - $sell));
		set_module_pref('dailytrades', (get_module_pref('dailytrades') - 1));
	}
	redirect("runmodule.php?module=trading&op=sell3");
}
if ($op=="leathersell"){
	if (get_module_pref('leather')<1){
		output("`!You don't have any Leather to sell.`n");
	}else{
		output("You have $leather Leather to sell.`n");
		output("`%How many Leather would you like to sell?`n"); 
	    $linkcode="<form action='runmodule.php?module=trading&op=leathersell2' method='POST'><input name='sell' id='sell'><input type='submit' class='button' value='sell'></form>";
		output("%s",$linkcode,true);
	    $linkcode="<script language='JavaScript'>document.getElementById('bet').focus();</script>";
		output("%s",$linkcode,true);
	    addnav("","runmodule.php?module=trading&op=leathersell2");
    }
    addnav("`!Trade Something Else","runmodule.php?module=trading&op=trade");
	villagenav(); 
}
if ($op=="leathersell2"){
	if (get_module_pref('leather') < $sell){
		output("`%You don't have that many!`n");
	}else{
		$cost=($sell * get_module_pref('leatherprice'));
		set_module_pref('message',"`!The man takes your $sell leather and hands you $cost gems.`n");
		$session['user']['gems']+=$cost;
		set_module_pref('leather', (get_module_pref('leather') - $sell));
		set_module_pref('dailytrades', (get_module_pref('dailytrades') - 1));
	}
	redirect("runmodule.php?module=trading&op=sell3");
} 
//I cannot make you keep this line here but would appreciate it left in.
rawoutput("<div style=\"text-align: left;\"><a href=\"http://www.pqcomp.com\" target=\"_blank\">Trading by Lonny @ http://www.pqcomp.com</a><br>"); 
page_footer();
?>