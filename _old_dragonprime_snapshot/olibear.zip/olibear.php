<?php

function olibear_getmoduleinfo()
{
 $info = array(
	"name"=>"Oli der Tanzb�r",
	"author"=>"`2Oliver Brendel",
	"version"=>"1.0",
	"category"=>"Forest Specials",
	"download"=>"http://dragonprime.net/dls/olibear.zip",
	"settings"=>array(
	"olibearmodul - Einstellungen, title",
	"loss"=>"Erfahrungsverlust bei olibears Behandlung in Prozent,range,1,20,1|3",
	"gold"=>"Gold pro Stufe als Basis,range,10,100,5|20",
	"olibearname"=>"Name von Oli (auch mit Farben m�glich),text|Oli",
	"leck"=>"Weggeleckte Erfahrung,viewonly",
	"Notiz: Sollte m�nnlich sein... ansonsten m�ssen per �bersetzungstool Texte evtl angepa�t werden,note",
  ),
  );
 return $info;
}
function olibear_install()
{
 module_addeventhook("forest", "return 100;");
 if (is_module_active("olibear")) output_notl("`c`bModul olibear geupdated`b`c`n`n");
 return true;
}
function olibear_uninstall()
{
 return true;
}
function olibear_dohook($hookname,$args)
{
return $args;
}
function olibear_runevent($type,$link)
{
 global $session,$value,$link,$olibear;
 $olibear=get_module_setting('olibearname');
 $link = "forest.php?";
 $session['user']['specialinc'] = "module:olibear";
 $op = httpget('op');
 $value=httpget('mode');
 switch ($op)
 {
	case "":
		output("`@ Aus gro�er Entfernung kommst Du an eine kleine Zirkusstadt... ja, unglaublich, da� es hier sowas gibt.");
		output(" Du trittst n�her und erkennst eine wild wuselnde und schimpfende Gestalt, und bei dem Zelt in der N�he steht: `^%s, der Tanzb�r`@.",$olibear);
		output("`nAls Du Dich n�her hinbewegst, bemerkst Du den Geruch leichter �le... es ist eine kleine Frau, die gerade wild in die Richtung schimpft, die vom Zelt verdeckt wird.");
		output_notl("`n`n");
		output("Was wirst du tun? ");
		output_notl("`n`n");
		addnav("N�hertreten",$link."op=comeclose");
		addnav("Weggehen+Grinsen",$link."op=walk");
	break;
	case "comeclose":
		output("`@Du gehst n�her darauf zu. `nNach einigen Schritten siehst Du, da� die kleine Madame in Richtung eines K�figs schimpft und protestiert.");
		output("`n`nEin `%gewaltiger`@ B�r sitzt dort auf seinem Hintern und scheint in der Nase zu bohren. Die Kette am Hals und die Fu�fesseln lassen eindeutig auf einen `^Tanzb�r`@ schlie�en.");
		output("`nDie Madame sagt: \"`q%s`q! Du Faulpelz! Los! `bSOFORT`b *springst,h�pfst,tanzt* `bDU`b!!!`@\"...",$olibear);
		output(" Aber %s`@ scheint keine gro�e Lust zu haben. Er bohrt in der Nase und schaut ein wenig zu Dir.",$olibear);
		output_notl("`n");
		output("`nNun wirst auch Du von der Madame bemerkt... und nach einem ziemlich b�se Blick leuchtet ihr Gesicht kugelrund auf.");
		output(" \"`qAaahh... Frischfl....�hm... Dringend ben�tigte Hilfe!... Mein lieber %s`q hier hat keine gro�e Lust derzeit... k�nntest Du ihn etwas animieren? Es soll Dein Schaden nicht sein!`@\" meint sie.",$olibear);
		output("`n`nHast Du Bock (Du verlierst dabei Zeit, die Du im Wald verk�mpfen k�nntest)?");
		addnav("Japp, hab ich.",$link."op=japp");
		addnav("Weggehen+Grinsen",$link."op=walk");
		break;
	case "japp":
		if ($session['user']['turns']<1) {
			output("`@Na, Du bist heute ja schon ausgenudelt... la� mal stecken und geh wieder ins Dorf.");
			output("`n`nDu kannst %s`@ weiter �rgern, wenn Du wieder munter bist.",$olibear);
			$session['user']['specialinc'] = "";			
			villagenav();
			break;
		}
		output("`@Gut... dann mal los, zeig `^%s`@ aus welchem Holz Du geschnitzt bist!",$olibear);
		output("`n`n");
		if (e_rand(1,2)==1) {
			output("Spontan versammeln sich viele Zuschauer!");
			$value=3;
		} else {
			output("Leider schaut kaum jemand zu Dir.");
			$value=1;
		}
		oli_nav();
		break;
	case "pieksen":
	$session['user']['turns']--;
	output("`@Du holst den Stock und piekst %s`@ ein bi�chen...",$olibear);
	output_notl("`n`n");
	$randomchance=e_rand(0,5);
	switch ($randomchance) {
		case 0:
			output("Aber leider hast Du Pech, und %s`@ bewegt sich kein St�ck.",$olibear);
			output("`nDie Leute sind entt�uscht.");
			output_notl("`n");
			$damage=e_rand(1,$session['user']['hitpoints']/13);
			if ($session['user']['hitpoints']-$damage>0) {
				output("Du kriegst eine Dose an den Kopf und erleidest %s Schaden!",$damage);
				$session['user']['hitpoints']-=$damage;
				}
			break;
			oli_nav();
		case 1:
			output("`kOh Nein! %s`k ist sauer, br�llt und tobt im K�fig!`n",$olibear);
			output("Du erschrickst total und f�llst hinten�ber!");
			output_notl("`n`n");
			output("Die Angst steckt Dir in den Knochen, w�hrend die Leute br�llen vor Lachen.");
			output("`n`nLeider hast Du heute daher keine Lust mehr, mit dem B�r zu spielen.");
			oli_addgold($value);
			addnews("%s`p hat sich im Wald bei Tanzb�r %s`p `\$fast in die Hose gemacht`p!!!",$session['user']['name'],$olibear);
			apply_buff('olibearspam',
				array(
				"name"=>"`)$olibear's Gebr�ll", //no, this is not tl-ready... but in 1.0.7 you can change this to "name"=>array("`)%s`0's Gejammer",$olibear), and it's ok
				"rounds"=>30,
				"wearoff"=>"Du kannst wieder normal atmen.",
				"atkmod"=>0.8,
				"defmod"=>0.8,
				"minioncount"=>1,
				"roundmsg"=>"$olibear's Gebr�ll bimmelt in Deinen Ohren!",
				"schema"=>"module-olibear",
				));
			break;
			villagenav();
			$session['user']['specialinc'] = "";
		case 2:
			output("`@Nach einer Weile hast du Erbarmen und gehst von dannen. Die Leute zeigen Mitleid und geben Dir noch etwas Geld mit auf den Weg.");
			oli_addgold($value);
			output_notl("`n`n");
			$loss=e_rand(0,$session['user']['turns']/2);
			if ($session['user']['turns']>0) {
				output("Du verlierst Zeit f�r %s Waldk�mpfe!",$loss);
				$session['user']['turns']-=$loss;
				}
			oli_nav();
			break;
		case 3:
			output("`k%s`k kreischt vergn�gt und hat tierisch Spa� daran. Er scheint es gewohnt zu sein.`n",$olibear);
			output("Die Leute klatschen vergn�gt!");
			output("`n`nNur Du f�hlst Dich etwas blo�gestellt als Tierqu�ler!");
			oli_addgold($value);
			$loss=e_rand(1,3);
			output("Du verlierst %s Charmepunkte!",$loss);
			$session['user']['charm']-=$loss;
			oli_nav();
			break;
		case 4:
			output("`@%s`@ quiekt und jault...`n`n",$olibear);
			output("`pOha, da hat jemand seine Goldb�rse fallen lassen.... ^^ na die braucht einen besseren Besitzer.");
			output_notl("`n`n");
			oli_addgold($value);
			oli_nav();
			break;
		case 5:
			output("`^Du am�sierst Dich so k�stlich, da� Du mit einem strahlenden L�cheln weitermassakrierst..");
			output_notl("`n`n");
			output("`^Du f�hlst Dich `%charmant`^!");
			$session['user']['charm']+=e_rand(1,3);
			oli_nav();
			break;
		}
		break;
	case "tanzen":
		$session['user']['turns']--;
		output("`@Du nutzt nat�rlich die Gunst der Stunde vor dem Publikum.");
		output("`n`nUnd packst die nahegelegenden Schie�eisen und l��t %s`@ mal ein wenig Tanzen!",$olibear);
		output_notl("`n`n");
		output("Die Wirkung bleibt nicht aus...");
		$randomchance=e_rand(0,2);
		switch ($randomchance)
		{
		case 0:
			output("`n`n`@Oh, das hat gesessen, %s`@ hetzt und rennt und schwitzt.",$olibear);
			output_notl("`n`n");
			output("Das hat so gesessen, da� du `%charmant`@ h�misch grinst.");
			$session['user']['charm']++;
			oli_addgold($value);
			oli_nav();
			break;
		case 1:
			output("`k`n`nUps, das ging in die Hose, er konnte sich l�sen, die T�r ging auf und %s`k f�llt gerade �ber Dich her.`@",$olibear);
			output_notl("`n`n");
			output("Zum Gl�ck ist %s`k ein lieber B�r...",$olibear);
			output("Nach einigen Stunden Abbusselns und Schleckens entl��t er Dich aus seiner \"Obhut\".`n");
			output_notl("`n`n");
			$loss=get_module_setting('loss');
			output("Dir wurden %s Prozent Deiner Erfahrung weggeleckt!",$loss);
			$loss/=100;
			$loss=$session['user']['experience']*$loss;
			$session['user']['experience']-=$loss;
			set_module_setting('leck',get_module_setting('leck')+$loss);
			oli_nav();
			break;
		case 2:
			output("`@Hmm.... %s`@ scheint gut gelaunt und tanzt wie eine 1!",$olibear);
			output_notl("`n`n");
			output("Gut gelaunt geben Dir die Leute extra Gold!");
			oli_addgold($value*2);
			apply_buff('olibearsstrafe',
			array(
			"name"=>"`^Hochgef�hl",
			"rounds"=>30,
			"wearoff"=>"Das tolle Gef�hl ist weg, $olibear vergessen.", //change this like in the comment above
			"atkmod"=>1.2,
			"defmod"=>1.2,
			"minioncount"=>1,
			"roundmsg"=>"Du f�hlst Dich toll!",
			"schema"=>"module-olibear",
			));
			oli_nav();
			break;
		}
		break;
	case "walk":
		output("`@Das ist genug f�r heute... Du ziehst von dannen.");
		output_notl("`n`n");
		switch (e_rand(0,2)) {
			case 0:
				output("Als das Zelt au�er Deiner Reichweite ist, atmest Du tief durch und bist so erleichtert, da� Du die Energie f�r einen weiteren Waldkampf sp�rst");
				$session['user']['turns']++;
				break;
			case 1:
				output("Als das Zelt au�er deiner Reichweite ist, findest Du noch etwas Gold!");
				$session['user']['gold']+=e_rand(1,100);
				break;
			}
		$session['user']['specialinc'] = "";
		break;
	}


}

function oli_addgold ($value) {
	global $session;
	$level=$session['user']['level'];
	$gold=get_module_setting('gold');
	$playergold=floor($value*(e_rand(2,$gold))*$level);
	$session['user']['gold']+=$playergold;
	output("`nDu verdienst `^%s Goldst�cke`0!`n",$playergold);
}

function oli_nav() {
	global $session,$olibear,$value;
	$link="forest.php?";
	if 	($session['user']['turns']>0) {
		addnav(array("%s`@ pieksen",$olibear),$link."op=pieksen&mode=$value");
		addnav(array("%s`@ tanzen lassen",$olibear),$link."op=tanzen&mode=$value");
		//addnav(array("%s`@ rennen lassen",$olibear),$link."op=rennen&mode=$value");
	}
	addnav("Weggehen+Grinsen",$link."op=walk");
}

function olibear_run(){
}

?>