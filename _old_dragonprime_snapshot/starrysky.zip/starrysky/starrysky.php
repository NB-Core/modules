<?php
// addnews ready
// mail ready
// translator ready

require_once("lib/http.php");
require_once("lib/villagenav.php");
require_once("lib/names.php");

function starrysky_getmoduleinfo(){
	$info = array(
		"name"=>"The Starry Sky",
		"version"=>"1.0",
		"author"=>"`^CortalUX",
		"category"=>"Village",
		"download"=>"http://dragonprime.net/users/CortalUX/starrysky.zip",
		"settings"=>array(
			"Starry Sky - Location,title",
			"ht"=>"Hook to a location?,bool|0",
			"hl"=>"If yes- Where is the hook?,location|".getsetting("villagename", LOCATION_FIELDS),
			"Starry Sky - Limit,title",
			"dkLimit"=>"DK Limit?,int|0",
			"Starry Sky - Titles,title",
			"good"=>"'Good' title?,text|`^Angel of Light",
			"neut"=>"'Neutral' title?,text|`@Starry Being",
			"evil"=>"'Evil' title?,text|`%Demon of \$Death",
			"(if the alignment module is not installed the neutral title will be used),note",
		),
		"prefs"=>array(
			"x"=>"X-coordinate?,int|1",
			"y"=>"Y-coordinate?,int|1",
			"l"=>"Is in starry sky?,bool|0",
			"o"=>"Old title?,text|",
		)
	);
	return $info;
}

function starrysky_install(){
	module_addhook("village-desc");
	module_addhook("newday");
	module_addhook("changesetting");
	return true;
}

function starrysky_uninstall(){
	return true;
}

function starrysky_dohook($hookname,$args){
	global $session;
	switch($hookname){
		case "village-desc":
			$t = false;
			if (get_module_setting('dkLimit')>0) {
				if ($session['user']['dragonkills']>=get_module_setting('dkLimit')) {
					$t = true;
				}
			} else {
				$t = true;
			}
			if ($t) {
				if (get_module_setting('ht')==1&&get_module_setting('hl')==$session['user']['location']) {
					tlschema($args['schema']['marketnav']);
					addnav($args['marketnav']);
					addnav("Sacred Starshrine","runmodule.php?module=starrysky&op=enter");
					tlschema();
					addnav("Sacred Starshrine","runmodule.php?module=starrysky&op=enter");
					output("`n`^A Starry shrine stands in the square!");
				} elseif (get_module_setting('ht')==0) {
					tlschema($args['schema']['marketnav']);
					addnav($args['marketnav']);
					addnav(array("%s Starshrine",$session['user']['location']),"runmodule.php?module=starrysky&op=enter");
					tlschema();
					output("`n`^A Starry shrine stands in the square!");
				}
			} else {
				output("`n`@A Starry shrine stands in the square, yet you cannot enter it..");
			}
			if (get_module_pref('l')==1) {
				redirect("runmodule.php?module=starrysky&op=stand");
			}
		break;
		case "newday":
			if (get_module_pref('l')==1) {
				output("`n`^The stars call to you..");
			}
		break;
		case "changesetting":
			if ($args['setting'] == "villagename"){
				if ($args['old'] == get_module_setting('hl')){
					set_module_setting('hl', $args['new']);
				}
			}
		break;
	}
	return $args;
}

function starrysky_run(){
	global $session;
	$max = 20;
	$op = httpget("op");
	if ($op!="enter") {
		page_header("The Starry Sky");
	} else {
		page_header("The Star Shrine");
	}
	checkday();
	$x = get_module_pref('x');
	$y = get_module_pref('y');
	switch($hookname){
		case "enter":
			$x = 1;
			$y = 1;
			set_module_pref('l',1);
			set_module_pref('o',$session['user']['ctitle']);
			$title = starrysky_gettitle();
			$session['user']['name'] = change_player_ctitle($title);
			$session['user']['ctitle'] = $title;
		break;
		case "leave":
			set_module_pref('l',0);
			output("`n`&You fall to earth in a flurry of light and sound...");
			addnav("Continue...","village.php");
			$session['user']['name'] = change_player_ctitle(get_module_pref('o'));
			$session['user']['ctitle'] = get_module_pref('o');
			set_module_pref('o',"");
		break;
		case "north":
			$y++;
			output("`^`@You fly north...");
		break;
		case "south":
			$y--;
			output("`n`@You fly south...");
		break;
		case "east":
			$x++;
			output("`n`^You whisk east...");
		break;
		case "west":
			$x--;
			output("`n`@You whisk west...");
		break;
		case "stand":
			output("`n`%You stop and stare for a moment... this mighty wonder of a place never ceases to amaze you.");
		break;
	}
	if ($x>$max) $x=$max;
	if ($x<1) $x=1;
	if ($y>$max) $y=$max;
	if ($y<1) $y=1;
	set_module_pref('x',$x);
	set_module_pref('y',$y);
	if ($op!='leave') {
		starrysky_navs();
		starrysky_descreturn();
	}
	page_footer();
}

function starrysky_descreturn() {
	$x = get_module_pref('x');
	$y = get_module_pref('y');
	$desc = array();
	if (isset($desc[$x][$y])) {
		output($desc[$x][$y]);
	} else {
		output("`^The stars are so beautiful...");
	}
	$w = "`^";
	if ($y>=10) {
		$w .= translate_inline("North-");
	} else {
		$w .= translate_inline("South-");
	}
	if ($x>=10) {
		$w .= translate_inline("East");
	} else {
		$w .= translate_inline("West");
	}
	$w .= "`n`@".translate_inline("Your starry senses show you to be on Sq. `%".$x."`@,`%".$y");
	output_notl($w);
}

function starrysky_navs() {
	$max = 20;
	$x = get_module_pref('x');
	$y = get_module_pref('y');
	$nav = array();
	addnav("Navigation");
	if ($x!=$max) {
		addnav("Whisk East","runmodule.php?module=starrysky&op=east");
	}
	if ($x!=1) {
		addnav("Whisk West","runmodule.php?module=starrysky&op=west");
	}
	if ($y!=$max) {
		addnav("Fly North","runmodule.php?module=starrysky&op=north");
	}
	if ($y!=1) {
		addnav("Fly South","runmodule.php?module=starrysky&op=south");
	}
	addnav("The Starry Path");
	$nav['1']['1']['Fall to Ground']="runmodule.php?module=starrysky&op=leave";
	$nav['20']['20']['Fall to Ground']="runmodule.php?module=starrysky&op=leave";
	modulehook("starrysky-navs",array('x'=>$x,'y'=>$y);
	if (isset($nav[$x][$y])) {
		foreach ($nav[$x][$y] as $text => $url) {
			addnav($text,$url);
		}
	}
}

function starrysky_gettitle() {
	global $session;
	if (is_module_active('alignment'))
		$evilalign=get_module_setting('evilalign','alignment');
		$goodalign=get_module_setting('goodalign','alignment');
		$useralign=get_module_pref('alignment','alignment',$session['user']['acctid']);
		if ($useralign >= $goodalign){$title=get_module_setting('good');}
		if ($useralign <=$evilalign){$title=get_module_setting('evil');}
		if ($useralign > $evilalign and $useralign < $goodalign){$title=get_module_setting('neut');}
	} else {
		$title=get_module_setting('neut');
	}
	return $title;
}
?>