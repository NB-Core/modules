<?php
/*
Details:
 * This is a module to allow users to have their GRAvatars appear
Credit:
 * Eric Stevens/MightyE - For the ServerURL Code
*/
function gravatar_getmoduleinfo(){
	$link = getsetting("serverurl","http://".$_SERVER['SERVER_NAME'] .	($_SERVER['SERVER_PORT']==80?"":":".$_SERVER['SERVER_PORT']) .	dirname($_SERVER['SCRIPT_NAME']));
	if (!preg_match("/\/$/", $link)) {
		$link = $link . "/";
		savesetting("serverurl", $link);
	}
	$info = array(
		"name"=>"Gravatar",
		"version"=>"1.0",
		"author"=>"`@CortalUX",
		"category"=>"General",
		"download"=>"http://www.dragonprime.net/users/CortalUX/gravatar.zip",
		"vertxtloc"=>"http://dragonprime.net/users/CortalUX/",
		"settings"=>array(
			"Gravatar - Settings,title",
			"pathTo"=>"URL for default image?,text|$link"."images/gravatar/default.png",
			"rating"=>"The Highest Rating allowed (inclusive)?,enum,G,G,PG,PG,R,R,X,X|PG",
			"border"=>"Should a border be auto-placed upon the image?,bool|0",
			"borderCol"=>"If so- what color?,text|#000000",
			"(must be hexadecimal),note",
		),
		"prefs"=>array(
			"Gravatars,title",
			"user_note"=>"`i`@This site is compatible with Gravatars!`nGet yours from www.gravatar.com`nGravatars will be displayed using the email address you registered with.`i,note",
			"user_show"=>"`^Show Gravatars?,bool|1",
		),
	);
	return $info;
}

function gravatar_install(){
	if (!is_module_active('gravatar')){
		output("`n`c`b`QGravatar Module - Installed`0`b`c");
	}else{
		output("`n`c`b`QGravatar Module - Updated`0`b`c");
	}
	module_addhook_priority("biostat",51);
	return true;
}

function gravatar_uninstall(){
	output("`n`c`b`QGravatar Module - Uninstalled`0`b`c");
	return true;
}

function gravatar_dohook($hookname,$args){
	global $session;
	switch($hookname){
		case "biostat":
			if (get_module_pref('user_show')==1) {
				$link=get_module_setting("pathTo");
				$sql = "SELECT emailaddress FROM `".db_prefix("accounts")."` WHERE acctid={$args['acctid']}";
				$result = db_query($sql);
				if (db_num_rows($result)>0) {
					output("`^Gravatar:`n");
					$row=db_fetch_assoc($result);
					require_once('lib/sanitize.php');
					$x=0;
					if (get_module_setting('border')!=0) $x=get_module_setting('borderCol');
					rawoutput(gravatar($row['emailaddress'],$link,full_sanitize($args['name']),get_module_setting('rating'),$x));
					output_notl("`n");
				}
			}
		break;
	}
	return $args;
}

function gravatar_run() {
}

/**
 Gravatar Function:
  * Returns the html code for a Gravatar
  * A GRAvatar (Globally Recognizable Avatar) is an image from http://www.gravatar.com
  *
  * @param string $email   The e-mail for a Gravatar
  * @param string $default The default URL if no gravatar for that exists
  * @param string $name    The name of the user (for the alt='' tag)
  * @param string $rating  A censor-rating (inclusive) / can be [ G | PG | R | X ]
  * @param string $border  0 for none, or the hexadecimal color of a border
*/

function gravatar($email="",$default="",$name="",$rating="PG",$border="0") {
	$email=md5($email);
	$url="http://www.gravatar.com/avatar.php?rating=$rating&gravatar_id=$email&default=".urlencode($default)."&size=80";
	if ($border!="0") $url.="&border=$border";
	$code="<img src='$url' width='80' height='80' style='width:80px;height:80px;border:0;' alt=\"".str_replace('"','\"',$name).translate_inline("'s Gravatar")."\"/>";
	return $code;
}
?>