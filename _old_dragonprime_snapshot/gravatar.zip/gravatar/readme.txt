Legend of the Green Dragon
by  Eric "MightyE" Stevens (http://www.mightye.org)
and JT "Kendaer" Traub (http://www.dragoncat.net)

Software Project Page:
http://sourceforge.net/projects/lotgd

Modification Community Page:
http://dragonprime.net

Gravatar Page:
http://gravatar.net

Author of this Module:
CortalUX (cortalux@gmail.com)

Download the latest version of this module from:
http://dragonprime.net/index.php?action=viewfiles&user=CortalUX

----------------------------------------------
-- STATUS: -----------------------------------
----------------------------------------------
This module is STABLE.

----------------------------------------------
-- INFORMATION: ------------------------------
----------------------------------------------
This is a gravatar module for LotGD 1.X.X.
It allows users to use their gravatars from
www.gravatar.com .

----------------------------------------------
-- INSTALLATION: -----------------------------
----------------------------------------------
Copy ALL folders (except this one) within this
zip into the folders of your installation.

Login to the Superuser Grotto and Install / Activate it.