<?php
/*
    Multiserverchat
    - Clientfile 0.9.7
    
*/

Require_once "common.php";

$serverurl = "http://www.logd.ch/centralchat";
$serverurl2 = "http://www.logd.ch/centralchat";
$path = getsetting("mscpath","/");

function multi_viewcommentary($section,$return,$message="Kommentar hinzuf�gen?",$limit=10,$talkline="sagt")
{
  global $session,$serverurl,$serverurl2,$path,$REQUEST_URI;
  $comments = file($serverurl."/serverscript.php?section=".$section);
  if(!isset($_GET['comscroll'])) $_GET['comscroll'] = 0;
  // $i = $limit * $_GET['comscroll'];
  $max = ($limit * $_GET['comscroll']) + $limit;
  $a = 1;
  $op = array();
  $infos = unserialize($comments[0]);
  while($i <= $max)
  {
    $row = unserialize($comments[$a]);
    if(!empty($row))
    {
      $comment = stripslashes(preg_replace("'[`][^".preg_quote("123456789!@#\$%&QqRr*~^?VvGgTtAaXxEeUuLl�")."]'","",$row['comment']));
      if(substr($comment,0,3) == "/me" || substr($comment,0,1) == ":"  || substr($comment,0,2) == "::" )
      {
        if(substr($comment,0,3) == "/me") $comment = str_replace("/me"," ",$comment);
        if(substr($comment,0,1) == ":") $comment = str_replace(":"," ",$comment);
        if(substr($comment,0,2) == "::") $comment = str_replace("::"," ",$comment);
        $op[$a] = "`&".$row['author'].HTMLENtities($comment);
      }
      else
      {
        $op[$a] = "`&".$row['author']."`3 ".$talkline."`3: \"`#".stripslashes(HTMLEntities($comment))."`3\" ";
      }
    }
    else break;
    $a++;
  }
  krsort($op);
  $b = $a;
  while($b >= 0)
  {
    // if(empty($op[$b]));
    $out.=$op[$b]."<br />";
    $b--;
  }
  $out .= "<form action='".$serverurl2."/serverscript_insert.php' method='POST' autocomplete='false'>"
         ."`@$message`n<input name='comment' size='40' maxlenght='500'>"
         ."<input type='hidden' name='section' value='$section'>"
         ."<input type='hidden' name='author' value='".str_replace("`","``",$session['user']['name'])."'>"
         ."<input type='hidden' name='acctid' value='".$session['user']['acctid']."'>"
         ."<input type='hidden' name='return' value='$return'>"
         ."<input type='hidden' name='serveruri' value='"."http://".$_SERVER['HTTP_HOST'].$path."'>"
         ."<input type='hidden' name='serverid' value='".getsetting("Serveruniqueid",false)."'>"
         ."<input type='submit' class='button' value='Hinzuf�gen'>"
         ."`n</form>";
  addnav("",$return);
         
  $request =  preg_replace("'[&]?c(omscroll)?=([[:digit:]-])*'","",$REQUEST_URI);

  $rmax = $infos['count'] / $limit;
  $rmax = floor($rmax);
  /* Ganz nach hinten */
  if ($_GET['comscroll'] != $rmax)
  {
    $req = $request."&comscroll=".$rmax;
    $req = str_replace("?&","?",$req);
    if (!strpos($req,"?")) $req = str_replace("&","?",$req);
    $out .= " <a href=\"$req\">&lt;&lt;&lt; Letzte </a>";
    addnav("",$req);
  }
  /* Zur�ck bl�ttern */
  if ($infos['count']>($_GET['comscroll']+1)*$limit)
  {
    $req = $request."&comscroll=".($_GET['comscroll']+1);
    $req = str_replace("?&","?",$req);
    if (!strpos($req,"?")) $req = str_replace("&","?",$req);
    $out .= "<a href=\"$req\">&lt;&lt; Vorherige</a>";
    addnav("",$req);
  }
  /* Refresh */
  $req = $request."&comscroll=".(!isset($_GET['comscroll'])?0:$_GET['comscroll']);
  $req = str_replace("?&","?",$req);
  if (!strpos($req,"?")) $req = str_replace("&","?",$req);
  $out .= "&nbsp;<a href=\"$req\">Aktualisieren</a>&nbsp;";
  addnav("",$req);
  /* Nach vorne */
  if ($_GET['comscroll']>0)
  {
    $req = $request."&comscroll=".($_GET['comscroll']-1);
    $req = str_replace("?&","?",$req);
    if (!strpos($req,"?")) $req = str_replace("&","?",$req);
    //output(" <a href=\"$req\">Next &gt;&gt;</a>",true);
    $out .= " <a href=\"$req\">N�chste &gt;&gt;</a>";
    addnav("",$req);
  }
  /* Ganz nach vorne */
  if ($_GET['comscroll']>1)
  {
    $req = $request."&comscroll=0";
    $req = str_replace("?&","?",$req);
    if (!strpos($req,"?")) $req = str_replace("&","?",$req);
    //output(" <a href=\"$req\">Next &gt;&gt;</a>",true);
    $out .= " <a href=\"$req\">Neuste &gt;&gt;&gt;</a>";
    addnav("",$req);
  }
  
  output($out,true);
}

page_header("Marktplatz von Renais");

switch($_GET['section']):
  case "":
    $_GET['section'] = "mcp";
  case "mcp":
    output("`c`b`@Renais`b`c`n");
    output("`@Der Marktplatz von Renais. Ein Treffpunkt f�r viele Krieger und Kriegerinnen. ");
    output("Viele hier verkehrende Personen hast du nie zuvor gesehen, geschweige den von ihnen geh�rt.`n");
    output("Aber trotzdem getraust du dich, mit einigen zu sprechen:`n`n");
    $msg = "Mit anderen sprechen";
    $tl = "sagt";
    break;
  case "waldrand":
    output("`c`b`@Der Waldrand`b`c`n");
    output("`@Diesmal brauchst du keine Sorge vor einem Gr�nen Drachen zu haben, denn die k�nigliche Garde h�lt den Wald sauber. ");
    output("Aber leise zu sprechen hat doch einige Vorteile... Machs den anderen nach!`n`n");
    $msg = "Leise sprechen";
    $tl = "sagt leise";
    break;
  case "taverne":
    output("`c`b`@Die Taverne Renais'`b`c`n");
    output("`@Dunkel ist es. der qualm von brennendem Holz steigt dir in die Nase. ");
    output("Der Barkeeper, ein Zwerg fortgeschrittenen Alters, w�scht gerade einige Gl�ser, ein grosses Al�fass steht ge�ffnet hinter der Theke.`n`n");
    $msg = "Lallen";
    $tl = "lallt";
    break;
  case "garten":
    output("`c`b`@Der Garten von Renais`b`c`n");
    output("`@Kleine Glitzerfeen flattern durch die L�fte, ein romantischer Fluss fliesst langsam durch den Garten. ");
    output("Mit kleiner Piepsestimme erinnert dich eine der Feen daran, dass du hier nur Charakterpezifisches schreiben darfst.`n`n");
    $msg = "Fl�stern";
    $tl = "fl�stert";
    break;
  case "spielwiese":
    output("`c`b`@Die Spielwiese`b`c`n");
    output("`@Kinder tollen herum, Eltern sitzen m�de unter den sch�nen, grossgewachsenen B�umen. ");
    output("Hier darfst du dich austollen - sofern du keine Regel brichst!`n`n");
    $msg = "Herumtollen";
    $tl = "grinst";
    break;
  case "erholung":
    output("`c`b`@Erholungszone`b`c`n");
    output("`@Eine Alte Frau steht in der Mitte des Gr�nen, schattigen Platzes und schenkt Tee aus. ");
    output("Die unterschiedlichsten Personen machen hier ihr schl�fchen, hier solltest du dich also �usserst leise unterhalten!`n`n");
    $msg = "Ganz leise fl�stern";
    $tl = "fl�stert leise";
    break;
  case "temple":
    output("`c`b`@Der verfallene Tempel`b`c`n");
    output("`@Tr�mmer liegen verstreut umher, die Umrisse des Tempels sind noch gut zu erkennen. ");
    output("Seltsame Wesen lungern hier herum, schauen sich die Steine genaustens an, graben hie und dort. ");
    output("Und doch merkt niemand den Rauch, der aus dem innern der Ruinen kommt...`n`n");
    $msg = "Staunen";
    $tl = "staunt";
    break;
  endswitch;

$prefix = $session['user']['prefs']['chatlang'];

multi_viewcommentary($prefix."".$_GET['section'],"marketplace.php?section=".$_GET['section'],$msg,30,$tl);


addnav("Renais");
addnav("Waldrand","marketplace.php?section=waldrand");
addnav("Marktplatz","marketplace.php?section=mcp");
addnav("Taverne","marketplace.php?section=taverne");
addnav("Garten","marketplace.php?section=garten");
addnav("Spielwiese","marketplace.php?section=spielwiese");
addnav("Erholungszone","marketplace.php?section=erholung");
addnav("Verfallener Tempel","marketplace.php?section=temple");



addnav("Zur�ck","village.php");

page_footer();
?>
