<?php
/*
Geschrieben fuer lotgd.eq-gildenhaus.de, Antic �2004-2005
Bugmeldungen bitte an antic@eq-gildenhaus.de
Vorschlaege zur Verbesserung sind jederzeit willkommen!
*/
function rsequip_getmoduleinfo(){
	$info = array(
		"name"=>"Rucksack und Equipment (german)",
		"author"=>"`3Antic`0",
		"version"=>"0.2",
		"category"=>"General",
        "download"=>"http://dragonprime.net/users/Antic/rsequip.zip",
		"override_forced_nav"=>true,
		"requires"=>array(
			"itemdat_editor"=>"0.55|Antic, Itemdat Editor",
		),
		"prefs" => array(
			"Rucksack und Equipment - Spieler Einstellungen,title",
			"groesse"=>"Wieviel Items gehen in den Rucksack?,int|20",
			"inhalt"=>"Wieviel Items sind im Rucksack?,viewonly",
		),
	);
	return $info;
}

function rsequip_install(){
	include("modules/rsequip/install.php");
	return true;
}

function rsequip_uninstall(){
	return true;
}

function rsequip_dohook($hookname,$args){
	global $session;
    switch($hookname){
	case 'everyhit':
		include("modules/rsequip/everyhit.php");
		break;

	case 'charstats':
		include("modules/rsequip/charstats.php");
		break;

	case 'biotop':
		//addnav("Equipment");
		//addnav("Anschauen","runmodule.php?module=rsequip");
		break;
    }
	return $args;
}

function rsequip_run(){
	include("modules/rsequip/run.php");
}
?>
