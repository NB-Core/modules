<?php
	addcharstat("Equipment Info");
	addcharstat("Rucksack","<a href='runmodule.php?module=rsequip' onClick=\"".popup("runmodule.php?module=rsequip").";return false;\" target='_blank' align='center' class=\"charinfo\" style=\"font-size:10px\">�ffnen</a>");
	addnav("","runmodule.php?module=rsequip");
?>
