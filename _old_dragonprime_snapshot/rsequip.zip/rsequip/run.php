<?php
	global $session;
	$op = httpget('op');
	$act = httpget('act');
	$del = httpget('del');
	$itemid = httpget('itemid');
	$iclass = httpget('iclass');
	$sort = httpget('sort');
	$limit = httpget('limit');
	$acctid = httpget('acctid');
	$psearch = httppost('search');
	$gsearch = httpget('search');

	$zurueck = translate_inline("Zur�ck");

	popup_header("Rucksack");

if ($op==''){

	$inhalt = translate_inline("Inhalt");
	$traenke = translate_inline("Tr�nke");
	$zauber = translate_inline("Zauber");

	if (!$sort){
		output_notl("`&[$inhalt]");
	}else{
		output_notl("`&[<a href='runmodule.php?module=rsequip'>`b$inhalt`b</a>",true);
    	addnav("","runmodule.php?module=rsequip");
	}

/*	if ($sort=="potion"){
		output_notl("`&|$traenke|");
	}else{
		output_notl("`&|<a href='runmodule.php?module=rsequip&sort=potion'>`b$traenke`b</a>`&|",true);
    	addnav("","runmodule.php?module=rsequip&act=potion");
	}

	if ($sort=="spell"){
		output_notl("`&$zauber]");
	}else{
		output_notl("<a href='runmodule.php?module=rsequip&sort=spell'>`b$zauber`b</a>`&]",true);
    	addnav("","runmodule.php?module=rsequip&act=spell");
	}
*/

	if (!$sort) $itemv1 = "(".db_prefix('itemdat').".itemv1=0 OR ".db_prefix('itemdat').".itemv1 LIKE 'slot-%')";
	if ($sort) $itemv1 = "".db_prefix('itemdat').".itemv1 LIKE '$sort-%'";

	if ($act==''){
   		$sql = "SELECT ".db_prefix('itemdat').".*,".db_prefix('itemclass').".*
	   		FROM ".db_prefix('itemdat')." INNER JOIN ".db_prefix('itemclass')."
			ON ".db_prefix('itemdat').".itemclass=".db_prefix('itemclass').".iclass
	   		WHERE ".db_prefix('itemdat').".activate=1
			AND ".db_prefix('itemdat').".ownerid={$session['user']['acctid']}
			AND ".db_prefix('itemdat').".itemv3=0
			AND $itemv1
			ORDER BY itemclass,itemname ASC";
   		$result = db_query($sql);
		if (db_num_rows($result)){

			if (!$sort){
		    	$name = translate_inline("Name");
		    	$action = translate_inline("Aktionen");
				$fablegen = translate_inline("Willst du das wirklich ablegen?");
				$ablegen = translate_inline("ablegen");
				$handeln = translate_inline("handeln");
				$anziehen = translate_inline("anziehen");

				rawoutput("<table width=\"100%\" border=0 align='center' cellpadding=2 cellspacing=1 bgcolor='#999999'>");
				output_notl("<br><tr style=\"background-color:#339999;\"><td>`b`c`&$name`c`b</td><td>`b`c`&$action`c`b</td></tr>", true);

   				for ($i=0;$i<db_num_rows($result);$i++){
					$row = db_fetch_assoc($result);

        			output_notl("<td class='trlight'><a href='runmodule.php?module=rsequip&op=info&itemid={$row['itemid']}&sort=$sort'>`b{$row['itemname']}`b</a>", true);
        			addnav("","runmodule.php?module=rsequip&op=info&itemid={$row['itemid']}");
	    			rawoutput("</td><td align='center' class='trlight'>");

					output_notl("`&[<a href='runmodule.php?module=rsequip&act=del&itemid={$row['itemid']}' onClick=\"return confirm('$fablegen');\">$ablegen</a>`&|", true);
					addnav("","runmodule.php?module=rsequip&act=del&itemid={$row['itemid']}");

					if ($row['trade']){
						rawoutput("<a href='runmodule.php?module=rsequip&op=handel&itemid={$row['itemid']}&iclass={$row['itemclass']}'>$handeln</a>");
						addnav("","runmodule.php?module=rsequip&op=handel&itemid={$row['itemid']}&iclass={$row['itemclass']}");
					}else{
						output_notl("`&$handeln");
					}

					if ($row['equip']){
						output_notl("`&|<a href='runmodule.php?module=rsequip&op=equip&itemid={$row['itemid']}'>$anziehen</a>`&]", true);
						addnav("","runmodule.php?module=rsequip&op=equip&itemid={$row['itemid']}");
					}else{
						output_notl("`&|$anziehen]");
					}

					rawoutput("</td></tr>");
   				}
    			rawoutput("</table>");
			}else{
			}
		}else{
    		if (!$sort) output("`n`n`b`cDu hast keine Items!`c`b`n");
    		if ($sort=='potion') output("`n`n`b`cDu hast keine Zaubertr�nke!`c`b`n");
    		if ($sort=='spell') output("`n`n`b`cDu hast keine Zauber!`c`b`n");
		}
	}

	if ($act=='del'){
		set_module_pref('inhalt',get_module_pref('inhalt','rsequip')-1,'rsequip');
    	$sql = "SELECT ".db_prefix('itemdat').".itemid,".db_prefix('itemclass').".ac
			FROM ".db_prefix('itemdat')." LEFT JOIN ".db_prefix('itemclass')."
			ON ".db_prefix('itemdat').".itemclass=".db_prefix('itemclass').".iclass
	   		WHERE ".db_prefix('itemdat').".itemid=$itemid
			AND ".db_prefix('itemdat').".itemclass=".db_prefix('itemclass').".iclass";
    	$result = db_query($sql);
		$row = db_fetch_assoc($result);
		if (!$row['ac']){
			$sql="DELETE FROM ".db_prefix('itemdat')."	WHERE itemid={$row['itemid']}";
			db_query($sql);
		}else{
 			$sql = "UPDATE ".db_prefix('itemdat')."
				SET ownerid=0
					,ownername=''
				   	,activate=1
				WHERE itemid={$row['itemid']}";
   			db_query($sql);
		}
		$back = translate_inline("Zur�ck");

		output("`n`b`cItem abgelegt!`c`b`n");
        output_notl("<a href='runmodule.php?module=rsequip'>`b`\$$back`b</a>",true);
        addnav("","runmodule.php?module=rsequip");
	}

}elseif ($op=='info'){

	$sql = "SELECT itemname,itemdesc,itemv2 FROM ".db_prefix('itemdat')." WHERE itemid=$itemid";
   	$result = db_query($sql);
	$row = db_fetch_assoc($result);

    output_notl("`&[<a href='runmodule.php?module=rsequip&sort=$sort'>`b$zurueck`b</a>`&]",true);
    addnav("","runmodule.php?module=rsequip&sort=$sort");
	rawoutput("<table width=\"100%\" border=0 align='center' cellpadding=2 cellspacing=1 bgcolor='#999999'>");
	rawoutput("<br><tr style=\"background-color:#339999;\"><td>");
	output("`b`&Name:`b");
	rawoutput("</td><td align='center' class='trlight'>");
	rawoutput($row['itemname']);
	rawoutput("</td></tr>");
	rawoutput("<tr style=\"background-color:#339999;\"><td>");
	output("`b`&Beschreibung:`b");
	rawoutput("</td><td align='center' class='trlight'>");
	rawoutput($row['itemdesc']);
	rawoutput("</td></tr>");
	rawoutput("<tr style=\"background-color:#339999;\"><td>");
	output("`b`&Extras:`b");
	rawoutput("</td><td align='center' class='trlight'>");
	output("`i`c`\$Nicht verf�gbar`c`i");
	rawoutput("</td></tr>");
	rawoutput("</table>");

}elseif ($op=='handel'){

    output_notl("`&[<a href='runmodule.php?module=rsequip&sort=$sort'>`b$zurueck`b</a>`&]",true);
    addnav("","runmodule.php?module=rsequip&sort=$sort");

	if (!$act){
    	if (isset($psearch) || $gsearch>""){
    	if ($gsearch>"") $psearch=$gsearch;
        	$search="%";
    	for ($x=0;$x<strlen($psearch);$x++){
        	$search .= substr($psearch,$x,1)."%";
    	}
    	$search="".db_prefix('accounts').".name LIKE '".$search."' AND ";
    	}else{
        	$search="";
    	}
   		$ppp=10;
   		$naechste = translate_inline("N�chste Seite");
   		$vorher = translate_inline("Vorherige Seite");
		$ssearch = translate_inline("Suchen");
		$nsearch = translate_inline("Nach Namen suchen:");
		$sname = translate_inline("Name");
		$slevel = translate_inline("Level");
		$ssex = translate_inline("Geschlecht");

    	if (!$limit){
        	$page=0;
        	output_notl("`&[`b$naechste`b|");
    	}else{
        	$page=(int)$limit;
		    output_notl("`&[<a href='runmodule.php?module=rsequip&op=handel&itemid=$itemid&iclass=$iclass&limit=".($page-1)."&search=$psearch'>`b$naechste`b</a>`&'|",true);
    		addnav("","runmodule.php?module=rsequip&op=handel&itemid=$itemid&iclass=$iclass&limit=".($page-1)."&search=$psearch");
    	}
       		$lim="".($page*$ppp).",".($ppp+1);
       		$sql = "SELECT mindk FROM ".db_prefix('itemclass')." WHERE iclass='$iclass'";
       		$result1 = db_query($sql);
        	$row1 = db_fetch_assoc($result1);

       		$sql = "SELECT acctid,level,sex,name FROM ".db_prefix('accounts')." WHERE $search locked=0 AND alive=1 AND acctid<>{$session['user']['acctid']} AND dragonkills > {$row1['mindk']} ORDER BY login,level LIMIT $lim";
       		$result = db_query($sql);
    		if (db_num_rows($result)>$ppp){
		    	output_notl("<a href='runmodule.php?module=rsequip&op=handel&itemid=$itemid&iclass=$iclass&limit=".($page-1)."&search=$psearch'>`b$vorher`b</a>`&']",true);
				addnav("","runmodule.php?module=rsequip&op=handel&itemid=$itemid&iclass=$iclass&limit=".($page+1)."&search=$psearch");
    		}else{
        		output_notl("`&`b$vorher`b]");
    		}

			output("`n`nWer soll der Empf�nger sein?`n");
       		rawoutput("<form action='runmodule.php?module=rsequip&op=handel&itemid=$itemid&iclass=$iclass' method='POST'>");
			output_notl("$nsearch<input name='search' value='$psearch'><input type='submit' class='button' value='$ssearch'></form>", true);
       		addnav("","runmodule.php?module=rsequip&op=handel&itemid=$itemid&iclass=$iclass");
       		rawoutput("<table cellpadding='3' cellspacing='0' border='0' align='center'><tr class='trhead'><td>$sname</td><td>$slevel</td><td>$ssex</td></tr>");
    	for ($i=0;$i<db_num_rows($result);$i++){
        	$row = db_fetch_assoc($result);

        	$senden = translate("Willst du dieses Item wirklich versenden?");

        	output_notl("<tr class='".($i%2?"trlight":"trdark")."'><td><a href='runmodule.php?module=rsequip&op=handel&itemid=$itemid&acctid={$row['acctid']}&act=trade' onClick=\"return confirm('$senden');\">{$row['name']}</a>",true);
        	rawoutput("</td><td>");
        	output_notl($row['level']);
        	rawoutput("</td><td align='center'><img src='images/".($row['sex']?"female":"male").".gif'></td></tr>");
        	addnav("","runmodule.php?module=rsequip&op=handel&itemid=$itemid&acctid={$row['acctid']}&act=trade");
    	}
    	rawoutput("</table>");
	}else{
   		$sql = "SELECT name FROM ".db_prefix('accounts')." WHERE acctid=$acctid";
   		$result = db_query($sql);
       	$row = db_fetch_assoc($result);

    	if (get_module_pref('inhalt','rsequip',$acctid)>=get_module_pref('groesse','rsequip',$acctid)){
			output("`c`&Der Rucksack von {$row['name']} `&ist voll!`c");
	    }else{
			output("`c`&Der Handel mit {$row['name']} `&ist perfekt!`c");
			$sql="UPDATE ".db_prefix('itemdat')." SET ownerid=$acctid, ownername='{$row['name']}' WHERE itemid=$itemid";
			db_query($sql);
    	}
	}

}elseif ($op=='equip'){
    output_notl("`&[<a href='runmodule.php?module=rsequip&sort=$sort'>`b$zurueck`b</a>`&]",true);
    addnav("","runmodule.php?module=rsequip&sort=$sort");
}
	popup_footer();
?>
