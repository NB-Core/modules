<?php
if (!$session['user']['acctid']=='' && is_module_active('rsequip')){
	$sql = "SELECT count(itemid) as a FROM ".db_prefix('itemdat')." WHERE ownerid={$session['user']['acctid']} AND itemv3=0";
	$resulta = db_query($sql);
	$rowa = db_fetch_assoc($resulta);
	set_module_pref('inhalt',$rowa['a'],'rsequip');
}
?>
