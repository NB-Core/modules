<?php
	module_addhook('charstats');
 	module_addhook('biotop');
	module_addhook('everyhit');
?>
