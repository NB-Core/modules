<?php
function delallcomments_getmoduleinfo(){
  $info = array(
    "name"=>"Delete All Comments",
    "version"=>"0.01",
    "author"=>"Derek0",
    "category"=>"Administrative",
    "download"=>"http://dragonprime.net/users/Derek/delallcomments.txt",
  );
return $info;
}

function delallcomments_install(){
module_addhook("footer-moderate");
return true;
}

function delallcomments_uninstall(){
return true;
}

function delallcomments_dohook($hookname,$args){
  global $session;
  switch($hookname){
    case "footer-moderate":
      addnav("Other");
      addnav("Delete All","runmodule.php?module=delallcomments");
    break;
  }
  return $args;
}

function delallcomments_run(){
global $session;
page_header("Delete All Comments");
$sql = "DELETE FROM " . db_prefix("commentary") . "";
db_query($sql);
output("All comments have been deleted!");
addnav("Continue","moderate.php");
page_footer();
}
?>
