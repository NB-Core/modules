<? 
/* ******************* 
Tempel der G�tter 
Written by Romulus von Grauhaar 
    Visit http://www.scheibenwelt-logd.de.vu

Das Special f�gt einen Tempel im Wald hinzu, bei dem Spieler eine beliebige Menge Gold spenden k�nnen. 
Ab einer gewissen Menge Gold passiert ein zuf�lliges Ereignis, je nach dem Gott, dem der Tempel geweiht ist.
Sowohl der ben�tigte Goldbetrag als auch die Namen der Gottheiten lassen sich ganz einfach am Skriptanfang
vom Admin festlegen.
Der Sinn dieses Specials ist, dass viele Spieler kurz vor ihrem Drachenkill eine Menge Gold �brig haben, was sie 
beim Drachenkill verlieren w�rden. Hier k�nnen sie mit etwas Gl�ck brauchbare Dinge daf�r bekommen, allerdings
kann der Schuss auch nach hinten losgehen (wobei die negativen Auswirkungen nicht dauerhaft sind, immerhin
hat der Spieler ne Menge Gold geopfert)

Um das Special zu benutzen, muss folgender SQL-Befehl ausgef�hrt werden: 

ALTER TABLE 'accounts' ADD 'tempelgold' INT( 30 ) DEFAULT '0' NOT NULL;

Optional kann in der user.php an geeigneter Stelle eingef�gt werden:
	"tempelgold"=>"Gold im Tempel gespendet,int",
so dass der Admin die Datenbank-Variable im User-Editor bearbeiten kann.



******************* */  


// Die nun folgenden Variablen konfigurieren das Special. Die Variable $spendenbetrag steht f�r den
// Betrag an Gold, den ein Spieler gespendet haben muss, damit die G�tter reagieren.
// Die einzelnen G�tternamen sind frei w�hlbar.

$spendenbetrag = "10000";
$gott_gem = "Die Lady";
$gott_defense = "Om";
$gott_hp = "Schicksal";
$gott_attack = "Offler";
$gott_charm = "Aphrodante";
$gott_fight = "Nuggan";
$gott_kill = "Bel-Shamharoth";
$gott_hurt = "Der heilige St. Tobsucht";


$session[user][specialinc]="tempel.php"; 
if ($HTTP_GET_VARS[op]==""){ 
    output("`@Auf deiner Reise kommst du pl�tzlich an einem Tempel vorbei. Ein imposater, aber schon leicht verfallener Bau mit S�ulen vor dem Eingang. Du betrittst das heilige Haus und siehst, dass der Tempel eine Renovierung dringend Notwendig h�tte. Das einzige was noch intakt zu sein scheint, ist der Opferstock, �ber dem ein Schild prangt: `n`&\"Sehr geehrter Besucher, unser Tempel ist leider dem Verfall preisgegeben, bitte spende etwas f�r die Renovierung. Die G�tter m�gen es dir danken. Gez. der Hohepriester.\"`@"); 
    output("`n`nWas wirst du tun?"); 
    addnav("Spende etwas","forest.php?op=spenden");
    addnav("Den Tempel verlassen","forest.php?op=verlassen");
$session[user][specialinc]="tempel.php"; 
}
else if ($HTTP_GET_VARS[op]=="verlassen"){    
	output("`@Du l��t den alten, bauf�lligen Tempel hinter dir.");
	$session[user][specialinc]="";
	addnav("Zur�ck in die weite Welt","forest.php");	
}
else if ($HTTP_GET_VARS[op]=="spenden"){    
$session[user][specialinc]="tempel.php"; 
addnav("100 Goldst�cke spenden","forest.php?op=spendeneingang&betrag=100");
addnav("500 Goldst�cke spenden","forest.php?op=spendeneingang&betrag=500");
addnav("1000 Goldst�cke spenden","forest.php?op=spendeneingang&betrag=1000");
addnav("5000 Goldst�cke spenden","forest.php?op=spendeneingang&betrag=5000");
addnav("Doch nichts spenden","forest.php?specialinc=");
output("Du hast ".($session[user][tempelgold]>0?"bereits zuvor":"noch nicht")." in diesem Tempel gespendet.`n Wieviele Goldst�cke spendest du f�r die Renovierung des Tempels?",true);
}
else if ($HTTP_GET_VARS[op]=="spendeneingang"){
if ($HTTP_GET_VARS[betrag]>$session[user][gold])

	{
		output("`@Tja, das hast du dir wohl so gedacht. Soviel Gold hast du gar nicht dabei. Wenn das mal hoffentlich nicht die G�tter bemerkt haben.`n`n");
		output("Du verl�sst den Tempel, bevor die G�tter auf deinen kleinen Verz�hler aufmerksam werden.");
		$session[user][specialinc]=""; 
		addnav("Zur�ck in die weite Welt","forest.php");
	}
if ($HTTP_GET_VARS[betrag]<=$session[user][gold])
	{
		$betrag=$HTTP_GET_VARS[betrag];
		output("`^`bDu spendest `&$betrag`^ Gold f�r die Tempelrenovierung. ");
		debuglog("spendete $betrag Gold f�r die Tempelrenovierung");
		$session[user][tempelgold]+=$betrag;
		$session[user][gold]-=$betrag;
		output("Die Gottheit, der der Tempel geweiht ist, hat deine Spende registriert.`b");
		$session[user][specialinc]="";
		addnav("Den Tempel verlassen","forest.php");
if($session[user][tempelgold] >= $spendenbetrag) 
	{
	output("`@Als du die Goldm�nzen in den Opfer stock wirfst, ert�nt pl�tzlich ein donnern. Anscheinend hat die Gottheit, der der Tempel geweiht ist, deine gro�z�gigen Gaben bemerkt.`n`n");
	switch(e_rand(1,8))
		{
          case 1:
              output("`@Vor dir erscheint die Gottheit, der der Tempel geweiht ist, n�mlich `^$gott_gem`@. Das Gl�ck scheint dir hold zu sein, denn du erh�lst f�r deine Spenden `$5 Edelsteine`@!");
	$session[user][gems]+=5;
	$session[user][tempelgold]=0;
	addnews("`%".$session[user][name]."`7 wurde in einem Tempel von $gott_gem mit gro�em steinernen Reichtum beschenkt.");
                break;
          case 2:
              output("`@Vor dir erscheint die Gottheit, der der Tempel geweiht ist, n�mlich `^$gott_defense`@. Mit g�ttlicher Kraft w�chst deine `$Verteidigungsst�rke`@ dauerhaft, als Dank f�r deine Spenden!");
	$session[user][defence]+=2;
	$session[user][tempelgold]=0;
	addnews("`%".$session[user][name]."`7s Haut wurde in einem Tempel von $gott_defense widerstandsf�higer gemacht.");
                break;
          case 3:
              output("`@Vor dir erscheint die Gottheit, der der Tempel geweiht ist, n�mlich `^$gott_attack`@. Mit g�ttlicher Kraft w�chst deine `$Angriffssst�rke`@ dauerhaft, als Dank f�r deine Spenden!");
	$session[user][attack]+=2;
	$session[user][tempelgold]=0;
	addnews("`%".$session[user][name]."s`7 Muskeln wurden in einem Tempel von $gott_attack gest�rkt.");
                break;
          case 4:
              output("`@Vor dir erscheint die Gottheit, der der Tempel geweiht ist, n�mlich `^$gott_hp`@. Dein Schicksal, zus�tzliche `$Trefferpunkte`@ dauerhaft zu besitzen, erf�llt sich als Dank f�r deine Spenden!");
	$session[user][maxhitpoints]+=2;
	$session[user][tempelgold]=0;
	addnews("`%".$session[user][name]."`7 wurde in einem Tempel von $gott_hp mit erh�hter Lebenskraft versehen.");
                break;
          case 5:
              output("`@Vor dir erscheint die Gottheit, der der Tempel geweiht ist, n�mlich `^$gott_fight`@. Mit g�ttlicher Kraft darfst du am heutigen Tag viele `$Kampfrunden`@ mehr bestreiten, als Dank f�r deine Spenden!");
	$session[user][turns]+=10;
	$session[user][tempelgold]=0;
	addnews("`%".$session[user][name]."`7 wurde in einem Tempel von $gott_fight mit neuen Kampfrunden gesegnet.");
                break;
          case 6:
              output("`@Vor dir erscheint die Gottheit, der der Tempel geweiht ist, n�mlich `^$gott_charm`@. Mit g�ttlicher Kraft siehst du wesentlich besser aus. Du erh�lst `$4 Charmepunkte`@ als Dank f�r deine Spenden!");
	$session[user][charm]+=4;
	$session[user][tempelgold]=0;
	addnews("`%".$session[user][name]."`7 wurde in einem Tempel von $gott_charm zu einem besser aussehenderen Menschen gemacht.");
                break;
          case 7:
              output("`@Vor dir erscheint die Gottheit, der der Tempel geweiht ist, n�mlich `^$gott_hurt`@. Was hast du dir nur dabei gedacht, diese Gottheit zu beschw�ren, die f�r ihre Ausraster und Schl�gereien ber�hmt ist? Nach einem harten `$ Schlag`@ erwachst du aus einer Ohnmacht und hast fast alle Trefferpunkte verloren.");
	$session[user][hitpoints]=1;
	$session[user][tempelgold]=0;
	addnews("`%".$session[user][name]."`7 wurde in einem Tempel von $gott_hurt schwer verletzt. Man sollte halt nicht mit gef�hrlichen G�ttern herumspielen.");
                break;
          case 8:
              output("`@Vor dir erscheint die Gottheit, der der Tempel geweiht ist, n�mlich `^$gott_kill`@. Was hast du dir nur dabei gedacht, eine Gottheit zu beschw�ren, die nichts anderes zu tun hat, als alle Lebewesen in ihrer Reichweite zu t�ten? $gott_kill ber�hrt dich einmal kurz und dann ist es mit dir vorbei!");
	$session[user][hitpoints]=0;
	$session[user][tempelgold]=0;
	addnews("`%".$session[user][name]."`7 wurde in einem Tempel von $gott_kill get�tet. Man sollte halt nicht mit gef�hrlichen G�ttern herumspielen.");
                break;
		} //switch
	} // ben�tigten betrag erreicht?
	} //spendeneingang
$session[user][specialinc]=""; 
}
        page_footer(); 
?>