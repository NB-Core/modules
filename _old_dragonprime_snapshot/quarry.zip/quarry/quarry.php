<?php
	global $session;
	$op = httpget('op');
	$page = httpget('page');
	page_header("The Quarry");
	require_once("lib/taunt.php");
	$blockpay = get_module_setting("blockpay");
	$ruler=get_module_setting("ruler");
	if (get_module_setting("leveladj")==1){
		$blockpay*=$session['user']['level'] / 15;
		$blockpay=round($blockpay);
	}
if (is_module_active('masons')) {
	//This sets autorecruiting in the Quarry based on the current number of masons
	if (get_module_setting("recruiting","masons")==1){
		if (get_module_setting("masonnum","masons")<=get_module_setting("autozero","masons")) set_module_setting("rarity",0,"masons");
		if ((get_module_setting("masonnum","masons")>get_module_setting("autozero","masons"))&&(get_module_setting("masonnum","masons")<=get_module_setting("autoone","masons"))) set_module_setting("rarity",1,"masons");
		if ((get_module_setting("masonnum","masons")>get_module_setting("autoone","masons"))&&(get_module_setting("masonnum","masons")<=get_module_setting("autotwo","masons"))) set_module_setting("rarity",2,"masons");
		if (get_module_setting("masonnum","masons")>get_module_setting("autotwo","masons")) set_module_setting("rarity",3,"masons");
	}
}
if (is_module_active('lostruins') && get_module_setting("usequarry")==0) {
	if (get_module_setting("blocksleft")==round((get_module_setting("blockmin"))/2)) {
		addnews("%s`% discovered that `3T`@he `3Q`@uarry`% is under siege by `)S`&tone `)G`&iants`%!",$session['user']['name']);
		debuglog ("was the first to notice the quarry was under siege.");
		set_module_setting("underatk",1);
		increment_module_setting("blocksleft",-3);
		set_module_setting("giantleft",get_module_setting("numbgiant"));
	}
	if (get_module_setting("blocksleft")<=0) {
		if (get_module_setting("newsclosed")==0) addnews("`n`@T`3he %s`& `@Q`3uarry `@o`3f `@G`3reat `@S`3tone `@in the village of %s `@has run out of stone and has been `\$closed`@.`n",get_module_setting("quarryfinder"),get_module_setting("quarryloc"));
		set_module_setting("newsclosed",1);
		set_module_setting("quarryclosed",0);
		debuglog ("was the first to notice the quarry was empty.");
		$sql = "UPDATE ".db_prefix("module_userprefs")." SET value=0 WHERE setting='firstq' AND modulename='quarry'";
		db_query($sql); 
		set_module_setting("quarryfound",0,"lostruins");
	}
}

if ($op=="enter") {
	if (get_module_setting("sgcount")>=get_module_setting("giantatk")) {
		set_module_setting("underatk",1);
		set_module_setting("giantleft",get_module_setting("numbgiant"));
		set_module_setting("sgcount",0);
	}
	if (get_module_setting("giantleft")<=0) {
		set_module_setting("underatk",0);
		debuglog("was the first to notice the giant siege was over.");
	}  
	if ((get_module_setting("underatk")==1) && (get_module_pref("sgfought")==0)) {
		set_module_pref("sgfought",1);
		output("`n`c`b`)S`&tone `)G`&iant `\$A`&ttack`c`b`n");
		output("`%A most desperate situation has occurred! `@T`3he `@Q`3uarry`% is under attack by a band of very angry `)S`&tone `)G`&iants`%!!  Before you have a chance to get away, you're dragged into combat.`n`n");
		output("Soon you find yourself engaged in a life or death battle with ");
		switch(e_rand(1,10)){
			case 1: case 2: case 3: case 4://small giant
				output("one of the `)S`&maller `)S`&tone `)G`&iants`%!");
				set_module_pref("monster",6);
			break;
			case 5: case 6: case 7://medium giant
				output("one of the `)M`&edium `)S`&ized `)S`&tone `)G`&iants`%!");
				set_module_pref("monster",7);
			break;
			case 8: case 9://large giant
				output("a really `)B`&ig `)S`&tone `)G`&iant`% of the group!");
				set_module_pref("monster",8);
			break;
			case 10: //huge giant
				output("the `)B`&iggest `)B`&addest `)S`&tone `)G`&iant`% of the group!");
				set_module_pref("monster",9);
			break;
		}
		addnav("`)S`&tone `)G`&iant `\$A`&ttack","runmodule.php?module=quarry&op=attack");
	}elseif ((get_module_setting("underatk")==1) && (get_module_pref("sgfought")==1)) {
		output("`n`c`b`)S`&tone `)G`&iant `\$A`&ttack`c`b`n");
		output("`%Before you get to `@T`3he `@Q`3uarry`%, you remember that it's under siege by `)S`&tone `)G`&iants`%.`n`nMaybe it will be safer to come back tomorrow.`n`n");
		addnav("V?(V) Return to Village","village.php");
	}else{
		addnav("V?(V) Return to Village","village.php");
		if (is_module_active('lostruins') && get_module_setting("usequarry")==0) {
			output("`n`c`b`@T`3he %s `@Q`3uarry`c`b`n",get_module_setting("quarryfinder"));
		}else{
			output("`n`c`b`@T`3he `@Q`3uarry`c`b`n");
		}
		if (get_module_pref ("firstq")==0){
			set_module_pref ("firstq",1);
			if (is_module_active('lostruins') && get_module_setting("usequarry")==0) {
				output("`%You walk to the newly discovered quarry and see a dedication sign.  You lean in to read the beautiful inscription:`n`n");
				output("`^By ordinance of `&%s`^, this site is dedicated in honor of `b%s`b`^ for discovering the quarry.  May we all prosper because of the wonders inside!`n`n",$ruler,get_module_setting("quarryfinder"));
			}
			output("`%You wonder around a little to get a lay of the land.  It's clear that this is a very nice quarry full of the most wonderful stone; useful for solid construction.");
			output("You see two women looking at a large piece of paper.  One is wearing a blue hardhat, the other wearing a purple one.");
			output("They are pointing to different areas in the quarry then back at the blueprint.  Your curiosity gets the best of you and you wander over to them.`n`n");
			output("The woman in the blue hat looks up at you.  She is stunningly beautiful.  She has soft brown hair that falls to her shoulders and has amazing hazel eyes.");
			output("`n`n`^'Hello! My name is `&Slatemaker `\$S`7h`&y`\$l`7l`&e`^.  I am in charge of the quarry operation.  My friend here, `!Engineer `\$Uraal`^, is helping me plan our next cleave into the bedrock.'`n`n");
			output("`%Upon further examination, you realize `!Engineer `\$Uraal`% isn't wearing a  regular hardhat but rather is dressed in a purple hard-tophat.");
			output("Her lightheartedness is readily apparent in her demeanor and you realize instantly that you would gladly call her your friend. `n`n `@'If you're looking for some work, we could use your help.");
			output("I'll be honest though, it is definately no piece of pie, and it's a lot harder than hugging a tree.  But we've had some lucky workers lately that have left here very wealthy so far.'`n`n");
			output("`!Engineer `\$Uraal`% teaches you the basics of quarrying, including the use of the pick-axe and where your hard-hat will be stored.  After she feels comfortable with your ability, she looks at you expectantly.`n`n");
			output("`@'Are you ready to work?'`n`n");
			addnav("The Rules","runmodule.php?module=quarry&op=rules");
		}else{
			output("`%'Welcome back to the `@T`3he `@Q`3uarry`%. Are you ready to get some work done?'");
			if (get_module_pref("usedqts")<get_module_setting("quarryturns")) addnav("Work the Quarry","runmodule.php?module=quarry&op=work");
			addnav("Review the Rules","runmodule.php?module=quarry&op=rules");
			addnav("Office","runmodule.php?module=quarry&op=office");
		}
	}
}
if($op=="rules"){
	addnav("V?(V) Return to Village","village.php");
	if (is_module_active('lostruins') && get_module_setting("usequarry")==0) output("`n`c`b`@T`3he %s `@Q`3uarry `@R`3ules`c`b`n",get_module_setting("quarryfinder"));
	else output("`n`c`b`@T`3he `@Q`3uarry `@R`3ules`c`b`n");
	output("`&Slatemaker `\$S`7h`&y`\$l`7l`&e`% takes you over to the board showing `@T`3he `@R`3ules`%. In large print you read the following:`n`n");
	output("`#1. NO Running!  This is not a playground.  `@T`#he `@Q`#uarry can be deadly.  Please be careful at all times.`n`n");
	output("`32. Hardhats must be worn at all times.`n`n");
	output("`#3. Due to the dangers, consider purchasing insurance at the office.  It's available every day.`n`n");
	output("`34. You may work the `@Q`3uarry up to`& %s times a day`3.`n`n",get_module_setting("quarryturns"));
	output("`#5. Your goal is to quarry`) Blocks of Stone`#.  You can complete `)one block`# in `@one turn`#.`n`n");
	output("`36. All of your work is carefully tracked and an updated ledger is available for your review at the office.`n`n");
	output("`#7. Stone may be sold at the office to `&Slatemaker `\$S`7h`&y`\$l`7l`&e`#.  Please see her for the current price being offered.`n`n");
	output("`38. Stone that is quarried here may have other uses.  Please check with `&%s`3 or his `&Staff`3.`n`n",$ruler);
	if (is_module_active('lostruins') && get_module_setting("usequarry")==0) output("`#9. The Quarry is probably going to run out of quality stone at some time. Please check at the office for when this may happen.`n`n");
	if (get_module_pref("usedqts")<get_module_setting("quarryturns")) addnav("Work the Quarry","runmodule.php?module=quarry&op=work");
	addnav("Office","runmodule.php?module=quarry&op=office");
}
if($op=="work"){
	quarry_quarrynavs();
	if (is_module_active('lostruins') && get_module_setting("usequarry")==0) output("`n`c`b`@T`3he %s `@Q`3uarry`c`b`n",get_module_setting("quarryfinder"));
	else output("`n`c`b`@T`3he `@Q`3uarry`c`b`n");
	if (get_module_setting("blocksleft")<=0) {
		output("`^'I'm so sorry, but this `@Q`3uarry`^ is empty.  It's going to be closed down.'`n`n'Until a new one opens up, you won't be able to sell any of your `)Blocks of Stone`^ once you leave, so please consider selling them now if you're interested.'`n");
		addnews("%s`% discovered that `@T`3he `@Q`3uarry`% was out of `)stone`%.",$session['user']['name']);
		debuglog("discovered that the quarry was going to be closed.");	
		blocknav("runmodule.php?module=quarry&op=work");
	}elseif ($session['user']['turns']<1){
		output("`%Whoa there.  You're too exhausted to work the quarry.  Why don't you try again when you've got the strength for some heavy labor?");
	}elseif (get_module_pref("usedqts")>=get_module_setting("quarryturns")){
		output("`%'You've spent enough time working `@T`3he `@Q`3uarry`%.  Try back tomorrow.'");
	}else{
		output("`%You grab your hardhat and get to work.`n`n");
		increment_module_pref("usedqts",1);
		$session['user']['turns']--;
		switch(e_rand(1,30)){
			case 1: case 2: case 3: 
				if (get_module_pref("seed","orchard")==15 && get_module_setting("alloworchard")==1) redirect("runmodule.php?module=orchard&op=quarry");
			case 4: case 5: case 6: case 7:	case 8:
				output("Despite your best efforts to get a decent `)block of stone`%, you`b`\$ Fail`b`%.`n`n`@T`3he `@Q`3uarry`% is a lot harder to work than you thought.");
				if (is_module_active('lostruins') && get_module_setting("usequarry")==0) if (get_module_setting("blocksleft")<10) output("`n`n`@T`3he `@Q`3uarry`% is looking low on stone and may have to be shut down soon.`n`n");
			break;
			case 9: case 10: case 11: case 12:
				output("Not bad.  Not bad at all. You finish `)One Block of Stone`% in `@one turn`%!`n`n");
				quarry_completeblock();	
			break;
			case 13:
				$gemenum=get_module_setting("case13ge");
				if ($gemenum==1) $gemfind=(e_rand(1,2));
				if ($gemenum==2) $gemfind=(e_rand(2,3));
				if ($gemenum==3) $gemfind=(e_rand(3,5));
				if ($gemenum==4) $gemfind=(e_rand(5,10));
				output("You carve out `)One Block of Stone`% in `@one turn`%.`n`nWhen you finish, you notice that the stone that you carved it out of has a natural `\$p`^o`@c`#k`!e`%t `\$o`^f `@g`#e`!m`%s`\$!`%`n`n");
				output("You collect `b%s gem%s`b!!`n`n",$gemfind,translate_inline($gemfind>1?"s":""));
				$session['user']['gems']+=$gemfind;
				quarry_completeblock();
			break;
			case 14:
				output("You finish the work and get a credit for `)One Block of Stone`%.`n`n  But the work was invigorating and you get to spend an extra turn in `@T`3he `@Q`3uarry`% if you would like to, in addition to `@3 extra forest fights`%!`n`n");
				increment_module_pref("usedqts",-1);
				$session['user']['turns']+=3;
				quarry_completeblock();	
			break;
			case 15:
				output("Confused and disoriented by the heat, you end up sitting down and grabbing a `#bottle of water`% to drink.`n`n You notice that there's something funny about the taste.`#`n`n");
				switch(e_rand(1,3)){
					case 1:
						output("Tasty!  And gives you a nice little hitpoint boost!");
						$session['user']['hitpoints']+=20;
					break;
					case 2:
						if ($session['user']['hitpoints']==1) {
							output("Nope... it's just water.  Ha! you thought something interesting was going to happen!");
						}else{
							output("Eww! There's a worm on the bottom of the bottle! That just turns your stomach, and causes you to
								`\$lose some hitpoints`#!");
							if ($session['user']['hitpoints']<=20) {
								$session['user']['hitpoints']=1;
							}else{
								$session['user']['hitpoints']-=20;
							}
						}
					break;
					case 3:
						output("Nope... it's just water.  Ha! you thought something interesting was going to happen!");
					break;
				}
				output("`n`n`%Unfortunately, you aren't able to complete `)Block of Stone`% this turn.`n`n");
				if (is_module_active('lostruins') && get_module_setting("usequarry")==0) if (get_module_setting("blocksleft")<10) output("`n`n`@T`3he `@Q`3uarry`% is looking low on stone and may have to be shut down soon.`n`n");
			break;
			case 16:
				output("You stand before your finished `)Block of Stone`% and give it a little tap proving how impressive you are. The `)stone `%falls on top of you.`n`n  You`$ lose all hitpoints`% except `\$one`%, but you were able to finish the `)stone!");
				$session['user']['hitpoints']=1;
				quarry_completeblock();	
			break;
			case 17:
				output("You wander around aimlessly pretending you are a teamster.  Since you aren't, you don't get any work done and don't get paid, either.`n`nSo surly!!");
				if (is_module_active('lostruins') && get_module_setting("usequarry")==0) if (get_module_setting("blocksleft")<10) output("`n`n`@T`3he `@Q`3uarry`% is looking low on stone and may have to be shut down soon.`n`n");
			break;
			case 18:
				output("With some pretty impressive pick-axe work, you cleave the stone like butter.  In fact, you are able to cut `)Two Blocks of Stone`% in `@one turn`%!  Very nice work!");
				increment_module_pref("blocks",2);
				increment_module_pref("blockshof",2);
				if (is_module_active('lostruins') && get_module_setting("usequarry")==0) {
					//Intentionally only subtract 1 block even though player gets credit for 2.  This is for the Giant Siege check.  Trust me here.
					increment_module_setting("blocksleft",-1);
					if (get_module_setting("blocksleft")<10) output("`n`n`@T`3he `@Q`3uarry`% is looking low on stone and may have to be shut down soon.`n`n");
				}
			break;
			case 19:
				output("`%Thinking that you know everything there is to know, you start hacking away at a wonderful `)Block of Stone`%.`n`n You stand up full of pride to show your work when `!Engineer `\$Uraal`% taps you on the shoulder.");
				output("`n`n`@'I'm so sorry, but that was a `)Block of Stone`@ that was already completed.  We have to charge you for that mistake.'`%`n`n");
				if ($session['user']['gold']<750){
					output("You hand over `^all your money");
					$session['user']['gold']=0;
				}else{
					output("You hand over `^750 gold");
					$session['user']['gold']-=750;
				}
				output("`%with a sheepish look. `n`n You `@lose a turn`%.");
				if (is_module_active('lostruins') && get_module_setting("usequarry")==0) {
					increment_module_setting("blocksleft",-1);
					if (get_module_setting("blocksleft")<10) output("`n`n`@T`3he `@Q`3uarry`% is looking low on stone and may have to be shut down soon.`n`n");
				}
			break;
			case 20:
				increment_module_pref("blocks",1);
				increment_module_pref("blockshof",1);
				output("`%Your pick-axe flies and you set free a perfect `)Block of Stone`%. `n`nYou complete your work on `)One Block of Stone`% in `@one turn`%. You puff your chest with pride and show the stone off to all the people around you.`n`nYou think one shady looking character is particularly interested in your work.`n`n");
				$random=2;
				if (is_module_active('masons')) {
					if (get_module_setting("rarity","masons")<=0) $random=15;
					if (get_module_setting("rarity","masons")==1) $random=2;
					if (get_module_setting("rarity","masons")==2) $random=4;
					if (get_module_setting("rarity","masons")==3) $random=6;
					if (get_module_setting("rarity","masons")>=4) $random=1;
				}
				switch(e_rand(1,$random)){
					case 1: case 3: case 4: case 5: case 6:
						output("However, he turns away.`n`n");
					break;
					case 2: case 7: case 8: case 9: case 10: case 11: case 12: case 13: case 14: case 15:
						output("`4So you take a couple of steps closer to him...`n`n");
						switch(e_rand(1,$random)){
							case 1: case 3: case 4: case 5: case 6:
								output("`7And he quickly retreats.  It must have been your imagination.`n`n");
							break;
							case 2: case 7: case 8: case 9: case 10: case 11: case 12: case 13: case 14: case 15:
								if (is_module_active('masons')) {
									if (get_module_pref("masonmember","masons")==1){
										output("`%He smiles and notices your tattoo. `7`n`n'This is a gift from `&T`)he `&S`)ecret `&O`)der `&o`)f `&M`)asons`7.  May you experience excellence in everything you do.`n`n");
										output("`%You open a small bag and find it is filled with `bgems`b and `^gold`%.`n`n");
										$gemenum=get_module_setting("case20ge");
										if ($gemenum==1) $gemfind=(e_rand(1,2));
										if ($gemenum==2) $gemfind=(e_rand(2,3));
										if ($gemenum==3) $gemfind=(e_rand(3,5));
										if ($gemenum==4) $gemfind=(e_rand(5,10));
										output("You collect `b%s gem%s`b and `^250 gold`%.",$gemfind,translate_inline($gemfind>1?"s":""));
										$session['user']['gems']+=$gemfind;
										$session['user']['gold']+=250;
									}else{
										output("`%He approaches you and stares at you.  Then he extends his hand and asks if he could have a 'private' word with you.");
										addnav("Private Chat","runmodule.php?module=quarry&op=private");
									}
								}else{
									output("`%The man smiles and hands you a `bbag full of gems`b!!`n`n `7'I am one of `&%s's Envoys`7 and I am giving you this token of appreciation from `&%s`7 from your excellent work.  Have a great day!'`n`n",$ruler,$ruler);
									$gemenum=get_module_setting("case20ge");
									if ($gemenum==1) $gemfind=(e_rand(1,2));
									if ($gemenum==2) $gemfind=(e_rand(2,3));
									if ($gemenum==3) $gemfind=(e_rand(3,5));
									if ($gemenum==4) $gemfind=(e_rand(5,10));
									if ($gemenum==5) $gemfind=(e_rand(8,15));
									output("`n`n`%You count out and find that you've received `b%s gem%s`b!!!",$gemfind,translate_inline($gemfind>1?"s":""));
									$session['user']['gems']+=$gemfind;
								}
							break;
						}
					break;
				}
				if (is_module_active('lostruins') && get_module_setting("usequarry")==0) {
					increment_module_setting("blocksleft",-1);
					if (get_module_setting("blocksleft")<10) output("`n`n`@T`3he `@Q`3uarry`% is looking low on stone and may have to be shut down soon.`n`n");
				}
			break;
			case 21:
				output("`n`c`^Somebody went under a dock`nAnd there they saw a rock`nIt wasn't a rock`nIt was a `)Rock `4Lobster`^!!`c");
				set_module_pref("monster",5);
				addnav("`)Rock `4Lobster `\$Attack","runmodule.php?module=quarry&op=attack");
				quarry_blocknavs();
			break;
			case 22:
				output("`%You split one of the giant stones and discover a strange fossil inside.  You blow on it and try to clean it off...`n`n  Your breath causes the `^F`Qossil `^D`Qinosaur`% to come to life!!");
				set_module_pref("monster",4);
				addnav("`^F`Qossil `^D`Qinosaur `\$Attack","runmodule.php?module=quarry&op=attack");
				quarry_blocknavs();
			break;
			case 23:
				output("`%Soon enough, you finish your work.  `!Engineer `\$Uraal`% hands you a voucher for `)One Block of Stone`%.  As soon as you take the voucher though, you hear panicked cries of workers all around you. `n`n It seems like your old nemesis, `qG`^reat `qB`^ig `qB`^ear`%, is back to cause more trouble!`n`n");
				set_module_pref("blocks",get_module_pref("blocks")+1);
				set_module_pref("blockshof",get_module_pref("blockshof")+1);
				set_module_pref("monster",3);
				addnav("Bear`$ Fight","runmodule.php?module=quarry&op=attack");
				quarry_blocknavs();
			break;
			case 24:
				output("`%Your pick-axe work is quite admirable.  However, before you get more than a couple of swings in, the quarry workers start to shout and panic.  On of the large boulders right above you is coming lose!`n`n  `@`b'Look out below!!'`b`%`n`n  You will have to depend on your razor sharp reflexes to save you!");
				output("You will be able to do this by `\$'fighting'`% your way to safety!");
				set_module_pref("monster",2);
				addnav("`\$Stone Collapse!","runmodule.php?module=quarry&op=attack");
				quarry_blocknavs();
			break;
			case 25:
				output("`%You start to work the quarry and here a voice from above shout `@`b'Falling Rock!'`b`%`n`n  You will have to depend on your razor sharp reflexes to dodge the falling rocks!  You will be able to do this by `\$'fighting'`% your way to safety!");
				set_module_pref("monster",1);
				addnav("`\$Avalanche!","runmodule.php?module=quarry&op=attack");
				quarry_blocknavs();
			break;
			case 26:
				$gold=get_module_setting("case26g");
				$randgold=round(e_rand($gold,$gold/2));
				output("You carve out `)One Block of Stone`% in `@one turn`%.`n`nWhen you finish, you notice that the stone that you carved it out of has a natural `^pocket of gold`%!`n`n You collect `^%s Gold`%!!`n`n",$randgold);
				$session['user']['gold']+=$randgold;
				quarry_completeblock();
			break;
			case 27:
				switch(e_rand(1,4)){
					case 1: case 2: case 3:
						output("Despite your best efforts to get a decent `)block of stone`%, you fail.`n`n`@T`3he `@Q`3uarry`% is a lot harder to work than you thought.");
					break;
					case 4:
						switch(e_rand(1,4)){
							case 1: case 2: case 3:
								output("You stand before your finished `)Block of Stone`% and give it a little tap proving how impressive you are.`n`nThe `)stone `%falls on top of you.`n`n  You`$ lose all hitpoints`% except `\$one`%, but you were able to finish the `)stone`%!");
								$session['user']['hitpoints']=1;
								quarry_completeblock();
							break;
							case 4:
								$exploss = round($session['user']['experience']*.05);
								output("Everything seems to be going so well, when suddenly a huge boulder falls off of the cliff above you.`n`nBefore you get a chance to escape, you are crushed under it's weight.`n`nYou are `\$MOSTLY dead`%.`n`n");
								output("`b`4You lose `#%s experience`4.`b`n`n",$exploss);
								output("`b`%You lose `^All Your Gold`%.`n`n");
								output("`b`%You are done visiting `@T`3he `@Q`3uarry`% for today.`n`n");
								addnews("%s`% was found `\$MOSTLY Dead`% but still alive at `@T`3he `@Q`3uarry`%.",$session['user']['name']);
								$session['user']['experience']-=$exploss;
								$session['user']['hitpoints'] = 1;
								$session['user']['gold']=0;
								set_module_pref("usedqts",get_module_setting("quarryturns"));
								blocknav("runmodule.php?module=quarry&op=office");
								blocknav("runmodule.php?module=quarry&op=work");
							break;
						}
					break;
				}
			break;
			case 28:
			case 29:
				output("You finish up with your work and collect your voucher for `)One Block of Stone`%.  Since you did it in record time, you find yourself getting a little bored.");
				output("You wander around and see a group of kids playing around an`q ant hill`% with a magnifying glass.`n`n  What do you do?`n`n`\$1.  Help Burn the Ants, showing better and more efficient methods.`n`^2.Wander off.");
				output("It's not your problem.`n`@3. Intervene to stop the little hooligans!`n`n");
				addnav("`\$Burn Ants","runmodule.php?module=quarry&op=burn");
				addnav("`^Wander Off","runmodule.php?module=quarry&op=wander");
				addnav("`@Stop them","runmodule.php?module=quarry&op=stopthem");
				quarry_completeblock();
				quarry_blocknavs();
			break;
			case 30:
				output("As you finish your work, you give one big swing to the ground and suddenly hear a loud gushing noise.`n`n  You look down to see that you've hit a `#natural spring`%!!`n`n");
				output("Well, you don't get to collect your `)stone`% because it's now about 10 feet underwater.`n`nYou almost drown and `\$lose all your hitpoints except seven`%!`n`n");
				output("(I figured you're probably getting sick of only having 1 hitpoint after all these things happen to you.)`n`n");
				$session['user']['hitpoints']=7;
				if (is_module_active('lostruins') && get_module_setting("usequarry")==0) {
					$beforeblock=get_module_setting("blocksleft");
					if ($beforeblock>10) increment_module_setting("blocksleft",-3);
					debuglog("Caused 3 blocks to be covered underwater.");
					//double check to see if this avoided the giant siege
					$afterblock=get_module_setting("blocksleft");
					$hblockmin=get_module_setting("blockmin")/2;
					if ($beforeblock>$hblockmin && $afterblock<$hblockmin) {
						set_module_setting("underatk",1);
						set_module_setting("giantleft",get_module_setting("numbgiant"));
					}	
					output("This section of `@T`3he `@Q`3uarry`% will no longer be useful.`n`n");
					if (get_module_setting("blocksleft")<10) output("`@T`3he `@Q`3uarry`% is looking low on stone and may have to be shut down soon.`n`n");
				}
			break;
		}	
	}
}
if ($op=="burn") {
	if (is_module_active('alignment')) set_module_pref("alignment",get_module_pref("alignment","alignment")-3,"alignment");
	output("`n`c`b`\$Burning Ants`c`b`n");
	output("`n`%You nudge the children and grab the magnifying glass. `n`nYou feel a little more `\$evil`%.`n`n Before you know it, you've got 5 ants on fire all at once! `n`nThe 'Ooohs' and 'Ahhhs' of the children make you feel `&more charming`%!!");
	$session['user']['charm']+=1;
	quarry_quarrynavs();
}
if ($op=="wander") {
	if (is_module_active('alignment')){
		if (get_module_pref("alignment","alignment")>=get_module_setting("goodalign","alignment")) set_module_pref("alignment",get_module_pref("alignment","alignment")-3,"alignment");
		if (get_module_pref("alignment","alignment")<=get_module_setting("evilalign","alignment")) set_module_pref("alignment",get_module_pref("alignment","alignment")+3,"alignment");
	}
	output("`n`c`b`^Wander Off`c`b`n");
	output("`%This really isn't your problem.  You feel a little more `^neutral`% about the world.`n`n  However, as wander off, you look down to spot a `bgem`b!! How cool!`n`n");
	$session['user']['gems']+=1;
	quarry_quarrynavs();
}
if ($op=="stopthem") {
	if (is_module_active('alignment')) set_module_pref("alignment",get_module_pref("alignment","alignment")+3,"alignment");
	output("`n`c`b`@Save the Ants`c`b`n");
	output("`n`%You rescue those poor little ants! You push the dumb punky kids out of the way and save the colony!`n`n The ants notice how you've saved them and bring up a bottle of wonderful elixir. `n`n ");
	if ($session['user']['hitpoints']<$session['user']['maxhitpoints']){
		$session['user']['hitpoints']=$session['user']['maxhitpoints'];
		output("You drink it down and your `\$hitpoints are restored to full`%!!");
	}else{
		$session['user']['maxhitpoints']+=1;
		output("You drink it down and `\$gain one permanent hitpoint`%!!");
	}
	quarry_quarrynavs();
}
if ($op=="private") {
	output("`n`c`b`&T`)he `&S`)ecret `&O`)rder `&o`)f `&M`)asons`c`b`n");
	output("`7'We are very honored to offer you membership into our `&S`)ecret `&O`)rder`7.  If you would like to join, you will find our hidden location revealed to you in %s.  Go there and present this `&I`)nvitation `&S`)croll`7.  You will receive further instructions when you get there.'`n`n",get_module_setting("masonsloc","masons"));
	output("`%You happily accept the scroll.`n`n`7'Just one warning.  Our offer is for today only.  If you don't show up, you may not get another chance.'`7");
	set_module_pref("offermember",1,"masons");
	debuglog("was given an invitation to join the Masons Order.");
	quarry_quarrynavs();
	if (is_module_active('lostruins') && get_module_setting("usequarry")==0) {
		increment_module_setting("blocksleft",-1);
		if (get_module_setting("blocksleft")<10) output("`n`n`@T`3he `@Q`3uarry`% is looking low on stone and may have to be shut down soon.`n`n");
	}
}
if ($op=="attack") {
	if (get_module_pref("monster")==1){
		//falling rocks
		$dkb = round($session['user']['dragonkills']*.05);
		$name=translate_inline("`)Falling `&rocks");
		$weapon=translate_inline("`0terribly sharp `&edges");
		$badguy = array(
			"creaturename"=>$name,
			"creaturelevel"=>$session['user']['level'],
			"creatureweapon"=>$weapon,
			"creatureattack"=>$session['user']['attack'],
			"creaturedefense"=>$session['user']['defense'],
			"creaturehealth"=>round($session['user']['maxhitpoints']*1.1),
			"diddamage"=>0,
			"type"=>"debri");
		$session['user']['badguy']=createstring($badguy);
		$op="fight";
		$start=translate_inline("`n`^A small avalanche of rocks falls onto you!`n");
		$bname=translate_inline("`)A`&valanche!");
		$woff=translate_inline("`n`&The larger rocks keep falling.");
		$nodmg=translate_inline("`&You nimbly dodge one of the rocks.");
		apply_buff('littlerocks', array(
			"startmsg"=>$start,
			"name"=>$bname,
			"rounds"=>1,
			"wearoff"=>$woff,
			"minioncount"=>$session['user']['level'],
			"mingoodguydamage"=>0,
			"maxgoodguydamage"=>1+$dkb,
			"effectmsg"=>"`)You are hit by a rock for `\${damage}`) damage.",
			"effectnodmgmsg"=>$nodmg,
			"effectfailmsg"=>$nodmg,
		));
		$session['user']['badguy']=createstring($badguy);
		$op="fight";
	}elseif (get_module_pref("monster")==2){
		//Falling boulder
		$dkb = round($session['user']['dragonkills']*.07);
		$name=translate_inline("a `)Falling `&Boulder");
		$weapon=translate_inline(" `)crushing weight");
		$badguy = array(
			"creaturename"=>$name,
			"creaturelevel"=>$session['user']['level']+1,
			"creatureweapon"=>$weapon,
			"creatureattack"=>round($session['user']['attack']*1.1),
			"creaturedefense"=>round($session['user']['defense']*1.1),
			"creaturehealth"=>round($session['user']['maxhitpoints']*.5),
			"diddamage"=>0,
			"type"=>"stonefall");
		$smsg=translate_inline("`n`^A small avalanche of rocks falls onto you!`n");
		$bname=translate_inline("`)A`&valanche!");
		$woff=translate_inline("`n`&The larger rocks keep falling.");
		$nodmg=translate_inline("`&You nimbly dodge one of the rocks.");
		apply_buff('littlerocks', array(
			"startmsg"=>$smsg,
			"name"=>$bname,
			"rounds"=>1,
			"wearoff"=>$woff,
			"minioncount"=>$session['user']['level']+5,
			"mingoodguydamage"=>0,
			"maxgoodguydamage"=>1+$dkb,
			"effectmsg"=>"`)You are hit by a rock for `\${damage}`) damage.",
			"effectnodmgmsg"=>$nodmg,
			"effectfailmsg"=>$nodmg,
		));
		$session['user']['badguy']=createstring($badguy);
		$op="fight";
	}elseif (get_module_pref("monster")==3){
		//Bear
		$name=translate_inline("`qG`^reat `qB`^ig `qB`^ear");
		$weapon=translate_inline("`@its`% Claws");
		$badguy = array(
			"creaturename"=>$name,
			"creaturelevel"=>$session['user']['level']+1,
			"creatureweapon"=>$weapon,
			"creatureattack"=>round($session['user']['attack']*.85),
			"creaturedefense"=>round($session['user']['defense']*1.3),
			"creaturehealth"=>round($session['user']['maxhitpoints']),
			"diddamage"=>0,
			"type"=>"bear");
		$session['user']['badguy']=createstring($badguy);
		$op="fight";
	}elseif (get_module_pref("monster")==4){
		//Fossil Dinosaur
		$name=translate_inline("`^T`Qhe `^F`Qossil `^D`Qinosaur");
		$weapon=translate_inline("`^B`Qrittle `^C`Qlaws");
		$badguy = array(
			"creaturename"=>$name,
			"creaturelevel"=>$session['user']['level']+1,
			"creatureweapon"=>$weapon,
			"creatureattack"=>round($session['user']['attack']*1.1),
			"creaturedefense"=>round($session['user']['defense']*.7),
			"creaturehealth"=>round($session['user']['maxhitpoints']),
			"diddamage"=>0,
			"type"=>"fosdino");
		$session['user']['badguy']=createstring($badguy);
		$op="fight";
	}elseif (get_module_pref("monster")==5){
		//Rock Lobster
		$name=translate_inline("`4The `)Rock `4Lobster");
		$weapon=translate_inline("`)Rockin `4and `)Rollin `4Claws");
		$badguy = array(
			"creaturename"=>$name,
			"creaturelevel"=>$session['user']['level']+1,
			"creatureweapon"=>$weapon,
			"creatureattack"=>round($session['user']['attack']-2),
			"creaturedefense"=>round($session['user']['defense']*.95),
			"creaturehealth"=>round($session['user']['maxhitpoints']*.93),
			"diddamage"=>0,
			"type"=>"rocklobster");
		$session['user']['badguy']=createstring($badguy);
		$op="fight";
	}elseif (get_module_pref("monster")==6){
		//Small Stone Giant
		$dkb = round($session['user']['dragonkills']*.07);
		$name=translate_inline("`)S`&mall `)S`&tone `)G`&iant");
		$weapon=translate_inline("`0a pretty good sized boulder");
		$badguy = array(
			"creaturename"=>$name,
			"creaturelevel"=>$session['user']['level']+1,
			"creatureweapon"=>$weapon,
			"creatureattack"=>round($session['user']['attack']*.9),
			"creaturedefense"=>round($session['user']['defense']*.9),
			"creaturehealth"=>round($session['user']['maxhitpoints']*.9+2),
			"diddamage"=>0,
			"type"=>"smallstonegiant");
		$smsg=translate_inline("`n`^A small avalanche of rocks falls onto you!`n`n");
		$bname=translate_inline("`)A`&valanche!");
		$woff=translate_inline("The barrage of small rocks ends.");
		$ndmg==translate_inline("`&You nimbly dodge one of the rocks.");
		apply_buff('littlerocks', array(
			"startmsg"=>$smsg,
			"name"=>$bname,
			"rounds"=>1,
			"wearoff"=>$woff,
			"minioncount"=>$session['user']['level'],
			"mingoodguydamage"=>0,
			"maxgoodguydamage"=>1+$dkb,
			"effectmsg"=>"`)You are hit by a rock for `\${damage}`) damage.",
			"effectnodmgmsg"=>$ndmg,
			"effectfailmsg"=>$ndmg,
		));
		$session['user']['badguy']=createstring($badguy);
		$op="fight";
	}elseif (get_module_pref("monster")==7){
		//Medium Stone Giant
		$dkb = round($session['user']['dragonkills']*.08);
		$name=translate_inline("`)M`&edium `)S`&tone `)G`&iant");
		$weapon=translate_inline("`0a pretty good sized boulder");
		$badguy = array(
			"creaturename"=>$name,
			"creaturelevel"=>$session['user']['level'],
			"creatureweapon"=>$weapon,
			"creatureattack"=>round($session['user']['attack']),
			"creaturedefense"=>round($session['user']['defense']),
			"creaturehealth"=>round($session['user']['maxhitpoints']+4),
			"diddamage"=>0,
			"type"=>"mediumstonegiant");
		$smsg=translate_inline("`n`^A small avalanche of rocks falls onto you!`n`n");
		$bname=translate_inline("`)A`&valanche!");
		$woff=translate_inline("The barrage of small rocks ends.");
		$ndmg==translate_inline("`&You nimbly dodge one of the rocks.");
		apply_buff('littlerocks', array(
			"startmsg"=>$smsg,
			"name"=>$bname,
			"rounds"=>1,
			"wearoff"=>$woff,
			"minioncount"=>$session['user']['level']+1,
			"mingoodguydamage"=>0,
			"maxgoodguydamage"=>1+$dkb,
			"effectmsg"=>"`)You are hit by a rock for `\${damage}`) damage.",
			"effectnodmgmsg"=>$ndmg,
             "effectfailmsg"=>$ndmg,
		));
		$session['user']['badguy']=createstring($badguy);
		$op="fight";
	}elseif (get_module_pref("monster")==8){
		//Large Stone Giant
		$dkb = round($session['user']['dragonkills']*.09);
		$name=translate_inline("`)L`&arge `)S`&tone `)G`&iant");
		$weapon=translate_inline("`0a large boulder");
		$badguy = array(
			"creaturename"=>$name,
			"creaturelevel"=>$session['user']['level']+1,
			"creatureweapon"=>$weapon,
			"creatureattack"=>round($session['user']['attack']*1.1),
			"creaturedefense"=>round($session['user']['defense']*1.1),
			"creaturehealth"=>round($session['user']['maxhitpoints']*1.1+5,0),
			"diddamage"=>0,
			"type"=>"largestonegiant");
		$smsg=translate_inline("`n`^A small avalanche of rocks falls onto you!`n`n");
		$bname=translate_inline("`)A`&valanche!");
		$woff=translate_inline("The barrage of small rocks ends.");
		$ndmg==translate_inline("`&You nimbly dodge one of the rocks.");
		apply_buff('littlerocks', array(
			"startmsg"=>$smsg,
			"name"=>$bname,
			"rounds"=>1,
            "wearoff"=>$woff,
			"minioncount"=>$session['user']['level'],
			"mingoodguydamage"=>0,
			"maxgoodguydamage"=>2+$dkb,
			"effectmsg"=>"`)You are hit by a rock for `\${damage}`) damage.",
			"effectnodmgmsg"=>$ndmg,
			"effectfailmsg"=>$ndmg,
		));
		$session['user']['badguy']=createstring($badguy);
		$op="fight";
	}elseif (get_module_pref("monster")==9){
		//Huge Stone Giant
		$dkb = round($session['user']['dragonkills']*.1);
		$name=translate_inline("`)H`&uge `)S`&tone `)G`&iant");
		$weapon=translate_inline("`0an unbelievably huge boulder");
		$badguy = array(
			"creaturename"=>$name,
			"creaturelevel"=>$session['user']['level'],
			"creatureweapon"=>$weapon,
			"creatureattack"=>round($session['user']['attack']*1.15),
			"creaturedefense"=>round($session['user']['defense']*1.15),
			"creaturehealth"=>round($session['user']['maxhitpoints']*1.15+10,0),
			"diddamage"=>0,
			"type"=>"hugestonegiant");
		$smsg=translate_inline("`n`^A small avalanche of rocks falls onto you!`n`n");
		$bname=translate_inline("`)A`&valanche!");
		$woff=translate_inline("The barrage of small rocks ends.");
		$ndmg==translate_inline("`&You nimbly dodge one of the rocks.");
		apply_buff('littlerocks', array(
			"startmsg"=>$smsg,
			"name"=>$bname,
			"rounds"=>1,
			"wearoff"=>$woff,
			"minioncount"=>$session['user']['level']+1,
			"mingoodguydamage"=>0,
			"maxgoodguydamage"=>2+$dkb,
			"effectmsg"=>"`)You are hit by a rock for `\${damage}`) damage.",
			"effectnodmgmsg"=>$ndmg,
			"effectfailmsg"=>$ndmg,
		));
		$session['user']['badguy']=createstring($badguy);
		$op="fight";
	}
}
if ($op=="fight"){ $battle=true; }
if ($battle){
	include("battle.php");
	if ($victory){
		if (get_module_pref("monster")==1){
			//falling rocks
			$expbonus=$session['user']['dragonkills']*2;
			$expgain =($session['user']['level']*17+$expbonus);
			$session['user']['experience']+=$expgain;
			output("`n`%You made it! You were able to fight through the avalanche to safety!`n`n");
			output("`@`bYou've gained `#%s experience`@.`b`n`n",$expgain);
			output("`%The adrenaline rush allows you to finish your work in the quarry`@ without losing a turn`%!`n`n");
			output("You complete your work on `)One Block of Stone`%.`n`n ");
			$session['user']['turns']++;
			quarry_completeblock();
			quarry_quarrynavs();
		}elseif (get_module_pref("monster")==2){
			//Huge Boulder
			$expbonus=$session['user']['dragonkills']*3;
			$expgain =($session['user']['level']*19+$expbonus);
			$session['user']['experience']+=$expgain;
			$gemenum=get_module_setting("caseb");
			if ($gemenum==1) $gemfind=(e_rand(1,2));
			if ($gemenum==2) $gemfind=(e_rand(2,3));
			if ($gemenum==3) $gemfind=(e_rand(3,5));
			if ($gemenum==4) $gemfind=(e_rand(5,10));
			output("`n`%You made it! Your fancy pick-axe work makes light of the huge boulder!`n`n");
			output("`@`bYou've gained `#%s experience`@.`b`n`n",$expgain);
			output("`%The adrenaline rush allows you to finish your work in the quarry`@ without losing a turn`%!`n`n");
			output("You complete your work on `)One Block of Stone`%.`n`n You also find `b%s gem%s`b in the debris.`n`n",$gemfind,translate_inline($gemfind>1?"s":""));
			$session['user']['turns']++;
			$session['user']['gems']+=$gemfind;
			quarry_completeblock();
			quarry_quarrynavs();
		}elseif (get_module_pref("monster")==3){
			//Bear
			$expbonus=$session['user']['dragonkills']*4;
			$expgain =($session['user']['level']*39+$expbonus);
			$session['user']['experience']+=$expgain;
			output("`n`%Silly `qB`^ear`%! When will you ever learn?  `n`nYou `@don't lose a turn `%for working in the `@Q`3uarry`%.`n");
			output("`n`@`bYou've gained `#%s experience`@.`b`n`n",$expgain);
			$session['user']['turns']++;
			quarry_completeblock();
			quarry_quarrynavs();
		}elseif (get_module_pref("monster")==4){
			//Fossil Dinosaur
			$expbonus=$session['user']['dragonkills']*5;
			$expgain =($session['user']['level']*27+$expbonus);
			$session['user']['experience']+=$expgain;
			$gemenum=get_module_setting("casef");
			if ($gemenum==1) $gemfind=(e_rand(1,2));
			if ($gemenum==2) $gemfind=(e_rand(2,3));
			if ($gemenum==3) $gemfind=(e_rand(3,5));
			if ($gemenum==4) $gemfind=(e_rand(5,10));
			output("`n`%The `^F`Qossil `^D`Qinosaur`% crumbles before your might! You complete work on the `)Block`% and suddenly notice `b%s gem%s`b that constituted the heart of the monster!`n",$gemfind,translate_inline($gemfind>1?"s":""));
			output("`n`@`bYou've gained `#%s experience`@.`b`n`n",$expgain);
			$session['user']['gems']+=$gemfind;
			quarry_completeblock();
			quarry_quarrynavs();
		}elseif (get_module_pref("monster")==5){
			//Rock Lobster
			$expbonus=$session['user']['dragonkills']*9;
			$expgain =($session['user']['level']*20+$expbonus);
			$session['user']['experience']+=$expgain;
			output("`n`%The `)Rock `4Lobster`% ends his dance! You complete work on `)One Block`%.`n");
			output("`n`@`bYou've gained `#%s experience`@.`b`n`n",$expgain);
			quarry_completeblock();
			quarry_quarrynavs();
		}elseif (get_module_pref("monster")==6){
			//Small Stone Giant
			$expbonus=$session['user']['dragonkills']*7;
			$expgain =($session['user']['level']*35+$expbonus);
			$session['user']['experience']+=$expgain;
			output("`n`%You defeat the `)S`&mall `)S`&tone `)G`&iant`% to help save `@T`2he `@Q`3uarry`% and gain `@an extra turn`%.`n");
			output("`n`@`bYou've gained `#%s experience`@.`b`n`n",$expgain);
			$session['user']['turns']++;
			quarry_giantkill();
		}elseif (get_module_pref("monster")==7){
			//Medium Stone Giant
			$expbonus=$session['user']['dragonkills']*9;
			$expgain =($session['user']['level']*37+$expbonus);
			$session['user']['experience']+=$expgain;
			output("`n`%You defeat the `)M`&edium `)S`&tone `)G`&iant`% to help save `@T`2he `@Q`3uarry`% and gain `@two extra turns`%.`n");
			output("`n`@`bYou've gained `#%s experience`@.`b`n`n",$expgain);
			$session['user']['turns']+=2;
			quarry_giantkill();
		}elseif (get_module_pref("monster")==8){
			//Large Stone Giant
			$expbonus=$session['user']['dragonkills']*11;
			$expgain =($session['user']['level']*42+$expbonus);
			$session['user']['experience']+=$expgain;
			output("`n`%You defeat the `)L`&arge `)S`&tone `)G`&iant`% to help save `@T`2he `@Q`3uarry`% and gain `@three extra turns`%.`n");
			output("`n`@`bYou've gained `#%s experience`@.`b`n`n",$expgain);
			$session['user']['turns']+=3;
			quarry_giantkill();
		}elseif (get_module_pref("monster")==9){
			//Huge Stone Giant
			$expbonus=$session['user']['dragonkills']*13;
			$expgain =($session['user']['level']*45+$expbonus);
			$session['user']['experience']+=$expgain;
			output("`n`%With a huge triumphant cry, you defeat the `)H`&uge `)S`&tone `)G`&iant`% to help save `@T`2he `@Q`3uarry`% and gain `@four extra turns`%.`n");
			output("`n`%Other quarry workers sing your praises and report your deed to the kingdom.`n");
			addnews("%s`% defeated one of the `)H`&uge `)S`&tone `)G`&iants `% ransacking `@T`3he `@Q`3uarry`%!!",$session['user']['name']);
			output("`n`@`bYou've gained `#%s experience`@.`b`n`n",$expgain);
			$session['user']['turns']+=4;
			quarry_giantkill();
		}	
	}elseif($defeat){
		$taunt = select_taunt_array();
		if (get_module_pref("monster")==1){
			//falling rocks
			$exploss = round($session['user']['experience']*.1);
			$session['user']['experience']-=$exploss;
			output("`n`%You become buried under the avalanche of pointy rocks.`n");
			output("`b`^All gold on hand has been lost!`b`n");
			output("`b`%You lose `#%s experience`4.`b`n`n",$exploss);
			quarry_dead();
			if (get_module_pref("insured")==1){
				addnews("%s `%was crushed by falling rocks in `@T`3he `@Q`3uarry`%.  Luckily, %s`% had purchased `)D`\$eath `)I`\$nsurance`% and didn't lose everything!",$session['user']['name'],translate_inline($session['user']['sex']?"she":"he"));
			}else{
				addnews("%s `%was crushed by falling rocks in `@T`3he `@Q`3uarry`%.",$session['user']['name']);
			}
		}elseif (get_module_pref("monster")==2){
			//Huge Boulder
			$exploss = round($session['user']['experience']*.08);
			$session['user']['experience']-=$exploss;
			output("`n`%You become buried under the huge boulder.`n");
			output("`b`^All gold on hand has been lost!`b`n");
			output("`b`%You lose `#%s experience`4.`b`n`n",$exploss);
			quarry_dead();
			if (get_module_pref("insured")==1){
				addnews("%s `%was crushed by a huge boulder in `@T`3he `@Q`3uarry`%.  Luckily, %s`% had purchased `)D`\$eath `)I`\$nsurance`% and didn't lose everything!",$session['user']['name'],translate_inline($session['user']['sex']?"she":"he"));
			}else{
			addnews("%s `%was crushed by a huge boulder in `@T`3he `@Q`3uarry`%.",$session['user']['name']);
			}
		}elseif (get_module_pref("monster")==3){
			//Bear
			$exploss = round($session['user']['experience']*.1);
			$session['user']['experience']-=$exploss;
			output("`n`n`b`%You can't `Q'bear'`% to think how you got killed...`b`n");
			output("`b`%He really `)'rocked'`% your world!`b`n");
			output("`b`^All gold on hand has been lost!`b`n");
			output("`b`%You lose `#%s experience`4.`b`n`n",$exploss);
			quarry_dead();
			if (get_module_pref("insured")==1){
				addnews("%s `%received a `Qbear hug`% in `@T`3he `@Q`3uarry`%... to death!  Luckily, %s`% had purchased `)D`\$eath `)I`\$nsurance`% and didn't lose everything!",$session['user']['name'],translate_inline($session['user']['sex']?"she":"he"));
			}else{
				addnews("%s `%received a `Qbear hug`% in `@T`3he `@Q`3uarry`%... to death!",$session['user']['name']);
			}
		}elseif (get_module_pref("monster")==4){
			//Fossil Dinosaur
			$exploss = round($session['user']['experience']*.07);
			$session['user']['experience']-=$exploss;
			output("`n`n`b`%The `^F`Qossil `^D`Qinosaur`% sends you to the bone yard...`b`n");
			output("`b`%Now you've become the fossil.  Isn't it Ironic?`b`n");
			output("`b`^All gold on hand has been lost!`b`n");
			output("`b`%You lose `#%s experience`4.`b`n`n",$exploss);
			quarry_dead();
			if (get_module_pref("insured")==1){
				addnews("%s `%was fossilized by a `^F`Qossil `^D`Qinosaur`% in `@T`3he `@Q`3uarry`%...  Luckily, %s`% had purchased `)D`\$eath `)I`\$nsurance`% and didn't lose everything!",$session['user']['name'],translate_inline($session['user']['sex']?"she":"he"));
			}else{
				addnews("%s `%was fossilized by a `^F`Qossil `^D`Qinosaur`% in `@T`3he `@Q`3uarry`%.",$session['user']['name']);
			}
		}elseif (get_module_pref("monster")==5){
			//Rock Lobster
			$exploss = round($session['user']['experience']*.07);
			$session['user']['experience']-=$exploss;
			output("`n`n`b`%The `)Rock `4Lobster`% dances all over your grave.`b`n");
			output("`b`^All gold on hand has been lost!`b`n");
			output("`b`%You lose `#%s experience`4.`b`n`n",$exploss);
			quarry_dead();
			if (get_module_pref("insured")==1){
				addnews("%s `%was stepped on by a `)Rock `4Lobster`% in `@T`3he `@Q`3uarry`%...  Luckily, %s`% had purchased `)D`\$eath `)I`\$nsurance`% and didn't lose everything!",$session['user']['name'],translate_inline($session['user']['sex']?"she":"he"));
			}else{
				addnews("%s `%was stepped on by a `)Rock `4Lobster`% in `@T`3he `@Q`3uarry`%.",$session['user']['name']);
			}
		}elseif (get_module_pref("monster")==6){
			//Small Stone Giant
			$exploss = round($session['user']['experience']*.085);
			$session['user']['experience']-=$exploss;
			output("`n`n`b`%The `)S`&mall `)S`&tone `)G`&iant`% pulverizes you to death.`b`n");
			output("`b`^All gold on hand has been lost!`b`n");
			output("`b`%You lose `#%s experience`4.`b`n`n",$exploss);
			quarry_giantdead();
			addnews("%s `%was killed by the `)S`&mall `)S`&tone `)G`&iant`% terrorizing `@T`3he `@Q`3uarry`%.`n%s",$session['user']['name'],$taunt);
		}elseif (get_module_pref("monster")==7){
			//Medium Stone Giant
			$exploss = round($session['user']['experience']*.085);
			$session['user']['experience']-=$exploss;
			output("`n`n`b`%The `)M`&edium `)S`&tone `)G`&iant`% pulverizes you to death.`b`n");
			output("`b`^All gold on hand has been lost!`b`n");
			output("`b`%You lose `#%s experience`4.`b`n`n",$exploss);
			quarry_giantdead();
			addnews("%s `%was killed by the `)M`&edium `)S`&tone `)G`&iant`% terrorizing `@T`3he `@Q`3uarry`%.`n%s",$session['user']['name'],$taunt);
		}elseif (get_module_pref("monster")==8){
			//Large Stone Giant
			$exploss = round($session['user']['experience']*.085);
			$session['user']['experience']-=$exploss;
			output("`n`n`b`%The `)L`&arge `)S`&tone `)G`&iant`% pulverizes you to death.`b`n");
			output("`b`^All gold on hand has been lost!`b`n");
			output("`b`%You lose `#%s experience`4.`b`n`n",$exploss);
			quarry_giantdead();
			addnews("%s `%was killed by the `)L`&arge `)S`&tone `)G`&iant`% terrorizing `@T`3he `@Q`3uarry`%.`n%s",$session['user']['name'],$taunt);
		}elseif (get_module_pref("monster")==9){
			//Huge Stone Giant
			$exploss = round($session['user']['experience']*.085);
			$session['user']['experience']-=$exploss;
			output("`n`n`b`%The `)L`&arge `)S`&tone `)G`&iant`% pulverizes you to death.`b`n");
			output("`b`^All gold on hand has been lost!`b`n");
			output("`b`%You lose `#%s experience`4.`b`n`n",$exploss);
			quarry_giantdead();
			addnews("%s `%was killed by the `)H`&uge `)S`&tone `)G`&iant`% terrorizing `@T`3he `@Q`3uarry`%.`n%s",$session['user']['name'],$taunt);
		}
	}else{
		require_once("lib/fightnav.php");
		fightnav(true,false,"runmodule.php?module=quarry");
    }
}
if($op=="office"){
	if (get_module_pref("insured")==0) addnav("Purchase `)D`\$eath `)I`\$nsurance`^","runmodule.php?module=quarry&op=insurance");
	if (get_module_pref("usedqts")<get_module_setting("quarryturns")) addnav("Work the Quarry","runmodule.php?module=quarry&op=work");
	addnav("Review the Rules","runmodule.php?module=quarry&op=rules");
	addnav("V?(V) Return to Village","village.php");
	output("`n`b`c`@Q`3uarry `@O`3ffice`b`c`n");
	output("`&Slatemaker `\$S`7h`&y`\$l`7l`&e`% takes off her hat and sits down behind the desk.`^`n`n");
	if (get_module_setting("blocksleft")>0) {
		if (get_module_pref("insured")==0) output("'We are currently offering `)D`\$eath `)I`\$nsurance`^ in case you die in `@Q`3uarry`^ for the low low price of`b %s gold`b.'",get_module_setting("insurecost"));
		output ("'Insurance will pay out `b%s gold`b and `%%s gems`^ if you are killed in the quarry.  The insurance runs out tomorrow.'`n`n",
		get_module_setting("inspaygold"),get_module_setting("inspaygems"));
		output("`\$You  ");
		if (get_module_pref("insured")==0)  output("`^ do not ");
		output("`\$have a valid `)D`\$eath `)I`\$nsurance `)P`\$olicy.`n`n");
	}
	if (get_module_setting("blocksleft")<=0) {
		blocknav("runmodule.php?module=quarry&op=rules");
		blocknav("runmodule.php?module=quarry&op=insurance");
	}
	if (get_module_setting("blocksleft")<=0)output("`^'There are `b`)No More Blocks of Stone`b`^ left to quarry.  `@T`3he `@Q`3uarry`^ is `\$Closed`^.'`n`n");
	output("`%She reviews your ledger:`n`n");
	output("`^'Let's see, under`0 %s`^... I have you listed for the following:`n`n",$session['user']['name']);
	if (get_module_setting("blocksleft")>0){
		output("`^You've spent`@ %s out of %s turns`^ working in the `@Q`3uarry`^.`n`n",get_module_pref("usedqts"),get_module_setting("quarryturns"));
		if (is_module_active('lostruins') && get_module_setting("usequarry")==0) output("`^There are about `b`)%s`b Blocks of Stone`^ left to quarry.`n`n",get_module_setting("blocksleft"));
	}
	output("`^You now have`b`) %s `bBlocks of Stone`^.`n`n", get_module_pref("blocks"));
	if (get_module_pref ("blocks")>=1){
		output("`^Currently, the best I can offer you for a `)Block of Stone`^ is`b %s gold`b.`n`n  How many would you like to sell?'",$blockpay);
		output("<form action='runmodule.php?module=quarry&op=blocksell' method='POST'><input name='sell' id='sell'><input type='submit' class='button'value='sell'></form>",true);
		addnav("","runmodule.php?module=quarry&op=blocksell");
	}else{
		output("`^'Since you don't have any blocks to sell, you'll probably want to get to work in the quarry.'`n`n`&Slatemaker `\$S`7h`&y`\$l`7l`&e `%closes the ledger and leads you to the door.`n`n");
	}
}
if ($op=="insurance"){
	addnav("V?(V) Return to Village","village.php");
	if (get_module_pref("usedqts")<get_module_setting("quarryturns")) addnav("Work the Quarry","runmodule.php?module=quarry&op=work");
	addnav("Review the Rules","runmodule.php?module=quarry&op=rules");
	addnav("Back to the Office","runmodule.php?module=quarry&op=office");
	output("`n`b`c`)D`\$eath `)I`\$nsurance`b`c`n");
	if ($session['user']['gold']<get_module_setting("insurecost")){
		output("`^'Although I appreciate your interest in our `)D`\$eath `)I`\$nsurance`^, I really think you should at least have the money to purchase a policy before thinking we will cover you.  Stop back when you've got at least`b %s gold`b.'",get_module_setting("insurecost"));
	}else{
		output("`^'Well, I think this was a really good idea.  Not that I think you'll die.  Err... I'm sure you'll be perfectly fine.`n`nJust remember, the insurance only works if you die in the `@Q`3uarry`^.'");
		set_module_pref("insured",1);
		$session['user']['gold']-=get_module_setting("insurecost");
	}
}
if ($op=="blocksell"){
	if (get_module_pref("usedqts")<get_module_setting("quarryturns")) addnav("Work the Quarry","runmodule.php?module=quarry&op=work");
	addnav("Review the Rules","runmodule.php?module=quarry&op=rules");
	addnav("Back to the Office","runmodule.php?module=quarry&op=office");
	output("`n`b`c`@Q`3uarry `@O`3ffice`b`c`n");
	$sell = httppost('sell');
	$max = get_module_pref("blocks");
	if ($sell < 0) $sell = 0;
	if ($sell >= $max) $sell = ($max);
	if ($max < $sell) {
		output("`&Slatemaker `\$S`7h`&y`\$l`7l`&e`% looks at you bewildered.  `^'You know you don't have that many squares!'`n`n");
	}else{
		$cost=($sell * $blockpay);
		$session['user']['gold']+=$cost;
		set_module_pref("blocks",get_module_pref("blocks")-$sell);
		output("`&Slatemaker `\$S`7h`&y`\$l`7l`&e`% gives you `^`b%s gold`b",$cost);
		if ($sell==1) {
			output("`%in return for`) one block`%.");
		}else{
			output("`%in return for`) %s blocks`%.",$sell);
		}
	}
}
if ($op == "hof") {
	page_header("Hall of Fame");
	$pp = get_module_setting("pp");
	$pageoffset = (int)$page;
	if ($pageoffset > 0) $pageoffset--;
	$pageoffset *= $pp;
	$limit = "LIMIT $pageoffset,$pp";
	$sql = "SELECT COUNT(*) AS c FROM " . db_prefix("module_userprefs") . " WHERE modulename = 'quarry' AND setting = 'blockshof' AND value > 0";
	$result = db_query($sql);
	$row = db_fetch_assoc($result);
	$total = $row['c'];
	$count = db_num_rows($result);
	if (($pageoffset + $pp) < $total){
		$cond = $pageoffset + $pp;
	}else{
		$cond = $total;
	}
	$sql = "SELECT ".db_prefix("module_userprefs").".value, ".db_prefix("accounts").".name FROM " . db_prefix("module_userprefs") . "," . db_prefix("accounts") . " WHERE acctid = userid AND modulename = 'quarry' AND setting = 'blockshof' AND value > 0 ORDER BY (value+0) DESC $limit";
	$result = db_query($sql);
	$rank = translate_inline("Rank");
	$name = translate_inline("Name");
	$squareshof = translate_inline("Blocks Quarried");
	$none = translate_inline("Nothing Quarried");
	output("`n`b`c`@Greatest`$ Masons `@in the Land`n`c`b");
	rawoutput("<table border='0' cellpadding='2' cellspacing='1' align='center' bgcolor='#999999'>");
	rawoutput("<tr class='trhead'><td>$rank</td><td>$name</td><td>$squareshof</td></tr>");
	if (db_num_rows($result)==0){
		output_notl("<tr class='trlight'><td colspan='2' align='center'>`&$none`0</td></tr>",true);
	}
	if (db_num_rows($result)>0){
		for($i = $pageoffset; $i < $cond && $count; $i++) {
			$row = db_fetch_assoc($result);
			if ($row['name']==$session['user']['name']){
				rawoutput("<tr class='trhilight'><td>");
			}else{
				rawoutput("<tr class='".($i%2?"trdark":"trlight")."'><td>");
			}
			$j=$i+1;
			output_notl("$j.");
			rawoutput("</td><td>");
			output_notl("`&%s`0",$row['name']);
			rawoutput("</td><td>");
			output_notl("`c`b`Q%s`c`b`0",$row['value']);
			rawoutput("</td></tr>");
        }
	}
	rawoutput("</table>");
	if ($total>$pp){
		addnav("Pages");
		for ($p=0;$p<$total;$p+=$pp){
			addnav(array("Page %s (%s-%s)", ($p/$pp+1), ($p+1), min($p+$pp,$total)), "runmodule.php?module=quarry&op=hof&page=".($p/$pp+1));
		}
	}
	addnav("Other");
	addnav("Back to HoF", "hof.php");
	villagenav();
}
page_footer();
?>