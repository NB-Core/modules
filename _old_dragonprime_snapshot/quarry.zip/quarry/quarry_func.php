<?php
function quarry_completeblock(){
	increment_module_pref("blocks",1);
	increment_module_pref("blockshof",1);
	if (is_module_active('lostruins')){
		increment_module_setting("blocksleft",-1);
		if (get_module_setting("blocksleft")<10) output("`@T`3he `@Q`3uarry`% is looking low on stone and may have to be shut down soon.`n`n");
	}
}
function quarry_quarrynavs(){
	addnav("V?(V) Return to Village","village.php");
	if (get_module_pref("usedqts")<get_module_setting("quarryturns")) addnav("Work the Quarry","runmodule.php?module=quarry&op=work");
	addnav("Office","runmodule.php?module=quarry&op=office");
}
function quarry_blocknavs(){
	blocknav("village.php");
	blocknav("runmodule.php?module=quarry&op=office");
	blocknav("runmodule.php?module=quarry&op=work");
} 
function quarry_giantkill(){
	increment_module_setting("giantleft",-1);
	if (get_module_setting("giantleft")<=0) {
		set_module_setting("underatk",0);
		debuglog("killed the last giant in the quarry.");
	}else{
		debuglog("killed a giant in the quarry.");
	}	
	addnav("V?(V) Return to Village","village.php");
}
function quarry_dead(){
	global $session;
	output("`b`%You may try again tomorrow.`b`n`n");
	addnav("Daily news","news.php");
	$session['user']['experience']-=$exploss;
	$session['user']['alive'] = false;
	$session['user']['hitpoints'] = 0;
	$session['user']['gold']=0;
	if (get_module_pref("insured")==1){
		$inspaygold=get_module_setting("inspaygold");
		$inspaygems=get_module_setting("inspaygems");
		output("It's times like these that you're happy that you bought your `)D`\$eath `)I`\$nsurance`%.`n`n You will have`^ %s gold`% and`b an additional %s gems `bon your next day.",$inspaygold,$inspaygems);
		$session['user']['gold']=$inspaygold;
		$session['user']['gems']+=$inspaygems;
		set_module_pref("insured",0);
	}
}
function quarry_giantdead(){
	global $session;
	output("`b`\$You may try again tomorrow.`b`n`n");
	addnav("Daily news","news.php");
	$session['user']['alive'] = false;
	$session['user']['hitpoints'] = 0;
	$session['user']['gold']=0;
}
?>