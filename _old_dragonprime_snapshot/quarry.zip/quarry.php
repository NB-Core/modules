<?php
/*
Module Name:  quarry.php
Category:  Village
Worktitle:  Quarry
Author:  DaveS
Date: September 10, 2005
Additional Modules for full function:
lostruins.php*, alignment.php, masons.phpH

*if lostruins is not installed, the quarry will automatically appear and never run out of blocks

Module should function without their installation

Credits:
Thanks to Sixf00t4 for the module concept.

Description:
Fight Rock Lobsters, Bears, Fossil Dinosaurs...
This is a somewhat involved module that allows players to quarry stone.
The module works as a standalone with the stone sold at a setting price.
However, additional modules may be linked for other uses of the stone.

Every so often the Quarry is beseiged by Stone Giants.  This requires players to
fight off Stone Giants until the Quarry can be re-opened.

The Quarry will either appear automatically in the Village and never disappear(if lostruins is NOT installed)
or it will appear when it is "discovered" in the Lost Ruins and will eventually run out of stones and
disappear again.

In addition, Players may become members of the Masons Secret Society with incorporation of masons.php.

v1.1  Tweaked for Secret Society Hook
v1.11 color tweaks
v1.12 more likely to get hurt (1 in 210 wasn't enough)
v1.2  Added a system for Giant Siege for when the Lost Ruins is active; also added a recruitment rate change
      for recruiting new Masons
v1.21 tweaked recruiting
v2.0 cleaned up and incremented, debuglogs written in
v2.02 db_prefix cleanup
v3.0 added vertxtloc
v3.11 added more settings as recommended by DAHZL (newday_runonce and cost/level to sell) and split into a quarry folder
v3.13 typos for function calls cleaned up
v3.14 repaired small missing code
v3.15 Added option to use quarry without being found in Lost Ruins
v3.16 Fixed a mistake on the random event generator.
v3.5  Orchard XL settings and integration added
v3.51 Cleaned up for translation, added a Stat Display
v3.6  settings for some of the rewards added
*/
require_once("lib/taunt.php");
function quarry_getmoduleinfo(){
	$info = array(
		"name"=>"The Quarry",
		"version"=>"3.61",
		"author"=>"DaveS",
		"category"=>"Village",
		"download"=>"http://dragonprime.net/index.php?module=Downloads;sa=dlview;id=147",
		"vertxtloc"=>"",
		"description"=>"A Quarry for Stone",
		"settings"=>array(
			"Quarry Settings,title",
			"quarryfinder"=>"Who found the quarry?,text|0",
			"quarryloc"=>"Where was the quarry found?,location|".getsetting("villagename", LOCATION_FIELDS),
			"quarryturns"=>"How many turns can they use in a day at the quarry?,int|3",
			"runonce"=>"Reset turns in the quarry only on server-generated game day?,bool|0",
			"usequarry"=>"Use quarry without being found in lost ruins (if lostruins active)?,bool|0",
			"blockmin"=>"Random blocks available range minimum (if lostruins active)?,int|85",
			"blockmax"=>"Random blocks available range maximum (if lostruins active)?,int|115",
			"blocksleft"=>"How many blocks are left in this Quarry (if lostruins active)?,int|100",
			"blockpaymin"=>"How much will the Slatemaker pay for a Stone minimum?,int|250",
			"blockpaymax"=>"How much will the Slatemaker pay for a Stone maximum?,int|350",
			"blockpay"=>"How much is the Slatemaker paying for a Stone today?,int|350",
			"leveladj"=>"Divide pay for a Block of Stone by Player's level?,bool|0",
			"quarryclosed"=>"Has the Quarry been announced as closed on newday?,bool|1",
			"newsclosed"=>"Has the Quarry been announced as closed on the news?,bool|0",
			"alloworchard"=>"Allow players to find the lime seed here?,bool|1",
			"ruler"=>"What is the name of the ruler that rewards the player?,text|The King",
			"Rewards,title",
			"case13ge"=>"`%Case 13: Gem reward for finding a cache of gems:,enum,1,1-2 Gems,2,2-3 Gems,3,3-5 Gems,4,5-10 Gems|2",
			"case20ge"=>"`%Case 20: Gem reward for perfect work by a mason:,enum,1,1-2 Gems,2,2-3 Gems,3,3-5 Gems,4,5-10 Gems|4",
			"case20bge"=>"`%Case 20b: Gem reward for perfect work if masons is not active:,enum,1,1-2 Gems,2,2-3 Gems,3,3-5 Gems,4,5-10 Gems,5,8-15 Gems|5",
			"case26g"=>"`^Case 26: Gold reward for carving a stone and finding a pocket of gold:,int|650",
			"caseb"=>"`%Boulder Attack: Gem reward for destroying the boulder:,enum,1,1-2 Gems,2,2-3 Gems,3,3-5 Gems,4,5-10 Gems|2",
			"casef"=>"`%Fossil Monster Attack: Gem reward for the Fossil Monster Heart:,enum,1,1-2 Gems,2,2-3 Gems,3,3-5 Gems,4,5-10 Gems|3",
			"Stone Giant Attack, title",
			"giantatk"=>"Number of counters before the Stone Giants attack(if lostruins inactive), int|3",
			"sgcount"=>"Current number of Stone Giant Counters(if lostruins inactive), int|0",
			"sgpercent"=>"Percentage that a counter will trigger on newday(if lostruins inactive), int|30",
			"underatk"=>"Is the Quarry currently under attack?, bool|0",
			"numbgiant"=>"How many Giants start an attack, int|40",
			"giantleft"=>"How many Giants are left?, int|40",
			"Death Insurance, title",
			"insurecost"=>"How much does insurance cost?,int|100",
			"inspaygold"=>"How much gold does insurance pay at death?,int|1000",
			"inspaygems"=>"How many gems does insurance pay at death?,int|5",
			"Hall of Fame, title",
			"usehof"=>"Use Hall of Fame?,bool|1",
			"pp"=>"How many players per page in Hall of Fame?,int|25",
		),
		"prefs"=>array(
			"Quarry User Preferences,title",
			"firstq"=>"Has player ever been to the quarry?,bool|0",
			"usedqts"=>"How many times did they quarry today?,int|0",
			"blocks"=>"Number of blocks player has,int|0",
			"blockshof"=>"Total number of blocks ever cut, int|0",
			"insured"=>"Does player have Death Insurance for today?, bool|0",
			"sgfought"=>"Has the player fought a stone giant during the siege today?,bool|0",
			"monster"=>"Which monster number are they fighting, int|1",
			"user_stat"=>"Display your number of blocks in the Stat bar?,bool|1",
		),
	);
	return $info;
}
function quarry_install(){
	module_addhook("village");
	module_addhook("newday");
	module_addhook("newday-runonce");
	module_addhook("footer-hof");
	module_addhook("lostruins");
	module_addhook_priority("charstats", 100);
	if (is_module_active("masons")) module_addhook("masons");
	return true;
}
function quarry_uninstall(){
	return true;
}
function quarry_dohook($hookname,$args){
	global $session;
	switch($hookname){
		case "newday-runonce":
			$blockpay=(e_rand(get_module_setting("blockpaymin"),get_module_setting("blockpaymax")));
			set_module_setting("blockpay",$blockpay);
			if (is_module_active('lostruins') && get_module_setting("usequarry")==0) {
				if (get_module_setting("quarryclosed")==0) output("`n`@T`3he %s`& `@Q`3uarry `@o`3f `@G`3reat `@S`3tone `@in the village of %s `@has run out of stone and has been `\$closed`@.`n",get_module_setting("quarryfinder"),get_module_setting("quarryloc"));
				set_module_setting("quarryclosed",1);
				set_module_setting("newsclosed",0);
			}else{
				if (e_rand(1,100)<=get_module_setting("sgpercent")) increment_module_setting("sgcount",1);
				if(get_module_setting("underatk")==1) {
					set_module_setting("sgcount",0);
					output("`n`@T`3he `@Q`3uarry`% is under siege by a band of `)S`&tone `)G`&iants`%!!!`n");
				}
			}
			if (get_module_setting("runonce")){
				$sql = "update ".db_prefix("module_userprefs")." set value=0 where value<>0 and setting='usedqts' and modulename='quarry'";
				db_query($sql);
				$sql = "update ".db_prefix("module_userprefs")." set value=0 where value<>0 and setting='sgfought' and modulename='quarry'";
				db_query($sql);
				$sql = "update ".db_prefix("module_userprefs")." set value=0 where value<>0 and setting='insured' and modulename='quarry'";
				db_query($sql);
				if (is_module_active("masons")){
					$sql = "update ".db_prefix("module_userprefs")." set value=0 where value<>0 and setting='offermember' and modulename='masons'";
					db_query($sql);
       			}
			}
		break;
		case "newday":
			if (!get_module_setting("runonce")){
				if (is_module_active("masons")) set_module_pref("offermember",0,"masons");
				set_module_pref("usedqts",0);
				set_module_pref("sgfought",0);
				set_module_pref("insured",0);
       			if (is_module_active("lostruins") && get_module_setting('quarryfound','lostruins')==1 && get_module_setting("usequarry")==0) output("`n`@T`3he %s`& `@Q`3uarry `@o`3f `@G`3reat `@S`3tone `@was discovered in the village of %s.`n",get_module_setting("quarryfinder"),get_module_setting("quarryloc"));		
			}
		break;
		case "village":
			if (is_module_active('lostruins') && get_module_setting("usequarry")==0) {
				if(get_module_setting("quarryfound","lostruins")==1){
					if ($session['user']['location'] == get_module_setting("quarryloc")){
						tlschema($args['schemas']['gatenav']);
						addnav($args['gatenav']);
						tlschema();
						addnav("The Quarry","runmodule.php?module=quarry&op=enter");
					}
				}
			}else{
				if ($session['user']['location'] == get_module_setting("quarryloc")) {
					tlschema($args['schemas']['gatenav']);
					addnav($args['gatenav']);
					tlschema();
					addnav("The Quarry","runmodule.php?module=quarry&op=enter");
				}
			}
		break;
		case "footer-hof":
			if(get_module_setting('usehof')==1){
				addnav("Warrior Rankings");
				addnav("Master Masons","runmodule.php?module=quarry&op=hof");
			}
		break;
		case "charstats":
			if(get_module_pref("user_stat")==1){
				$blocks=get_module_pref("blocks");
				if($blocks>0) setcharstat("Personal Info", "Stone", "`^$blocks");				
			}
		break;
	}
	return $args;
}
function quarry_run(){
	$op = httpget('op');
	global $SCRIPT_NAME;
	if ($SCRIPT_NAME == "runmodule.php"){
		$module=httpget("module");
		if ($module == "quarry"){
			require_once("modules/quarry/quarry_func.php");
			include("modules/quarry/quarry.php");
		}
	}
}
?>