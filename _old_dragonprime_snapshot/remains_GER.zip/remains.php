<?
/* Skeletal Remains v1.1 by Timothy Drescher (Voratus)
Current version can be found at Domarr's Keep (lgd.tod-online.com)

Version History
1.0 original version
1.1 bug fix (would not award gold nor gem(s) upon defeating the warrior)

German Translation by Hadriel
*/
if (!isset($session)) exit();
if ($HTTP_GET_VARS['op']==""){
	$sql = "SELECT name FROM accounts WHERE alive=0";
   $result = db_query($sql);
   $go=e_rand(1,db_num_rows($result));
   for ($i=0;$i<$go;$i++){
       $row = db_fetch_assoc($result);
      $tname = $row[name];
   }
	output("`7Beim durchforsten des Waldes siehst du ein Skelett am Boden liegen. Es ist");
   output("$tname`7.  Das Skelett ist unber�hrt ... was machst du? ");
	addnav("Leiche Durchsuchen","forest.php?op=desecrate");
	addnav("In ruhe lassen","forest.php?op=leave");
	if ($session[user][turns] > 3) {
		addnav("Dem Skelett ein richtiges Grab schaufeln (4 WK)","forest.php?op=bury");
	}
	$session[user][specialinc]="remains.php";
} elseif ($HTTP_GET_VARS['op']=="bury"){
	$session[user][turns]-=4;
// The following two lines are specific to lgd.tod-online.com
	$session[user][clean]+=2;
	output("Du schaufelst ein Richtiges Grab f�r dieses Skelett. So vermeidest du , dass die ");
	output("Reichen das Skelett auspl�ndern .`n`nSchliesslich w�nschst du nicht, dass die Kreaturen ");
	output("Des Waldes sich an das Skelett heranmachen.`n`n");
	$rand = rand(1,3);
	if ($rand != 1) {
		output("Als du das Grab verl�sst ,kommt eine kleine Fee angeflogen. \"`#Das war eine ");
		output("richtige Sache , die du getan hast. Ich werde dich Belohnen.`7\"`n`n");
		$reward = rand(1,8);
		switch ($reward) {
			case 1:
			case 2:
			case 3:
				output("Die Fee gibt dir einen Edelstein!");
				debuglog("received one gem for burying a corpse");
				$session[user][gems]++;
				break;
			case 4:
			case 5:
			case 6:
				$cash = rand(($session[user][level]*20),($session[user][level]*40));
				output("Die Fee gibt dir $cash Gold!");
				debuglog("received $cash gold for burying a corpse");
				$session[user][gold]+=$cash;
				break;
			case 7:
			case 8:
				output("Die Fee gibt dir zwei Edelsteine!");
				debuglog("received two gems for burying a corpse");
				$session[user][gems]+=2;
				break;
		}
	} else {
		output("Du f�hlst dich gut.`n");
		output("Du bekommst zwei Charmepunkte!");
		debuglog("gained two charm for burying a corpse");
		$session[user][charm]+=2;
	}
	$session['user']['specialinc']="";
} elseif ($HTTP_GET_VARS['op']=="leave"){
	output("Irgendwas hat dieses Skelett get�tet. Dieses Etwas muss noch hier sein. Es ist sicherer ");
	output("das Skelett in frieden zu lassen.`n`n");
	$session[user][specialinc]="";
} elseif ($HTTP_GET_VARS['op']=="desecrate"){
	$session['user']['turns']--;
	output("Du untersuchst den K�rper, in der Hoffnung etwas zu finden.`n");
// The following line is specific to lgd.tod-online.com
	$session[user][turns]--;
	switch (rand(1,4)) {
		case 1:
			$gem_gain = rand(1,4);
			$gold_gain = rand($session[user][level]*10,$session[user][level]*20);
			$gemword = "Edelsteine";
			if ($gem_gain == 1) $gemword = "gem";
			output("Du hast erfolg! du findest $gem_gain $gemword ");
			output("und $gold_gain Gold.`n`n");
			$session[user][gems]+=$gem_gain;
			$session[user][gold]+=$gold_gain;
			$session[user][specialinc]="";
			debuglog("stole $gem_gain gems and $gold_gain gold from a corpse");
			break;
		case 2:
		case 3:
			output("Du durchsuchste den K�rper, jedoch findest du nur ein Altes Schwert. ");
			output("Vielleicht hast du n�chstes mal mehr Gl�ck.`n`n");
			$session[user][specialinc]="";
			debuglog("looted a corpse and found nothing");
			break;
		case 4:
			output("Als du den K�rper durchsuchst , bemerkst du eine seltsame Bewegung. Du springst ein St�ck zur�ck, ");
			output("als das Skelett aufsteht. Es sieht dich mit `4Teuflischen `0 Augen an. ");
			output("Wenn es sprechen k�nnte , w�rst du sicher ,dass es dich bis auf alle Knochen verfluchen w�rde ");
			output("Es attackiert dich.`n`n");
			$badguy = array(
            	"creaturename"=>"`\$Skelettkrieger`0",
            	"creaturelevel"=>$session[user][level]+1,
            	"creatureweapon"=>"Verrostetes Schwert",
            	"creatureattack"=>$session['user']['attack']+2,
            	"creaturedefense"=>$session['user']['defence']+2,
            	"creaturehealth"=>round($session['user']['maxhitpoints']*1.25,0), 
            	"diddamage"=>0);
			$session['user']['badguy']=createstring($badguy);
        	$session['user']['specialinc']="remains.php";
			$HTTP_GET_VARS['op']="fight";
			break;
	}
}
if ($HTTP_GET_VARS[op]=="run"){
	if (e_rand()%3 == 0){
		output ("`c`b`&Du rennst vor der untoten Bedrohung weg!`0`b`c`n");
		$HTTP_GET_VARS[op]="";
	}else{
		output("`c`b`\$Du kannst nicht Fliehen!`0`b`c");
	}
}
if ($HTTP_GET_VARS['op']=="fight"){
	$battle=true;
}
if ($battle) {
	include("battle.php");
    $session['user']['specialinc']="remains.php";
    	if ($victory){
        	$badguy=array();
            $session['user']['badguy']="";
            output("`n`7Nach dem siegreichen Kampf hast du das Skelett get�tet.Du hoffst , es findet nun seine Ruhe ");
            output("Oder der n�chste Krieger , der hier vorbeikommt , wird es leicht im Kampf haben. ");
            debuglog("defeated a skeletal warrior after disturbing it");
			if (rand(1,2)==1) {
				$gem_gain = rand(1,4);
				$gold_gain = rand($session[user][level]*10,$session[user][level]*20);
				$gemword = "gems";
				if ($gem_gain == 1) $gemword="gem";
				output("Nach dem kampf gegen den Untoten , findest du $gem_gain $gemword ");
				output("und $gold_gain Gold.`n`n");
				$session['user']['gems']+=$gem_gain;
				$session['user']['gold']+=$gold_gain;
			} else {
				output("Nach all der Arbeit findest du `5NICHTS!`0`n`n");
			}
			// The below is because I don't know how to pull the creature experience out of the table.
			// Its actually 10% more than the creature experience, since the level is one higher
			$skelevel = $session[user][level]+1;
			switch ($skelevel) {
				case 2:
					$exp_gain = 26;
					break;
				case 3:
					$exp_gain = 37;
					break;
				case 4:
					$exp_gain = 50;
					break;
				case 5:
					$exp_gain = 61;
					break;
				case 6:
					$exp_gain = 73;
					break;
				case 7:
					$exp_gain = 85;
					break;
				case 8:
					$exp_gain = 98;
					break;
				case 9:
					$exp_gain = 111;
					break;
				case 10:
					$exp_gain = 125;
					break;
				case 11:
					$exp_gain = 140;
					break;
				case 12:
					$exp_gain = 155;
					break;
				case 13:
					$exp_gain = 172;
					break;
				case 14:
					$exp_gain = 189;
					break;
				case 15:
					$exp_gain = 208;
					break;
				case 16:
					$exp_gain = 228;
					break;
			}
			output("Du bekommst $exp_gain Erfahrungspunkte f�r den Kampf.`n`n");
			$session[user][experience]+=$exp_gain;
			$session['user']['specialinc']="";
        } elseif ($defeat){
            $badguy=array();
            $session[user][badguy]="";
            debuglog("was killed by a Skeletal Warrior.");
            output("`n`7Du wurdest von einem Skelett niedergemetzelt!`n`nDoch du bist nicht tot! Du verlierst etwas Erfahrung und $gem_loss Edelsteine! ");
			$gem_loss = rand(1,4);
			if ($gem_loss >= $session[user][gems]) {
				output("Du verlierst ALL deine Edelsteine!`n`n");
				$session[user][gems]=0;
			} else {
				output("Du hast $gem_loss Edelsteine und dein gesamtes Gold verloren!`n`n");
				$session[user][gems]-=$gem_loss;
			}
			//addnav("Daily news","news.php");
			//$session[user][alive]=false;
			$session[user][gold]=0;
			$session[user][hitpoints]=1;
			$session[user][experience]=round($session[user][experience]*.9,0);
			$session[user][specialinc]="";
			addnews($session[user][name]." kam dem Tod n�her als ".($session[user][sex]?"sie":"er")." wollte!");
		} else {
			fightnav(true,true);
		}
	
}
?>