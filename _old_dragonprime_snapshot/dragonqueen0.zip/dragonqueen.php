<?php

// upgraded to 1.1 .. randomised event outcomes and added a few extra's
// upgraded to 1.2 .. added Dragon King
// upgraded to 1.3 .. added graphics
require_once("common.php");
require_once("lib/forest.php");
function dragonqueen_getmoduleinfo (){
		$info = array(
		"name"=>"Dragon Queen",
		"author" => "`b`&Ka`6laza`&ar`b",
		"version"=>"1.3",
		"download"=>"http://dragonprime.net/index.php?module=Downloads;sa=dlview;id=639",
		"category"=>"Forest Specials",
		"description"=>"Multi-levelled Special to find the DragonQueen within her cavern",
		"settings"=>array(
			"Dragon Queen Settings,title",
			"maxhp"=>"How many hitpoints can DragonQueen give?,range,1,5,1|3",
			"carrydk"=>"Do max hitpoints gained carry across DKs?,bool|1",
			"favor"=>"Percentage of favor lost, int|50"
		),
		);
		return $info;
	}
	function dragonqueen_install() {
    	module_addeventhook("forest", "return 100;");
    	module_addhook("hprecalc");
		return true;
	}
	
	function dragonqueen_uninstall() {
		return true;
	}	
    
	function dragonqueen_dohook ($hookname, $args){
			switch($hookname){
	case "hprecalc":
		$args['total'] -= get_module_pref("extrahps");
		if (!get_module_setting("carrydk")) {
			$args['extra'] -= get_module_pref("extrahps");
			set_module_pref("extrahps", 0);
		}
		break;
	}
	return $args;
	}	
	function dragonqueen_runevent ($type) {
	global $session;
		$favor = get_module_setting("favor");
		$from = "forest.php?";
		$session['user']['specialinc'] = "module:dragonqueen";
		page_header("Dragon Queen");
		$op = httpget('op');
	if ($op=="" || $op=="search"){
		output("`3You come across the ivy shrouded entrance to what appears to be a cavern.");
		output("What do you do?");
		addnav("The Cave");
		addnav("Pull Back the Ivy and enter the Cavern", "forest.php?op=enter");
		addnav("Turn tail and Run", "forest.php?op=run");
		addnav("Back Away Slowly", "forest.php?op=back");
		}elseif ($op=="enter") {
			output("`6You pull back some of the ivy and find yourself in a dank shallow cave littered with the bones of warriors and various forest creatures");
			output_notl("`n`n");
			output("`^Shuddering slightly at the sight before you, you return to the forest.");
			addnav("Return to the Forest", "forest.php?");
			$session['user']['specialinc'] = "";
		}elseif ($op=="run"){
			output("`2Fearing for your life you turn tail for safer parts of the forest");
			addnav("Return to the Forest", "forest.php?");
			$session['user']['specialinc'] = "";
		}elseif ($op=="back") {	
			output("`3You back slowly away from the entrance, suddenly the ground opens up under your feet, teetering on the edge, you slowly loose your balance");
			output_notl("`n`n");
			output("Hitting the ground below with a solid thwack, you pull yourself to your feet, check yourself for injuries, luckily there are none, and slowly take stock of your surroundings");
			addnav("The Cavern");
			addnav("Continue", "forest.php?op=continue");
			addnav("Close Your Eyes and Hope for the best", "forest.php?op=hope");
		}elseif ($op=="hope"){
			output("`6You close your Eyes tightly, and hope that someone or something intervenes and saves your neck.");
			output_notl("`n`n");
			output("`7Suddenly a howling wind comes out of nowhere, it rips at your armor, seeming to find every small crack to enter it chilling you to the bone.  You're picked up off your feet, and slammed against walls and the roof of the cavern, just as suddently the wind disappears, you open your eyes.");
			output_notl("`n`n");
			output("Finding yourself back in the forest, rather tattered and torn from your experience.");
			output_notl("`n`n");
			output("`^You loose 4 forest fight.");
				$prev = $session['user']['turns'];
				if ($prev >= 4) $session['user']['turns']-=4;
				else if ($prev < 4) $session['user']['turns']=0;
				$current = $session['user']['turns'];
				$lost = $prev - $current;
				addnav("Return to the Forest", "forest.php?");
				$session['user']['specialinc'] = "";
		}elseif ($op=="continue") {
			output("`7Looking around slowly you see there are several tunnels running off the main cavern, and in one corner the remains of a warrior, grasped in his bony hand is a message.");
			output_notl("`n`n");
			output("Prising the note from his grasp you read it.");
			output_notl("`n`n");
			output("`@Be Warned all Ye Who enter here.  This cavern is the Lair of the `^DragonQueen.  `@There are many traps to be found, but the reward is great..");
			output_notl("`n`n");
			output("`7the scrawled writing looks suspiciously as if the writer was going to continue on, but something stopped him.. that and the drops of blood soaked into the parchment."); 
			output_notl("`n`n");
			output("Which Tunnel will you pick?");
			addnav("The Cavern");
			addnav ("Tunnel One", "forest.php?op=tunnel");
			addnav ("Tunnel Two", "forest.php?op=tunnel");
			addnav ("Tunnel Three", "forest.php?op=tunnel");
			addnav ("Tunnel Four", "forest.php?op=tunnel");
			addnav ("Tunnel Five", "forest.php?op=tunnel");
		}elseif ($op=="tunnel") {
			switch (e_rand (1, 5)){
			case 1:
			output("`7Halfway down the tunnel, you come across a cave-in.");
			output_notl("`n`n");
			output("`3Sighing you turn around and head back to the cavern.");
			output_notl("`n`n");
			output("`7Back in the Cavern. You try to decide which tunnel to pick this time.");
			addnav("The Cavern");
			addnav("Continue", "forest.php?op=continue");
			break;
			case 2:
			output("`3Heading down the tunnel you see a glimmer of light in the distance, following the light you find yourself back in the forest, none the worse for wear.");
			output_notl("`n`n");
			output("`3You see something glittering off to the left of you, looking closer you have found 2 gems");
			$session ['user']['gems']+=2;
			addnav("Return to the Forest", "forest.php?");
			$session['user']['specialinc'] = "";
			break;
			case 3:
			output("`7Starting down the tunnel, you twist your ankle, hobbling back to the cavern, you realise there is no way out for you, you are going to die here.");
			output_notl("`n`n");
			output("Since your body now lies in a deep cavern.");
			output("`n`n");
			output("You lose 10% of your experience.  You may continue playing again tomorrow.");
			$session['user']['alive']=false;
			$session['user']['hitpoints']=0;
			$session['user']['experience']*=0.9;
			$gold = $session['user']['gold'];
			$session['user']['gold'] = 0;
			addnav("Daily News","news.php");
			addnews("The body of %s was discovered in a deep cavern.",$session['user']['name']);
			$session['user']['specialinc'] = "";
			break;
			case 4:
			output("`7You walk around a curve in the tunnel straight into a underground river, and find yourself standing on a shelf with an waterfall showering down upon you.");
			output_notl("`n`n");
			output("As you Stand there you feel your Stamina Increase!");
			output_notl("`n`n");
			$reward = e_rand(1, get_module_setting("maxhp"));
			$hptype = "permanently";
			if (!get_module_setting("carrydk") ||
			(is_module_active("globalhp") &&
			 !get_module_setting("carrydk", "globalhp")))
			$hptype = "temporarily";
			$hptype = translate_inline($hptype);
			output("Your maximum hitpoints have been `b%s`b increased by %s!",$hptype, $reward);
			output_notl("`n`n");
			$session['user']['maxhitpoints'] += $reward;
			$session['user']['hitpoints'] += $reward;
			set_module_pref("extrahps", get_module_pref("extrahps")+$reward);
			output("You find yourself back in the forest");
			addnav("Return to the Forest", "forest.php?");
			$session['user']['specialinc'] = "";
			break;
			case 5:
			output("`7You start down the tunnel, hearing a rustling sound you see a `^fairy `7trapped in a small cage in a small cave to your right.");
			output_notl("`n`n");
			output("She calls out to you, `^Help me please, An Evil Troll has imprisoned me, free me and I will reward you");
			output_notl("`n`n");
			output("`7Will you help?");
			addnav("The Fairy");
			addnav("Free Her", "forest.php?op=free");
			addnav("Continue On Your Way", "forest.php?op=onway");
			break;
		}
		}elseif ($op=="free") {
			switch (e_rand (1, 3)){
			case 1:
			output("`^You reach into the small cave and pull the fairy and her cage free, opening the door the small thing flitters out.");
			output_notl("`n`n");
			output("A glimmering mist engulfs you and you loose conciousness, when you awake, you are further into the cavern, the fairy has helped you on your way.");
			output_notl("`n`n");
			output("There is a turn in the tunnel ahead of you.");
			addnav("Freeing the Fairy");
			addnav("Turn down the tunnel","forest.php?op=turn");
			break;
			case 2: 
			output("`^You reach into the small cave and pull the fairy and her cage free, opening the door the small thing flitters out.");
			output_notl("`n`n");
			output("Darkness engulfs you, when you finally awaken you are back in the main cavern, minus a forest fight.");
			$session['user']['turns']-=1;
			addnav("Continue", "forest.php?op=continue");
			break;
			case 3:
			output("`^You reach into the small cave and pull the fairy and her cage free, opening the door the small thing flitters out.");
			output_notl("`n`n");
			output("A golden light envelops you, when it fades you realise you've gained 2 forest fights and continue on your way.");
			$session['user']['turns']+=2;
			addnav("Continue On Your Way", "forest.php?op=onway");
			break;
		}
		}elseif ($op=="turn") {
			output("`7You turn down the tunnel and come to a fork");
			output("Which will you choose?");
			addnav("Take the Left","forest.php?op=choice");
			addnav("Straight Ahead","forest.php?op=choice");
			addnav("Take the Right","forest.php?op=choice");
		}elseif ($op=="onway") {
			output("`7Continuing down the tunnel you come across a small pocket of`$ g`5e`2m`6s`7, you quickly prise a few from the wall.");
			$session ['user']['gems']+=1;
			output_notl("`n`n");
			output("`#You have gained a gem!");
			output_notl("`n`n");
			output("`7Continuing on, you come to an underground stream, to your left is a small boat, to your right there is a path leading to another tunnel.");
			output_notl("`n`n");
			output("what will you Do?");
			addnav("The Stream");
			addnav ("Take the Path", "forest.php?op=path");
			addnav ("Take a Boat", "forest.php?op=boat");
			addnav ("Swim Across", "forest.php?op=swim");
		}elseif ($op=="swim"){
			output("`7Diving in you start to swim across the stream, to your left you see a stream of bubbles, panicking you start to swim faster, keeping an eye on the bubbles.");
			output_notl("`n`n");
			output("The bubbles are steadily getting closer, you don't think you're going to make it to the shoreline.");
			output_notl("`n`n");
			output("Suddenly a giant tentacle reaches up from the depths and drags you down below, gasping for breath, you look into the single eye of a giant octopus.");
			output_notl("`n`n");
			output("You release the last of your air and resign yourself to dieing, and just as suddenly as you were caught you find yourself free, quickly dragging yourself back to the shoreline,");
			output_notl("`n`n");
			output("Trembling and shivering with cold you reconsider your choice of swimming!");
			addnav("The Stream");
			addnav ("Take the Path", "forest.php?op=path");
			addnav ("Take a Boat", "forest.php?op=boat");
		}elseif ($op=="path"){
			output("`QYou turn to the right and follow the path, eventually it leads you to a small hut, set into the side of one of the tunnels, knocking upon the door, a large ugly Troll opens the door and glares at you.");
			output_notl("`n`n");
			output("He gruffly says `^What do you want?");
			output_notl("`n`n");
			output("`QYou consider this, replying `^I just want to get out of here.");
			output_notl("`n`n");
			output("`QThe Troll offers to guide you out for 2 gems, do you take him up on his offer?");
			addnav("The Troll");
			addnav ("Pay him", "forest.php?op=pay");
			addnav ("Don't Pay", "forest.php?op=don");
		}elseif ($op=="don"){
			output("`^No Way, I'm not paying you 2 gems, I'll find my own way out");
			output_notl("`n`n");
			output("`2Turning on your heel you wander around the cave system for quite some time before eventually finding your way out, you loose a forest fight.");
			$session ['user']['turns']-=1;
			addnav("Return to the Forest", "forest.php?");
			$session['user']['specialinc'] = "";
		}elseif ($op=="pay") {
			output("`Qnodding your head, you quickly pull 2 gems from your gem pouch and thrust them at the Troll, he quickly stows them away, and turns to swiftly lead you to the surface.");
			$session ['user']['gems']-=2;
			addnav("Return to the Forest", "forest.php?");
			$session['user']['specialinc'] = "";			
		}elseif ($op=="boat"){
			output("`3You quickly untie the small boat and jump onboard, rowing your way across the stream.  From the corner of your eye you see a stream of bubbles heading straight for you.");
			output_notl("`n`n");
			output("`3Hitting the shore, you jump quickly from the boat, turning to watch a large tentacle, crush the boats, the remains of which slowly float off downstream. Wiping your forehead after such a close call, you?");
			output("Take the left tunnel, take the right tunnel?");
			addnav("The Fork in the Road");
			addnav ("Take the left", "forest.php?op=choice");
			addnav ("Take the right", "forest.php?op=choice");
			addnav("Straight ahead", "forest.php?op=choice");
		}elseif ($op=="choice") {
			switch (e_rand (1, 3)){
			case 1:
			output ("`3The `^Dragon Queen `3beckons you closer, feeling no fear you approach her.  She smiles down at you.");
			output_notl("`n`n");
			output("`6My gratitude to you, you have left my nest along with its eggs undisturbed, I bestow upon you a gift.");
			output_notl("`n`n");
            output ("`3Nudging you gently, she pushes you in the direction of the back of the cavern, a large `7silver `3filigree embroidered curtain covers a archway in the back of the cavern, lifting it aside you are blinded by a sudden light....");
            output_notl("`n`n");
            output ("`#Blinking at the sudden brightness you realise she has given you the gift of a NewDay");
            output_notl("`n`n");
			rawoutput("<IMG SRC=\"images/dq_gold.gif\"><BR>\n");
			rawoutput("<div style=\"text-align: left;\"><a href=\"http://www.arcanetinmen.dk\" target=\"_blank\">copyright and used with permission of Arcane Tinmen ApS 1999 - 2003, http://www.arcanetinmen.dk</a><br>");
			$session['user']['lasthit']="0000-00-00 00:00";
			$session['user']['restorepage']="forest.php";
			break;
			case 2:
			$a = ($session['user']['deathpower']*($favor/100));
			output(array("`Qyou stumble into a cave full of dragon eggs, cracking several open.. a frightening roar is heard, and you run from the cave as fast as you can.. a cold hand reaches out to grasp you just as you leap from the cave entrance, you loose %s favor",$a));
			$session['user']['deathpower']-=$a;
			$session['user']['specialinc'] = "";
			break;
			case 3:
			$id=$session['user']['acctid'];
			$sql = "SELECT acctid,name FROM ".db_prefix("accounts")." WHERE alive=1 and acctid<>'$id' ORDER BY rand(".e_rand().") LIMIT 1";
			$res = db_query($sql);
	 	   	$row = db_fetch_assoc($res);
		    $random = $row['name'];
			output("`7You stumble and fall, you can feel a warm breath on the back of your neck and something crunching under your hand, raising your head slightly, you find yourself looking at the claw of a Large `)Obsidian Dragon.  `7He appeared to have been eating someone who looks rather like %s`7.  Looking down you realise you've crushed a large dragon egg.",$random);
			output_notl("`n`n");
			output("With a sudden scream of rage, the Dragon King attacks.");
			output_notl("`n`n");
			rawoutput("<IMG SRC=\"images/dq_black.gif\"><BR>\n");
			rawoutput("<div style=\"text-align: left;\"><a href=\"http://www.arcanetinmen.dk\" target=\"_blank\">copyright and used with permission of Arcane Tinmen ApS 1999 - 2003, http://www.arcanetinmen.dk</a><br>");
			addnav("Dragon King","runmodule.php?module=dragonqueen&op=attack");
			break;
			}
			addnav("Return to Forest","forest.php");
			$session['user']['specialinc'] = "";
		}
		page_footer();
		}
function dragonqueen_run(){
	global $session;
	$id=$session['user']['acctid'];
	$op=httpget('op');
	page_header("Dragon King");
	if ($op=="attack"){
		$level = $session['user']['level']+2;
		$dk = round($session['user']['dragonkills']*.5);
		$badguy = array(
			"creaturename"=>"`7Dragon King",
			"creaturelevel"=>$level,
			"creatureweapon"=>"`7Obsidian Claws `5and `#Ice Breath",
			"creatureattack"=>round($session['user']['attack'])+1,
			"creaturedefense"=>round($session['user']['defense'])+1,
			"creaturehealth"=>round($session['user']['maxhitpoints']*1.76),
			"diddamage"=>0,
			"type"=>"DragonKing");
		$session['user']['badguy']=createstring($badguy);
		$op="fight";
		httpset("op", "fight");
	}
	if ($op=="fight"){ $battle=true; }
	if ($battle){       
		include("battle.php");  
		if ($victory){
			output("`n`^The Dragon King lays at your feet.");
			$expbonus=$session['user']['dragonkills']*4;
			$expgain =($session['user']['level']*e_rand(18,26)+$expbonus);
			$session['user']['experience']+=$expgain;
			output("`@You gain `#%s experience`@.`n`n",$expgain);
			addnews("%s `^defeated the `)Dragon King`^.",$session['user']['name']);
			if (is_module_active('witchgarden')){
				$a = get_module_pref("scale","witchgarden",$id)+1;
				set_module_pref("scale",$a,"witchgarden",$id);
				output("  `)You pick one of his scales from the body, sure it will be of use later.`n`n");
			}
			output("`^Feeling somewhat tired yet exhilerated, you return to the forest.");
			addnav("Return to the Forest", "forest.php?");
			$session['user']['specialinc'] = "";
		}elseif($defeat){
			$session['user']['specialinc'] = "";
			$session['user']['alive'] = false;
			$session['user']['hitpoints'] = 0;
			$session['user']['gold'] = 0;
			output("You can hear the triumphant roar and maybe the cracking of one last bone as your lifeforce fades, You're Dead!!");
			$exploss = round($session['user']['experience']*.1);
			$session['user']['experience']-=$exploss;
			output("You have lost %s experience",$exploss);
			output("You've lost all your gold");
			output("You may continue playing again tomorrow.");
			addnav("Daily news","news.php");
			addnews("%s`2 was seen entering a large cavern, they weren't seen again.",$session['user']['name']);
		}else{
			require_once("lib/fightnav.php");
			fightnav(true,false,"runmodule.php?module=dragonqueen");
		}
	}
	page_footer();
}
?>                