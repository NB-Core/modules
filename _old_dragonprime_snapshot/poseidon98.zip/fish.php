<?php
//addnews ready
/**
* Version:      1.8
* Date:         November 14, 2005
* Author:       Kevin Hatfield - Arune http://www.dragonprime.net
* LOGD VER:     Module for 0.9.8
*
* Module Updated by Sichae.
* Updated - Transalation Ready.
*/
require_once("lib/http.php");
function fish_getmoduleinfo(){
        $info = array(
                "name"=>"Fishing Module",
                "author"=>"<a href=\"http://logd.ecsportal.com\" target=_new>Arune - Kevin Hatfield</a>",
                "version"=>"1.8",
                "category"=>"Poseidon Pool",
				"vertxtloc"=>"http://www.dragonprime.net/users/khatfield/",
				"description"=>"Allows for users to fish in the Poseidon Pool Area",
                "download"=>"http://dragonprime.net/users/khatfield/poseidon98.zip",
                 );
        return $info;
}
function fish_install(){
        if (!is_module_active('fish')){
                output("`4Installing Fishing Module.`n");
        }else{
                output("`4Updating Fishing Module.`n");
        }
        module_addhook("pool");
	module_addhook("moderate");
        return true;
}
function fish_uninstall(){
        return true;
}
function fish_dohook($hookname, $args){
        global $session;
        switch($hookname){
        case "moderate":
                $args['fishing'] = "Fishing Hole";
                break;
        case "pool":
                addnav("Fishing Hole","runmodule.php?module=fish");
            break;
   }
      return $args;
}
function fish_run(){
                global $session;
                $op = httpget('op');
                checkday(); 
		page_header("The Fishing Hole"); 
//check and display inventory
	output("`2You have in your pack.`n");
//Worms
$worms=(get_module_pref("worms","bait"));
if (get_module_pref("worms","bait")>0){ //These were added due to counters going into negative.
output("`!bait worms - %s`n",$worms);
}else{
output("`!bait worms - 0`n");
}
$inventory=(get_module_pref("worms","bait"));
//Minnows
$minnow=(get_module_pref("minnows","bait"));
if (get_module_pref("minnows","bait")>0){ //These were added due to counters going into negative.
output("`!Minnows - %s`n",$minnow);
}else{
output("`!Minnows - 0`n");
}
$inventory+=(get_module_pref("worms","bait"));
$fishturns=(get_module_pref("fishturn","bait"));
if (get_module_pref("fishturn","bait")>0){ //These were added due to counters going into negative.
output("`!Fishing Turns - %s`n",$fishturns);
}else{
output("`!Fishing Turns - 0`n");
}
if ($op == ""){
		//output("`c<img src='images/fishing.jpg''>`c", true);
		addnav("To do"); 
		if (get_module_pref("minnows","bait") > 0 and (get_module_pref("fishturn","bait") > 0)) addnav("`!Cast Minnow","runmodule.php?module=fish&op=check1");
		if (get_module_pref("worms","bait") > 0 and (get_module_pref("fishturn","bait") > 0)) addnav("`!Cast Worm","runmodule.php?module=fish&op=check2");
		if (get_module_pref("minnows","bait") == 0 and (get_module_pref("worms","bait") == 0)) output("Currently you do not possess any bait.");
		if (get_module_pref("fishturn","bait") == 0) output ("Currently you have 0 fishing turns available"); 
		addnav("R?Return to Pool","runmodule.php?module=pool");
		addnav("B?Bait Shop","runmodule.php?module=bait");
		output("`n`n`7You follow the path around to the large fishing area...`n");
		output("Looking around you see other villagers lounging on the weathered benches, with a sunny day like this");
		output("the fishing should be excellent.`n`n");
	}
if ($op == "check1"){
	output("`n`nYou cast your line...`n`n");
        set_module_pref('minnows',(get_module_pref('minnows','bait')-1),'bait');
	set_module_pref('fishturn',(get_module_pref('fishturn','bait')-1),'bait');
              check1();
}
if ($op == "check2"){
	output("`n`nYou cast your line...`n`n");
        set_module_pref('worms',(get_module_pref('worms','bait')-1),'bait');
	set_module_pref('fishturn',(get_module_pref('fishturn','bait')-1),'bait');
              check2();
}
require_once("lib/commentary.php");
addcommentary();
output("`n`2-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-`n");
viewcommentary("fishing", "Chat here", 1000, "says");
page_footer();
 }
/*******************
Fishing With Minnows
*******************/
function check1(){ 
global $session; 
switch (e_rand(1,40)){ 
case 1: 
output("A boot?!`n"); 
output("You spend 10 minutes trying to get the boot off your hook...`n"); 
output("Taking so long.`n`n"); 
output("`bYou lose an extra fishing turn`n`n"); 
set_module_pref('fishturn',(get_module_pref('fishturn','bait')-1),'bait');
addnav("Fishing Hole","runmodule.php?module=fish");

break; 

case 2: 
output("`@ You reel in a small pouch... `n`n");  
output("`^Inside you find 200 gold !!`^`n`n"); 
$session['user']['gold']+=200; 
addnav("Fishing Hole","runmodule.php?module=fish");

break; 

case 3: 
output("You throw out your line, sitting down you have been bitten by a `!Rattle Snake`!!!! `n`n"); 
$b=e_rand(10,20); 
output("You Lose %s hitpoints",$b); 
$session['user']['hitpoints'] -= $b; 
output("`!You are about to pass out!`!`n"); 
output("`4You decide you have had enough fishing for today..`n`n"); 
set_module_pref('fishturn',0,'bait');
addnav("Return to Pool","runmodule.php?module=pool");

break; 

case 4: 
output("You have came up empty! `n`n"); 
addnav("Fishing Hole","runmodule.php?module=fish");

break; 

case 5: 
output("`@You have caught a branch!!!`n`n"); 
addnav("Fishing Hole","runmodule.php?module=fish");

break; 

case 6: 
output("`2Your hook gets caught in your hand!! `nYou lose 12 Hitpoints. `n`n"); 
$session['user']['hitpoints']-=12; 
addnav("Fishing Hole","runmodule.php?module=fish");

break; 

case 7: 
output("You have came up empty!`n`n"); 
addnav("Fishing Hole","runmodule.php?module=fish");

break; 

case 8: 
output("As you were reeling in your line you notice something shining beside you...`n");
output("`^`bYou find 1 gem !!! `^`b`n`n"); 
$session['user']['gems']+=1; 
addnav("Fishing Hole","runmodule.php?module=fish");

break; 

case 9: 
output("`@You have snagged something.. `n`n");
output("`!Reeling it in you find a small pouch of worms... `n`n");
output("`&`bYou gain 3 worms!`n Free bait!`b`n`n"); 
set_module_pref('worms',(get_module_pref('worms','bait')+3),'bait');
addnav("Fishing Hole","runmodule.php?module=fish");

break; 

case 10: 
output("`!You have caught a shiny gem! `n`n"); 
output("`7As you hold the gem in your hands..`n"); 
output("A bright flash of light illuminates the area!!!`n`n"); 
        if    (strchr($session['user']['weapon'],"Glowing")){
	output("`b`4Your weapon continues to glow!");
	addnav("Return to Fishing","runmodule.php?module=fish");
	break;
	}else{	
output(" You feel stronger"); 
debuglog("Weapon - Glowing enhancement from pool");
$session['user']['hitpoints']+=10;  
$session['user']['defense']+=1; 
$newweapon = "Glowing ".$session[user][weapon];
$session['user']['weapon']=$newweapon;
$session['user']['weapondmg']+=2;
}
addnav("Fishing Hole","runmodule.php?module=fish");

break; 

case 11: 

output("`4The wind catches your line and it wraps around your neck...hooking into your throat!`n`n");
output("`3You are choking to death!`n");
output("`7You have fallen unconscious!`n");
$session['user']['hitpoints']=0;
$session['user']['alive']=false;
$name=$session['user']['name'];
addnews("`@%s`@ has `5hung`@ themselves on the banks fishing.",$name); 
addnav("DIE!","graveyard.php");

break; 

case 12: 
output("`3You lost your bait!`3 `n`n"); 
addnav("Fishing Hole","runmodule.php?module=fish");

break; 

case 13:
output("You have came up empty!`n`n");
addnav("Fishing Hole","runmodule.php?module=fish");

break;

case 14: 
output("`7You fall into the water!`n"); 
output("Swimming for your like you pull yourself on the bank, soaking wet.`n");
output("`^You have lost 5 charm!`n`n"); 
$session['user']['charm']-=5; 
addnav("Fishing Hole","runmodule.php?module=fish");

break; 

case 15: 
output("`3Your minnow flies off your hook!`3 `n`n"); 
addnav("Fishing Hole","runmodule.php?module=fish");

break; 

case 16: 
output("You catch an enormous bass !`n`n");
output("`7Onlookers gather around you to see your catch!`n"); 
output("`^You gain 3 charm!!`^`n`n"); 
$session['user']['charm']+=3; 
addnav("Fishing Hole","runmodule.php?module=fish");

break; 

case 17: 
output("`@You get a bite! `n`n");
output("`6Unfortunately it catches you off-guard...You snatch your rod, stumbling back you kick over your pail`n");
output("of minnows!`n");
output("`4You lost all your minnows!`n`n"); 
set_module_pref('minnows',0,'bait');
addnav("Fishing Hole","runmodule.php?module=fish");

break; 

case 18: 
output("`@You get a bite!`n`n"); 
output("You jump back and reel furiously!`n");
output("`7TOO Much Pressure! You broke your line!`n"); 
output("`4Your pole flies back hitting you in the face!`n");
output("`4You lose 40 hitpoints!`n`n");
$session['user']['hitpoints']-=40; 
addnav("Fishing Hole","runmodule.php?module=fish");

break; 

case 19: 
output("`2You catch a rotten corpse! `2`n`n"); 
output("`7........`n");
output("You decide to check its pockets.`n");
output("`^You have found 250 gold and lose 2 turns!`n`n");
$session['user']['gold']+=250; 
set_module_pref('fishturn',(get_module_pref('fishturn','bait')-1),'bait');
addnav("Fishing Hole","runmodule.php?module=fish");

break; 

case 20:
output("You have came up empty!`n`n");
addnav("Fishing Hole","runmodule.php?module=fish");

break;

case 21: 
output("`2Casting out you notice a box of worms near you!`2`n`n");
output("`^You have found 3 worms!`n`n"); 
set_module_pref('worms',(get_module_pref('worms','bait')+3),'bait');
addnav("Fishing Hole","runmodule.php?module=fish");

break; 

case 22: 
output("You have caught a small pouch! `n`n"); 
output("Inside you find 2 gems !`n");
output("`^You Gain 2 gems!`^ `n`n"); 
$session['user']['gems']+=2;   
addnav("Fishing Hole","runmodule.php?module=fish");

break; 

case 23:
output("You have came up empty!`n`n");
addnav("Fishing Hole","runmodule.php?module=fish");

break;

case 24:
output("You have came up empty!`n`n");
addnav("Fishing Hole","runmodule.php?module=fish");

break;

case 25:
output("As your minnow hits the water you feel a huge surge of energy!`n`n");
output("The god's are looking after you today!`n");
output("`^You feel strong!`n`n");
$session['user']['attack']+=15;
addnav("Fishing Hole","runmodule.php?module=fish");

break;

case 26:
output("`4You stumble over a rock and fall into the water! `0!`n`n");
output("Undoubtedly you hit your head and washed back onto the shore..`n");
output("Upon waking...You notice all your gold and gems are missing!`n`n");
$session['user']['hitpoints']=1;
set_module_pref('fishturn',0,'bait');
$session['user']['gold']=0;
$session['user']['gems']=0;
addnav("Leave","runmodule.php?module=pool");

break;

case 27: case 28: case 29: case 30: case 31: case 32: case 33: case 34: case 35: case 36: case 37: case 38: case 39: case 40:

output("You have came up empty! `n`n");
addnav("Fishing Hole","runmodule.php?module=fish");

break;
	} 
	} 
/************************
Fishing with worms
************************/
function check2(){
global $session;
switch (e_rand(1,35)){
case 1:

output("You have came up empty! `n`n");
addnav("Fishing Hole","runmodule.php?module=fish");

break;

case 2:

output("You have came up empty! `n`n");
addnav("Fishing Hole","runmodule.php?module=fish");

break;

case 3:

output("Reeling in your line you have caught a large heavy bag...`n");
output("Looking inside the bag you find.`n");
output("`^3 Gems!`0`n`n");
$session['user']['gems']+=3;
addnav("Fishing Hole","runmodule.php?module=fish");

break;

case 4:

output("You reel in a monstrous catch!`n");
output("Many fishermen look at you in total disgust!`n");
output("`^You have lost 10 Charm!`0`n`n");
$session['user']['charm']-=10;
addnav("Fishing Hole","runmodule.php?module=fish");

break;

case 5:

output("You have snagged your line!`n");
output("You lost your bait..`n`n");
addnav("Fishing Hole","runmodule.php?module=fish");

break;

case 6:

output("Reeling in your line, you snag a small bucket..`n");
output("Inside you find `^15 minnows`0!`n`n");
output("`4Emptying the bucket into your pail you find `12 gems`4 buried inside!`n`n");
set_module_pref('minnows',(get_module_pref('minnows','bait')+15),'bait');
$session['user']['gems']+=2;
addnav("Fishing Hole","runmodule.php?module=fish");

break;

case 7:

output("You have came up empty! `n`n");
addnav("Fishing Hole","runmodule.php?module=fish");

break;

case 8:

output("You have came up empty! `n`n");
addnav("Fishing Hole","runmodule.php?module=fish");

break;

case 9:

output("You have came up empty! `n`n");
addnav("Fishing Hole","runmodule.php?module=fish");

break;

case 10:

output("You have came up empty! `n`n");
addnav("Fishing Hole","runmodule.php?module=fish");

break;

case 11:

output("You have came up empty! `n`n");
addnav("Fishing Hole","runmodule.php?module=fish");

break;

case 12:

output("You have came up empty! `n`n");
addnav("Fishing Hole","runmodule.php?module=fish");

break;

case 13:
output("As your reeling your line in your hook snags something shiny..`n");
output("A sharp jolt of energy streams throughout your body!`n`n");
output("`^You gain 10 defense today!`0`n`n");
$session['user']['defense']+=10;
addnav("Fishing Hole","runmodule.php?module=fish");

break;

case 14:
addnav("Fishing Hole","runmodule.php?module=fish");
output("`!You have caught a gleaming crytal! `n`n");
output("`7As you hold the crystal in your hands..`n");
output("A bright flash of light illuminates the area!!!`n`n");
        if    (strchr($session['user']['weapon'],"Crystalized")){
        output("`b`4Your weapon continues to crystalize!");
        break;
        }else{
output(" Your weapon changes its form..`n`n");
debuglog("Weapon - Crystalized enhancement from pool");
$session['user']['hitpoints']+=20;
$session['user']['attack']+=15;
$session['user']['defense']+=15;
$newweapon = "Crystalized ".$session[user][weapon];
$session['user']['weapon']=$newweapon;
$session['user']['weapondmg']+=3;
}

break;

case 15:

output("You hook an extremely large fish...`n");
output("With fear of losing your pole you wrap your weapon strap around the handle and your belt!`n");
output("The fish begins to struggle and flip out of the water...Realizing this maybe more than you can handle!`n");
output("You have lost your step and drug into the water face first..`n");
output("Struggling to get your belt lose you are running out of air quickly!`n");
if ($session['user']['attack']<40){
 output("`4The line is held too tight, you cannot break free and begin to slowly drown`n`n");
 $session['user']['alive']=false;
 $session['user']['hitpoints']=0;
 }else{
 output("`!You have broken free! Swimming to the shore...You decide thats enough of this for today!`n`n");
 $session['user']['hitpoints']=1;
}
addnav("Fishing Hole","runmodule.php?module=fish");

break;

case 16:

output("You have came up empty! `n`n");
addnav("Fishing Hole","runmodule.php?module=fish");

break;

case 17:

output("You have came up empty! `n`n");
addnav("Fishing Hole","runmodule.php?module=fish");

break;

case 18:

output("You have came up empty! `n`n");
addnav("Fishing Hole","runmodule.php?module=fish");

break;

case 19:

output("You have came up empty! `n`n");
addnav("Fishing Hole","runmodule.php?module=fish");

break;

case 20:

output("`0You have caught a bag full of `^gold`0!`n");
output("Greedily counting your gold you do not notice another fisherman running over to you!`n");
output("`4BOOM! `0You have been hit by something blunt...You are knocked unconscious!`n`n");
output("Upon waking...You notice all your gold and gems are missing!`n`n");
$session['user']['hitpoints']=1;
$session['user']['gold']=0;
$session['user']['gems']=0;
addnav("Fishing Hole","runmodule.php?module=fish");

break;

case 21:

output("You have caught ....`n");
output("`^a chisel!`n");
output("`&Thinking over the many uses...`0You decide to touch up your armor.`n");
output("`0Wow..Your armor sure has taken a beaten lately!`n");
if    (strchr($session['user']['armor'],"Modified")){
        output("`b`4Your armor is already modified!`n`n");
	addnav("Fishing Hole","runmodule.php?module=fish");
        break;
        }else{
output(" Your armor smooths out and looks much better!`n");
debuglog("Armor - Chisel enhancement from pool");
$session['user']['defense']+=5;
$newarmor = "Modified ".$session[user][armor];
$session['user']['armor']=$newarmor;
$session['user']['charm']+=5;
output("Hey! You even look better!`n");
output("`^You gain 5 charm!`n`n");
		}
addnav("Fishing Hole","runmodule.php?module=fish");

	break;

case 22: case 23: case 24: case 25: case 26: case 27: case 28: case 29: case 30: case 31: case 32: case 33: case 34: case 35:
output("You have came up empty! `n`n");
addnav("Fishing Hole","runmodule.php?module=fish");

break;
	}
page_footer(); 
}
?>
