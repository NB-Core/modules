<?php
//addnews ready
/**
* Version:      1.8
* Date:         November 14, 2005
* Author:       Kevin Hatfield - Arune http://www.dragonprime.net
* LOGD VER: 	Module for 0.9.8
*
* Module Updated by Sichae.
* Updated - Transalation Ready.
*/
require_once("lib/http.php");
function bait_getmoduleinfo(){
        $info = array(
                "name"=>"Bait Shop",
                "author"=>"<a href=\"http://logd.ecsportal.com\" target=_new>Arune - Kevin Hatfield</a>",
                "version"=>"1.8",
                "category"=>"Poseidon Pool",
				"vertxtloc"=>"http://www.dragonprime.net/users/khatfield/",
				"description"=>"Allows for users to buy bait for the Poseidon Pool Area",
                "download"=>"http://dragonprime.net/users/khatfield/poseidon98.zip",
		"prefs"=>array(
			"Poseidon Pool Module User Preferences,title",
			"worms"=>"worms,int|0",
			"minnows"=>"minnows,int|0",
			"fishturn"=>"fishturn,int|0",
		),
	                "settings"=>array(
                        "BaitShop Module Settings,title",
                        "fishone"=>"DK 1+ How Many Fish Turns?,range,0,5,1",
			      "wormcost"=>"Worm Cost,int|112",
			      "minnowcost"=>"Minnow Cost,int|138",
			),
               	);
	return $info;
}
function bait_install(){
	if (!is_module_active('bait')){
		output("`4Installing Bait Shop Module.`n");
	}else{
		output("`4Updating Bait Shop Module.`n");
	}
	module_addhook("newday");
	module_addhook("pool");
	module_addhook("dragonkill");
	return true;
}
function bait_uninstall(){
        return true;
}

function bait_dohook($hookname,$args){
	global $session;
	switch($hookname){
		case "newday":
			if ($session['user']['dragonkills']>0)set_module_pref('fishturn', get_module_setting('fishone'));
		break;
		case "pool":
			if ($session['user']['dragonkills']>0) addnav("Bait Shop","runmodule.php?module=bait");
		break;
                case "dragonkill":
                set_module_pref('minnows',0);
                set_module_pref('worms',0);
		break;
	}
	return $args;
}
function bait_run(){
		global $session;
		$op = httpget('op');
		$buy = $_POST['buy'];
		require_once("common.php");
		checkday();
		page_header("Kerra's Baitshop");
		output("`@`c`bKerra's Baitshop`b`c`n");
		output("`2You have in your pack.`n");
		$worms=(get_module_pref('worms'));
		output("`1bait worms - %s`n",$worms);
		$inventory=(get_module_pref('worms'));
		$minnow=(get_module_pref('minnows'));
		output("`!Minnows - %s`n",$minnow);
		$inventory+=(get_module_pref('minnows'));
		$space=(50 - $inventory);
	        $wormcost=get_module_setting('wormcost');
	        $minnowcost=get_module_setting('minnowcost');
		if ($inventory < 50) output("`2You have space left for $space more items.`n`n");
		if ($inventory > 49) output("`4You notice that your Pack is full.`n`n");
	if ($op == ""){
	if ($session['user']['dragonkills']>1){
	output("`5Kerra is behind the counter, she says \"`6What is it you would like today?`5\"`n");
		addnav(array("`!Bait Worms (%s gold)", $wormcost), "runmodule.php?module=bait&op=worms");
		addnav(array("`!Minnows (%s gold)", $minnowcost),"runmodule.php?module=bait&op=minnows");
	addnav("Return to Pool","runmodule.php?module=pool");
	}else{
	output("Kerra walks up to the counter, she says \"`6I'm sorry but you are not experienced enough to have use of this area yet!`0\"`n`n");
	addnav("Return to Pool","runmodule.php?module=pool");
   }
}
if ($op == "trade"){
	        $wormcost=get_module_setting('wormcost');
	        $minnowcost=get_module_setting('minnowcost');
                output("`5Kerra says \"`6What else?`5\"`n");
		addnav(array("`!Bait worms (%s gold)", $wormcost), "runmodule.php?module=bait&op=worms");
		addnav(array("`!Minnows (%s gold)", $minnowcost),"runmodule.php?module=bait&op=minnows");
		addnav("`@Return to Pool","runmodule.php?module=pool");
}
//Selections
if ($op == "worms"){
        output("`3Bait worms are going for %s gold, would you like to buy?`n",$wormgold);
        addnav("`2Buy","runmodule.php?module=bait&op=wormbuy");
        addnav("`!Buy Something Else","runmodule.php?module=bait&op=trade");
        addnav("`@Return to Pool","runmodule.php?module=pool");
    }
if ($op == "minnows"){
        output("`3Minnows are going for %s gold, would you like to buy?`n",$minnowgold);
        addnav("`2Buy","runmodule.php?module=bait&op=minnowbuy");
        addnav("`!Buy Something Else","runmodule.php?module=bait&op=trade");
        addnav("`@Return to Pool","runmodule.php?module=pool");
    }
//buy products
if ($op=="wormbuy"){
        if ($inventory>49){
                output("`!You cannot carry any more in your pack.`n");
            }else{
        output("`%How many worms would you like to buy?`n");
    $linkcode="<form action='runmodule.php?module=bait&op=wormbuy2' method='POST'><input name='buy' id='buy'><input type='submit' class='button' value='buy'></form>";
        output("%s",$linkcode,true);
    $linkcode="<script language='JavaScript'>document.getElementById('bet').focus();</script>";
        output("%s",$linkcode,true);
    addnav("","runmodule.php?module=bait&op=wormbuy2");
    }
    addnav("Buy Something Else","runmodule.php?module=bait&op=trade");
    addnav("Return to Pool","runmodule.php?module=pool");
}

if ($op=="wormbuy2"){
        if ($buy > (50 - $inventory)) $buy = (50 - $inventory);
        if ($buy < 0) $buy = 0;
        if ($session['user']['gold'] < ($buy * $wormcost)) output("You can't afford that!");
        else{
                set_module_pref('message',"`!The man takes your money and hands you %s Worms.",$buy);
                $wormcost1=($buy * get_module_setting('wormcost'));
		$session['user']['gold']-=$wormcost1;
                set_module_pref('worms', (get_module_pref('worms') + $buy));
                }
        redirect("runmodule.php?module=bait&op=buy3");
    }
if ($op=="buy3"){
        output_notl(get_module_pref('message'));
        addnav("`!Buy Something Else","runmodule.php?module=bait&op=trade");
        addnav("@Return to Pool","runmodule.php?module=pool");
}
	
if ($op=="minnowbuy"){
        if ($inventory>49){
                output("`!You cannot carry any more in your pack.`n");
		addnav("Return to Pool","runmodule.php?module=pool");
            }else{
        output("`%How many minnows would you like to buy?`n");
    $linkcode="<form action='runmodule.php?module=bait&op=minnowbuy2' method='POST'><input name='buy' id='buy'><input type='submit' class='button'value='buy'></form>";
        output("%s",$linkcode,true);
    $linkcode="<script language='JavaScript'>document.getElementById('bet').focus();</script>";
        output("%s",$linkcode,true);
    addnav("","runmodule.php?module=bait&op=minnowbuy2");
    }
    addnav("`!Buy Something Else","runmodule.php?module=bait&op=trade");
    addnav("`@Return to Pool","runmodule.php?module=pool");
}
if ($op=="minnowbuy2"){
        if ($buy > (50 - $inventory)) $buy = (50 - $inventory);
        if ($buy < 0) $buy = 0;
        if ($session['user']['gold'] < ($buy * $minnowcost)) output("You can't afford that!");
        else{
                set_module_pref('message',"`!The man takes your money and hands you %s Minnows.",$buy);
                $minnowcost1=($buy * get_module_setting('minnowcost'));
                $session['user']['gold']-=$minnowcost1;
                set_module_pref('minnows', (get_module_pref('minnows') + $buy));
                }
        redirect("runmodule.php?module=bait&op=buy3");
    }
page_footer();
}
?>
