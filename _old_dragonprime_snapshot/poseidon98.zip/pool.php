<?php
//addnews ready
/**
* Version:      1.8
* Date:         November 14, 2005
* Author:       Kevin Hatfield - Arune http://www.dragonprime.net
* LOGD VER: 	Module for 0.9.8
*
* Module Updated by Sichae.
* Updated - Transalation Ready.
*/
require_once("lib/http.php");

function pool_getmoduleinfo(){
        $info = array(
                "name"=>"Poseidon Pool",
                "author"=>"<a href=\"http://logd.ecsportal.com\" target=_new>Arune - Kevin Hatfield</a>",
                "version"=>"1.8",
                "category"=>"Poseidon Pool",
				"vertxtloc"=>"http://www.dragonprime.net/users/khatfield/",
				"description"=>"Central area for Poseidon Pool locs",
                "download"=>"http://dragonprime.net/users/khatfield/poseidon98.zip",
                "settings"=>array(
                "poolloc"=>"What city is the Poseidon Pool in?,location|".getsetting("villagename", LOCATION_FIELDS)
                )
        );
        return $info;
}

function pool_install(){
	module_addhook("changesetting");
	module_addhook("moderate");
	module_addhook("village");
	return true;
}

function pool_uninstall(){
	return true;
}
function pool_dohook($hookname, $args){
        global $session;
        switch($hookname){
        case "changesetting":
                if ($args['setting'] == "villagename") {
                        if ($args['old'] == get_module_setting("poolloc")) {
                                set_module_setting("poolloc", $args['new']);
                        }
		}
	   break;
	case "moderate":
                $args['pool'] = "Poseidon Pool";
                break;
        case "village":
             if ($session['user']['location'] == get_module_setting("poolloc")){
                tlschema($args['schemas']['gatenav']);
                addnav($args['gatenav']);
                tlschema();
                addnav("Poseidon Pool","runmodule.php?module=pool");
                }
                break;
	}
        return $args;
}
function pool_run(){
		global $session;
		$op = httpget('op');
		require_once("lib/http.php");
		require_once("lib/commentary.php");
		require_once("lib/villagenav.php");
		addcommentary();
		page_header("Poseidon Pool");
		output("`c`b`&Poseidon Pool`0`b`c`n`n");
		if ($op == ""){
		output("`7This is a dark place, almost magically dim.");
		output(" Unlike other areas in the grounds this area seems to always have fog seemingly reaching from the ground to the skies above.");
		output(" You can see the edge of the water and on around near the main fishing spot, light shines down from the sun beaming off the water.");
		output("`n Everytime you come here, it always amazes you how the lighting never changes...even the weather rarely changes in this area, despite the changes elsewhere..`n`n"); 
		output("As unusual and truly dangerous this area can be, the possibilities of treasure found in the waters before you, keep you returning..`n`n");
		}
		output("`n`2-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-`n");
		viewcommentary("pool", "Converse here", 10, "says");
		villagenav();
		if ($session['user']['dragonkills']>1) addnav("Bait Shop","runmodule.php?module=bait");
		if ($session['user']['dragonkills']>1) addnav("Fishing Hole","runmodule.php?module=fish");
page_footer();
}
?>
