<?php
function musicshop_musicheader(){
	addnav("V?Return to the Village","village.php");
	page_header("Amleine's Music Shop");
	output("`n`c`b`%Amleine's `%M`4usic `%S`4hop`n`n`c`b");
}
function musicshop_musicnavs(){
	$choice=get_module_pref("choice");
	addnav("Review Rules","runmodule.php?module=musicshop&op=rules");
	if (get_module_pref("nummastered")>0) addnav("Review Completed Studies","runmodule.php?module=musicshop&op=completed");
	if ($choice>0 && $choice<=5) addnav("Practice","runmodule.php?module=musicshop&op=practiceplay");
	if ($choice>5 && $choice<=10) addnav("Build","runmodule.php?module=musicshop&op=startbuild");
	if ($choice>10) addnav("Compose","runmodule.php?module=musicshop&op=startcompose");
}
function musicshop_goodanimal(){
	global $session;
	output("`n`n `%Amleine`Q comes around the counter and gives you a hug.");
	output("It seems to be a little therapeutic for her to be able to share this story with you.");
	output("It makes you feel good to be able to give something back to her.");
	output("`n`nYou gain `@3 extra turns`Q!`n`n");
	$session['user']['turns']+=3;
	addnav("Back to the Storefront","runmodule.php?module=musicshop&op=music");
}
function musicshop_badanimal(){
	global $session;
	output("`%'Oh, no, I said it was something else.'");
	output("`n`n'It's not really too important.");
	output("But thanks for listening!'`n`n");
	output("`QYou feel a little guilty for not giving `%Amleine`Q your full attention.");
	output("`n`nYou lose `&One Charm`Q because of your guilt.`n`n");
	$session['user']['charm']--;
	addnav("Back to the Storefront","runmodule.php?module=musicshop&op=music");
}
function musicshop_rightrace(){
	global $session;
	$goldlesson=get_module_setting("goldlevel")*$session['user']['level'];
	output("For some reason, my music doesn't seem to win them over like it does the other races.'");
	output("`n`n `%Amleine`Q smiles and looks at you with appreciation for listening.");
	output("`n`n`%'Today's lesson is free!");
	output("In fact, I'm going to give you enough money for a lesson, but I'll let you decide how you want to spend it.'");
	output("`n`n`QYou gain `^%s Gold`Q and also an `@Extra Turn`Q!`n`n",$goldlesson);
	$session['user']['turns']++;
	$session['user']['gold']+=$goldlesson;
	addnav("Back to the Storefront","runmodule.php?module=musicshop&op=music");
}
function musicshop_wrongrace(){
	global $session;
	output("`%'Oh, no, I have no hatred for them.");
	output("It was the other race.'");
	output("`n`n'It's not really too important.");
	output("But thanks for listening!'`n`n");
	output("`QYou feel a very guilty for not giving `%Amleine`Q your full attention.`n`n");
	if ($session['user']['turns']>=2) {
		output("You `@Lose Two Turns`Q because of your guilt.`n`n");
		$session['user']['turns']-=2;
	}elseif ($session['user']['turns']==1) {
		output("You `@lose One Turn`Q and `&Two Charm`Q because of your guilt.`n`n");
		$session['user']['turns']--;
		$session['user']['charm']-=2;
	}elseif ($session['user']['turns']=0) {	
		output("You `&Lose Three Charm`Q because of your guilt.`n`n");
		$session['user']['charm']-=3;
	}			
	addnav("Back to the Storefront","runmodule.php?module=musicshop&op=music");
}
function musicshop_firstlesson(){
	global $session;
	output("`Qand soon complete your first lesson!`n`n");
	output("`%Amleine `Qcompliments you on your skills and mentions that you have a lot of potential.");
	output("`n`n`%'I hope to see you when you've reached your next level!'`n`n");
	output("`QYour excitement over your first lesson gives you the energy for `@one more turn`Q!");
	output("`n`nYou leave the shop with excited prospects of future lessons.");
	$session['user']['turns']++;
}
function musicshop_levelstudy(){
	global $session;
    if ($session['user']['level']==1) set_module_pref("level1",1);
    if ($session['user']['level']==2) set_module_pref("level2",1);
    if ($session['user']['level']==3) set_module_pref("level3",1);
    if ($session['user']['level']==4) set_module_pref("level4",1);
    if ($session['user']['level']==5) set_module_pref("level5",1);
    if ($session['user']['level']==6) set_module_pref("level6",1);
    if ($session['user']['level']==7) set_module_pref("level7",1);
    if ($session['user']['level']==8) set_module_pref("level8",1);
    if ($session['user']['level']==9) set_module_pref("level9",1);
    if ($session['user']['level']==10) set_module_pref("level10",1);
    if ($session['user']['level']==11) set_module_pref("level11",1);
    if ($session['user']['level']==12) set_module_pref("level12",1);
    if ($session['user']['level']==13) set_module_pref("level13",1);
    if ($session['user']['level']==14) set_module_pref("level14",1);
    if ($session['user']['level']==15) set_module_pref("level15",1);
	increment_module_pref("musicvisit",1);
}
function musicshop_lute(){
	output("`%'The history of the `^Lute`% is ancient, going back far beyond written history that currently exists.");
	output("Through the crusades and trade, it was spread throughout Europe, and it was adopted as an instrument by the Europeans.");
	output("Frets were added and eventually the strings were doubled.'`n`n");
	//information thanks to http://home.earthlink.net/~guitarandlute/lute.html
}
function musicshop_fiddle(){
	output("`%'Primitive bowed instruments of many types exist around the world and some are still widely used, but the modern `!Fiddle`% first appeared in Italy in the early 16th century.");
	output("The modern classical violin has a longer neck and fingerboard, and a greater neck angle than the original baroque design, in order to provide more volume.'`n`n");
	//information thanks to http://www.hobgoblin-usa.com/faqfiddle.htm
}
function musicshop_bagpipes(){
	output("`%'`\$B`@a`\$g`@p`\$i`@p`\$e`@s`% existed in many forms in many places around the world.");
	output("In each country the basic instrument was the same, a bag with a chanter and one or more drones.");
	output("Some of these were mouth blown while others used a bellows attachment to supply the air.");
	output("The bag provided a sustained tone while the musician took a breath and allowed several tones to be played at once.'`n`n");
	//information thanks to http://www.visitdunkeld.com/bagpipe-history.htm
}
function musicshop_flute (){
	output("`%'The `#'flute family'`% is the oldest in the category of woodwind instruments.");
	output("Throughout history the size of the tube along the flutes length has evolved in respect to its bore shape.");
	output("In the Renaissance the `#flute`% was a simple cylindrical wooden tube with embouchure hole and finger holes, stopped at the end above the embouchure hole.");
	output("To achieve a greater range, the bore of the baroque flute was modified to a slightly tapered conical shape with the larger radius at the embouchure hole and the smaller radius at the bell end.'`n`n");
	//information thanks to http://community.middlebury.edu/%7Ebeyer/s/history.html
}
function musicshop_kettledrums(){
	output("`%'Historically, `#Kettledrums`% have been used throughout many Islamic and Middle Eastern nations; carved images of these instruments from Mesopotamia date back to at least the 4000 B.C., while instructions for building them have been found on ancient Babylonian tablets.");
	output("They have also played a significant role in European music since the 13th century.");
	output("First brought to the west by soldiers during the Crusades, kettle drums were traditionally associated with military bands and campaigns.");
	output("These and other instruments were used to mark time, to signal attack and strike fear in one's opponents.'`n`n");
	//information thanks to http://www.si.umich.edu/chico/instrument/pages/ktldrm_gnrl.html	
}
function musicshop_earlylesson(){
	global $session;
	$musicstudy=array("","play the lute","play the fiddle","play bagpipes","play the flute","play kettledrums","make a lute","make a fiddle","make bagpipes","make a flute","make kettledrums","compose festival music","compose madrigal music","compose dirges","compose symphonies","compose sonatas");
	switch(e_rand(1,35)){
		case 1: case 2: case 3: case 4: case 5: case 6: case 7: case 8: case 9: case 10: case 11: case 12: case 13: case 14: case 15: case 16: case 17: case 18: case 19:
			output("`QYou thank `%Amleine`Q for her help and sing some of the music that you learned as you leave the shop.`n`n");
		break;
		case 20: case 21: case 22: case 23: case 24: case 25: case 26: case 27: case 28: case 29: case 30: 
			output("`QYour confidence increases.");
			output("When you leave the shop, people notice that you're walking with a little more pride.");
			output("`n`nYou `&Gain One Charm Point`Q.");
			$session['user']['charm']++;
		break;
		case 31: case 32: case 33:
			output("`QThis was exhilarating.");
			output("You learned things that opened your mind and awareness of the world.");
			output("`n`nYou `@Gain One Extra Turn`Q!`n`n");
			output("In fact, `%Amleine`Q is so impressed that she starts calling you `%'Maestro'`Q and offers to change that to your official title.");
			output("`n`nWould you like that to be your new title?");
			$session['user']['turns']++;
			addnav("Maestro Title","runmodule.php?module=musicshop&op=maestro");
		break;	
		case 34:
			output("`%Amleine`Q looks at you with a bit of disappointment.");
			output("`n`n`%'This really wasn't your best lesson, you know that?");
			output("I think that you need to practice a little more.'`n`n");
			output("`QYou decide to `@stay a turn`Q in order to try to figure out what you were doing wrong.");
			$session['user']['turns']--;
		break;	
		case 35:
			output("`%Amleine`Q looks at you with disbelief.");
			output("`n`n`%'You think you're going to learn how to `&%s`% without trying?",$musicstudy[get_module_pref("choice")]);
			output("No.  You won't.");
			output("I'm sorry, but you're wasting my time.");
			output("Come back when you've gained a level and some maturity.'");
			output("`n`n`QYou feel very guilty for your poor performance today.");
			output("Unfortunately, you don't get credit for this visit.");
			output("You will have to work even harder to master your lessons after this mistake.");	
			increment_module_pref("musicvisit",-1);
		break;
	}
}
function musicshop_midlesson(){
	global $session;
	$goldlesson=get_module_setting("goldlevel")*$session['user']['level'];
	switch(e_rand(1,35)){
		case 1: case 2: case 3: case 4: case 5: case 6: case 7: case 8: case 9: case 10: case 11: case 12: case 13: case 14: case 15: case 16: case 17: case 18: case 19:
			output("`%'Well, you are exceeding my expectations.");
			output("I have to admit, I wasn't sure you could accomplish so much in so little time.");
			output("You're doing wonderfully!'`n`n");
			output("`QYou leave the office with a smile and a positive outlook.`n`n");
		break;
		case 20: case 21: case 22: case 23: case 24: case 25: case 26: case 27: case 28: case 29:
			output("She starts to clap.");
			output("She smiles and looks at you.");
			output("`n`n`%'Yes, you're getting better than I had ever dreamed.'");
			output("`n`n`QThe music grows inside you and you leave with a happy song in your heart.");
			apply_buff('happysong',array(
				"name"=>"`%Happy Song",
				"rounds"=>5,
				"wearoff"=>"`%The song starts to fade",
				"atkmod"=>1.03,
				"roundmsg"=>"You slash and sing 'It's a beautiful day in the neighborhood...'",
			));
		break;
		case 30: case 31:
			output("`%'With such talent, I have a feeling you'll go far!'");
			output("`n`n`QYou `@Gain One Extra Turn`Q and `&One Extra Charm`Q!");
			$session['user']['turns']++;
			$session['user']['charm']++;
		break;	
		case 32: case 33: case 34:
			output("`%Amleine`Q looks at you and grimaces.");
			output("`n`n`%'Good Lord what was that muck?");
			output("Ugh.  I can't even look at you.'`n`n");
			output("`QHer disappointment makes you feel uncomfortable with yourself.");
			output("You `&Lose one Charm`Q.");
			$session['user']['charm']--;
		break;	
		case 35:
			output("`%Amleine`Q looks at you... you can't tell what she's thinking.");
			output("She lifts her hands as if to strike you but instead starts a slow clap, smiling all the while.");
			output("`n`n`%'This lesson was amazing... worthy of someone much more advanced than I would have ever predicted.");
			output("I can't imagine charging you for such a performance.");
			output("In fact, I think you deserve your money back plus that much more as a gift of my appreciation for your performance.'");
			output("`n`n Amleine `Qgives you `^%s gold `Qfor your amazing performance.",$goldlesson*2);
			$session['user']['gold']+=$goldlesson*2;
		break;
	}
}
function musicshop_latelesson(){
	global $session;
	$musicitem=array("","lute","fiddle","bagpipes","flute","kettledrums","lute","fiddle","bagpipe","flute","kettledrum","festival piece","madrigal","dirge","symphony","sonata");
	switch(e_rand(1,35)){
		case 1: case 2: case 3: case 4: case 5: case 6: case 7: case 8: case 9: case 10: case 11: case 12: case 13: case 14: case 15: case 16: case 17: case 18: case 19:
			output("`%'You are well on the way to mastering the %s.", $musicitem[get_module_pref("choice")]);
			output("In fact, soon I will not be able to teach you any more.'");
			output("`n`n`QThis is turning out to be a very good experience for you.");
			output("You finish the lesson, smile, and head out of the `%M`4usic `%S`4hop`Q.`n`n");
		break;
		case 20: case 21: case 22: case 23: case 24: case 25: case 26: case 27: case 28: case 29:
			output("`%'You're doing a great job.");
			output("Keep up the good work.'");
			output("`n`n`QYou smile and gather your instrument and get ready to leave the store.");
			output("However, you notice a colorful little gem stuck to the bottom of your shoe.");
			output("You smile and toss it in your pouch.");
			output("`n`nHow cool! You `%found a gem`Q!");
			$session['user']['gems']++;
		break;
		case 30: case 31: case 32:
			output("`%'Unbelievably well done, my friend.");
			output("Just spectacular.'");
			output("`Q`n`nYou feel quite happy about today's lesson, and decide that there are some extra monsters in the forest that should meet your `w`Q.");
			output("`n`nYou `@Gain 2 Extra Turns`Q!`n`n");
			$session['user']['turns']+=2;
		break;	
		case 33: case 34:
			output("`%Amleine`Q looks at you and shakes her head sadly.");
			output("`n`n`%'No, that's not really going to impress anyone.");
			output("Honestly.  You should just hang your head and shame and practice a little more.'`n`n");
			if ($session['user']['turns']>=1) {
				output("`QHer disappointment makes you feel uncomfortable with yourself.");
				output("You `&Lose one Charm`Q and decide you should spend `@an extra turn`Q practicing some more.");
				$session['user']['charm']--;
				$session['user']['turns']--;
			}else{
				output("`QHer disappointment makes you feel uncomfortable with yourself.");
				output("You `&Lose Two Charm`Q and end up practicing some more.");
				$session['user']['charm']-=2;
			}
		break;	
		case 35:
			output("`%Amleine `Qstops you in the middle of your performance.");
			output("`n`n`%'Who ARE you?");
			output("This really isn't up to your normal level of excellence.");
			output("Perhaps today just isn't your day.'");
			output("`n`n`QYou leave the store realizing that today just isn't your day.");
			output("`n`nIn fact, this has a damper on the rest of your day.`n`n");
			apply_buff('badday',array(
				"name"=>"`%Bad Day",
				"rounds"=>100,
				"wearoff"=>"`%The dissonance dissolves and you feel the sadness lift.",
				"atkmod"=>.97,
				"defmod"=>.97,
				"roundmsg"=>"Nothing is going right today.  It's just a bad day...",
			));
		break;	
	}
}
function musicshop_mastercheck(){
	if (get_module_pref("plute")==1) set_module_pref("plute",2);	
	if (get_module_pref("pfiddle")==1)	set_module_pref("pfiddle",2);		
	if (get_module_pref("pbagpipes")==1) set_module_pref("pbagpipes",2);		
	if (get_module_pref("pflute")==1) set_module_pref("pflute",2);			
	if (get_module_pref("pkettledrums")==1) set_module_pref("pkettledrums",2);
	if (get_module_pref("mlute")==1) set_module_pref("mlute",2);			
	if (get_module_pref("mfiddle")==1)	set_module_pref("mfiddle",2);
	if (get_module_pref("mbagpipes")==1) set_module_pref("mbagpipes",2);	
	if (get_module_pref("mflute")==1) set_module_pref("mflute",2);	
	if (get_module_pref("mkettledrums")==1) set_module_pref("mkettledrums",2);		
	if (get_module_pref("festival")==1) set_module_pref("festival",2);
	if (get_module_pref("madrigal")==1) set_module_pref("madrigal",2);
	if (get_module_pref("dirges")==1) set_module_pref("dirges",2);
	if (get_module_pref("symphonies")==1) set_module_pref("symphonies",2);
	if (get_module_pref("sonatas")==1)	set_module_pref("sonatas",2);
}
function musicshop_mastercount(){
	if (get_module_pref("plute")==2) $master1=1;		
	if (get_module_pref("pfiddle")==2) $master2=1;		
	if (get_module_pref("pbagpipes")==2) $master3=1;		
	if (get_module_pref("pflute")==2) $master4=1;		
	if (get_module_pref("pkettledrums")==2) $master5=1;	
	if (get_module_pref("mlute")==2) $master6=1;		
	if (get_module_pref("mfiddle")==2) $master7=1;		
	if (get_module_pref("mbagpipes")==2) $master8=1;		
	if (get_module_pref("mflute")==2) $master9=1;	
	if (get_module_pref("mkettledrums")==2) $master10=1;		
	if (get_module_pref("festival")==2) $master11=1;
	if (get_module_pref("madrigal")==2) $master12=1;	
	if (get_module_pref("dirges")==2) $master13=1;
	if (get_module_pref("symphonies")==2) $master14=1;		
	if (get_module_pref("sonatas")==2) $master15=1;
	set_module_pref("nummastered",$master1+$master2+$master3+$master4+$master5+$master6+$master7+$master8+$master9+$master10+$master11+$master12+$master13+$master14+$master15);
	set_module_pref("masterhof",get_module_pref("masterful")*15+get_module_pref("nummastered"));
}

?>