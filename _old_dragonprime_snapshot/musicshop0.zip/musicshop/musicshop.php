<?php
	global $session;
	require_once("lib/titles.php");
	require_once("lib/names.php");
	$op = httpget("op");
	$musicvisit=get_module_pref("musicvisit");
	$award=get_module_pref("award");
	$story=get_module_pref("story");
	$choice=get_module_pref("choice");
	$firstmusic=get_module_pref("firstmusic");
	$goldlevel=get_module_setting("goldlevel");
	$musicstudy=array("","play the lute","play the fiddle","play bagpipes","play the flute","play kettledrums","make a lute","make a fiddle","make bagpipes","make a flute","make kettledrums","compose festival music","compose madrigal music","compose dirges","compose symphonies","compose sonatas");
	$musicitem=array("","lute","fiddle","bagpipes","flute","kettledrums","lute","fiddle","bagpipe","flute","kettledrum","festival piece","madrigal","dirge","symphony","sonata");
	$level = $session['user']['level'];
	$goldlesson=$goldlevel*$level;
	if (get_module_pref("level1")==1) $level1=1;
	if (get_module_pref("level2")==1) $level2=2;
	if (get_module_pref("level3")==1) $level3=3;
	if (get_module_pref("level4")==1) $level4=4;
	if (get_module_pref("level5")==1) $level5=5;
	if (get_module_pref("level6")==1) $level6=6;
	if (get_module_pref("level7")==1) $level7=7;
	if (get_module_pref("level8")==1) $level8=8;
	if (get_module_pref("level9")==1) $level9=9;
	if (get_module_pref("level10")==1) $level10=10;
	if (get_module_pref("level11")==1) $level11=11;
	if (get_module_pref("level12")==1) $level12=12;
	if (get_module_pref("level13")==1) $level13=13;
	if (get_module_pref("level14")==1) $level14=14;
	if (get_module_pref("level15")==1) $level15=15;
	musicshop_mastercount();
if ($op=="hof"){
	global $session;
	page_header("Hall of Fame");
	$page = httpget('page');
	$pp = get_module_setting("pp");
	$pageoffset = (int)$page;
	if ($pageoffset > 0) $pageoffset--;
	$pageoffset *= $pp;
	$limit = "LIMIT $pageoffset,$pp";
	$sql = "SELECT COUNT(*) AS c FROM " . db_prefix("module_userprefs") . " WHERE modulename = 'musicshop' AND setting = 'masterhof' AND value > 0";
	$result = db_query($sql);
	$row = db_fetch_assoc($result);
	$total = $row['c'];
	$count = db_num_rows($result);
	if (($pageoffset + $pp) < $total){
		$cond = $pageoffset + $pp;
	}else{
		$cond = $total;
	}
	$sql = "SELECT ".db_prefix("module_userprefs").".value, ".db_prefix("module_userprefs").".userid, ".db_prefix("accounts").".name FROM " . db_prefix("module_userprefs") . "," . db_prefix("accounts") . " WHERE acctid = userid AND modulename = 'musicshop' AND setting = 'masterhof' AND value >= 0 ORDER BY (value+0) DESC $limit";
	$result = db_query($sql);
	$rank = translate_inline("Rank");
	$name = translate_inline("Name");
	$title = translate_inline("Title");
	$nummastered = translate_inline("Areas Mastered");
	$none = translate_inline("No Musicians Available");
	output("`b`c`@Most Talented Musicians In The Land`c`b`n`n");
	rawoutput("<table border='0' cellpadding='2' cellspacing='1' align='center' bgcolor='#999999'>");
	rawoutput("<tr class='trhead'><td>$rank</td><td>$name</td><td>$title</td><td>$nummastered</td></tr>");
	if (db_num_rows($result)==0) output_notl("<tr class='trlight'><td colspan='2' align='center'>`&$none`0</td></tr>",true);
	else{
		for($i = $pageoffset; $i < $cond && $count; $i++) {
			$row = db_fetch_assoc($result);
			if ($row['name']==$session['user']['name']){
				rawoutput("<tr class='trhilight'><td>");
			}else{
				rawoutput("<tr class='".($i%2?"trdark":"trlight")."'><td>");
			}
			$j=$i+1;
			output_notl("$j.");
			rawoutput("</td><td>");
			output_notl("`&%s`0",$row['name']);
			rawoutput("</td><td>");
			$masterful=get_module_pref("masterful","musicshop",$row['userid']);
			if ($masterful>9) $newtitle="`5`bThe Ultimate Supreme Grandmaster of Music`b";
			if ($masterful==9) $newtitle="`6Third Level Supreme Grandmaster of Music";
			if ($masterful==8) $newtitle="`QSecond Level Supreme Grandmaster of Music";
			if ($masterful==7) $newtitle="`&First Level Supreme Grandmaster of Music";
			if ($masterful==6) $newtitle="`\$Third Level Grandmaster of Music";
			if ($masterful==5) $newtitle="`%Second Level Grandmaster of Music";
			if ($masterful==4) $newtitle="`!First Level Grandmaster of Music";
			if ($masterful==3) $newtitle="`#Third Level Master of Music";
			if ($masterful==2) $newtitle="`@Second Level Master of Music";
			if ($masterful==1) $newtitle="`^First Level Master of Music";
			if ($masterful==0) $newtitle="`^Disciple of Music";
			output_notl("`c`Q%s`c`0",$newtitle);
			rawoutput("</td><td>");
			output_notl("`c`b`Q%s`c`b`0",get_module_pref('nummastered','musicshop',$row['userid']));
			rawoutput("</td></tr>");
        }
	}
	rawoutput("</table>");
	if ($total>$pp){
		addnav("Pages");
		for ($p=0;$p<$total;$p+=$pp){
			addnav(array("Page %s (%s-%s)", ($p/$pp+1), ($p+1), min($p+$pp,$total)), "runmodule.php?module=musicshop&op=hof&page=".($p/$pp+1));
		}
	}
	addnav("Return");
	addnav("Back to HoF", "hof.php");
	villagenav();
}
if ($op=="musicbook"){
	//taken from XChrisX's questbook.php starting here
	global $session;
	$return = httpget('return');
	$return = cmd_sanitize($return);
	$return = substr($return,strrpos($return,"/")+1);
	tlschema("nav");
	addnav("Return whence you came",$return);
	tlschema();
	$userid = httpget("user");
	$strike = false;
	//taken from xChrisX's questbook.php ending here
	page_header("Musical Records");
	rawoutput("<big>");
	output("`b`c`%L`4ist `%o`4f `%M`4usical `%A`4ccomplisments`c`b`n");
	if (get_module_pref("masterful","musicshop",$userid)>9) output("`5`b`cThe Ultimate Supreme Grandmaster of Music`b`c`n");
	if (get_module_pref("masterful","musicshop",$userid)==9) output("`6`b`cThird Level Supreme Grandmaster of Music`b`c`n");
	if (get_module_pref("masterful","musicshop",$userid)==8) output("`Q`b`cSecond Level Supreme Grandmaster of Music`b`c`n");
	if (get_module_pref("masterful","musicshop",$userid)==7) output("`&`b`cFirst Level Supreme Grandmaster of Music`b`c`n");
	if (get_module_pref("masterful","musicshop",$userid)==6) output("`\$`b`cThird Level Grandmaster of Music`b`c`n");
	if (get_module_pref("masterful","musicshop",$userid)==5) output("`%`b`cSecond Level Grandmaster of Music`b`c`n");
	if (get_module_pref("masterful","musicshop",$userid)==4) output("`!`b`cFirst Level Grandmaster of Music`b`c`n");
	if (get_module_pref("masterful","musicshop",$userid)==3) output("`#`b`cThird Level Master of Music`b`c`n");
	if (get_module_pref("masterful","musicshop",$userid)==2) output("`@`b`cSecond Level Master of Music`b`c`n");
	if (get_module_pref("masterful","musicshop",$userid)==1) output("`^`b`cFirst Level Master of Music`b`c`n");
	rawoutput("</big>");
	if (get_module_pref("plute","musicshop", $userid)==2) output("`b`c`^-Lute Performance-`b`c`n");	
	if (get_module_pref("pfiddle","musicshop", $userid)==2) output("`b`c`!-Fiddle Performance-`b`c`n");			
	if (get_module_pref("pbagpipes","musicshop", $userid)==2) output("`b`c`@-`\$B`@a`\$g`@p`\$i`@p`\$e`@s `\$P`@e`\$r`@f`\$o`@r`\$m`@a`\$n`@c`\$e `@Performance-`b`c`n");		
	if (get_module_pref("pflute","musicshop", $userid)==2) output("`b`c`#-Flute Performance-`b`c`n");		
	if (get_module_pref("pkettledrums","musicshop", $userid)==2) output("`b`c`%-Kettledrum Performance-`b`c`n");		
	if (get_module_pref("mlute","musicshop", $userid)==2) output("`b`c`^-Lute Making-`b`c`n");		
	if (get_module_pref("mfiddle","musicshop", $userid)==2) output("`b`c`!-Fiddle Making-`b`c`n");		
	if (get_module_pref("mbagpipes","musicshop", $userid)==2) output("`b`c`@-`\$B`@a`\$g`@p`\$i`@p`\$e`@s `\$P`@e`\$r`@f`\$o`@r`\$m`@a`\$n`@c`\$e `@Making-`b`c`n");		
	if (get_module_pref("mflute","musicshop", $userid)==2) output("`b`c`#-Flute Making-`b`c`n");		
	if (get_module_pref("mkettledrums","musicshop", $userid)==2) output("`b`c`%-Kettledrum Making-`b`c`n");	
	if (get_module_pref("festival","musicshop", $userid)==2) output("`b`c`@-F`2estival `^M`6usic `@C`2omposition-`b`c`n");	
	if (get_module_pref("madrigal","musicshop", $userid)==2) output("`b`c`%-M`5adrigal `%M`5usic `%C`5omposition-`b`c`n");		
	if (get_module_pref("dirges","musicshop", $userid)==2) output("`b`c`)-Dirge Composition-`b`c`n");	
	if (get_module_pref("symphonies","musicshop", $userid)==2) output("`b`c`3-Symphony Composition-`b`c`n");	
	if (get_module_pref("sonatas","musicshop", $userid)==2) output("`b`c`\$-S`4onata `\$C`4omposition-`b`c`n");
}

if ($op=="music"){
	musicshop_musicheader ();
	if ($firstmusic==0) {
		output("`QWhen you push open the door to the `%M`4usic `%S`4hop`Q you hear the little ding noise of the bells hanging from the door.`n`n");
		output("`c`b`@<ding> <dong>`Q`c`b`n");
		output("You slowly look around and take in the details of the shop.`n`n");
		output("On the wall are a wide variety of minstrel's instruments.");
		output("Lutes, fiddles, bagpipes, flutes, and kettledrums each capture a piece of your imagination.");
		output("Ah, the possibilities...`n`n");
		output("Then your eyes wander to the woman behind the counter.");
		output("Her elfish features accent her fiery red hair, but you're quickly distracted by the sharp green from her eyes.");
		output("Is it wisdom or war that caused them to burn so brightly?");
		output("Perhaps that's a story for the bard to share with you some other day.`n`n");
		output("`%'Welcome to my `%M`4usic `%S`4hop`%.");
		output("I am, of course,  `%Amleine`%.");
		output("My specialty is the flute, but perhaps that's not as important to you as what I have to offer.'");
		output("`n`n'Music is, in my opinion, one of the most difficult disciplines to master.");
		output("It requires the dexterity of a master swordsman and the perseverance and wisdom of the most powerful of Wizards.");
		output("The rewards for success can be more impressive than you could ever dream.'`n`n");
		output("'My shop is always open for you, and I am at your service.");
		output("My prices can be a little steep, but my promise is that your dedication to this art will be well worth your effort.");
		output("As you become familiar with me, I will become more familiar with you.'`n`n");
		output("'Perhaps you'd like to learn more?'");
		addnav("Rules","runmodule.php?module=musicshop&op=rules");
	}elseif ($choice==0) {
		output("`QWhen you push open the door to the `%M`4usic `%S`4hop`Q you hear the little ding noise of a the bells hanging from the door.`n`n");
		output("`c`b`@<ding> <dong>`Q`c`b`n");
		output("You look at `%Amleine`Q and tell her that you think you're ready to choose a discipline to study.`n`n");
		output("`%'Sounds good to me.  What would you like to focus on?'");
		addnav("Learn an Instrument","runmodule.php?module=musicshop&op=practice");
		addnav("Learn Instrument Making","runmodule.php?module=musicshop&op=build");
		addnav("Learn Composition","runmodule.php?module=musicshop&op=compose");
		if (get_module_pref("nummastered")>0) addnav("Review Completed Studies","runmodule.php?module=musicshop&op=completed");
		addnav("Rules","runmodule.php?module=musicshop&op=rules");
	}elseif	($musicvisit>11 && $award==0){
		if ($session['user']['level']<15){
			output("`QYou open the door, wait a couple seconds, and hear the wonderful sound...");
			output("`n`n`c`b`2<`@ding`2> `#<`3d`#on`3g`#>`Q`c`b`n");
			output("You chime up and sing a perfect 5th, completing the Major Chord.");
			output("You wander over to the counter and smile at `%Amleine`Q.");
			output("She smiles back.");
			output("`n`n`%'You have mastered your skill of how to `&%s`%.",$musicstudy[get_module_pref("choice")]);
			output("There is not much that I can teach you anymore.");
			output("However, your performance will have to wait until you have reached level 15.");
			output("I know you're excited to see what you're going to get, but you'll just have to wait.'");
			output("`n`n `QYou give `%Amleine`Q a smile of understanding and walk out of the `%M`4usic `%S`4hop`Q.");
			output("`n`n`b`c`&Just don't forget to come back back when you reach Level 15!`n`n`b`c");
		}else{
			output("`QWhen you open the door this time, you quickly grab the bells before they hit the door.");
			output("You sing in perfect pitch the sound they make, including the slight dissonance of the second bell.");
			output("`n`n`c`b`2<`@ding`2> `#<`3d`#on`3g`#>");
			output("`Q`c`b`n`%Amleine `Qlooks up and smiles.");
			output("`n`n`%'Ah, my favorite student.");
			output("You know, you are always welcome here, `^%s`%.'",$session['user']['name']);
			output("`n`n`QShe comes over to you and gives you a hug that communicates the friendship that can only come between two close friends and equals.");
			output("`n`n`%'Yes,	there's nothing more that I can teach you.");
			output("I think you're ready to prove to the world that you know how to `&%s`%.",$musicstudy[get_module_pref("choice")]);
			output("It's time for you to shine.'");
			addnav("Performance","runmodule.php?module=musicshop&op=award");	
		}
	}elseif($award==1){
		output("`QYou're distracted by the call of the `@Green Dragon`Q.");
		output("The bells ring pleasantly in your ear, but you barely notice them.");
		output("`n`n`c`b`2<`@ding`2> `#<`3d`#on`3g`#>`Q`c`b`n");
		output("`%Amleine`Q smiles at you and comes to give you a hug.");
		output("`n`n`%'I have to admit, I want to be able to help you, but there's nothing more I can teach you.");
		output("It's time you put your skills to use to slay that beast that is terrorizing our kingdom.");
		output("Good luck.'`n`n`Q");				
	}elseif ($session['user']['level']<15 && ($level == $level1 || $level == $level2 || $level == $level3 || $level == $level4 || $level == $level5 || $level == $level6 || $level == $level7 || $level == $level8 || $level == $level9 || $level == $level10 || $level == $level11 || $level == $level12 || $level == $level13 || $level == $level14 || $level == $level15)){
		output("`QYou smile as the door opens and you hear the pleasant sounds...");
		output("`n`n`c`b`@<ding> <dong>`Q`c`b`n");
		output("`%Amleine`Q looks at you happily, but starts to shake her head.`n`n");
		output("`%'Oh no, you really only can study one lesson per level, and you've already completed your lessons for learning to`& %s`% for this level.",$musicstudy[get_module_pref("choice")]);
		output("Come back once you've gained another level.'`n`n");
	}elseif((16-$session['user']['level']) < (12-$musicvisit)){
		output("`QWith a sense of urgency you enter `%Amleine's `%M`4usic `%S`4hop`Q."); 
		output("In your haste, you barely notice the bells ringing.");
		output("`n`n`c`b`@<ding> <dong>`Q`c`b`n ");
		output("`%'Oh my!' Amleine `Qsays as she looks at you, `%'This is not good.");
		output("Unfortunately, you won't be able to finish mastering your lessons as you have fallen behind.");
		output("I think it would be best if you focus your studies on something else.'");
		output("`n`n`QYou shake your head sadly as you realize that because you are `#Level %s`Q and you have only finished",$session['user']['level']);
		if ($musicvisit==1) {
			output("`#one lesson`Q,");
		}else{
			output("`#%s lessons`Q,",$musicvisit);
		}
		output("you won't be able to master your studies before it's time to kill the `@Green Dragon`Q.");
		output("`n`nYou will have to try again after you kill the `@Green Dragon`Q and perhaps you'll be a little more attentive to your studies next time.");
	}elseif ($session['user']['gold']<	$goldlesson){
		output("`QAs soon as you enter the `%M`4usic `%S`4hop`Q you hear the bells...");
		output("`n`n`c`b`@<ding> <dong>`Q`c`b`n");
		output("You're about to approach the counter when you decide to do a quick inventory of you current finances.");
		output("You do the math and realize you will need `^%s gold`Q for today's lesson.",$goldlesson);
		output("`n`nNo, you don't have enough.");
		output("You better stop at the bank before you bother `%Amleine`Q.");
		if (get_module_pref("nummastered")>0) addnav("Review Completed Studies","runmodule.php?module=musicshop&op=completed");
		addnav("Rules","runmodule.php?module=musicshop&op=rules");		
	}elseif ($musicvisit<=2) {
		output("`QYou open the door and hear the bells.");
		output("`n`n`c`b`@<ding> <dong>`Q`c`b`n");
		output("`%Amleine`Q smiles at your approach.");
		output("`n`n`%'I know you're familiar to me, what was your name again?'");
		output("`n`n`QYou remind her of your name and `%Amleine`Q nods.");
		output("`n`n`%'Ah, yes `^ %s`%, I'm sorry.",$session['user']['name']);
		output("Don't worry, I'll remember it eventually.");
		output("What can I do for you today?'");
		musicshop_musicnavs();
	}elseif ($musicvisit<=5) {
		output("`QYou open the door and hear the bells ding.");
		output("`n`n`c`b`@<ding> `#<dong>`Q`c`b`n");
		output("You hum as you recognize that the bells don't play cacophonous notes, but rather play the first and third notes of the major scale.");
		output("You are starting to learn the fundamentals of music.");
		output("`%Amleine`Q smiles and looks at you for a second, snaps her fingers, and greets you.");
		output("`n`n `%'Hello `^%s`%, welcome back!",$session['user']['name']);
		output("I have to tell you, you're progressing very well.'");
		if (get_module_pref("amleine")==0){
			output("`n`n'It reminds me a little bit about how I started.");
			output("You might find that an interesting story if you have a moment.'");
			addnav("Amleine's Story","runmodule.php?module=musicshop&op=amleine");
		}				
		output("`n`n'What would you like to do today?'`n`n");	
		musicshop_musicnavs();  
	}elseif ($musicvisit<=8) {
		output("`QThe door opens and this time you pay particular attention to the bells.");
		output("`n`n`c`b`@<`2ding`@> `#<`3dong`#>`Q`c`b`n");
		output("This time you realize the notes come from the key of C.");
		output("You're definitely getting a hang of music.");
		output("`%Amleine`Q smiles happily upon recognizing you.");
		output("`%`n`n'It's always my pleasure to see you, `^%s`%.",$session['user']['name']);
		output("What would you like to do?'");
		musicshop_musicnavs();  
	}elseif ($musicvisit<=11) {
		output("`QThe door opens and instinctively your ears perk up.");
		output("`n`n`c`b`@<`2ding`@> `#<`3d`#on`3g`#>`Q`c`b`n");
		if (get_module_pref("bellstory")==0) {
			output("Something's a little off though...");
			output("something that was always there but that you had never noticed until today.");
			output("The second note actually is a little dissonant.");
			output("When you look up at the bell, you notice a small chip out of the second one, causing the slightest impurity of sound.");
			output("You turn and notice a smile slowly glow across `%Amleine's`Q face.");
			output("`n`n`%'I was waiting for the day that you would notice this,`^ %s`%.",$session['user']['name']);
			output("It means that you're close to finally appreciating music at its highest level.");
			output("You're making me very proud.");
			output("If you're interested, allow me to tell you the story of the bell.");
			output("If you don't have time, you can just get to your studies.'");
			output("`n`n'What would you like to do today?'");
			addnav("Bell Story","runmodule.php?module=musicshop&op=story");
		}else{
			output("Something's a little off though and you recall the story that `%Amleine`Q told you about the break in the bell.");
			output("`n`n `%'Who else would be here at this time except my favorite student,`^ %s`%?",$session['user']['name']);
			output("Welcome back.");
			output("Are you ready to study?'");		
		}
		musicshop_musicnavs();
	}	
}
if ($op=="amleine"){
	musicshop_musicheader ();
	blocknav ("village.php");
	$animal=e_rand(1,10);
	set_module_pref("animal",$animal);
	$anichoice=array("","penguin","dog","cat","frog","platypus","hummingbird","duck","scorpion","monkey","horse");
	set_module_pref("amleine",1);
	output("`%'Well, since you asked, I'd be more than happy to share my story with you.'");
	output("`n`n'Essentially, I was born to an elven family that was outcast for their interests in helping humans.");
	output("Although most elves do not struggle with helping other races, the community my parents lived in was particularly xenophobic.");
	output("In fact, it was considered a personal offense to all members of the community to give shelter to any non-elf that requested assistance.");
	output("It was because of the closed nature of our village that I, too, developed my own insensitivities to the fights and pains of those that have been oppressed.");
	output("When my parents wanted to help an injured dwarf that wandered by our home, I decided to take my own course of action.");
	output("I failed to uphold the values that my family had tried to instill in me and I reported my parents to the city elders.'");
	output("`n`n'\"Helping a dwarf!?!?\" cried the townselves, \"What would possess any decent elf to do such an ignorant act?\"'");
	output("`n`n'My parents were dismissed from the village, but I was given the opportunity to stay.");
	output("And I stayed for what may have been years with a dark heart growing inside me.");
	output("I would have been lost to the world had it not been	the sounds of a human bard that came before my window playing a flute.");
	output("It was five simple notes that changed my life.");
	output("I will never forget them.'");
	output("`n`n`%Amleine`Q picks up the flute and begins to play you one of the most elegant songs...");
	output("and somehow, the song consists of only five notes.");
	output("She puts the flute down and continues her tale.");
	output("`n`n`%'He told me his name was `2Transic`% and he introduced me to his art, changing me forever.");
	output("It was as if someone opened the floodgates to clean out the stagnant cesspool that had become my heart.");
	output("I was alive again; maybe for the first time actually.'");
	output("`n`n'So I gathered my pet %s and left the elven city to pursue a world more accepting of the good in sharing with others.",$anichoice[get_module_pref("animal")]);
	output("Eventually, I mastered the flute and even surpassed `2Transic`% in skills.");
	output("It was during my first performance of 'Evening Primrose Dance', a very complicated flute piece, that the ultimate change occurred.");
	output("My eyes shifted from the `qoak brown`% of my youth to the `@bright green`% that you see today.'");
	output("`n`n'From that day forward, I was reborn as a Master Bard.'`n`n");
	addnav("Amleine's Story Continues","runmodule.php?module=musicshop&op=continues");	
}
if ($op=="continues"){
	musicshop_musicheader ();
	blocknav ("village.php");
	output("`%Amleine`Q looks at you as a tear falls from her eye.");
	output("`n`n`%'I will never forget escaping my home town with my best friend.");
	output("I'm sorry, but do you remember what kind of animal my best friend was?'`n`n");
	addnav("Penguin","runmodule.php?module=musicshop&op=penguin");
	addnav("Dog","runmodule.php?module=musicshop&op=dog");
	addnav("Cat","runmodule.php?module=musicshop&op=cat");
	addnav("Frog","runmodule.php?module=musicshop&op=frog");
	addnav("Platypus","runmodule.php?module=musicshop&op=platypus");
	addnav("Hummingbird","runmodule.php?module=musicshop&op=hummingbird");
	addnav("Duck","runmodule.php?module=musicshop&op=duck");
	addnav("Scorpion","runmodule.php?module=musicshop&op=scorpion");
	addnav("Monkey","runmodule.php?module=musicshop&op=monkey");
	addnav("Horse","runmodule.php?module=musicshop&op=horse");
}
if ($op=="penguin"){
	musicshop_musicheader ();
	if (get_module_pref("animal")==1){
		output("`%'Yeah, `#Plunky Penguin`% was his name.");
		output("He was a really good bird.'");
		musicshop_goodanimal();
	}else{
		musicshop_badanimal();
	}
}
if ($op=="dog"){
	musicshop_musicheader ();
	if (get_module_pref("animal")==2){
		output("`%'Yeah, `#Dougy Dog`% was his name.");
		output("He was a really good dog.'");
		musicshop_goodanimal();
	}else{
		musicshop_badanimal();
	}
}
if ($op=="cat"){
	musicshop_musicheader ();
	if (get_module_pref("animal")==3){
		output("`%'Yeah, `#Klicky Kitty`% was his name.");
		output("He was a really good cat.'");
		musicshop_goodanimal();
	}else{
		musicshop_badanimal();
	}
}
if ($op=="frog"){
	musicshop_musicheader ();
	if (get_module_pref("animal")==4){
		output("`%'Yeah, `#Flicky Froggy`% was his name.");
		output("He was a really good frog.'");
		musicshop_goodanimal();
	}else{
		musicshop_badanimal();
	}
}
if ($op=="platypus"){
	musicshop_musicheader ();
	if (get_module_pref("animal")==5){
		output("`%'Yeah, `#Patience the Platypus`% was his name.");
		output("He was a really good platypus.'");
		musicshop_goodanimal();
	}else{
		musicshop_badanimal();
	}
}
if ($op=="hummingbird"){
	musicshop_musicheader ();
	if (get_module_pref("animal")==6){
		output("`%'Yeah, `#Humly Hummingbird`% was his name.");
		output("He was a really good bird.'");
		musicshop_goodanimal();
	}else{
		musicshop_badanimal();
	}
}
if ($op=="duck"){
	musicshop_musicheader ();
	if (get_module_pref("animal")==7){
		output("`%'Yeah, `#Dinky Duck`% was his name.");
		output("He was a really good bird.'");
		musicshop_goodanimal();
	}else{
		musicshop_badanimal();
	}
}
if ($op=="scorpion"){
	musicshop_musicheader ();
	if (get_module_pref("animal")==8){
		output("`%'Yeah, `#Scrungy Scorpion`% was his name.");
		output("He was a really good scorpion.'");
		musicshop_goodanimal();
	}else{
		musicshop_badanimal();
	}
}
if ($op=="monkey"){
	musicshop_musicheader ();
	if (get_module_pref("animal")==9){
		output("`%'Yeah, `#Macky Monkey`% was his name.");
		output("He was a really good monkey.'");
		musicshop_goodanimal();
	}else{
		musicshop_badanimal();
	}
}
if ($op=="horse"){
	musicshop_musicheader ();
	if (get_module_pref("animal")==10){
		output("`%'Yeah, `#Humphrey Horsey`% was his name.");
		output("He was a really good horse.'");
		musicshop_goodanimal();
	}else{
		musicshop_badanimal();
	}
}
if ($op=="story"){
	musicshop_musicheader ();
	blocknav ("village.php");
	set_module_pref("bellstory",1);
	$race=e_rand(1,10);
	set_module_pref("race",$race);
	$racechoice=array("","Dwarf","Imp","Dark Elf","Felyne","Drow","Troll","Human","Storm Giant","Halfling","Gnome");
	output("`%'As you recall, `2Transic`% became my teacher and guide in the world of music.");
	output("And this is the world that saved me from shunning light and happiness.");
	output("It's no surprise that we eventually fell in love.'");
	output("`n`n'Our wedding was simple and small; few family members came.");
	output("Rather a collection of fellow musicians witnessed our union.");
	output("I won't lie to you, there has never been such wondrous joy in the air like the music that was played at our wedding.");
	output("It was a moment when I let all the dark thoughts in my past wash away forever and I embraced the two greatest loves of my life; `2Transic`% and Music.'");
	output("`n`n'Those bells that adorn my door?");
	output("They topped our cake, held on a wonderful little trellis.");
	output("The wind would blow across the cake and the bells would ring.");
	output("We would kiss.");
	output("I was never happier in my life.'");
	output("`n`n`QShe pauses for a second, smiling, immersed in memory.");
	output("`n`n`%'Of course, our wedding was something held only in the highest scorn from the members of my home community.");
	output("It never crossed my mind to care.");
	output("I should have known better.'");
	output("`n`n'Little did I realize that the governing body of my hometown had been infiltrated by a %s of pure evil.",$racechoice[$race]);
	output("I know, it doesn't make sense to me how it could happen either, but it did.");
	output("He stirred the people against my marriage and it became a rallying point for their hatred.");
	output("Soon enough, they attacked my home and burned it to the ground.");
	output("`2Transic`% and I were pursued across the countryside until we were able to take a stand.");
	output("We would have been killed instantly if it hadn't been for the help of a band of outcast elves.");
	output("Together we fought off the evil attack, but both `2Transic`% and I received grave wounds from an archer's arrows.");
	output("`2Transic`% died just an arm's length away from me, and my hand held his til the last.'");
	output("`n`n'I would have died too, had it not been for the bells that I wore covered under my shirt.");
	output("The second bell deflected the arrow just enough to save my life.'");
	output("`n`n'When I was recovering, I finally had a chance to thank the outcast elves that had saved my life.");
	output("It was then that I learned the truth.");
	output("`n`n'Those elves that saved my life and desperately tried to save the life of my husband... were my parents.'`n`n");
	addnav("Amleine's Story Continues","runmodule.php?module=musicshop&op=continue2");	
}
if ($op=="continue2"){
	musicshop_musicheader ();
	blocknav ("village.php");
	output("`QYou stagger from the story.");
	output("`n`n`%'By now I'm sure you can understand why that is the one race in the world that I have little love for.'`n`n");
	output("`%Amleine`Q looks at you for a glimmer of confirmation and understanding.");
	output("You can only reply that you understand why she would hate...`n`n");
	addnav("Dwarves","runmodule.php?module=musicshop&op=dwarves");
	addnav("Imps","runmodule.php?module=musicshop&op=imps");
	addnav("Dark Elves","runmodule.php?module=musicshop&op=darkelves");
	addnav("Felynes","runmodule.php?module=musicshop&op=felynes");
	addnav("Drow","runmodule.php?module=musicshop&op=drow");
	addnav("Trolls","runmodule.php?module=musicshop&op=trolls");
	addnav("Humans","runmodule.php?module=musicshop&op=humans");
	addnav("Storm Giants","runmodule.php?module=musicshop&op=stormgiants");
	addnav("Halflings","runmodule.php?module=musicshop&op=halflings");
	addnav("Gnomes","runmodule.php?module=musicshop&op=gnomes");
}
if ($op=="dwarves"){
	musicshop_musicheader ();
	if (get_module_pref("race")==1){
		output("`%'Well, I don't want you to get the wrong impression.");
		output("I don't hate Dwarves, I just fear them more than other races.");	
		musicshop_rightrace();
	}else{
		musicshop_wrongrace();
	}
}	
if ($op=="imps"){
	musicshop_musicheader ();
	if (get_module_pref("race")==2){
		output("`%'Well, I don't want you to get the wrong impression.");
		output("I don't hate Imps, I just fear them more than other races.");	
		musicshop_rightrace();
	}else{
		musicshop_wrongrace();
	}
}
if ($op=="darkelves"){
	musicshop_musicheader ();
	if (get_module_pref("race")==3){
		output("`%'Well, I don't want you to get the wrong impression.");
		output("I don't hate Dark Elves, I just fear them more than other races.");	
		musicshop_rightrace();
	}else{
		musicshop_wrongrace();
	}
}
if ($op=="felynes"){
	musicshop_musicheader ();
	if (get_module_pref("race")==4){
		output("`%'Well, I don't want you to get the wrong impression.");
		output("I don't hate Felynes, I just fear them more than other races.");	
		musicshop_rightrace();
	}else{
		musicshop_wrongrace();
	}
}
if ($op=="drow"){
	musicshop_musicheader ();
	if (get_module_pref("race")==5){
		output("`%'Well, I don't want you to get the wrong impression.");
		output("I don't hate Drow, I just fear them more than other races.");	
		musicshop_rightrace();
	}else{
		musicshop_wrongrace();
	}
}
if ($op=="trolls"){
	musicshop_musicheader ();
	if (get_module_pref("race")==6){
		output("`%'Well, I don't want you to get the wrong impression.");
		output("I don't hate Trolls, I just fear them more than other races.");	
		musicshop_rightrace();
	}else{
		musicshop_wrongrace();
	}
}
if ($op=="humans"){
	musicshop_musicheader ();
	if (get_module_pref("race")==7){
		output("`%'Well, I don't want you to get the wrong impression.");
		output("I don't hate Humans, I just fear them more than other races.");	
		musicshop_rightrace();
	}else{
		musicshop_wrongrace();
	}
}
if ($op=="stormgiants"){
	musicshop_musicheader ();
	if (get_module_pref("race")==8){
		output("`%'Well, I don't want you to get the wrong impression.");
		output("I don't hate Storm Giants, I just fear them more than other races.");	
		musicshop_rightrace();
	}else{
		musicshop_wrongrace();
	}
}
if ($op=="halflings"){
	musicshop_musicheader ();
	if (get_module_pref("race")==9){
		output("`%'Well, I don't want you to get the wrong impression.");
		output("I don't hate Halflings, I just fear them more than other races.");	
		musicshop_rightrace();
	}else{
		musicshop_wrongrace();
	}
}
if ($op=="gnomes"){
	musicshop_musicheader ();
	if (get_module_pref("race")==10){
		output("`%'Well, I don't want you to get the wrong impression.");
		output("I don't hate Gnomes, I just fear them more than other races.");	
		musicshop_rightrace();
	}else{
		musicshop_wrongrace();
	}
}
if ($op=="rules"){
	musicshop_musicheader ();
	if ($firstmusic==0) output("`%'As I mentioned, music is not a skill that can be mastered lightly. Here's how my shop works:`n`n");
	set_module_pref("firstmusic",1);
	output("`c`b`%R`4ules`n`n`c`b");
	if ($choice==0) {
		output("`61. You will first need to choose a discipline to study.");
		output("Once you make your choice, you will need to follow through with studying it.");
		output("There are 3 types of musical studies you can work on:");
		output("`!Performance`6, `@Instrument Making`6, and `\$Composition`6.");
		output("Each has five different focuses from which you will need to choose one from.`n`n");
	}else{
		output("`61. You are currently studying how to`b`& %s`b`6.",$musicstudy[get_module_pref("choice")]);
		output("This is your current focus.");
		output("Due to the difficulty of mastering a discipline, you will be required to continue focusing on this until you have completed your studies.");
		output("You can't change your studies once you've started them.`n`n");
	}
	output("`72. Each day of study will cost you more as your lessons become more difficult.");
	output("You will need to pay `^%s gold`7 per level.",$goldlevel);
	if ($choice==0) output("By the way, your first lesson is always free!");
	else output  ("Your current fee for today's lesson is`^ %s gold`7.",$goldlesson);
	output("`n`n`63. In order to master your lessons, you'll need to study for `b`& at least 12 Different Levels`b`6.");
	output("It's up to you to remember to practice!");
	if ($musicvisit==1) output("You have `b`&completed ONE lesson`b`6 so far.");
	if ($musicvisit>1) output("You have `b`&completed %s lessons`b`6 so far.",$musicvisit);	
	output("If you get behind in your studies, you will not be able to master your discipline no matter what.");
	output("Music is a harsh master.`n`n");
	output("`74.  Upon completion of your studies, you will have to demonstrate your abilities, after which I will present you with your award.");
	output("Each award is different depending on what you have chosen to study.`n`n");
	output("`65.  You may not repeat studying any area until you have completed every focus in every discipline.");
	output("After all, I want you to expand your talents in all directions.");
	if (get_module_setting("musicbio")==1&&get_module_pref("masterful")==0) output("Once you have completed all of the disciplines, your Bio will show you as `^First Level Master of Music`6.  Every time you complete all areas, your bio will update with a new title to reflect this.");
	if (get_module_setting("musicbio")==1&&get_module_pref("masterful")>0&&get_module_pref("nummastered")<10) output("Your bio will update as you continue to demonstrate mastery of all the areas of music.");
	if (get_module_setting("musicbio")==1&&get_module_pref("masterful")>=10) output("You are the `5`bThe Ultimate Supreme Grandmaster of Music`b`6.  You may continue your studies, but your title shows you are the best there is.");
	output("`n`n");
	if ($choice==0) {
		output("`%'Are you ready to choose your discipline?'`n`n");
		addnav("Learn an Instrument","runmodule.php?module=musicshop&op=practice");
		addnav("Learn Instrument Making","runmodule.php?module=musicshop&op=build");
		addnav("Learn Composition","runmodule.php?module=musicshop&op=compose");
	}elseif ($session['user']['gold']<	$goldlesson){
		addnav("Back to the Storefront","runmodule.php?module=musicshop&op=music");		
	}else{
		output("`%'Are you ready to continue your studies on how to`& %s`%?'",$musicstudy[get_module_pref("choice")]);
		addnav("Back to the Storefront","runmodule.php?module=musicshop&op=music");
		blocknav("runmodule.php?module=musicshop&op=rules");
	}
	if (get_module_pref("nummastered")>0) addnav("Review Completed Studies","runmodule.php?module=musicshop&op=completed");
}
if ($op=="completed"){
	musicshop_musicheader ();
	output("`%'You have completed studies in the following areas:'`n`n");
	if (get_module_pref("plute")==2) output("`^Lute Performance`n");
	if (get_module_pref("pfiddle")==2) output("`!Fiddle Performance`n");
	if (get_module_pref("pbagpipes")==2) output("`\$B`@a`\$g`@p`\$i`@p`\$e`@s `\$P`@e`\$r`@f`\$o`@r`\$m`@a`\$n`@c`\$e`n");
	if (get_module_pref("pflute")==2) output("`#Flute Performance`n");
	if (get_module_pref("pkettledrums")==2) output("`%Kettledrum Performance`n");
	if (get_module_pref("mlute")==2) output("`^Lute Making`n");
	if (get_module_pref("mfiddle")==2) output("`!Fiddle Making`n");
	if (get_module_pref("mbagpipes")==2) output("`\$B`@a`\$g`@p`\$i`@p`\$e`@s `\$M`@a`\$k`@i`\$n`@g`n");
	if (get_module_pref("mflute")==2) output("`#Flute Making`n");
	if (get_module_pref("mkettledrums")==2) output("`%Kettledrum Making`n");
	if (get_module_pref("festival")==2) output("`@F`2estival `^M`6usic `@C`2omposition`n");	
	if (get_module_pref("madrigal")==2) output("`%M`5adrigal `%M`5usic `%C`5omposition`n");
	if (get_module_pref("dirges")==2) output("`)Dirge Composition`n");
	if (get_module_pref("symphonies")==2) output("`3Symphony Composition`n");
	if (get_module_pref("sonatas")==2) output("`\$S`4onata `\$C`4omposition`n");
	if ($musicvisit==0) {
		output("`Q`nAre you ready to choose your area of study?`n`n");
		addnav("Learn an Instrument","runmodule.php?module=musicshop&op=practice");
		addnav("Learn Instrument Making","runmodule.php?module=musicshop&op=build");
		addnav("Learn Composition","runmodule.php?module=musicshop&op=compose");
		addnav("Review Rules","runmodule.php?module=musicshop&op=rules");
	}elseif ($session['user']['gold']<$goldlesson){
		addnav("Review Rules","runmodule.php?module=musicshop&op=rules");
	}else{	
		musicshop_musicnavs();
		blocknav("runmodule.php?module=musicshop&op=completed");
	}
	addnav("Back to the Storefront","runmodule.php?module=musicshop&op=music");
}
if ($op=="practice"){
	musicshop_musicheader ();
	output("`%'The following instruments are available for you to study:'`n`n");
	addnav("Review Rules","runmodule.php?module=musicshop&op=rules");
	if (get_module_pref("nummastered")>0) addnav("Review Completed Studies","runmodule.php?module=musicshop&op=completed");
	addnav("Back to the Storefront","runmodule.php?module=musicshop&op=music");
	addnav("Choose an Instrument");
	if (get_module_pref("plute")==0){
		output("`^Lute`n`n");
		addnav("Play the Lute","runmodule.php?module=musicshop&op=learnlute");
	}	
	if (get_module_pref("pfiddle")==0){
		output("`!Fiddle`n`n");
		addnav("Play the Fiddle","runmodule.php?module=musicshop&op=learnfiddle");
	}
	if (get_module_pref("pbagpipes")==0){
		output("`\$B`@a`\$g`@p`\$i`@p`\$e`@s`n`n");
		addnav("Play Bagpipes","runmodule.php?module=musicshop&op=learnbagpipes");
	}
	if (get_module_pref("pflute")==0){
		output("`#Flute`n`n");
		addnav("Play the Flute","runmodule.php?module=musicshop&op=learnflute");
	}
	if (get_module_pref("pkettledrums")==0){
		output("`%Kettledrums`n`n");
		addnav("Play Kettledrums","runmodule.php?module=musicshop&op=learnkettledrums");
	}
	if (get_module_pref("plute")==2 && get_module_pref("pfiddle")==2 && get_module_pref("pbagpipes")==2 && get_module_pref("pflute")==2 && get_module_pref("pkettledrums")==2){
		output("`%'Oh, I see you've mastered playing all our instruments in the `%M`4usic `%S`4hop`%.");
		output("Perhaps you'd like to try one of our other studies.'");
	}
	addnav("Choose Another Area of Study");
	addnav("Learn Instrument Making","runmodule.php?module=musicshop&op=build");
	addnav("Learn Composition","runmodule.php?module=musicshop&op=compose");	
}
if ($op=="learnlute"){
	musicshop_musicheader ();
	output("`QYou decide to learn how to play the `^Lute`Q.");
	output("`n`n`%Amleine`Q begins your first lesson (which is free) by introducing you to your new instrument.`n`n");
	musicshop_lute();
	output("`QYou begin your rudimentary exploration of the `^Lute");
	set_module_pref("plute",1);
	set_module_pref("choice",1);
	musicshop_firstlesson();
	musicshop_levelstudy();
}
if ($op=="learnfiddle"){
	musicshop_musicheader ();
	output("`QYou decide to learn how to play the `!Fiddle`Q.");
	output("`n`n`%Amleine`Q begins your first lesson (which is free) by introducing you to your new instrument.`n`n");
	musicshop_fiddle();
	output("`QYou begin your rudimentary exploration of the `!Fiddle");
	set_module_pref("pfiddle",1);
	set_module_pref("choice",2);
	musicshop_firstlesson();
	musicshop_levelstudy();
}
if ($op=="learnbagpipes"){
	musicshop_musicheader ();
	output("`QYou decide to learn how to play the `\$B`@a`\$g`@p`\$i`@p`\$e`@s`Q.");
	output("`n`n`%Amleine`Q begins your first lesson (which is free) by introducing you to your new instrument.`n`n");
	musicshop_bagpipes();
	output("`QYou begin your rudimentary exploration of the `\$B`@a`\$g`@p`\$i`@p`\$e`@s");
	set_module_pref("pbagpipes",1);
	set_module_pref("choice",3);
	musicshop_firstlesson();
	musicshop_levelstudy();
}
if ($op=="learnflute"){
	musicshop_musicheader ();
	output("`QYou decide to learn how to play the `#Flute`Q.");
	output("`n`n`%Amleine`Q begins your first lesson (which is free) by introducing you to your new instrument.`n`n");
	musicshop_flute();
	output("`QYou begin your rudimentary exploration of the `#flute");
	set_module_pref("pflute",1);
	set_module_pref("choice",4);
	musicshop_firstlesson();
	musicshop_levelstudy();
}
if ($op=="learnkettledrums"){
	musicshop_musicheader ();
	output("`QYou decide to learn how to play the `%Kettledrums`Q.");
	output("`n`n`%Amleine`Q begins your first lesson (which is free) by introducing you to your new instrument.`n`n");
	musicshop_kettledrums();
	output("`QYou begin your rudimentary exploration of the `%Kettledrums ");
	set_module_pref("pkettledrums",1);
	set_module_pref("choice",5);
	musicshop_firstlesson();
	musicshop_levelstudy();
}

if ($op=="build"){
	musicshop_musicheader ();
	output("`%'The following instruments are available for you to learn how to make:'`n`n");
	addnav("Review Rules","runmodule.php?module=musicshop&op=rules");
	if (get_module_pref("nummastered")>0) addnav("Review Completed Studies","runmodule.php?module=musicshop&op=completed");
	addnav("Back to the Storefront","runmodule.php?module=musicshop&op=music");
	addnav("Choose an Instrument");
	if (get_module_pref("mlute")==0){
		output("`^Lute`n`n");
		addnav("Make a Lute","runmodule.php?module=musicshop&op=makelute");
	}	
	if (get_module_pref("mfiddle")==0){
		output("`!Fiddle`n`n");
		addnav("Make a Fiddle","runmodule.php?module=musicshop&op=makefiddle");
	}
	if (get_module_pref("mbagpipes")==0){
		output("`\$B`@a`\$g`@p`\$i`@p`\$e`@s`n`n");
		addnav("Make Bagpipes","runmodule.php?module=musicshop&op=makebagpipes");
	}
	if (get_module_pref("mflute")==0){
		output("`#Flute`n`n");
		addnav("Make a Flute","runmodule.php?module=musicshop&op=makeflute");
	}
	if (get_module_pref("mkettledrums")==0){
		output("`%Kettledrums`n`n");
		addnav("Make Kettledrums","runmodule.php?module=musicshop&op=makekettledrums");
	}
	if (get_module_pref("mlute")==2 && get_module_pref("mfiddle")==2 && get_module_pref("mbagpipes")==2 && get_module_pref("mflute")==2 && get_module_pref("mkettledrums")==2){
		output("`%'Oh, I see you've mastered creating all our instruments in the `%M`4usic `%S`4hop`%.");
		output("Perhaps you'd like to try one of our other studies.'");
	}
	addnav("Choose Another Area of Study");
	addnav("Learn Performance","runmodule.php?module=musicshop&op=practice");
	addnav("Learn Composition","runmodule.php?module=musicshop&op=compose");
}
if ($op=="makelute"){
	musicshop_musicheader ();
	output("`QYou decide to learn how to make `^Lutes`Q.");
	output("`n`n`%Amleine`Q begins your first lesson (which is free) by introducing you to the history of the instrument you're going to make.`n`n");
	musicshop_lute();
	output("`QYou begin your rudimentary exploration of `^Lute`Q making");
	set_module_pref("mlute",1);
	set_module_pref("choice",6);
	musicshop_firstlesson();
	musicshop_levelstudy();
}
if ($op=="makefiddle"){
	musicshop_musicheader ();
	output("`QYou decide to learn how to make `!Fiddles`Q.");
	output("`n`n`%Amleine`Q begins your first lesson (which is free) by introducing you to the history of the instrument you're going to make.`n`n");
	musicshop_fiddle();
	output("`QYou begin your rudimentary exploration of `!Fiddle`Q making");
	set_module_pref("mfiddle",1);
	set_module_pref("choice",7);
	musicshop_firstlesson();
	musicshop_levelstudy();
}
if ($op=="makebagpipes"){
	musicshop_musicheader ();
	output("`QYou decide to learn how to make `\$B`@a`\$g`@p`\$i`@p`\$e`@s`Q.");
	output("`n`n`%Amleine`Q begins your first lesson (which is free) by introducing you to the history of the instrument you're going to make.`n`n");
	musicshop_bagpipes();
	output("`QYou begin your rudimentary exploration of `\$B`@a`\$g`@p`\$i`@p`\$e `Qmaking");
	set_module_pref("mbagpipes",1);
	set_module_pref("choice",8);
	musicshop_firstlesson();
	musicshop_levelstudy();
}
if ($op=="makeflute"){
	musicshop_musicheader ();
	output("`QYou decide to learn how to make `#Flute`Q.");
	output("`n`n`%Amleine`Q begins your first lesson (which is free) by introducing you to the history of the instrument you're going to make.`n`n");
	musicshop_flute();
	output("`QYou begin your rudimentary exploration of `#Flute `Qmaking");
	set_module_pref("mflute",1);
	set_module_pref("choice",9);
	musicshop_firstlesson();
	musicshop_levelstudy();
}
if ($op=="makekettledrums"){
	musicshop_musicheader ();
	output("`QYou decide to learn how to make `%Kettledrums`Q.");
	output("`n`n`%Amleine`Q begins your first lesson (which is free) by introducing you to the history of the instrument you're going to make.`n`n");
	musicshop_kettledrums();
	output("`QYou begin your rudimentary exploration of `%Kettledrum `Qmaking");
	set_module_pref("mkettledrums",1);
	set_module_pref("choice",10);
	musicshop_firstlesson();
	musicshop_levelstudy();
}
if ($op=="compose"){
	musicshop_musicheader ();
	output("`%'The following music Styles are available for you to learn how to compose:'`n`n");
	addnav("Review Rules","runmodule.php?module=musicshop&op=rules");
	if (get_module_pref("nummastered")>0) addnav("Review Completed Studies","runmodule.php?module=musicshop&op=completed");
	addnav("Back to the Storefront","runmodule.php?module=musicshop&op=music");
	addnav("Choose Music Style");
	if (get_module_pref("festival")==0){
		output("`@F`2estival `^M`6usic`n`n");
		addnav("Festival Music","runmodule.php?module=musicshop&op=writefestival");
	}	
	if (get_module_pref("madrigal")==0){
		output("`%M`5adrigal `%M`5usic`n`n");
		addnav("Madrigal Music","runmodule.php?module=musicshop&op=writemadrigal");
	}
	if (get_module_pref("dirges")==0){
		output("`)Dirges`n`n");
		addnav("Dirges","runmodule.php?module=musicshop&op=writedirges");
	}
	if (get_module_pref("symphonies")==0){
		output("`3Symphonies`n`n");
		addnav("Symphonies","runmodule.php?module=musicshop&op=writesymphonies");
	}
	if (get_module_pref("sonatas")==0){
		output("`\$S`4onatas`n`n");
		addnav("Sonatas","runmodule.php?module=musicshop&op=writesonatas");
	}
	if (get_module_pref("festival")==1 && get_module_pref("madrigal")==1 && get_module_pref("dirges")==1 && get_module_pref("symphonies")==1 && get_module_pref("sonatas")==1){
		output("`%'Oh, I see you've mastered all the composition styles in the `%M`4usic `%S`4hop`%.");
		output("Would you like to try one of our other studies?'");
	}
	addnav("Choose Another Area of Study");
	addnav("Learn Performance","runmodule.php?module=musicshop&op=practice");
	addnav("Learn Instrument Making","runmodule.php?module=musicshop&op=build");
}
if ($op=="writefestival"){
	musicshop_musicheader ();
	output("`QYou decide to learn how to compose `@F`2estival `^M`6usic`Q.");
	output("`n`n`%Amleine`Q begins your first lesson (which is free) by introducing you to the basics of `@F`2estival `^M`6usic`Q.`n`n");
	output("`%'The increasing reliance on the interval of the third as a consonance is one of the most pronounced features of early Festival Music.");
	output("Previously, thirds had been considered dissonances.");
	output("Polyphony, in use since the 12th century, became increasingly elaborate with highly independent voices throughout the 14th century:");
	output("the beginning of the 15th century showed simplification, with the voices often striving for smoothness.");
	output("`@F`2estival `^M`6usic`% often focused on a basic three chord structure accented with simple meter.'");
	output("`n`n`QYou begin your rudimentary exploration of `@F`2estival `^M`6usic`Q Composition");
	set_module_pref("festival",1);
	set_module_pref("choice",11);
	musicshop_firstlesson();
	musicshop_levelstudy();
	//information thanks to http://en.wikipedia.org/wiki/Renaissance_music
}
if ($op=="writemadrigal"){
	musicshop_musicheader ();
	output("`QYou decide to learn how to compose `%M`5adrigal `%M`5usic`Q.");
	output("`n`n `%Amleine`Q begins your first lesson (which is free) by introducing you to the basics of `%M`5adrigal `%M`5usic`Q.`n`n");
	output("`%'M`5adrigal`% is a vocal music form that flourished in the Renaissance, originating in Italy.");
	output("The M`5adrigal`% is generally written for four to six voices that may or may not be accompanied.");
	output("M`5adrigals`% are usually set to short love poems, though the words are occasionally about death, war, etc.");
	output("They were extremely popular in England and Italy, and also produced in France, Germany, and a few in Spain.'");
	output("`n`n`QYou begin your rudimentary exploration of `%M`5adrigal `%M`5usic`Q Composition");
	set_module_pref("madrigal",1);
	set_module_pref("choice",12);
	musicshop_firstlesson();
	musicshop_levelstudy();
	//information thanks to http://www.music.vt.edu/musicdictionary/textm/Madrigal.html
}
if ($op=="writedirges"){
	musicshop_musicheader ();
	output("`QYou decide to learn how to compose `)Dirge Music`Q.");
	output("`n`n`%Amleine`Q begins your first lesson (which is free) by introducing you to the basics of `)Dirge `QComposition.`n`n");
	output("`%'A `)Dirge`% is a somber song expressing mourning or grief, such as would be appropriate for performance at a funeral.'");
	output("`n`n`QYou begin your rudimentary exploration of `)Dirge`Q Composition");
	set_module_pref("dirges",1);
	set_module_pref("choice",13);
	musicshop_firstlesson();
	musicshop_levelstudy();
	//information thanks to http://en.wikipedia.org/wiki/Dirge
}
if ($op=="writesymphonies"){
	musicshop_musicheader ();
	output("`QYou decide to learn how to compose `3Symphonies`Q.");
	output("`n`n`%Amleine`Q begins your first lesson (which is free) by introducing you to the basics of `3Symphony `QComposition.`n`n");
	output("`%'`3Symphonies`% are large compositions for orchestra, generally in three or four movements.");
	output("The `3Symphony`% may also be defined as a sonata for orchestra.");
	output("The earlier `3Symphonies`%, those of the Classical era, were generally simpler, and of a smaller scale.'");
	output("`n`n`QYou begin your rudimentary exploration of `3Symphony`Q Composition");
	set_module_pref("symphonies",1);
	set_module_pref("choice",14);
	musicshop_firstlesson();
	musicshop_levelstudy();
	//information thanks to http://www.music.vt.edu/musicdictionary
}
if ($op=="writesonatas"){
	musicshop_musicheader ();
	output("`QYou decide to learn how to compose `\$S`4onatas`Q.");
	output("`n`n`%Amleine`Q begins your first lesson (which is free) by introducing you to the basics of `\$S`4onata `QComposition.`n`n");
	output("`%'A `\$S`4onata `% is a composition for one or more solo instruments, one of which is usually a harpsicord, usually consisting of three or four independent movements varying in key, mood, and tempo.'");
	output("`n`n`QYou begin your rudimentary exploration of `\$S`4onata`Q Composition");
	set_module_pref("sonatas",1);
	set_module_pref("choice",15);
	musicshop_firstlesson();
	musicshop_levelstudy();
	//information thanks to http://www.answers.com/topic/sonata
}
if ($op=="maestro"){
	musicshop_musicheader ();
	$newtitle = "Maestro";
	$newname = change_player_title($newtitle);
	$session['user']['title'] = $newtitle;
	$session['user']['name'] = $newname;
	output("`%'Good job, `^%s`%!!'",$session['user']['name']);
}	
if ($op=="practiceplay"){
	musicshop_musicheader ();
	musicshop_levelstudy();
	$session['user']['gold']-=$goldlesson;
	output("`QYou hand over your `^%s gold`Q and look expectantly.`n`n",$goldlesson);
	if ($musicvisit<=4) {
		output("`%Amleine`Q takes you to the `%P`4ractice `%R`4oom`Q and guides you with your lessons on how to play the `&%s`Q.",$musicitem[get_module_pref("choice")]);
		output("`n`nIt's an intensive learning experience and after a while you feel like some of it is finally starting to sink in.`n`n");
		musicshop_earlylesson();
	}elseif	($musicvisit<=7) {
		output("`QYou borrow a `&%s`Q from `%Amleine`Q and wander back to the `%P`4ractice `%R`4oom`Q.  When she arrives, you start to work on intermediate skills of the `&%s`Q.",$musicitem[get_module_pref("choice")],$musicitem[get_module_pref("choice")]);
		output("`n`nYou feel like you're doing a great job, and look up at `%Amleine`Q  expectantly.`n`n");
		musicshop_midlesson();
	}elseif ($musicvisit<=10){
		output("`%'Ready for another lesson?' Amleine`Q asks you with a smile.");
		output("Of course you are, and you follow her to the `%P`4ractice `%R`4oom`Q with your`& %s`Q.",$musicitem[get_module_pref("choice")]);
		output("The lessons are definitely becoming much more difficult, but `%Amleine`Q guides you expertly.`n`n");
		musicshop_latelesson();
	}elseif ($musicvisit>10){
		addnav("Back to the Storefront","runmodule.php?module=musicshop&op=music");
		output("`QAs soon as you walk in, you realize something is different about today.");
		output("Yes, today will be your final lesson on the `&%s`Q.",$musicitem[get_module_pref("choice")]);
		output("You've worked very hard to get to this point, and it's just a matter of learning a couple extra subtle techniques.");
		output("You walk with `%Amleine`Q back to the `%P`4ractice `%R`4oom`Q together to take your last lesson.");
		output("You perform a very complicated composition for `%Amleine`Q and look at her expectantly.`n`n");		
		switch(e_rand(1,35)){
			case 1: case 2: case 3: case 4: case 5: case 6: case 7: case 8: case 9: case 10: case 11: case 12: case 13: case 14: case 15: case 16: case 17: case 18: case 19:
				output("`%'I have to admit, a performance of such skill would enthrall even the most unappreciative audience.");
				output("In fact, that will be the final test for you.'");
				output("`n`n'If you have some time, we can go back to the front of the office to talk a little more.");
				output("Otherwise, come and visit me one more time and we'll see if you're ready to give a public concert.");
				output("Remember, you haven't proven mastery of how to `&%s`% until you've proven yourself in concert.'`n`n",$musicstudy[get_module_pref("choice")]);
				output("`QThe excitement gives a lilt in your step and the people all see you walking a little more proudly.");
				output("You gain `&One Charm Point`Q.");
				$session['user']['charm']++;
			break;
			case 20: case 21: case 22: case 23: case 24: case 25: case 26: case 27: case 28: case 29:
				output("`%'You're performance is wonderful.");
				output("Truly, it is.");
				output("Since this is a gem of a performance, I want to give you something so that you don't forget about this amazing accomplishment.'");
				output("`n`n`%Amleine`Q takes out a beautiful `\$g`^e`@m`Q and you know its value is worth quite a bit.");
				output("`n`n  In fact, it's worth `%3 gems`Q.`n`n");
				output("`%'If you have some time, we can go back to the front of the office to talk a little more.");
				output("Otherwise, come and visit me one more time and we'll see if you're ready to give a public concert.");
				output("Remember, you haven't proven mastery of how to `&%s`% until you've proven yourself in concert.'`n`n",$musicstudy[get_module_pref("choice")]);
				$session['user']['gems']+=3;
			break;
			case 30: case 31: case 32:
				output("`%'This has come together beautifully.");
				output("What more can I say?'");
				output("`Q`n`nYou feel quite happy about your performance.");
				output("Your hard work has paid off quite well.");
				output("The adrenaline gives you strength and energy.`n`n");
				output("You decide you can go back to the forest `@3 times more`Q.`n`n");
				output("`%'If you have some time, we can go back to the front of the office to talk a little more.");
				output("Otherwise, come and visit me one more time and we'll see if you're ready to give a public concert.");
				output("Remember, you haven't proven mastery of how to `&%s`% until you've proven yourself in concert.'`n`n",$musicstudy[get_module_pref("choice")]);
				$session['user']['turns']+=3;
			break;	
			case 33: case 34:
				output("`%Amleine`Q reviews your performance very thoughtfully.");
				output("`%`n`n'You know, I'm not sure about your technique.");
				output("I think it's pretty good, but there is something peculiar about your approach to the second movement that is different than that of a typical performance on a `&%s`%.",$musicitem[get_module_pref("choice")]);
				output("But don't take my word for it.");
				output("The proof will be how well an audience receives you.");
				output("Nonetheless, your lessons are complete.'");
				output("`n`n`QThe lukewarm reception by `%Amleine`Q brings you down a little.");
				If ($session['user']['turns']>=2) {
					output("`QYou lose `@2 Turns`Q");
					$session['user']['turns']-=2;
				}elseif ($session['user']['turns']==1) {
					output("`QYou `&Lose one Charm`Q and `@One Turn`Q");
					$session['user']['charm']--;
					$session['user']['turns']--;
				}else{
					output("You `&Lose Three Charm`Q");
					$session['user']['charm']-=3;
				}
				output("second-guessing your work.");
				output("`n`n`%'I tell you what, why don't you come back to my storefront and we'll talk about performing in front of a public audience.");
				output("If you don't have the time today, you can come back later though.");
				output("Maybe I'm wrong, and it will turn out to be very successful!");
				output("Remember, you haven't mastered how to `&%s`% until you've shown the world your talent.'`n`n",$musicstudy[get_module_pref("choice")]);
			break;	
			case 35:
				output("`QYou put down your instrument and beam with pride.");
				output("`%Amleine`Q smiles with you in excitement at your performance.");
				output("`n`nThe energy of a job well done gives you a chance to go back to the forest at least `@5 More Times`Q!!`n`n");
				output("`%'If you have some time, we can go back to the front of the office to talk a little more.");
				output("Otherwise, come and visit me one more time and we'll see if you're ready to give a public concert.");
				output("Remember, you haven't proven mastery of how to `&%s`% until you've proven yourself in concert.'`n`n",$musicstudy[get_module_pref("choice")]);
				$session['user']['turns']+=5;
			break;	
		}
	}
}
if ($op=="startbuild"){
	musicshop_musicheader ();
	musicshop_levelstudy();
	$session['user']['gold']-=$goldlesson;
	output("`QYou hand over your `^%s gold`Q and look expectantly.`n`n",$goldlesson);
	if ($musicvisit<=4) {
		output("`%Amleine`Q takes you to the `%W`4ood `%S`4hop`Q and guides you with your lessons on how to make a `&%s`Q.",$musicitem[get_module_pref("choice")]);
		output("`n`nIt's an intensive learning experience and after a while you feel like some of it is finally starting to sink in.`n`n");
		musicshop_earlylesson();
	}elseif	($musicvisit<=7) {
		output("`QYou grab your tools and head to the `%W`4ood `%S`4hop`Q where your incomplete `&%s`Q waits for you.",$musicitem[get_module_pref("choice")]);
		output("When she arrives, you start to work on intermediate skills of `&%s`Q making.",$musicitem[get_module_pref("choice")]);
		output("`n`nYou feel like you're doing a great job, and look up at `%Amleine`Q  expectantly.`n`n");
		musicshop_midlesson();
	}elseif ($musicvisit<=10){
		output("`%'Ready for another lesson?' Amleine`Q asks you with a smile.");
		output("Of course you are, and you follow her to the `%W`4ood `%S`4hop`Q to work on completing your `&%s`Q.",$musicitem[get_module_pref("choice")]);
		output("The lessons are definitely becoming much more difficult, but `%Amleine`Q guides you expertly.`n`n");
		musicshop_latelesson();
	}elseif ($musicvisit>10){
		addnav("Back to the Storefront","runmodule.php?module=musicshop&op=music");
		output("`QAs soon as you walk in, you realize something is different about today.");
		output("Yes, today will be your final day making your `&%s`Q.",$musicitem[get_module_pref("choice")]);
		output("You've worked very hard to get to this point, and it's just a matter of making some finishing touches on your instrument.");
		output("You walk with `%Amleine`Q back to the `%W`4ood `%S`4hop`Q and together you put the master touches on your instrument.`n`n");		
		switch(e_rand(1,35)){
			case 1: case 2: case 3: case 4: case 5: case 6: case 7: case 8: case 9: case 10: case 11: case 12: case 13: case 14: case 15: case 16: case 17: case 18: case 19:
				output("`QTogether you complete the instrument, modeled after the works of the `&%s`Q makers of old.");
				output("`n`n`%'I have to admit, an instrument of this quality would be an honor for any musician to hold.");
				output("In fact, that will be the final test for you.");
				output("If you have some time, we can go back to the front of the office to talk a little more.");
				output("Otherwise, come and visit me one more time and we'll see if you're ready to give your instrument a try in a public performance by Seth.");
				output("Remember, you haven't proven mastery of how to `&%s`% until the instrument has had a chance to shine under the hands of a master.'`n`n",$musicstudy[get_module_pref("choice")]);
				output("`QThe excitement gives a lilt in your step and the people all see you walking a little more proudly.  You gain `&One Charm Point`Q.");
				$session['user']['charm']++;
			break;
			case 20: case 21: case 22: case 23: case 24: case 25: case 26: case 27: case 28: case 29:
				output("`%'You're instrument is wonderful.");
				output("Truly, it is.");
				output("Since this is a gem of an instrument, I want to give you something so that you don't forget about this amazing accomplishment.'");
				output("`n`n`%Amleine`Q takes out a beautiful `\$g`^e`@m`Q and you know its value is worth quite a bit.");
				output("`n`nIn fact, it's worth `%3 gems`Q.`n`n");
				output("`%'If you have some time, we can go back to the front of the office to talk a little more.");
				output("Otherwise, come and visit me one more time and we'll see if you're ready to give your instrument a try in a public performance by Seth.");
				output("Remember, you haven't proven mastery of how to `&%s`% until the instrument has had a chance to shine under the hands of a master.'`n`n",$musicstudy[get_module_pref("choice")]);
				$session['user']['gems']+=3;
			break;
			case 30: case 31: case 32:
				output("`%'This has come together beautifully.");
				output("What more can I say?'");
				output("`Q`n`nYou feel quite happy about your instrument.");
				output("Your hard work has paid off quite well.");
				output("The adrenaline gives you strength and energy.");
				output("`n`nYou decide you can go back to the forest `@3 times more`Q.`n`n");
				output("`%'If you have some time, we can go back to the front of the office to talk a little more.");
				output("Otherwise, come and visit me one more time and we'll see if you're ready to give your instrument a try in a public performance by Seth.");
				output("Remember, you haven't proven mastery of how to `&%s`% until the instrument has had a chance to shine under the hands of a master.'`n`n",$musicstudy[get_module_pref("choice")]);
				$session['user']['turns']+=3;
			break;	
			case 33: case 34:
				output("`%Amleine`Q reviews your instrument very thoughtfully.");
				output("`n`n`%'You know, I'm not sure about this piece.");
				output("I think it's pretty good, but there is something peculiar about its assembly that isn't quite typical of a standard `&%s`%.",$musicitem[get_module_pref("choice")]);
				output("But don't take my word for it.");
				output("The proof will be how well it performs under the hands of a bard.");
				output("Nonetheless, the work is complete.'");
				output("`n`n`QThe lukewarm reception by `%Amleine`Q brings you down a little.");
				If ($session['user']['turns']>=2) {
					output("`QYou lose `@2 Turns`Q");
					$session['user']['turns']-=2;
				}elseif ($session['user']['turns']==1) {
					output("`QYou `&Lose one Charm`Q and `@One Turn`Q");
					$session['user']['charm']--;
					$session['user']['turns']--;
				}else{
					output("You `&Lose Three Charm`Q");
					$session['user']['charm']-=3;
				}
				output("second-guessing your work.");
				output("`n`n`%'I tell you what, why don't you come back to my storefront and we'll talk about testing your instrument out in front of a public audience in the hands of a bard.");
				output("If you don't have the time today, you can come back later though.");
				output("Maybe I'm wrong, and it will turn out to be very successful!");
				output("Remember, you haven't mastered how to `&%s`% until the instrument has had a chance to shine under the hands of a master.'`n`n",$musicstudy[get_module_pref("choice")]);
			break;	
			case 35:
				output("`QYou hold up the instrument and beam with pride.");
				output("`%Amleine`Q smiles with you in excitement and anticipation of hearing your instrument used in a public performance.");
				output("`n`nThe energy of a job well done gives you a chance to go back to the forest at least `@5 More Times`Q!!");
				output("`n`n`%'If you have some time, we can go back to the front of the office to talk a little more.");
				output("Otherwise, come and visit me one more time and we'll see if you're ready to give your instrument a try in a public performance by Seth.");
				output("Remember, you haven't proven mastery of how to `&%s`% until the instrument has had a chance to shine under the hands of a master.'`n`n",$musicstudy[get_module_pref("choice")]);
				$session['user']['turns']+=5;
			break;	
		}
	}
}
if ($op=="startcompose"){
	musicshop_musicheader ();
	musicshop_levelstudy();
	$session['user']['gold']-=$goldlesson;
	output("`QYou hand over your `^%s gold`Q and look expectantly.`n`n",$goldlesson);
	if ($musicvisit<=4) {
		output("`%Amleine`Q takes you to a quiet study room with only a harpsicord and reams of lined paper.");
		output("Here, in the `%C`4omposition `%R`4oom`Q, your lessons on how to `&%s`Q continue with the fundamentals of music theory.",$musicstudy[get_module_pref("choice")]);
		output("`n`nIt's an intensive learning experience and after a while you feel like some of it is finally starting to sink in.`n`n");
		musicshop_earlylesson();
	}elseif	($musicvisit<=7) {
		output("`QPen in hand, you go to the `%C`4omposition `%R`4oom`Q.");
		output("`%Amleine`Q soon arrives, and you start to work on intermediate skills of writing a`& %s`Q.",$musicitem[get_module_pref("choice")]);
		output("`n`nYou feel like you're doing a great job, and look up at `%Amleine`Q  expectantly.`n`n");
		musicshop_midlesson();
	}elseif ($musicvisit<=10){
		output("`%'Ready for another lesson?' Amleine`Q asks you with a smile.  Of course you are, and you follow her to the `%C`4omposition `%R`4oom`Q with your pen at the ready.");
		output("The lessons are definitely becoming much more difficult, but `%Amleine`Q guides you expertly.`n`n");
		musicshop_latelesson();
	}elseif($musicvisit>10){
		addnav("Back to the Storefront","runmodule.php?module=musicshop&op=music");
		output("`QAs soon as you walk in, you realize something is different about today.");
		output("Yes, today will be your last lesson on how to compose a `&%s`Q.",$musicitem[get_module_pref("choice")]);
		output("You've worked very hard to get to this point, and it's just a matter of making some finishing touches on your opus.");
		output("You walk with `%Amleine`Q back to the `%C`4omposition `%R`4oom`Q and together you put the master touches on your piece.`n`n");		
		switch(e_rand(1,35)){
			case 1: case 2: case 3: case 4: case 5: case 6: case 7: case 8: case 9: case 10: case 11: case 12: case 13: case 14: case 15: case 16: case 17: case 18: case 19:
				output("`QTogether you review the song, written in the perfect style of the `&%s`Q composers of old.");
				output("`n`n`%'I have to admit, I will have this song in the back of my head for quite a while.");
				output("It really is a song that is worthy of public performance.");
				output("If you have some time, we can go back to the front of the office to talk a little more.");
				output("Otherwise, come and visit me one more time and we'll see if you're ready to give your song to the public.");
				output("Remember, you haven't mastered how to `&%s`% until it's been performed publicly.'`n`n",$musicstudy[get_module_pref("choice")]);
				output("`QThe excitement gives a lilt in your step and the people all see you walking a little more proudly.");
				output("You gain `&One Charm Point`Q.");
				$session['user']['charm']++;
			break;
			case 20: case 21: case 22: case 23: case 24: case 25: case 26: case 27: case 28: case 29:
				output("`%'You're composition is wonderful.");
				output("Truly, it is.");
				output("Since this is a gem of a song, I want to give you something so that you don't forget about this composition.'");
				output("`n`n`%Amleine`Q takes out a beautiful `\$g`^e`@m`Q and you know its value is worth quite a bit.");
				output("`n`nIn fact, it's worth `%3 gems`Q.`n`n");
				output("`%'If you have some time, we can go back to the front of the office to talk a little more.");
				output("Otherwise, come and visit me one more time and we'll see if you're ready to give your song to the public.");
				output("Remember, you haven't mastered how to `&%s`% until it's been performed publicly.'`n`n",$musicstudy[get_module_pref("choice")]);
				$session['user']['gems']+=3;
			break;
			case 30: case 31: case 32:
				output("`%'This has come together beautifully.   What more can I say?'`Q`n`nYou feel quite happy about your composition.  Your hard work has paid off quite well. The adrenaline gives you strength and energy.`n`n
					You decide you can go back to the forest `@3 times more`Q.");
				output("`n`n`%'If you have some time, we can go back to the front of the office to talk a little more.  Otherwise, come and visit me one more time and we'll see if you're ready to give your song to the public.
					Remember, you haven't mastered how to `&%s`% until it's been performed publicly.'`n`n",$musicstudy[get_module_pref("choice")]);
				$session['user']['turns']+=3;
			break;	
			case 33: case 34:
				output("`%Amleine`Q reviews your piece very thoughtfully.");
				output("`n`n`%'You know, I'm not sure about this piece.");
				output("I think it's pretty good, but there are some experimental stanzas that aren't quite typical of a `&%s`%.",$musicitem[get_module_pref("choice")]);
				output("But don't take my word for it.");
				output("The proof will be how well it is received by the public.");
				output("Nonetheless, the work is complete.'");
				output("`n`n`QYou gather your composition, but the lukewarm reception by `%Amleine`Q brings you down a little.");
				If ($session['user']['turns']>=2) {
					output("`QYou `@lose 2 Turns`Q");
					$session['user']['turns']-=2;
				}elseif ($session['user']['turns']==1) {
					output("`QYou `&Lose one Charm`Q and `@One Turn`Q");
					$session['user']['charm']--;
					$session['user']['turns']--;
				}else{
					output("You `&Lose Three Charm`Q");
					$session['user']['charm']-=3;
				}
				output("second-guessing your work.");
				output("`n`n`%'I tell you what, why don't you come back to my storefront and we'll talk about testing your composition out in front of a public audience.");
				output("If you don't have the time today, you can come back later though.");
				output("Maybe I'm wrong, and it	will turn out to be very successful!");
				output("Remember, you haven't mastered how to `&%s`% until it's been performed publicly.'`n`n",$musicstudy[get_module_pref("choice")]);
			break;	
			case 35:
				output("`QYou hold up the composition and beam with pride.");
				output("`%Amleine`Q smiles with you in excitement and anticipation of hearing your composition performed for the public.");
				output("`n`nThe energy of a job well done gives you a chance to go back to the forest at least `@5 More Times`Q!!");
				output("`n`n`%'If you have some time, we can go back to the front of the office to talk a little more.");
				output("Otherwise, come and visit me one more time and we'll see if you're ready to give your song to the public.");
				output("Remember, you haven't mastered how to `&%s`% until it's been performed publicly.'`n`n",$musicstudy[get_module_pref("choice")]);
				$session['user']['turns']+=5;
			break;	
		}
	}	
}
if ($op=="award"){
	musicshop_musicheader ();
	set_module_pref("award",1);
	if ($choice<=5){
		output("`QYou go into the village square and take out your `&%s`Q.",$musicitem[get_module_pref("choice")]);
		output("You begin playing the instrument and a small crowd gathers.");
		output("Before you know it, your fingers are flying across the instrument and the crowd `@'Ooooos'`Q and `@'ahhhhs'`Q.");
		output("`n`n`%Amleine`Q watches with a big smile.`n`n");
		output("You finish the performance and stand to take a bow.");
		output("The adrenaline courses through you.");
		output("It feels like the applause never ends!`n`n");	
		output("You put the `&%s`Q down and take another bow.",$musicitem[get_module_pref("choice")]);
		output("Yes, you truly have mastered the `&%s`Q.`n`n",$musicitem[get_module_pref("choice")]);
		if ($choice==1){
			//I know 10 forest fights sounds like a lot, but remember, they are level 15 and ready to fight the dragon.  10 Forest Fights are kinda useless for most activities.
			output("The energy is exhilarating.");
			output("`n`n`bYou `@Gain 10 extra turns`Q, `&an attack`Q, and `&a defense`Q.");
			output("`b`n`n`%Amleine`Q hugs you, congratulates you, and gives you a `b`%L`4ute `%P`4erformance `%C`4ertificate `%o`4f `%M`4astery`Q`b.`n`n");
			output("`c`b`\$C`^o`@n`#g`!r`%a`\$t`^u`@l`#a`!t`%i`\$o`^n`@s`#!`b`c");
			$session['user']['turns']+=10;
			$session['user']['defense']++;
			$session['user']['attack']++;
			set_module_pref("plute",2);
			addnews("%s`% demonstrated mastery in `^Playing the Lute`%!!",$session['user']['name']);
			debuglog("received 10 turns, 1 defense, and 1 attack for mastering the lute.");
		}elseif ($choice==2){
			output("An old man comes up to you crying.");
			output("He introduces himself.");
			output("`n`n`#'My name is `2Grand Master Fiddler Vanderick`#, perhaps you've heard of me.");
			output("I was once recognized as the best `!fiddle`# player to walk the earth.");
			output("Today, I think that I have heard a performance better than any I have performed myself.'");
			output("`n`n`QYou bow low to such a wonderful compliment and then shake his hand.");
			output("With this touch, you feel a pulse of energy sweep across your body.");
			output("Some of his powers have entered into you, and you feel changed.`n`n");
			output("The energy is exhilarating.");
			output("`n`n`bYou `#Gain the `!Fiddle Mastery`# Buff`Q.");
			output("`b`n`n`%Amleine`Q hugs you, congratulates you, and gives you a `b`%F`4iddle `%P`4erformance `%C`4ertificate `%o`4f `%M`4astery`Q`b.`n`n");
			output("`c`b`\$C`^o`@n`#g`!r`%a`\$t`^u`@l`#a`!t`%i`\$o`^n`@s`#!`b`c");
			apply_buff('fiddlemaster',array(
				"name"=>"`!Fiddle Mastery",
				"rounds"=>25,
				"wearoff"=>"`!The magic from the old Fiddler fades.",
				"atkmod"=>1.5,
				"defmod"=>1.5,
				"regen"=>5,
				"roundmsg"=>"The magic from the old Fiddler surges from you.",
			));
			set_module_pref("pfiddle",2);
			addnews("%s`% demonstrated mastery in `#Playing the Fiddle`%!!",$session['user']['name']);
			debuglog("received a powerful buff for mastering the fiddle.");
		}elseif ($choice==3){
			$gold=e_rand(5000,10000);
			$gems=e_rand(5,15);
			output("You look at the crowd and notice that everyone is `@S`\$c`@o`\$t`@t`\$i`@s`\$h`Q!!");
			output("They all empty their `^gold`Q and `%gem`Q belts at your feet.");
			output("The energy is exhilarating.");
			output("`n`n `b You gather up `^%s Gold`Q and `%%s Gems`Q!",$gold,$gems);
			output("`b`n`n`%Amleine`Q hugs you, congratulates you, and gives you a `b`%B`4agpipe `%P`4erformance `%C`4ertificate `%o`4f `%M`4astery`Q`b.`n`n");
			output("`c`b`\$C`^o`@n`#g`!r`%a`\$t`^u`@l`#a`!t`%i`\$o`^n`@s`#!`b`c");
			$session['user']['gold']+=$gold;
			$session['user']['gems']+=$gems;
			set_module_pref("pbagpipes",2);
			addnews("%s`% demonstrated mastery in `@Playing the Bagpipes`%!!",$session['user']['name']);
			debuglog("received $gold and $gems for mastering the bagpipes.");
		}elseif ($choice==4){
			output("`QYou know that this meant a lot to `%Amleine`Q.");
			output("After all, the `&Flute`Q is her favorite instrument.");
			output("She looks at you and closes her `@brilliant green`Q eyes and she starts to cast a spell.");
			output("The energies start to envelope your whole body.");
			output("You know that you're unstoppable.`n`n");
			output("The energy is exhilarating.");
			output("`n`n`bYou `#Gain `%Amleine's Blessing`Q.");
			output("`b`n`n`%Amleine`Q hugs you, congratulates you, and gives you a `b`%F`4lute `%P`4erformance `%C`4ertificate `%o`4f `%M`4astery`Q`b.`n`n");
			output("`c`b`\$C`^o`@n`#g`!r`%a`\$t`^u`@l`#a`!t`%i`\$o`^n`@s`#!`b`c");
			apply_buff('amleine',array(
				"name"=>"`%Amleine's Blessing",
				"rounds"=>8,
				"wearoff"=>"`%Although the power of the blessing fades, the inspiration doesn't.",
				"invulnerable"=>1,
				"roundmsg"=>"`@You are protected by `%Amleine's Blessing`@ from all harm.",
			));
			set_module_pref("pflute",2);
			addnews("%s`% demonstrated mastery in `#Playing the Flute`%!!",$session['user']['name']);
			debuglog("received 8 turns of invulnerability for mastering the flute.");
		}elseif ($choice==5){
			output("`QEveryone knows that drummers are the best!");
			output("They are SOOO dreamy!`n`n");
			output("The energy from your performance is exhilarating.");
			output("`n`n`bYou `&Gain 5 Charm`Q, `@2 Extra Turns`Q, and `&2 defense points`Q.");
			output("`b`n`n`%Amleine`Q hugs you, congratulates you, and gives you a `b`%K`4ettledrum `%P`4erformance `%C`4ertificate `%o`4f `%M`4astery`Q`b.`n`n");
			output("`c`b`\$C`^o`@n`#g`!r`%a`\$t`^u`@l`#a`!t`%i`\$o`^n`@s`#!`b`c");
			$session['user']['charm']+=5;
			$session['user']['turns']+=2;
			$session['user']['defense']+=2;
			set_module_pref("pkettledrums",2);
			addnews("%s`% demonstrated mastery in `%Playing the Kettledrums`%!!",$session['user']['name']);
			debuglog("received 5 charm, 2 turns, and 2 defense for mastering the kettledrums.");
		}
	}elseif ($choice<=10){
		output("`QYou meet Seth in the Village square and hand him your hand made `&%s`Q.",$musicitem[get_module_pref("choice")]);
		output("He stops to look over it for a couple of minutes.`n`nHe gives the`&");
		if ($choice==6) output("lute`Q an experimental strum");
		if ($choice==7) output("fiddle`Q an experimental strum");
		if ($choice==8) output("bagpipes`Q an experimental blow");
		if ($choice==9) output("flute`Q an experimental blow");
		if ($choice==10) output("kettledrum`Q an experimental beat");
		output("and looks at you with a smile.");
		output("`n`n`4'I think I'm ready to perform!'`n`n");
		output("`QYou stand next to `%Amleine`Q and watch the performance.");
		output("Seth plays flawlessly, in fact, you can't remember him ever performing so well before.");
		output("`n`nHe finishes the performance to a vivid round of applause and comes over to shake your hand.");
		output("`n`n`4'This is the most amazing `&%s`4 I have ever played.",$musicitem[get_module_pref("choice")]);
		output("Thank you for letting me use your instrument.'");
		if ($choice==6){
			output("`Q He hands back your lute and smiles as he walks away.`n`n");
			output("`%'He's never given such a wonderful compliment to anyone before.");
			output("He really must like that lute.'`n`n");
			output("`%Amleine's`Q words uplift you, and you decide it's time to show that `@Green Dragon`Q who's in charge.");
			output("`n`nYou collect the `^gold`Q from the audience and find that you've made `^2000 gold`Q!!`n`n");
			output("`%Amleine`Q hugs you, congratulates you, and gives you a `b`%L`4ute `%C`4raftwork `%C`4ertificate `%o`4f `%M`4astery`Q`b.`n`n");
			output("`c`b`\$C`^o`@n`#g`!r`%a`\$t`^u`@l`#a`!t`%i`\$o`^n`@s`#!`b`c");
			apply_buff('lutemaker',array(
				"name"=>"`!Lute Maker Power",
				"rounds"=>5,
				"wearoff"=>"`!The sounds of the Lute fade.",
				"atkmod"=>2,
				"roundmsg"=>"You hit with more power than ever imagined.",
			));
			$session['user']['gold']+=2000;
			set_module_pref("mlute",2);
			addnews("%s`% demonstrated mastery in `&Making Lutes`%!!",$session['user']['name']);
			debuglog("received a buff and 2000 gold for mastering lute making.");
		}
		if ($choice==7){
			output("`QHe offers to buy the instrument from you.`n`n");
			output("Since you don't have much use for a fiddle, you sell it to Seth for `^500 gold`Q and `%5 gems`Q.`n`n");
			output("`%Amleine`Q hugs you, congratulates you, and gives you a `b`%F`4iddle `%C`4raftwork `%C`4ertificate `%o`4f `%M`4astery`Q`b.`n`n");
			output("`c`b`\$C`^o`@n`#g`!r`%a`\$t`^u`@l`#a`!t`%i`\$o`^n`@s`#!`b`c");
			$session['user']['gold']+=500;
			$session['user']['gems']+=5;
			set_module_pref("mfiddle",2);
			addnews("%s`% demonstrated mastery in `&Making Fiddles`%!!",$session['user']['name']);
			debuglog("received 500 gold and 5 gems for mastering fiddle making.");
		}
		if ($choice==8){
			output("`Q He hands back your `@bagpipes`Q and hands you a bottle from his sac.");
			output("`n`n`4'This is a wonderful augmentation potion.");
			output("You're bagpipes have made me remember how much I appreciate a good instrument.");
			output("And I give you this potion to show that I don't forget quality.'");
			output("`n`n`QYou toast to his health and down the magic potion.");
			if (get_module_setting("permhp")==1) {
				output("Suddenly, your `\$hitpoints increase`Q and your `\$maximum hitpoints improve by 4`Q.`n`n");
				$session['user']['maxhitpoints']+=4;
				debuglog("received 4 permanent hitpoints and a temporary hitpoint boost for mastering fiddle making.");
			}else{
				output("Suddenly, your `\$hitpoints increase`Q.`n`n");
				debuglog("received a temporary hitpoint boost for mastering fiddle making.");
			}
			output("`%Amleine`Q hugs you, congratulates you, and gives you a `b`%B`4agpipe `%C`4raftwork `%C`4ertificate `%o`4f `%M`4astery`Q`b.`n`n");
			output("`c`b`\$C`^o`@n`#g`!r`%a`\$t`^u`@l`#a`!t`%i`\$o`^n`@s`#!`b`c");
			if ($session['user']['hitpoints']<($session['user']['maxhitpoints']+150)) {
				$session['user']['hitpoints']= $session['user']['maxhitpoints']+150;
			}else{
				$session['user']['hitpoints']+=100;
			}
			set_module_pref("mbagpipes",2);
			addnews("%s`% demonstrated mastery in `&Making Bagpipes`%!!",$session['user']['name']);
		}
		if ($choice==9){
			output("`QYou bask in the compliment and draw inner strength.");
			output("`n`nYou gain `&5 Attack Points`Q!!");
			output("`%Amleine`Q hugs you, congratulates you, and gives you a `b`%F`4lute `%C`4raftwork `%C`4ertificate `%o`4f `%M`4astery`Q`b.`n`n");
			output("`c`b`\$C`^o`@n`#g`!r`%a`\$t`^u`@l`#a`!t`%i`\$o`^n`@s`#!`b`c");
			$session['user']['attack']+=5;
			set_module_pref("mflute",2);
			addnews("%s`% demonstrated mastery in `&Making Flutes`%!!",$session['user']['name']);
			debuglog("received 5 attack points for mastering flute making.");
		}
		if ($choice==10){
			output("`QYou bask in the compliment and draw inner strength.");
			output("`n`nYou gain `&5 Defense Points`Q!!");
			output("`%Amleine`Q hugs you, congratulates you, and gives you a `b`%K`4ettledrum `%C`4raftwork `%C`4ertificate `%o`4f `%M`4astery`Q`b.`n`n");
			output("`c`b`\$C`^o`@n`#g`!r`%a`\$t`^u`@l`#a`!t`%i`\$o`^n`@s`#!`b`c");
			$session['user']['defense']+=5;
			set_module_pref("mkettledrums",2);
			addnews("%s`% demonstrated mastery in `&Making Kettledrums`%!!",$session['user']['name']);
			debuglog("received 5 defense points for mastering kettledrum making.");
		}
	}elseif ($choice>10){
		output("`QYou meet `%Amleine`Q in the village square.");
		output("To your surprise, you see");
		if ($choice==11) output("the local festival musicians gathered around fresh copies of your `@F`2estival `^M`6usic`Q.");
		if ($choice==12) output("the official court musicians formally gathered around fresh copies of your `%M`5adrigal `%M`5usic`Q.");
		if ($choice==13) output("several professional musicians preparing to play your `)Dirge `Q in a memorial ceremony for the warriors that died to establish the kingdom.");
		if ($choice==14) output("a professional orchestra gathered together to play your `3Symphony`Q.");
		if ($choice==15) output("a select quartet of the highest quality musicians ready to play your `\$S`4onata`Q.");
		output("`n`nYou sit in the audience next to `%Amleine`Q and listen to your composition.`n`n");
		if ($choice==11){
			output("Soon everyone in the square is dancing happily to your song.");
			output("It's some of the best festival music that has been played in quite a long time.");
			output("Each dancer comes by and leaves `^some gold`Q and `%a gem`Q at your feet.");
			output("`n`n  At the end of your composition, you find you've made `^2200 gold`Q and `%12 gems`Q!`n`n");
			output("`%Amleine`Q hugs you, congratulates you, and gives you a `b`%F`4estival `%M`4usic `%C`4omposition `%C`4ertificate `%o`4f `%M`4astery`Q`b.`n`n");
			output("`c`b`\$C`^o`@n`#g`!r`%a`\$t`^u`@l`#a`!t`%i`\$o`^n`@s`#!`b`c");
			$session['user']['gold']+=2200;
			$session['user']['gems']+=12;
			set_module_pref("festival",2);
			addnews("%s`% demonstrated mastery in `&Festival Music Composition`%!!",$session['user']['name']);
			debuglog("received 2200 gold and 22 gems for mastering festival music composition.");
		}
		if ($choice==12){
			output("Soon enough, the `&King`Q has come to enjoy your music.");
			output("It's the highest honor you can imagine!`n`n");
			output("Pride spreads through you and you feel much stronger because of it!");
			output("In fact, it's almost as if the musical notes will fight for you!`n`n");
			output("`%Amleine`Q hugs you, congratulates you, and gives you a `b`%M`4adrigal `%M`4usic `%C`4omposition `%C`4ertificate `%o`4f `%M`4astery`Q`b.`n`n");
			output("`c`b`\$C`^o`@n`#g`!r`%a`\$t`^u`@l`#a`!t`%i`\$o`^n`@s`#!`b`c");
			$dkb = round($session['user']['dragonkills']*.1);
			apply_buff('musicalnotes', array(
				"startmsg"=>"`n`%The notes from the M`4adrigal `%M`4sic`% help you!",
				"name"=>"`%Music Power",
				"rounds"=>5,
				"wearoff"=>"The music fades.",
				"minioncount"=>5,
				"minbadguydamage"=>0,
				"maxbadguydamage"=>3+$dkb,
				"effectmsg"=>"`%The note cuts like a knife for `\${damage}`) damage.",
				"effectnodmgmsg"=>"`%It isn't affected by this note.",
				"effectfailmsg"=>"`%It doesn't hear this note.",
			));
			set_module_pref("madrigal",2);
			addnews("%s`% demonstrated mastery in `&Madrigal Music Composition`%!!",$session['user']['name']);
			debuglog("received a buff for mastering festival music composition.");
		}
		if ($choice==13){
			output("After the ceremony has finished, a lonely old widow dressed all in black comes to thank you for the music.");
			output("`n`n`)'It reminds me so much of the bravery and strength that my husband demonstrated when he died helping make this kingdom the great place that it is.");
			output("I want to give you a gift from our household as a thank you.'`n`n");
			output("`QYou collect `^1000 Gold `Qand `%5 Gems`Q from the old lady.");
			output("However, as you touch the treasure, one of the `\$g`^e`@m`#s `Qexudes a wonderful power and you gain `\$50 temporary hitpoints`Q!`n`n");
			output("`%Amleine`Q hugs you, congratulates you, and gives you a `b`%D`4irge `%C`4omposition `%C`4ertificate `%o`4f `%M`4astery`Q`b.`n`n");
			output("`c`b`\$C`^o`@n`#g`!r`%a`\$t`^u`@l`#a`!t`%i`\$o`^n`@s`#!`b`c");
			$session['user']['gold']+=1000;
			$session['user']['gems']+=5;
			$session['user']['hitpoints']+=50;
			set_module_pref("dirges",2);
			addnews("%s`% demonstrated mastery in `&Dirge Music Composition`%!!",$session['user']['name']);
			debuglog("received 1000 gold, 5 gems, and 50 hitpoints for mastering dirge music composition.");
		}
		if ($choice==14){
			output("The audience goes completely silent and not even a cough is heard.");
			output("It's a complete success!");
			output("`n`nThe conductor brings you on stage to take a bow and you bask in your success.`n`n");
			output("`%Amleine`Q brings you some magical flowers.");
			output("`n`nYou `&Gain 1 Attack`Q, `&1 Defense`Q, `\$1 Permanent Hitpoint`Q, `&1 charm, `^1000 Gold`Q and `%10 Gems`Q!!`n`n");	
			output("`%Amleine`Q hugs you, congratulates you, and gives you a `b`%S`4ymphony `%C`4ertificate `%o`4f `%M`4astery`Q`b.`n`n");
			output("`c`b`\$C`^o`@n`#g`!r`%a`\$t`^u`@l`#a`!t`%i`\$o`^n`@s`#!`b`c");
			$session['user']['gold']+=1000;
			$session['user']['gems']+=10;
			$session['user']['charm']++;
			$session['user']['maxhitpoints']++;
			$session['user']['defense']++;
			$session['user']['attack']++;
			set_module_pref("symphonies",2);
			addnews("%s`% demonstrated mastery in `&Symphony Music Composition`%!!",$session['user']['name']);
			debuglog("received 1000 Gold, 10 gems, 1 permanent hitpoint, 1 charm, 1 defense, and 1 attack for mastering symphony music composition.");
		}
		if ($choice==15){
			output("The music soars and your heart beats with the rhythm.");
			output("The people love your music and `%Amleine`Q smiles at your amazing success.`n`n");
			output("A small child walks up to you and hands you her teddy bear.");
			output("`n`n`^'I love your song so much, I want to give you this bear.'");
			output("`n`n`QShe walks away with a smile and you stare at the bear.");
			output("An old man in the audience jumps up yelling `@'That's my Bobo! That's my Bobo!'`Q");
			output("His friendly assistant looks at you and offers you `^10,000 gold `Q for the bear.");
			output("You happily accept and watch the old man cradle the teddy bear.");
			output("`n`n`#'Okay,'`Q you think, `#'That was kinda weird.'`Q`n`n");
			output("`%Amleine`Q hugs you, congratulates you, and gives you a `b`%S`4onata `%C`4ertificate `%o`4f `%M`4astery`Q`b.`n`n");
			output("`c`b`\$C`^o`@n`#g`!r`%a`\$t`^u`@l`#a`!t`%i`\$o`^n`@s`#!`b`c");
			$session['user']['gold']+=10000;				
			set_module_pref("sonatas",2);
			addnews("%s`% demonstrated mastery in `&Sonata Music Composition`%!!",$session['user']['name']);
			debuglog("received for mastering sonata music composition.");
		}
	}
	musicshop_mastercount();
}
page_footer();
?>