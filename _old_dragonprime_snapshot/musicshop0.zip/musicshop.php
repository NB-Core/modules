<?php
/*
Module Name:  musicshop.php
Category:  Village
Worktitle:  Amleine's musicshop
Author:  DaveS
Date: October 5, 2005
Credits:
Thanks to Melanie for the idea!

Description:
Players can become musicians! Get the title Maestro!
Learn to Play, compose, or make instruments (15 different disciplines).  
The module was designed for significant replay value, with lots of little things changing as players progress.
Requires a player to visit the shop every level for at least 12 levels and then return at level 15 for an award, only
one discipline can be attempted per dk (so they have to at least do this for 15 dks to see all the awards).
If they miss too many, they can't complete the discipline.  Each award is specific to the area of study.
Optional setting to give a list of completed disciplines in the bio. Once all 15 are completed, they get additional
mention in the bio of their success.

Goal:
1.  If using cities, place in a low-traffic city to increase activity
2.  Replay value of the game; keep people interested in exploring new aspects of the module
3.  Use up gold.  Lessons cost a setting amount per level.  Too much gold in the game? make them pay a lot for lessons.

v1.15 typos fixed!
v1.16 It was a PENGUIN... not a duck.  bah.  darn it.
v1.17 grammar fixes
v3.0 added vertxtloc
v3.01 changed folder to musicshop instead of lib
v3.02 corrected lute/flute making mistakes (thanks NikSolo)
v3.11 Tweaked music book, improved translation readiness, randomized quiz questions
v3.12 Halfling answer fixed, Gold pay for listening to story fixed
v3.13 missing %s call, thanks Eth!
v3.14 missing %s call, thanks Scooter2!
v3.15 missing %s call, thanks Eph!
v3.16 arieswind's hof and fixes.
*/
function musicshop_getmoduleinfo(){
	$info = array(
		"name"=>"Amleine's Music Shop",
		"version"=>"3.16",
		"author"=>"DaveS, HoF by Arieswind",
		"category"=>"Village",
		"download"=>"http://dragonprime.net/index.php?module=Downloads;sa=dlview;id=181",
		"vertxtloc"=>"",
		"settings"=>array(
			"Amleine's Music Shop Settings,title",
			"musicshoploc"=>"Where does the Music Shop appear,location|".getsetting("villagename", LOCATION_FIELDS),
			"goldlevel"=>"Price per lesson times their level:,int|100",
			"musicbookbio"=>"Show list of disciplines completed in Music Book under Bio?,bool|1",
			"musicbio"=>"Show title for completing a full set of disciplines in Bio?,bool|1",
			"permhp"=>"Allow permanent hitpoints to be given as an award?,bool|1",
			"hof"=>"Show HoF?,bool|0",
			"pp"=>"Number of players to show per page on the HoF?,int|25",
		),
		"prefs"=>array(
			"Amleine's Music Shop Preferences,title",
			"firstmusic"=>"Have they had a first visit to the shop this dk?,bool|0",	
			"musicvisit"=>"How many times have they practiced this dk?,int|0",
			"award"=>"Have they received their reward for mastery of this discipline?,bool|0",
			"amleine"=>"Have they heard Amleine's story?,bool|0",
			"animal"=>"Which animal was Amleine's pet?,enum,1,Penguin,2,Dog,3,Cat,4,Frog,5,Platypus,6,Hummingbird,7,Duck,8,Scorpion,9,Monkey,10,Horse|1",
			"bellstory"=>"Have they heard the story of the bell?,bool|0",
			"race"=>"What race is Amleine afraid of?,enum,1,Dwarves,2,Imps,3,Dark Elves,4,Felynes,5,Drow,6,Trolls,7,Humans,8,Storm Giants,9,Halflings,10,Gnomes|1",
			"Areas of Study,title",
			"choice"=>"What number discipline are they currently studying?,int|0",
			"nummastered"=>"How many areas have they mastered?,int|0",
			"masterful"=>"How many times have they mastered ALL disciplines?,int|0",
			"masterhof"=>"times mastered all*15 + number mastered?,int|0",
			"plute"=>"1 Play the Lute?,enum,0,Never,1,Learning,2,Mastered",
			"pfiddle"=>"2 Play the Fiddle?,enum,0,Never,1,Learning,2,Mastered",
			"pbagpipes"=>"3 Play Bagpipes?,enum,0,Never,1,Learning,2,Mastered",
			"pflute"=>"4 Play the Flute?,enum,0,Never,1,Learning,2,Mastered",
			"pkettledrums"=>"5 Play Kettledrums?,enum,0,Never,1,Learning,2,Mastered",
			"mlute"=>"6 Make Lutes?,enum,0,Never,1,Learning,2,Mastered",
			"mfiddle"=>"7 Make Fiddles?,enum,0,Never,1,Learning,2,Mastered",
			"mbagpipes"=>"8 Make Bagpipes?,enum,0,Never,1,Learning,2,Mastered",
			"mflute"=>"9 Make Flutes?,enum,0,Never,1,Learning,2,Mastered",
			"mkettledrums"=>"10 Make Kettledrums?,enum,0,Never,1,Learning,2,Mastered",
			"festival"=>"11 Compose Festival Music?,enum,0,Never,1,Learning,2,Mastered",
			"madrigal"=>"12 Compose Madrigal Music?,enum,0,Never,1,Learning,2,Mastered",
			"dirges"=>"13 Compose Dirge Music?,enum,0,Never,1,Learning,2,Mastered",
			"symphonies"=>"14 Compose Symphonies?,enum,0,Never,1,Learning,2,Mastered",
			"sonatas"=>"15 Compose Sonatas?,enum,0,Never,1,Learning,2,Mastered",
			"Practice Sessions For Each Level,title",
			"level1"=>"Practiced at level 1?,bool|0",
			"level2"=>"Practiced at level 2?,bool|0",
			"level3"=>"Practiced at level 3?,bool|0",
			"level4"=>"Practiced at level 4?,bool|0",
			"level5"=>"Practiced at level 5?,bool|0",
			"level6"=>"Practiced at level 6?,bool|0",
			"level7"=>"Practiced at level 7?,bool|0",
			"level8"=>"Practiced at level 8?,bool|0",
			"level9"=>"Practiced at level 9?,bool|0",
			"level10"=>"Practiced at level 10?,bool|0",
			"level11"=>"Practiced at level 11?,bool|0",
			"level12"=>"Practiced at level 12?,bool|0",
			"level13"=>"Practiced at level 13?,bool|0",
			"level14"=>"Practiced at level 14?,bool|0",
			"level15"=>"Practiced at level 15?,bool|0",				
		)
    );
    return $info;
}

function musicshop_install(){
    module_addhook("changesetting");
    module_addhook("village");
    module_addhook("newday");
	module_addhook("newday-runonce");
	module_addhook("dragonkill");
	module_addhook("footer-prefs");
	module_addhook("footer-hof");
	module_addhook("bioinfo");
	if (is_module_active("alignment")) module_addhook("alignment");
   return true;
}

function musicshop_uninstall(){
    return true;
}
function musicshop_dohook($hookname,$args){
	global $session;
	global $session, $REQUEST_URI;
	$userid = $session[user][acctid];
	$argsid = $args[acctid];
	$argsname = $args[login];
	switch ($hookname) {
		case "footer-hof":
			if (get_module_setting("hof")==1){
				addnav("Warrior Rankings");
				addnav("Talented Musicians","runmodule.php?module=musicshop&op=hof");
			}
		break;
	case "changesetting":
		if ($args['setting'] == "villagename") {
			if ($args['old'] == get_module_setting("musicshoploc")) {
				set_module_setting("musicshoploc", $args['new']);
			}
		}
	break;
	case "village":
		if ($session['user']['location'] == get_module_setting("musicshoploc")) {
			tlschema($args['schemas']['marketnav']);
			addnav($args['marketnav']);
			tlschema();
			addnav("Amleine's Music Shop","runmodule.php?module=musicshop&op=music");
		}
	break;
	case "newday":
	break;
	case "dragonkill":
		set_module_pref("amleine",0);
		set_module_pref("bellstory",0);
		set_module_pref("musicvisit",0);
		set_module_pref("award",0);
		set_module_pref("master",0);
		set_module_pref("firstmusic",0);
		set_module_pref("choice",0);
		set_module_pref("level1",0);
		set_module_pref("level2",0);
		set_module_pref("level3",0);
		set_module_pref("level4",0);
		set_module_pref("level5",0);
		set_module_pref("level6",0);
		set_module_pref("level7",0);
		set_module_pref("level8",0);
		set_module_pref("level9",0);
		set_module_pref("level10",0);
		set_module_pref("level11",0);
		set_module_pref("level12",0);
		set_module_pref("level13",0);
		set_module_pref("level14",0);
		set_module_pref("level15",0);
		if (get_module_pref("nummastered")>=15){
			addnews("%s`% has mastered every discipline in `%Amleine's `%M`4usic `%S`4hop`%!!",$session['user']['name']);
			increment_module_pref("masterful",1);
			set_module_pref("nummastered",0);
			set_module_pref("plute",0);
			set_module_pref("pfiddle",0);
			set_module_pref("pbagpipes",0);
			set_module_pref("pflute",0);
			set_module_pref("pkettledrums",0);
			set_module_pref("mlute",0);
			set_module_pref("mfiddle",0);
			set_module_pref("mbagpipes",0);
			set_module_pref("mflute",0);
			set_module_pref("mkettledrums",0);
			set_module_pref("festival",0);
			set_module_pref("madrigal",0);
			set_module_pref("dirges",0);
			set_module_pref("symphonies",0);
			set_module_pref("sonatas",0);
		}
		if (get_module_pref("plute")==1) set_module_pref("plute",0);		
		if (get_module_pref("pfiddle")==1) set_module_pref("pfiddle",0);		
		if (get_module_pref("pbagpipes")==1) set_module_pref("pbagpipes",0);		
		if (get_module_pref("pflute")==1) set_module_pref("pflute",0);		
		if (get_module_pref("pkettledrums")==1) set_module_pref("pkettledrums",0);		
		if (get_module_pref("mlute")==1) set_module_pref("mlute",0);		
		if (get_module_pref("mfiddle")==1) set_module_pref("mfiddle",0);		
		if (get_module_pref("mbagpipes")==1) set_module_pref("mbagpipes",0);		
		if (get_module_pref("mflute")==1) set_module_pref("mflute",0);		
		if (get_module_pref("mkettledrums")==1) set_module_pref("mkettledrums",0);		
		if (get_module_pref("festival")==1) set_module_pref("festival",0);		
		if (get_module_pref("madrigal")==1) set_module_pref("madrigal",0);		
		if (get_module_pref("dirges")==1) set_module_pref("dirges",0);		
		if (get_module_pref("symphonies")==1) set_module_pref("symphonies",0);		
		if (get_module_pref("sonatas")==1) set_module_pref("sonatas",0);
	break;
	case "bioinfo":
	if (get_module_setting("musicbookbio")==1){	
	if (((int)get_module_pref("nummastered","musicshop",$args[acctid])>=1)||(get_module_pref("masterful","musicshop",$args[acctid])>=1)) 
		addnav("Musicbook", "runmodule.php?module=musicshop&op=musicbook&user=$argsid&username=$argsname&return=".URLencode($_SERVER['REQUEST_URI']));
	}
	if (get_module_setting("musicbio")==1){
		if (get_module_pref("masterful","musicshop",$args[acctid])>0) output("`^Musical Achievement Title: ");
		if (get_module_pref("masterful","musicshop",$args[acctid])>9) output("`5`bThe Ultimate Supreme Grandmaster of Music`b");
		if (get_module_pref("masterful","musicshop",$args[acctid])==9) output("`6Third Level Supreme Grandmaster of Music");
		if (get_module_pref("masterful","musicshop",$args[acctid])==8) output("`QSecond Level Supreme Grandmaster of Music");
		if (get_module_pref("masterful","musicshop",$args[acctid])==7) output("`&First Level Supreme Grandmaster of Music");
		if (get_module_pref("masterful","musicshop",$args[acctid])==6) output("`\$Third Level Grandmaster of Music");
		if (get_module_pref("masterful","musicshop",$args[acctid])==5) output("`%Second Level Grandmaster of Music");
		if (get_module_pref("masterful","musicshop",$args[acctid])==4) output("`!First Level Grandmaster of Music");
		if (get_module_pref("masterful","musicshop",$args[acctid])==3) output("`#Third Level Master of Music");
		if (get_module_pref("masterful","musicshop",$args[acctid])==2) output("`@Second Level Master of Music");
		if (get_module_pref("masterful","musicshop",$args[acctid])==1) output("`^First Level Master of Music");
		if (get_module_pref("masterful","musicshop",$args[acctid])>0) output_notl("`n");
	}
	break;	
	}
	return $args;
}
function musicshop_run(){
	global $SCRIPT_NAME;
	if ($SCRIPT_NAME == "runmodule.php"){
		$module=httpget("module");
		if ($module == "musicshop"){
			require_once("modules/musicshop/musicshop_func.php");
			include("modules/musicshop/musicshop.php");
		}
	}
}
?>
