<?php

function templatemap_getmoduleinfo(){
	$info = array(
		"name"=>"template Map",
		"version"=>"20050404",
		"author"=>"sixf00t4",
		"category"=>"Maps",
		"download"=>"http://dragonprime.net/users/sixf00t4/cartographer.zip",
		"vertxtloc"=>"http://dragonprime.net/users/sixf00t4/",        
		"settings"=>array(
			"template Map Settings,title",
            "gemcost"=>"Cost in gems for map,int|2",
			"goldcost"=>"Cost in gold for map?,int|3000",
			"dksneeded"=>"Number of DKs needed to buy a map?,int|0",
            ),
        "prefs"=>array(
			"Map Preferences,title",
			"hasmap"=>"Has a map to TEMPLATEPLACE?,bool|0",
        ),
		"requires"=>array(
			"cartographer" => "20050318|Sixf00t4, http://dragonprime.net/users/sixf00t4/cartographer.zip",            
            ),
        );
	return $info;
}

function templatemap_install(){
	if (!is_module_active('templatemap')){
		output("`2Installing template map Module.`n");
	}
	module_addhook("village");
	module_addhook("maps-cartographer");
	return true;
}

function templatemap_uninstall(){
		output("`2Un-Installing template map Module.`n");
	return true;
}

function templatemap_dohook($hookname,$args){
global $session;

   	switch($hookname){
   		case "village":
            if (get_module_pref('hasmap','templatemap')==0) blocknav('runmodule.php?module=TEMPLATEFILE'); 
        break;
        
        case "maps-cartographer":
            if($session['user']['dragonkills'] >= (get_module_setting("dksneeded","templatemap"))){
            addnav("TEMPLATEPLACE","runmodule.php?module=templatemap");
            }
        break;
    
    }
return $args;
}

function templatemap_run(){
global $session;
checkday();
page_header("Cartographer");
$op=httpget('op');

$gemcost = get_module_setting("gemcost","templatemap");
$goldcost = get_module_setting("goldcost","templatemap");
$mapmaker = get_module_setting("cartographername","cartographer");

if ($op==""){
    if(get_module_pref("hasmap","templatemap")>0){
        output("%s The Cartographer goes in the back to get you the map to TEMPLATEPLACE.  While waiting, you pull out your map to TEMPLATEPLACE from your backpack.`n`n",$mapmaker);
        output("`&You think to yourself, `#\"Why am I getting another?\"");
    }else{
    output("%s shuffles around through some maps, knocks over a few globes, and eventually finds the map you need. After looking at it for a while, admiring the skill it took to create such an accurate cartography, he says he can let it go for %s gems and %s gold.",$mapmaker,$gemcost,$goldcost);
        addnav("I'll take it!","runmodule.php?module=templatemap&op=buy");
    }
    addnav("Back","runmodule.php?module=cartographer");   
}
else if ($op=="buy"){
    if(($session['user']['gems']<$gemcost) || ($session['user']['gold']<$goldcost)){
        output("After you empty your pockets on the table, %s draws you a detailed map to the bank.",$mapmaker);
    }else{
        output("%s rolls up the map to TEMPLATEPLACE, and puts it in a long canister and hesitantly hands it to you.`n  `#Here you go, now you should be able to find your way without delay!  Be sure to take care of this one, it is a rare map indeed.",$mapmaker);
        set_module_pref("hasmap",1,"templatemap");
        $session['user']['gems']-=$gemcost;
        $session['user']['gold']-=$goldcost;        
    }
    addnav("Back","runmodule.php?module=cartographer");
}
addnav("To the village","village.php");
page_footer();
}
?>