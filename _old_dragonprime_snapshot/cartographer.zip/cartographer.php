<?

function cartographer_getmoduleinfo(){
	$info = array(
		"name"=>"Cartographer",
		"version"=>"20050404",
		"author"=>"sixf00t4",
		"category"=>"Maps",
		"download"=>"http://dragonprime.net/users/sixf00t4/cartographer.zip",
		"vertxtloc"=>"http://dragonprime.net/users/sixf00t4/",
        "settings"=>array( 
        "cartographer Settings,title",
            "cartographername"=>"What is the name of the Cartographer?,text|Runering",
            "cartographerloc"=>"Where does the cartographer appear?,location|".getsetting("villagename", LOCATION_FIELDS),
        ),
    );
	return $info;
}

function cartographer_install(){
	if (!is_module_active('cartographer')){
		output("`2Installing cartographer Module.`n");
	}
	module_addhook("village");
	module_addhook("changesetting");
	return true;
}

function cartographer_uninstall(){
		output("`2Un-Installing cartographer Module.`n");
	return true;
}

function cartographer_dohook($hookname,$args){
	global $session;
    	switch($hookname){
		case "changesetting":
   			if ($args['setting'] == "villagename") {
    		if ($args['old'] == get_module_setting("cartographerloc")) {
       		set_module_setting("cartographerloc", $args['new']);
       }
    }
        break;
    	case "village":
            if ($session['user']['location'] == get_module_setting("cartographerloc","cartographer")){
                tlschema($args['schemas']['marketnav']);
                addnav($args['marketnav']);
                tlschema();
                addnav("Cartographer","runmodule.php?module=cartographer");
            }
        break;    
    }
return $args;
}
function cartographer_run(){

checkday();
page_header("Cartographer");

$mapmaker = get_module_setting("cartographername","cartographer");

if ($op==""){
output("%s `0sits at a desk strewn with maps, globes, rulers, compasses for measuring, and directional compasses, pencils, books, and even more maps.`n",$mapmaker);
addnav("Back to the Village","village.php");
addnav("Ask for a map to");
    modulehook ("maps-cartographer");    
}
page_footer();
}
?>