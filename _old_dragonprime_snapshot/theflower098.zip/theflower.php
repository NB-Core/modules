<?php
/* The Flower - 17April2005
   Author: Robert of Maddrio dot com
   converted from an 097 forest event
*/
function theflower_getmoduleinfo(){
	$info = array(
	"name"=>"the Flower",
	"version"=>"1.0",
	"author"=>"`2Robert",
	"category"=>"Forest Specials",
	"download"=>"http://dragonprime.net/users/robert/theflower098.zip",
	"settings"=>array(
	"The Flower Settings,title",
	"percentage"=>"Chance player gains or loses 1 charm,range,10,100,2|50"
	),
	);
	return $info;
}

function theflower_install(){
	module_addeventhook("forest","return 100;");
	return true;
}

function theflower_uninstall(){
	return true;
}

function theflower_dohook($hookname,$args){
	return $args;
}

function theflower_runevent($type){
	global $session;
	$chance = get_module_setting("percentage");
	$rand = e_rand(1,100);
	if ($rand <= $chance) {
	output("`n`n`2 You stumble upon a small patch of wild-flowers. `n`n");
	output(" Stopping for a moment, you admire the beauty of the flowers. `n`n");
	output(" Walking over to pick one for yourself, you find that you just stepped into dragon poo! `n`n");
	if ($session['user']['charm'] >=1 ) {
		output("`2 You feel a little less charming! ");
		$session['user']['charm']--;
		}
	}else{
	output("`n`n`2 You stumble upon a small patch of wild-flowers. `n`n");
	output(" Stopping for a moment, you admire the beauty of the flowers. `n`n");
	output(" Walking over to pick one for yourself and pin it upon your %s`2, `n`n you feel a little more charming!", $session['user']['armor']);
	$session['user']['charm']++;
	}
}

function theflower_run(){
}
?>