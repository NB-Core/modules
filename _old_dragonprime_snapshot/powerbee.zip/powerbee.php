<?php
// translator ready
// mail ready
// addnews ready
function powerbee_getmoduleinfo(){
	$info = array(
		"name"=>"Power Bee",
		"version"=>"2.1",
		"author"=>"Fliquid",
		"category"=>"Forest Specials",
		"download"=>"http://dragonprime.net/users/fliquid/powerbee.txt.txt",
		"settings"=>array(
			"Power Bee Event Settings,title",
			"minhitpoints"=>"Minimum hitpoints increase,range,1,5,1|1",
			"maxhitpoints"=>"Maximum hitpoints increase,range,1,5,1|5"
		),
	);
	return $info;
}

function powerbee_install(){
	module_addeventhook("forest", "return 25;");
	module_addeventhook("travel", "return 20;");
	return true;
}

function powerbee_uninstall(){
	return true;
}

function powerbee_dohook($hookname,$args){
	return $args;
}

function powerbee_runevent($type,$link)
{
	global $session;
	$min = $session['user']['level']*get_module_setting("minhitpoints");
	$max = $session['user']['level']*get_module_setting("maxhitpoints");
	$hitpoints = e_rand($min, $max);
	output("`4OUCH!");
	output("`n`n`^You have been stung by the `4Power `6Bee`^ your hitpoints increase by %s!`0", $hitpoints);
	output("`n`^They are very rare and very powerfull, it hurts like hell but makes you endurance go up.");
	$session['user']['hitpoints']+=$hitpoints;
	debuglog("your hitpoints increased by $hitpoints");
}

function powerbee_run(){
}
?>
