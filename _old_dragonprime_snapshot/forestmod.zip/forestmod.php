<?php
// mod for quick fights in the wood
//note that this is for Version Dragonprime 1.1.0
/*please visit dragonprime.net, I also share a German translation, the name there is Nightborn
fight log copied from battle.php
v1.01 fixed a battle that ocurred directly after a special event
v1.02 little scheme changes
*/

require_once("lib/forest.php");
require_once("lib/events.php");

	$fight = false;
    $battle = false;

function forestmod_getmoduleinfo(){
	$info = array(
		"name"=>"Forst Modification inspired by XChrisX",
		"version"=>"1.02",
		"author"=>"`2Oliver Brendel",
		"category"=>"Forest",
		"download"=>"http://dragonprime.net/dls/forestmod.zip",
	);
	return $info;
}

function forestmod_install(){
	module_addhook("forest");
	if (!is_module_active('forestmod')){
		debug("`4Installing Forest Enhancement Module.");
	}else{
		debug("`4Updating Forest Enhancement Module.");
	}
	return true;
}

function forestmod_uninstall(){
	debug("Uninstalling this module.");
	return true;
}

function forestmod_dohook($hookname,$args){
	global $session;
	switch($hookname){
		case "forest":
		    //extracted from healer.php
		    $loglev = log($session['user']['level']);
			$cost = ($loglev * ($session['user']['maxhitpoints']-$session['user']['hitpoints'])) + ($loglev*10);
		    $cost = round($cost,0);
			$result=modulehook("healmultiply",array("alterpct"=>1.0));
            $cost*=$result['alterpct'];
		    if (($session['user']['gold'] >= $cost && $session['user']['maxhitpoints']-$session['user']['hitpoints']>0) || $session['user']['turns']>0)
 			 {
			 	addnav("Actions");
		     	if ($session['user']['gold'] >= $cost && $session['user']['maxhitpoints']-$session['user']['hitpoints']>0)
			 	addnav(array("Complete Healing (%s gold)",$cost),"runmodule.php?module=forestmod&op=heal");
				if ($session['user']['turns']>0)
				{
					if ($session['user']['level']>1)
					addnav("Slumber (till the end)","runmodule.php?module=forestmod&op=fight&auto=full&type=slum");
					addnav("Seek out (till the end)","runmodule.php?module=forestmod&op=fight&auto=full");
					addnav("Thrillseeking (till the end)","runmodule.php?module=forestmod&op=fight&auto=full&type=thrill");
				}
			 }
			break;
	}
	return $args;
}

function forestmod_run() {
 	global $session;
 	$opt=httpget('op');
 	switch($opt) {
	    case "heal":	    //autohealing
	    //tynan is interfering
	    $loglev = log($session['user']['level']);
		$cost = ($loglev * ($session['user']['maxhitpoints']-$session['user']['hitpoints'])) + ($loglev*10);
	    $cost = round($cost,0);
	    $maxhit=$session['user']['maxhitpoints'] + round(get_module_pref("hitpoints","tynan"),0);
	    $session['user']['hitpoints'] =$maxhit;
	    $result=modulehook("healmultiply",array("alterpct"=>1.0));
	    $cost*=$result['alterpct'];
	    $session['user']['gold'] -=$cost;
	    page_header("Marco, the flying healer");
	    output("`^`c`bMarco, the flying healer`b`c");
	    output("`n`nNow you're fully healed, my %s.",translate_inline($session['user']['sex']?"Heroine":"Hero"));
	    forest(true);
	    break;

	    //the main quickfight, mainly just copied from the forest.php, sorry ! ! !
	    case "fight":
		    tlschema ("forest");
			page_header("The Forest");
			$dontdisplayforestmessage=handle_event("forest");
			checkday();
			if ($session['user']['turns']<=0){
				output("`\$`bYou are too tired to search the forest any longer today.  Perhaps tomorrow you will have more energy.`b`0");
				$op="";
				httpset('op', "");
			}else{
				modulehook("forestsearch", array());
				$args = array(
					'soberval'=>0.9,
					'sobermsg'=>"`&Faced with the prospect of death, you sober up a little.`n",
					'schema'=>'forest');
				modulehook("soberup", $args);
				$dontdisplayforestmessage=handle_event("forest");
				if (module_events("forest", getsetting("forestchance", 15), "forest.php?") != 0) {
					if (!checknavs()) {
						// If we're showing the forest, make sure to reset the special
						// and the specialmisc
						$session['user']['specialinc'] = "";
						$session['user']['specialmisc'] = "";
						$dontdisplayforestmessage=true;
						$op = "";
						httpset("op", "");
					} else {
						tlschema();
						page_footer();
					}
				}else{
					$session['user']['turns']--;
					$battle=true;
					if (e_rand(0,2)==1){
						$plev = (e_rand(1,5)==1?1:0);
						$nlev = (e_rand(1,3)==1?1:0);
					}else{
						$plev=0;
						$nlev=0;
					}
					$type = httpget('type');
					if ($type=="slum"){
						$nlev++;
						output("`\$You head for the section of forest you know to contain foes that you're a bit more comfortable with.`0`n");
					}
					if ($type=="thrill"){
						$plev++;
						output("`\$You head for the section of forest which contains creatures of your nightmares, hoping to find one of them injured.`0`n");
					}
					$extrabuff = 0;
					if ($type=="suicide"){
						if ($session['user']['level'] <= 7) {
							$plev += 1;
							$extrabuf = .25;
						} elseif ($session['user']['level'] < 14) {
							$plev+=2;
							$extrabuf = 0;
						} else {
							$plev++;
							$extrabuff = .4;
						}
						output("`\$You head for the section of forest which contains creatures of your nightmares, looking for the biggest and baddest ones there.`0`n");
					}

					$targetlevel = ($session['user']['level'] + $plev - $nlev );
					if ($targetlevel<1) $targetlevel=1;
					$sql = "SELECT * FROM " . db_prefix("creatures") . " WHERE creaturelevel = $targetlevel AND forest=1 ORDER BY rand(".e_rand().") LIMIT 1";
					$result = db_query($sql);
					restore_buff_fields();
					if (db_num_rows($result) == 0) {
						// There is nothing in the database to challenge you, let's
						// give you a doppleganger.
						$badguy = array();
						$badguy['creaturename']=
							"An evil doppleganger of ".$session['user']['name'];
						$badguy['creatureweapon']=$session['user']['weapon'];
						$badguy['creaturelevel']=$session['user']['level'];
						$badguy['creaturegold']=0;
						$badguy['creatureexp'] =
						round($session['user']['experience']/10, 0);
						$badguy['creaturehealth']=$session['user']['maxhitpoints'];
						$badguy['creatureattack']=$session['user']['attack'];
						$badguy['creaturedefense']=$session['user']['defense'];
					} else {
						$badguy = db_fetch_assoc($result);
						require_once("lib/forestoutcomes.php");
						$badguy = buffbadguy($badguy);
						// Okay, they are thrillseeking, let's give them a bit extra
						// exp and gold.
						if ($type == "thrill") {
							// 10% more experience
						$badguy['creatureexp'] =
								round($badguy['creatureexp']*1.1, 0);
							// 10% more gold
							$badguy['creaturegold'] =
								round($badguy['creaturegold']*1.1, 0);
						}
						if ($type == "suicide") {
							// Okay, suicide fights give even more rewards, but
							// are much harder
							// 25% more experience
							$badguy['creatureexp'] =
								round($badguy['creatureexp']*1.25, 0);
							// 25% more gold
							$badguy['creaturegold'] =
								round($badguy['creaturegold']*1.25, 0);
							// Now, make it tougher.
							$mul = 1.25 + $extrabuff;
							$badguy['creatureattack'] =
								round($badguy['creatureattack']*$mul, 0);
							$badguy['creaturedefense'] =
								round($badguy['creaturedefense']*$mul, 0);
							$badguy['creaturehealth'] =
								round($badguy['creaturehealth']*$mul, 0);
							// And mark it as an 'elite' troop.
							$prefixs = array(
									"Elite",
									"Dangerous",
									"Lethal",
									"Savage",
									"Deadly",
									"Malevolent",
									"Malignant");
							$prefixs = translate_inline($prefixs);
							$key = array_rand($prefixs);
							$prefix = $prefixs[$key];
							$badguy['creaturename'] =
								$prefix . " " . $badguy['creaturename'];
						}
					}
					calculate_buff_fields();
					$badguy['playerstarthp']=$session['user']['hitpoints'];
					$badguy['diddamage']=0;
					$badguy['type'] = 'forest';
					$session['user']['badguy']=createstring($badguy);
				}
			}
			if ($battle){
				require_once("battle.php");
				if ($victory)
				{
					require_once("lib/forestoutcomes.php");
					$op="";
					httpset('op', "");
					forestvictory($badguy);
					$battle=false;
					$dontdisplayforestmessage=true;
				}elseif($defeat)
					{
					require_once("lib/forestoutcomes.php");
					forestdefeat($badguy);
					$battle=false;
					}
			}
				$dontdisplayforestmessage=true;
			 	tlschema();
				forest(true);
	        break;
	}
	output_notl("`0");
	page_footer();
}

?>