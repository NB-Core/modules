<?php
/*
Meet Ero-Sennin in the woods...

you find him peeping at some bathing girls...

v1.01 minor fixes
v1.02 fix in the gain of attackpoints (forgot to add)


Ero Sennin - The Perverted Hermit",
  "author"=>"Oliver Brendel",
  "version"=>"1.02",
  "category"=>"Forest Specials",
   "Ero Sennin - Preferences, title",
   "Meet him and maybe the frog boss,note",
*/
$erosennin="`QEro-`!Sennin";//   "name"=>"Name (coloured) of Ero-Sennin,text|`QEro-`gSennin",
$charmmax=30; //   "charme"=>"Charm value for female players to get stalked,int|30",
$experienceloss = 10; //   "experienceloss"=>"Percentage: How many experience is lost/won after a fight,floatrange,1,100,1|10",
$username=$session['user']['name'];

	$link = "forest.php?";
	$specialbat = "erosennin097.php";
	$session[user][specialinc]=$specialbat;
	$op=$HTTP_GET_VARS[op];
	switch ($op)
	{
	case "":
		output("`3Du bummelst so eine ruhige Stra�e entlang... und nach einigen Minuten siehst Du ein kleines Badehaus in der N�he einer hei�en Quelle am Stra�enrand.");
		output(" Du entschlie�t Dich, ein bi�chen n�herzukommen... es liegt ja eh auf Deinem Weg.");
		$adj=($session['user']['sex']?"widerw�rtig":"interessant");
		output("`n`nOh! Das ist ja $adj... ein alter Mann sitzt an einem hohen Holzzaun und schaut durch ein Loch!");
		output("`n`nWas wirst Du tun?");
		addnav("Zur Ordnung rufen",$link."op=disturb");
		addnav("Zusammen reinschauen",$link."op=peek");
		addnav("Weggehen",$link."op=walk");
		break;
	case "peek":
		output("`3Du fragst leise ob Du mitschauen kannst... der alte Mann wird Deiner gewahr und schaut Dich an.`n`n");
		output("'`QShhh... such Dir Dein eigenes Loch! Ich sammle gerade wichtige Daten!`3'");
		if ($session['user']['sex'] && $charmmax<$session['user']['charm'])
			{
			output("`n`nEr schaut Dich `$ ganz`3 genau an... und f�ngt zu sabbern an.");
			output("'`QOh... was f�r reife Fr�chte zu mitgebracht hast...sind ja wirklich ordentliche Melonen...`3'");
			output(" Es macht Dich irgendwie krank, wie der alte Sack Dich angafft.");
			$gold=e_rand(0,$session['user']['gold']);
			output("`n`nDu l�ufst weg, und verlierst $gold Goldst�cke!");
			$session['user']['gold']-=$gold;
			$session['user']['specialinc'] = "";
			break;
			}
		output("In der Tat, Du findest ein h�bsches Loch zum Durchschauen.");						output(" Du schaust tiiief rein... und naja... was f�r sch�ne K�rper... rrrr...");
		output(" frische, jugendliche Damen... bereit, betrachtet zu werden...");
		$randomchance=e_rand(1,3);
		switch ($randomchance)
		{
			case "1":
				output("Du bist �berraschst... sch�ne K�rper... jung und knackig... Du f�hlst Dich `%vor Energie �bersch�umend`3!`n`n");
				$session['user']['charm']+=2;
			break;
			case "2":
				output("Du bist nicht zufriedengestellt... Du hast h�here Anspr�che.`n`n");
			break;
			case "3":
				output("Ach Du! Kleiner Dummi... Du hast Dich zu stark an den Zaun gelehnt!");
				output("Die Damen sind jetzt ein wenig sauer... und der alte Mann ist weg!");
				output("`n`n`$ Die Badem�dels verpr�geln Dich ziemlich �bel!`n`n");
				addnews("$username`^ wurde von halbnackten Damen wegen Spannens �bel verpr�gelt!");
				$session['user']['hitpoints']=e_rand(1,$session['user']['hitpoints']/2);
			break;

		}
		$gendercall=(!$session['user']['sex']?"boy":"cutie");
		if (e_rand(1,3)==1 && $randomchance<>3)
			{
			output("'`QHey, $gendercall, ich mag Deine Art. Ich werde Dir ein Geheimnis lehren... damit Du ein wenig Schlagkraft kriegst.`3'");
			output("`n`nUnd wie ist Dein Name?`3'... und dann dauert es einige Augenblicke...");
			output(" und er antwortet: '`QDanke f�rs Nachfragen! Ich bin der `!Gama-Sennin`Q aus den Myouboku Bergen!");
			output(" Du gr�belst �ber ihn nach... und stellst fest, da� Du schon vorher von ihm geh�rt hast: \'`@Du bist kein Gama-Sennin! Du bist der legend�re $erosennin`@!!!`3");
			output("`n`nNach einigen Momenten wilder Diskussion verl��t Du den Ort mit neuen Geheimnissen in Deinem Kopf.");
			output("`n`nDu `^erh�lst`3 `$ zwei `3 tempor�re Angriffspunkte! (verschwinden nach dem DK wieder)");
			$session['user']['attack']+=2;
			}
		$session['user']['specialinc'] = "";
		break;
	case "walk":
		output("`3Dir ist egal, da� der alte Sack spannt... Du setzt Deine Reise fort.`n`n");
		$session['user']['specialinc'] = "";
	break;
	case "disturb": //players who try to harm her have to fight against her protector ;) and they receive no mercy
		output("`3Du gehst auf ihn zu... er scheint sich aber f�r nichts anderes au�er Nacktheit zu interessieren...`n");
		output("Du meinst ziemlich laut:'`@Was machst Du da, alter Perversling? Voyeurismus und Spannen sind Verbrechen, wei�t Du?`3'");
		output(" Er scheint v�llig �berrumpelt zu sein und dreht sich um... er hat einen traurigen Ausdruck in seinen Augen... aber er scheint w�tend zu werden!`3`n`n");
		output("'`QBaka baka baka... Du hast die ganzen h�bschen M�dels vertrieben... Dir sollte man eine Lektion erteilen!`3'`n`n");
		output("`^Inu...Ii.. Tori... Saru... O-hitsuji... Ninpou Kuchiyose no Jutsu!`3`n`n");
		$selection=0;
		if ($session['user']['level']<5)
		 {
		 output("Ein kleiner Froschkrieger erscheint vor Dir... und greift sofort an.");
		 	$badguy = array(
			"creaturename"=>"kleiner Froschkrieger",
            "creaturelevel"=>$session['user']['level']+1,
            "creatureweapon"=>"Froschkuss",
			"creatureattack"=>$session['user']['level']+$session['user']['dragonkills']+1,
			"creaturedefense"=>$session['user']['defense'],
			"creaturehealth"=>($session['user']['level']*10+round(e_rand($session['user']['level'],($session['user']['maxhitpoints']-$session['user']['level']*10)))),
			"diddamage"=>0,);
		 } elseif ($session['user']['level']<10) {
			output("Ein kleiner Froschkrieger erscheint vor Dir... und greift sofort an.");
		 	$badguy = array(
			"creaturename"=>"gr�sserer Froschkrieger",
            "creaturelevel"=>$session['user']['level']+1,
            "creatureweapon"=>"Zwillingss�bel",
			"creatureattack"=>$session['user']['level']+$session['user']['dragonkills']+3,
			"creaturedefense"=>$session['user']['defense']+1,
			"creaturehealth"=>($session['user']['level']*10+round(e_rand($session['user']['level'],($session['user']['maxhitpoints']-$session['user']['level']*10)))),
			"diddamage"=>0,);
		 } else {
			output("Oh nein! Er hat den Froschboss gerufen! Es ist `^%s`3!");
				$badguy = array(
				"creaturename"=>"Gamabunta",
				"creaturelevel"=>$session['user']['level']+1,
				"creatureweapon"=>"Suiton Teppoudama",
				"creatureattack"=>$session['user']['level']+$session['user']['dragonkills']+5,
				"creaturedefense"=>$session['user']['level']+$session['user']['dragonkills'],
				"creaturehealth"=>($session['user']['level']*10+50+round(e_rand($session['user']['level']+50,($session['user']['maxhitpoints']-$session['user']['level']*10)))),
				"diddamage"=>0,);
				}
   	$battle=true;
	$session['user']['badguy'] = createstring($badguy);
	$op = "combat";
	case "combat": case "fight":
	include("battle.php");
	if ($victory){ //no exp at all for such a foul act
		output("`n`n`@...".$badguy['creaturename']."`^ stirbt durch Deine Hand. Du konntest �berleben... irgendwie...");
		addnews("$username`^ �berlebte eine Begegnung mit $erosennin`^.");
		$session['user']['specialinc'] = "";
		$exploss = $session['user']['experience']*$experienceloss/100;
		if ($exploss>0) output(" Du erh�lst `^$experienceloss Prozent`@ Erfahrung.");
		$session['user']['experience']+=$exploss;
		$badguy=array();
		$session['user']['badguy']="";
    }elseif ($defeat){ //but a loss of course if you die
		$exploss = $session['user']['experience']*$experienceloss/100;
		output("`n`n`@Du bist tot... ".$badguy['creaturename']."`@ hat Dich vernichtet.`@.`n");
		if ($exploss>0) output(" Du verlierst `^$experienceloss Prozent`@  Deiner Erfahrung und all Dein Gold.");
		$session['user']['experience']-=$exploss;
		$session['user']['gold']=0;
		debuglog("lost $exploss experience and all gold to Ero-Sennin.");
		addnews("$username`^ wurde get�tet von ".$badguy['creaturename']."`^ sent out by $erosennin`^.");
		addnav("Return");
		addnav("Zur�ck zu den Schatten","shades.php");
		$session['user']['specialinc'] = "";
		$badguy=array();
		$session['user']['badguy']="";
    }else{
		fightnav(true,false);
		if ($session['user']['superuser']) addnav("Zur�ck zum Dorf","village.php");
    }
 }



?>