<?php

function zeratul_getmoduleinfo(){
	$info = array(
		"name"=>"Zeratul's Hideout",
		"author"=>"Chris Vorndran",
		"version"=>"1.12",
		"category"=>"Village",
		"download"=>"http://dragonprime.net/index.php?module=Downloads;sa=dlview;id=36",
		"vertxtloc"=>"http://dragonprime.net/users/Sichae/",
		"description"=>"User will encounter Zeratul, a fugitive, in the forest and have a battle with him. If successful, they shall obtain a crystal. Upon finding crystals, a user can see his hideout and be able to trade crystals in for certain things.",
		"settings"=>array(
			"Zeratul's Augmentation Settings,title",
				"aug"=>"Are users allowed to augment their armor/weapon,bool|1",
				"auggold"=>"Gold Cost to Augment,int|5000",
				"auggems"=>"Gem Cost to Augment,int|10",
			"Zeratul's Creation Settings,title",
				"create"=>"Are users allowed to create equipment,bool|1",
				"cregold"=>"Gold Cost to Create,int|10000",
				"cregems"=>"Gem Cost to Create,int|50",
			"Zeratul's Stats,title",
				"atk"=>"Multiplier of attacker's attack to get Creature Attack,floatrange,0,2,.02|1.3",
				"def"=>"Multiplier of attacker's defense to get Creature Defense,floatrange,0,2,.02|1.3",
				"hp"=>"Multiplier of attacker's maxHP to get Creature Hitpoints,floatrange,0,2,.02|1.2",
				"weap"=>"Zeratul's Weapon's Name,text|Dark Archon Blade",
			"Zeratul's Location,title",
				"zeraloc"=>"Where is Zeratul's hideout located,location|".getsetting("villagename", LOCATION_FIELDS),
			),
		"prefs"=>array(
			"Zeratul's Equipment Augmentation,title",
				"augarm"=>"Has the user augmented their armor,bool|0",
				"augweap"=>"Has the user augmented their weapon,bool|0",
			"Zeratul's Equipment Creation,title",
				"weapon"=>"Did the user use their crystals for a Weapon,bool|0",
				"armor"=>"Did the user use their crystals for Armor,bool|0",
				"extra"=>"Did the user use their crystals for an Accessory,bool|0",
			"Zeratul's Crystal Holdings,title",
				"red"=>"Does this user have the Red Crystal,bool|0",
				"blue"=>"Does this user have the Blue Crystal,bool|0",
				"green"=>"Does this user have the Green Crystal,bool|0",
				"white"=>"Does this user have the White Crystal,bool|0",
				"black"=>"Does this user have the Black Crystal,bool|0",
		),
		);
	return $info;
}
function zeratul_install(){
	module_addhook("newday");
	module_addhook("village");
	module_addhook("changesetting");
	module_addhook("dragonkilltext");
	module_addeventhook("forest","return 100;");
	return true;
}
function zeratul_uninstall(){
	return true;
}
function zeratul_dohook($hookname,$args){
	global $session;
	switch ($hookname){
		case "village":
			if ($session['user']['location'] == get_module_setting("zeraloc")) {
				tlschema($args['schemas']['marketnav']);
				addnav($args['marketnav']);
				tlschema();
				if (get_module_pref("red")
					|| get_module_pref("blue")
					|| get_module_pref("green")
					|| get_module_pref("white")
					|| get_module_pref("black")) addnav("Zeratul's Hideout","runmodule.php?module=zeratul&op=enter");
			}
			break;
		case "changesetting":
			if ($args['setting'] == "villagename") {
			if ($args['old'] == get_module_setting("zeraloc")) {
			   set_module_setting("zeraloc", $args['new']);
		   }
		}
		break;
		case "dragonkilltext":
			if (get_module_pref("red")
				|| get_module_pref("blue")
				|| get_module_pref("green")
				|| get_module_pref("white")
				|| get_module_pref("black")){
				output("`n`)A large portal opens, and `i`@Zeratul`i`) marches through.");
				if (e_rand(1,10) < 7){
					output("He collects any of your remaining crystals");
					set_module_pref("red",0);
					set_module_pref("blue",0);
					set_module_pref("green",0);
					set_module_pref("black",0);
					set_module_pref("white",0);
				}
			}
			set_module_pref("augarm",0);
			set_module_pref("augweap",0);
			set_module_pref("weapon",0);
			set_module_pref("armor",0);
			set_module_pref("extra",0);
			break;
		case "newday":
			if (get_module_pref("extra") == 1){
				apply_buff("zeratul", array(
					"name"=>"`i`@Zeratul's`i`) Talisman`0",
					"atkmod"=>1.05,
					"defmod"=>1.05,
					"rounds"=>-1,
					"allowinpvp"=>1,
					"schema"=>"module-zeratul",
					)
				);
			}
			break;
		}
	return $args;
}
function zeratul_run(){
	global $session;
	$op = httpget('op');
	$op2 = httpget('op2');
	$crys = httpget('crys');
	$weap = httpget('weap');
	$arm = httpget('arm');
	$ext = httpget('ext');

	$auggold = get_module_setting("auggold");
	$auggems = get_module_setting("auggems");
	$cregold = get_module_setting("cregold");
	$cregems = get_module_setting("cregems");

	page_header("Zeratul's Hideout");
		switch ($op){
			case "enter":
				output("`)You wander into a small shoppe.");
				output("Upon the walls, are millions of boxes stacked to the ceiling.");
				output("A blinding blue light appears in the corner, and `i`@Zeratul `i`)walks out from it.");
				output("His green blade upon his wrist, glistening with the blood of a recent kill.");
				output("He walks up to you, and tilts his head to the side, checking behind your ears.");
				if (get_module_pref("red") == 1 || get_module_pref("blue") == 1 || get_module_pref("green") == 1 || get_module_pref("white") == 1 || get_module_pref("black") == 1){
					output(" \"`i`@So... I see that you have some of the crystals that I gave you in the woods.");
					output(" Would you care to use them now?`i`)\"");
					zeratul_navs();
				}else{
					output("`i`@Zeratul `i`)looks at you and shakes his head.");
					output(" \"`i`@You do not have any crystals...");
					output(" If you can best me in the woods, then I shall give you some of my fineries.`i`)\"");
				}
				break;
			case "full":
				output("`i`@Zeratul `i`)takes you by the arm, and whisks you off to the shoppe.");
				output(" \"`i`@You have already acquired all of my crystals... please spend them, or I shall not duel with you anymore.`i`)\"");
				zeratul_navs();
				break;
			case "aug":
				if ($session['user']['gold'] >= $auggold || $session['user']['gems'] >= $auggems){
				switch ($op2){
					case "armor":
						output("`i`@Zeratul `i`)grins as he looks upon you.");
						output(" He guides you into a small room, labeled \"Armor\".");
						output(" Smiling, he begins to speak, \"`i`@So, you wish to augment your armor...");
						output(" Well, I will have to use one of your crystals in order to use it.");
						output("If you are sure, then select a crystal to use.`i`)\"");
						addnav("Crystals");
						if (get_module_pref("red") == 1) addnav("Red Crystal","runmodule.php?module=zeratul&op=done&crys=red&arm=1");
						if (get_module_pref("blue") == 1) addnav("Blue Crystal","runmodule.php?module=zeratul&op=done&crys=blue&arm=1");
						if (get_module_pref("green") == 1) addnav("Green Crystal","runmodule.php?module=zeratul&op=done&crys=green&arm=1");
						if (get_module_pref("white") == 1) addnav("White Crystal","runmodule.php?module=zeratul&op=done&crys=white&arm=1");
						if (get_module_pref("black") == 1) addnav("Black Crystal","runmodule.php?module=zeratul&op=done&crys=black&arm=1");
						addnav("Return");
						addnav("Return to the Storefront","runmodule.php?module=zeratul&op=enter");
						break;
					case "weapon":
						output("`i`@Zeratul `i`)look at you, and tilts his head to the left.");
						output(" \"`i`@So, you have chosen to mar your precious weapon, in order to best those evil creatures of the forest?`i`)\"");
						output(" He grins evilly and rubs his hands together.");
						output("Nodding, he begins to speak once more.");
						output(" \"`i`@Which crystal do you wish to use, in order to augment your `i%s`i`@.`i`)\"",$session['user']['weapon']);
						addnav("Crystals");
						if (get_module_pref("red") == 1) addnav("Red Crystal","runmodule.php?module=zeratul&op=done&crys=red&weap=1");
						if (get_module_pref("blue") == 1) addnav("Blue Crystal","runmodule.php?module=zeratul&op=done&crys=blue&weap=1");
						if (get_module_pref("green") == 1) addnav("Green Crystal","runmodule.php?module=zeratul&op=done&crys=green&weap=1");
						if (get_module_pref("white") == 1) addnav("White Crystal","runmodule.php?module=zeratul&op=done&crys=white&weap=1");
						if (get_module_pref("black") == 1) addnav("Black Crystal","runmodule.php?module=zeratul&op=done&crys=black&weap=1");
						addnav("Return");
						addnav("Return to the Storefront","runmodule.php?module=zeratul&op=enter");
						break;
				}
				}else{
					output("`i`@Zeratul `i`)looks at you and frowns.");
					if ($session['user']['gold'] < $auggold) output("`n`n\"`i`@I am sorry... but you need `^%s `@more gold, until you can augment anything...`i`)\"",$auggold - $session['user']['gold']);
					if ($session['user']['gems'] < $auggems){
						output("`n`n\"`i`@I am terribly sorry... but you do not have enough gems to complete this augmentation.");
						output(" You need `%%s `@more.`i`)\"",$auggems - $session['user']['gems']);
					}
				}
				break;
			case "done":
				if ($weap){
					output("`i`@Zeratul `i`)takes your %s `)and brings it into his back room.",$session['user']['weapon']);
					output(" When he returns, a new sheen is left on your weapon.");
					output("`i`@Zeratul`i`) grins with satisfaction and hands it back to you.");
					output(" \"`i`@This, is a work of art.");
					output(" Please take good care of it...`i`)\"");
					$session['user']['attack']++;
					$session['user']['weapondmg']++;
					set_module_pref("augweap",1);
				}
				if ($arm){
					output("`i`@Zeratul`i`) spins about and tears off your %s`).",$session['user']['armor']);
					output(" Whilst you stand there naked, he whisks about, making alterations.");
					output(" He walks back to you, and slips your armor back onto you.");
					output(" With a satisfied nod, he takes your crystal from you.");
					$session['user']['defense']++;
					$session['user']['armordef']++;
					set_module_pref("augarm",1);
				}
				switch ($crys){
					case "red":
						set_module_pref("red",0);
						break;
					case "blue":
						set_module_pref("blue",0);
						break;
					case "green":
						set_module_pref("green",0);
						break;
					case "white":
						set_module_pref("white",0);
						break;
					case "black":
						set_module_pref("black",0);
						break;
					}
				break;
			case "finish":
				if ($weap){
					output("`i`@Zeratul `i`)gathers all of your crystals and walks into his back room.");
					output(" You can hear some low chanting and a dulcet drone.");
					output(" He returns several hours later, with a glowing blade.");
					output(" \"`i`@This is an `&Archon Warp Blade`@.");
					output(" The pride of the  Dark Templar's force.");
					output(" Thanks for proving yourself worthy of this blade...`i`)\"");
					output("`i`@Zeratul `i`)hands you the blade, and smiles.");
					output(" You give it a quick whirl around and then wander out the front door.");
					$atk = $session['user']['weapondmg'];
					$final = 17-$atk;
					$session['user']['weapon'] = "Archon Warp Blade";
					$session['user']['attack']+=$final;
					$session['user']['weapondmg']=17;
					set_module_pref("weapon",1);
				}
				if ($arm){
					output("`i`@Zeratul `i`)takes all of your crystals and walks over to his portal.");
					output(" He chants into the burning blue flames and punches his hand into it.");
					output(" He pulls his hand back, and has a long flowing cloak, clutched in his hand.");
					output(" \"`i`@This is the cloak of my kind.");
					output(" This is made of the highest strength cloth.");
					output(" Man nor beast is able to rend it from it's seams.");
					output(" You have proven yourself worthy of this... and I am glad.`i`)\"");
					output(" You take the cloak, and throw it around your shoulders, smiling at the weight... for there is none.");
					output(" You wander out from the shoppe, and see that it is disappearing around you.");
					$def = $session['user']['armordef'];
					$final = 17-$def;
					$session['user']['armor'] = "Dark Templar's Cloak";
					$session['user']['defense']+=$final;
					$session['user']['armordef']=17;
					set_module_pref("armor",1);
				}
				if ($ext){
					output("`i`@Zeratul`i`) grabs your crystals, and takes the small talisman.");
					output(" He casts them into the fiery pits of his portal.");
					output(" Hours later, a shimmering talisman is regurgitated back out.");
					output(" `i`@Zeratul `i`)strings a golden rope through it, and walks over to you.");
					output(" \"`i`@Well, this is a good piece...");
					output(" This is my own personal creation...");
					output(" It shall aid you in battle...");
					output(" The effects shall take place, starting tomorrow... for it needs to channel the powers of my realm.`i`)\"");
					output(" He sets the talisman around your neck and smiles.");
					output(" You take it into your hand, and begin to walk out.");
					set_module_pref("extra",1);
				}
				set_module_pref("red",0);
				set_module_pref("blue",0);
				set_module_pref("green",0);
				set_module_pref("white",0);
				set_module_pref("black",0);
				break;
			case "create":
				if ($session['user']['gold'] >= $cregold || $session['user']['gems'] >= $cregold){
				if (get_module_pref("red") == 1 && get_module_pref("blue") == 1 && get_module_pref("green") == 1 && get_module_pref("white") == 1 && get_module_pref("black") == 1){
				switch ($op2){
					case "armor":
						output("`i`@Zeratul `i`)looks at you and ponders.");
						output(" He looks upon your %s and asks, \"`i`@Are ye sure that ya wish to rid yourself of this terribly crafted armor?`i`)\"",$session['user']['armor']);
						output(" You nod, and then take a step forward.");
						output("`i`@Zeratul`i`) responds, \"`i`@Okay, this will cost ALL of your crystals... are you sure now?`i`)\"");
						addnav("Choices");
						addnav("Yes","runmodule.php?module=zeratul&op=finish&arm=1");
						break;
					case "weapon":
						output("`i`@Zeratul `i`)looks out the window.");
						output("\"`i`@Ya know... MightyE is losing business, because you are turning to me.");
						output(" Of course, that is better for me.`i`)\"");
						output(" He grins and clasps his hands together.");
						output("`i`@Zeratul`i`) responds, \"`i`@Okay, this will cost ALL of your crystals... are you sure now?`i`)\"");
						addnav("Choices");
						addnav("Yes","runmodule.php?module=zeratul&op=finish&weap=1");
						break;
					case "extra":
						output("`i`@Zeratul `i`) arches a brow.");
						output(" He walks to his shelf, and pulls down a small talisman.");
						output(" \"`i`@So, you wish to have something like this?`i`)\" he inquires.");
						output(" He awaits your decision.");
						output("`i`@Zeratul`i`) hurries up, \"`i`@Okay, this will cost ALL of your crystals... are you sure now?`i`)\"");
						addnav("Choices");
						addnav("Yes","runmodule.php?module=zeratul&op=finish&ext=1");
						break;
				}
				addnav("Choices");
				addnav("No","runmodule.php?module=zeratul&op=enter");
				}else{
					output("`i`@Zeratul`i`) shakes his head at you.");
					output(" He points to a sign.");
					output(" To create a piece of equipment, all of the crystals must be collected.");
					output(" He then points to the door, staring at the ground.");
				}
			}else{
				output("`i`@Zeratul `i`)looks at you and frowns.");
				if ($session['user']['gold'] < $cregold) output("`n`n\"`i`@I am sorry... but you need `^%s `@more gold, until you can create anything...`i`)\"",$cregold - $session['user']['gold']);
				if ($session['user']['gems'] < $cregems){
					output("`n`n\"`i`@I am terribly sorry... but you do not have enough gems to complete this creation.");
					output(" You need `%%s `@more.`i`)\"",$cregems - $session['user']['gems']);
				}
			}
			break;
		}
		addnav("Return");
		villagenav();
page_footer();
}
function zeratul_runevent($type){
	global $session;
	$op = httpget('op');

	$atk = get_module_setting("atk");
	$def = get_module_setting("def");
	$hp = get_module_setting("hp");

	$session['user']['specialinc'] = "module:zeratul";
		if ($op == "" || $op == "search"){
			if (get_module_pref("red") == 1 && get_module_pref("blue") == 1 && get_module_pref("green") == 1 && get_module_pref("white") == 1 && get_module_pref("black") == 1){
				$session['user']['specialinc'] = "";
				redirect("runmodule.php?module=zeratul&op=full");
			}
			$session['user']['specialinc'] = "module:zeratul";
			output("`)You wander into a small clearing and see a small portal.");
			output(" Out from the portal, a crippled hand extends towards you.");
			output(" A tall figure appears and takes a step towards you.");
			output(" He rolls up his cloak sleeve, and down comes a green blade.");
			output(" He speaks from underneath the hood, \"`i`@Why hath ye tread upon my woods?`i`)\"");
			output(" Utterly confused, you point to yourself, and he nods.");
			output(" \"`i`@The toll for trespassing, is death.`i`)\" he says with a maniacal laughter afterwards.");
			output(" \"`i`@Do you care to fight?`i`)\" he asks of you, eyeing your %s`0.",$session['user']['weapon']);
			addnav("Duel?");
			addnav("Yes","forest.php?op=yes");
			addnav("Decline","forest.php?op=no");
		}elseif ($op == "yes"){
			$session['user']['specialinc'] = "module:zeratul";
			output("`)The figure pulls back it's hood and grins, \"`i`@My name is Zeratul, and I am a Dark Templar.");
			output(" My kind has been hunted down, from realm to realm.");
			output(" My head carries a high fee... if you can best me in battle, I shall give you a precious gem.");
			output(" This gem will show you the path, to my hideout in the village of %s.",get_module_setting("zeraloc"));
			output(" Are you sure you wish to duel?`i`)\" he finishes and looks to his hand.");
			output(" He is holding 5 crystals.");
			output(" Each a different color.");
			addnav("Assurance");
			addnav("I'm Ready","forest.php?op=final");
			addnav("Not Today","forest.php?op=no");
		}elseif ($op == "final"){
			$session['user']['specialinc'] = "module:zeratul";
			output("`i`@Zeratul`i`) nods and then reveals his entire body.");
			output(" He is standing on the balls of his feet, a large blade extends to his side.");
			output(" `i`@Zeratul `i`)winks at you, \"`i`@Draw your weapon! We duel now!`i`)\"");
			$badguy = array(
				"creaturename"=>"Zeratul, the Dark Templar",
				"creatureweapon"=>get_module_setting("weap"),
				"creaturelevel"=>$session['user']['level']+1,
				"creatureattack"=>round($session['user']['attack']*$atk),
				"creaturedefense"=>round($session['user']['defense']*$def),
				"creaturehealth"=>round($session['user']['maxhitpoints']*$hp), 
				"diddamage"=>0);
			$session['user']['badguy'] = createstring($badguy);
			$op = "fight";
			httpset('op',$op);
		}elseif ($op == "no"){
			$session['user']['specialinc'] = "";
			output("`i`@Zeratul `i`)looks at you and nods.");
			output(" \"`i`@I understand %s`@.",$session['user']['name']);
			output(" Perhaps some other time then.`i`)\"");
			output(" He steps back into his portal, and disappears in a flash.");
			output("`n`n");
			output("\"`2How did he know my name...?`)\" you ask yourself, as you wander back into the woods.");
		}
		if ($op == "fight"){
			switch (e_rand(1,5)){
				case 1:
					rawoutput("<big>");
					output("`c`i`@Is that all you got?!`i`c");
					rawoutput("</big>");
					break;
				case 2:
					rawoutput("<big>");
					output("`c`i`@You can not beat me!`i`c");
					rawoutput("</big>");
					break;
				case 3:
					rawoutput("<big>");
					output("`c`i`@You are weak... why are you even trying?`i`c");
					rawoutput("</big>");
					break;
				case 4:
					rawoutput("<big>");
					output("`c`i`@That hurt... not!`i`c");
					rawoutput("</big>");
					break;
				case 5:
					rawoutput("<big>");
					output("`c`i`@Put some more muscle into it!`i`c");
					rawoutput("</big>");
					break;
				}		
			$battle = true;
		}
		if ($battle){
			include("battle.php");

			if ($victory){
				$session['user']['specialinc'] = "";
				$expgain = round($session['user']['experience']*.05);
				$session['user']['experience']+=$expgain;
				output("`n`c`b`)You gained `^%s `)experience from the battle.`b`c`n",$expgain);
				output("`i`@Zeratul `i`)looks at you and smiles.");
				output(" \"`i`@I am glad that ye have bested me...");
				output(" Here is what I promised you...`i`)\"");
				switch (e_rand(1,5)){
					case 1:
						if (get_module_pref("red") == 0){
							output("`n`n He reaches out and hands you a Red Crystal.");
							set_module_pref("red",1);
							output("`n`n`i`@Zeratul `i`)looks at you.");
							output(" \"`i`@I am proud of you.");
							output(" I did not think that you would be able to beat me... but you did.");
							output(" Please, take this crystal to my shoppe... and I will be able to make you something special.`i`)\"`0");
						}else{
							output("`n`n\"`i`@I am sorry... but I must depart.`i`)\"");
						}
					break;
					case 2:
						if (get_module_pref("blue") == 0){
							output("`n`n He reaches out and hands you a Blue Crystal.");
							set_module_pref("blue",1);
							output("`n`n`i`@Zeratul `i`)looks at you.");
							output(" \"`i`@I am proud of you.");
							output(" I did not think that you would be able to beat me... but you did.");
							output(" Please, take this crystal to my shoppe... and I will be able to make you something special.`i`)\"`0");
						}else{
							output("`n`n\"`i`@I am sorry... but I must depart.`i`)\"");
						}
					break;
					case 3:
						if (get_module_pref("green") == 0){
							output("`n`n He reaches out and hands you a Green Crystal.");
							set_module_pref("green",1);
							output("`n`n`i`@Zeratul `i`)looks at you.");
							output(" \"`i`@I am proud of you.");
							output(" I did not think that you would be able to beat me... but you did.");
							output(" Please, take this crystal to my shoppe... and I will be able to make you something special.`i`)\"`0");
						}else{
							output("`n`n\"`i`@I am sorry... but I must depart.`i`)\"");
						}
					break;
					case 4:
						if (get_module_pref("white") == 0){
							output("`n`n He reaches out and hands you a White Crystal.");
							set_module_pref("white",1);
							output("`n`n`i`@Zeratul `i`)looks at you.");
							output(" \"`i`@I am proud of you.");
							output(" I did not think that you would be able to beat me... but you did.");
							output(" Please, take this crystal to my shoppe... and I will be able to make you something special.`i`)\"`0");
						}else{
							output("`n`n\"`i`@I am sorry... but I must depart.`i`)\"");
						}
					break;
					case 5:
						if (get_module_pref("black") == 0){
							output("`n`n He reaches out and hands you a Black Crystal.");
							set_module_pref("black",1);
							output("`n`n`i`@Zeratul `i`)looks at you.");
							output(" \"`i`@I am proud of you.");
							output(" I did not think that you would be able to beat me... but you did.");
							output(" Please, take this crystal to my shoppe... and I will be able to make you something special.`i`)\"`0");
						}else{
							output("`n`n\"`i`@I am sorry... but I must depart.`i`)\"");
						}
					break;
				}
			}elseif($defeat){
				$session['user']['specialinc'] = "";
				$exploss = round($session['user']['experience']*.1);
				output("`c`n`n`)`bThe templar strikes down one final blow and knocks you out cold.");
				output(" You lose `^%s `)experience.`b`c`0",$exploss);
				$session['user']['experience']-=$exploss;
				$session['user']['alive'] = false;
				$session['user']['hitpoints'] = 0;
				debuglog("lost $exploss experience to Zeratul.");
				addnews("%s was destroyed by Zeratul in the Forest.",$session['user']['name']);
				addnav("Return");
				addnav("Return to the Shades","shades.php");
			}else{
				fightnav(true,true);
			}
		}
}
function zeratul_navs(){
	global $session;
		if (get_module_setting("aug") == 1) {
			addnav("Augmentation");
			if (get_module_pref("augarm") == 0) addnav("Augment Armor","runmodule.php?module=zeratul&op=aug&op2=armor");
			if (get_module_pref("augweap") == 0) addnav("Augment Weapon","runmodule.php?module=zeratul&op=aug&op2=weapon");
		}
		if (get_module_setting("create") == 1){
			addnav("Creation");
			if (get_module_pref("armor") == 0) addnav("Create Armor","runmodule.php?module=zeratul&op=create&op2=armor");
			if (get_module_pref("weapon") == 0) addnav("Create Weapon","runmodule.php?module=zeratul&op=create&op2=weapon");
			if (get_module_pref("extra") == 0) addnav("Create Accessory","runmodule.php?module=zeratul&op=create&op2=extra");
		}
		if (get_module_pref("weapon") == 1 && get_module_pref("armor") == 1 && get_module_pref("extra") == 1 && get_module_pref("augarm") == 1 && get_module_pref("augweap") == 1){
			output("`n`n`i`@Zeratul`i `)walks you from his hideout.");
			output(" \"`i`@I am sorry... but you have already taken everything from me...");
			output(" Please come back when you are done with this run through...`i`)\"");
		}
}
?>