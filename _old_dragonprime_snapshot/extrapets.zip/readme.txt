//////////////////////////////////////////////////////
Name: Extra Pets
Author: Eth - ethstavern(at)gmail(dot)com
Version: 1.0
Release Date: 12/23/2005
About: Just a small mod that adds extra pets for the petshop.
Files: extrapets.php, readme.txt 
//////////////////////////////////////////////////////

Installation: Just drop into modules directory and install via modules manager. This module will also uninstall itself after installation, BUT you will retain all the extra pets added. This is to prevent it from repeatedly adding the extra pets to the database.

After the module adds the pets and uninstalls itself, you can safely delete extrapets.php from your modules directory. 

You may also want to adjust the price and upkeep fee for each pet to better suit your server.






