<?php

// 08082004

// New race "Saur" by anpera as first seen in LoGD ext GER.
// Now available as module for 0.9.8
// based on races code by JT
//
// english translation not yet available. Tell me if I'm wrong ;)
if ($_GET['op']=="download"){
	$dl=join("",file("racesaur.php"));
	echo $dl;
}else{
function racesaur_getmoduleinfo(){
	$info = array(
		"name"=>"Rasse - Echse",
		"version"=>"08082004ger",
		"author"=>"anpera, based on code by JT Traub",
		"category"=>"Races",
		"download"=>"modules/racesaur.php?op=download",
		"settings"=>array(
			"Saur Race Settings,title",
			"villagename"=>"Name der Echsenstadt|Zachazzas",
			"minedeathchance"=>"Chance f�r Echsen in der Mine zu sterben,range,0,100,1|80",
		),
	);
	return $info;
}

function racesaur_install(){
	module_addhook("chooserace");
	module_addhook("setrace");
	module_addhook("newday");
	module_addhook("villagetext");
	module_addhook("travel");
	module_addhook("charstats");
	module_addhook("validlocation");
	module_addhook("moderate");
	module_addhook("changesetting");
	module_addhook("raceminedeath");
	module_addhook("stabletext");
	module_addhook("stablelocs");
	return true;
}

function racesaur_uninstall(){
	return true;
}

function racesaur_dohook($hookname,$args){
	//yeah, the $resline thing is a hack.  Sorry, not sure of a better way
	//to handle this.
	// Pass it in via args?
	global $session,$resline;
	$city = get_module_setting("villagename");
	$race = "Echse";
	switch($hookname){
	case "raceminedeath":
		if ($session['user']['race'] == $race) {
			$args['chance'] = get_module_setting("minedeathchance");
		}
		break;
	case "changesetting":
		// Ignore anything other than villagename setting changes
		if ($args['setting'] == "villagename") {
			if ($session['user']['location'] == $args['old'])
				$session['user']['location'] = $args['new'];
			$sql = "UPDATE " . db_prefix("accounts") .
				" SET location='" . $args['new'] .
				"' WHERE location='" . $args['old'] . "'";
			db_query($sql);
			if (is_module_active("cities")) {
				$sql = "UPDATE " . db_prefix("module_userprefs") .
					" SET value='" . $args['new'] .
					"' WHERE modulename='cities' AND setting='homecity'" .
					"AND value='" . $args['old'] . "'";
				db_query($sql);
			}
		}
		break;
	case "charstats":
		if ($session['user']['race']==$race){
			addcharstat("Vital Info");
			addcharstat("Rasse", $race);
		}
		break;
	case "chooserace":
		output("<a href='newday.php?setrace=Echse$resline'>In einem Erdloch in der �den Landschaft</a> von $city, weit au�erhalb jeder Siedlung, bist du als `5Echsenwesen`0 aus deinem Ei geschl�pft. Artverwandt mit den Drachen hast du es nicht leicht in dieser Welt.`n`n",true);
		addnav("`5Echse`0","newday.php?setrace=Echse$resline");
		addnav("","newday.php?setrace=Echse$resline");
		break;
	case "setrace":
		if ($session['user']['race']==$race){
			output("`5Als Echsenwesen hast du durch deine H�utungen einen klaren gesundheitlichen Vorteil gegen�ber anderen Rassen.`n`^Du startest mit einem permanenten Lebenspunkt mehr.");
			if (is_module_active("cities")) {
				if ($session['user']['dragonkills']==0 &&
						$session['user']['age']==0){
					//new farmthing, set them to wandering around this city.
					set_module_setting("newest-$city",
							$session['user']['acctid'],"cities");
				}
				set_module_pref("homecity",$city,"cities");
				$session['user']['location']=$city;
			}
			$session['user']['maxhitpoints']++;
		}
		break;
	case "newday":
		if ($session['user']['race']==$race){
			racesaur_checkcity();
		}
		break;
	case "validlocation":
		if (is_module_active("cities"))
			$args[$city]=1;
		break;
	case "moderate":
		if (is_module_active("cities"))
			$args["village-$race"]="City of $city";
		break;
	case "travel":
		$capital = getsetting("villagename", LOCATION_FIELDS);
		if ($session['user']['location']==$capital){
			addnav("Safer Travel");
			addnav(substr($city,0,1)."?Go to $city","runmodule.php?module=cities&op=travel&city=$city");
		}elseif ($session['user']['location']!=$city){
			addnav("More Dangerous Travel");
			addnav(substr($city,0,1)."?Go to $city","runmodule.php?module=cities&op=travel&city=$city&d=1");
		}
		if ($session['user']['superuser'] & SU_EDIT_USERS){
			addnav("Superuser");
			addnav("Go to $city","runmodule.php?module=cities&op=travel&city=$city&su=1");
		}
		break;
	case "stabletext":
		if ($session['user']['location'] != $city) break;
		$args['title'] = "Zoo";
		$args['desc'] = "`5In einer eigenen H�hle halten sich die Echsen Tiere aller Art. �hnlich einem Zoo kann man sich die verschiedensten Waldmonster und Tiere ansehen. Einige der Wesen wurden dressiert und k�nnen sogar gekauft werden.%s";
		$args['lad']="";
		$args['lass']="";
		$args['nosuchbeast']="`5Das Tier, das du suchst, scheint es nicht zu geben.";
		$args['finebeast']=array(
			"`5Du bist von dieser Kreatur fasziniert.`n`n",
			"`5In deinen Augen ein wirklich sch�nes Gesch�pf.`n`n",
			"`5In Ehrfurcht verweilst du einen Augenblick vor diesem Lebewesen.`n`n",
			"`5Die vorbeigehenden Echsen nicken dir f�r diese Wahl anerkennend zu.`n`n",
		);
		$args['toolittle']="`5Dieses Tier kostet `^%s `5Gold und `#%s`5 Edelsteine. So viel hast du gar nicht und du musst dich von dem Tier wieder trennen.";
		$args['replacemount']="`5 Du �bergibst %s`5 und den geforderten Preis. Und kannst du mit %s`5 davon ziehen.";
		$args['newmount']="`5Du hast dich in %s verliebt, bezahlst und ziehst stolz von dannen.";
		$args['nofeed']="`5Die Echsen haben strenge Regeln und f�r dich gibt es leider kein Futter mehr. Also vielmehr f�r dein Tier gibt es nichts.";
		$args['nothungry']="`5%s hat entweder keinien Hunger, oder mag das Futter nicht, denn es bleibt alles �brig. Wenigstens musst du nichts bezahlen.";
		$args['halfhungry']="`5%s knabbert etwas am �berreichten Futter, r�hrt den Rest aber nicht an. Du musst nur `^%s`5 Gold bezahlen.";
		$args['hungry']="`5%s`5 macht sich ger�uschvoll und gierig �ber das Futter her, w�hrend du %ss Futter mit `^%s`5 Gold bezahlst.";
		$args['mountfull']="`n`5Der Eimer mit der Aufschrift \"`%%ss %s`5\" leert sich sehr schnell. Dein Tier muss wahnsinnig hungrig gewesen sein.";
		$args['nofeedgold']="`5Wie willst du das Futter bezahlen, hmm? Es sieht so aus, als ob du %s woanders f�ttern m�sstest.";
		$args['confirmsale']="`5Du nimmst dir einen Moment Zeit, um noch einmal �ber deine Entscheidung nachzudenken. Willst du dein Tier wirklich verkaufen?";
		$args['mountsold']="`5Du �bergibst %s`5 den Echsen.  Etwas traurig �ber den Abschied nimmst du %s`5 entgegen.";
		$args['offer']="`n`n`5Dir werden `^%s`5 Gold und `#%s`5 Edelsteine geboten, wenn du dein %s`5 dem Zoo zur Verf�gung stellst.";
		break;
	case "stablelocs":
		$args[$city]="The Village of $city";
		break;
	case "villagetext":
		racesaur_checkcity();
		if ($session['user']['location'] == $city){
			$args['text']="`5`c`bDie Ein�de von $city, Heimat der Echsen`b`c`n`5Erdloch an Erdloch reiht sich in der �den Landschaft von $city. Nur die zerbrochenen Eierschalen frisch geschl�pfter Neuank�mmlinge lassen vermuten, dass es hier irg3endwo Leben geben muss. Und Leben gibt es in der engen, d�steren Stadt unter der Erde, die aus zahlreichen H�hlen besteht, die durch viele enge G�nge miteinander verbunden sind. Es gibt sogar einen Zoo hier. Ja, das ist die Stadt $city! `n";
			if ($session['user']['race']=="Echse"){
				$args['clock']="`n`5Deine tageszeitabh�ngige K�rpertemperatur sagt dir, dass es `^%s`5 Uhr sein muss.";
			}else{
				$args['clock']="`n`5Die tageszeitabh�ngige Aktivit�t der umherstreifenden Echsenwesen l�sst dich auf die aktuelle Uhrzeit schlie�en. Demnach ist es `^%s`5 Uhr.`n";
			}
			$args['title']="Stadt $city";
			$args['sayline']="zischt";
			$args['talk']="`n`5In einer der gr��eren H�hlen h�rst du die zischelnden Unterhaltungen einiger Bewohner:`n";
			$new = get_module_setting("newest-$city", "cities");
			if ($new != 0) {
				$sql =  "SELECT name FROM " . db_prefix("accounts") .
					" WHERE acctid='$new'";
				$result = db_query_cached($sql, "newest-$city");
				$row = db_fetch_assoc($result);
				$args['newestplayer'] = $row['name'];
				$args['newestid']=$new;
			} else {
				$args['newestplayer'] = $new;
				$args['newestid']="";
			}
			if ($new == $session['user']['acctid']) {
				$args['newest']="`n`5Du bestaunst die fantastischen Arbeiten der Echsen. Die gro�en H�hlen und die engen G�nge stehen in einem seltsamen, aber faszinierenden Widerspruch.";
			} else {
				$args['newest']="`n`5Du bemerkst `^%s`5 beim Bestaunen der fantastisichen Arbeiten der alten Echsen. Ja, die gro�en H�hlen und engen G�nge k�nnen Neulinge schon beeindrucken.";
			}
			$args['fightnav']="K�mpferh�hle";
			$args['marketnav']="Markth�hle";
			$args['tavernnav']="Gemeinschaft";
			$args['section']="village-$race";
			$args['stablename']="Zoo";
			unblocknav("stables.php");
		}
		break;
	}
	return $args;
}

function racesaur_checkcity(){
	global $session;
	$race="Echse";
	$city=get_module_setting("villagename");
	
	if ($session['user']['race']==$race && is_module_active("cities")){
		//if they're this race and their home city isn't right, set it up.
		if (get_module_pref("homecity","cities")!=$city){ //home city is wrong
			set_module_pref("homecity",$city,"cities");
		}
	}	
	return true;
}

function racesaur_run(){

}
}
?>