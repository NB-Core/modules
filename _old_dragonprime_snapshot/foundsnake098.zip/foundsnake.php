<?php
/*
* Date:     April 15, 2005
* Author:   Robert of MaddRio dot com
* v 1.2     optimized code
*/
function foundsnake_getmoduleinfo(){
	$info = array(
	"name"=>"Found Snake",
	"version"=>"1.2",
	"author"=>"`2Robert",
	"category"=>"Forest Specials",
	"download"=>"http://dragonprime.net/users/Robert/foundsnake098.zip",
	);
	return $info;
}

function foundsnake_install(){
	module_addeventhook("forest", "return 100;");
	return true;
}

function foundsnake_uninstall(){
	return true;
}

function foundsnake_dohook($hookname,$args){
	return $args;
}
function foundsnake_runevent($type){
global $session;
switch(e_rand(1,11)){
	case 1: case 6: 
	output("`n`n`2 A `b`i`&small snake`i`b `2has been startled by your presence, you are bitten!"); 
	$session['user']['hitpoints']=$session['user']['hitpoints']*.95; break;
	case 2: case 7: 
	output("`n`n`2 A `b`i`&small brown snake`i`b `2has been startled by your presence, you are bitten!"); 
	$session['user']['hitpoints']=$session['user']['hitpoints']*.9; break;
	case 3: case 8: 
	output("`n`n`2 A `b`i`&small black snake`i`b `2has been startled by your presence, you are bitten!"); 
	$session['user']['hitpoints']=$session['user']['hitpoints']*.85; break;
	case 4: case 9: 
	output("`n`n`2 A `b`i`&brown snake`i`b `2has been startled by your presence, you are bitten!"); 
	$session['user']['hitpoints']=$session['user']['hitpoints']*.8; break;
	case 5: case 10: 
	output("`n`n`2 A `b`i`&black snake`i`b `2has been startled by your presence, you are bitten!"); 
	$session['user']['hitpoints']=$session['user']['hitpoints']*.75; break;
	case 11: 
	output("`n`n`2 A large `b`i`&snake`i`b `2is startled by your presence, you are bitten!"); 
	$session['user']['hitpoints']=$session['user']['hitpoints']*.65; break;
	}
}
function foundsnake_run(){
}
?>