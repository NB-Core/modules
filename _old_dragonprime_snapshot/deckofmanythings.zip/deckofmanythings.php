<?php
/*
Module Name:  deckofmanythings.php 
Category:  Forest Specials
Worktitle:  Deck of Many Things
Author:  DaveS
Date:  October 23, 2005

Required Modules:
None

Additional Modules for full function:
moons.php, potions.php
Module will function without their installation

credits:
Many events are inspired and a tribute to the old ASCII RPG Nethack; particularly the encounter with the
Gypsy in Slash-Em. Check it out if you've never heard of it.
In addition, the concept is from the Dungeons and Dragons Artifact Item "The Deck of Many Things".

Description:
Meet up with a Gypsy to decide if you want to draw a card.  If you do, you may pick 1 of 20 different cards.
Fight Vampires, Demons, Wizards, Foocubi, and more.  The monsters are tough and have learned a few tricks of their
own.  Learn the current Moon phase, spin the wheel of fate, get a precious stone based on the month, or become 
invisible. Perhaps you'll be lucky enough to make a Wish! Lots more.

Features:
Turn off the pictures of the cards. Unlock the forest special after a certain number of dragon kills if desired 
(Default is zero).  Turn off the Foocubus for G-rated sites (it's a PG encounter).  Turn off Permanent Hitpoint 
awards/penalties.

*/
require_once("lib/increment_specialty.php");
require_once("lib/titles.php");
require_once("lib/names.php");
function deckofmanythings_getmoduleinfo(){
	$info = array(
		"name"=>"Deck of Many Things",
		"version"=>"3.02",
		"author"=>"DaveS",
		"category"=>"Forest Specials",
		"download"=>"http://dragonprime.net/index.php?module=Downloads;sa=dlview;id=184",
		"vertxtloc"=>"",
		"settings"=>array(
			"Deck of Many Things - Settings,title",
			"dksneeeded"=>"How many dks needed before encountering this forest special?,int|0",
			"usepics"=>"Use images?,bool|1",
			"gypsycharm"=>"How charming is the gypsy?,int|0",
			"penavt"=>"How many turns to lose for avoiding the gypsy?,range,0,4,1|2",
			"penavg"=>"How much gold to lose for avoiding the gypsy?,enum,0,None,1,100 Gold,2,500 Gold,3,1000 Gold,4,10% of Gold,5,25% of Gold,6,50% of Gold,7,100% of Gold|0",
			"penavge"=>"How many gems to lose for avoiding the gypsy?,range,0,4,1|0",
			"givepermhp"=>"Allow Permanent hps to be given or lost?,bool|1",
			"deckseduction"=>"Allow player to sleep with Foocubus?,bool|1",
			"Nothing graphic but may not be acceptable on a G-Rated site,note",
		),
		"prefs"=>array(
			"Deck of Many Things - Preferences,title",
			"deckcheck"=>"Used this newday?,bool|0",
			"monsternum"=>"What monster did they fight last?,enum,1,The Gypsy,2,The Wizard of Yendor,3,A Foocubus,4,Erinys,5,Asmodeus,6,Vampire|1",
			"Foocubus Card,title",
			"deckseduced"=>"Have they been seduced by the Foocubus?,bool|0",
			"decktemparmor"=>"what armor do they normally have?,text|0",
			"decktempdefense"=>"what is the defense value of the armor?,int|0",
			"Pain Card,title",
			"deckpain"=>"Days left of pain?,int|0",
		),
	);
	return $info;
}
function deckofmanythings_chance() {
	global $session;
	if (get_module_pref('deckcheck',"deckofmanythings",$session['user']['acctid'])==1 || $session['user']['dragonkills']<get_module_setting('dksneeeded',"deckofmanythings",$session['user']['acctid'])) return 0;
	else return 100;
}
function deckofmanythings_install(){
	module_addeventhook("forest","require_once(\"modules/deckofmanythings.php\"); 
	return deckofmanythings_chance();");
	module_addhook("newday");
	module_addhook("inn");
	if (is_module_active("moons")) module_addhook("moons");
	if (is_module_active("potion")) module_addhook("potions");
	return true;
}
function deckofmanythings_uninstall(){
	return true;
}
function deckofmanythings_dohook($hookname,$args){
	global $session;
	switch ($hookname) {
		case "newday":
			set_module_pref("deckcheck",0);
			if (get_module_pref("deckpain")>1) {
				increment_module_pref("deckpain",-1);
				output("`n`\$You wake to excruciating pain with only `bone hitpoint`b because of the Deck of Many Things.`n");
				$session['user']['hitpoints']=1;
			}elseif (get_module_pref("deckpain")==1) {
				set_module_pref("deckpain",0);
				output("`n`\$The pain from the Deck of Many Things finally subsides.`n");
			}			
		break;
	}
	return $args;
}
function deckofmanythings_runevent($type) {
	global $session;
	set_module_pref("deckcheck",1);
	output("`#`n");
	output("While slashing through the `@Forest`# in a desperate attempt to protect the kingdom, your %s`# stops inches away from chopping the head off
		of an `%o`^l`%d `%g`^y`%p`^s`%y `%w`^o`%m`^a`%n`#.`n`nLuckily, you didn't hit her, because everyone knows the penalty for accidentally killing `%o`^l`%d `%g`^y`%p`^s`%y `%w`^o`%m`^e`%n`# 
		is usually some awful curse or something.`n`n",$session['user']['weapon']);
	output("`%'You're lucky you didn't hit me,'`# she says. `%'Because I would have cast an awful curse on you if you had.'`#`n`n(See! I tell you, these old
		fables are true!)`n`n");
	output("She looks at you and pokes you with her walking stick. `%'Quit daydreaming! I got a proposition for you!'`n`n`#Part of you starts to shiver at the
		thought of being propositioned by the old bat, so you stare at her and let her continue.`n`n");
	output("She pulls out a very beautifully ornate `\$Deck `^of `\$Cards`#. `%'I will sell you the opportunity to draw a card from my magic deck.  Who knows
		what benefits you will enjoy.  Or perhaps what curses will consume you.' `#She shrugs.`% 'I don't care either way.  Just give me");
	if ($session['user']['gold']>=400){
		output("`^400 gold`% and");
		addnav("Give her the `^Gold","runmodule.php?module=deckofmanythings&op=deckplaygold");
	}elseif ($session['user']['gems']>=1){
		output("`bOne Gem`b and");
		addnav("Give her the `%Gem","runmodule.php?module=deckofmanythings&op=deckplaygem");
	}else{
		output("`&two of your charm points`%. You see, I have a special potion that will take `&two of your charm`% and give it to me so I will look even MORE beautiful!'`n`n`#You consider how much
			she could benefit from a little beautification project when she pokes you with her stick again.`n`n`%'If you agree,");
		addnav("Give her Your Charm","runmodule.php?module=deckofmanythings&op=deckplaycharm");
	}
	output("I'll let you pick a card.'`n`n`#What would you like to do?");
	addnav("Fight the `%O`^l`%d G`^y`%p`^s`%y`#","runmodule.php?module=deckofmanythings&op=gypsyattack");
	addnav("Slowly Back Away","runmodule.php?module=deckofmanythings&op=exitstageleft");
}
function deckofmanythings_run(){
	global $SCRIPT_NAME;
	if ($SCRIPT_NAME == "runmodule.php"){
		$module=httpget("module");
		if ($module == "deckofmanythings"){
			include("modules/deckofmanythings/deckofmanythings.php");
		}
	}
}
?>