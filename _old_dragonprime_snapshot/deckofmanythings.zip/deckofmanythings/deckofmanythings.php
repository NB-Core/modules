<?php
global $session;
$op = httpget('op');
$session['user']['specialinc']="module:deckofmanythings";
page_header("The Deck of Many Things");
output("`n`c`b`^The `\$Deck `^of `\$Many `^Things`c`b");
output("`#`n");
if ($op=="deckplaygold"){
	$session['user']['gold']-=400;
	output("You hand over your `^400 Gold`# and wonder if this was the right idea.");
	output("`n`nBefore you have a chance to ask for your money back, the `%g`^y`%p`^s`%y`# fans out the deck.`n`nYou slowly reach and pick a card...");
	addnav("Draw a Card","runmodule.php?module=deckofmanythings&op=carddraw");
}
if ($op=="deckplaygem"){
	$session['user']['gems']--;
	output("You hand over your `%One Gem`# and wonder if this was the right idea.");
	output("`n`nBefore you have a chance to ask for your gem back, the `%g`^y`%p`^s`%y`# fans out the deck.`n`nYou slowly reach and pick a card...");
	addnav("Draw a Card","runmodule.php?module=deckofmanythings&op=carddraw");
}
if ($op=="deckplaycharm"){
	$session['user']['charm']-=2;
	increment_module_setting("gypsycharm",2);
	if (get_module_setting("gypsycharm")>=31) set_module_setting("gypsycharm",0); 
	$gypsycharm=get_module_setting("gypsycharm");
	output("You take the potion from the old `%g`^y`%p`^s`%y`# and slowly drink it down.`n`n  You feel your `&charm`# lower to `&%s`# and hers go up to `&%s`#.  You look at her and think",$session['user']['charm'],$gypsycharm);
	if ($gypsycharm<11) output("`@'Wow... too bad she didn't take more than 2 points. She is STILL really ugly.'");
	if ($gypsycharm>=11 && $gypsycharm<21) output("`@'Well, she's not the ugliest `%g`^y`%p`^s`%y`@ I've ever seen.'");
	if ($gypsycharm>=21) output("`@'Actually, for an `%o`^l`%d `%g`^y`%p`^s`%y `%w`^o`%m`^a`%n`@, she's not really that bad looking.'");
	output("`#`n`nYou wonder if this was the right idea.");
	output("`n`nBefore you have a chance to change your mind, the `%g`^y`%p`^s`%y`# fans out the deck.`n`nYou slowly reach and pick a card...");
	addnav("Draw a Card","runmodule.php?module=deckofmanythings&op=carddraw");
}
if ($op=="carddraw"){
	output("You draw...`n");
	switch(e_rand(1,20)){
		case 1:
			if (get_module_setting("usepics")==1) rawoutput("<br><center><table><tr><td align=center><img src=modules/deckofmanythings/dmtfool.jpg></td></tr></table></center><br>"); 
			rawoutput("<big>");
			output("`c`b`^The Fool`b`c");
			rawoutput("</big>");
			output("`n`nThe `@F`%o`!o`\$l`^ and his `bMoney`b are quickly parted... As are you and yours! `n`n You lose `bAll your gold`b and `%10% of your gems`^!`n`n");
			$session['user']['gold']=0;
			$gems=round($session['user']['gems']*.9);
			$session['user']['gems']=$gems;
			$session['user']['specialinc']="";
			debuglog("lost all gold and $gems from the Deck of Many Things.");
			addnav("Back to the Forest","forest.php");
			addnews("%s`^ drew the `\$Fool Card`^.",$session['user']['name']);
		break;
		case 2:
			if (get_module_setting("usepics")==1) rawoutput("<br><center><table><tr><td align=center><img src=modules/deckofmanythings/dmtmagician.jpg></td></tr></table></center><br>"); 
			rawoutput("<big>");
			output("`c`b`^The Magician`b`c");
			rawoutput("</big>");
			output("`nSuddenly, you find yourself face to face with a very powerful magician...  His name is `!The Wizard of Yendor`^!`n`n");
			set_module_pref("monsternum",2);
			addnav("Fight the `!Wizard","runmodule.php?module=deckofmanythings&op=attack");
		break;
		case 3:
			if (get_module_setting("usepics")==1) rawoutput("<br><center><table><tr><td align=center><img src=modules/deckofmanythings/dmthighpriestess.jpg></td></tr></table></center><br>"); 
			rawoutput("<big>");
			output("`c`b`^The High Priestess`b`c");
			rawoutput("</big>");
			if (get_module_setting("givepermhp")==1) {
				output("`n`nYour `\$hitpoints`^ are restored to full!  Plus you gain `\$3 Permanent Hitpoints`^ and `\$10 additional hitpoints`^!`n`n`n");
				$session['user']['maxhitpoints']+=3;
				$session['user']['hitpoints']=$session['user']['maxhitpoints']+10;
				debuglog("received 10 temp hitpoints and 3 Permanent Hitpoints from the Deck of Many Things.");
			}else{
				output("`n`nYour `\$hitpoints`^ are restored to full!  Plus you gain `\$50 Hitpoints`^!`n`n`n");
				$session['user']['hitpoints']=$session['user']['maxhitpoints']+50;
				debuglog("received 50 temp hitpoints from the Deck of Many Things.");	
			}
			addnav("Back to the Forest","forest.php");
			$session['user']['specialinc']="";
			addnews("%s`^ drew the `\$High Priestess Card`^.",$session['user']['name']);
		break;
		case 4:
			if (get_module_setting("usepics")==1) rawoutput("<br><center><table><tr><td align=center><img src=modules/deckofmanythings/dmtoracle.jpg></td></tr></table></center><br>"); 
			rawoutput("<big>");
			output("`c`b`^The Oracle`b`c");
			rawoutput("</big>");
			output("`n`nYou may ask the Oracle about any player in the game.`n`n");
			addnav("Ask the Oracle","runmodule.php?module=deckofmanythings&op=deckoracle");	
			addnews("%s`^ drew the `\$Oracle Card`^.",$session['user']['name']);
		break;
		case 5:
			if (get_module_setting("usepics")==1) rawoutput("<br><center><table><tr><td align=center><img src=modules/deckofmanythings/dmtlovers.jpg></td></tr></table></center><br>"); 
			rawoutput("<big>");
			output("`c`b`^The Lovers`b`c");
			rawoutput("</big>");
			output("`n`nStanding before you is `\$%s`^.  I'd advise you to defeat %s in battle.`n`n",translate_inline($session['user']['sex']?"an Incubus":"a Succubus"),translate_inline($session['user']['sex']?"him":"her"));
			addnav("`\$Fight!","runmodule.php?module=deckofmanythings&op=attack");
			if (get_module_setting("deckseduction")==1){
				if ($session['user']['gold']>=500) addnav (array("`0Pay `^500 Gold`0 to the %s",translate_inline($session['user']['sex']?"Incubus":"Succubus")),"runmodule.php?module=deckofmanythings&op=payment");
			}
			set_module_pref("monsternum",3);
		break;
		case 6:
			if (get_module_setting("usepics")==1) rawoutput("<br><center><table><tr><td align=center><img src=modules/deckofmanythings/dmtchariot.jpg></td></tr></table></center><br>"); 
			rawoutput("<big>");
			output("`c`b`^The Chariot`b`c");
			rawoutput("</big>");
			output("`n`nYou hop aboard the Chariot and are transported to the `#Local Watering Hole`^.");
			output("This may sound like a strange place to visit, but then you realize that driving a Chariot must be a lot of work. `n`nSounds like a good excuse to go get a `QMead`^!");
			$session['user']['specialinc']="";
			$vname = getsetting("villagename", LOCATION_FIELDS);
			$capital = $session['user']['location']==$vname;
			$session['user']['location']=$vname;
			addnav("Visit the Inn","inn.php?op=strolldown");
			addnews("%s`^ drew the `\$Chariot Card`^.",$session['user']['name']);
		break;
		case 7:
			if (get_module_setting("usepics")==1) rawoutput("<br><center><table><tr><td align=center><img src=modules/deckofmanythings/dmtstrength.jpg></td></tr></table></center><br>"); 
			rawoutput("<big>");
			output("`c`b`^Strength`b`c");
			rawoutput("</big>");
			output("`n`nThe `%g`^y`%p`^s`%y`^ looks at you and nods.`n`n`%'Yes, you look quite powerful!'`n`n`^You gain `&One Attack`^.  You eat a can of `@Spinach`^ and also `&Gain A Powerful Buff`^.`n`n");
			$session['user']['attack']++;
			apply_buff('evileye',array(
				"name"=>"`@Spinach",
				"rounds"=>10,
				"wearoff"=>"`@The power of the Spinach wears off",
				"atkmod"=>1.25,
				"roundmsg"=>"`@'I Yam what I Yam!!' becomes your battle cry...",
			));
			addnav("Back to the Forest","forest.php");
			$session['user']['specialinc']="";
			addnews("%s`^ drew the `\$Strength Card`^.",$session['user']['name']);
		break;
		case 8:
			if (get_module_setting("usepics")==1) rawoutput("<br><center><table><tr><td align=center><img src=modules/deckofmanythings/dmthermit.jpg></td></tr></table></center><br>"); 
			rawoutput("<big>");
			output("`c`b`^The Hermit`b`c");
			rawoutput("</big>");
			output("`n`nSuddenly you feel like hiding!`n`nYou are invisible to the world.`n`n");
			apply_buff('invisibility',array(
				"name"=>"Invisibility",
				"rounds"=>15,
				"wearoff"=>"`&You are suddenly seen by your enemy.",
				"defmod"=>1.25,
				"roundmsg"=>"`&Your invisibility makes you more difficult for the enemy to defeat!",
			));
			addnav("Back to the Forest","forest.php");
			$session['user']['specialinc']="";
			addnews("%s`^ drew the `\$Hermit Card`^.",$session['user']['name']);
		break;
		case 9:
			if (get_module_setting("usepics")==1) rawoutput("<br><center><table><tr><td align=center><img src=modules/deckofmanythings/dmtwheel.jpg></td></tr></table></center><br>"); 
			rawoutput("<big>");
			output("`c`b`^Wheel of Fortune`b`c");
			rawoutput("</big>");
			output("`n`nThe `%g`^y`%p`^s`%y`^ watches you as the card you picked enlarges to a full sized spinning wheel.  You take several seconds to carefully read the wedges:`n`n");
			output("`c`!Health`n`#Fear`n`%Friendship`n`\$Pain`n`QBeauty`n`6Skill`n`^Wealth`n`@Energy`n`)Death`c`n");
			output("`^You reach out to touch the wheel and it suddenly starts spinning.  You nervously watch it slow down...");
			addnav("Wheel of Fortune","runmodule.php?module=deckofmanythings&op=deckwheel");	
		break;
		case 10:
			if (get_module_setting("usepics")==1) rawoutput("<br><center><table><tr><td align=center><img src=modules/deckofmanythings/dmtjustice.jpg></td></tr></table></center><br>"); 
			rawoutput("<big>");
			output("`c`b`^Justice`b`c");
			rawoutput("</big>");
			output("`n`nA terrible creature appears before you, it's head wreathed with `@serpents`^, eyes dripping with `4blood`^, it's body terrific and appalling.");
			output("It has the `)wings of a bat`^ and the `qbody of a dog`^.`n`n It is one of the `&Erinyes`^ standing before you and calling for Justice to be served against you!");
			set_module_pref("monsternum",4);
			addnav("Fight the Erinys","runmodule.php?module=deckofmanythings&op=attack");			
		break;
		case 11:
			if (get_module_setting("usepics")==1) rawoutput("<br><center><table><tr><td align=center><img src=modules/deckofmanythings/dmtpunishment.jpg></td></tr></table></center><br>"); 
			rawoutput("<big>");
			output("`c`b`^Punishment`b`c");
			rawoutput("</big>");
			output("`n`nYou are being `)`bPunished`b`^!");
			output("You hear the sound of shackles and feel a tightening sensation around your leg.");
			output("You look down to see a very heavy `)Ball `&and `)Chain`^ hindering your every movement.");
			output("You sigh and realize that it's going to be a VERY long day.`n`n");
			apply_buff('ballnchain',array(
				"name"=>"`)Ball `&and `)Chain",
				"rounds"=>50,
				"wearoff"=>"`)The shackles break and you're free!",
				"defmod"=>.75,
				"roundmsg"=>"`)Your defensive maneuvers are hindered by the huge Ball attached to your leg.",
			));
			addnav("Back to the Forest","forest.php");
			$session['user']['specialinc']="";
			addnews("%s`^ drew the `\$Punishment Card`^.",$session['user']['name']);
		break;
		case 12:
			if (get_module_setting("usepics")==1) rawoutput("<br><center><table><tr><td align=center><img src=modules/deckofmanythings/dmtdevil.jpg></td></tr></table></center><br>"); 
			rawoutput("<big>");
			output("`c`b`^The Devil`b`c");
			rawoutput("</big>");
			output("`n`nThe smell of `)brimstone`^ surrounds you.  You turn to find yourself facing a`\$ Major Demon`^!");
			set_module_pref("monsternum",5);
			addnav("`4Fight `\$Asmodeus","runmodule.php?module=deckofmanythings&op=attack");				
		break;
		case 13:
			if (get_module_setting("usepics")==1) rawoutput("<br><center><table><tr><td align=center><img src=modules/deckofmanythings/dmtsorcery.jpg></td></tr></table></center><br>"); 
			rawoutput("<big>");
			output("`c`b`^Sorcery`b`c");
			rawoutput("</big>");
			switch(e_rand(1,2)){
				case 1:
					output("`n`nA great and powerful wizard in `@Emerald`^ appears before you.");
					output("He sizes you up and decides that you are standing a little too proudly and need to be taken down a notch.");
					output("The wizard casts a terrible spell on you!`n`n`nOh No!  What will it be?!?!?`n`n`n Some horrible curse?!?!`n`n`nA plague of boils?!?!`n`n`n");
					output("Or maybe Locusts?!?!`n`nYou cringe in anticipation and fear!`n`n`nBefore you know it, there's a darn pebble in your shoe poking you with every step!");
					output("`n`n`\$Oh the Wickedness of it all!!!");
					apply_buff('shoepebble',array(
						"name"=>"Pebble in Your Shoe",
						"rounds"=>25,
						"wearoff"=>"`)The pebble pops out of your shoe",
						"minioncount"=>1,
						"mingoodguydamage"=>1,
						"maxgoodguydamage"=>1,
						"effectmsg"=>"`\$Darn that little pebble is annoying! You lose 1 hitpoint from it!",
					));	
				break;
				case 2:
					output("`n`nA large floating head appears out of no where.  It requests that you retrieve a `qbroom`^ from a `)w`2itch`^ or something like that.");
					output("You get kinda bored with all the hoo-ha.`n`nAs you turn to leave, you see a `0small dog`^ tugging at a curtain revealing a man operating come complicated machinery.");
					output("`n`nSince you are not a `%little `\$g`&i`\$r`&l`^ from Kansas you realize you've popped into the wrong story!`n`nThe `%o`^l`%d `%g`^y`%p`^s`%y `%w`^o`%m`^a`%n`^ apologizes and mentions that she can't always understand");
					output("what happens with this crazy deck.  She gives you back your gold plus a little more to get you on your `%merry way`^.`n`nYou receive `b750 gold`b and go on your `%Merry Way`^.");
					$session['user']['gold']+=750;
					apply_buff('merryway',array(
						"name"=>"`%Merry Way",
						"rounds"=>10,
						"wearoff"=>"`%Your way isn't quite so merry anymore.",
						"atkmod"=>1.1,
						"defmod"=>1.1,
						"roundmsg"=>"`%Tra la la la la la! What a Merry Way!",
					));
				break;
			}
			addnav("Back to the Forest","forest.php");
			$session['user']['specialinc']="";
			addnews("%s`^ drew the `\$Sorcery Card`^.",$session['user']['name']);
		break;
		case 14:
			if (get_module_setting("usepics")==1) rawoutput("<br><center><table><tr><td align=center><img src=modules/deckofmanythings/dmtdeath.jpg></td></tr></table></center><br>"); 
			rawoutput("<big>");
			output("`c`b`^Death`b`c");
			rawoutput("</big>");
			output("`n`n`\$Pain`^ surrounds you and a crushing sensation overcomes you. `)Death Incarnate`^ grows from out of the card holding a horrible scythe dripping with the blood of the uncountable dead.`n`n");
			output("Without words, the skull under the hood looks at you and raises a hand and points.");
			output("`n`nIn an instant, you are `\$Dead`^.`n`n`)Death Incarnate`^ disappears and you give a silly little smile.");
			output("He killed you too quickly! You're not fully dead, you're `\$MOSTLY Dead`^!`n`n");
			$exploss = round($session['user']['experience']*.07);
			output("`bYou lose `#%s experience`^, all your `\$hitpoints except 1`^, all your gold, and you lost `@1/2 of your remaining turns`^.`b`n`n",$exploss);
			output("But you still get to return to the `@Forest`^!`n`n`n");
			$session['user']['experience']-=$exploss;
			$session['user']['hitpoints']=1;
			$session['user']['gold']=0;
			$session['user']['turns']=round($session['user']['turns']*.5);
			$session['user']['specialinc']="";
			addnav("Back to the Forest","forest.php");
			addnews("%s`^ drew the `\$Death Card`^.",$session['user']['name']);
		break;
		case 15:
			if (get_module_setting("usepics")==1) rawoutput("<br><center><table><tr><td align=center><img src=modules/deckofmanythings/dmttower.jpg></td></tr></table></center><br>"); 
			rawoutput("<big>");
			output("`c`b`^The Tower`b`c");
			rawoutput("</big>");
			output("`n`nThe card drops to the ground and a spiraling tower grows from it.");
			output("The monolith rises above you.  You stare at it with a sense of fear but an even greater sense of adventure.");
			output("`n`n The first step is always the hardest.  Are you ready to go up the stairway?`n`n");
			addnav("Enter the Tower","runmodule.php?module=deckofmanythings&op=decktower");
			addnav("Leave for the Forest","runmodule.php?module=deckofmanythings&op=exitstageleft");
		break;
		case 16:
			if (get_module_setting("usepics")==1) rawoutput("<br><center><table><tr><td align=center><img src=modules/deckofmanythings/dmtstar.jpg></td></tr></table></center><br>"); 
			rawoutput("<big>");
			output("`c`b`^The Star`b`c");
			rawoutput("</big>");
			$monthnumb=date("n");			
			$gemnumb=e_rand(0,1);
			$gemnumbera=array("One","Two");
			$gemadds=array("","s");
			$gemprecious=array("a `\$P`Qr`^e`@c`#i`!o`%`\$u`Qs `%Gem","`%Two `\$P`Qr`^e`@c`#i`!o`%`\$u`Qs `%Gems");
			$monthname=array("","January","February","March","April","May","June","July","August","September","October","November","December");
			$monthgem=array("","`4Garnet","`%`bAmethyst`b","`#Aquamarine","`&Diamond","`@Emerald","`&O`%p`\#a`&l","`\$Ruby","`^Chrysoberyl","`!Sapphire","`)B`0l`)a`0c`)k `0O`)p`0a`)l","`1T`#o`1p`#a`1z","`2T`@u`2r`@q`2u`@o`2i`@s`2e");
			$gemvalue=array("","700","600","1500","4000","2500","800","3500","700","3000","2500","900","2000");
			$gemn=array("","","n","n","","n","n","","","","","","");
			output("`n`nThe `%o`^l`%d `%g`^y`%p`^s`%y `%w`^o`%m`^a`%n`^ looks at you playfully and grabs for your ear.  She pulls out %s`^ and smiles at you.`n`n",$gemprecious[$gemnumb]);
			output("`%'Since it is `b`&%s`b`% you get `&%s %s%s`%.",$monthname[$monthnumb],$gemnumbera[$gemnumb],$monthgem[$monthnumb],$gemadds[$gemnumb]);
			output("A%s %s`% is worth `^%s Gold`%.'`n`n`^After thinking about it for a second, you happily accept the gold instead of the `\$P`Qr`^e`@c`#i`!o`%`\$u`Qs `%Gem%s`^.",$gemn[$monthnumb],$monthgem[$monthnumb],$gemvalue[$monthnumb],$gemadds[$gemnumb]);
			$getgold=$gemvalue[$monthnumb]*($gemnumb+1);
			$session['user']['gold']+=$getgold;
			output("`n`n`^You gain `b%s Gold`b!`n`n",$getgold);
			$session['user']['specialinc']="";
			addnav("Back to the Forest","forest.php");
			addnews("%s`^ drew the `\$Star Card`^.",$session['user']['name']);
		break;
		case 17:
			if (get_module_setting("usepics")==1) rawoutput("<br><center><table><tr><td align=center><img src=modules/deckofmanythings/dmtmoon.jpg></td></tr></table></center><br>"); 
			rawoutput("<big>");
			output("`c`b`^The Moon`b`c");
			rawoutput("</big>");
			output("`n`n");
			if (is_module_active("moons")){
				//From moons by JT Traub
				$msg = "`%'The moon `&%s`% is %s`%.'`n";
				$moon1 = get_module_setting("moon1","moons");
				$moon2 = get_module_setting("moon2","moons");
				$moon3 = get_module_setting("moon3","moons");
				if ($moon1) {
					$place = get_module_setting("moon1place","moons");
					$max = get_module_setting("moon1cycle","moons");
					output($msg, get_module_setting("moon1name","moons"),deckofmanythings_phase($place, $max));
				}
				if ($moon2) {
					$place = get_module_setting("moon2place","moons");
					$max = get_module_setting("moon2cycle","moons");
					output($msg, get_module_setting("moon2name","moons"),deckofmanythings_phase($place, $max));
				}
				if ($moon3) {
					$place = get_module_setting("moon3place","moons");
					$max = get_module_setting("moon3cycle","moons");
					output($msg, get_module_setting("moon3name","moons"),deckofmanythings_phase($place, $max));
				}
				//end of moons
			}else{
				$today=date("j");
				$moonphased=array("","`)new","`)new","`)new","`)new","`7waxing crescent","`7waxing crescent","`7waxing crescent","`7waxing crescent","`6half full","`6half full","`6half full","`6waxing gibbous","`6waxing gibbous","`6waxing gibbous","`6waxing gibbous","`^full","`^full","`^full","`^full","`6waning gibbous","`6waning gibbous","`6waning gibbous","`6waning gibbous","`6half full and waning","`6half full and waning","`6half full and waning","`6half full and waning","a `7waning crescent","`7waning crescent","`7waning crescent","`7waning crescent");
				output("`%'It is a `b%s Moon`b`%.'`n",$moonphased[$today]);
			}
			output("`n`#You look at `%o`^l`%d `%g`^y`%p`^s`%y `%w`^o`%m`^a`%n`# and start complaining to her.`n`n`@'THAT is your amazing deck?!? It tells me what kind of moon it is?!? This sucks!'`n`n");
			output("`#The `%g`^y`%p`^s`%y`# doesn't really seem to care, shrugs, and disappears into the `@forest`#.`n`n");
			$session['user']['specialinc']="";
			addnav("Back to the Forest","forest.php");
			addnews("%s`^ drew the `\$Moon Card`^.",$session['user']['name']);
		break;
		case 18:
			if (get_module_setting("usepics")==1) rawoutput("<br><center><table><tr><td align=center><img src=modules/deckofmanythings/dmtsun.jpg></td></tr></table></center><br>"); 
			rawoutput("<big>");
			output("`c`b`^The Sun`b`c");
			rawoutput("</big>");
			output("`n`nOut of nowhere, some `%music`^ starts to play.");
			output("You turn to see the `%g`^y`%p`^s`%y`^ standing before you with a `)top hat`^ on and a `&cane`^ in her hand.");
			output("Before you have a chance to escape, she starts dancing around you and singing...`n`n`%'The `^Sun`% will come out... Tomorrow! Bet your bottom `@dollar`% that Tomorrow, there'll be `^sun`%!'`n`n'Tomorrow! Tomorrow!");
			output("I love you! Tomorrow! You're only a Dayyyyyyyyy AAaaaaawwwwayyyyyyy!!'`n`n");
			output("`#Wow! That was some inspirational singing! You gain `@3 Extra turns`#!`n`n");
			$session['user']['turns']+=3;
			$session['user']['specialinc']="";
			addnav("Back to the Forest","forest.php");
			addnews("%s`^ drew the `\$Sun Card`^.",$session['user']['name']);
		break;
		case 19:
			if (get_module_setting("usepics")==1) rawoutput("<br><center><table><tr><td align=center><img src=modules/deckofmanythings/dmtjudgement.jpg></td></tr></table></center><br>"); 
			rawoutput("<big>");
			output("`c`b`^Judgement`b`c");
			rawoutput("</big>");
			output("`n`nYou suddenly find yourself standing in a courtroom full of `)crows`^.  You are going to be judged by the crows on your ability to tell a joke.`n`nWhich one will you tell?`n`n");
			output("`@1. The Crazy Patient`n`n`^2. Ducks and Elephants`n`n`\$3. The Hunchback and the Bell`n`n");
			addnav("`@1. The Crazy Patient","runmodule.php?module=deckofmanythings&op=deckjoke1");
			addnav("`^2. Ducks and Elephants","runmodule.php?module=deckofmanythings&op=deckjoke2");
			addnav("`\$3. The Hunchback and the Bell","runmodule.php?module=deckofmanythings&op=deckjoke3");
		break;
		case 20:
			if (get_module_setting("usepics")==1) rawoutput("<br><center><table><tr><td align=center><img src=modules/deckofmanythings/dmtinfinity.jpg></td></tr></table></center><br>"); 
			rawoutput("<big>");
			output("`c`b`^Infinity`b`c");
			rawoutput("</big>");
			output("`n`nThe `%o`^l`%d `%g`^y`%p`^s`%y `%w`^o`%m`^a`%n`^ looks at the card and starts to nod.`n`n`%'You may buy a `@W`^i`&s`%h for only `^1000 Gold`%.'`n`n");
			if ($session['user']['gold']<1000) {
				output("'Oh, I see you don't have `^1000 Gold`%.  That is sad. Your loss.  Well, the least I can do is give you a little something because I will take your wish.'`n`n");
				output("`^The `%g`^y`%p`^s`%y `^gives you `b1000 gold`b, `%1 gem`^, and a potion that gives you `&2 Charm`^.");
				$session['user']['gold']+=1000;
				$session['user']['gems']++;
				$session['user']['charm']+=2;
				$session['user']['specialinc']="";
				addnav("Back to the Forest","forest.php");
			}else{
				output("'Give me your `^Gold`% and you can make your wish.'`n`n");
				addnav("Make a `@W`^i`&s`%h","runmodule.php?module=deckofmanythings&op=deckwish");
				addnav("No thanks!","runmodule.php?module=deckofmanythings&op=deckleave");
			}
			addnews("%s`^ drew the `\$Infinity Card`^.",$session['user']['name']);
		break;
	}
}
if ($op=="gypsyattack"){
	output("Showing how brave you are, you decide to attack the `%o`^l`%d `%g`^y`%p`^s`%y `%w`^o`%m`^a`%n`#.");
	output("She looks at you stunned at the fact that you're drawing your weapon and getting ready to fight her.`n`n`%'Okay, we can fight.  No problem.  However, before we start, I get to cast a curse on you.'`n`n`#You suddenly realize that yes, that is one of the rules, so you");
	output("wait patiently for her to curse you.`n`nShe gives you one of the meanest hairiest eyeball `\$Evil Eyes`# you've ever seen and shiver as the curse takes hold of you.`n`n`%'There ya go! Let's Rumble!'`n`n");
	output("`3(Oh by the way, you `4lose 1/2 your hitpoints`3 just to make it a little more fair.)`n`n");	
	$session['user']['hitpoints']*=.5;
	apply_buff('evileye',array(
		"name"=>"`\$The EVIL Eye",
		"rounds"=>10,
		"wearoff"=>"`\$The Curse of the `%Gypsy`\$ wears off.",
		"atkmod"=>.9,
		"defmod"=>.9,
		"roundmsg"=>"`#That was ONE mean hairy eyeball `\$Evil Eye`# that Gypsy gave you!",
	));
	set_module_pref("monsternum",1);
	addnav("`%O`^l`%d G`^y`%p`^s`%y`\$ Fight!","runmodule.php?module=deckofmanythings&op=attack");
}
//from Darkhorse Tavern by Eric Stevens
if($op=="deckoracle"){
	$who = httpget('who');
	if ($who==""){
		output("`n`^'Who do you want to know about?'`n`n");
		$subop = httpget('subop');
		if ($subop!="search"){
			$search = translate_inline("Search");
			rawoutput("<form action='runmodule.php?module=deckofmanythings&op=deckoracle&subop=search' method='POST'><input name='name' id='name'><input type='submit' class='button' value='$search'></form>");
			addnav("","runmodule.php?module=deckofmanythings&op=deckoracle&subop=search");
			rawoutput("<script language='JavaScript'>document.getElementById('name').focus();</script>");
			addnav("Ask Again","runmodule.php?module=deckofmanythings&op=deckoracle");
		}else{
			addnav("Search Again","runmodule.php?module=deckofmanythings&op=deckoracle");
			$search = "%";
			$name = httppost('name');
			for ($i=0;$i<strlen($name);$i++){
			$search.=substr($name,$i,1)."%";
		}
		$sql = "SELECT name,alive,location,sex,level,laston,loggedin,login FROM " . db_prefix("accounts") . " WHERE (locked=0 AND name LIKE '$search') ORDER BY level DESC";
		$result = db_query($sql);
		$max = db_num_rows($result);
		if ($max > 100) {
			output("`n`n`7No.  That's too many names to pick from.  I'll let you choose from the first couple...`n");
			$max = 100;
		}
		$n = translate_inline("Name");
		$lev = translate_inline("Level");
		rawoutput("<table border=0 cellpadding=0><tr><td>$n</td><td>$lev</td></tr>");
		for ($i=0;$i<$max;$i++){
			$row = db_fetch_assoc($result);
			rawoutput("<tr><td><a href='runmodule.php?module=deckofmanythings&op=deckoracle&who=".rawurlencode($row['login'])."'>");
			output_notl("%s", $row['name']);
			rawoutput("</a></td><td>{$row['level']}</td></tr>");
			addnav("","runmodule.php?module=deckofmanythings&op=deckoracle&who=".rawurlencode($row['login']));
		}
		rawoutput("</table>");
		}
	}else{
		$sql = "SELECT name,acctid,alive,location,maxhitpoints,gold,gems,sex,level,weapon,armor,attack,race,defense FROM " . db_prefix("accounts") . " WHERE login='$who'";
		$result = db_query($sql);
		if (db_num_rows($result)>0){
			$row = db_fetch_assoc($result);
			$row = modulehook("adjuststats", $row);
			$name = $row['name'];
			output("`^The Oracle closes her eyes and starts to recite the following information:`n`n");
			output("`^`bName:`b`\$ %s`n", $row['name']);
			output("`^`bRace:`b`\$ %s`n",  translate_inline($row['race']));
			output("`^`bLevel:`b`\$ %s`n", $row['level']);
			output("`^`bHitpoints:`b`\$ %s`n", $row['maxhitpoints']);
			output("`^`bGold:`b`\$ %s`n", $row['gold']);
			output("`^`bGems:`b`\$ %s`n", $row['gems']);
			output("`^`bWeapon:`b`\$ %s`n", $row['weapon']);
			output("`^`bArmor:`b`\$ %s`n", $row['armor']);
			output("`^`bAttack:`b`\$ %s`n", $row['attack']);
			output("`^`bDefense:`b`\$ %s`n", $row['defense']);
			output("`n`n`#The `%o`^l`%d `%g`^y`%p`^s`%y `%w`^o`%m`^a`%n`# nods and pushes you back to the forest with her `qstick`#.  You turn to protest and suddenly she's gone.`n`n`n");
			debuglog("chose to learn about $name from the Oracle from the Deck of Many Things.");
			addnav("Back to the Forest","forest.php");
			$session['user']['specialinc']="";	
		}else{
			output("'`7Heh...  I don't know anyone named that.'");
			addnav("Back to the Forest","forest.php");
			$session['user']['specialinc']="";	
		}
	}
}
if ($op=="payment"){
	output("You decide you're more of a lover than a fighter and choose to spend quality time with the %s.  You give %s `b`^",($session['user']['sex']?"Incubus":"Succubus"),($session['user']['sex']?"him":"her"));
	if ($session['user']['gold']>=500) {
		output("500");
		$session['user']['gold']-=500;
	}else{
		output("All your");
		$session['user']['gold']=0;
	}
	output("gold`b`# and have a great time!`n`n`%");
	switch(e_rand(1,15)){
		case 1:
			output("You feel drained of energy!`#  You `\$Lose 1/2 of your Hitpoints`#!`n`n");
			output("That was a little disappointing.  You wander back into the `@forest`# trying to figure out what you did wrong.");
			$session['user']['hitpoints']*=0.5;
		break;
		case 2:
			output("Your senses are dulled.  `#You `&Lose One Defense Point`#!`n`n");
			output("That was a little disappointing.  You wander back into the `@forest`# trying to figure out what you did wrong.");
			$session['user']['defense']--;
		break;
		case 3:
			$expbonus=$session['user']['dragonkills']*3;
			$exploss =($session['user']['level']*e_rand(10,15)+$expbonus);
			if ($session['user']['experience']>=$exploss) {
				$session['user']['experience']-=$exploss;
				output("You feel out of shape. You `3Lose %s Experience`#!",$exploss);
			}else{
				$session['user']['experience']=0;
				output("You feel out of shape. `#You `3have Zero Experience`#!");
			}
			output("`n`nThat was a little disappointing.  You wander back into the `@forest`# trying to figure out what you did wrong.");		
		break;
		case 4:
			output("You are down in the dumps.`#`n`n");
			output("That was a little disappointing.  You wander back into the `@forest`# trying to figure out what you did wrong.");		
			apply_buff('depression',array(
				"name"=>"Depression",
				"rounds"=>10,
				"wearoff"=>"Your don't feel so sad anymore!",
				"atkmod"=>.96,
				"roundmsg"=>"You feel sad.",
			));
		break;
		case 5:
			output("You feel exhausted `#and `@Lose");
			if ($session['user']['turns']>1) {
				output("Two Turns.");
				$session['user']['turns']-=2;
			}else{
				output("One Turn.");
				$session['user']['turns']--;	
			}
			output("`#`n`nThat was a little disappointing.  You wander back into the `@forest`# trying to figure out what you did wrong.");
		break;
		case 6: case 7:
			output("You feel restored to health!`#");
			output("`n`nYou wander back to `@the forest`# with a smile on your face.");
			$session['user']['hitpoints']=$session['user']['maxhitpoints'];
		break;
		case 8: case 9:
			output("You feel raised to your full potential!`#  You `&Gain 1 Attack`# and`& 1 Defense`#!");
			$session['user']['defense']++;
			$session['user']['attack']++;
			output("`n`nYou wander back to `@the forest`# with a smile on your face.");
		break;
		case 10: case 11:
			output("You feel good enough to do it again! `# The `\$%s`# shakes %s head and grins. `n`n`\$'Oh no, you only get one time!'`n`n",($session['user']['sex']?"Incubus":"Succubus"),($session['user']['sex']?"him":"her"));
			output("`#You `@Gain 3 Extra Turns`# and get your `^500 gold`# back!!");
			$session['user']['turns']+=3;
			$session['user']['gold']+=500;
			output("`n`nYou wander back to `@the forest`# with a smile on your face.");
		break;
		case 12: case 13:
			output ("That was a very educational experience.`#`n`n");
			$expbonus=$session['user']['dragonkills']*4;
			$expgain =($session['user']['level']*e_rand(20,30)+$expbonus);
			$session['user']['experience']+=$expgain;
			output("You gain `b%s experience`b.",$expgain);
			output("`n`nYou wander back to `@the forest`# with a smile on your face.");
		break;
		case 14: case 15:
			output("You will always remember the `\$%s`%...",($session['user']['sex']?"Incubus":"Succubus"));
			output("`n`n`#You wander back to `@the forest`# with a smile on your face, with a new `&Buff`# to help you along.");
			apply_buff('fondmemory',array(
				"name"=>"Fond Memories",
				"rounds"=>20,
				"wearoff"=>"`#Your happy memory fades a little.",
				"atkmod"=>1.1,
			));
		break;
	}	
	output("`n`n`n");
	$session['user']['specialinc']="";	
	addnav("Back to the Forest","forest.php");	
}
if ($op=="deckwheel"){
	output("`c`!<click>`#<click>`%<click>`\$<click>`Q<click>`^<click>`@<click>`)<click>`c");
	switch(e_rand(1,9)){
		case 1:	
			output("`c`!<click>`#<click>`%<click>`\$<click>`Q<click>`^<click>`@<click>`n");
			output("`!<click>`#<click>`%<click>`\$<click>`Q<click>`^<click>`n");
			output("`!<click>`#<click>`%<click>`\$<click>`Q<click>`n");
			output("`!<click>`#<click>`%<click>`\$<click>`n");
			output("`!<click>`#<click>`%<click>`n");
			output("`!<click>`#<click>`n");
			output("`!<click>`n`n");
			output("`bHealth!`b`c`n");
			if (is_module_active('potions') && get_module_pref('potion','potions')<5){
				set_module_pref('potion', 5, 'potions');
				output("You notice your backpack is filled with healing potions!");
				debuglog("gained maximum healing potions from the Deck of Many Things.");
			}elseif (get_module_setting("givepermhp")==1) {
				output("You gain `\$A Permanent Hitpoint`! and `\$you are restored to full health`!!");
				$session['user']['maxhitpoints']++;
				$session['user']['hitpoints']=$session['user']['maxhitpoints'];
				debuglog("received 1 Permanent Hitpoint from the Deck of Many Things.");
			}else{
				output("You gain `\$20 Hitpoints`^!`n`n`n");
				$session['user']['hitpoints']=$session['user']['maxhitpoints']+20;
				debuglog("received 20 temp hitpoints from the Deck of Many Things.");	
			}
		break;
		case 2:
			output("`c`)<click>`!<click>`#<click>`%<click>`\$<click>`Q<click>`^<click>`n");
			output("`@<click>`)<click>`!<click>`#<click>`%<click>`\$<click>`n");
			output("`^<click>`@<click>`)<click>`!<click>`#<click>`n");
			output("`Q<click>`^<click>`@<click>`)<click>`n");
			output("`\$<click>`Q<click>`^<click>`n");
			output("`%<click>`\$<click>`n");
			output("`#<click>`n`n");
			output("`bFear!`b`c`n");
			output("A deep `\$shiver`# runs through you and you start to notice the `)shadows`# are creeping in all around you.`n`nThis is going to be
				a `\$s`)c`#a`\$r`)y`# day for you!");
			apply_buff('fear',array(
				"name"=>"`#F`)e`\$a`#r",
				"rounds"=>50,
				"wearoff"=>"`#Your fears are alleviated.",
				"atkmod"=>.90,
				"defmod"=>.90,
				"roundmsg"=>"`#Your attack is less affective because you're afraid you'll hurt yourself.",
			));
			debuglog("became terrified with a fear buff from the Deck of Many Things.");
		break;
		case 3:
			output("`c`!<click>`\$<click>`@<click>`#<click>`Q<click>`)<click>`%<click>`n");
			output("`^<click>`!<click>`\$<click>`@<click>`#<click>`Q<click>`n");
			output("`)<click>`%<click>`^<click>`!<click>`\$<click>`n");
			output("`@<click>`#<click>`Q<click>`)<click>`n");
			output("`%<click>`^<click>`!<click>`n");
			output("`\$<click>`@<click>`n");
			output("`%<click>`n`n");
			output("`bFriendship!`b`c`n");
			if ($session['user']['sex']==0){
				output("Since a `qdog`% is man's best friend, you get a little puppy to help you out for a little while!");
				apply_buff('wizardminions', array(
					"startmsg"=>"`qYour best friend fights by your side!",
					"name"=>"`%Little `qDog",
					"rounds"=>25,
					"minioncount"=>1,
					"minbadguydamage"=>3,
					"maxbadguydamage"=>3+$session['user']['level'],
					"effectmsg"=>"`%The Little Dog takes a Big Bite out of crime and does {damage} damage!",
				));
				debuglog("received the help of a little dog from the Deck of Many Things.");
			}else{
				output("Since `&Diamonds`% are a girl's best friend, you find yourself holding `b5 Gems`b!");
				$session['user']['gems']+=5;
				debuglog("received 5 gems from the Deck of Many Things.");
			}	
		break;
		case 4:
			output("`c`!<click>`#<click>`%<click>`\$<click>`Q<click>`^<click>`@<click>`n");
			output("`)<click>`!<click>`#<click>`%<click>`\$<click>`Q<click>`n");
			output("`^<click>`@<click>`)<click>`!<click>`#<click>`n");
			output("`%<click>`\$<click>`Q<click>`^<click>`n");
			output("`@<click>`)<click>`!<click>`n");
			output("`#<click>`%<click>`n");
			output("`\$<click>`n`n");
			output("`bPain!`b`c`n");
			output("A sudden shock from the card shoots out at you.  Excruciating unbearable pain that you've never dreamed of before courses through your body.`n`nYou");
			if (get_module_setting("givepermhp")==1 && ($session['user']['maxhitpoints']>($session['user']['level']*11)+10)) {
				output("lose `b5 Permanent Hitpoints`b.  You also ");
				$session['user']['maxhitpoints']-=5;
				debuglog("lost 5 maxhitpoints and all hitpoints except 1 for the next 10 days from the Deck of Many Things.");
			}	
			output("lose all your hitpoints except 1.  For the next 10 days the aching memory will cause you to start each day with only 1 hitpoint.");
			set_module_pref("deckpain",10);
			$session['user']['hitpoints']=1;
			debuglog("lost all hitpoints except 1 for the next 10 days from the Deck of Many Things.");
		break;
		case 5:
			output("`c`#<click>`%<click>`\$<click>`Q<click>`^<click>`@<click>`)<click>`n");
			output("`\$<click>`Q<click>`^<click>`@<click>`)<click>`!<click>`n");
			output("`@<click>`)<click>`!<click>`#<click>`%<click>`n");
			output("`%<click>`\$<click>`Q<click>`^<click>`n");
			output("`)<click>`!<click>`#<click>`n");
			output("`^<click> `@<click>`n");
			output("`Q<click>`n`n");
			output("`bBeauty!`b`c`n");
			output("The `%o`^l`%d `%g`^y`%p`^s`%y `%w`^o`%m`^a`%n`Q looks around for any witnesses.  She takes out her `qstick`Q and hits you `\$Hard`Q on the head!  In fact, it costs you `\$1/2 of your
				hitpoints`Q!`n`n");
			output("You look at her and get ready to beat her silly, but notice that actually, you are looking good! She smiles.`n`n`%'You're lucky I decided to
				hit you with my pretty stick.'`n`n`QYou gain `&4 Charm`Q!");
			$session['user']['charm']+=4;
			$session['user']['hitpoints']=round($session['user']['hitpoints']*.5);
			debuglog("lost 1/2 hitpoints and 4 charm points from the Deck of Many Things.");
		break;
		case 6:
			output("`c`!<click>`\$<click>`@<click>`#<click>`Q<click>`)<click>`%<click>`n");
			output("`^<click>`!<click>`\$<click>`@<click>`#<click>`Q<click>`n");
			output("`)<click>`%<click>`^<click>`!<click>`\$<click>`n");
			output("`@<click>`#<click>`Q<click>`)<click>`n");
			output("`%<click>`^<click>`!<click>`n");
			output("`\$<click>`@<click>`n");
			output("`6<click>`n`n");
			output("`bSkill!`b`c`n");
			output("The `bSpecialty Fairy`b comes flying around and touches you on the nose!`n`nYou Advance in your Specialty.");
			increment_specialty("`6");
			debuglog("incremented their specialty from the Deck of Many Things.");
		break;
		case 7:
			output("`c`!<click>`\$<click>`@<click>`#<click>`Q<click>`)<click>`%<click>`n");
			output("`^<click>`!<click>`\$<click>`@<click>`#<click>`Q<click>`n");
			output("`)<click>`%<click>`^<click>`!<click>`\$<click>`n");
			output("`@<click>`#<click>`Q<click>`)<click>`n");
			output("`%<click>`^<click>`!<click>`n");
			output("`\$<click>`@<click>`n");
			output("`^<click>`n`n");
			output("`bWealth!`b`c`n");
			output("You receive");
			if ($session['user']['gold']==0) {
				output("1,000,000");
			}elseif($session['user']['gold']<=100){
				output("20");
				$session['user']['gold']*=20;
			}elseif($session['user']['gold']<=1000){
				output("3");
				$session['user']['gold']*=3;
			}else{
				output("2");
				$session['user']['gold']*=2;
			}
			output("times your current amount of gold!!!");	
		break;
		case 8:
			output("`c`%<click>`\$<click>`Q<click>`^<click>`@<click>`)<click>`!<click>`n");
			output("`Q<click>`^<click>`@<click>`)<click>`!<click>`#<click>`n");
			output("`@<click>`)<click>`!<click>`#<click>`%<click>`n");
			output("`!<click>`#<click>`%<click>`\$<click>`n");
			output("`%<click>`\$<click>`Q<click>`n");
			output("`Q<click>`^<click>`n");
			output("`@<click>`n`n");
			output("`bEnergy!`b`c`n");
			output("A blinding `&L`^i`&g`^h`&t`@ pulses out of the Wheel of Fortune. Soon enough, you're engulfed by the `&l`^i`&g`^h`&t`@.  Covering your eyes doesn't help!`n`n
				The `&l`^i`&g`^h`&t`@ fades as you notice a glow spreads across your weapon and your armor.`n`nYou can `b5 extra turns`b!");
			$session['user']['weapon']="`b`&Bright`b ".$session['user']['weapon'];
			$session['user']['armor']="`b`&Bright`b ".$session['user']['armor'];
			$session['user']['turns']+=5;
		break;
		case 9:
			output("`c`#<click>`%<click>`\$<click>`Q<click>`^<click>`@<click>`)<click>`n");
			output("`%<click>`\$<click>`Q<click>`^<click>`@<click>`)<click>`n");
			output("`\$<click>`Q<click>`^<click>`@<click>`)<click>`n");
			output("`Q<click>`^<click>`@<click>`)<click>`n");
			output("`^<click>`@<click>`)<click>`n");
			output("`@<click>`)<click>`n");
			output("`)<click>`n`n");
			output("Death!`b`c`n");
		   $exploss = round($session['user']['experience']*.05);
			output("`b`) You lose `#%s experience`).`n`n",$exploss);
			output("You lose all your `^gold`) and `@1/4 of your remaining turns`).`n");
			output("`c`b`n`@You are `\$MOSTLY dead`@... Which means you're still really alive.`b`c");
			addnews("%s `@was rendered `\$MOSTLY dead...`@ by the `^Deck `\$of `^Many Things",$session['user']['name']);
			$session['user']['experience']-=$exploss;
			$session['user']['hitpoints']=1;
			$session['user']['gold']=0;
			$session['user']['turns']=round($session['user']['turns']*.75);
		break;
	}
	output("`n`n`#The `%o`^l`%d `%g`^y`%p`^s`%y `%w`^o`%m`^a`%n`# looks at you and shrugs, pokes you with her `qstick`#, and disappears into the `@forest.`n`n");
	$session['user']['specialinc']="";
	addnav("Back to the Forest","forest.php");
	addnews("%s`^ drew the `\$Wheel of Fortune Card`^.",$session['user']['name']);
}
if ($op=="deckslayer"){
	$newtitle = "`b`\$Slayer`b";
	$newname = change_player_title($newtitle);
	$session['user']['title'] = $newtitle;
	$session['user']['name'] = $newname;
	$session['user']['specialinc'] = "";
	output("You carry your new title with pride and return to the `@forest`# looking for more adventure.`n`n");
	addnav("Back to the Forest","forest.php");
}
if ($op=="decktower"){
	output("It seems like a never ending walk up the stairs to the tower, but you persevere.");
	output("`n`nAt the top is a tall door with ancient words written across the header:`n`n`c`b`qSanctum `)of `qStrigoi`c`b`n`#");
	output("You decide maybe it's not a good idea to enter and as you're about to turn to leave, the door creaks open with an unlikely sense of timing that makes you sure that it is not accidental. You feel a breath of wind");
	output("across your neck... or was that wings?`n`n");
	addnav("Continue","runmodule.php?module=deckofmanythings&op=decktencounter");
}
if ($op=="decktencounter"){
	output("A voice behind you speaks into your ear.`n`n`Q'Why would you enter my house?  Do you wish to steal from me? Or perhaps to murder me while I sleep?  Strange, I do not see a wooden stake in your hands.  How do you plan");
	output("on defeating me?'`n`n`#You turn to find yourself standing before a creature dressed in black.  A cloak hangs from his shoulders giving him the appearance of wings.  An `\$o`Qr`^n`@a`#t`!e`# necklace fastens the cloak around his neck.`n`nThen as you stare at the man,");
	output("clarity dawns upon you.   Before you stands one of the darkest creatures to curse the land.  You have brought upon the kingdom a `\$V`Qa`\$m`Qp`\$i`Qr`\$e`#!");
	set_module_pref("monsternum",6);
	addnav("Fight the `\$V`Qa`\$m`Qp`\$i`Qr`\$e","runmodule.php?module=deckofmanythings&op=attack");	
}
if ($op=="deckjoke1"){
	output("`n`#You begin the joke with the best of your skills...`n`n`@Okay, so this man walks into his psychiatrist's office.  He sits down at the desk of the psychiatrist and starts to list his problems.`n`n");
	output("`6'I'm a Teepee.'`n`n'I'm a Wigwam.'`n`n'I'm a Teepee.'`n`n'I'm a Wigman.'`n`n`@The	psychiatrist stops the man and says `5'I think I can help you.  I know what your problem is.'`n`n`6'What is is doc?'`n`n`5'You're too tense!'");
	addnav("Continue","runmodule.php?module=deckofmanythings&op=deckjokeend");
}
if ($op=="deckjoke2"){
	output("`n`#You begin the joke with the best of your skills...`n`n`@Why do ducks have webbed feet?`n`&To stamp out fires.`n`n`@Why do elephants have flat feet?`n`&To stamp out burning ducks!");
	addnav("Continue","runmodule.php?module=deckofmanythings&op=deckjokeend");
}
if ($op=="deckjoke3"){
	output("`n`#You begin the joke with the best of your skills...`n`n`@The local church looks to hire a new Bell Ringer.  A `Qhunchback`@ applies and is warned of the dangers involved in the job - mainly, that of slipping and falling to one's ");
	output("death while bell ringing. `n`nThe applicant seems unimpressed by this, and explains that he comes from a long line of bell ringers, and that his family uses a special bell ringing technique. The priest, eager to see this, asks him to ");
	output("audition. `n`nThe `Qhunchback`@ goes up to a large bell perched high in the tower, pulls it towards him, and smashes his forehead into it to make it sound. Dazed from the impact, he stumbles and falls from the tower to his death below.");
	output("`n`n The priest climbs down to find a crowd gathered and a policeman who says, `%'I see a hunchback fell from your bell tower - do you know who he is?' `@The priest replies, `^'No, but his face rings a bell ...'");
	addnav("Continue","runmodule.php?module=deckofmanythings&op=deckjokeend");
}
if ($op=="deckjokeend"){
	output("`n`#The `)crows `#don't respond for what seems like eternity.`n`n");
	switch(e_rand(1,3)){
		case 1:	
			output("Suddenly, the `)crows`# start laughing uncontrollably.  You feel elated by their laughter and you gain `@4 extra turns`#!`n`n");
			$session['user']['turns']+=4;
		break;
		case 2:
			output("A couple of `)crows`# laugh politely, but, to be honest, your joke really didn't tickle their funny bones.  They dismiss you and send you on your way back to the `@forest`#.");
		break;
		case 3:
			output("`@Crickets`# start to chirp.  The `%o`^l`%d `%g`^y`%p`^s`%y `%w`^o`%m`^a`%n`# loses consciousness.`n`nThe `)crows`# were not impressed.  You find yourself depressed and");
			if ($session['user']['turns']>2) {
				output("you `@Lose Two Turns`#.");
				$session['user']['turns']-=2;
			}else{
				output("you `@Lose All your remaining turns`#.");	
				$session['user']['turns']=0;
			}
		break;
	}
	output("`n`n");
	$session['user']['specialinc'] = "";
	addnav("Back to the Forest","forest.php");
	addnews("%s`^ drew the `\$Judgement Card`^.",$session['user']['name']);
}
if ($op=="deckwish"){
	$session['user']['gold']-=1000;
	output("`%'Okay, what would you like to `@w`^i`&s`%h for?'`n`n");
	output("`^1.  15,000 Gold`n`%2. 30 Gems`n`@3. 10 Extra Turns`n`#4. Invulnerability for 20 Rounds`&`n5. An Experience Boon`n`Q6. 12 Charm`n");
	addnav("`^1. Gold","runmodule.php?module=deckofmanythings&op=deckwgold");
	addnav("`%2. Gems","runmodule.php?module=deckofmanythings&op=deckwgems");
	addnav("`@3. Turns","runmodule.php?module=deckofmanythings&op=deckwturns");
	addnav("`#4. Invulnerability","runmodule.php?module=deckofmanythings&op=deckwinvul");
	addnav("`&5. Experience","runmodule.php?module=deckofmanythings&op=deckwexp");	
	addnav("`Q6. Charm","runmodule.php?module=deckofmanythings&op=deckwcharm");	
	if (get_module_setting("givepermhp")==1){
		output("`\$7. 8 Permanent Hitpoints");
		addnav("`\$7. Permanent Hitpoints","runmodule.php?module=deckofmanythings&op=deckwpermhp");
	}	
}
if ($op=="deckwgold"){
	output("Before you even speak your wish, `^15,000 Gold`# appears at your feet. `n`nWith a wicked grin, you collect it all and wave to the `%g`^y`%p`^s`%y`# as you go to the bank!`n`n");
	$session['user']['gold']+=15000;
	$session['user']['specialinc'] = "";
	debuglog("wished for 15,000 gold from the Deck of Many Things.");
	addnav("Back to the Forest","forest.php");
}
if ($op=="deckwgems"){
	output("Before you even speak your wish, `%30 Gems`# appears at your feet. `n`nWith a wicked grin, you collect it all and wave to the `%g`^y`%p`^s`%y`# as you go to the bank!`n`n");
	$session['user']['gems']+=30;
	$session['user']['specialinc'] = "";
	debuglog("wished for 30 gems from the Deck of Many Things.");
	addnav("Back to the Forest","forest.php");
}
if ($op=="deckwturns"){
	output("Before you even speak your wish, you feel a surge of energy throughout your body. You gain `@10 turns`#.`n`nWith a wicked grin, wave to the `%g`^y`%p`^s`%y`# as you head back to the `@forest`#!`n`n");
	$session['user']['turns']+=10;
	$session['user']['specialinc'] = "";	
	debuglog("wished for 10 extra turns from the Deck of Many Things.");
	addnav("Back to the Forest","forest.php");
}
if ($op=="deckwinvul"){
	output("Before you even speak your wish, you realize that NOBODY can touch you. You develop that flashy transparency that characters get in video games when they are invincible.  `n`nWith a wicked grin, you wave to the `%g`^y`%p`^s`%y`# as you head back to the `@forest`#!`n`n");
	apply_buff('invulnerability', array(
		"name"=>"`#Invulnerability",
		"rounds"=>20,
		"invulnerable"=>1,
		"roundmsg"=>"`#You are Invulnerable.  Nothing can touch you.",
		"wearoff"=>"`#You stop having that strange transparency.  Watch out! You are no longer Invulnerable.",
	));
	$session['user']['specialinc'] = "";
	debuglog("wished for 20 turns of invulnerability from the Deck of Many Things.");
	addnav("Back to the Forest","forest.php");
}
if ($op=="deckwexp"){
	$expgain =($session['user']['level']*120+$session['user']['dragonkills']*10);
	$session['user']['experience']+=$expgain;
	output("Before you even speak your wish, you feel the flush of learning run through your body as you gain `b%s experience`b.`n`nWith a wicked grin, you wave to the `%g`^y`%p`^s`%y`# as you go to train!`n`n",$expgain);
	$session['user']['specialinc'] = "";
	debuglog("wished for $expgain experience from the Deck of Many Things.");
	addnav("Back to the Forest","forest.php");
}
if ($op=="deckwcharm"){
	output("Before you even speak your wish, you turn much more `QCharming by 12`#! `n`nWith a wave to the `%g`^y`%p`^s`%y`# as you go to strut around in the Village!`n`n");
	$session['user']['charm']+=12;
	$session['user']['specialinc'] = "";
	debuglog("wished for 12 charm from the Deck of Many Things.");
	addnav("Back to the Forest","forest.php");
}
if ($op=="deckwpermhp"){
	output("Before you even speak your wish, you feel your body become tougher. `n`nWith a wave to the `%g`^y`%p`^s`%y`# as you go back to the `@forest`#!`n`n");
	$session['user']['maxhitpoints']+=8;
	$session['user']['specialinc'] = "";
	debuglog("wished for 8 permanent hitpoints from the Deck of Many Things.");	
	addnav("Back to the Forest","forest.php");
}
if ($op=="exitstageleft"){
	$penavt=get_module_setting("penavt");
	$penavg=get_module_setting("penavg");
	$penavge=get_module_setting("penavge");
	output("You look at the `\$Deck `^of `\$Cards`#, then at the `%o`^l`%d `%g`^y`%p`^s`%y `%w`^o`%m`^a`%n`#.");
	output("You pretend to look at your wrist watch `3(which, since wrist watches haven't been invented yet, makes you look a tad foolish)`# and try to stammer some excuse as to why you need to leave.`n`n");
	output("After mumbling something about going to feed a parking meter `3(which once again doesn't make any sense for the same reason that looking at a non-existent wrist watch doesn't)`# the old `%g`^y`%p`^s`%y`# woman rolls her eyes and pokes you with her `qstick`# one last time before you go.`n`n");
	if ($penavt>0 && $session['user']['turns']>0){
		if ($session['user']['turns']>$penavt) {
			output("You `@lose %s turn%s`#",$penavt,translate_inline($penavt>1?"s":""));
			$session['user']['turns']-=$penavt;
		}else{
			output("You `@lose all your remaining turns`#");	
			$session['user']['turns']=0;
		}
		output("for wasting her time and for being so boring and not doing anything.`n`n");	
	}
	if ($penavg>0 && $session['user']['gold']>0){
		if ($penavg==1) $gold=100;
		if ($penavg==2) $gold=500;
		if ($penavg==3) $gold=1000;
		if ($penavg<=3){
			output("As you slink off to the forest, you notice that the darn gypsy stole ");
			if ($session['user']['gold']>$gold) {
				output("`^%s gold`# from you!`n`n",$gold);
				$session['user']['gold']-=$gold;
			}else{
				output("`^all your gold`# from you!`n`n");
				$session['user']['gold']=0;
			}
		}else{
			if ($penavg==4) $mult=.1;
			if ($penavg==5) $mult=.25;
			if ($penavg==6) $mult=.5;
			output("As you slink off to the forest, you notice that the darn gypsy stole");
			if ($penavg<7){
				output("`^%s gold`# from you!`n`n",round($session['user']['gold']*$mult));
				$session['user']['gold']-=round($session['user']['gold']*$mult);
			}else{
				output("`^all your gold`# from you!`n`n");
				$session['user']['gold']=0;
			}
		}
	}
	if ($penavge>0 && $session['user']['gems']>0){
		output("Happily being away from that whole fiasco, you check your `%gem`# sack and notice that she robbed you of your `%gems`#!!!`n`n");
		if ($session['user']['gems']>$penavge) {
			output("You `%lose %s gem%s`#.",$penavge,translate_inline($penavge>1?"s":""));
			$session['user']['gems']-=$penavge;
		}else{
			output("You `%lose all your remaining gems`#.");	
			$session['user']['gems']=0;
		}
	}
	$session['user']['specialinc']="";
	addnav("Back to the Forest","forest.php");
}
if ($op=="deckleave"){
	output("You return to the forest looking for further adventures.");
	$session['user']['specialinc'] = "";
	addnav("Back to the Forest","forest.php");
}
if ($op=="attack") {
	if (get_module_pref("monsternum")==1){
		$badguy = array(
			"creaturename"=>"The `%O`^l`%d `%G`^y`%p`^s`%y `%W`^o`%m`^a`%n`#",
			"creaturelevel"=>$session['user']['level']+1,
			"creatureweapon"=>"her `#Stupid `qStick",
			"creatureattack"=>round($session['user']['attack'])+2,
			"creaturedefense"=>round($session['user']['defense'])+2,
			"creaturehealth"=>round($session['user']['hitpoints']),
			"diddamage"=>0,
			"type"=>"oldgypsy");
		$session['user']['badguy']=createstring($badguy);
	}
	if (get_module_pref("monsternum")==2){
		$badguy = array(
			"creaturename"=>"`!The Wizard of Yendor",
			"creaturelevel"=>$session['user']['level'],
			"creatureweapon"=>"the `&Book`) of `&the `)Dead",
			"creatureattack"=>$session['user']['attack']+1,
			"creaturedefense"=>$session['user']['defense']+1,
			"creaturehealth"=>$session['user']['maxhitpoints'],
			"diddamage"=>0,
			"type"=>"wizardyendor");
		$session['user']['badguy']=createstring($badguy);
	}
	if (get_module_pref("monsternum")==3){
		$monster = translate_inline($session['user']['sex']?"`\$the Incubus" : "`\$the Succubus"); 
		$badguy = array(
			"creaturename"=>$monster,
			"creaturelevel"=>$session['user']['level'],
			"creatureweapon"=>"powers of seduction",
			"creatureattack"=>round($session['user']['attack']*.9),
			"creaturedefense"=>1,
			"creaturehealth"=>round($session['user']['maxhitpoints']*1.6),
			"diddamage"=>0,
			"type"=>"foocubus");
		$session['user']['badguy']=createstring($badguy);
	}
	if (get_module_pref("monsternum")==4){
		$dkb = round($session['user']['dragonkills']*.15);
		$badguy = array(
			"creaturename"=>"Erinys",
			"creaturelevel"=> $session['user']['level'],
			"creatureweapon"=>"painful blows",
			"creatureattack"=>round($session['user']['attack']*.9),
			"creaturedefense"=>round($session['user']['defense']*.9),
			"creaturehealth"=>round($session['user']['maxhitpoints']*1.3),
			"diddamage"=>0,
			"type"=>"erinys");
		apply_buff('vengeance', array(
			"startmsg"=>"`&I will strike down upon thee with great vengeance and furious anger!`n",
			"name"=>"`4Fury",
			"rounds"=>1,
			"minioncount"=>1+$dkb,
			"mingoodguydamage"=>1,
			"maxgoodguydamage"=>1+$dkb,
			"effectmsg"=>"`&L`^i`&ght`^`&`^n`&i`^n`&g bolts of Vengeance strike you for `\${damage}`) hitpoints`^.",
		));
		$session['user']['badguy']=createstring($badguy);
	}
	if (get_module_pref("monsternum")==5){
		if ($session['user']['maxhitpoints']<150) $hitpoints=150;
		else ($hitpoints=$session['user']['maxhitpoints']);
		$badguy = array(
			"creaturename"=>"`\$`bAsmodeus`b",
			"creaturelevel"=>$session['user']['level']+1,
			"creatureweapon"=>"`b`\$Pain`b",
			"creatureattack"=>round($session['user']['attack']*1.5)+1,
			"creaturedefense"=>round($session['user']['defense']*1.5)+1,
			"creaturehealth"=>round($hitpoints*1.5),
			"diddamage"=>0,
			"type"=>"asmodeus");
		$session['user']['badguy']=createstring($badguy);
	}
	if (get_module_pref("monsternum")==6){
		$badguy = array(
			"creaturename"=>"`\$V`Qa`\$m`Qp`\$i`Qr`\$e",
			"creaturelevel"=>$session['user']['level']+1,
			"creatureweapon"=>"blood dripping fingernails",
			"creatureattack"=>$session['user']['attack'],
			"creaturedefense"=>$session['user']['defense']-1,
			"creaturehealth"=>round($session['user']['maxhitpoints']*.97),
			"diddamage"=>0,
			"type"=>"thevampire");
		$session['user']['badguy']=createstring($badguy);
	}
	$op="fight";
}
if ($op=="fight"){
	if (get_module_pref("monsternum")==2 ||get_module_pref("monsternum")==3 || get_module_pref("monsternum")==6){
		blocknav("runmodule.php?module=deckofmanythings&op=fight&auto=five");
		blocknav("runmodule.php?module=deckofmanythings&op=fight&auto=ten");
		blocknav("runmodule.php?module=deckofmanythings&op=fight&auto=full");
	}
	if (get_module_pref("monsternum")==2){
		$yendor=array("So thou thought though couldst destroy me, fool...","Hell shall soon claim thy remains!","I chortle at thee, thou art pathetic!","Prepare to die, thou!","Resistance is useless!","Surrender or die, thou!","There shall be no mercy, thou!","Thou shalt repent of thy cunning!","Thou art as a flea to me!","Thou art doomed!","Thy fate is sealed!","Verily, thou shalt be one dead!","Even now thy life force ebbs!","Relinquish the Amulet!");
		$phrase=e_rand(0,13);
		output("`c`i`b`!The Wizard Cries out `@'%s'`i`c`b`n",$yendor[$phrase]);
		if ($phrase==1 || $phrase==2 ||$phrase==3 || $phase==4){
			apply_buff('wizardminions', array(
			"startmsg"=>"`5The `!Wizard `5casts a spell and calls forth some help!",
				"name"=>"`%Evil `\$Minion",
				"rounds"=>1,
				"minioncount"=>1,
				"mingoodguydamage"=>1,
				"maxgoodguydamage"=>10,
				"effectmsg"=>"`%The `!Wizard's `\$Minon `%hits you! You take `\${damage}`% hitpoints`%.`nThe `\$Minion `%dissipates.",
			));
		}
	}
	if (get_module_pref("monsternum")==3 && get_module_pref("deckseduced")==0){
		$monster = translate_inline($session['user']['sex']?"Incubus" : "Succubus"); 
		rawoutput("<big>");
		output("`b`&The `\$%s `&tries to seduce you...`b",($session['user']['sex']?"Incubus":"Succubus"));
		rawoutput("</big>");
		$phrase=e_rand(1,6);
		if ($phrase==1 && $session['user']['armordef']>1){
			output("`\$and %s suggests that you `#remove your armor`\$.  You realize that this is a great idea and you do.`n`n `b `&You'll have to fight the rest of this fight in your `^T-Shirt`&!`b`n`n`n`n",translate_inline($session['user']['sex']?"he":"she"));
			set_module_pref("deckseduced",1);
			set_module_pref("decktempdefense",$session['user']['armordef']);
			set_module_pref("decktemparmor",$session['user']['armor']);
			$session['user']['defense']-=$session['user']['armordef']+1;
			$session['user']['armordef'] = 1;
			$session['user']['armor']="T-Shirt";
		}elseif($phrase==3){
			output("`n`nYou stop and consider %s offer. If you'd like, you could stop this fighting and spend some quality time with the %s. `0(That is, if you haven't already died or killed %s.)`n`n",($session['user']['sex']?"his":"her"),($session['user']['sex']?"Incubus":"Succubus"),($session['user']['sex']?"him":"her"));
			addnav(array("`0Spend Quality time with the %s",translate_inline($session['user']['sex']?"Incubus":"Succubus")),"runmodule.php?module=deckofmanythings&op=payment");
		}else{
			output("`%but you are not seduced by such `\$Evils`%!`n`n");
		}
	}
	if (get_module_pref("monsternum")==6){
		$bite=e_rand(1,5);
		$damage=round($session['user']['level']*.5);
		if ($bite==5){
			apply_buff('vampiredrain', array(
				"startmsg"=>"`QThe Vampire gets close enough to bite you!",
				"name"=>"Vampire Bite",
				"rounds"=>1,
				"minioncount"=>1,
				"mingoodguydamage"=>$damage,
				"maxgoodguydamage"=>$damage,
				"effectmsg"=>"`QYou are drained for `\${damage} hitpoints`Q while the Vampire gains that many!",
			));
			apply_buff('vampiregain', array(
				"name"=>"Vampire Bite",
				"rounds"=>1,
				"minioncount"=>1,
				"minbadguydamage"=>-$damage,
				"maxbadguydamage"=>-$damage,
			));
		}
	}
	$battle = true;
}
if ($battle){       
	include("battle.php");
	$monster = translate_inline($session['user']['sex']?"Incubus" : "Succubus"); 
	if ($victory){
		if (get_module_pref("monsternum")==1){
			output("`n`#Well, I have to admit, you did a good job beating up an old lady.  But hey, that's cool.`n`n");
			$expbonus=$session['user']['dragonkills']*4;
			$expgain =($session['user']['level']*e_rand(40,45)+$expbonus);
			$session['user']['experience']+=$expgain;
			output("`@You gain `#%s experience`@.`n",$expgain);
			$goldgain= e_rand(2,5)*400;
			$gemgain=e_rand(1,4);
			$session['user']['gold']+=$goldgain;
			$session['user']['gems']+=$gemgain;
			output("`@You gain `^%s Gold`@ and `%%s Gems`@.`n`n",$goldgain,$gemgain);
			addnews("%s`# killed an `%o`^l`%d `%g`^y`%p`^s`%y `%w`^o`%m`^a`%n`# that just wanted to play cards.",$session['user']['name']);
			$session['user']['specialinc'] = "";
			debuglog("defeated the Old Gypsy Woman with the Deck of Many Things.");
			addnav("Back to the Forest","forest.php");
		}
		if (get_module_pref("monsternum")==2){
			output("`n`^You've killed the Wizard of Yendor!`n`n");
			$expbonus=$session['user']['dragonkills']*5;
			$expgain =($session['user']['level']*e_rand(45,60)+$expbonus);
			$session['user']['experience']+=$expgain;
			output("`@You gain `#%s experience`@.`n`n",$expgain);
			output("`^You search through the remains and find a very strange book.  When you pick it up, it `\$burns your fingers`^!`n`n You recover close from death, but your `\$hitpoints are reduced to 1`^. You were lucky as you notice the title is `HBook of the Dead`H`^.`n`n");
			output("`#The `%o`^l`%d `%g`^y`%p`^s`%y `%w`^o`%m`^a`%n`# looks at you and shrugs, pokes you with her `qstick`#, and disappears into the `@forest.`n`n");
			$session['user']['hitpoints']=1;
			$session['user']['specialinc'] = "";
			addnews("%s`^ drew the `\$Magician Card`^.",$session['user']['name']);
			debuglog("defeated the Wizard of Yendor from the Deck of Many Things.");
			addnav("Back to the Forest","forest.php");		
		}
		if (get_module_pref("monsternum")==3){
			output("`n`#You defeat the `\$%s`#!  Very nice job!`n`n",$monster);
			if (get_module_pref("deckseduced")==1){
				$armor=get_module_pref("decktemparmor");
				output("You grab your `b`&%s`#`b back and put it back on. You feel much safer again.`n`n",$armor);
				set_module_pref("deckseduced",0);
				$session['user']['defense']+=get_module_pref("decktempdefense")-1;
				$session['user']['armordef']=get_module_pref("decktempdefense");
				$session['user']['armor']=get_module_pref("decktemparmor");
			}
			$expbonus=$session['user']['dragonkills']*4;
			$expgain =($session['user']['level']*e_rand(30,40)+$expbonus);
			$session['user']['experience']+=$expgain;
			output("`@You gain `#%s experience`@ and also gain an `bExtra Turn`b!`n`n",$expgain);
			$session['user']['turns']++;
			output("`#The `%o`^l`%d `%g`^y`%p`^s`%y `%w`^o`%m`^a`%n`# looks at you and shrugs, pokes you with her `qstick`#, and disappears into the `@forest.`n`n");
			addnews("%s`^ drew the `\$Lovers Card`^.",$session['user']['name']);
			debuglog("defeated the $monster from the Deck of Many Things.");
			blocknav("runmodule.php?module=deckofmanythings&op=payment");
			$session['user']['specialinc'] = "";
			addnav("Back to the Forest","forest.php");
		}
		if (get_module_pref("monsternum")==4){
			output("`n`^Your ability to defeat the `&Erinys`^ proves you innocent of all charges!`n`n");
			$expbonus=$session['user']['dragonkills']*4;
			$expgain =($session['user']['level']*e_rand(30,45)+$expbonus);
			$session['user']['experience']+=$expgain;
			output("`@You gain `#%s experience`@.`n`n",$expgain);
			output("Since you have proven yourself innocent, your hitpoints are restored to full.");
			$session['user']['hitpoints']=$session['user']['maxhitpoints'];
			debuglog("defeated an Erinys from the Deck of Many Things.");
			addnews("%s`^ drew the `\$Justice Card`^.",$session['user']['name']);
			$session['user']['specialinc'] = "";
			addnav("Back to the Forest","forest.php");
		}
		if (get_module_pref("monsternum")==5){
			output("`n`4The `\$Demon `4falls before you defeated!!`n`nYou have crushed a power from the Astral Plane, a rare accomplishment indeed!`n`n");
			$expbonus=$session['user']['dragonkills']*15;
			$expgain =($session['user']['level']*e_rand(75,85)+$expbonus);
			$session['user']['experience']+=$expgain;
			$session['user']['gems']+=10;
			output("`@You gain `#%s experience`@ and `%10 Gems`@.`n`n",$expgain);
			output("If you would like, you may take the title of `\$`bSlayer`b.");
			addnav("Change my Title","runmodule.php?module=deckofmanythings&op=deckslayer");
			addnav("No Thank You","runmodule.php?module=deckofmanythings&op=deckleave");
			debuglog("defeated a Demon from the Deck of Many Things.");
			addnews("%s`^ drew the `\$Devil Card`^.",$session['user']['name']);
		}
		if (get_module_pref("monsternum")==6){
			output("`n`5The `QVampire `5falls to your feet.  However, you are unable to finish his destruction because you do not have the wooden steak that is needed");
			output("to destroy his undead heart. `n`nYou decide it will be best if you retreat back to the `@forest`5. Before you leave, you take the `\$o`Qr`^n`@a`#t`!e`5 jewelry holding his cloak to his chest.  It is worth at least `%4 Gems`5!`n`n");
			$expbonus=$session['user']['dragonkills']*8;
			$expgain =($session['user']['level']*e_rand(45,55)+$expbonus);
			$session['user']['experience']+=$expgain;
			$session['user']['gems']+=4;
			output("`@You gain `#%s experience`@ and `%4 Gems`@.`n`n",$expgain);
			debuglog("defeated a Vampire from the Deck of Many Things.");
			addnews("%s`^ drew the `\$Tower Card`^.",$session['user']['name']);
			$session['user']['specialinc'] = "";
			addnav("Back to the Forest","forest.php");
		}
	}elseif($defeat){
		$session['user']['specialinc'] = "";
		require_once("lib/taunt.php");
		$taunt = select_taunt_array();
		$session['user']['alive'] = false;
		$session['user']['hitpoints'] = 0;
		if (get_module_pref("monsternum")==1){	
			$exploss = round($session['user']['experience']*.1);
			output("`n`#The `%O`^l`%d `%G`^y`%p`^s`%y `%W`^o`%m`^a`%n`# stands over you and starts laughing.`n`n`%'Wow... beat up by an old woman.  I guess you won't be bragging to your friends about that, will you?'`#`n`n");
			output("You lose `#%s experience and `^all your gold`#.`b`0`n",$exploss);
			output("`@`n`c`bYou may begin your adventures again tomorrow.`c`b");
			addnav("Daily news","news.php");
			$session['user']['experience']-=$exploss;
			$session['user']['gold']=0;
			addnews("%s `#was defeated by an `%O`^l`%d `%G`^y`%p`^s`%y `%W`^o`%m`^a`%n`# in the forest.  Did I mention it was an `b`%O`^L`%D`b `%G`^y`%p`^s`%y`#? She was using a walker and oxygen to get around.  Seriously, how pitiful is that?",$session['user']['name']);
			debuglog("lost to the Gypsy with the Deck of Many Things.");
		}
		if (get_module_pref("monsternum")==2){
			$exploss = round($session['user']['experience']*.05);
			output("`n`^The `!Wizard of Yendor`^ stands over your body.  He searches you and starts yelling `4'Where is the Amulet?!?!'`n`n`^You don't really care where the Amulet (whatever that is) could be because you are dead.`n`n");
			output("`^All your gold is lost.  For some reason, you hope that you left a `)bones`^ file.`n");
			output("You lose `#%s experience and `^all your gold`#.`b`0`n",$exploss);
			output("`@`n`c`bYou may begin your adventures again tomorrow.`c`b");
			addnav("Daily news","news.php");
			$session['user']['experience']-=$exploss;
			$session['user']['gold']=0;
			addnews("%s `^was defeated by `!The Wizard of Yendor`^.",$session['user']['name'],$taunt);
			debuglog("lost to the Wizard of Yendor from the Deck of Many Things.");
		}
		if (get_module_pref("monsternum")==3){
			output("`n`#The %s gives you one final `\$`bkiss`b`# goodbye.`^`n",$monster);
			if (get_module_pref("deckseduced")==1){
				set_module_pref("deckseduced",0);
				output("`nSince you were killed by %s, you aren't able to recover your armor. `b`\$Love`b`^ sucks.`n",translate_inline($session['user']['sex']?"him":"her"));
			}
			$exploss = round($session['user']['experience']*.05);
			output("`nThe %s lets you keep your gold since money can't buy love.`n",$monster);
			output(" `\$You lose `#%s experience`\$.`b`0`n",$exploss);
			output("`@`n`c`bYou may begin your adventures again tomorrow.`c`b");
			addnav("Daily news","news.php");
			$session['user']['experience']-=$exploss;
			addnews("%s `^was seduced to death by a `\$%s`^.",$session['user']['name'],$monster,$taunt);
			blocknav("runmodule.php?module=deckofmanythings&op=payment");
		}
		if (get_module_pref("monsternum")==4){
			$exploss = round($session['user']['experience']*.1);
			output("`n`n`^Your defeat at the hands of the Erinys proves to the world you have committed a grave sin against a tie of kinship.`n");
			output(" `n`\$You lose `#%s experience`\$.`b`0`n",$exploss);
			output("`@`n`c`bYou may begin your adventures again tomorrow.`c`b");
			addnav("Daily news","news.php");
			$session['user']['experience']-=$exploss;
			$session['user']['gold']=0;
			addnews("%s `@was found guilty of crimes against kinship.",$session['user']['name']);
		}
		if (get_module_pref("monsternum")==5){
			output("`n`^The `\$Demon`^ prepares to strike you but his hand is stilled before the fatal blow falls.`n`n`b`\$'No, I shall not end your existence, for");
			output("I think I will be able to harvest your soul soon enough if I give you just a little more time here.  In fact, let me give you some extra `^gold`\$");
			output("to spend.  I think perhaps that will hasten my victory over you.'`b`n`n");
			output("Asmodeus `^disappears, leaving you with `\$1 hitpoint`^ and `b500 more Gold`b.  You do not lose any experience.");
			$session['user']['gold']+=500;
			$session['user']['hitpoints']=1;
			$session['user']['alive'] = true;
			addnav("Back to the Forest","forest.php");
			addnews("%s `@lost in a fight to a `\$Demon`@ from another plane of existence.",$session['user']['name']);
		}
		if (get_module_pref("monsternum")==6){
			$exploss = round($session['user']['experience']*.1);
			output("`n`5Your body is slain by the final bite from the `QVampire`5.  As he feasts on your blood, you realize that this is a transforming loss.  You");
			output("have become one of the `QUndead`5.  It is a title you will carry with you from now on.`n`n");
			output("`\$You lose `#%s experience`\$ and all your `^Gold`\$.`0`n",$exploss);
			if (get_module_setting("givepermhp")==1 && ($session['user']['maxhitpoints']>($session['user']['level']*11)+10)) {
				output("`nYou also lose `b2 Permanent Hitpoints`b because of the drain to your body.`n");
				$session['user']['maxhitpoints']-=2;
				debuglog("lost 2 maxhitpoints because of being defeated by a Vampire from the Deck of Many Things.");
			}	
			output("`@`n`c`bYou may begin your adventures again tomorrow.`c`b");
			addnav("Daily news","news.php");
			$session['user']['experience']-=$exploss;
			$newtitle = "`QUndead`0";
			$newname = change_player_title($newtitle);
			$session['user']['title'] = $newtitle;
			$session['user']['name'] = $newname;
			$session['user']['gold']=0;
			addnews("%s `@lost in a fight to a `QVampire`@ discovered in a Tower in the forest.",$session['user']['name']);
		}
	}else{
		require_once("lib/fightnav.php");
		fightnav(true,false,"runmodule.php?module=deckofmanythings");
	}
}
//from moons by JT Traub
function deckofmanythings_phase($cur, $max){
	$phase = "new";
	if ($cur < $max * .12) {
		// new to first quarter
		$phase = "`)new";
	} elseif ($cur < $max * .25) {
		// first quarter to waxing half
		$phase = "a `7waxing crescent";
	} elseif ($cur < $max * .37) {
		// waxing half to 3/4 full
		$phase = "`6half full";
	} elseif ($cur < $max * .5) {
		// 3/4 full to full
		$phase = "`6waxing gibbous";
	} elseif ($cur < $max * .62) {
		// full to waning 3/4
		$phase = "`^full";
	} elseif ($cur < $max * .75) {
		// waning 3/4 to waning half
		$phase = "`6waning gibbous";
	} elseif ($cur < $max * .87) {
		// waning half to waning 1/4
		$phase = "`6half full and waning";
	} else {
		// waning 1/4 to new
		$phase = "a `7waning crescent";
	}
	return translate_inline($phase);
}
page_footer();
?>