<?
/*Thondin's Gem Shop 
by Kyky on http://dragonprime.cawsquad.net/
Updated and edited by Will Munn
http://www.dubmun.com
<br>
The names of the characters in this mod have been changed to protect the identities of those involved.
This mods is plug-and-play, just add your link in the village and run with it. No DB stuff necessary.*/

//Costs of Gems
$gembuyvalue = 1500;
$gemsellvalue = 1000;

//Header Stuff
require_once "common.php";
checkday();
page_header("Thondin's Gems");
    $config = unserialize($session['user']['donationconfig']);
     output("`&`b`cThondin's Gems`c`b`n");

//Main Area
if ($_GET[op] == "") {
	if (!$_GET[type]=="entered") {
		output("`&Thondin`@ the dwarf stares at you from behind his bushy eyebrows. You wish you could see what he is thinking behind that beard.`n");
		output("One look at all the marvelous gems he has for sale, and you wonder if you have enough money to buy any.`n`n");
	} else {
		output("`#\"So....what seems to interest you in my shop? I have gems, gems, and more gems.\"`@ `&Thondin`@ asks somewhat grumpily.`n`n");
	}
	
	output("`#\"I have ".getsetting("selledgems",0)." gems in my shop.\"`@ says `&Thondin`@.`n");
	if (getsetting("selledgems",0) < 1) { 
		//if Thondin is out of gems, you may want to randomly add him into the INN for players to chat with
		output("`n`&Thondin`@ continues, to say, `#\"I'm sorry but I don't seem to have any more gems to sell, I'm going to close up shop and get an ale.`n`n Come back when I get my new shipment.\"`n`n"); 
	} else { 
		addnav("Buy Gems","gemshop.php?op=buy&type=many"); 
	}
	if ($session[user][gems] > 0) { addnav("Sell Gems","gemshop.php?op=sell&type=many"); }
	addnav("Talk to Wonk","gemshop.php?op=Wonk");
	addnav("Return to the village","village.php");
}

//How many gems to buy or sell
else if ($_GET['type']=="many") {

     $offer = $_GET[op];
     output("<form action='gemshop.php?op=".$offer."&type=accept' method='POST'> `&".$offer." how many gems? <input id='input' name='amount' width=5 accesskey='h'> <input type='submit' class='button' value='".$offer."'>`n</form>",true);
     output("<script language='javascript'>document.getElementById('input').focus();</script>",true);
     addnav("Nevermind","gemshop.php?type=entered");
     addnav("","gemshop.php?op=".$offer."&type=accept");
}

//Thondin makes his offer
else if ($_GET[type]=="accept") {
        $_POST[amount]=abs((int)$_POST[amount]);

        if ($_GET[op]=="buy") {
			if ($_POST[amount]==0) { $_POST[amount] = getsetting("selledgems",0); }
			if ($_POST[amount]> getsetting("selledgems",0)) { $_POST[amount] = getsetting("selledgems",0); }
	
			//buying value
			$hisoffer = $_POST[amount]." gem".($_POST[amount]>1?"s":"");
			$myoffer = ($_POST[amount]* $gembuyvalue)." gold";
        } else {
			if ($_POST[amount]==0) { $_POST[amount] = $session[user][gems]; }
	
			//selling value
			$hisoffer = ($_POST[amount] * $gemsellvalue)." gold,";
			$myoffer = $_POST[amount]." gem".($_POST[amount]>1?"s":"");
        }

		addnav("Yes","gemshop.php?op=".$_GET[op]."&amount=".$_POST[amount]);
		addnav("No","gemshop.php?type=entered");
		output("`&Thondin`@ thinks carefully about the exchange and makes you an offer.");
		output("`n`nWill you accept my ".$hisoffer." for your ".$myoffer."?");
		output("`n`&[`#<a href='gemshop.php?op=$_GET[op]&amount=$_POST[amount]'>Yes</a>`&][`#<a href='gemshop.php?type=entered'>No</a>`&]",true);
}

//process sell
else if ($_GET[op]=="sell" && ($_GET[amount])) {
        $_GET[amount]=abs((int)$_GET[amount]);
        //cost of gems
		$hisoffer = ($_GET[amount] * $gemsellvalue);
        if ($_GET['amount'] > $session['user']['gems']) {
			output("`#\"You would like to sell ".$_GET[amount]." gems, which is more than ".$session[user][gems]." gems, that you actually have!\"`@, exclaims `&Thondin`@."); 
		}
        else {
			output("`&Thondin`@ gives you your `&".$hisoffer."`@ gold and takes your `&".$_GET[amount]."`@ gem".($_GET[amount]>1?"s":""));
			output("`n`n`&Wonk`@ ambles over and pickes up the bag of gems.`n`n");
			output("`&Thondin`@ shakes his fist at `&Wonk`@,`#\"Can't you go any faster you ol lump of lard`#!`n`n");
			$session[user][gold] += $hisoffer;
			$session[user][gems] -= $_GET[amount];
			$session['user']['donationconfig']=serialize($config);
			if ((getsetting("selledgems",0) + $_GET['amount']) > 100000000000) { 
				output("`#\"We'll be putting these in our front display case!\"`@, says `&Wonk`@`n`n"); savesetting("selledgems",100000000); 
			} 
			else {savesetting("selledgems",(getsetting("selledgems",0) + $_GET[amount])); }
        }

		addnav("Talk to Thondin.","gemshop.php?type=entered");
}

//process buy
else if ($_GET[op]=="buy" && ($_GET[amount])) {
     	 $_GET[amount]=abs((int)$_GET[amount]);
    	 //cost of gems
         $myoffer = ($_GET[amount]* $gembuyvalue);
         if ($myoffer > $session[user][gold]) { 
		 	output("`#\"The gems I do have are in this legend. I can only guess that the gold you don't have, is in some myth.\"`@ says `&Thondin`@."); 
		 }
         else {
			 output("`n`n`&Thondin`@ gives you your `&".$_GET['amount']."`@ gem".($_GET['amount'] > 1?"":"s")." and accepts your `&".$myoffer);
			 output("`n`n`&Thondin`@ calls out, `#\"`&Wonk`#! Hurry up an fetch up this gold!\"`n`n");
			 output("`&Wonk`@ wheezes as he carry's the gold to the back.");
			 output("`n`n`&Thondin`@ says, `#\"Heh heh... good excercise for 'em.\"`n");
			 $session[user][gold] -= $myoffer;
			 $session[user][gems] += $_GET[amount];
			 if ($_GET[amount] == getsetting("selledgems",0))
				$_GET[amount] = $_GET[amount] - 1;
				
			 savesetting("selledgems",(getsetting("selledgems",0) - $_GET[amount]));
         }

         addnav("Talk to Thondin.","gemshop.php?type=entered");
}

//visit Wonk
//this area could easily be interfaced with an event, (like Wonk asking you to help him rob Thondin's shop).
else if ($_GET[op]=="Wonk") {
		output("`@The huge man, `&Wonk`@ stands in his corner carefully polishing some gems.`n`n");
		output("`#\"I wish I had some gems! Then I could buy myself a nice little home and settle down with my wife and kids! ");
		output("I haven't seen 'em in a month or so...\"`n`n");
		output("`#\"I'd hold on to some of yer gems if I were ye! ");
		output("Gems are so hard to come by now-a-days.`n");
		output("Ye know, `&Thondin`# pays people gold to find every gem they can!\"`n");
		
		addnav("Talk to Thondin","gemshop.php?type=entered");
}
page_footer();

?>
