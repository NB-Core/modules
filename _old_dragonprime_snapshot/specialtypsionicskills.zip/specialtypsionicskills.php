<?php
//addnews ready
// mail ready
// translator ready
/******************************************
 Name: Specialty - Psionic Skills
 Ver: 1.0   Date: 12-22-04
 By: dvd871

 ~~ Credits ~~
 Danic
 Based on his Elementalist skill.
******************************************/

function specialtypsionicskills_getmoduleinfo(){
        $info = array(
                "name" => "Specialty - Psionic Skills",
                "author" => "dvd871",
                "version" => "1.0",
                "download" => "http://dragonprime.net/users/Dvd871/specialtypsionicskills.zip",
                "category" => "Specialties",
                "settings"=> array(
                        "Specialty - Psionic Settings,title",
                        "mindk"=>"How many DKs do you need before the specialty is available?,int|0",
                        "cost"=>"How many points do you need before the specialty is available?,int|0",
                ),
                "prefs" => array(
                        "Specialty - Psionic Skills User Prefs,title",
                        "skill"=>"Skill points in Psionic Skills,int|0",
                        "uses"=>"Uses of Psionic Skills allowed,int|0",
                ),
        );
        return $info;
}

function specialtypsionicskills_install(){
        module_addhook("choose-specialty");
        module_addhook("set-specialty");
        module_addhook("fightnav-specialties");
        module_addhook("apply-specialties");
        module_addhook("newday");
        module_addhook("incrementspecialty");
        module_addhook("specialtynames");
        module_addhook("specialtycolor");
        module_addhook("dragonkill");
        module_addhook("pointsdesc");
        return true;
}

function specialtypsionicskills_uninstall(){
        // Reset the specialty of anyone who had this specialty so they get to
        // rechoose at new day
        $sql = "UPDATE " . db_prefix("accounts") . " SET specialty='' WHERE specialty='PS'";
        db_query($sql);
        return true;
}

function specialtypsionicskills_dohook($hookname,$args){
        global $session,$resline;
        tlschema("fightnav");

        $spec = "PS";
        $name = "Psionic Skills";
        $ccode = "`@";
		$cost = get_module_setting("cost");
		
        switch ($hookname) {
        case "pointsdesc":
				if ($cost>0)
				{
					$args['count']++;
					$format = $args['format'];
					$str = translate("The Psionics Specialty is availiable upon reaching %s Dragon Kills and %s points.");
					$str = sprintf($str, get_module_setting("mindk"),
							$cost);
					output($format, $str, true);
				}
				break;
        case "dragonkill":
                set_module_pref("uses", 0);
                set_module_pref("skill", 0);
                break;
        case "choose-specialty":
                if ($session['user']['specialty'] == "" ||
                                $session['user']['specialty'] == '0') {
                        $pointsavailable = $session['user']['donation'] - $session['user']['donationspent'];
                        if ($session['user']['dragonkills'] < get_module_setting("mindk") || get_module_setting("cost") > $pointsavailable)
                                break;
                        addnav("$ccode$name`0","newday.php?setspecialty=".$spec."$resline");
                        $t1 = translate_inline("Expanding your mind");
                        $t2 = appoencode(translate_inline("$ccode$name`0"));
                        rawoutput("<a href='newday.php?setspecialty=$spec$resline'>$t1 ($t2)</a><br>");
                        addnav("","newday.php?setspecialty=$spec$resline");
                }
                break;
        case "set-specialty":
                if($session['user']['specialty'] == $spec) {
                        page_header($name);
                        $session['user']['donationspent'] = $session['user']['donationspent'] + $cost;
                        output("`3Growing up, you remember reading and endless hours of study.");
                        output("Over time you began to train your mind, channeling thoughts into a form of material energy!");
                        output("You found that this energy could be controlled and used as a weapon against your foes.");                }
                break;
        case "specialtycolor":
                $args[$spec] = $ccode;
                break;
        case "specialtynames":
                $args[$spec] = translate_inline($name);
                break;
		case "specialtymodule":
				$args[$spec] = "specialtypsionicskills";
			    break;
        case "incrementspecialty":
                if($session['user']['specialty'] == $spec) {
                        $new = get_module_pref("skill") + 1;
                        set_module_pref("skill", $new);
                        $c = $args['color'];
                        output("`n%sYou gain a level in `&%s%s to `#%s%s!",
                                        $c, $name, $c, $new, $c);
                        $x = $new % 3;
                        if ($x == 0){
                                output("`n`^You gain an extra use point!`n");
                                set_module_pref("uses", get_module_pref("uses") + 1);
                        }else{
                                if (3-$x == 1) {
                                        output("`n`^Only 1 more skill level until you gain an extra use point!`n");
                                } else {
                                        output("`n`^Only %s more skill levels until you gain an extra use point!`n", (3-$x));
                                }
                        }
                        output_notl("`0");
                }
                break;
        case "newday":
                $bonus = getsetting("specialtybonus", 1);
                if($session['user']['specialty'] == $spec) {
                        if ($bonus == 1) {
                                output("`n`2For being interested in %s%s`2, you receive `^1`2 extra `&%s%s`2 use for today.`n",$ccode,$name,$ccode,$name);
                        } else {
                                output("`n`2For being interested in %s%s`2, you receive `^%s`2 extra `&%s%s`2 uses for today.`n",$ccode,$name,$bonus,$ccode,$name);
                        }
                }
                $amt = (int)(get_module_pref("skill") / 3);
                if ($session['user']['specialty'] == $spec) $amt++;
                set_module_pref("uses", $amt);
                break;
        case "fightnav-specialties":
                $uses = get_module_pref("uses");
                $script = $args['script'];
                if ($uses > 0) {
                        addnav(array("%s%s (%s points)`0", $ccode, $name, $uses), "");
                        addnav(array("%s &#149; Animal Telepathy`7 (%s)`0", $ccode, 1),
                                        $script."op=fight&skill=$spec&l=1", true);
                }
                if ($uses > 1) {
                        addnav(array("%s &#149; Iron Will`7 (%s)`0", $ccode, 2),
                                        $script."op=fight&skill=$spec&l=2",true);
                }
                if ($uses > 2) {
                        addnav(array("%s &#149; Molecular Agitation`7 (%s)`0", $ccode, 3),
                                        $script."op=fight&skill=$spec&l=3",true);
                }
                if ($uses > 4) {
                        addnav(array("%s &#149; Psychic Crush`7 (%s)`0", $ccode, 5),
                                        $script."op=fight&skill=$spec&l=5",true);
                }
                break;
        case "apply-specialties":
                $skill = httpget('skill');
                $l = httpget('l');
                if ($skill==$spec){
                        if (get_module_pref("uses") >= $l){
                                switch($l){
                                case 1:
                                        apply_buff('ps1',array(
                                                "startmsg"=>"`^You focus your thoughts and call out to the animals for help!",
                                                "name"=>"`^Animal Telepathy`^",
                                                "rounds"=>5,
                                                "wearoff"=>"`^The animals have helped you all they can...`^",
                                                "minioncount"=>round($session['user']['level']/2)+2,
                                                "maxbadguydamage"=>round($session['user']['level']/2)+3,
                                                "effectmsg"=>"`^An animal minion hits {badguy} for {damage} damage.`^",
                                                "effectnodmgmsg"=>"`)An animal minion tries to hit {badguy}`) but `\$MISSES`)!",
                                                "schema"=>"specialtypsionicskills"
                                        ));
                                        break;
                                case 2:
                                        apply_buff('ps2',array(
                                                "startmsg"=>"`^You focus your thoughts into a wall of energy.`^",
                                                "name"=>"`^Iron Will`^",
                                                "rounds"=>5,
                                                "wearoff"=>"`^Your wall of energy fades away...`^",
                                                "badguyatkmod"=>0.5,
                                                "defmod"=>1.5,
                                                "effectmsg"=>"`^Your wall of energy prevents {badguy} from attacking as well!`^",
                                                "schema"=>"specialtypsionicskills"
                                        ));
                                        break;
                                case 3:
                                        apply_buff('ps3', array(
                                                "startmsg"=>"`^You cause the molecules of {badguy} to unform.`^",
                                                "name"=>"`^Molecular Agitation`^",
                                                "rounds"=>5,
                                                "wearoff"=>"`^{badguy}'s molecules reform again...`^",
                                                "minioncount"=>round($session['user']['level']/2.5)+1,
                                                "maxbadguydamage"=>round($session['user']['level']/1.8,0)+1,
                                                "effectmsg"=>"`^{badguy}'s soul burns for {damage} damage.`^",
                                                "effectnodmgmsg"=>"`)Your attack on {badguy} fails!",
                                                "schema"=>"specialtypsionicskills"
                                        ));
                                        break;
                                case 5:
                                        apply_buff('ps5',array(
                                                "startmsg"=>"`^Concentrating deeply you project an intense mental blast on {badguy}!`^",
                                                "name"=>"`^Psychic Crush`^",
                                                "rounds"=>1,
                                                "wearoff"=>"`^{badguy} recovers from your mental attack...`^",
                                                "minioncount"=>1,
                                                "minbadguydamage"=>round($session['user']['attack']*2,0),
                                                "maxbadguydamage"=>round($session['user']['attack']*4,0),
                                                "effectmsg"=>"`^Your psychic crush hits {badguy} for {damage} damage.`^",
                                                "schema"=>"specialtypsionicskills"
                                        ));
                                        break;
                                }
                                set_module_pref("uses", get_module_pref("uses") - $l);
                        }else{
                                apply_buff('ps0', array(
                                        "startmsg"=>"`^You try to focus your mental energy, but are distracted.  `%{badguy} `^smirks an evil grin at you.`^",
                                        "rounds"=>1,
                                        "schema"=>"specialtypsionicskills"
                                ));
                        }
                }
                break;
        }
        return $args;
}

function specialtypsionicskills_run(){
}
?>
