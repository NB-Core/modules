Module: Starting HP
for Legend of the Green Dragon 1.x
Version 1.0 (04/08/06)
by Gary Hartzell
Special thanks to Dave S and Shadow Raven!

Description:
Allows game admins to set a maximum hit point cap based on either the number of dragon kills a 
player has or a fixed number.

Installation:
1. Upload to your LoGD modules directory
2. Log into LoGD, enter the Module Manager in the Superuser Grotto
3. Find "Starting HP" and click "Install"
4. From the next screen, again find "Starting HP" and click "Settings"
5. Choose your desired settings and save your changes
6. Click "Activate"
