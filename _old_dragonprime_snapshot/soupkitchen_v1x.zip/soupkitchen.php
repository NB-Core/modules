<?php
// BY Robert of maddrio dot com
// v1.2 adds more settings

function soupkitchen_getmoduleinfo(){
	$info = array(
		"name"=>"Soup Kitchen",
		"version"=>"1.2",
		"author"=>"`2Robert",
		"category"=>"Village",
		"download"=>"http://dragonprime.net/users/robert/soupkitchen_v1x.zip",
		"description"=>"Senseless mod - adds a shop which does little",
		"vertxtloc"=>"http://dragonprime.net/users/robert/",
		"settings"=>array(
			"Soup Kitchen - Settings,title",
			"storeloc"=>"Where does the store appear,location|".getsetting("villagename", LOCATION_FIELDS),
			"Player will gain same amount of gold as charm lost!,note",
			"minch"=>"Min charm lost for robbing store,range,1,25,1|1",
			"maxch"=>"Max charm lost for robbing store,range,2,50,1|3",
			"Players OVER the next setting will not be able to donate!,note",
			"stopch"=>"Players with LESS than what charm can donate?,range,5,200,5|20",
			"donatecost"=>"Players donate how much to earn charm?,range,500,5000,100|2000",
			"chgive"=>"Charm GAINED for donation,range,1,50,1|1",
		),
		"prefs"=>array(
			"Soup Kitchen - User Prefs,title",
			"robtoday"=>"Did player rob Soup Kitchen today?,bool|0",
			"robtotal"=>"Total times player has robbed the Soup Kitchen?,int|0",
			"donatetoday"=>"Did player donate today?,bool|0",
			"donatetotal"=>"Total times player has donated?,int|0",
		)
	);
	return $info;
}

function soupkitchen_install(){
	module_addhook("changesetting");
	module_addhook("newday");
	module_addhook("village");
	return true;
}

function soupkitchen_uninstall(){
    return true;
}

function soupkitchen_dohook($hookname,$args){
	global $session;
	switch($hookname){
	case "changesetting":
		if ($args['setting'] == "villagename") {
			if ($args['old'] == get_module_setting("storeloc")) {
				set_module_setting("storeloc", $args['new']);
			}
		}
	break;
	case "newday":
		set_module_pref("robtoday",0);
		set_module_pref("donatetoday",0);
	break;
	case "village":
		if ($session['user']['location'] == get_module_setting("storeloc")) {
			tlschema($args['schemas']['tavernnav']);
			addnav($args['tavernnav']);
			tlschema();
			addnav("Soup Kitchen","runmodule.php?module=soupkitchen");
		}
		break;
	}
	return $args;
}

function soupkitchen_run() { // Player robs for charm loss
	global $session;
	$op=httpget('op');
	$weapon=$session['user']['weapon'];
	$race = $session['user']['race'];
	$howmuch = $session['user']['gold'];
	$hp = $session['user']['hitpoints'];
	$ch = $session['user']['charm'];
	$min=get_module_setting("minch");
	$max=get_module_setting("maxch");
	$amt=e_rand($min,$max);
	$name=$session['user']['name'];
	$robtoday=get_module_pref("robtoday");
	$donatecost=get_module_setting("donatecost");
	$stopch=get_module_setting("stopch");
	$chgive=get_module_setting("chgive");
	$donatetoday=get_module_pref("donatetoday");

	page_header("Soup Kitchen");
	rawoutput("<font size='+1'>");
	output("`c`b`i`# Soup Kitchen`0`i`b`c`n");
	rawoutput("</font>");
	if ($op==""){
		output("`n You enter the Soup Kitchen, there are rows of tables with vagrant's eating soup. ");
		output("`n`n A matron looks you over and says,`n`n `6 Our meals are free for the poor but if you really are hungry, we will feed you. ");
		if ($robtoday==0){
			addnav(" Soup Kitchen ");
			addnav("(R) Rob the Place","runmodule.php?module=soupkitchen&op=rob");
		}
		if ($robtoday>=1){
			output("`n`n`7 The matron suddenly realizes YOU were the one to rob the place earlier. ");
			output("`n`n She shouts, `6Thats the one!! ....get the bloody scoundrel boys!!! ");
			output("`n`n`7 Vagrants with forks and spoons attack you, poking you endlessly `n`n`&....time to leave dont you think?");
			if ($hp>=10){$session['user']['hitpoints'] = round($session['user']['hitpoints']*.75);}
		}
		if ($donatetoday>=1){
			output("`n`n`6 Oh my! Its you, bless your kind heart for the most generous donation! ");
		}else{
			if ($howmuch>=$donatecost && $ch<$stopch){
				addnav(" Soup Kitchen ");
				addnav("(D) Make $donatecost Donation","runmodule.php?module=soupkitchen&op=donate");
			}
		}
	}elseif ($op=="rob"){
		output("`n`n`2 You pull out your %s, and push the matron onto the floor, ",$weapon);
		output("`n`n You find %s in the cash box and become disappointed.",$amt);
		increment_module_pref("robtoday",1);
		increment_module_pref("robtotal",1);
		$session['user']['gold'] += $amt;
		$session['user']['charm'] -= $amt;
		output("`n`n For stealing from the poor, you lost $amt charm.");
		addnews("`6Crazed %s robs the Soup Kitchen! `0 %s `6 is suspect in this hideous crime!`0",$race,$name);
	}elseif ($op=="donate"){
		output("`n`n`2 Reaching into your pouch you take out 2000 and hand it to the matron. ");
		output("`n`n She takes the money and burst into tears and says, `6Bless you, this will feed many hungry souls`2! ");
		output("`n`n People at near by tables stand up, some shout praises, others begin clapping their hands. ");
		output("`n`n You have become their Hero! You feel like a Champion, a Savior `7....ok already, enough of the praising! ");
		$session['user']['gold']-=$donatecost;
		addnews("`#Glory Hallelujah! `0 %s `3 has made a substantial donation to the Soup Kitchen!`0",$name);
		debuglog(" gave 2000 gold to Soup Kitchen +$amt charm");
		$session['user']['charm'] += $chgive;
		increment_module_pref("donatetotal",1);
		increment_module_pref("donatetoday",1);
	}
	addnav(" exit ");
	villagenav();
	page_footer();
}
?>