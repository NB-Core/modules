<?php
/*
Module Name: quizgame1.php
Category: Village
Worktitle: Quiz Game 1
Version: 3.0
Author: DaveS
Date:  February 6, 2006
Modified from an original program by DaveS and Kestrel Sky with debugging by Niksolo

Description: 
Encourages new players to explore the realm to win a prize.  Set with questions based purely on
core modules.  This is a little different from the basic quiz in the Quiz Loader program.

Hooks into the Quiz Loader Module for even more fun but can stand alone.
v3.01  fixed $error and missing module_addhook
v3.02  simple typos fixed
v3.03  fixed spelling error on line 278
*/
require_once("lib/villagenav.php");
require_once("lib/titles.php");
require_once("lib/names.php");
function quizgame1_getmoduleinfo() {
	$info = array(
		"name"=>"Quiz Game 1",
		"author"=>"DaveS",
		"version"=>"3.03",
		"category"=>"Village",
		"download"=>"http://dragonprime.net/index.php?module=Downloads;sa=dlview;id=188",
		"vertxtloc"=>"",
		"settings"=>array(
			"Quiz Game 1,title",
			"goldaward"=>"Gold Awarded,int|100",
			"gemaward"=>"Gems Awarded,int|1",
			"quizname"=>"What is the name of the quiz?,text|New Player Exam",
			"announce1"=>"First line of your description of this quiz,text|Although the kingdom can be scary at the start",
			"announce2"=>"Second line of your description of this quiz,text|You'll be stronger and faster the more you explore.",
			"announce3"=>"Third line of your description of this quiz,text|Strengthen your mind, open your heart",
			"announce4"=>"Fourth line of your description of this quiz,text|Make new friends and you'll learn much more.",
			"quizgame1loc"=>"Where does the Quiz Office appear?,location|".getsetting("villagename", LOCATION_FIELDS),
			"Only needed if not using quizload module,note",
			"titleyes"=>"Would you like to offer a title for completing this quiz?,bool|0",
			"titleto"=>"What title would you like to use? (no spaces),text|LilSlayer",
			"limitwin"=>"If you wish to limit to a certain number of winners; how many?,int|-1",
			"Set to -1 if you do not want a limit to the number of winners,note",
			"currentwin"=>"How many winners are there so far?,int|0",
			"limitlong"=>"If you wish to autoclose the quiz; how many game days until it closes?,int|-1",
			"Set to -1 if you do not want the quiz to autoclose,note",
			"currentlong"=>"How many days has this quiz been open so far?,int|0",
			"quizhold"=>"Close the quiz?,bool|0",
			"resetquiz"=>"Reload the quiz at the next day?,bool|0",
			"This will reset and open everything at next newday so use it only if you are ready with a new quiz,note",
			"Question 1,title",
			"Leave extra lines blank if there is no additional text,note",
			"riddle1a"=>"What is the first line of riddle 1?,text|You learn to dance at Ella's Studio.",
			"riddle1b"=>"What is the second line of riddle 1?,text|The music is invigorating and sweet.",
			"riddle1c"=>"What is the third line of riddle 1?,text|A felyne keeps time on this instrument",
			"riddle1d"=>"What is the fourth line of riddle 1?,text|So you can keep your eyes on your feet.",
			"riddle1e"=>"What is the fifth line of riddle 1?,text|What is the instrument?",
			"answer1"=>"What is the correct answer?,text|Piano",
			"letter1"=>"Which letter in the answer starts with the letter I?,range,1,20,1|2",
			"reminder1"=>"Where is the answer to this question from?,text|Ella's Dance Studio Description",
			"wrong1a"=>"What is wrong answer 1?,text|Lute",
			"wrong1b"=>"What is wrong answer 2?,text|Fiddle",
			"wrong1c"=>"What is wrong answer 3?,text|Drums",
			"wrong1d"=>"What is wrong answer 4?,text|Trumpet",
			"wrong1e"=>"What is wrong answer 5?,text|Flute",
			"wrong1f"=>"What is wrong answer 6?,text|Tamborine",
			"wrong1g"=>"What is wrong answer 7?,text|Triangle",
			"wrong1h"=>"What is wrong answer 8?,text|Trombone",
			"wrong1i"=>"What is wrong answer 9?,text|Oboe",
			"quizzer1"=>"Person asking question 1,text|Ella",
			"sexofq1"=>"What is the sex of Person 1?,enum,0,Female,1,Male|1",
			"Question 2,title",
			"Leave extra lines blank if there is no additional text,note",
			"riddle2a"=>"What is the first line of riddle 2?,text|Go here to find the Dark Bowl of water",
			"riddle2b"=>"What is the second line of riddle 2?,text|That sits on a silver tray",
			"riddle2c"=>"What is the third line of riddle 2?,text|You can talk to the dead",
			"riddle2d"=>"What is the fourth line of riddle 2?,text|Instead of waiting for a new day.",
			"riddle2e"=>"What is the fifth line of riddle 2?,text|",
			"answer2"=>"What is the correct answer?,text|Gypsy Hut",
			"letter2"=>"Which letter in the answer starts with the letter U?,range,1,20,1|7",
			"reminder2"=>"Where is the answer to this question from?,text|Gypsy Hut Description",
			"wrong2a"=>"What is wrong answer 1?,text|Ramius",
			"wrong2b"=>"What is wrong answer 2?,text|Hades",
			"wrong2c"=>"What is wrong answer 3?,text|Crystal Ball Palace",
			"wrong2d"=>"What is wrong answer 4?,text|Seance",
			"wrong2e"=>"What is wrong answer 5?,text|Monkey's Paw",
			"wrong2f"=>"What is wrong answer 6?,text|Scrying Tent",
			"wrong2g"=>"What is wrong answer 7?,text|Palantir",
			"wrong2h"=>"What is wrong answer 8?,text|Oracle",
			"wrong2i"=>"What is wrong answer 9?,text|Cemetery",
			"quizzer2"=>"Person asking question 2,text|Franken",
			"sexofq2"=>"What is the sex of Person 2?,enum,0,Female,1,Male|1",
			"Question 3,title",
			"Leave extra lines blank if there is no additional text,note",
			"riddle3a"=>"What is the first line of riddle 3?,text|Play with the pets",
			"riddle3b"=>"What is the second line of riddle 3?,text|And you might get a prize.",
			"riddle3c"=>"What is the third line of riddle 3?,text|Get called a fancier",
			"riddle3d"=>"What is the fourth line of riddle 3?,text|If you attempt too many tries.",
			"riddle3e"=>"What is the fifth line of riddle 3?,text|Who owns the pets?",
			"answer3"=>"What is the correct answer?,text|Crazy Audrey",
			"letter3"=>"Which letter in the answer starts with the letter S?,range,1,20,1|8",
			"reminder3"=>"Where is the answer to this question from?,text|Crazy Audrey Description",
			"wrong3a"=>"What is wrong answer 1?,text|Spicy Silvia",
			"wrong3b"=>"What is wrong answer 2?,text|Bard Seth",
			"wrong3c"=>"What is wrong answer 3?,text|Green Dragon Doug",
			"wrong3d"=>"What is wrong answer 4?,text|Smelly Merrik",
			"wrong3e"=>"What is wrong answer 5?,text|Sleepy Elessa",
			"wrong3f"=>"What is wrong answer 6?,text|Barmaid Violet",
			"wrong3g"=>"What is wrong answer 7?,text|Chef Saucy",
			"wrong3h"=>"What is wrong answer 8?,text|Husbandry Master Dot",
			"wrong3i"=>"What is wrong answer 9?,text|Sweet Wesley",
			"quizzer3"=>"Person asking question 3,text|Buttercup",
			"Question 4,title",
			"Leave extra lines blank if there is no additional text,note",
			"riddle4a"=>"What is the first line of riddle 4?,text|If you find this grim tavern",
			"riddle4b"=>"What is the second line of riddle 4?,text|On your trips to the forest",
			"riddle4c"=>"What is the third line of riddle 4?,text|You can look at other people",
			"riddle4d"=>"What is the fourth line of riddle 4?,text|to see who's the poorest!",
			"riddle4e"=>"What is the fifth line of riddle 4?,text|",
			"answer4"=>"What is the correct answer?,text|Darkhorse",
			"letter4"=>"Which letter in the answer starts with the letter K?,range,1,20,1|4",
			"reminder4"=>"Where is the answer to this question from?,text|Darkhorse Tavern",
			"wrong4a"=>"What is wrong answer 1?,text|Hillbilly",
			"wrong4b"=>"What is wrong answer 2?,text|Eat At Joe's",
			"wrong4c"=>"What is wrong answer 3?,text|Cedrick",
			"wrong4d"=>"What is wrong answer 4?,text|Ye Olde Inn",
			"wrong4e"=>"What is wrong answer 5?,text|Boar's Head",
			"wrong4f"=>"What is wrong answer 6?,text|Red Dragon",
			"wrong4g"=>"What is wrong answer 7?,text|Mead and Stead",
			"wrong4h"=>"What is wrong answer 8?,text|Serf's Up",
			"wrong4i"=>"What is wrong answer 9?,text|Cornerstone",
			"quizzer4"=>"Person asking question 4,text|The Barkeeper",
			"Question 5,title",
			"Leave extra lines blank if there is no additional text,note",
			"riddle5a"=>"What is the first line of riddle 5?,text|You will need to improve your might..",
			"riddle5b"=>"What is the second line of riddle 5?,text|The dragon is the ultimate fight.",
			"riddle5c"=>"What is the third line of riddle 5?,text|When you're level 15 you will find your foe;",
			"riddle5d"=>"What is the fourth line of riddle 5?,text|But where is the great beast? This is where you go!",
			"riddle5e"=>"What is the fifth line of riddle 5?,text|",
			"answer5"=>"What is the correct answer?,text|Forest",
			"letter5"=>"Which letter in the answer starts with the letter R?,range,1,20,1|3",
			"reminder5"=>"Where is the answer to this question from?,text|The dragon's in the forest.",
			"wrong5a"=>"What is wrong answer 1?,text|Courtyard",
			"wrong5b"=>"What is wrong answer 2?,text|Degolburg",
			"wrong5c"=>"What is wrong answer 3?,text|Loveshack",
			"wrong5d"=>"What is wrong answer 4?,text|Underworld",
			"wrong5e"=>"What is wrong answer 5?,text|Hall of Fame",
			"wrong5f"=>"What is wrong answer 6?,text|Gardens",
			"wrong5g"=>"What is wrong answer 7?,text|Estates",
			"wrong5h"=>"What is wrong answer 8?,text|Fields",
			"wrong5i"=>"What is wrong answer 9?,text|Forum",
			"quizzer5"=>"Person asking question 5,text|Dragonslayer Doug",
			"Question 6,title",
			"Leave extra lines blank if there is no additional text,note",
			"riddle6a"=>"What is the first line of riddle 6?,text|Play with RSP Gnome",
			"riddle6b"=>"What is the second line of riddle 6?,text|For honor and fame",
			"riddle6c"=>"What is the third line of riddle 6?,text|This winner against scissors",
			"riddle6d"=>"What is the fourth line of riddle 6?,text|Will help win his game.",
			"riddle6e"=>"What is the fifth line of riddle 6?,text|",
			"answer6"=>"What is the correct answer?,text|Rock",
			"letter6"=>"Which letter in the answer starts with the letter C?,range,1,20,1|3",
			"reminder6"=>"Where is the answer to this question from?,text|Rock always beats scissors",
			"wrong6a"=>"What is wrong answer 1?,text|Candy",
			"wrong6b"=>"What is wrong answer 2?,text|Scissors",
			"wrong6c"=>"What is wrong answer 3?,text|Bomb",
			"wrong6d"=>"What is wrong answer 4?,text|Water",
			"wrong6e"=>"What is wrong answer 5?,text|Rust",
			"wrong6f"=>"What is wrong answer 6?,text|Lightning",
			"wrong6g"=>"What is wrong answer 7?,text|Paper",
			"wrong6h"=>"What is wrong answer 8?,text|Mead",
			"wrong6i"=>"What is wrong answer 9?,text|Mutton",
			"quizzer6"=>"Person asking question 6,text|The RPG Gnome",
			"Question 7,title",
			"Leave extra lines blank if there is no additional text,note",
			"riddle7a"=>"What is the first line of riddle 7?,text|Feeling whimpy?",
			"riddle7b"=>"What is the second line of riddle 7?,text|Feeling dim?",
			"riddle7c"=>"What is the third line of riddle 7?,text|Become this...",
			"riddle7d"=>"What is the fourth line of riddle 7?,text|At Tynan's Gym!",
			"riddle7e"=>"What is the fifth line of riddle 7?,text|",
			"answer7"=>"What is the correct answer?,text|Adonis",
			"letter7"=>"Which letter in the answer starts with the letter N?,range,1,20,1|4",
			"reminder7"=>"Where is the answer to this question from?,text|From Tynan's Gym Text",
			"wrong7a"=>"What is wrong answer 1?,text|Zeus",
			"wrong7b"=>"What is wrong answer 2?,text|Poseidon",
			"wrong7c"=>"What is wrong answer 3?,text|Beefcake",
			"wrong7d"=>"What is wrong answer 4?,text|Stonecutter",
			"wrong7e"=>"What is wrong answer 5?,text|Dumbbell",
			"wrong7f"=>"What is wrong answer 6?,text|Flexinator",
			"wrong7g"=>"What is wrong answer 7?,text|Hercules",
			"wrong7h"=>"What is wrong answer 8?,text|Perseus",
			"wrong7i"=>"What is wrong answer 9?,text|Apollo",
			"quizzer7"=>"Person asking question 2,text|Hera",
		),
		"prefs"=>array(
			"Quiz Game 1 User Preferences,title",
			"heardthis"=>"Has the player heard the opening Spiel?,bool|0",
			"current"=>"What riddle is the player currently solving?,int|0",
			"solved1"=>"Solved Riddle 1?,bool|0",
			"solved2"=>"Solved Riddle 2?,bool|0",
			"solved3"=>"Solved Riddle 3?,bool|0",
			"solved4"=>"Solved Riddle 4?,bool|0",
			"solved5"=>"Solved Riddle 5?,bool|0",
			"solved6"=>"Solved Riddle 6?,bool|0",
			"solved7"=>"Solved Riddle 7?,bool|0",
			"solved8"=>"Solved Riddle 8?,bool|0",
			"triedtoday"=>"Tried Today?,bool|0",
		),
	);
	return $info;
}

function quizgame1_install() {
	module_addhook("village");
	module_addhook("newday");
	module_addhook("newday-runonce");
	module_addhook("changesetting");
	module_addhook("bioinfo");
    module_addhook("footer-prefs");
    module_addhook("quiznav-quizload");
    module_addhook("quizload");
	return true;
}
function quizgame1_uninstall() {
	return true;
}

function quizgame1_dohook($hookname,$args) {
	global $session;
	switch($hookname) {
		case "changesetting":
			if ($args['setting'] == "villagename") {
				if ($args['old'] == get_module_setting("quizgame1loc")) set_module_setting("quizgame1loc", $args['new']);
			}
		break;
		case "quiznav-quizload":
			if (get_module_pref("solved8")==0) addnav(array("%s`0",get_module_setting("quizname")),"runmodule.php?module=quizgame1&op=quizgo");
		break;
		case "village":
			if (is_module_active('quizload')){
			}elseif (get_module_pref("solved8")==0 && $session['user']['location'] == get_module_setting("quizgame1loc")){
				tlschema($args["schemas"]["marketnav"]);
				addnav($args["marketnav"]);
				tlschema();
				addnav(array("%s`0",get_module_setting("quizname")),"runmodule.php?module=quizgame1&op=quizgo");
			}
		break;
		case "newday":
			set_module_pref("triedtoday",0);
		break;
		case "newday-runonce":
			increment_module_setting("currentlong",1);
			if (get_module_setting("resetquiz")==1){
       			$sql = "update ".db_prefix("module_userprefs")." set value=0 where value<>0 and setting='heardthis' and modulename='quizgame1'";
       			db_query($sql);
       			$sql = "update ".db_prefix("module_userprefs")." set value=0 where value<>0 and setting='triedtoday' and modulename='quizgame1'";
       			db_query($sql);				
       			$sql = "update ".db_prefix("module_userprefs")." set value=0 where value<>0 and setting='solved1' and modulename='quizgame1'";
       			db_query($sql);				
       			$sql = "update ".db_prefix("module_userprefs")." set value=0 where value<>0 and setting='solved2' and modulename='quizgame1'";
       			db_query($sql);				
       			$sql = "update ".db_prefix("module_userprefs")." set value=0 where value<>0 and setting='solved3' and modulename='quizgame1'";
       			db_query($sql);				
       			$sql = "update ".db_prefix("module_userprefs")." set value=0 where value<>0 and setting='solved4' and modulename='quizgame1'";
       			db_query($sql);				
       			$sql = "update ".db_prefix("module_userprefs")." set value=0 where value<>0 and setting='solved5' and modulename='quizgame1'";
       			db_query($sql);				
       			$sql = "update ".db_prefix("module_userprefs")." set value=0 where value<>0 and setting='solved6' and modulename='quizgame1'";
       			db_query($sql);				
       			$sql = "update ".db_prefix("module_userprefs")." set value=0 where value<>0 and setting='solved7' and modulename='quizgame1'";
       			db_query($sql);				
       			$sql = "update ".db_prefix("module_userprefs")." set value=0 where value<>0 and setting='solved8' and modulename='quizgame1'";
       			db_query($sql);				
				set_module_setting("resetquiz",0);
				set_module_setting("quizhold",0);
				set_module_setting("currentlong",0);
				set_module_setting("currentwin",0);
			}
		break;
	}
	return $args;
}

function quizgame1_run(){
	$op = httpget('op');
	global $SCRIPT_NAME;
	if ($SCRIPT_NAME == "runmodule.php"){
		$module=httpget("module");
		if ($module == "quizgame1"){
			include("modules/quizgame1/quizgame1.php");
		}
	}
}
?>