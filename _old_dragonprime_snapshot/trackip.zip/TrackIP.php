
// CR Dasher
// 14th March 2004
// log IP and proxy to the user's debuglog
// Helps track abuse/hacking/etc
// Goes in login.php - just after $session[sentnotice]=0;


if ($_SERVER['HTTP_X_FORWARDED_FOR']) {
	if ($_SERVER['HTTP_CLIENT_IP']) {
		$proxy = $_SERVER['HTTP_CLIENT_IP'];
	} else {
		$proxy = $_SERVER['REMOTE_ADDR'];
	}
	$ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
} else {
	if ($_SERVER['HTTP_CLIENT_IP']) {
		$ip = $_SERVER['HTTP_CLIENT_IP'];
	} else {
		$ip = $_SERVER['REMOTE_ADDR'];
	}
}
if (isset($proxy)) {
	$ip .= " through Proxy: ".$proxy;
}
debuglog("Client connected from IP: ".$ip);
//