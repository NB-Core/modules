<?
//=======================================
//Q's Quick Gold v1.0 Final
//By: bwatford
//March 2004
//http://ftpdreams.com/new/lotgd
//WHAT DOES IT DO?
//You can place this script in any shop section that is away from the bank so that
//the users cab make a quick withdraw of all there funds. Simular to the Eagle Banking
//script which allows quick deposits.
//=======================================

require_once "common.php";
page_header("Q's Quick Gold");
output("`^`c`bInstant Withdraw`b`c`6");
addnav("Return to The Promenade","promenade.php");
//output("`c<img src='images/eagle.gif' width='200' height='230' align='right' alt='InstantBank'>`c",true);
if($HTTP_GET_VARS[op]==""){
        $_POST[amount]=$session[user][goldinbank];
        }if ($session[user][goldinbank]>=0){
        output("Q looks up at you and then at his books. He waves a magic wand and *poof* all your gold in the bank is now laying in front of you. He gives you a note on how much money you have withdran and how much you have in the bank now.");
        output("`^`b`nYou have withdrawn `&$_POST[amount]`^ gold from your bank account. ");
        debuglog("withdrawn " . $_POST[amount] . " gold in the bank");
        $session[user][goldinbank]-=$_POST[amount];
        $session[user][gold]+=$_POST[amount];
         }else{
        output("\"`3You have have a `&debt`3 of `^".abs($session[user][goldinbank])." gold`3 at the bank, you cannot use instant withdraw until you payoff your debt. ");
       debuglog("Withdraw not allowed, user has debt");

}
page_footer();

?>

