<?php
/**************
Name: Fairy Dragon
Author: Eth - ethstavern(at)gmail(dot)com 
Version: 1.3
Release Date: 01-22-2005
About: Find a little fairy dragon, make him/her your companion.
	   He fights by your side, learns magic spells, accompanies
	   you just about everywhere, too. 
Bugs: None that I know of at the moment. But, that may not be true...
Special thanks to Sichae and xChrisx from Dragonprime for helping to make
translation compatible.
*****************/
require_once("lib/http.php");
require_once("lib/villagenav.php");
require_once("lib/buffs.php");

function fairydragon_getmoduleinfo(){
    $info = array(
        "name"=>"Fairy Dragon",
        "version"=>"1.3",
        "author"=>"Eth",
        "category"=>"Pets",
        "download"=>"http://dragonprime.net/users/Eth/fairydragon.zip",
        "vertxtloc"=>"http://dragonprime.net/users/Eth/",
        "settings"=>array(
            "Fairy Dragon - Main Settings,title",             
			"defaultname"=>"What is the default name for the Fairy Dragon,text|Pip",
            "fairychance"=>"Raw Chance of finding a fairy dragon,range,0,100,5|10",
            "fairydk"=>"How many DK's needed to possess Fairy Dragon?,int|0",  
            "maxfd"=>"How many Fairy Dragons are available?,int|10",  
            "totalfd"=>"How many Fairy Dragons are in play at the moment?,int|0",           
            "fdlifespan"=>"Initial lifespan (in game days) of Fairy Dragon,int|15",
            "fdnamemax"=>"Maximum characters for Fairy Dragon name,int|12",             
            "canlose"=>"Chance to lose Fairy Dragon on DK?,bool|0",
            "Fairy Dragon - Battle Settings,title",
            "fdauto"=>"Can fairy dragon attack automatically?,bool|1", 
            "fdexp"=>"Experience points rewarded after battle,int|50",
            "fdexpgain"=>"Gain a use point per how many exp points?,int|1000", 
            "mindamage"=>"Min damage of attack,int|5",
            "maxdamage"=>"Max damage of attack,int|8",
            "Fairy Dragon - Magic Settings,title",            
            "fdusesmax"=>"Base times Fairy Dragon can use his magic per day,int|5",  
            "fdusescap"=>"Max times Fairy Dragon can use his magic per day,int|15",                       
            "fdbonus"=>"Can Fairy Dragon cast protective aura on player?,bool|1",
            "This deals with his first spell: Scintillating Bolt,note",
            "fdexp1"=>"Exp points to gain Scintillating Bolt?,int|500",
            "sp1min"=>"Min damage Scintillating Bolt,int|5",
            "sp1max"=>"Max damage Scintillating Bolt,int|8",
            "This deals with his second spell: Magical Healing,note",
            "fdexp2"=>"Exp points to gain Magical Healing?,int|1000",  
            "This deals with his third spell: Lightning Storm,note",          
            "fdexp3"=>"Exp points to gain Lightning Storm?,int|2000",
            "sp3num"=>"How man bolts are cast?,int|4",
            "sp3min"=>"Min Damage per Bolt,int|7",
            "sp3max"=>"Max damage per Bolt,int|18",       
            "Immortality ignores the age of the critter - as he no longer can die of old age,note",    
            "fdimmortalexp"=>"How much Experience needed to become immortal?,int|10000",            
        ),
        "prefs"=>array(
         	"Fairy Dragon - User Settings,title",
         	"foundfairydragon"=>"Found one yet?,bool|0",
            "fairyname"=>"What's it's name?|Pip",
            "fairydragonage"=>"Pet's Age?,int|0",
            "fairydragonexp"=>"Pet's Experience?,int|0",                                  
            "fairydragonlifespan"=>"Lifespan of Fairy Dragon in Game Days,int|15",
            "fdsex"=>"Fairy Dragon Sex,enum,0,Male,1,Female",            
            "broughtgift"=>"Has it brought you a gift today?,bool|0",                 
            "fdperm"=>"Is Fairy Dragon immortal?,bool|0",             
            "Fairy Dragon - Magic Settings,title",            
            "fduses"=>"Magic uses per day,int|5",            
            "fdgift"=>"Seen immortal message yet?,bool|0",                              
        )
    );
    return $info;
}
function fairydragon_install(){
	module_addeventhook("forest", "require_once(\"modules/fairydragon.php\"); return fairydragon_test();");
    module_addhook("village");
	module_addhook("gardens");
	module_addhook("forest");
	module_addhook("newday");
	module_addhook("charstats");
	module_addhook("graveyard-desc");	
	module_addhook("biostat");
	module_addhook("dragonkill");
	module_addhook("battle");
	module_addhook("battle-victory");
	module_addhook("battle-defeat");
	module_addhook("fightnav-specialties");
	module_addhook("apply-specialties");
	return true;
}
function fairydragon_uninstall(){
	return true;
}
function fairydragon_reset($id){
	global $session;
	$maxuses = get_module_setting("fdusesmax");
	$tfd = get_module_setting("totalfd");
	$lifespan = get_module_setting("fdlifespan");
	set_module_pref("foundfairydragon", 0);
	set_module_pref("fairydragonage", 0);	
	set_module_pref("fduses", $maxuses);
	set_module_pref("fdperm", 0);
	set_module_pref("fairydragonexp", 0);
	set_module_pref("fdgift", 0);				
	set_module_pref("fairydragonlifespan", $lifespan);
	set_module_setting("totalfd", $tfd-1);
	set_module_setting("maxfd",get_module_setting("maxfd")+1);
	return true;
}
function fairydragon_test(){
	global $session;	
	$chance = get_module_setting("fairychance","fairydragon");
	if (get_module_pref("foundfairydragon","fairydragon") == 1) return 0; 
	return $chance; 
}
function fairydragon_dohook($hookname,$args){
    global $session; 
    $haspet = get_module_pref("foundfairydragon");
    $petname = get_module_pref("fairyname");  
    $petage = get_module_pref("fairydragonage"); 
    $petlifespan = get_module_pref("fairydragonlifespan");
    $petexp = get_module_pref("fairydragonexp");
    $petexpbonus = get_module_setting("fdexp");
    $halfgrown =  round($petlifespan/2); 
    $maxuses = get_module_setting("fdusesmax");      
    $neardeath = abs($petlifespan-2);    
    $immortal = get_module_pref("fdperm"); 
    $exploss = round($petexp*.25); 
    $fdsex = get_module_pref("fdsex");      
	switch($hookname){
	case "graveyard-desc":
	if ($haspet==1){
		$event = e_rand(1,4);
		switch($event){
			case 1:
			output("`n`n%s`2, quite afraid, hides in your backpack as you float about the graveyard.`n", $petname);
			break;
			case 2:
			output("`n`n%s `2looks about the underworld in a trance-like state.", $petname);
			break;
			case 3:
			output("`n`n`2Feeling bolder,%s `2snarls as another shade floats by.`n", $petname);
			break;
			case 4:
			output("`n`n`2%s `2is clearly annoyed at being dead. `n", $petname);
			break;
		}	
	}
	break;
	case "dragonkill":
	if ($haspet==1){
		$sex = translate_inline($fdsex?"her":"him");
		if (get_module_setting("canlose") && e_rand(1,3) == 1){		
			output("`n`2You stop and pause a moment as you see a `%small, brightly colored creature `2flying off into the forest at a frenzied pace.");
			output(" `2You have a vague feeling that you once knew that little critter.");
			output(" `2Shrugging your shoulders, you continue on your way.`n`n");
			fairydragon_reset($session['user']['acctid']);
		}else{
			output("`n`2You stop and stare a moment at the strange little creature that has landed upon your shoulder.");
			output(" It gives a concerned squeak, and stares at you quizically.");
			output(" You have a vague feeling of knowing this critter, and decide to continue on your way with %s in tow.`n`n",$sex);
			//even though you get to keep him, he loses some of his experience.
			set_module_pref("fairydragonexp", $exploss);	
		}
	}
	break;
	case "battle":
	$uses = get_module_pref("fduses");
	if ($haspet==1){
		if ($args['type'] == "dragon") {
			output("`@%s `2 seems visibly nervous at the sight of the `@Green Dragon!`n", $petname);
		}else if ($args['type'] == "graveyard") {
			output("`@%s `2seems paralyzed at the sight of the undead fiend before you.`n", $petname);
		}else if ($args['type'] == "pvp") {
			output("`@%s `2flies off to one side as you prepare to do battle with a fellow warrior.`n", $petname);
		}else if ($args['type'] == "train"){
			output("`@%s `2flies off to one side as you prepare to do battle with your master.`n", $petname);
		}else{
			output("`@%s `2perches on your shoulder, awaiting the chance to do battle.`n", $petname);
		}
		//apply pet's attack/buff only in battle
		//apply whatever other types you'd like here. Or remove. Either way...
		if ($args['type']=="forest" || $args['type'] == "dragon"){	
			if (get_module_setting("fdauto") == 1){
				$min = get_module_setting("mindamage");
				$max = get_module_setting("maxdamage");	
				apply_buff('fdattack', array(
					"startmsg"=>"$petname `5growls as {badguy} draws closer.",
					"name"=>"$petname's `^Attack",
					"rounds"=>-1,
					"wearoff"=>"",
					"minioncount"=>1,
					"effectmsg"=>"$petname `5viciously snaps at {badguy} and causes `^{damage}`5 damage.",
					"effectnodmgmsg"=>"{badguy} `5narrowly dodges $petname's`5 snapping jaws.",
					"effectfailmsg"=>"{badguy} `5narrowly dodges $petname's`5 snapping jaws.",
					"minbadguydamage"=>$min,
					"maxbadguydamage"=>$max,
					"schema"=>"fairydragon"
				));
			}
		}															
	}	
	break;
	case "battle-victory":	
	if ($haspet==1){	
	strip_buff("fdattack");	
	//reward pet with some experience points...
	$petexptotal = round($petexpbonus+$session['user']['level']);
	$sex = translate_inline($fdsex?"her":"his");		
	output("%s `@squeaks in delight over your victory.`n", $petname);
		//let's only reward him/her for battles they fought in
		if ($args['type']=="forest" || $args['type'] == "dragon"){
			set_module_pref("fairydragonexp", $petexp+$petexptotal);
			output("%s `@is also awarded `^%s experience points `@for %s role in the battle!`n", $petname, $petexptotal, $sex);
		}
	}
	break;
	case "battle-defeat":	
	if ($haspet == 1) strip_buff("fdattack");		
	break;
	//this is going to be long...
	case "newday":		
	$sex = translate_inline($fdsex?"she":"he");
	$sex2 = translate_inline($fdsex?"her":"his");
	$sex3 = translate_inline($fdsex?"herself":"himself");		
	if ($haspet == 1){		
		if ($immortal == 1) set_module_pref("fairydragonage", 0);				
		else{ set_module_pref("fairydragonage", get_module_pref("fairydragonage")+1);}
		//if fairy dragon dies...
		if ($petage==$petlifespan){
		output("`n`@You are deeply saddened to find that %s `@has passed away!",$petname);
		output(" As a result, you don't feel much like adventuring today.`0`n");
		fairydragon_reset($session['user']['acctid']);		
		$session['user']['turns'] = round($session['user']['turns']*.50);
		addnews("`2Sad news today, for %s's `2pet `5Fairy Dragon `2has passed away.", $session['user']['name']);
		//otherwise...
		}else{
			//this is where he becomes immortal!
			if (!get_module_pref("fdperm")){
				if (get_module_pref("fairydragonexp")>=get_module_setting("fdimmortalexp")) {
					set_module_pref("fdperm", 1);		
					if ($message==0){
						output("`n`b`@Amazing! %s `@has learned a new spell to make %s immortal!`b`n", $petname, $sex3);
						set_module_pref("fdgift", 1);
					}
				}
			}
			//as he ages, he can cast a spell on you. He also gains these abilities if he's immortal
	    	if ($petage>=$halfgrown OR $immortal==1){
		    	if (e_rand(1,3)==1 && get_module_setting("fdbonus") == 1){  
					output("`n%s `2then suprises you by casting a protective aura around you!`n", $petname);
					apply_buff('fdaura', array(
					"name"=>"`^$petname's `^Aura",
					"rounds"=>-1,
					"wearoff"=>".",
					"defmod"=>1.15,			
					"roundmsg"=>"",
					));
				}
			}	
			//end special gift	
			if ($petage>=$neardeath){
				output("`n%s `2seems to be moving a little slower today as %s emerges from your pack.",$petname, $sex);
				output(" Looking into %s eyes, %s seems much older and powerful.`n", $sex2, $sex2);
			}else{
	    	output("`n`5%s `2gives a yawn as %s sticks %s head from your pack.",$petname, $sex, $sex2);
			output(" Soon, %s is perched upon your shoulder, ready for the day's adventure.`0`n", $sex);
    	} 	 
		set_module_pref("broughtgift", 0); 				
		$message = get_module_pref("fdgift"); 
		$giftexp = get_module_setting("fdimmortalexp"); 
		$expgain = get_module_setting("fdexpgain"); 
		$usecap = get_module_setting("fdusescap");
		set_module_pref("fduses", $maxuses);
		//calculates number of extra magic uses fairy dragon gains...
		$bonususes = floor($petexp/$expgain);	
		//set number of uses here...
		set_module_pref("fduses", get_module_pref("fduses")+$bonususes);		
		//then run a check to see if they go over the allowed cap
		$fduc = get_module_pref("fduses");	
		if ($fduc>$usecap){
			//if so, reset uses to maximum cap		
			set_module_pref("fduses", $usecap);
		}
		//then continue on as normal
		$totaluses = get_module_pref("fduses");		
		output("`n`5You can call upon %s `5to use %s special powers in battle `^%s `5times today!`n",$petname,$sex2,$totaluses); 				
		}		
	}  		
	break;
	case "charstats": 	
	$sex = translate_inline($fdsex?"Female":"Male");		
    	if ($haspet==1){
	    $totaluses = get_module_pref("fduses");	    	        
	    addcharstat("Companion Pet Info");
    	addcharstat("Pet", "`5Fairy Dragon");
    	if ($session['user']['alive']){	addcharstat("Pet Name", $petname);	    	
    	}else{ addcharstat("Pet Name", "$petname's Ghost"); }
      	if ($immortal==1){ addcharstat("Pet Age", "`6Immortal"); 
      	//note - don't remove the color codes!    	
		}else if  ($petage==0){ addcharstat("Pet Age", "Newborn");
    	}else if ($petage==1){ addcharstat("Pet Age", sprintf_translate("`@%s Day", $petage));
    	}else if ($petage<$halfgrown){ addcharstat("Pet Age", sprintf_translate("`@%s Days", $petage));
    	}else if ($petage>=$neardeath){	addcharstat("Pet Age", sprintf_translate("`\$%s Days", $petage));	    
	    }else{	addcharstat("Pet Age", sprintf_translate("%s Days", $petage)); }
	    addcharstat("Gender", "$sex");
        if ($totaluses==1){ addcharstat("Magic Points", "`\$$totaluses Use Left");			
		}else if ($totaluses==0){ addcharstat("Magic Points", "None");
        }else{ addcharstat("Magic Points", "$totaluses Uses Left"); }		
		addcharstat("Experience", "$petexp");
        }
    break;
    case "biostat":
    	$ownspet = get_module_pref("foundfairydragon", "fairydragon", $args['acctid']);			
		$pettype = "`5Fairy Dragon";
		if ($ownspet==1){
			output("`^Pet: `@%s`n",$pettype);
		}
		break;
    case "village":
    $petsex = translate_inline($fdsex?"her":"his");
    if ($haspet==1){
	    $event = e_rand(1,6);
	    $broughtgift = get_module_pref("broughtgift");	   		    
	    switch ($event){
		    case 1:	
		    if ($broughtgift==0){			
	    		output("`n%s `2takes off and returns moments later with something small clutched in %s jaws! Perhaps you", $petname, $petsex);
				$navop = translate_inline("should take a look");		
	   			rawoutput("<a href='runmodule.php?module=fairydragon&op=mouth'> [$navop].</a><br>");
	    		addnav("", "runmodule.php?module=fairydragon&op=mouth");   
			}else{
				output("`n%s `2gives a small yawn and looks about the area in a sleepy stupor.`0`n", $petname);
			}			    	    
		    break;
		    case 2:
		    output("`n`2%s `2sits upon your shoulder, gazing about the town as you walk on through.`0`n", $petname);
		    break;
		    case 3:
		     output("`n`2Muffled snoring sounds can be heard from your backpack as %s `2enjoys a brief nap.`0`n", $petname);
		    break;
		    case 4:
		    output("`n`2As you wander about town, %s `2suddenly flies off.", $petname);
			output(" A startled scream is heard moments later followed by a `5brightly colored blur `2that suddenly buries itself in your backpack.`0`n");	    
		    break;
		    case 5:
		    output("`n`2%s `2looks somewhat bored as you wander around town doing your errands.`0`n", $petname);
		    break;
		    case 6:
		    output("`n`2Villagers in passing stop to stare in wonder at your little `5fairy dragon`2.");
			output(" %s `2seems to find this quite amusing.`0`n", $petname);
		    break;
	    }	    	 	   	
    } 
    break;
    case "gardens":
    $petsex = translate_inline($fdsex?"she":"he");
    if ($haspet==1){
	    $event = e_rand(1,4);
	    switch($event){
		    case 1:
		    output("%s `2hunts for mice in the flower patches as you stroll through the gardens.`0`n`n", $petname);
		    break;
		    case 2:
		   	output("%s `2flushes out a `&small white rabbit `2and proceeds to give chase throughout the gardens.`n`n", $petname);
		    break;
		    case 3:
		    output("`2As you stop to smell the `\$roses`2, %s `2decides to make a meal out of a fairy!`n`n", $petname);
	 		addnews("%s's `2pet was seen `@devouring `2a `5fairy `2in the gardens!", $session['user']['name']);
		    break;
		    case 4:
		    output("%s `2has a sneezing fit as %s hunts for mice among a patch of daisies.`n`n", $petname, $petsex);
		    break;
	    }	    		
    }
    break;  
    case "fightnav-specialties":
		$uses = get_module_pref("fduses");
		$script = $args['script'];
		$fdskillname = translate_inline("`5Fairy Dragon Powers");
		$fd1 = translate_inline("`\$Scin`4tilla`\$ting `4B`\$ol`4t");
		$fd2 = translate_inline("`3Ma`#gi`3cal `#He`3al`#ing");
		$fd3 = translate_inline("`^Li`6ghtn`^ing `6St`^or`6m");
		$sp1 = get_module_setting("fdexp1");
		$sp2 = get_module_setting("fdexp2");
		$sp3 = get_module_setting("fdexp3");			
		if ($uses > 0 && $haspet==1 && $petexp>=$sp1 OR $immortal==1 && $uses > 0) {
			addnav(array("%s`0", $fdskillname), "");
			addnav(array("&#149; %s`7 (%s)`0", $fd1, 1), $script."op=fight&fd=1", true);
		}
		if ($uses > 1 && $haspet==1 && $petexp>=$sp2 OR $immortal==1 && $uses > 1){
			addnav(array("&#149; %s`7 (%s)`0", $fd2, 2), $script."op=fight&fd=2", true);
		}
		if ($uses > 4 && $haspet==1 && $petexp>=$sp3 OR $immortal==1 && $uses > 4){
			addnav(array("&#149; %s`7 (%s)`0", $fd3, 5), $script."op=fight&fd=5", true);
		}
	break;  
	case "apply-specialties":
	if ($haspet==1){
	$fd = httpget('fd');
	$petname = get_module_pref("fairyname");
		if (get_module_pref("fduses") >= $fd){
				switch($fd){				
				case 1:			
				$min = get_module_setting("sp1min");
				$max = get_module_setting("sp1max");	
				apply_buff('fd1', array(
						"startmsg"=>"$petname `5shoots a multicolored bolt of energy at {badguy}!",
						"name"=>"$fd1",
						"rounds"=>1,
						"wearoff"=>"",
						"minioncount"=>1,
						"effectmsg"=>"$petname's `5searing bolt hits  {badguy} for `^{damage}`5 points of damage.",
						"minbadguydamage"=>$min,
						"maxbadguydamage"=>$max,
						"schema"=>"fairydragon"
					));
				break;
				case 2:
				apply_buff('fd2', array(
						"startmsg"=>"$petname `^ casts a healing aura around you!",
						"name"=>"$fd2",
						"rounds"=>1,
						"wearoff"=>"",
						"regen"=>$session['user']['level']*10,
						"effectmsg"=>"$petname's `^aura heals you for `6{damage}`^ points.",
						"effectnodmgmsg"=>"$petname's `^aura fails as you have no wounds to heal.",
						"schema"=>"fairydragon"
					));
				break;
				case 3:
				break;
				case 4:
				break;
				case 5:
				$num = get_module_setting("sp3num");
				$min = get_module_setting("sp3min");
				$max = get_module_setting("sp3max");
				apply_buff('fd5', array(
						"startmsg"=>"$petname `^summons forth a blazing ball of lightning!",
						"name"=>"$fd3",
						"rounds"=>1,
						"wearoff"=>"",
						"minioncount"=>$num,
						"effectmsg"=>"`^A bolt of lightning hits  {badguy} for `6{damage}`^ points of damage.",
						"minbadguydamage"=>$min,
						"maxbadguydamage"=>$max,
						"effectfailmsg"=>"{badguy} `^narrowly dodges $petname's `^lightning storm.",
						"schema"=>"fairydragon"
					));
				break;			
			}
			set_module_pref("fduses", get_module_pref("fduses") - $fd);		
		}
	}	
	break;
   	}
   	return $args;
}
function fairydragon_runevent($type) {
	global $session;
	$from = "runmodule.php?module=fairydragon&";	
	if ($type == "forest") $from = "forest.php?";	
	$haspet = get_module_pref("foundfairydragon");
    $petname = get_module_pref("fairyname");        
    $maxfd = get_module_setting("maxfd"); 
    $totalfd = get_module_setting("totalfd");   
    $dk = $session['user']['dragonkills'];
    $dkneeded = get_module_setting("fairydk");    
    $fdsex = get_module_pref("fdsex"); 
    $petsex = translate_inline($fdsex?"she":"he");
    $petsexc = translate_inline($fdsex?"She":"He");
    $petsex2 = translate_inline($fdsex?"her":"him");
    $petsex3 = translate_inline($fdsex?"her":"his");
    $namemax = get_module_setting("fdnamemax");
    $session['user']['specialinc'] = "module:fairydragon";	
    $op = httpget('op');    
    output_notl("`n");
	switch ($type) {	
	case forest:	
		if ($op=="" || $op=="search") {	
			//this is just for admins really, in case they click the specials link and already have a critter
			if ($haspet == 1){
				output("`2Returning to the glen you found %s `2in, you look around and find nothing of interest.`n`n", get_module_pref("fairyname"));	
				addnav("Ditch the Dragon",$from."op=ditch");
				//$session['user']['specialinc']="";	
				addnav("Back to Forest",$from."op=leave");
			}else{
				//if they haven't found one yet
				output("`2While questing through the forest, you happen upon a small, tranquil glen.");
				output(" `2Deciding this would be a good time for a nap, you begin walking towards the lone oak tree that grows within it's center.`n`n");								
				//if max number of fairy dragons have been found...
				if ($totalfd>=$maxfd){
					output("`2Not noticing anything out of the ordinary, you settle in for a long and comfortable nap.`n`n");					
					output("`2Upon waking up, you feel a strange aura emanating from the glen.");
					output(" `2There's something special about this place, you conclude, as you gather your things and depart.`n`n");
					//$session['user']['hitpoints'] = $session['user']['maxhitpoints'];					
					$session['user']['specialinc']="";	
					//otherwise, if they don't have enough dragonkills to own a pet...				
				}else if ($dk<$dkneeded){
					output("`2However, as you walk towards the tree, a small, brightly-colored object suddenly flits out from a thick bush nearby.");
					output(" `2Before you can judge what the creature might be, it is gone; leaving you a tiny bit spooked.");
					output(" You decide now would not be a good time for a nap.`n`n ");
					$session['user']['specialinc']="";									
				//otherwise, give em one!
				}else{
					output("`2However, as you walk towards the tree, a small, brightly-colored object suddenly flits out from a thick bush nearby.");
					output(" `2It alights upon your shoulder, and stares at you with a bemused smirk upon it's tiny snout.`n`n");
					output("`2The small creatures looks quite like a miniature dragon; no bigger then a chicken and covered in iridescent scales.");
					output(" You once heard a bard at an inn describe a similar creature.");
					output(" He referred to it as a `5Fairy Dragon`2, said to be quite legendary...and mischievous.`n`n");
					output("`2The little dragon appears to be quite eager to join you in your journeys.");
					output(" Would you like to take it along with you?");
					addnav("Take Fairy Dragon", $from . "op=take");
					addnav("Leave It Behind", $from . "op=leave");	
				}		
			}
		}else if ($op == "ditch"){
			output("`2For whatever reasons, you decide to leave %s `2behind in the glen.`n`n", $petname);
			fairydragon_reset($session['user']['acctid']);
			$session['user']['specialinc']="";				
		}else if ($op=="take"){
			//let's set a random gender here...
			if (e_rand(0,1) == 0){set_module_pref("fdsex", 1); }
			else{set_module_pref("fdsex", 0); }
			$fdsex = get_module_pref("fdsex"); 
			$petsex = translate_inline($fdsex?"she":"he");
    		$petsexc = translate_inline($fdsex?"She":"He");
    		$petsex2 = translate_inline($fdsex?"her":"him");
    		$petsex3 = translate_inline($fdsex?"her":"his");
			$gender = get_module_pref("fdsex");
			output("`n`2Deciding to take the little critter with along with you, you stop and pause a moment.");
			output(" %s doesn't have a name. Perhaps you should give %s one?`n`n", $petsexc, $petsex3);
			output("`6Maximum of `^%s `6letters and you can use colors in `^%s`6 name as well.`2`n`n", $namemax, $petsex2);
			//naming time!
			rawoutput("<form action='forest.php?op=name' method='POST'>");
			rawoutput("<input name='fairyname' id='fairyname' width='10' maxlength='$namemax'>");
			rawoutput("<input type='submit' class='button' value='".translate_inline("Name Dragon")."'>");
			rawoutput("</form>");			
			addnav("", $from . "op=name");			
			addnav("Leave It Behind Instead", $from . "op=leave");	
		}else if ($op=="name"){
			$name = httppost('fairyname');
			$defaultname = get_module_setting("defaultname");
			$lifespan = get_module_setting("fdlifespan");
			$maxuses = get_module_setting("fdusesmax");
			//in case the player enters no name, this will assign a default name
			if ($name=="") set_module_pref("fairyname", $defaultname);
			else set_module_pref("fairyname", $name);
			//			
			set_module_pref("foundfairydragon", 1);			
			set_module_pref("fairydragonexp", 0);					
			set_module_pref("fairydragonlifespan", $lifespan);			
			set_module_pref("fduses", $maxuses);
			set_module_setting("maxfd", get_module_setting("maxfd")-1);
			if (get_module_setting("maxfd")<0) set_module_setting("maxfd",0);
			set_module_setting("totalfd", $totalfd +1); 
			//				
			$newname = get_module_pref("fairyname");
			$petsexc = translate_inline($fdsex?"She":"He");
			$petsex2 = translate_inline($fdsex?"herself":"himself");
			output("`n`2You decide to name your new pet `b%s`b`2.", $newname);
			output(" %s `2squeaks in delight, and promptly buries %s in your backpack.", $petsexc, $petsex2);
			output(" You just hope the little dragon is pack-trained...`n`n");
			addnews("%s`2 discovered a `5Fairy Dragon `2in the `@Forest `2today!", $session['user']['name']);
			$session['user']['specialinc']="";
		}else if ($op=="leave"){	
			output("`n`2You decide it would be in your best interest to leave the little dragon behind in the glen.");
			output(" You're not one for causing trouble, and there's no telling what mischief this rascal could bring.`n`n");		
			$session['user']['specialinc']="";			
		}
		break;							
	}	
}
function fairydragon_run(){	
	global $session;
	page_header("Fairy Dragon Antics");
	$op = httpget("op");
	$from = "runmodule.php?module=fairydragon&";	
	$chance = (e_rand(1,3));
	$petname = get_module_pref("fairyname");
	$broughtgift = get_module_pref("broughtgift");
	$fdsex = get_module_pref("fdsex");
	$petsex = translate_inline($fdsex?"she":"he");	
	if ($op=="mouth"){		
		output("`c`b`2Fairy Dragon Antics`b`c`n`n");
		output("`2Leaning down, you get a closer look at what's clutched in %s's `2jaw.`n`n", $petname);
		switch ($chance){
			case 1:
			output("%s `2drops a `\$gleaming gemstone `2at your feet!",$petname);
			output(" Seems to be your lucky day.");
			output(" You then wonder where the little dragon stole it from...`n`n ");
			$session['user']['gems']++;
			break;
			case 2:
			output("`2It appears to be something furry and...`n`n");
			output("%s `2drops a dead mouse at your feet and looks up at you with an impish smirk.", $petname);
			output(" While you're hungry, you're not `ithat`i hungry. Yugh...`n`n");
			break;
			case 3:
			output("`2Something small and golden is held in %s's `2mouth.",$petname);
			output(" Without hesitation, %s drops the `^gold coin `2in your hand.", $petsex);
			output(" You wonder where %s found it as you stuff it into your coin pouch.`n`n", $petsex);
			$session['user']['gold']++;
			break;			
		}
		set_module_pref("broughtgift", 1);		
		villagenav();					
	}	
page_footer();
}
?>