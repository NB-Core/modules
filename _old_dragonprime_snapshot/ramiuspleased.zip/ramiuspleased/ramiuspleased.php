<?
/*
Details:
 * This is a module that resurrects every third user if Ramius is 'pleased'
 * Otherwise, he doubles your favour (if he is pleased)
Version Log:
 v1.0:
 o Seems to be Stable
*/
require_once("lib/http.php");
require_once("lib/villagenav.php");
require_once("lib/addnews.php");

function ramiuspleased_getmoduleinfo(){
	$info = array(
		"name"=>"Ramius is Pleased",
		"author"=>"`@CortalUX",
		"version"=>"1.0",
		"category"=>"Graveyard",
		"download"=>"http://www.dragonprime.net/users/CortalUX/ramiuspleased.zip",
		"vertxtloc"=>"http://dragonprime.net/users/CortalUX/",
		"settings"=>array(
			"Ramius is Pleased,title",
			"pleased"=>"Is Ramius pleased?,bool|0",
			"favor"=>"Allow increase of favor?,bool|0",
			"count"=>"Count so far?,int|0",
		),
		"prefs"=>array(
			"Ramius is Pleased,title",
			"ttoday"=>"Times today?,int|0",
		),
	);
	return $info;
}
function ramiuspleased_install(){
	module_addhook("mausoleum");
	module_addhook("footer-graveyard");
	module_addhook("battle-defeat");
	module_addhook("newday");
	return true;
}
function ramiuspleased_uninstall(){
	return true;
}
function ramiuspleased_dohook($hookname,$args){
	global $session,$victory,$op;
	switch ($hookname){
		case "mausoleum":
			if (get_module_setting('pleased')==1&&get_module_setting('count')>=3) {
				redirect("runmodule.php?module=ramiuspleased&op=resurrect");
				die();
			}
		break;
		case "newday":
			if (get_module_setting('favor')==1) {
				$count = get_module_pref('ttoday');
				if (!is_numeric($count)) $count=0;
				if ($count>0) {
					output("`n`\$Ramius`@ doubled your favour, and now that you left him.. he has set it back to normal!");
				}
				while ($count>0) {
					$session['user']['deathpower']=$session['user']['deathpower']/2;
					$count--;
				}
				$session['user']['deathpower']=round($session['user']['deathpower']);
				if ($session['user']['deathpower']<0) {
					$session['user']['deathpower']=0;
				}
				set_module_pref('ttoday',0);
			}
		break;
		case "footer-graveyard":
			if (get_module_setting('pleased')==1&&get_module_setting('count')<3&&get_module_setting('favor')==1) {
				if ($victory===true&&$op==0) {
					$count = get_module_pref('ttoday');
					$count++;
					set_module_pref('ttoday',$count);
					$session['user']['deathpower']+=$session['user']['deathpower'];
					output("`n`\$Ramius`@ doubles your favor!");
				}
			}
		break;
		case "battle-defeat":
			if ($args['type']=="forest"&&get_module_setting('pleased')==1) {
				$count = get_module_setting('count');
				$count++;
				set_module_setting('count',$count);
				if ($count>=3) {
					 addnews("`\$Ramius`@ is so pleased, he will resurrect the next user to see him.");
				}
			}
		break;
	}
	return $args;
}
function ramiuspleased_run(){
	global $session;
	$op = httpget('op');
	switch ($op) {
		case "resurrect":
			page_header("Resurrection");
			set_module_setting('count',0);
			output("`n`\$Ramius`@ is so pleased with you, he resurrects you upon sight!");
			addnav("Continue","newday.php?resurrection=true");
			addnews("`\$Ramius`@ has resurrected `^%s`0`@.",$session['user']['name']);
			page_footer();
		break;
	}
	page_footer();
}
?>