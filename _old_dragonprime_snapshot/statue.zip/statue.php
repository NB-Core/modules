<?php

 //09092005

 /* ******************
 Codierung von Ray
 Ideen von Ray
 Einige �nderungen von Anpera
 ICQ:230406044
 ******************* */

 if (!isset($session)) exit();
 if ($_GET['op']==""){
 output("`n`c`b`6Riesige Goldene Statue`n`b`c");
 output("`n`#Du Wanderst auf der suche nach ein paar ebenb�rdigen gegnern durch den Wald als du pl�tzlich vor dir eine Riesige Goldene Statue siehst. Du stehst erf�rchtig vor der Statue und bist von der pracht der Riesigen Goldenen Statue angetahn. Die Statue stellt Einen Ritterlichen Mann und seine Wundersch�ne Frau dar du gehst n�her heran um die inschrift zu lesen:`n`n");

 output("`c `@Diese Statue Wurde von Lord Ray zu ehren seiner wunderbaren Frau Vampchloe und seinen wunderbaren Kindern errichtet `c");


 addnav("Aktion");
 addnav("B?Blumen hinlegen","forest.php?op=blu");
 addnav("g?Verbeugen","forest.php?op=ver");
 addnav("s?Versuchen ein st�ck gold abzubrechen","forest.php?op=klau");
 addnav("W?Zur�ck in den Wald","forest.php?op=weg");
 $session['user']['specialinc']="statue.php";

 }else if ($_GET['op']=="blu"){   //Blumen geben
 $session['user']['reputation']++;
 output("`n`#Du wendest der Statue kurz den r�cken zu um ein paar Blumen zu pfl�cken, nachdem du damit fertig bist wendest du dich wieder der Statue zu und legst den Straus Blumen neben der Statue.");
 output("`n`#Kaum hast du die Blumen abgelegt H�rst du eine Stimme sagen:");
 output("`n`c`@Du der du Blumen an meine Statue gelegt hast ich Danke dir nicht viele sind so nett und w�rdigen mein geschenk an meine Frau daf�r das du jedoch deinen groll �berwunden hast und mir Blumen an die Statue gelegt hast werde ich dich belohnen. Was es sein wird? Lass dich �berraschen...`c`n`n");

 switch(e_rand(1,7)){
     case 1:
     case 2:
     output("`n`#Nach dieser Anrede willst du den ort verlassen aber kaum hast du dich gedreht siehst du vor dir ein paar Edelsteine liegen.`n`n `@Du findest `^4 `@Edelsteine");
     $session['user']['turns']-=1;
     $session['user']['experience']+=300;
     $session['user']['gems']+=4;
     break;
     case 3:
     case 4:
  output("`n`#Nach dieser Anrede willst du den ort verlassen aber kaum hast du dich gedreht siehst du vor dir ein paar Goldst�cke liegen.`n`n `@Du findest `^2000 `@Goldst�cke");
  $session['user']['turns']-=1;
  $session['user']['experience']+=300;
  $sesion['user']['gold']+=2000;
  break;
  case 5:
  case 6:
  output("`n`#Nach dieser Anrede willst du den ort verlassen aber kaum hast du dich gedreht siehst du vor dir ein paar Goldst�cke und Edelsteine liegen.`n`n `@Du findest `^1000 `@Goldst�cke `#und `^2 `@Edelsteine");
  $session['user']['turns']-=1;
     $session['user']['experience']+=300;
 $session['user']['gold']+=1000;
 $session['user']['gems']+=2;
 break;
 case 7:
 output("`n`#Nach dieser Anrede  willst du den ort verlassen aber kaum hast du dich gedreht siehst du eine Person vor dir stehen diese Person kommt dir irgendwie bekannt vor du macht eine fl�chtigen blick nach hinten um auf die Statue zu sehen, ja du bist dir sicher diese Person ist diese Ritterliche person von der Statue. Diese Person guckt dich nur an und sagt:");
 output("`n`@Nach langer �berlegung bin ich zu den entschluss gekommen dir wegen deiner gabe ein bisschen mehr ausdauer f�r diesen tag, Gold und Edelsteine zu geben.");
 output("`n`#Du willst Lord Ray noch einmal daf�r danken das er dir ein so sch�nes geschenk gegeben hat aber so schnell wie er da war ist er auch wieder verschwunden. Du guckst in deiner Tasche und findest 3 Edelsteine, 1500 Goldst�cke und du f�hlst dich danach ein paar monster den gar aus zu machen.");
 $session['user']['turns']+=2;
     $session['user']['experience']+=300;
 $session['user']['gold']+=1500;
 $session['user']['gems']+=3;
 break;
 }
 $session['user']['specialinc']="";

 }else if ($_GET['op']=="ver"){ //verbeugen
 $session['user']['reputation']++;
 output("`n`#Du verbeugst dich erw�rdig vor der Statue und betest.....nach einiger zeit beten stehst du auf und willst den ort verlassen also du pl�tzlich vor dir.....`n`n");
 switch(e_rand(1,10)){
 case 1:
 case 2:
 case 3:
 output("`n`#...ein kleinen runden Elektrischen Ball siehst du bist dir nicht so sicher ob du ihn einfach so anfassen kannst oder ob er irgendwie gef�rlich ist. Du riskierst es einfach und fasst ihn an pl�tzlich durchstr�mt dich eine komische kraft.`n`n`& Du steigst in Mystischen K�nsten um 5 punkte.");
 $session['user']['magic']+=5;
 $session['user']['magicuses']+=2;
 break;
 case 4:
 case 5:
 case 6:
 output("`n`#...ein kleinen runden Elektrischen Ball siehst du bist dir nicht so sicher ob du ihn einfach so anfassen kannst oder ob er irgendwie gef�rlich ist. Du riskierst es einfach und fasst ihn an pl�tzlich durchstr�mt dich eine komische kraft.`n`n`& Du steigst in Diebes K�nsten um 5 punkte.");
 $session['user']['thievery']+=5;
 $session['user']['thieveryuses']+=2;
 break;
 case 7:
 case 8:
 case 9:
 output("`n`#...ein kleinen runden Elektrischen Ball siehst du bist dir nicht so sicher ob du ihn einfach so anfassen kannst oder ob er irgendwie gef�rlich ist. Du riskierst es einfach und fasst ihn an pl�tzlich durchstr�mt dich eine komische kraft.`n`n`& Du steigst in Dunklen K�nsten um 5 punkte.");
 $session['user']['darkarts']+=5;
     $session['user']['darkartuses']+=2;
 break;
 case 10:
 output("`n`#...ein kleinen runden Elektrischen Ball siehst du bist dir nicht so sicher ob du ihn einfach so anfassen kannst oder ob er irgendwie gef�rlich ist. Du riskierst es einfach und fasst ihn an pl�tzlich durchstr�mt dich eine komische kraft.`n`n`& Du steigst in allen K�nsten um 5 punkte.");
 $session['user']['darkarts']+=5;
 $session['user']['darkartsuses']+=2;
 $session['user']['thievery']+=5;
 $session['user']['thieveryuses']+=2;
 $session['user']['magic']+=5;
 $session['user']['magicuser']+=2;
 break;
 }
 $session['user']['specialinc']="";
 }else if ($_GET['op']=="klau"){ //klauen
 $session['user']['reputation']--;
 output("`n`#Du versuchst mit hilfe deiner waffe ein st�ck Gold aus der Statue rauszubrechen um das nachher teuer zu verkaufen du h�mmerst mit deiner waffe auf der Statue rumm und guckst ob du vielleicht ein kleines st�ck rausbrechen kannst. Leider gelingt es dir nicht etwas rauszubrechen statt dessen h�rst du eine stimme sprechen:");
 output("`n`c`@Wer wagt es meine Statue zu besch�digen!? Sp�re meinen Zorn.`c");
 output("`n`#Du fragst dich wer es war und denkst es sei besser schnell abzuhauen. Du drehst dich in richtung Wald und f�ngst an zu rennen als pl�tzlich...`n`n");
 switch(e_rand(1,6)){
 case 1:
 case 2:
 case 3:
 output("`n`#...ein Blitz auf dir einschl�gt und dich langsam aber sicher zu boden haut, regungslos liegst du am Boden und h�rst diese stimme erneut.`n`n `@ `cDas geschieht dir recht merk dir eins versuche nie einen Gott zu ver�rgern.`c");
 $session['user']['alive'] = false;
 $session['user']['hitpoints']=0;
 addnav("T?T�gliche news","news.php");
 break;
 case 4:
 case 5:
         output("`n`#...ein Blitz knapp neben dir einschl�gt und dich um Haaresbreite verfehlt. Dir gelingt die flucht von diesen ort aber nicht ganz unbeschadet, als du nach deinen gold sehen wolltest siehst du das dir einige Goldst�cke fehlen.`n");
         if ($session['user']['gold']>999){
         output("`#Du verlierst `^1000 `#Gold.");
         $session['user']['gold']-=1000;
         }else{
         output("`#Du verlierst den Rest deines Goldes.");
         $session['user']['gold']=0;
         }
         break;
         case 6:
         output("`n`#... ein paar Blitze vor dir auf den boden einschlagen aber irgendwie schlagen sie immer knapp vor dir ein, du denkst dir es sei klug in richtung Statue zu rennen um mithilfe des Blitzes ein st�ck Gold zu ergattern. Der Blitz schl�gt genau auf die Statue ein und bricht ein paar st�cke raus, du rennst schnell an der Statue vorbei um die Goldteile aufzuheben. Kurz danach fliehst du in den Wald.`n");
         output("`#Sp�ter als du die Goldteile einen sammler gezeigt hast bieter er dir daf�r 5000 Gold an. Du wusstest das es viel wert ist aber nicht so viel du nimmst dieses angebot sofort an und bist um 5000 Gold reicher.");
         $session['user']['gold']+=5000;
         }
         $session['user']['specialmisc']="";
 }else if ($_GET['op']=="weg"){
 output("`n`#Du gehst lieber wieder in den Wald.");
 $session['user']['specialmisc']="";
 }
 ?>