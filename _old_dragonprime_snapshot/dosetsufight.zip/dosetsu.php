<?php
/*notes by fabian2_de for Somtaaw:
also gut.... das ist der Grundaufbau, du kannst �ndern, was du willst, aber das modul ist soweit getestet, also brauchst du am code selber nichts �ndern... (es sei denn, du willst andere belohnungen/strafen...

tjoa... soviel dazu... :) hoffe, du hast spa� damit ;) bei Fragen etc. steh' ich dir nat�rlich zur Verf�gung...!
*/
function dosetsu_getmoduleinfo(){
	$info = array(
		"name"=>"Fight vs Dosetsu",
		"author"=>"fabian2_de written for Somtaaw",
		"version"=>"1.00",
		"category"=>"Forest Specials",
		"download"=>"http://dragonprime.net/users/fabian2_de/dosetsufight.zip",
		"vertxtloc"=>"http://dragonprime.net/users/fabian2_de/",
		"description"=>"Forest Special, in which a player will ba able to fight against Dosetsu - Master of Swords. If killed, you get many exp, else you'll be marked.",
		"settings"=>array(
			"charmlose"=>"Charmpoints to lose if you are already level 15 and nevertheless try to hear him,int|2",
		),
		);
	return $info;
}
function dosetsu_install(){
	module_addeventhook("forest", "return 100;");
	return true;
}
function dosetsu_uninstall(){
	return true;
}
function dosetsu_dohook($hookname,$args){
return $args;
}
function dosetsu_runevent(){
	global $session;
	$from = "forest.php?";
	$session['user']['specialinc'] = "module:dosetsu";
	$op = httpget('op');
	if ($op=="" || $op=="search"){
		output("`n`n`3W�hrend du durch den Wald wanderst... bla bla bla... `2dosetsu.php - anpassen.... :)");
		$session['user']['specialinc'] = "module:dosetsu";
		addnav("Stelle dich Dosetsu","forest.php?op=fighthim");
		addnav("H�re ihm zu","forest.php?op=hear");
		addnav("Verlasse diesen Ort","forest.php?op=runawaylikealittlesissybaby");

	}elseif ($op=="hear"){
	if ($session['user']['level']<15){
		output("`n`n`3Er erz�hlt dir von seinen gro�en Taten.. bla bla bla `2dosetsu.php - anpassen.... :)");
		$experience = e_rand(25, 250);
		$session['user']['experience']+=$experience;
		output(" Du denkst, dass es Zeit ist zu gehen, auch wenn du gerne noch geblieben w�rst, um dem Meister zuzuh�ren. Als du die Kapelle verlassen hast, f�hlst du dich  etwas weiser.");
		output(" `n`2Du erh�lst `6%s`2 Erfahrungspunkte `3.",$experience);
		debuglog("Met with Dosetsu and gained $experience experience.");
	}else{
		output("`n`n`2Er erz�hlt dir, dass er dir nichts zu sagen hat. Als er gerade ein Gespr�ch �ber etwas anderes anfangen will verl�sst du die Kapelle einfach ohne dich umzudrehen und l�sst den alten Kauz allein.");
		$session['user']['charm']-=get_module_setting("charmlose");
		output("`n`2Er ist jetzt bestimmt traurig. `n Wegen deines schlechten Gewissens verlierst du `6%s`2 Charmpukte.",get_module_setting("charmlose"));
		debuglog("Met up with Dosetsu and lost %s charmepoints for being level 15.");
		}
		$session['user']['specialinc']="";
	}elseif ($op=="runawaylikealittlesissybaby"){
		output("`n`n`6Dir ist diese alte Kapelle unheimlich... bla bla bla `2dosetsu.php - anpassen.... :)");
		if (e_rand(1,3)==1){
			$session['user']['specialinc']="";
			output("`n`nDu gehst langsam weg.. bla bla bla `2dosetsu.php - anpassen.... :)");
		}else{
			output("`n`nPl�tzlich - du willst gerade deines Weges gehen - steht er im Tor. Der Meister Dosetsu pers�nlich. Er m�chte dich herausfordern und dein Stolz zwingt dich, dein/e `%%s `6bereit zu machen und dich auf den Kampf vorzubereiten .",$session['user']['weapon']);
			addnav("Stelle dich Dosetsu!","forest.php?op=fighthim");
		}
	}elseif ($op=="fighthim"){
	$dkb = round($session['user']['dragonkills']*.1);
		$badguy = array(
			"creaturename"=>translate_inline("`^Schwertmeister Dosetsu`0"),
			"creaturelevel"=>$session['user']['level']+4,
			"creatureweapon"=>translate_inline("Perfekt gef�hrte Schwerter"),
			"creatureattack"=>round($session['user']['attack']+$session['user']['attack']*0.1,0),
			"creaturedefense"=>round($session['user']['defence']+$session['user']['defence']*0.1,0),
			"creaturehealth"=>round($session['user']['maxhitpoints']*0.9,0),
			"diddamage"=>0);
			$minioncount=e_rand($session['user']['level']-3,$session['user']['level']);
			$session['bufflist']['dosetsu'] = array(
				"startmsg"=>"`n`^Er ist viel erfahrener als du!`n`n",
				"name"=>"`%Schwerter",
				"rounds"=>30,
				"wearoff"=>"Er wird langsam m�de.",
				"minioncount"=>$minioncount,
				"mingoodguydamage"=>$dkb+1,
				"maxgoodguydamage"=>$dkb+4,
				"effectmsg"=>"Er trifft dich mit seinem Schwert mit {damage} Schadenspunkten.",
				"effectnodmgmsg"=>"Er hat deinen Kopf gerade noch so verfehlt.",
				"effectfailmsg"=>"Sein Schwert streift dich nur.",
				"activate"=>"roundstart",
				);
				$session['user']['badguy']=createstring($badguy);
				$op="fight";
	}
	if ($op=="run"){
		output("Deine Ehre verbietet es dir, vor Dosetsu zu flihen!");
		$op="fight";
	}
	if ($op=="fight"){
		$battle=true;
}
if ($battle){
	  include("battle.php");
		if ($victory){
			$session['user']['specialinc']="";
			unset($session['bufflist']['dosetsu']);
			$badguy=array();
			$session['user']['badguy']="";
			/*hier: player hat gewonnen.... */
}elseif ($defeat){
			$session['user']['specialinc']="";
			unset($session['bufflist']['dosetsu']);
			$badguy=array();
			$session['user']['badguy']="";
			/*hier: player hat verloren.... */
}else{
			require_once("lib/fightnav.php");
			fightnav(true,false);
}
}
}

function dosetsu_run(){
}
?>