<?
/*
Sir Keith's Rations v1.0 
Author: bwatford
Board: http://www.ftpdreams.com/lotgd
Date: 03-2004
Drop this in your main folder.
*/

require_once "common.php";
checkday(); 
if ($HTTP_GET_VARS[op]==""){
$food=$session['user']['level']*(($session['user']['dragonkills']+1)/2)*25;
$weekfood=$session['user']['level']*(($session['user']['dragonkills']+1)/2)*25*5;
$water=$session['user']['level']*(($session['user']['dragonkills']+1)/2)*15;
$weekwater=$session['user']['level']*(($session['user']['dragonkills']+1)/2)*15*5;
page_header("Sir Keith's Rations");
addnav("Navigation");
addnav("R?Return To Toddsbury","village.php");
addnav("Thing's To Do Here");
addnav("Buy Food Rations","groceries.php?op=food");
addnav("Buy Water Rations","groceries.php?op=water");
output("`b`n`n`c`bSir Keith's Rations`b`c`n`n");
output("`@You enter this little shop ans see people busy shopping to and fro, everyone is stocking there packs and getting ready for a big day in the forest!`@`n`n");
output("`@A middle aged gentleman with a wooden leg hops over to you and says 'welcome to my rations shop my name is Sir Keith may I help you!`@`n`n");
}

if ($HTTP_GET_VARS['op']=="food"){
$food=$session['user']['level']*(($session['user']['dragonkills']+1)/2)*25;
$weekfood=$session['user']['level']*(($session['user']['dragonkills']+1)/2)*25*5;
page_header("Buying Food Rations");
output("`n`n`c`bBuying Food Rations`b`c`n`n");
output("`@`c'I have several rather fine food rations for the mighty adventurer' Sir Keith says. These choices are:`n`n`c");
$food=$session['user']['level']*(($session['user']['dragonkills']+1)/2)*25;
$weekfood=$session['user']['level']*(($session['user']['dragonkills']+1)/2)*25*5;
output("1 Days Rations = ".$food." gold`n");
output("1 Weeks Rations = ".$weekfood." gold");
addnav("Main Navigation");
addnav("Forget It","groceries.php");
addnav("Purchase Menu");
addnav("Buy 1 Days Rations","groceries.php?op=payfoodday");
addnav("Buy 1 Weeks Rations","groceries.php?op=payfoodweek");

}

if ($HTTP_GET_VARS['op']=="payfoodday"){
$food=$session['user']['level']*(($session['user']['dragonkills']+1)/2)*25;
page_header("Buying Food Rations");
output("`n`n`c`bBuying Food Rations`b`c`n`n");
if ($session[user][hungry]>=14){
output("`@`c'You are already carying your maximum amount of food rations' Sir Keith says.`@`c`n`n");
addnav("Main Navigation");
addnav("Forget it","groceries.php");
   }else{
if ($session[user][gold]<$food){
output("`@`c'You don't have enough gold to pay me.' Sir Keith says.`@`c`n`n");
addnav("Main Navigation");
addnav("Forget it","groceries.php");
   }else{
output("`@`cSir Keith fills your order and places it on the counter.'Your welcome and thanks for the order.' Sir Keith says.`@`c`n`n");
output("`^You gain 1 days of rations`^`n`n");
addnav("Main Navigation");
addnav("Continue","groceries.php");
$session[user][hungry]+=1;
$session[user][gold]-=$food;

}
}
}

if ($HTTP_GET_VARS[op]=="payfoodweek"){
$weekfood=$session['user']['level']*(($session['user']['dragonkills']+1)/2)*25*5;
page_header("Buying Food Rations");
output("`n`n`c`bBuying Food Rations`b`c`n`n");
if ($session[user][hungry]>=14){
output("`@`c'You are already carying your maximum amount of food rations' Sir Keith says.`@`c`n`n");
addnav("Main Navigation");
addnav("Forget it","groceries.php");
   }else{
if ($session[user][gold]<$weekfood){
output("`@`c'You don't have enough gold to pay me.' Sir Keith says.`@`c`n`n");
addnav("Main Navigation");
addnav("Forget it","groceries.php");
   }else{
output("`@`cSir Keith fills your order and places it on the counter.'Your welcome and hanks for the order.' Sir Keith Says.`@`c`n`n");
output("`^You gain 7 days of rations`^`n`n");
addnav("Main Navigation");
addnav("Continue","groceries.php");
$session[user][hungry]+=7;
$session[user][gold]-=$weekfood;

}
}
}

if ($HTTP_GET_VARS[op]=="water"){
$water=$session['user']['level']*(($session['user']['dragonkills']+1)/2)*15;
$weekwater=$session['user']['level']*(($session['user']['dragonkills']+1)/2)*15*5;
page_header("Buying Water Rations");
output("`n`n`c`bBuying Water Rations`b`c`n`n");
output("`@`c'I have several rather fine water rations for the mighty adventurer' Sir Keith says. These choices are:`n`n`c");
output("1 Days Water = ".$water." gold`n");
output("1 Weeks Water = ".$weekwater." gold");
addnav("Main Navigation");
addnav("Forget It","groceries.php");
addnav("Purchase Menu");
addnav("Buy 1 Days Water","groceries.php?op=paywaterday");
addnav("Buy 1 Weeks Water","groceries.php?op=paywaterweek");

}

if ($HTTP_GET_VARS[op]=="paywaterday"){
$water=$session['user']['level']*(($session['user']['dragonkills']+1)/2)*15;
page_header("Buying Water Rations");
output("`n`n`c`bBuying Water Rations`b`c`n`n");
if ($session[user][thirsty]>=14){
output("`@`c'You are already carying your maximum amount of water rations' Sir Keith Says.`@`c`n`n");
addnav("Main Navigation");
addnav("Forget it","groceries.php");
   }else{
if ($session[user][gold]<$water){
output("`@`c'You don't have enough gold to pay me.' Sir Keith Says.`@`c`n`n");
addnav("Main Navigation");
addnav("Forget it","groceries.php");
   }else{
output("`@`cSir Keith fills your order and places it on the counter.'Your welcome and thanks for the order.' Sir Keith Says.`@`c`n`n");
output("`^You gain 1 days of water`^`n`n");
addnav("Main Navigation");
addnav("Continue","groceries.php");
$session[user][thirsty]+=1;
$session[user][gold]-=$water;

}
}
}

if ($HTTP_GET_VARS[op]=="paywaterweek"){
$weekwater=$session['user']['level']*(($session['user']['dragonkills']+1)/2)*15*5;
page_header("Buying Water Rations");
output("`n`n`c`bBuying Water Rations`b`c`n`n");
if ($session[user][thirsty]>=14){
output("`@`c'You are already carying your maximum amount of water rations' Sir Keith says.`@`c`n`n");
addnav("Main Navigation");
addnav("Forget it","groceries.php");
   }else{
if ($session[user][gold]<$weekwater){
output("`@`c'You don't have enough gold to pay me.' Sir Keith says.`@`c`n`n");
addnav("Main Navigation");
addnav("Forget it","groceries.php");
   }else{
output("`@`cSir Keith fills your order and places it on the counter.'Your welcome and thanks for the order.' Sir Keith Says.`@`c`n`n");
output("`^You gain 7 days of water`^`n`n");
addnav("Main Navigation");
addnav("Continue","groceries.php");
$session[user][thirsty]+=7;
$session[user][gold]-=$weekwater;

}
}
}

page_footer();

?> 