 # | seed    | place
 -------------------
 1 | apple   | cellar (or random monster)
 2 | orange  | forest special
 3 | pear    | after fighting a specific enemy
 4 | apricot | buy from cedrick barkeep
 5 | banana  | Abandoned House Quest (or random monster)
 6 | peach   | graveyard (from ramius)
 7 | plum    | stables
 8 | fig     | after fighting a specific enemy
 9 | mango   | alley special (or random monster)
10 | cherry  | dragon's corpse

install is straight forward.... files in lib folder go into modules/lib
orchard.php goes in modules folder.

install as any other module.