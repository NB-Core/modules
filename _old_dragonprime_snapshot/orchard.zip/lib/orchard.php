<?php
global $session;
require_once("lib/http.php");
require_once("lib/villagenav.php");
$op = httpget('op');
$subop = httpget('subop');

if ($op==""){
        page_header("The Fruit Orchard");
        addnav("Enter the Hollow Tree","runmodule.php?module=orchard&op=hollowtree");
        addnav("Explore the orchard","runmodule.php?module=orchard&op=explore");
        if (get_module_pref("tree")>0 || get_module_pref("treegrowth")>0){
                addnav("Visit your trees","runmodule.php?module=orchard&op=trees");
        }
        villagenav();
        output("`7You stroll into the orchard, it's a picturesque area filled with a large variety of different fruit trees, many of the fruits look ripe and ready to be picked.");
        output("You could easily spend hours just relaxing in here.`n`n");
        output("To the right of the entrance is a small path leading up to the hollow tree, the house of `!Elendir`7, keeper of the orchard.`n`n");
        output("It looks as though he might be home.");
        page_footer();
}

elseif ($op=="explore"){
        page_header("The Fruit Orchard");
        addnav("Return to the entrance","runmodule.php?module=orchard");
        output("`7Wandering through the orchard between the many trees planted by different villagers, occasionally you meet someone else and wave.");
        output("It's a beautiful place to spend an afternoon.`n`n");
        output("`c`b`^The best trees in the orchard:`b`c`n");

        $names=array("","Apple","Orange","Pear","Apricot","Banana","Peach","Plum","Fig","Mango","Cherry");
        $perpage = 15;
        if ($subop=="") $subop=1;
        $min = ($subop-1)*$perpage;
        $limit = "LIMIT $min,$perpage";
        $sql = "SELECT COUNT(*) AS c FROM " . db_prefix("module_userprefs") . " WHERE modulename = 'orchard' AND setting = 'tree' AND value > 0";
        $result = db_query($sql);
        $row = db_fetch_assoc($result);
        $total = $row['c'];
        addnav("Pages");
        for($i = 0; $i < $total; $i+= $perpage) {
                $pnum = ($i/$perpage+1);
                $min = ($i+1);
                $max = min($i+$perpage,$total);
                addnav(array("Page %s (%s-%s)", $pnum, $min, $max), "runmodule.php?module=orchard&op=explore&subop=$pnum");
        }
        $sql = "SELECT module_userprefs.value,accounts.name FROM " . db_prefix("module_userprefs") . "," . db_prefix("accounts") . " WHERE acctid = userid AND modulename = 'orchard' AND setting = 'tree' AND value > 0 ORDER BY (value+0) DESC $limit";
        $result = db_query($sql);
        $name = translate_inline("Name");
        $tree = translate_inline("Best Tree");
        $none = translate_inline("No Trees Found");
        rawoutput("<table border='0' cellpadding='2' cellspacing='1' align='center' bgcolor='#999999'>");
        rawoutput("<tr class='trhead'><td>$name</td><td>$tree</td></tr>");
        if (db_num_rows($result)==0){
                output_notl("<tr class='trlight'><td colspan='2' align='center'>`&$none`0</td></tr>",true);
        }
        else{
                for ($i=0;$i<db_num_rows($result);$i++){
                        $row = db_fetch_assoc($result);
                        if ($row['name']==$session['user']['name']){
                                rawoutput("<tr class='trhilight'><td>");
                        } else {
                                rawoutput("<tr class='".($i%2?"trdark":"trlight")."'><td>");
                        }
                        output_notl("`&%s`0",$row['name']);
                        rawoutput("</td><td>");
                        output_notl("`@%s`0",$names[$row['value']]);
                        rawoutput("</td></tr>");
                }
        }
        rawoutput("</table>");
        page_footer();
}

elseif ($op=="hollowtree"){
        page_header("The Hollow Tree");
        addnav("Return to the entrance","runmodule.php?module=orchard");
        $tree = get_module_pref("tree");
        if (get_module_pref("found")>0){
                addnav("Show Elendir your seed","runmodule.php?module=orchard&op=giveseed");
        }
        elseif ($tree<10){
                addnav("Ask about tree seeds","runmodule.php?module=orchard&op=askseeds");
        }
        if ($tree>0 || get_module_pref("treegrowth")>0){
                addnav("Ask about your trees","runmodule.php?module=orchard&op=asktrees");
        }
        if ($tree==0 && get_module_pref("seed")==0){
                output("`!Elendil`7 spots you as you are walking down the path and comes out to greet you.`n`n");
                output("\"`#Hello there, you're a new face, have you looked around the orchard yet?  It's truly wonderful is it not.`7\" he says merrily.`n");
                output("\"`#Please, do come in and stay a while, I can tell you all about the orchard if you like.`7\"`n`n");
                output("Of course, you were heading to his house anyway and who can refuse an invitation from an elf, so you follow him inside.`n`n");
                output("\"`#OK, I'm sure you'll be wanting your own little spot and I believe theres still space for more trees.");
                output("Unfortunately it isn't quite that simple, I cannot help you plant trees unless you bring me seeds to plant them with.  And then of course they take time to grow, but I think you'll agree that it's worth the wait.`7\"`n");
                output("`!Elendir`7 smiles and waves his arms vaguely towards the window, where there is a superb view of the orchard.");
        }
        elseif ($tree==0){
                output("`!Elendil`7 spots you as you are walking down the path and comes out to greet you.`n`n");
                output("\"`#Hello there %s`#!  You are looking very well today, I wonder, have you found any seeds for me yet?`7\"",$session['user']['name']);
                output("He says, greeting you with a firm handshake.`n`n");
                output("\"`#Please, come inside and sit a while.`7\" `!Elendir`7 gestures you inside and you follow politely.`n`n");
                output("\"`#So, would you like me to tell you about the orchard?  Perhaps you think I know about some seeds you may be able to find?`7\"");
                output("He smiles at you knowingly and sits down opposite you.");
        }
        elseif ($tree<10){
                output("`!Elendil`7 spots you as you are walking down the path and comes out to greet you.");
                output("\"`#Hello there %s`#!  How are you today, you're trees seem to be doing very well for themselves, as do everyone elses.  What is it you would like today?`7\" he asks jovially, gesturing you inside.`n`n",$session['user']['name']);
                output("You follow him in and take a seat.`n`n");
                output("\"`#I suppose you're interested in how your trees are doing?  and of course there are always more seeds to be found.`7\"");
        }
        else{
                output("`!Elendil`7 spots you as you are walking down the path and comes out to greet you.");
                output("\"`#Hello there %s`#!  How are you today, you're trees seem to be doing very well for themselves, as do everyone elses.  What is it you would like today?`7\" he asks jovially, gesturing you inside.`n`n",$session['user']['name']);
                output("You follow him in and take a seat.`n`n");
                output("\"`#My friend, you know as much about the trees in this orchard as I do, I'm not sure I can be of any more service to you.  Of course you are welcome to stay and relax here as long as you want.`7\"");
        }
        page_footer();
}

elseif ($op=="giveseed"){
        page_header("The Hollow Tree");
        addnav("Return to the entrance","runmodule.php?module=orchard");
        $tree = get_module_pref("tree");
        $names=array("","Apple","Orange","Pear","Apricot","Banana","Peach","Plum","Fig","Mango","Cherry");
        if (get_module_pref("treegrowth")>0){
                output("`7\"`#If you recall, you still have a `@%s`# tree growing in the orchard, you need to wait for it to finish growing before you can plant another.`7\"",$names[($tree+1)]);
                if ($tree>0){
                        addnav("Ask about your trees","runmodule.php?module=orchard&op=asktrees");
                }
        }
        else{
                $found = get_module_pref("found");
                if ($tree>0){
                        addnav("Pick some fruit","runmodule.php?module=orchard&op=pick");
                }
                output("`7\"`#Ah, wonderful, a `@%s`# seed.  Come, lets head out into the orchard and get this planted shall we.`7\"`n`n",$names[$found]);
                output("You follow `!Elendir`7 out into the orchard to a small clearing and he asks for the `@%s`7 seed.`n",$names[$found]);
                output("`!Elendir`7 begins to dig a small hole to plant the seed in and starts chatting about the orchard.`n");
                output("You sit and listen whilst he plants the tree, keeping an eye on what he's doing.`n");
                output("After a short while the tree is planted and `!Elendir`7 stands up and smiles at you.`n`n");
                output("\"`#Thats going to be a fine tree when it's fully grown, trust me.  Just make sure you look after it.`7\"`n");
                output("\"`#Remember never to pick too much fruit from it, otherwise it will become unhealthy and possibly even die.`7\"`n");
                output("\"`#Oh, and it will take `^%s`# days for the tree to grow to full size and bear fruit for you to eat.  You must be patient.`7\"`n`n",get_module_setting("growth"));
                output("With a final wave `!Elendir`7 heads back through the orchard, leaving you with the newly planted tree.");
                set_module_pref("found",0);
                set_module_pref("treegrowth",get_module_setting("growth"));
                if ($tree>0){
                        for($i=1;$i<=$tree;$i++){
                                if ($trees == null){
                                        $trees = $names[$i];
                                }
                                else{
                                        $trees = $trees."`7,`^ ".$names[$i];
                                }
                        }
                        output("Looking around, you see that you have the following trees: `^%s`7.",$trees);
                }

        }
        page_footer();
}

elseif ($op=="askseeds"){
        page_header("The Hollow Tree");
        addnav("Return to the entrance","runmodule.php?module=orchard");
        $tree=get_module_pref("tree");
        if (get_module_pref("treegrowth")>0){
                $tree++;
        }
        if (get_module_pref("found")>0){
                addnav("Show Elendir your seed","runmodule.php?module=orchard&op=giveseed");
        }
        if ($tree>0){
                addnav("Ask about your trees","runmodule.php?module=orchard&op=asktrees");
        }
        output("`7\"`#So you want to find a seed to make your own contribution to the orchard, thats wonderful!`7\"`n`n");
        switch ($tree){
                case 0:
                        if (is_module_active("cellar")) {
                                output("\"`#I know that Cedrick used to have a few apple seeds in his posession, but he probably lost them in the cellar somewhere knowing him.`7\"");
                        }
                        else{
                                orchard_monster(1);
                        }
                        break;
                case 1:
                        output("\"`#I heard tell of an orange grove hidden deep in the forest, perhaps you will find it in your travels.`7\"");
                        break;
                case 2:
                        orchard_monster(3);
                        break;
                case 3:
                        output("\"`#Cedrick owns a small apricot tree, it's a very important posession to him so it will probably cost you dearly to get a seed from it, go and talk to him.`7\"");
                        break;
                case 4:
                        if (is_module_active("darkalley")){
                                output("\"`#An old man used to live in the Dark Alley, he owned a banana tree, perhaps he left some seeds in his house when he left.`7\"");
                        }
                        else{
                                orchard_monster(5);
                        }
                        break;
                case 5:
                        output("\"`#I have here a peach seed, but unfortunately it has been dead for some time.  I will help you plant it if you can convince Raimus to breathe life back into the seed.`7\"");
                        break;
                case 6:
                        output("\"`#I believe Merick feeds the horses at his stables plums sometimes.`7\"");
                        break;
                case 7:
                        orchard_monster(8);
                        break;
                case 8:
                        if (is_module_active("darkalley")){
                                output("\"`#The last I heard, some unsavoury character who is often seen in the Dark Alley had some mango seeds, who knows where he is now though.`7\"");
                        }
                        else{
                                orchard_monster(9);
                        }
                        break;
                case 9:
                        output("\"`#Rumour has it that the Green Dragon is fond of cherries.  There is only one way to find out for sure though.`7\"");
                        break;
        }
        set_module_pref("seed",($tree+1));
        page_footer();
}

elseif ($op=="asktrees"){
        page_header("The Hollow Tree");
        addnav("Return to the entrance","runmodule.php?module=orchard");
        $names=array("","Apple","Orange","Pear","Apricot","Banana","Peach","Plum","Fig","Mango","Cherry");
        $tree=get_module_pref("tree");
        if (get_module_pref("found")>0){
                addnav("Show Elendir your seed","runmodule.php?module=orchard&op=giveseed");
        }
        elseif ($tree<10){
                addnav("Ask about tree seeds","runmodule.php?module=orchard&op=askseeds");
        }
        output("`7\"`#Of course you can always go and look at your trees yourself, you're free to roam the orchard as you please.");
        output("But if you want my opinion on your trees then it is yours.`7\"`n`n");
        switch($tree){
                case 0:
                        output("\"`#Sadly you have no fully grown trees in the orchard, but time will change that as I'm sure you know.`)\"");
                        break;
                case 1:case 2:case 3:case 4:
                        output("\"`#Well, I'm very pleased that you've taken an interest in the orchard, but you still have a lot to learn from me about trees.`n");
                        output("I hope you maintain your interest, and your little section of my orchard grows.`7\"");
                        break;
                case 5:case 6:case 7:case 8:
                        output("\"`#I have to say you're doing very well, there are still a few things I have to show you though, but I'm sure you'll pick them up just fine.`7\"");
                        break;
                case 9:
                        output("\"`#Well, your skills in the orchard almost match my own.  You should be very proud of what you have achieved here.`7\"");
                        break;
                case 10:
                        output("\"`#We are like brothers, our knowledge of the orchard is equal and unrivalled.`7\"");
                        break;
        }
        $growth=get_module_pref("treegrowth");
        if ($growth>0){
                output("`n`n\"`#No doubt you're also wondering about the `@%s`# tree that we planted not long ago, well it still has `^%s`# more days before it will be fully grown.`7\"",$names[$tree+1],$growth);
        }
        page_footer();
}

elseif ($op=="trees"){
        page_header("The Fruit Orchard");
        $names=array("","Apple","Orange","Pear","Apricot","Banana","Peach","Plum","Fig","Mango","Cherry");
        $tree=get_module_pref("tree");
        addnav("Return to the entrance","runmodule.php?module=orchard");
        if ($tree>0){
                addnav("Pick some fruit","runmodule.php?module=orchard&op=pick");
        }
        output("`7You saunter through the orchard to a familiar area, you think back to the proud moment when `!Elendir`7 helped you to plant your very own trees in this spot.");
        output("Some of the fruit on the more mature trees looks wonderfully ripe, you could so easily reach out and pick some and eat it right now.`n`n");
        if ($tree>0){
                for($i=1;$i<=get_module_pref("tree");$i++){
                        if ($trees == null){
                                $trees = $names[$i];
                        }
                        else{
                                $trees = $trees."`7,`^ ".$names[$i];
                        }
                }
                output("Looking around, you see that you have the following trees: `^%s`7.",$trees);
        }
        if (get_module_pref("treegrowth")>0){
                output("`n`nYou note that the tree you and `!Elendir`7 planted is still not fully grown, perhaps `!Elendir`7 could give you an idea of how much longer it will take.");
        }
        page_footer();
}

elseif ($op=="pick"){
        page_header("The Fruit Orchard");
        addnav("Go back to your trees","runmodule.php?module=orchard&op=trees");
        addnav("Return to the entrance","runmodule.php?module=orchard");
        if (get_module_pref("hadfruittoday")){
                output("`7You reach out to pick some fruit, but remember what `!Elendir`7 told you, only one piece of fruit per day or the trees may grow unhealthy.");
        }
        else{
                $names=array("","Apple","Orange","Pear","Apricot","Banana","Peach","Plum","Fig","Mango","Cherry");
                $level=get_module_pref("tree");
                $tree=$names[$level];
                output("`7You reach out and pick a ripe `@%s`7 from a nearby tree and munch on it happily.`n`n",$tree);
                output("You feel much healthier for it, and gain `^%s`7 health!",$level*10);
                $session['user']['hitpoints']+=$level*10;
                set_module_pref("hadfruittoday",1);
        }
        page_footer();
}


// everything after here is interaction with other modules
elseif ($op=="cedrick"){
        $iname = getsetting("innname", LOCATION_INN);
        page_header($iname);
        rawoutput("<span style='color: #9900FF'>",true);
        output_notl("`c`b$iname`b`c");
        if ($subop==""){
                output("\"`%You're looking for seeds, are ya?`0\" Cedrik asks.  \"`%Well I guess I could part with my prized Apricot seed, but it'll cost ya. `^10 gems`% and `^10,000 gold`%!`0\"`n`n");
                output("Will you buy the seed from Cedrick?");
                addnav("Buy Apricot seed","runmodule.php?module=orchard&op=cedrick&subop=buy");
        }
        elseif ($subop="buy"){
                if ($session['user']['gold']>=10000 && $session['user']['gems']>=10){
                        output("Cedrick takes your gold and gems and hands you a small seed in exchange.");
                        $session['user']['gold']-=10000;
                        $session['user']['gems']-=10;
                        orchard_findseed();
                }
                else{
                        if ($session['user']['gold']>=10000){
                                output("Cedrik stares at you blankly.  \"`%You don't have that many gems, `bgo get some more gems!`b`0\" he says.");
                        }
                        elseif ($session['user']['gems']>=10){
                                output("Cedrik stares at you blankly.  \"`%You don't have enough gold, `bgo get some more gold!`b`0\" he says.");
                        }
                        else{
                                output("Cedrik stares at you blankly.  \"`%You don't have enough gold or gems, `bgo get some more!`b`0\" he says.");
                        }
                }
        }
        addnav("Other");
        addnav("Return to the Inn","inn.php");
        villagenav();
}
elseif ($op=="stables"){
        page_header("Merick's Stables");
        output("`7You go searching for the Plum seed in the stables, Merick gives you an odd sort of glance but lets you be.");
        output("Unfortunately you can't seem to find it, just as you're about to give up you spot a large heap of manure in the corner.");
        output("You're not entirely sure you want to go looking in there, but what the heck it's worth it right?`n`n");
        output("You delve into the manure heap up to your waist and push your arms into the pile searching around.");
        output("By some miracle you manage to find a Plum seed in the stinking mess and raise it above you head shouting \"`5Woohoo!`7\"");
        output("`7Seeing what you're doing, Merick comes storming over screaming \"`&Ach, thats disgusting! git outta me stables!`7\" and chases you away.`n`n");
        output("`7Fortunately you managed to keep hold of the Plum seed and race away from the stables triumphantly.");
        orchard_findseed();
        villagenav();
}
elseif ($op=="abh"){
        if (get_module_pref("seed")==5){
                page_header("Abandoned House");
                output("`7`c`bAbandoned House`b`c`n");
                output("You enter the derelict building to discover... nothing.");
                output("Oddly enough the place is empty having been abandoned some time ago by it's previous owner.`n`n");
                output("You explore a little, and notice a small seed covered in dust, you aren't sure, but it looks like a banana seed.");
                addnav("Return to the Alley","runmodule.php?module=darkalley");
                orchard_findseed();
                page_footer();
        }
        else{
                page_header("Abandoned House");
                output("`7`c`bAbandoned House`b`c`n");
                output("You enter the derelict building to discover... nothing.");
                output("Oddly enough the place is empty having been abandoned some time ago by it's previous owner.`n`n");
                output("You explore a little, but discover nothing of interest, the previous owner must have taken everything with them when they left.");
                addnav("Return to the Alley","runmodule.php?module=darkalley");
                page_footer();
        }
}
elseif ($op=="ramius"){
        page_header("The Graveyard");
        output("`7`b`cThe Mausoleum`c`b");
        if (get_module_pref("seed")==6){
                if ($subop=="restore"){
                        $session['user']['deathpower']-=100;
                        output("`\$Ramius`7 is impressed with your actions, and agrees to restore life to your peach seed.`n`n");
                        orchard_findseed();
                }
                else{
                        if ($session['user']['deathpower']>=100){
                                output("`\$Ramius`7 speaks, \"`7You ask a favour of me?  but of course, as you are such a faithful servant to me I would be happy to grant this request.`7\"");
                                addnav("Restore the Seed (100 Favors)","runmodule.php?module=orchard&op=ramius&subop=restore");
                        }
                        else{
                                output("`\$Ramius`7 speaks, \"`7No, I refuse to grant your request.  If you want something from me, you have to earn it.  Continue my work and we may speak further.`7\"");
                        }
                }
        }
                output("`n`nYou have `6%s`7 favor with `\$Ramius`7.", $session['user']['deathpower']);
                addnav("Question `\$Ramius`0 about the worth of your soul","graveyard.php?op=question");
                $max = $session['user']['level'] * 5 + 50;
                $favortoheal = round(10 * ($max-$session['user']['soulpoints'])/$max);
                addnav(array("Restore Your Soul (%s favor)",$favortoheal),"graveyard.php?op=restore");

                addnav("Places");
                addnav("S?Land of the Shades","shades.php");
                addnav("G?Return to the Graveyard","graveyard.php");
                modulehook("ramiusfavors");
}
elseif ($op="hof"){
        page_header("Hall of Fame");
        $names=array("","Apple","Orange","Pear","Apricot","Banana","Peach","Plum","Fig","Mango","Cherry");
        $perpage = get_module_setting('perpage');
        if ($subop=="") $subop=1;
        $min = ($subop-1)*$perpage;
        $limit = "LIMIT $min,$perpage";
        $sql = "SELECT COUNT(*) AS c FROM " . db_prefix("module_userprefs") . " WHERE modulename = 'orchard' AND setting = 'tree' AND value > 0";
        $result = db_query($sql);
        $row = db_fetch_assoc($result);
        $total = $row['c'];
        addnav("Pages");
        for($i = 0; $i < $total; $i+= $perpage) {
                $pnum = ($i/$perpage+1);
                $min = ($i+1);
                $max = min($i+$perpage,$total);
                addnav(array("Page %s (%s-%s)", $pnum, $min, $max), "runmodule.php?module=orchard&op=hof&subop=$pnum");
        }
        $sql = "SELECT module_userprefs.value,accounts.name FROM " . db_prefix("module_userprefs") . "," . db_prefix("accounts") . " WHERE acctid = userid AND modulename = 'orchard' AND setting = 'tree' AND value > 0 ORDER BY (value+0) DESC $limit";
        $result = db_query($sql);
        $name = translate_inline("Name");
        $tree = translate_inline("Best Tree");
        $none = translate_inline("No Trees Found");
        rawoutput("<table border='0' cellpadding='2' cellspacing='1' align='center' bgcolor='#999999'>");
        rawoutput("<tr class='trhead'><td>$name</td><td>$tree</td></tr>");
        if (db_num_rows($result)==0){
                output_notl("<tr class='trlight'><td colspan='2' align='center'>`&$none`0</td></tr>",true);
        }
        else{
                for ($i=0;$i<db_num_rows($result);$i++){
                        $row = db_fetch_assoc($result);
                        if ($row['name']==$session['user']['name']){
                                rawoutput("<tr class='trhilight'><td>");
                        } else {
                                rawoutput("<tr class='".($i%2?"trdark":"trlight")."'><td>");
                        }
                        output_notl("`&%s`0",$row['name']);
                        rawoutput("</td><td>");
                        output_notl("`@%s`0",$names[$row['value']]);
                        rawoutput("</td></tr>");
                }
        }
        rawoutput("</table>");
}
addnav("Other");
addnav("Back to HoF", "hof.php");
villagenav();
page_footer();
?>