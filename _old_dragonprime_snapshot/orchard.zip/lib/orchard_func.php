<?php
function orchard_findseed(){
        $names=array("","apple","orange","pear","apricot","banana","peach","plum","fig","mango","cherry");
        output("`n`#You have found a`@ %s `#seed!`n",$names[get_module_pref("seed")]);
        output("You should probably take it to the orchard and get it planted.");
        set_module_pref("found",get_module_pref("seed"));
        set_module_pref("seed",0);
}

function orchard_monster($lvl){
        global $session;
        $names=array("","Apple","Orange","Pear","Apricot","Banana","Peach","Plum","Fig","Mango","Cherry");
        if (get_module_pref("monsterid")>0){
                if (get_module_pref("monsterlevel")!=$session['user']['level']){
                        orchard_monsterid($session['user']['level']);
                        output("`!Elendir`7 looks a little embarrassed, \"`#Urm, yes, well I know what I said before.  But after thinking about it, I'm quite sure it was actually a `4%s`# that stole my `@%s`# seed.`7\"",get_module_pref("monstername"),$names[$lvl]);
                }
                else{
                        output("`7\"`#As I said before, I think a `4%s`# stole my `@%s`# seed in the forest.`7\"",get_module_pref("monstername"),$names[$lvl]);
                }
        }
        else{
                orchard_monsterid($session['user']['level']);
                output("`7\"`#I'm afraid I lost one of my `@%s`# seeds the other day when I was wondering in the forest, if I recall correctly, a `4%s`# stole it.`7\"",$names[$lvl],get_module_pref("monstername"));
        }
}

function orchard_monsterid($lvl){
        // thankyou GenmaC for this little code snippet
        $sql = "SELECT * FROM ".db_prefix("creatures")." WHERE creaturelevel='".$lvl."'";
        $result = db_query($sql);
        while($row = db_fetch_assoc($result)){ 
                $critters[] = $row; 
        }
        $select = e_rand(0,count($critters)-1);
        set_module_pref("monsterid", $critters[$select]['creatureid']);
        set_module_pref("monsterlevel", $lvl);
        set_module_pref("monstername", $critters[$select]['creaturename']);
}
?>