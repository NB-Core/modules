<?php
global $session;
require_once("lib/http.php");
$op=httpget('op');
require_once("modules/lib/orchard_func.php");
switch($type){
        case cellar:
                output("`%You spot a seed in the darkness, picking it up you realise it's the apple seed you've been looking for!");
                orchard_findseed();
        case forest:
                if (get_module_pref("seed")==2){
                        output("`n`2As you are walking through the forest, you come across a large orange grove, you pick an orange and eat it.`n");
                        output("Just as you are about to throw the skin and seeds away, you remember the orchard and pocket one of the seeds.");
                        orchard_findseed();
                }
                elseif (get_module_pref("seed")==9){
                        output("`n`2Strolling through the forest in search of something to kill, you stumble upon a mango tree.  You think perhaps it's a little odd for a mange tree to be growing in the middle of the forest, but this is only a game after all.`n");
                        output("You decide it would be nice to eat a mango, and then you could keep one of the mango seeds and take it to the orchard.  So thats what you do.");
                        orchard_findseed();
                }
                break;
        case darkalley:
                $session['user']['specialinc'] = "module:orchard";
                if($session['user']['gold']<1000){
                        output("`n`7A shady figure approaches out of the darkness of the alley.`n");
                        output("`7Quickly looking you over he moves on in another direction. ");
                        output("Disappearing back into the darkness. You shake your head and wonder what that was all about.`n");
                        break;
                }

                if ($op=="pass"){
                        $session['user']['specialinc'] = "";
                        output("`n`7The salesman seems just too shady for you, and you pass on his offer.`n`n");
                        output("`7He slinks away, muttering, \"`7You don't know what you're missing, pal.`7\"`n`n");
                        output("`7You shake your head, and turn around to head back to the alley.");
                }
                elseif ($op=="accept"){
                        $session['user']['specialinc'] = "";
                        output("`n`7Shady though he is, you decide to take up the salesman on his offer.`n`n");
                        $session['user']['gold']-=1000;
                        debuglog("spent 1000 on the shady salesman.");
                        output("`7The salesman reaches into one of his deep pockets and pulls out a mango seed.");
                        output("The salesman explains to you that this seed is very rare.");
                        output("He then slinks off into the shadows as you examine the seed, ");
                        output("which you thankfully discover is actually a mango seed like he said, just what you needed for the orchard.");
                        orchard_findseed();
                }
                else{
                        output("`n`7While passing through the alley, a shady figure in a black trenchcoat and fedora catches your eye and motions you over into his dark corner.");
                        output("You cautiously apporach the man, wondering what he could want with you.");
                        output("Once you are close by he finally speaks, \"`7Greetings, adventurer.");
                        output("You look like you could use a break, and I am just the person to give you such a break.");
                        output("For the pittance of only `^1000`7 gold, I can offer you something that will be a great asset to you on your travels.");
                        output("Bear in mind, I don't offer my services to just anyone, so you're very lucky.");
                        output("Although, you will have to decide quickly, as I am quite busy.`7\"");
                        output("He stands there with his hands in his deep pockets, awaiting your decision.`n`n");
                        output("You ponder the shady salesman's pitch carefully, wondering how useful this mystery item might actually be, somewhat doubting that the salesman was fully honest.");
                        addnav("Accept the Salesman's Offer (`^1000`0 gold)", "runmodule.php?module=darkalley&op=accept");
                        addnav("Pass on the Salesman's Offer","runmodule.php?module=darkalley&op=pass");
                }
                break;
}
?>