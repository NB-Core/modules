<?php

function orchard_getmoduleinfo(){
        $info = array(
                "name"=>"Fruit Orchard",
                "author"=>"Spider, Billie Kennedy<br>Modified by `#Lonny Luberts",
                "version"=>"2.0",
                "category"=>"Village",
                "download"=>"http://www.pqcomp.com/modules/mydownloads/visit.php?cid=3&lid=106",
				"vertxtloc"=>"http://www.pqcomp.com/",
                "settings"=>array(
                        "Fruit Orchard Settings,title",
                        "growth"=>"How many days does it take for a tree to grow?,int|10",
                        "everyday"=>"Do the trees grow every single day?,bool|0",
                        "(select no if you only want the trees to grow when the user logs in.,note",
                        "orchardloc"=>"What city is the Orchard in?,location|".getsetting("villagename", LOCATION_FIELDS),
                        "usehof"=>"Use Hall of Fame?,bool|1",
                        "perpage"=>"How many trees per page in Hall of Fame?,int|15",
                ),
                "prefs"=>array(
                        "Fruit Orchard User Preferences,title",
                        "Be careful when editing these.  If you don't fully understand what they each do you could easily break the module for the user you're editing.  If you need more explanation on then get in touch with spider at spider@spiderscripts.org.uk,note",
                        "seed"=>"The level of the seed the user is currently searching for,int|0",
                        "found"=>"If the user has found their current seed this is it's level,int|0",
                        "tree"=>"The level of the users best tree,int|0",
                        "treegrowth"=>"The number of days left for the users current tree to finish growing,int|0",
                        "monsterid"=>"If the user is looking for a seed found on a dead monster this is that monsters ID,int|0",
                        "monsterlevel"=>"If the user is looking for a seed found on a dead monster this is that monsters level,int|0",
                        "monstername"=>"If the user is looking for a seed found on a dead monster this is that monsters name",
                        "hadfruittoday"=>"Has the user eaten fruit from their trees today?,bool|0",
                        "user_stat"=>"Display no. of lays in Stat bar?,bool|1",
                )
        );
        return $info;
}

function orchard_percent($from) {
        global $session;
        $ret = 0;
        if (is_module_active("cellar")){
            if (get_module_pref("seed","orchard")==1 && $from=="cellar") {
    	        $ret = 100;
            }
        }else{
            if (get_module_pref("seed","orchard")==1 && $from=="forest") {
            	$ret = 100;
            }
        }
        if (get_module_pref("seed","orchard")==2 && $from=="forest") {
        	$ret = 100;
        }
        if (is_module_active("darkalley")){
            if (get_module_pref("seed","orchard")==9 && $from=="darkalley") {
            	$ret = 100;
            }
        }else{
            if (get_module_pref("seed","orchard")==9 && $from=="forest") {
            	$ret = 100;
            }
        }
        return $ret;
}

function orchard_install(){
		module_addhook("changesetting");
        module_addhook("village");
        module_addhook("newday");
        module_addhook("newday-runonce");
        module_addhook("ale");
        module_addhook("stables-nav");
        module_addhook("dragonkilltext");
        module_addhook("battle-victory");
        module_addhook("mausoleum");
        module_addhook("footer-hof");  // added by Billie Kennedy
        module_addhook("charstats");   // added by Billie Kennedy
        module_addeventhook("forest",
                        "require_once(\"modules/orchard.php\");
                         return orchard_percent(\"forest\");");
        if (is_module_active("darkalley")) {
                module_addhook("darkalley");
                module_addeventhook("darkalley",
                                "require_once(\"modules/orchard.php\");
                                 return orchard_percent(\"darkalley\");");
        }
        if (is_module_active("cellar")) {
                module_addeventhook("cellar",
                                "require_once(\"modules/orchard.php\");
                                 return orchard_percent(\"cellar\");");
        }
        return true;
}

function orchard_uninstall(){
        return true;
}

function orchard_dohook($hookname, $args){
        global $session;
        require_once("modules/lib/orchard_func.php");
        switch($hookname){
        case "changesetting":
                if ($args['setting'] == "villagename") {
                        if ($args['old'] == get_module_setting("orchardloc")) {
                                set_module_setting("orchardloc", $args['new']);
                        }
                }
                break;
        case "village":
                if ($session['user']['location'] == get_module_setting("orchardloc")){
                        addnav($args["tavernnav"]);
                        addnav("Fruit Orchard", "runmodule.php?module=orchard");
                }
                break;
        case "footer-hof":  // added by Billie Kennedy
                        if(get_module_setting('usehof')){
                                addnav("Warrior Rankings");
                                addnav("Trees", "runmodule.php?module=orchard&op=hof");
                        }
                break;
        case "charstats":
                        if(get_module_pref("user_stat")){
                                $names=array("","Apple","Orange","Pear","Apricot","Banana","Peach","Plum","Fig","Mango","Cherry");
                                if(get_module_pref("tree")>0){
                                        setcharstat("Personal Info", "Tree", "`@" . $names[get_module_pref("tree")]);
                                }
                        }
                break;
        case "darkalley":
                addnav("Shady Houses");
                addnav("Abandoned House", "runmodule.php?module=orchard&op=abh");
                blocknav("runmodule.php?module=abh");
                break;
        case "mausoleum":
                if (get_module_pref("seed")==6){
                        addnav("Other");
                        addnav("Ask Ramius about Seed", "runmodule.php?module=orchard&op=ramius");
                }
                break;
        case "newday":
                set_module_pref("hadfruittoday",0);
                if (get_module_setting("everyday")){
                        if (get_module_pref("treegrowth")>0){
                                output("`n`@You recall that your tree still has `^%s`@ more days to grow`n",get_module_pref("treegrowth"));
                        }
                }
                else{
                        $growth=get_module_pref("treegrowth");
                        if ($growth>0){
                                $growth--;
                                set_module_pref("treegrowth",$growth);
                                if ($growth>0){
                                        output("`n`@You recall that your tree still has `^%s`@ more days to grow`n",$growth);
                                }
                                else{
                                        $tree = get_module_pref("tree")+1;
                                        set_module_pref("tree",$tree);
                                        output("`n`@You recall that your should be fully grown by now, perhaps you should visit the orchard and take a look.`n");
                                }
                        }
                }
                break;
        case "newday-runonce":
                if (get_module_setting("everyday")){
                        $sql = "SELECT * FROM " . db_prefix("module_userprefs") . " WHERE modulename = 'orchard' AND setting = 'treegrowth' AND value > 0";
                        $result = db_query($sql);
                        while($row = db_fetch_assoc($result)){
                                $value = $row['value'] - 1;
                                $sql2 = "Update " . db_prefix("module_userprefs") . " set value='$value' where modulename='orchard' AND setting='treegrowth' AND userid='{$row['userid']}'";
                          db_query($sql2);
                          if ($value==0){
                                  $tree = get_module_pref("tree","orchard",$row['userid']) + 1;
                                        $sql3 = "Update " . db_prefix("module_userprefs") . " set value='$tree' where modulename='orchard' AND setting='tree' AND userid='{$row['userid']}'";
                                  db_query($sql3);
                          }
                        }
                }
                break;
        case "ale":
                if (get_module_pref("seed")==4){
                        addnav("Other");
                        addnav("Ask about fruit seed", "runmodule.php?module=orchard&op=cedrick");
                }
                break;
        case "stables-nav":
                if (get_module_pref("seed")==7){
                        if (getsetting("villagename", LOCATION_FIELDS) == $session['user']['location']){
                                addnav("Other");
                                addnav("Search for fruit seed", "runmodule.php?module=orchard&op=stables");
                        }
                }
                break;
        case "dragonkilltext":
                if (get_module_pref("seed")==10){
                        output("You notice a small Cherry seed in the grass beside you, for some reason you decide to pick it up, perhaps it will be useful somewhere...");
                        orchard_findseed();
                }
                break;
        case "battle-victory":
                if (get_module_pref("monsterid")==$args['creatureid'] && $args['type']=="forest"){
                        output("`nYou find a small seed on the slain monsters corpse.  It appears to be exactly the seed you were looking for!");
                        set_module_pref("monsterid",0);
                        set_module_pref("monsterlevel",0);
                        set_module_pref("monstername","");
                        orchard_findseed();
                }
                break;
        }
        return $args;
}

function orchard_run(){
	global $SCRIPT_NAME;
	if ($SCRIPT_NAME == "runmodule.php"){
		$module=httpget("module");
		if ($module == "orchard"){
			require_once("modules/lib/orchard_func.php");
			include("modules/lib/orchard.php");
		}
	}
}

function orchard_runevent($type){
		include("modules/lib/orchard_event.php");
}
?>