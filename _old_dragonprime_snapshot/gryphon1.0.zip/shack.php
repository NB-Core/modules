<?
require_once "common.php";
checkday();

page_header("Old Man's Shack");
output("`c`b`&Rickety Old Shack`0`b`c`n`n");

if ($HTTP_GET_VARS[op]==""){
    if ($session[user][vial]==0){
    output("`6As you stroll towards the edge of town you notice an old shack shadowed in darkness.  Curious, you head towards it and hear an old man cursing to himself inside.  You enter the shack...`n`n",true);
    output("`2What, what?  Who's there? `6asks the old man`n`n",true);
    output("`6You state your name proudly, `3It is I, `#" . $session[user][name] . "`3, how can I help you old man?  I heard you cursing in anger at someone.`n`n",true); 
    output("`2I need to leave this land, I need to go away, but I am too old and weak to search for the last piece I need to finish my potion. `n`n`6He points to a cage in the corner, in it you see 2 lions.  Another cage hangs near it, in it you see 2 eagles.`n`n");
    output("`3What do you need? `6you ask curiously.`n`n",true);
    output("`6I need the`$ blood `6of a fairy, one vial of it.`n Will you bring me this?  You will be `^GREATLY `6rewarded.`n");
    addnav("Bring him a vial?", "shack.php?op=vial");
    addnav("Sorry, no time", "shack.php?op=novial");
    addnav("Return to Village", "village.php");
    }
    else if ($session[user][vial]==1){
    output("`2What, what?  Who's there? `6asks the old man`n`n",true);
    output("`2Don't come back until you bring me my vial of Fairy Blood!`n`n",true);
    addnav("Return to Village", "village.php");
    }
    else if ($session[user][vial]==2){
    output("`2What, what?  Who's there? `6asks the old man`n`n",true);
    output("`2You found it!  Yes...just one second...`n`n",true);
    output("`6The old man takes the vial and scurry's into the corner where his animals are.  He pours the vial into a cauldron.  You hear him mumble some incantations.`n`n",true);
    output("`6Suddenly there's a loud explosive sound and a huge cloud of smoke.......`n`n",true);
    output("`6The old man appears out of the cloud, next to him are two creatures, each has the head of a eagle, and the body of a lion with great wings.",true);
    output("`2These are gryphons, and you may have one for helping me.  I must leave now, thank you again! `6 And with that the old man hops on a gryphon and flies out of the roof and away.`n`n",true);
    output("`6You aquire a `^Gryphon!!`n`n",true);
    addnav("Return to the village","village.php");
    $session[user][vial]=3;
    $sql = "SELECT * FROM mounts WHERE mountname='Gryphon'";
   $result = db_query($sql);
    $mount = db_fetch_assoc($result);
    $id=$mount['mountid'];
    $session['user']['hashorse']=$id;
    $session['bufflist']['mount']=unserialize($mount['mountbuff']);
    
    }
    else if ($session[user][vial]==3){
    output("`6The shack is now empty where the old man once was.  `n`n",true);
    addnav("Return to Village", "village.php");
    }
}else if ($HTTP_GET_VARS[op]=="vial"){
        output("`2GOOD!  Please hurry, I may not last much longer and need the vial as soon as you can get it.",true);
	 output("`6The old man hands you a vial to use for the fairy blood.",true);
	$session[user][vial]=1;
	addnav("Return to the village","village.php");
        
}else if($HTTP_GET_VARS[op]=="novial"){
 output("`2BAH!! Get out and stop wasting my time.  Don't come back unless you want to help!",true);
addnav("Return to the village","village.php");
}


page_footer();
?>