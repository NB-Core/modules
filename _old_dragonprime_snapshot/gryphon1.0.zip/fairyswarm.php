<?
//fairy swarm by nick puleo
//compliments the rickety shack quest to get the gryphon
if (!isset($session)) exit();
if ($HTTP_GET_VARS[op]==""){
	$session[user][turns]--;
	output("`n`n`%While wondering through the forrest, you suddenly hear singing and laughter.", true);
	output("`%Looking around you don't see anything, then through a small clearing you see bright glimmering lights...`n`n",true);
	output("`%...you head through the clearing and see before you hundreds of fairies all flying around.  They are laughing and singing.",true);
	output("`%They appear to be hard at work at some jovial task, suddenly a fairy notices you and the laughter stops.  The singing stops.  The fairies line up as if they are ready for battle.",true);
	addnav("Stand your ground?","forest.php?op=stand");
	addnav("Massacre the fairies?","forest.php?op=charge");
	addnav("RUN AWAY!", "forest.php?op=runaway");
	$session[user][specialinc]="fairyswarm.php";
}else if ($HTTP_GET_VARS[op]=="stand"){
$battle=e_rand(1,100);
$battle=$battle+$session[user][attack];
	if ($battle<90){
	output("`%The fairies `^charge you `%.  Suddenly you are overwhelmed, they begin kicking, biting and scratching you.  Like a 1000 flies at once you are engulfed with fairies.`n`n");
	output("`%They are too much, suddenly you black out, you feel cold....the last thing you hear is the high pitched laughter as the fairies finish you off`n`n");
	output("`2You have `^died",true);
	$session[user][alive]=false;
         $session[user][hitpoints]=0;
         addnav("Daily News","news.php");
         addnews("`%".$session[user][name]."`3 was slaughtered by a group of fairies.");
	}
	if ($battle>=90){
	output("`%The fairies `^charge you `%.  You put up a staunch defence, swatting them back with your`^ ".$session[user][weapon] . ".`%It's difficult to make contact, but finally you connect with one.`n`n");
	output("`%The fairy falls to the ground.  His friends quickly flee in fear.  You look him in the eye and he screams as you do an overhead bash with your `^".$session[user][weapon] ."`n`n",true);
	output("`%The weapon makes contact and pulverizes the fairy into the ground.`n`n",true);  
	if ($session[user][vial]==1){output("`@Picking up the carcass, you squeeze the `&blood `@into the vial`n`n");$session[user][vial]=2;}
	$xp=$session[user][level]*50;
	output("`@You gain `^$xp `@expierence.");
	$session[user][ experience]+=$xp;
	addnav("Return to Forrest","forest.php");
	}
 }
 else if ($HTTP_GET_VARS[op]=="charge"){
$battle=e_rand(30,100);
$battle=$battle+$session[user][attack];
	if ($battle<90){
	output("`%You `^charge `% the fairies.  You run screaming like a madman...`n`n");
	output("`%While running you trip over a log and fall flat on your face.  Suddenly the fairies are all around you",true);
	output("`%They are too much, suddenly you black out, you feel cold....the last thing you hear is the high pitched laughter as the fairies finish you off`n`n");
	output("`2You have `^died",true);
	$session[user][alive]=false;
         $session[user][hitpoints]=0;
         addnav("Daily News","news.php");
         addnews("`%".$session[user][name]."`3 was slaughtered attacking a group of fairies.");
	}
	if ($battle>=90){
	output("`%You `^charge.  `%You are a madman, swinging like crazy with your`^ ".$session[user][weapon] . ". `% The fairies laugh as they dodge your swings with ease. Suddenly you make contact with one.  The fairies shreek in horror!  They quickly flee.`n`n");
	output("`%The fairy falls to the ground.  You look him in the eye and he screams as you do an overhead bash with your `^" .$session[user][weapon] . "`n`n",true);
	output("`%The weapon makes contact and pulverizes the fairy into the ground.`n`n",true);  
	if ($session[user][vial]==1){output(" Picking up the carcass, you squeeze the blood into the vial`n`n");$session[user][vial]=2;}
	$xp=$session[user][level]*50;
	output("`@You gain `^$xp `@expierence.");
	$session[user][ experience]+=$xp;
	addnav("Return to Forrest","forest.php");
	}
 }
 else if ($HTTP_GET_VARS[op]=="runaway"){
output("Run away!",true);
output("`@You run and run away from the fairies.  You get so winded you lose another forrest fight!");
$session[user][turns]--;
addnav("Return to Forrest","forest.php");
}

page_footer();
?>