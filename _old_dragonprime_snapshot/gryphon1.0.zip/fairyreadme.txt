The Gryphon/Fairy Quest

This is a new "quest" for your users to get a cool new mount

The first step is to add a field to the accounts table that is a tiny int length 3, and give it a default value of 0
Next you need to create a new mount and call it Gryphon.  NOTE: IT MUST BE NAMED GRYPHON WITH A CAPITAL G.  
You can give the mount any attributes you like, make it GOOD though, here is mine and you may use this:

INSERT INTO `mounts` (`mountid`, `mountname`, `mountdesc`, `mountcategory`, `mountbuff`, `mountcostgems`, `mountcostgold`, `mountactive`, `mountforestfights`, `tavern`, `newday`, `recharge`, `partrecharge`, `mine_canenter`, `mine_candie`, `mine_cansave`, `mine_tethermsg`, `mine_deathmsg`, `mine_savemsg`) VALUES (4, 'Gryphon', 'A beautiful beast that is half lion half eagle', 'Flying Beasts', 'a:7:{s:4:"name";s:16:"`&Gryphon Attack";s:8:"roundmsg";s:38:"`7Your Gryphon swoops down and attacks";s:7:"wearoff";s:29:"`7Your gryphon is tired today";s:6:"rounds";s:2:"75";s:6:"atkmod";s:3:"1.2";s:6:"defmod";s:3:"1.5";s:8:"activate";s:7:"offense";}', 6, 5250, 0, 2, 1, 'Your strap your gear to the gryphon and take off.', 'You decide to rest with your gryphon before fighting any more.', 'You take the time for a quick break before flying off to fight again.', 5, 5, 15, 'You tie your Gryphon up and enter the mine.', '', '');

Next deactivate the mount so you can not buy it in the stables...
    
Next extract the files to your LotGD directory.  Place the fairyswarm.php in the special directory.  Please shack.php in the main directory.
Add a nav point in the village to the shack.

that's it...good luck with the quest!