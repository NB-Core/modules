<?php

function constand_getmoduleinfo(){
	$info = array(
		"name"=>"User-Run Booth",
		"author"=>"Chris Vorndran",
		"version"=>"0.1",
		"category"=>"Village",
		"download"=>"http://dragonprime.net/index.php?module=Downloads;sa=dlview;id=27",
		"vertxtloc"=>"http://dragonprime.net/users/Sichae/",
		"description"=>"Allows a user, usually with Admin privs, to be running a booth. From their they will be able to give out certain things, depending on the powers they have.",
		"settings"=>array(
			"User-Run Booth Settings,title",
			"open"=>"Is the Booth open?,bool|0",
			"curgive"=>"What is the Booth currently giving?,textarea|",
			"staloc"=>"Location of the Stand,location|".getsetting("villagename", LOCATION_FIELDS),
			"Do NOT turn on the Booth until you have set an Owner,note",
			),
		"prefs"=>array(
			"User-Run Booth Prefs,title",
			"back"=>"Does this user run the Booth?,bool|0",
			),
		);
	return $info;
}
function constand_install(){
	module_addhook("village");
	module_addhook("changesetting");
	module_addhook("moderate");
	return true;
	}
function constand_uninstall(){
	db_query("DELETE FROM ".db_prefix("commentary")." WHERE section='sta'");
	return true;
}
function constand_dohook($hookname,$args){
	global $session;
	$sql = "SELECT name FROM ".db_prefix("accounts")." INNER JOIN ".db_prefix("module_userprefs")." ON acctid=userid WHERE modulename='constand' AND setting='back' AND value='1' LIMIT 1";
	$res = db_query($sql);
	$row = db_fetch_assoc($res);
	$name = $row['name'];
	$hname = color_sanitize($name);
	switch ($hookname){
		case "changesetting":
			if ($args['setting'] == "villagename") {
				if ($args['old'] == get_module_setting("staloc")) {
				   set_module_setting("staloc", $args['new']);
				}
			}
			break;
		case "village":
			if ($session['user']['location'] == get_module_setting("staloc") && get_module_setting("open") == 1){
				tlschema($args['schemas']['marketnav']);
				addnav($args['marketnav']);
				tlschema();
				addnav(array("%s's Booth",$hname),"runmodule.php?module=constand&op=enter");
			}
			break;
		case "moderate":
			$args['sta'] = array("%s's Booth",$hname);
			break;
		}
	return $args;
}
function constand_run(){
	global $session;
	$op = httpget('op');
	$sell = httppost("sell");
	$sql = "SELECT name,sex,race FROM ".db_prefix("accounts")." INNER JOIN ".db_prefix("module_userprefs")." ON acctid=userid WHERE modulename='constand' AND setting='back' AND value='1' LIMIT 1";
	$res = db_query($sql);
	$row = db_fetch_assoc($res);
	$name = $row['name'];
	require_once("lib/sanitize.php");
	$hname = color_sanitize($name);
	$g = translate_inline($row['sex']==0?"male":"female");
	$p = translate_inline($row['sex']==0?"his":"her");
	$pos = translate_inline($row['sex']==0?"He":"She");
	$ps = translate_inline($row['sex']==0?"himself":"herself");
	$race = $row['race'];
	$curgive = get_module_setting("curgive");
	if ($curgive == "") $curgive = translate_inline("Sorry for the inconvienence, but the Booth is still trying to get the supplies in.");
	page_header(array("%s's Booth",$hname));

	switch ($op){
		case "enter":
			output("`3You enter a dark and dank Booth.");
			output("Around you, you hear a %s's voice.",$g);
			output("Finding a tiny lantern, you light it.");
			output("Before you stands a %s %s, who introduces %s as `# %s`3.",$g,$race,$ps,$name);
			output("You smile, and see a tiny note, \"`#This Booth is currently offering: %s`3\"",$curgive);
			addnav("Look Around");
			if (get_module_pref("back") == 1) addnav("Backroom","runmodule.php?module=constand&op=backroom");
			addnav("Commons","runmodule.php?module=constand&op=commons");
			break;
		case "backroom":
			// Lets just assume that someone got in the backroom, without having the pref set... :P
			if (get_module_pref("back") == 0) redirect("runmodule.php?module=constand&op=commons");
			// Boot them to the Commons
			if ($sell == ""){
				output("`^Wandering into the backroom, you look around.");
				output("You see a bunch of blank signs, and a lot of paint.");
				output("What would you like to be selling?`n`n");
				rawoutput("<form action='runmodule.php?module=constand&op=backroom' method='POST'>");
				rawoutput("<textarea name=\"sell\" rows=\"10\" cols=\"60\" class=\"input\"></textarea>");
                rawoutput("<input type='submit' class='button' value='".translate_inline("Change")."'></form>");
			}else{
				output("`3Your new requests line is: `#%s.",$sell);
				set_module_setting("curgive",$sell);
			}
			addnav("Commons","runmodule.php?module=constand&op=commons");
			addnav("","runmodule.php?module=constand&op=backroom");
			break;
		case "commons":
			output("`3All around you, you see many people, bellowing requests.");
			output("You see `#%s`3, smiling happily, taking down all the requests.",$name);
			output("%s points to a sign, stating the line of requests: `#%s`3.`n`n",$pos,$curgive);
			require_once("lib/commentary.php");
			addcommentary();
			viewcommentary("sta","Hearing requests, you speak up",20,"requests");
			break;
	}
	villagenav();
page_footer();
}
?>