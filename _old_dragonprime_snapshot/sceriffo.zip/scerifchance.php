<?php
require_once "common.php";

page_header("Lo Sceriffo");
output("`c`b`&Lo Sceriffo`0`b`c`n`n");
if ($HTTP_GET_VARS['op'] == ""){
   output("`3Dopo aver fatto un baccano infernale riesci finalmente ad attirare l'attenzione dello sceriffo ");
   output("che lentamente si alza dalla sua scrivania e si avvicina alla tua cella. Tenendo la mano sul calcio ");
   output("della pistola nella fondina ti squadra attentamente e con fare svogliato dice: `n\"`#Cosa posso fare ");
   output("per un delinquente rinchiuso in una cella senza nessuna possibilit� di fuga ?`3\"`n Dopodich� un sorriso ");
   output("sardonico si dipinge sulle sue labbra.`n");
   addnav("Corrompi lo Sceriffo","scerifchance.php?op=corrompi");
   addnav("Sorprendi lo Sceriffo","scerifchance.php?op=sorprendi");
   addnav("Afferra la Pistola","scerifchance.php?op=pistola");
   addnav("Lascia Perdere","constable.php?op=twiddle");
}else if ($HTTP_GET_VARS['op'] == "corrompi"){
   page_header("Corruzione");
   if ($session['user']['gems'] != 0){
      if ($HTTP_POST_VARS['gemme']==""){
         output("`2Decidi di tentare la carta della corruzione, e non avendo neanche un pezzo d'oro decidi di offrire ");
         output("qualcuna delle tue gemme. Quante vuoi offrirne ?`n");
         output("<form action='scerifchance.php?op=corrompi' method='POST'><input name='gemme' value='0'><input type='submit' class='button' value='Dai'>`n",true);
         addnav("","scerifchance.php?op=corrompi");
      }else{
         $gemme = abs((int)$HTTP_POST_VARS['gemme']);
         if ($gemme > $session['user']['gems']) {
            output("`%Non fare il furbo, non hai tutte quelle gemme !!!`n");
            addnav("Gira i Pollici","constable.php?op=twiddle");
         }else{
            if ($gemme == 0) {
               output("`3Lo sceriffo prende le tue gemme immaginarie, apre la porta della cella e con un bastone inizia a ");
               output("dartele di santa ragione. Non si ferma fino a che non sei moribondo, e richiudendo la cella lo ");
               output("senti dire`n\"`#forse la prossima volta non ti prenderai gioco di me!!`3\"`n`n");
               output("`\$Sei ridotto in fin di vita!!`n`^Hai perso il 10% della tua esperienza!!`n");
               debuglog("perde 10% exp nel tentativo di corrompere lo sceriffo");
               $session['user']['hitpoints'] = 1;
               $session['user']['experience'] = intval($session['user']['experience'] * 0.9);
               addnav("Gira i Pollici","constable.php?op=twiddle");
            }else if ($gemme >= ($session['user']['gems']/2) OR $gemme > 3){
               output("`6Gli occhi dello sceriffo iniziano a brillare alla vista del luccichio nella tua mano, riesci ");
               output("a leggere la bramosia che lo sta animando, e dopo qualche istante vedi comparire la chiave della ");
               output("cella nella sua mano e le tue gemme cambiare proprietario. `n\"`#Io non ho visto nulla, ma sappi ");
               output("che se ti ritrover� nei miei giri di perlustrazione non ti far� nessuno sconto.`6\"`n");
               output("Detto ci� apre la cella e si gira dalla parte opposta, lasciandoti libero di fuggire.`n Non ti ");
               output("perdi in convenevoli e prendi veloce la strada per la libert�.`n");
               debuglog("Paga $gemme gemme per corrompere lo sceriffo e riesce a fuggire");
               addnews("`%".$session['user']['name']." `@� fuggito di prigione corrompendo lo sceriffo !!");
               $session['user']['gems'] -= $gemme;
               $session['user']['jail'] = 0;
               $session['return'] = "";
               addnav("Fuggi !!","village.php");
            }else{
               output("`3Lo sceriffo afferra le tue gemme e soppesandole dice:`n\"`#Non penserai che ti lasci fuggire per ");
               output("questa miseria, vero? Non riuscirei a pagarci neanche una notte con Violet!`3\"`n E detto ci� ");
               output("intasca le tue gemme e torna alla sua scrivania. Hai perso inutilmente $gemme gemme!!!`n");
               debuglog("Perde $gemme gemme nel tentativo di corrompere lo sceriffo");
               $session['user']['gems'] -= $gemme;
               addnav("Gira i Pollici","constable.php?op=twiddle");
            }
         }
      }
   }else {
      output("`3Sfortunatamente non hai ne oro ne gemme da offrire allo sceriffo, e rassegnato ti sdrai sulla brandina ");
      output("della cella a meditare sul fatto che il crimine non paga.`n");
      addnav("Gira i Pollici","constable.php?op=twiddle");
   }
}else if ($HTTP_GET_VARS['op'] == "sorprendi"){
   page_header("Sorprendi lo Sceriffo");
   output("`5Mentre lo sceriffo ti sbeffeggia senti la rabbia salire dentro di te, ed un piano di fuga improvviso ti si presenta ");
   output("davanti agli occhi: immobilizzare lo sceriffo, impossessarti delle chiavi della cella e fuggire verso la ");
   output("libert� !!`nDecidi immediatamente di tentare la sorte e ti avvicini alle sbarre con l'aria pi� innocente che ");
   output("ti riesce, parlando della tua presunta innocenza per distrarre lo sceriffo. Quando si avvicina alle ");
   output("sbarre quel tanto che basta con un guizzo fulmineo allunghi entrambe le braccia ");
   switch (e_rand(1,5)){
      case 1:
         output("`5e lo afferri alla gola con morsa d'acciaio. Colto alla sprovvista lo sceriffo ");
         output("non � in grado di reagire e ben presto lo rendi incosciente. Prendi le chiavi della cella, apri le sbarre ");
         output("e ti avvii verso la libert�!`n");
         switch (e_rand(0,1)){
            case 0:
               output("`n`%Sai che allo sceriffo non piacer� la tua azione, e che sicuramente aumenter� la taglia sulla tua ");
               output("testa, come sai perfettamente che la tua cattiveria ha subito un ulteriore incremento a causa della ");
               output("tua azione malvagia!`n");
               $taglia = 1000 * e_rand(1,3);
               $session['user']['bounty'] += $taglia;
               $session['user']['evil'] += 50;
               $session['user']['jail'] = 0;
               $session['return'] = "";
               addnav("Fuggi !!","village.php");
               debuglog("Immobilizza lo sceriffo e fugge dalla prigione. Aggiunta $taglia di taglia");
               addnews("`#".$session['user']['name']." `2� riuscito a fuggire dalla prigione dopo aver reso incosciente lo sceriffo !!");
            break;
            case 1:
               output("`n`5Nell'istante in cui stai per allontanarti dalla prigione, senti qualcosa di freddo e rigido sulla ");
               output("tua schiena all'altezza dei reni, e mentre ti giri per scoprire cosa sia vedi il ghigno del vice ");
               output("sceriffo che ti sta puntando la pistola.`n\"`^Pensavi forse di farla franca, delinquente? Sono ");
               output("certo che qualche giorno supplementare di prigione ti far� riflettere!`5\"`n`n");
               output("Detto ci� ti risbatte in cella e si ferma a soccorrere lo sceriffo.`n");
               $session['user']['jail'] = 2;
               $session['user']['evil'] += 41;
               addnav("Gira i Pollici","constable.php?op=twiddle");
            break;
         }
      break;
      case 2:
         output("`5solo per andare a sbattere il muso contro le sbarre! Lo sceriffo si aspettava la tua mossa ");
         output("e con un tempismo perfetto si � sottratto al tuo tentativo di immobilizzarlo. `nIl sorriso sardonico ");
         output("si � trasformato in un ghigno e quella che senti risuonare nella tua testa � la sua risata ... `n");
         output("`6AH AH  <big>AH AH  `^AH AH  <big>AH AH  <big>AH AH  <big>`\$AH AH  <big>AH AH AH AH</big></big></big></big>",true);
         addnav("Gira i Pollici","constable.php?op=twiddle");
         $session['user']['jail'] = 2;
      break;
      case 3: case 5:
         output("`5solo per afferrare l'aria!! Lo sceriffo, al di fuori della tua portata, se la ride di gusto sbeffeggiandoti ");
         output("per il tuo ridicolo tentativo. Per oggi non avrai sicuramente altre opportunit� di sorprenderlo.`nTi sdrai ");
         output("sulla brandina della tua cella rimuginando su ci� che hai fatto nel tentativo di capire dove hai sbagliato.`n");
         addnav("Gira i Pollici","constable.php?op=twiddle");
         $session['user']['jail'] = 2;
      break;
      case 4:
         output("`5e riesci ad afferrare il braccio destro dello sceriffo.`nLo tiri verso le sbarre cercando di immobilizzarlo ");
         output("ma per tua sfortuna lo sceriffo � mancino, ed estraendo la pistola ti colpisce con il calcio della stessa ");
         output("alla tempia. Perdi conoscenza e rinvieni quando una secchiata di acqua gelata ti colpisce. Lo sceriffo, con ");
         output("un secchio in mano ti osserva indispettito e ti dice`n\"`#Sono certo che un giorno di galera supplementare ");
         output("ti far� bene`5\"`nDopodich� si volta e torna alla sua routine dietro la scrivania.`n`n");
         output("Scopri inoltre che in seguito al colpo ricevuto hai perso il 5% della tua esperienza!!`n");
         addnav("Gira i Pollici","constable.php?op=twiddle");
         debuglog("perde il 5% exp + 21 PC tentando di fuggire dalla prigione");
         $session['user']['jail'] = 2;
         $session['user']['experience'] = intval($session['user']['experience'] * 0.9);
         $session['user']['evil'] += 21;
      break;
   }
}else if ($HTTP_GET_VARS['op'] == "pistola"){
   page_header("Afferra la Pistola");
   output("`5Mentre lo sceriffo ti sbeffeggia senti la rabbia salire dentro di te, ed un piano di fuga improvviso ti ");
   output("si presenta davanti agli occhi: impossessarti della pistola dello sceriffo, minacciarlo per farti aprire ");
   output("la cella e fuggire verso la libert� !!`nDecidi di tentare la sorte e ti avvicini alle sbarre con l'aria ");
   output("pi� innocente che ti riesce, parlando della tua presunta innocenza per distrarre lo sceriffo. Quando si ");
   output("avvicina alle sbarre quel tanto che basta con un guizzo fulmineo allunghi la mano ");
   switch (e_rand(1,2)){
      case 1:
         output("`5e afferri il calcio della pistola. La estrai e la punti contro lo sceriffo che ti guarda basito. ");
         output("Gli ordini di aprire la cella, ");
         switch (e_rand(1,2)){
            case 1:
               output("`5cosa che lo sceriffo si appresta a fare immediatamente, terrorizzato dall'arma che gli stai ");
               output("puntando addosso. Aperta la porta stordisci lo sceriffo colpendolo alla testa. ");
               output("Veloce ti allontani dalla prigione e ti dirigi alla piazza mescolandoti con gli altri ");
               output("cittadini.`nHai riguadagnato la libert� ma la tua cattiveria ha subito un notevole aumento ");
               output("come anche la taglia sulla tua testa.`n");
               if (e_rand(0,1) == 0){
                  $sql = "SELECT name,acctid,goldinbank,sex FROM accounts WHERE loggedin = 0 AND superuser = 0 ORDER BY RAND() LIMIT 1";
                  $result = db_query($sql) or die(db_error(LINK));
                  $row = db_fetch_assoc($result);
                  $nome = $row['name'];
                  $acctid = $row['acctid'];
                  $orobanca = $row['goldinbank'];
                  $sesso = $row['sex'];
                  if ($orobanca > 0){
                     $ororubato = intval($orobanca / 2);
                     if ($ororubato > 1000) {$ororubato = 1000; }
                     output("`6Inoltre mentre esci incroci `#$nome`6 e l".($sex?"a":"o")." derubi di `&$ororubato pezzi d'oro`6!!`n");
                     $mailmsg = "`^Mentre passavi nei pressi della prigione sei stato derubat".($sex?"a":"o")." di $ororubato pezzi d'oro da ";
                     $mailmsg .= "`#".$session['user']['name']." `^mentre evadeva dalla prigione. Purtroppo per te ";
                     $mailmsg .= "eri nel posto sbagliato al momento sbagliato.";
                     $session['user']['gold'] += $ororubato;
                     debuglog("deruba a $nome $ororubato pezzi d'oro mentre evade dalla prigione");
                     systemmail($acctid,"`!`bSei stato rapinato !!!`b",$mailmsg);
                     $sql = "UPDATE accounts SET goldinbank=goldinbank-$ororubato WHERE acctid = '$acctid'";
                     $result = db_query($sql) or die(db_error(LINK));
                     addnews("`#".$session['user']['name']." `2� riuscito a fuggire dalla prigione dopo aver reso incosciente lo sceriffo !!`n
                     `3Inoltre ha derubato `%$nome`3 che passeggiava tranquillamente da quelle parti !!");
                     $session['user']['evil'] += 30;
                  }else{
                     addnews("`#".$session['user']['name']." `2� riuscito a fuggire dalla prigione dopo aver reso incosciente lo sceriffo !!");
                  }
               }
               $taglia = 1000 * e_rand(1,3);
               $session['user']['bounty'] += $taglia;
               $session['user']['evil'] += 50;
               $session['user']['jail'] = 0;
               $session['return'] = "";
               addnav("Fuggi !!","village.php");
               debuglog("Immobilizza lo sceriffo e fugge dalla prigione. Aggiunti $taglia oro di taglia");
            break;
            case 2:
               output("`5ma quella mammoletta, terrorizzato dall'arma che gli punti contro ... sviene!!!`n Decidi ");
               output("quindi di forzare la serratura sparandole contro. ");
               switch (e_rand(1,2)){
                  case 1:
                     output("`5Purtroppo la tua mira lascia alquanto a desiderare e dopo aver sparato tutti i colpi, la ");
                     output("serratura � ancora integra.`nRassegnato abbandoni la pistola oramai inutile e torni a ");
                     output("sdraiarti sulla brandina a rimuginare sulla tua sfortuna.`n");
                     addnav("Gira i Pollici","constable.php?op=twiddle");
                     $session['user']['jail'] = 2;
                  break;
                  case 2:
                     output("`5Esplodi tutto il caricatore contro la serratura che alla fine cede con uno schianto. ");
                     output("Ma quando stai per avviarti alla porta, questa si apre e il vice sceriffo ti si ");
                     output("piazza davanti con il fucile spianato.`nNon ti rimane altro che avviarti nella cella ");
                     output("a fianco di quella vecchia e rassegnarti a scontare la tua pena ... almeno fino al ");
                     output("prossimo tentativo di fuga ;-)`n");
                     addnav("Gira i Pollici","constable.php?op=twiddle");
                     $session['user']['jail'] = 2;
                  break;
               }
            break;
         }
      break;
      case 2:
         output("`5e afferri il calcio della pistola. Purtroppo non riesci a stringerla a sufficienza e mentre ritrai ");
         output("il braccio ti scivola di mano. Cadendo parte un colpo che ");
         switch (e_rand(1,2)){
            case 1:
               output("`5ti colpisce alla spalla!! Lo sceriffo recupera velocemente l'arma e manda a chiamare il dottore ");
               output("per curarti.`n Doc Wylelm arriva dopo pochi minuti e si dedica alla tua ferita con professionalit�. ");
               output("Al termine del suo intervento ");
               if (($session['user']['maxhitpoints']/10) > $session['user']['level']){
                  output("ti comunica, con estremo rammarico, che hai perso `^`b1 HP `iPermanente`i`b``5!!`n");
                  output("`#La ferita ti ha causato anche la perdita del `b5%`b di esperienza!!`n");
                  debuglog("perde 1 HP permanente per un proiettile vagante tentando di evadere");
                  $session['user']['maxhitpoints']--;
                  $session['user']['hitpoints']--;
               }else{
                  output("sei come nuovo, anche se la ferita ti ha causato la perdita del `b5%`b di esperienza!!`n");
               }
               addnav("Gira i Pollici","constable.php?op=twiddle");
               $session['user']['jail'] = 2;
               $session['user']['experience'] = intval($session['user']['experience'] * 0.9);
            break;
            case 2:
               $sql = "SELECT name,acctid,sex FROM accounts WHERE loggedin = 0 AND superuser = 0 ORDER BY RAND() LIMIT 1";
               $result = db_query($sql) or die(db_error(LINK));
               $row = db_fetch_assoc($result);
               $nome = $row['name'];
               $acctid = $row['acctid'];
               $sesso = $row['sex'];
               /*$nome = "`\$Admin Excalibur";
               $acctid = 3;
               $sesso = 0; */
               output("`5colpisce l'innocente `@$nome `5che nel frattempo era entrato nella prigione.`n");
               if ($session['user']['gems'] > 0){
                  output("`%Lo sceriffo ti confisca `^1 gemma `%per darla come indennizzo al".($sex?"la povera":" povero")." `@$nome`%.");
                  output("`nL'azione appena compiuta aumenta anche la tua malvagit�, dovrai scontare una giornata supplementare ");
                  output("tra le sbarre!!`n");
                  $sql = "UPDATE accounts SET gems=gems+1 WHERE acctid = '$acctid'";
                  $result = db_query($sql) or die(db_error(LINK));
                  $mailmsg = "`%Mentre passavi nei pressi della prigione sei stato colpito da una pallottola vagante partita dall'arma ";
                  $mailmsg .= "dello sceriffo, mentre `#".$session['user']['name']." `%tentava di fuggire. Come indennizzo lo sceriffo ti ha dato ";
                  $mailmsg .= "una delle sue gemme.`n Speriamo tu possa accettarla e dimenticare l'accaduto.";
               }else{
                  output("`5Lo sceriffo ti confischerebbe 1 gemma se tu l'avessi per darla come indennizzo al".($sex?"`\$ povero":"`6la povera")." $nome.");
                  output("`nGli far� recapitare per l'inconveniente 2.000 pezzi d'oro, e ti augura che non porti rancore per l'accaduto.");
                  output("`nL'azione appena compiuta aumenta anche la tua malvagit�, dovrai scontare una giornata supplementare ");
                  output("tra le sbarre!!`n");
                  $sql = "UPDATE accounts SET goldinbank=goldinbank+2000 WHERE acctid = '$acctid'";
                  $result = db_query($sql) or die(db_error(LINK));
                  $mailmsg = "`%Mentre passavi nei pressi della prigione sei stato colpito da una pallottola vagante partita dall'arma
                  dello sceriffo, mentre `#".$session['user']['name']." `%tentava di fuggire. Come indennizzo lo sceriffo ha depositato
                  sul tuo conto 2.000 pezzi d'oro.`n Speriamo tu possa accettarla e dimenticare l'accaduto.";
               }
               $session['user']['jail'] = 2;
               addnav("Gira i Pollici","constable.php?op=twiddle");
               $session['user']['evil'] += 21;
               systemmail($acctid,"`!`bSei stato ferito !!!`b",$mailmsg);
            break;
         }
      break;
   }
}

page_footer();
?>

