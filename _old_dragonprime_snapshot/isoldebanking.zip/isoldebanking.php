<?php
/*
Details:
 * Isolde Banking
 * Datum: 27.07.2006
 * Autor: Gucky2000
*/
require_once("lib/systemmail.php");

function isoldebanking_getmoduleinfo(){
	$info = array(
		"name"=>"Isolde Banking",
		"author"=>"Gucky2000",
		"version"=>"0.9",
		"category"=>"Forest",
		"vertxtloc"=>"",
		"download"=>"",
		"settings"=>array(
			"Isolde Banking - Settings,title",
			"dklimit"=>"Min. Dragonkill to call for Isolde,int|0",
			"(set to 0 to deactivate),note"
		),
		"prefs"=>array(
			"Isolde Banking - Preferences,title",
			"firstseen"=>"Have you ever seen Isolde?(not active),bool|0"
		),
	);
	return $info;
} 

function isoldebanking_install(){
        debuglog("Adding Hooks");
        module_addhook("forest");
        return true;
}

function isoldebanking_uninstall(){
        output("Uninstalling this module.`n");
        return true;
}

function isoldebanking_dohook($hookname, $args){
	global $session;
	switch($hookname){
		case "forest":
			if (get_module_setting('dklimit')<=$session['user']['dragonkills']) {
				if (get_module_pref('firstseen') == 0) {
					addnav("I?Calling for Isolde","runmodule.php?module=isoldebanking&op=seefirst");
				}else{
					addnav("I?Calling for Isolde","runmodule.php?module=isoldebanking");
				}
			}
			break;
		default:
			break;
	}
	return $args;
}

function isoldebanking_run(){
	global $session;
	$op = httpget('op');
		page_header("Isolde the Elwetritsche's Banking");
	switch($op){
		case "":
			$rand = e_rand(1,10);
			output("`^`c`bIsolde the Elwetritsche's Banking`b`c`6");
			addnav("Return to Forest","forest.php");
			$amount=$session[user][gold];
			if ($rand == 1){
				if ($session[user][goldinbank]>=0){
					$randfail = e_rand(1,5);
					switch($randfail) {
					case 1:
						output("`n`nAs you call for Isolde, nothing happens.");
						output("Even after minutes of waiting, Isolde does not appear.`n`n");
						output("`bIn fact, you lose one turn for wasting your time.");
						$session['user']['turns']-=1;
						break;
					case 2:
						$session[user][gold]-=$amount;
						$amount = round($amount*0.9);
						output("`n`nAs she turns to you and waves softly with her wing goodbye, she falls over a log.");
						output("All your gold rolls over the forest bottom.");
						output("Hurriedly Isolde collects the fallen gold into her basket, but some coins stay lost.`n`n");
						output("`bIsolde founds only %s of your gold",$amount);
						debuglog("Isolde deposited ".$amount." gold in the bank");
				      	$session[user][goldinbank]+=$amount;
						break;
					case 3:
						$session['user']['gold']-=$amount;
						$amount = round($amount*1.1);
						output("`n`nAs she turns to you and waves softly with her wing goodbye, she falls over a stone.");
						output("All your gold rolls over the forest bottom.");
						output("Isolde searches for your gold and found a bit more gold.`n`n");
						output("`bIsolde founds %s gold and disappear in the forest.",$amount);
						debuglog("Isolde deposited ".$amount." gold in the bank");
				      	$session['user']['goldinbank']+=$amount;
						break;
					case 4:
						$sql = "SELECT * from ".db_prefix("accounts")." order by rand()";
						$result = db_query($sql);
						$row = db_fetch_assoc($result);
						$targetname = $row['name'];
						$targetid = $row['acctid'];
						output("`n`nAs she turns to you and waves softly with her wing goodbye, a strange feeling comes to you.");
						output("She seems very absentminded and had problems keeping your name in mind.`n`n");
						output("`bIsolde puts the gold to the bank, thats all you can see.");
						if ($targetid == $session['user']['acctid']) {
							output("But luckily she founds the right account.");
							debuglog("Isolde deposited ".$amount." gold in the bank");
					      	$session['user']['goldinbank']+=$amount;
		      		  		$session['user']['gold']-=$amount;
						}else{
							output("But not to your account. You lost %s gold",$amount);
							debuglog("Isolde deposited ".$amount." gold in the bank to ".$targetname);
							$sql = "UPDATE ". db_prefix("accounts") . " SET goldinbank=goldinbank+".$amount." WHERE acctid='{$targetid}'";
							db_query($sql);
		      		  		$session['user']['gold']-=$amount;
							$subj = array("`^You have received a money transfer!`0");
							$body = array("`&Isolde`6 has transferred `^%s`6 gold to your bank account! Nobody knows where it came from!",$amount);
							systemmail($targetid,$subj,$body);
						}
						break;
					default:
						output("`n`nIsolde walks your way.");
						output("As she sees you, she declines your request with a gesture.`n`n");
						output("`bShe is too tired to walk to the village.");
						break;
					}
				}else{
					output("You have a debt in your bank account, please pay your debt.`n`n");
					output("Isolde will not carry your gold to bank");
					debuglog("Depositing not allowed, user has debt");
				}
			}else{
				if ($session[user][goldinbank]>=0){
					$randbank = e_rand(1,5);
					switch($randbank) {
					case 1:
						output("`n`nYou give all your gold to Isolde and she runs to the village.`n`n");
						output("`^`b`nIsolde deposit `&%s`^ gold in the bank.",$amount);
						break;
					case 2:
						output("`n`nAs you call for Isolde, she comes over the path.");
						output("Silent she holds her basket open.`n`n");
						output("`bWith your gold in her basket, she runs to the village.");
						break;
					case 3:
						output("`n`nAs you call for Isolde, she comes cackling through the bushes.");
						output("She is scratched all over and is talking all the time.`n`n");
						output("`bIsolde puts your gold into her handbag and walks with a strut to the village.");
						break;
					case 4:
						output("`n`nAs you call for Isolde, she comes to you very lively.");
						output("She looks very fresh and energetic.`n`n");
						output("`bIsolde fills her backpack with your gold and runs away.");
						break;
					default:
						output("`n`nAs you call for Isolde, she shambles to you.");
						output("She seems to be very tired, because she was sent to bank a lot of times today`n`n");
						output("`bIsolde gets the bundle with all your gold and drags it to the bank.");
						break;
					}
					debuglog("Isolde deposited ".$amount." gold in the bank");
			      	$session[user][goldinbank]+=$amount;
	      	  		$session[user][gold]-=$amount;
				}else{
					output("You have a debt in your bank account, please pay your debt.`n`n");
					output("Isolde will not carry your gold to bank");
					debuglog("Depositing not allowed, user has debt");
				}
			}
			break;
		case "seefirst":
			addnav("C?Continue","runmodule.php?module=isoldebanking");
			set_module_pref('firstseen', 1);
			output("`b`cIsolde the Elwetritsche`c`b`n`n");
			output("`^You call the name of the fabulous creature you heared of and wait a short time.`n");
			output("Isolde is a Elwetritsche.`n");
			output("These creatures live in the deep forest and normally you see them at night.");
			output("But this Tritsche is different from the others.");
			output("Unbashfully she comes to you and carries a little bag.`n`n");
			output("Elwetritsche are little birdlike creatures, with rainbow-colored feathers, two little wings to fly and small Horns on the head.");
			output("They move so quickly normally you never see any of them.`n`n");
			output("Isolde's long beak seems frowningly, but her smart eyes shows, that she is harmless.");
			output("If she is not running, Isolde is shambling through the forest. Then she walks some kind of clumsy.`n`n`n");
			output("By now, you can call for Isolde and she brings your gold to the bank....hopefully");
			break;
		default:
			break;
	}
	page_footer();
}
?>