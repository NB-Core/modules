<?php
//Idee und Umsetzung
//Morpheus aka Apollon & Lilith
//2005 f�r logd.at(LoGD 0.9.7 +jt ext (GER) 3)
//Mail to Morpheus@magic.ms or Apollon@magic.ms
//Nicht vergessen, den Namen der eigenen Stadt ein zu f�gen, die Kommentierungen der Zeilen d�rfen gel�scht werden
//Die Burg, der Laden und der Wanderweg sind nicht im ZIP enthalten
require_once "common.php";
addcommentary();
page_header("Stadttor");
if($_GET_VARS['op']=="")
{
output("`c`b`6Das Stadttor Tetharions`0`b`c`n");
output("`n<table align='center'><tr><td><IMG SRC=\"images/stadt/stadttor.jpg\"></tr></td></table>`n",true);
output("`3Du kommst zum `TStadttor `3der sch�nen Kleinstadt `6Tetharion`3. Auf der einen Seite, innerhalb der Stadtmauer, liegt die Stadt, �berall ist gesch�ftiges Treiben zu sehen und `7Qualm `3steigt aus einigen `4Schornsteinen`3. Au�erhalb liegt ein kleines Camp von `vAbenteurern `3und `vKriegern`3, die dort lagern und ihre Zelte aufgeschlagen haben.`n");
output("`3Innerhalb der Mauer f�hrt ein kleiner, schmaler `7Bergpfad`3 hoch zur `6Burg Tetharion`3, wo die G�tter ihren Sitz haben und eine breite Stra�e direkt in die Stadt. Vor der Mauer f�hrt ein breiter Weg  Dich direkt in den `2Wald`3, in dem die Gefahren nur so auf Dich lauern.`n");
output("`3Am Tor stehen grimmig drein blickende `5Trolle`3 der Stadtwache, die dem `^Sheriff`3 unterstehen, und mustern einen jeden, der das `TTor`3 passieren m�chte, egal ob er `6Tetharion `3betritt oder verl��t.");

	if ($session[user][bounty]>100) //eine belibige H�he festetzen f�r das Kopfgeld
	{
	output("`3`n`nDu gehst durch das `TTor ");
    switch(e_rand(1,20))
		{
		case 1:
		case 2:
		case 3:
		case 4:
		case 5:
		case 6:
		case 7:
		case 8:
		case 9:
		case 10:
		case 11:
		case 12:
		case 13:
	   	case 14:
	   	case 15:
	   	case 16:
	   	output("`3und nickst den `5Stadtwachen `3freundlich zu, sie aber blicken dich nur grimmig an.");
		addnav("In der Stadtmauer");
		addnav("Nach Tetharion","village.php");
		addnav("Zur Burg","burgthetarion.php");
		addnav("L�den");
		addnav("Garros kleiner Torshop","garro.php");
		addnav("Vor dem Stadttor");
		$session['user']['specialinc']="";
		$session['user']['specialmisc']="";
		addnav("Zu den Feldern","stadttor.php?op=felder");
		addnav("In den Wald","forest.php");
		addnav("Wanderweg","wander.php");
		addnav("Der Heldenweg","heldenweg.php");
	   	break;
		case 17:
		case 18:
		output("`3und nickst den `%Stadtwachen `3freundlich zu, als pl�tzlich einer auf Dich zust�rzt: `v\"Hey, Dich kenne ich doch, auf Dich ist ein Kopfgeld ausgesetzt!\"");
		output("`3Er greift nach Dir, will Dich fest halten, doch mit ganzer Kraft gelingt es Dir, ihm zu entkommen, bevor die anderen heran sind, wobei Du allerdings Lebenspunkte verlierst.");
		$session['user']['hitpoints']*=0.9;
		addnav("In der Stadtmauer");
		addnav("Nach Tetharion","village.php");
		addnav("Zur Burg","burgthetarion.php");
		addnav("L�den");
		addnav("Garros kleiner Torshop","garro.php");
		addnav("Vor dem Stadttor");
		$session['user']['specialinc']="";
		$session['user']['specialmisc']="";
		addnav("Zu den Feldern","stadttor.php?op=felder");
		addnav("In den Wald","forest.php");
		addnav("Wanderweg","wander.php");
		addnav("Der Heldenweg","heldenweg.php");
		break;
		case 19:
		case 20: 
		output("`3und nickst den `%Stadtwachen `3freundlich zu, als pl�tzlich einer auf Dich zust�rzt: `v\"Hey, Dich kenne ich doch, auf Dich ist ein Kopfgeld ausgesetzt!\"");
		output("`3Er greift nach Dir und Du versuchst Dich zu befreien, greifst nach Deiner Waffe, worauf hin andere Wachen ihren Bogen z�cken und Dich mit Pfeilen spicken.");
		output("`3Das letzte, was Du noch h�rst, ist das Lachen der `%Trolle`3, die sich auf das `6Kopfgeld`3 freuen.");
		$session['user']['alive']=false;
		$session['user']['deathpower']+=15;
		$session['user']['hitpoints']=0;
		$session['user']['gold']=0;
		$session['user']['experience']*0.97;
		$session[user][bounty]=0;
		addnews($session['user']['name']." starb bei dem Versuch, der Verhaftung durch die Stadtwache zu entkommen.");
		addnav("T�gliche News","news.php");
		break;
		}
	}
	else
	{
		output("`3`n`nDu gehst durch das `TTor `3und nickst den `%Stadtwachen `3freundlich zu. Sie nicken zur�ck, widmen sich dann aber weiter der Kontrolle des Zugangs zur Stadt.");
		addnav("In der Stadtmauer");
		addnav("Nach Tetharion","village.php");
		addnav("Zur Burg","burgthetarion.php");
		addnav("L�den");
		addnav("Garros kleiner Torshop","garro.php");
		addnav("Vor dem Stadttor");
		$session['user']['specialinc']="";
		$session['user']['specialmisc']="";
		addnav("Zu den Feldern","stadttor.php?op=felder");
		addnav("In den Wald","forest.php");
		addnav("Wanderweg","wander.php");
		addnav("Der Heldenweg","heldenweg.php");
	}
}
if ($_GET[op]=="felder")
	{
    page_header("Die Felder");
	output("`n<table align='center'><tr><td><IMG SRC=\"images/stadt/feldlager.jpg\"></tr></td></table>`n",true);
	output("`n`gDu gehst in das Feldlager, dass sich vor dem `TTor `gbefindet und schlenderst an vielen `tZelten`g vorbei. Vor einigen sitzen `vKrieger`g, von denen Dich manche misstrauisch beobachten, andere wiederum dich zu ihrem `\$Lagerfeuer `geinladen.`n`n");
	output("`gBei einem der `vKrieger `gmachst Du dann halt und nimmst seine Einladung an, seinen Geschichten am `\$Lagerfeuer `gzu lauschen:`n`n");
    viewcommentary("felder","`gMit anderen unterhalten:",20);
	addnav("Zur�ck zum Stadttor","stadttor.php");
	addnav("Die Felder");
		if (getsetting("pvp",1))
		{
		addnav("Spieler t�ten","pvp.php");
		}
	addnav("Nachtlager aufschlagen (Logout)","login.php?op=logout",true);
	}
page_footer();
?>