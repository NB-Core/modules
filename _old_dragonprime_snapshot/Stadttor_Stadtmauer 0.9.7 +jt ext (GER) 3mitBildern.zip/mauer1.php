<?php
//Idee und Umsetzung
//Morpheus aka Apollon
//2005 f�r logd.at(LoGD 0.9.7 +jt ext (GER) 3)
//Mail to Morpheus@magic.ms or Apollon@magic.ms
//Nicht vergessen, den Namen der eigenen Stadt ein zu setzen und die addnavs zu �ndern
require_once "common.php";
page_header("Die Stadtmauer");
if($_GET_VARS['op']=="")
	{
    page_header("Die Stadtmauer");
	output("`n<table align='center'><tr><td><IMG SRC=\"images/stadt/mauer.jpg\"></tr></td></table>`n",true);
	output("`n`gDu gehst vom Stadtplatz zu einer einsamen Stelle an der Stadtmauer, weil Du etwas zu verbergen hast vor den `%Torwachen`g. Du wei�t, wo eine geheime T�r in der Stadtmauer ist, die Du nutzen k�nntest. Jetzt stehst Du vor der hohen `7Stadtmauer`g, die stellenweise von `2B�schen`g und `2Efeu `gbewachsen ist und kannst schon die Stelle erkennen, wo sich die T�r befindet, die nicht immer bewacht ist.`n`n");
	output("`gWas willst Du tun?`n`n");
	addnav("Die Stadtmauer");
	addnav("Versuchen, aus der Stadt zu schleichen","mauer1.php?op=schleichen");
	addnav("Vielleicht schaffe ich es ja doch durch das Stadttor","stadttor.php");
	addnav("Doch lieber zur�ck zum Stadtplatz","village.php");
	}
if ($_GET[op]=="schleichen")
{
output("`c`b`7Die Stadtmauer`0`b`c`n");
output("`gVorsichtig trittst Du n�her an die `7Mauer `gund dr�ckst dichte `2Efeub�schel `gnach rechts und links zur Seite, wodurch eine massive `THolzt�r `gmit `7Eisenverschl�gen `gzum Vorscheinen kommt.");
output("`g�ngstlich blickst du dich noch einmal um, ob dich auch niemand beobachtet und keine der `%Stadtwachen `gin der N�he ist, dann tritst du nahe an die `TT�r`g.");
	if ($session[user][bounty]>100)
	{
	output("`gDu dr�ckst die `7Klinke`g nieder, �ffnest die `TT�r`g, ");
    switch(e_rand(1,20))
		{
		case 1:
		case 2:
		case 3:
		case 4:
		case 5:
		case 6:
		case 7:
		case 8:
		case 9:
		case 10:
		case 11:
		case 12:
		case 13:
	   	case 14:
	   	case 15:
	   	case 16:
		case 17:
		case 18:
	   	output("`gpassierst sie schnell, schlie�t sie wieder von au�en und machst Dich davon. Hui, das ging nochmal gut! ");
		addnav("In den Wald","forest.php");
	   	break;
		case 19:
		output("`gpassierst sie schnell, schlie�t sie wieder von au�en und willst Dich grade davon machen, als sich eine `%Stadtwache`g, die im Schatten stand, wo Du sie nicht sehen konntest, auf Dich st�rtzt: `v\"Hey, Dich kenne ich doch, auf Dich ist ein Kopfgeld ausgesetzt!\"");
		output("`gDu ziehst Deine Waffe, schl�gst nach der `%Wache `gund diese f�llt ohnm�chtig zu Boden, w�hrend Du schnell das Weite suchst. Bei diesem kleinen Scharm�tzel hast Du ein paar Lebenspunkte eingeb��t.");
		$session['user']['hitpoints']*=0.9;
		addnews($session['user']['name']." wurde verletzt als ".($session[user][sex]?"sie":"er")." aus der Stadt schlich.");
		addnav("In den Wald","forest.php");
		break;
		case 20: 
		output("`gpassierst sie schnell, schlie�t sie wieder von au�en und willst Dich grade davon machen, als sich eine `%Stadtwache`g, die im Schatten stand, wo Du sie nicht sehen konntest, auf Dich st�rtzt: `v\"Hey, Dich kenne ich doch, auf Dich ist ein Kopfgeld ausgesetzt!\"");
		output("`gDu ziehst Deine Waffe, schl�gst nach der `%Wache `gund hoffst, Dich befreien zu k�nnen, doch diese ist schneller. Mit einem gekonnten Schwerthieb streckt die `%Wache `gdich nieder und du brichst, t�dlich getroffen, zusammen.");
		$session['user']['alive']=false;
		$session['user']['deathpower']+=15;
		$session['user']['hitpoints']=0;
		$session['user']['gold']=0;
		$session['user']['experience']*0.97;
		$session[user][bounty]=0;
		addnews($session['user']['name']." starb bei dem Versuch, in die Stadt zu schleichen.");
		addnav("T�gliche News","news.php");
		break;
		}
	}
	else
	{
		output("`gDu dr�ckst die `7Klinke`g nieder, �ffnest die `TT�r`g, passierst sie schnell, schlie�t sie wieder von au�en und gehst kichernd in den `2Wald`g. Hui, das war ein nettes, kleines Abenteuer!");
		addnav("In den Wald","forest.php");
	}
}
page_footer();
?>