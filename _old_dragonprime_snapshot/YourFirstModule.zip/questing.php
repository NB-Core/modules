<?php
$quests = array( "stolenitem" => array("Description"=>"During the night something snuck into my home
                                                       and removed a very valuable item from within.
													   find that creature and destroy it and I shall
													   reward you.",
                                       "Reward"=>'$session["user"]["gold"]+=900;output("Your pockets feel heavier, you have recieved 900 gold.");',
                                       "Type"=>"creature",
                                       "Name"=>"stolenitem"
                                      ),
                 "gosomeplace"=> array("Description"=>"I see that you like to travel go to $(TownName)
				 				 					   and I shall reward you.",
                                       "Reward"=>'$session["user"]["gems"]++;output("Your pockets feel heavier, you have recieved 1 gem.");',
                                       "Type"=>"town",
                                       "Name"=>"gosomeplace"
                                      )
               );

function questing_getmoduleinfo(){
  $info = array(
    "name"=>"Configurable Questing Module",   // Name to display to the admin
    "version"=>"1.0",                         // Version number of the module
    "author"=>"Jeremy Darling",               // Your name
    "category"=>"Questing",                   // Category to list module under when installed
    "download"=>"http://www.dragonprime.net/",// Download location for module
    "prefs"=>array(
                   "Questing module settings,title",
                   "CurrentQuest"=>"Current user quest|",
                   "VillageName"=>"Village to travel to|"
                  )
  );
  return $info;
}

function questing_install(){
  if (!is_module_installed("cities")) {
    output("This module requires the Multiple Cities module to be installed.");
    return false;
  }

  module_addhook("battle-victory");
  module_addhook("village");
  module_addeventhook("forest", "return 100;");
  return true;
}

function questing_uninstall(){
  return true;
}

function questing_CompletedQuest()
{
  output("From no where the Quest Master appears in front of you.  \"You have done
          as I asked.  Now here is your reward\".");
}

function questing_HandleVitory(){
  $idropped  = e_rand(1, 100);
  global $session;
  if (($idropped < 50) && ($idropped > 20))
  {
    questing_CompletedQuest();
    eval($quest["Reward"]);
    output("`n");
    set_module_setting("VillageName", "");
    set_module_setting("CurrentQuest", "");
  }
}

function questing_dohook($hookname,$args){
  global $session;
  $questname = get_module_setting("CurrentQuest");
  if ($questname <> ''){
    $quest = $quests[$questname];
    $townname = get_module_setting("VillageName");
    swtich($hookname){
      case "village":
        if ($session['user']['location'] == $townname){
          questing_CompletedQuest();
          eval($quest["Reward"]);
          output("`n");
          set_module_setting("VillageName", "");
          set_module_setting("CurrentQuest", "");
        }
      break;
      case "battle-victory":
        questing_HandleVitory();
      break;
      default:
        // code for an undefined hoook goes here
      break;
    }
  }
  return $args;
}

function questing_runevent($type){
  $op = httpget("op");
  swtich($type){
    case "forest":
    default:
      if ($op<>"")
      {
        questing_HandleEventOp($op);
      }
      else
      {
	      // code to handle hook goes here
	    output("You stumble upon a small hut in the middle of no where.  From within
		        the hut a small elf appears.  \"I am the quest master\" he exclaims.
		        \"If you are brave and willing I will send you upon a quest and
			    upon its completetion will reward you\".");
	    addnav("Ask about a Quest","forest.php?op=askforquest");
	    addnav("Run away", "forest.php?op=chicken");
    	$session['user']['specialinc'] = "module:questing";
	  }
    break;
  }
  output("`0");
  return $args;
}

function questing_GetRandomQuest(){
  $questnum = e_rand(1, count($quests));
  reset($quests);
  if ($questnum>1){
    for($i=1;$i<$questnum;$i++){
      next($quests);
    }
  }
  return current($quests);
}

function questing_GetRandomCity()
{
  $vloc = array();
  $vname = getsetting("villagename", LOCATION_FIELDS);
  $vloc[$vname] = "village";
  $vloc = modulehook("validlocation", $vloc);
  $cityindex = e_rand(1, count($vloc));
  reset($vloc);
  if ($cityindex>1){
    for($i=1;$i<$cityindex;$i++){
      next($vloc);
    }
  }
  return key($vloc);
}

function questing_run(){
}

function questing_HandleEventOp($op){
  global $session;

  $op = httpget("op");
  switch($op){
    case "askforquest":
      if (get_module_setting("CurrentQuest") <> '')
      {
        output("Why is it you bother me once again when you still haven't managed ");
        output("to do the simple task I put before you.  Now be gone, until you have ");
        output("completed what I asked.");
		$session['user']['specialinc']="";
      }
      else
      {
        $quest = questing_GetRandomQuest();
        $townname = questing_GetRandomCity();
        $quest['Description'] = str_replace("$(TownName)", $townname, $quest['Description']);
        output($quest['Description']);
        set_module_setting("CurrentQuest", $quest['Name']);
        set_module_setting("VillageName", $townname);
		$session['user']['specialinc']="";
      }
    break;
    case "chicken":
      output("Deciding that this fellow looks a bit too much like the madman killer
	          you see on TV every night you quickly hit the rewind button back to
			  the forest.");
      $session['user']['specialinc'] = "";
    break;
  }
}
?>
