<?php
require_once("lib/showform.php");
function boosts_admin_getmoduleinfo(){
    $info = array(
        "name"=>"Boosts - Admin control module",
        "version"=>"1.2",
        "author"=>"R4000",
        "category"=>"Boosts",
        "download"=>"",
    );
    return $info;
}

function boosts_admin_install(){
	output("`^PLEASE REMEMBER THAT THE BOOSTS SYSTEM IS STILL IN BETA AND MAY CAUSE BUGS`n");
	output("`^THE WIERDEST BUG SO FAR IS A USER RECIEVING 40000+ EXP, BUT I THINK I IRONED IT OUT`n");
	output("`^PLEASE BE CAREFULL THOUGH!`n`n");
	module_addhook("superuser");
	return true;
}

function boosts_admin_uninstall(){
    return true;
}

function boosts_admin_dohook($hookname,$args){
    global $session;
    $from = "runmodule.php?module=boosts_admin&";
    switch($hookname){
	case "superuser":
		if ($session['user']['superuser'] & SU_EDIT_MOUNTS)addnav("Actions");	
		if ($session['user']['superuser'] & SU_EDIT_MOUNTS)addnav("Boost Control", $from."op=editor&what=view");
	break;
	}
    return $args;
}
function boosts_admin_run() {
    global $session;
	$op = httpget('op');
	$from = "runmodule.php?module=boosts_admin&op=editor&";
	page_header("Boost Control");
	if ($op == "editor"){
		$id = httpget('id');
		$boosts = array();
		if(is_module_active("boosts_xp"))  $boosts['xp'] =array("xp"  , "Experience");
		if(is_module_active("boosts_atk")) $boosts['atk']=array("atk" , "Attack");
		if(is_module_active("boosts_def")) $boosts['def']=array("def" , "Defence");	
		if(is_module_active("boosts_gold")) $boosts['def']=array("gold" , "Gold");	
		$itemarray=array(
			"Boost Settings (".$id."),title",
			"active"=>"Is Boost Enabled?,enum,0,No,1,Yes",
			"multip"=>"Boost Multiplier?,int|2",
			);	
		$row=array(				
			"active"=>0,									
			"multip"=>2,
			);
		switch (httpget('what')){
			case "view":							
				output("`^Please use the navigation on the left menu to configure your boosts.`n");
				output("`5You have the following boost modules installed:`n`n");
				foreach($boosts as $boost){
					output("`t`2%s`n",$boost[1]);
				}    
				break;
			case "edit":
				rawoutput("<form action='runmodule.php?module=boosts_admin&op=editor&what=save&id=$id' method='POST'>");
				addnav("","runmodule.php?module=boosts_admin&op=editor&what=save&id=$id");				
				showform($itemarray,$row);
				rawoutput("</form>");	
				break;	
			case "save":
				$active = httppost('active');
				$multip = httppost('multip');
				$sql = "UPDATE " . db_prefix("module_settings") . " SET value=\"$active\" WHERE modulename='boosts_$id' AND setting='booston'";
				db_query($sql);
				$sql = "UPDATE " . db_prefix("module_settings") . " SET value=\"$active\" WHERE modulename='boosts_$id' AND setting='multip'";
				db_query($sql);
				output("`^The boost settings have been saved!`n");
				break;
		}
   		modulehook("boosts-admin-editor", array());  
		addnav("Boosts");
		foreach($boosts as $boost){
			addnav(array("%s",$boost[1]),$from."what=edit&id=".$boost[0]);
		}    
    		addnav("Other");	
		addnav("Return to the Grotto", "superuser.php");
	}			
	page_footer();
}
?>