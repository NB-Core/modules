<?php
require_once("lib/showform.php");
function boosts_xp_getmoduleinfo(){
	$info = array(
		"name"=>"XP Boost",
		"version"=>"0.1",
		"author"=>"R4000",
		"category"=>"Boosts",
		"download"=>"",
		"settings"=>array(
			"XP Boost Settings - Main,title",
			"multip"=>"Multiplier (XP = OrginalXP*this),int|2",
			"msga"=>"Boost Message (In Battle %d = XP)|You have gained %d extra XP points due to the boost!",						
			"msgb"=>"Boost Message (In Home/newdays)|The gods have declared a boost to Experience!",						
			"msgc"=>"Boost Message NOT IMPLIMENTED! (In Header)|The gods have declared a boost to Experience.",						
			"days"=>"The amount of days to boost for. NOT IMPLIMENTED,int|1",
			"booston"=>"Boost currently enabled?,bool|0",
		),
		"prefs"=>array(
			"XP Boost Preferences,title",
			"xpbonus"=>"XP bonus points"
		),
		"requires"=>array(
			"boosts_admin"=>"1.2|R4000, available at Dragonprime",
		),
	);
	return $info;
}
function boosts_xp_install(){
	output("`^PLEASE REMEMBER THAT THE BOOSTS SYSTEM IS STILL IN BETA AND MAY CAUSE BUGS`n");
	output("`^THE WIERDEST BUG SO FAR IS A USER RECIEVING 40000+ EXP, BUT I THINK I IRONED IT OUT`n");
	output("`^PLEASE BE CAREFULL THOUGH!`n`n");
	module_addhook("newday");
	module_addhook("index");
	module_addhook("creatureencounter");
	module_addhook("battle-victory");
	return true;
}

function boosts_xp_uninstall(){	
	return true;
}
function boosts_xp_dohook($hookname,$args){
	global $session;
	if(get_module_setting("booston")){
		switch ($hookname) {
			case "battle-victory":
				output(sprintf("`^%s`n",get_module_setting("msga")),get_module_pref("xpbonus"));
			case "creatureencounter":
				$oldxp = $args['creatureexp'];
				$args['creatureexp']*=get_module_setting("multip");
				$gained = $args['creatureexp']-$oldxp;
				set_module_pref("xpbonus",$gained);
				break;
			case "newday":
				$msg = get_module_setting("msgb");
				output("`2%s`n",$msg);
				break;			
			case "index":
				$msg = get_module_setting("msgb");
				output("`2%s`n",$msg);
				break;
		}
	}
	return $args;
}
function boosts_xp_run(){	
	return true;
}
?>