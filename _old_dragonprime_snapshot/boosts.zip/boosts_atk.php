<?php
require_once("lib/showform.php");
function boosts_atk_getmoduleinfo(){
	$info = array(
		"name"=>"Attack Boost",
		"version"=>"0.1",
		"author"=>"R4000",
		"category"=>"Boosts",
		"download"=>"",
		"settings"=>array(
			"Attack Boost Settings - Main,title",
			"multip"=>"Multiplier (Atk = OrginalAtk*this),int|2",
			"msga"=>"Boost Message (In Battle)|There is a boost to your Attack, thank the gods!",						
			"msgb"=>"Boost Message (In Home/newdays)|The gods have declared a boost to Attack!",						
			"msgc"=>"Boost Message NOT IMPLIMENTED! (In Header)|The gods have declared a boost to Attack.",						
			"days"=>"The amount of days to boost for. NOT IMPLIMENTED,int|1",
			"booston"=>"Boost currently enabled?,bool|0",
		),
		"requires"=>array(
			"boosts_admin"=>"1.2|R4000, available at Dragonprime",
		),
	);
	return $info;
}
function boosts_atk_install(){
	module_addhook("newday");
	module_addhook("index");
	module_addhook("forest");
	module_addhook("village");
	return true;
}

function boosts_atk_uninstall(){	
	output("`^PLEASE REMEMBER THAT THE BOOSTS SYSTEM IS STILL IN BETA AND MAY CAUSE BUGS`n");
	output("`^THE WIERDEST BUG SO FAR IS A USER RECIEVING 40000+ EXP, BUT I THINK I IRONED IT OUT`n");
	output("`^PLEASE BE CAREFULL THOUGH!`n`n");
	return true;
}
function boosts_atk_dohook($hookname,$args){
	global $session;
	switch ($hookname) {
		case "forest":
		case "village":
		case "newday":
			if(!has_buff("atkboostv0.1") && get_module_setting("booston")){
				$buff = array(
					"name"=>"`^Attack boost",
					"wearoff"=>"`^The gods have revoked the Attack boost.",
					"atkmod"=>1*get_module_setting("multip"),
					"survivenewday"=>1,
					"rounds"=>-1,
					"roundmsg"=>"`^".get_module_setting("msga"),
					"schema"=>"module-boosts-atk"
					);
				apply_buff("atkboostv0.1",$buff);
				$msg = get_module_setting("msgb");
				output("`2%s`n",$msg);
			} elseif (has_buff("atkboostv0.1") && !get_module_setting("booston")){
				strip_buff("atkboostv0.1");
			}
			break;			
		case "index":
			if(get_module_setting("booston")){
				$msg = get_module_setting("msgb");
				output("`2%s`n",$msg);
			}
			break;
	}
	return $args;
}
function boosts_atk_run(){	
	return true;
}
?>