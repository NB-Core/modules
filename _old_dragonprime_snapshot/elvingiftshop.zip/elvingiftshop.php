<?
function elvingiftshop_getmoduleinfo(){
	$info = array(
		"name"=>"Elvin gift Shop",
		"version"=>"1.55",
		"author"=>"`#Lonny Luberts, text modified for elvin gift shop by Niksolo",
		"category"=>"PQcomp",
		"download"=>"http://dragonprime.net/users/Finwe/elvingiftshop.zip",
		"settings"=>array(
			"PQ Gift Shop Module Settings,title",
			"gsloc"=>"Where does the Gift Shop appear,location|".getsetting("villagename", LOCATION_FIELDS),
			"gsowner"=>"Gift Shop Clerk Name,text|`#F`3inwe",
			"gsheshe"=>"Gift Shop Owner Sex,text|he",
			"special"=>"Shop Specialty,text|Elven Enthusiast",
			"If you use the word -Card- the gift show will assume it is a greeting card,note",
			"gift1"=>"Gift1,text|Elven Brooch",
			"gift1price"=>"Gift1 Price,int|0",
			"gift2"=>"Gift2,text|Magic Rope",
			"gift2price"=>"Gift2 Price,int|10",
			"gift3"=>"Gift3,text|Elven Cloak",
			"gift3price"=>"Gift3 Price,int|20",
			"gift4"=>"Gift4,text|Silverwood Bow",
			"gift4price"=>"Gift4 Price,int|40",
			"gift5"=>"Gift5,text|Gem Necklace",
			"gift5price"=>"Gift5 Price,int|60",
			"gift6"=>"Gift6,text|Star Necklace",
			"gift6price"=>"Gift6 Price,int|100",
			"gift7"=>"Gift7,text|Ring of Galadriel",
			"gift7price"=>"Gift7 Price,int|200",
			"gift8"=>"Gift8,text|Eternal Love Pendant",
			"gift8price"=>"Gift8 Price,int|500",
			"gift9"=>"Gift9,text|Elven Headdress",
			"gift9price"=>"Gift9 Price,int|1000",
			"gift10"=>"Gift10,text|Gem Bracelet",
			"gift10price"=>"Gift10 Price,int|1500",
			"gift11"=>"Gift11,text|Eternal Love Ear Rings",
			"gift11price"=>"Gift11 Price,int|2000",
			"gift12"=>"Gift12,text|Elven Love Ring",
			"gift12price"=>"Gift12 Price,int|3000",
		),
	);
	return $info;
}

function elvingiftshop_install(){
	if (!is_module_active('elvingiftshop')){
		output("`4Installing Gift Shop (3) Module.`n");
	}else{
		output("`4Updating Gift Shop (3) Module.`n");
	}
	module_addhook("village");
	return true;
}

function elvingiftshop_uninstall(){
	output("`4Un-Installing Gift Shop (3) Module.`n");
	return true;
}

function elvingiftshop_dohook($hookname,$args){
	global $session;
	switch($hookname){
		case "village":
			if ($session['user']['location'] == get_module_setting("gsloc")){
				tlschema($args['schemas']['marketnav']);
    			addnav($args['marketnav']);
    			tlschema();
				addnav(array("%s's Gift Shop",get_module_setting('gsowner')), "runmodule.php?module=elvingiftshop");
			}
		break;
	}
	return $args;
}

function elvingiftshop_run(){
global $session;
$op = httpget('op');
$gift=httpget('op2');
$price=httpget('price');
$name=httpget('name');
$whom=$_POST['whom'];
$whom = stripslashes(rawurldecode($whom));
        $newname="%";
        for ($x=0;$x<strlen($whom);$x++){
            $newname.=substr($whom,$x,1)."%";
        }
        $whom = addslashes($newname);
$mess=$_POST['mess'];
page_header(get_module_setting('gsowner')."'s Ol' Gifte Shoppe");
output("`c`b`&Ye Ol' Gifte Shoppe`0`b`c`n`n");
if ($op==""){
output("You walk into the gift shop and see many Elvish items for sale.`n");
output("%s is behind the counter, %s smiles politely at you.  You could have sworn you just saw him at the bank.`n",get_module_setting('gsowner'),get_module_setting('gsheshe'));
output("You see a sign on the wall that says \"Free Delivery and gift wrapping.\"`n");
output("This shop specializes in gifts for your %s, things you can afford...`n`n",get_module_setting('special'));
for ($i=1;$i<13;$i+=1){
	$currentgift = "gift".$i;
	$currentprice = "gift".$i."price";
	if ($session['user']['gold'] >= get_module_setting($currentprice)){
		$linkcode="<a href=\"runmodule.php?module=elvingiftshop&op=send&op2=".get_module_setting($currentgift)."&price=". get_module_setting($currentprice)."\"><span style=\"color: rgb(0, 204, 204);\">`3".get_module_setting($currentgift)." - ".get_module_setting($currentprice)." gold</span></a><br>";
		output("%s",$linkcode,true);
		addnav("","runmodule.php?module=elvingiftshop&op=send&op2=".get_module_setting($currentgift)."&price=". get_module_setting($currentprice));
	}
}
addnav("Back to Village","village.php");
}
if ($op == "send"){
	output("To whom would you like to send your gift to?`n");
		$linkcode="<form action='runmodule.php?module=elvingiftshop&op=send2&op2=$gift&price=$price' method='POST'>";
		output("%s",$linkcode,true);
		$linkcode="<p><input type=\"text\" name=\"whom\" size=\"37\"></p>";
		output("%s",$linkcode,true);
		$linkcode="<p><input type=\"submit\" value=\"Submit\" name=\"B1\"><input type=\"reset\" value=\"Reset\" name=\"B2\"></p>";
		output("%s",$linkcode,true);
		$linkcode="</form>";
		output("%s",$linkcode,true);
		addnav("","runmodule.php?module=elvingiftshop&op=send2&op2=$gift&price=$price");
		addnav("Go Back","runmodule.php?module=elvingiftshop");
}
if ($op=="send2"){
	$sql = "SELECT login,name,level,acctid FROM ".db_prefix("accounts")." WHERE name LIKE '%".$whom."%' and acctid <> '".$session['user']['acctid']."' ORDER BY level,login LIMIT 100";
	$result = db_query($sql);
		        if (db_num_rows($result) < 1) output("No on matching that name found.");
				output("Choose who to send your gift to:`n");
		        $linkcode="<table cellpadding='3' cellspacing='0' border='0'>";
				output("%s",$linkcode,true);
		        $linkcode="<tr class='trhead'><td>Name</td><td>Level</td></tr>";
				output("%s",$linkcode,true);
		          for ($i=0;$i<db_num_rows($result);$i++){
			      $row = db_fetch_assoc($result);
			      $linkcode="<tr class='".($i%2?"trlight":"trdark")."'><td><a href='runmodule.php?module=elvingiftshop&op=send3&op2=$gift&price=$price&name=".HTMLEntities($row['acctid'])."'>";
			      output("%s",$linkcode,true);
			      output_notl($row['name']);
			      $linkcode="</a></td><td>";
			      output("%s",$linkcode,true);
			      output_notl($row['level']);
			      $linkcode="</td></tr>";
			      output("%s",$linkcode,true);
			      addnav("","runmodule.php?module=elvingiftshop&op=send3&op2=$gift&price=$price&name=".HTMLEntities($row['acctid']));
		          }
		          $linkcode="</table>";
		          output("%s",$linkcode,true);
		          output("`n");
		          addnav("Go Back","runmodule.php?module=elvingiftshop");
}

if ($op=="send3"){
	if (strchr(strtolower($gift),"card")){
		output("Write a message in the Card.`n");
	}else{
		output("Fill in the Note Card that goes with the gift.`n");
	}
	output("Leave blank for no note.");
	$linkcode="<form action='runmodule.php?module=elvingiftshop&op=send4&op2=$gift&price=$price&name=$name' method='POST'>";
	output("%s",$linkcode,true);
	$linkcode="<p><input type=\"text\" name=\"mess\" size=\"37\"></p>";
	output("%s",$linkcode,true);
	$linkcode="<p><input type=\"submit\" value=\"Submit\" name=\"B1\"><input type=\"reset\" value=\"Reset\" name=\"B2\"></p>";
	output("%s",$linkcode,true);
	$linkcode="</form>";
	output("%s",$linkcode,true);
	addnav("","runmodule.php?module=elvingiftshop&op=send4&op2=$gift&price=$price&name=$name");
	addnav("Go Back","runmodule.php?module=elvingiftshop");
}

if ($op=="send4"){
	$session['user']['gold']-=$price;
	$mailmessage=$session['user']['name'];
	$mailmessage.="`7 has sent you a gift.  When you open it you see it is a `6";
	$mailmessage.=$gift;
	$mailmessage.="`7 from ".get_module_setting('gsowner')."'s Ye Old Gifte Shope.`n`n";
	if ($mess <> ""){
		if (strchr(strtolower($gift),"card")){
			$mailmessage.="Inside the card it says \"";
		}else{
			$mailmessage.="The attached note says \"";
		}
	$mailmessage.=$mess;
	$mailmessage.=".\"";
	}
	require_once("lib/systemmail.php");
	systemmail($name,"`2You have recieved a gift!`2",$mailmessage);
	output("You gift of a %s has been sent!",$gift);
	addnav("Continue","runmodule.php?module=elvingiftshop");
}
page_footer();
}
?>