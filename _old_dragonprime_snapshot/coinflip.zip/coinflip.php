<?php
// translator ready
// mail ready
// addnews ready
function coinflip_getmoduleinfo(){
	$info = array(
		"name"=>"Coin Flip",
		"version"=>"1.0",
		"author"=>"Jeffrey Riddle",
		"category"=>"Forest Specials",
		"download"=>"",
		"settings"=>array(
			"Coin Flip Settings,title",
			"coinflipchance"=>"Chance the player will be right,range,1,100,1|50",
			"goldbetamount"=>"How much the player must wager to play,range,250,10000,250|5000"
		),
	);
	return $info;
}

function coinflip_install(){
	module_addeventhook("forest", "return 100;");
	return true;
}

function coinflip_uninstall(){
	return true;
}

function coinflip_dohook($hookname,$args){
	return $args;
}

function coinflip_runevent($type)
{
	global $session;
	$from = "forest.php?";
	$session['user']['specialinc'] = "module:coinflip";
	$op = httpget('op');
    $coinflipchance = get_module_setting("coinflipchance");
	$goldbet = get_module_setting("goldbetamount");
	$roll = e_rand(1, 100);
	
	if ($op=="" || $op=="search") {
		output("`2As you wander the forest, you find a litle dwarf. You wonder why he would be out here, so you approach him.");
		output("`2Before you can speak, the dwarf says,`^ I bet you're wondering why I am here...Well, I want to play a little game...");
		output("`2He continues, `^It is a game of chance, a coin flip actually. If it is heads, you win, but if not, I do! It is only a trifle...$goldbet gold!");
	addnav("Want to Play?");
	addnav("Yes", $from . "op=playcoinflip");
	addnav("No", $from . "op=noplaycoinflip");
		}
	if ($op=="playcoinflip" and $roll <= $coinflipchance) {
		output("`2You nod and place the $goldbet gold down on the stump.");
		output("`2The dwarf takes out a coin and flip it in the air. It lands on the stump and the dwarf looks at it.");
		output("`!`c`bThe coin lands on heads!`b`c");
		output("`^Well, I guess you won. Here, take your $goldbet gold. You won't be so lucky next time.");
		$session['user']['gold']+=$goldbet;
		}
	if ($op=="playcoinflip" and $roll > $coinflipchance) {
		output("`2You nod and place the $goldbet gold down on the stump.");
		output("`2The dwarf takes out a coin and flip it in the air. It lands on the stump and the dwarf looks at it.");
		output("`$`c`bThe coin lands on tails!`b`c");
		output("`^Haha, it appears that I've won!");
		output("`^I'll take my $goldbet gold now...");
		$session['user']['gold']-=$goldbet;	 
		}
   if ($op=="noplaycoinflip") {
       output("`^Well I guess you are kinda scared...I guess I can play someone else...");
	   }
	   }
function coinflip_run(){
}
?>