<? 
require_once "common.php"; 
checkday(); 
$polecost=round($session[user][level]*(($session[user][dragonkills]+1)*1/3)*90);
$poleone=$polecost*1/6;
$poletwo=$polecost*1/3;
$polethree=$polecost*2/3;
$polefour=$polecost;
$baitcost=round($session[user][level]*(($session[user][dragonkills]+1)*1/3)*30);
$baitone=$baitcost*1/6;
$baittwo=$baitcost*1/3;
$baitthree=$baitcost*2/3;
$baitfour=$baitcost;
$session[user][place]="Lake Ketcheefishee";
if ($HTTP_GET_VARS[op]==""){
	page_header("Lake Ketcheefishee"); 
	$session[user][place]="Lake Ketcheefishee";
	output("You walk up to a pond and look around. In front of the pond is"); 
	output("a sign: Toddsbury Fishing Pond. Over to the left is a fishing shop,"); 
	output("over to your right there is a boat rental, and by the sign is a pier."); 
	output("You sand there pondering what you should do."); 
	addnav("Do Somthing"); 
	addnav("S?Fishing Shop","fishingpond.php?op=shop"); 
	addnav("B?Boat Rental","fishingpond.php?op=boatstore");
	addnav("F?Go Fishing","fishingpond.php?op=gofishing");
	addnav("R?Return to Toddsdbury","village.php");
}
if ($HTTP_GET_VARS[op]=="shop"){
	$session[user][place]="Fishing Shop";
	page_header("Fishing Shop"); 
	output("`@You enter the fishing shop and see a lot a different kinds of bait ");
	output("and some fishinging poles. people are buisy looking for supleys for ");
	output("there fishing trips. A young man comes up to you and say 'Hello ");
	output("".$session[user][name]." `@and welcome to my shop we have many ");
	output("fine poles you can fish with and quite a few kinds of bait. So what ");
	output("would you like?'");
	addnav("Rent a Fishing Pole","fishingpond.php?op=pole");
	addnav("Buy Some Bait","fishingpond.php?op=bait");
	addnav("Return to Lake Ketcheefishee","fishingpond.php");
} 

if ($HTTP_GET_VARS[op]=="boatstore"){
	$session[user][place]="Fishing Boat Rental";
	page_header("Boat Rental"); 
	output("An old man in worn out clothes comes up to you and says 'I have a ");
	output("boat you can rent if you want, it will increse the chance of you chatching ");
	output("somthing and my family could realy use some money. I'll let you use it for");
	output("100 gold. thats the least I can give it to you for'");
	addnav("Return to Lake Ketcheefishee","fishingpond.php");
	addnav("Rent a Boat","fishingpond.php?op=rentboat");
	addnav("Give the Man 250 to Rent a Boat","fishingpond.php?op=bigrent");
	addnav("Just Give the Old Guy Some Gold","fishingpond.php?op=givemangold");
}

if ($HTTP_GET_VARS[op]=="pole"){
	$session[user][place]="Fishing Shop";
	page_header("Fishing Shop"); 
	output("What pole should you rent");
	addnav("Bamboo Fishing Pole ".$poleone." gold","fishingpond.php?op=bamboopole");
	addnav("Small Fishing Pole ".$poletwo." gold","fishingpond.php?op=smallpole");
	addnav("Medium Fishing Pole ".$polethree." gold","fishingpond.php?op=medpole");
	addnav("Large Fishing Pole ".$polefour." gold","fishingpond.php?op=bigpole");
	addnav("Return to the Shop","fishingpond.php?op=shop");
}
if ($HTTP_GET_VARS[op]=="bait"){
	$session[user][place]="Fishing Shop";
	page_header("Fishing Shop"); 
	output("What bait should you buy");
	addnav("Cheese - ".$baitone." gold","fishingpond.php?op=cheesebait");
	addnav("Rubber Worms - ".$baittwo." gold","fishingpond.php?op=rubberwormbait");
	addnav("Live Worms - ".$baitthree." gold","fishingpond.php?op=livewormbait");
	addnav("Nightcrawlers - ".$baitfour." gold","fishingpond.php?op=nightcrawlers");
	addnav("Return to the Shop","fishingpond.php?op=shop");
}

//Start Of The Fishing Pole Code
if ($HTTP_GET_VARS[op]=="bamboopole"){
	$session[user][place]="Fishing Shop";
	page_header("Fishing Shop"); 
	if ($session[user][gold]>=$poleone && $session[user][pole]<=0){
		output("Ahh so your going to use a cheapos pole. Well good luck, you'll need it. you need to bring the pole back tomorow");
		$session[user][pole]=1;
		$session[user][gold]-=$poleone;
		addnav("Return to the Shop","fishingpond.php?op=shop");
		addnav("Return to Lake Ketcheefishee","fishingpond.php");
	}else if($session[user][pole]>=1){
		output("You allready have some a pole, go use that");
		addnav("Return to the Shop","fishingpond.php?op=shop");
		addnav("Return to Lake Ketcheefishee","fishingpond.php");
	}else{
		output("You don't have enough gold to rent that pole, go get some more gold");
		addnav("Return to the Shop","fishingpond.php?op=shop");
		addnav("Return to Lake Ketcheefishee","fishingpond.php");
	}
}
if ($HTTP_GET_VARS[op]=="smallpole"){
	$session[user][place]="Fishing Shop";
	page_header("Fishing Shop"); 
	if ($session[user][gold]>=$poletwo && $session[user][pole]<=0){
		output("Ahh so your going to use a kiddies pole. Well good luck, you might need it. you need to bring the pole back tomorow");
		$session[user][pole]=2;
		$session[user][gold]-=$poletwo;
		addnav("Return to the Shop","fishingpond.php?op=shop");
		addnav("Return to Lake Ketcheefishee","fishingpond.php");
	}else if($session[user][pole]>=1){
		output("You allready have some a pole, go use that");
		addnav("Return to the Shop","fishingpond.php?op=shop");
		addnav("Return to Lake Ketcheefishee","fishingpond.php");
	}else{
		output("You don't have enough gold to rent that pole, go get some more gold");
		addnav("Return to the Shop","fishingpond.php?op=shop");
		addnav("Return to Lake Ketcheefishee","fishingpond.php");
	}
}

if ($HTTP_GET_VARS[op]=="medpole"){
	$session[user][place]="Fishing Shop";
	page_header("Fishing Shop"); 
	if ($session[user][gold]>=$polethree && $session[user][pole]<=0){
		output("Ahh so your going to use a pros pole. Well good luck, and I'm sure you'll have it. you need to bring the pole back tomorow");
		$session[user][pole]=3;
		$session[user][gold]-=$polethree;
		addnav("Return to the Shop","fishingpond.php?op=shop");
		addnav("Return to Lake Ketcheefishee","fishingpond.php");
	}else if($session[user][pole]>=1){
		output("You allready have some a pole, go use that");
		addnav("Return to the Shop","fishingpond.php?op=shop");
		addnav("Return to Lake Ketcheefishee","fishingpond.php");
	}else{
		output("You don't have enough gold to rent that pole, go get some more gold");
		addnav("Return to the Shop","fishingpond.php?op=shop");
		addnav("Return to Lake Ketcheefishee","fishingpond.php");
	}
}

if ($HTTP_GET_VARS[op]=="bigpole"){
	$session[user][place]="Fishing Shop";
	page_header("Fishing Shop"); 
	if ($session[user][gold]>=$polefour && $session[user][pole]<=0){
		output("Ahh so your going to use a pros pole. Well good luck, and I'm sure you'll have it. you need to bring the pole back tomorow");
		$session[user][pole]=4;
		$session[user][gold]-=$polefour;
		addnav("Return to the Shop","fishingpond.php?op=shop");
		addnav("Return to Lake Ketcheefishee","fishingpond.php");
	}else if($session[user][pole]>=1){
		output("You allready have some a pole, go use that");
		addnav("Return to the Shop","fishingpond.php?op=shop");
		addnav("Return to Lake Ketcheefishee","fishingpond.php");
	}else{
		output("You don't have enough gold to rent that pole, go get some more gold");
		addnav("Return to the Shop","fishingpond.php?op=shop");
		addnav("Return to Lake Ketcheefishee","fishingpond.php");
	}
}


//End Of The Fishing Pole Code


//Start Of The Fishing Bait Code
if ($HTTP_GET_VARS[op]=="cheesebait"){
	$session[user][place]="Fishing Shop";
	page_header("Fishing Shop"); 
	if ($session[user][gold]>=$baitone && $session[user][baitamount]<=0){
		output("Ahh so your going to use a cheapos bait. Well good luck, you'll need it. That bait will last ten turns");
		$session[user][bait]=1;
		$session[user][baitamount]=10;
		$session[user][gold]-=$baitone;
		addnav("Return to the Shop","fishingpond.php?op=shop");
		addnav("Return to the Pond","fishingpond.php");
	}else if($session[user][baitamount]>=1){
		output("You allready have some bait, go use that before you buy some more");
		addnav("Return to the Shop","fishingpond.php?op=shop");
		addnav("Return to Lake Ketcheefishee","fishingpond.php");
	}else{
		output("You don't have enough gold to buy that bait, go get some more gold");
		addnav("Return to the Shop","fishingpond.php?op=shop");
		addnav("Return to Lake Ketcheefishee","fishingpond.php");
	}
}

if ($HTTP_GET_VARS[op]=="rubberworm"){
	$session[user][place]="Fishing Shop";
	page_header("Fishing Shop"); 
	if($session[user][gold]>=$baittwo && $session[user][baitamount]<=0){
		output("Ahh so your going to use a rubber worms. Well good luck, you might need it. That bait will last ten turns");
		$session[user][bait]=2;
		$session[user][baitamount]=10;
		$session[user][gold]-=$baittwo;
		addnav("Return to the Shop","fishingpond.php?op=shop");
		addnav("Return to Lake Ketcheefishee","fishingpond.php");
	}else if($session[user][baitamount]>=1){
		output("You allready have some bait, go use that before you buy some more");
		addnav("Return to the Shop","fishingpond.php?op=shop");
		addnav("Return to Lake Ketcheefishee","fishingpond.php");
	}else{
		output("You don't have enough gold to buy that bait, go get some more gold");
		addnav("Return to the Shop","fishingpond.php?op=shop");
		addnav("Return to Lake Ketcheefishee","fishingpond.php");
	}
}

if ($HTTP_GET_VARS[op]=="livewormbait"){
	$session[user][place]="Fishing Shop";
	page_header("Fishing Shop"); 
	if($session[user][gold]>=$baitthree && $session[user][baitamount]<=0){
		output("Ahh so your going to use live worms. Well good luck, you might get it with those. That bait will last ten turns");
		$session[user][bait]=3;
		$session[user][baitamount]=10;
		$session[user][gold]-=$baitthree;
		addnav("Return to the Shop","fishingpond.php?op=shop");
		addnav("Return to Lake Ketcheefishee","fishingpond.php");
	}else if($session[user][baitamount]>=1){
		output("You allready have some bait, go use that before you buy some more");
		addnav("Return to the Shop","fishingpond.php?op=shop");
		addnav("Return to Lake Ketcheefishee","fishingpond.php");
	}else{
		output("You don't have enough gold to buy that bait, go get some more gold");
		addnav("Return to the Shop","fishingpond.php?op=shop");
		addnav("Return to Lake Ketcheefishee","fishingpond.php");
	}
}

if ($HTTP_GET_VARS[op]=="nightcrawlers"){
	$session[user][place]="Fishing Shop";
	page_header("Fishing Shop"); 
	if($session[user][gold]>=$baitfour && $session[user][baitamount]<=0){
		output("Ahh so your going to use a nightcrawlers. Well good luck, and I'm sure you'll have it. That bait will last ten turns");
		$session[user][bait]=4;
		$session[user][baitamount]=10;
		$session[user][gold]-=$baitfour;
		addnav("Return to the Shop","fishingpond.php?op=shop");
		addnav("Return to Lake Ketcheefishee","fishingpond.php");
	}else if($session[user][baitamount]>=1){
		output("You allready have some bait, go use that before you buy some more");
		addnav("Return to the Shop","fishingpond.php?op=shop");
		addnav("Return to Lake Ketcheefishee","fishingpond.php");
	}else{
		output("You don't have enough gold to buy that bait, go get some more gold");
		addnav("Return to the Shop","fishingpond.php?op=shop");
		addnav("Return to Lake Ketcheefishee","fishingpond.php");
	}
}

//End Of The Fishing Bait Code


//Start Of The Boat Renting Code
if ($HTTP_GET_VARS[op]=="rentboat"){
	$session[user][place]="Fishing Boat Rental";
	page_header("Boat Rental"); 
	if ($session[user][gold]>=100){
		output("You look over the boat and see it's pretty good and it's a ");
		output("cheap price so you deside to rent it. When you tell the man ");
		output("your going to rent it he looks happy and tells you, you can ");
		output("use it for ten turns");
		$session[user][gold]-=100;
		$session[user][boat]=10;
		addnav("Return to Lake Ketcheefishee","fishingpond.php");
	}else{
		output("you diside to rent the boat but when you look in you pouch ");
		output("and see you don't have enough gold, you tell him that and ask ");
		output("if he'll go any lower. he says since you don't have any gold ");
		output("he'll let you use it for free");
		addnav("Accept","fishingpond.php?op=cheapboat");
		addnav("Let Him Rent it to Another Person","fishingpond.php");
	}
}
if ($HTTP_GET_VARS[op]=="bigrent"){
	$session[user][place]="Fishing Boat Rental";
	page_header("Boat Rental"); 
	if ($session[user][gold]>=250){
		output("You feel sorry for the old man and tell him you'll give him ");
		output("250 gold to rent the boat. he looks very happy and tells ");
		output("you, you can use the boat for twenty turns");
		$session[user][boat]=20;
		addnav("Return to Lake Ketcheefishee","fishingpond.php");
	}else{
		output("you start to tell him you'll give him 250 gold but realize you ");
		output("only have ".$session[user][gold]." gold in your pouch.");
		addnav("Rent a Boat","fishingpond.php?op=rentboat");
		addnav("Give the Man 250 to Rent a Boat","fishingpond?op=bigrent");
		addnav("Just Give the Old Guy 500 Gold","fishingpond.php?op=givemangold");
		addnav("Return to Lake Ketcheefishee","fishingpond.php");
	}
}
if ($HTTP_GET_VARS[op]=="givemangold"){
	$session[user][place]="Fishing Boat Rental";
	page_header("Boat Rental"); 
	if ($session[user][gold]>=500){
		output("You give the old man 500 gold and he starts jumping ");
		output("for joy. Then ");
		if (e_rand(1,2)==1){
			if (e_rand(1,2)==1){
				output("he starts telling you his life story and how he became ");
				output("poor and you loose a turn listening to him talk for a while");
				output(". Right before you leave he says here take this rock ");
				output("I found in my yard, it's not much but I wan't to give you ");
				output("something for you listening to me. Not caring about it ");
				output("much you take it and later clean it off and see it is a gem!");
				$session[user][turns]--;
				$session[user][gems]++;
				addnav("Return to Lake Ketcheefishee","fishingpond.php");
			}else{
				output("as he is jumping up and down you see a gem ");
				output("on the ground. You try to give them to him but he is to ");
				output("buisy jumping so you keep it");
				$session[user][gems]+=$reward;
				addnav("Return to Lake Ketcheefishee","fishingpond.php");
			}
		}else{
			output(" after a while you get tired of seeing how hight he");
			output(" he can jump so you head back to the pond.");
			addnav("Return to Lake Ketcheefishee","fishingpond.php");
		}			
	}else{
		output("You are just about to tell him you'll give him 500 ");
		output("gold then remember you only have ".$session[user][gold]." ");
		output("gold and turn red from emberesment.");
		addnav("Return to Lake Ketcheefishee","fishingpond.php");
	}
}
if ($HTTP_GET_VARS[op]=="cheapboat"){
	$session[user][place]="Fishing Boat Rental";
	page_header("Boat Rental"); 
	if ($session[user][goldinbank]+$session[user][gold]<=50){
		output("you accept the offer and tell him how glad ");
		output("you are to be able to use his boat. he tells");
		output("you that you are poorer than him and you ");
		output("can use the boat for 10 turns");
		addnav("Return to Lake Ketcheefishee","fishingpond.php");
	}else{
		output("You accept the offer trying to pretend you're ");
		output("poor when someone passing by says oh hi ");
		output("".$session[user][name]." I hear you've been ");
		output("getting a lot a gold in the forest lately. When ");
		output("the old man hears this he gets angry and takes ");
		output("any of your gold and tells you you can not use his ");
		addnav("Return to Lake Ketcheefishee","fishingpond.php");
		$session[user][gold]=0;
		$session[user][boat]=1000;
	}
}
//End Of The Boat Renting Code
if ($HTTP_GET_VARS[op]=="gofishing"){
	page_header("Fishing Pond"); 
	if ($session[user][pole]>0){
		if ($session[user][baitamount]>0){
			if ($session[user][boat]>0 && $session[user][boat]!==1000){
				output("you get in your rental boat and drive to the middle ");
				output("of the lake bait your hook and look for something ");
				output("swimming in the water to try to catch.");
				addnav("Return to the Shore","fishingpond.php");
				addnav("Cast Your Line","fishingpond.php?op=cast1");
			}else{
				output("You walk to the end of the pier and bait your hook ");
				output("and look in the water for something to try to catch");
				addnav("Return to the Shore","fishingpond.php");
				addnav("Cast Your Line","fishingpond.php?op=cast2");
			}
		}else{
			output("You walk to the end of the pier full of pride but ");
			output("because you don't have any bait everone gives ");
			output("you strange looks, by the time you get to the end");
			output("all your pride is gone. So you try to ignore it by ");
			output("looking in to the water for fish, which makes the ");
			output("people give you even stanger looks, after all you ");
			output("can catch fish by looking at them. So you get ");
			output("ready to cast your baitless hook in to the water ");
			output("and hope you catch something");
			addnav("Return to the Shore","fishingpond.php");
			addnav("Cast Your Line","fishingpond.php?op=cast3");
		}
	}else{
		output("`!You start to walk down the pier when some people ");	
		output("yell, \"`4Hey you, what do you think your doing? You ");
		output("can't come one here without any fishing equipment!`!\" ");
		output("So you deside if you can't go on the pier you'll just try ");
		output("at the bank. As you walk up to the the bank you here ");
		output("people laughing at you from the pier, you try to ignore ");
		output("them as you consentrate at trying to catch the fish ");
		output("swimming at the shore");
		addnav("Return to the Shore","fishingpond.php");
		addnav("Dunk Your Hands","fishingpond.php?op=cast4");
	}
}



//The Start Of The Casting And Catching Code
if ($HTTP_GET_VARS[op]=="cast1"){
	page_header("Fishing Pond"); 
	if ($session[user][turns]>0){
		if ($session[user][baitamount]>0){
			if ($session[user][boat]>0){
				$catchmax=($session[user][bait]*2)*3;
				$catchmin=$session[user][bait]*3;
				$breakmax=($session[user][pole]+4)*4;
				$breakmin=($session[user][pole]+3)*2;
				$break=e_rand($breakmin,$breakmax);
				$catch=e_rand($catchmin,$catchmax);
				if ($break<$catch){
					$brokenline=1;
				}else{
					$brokenline=0;
					$food=$catch*1/5;
					$gold=$catch*2;
					if ($food<1) $food=1;
				}
				if ($catch>=0){
					if ($catch>=8){
						if ($catch>=16){
							if ($catch>=24){
								$fish="Large Mouth Bass";
							}else{
								$fish="Small Mouth Bass";
							}
						}else{
							$fish="Blue Gill";
						}
					}else{
						$fish="Minnow";
					}
				}
				output("`!You cast your line into the water and ");
				output(" a ".$fish." bites your line ");
				if ($brokenline==1){
					output("but it was to big and broke your line.");
					$session[user][turns]--;
					$session[user][baitamount]--;
					$session[user][boat]--;
					addnav("Cast Again","fishingpond.php?op=cast1");
					addnav("Return to the Shore","fishingpond.php");
				}else{
					output("and you quickly reel it in.`n");
					output("`^You gain ".$food." rations and ");
					output("you find ".$gold." in it's mouth");
					$session[user][turns]--;
					$session[user][baitamount]--;
					$session[user][boat]--;
					$session[user][hungry]+=$food;
					$session[user][gold]+=$gold;
					addnav("Cast Again","fishingpond.php?op=cast1");
					addnav("Return to the Shore","fishingpond.php");
				}
			}else{
				output("you realize you need to take you boat ");
				output("so you head to shore and give your boat ");
				output("back");
				addnav("Return to the Shore","fishingpond.php");
			}
		}else{
			output("you don't have any more bait so ");
			output("you head back to the shore");
			$session[user][bait]=0;
			addnav("Return to the Shore","fishingpond.php");
		}
	}else{
		output("You're to tired to go fishing anymore today");
		output("come back tomorow");
		addnav("Return to the Shore","fishingpond.php");
	}
}
if ($HTTP_GET_VARS[op]=="cast2"){
	page_header("Fishing Pond"); 
	if ($session[user][turns]>0){
		if ($session[user][baitamount]>0){
			$catchmax=($session[user][bait]*4);
			$catchmin=$session[user][bait]*2;
			$strengthmax=($session[user][pole]+4)*4;
			$strengthmin=($session[user][pole]+3)*2;
			$break=e_rand($strengthmin,$strengthmax);
			$catch=e_rand($catchmin,$catchmax);
			if ($strength<$catch){
				$brokenline=1;
			}else{
				$brokenline=0;
				$food=round($catch*1/5);
				$gold=$catch*2;
				if ($food<1) $food=1;
			}
			if ($catch>=0){
				if ($catch>=8){
					if ($catch>=16){
						if ($catch>=24){
							$fish="Large Mouth Bass";
						}else{
							$fish="Small Mouth Bass";
						}
					}else{
						$fish="Blue Gill";
					}
				}else{
					$fish="Minnow";
				}
			}
			output("`!You cast your line into the water and ");
			output(" a ".$fish." bites your line ");
			if ($brokenline==1){
				output("but it was to big and broke your line.");
				$session[user][turns]--;
				$session[user][baitamount]--;
				addnav("Cast Again","fishingpond.php?op=cast2");
				addnav("Return to the Shore","fishingpond.php");
			}else{
				output("and you quickly reel it in.`n");
				output("`^You gain ".$food." rations and ");
				output("you find ".$gold." in it's mouth");
				$session[user][turns]--;
				$session[user][baitamount]--;
				$session[user][hungry]+=$food;
				$session[user][gold]+=$gold;
				addnav("Cast Again","fishingpond.php?op=cast2");
				addnav("Return to the Shore","fishingpond.php");
			}
		}else{
			output("you don't have any more bait so ");
			output("you head back to the shore");
			$session[user][bait]=0;
			addnav("Return to the Shore","fishingpond.php");
		}
	}else{
		output("You're to tired to go fishing anymore today");
		output("come back tomorow");
		addnav("Return to the Shore","fishingpond.php");
	}
}
	
if ($HTTP_GET_VARS[op]=="cast3"){
	page_header("Fishing Pond"); 
	if ($session[user][turns]>0){
		$catchmax=6;
		$catchmin=3;
		$breakmax=($session[user][pole]+3)*2;
		$breakmin=($session[user][pole]+4);
		$break=e_rand($breakmin,$breakmax);
		$catch=e_rand($catchmin,$catchmax);
		if ($break<$catch){
			$brokenline=1;
		}else{
			$brokenline=0;
			$food=$catch*1/5;
			$gold=$catch*2;
			if ($food<1) $food=1;
		}
		if ($catch>=0){
			if ($catch>=8){
				if ($catch>=16){
					if ($catch>=24){
						$fish="Large Mouth Bass";
					}else{
						$fish="Small Mouth Bass";
					}
				}else{
					$fish="Blue Gill";
				}
			}else{
				$fish="Minnow";
			}
		}
		output("`!You cast your line into the water and ");
		output(" a ".$fish." bites your line ");
		if ($brokenline==1){
			output("but it was to big and broke your line.");
			$session[user][turns]--;
			addnav("Cast Again","fishingpond.php?op=cast3");
			addnav("Return to the Shore","fishingpond.php");
		}else{
			output("and you quickly reel it in.`n");
			output("`^You gain ".$food." rations and ");
			output("you find ".$gold." in it's mouth");
			$session[user][turns]--;
			$session[user][hungry]+=$food;
			$session[user][gold]+=$gold;
			addnav("Cast Again","fishingpond.php?op=cast3");
			addnav("Return to the Shore","fishingpond.php");
		}
	}else{
		output("You're to tired to go fishing anymore today");
		output("come back tomorow");
		addnav("Return to the Shore","fishingpond.php");
	}
}
if ($HTTP_GET_VARS[op]=="cast4"){
	page_header("Fishing Pond"); 
	if ($session[user][turns]>4){
		$catch=(e_rand(3,6));
		$turns=(e_rand(2,4));
		$food=round($catch*1/3);
		if ($catch=6){
			$fish=minnow;
		}else{
			$fish=tadpole;
		}
		output("You swope your hands in to the water ");
		output("but the fish scatter two much you try a ");
		output("few times before you finaly catch a ".$fish." ");
		output("that gives you ".$food." food but use ".$turns." ");
		output("turns.");
		$session[user][turns]-=$turns;
		$session[user][hungry]+=$food;
		addnav("Try Again","fishingpond.php?op=cast4");
		addnav("Return to the Shore","fishingpond.php");
	}else{
		output("your to tired to try to catch any more ");
		output("fish today, come back tomorow");
		addnav("Return to the Shore","fishingpond.php");
	}
}
page_footer(); 
?>