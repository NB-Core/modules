<?php

function election_getmoduleinfo(){
	$info = array(
		"name"=>"Election System",
		"version"=>"2.0",
		"author"=>"Sneakabout - modifications/enhancements `3Lonny Luberts",
		"category"=>"General",
		"download"=>"http://www.pqcomp.com/modules/mydownloads/visit.php?cid=3&lid=19",
		"vertxtloc"=>"http://www.pqcomp.com/",
		"settings"=>array(
			"Election System Settings,title",
			"electionregister"=>"Is election registration active?,bool|0",
			"electionon"=>"Is an election on?,bool|0",
			"electioncandidates"=>"Who are the candidates?,viewonly",
			"importantnumber"=>"This number is important.,viewonly",
			"electionvotes"=>"Who has what votes?,viewonly",
			"registrationcost"=>"How much does registering cost?,int|10",
			"votescast"=>"How many votes have been cast?,int|0",
			"charmlimit"=>"How much charm do you have to have to stand?,int|30",
			"machinename"=>"What are the voting machines called?|Bravedeath",
			"leadername"=>"What is the winner's name?,",
			"leaderacctid"=>"What is the winner's account id?,",
			"peruseraccess"=>"Set Grotto Access per user?,bool|1",
		),
		"prefs"=>array(
            "havevoted"=>"Has this player voted?,bool|0",
            "haveregistered"=>"Has this player registered as a candidate?,bool|0",
            "superuser"=>"Superuser Access?,bool|0",
            "postermess"=>"Campagn Poster Message,text|",
            "bannermess"=>"Banner Message,text|",
            "bannercount"=>"Banner Displays Left,int|0",
        ),
        "requires"=>array(
	       "townfinance"=>"1.0|By Sneakabout, available on DragonPrime",
		),
	);
	return $info;
}

function election_install(){
	module_addhook("footer-runmodule");
	module_addhook("newday");
	module_addhook("superuser");
	module_addhook("village");
	module_addhook("everyhit");
	return true;
}

function election_uninstall(){
	return true;
}

function election_dohook($hookname,$args){
	global $session;
	$electionregister=get_module_setting("electionregister");
	$electionon=get_module_setting("electionon");
	$havevoted=get_module_pref("havevoted");
	$haveregistered=get_module_pref("haveregistered");
	switch ($hookname) {
	case "footer-runmodule":
		$op=httpget("op");
		$module=httpget("module");
		if (($module=="townfinance")&&($op=="enter")) {
			if (($electionregister==1)&&($haveregistered==0)) {
				output("`n`n`QS`qneakabout`% is taking names for who is standing to be elected!");
				addnav("Talk to `QS`qneakabout","runmodule.php?module=election&op=register");
			} elseif (($electionon==1)&&($havevoted==0)) {
				output("`n`n`@An election is on! Warriors are queueing up to vote to one side of the room!");
				addnav("Talk to the Registrar","runmodule.php?module=election&op=vote");
			} elseif (($electionon==1)&&($havevoted==1)) {
				output("`n`n`@An election is on! Warriors are queueing up to vote to one side of the room!");
				output("`n`3So far %s votes have been cast.",get_module_setting('votescast'));
			}
			//show stats
			if ($electionon == 1){
				$electionvotes=get_module_setting("electionvotes");
				$electionvotes=unserialize($electionvotes);
				$electioncandidates=get_module_setting("electioncandidates");
				$electioncandidates=unserialize($electioncandidates);
				output("`n`n`!Current Results.`n");
				$totalvote = 0;
				for ($i=1;$i<count($electioncandidates)+1;$i+=1){
					if (!$electionvotes[$i]) $electionvotes[$i]=0;
					output("%s - %s votes`n",$electioncandidates[$i]['name'],$electionvotes[$i]);
					$totalvote = $totalvote + $electionvotes[$i];
				}
				$badvote = get_module_setting('votescast') - $totalvote;
				output("`2Illegible Ballots - %s`n",$badvote);
			}elseif ($electionregister == 1){
				$electioncandidates=get_module_setting("electioncandidates");
				$electioncandidates=unserialize($electioncandidates);
				output("`n`n`!Registered Candidates.`n");
				for ($i=1;$i<count($electioncandidates)+1;$i+=1){
					output("%s`n",$electioncandidates[$i]['name']);
				}
			}
			if ($haveregistered){
				addnav("Campagn Office","runmodule.php?module=election&op=campagn");
			}
		}
		break;
	case "newday":
		//can't clear haveregistered here any longer - messes up campagn
		//if ((!get_module_setting("electionregister"))&&(get_module_pref("haveregistered"))) set_module_pref("haveregistered",0);
		if ((!$electionon)&&($havevoted)) set_module_pref("havevoted",0);
		if (($electionregister)&&(!$haveregistered)) {
			output("`n`QS`qneakabout`% is taking names for the upcoming election! If you want to stand, you had best act now!`0`n");
		} elseif (($electionon)&&(!$havevoted)) {
			output("`n`@An election is on! Get your vote in now, or the dragon wins!`0`n");
		}else{
			 if ($haveregistered == 1 AND $electionon == 0 AND $electionregister == 0 ) set_module_pref("haveregistered",0);
		}
		break;
	case "superuser":
		if (get_module_pref('superuser') == 1 or get_module_setting('peruseraccess') == 0){
			if ($electionon==1) {
				addnav("Finish the Election","runmodule.php?module=election&op=finish");
			} elseif ($electionregister==1) {
				addnav("Start Election Voting","runmodule.php?module=election&op=votestart");
			} else {
				addnav("Start Election Registration","runmodule.php?module=election&op=registerstart");
			}
		}
		break;
	case "village":
		if ($electionregister == 1){
			rawoutput("<big>");
			output("`4`b`cRegistration for the Upcoming Mayoral Election is Being Held at City Hall!`b`c");
			rawoutput("</big>");
		}elseif ($electionon == 1){
			rawoutput("<big>");
			output("`4`b`cVoting for the Mayoral Election is Being Held at City Hall!`b`c");
			rawoutput("</big>");
		}
		//display campagn posters
		if ($electionregister == 1 or $electionon == 1){
			$sql = "SELECT value FROM ".db_prefix("module_userprefs")." WHERE modulename = 'election' AND setting = 'postermess' AND value <> ''";
			$result = db_query($sql);
			output("`n`c`bYou see Election Posters Plastered About the Village`b`c");
			for ($i=0;$i<db_num_rows($result);$i+=1){
				$row = db_fetch_assoc($result);
				rawoutput("<div align=\"center\"><table border=\"1\" cellpadding=\"0\" cellspacing=\"0\" width=\200\" bordercolor=\"#000000\"><tr><td width=\"90%\">");
				rawoutput("<center>");
				output("%s",$row['value']);
				rawoutput("</center></td></tr></table></div><br>");
			}
		}
		break;
	case "everyhit":
			//display banners... cycle through purchased banners
			if ($electionregister == 1 or $electionon == 1){
			$sql = "SELECT value,userid FROM ".db_prefix("module_userprefs")." WHERE modulename = 'election' AND setting = 'bannermess' AND value <> '' ORDER BY RAND(".e_rand().")";
			$result = db_query($sql);
			$row = db_fetch_assoc($result);
				if ($row['value']){
					rawoutput("<div align=\"center\"><table border=\"1\" cellpadding=\"0\" cellspacing=\"0\" width=\"468\" bordercolor=\"#0000FF\" height=\"60\" bgcolor=\"#FFFFFF\"><tr><td>");
					rawoutput("<center>");
					output("`b %s`b",$row['value']);
					rawoutput("</center></td></tr></table></div><br>");
					db_query("UPDATE ".db_prefix("module_userprefs")." SET value = value - 1 WHERE modulename = 'election' AND setting = 'bannercount' AND userid = '".$row['userid']."'");
					$sql2 = "SELECT value FROM ".db_prefix("module_userprefs")." WHERE modulename = 'election' AND setting = 'bannercount' AND userid = '".$row['userid']."'";
					$result2 = db_query($sql2);
					$row2 = db_fetch_assoc($result2);
					if ($row2['value'] < 1){
						db_query("UPDATE ".db_prefix("module_userprefs")." SET value = '' WHERE modulename = 'election' AND setting = 'bannermess' AND userid = '".$row['userid']."'");
					}
				}
			}
		break;
	}
	return $args;
}

function election_runevent($type) {
}

function election_run(){
	global $SCRIPT_NAME;
	if ($SCRIPT_NAME == "runmodule.php"){
		$module=httpget("module");
		if ($module == "election") include("modules/lib/election.php");
	}
}
?>