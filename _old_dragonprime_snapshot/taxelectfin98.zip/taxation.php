<?php

function taxation_getmoduleinfo(){
	$info = array(
		"name"=>"Taxation System",
		"version"=>"2.0",
		"author"=>"Sneakabout",
		"category"=>"General",
		"download"=>"http://www.pqcomp.com/modules/mydownloads/visit.php?cid=3&lid=19",
		"vertxtloc"=>"http://www.pqcomp.com/",
		"settings"=>array(
			"Taxation System Settings,title",
			"taxon"=>"Is the tax active?,bool|0",
			"taxfree"=>"How much do you get tax-free?,int|5000",
			"lowrate"=>"What is the low rate (percentage)?,range,0,100,1|15",
			"highrate"=>"What is the high rate (percentage)?,range,0,100,1|30",
			"highlow"=>"What is the top limit for the low rate?,int|10000",
			"redistribution"=>"Is there an upper gold limit?,bool|0",
			"highestgold"=>"What is the gold limit?,int|25000",
			"taxman"=>"Is the taxman in the forest active?,bool|0",
			"rebate"=>"Is there a rebate?,bool|0",
		),
		"prefs"=>array(
            "taxavoidance"=>"Has this player avoided tax?,bool|0",
            "taxpaid"=>"How much tax has this player paid?,int|0",
        )
	);
	return $info;
}

function taxation_install(){
	module_addeventhook("forest","return 100;");
	module_addhook("validatesettings");
	module_addhook("newday");
	return true;
}

function taxation_uninstall(){
	return true;
}

function taxation_dohook($hookname,$args){
	global $session;
	switch ($hookname) {
	case "validatesettings":
		if ($args['taxfree'] > $args['highlow']) {
			$args['validation_error'] = "The limit must be higher than the tax-free amount.";
		}
		if ($args['highlow'] > $args['highestgold']) {
			$args['validation_error'] = "The limit must be higher than the high/low tax barrier.";
		}
		break;
	case "newday":
		$taxon=get_module_setting("taxon");
		if ($taxon==1) {
			$taxfree=get_module_setting("taxfree");
			$highlow=get_module_setting("highlow");
			$redistribution=get_module_setting("redistribution");
			$highestgold=get_module_setting("highestgold");
			$taxpaid=get_module_pref("taxpaid");
			$rebate=get_module_setting("rebate");
			if (get_module_pref("homecity","cities")==get_module_setting("hightaxtown","townfinance")) {
				output("`n`^Because of your town's status, you have to pay extra tax!`n");
				$taxfree=0;
				$highlow=0;
			}
			if (get_module_pref("homecity","cities")==get_module_setting("notaxtown","townfinance")) {
				output("`n`^Because of your town's preferred status, you do not have to pay tax!`n");
				$notax==1;
			} elseif (($session['user']['goldinbank']<$taxfree)) {
				output("`n`7The taxman checks the bank and finds that you have no significant assets!");
				if ($rebate==1){
					$taxrebate=round(min(max($taxpaid * 0.01,10),500));
					$session['user']['goldinbank']+=$taxrebate;
					output("`n`7You have been granted a tax rebate of %s!",$taxrebate);
					debuglog("gained %s gold from a tax rebate",$taxrebate);
					$taxpaid-=$taxrebate;
				}
				set_module_pref("taxavoidance",0);
			} elseif ($session['user']['goldinbank']<$highlow) {
				$lowrate=get_module_setting("lowrate");
				$taxablebalance=($session['user']['goldinbank']-$taxfree);
				$taxloss=round(max(($taxablebalance * $lowrate * 0.01),2));
				output("`n`7The taxman checks the bank and finds that you have taxable assets! You are forced to pay %s gold into the treasury!`n`0",$taxloss);
				$session['user']['goldinbank']-=$taxloss;
			} elseif ($redistribution==0) {
				$lowrate=get_module_setting("lowrate");
				$lowtaxablebalance=($highlow-$taxfree);
				$lowtax=round(max(($lowtaxablebalance * $lowrate * 0.01),2));
				$highrate=get_module_setting("highrate");
				$hightaxablebalance=($session['user']['goldinbank']-$highlow);
				$hightax=round(max(($hightaxablebalance * $highrate * 0.01),2));
				$taxloss=($hightax+$lowtax);
				output("`n`7The taxman checks the bank and finds that you have extensive taxable assets! You are forced to pay %s gold into the treasury!`n`0",$taxloss);
				$session['user']['goldinbank']-=$taxloss;
			} elseif (($redistribution==1)&&($session['user']['goldinbank']>$highestgold)) {
				$taxloss=($session['user']['gold'] + $session['user']['goldinbank']);
				$session['user']['gold'] -= round($session['user']['gold']*.10);
				$session['user']['goldinbank'] -= round($session['user']['goldinbank']*.10);
				output("`n`7The taxman checks the bank and gets buried in your money! He takes 10% of your gold!`n`0");
				set_module_pref("taxavoidance",0);
			}
			if (($session['user']['gold']>$session['user']['goldinhand'])&&($session['user']['gold']>1000)&&($notax==0)) {
				output("`n`&The taxman doesn't notice the gold hidden in your pouches - you don't get taxed on that!`n`0");
				set_module_pref("taxavoidance",1);
			}
			$taxpaid+=$taxloss;
			$totalcash=get_module_setting("totalcash","townfinance");
			$totalcash-=$taxrebate;
			$taxloss *=0.9;
			$totalcash+=$taxloss;
			set_module_setting("totalcash",$totalcash,"townfinance");
			set_module_pref("taxpaid",$taxpaid);
		}
		break;
	}
	return $args;
}

function taxation_runevent($type) {
	global $SCRIPT_NAME;
	if ($SCRIPT_NAME == "forest.php" or $SCRIPT_NAME == "runmodule.php"){
		include("modules/lib/taxation_event.php");
	}
}

function taxation_run(){
	global $SCRIPT_NAME;
	if ($SCRIPT_NAME == "runmodule.php"){
		$module=httpget("module");
		if ($module == "taxation") include("modules/lib/taxation.php");
	}
}
?>