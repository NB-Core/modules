<?php
global $session;
$op = httpget('op');
if ($op=="campagn"){
	$op2 = httpget('op2');
	page_header("Campagn");
	if ($op2 == "news"){
		$newsmess = httppost('newsmess');
		if ($newsmess){
			$session['user']['gold']-=500;
			$newsmess = "`@Vote for ".$session['user']['name']." `n`@".$newsmess;
			output("`2Your message of: %s `2has been posted!",$newsmess);
			addnews($newsmess);
			addnav("Continue","runmodule.php?module=election&op=campagn");
		}else{
			output("News will already say `@Vote for %s:`n",$session['user']['name']);
			output("What else would you like your news blip to say?`n");
			$linkcode="<form action='runmodule.php?module=election&op=campagn&op2=news' method='POST'>";
			output("%s",$linkcode,true);
			$linkcode="<p><input type=\"text\" name=\"newsmess\" size=\"60\"></p>";
			output("%s",$linkcode,true);
			$linkcode="<p><input type=\"submit\" value=\"Submit\" name=\"B1\"><input type=\"reset\" value=\"Reset\" name=\"B2\"></p>";
			output("%s",$linkcode,true);
			$linkcode="</form>";
			output("%s",$linkcode,true);
			addnav("","runmodule.php?module=election&op=campagn&op2=news");
			addnav("Cancel","runmodule.php?module=election&op=campagn");
		}
	}elseif ($op2 == "posters"){
		$postermess = httppost('postermess');
		if ($postermess){
			$session['user']['gold']-=5000;
			$postermess = "`@Vote for ".$session['user']['name']." `n`@".$postermess;
			output("`2Your posters saying: %s `2have been posted!",$postermess);
			set_module_pref('postermess',$postermess);
			addnav("Continue","runmodule.php?module=election&op=campagn");
		}else{
			output("`2Note: `@New Posters will replace your old posters!`n`n");
			output("Posters will already say `@Vote for %s:`n",$session['user']['name']);
			output("What else would you like your posters to say?`n");
			$linkcode="<form action='runmodule.php?module=election&op=campagn&op2=posters' method='POST'>";
			output("%s",$linkcode,true);
			$linkcode="<p><input type=\"text\" name=\"postermess\" size=\"60\"></p>";
			output("%s",$linkcode,true);
			$linkcode="<p><input type=\"submit\" value=\"Submit\" name=\"B1\"><input type=\"reset\" value=\"Reset\" name=\"B2\"></p>";
			output("%s",$linkcode,true);
			$linkcode="</form>";
			output("%s",$linkcode,true);
			addnav("","runmodule.php?module=election&op=campagn&op2=posters");
			addnav("Cancel","runmodule.php?module=election&op=campagn");
		}
	}elseif ($op2 == "banners"){
		$bannermess = httppost('bannermess');
		if ($bannermess){
			$session['user']['gold']-=5000;
			$bannermess = "`@Vote for ".$session['user']['name']." `n`@".$bannermess;
			output("`2Your banners saying: %s `2have been posted!",$postermess);
			set_module_pref('bannermess',$bannermess);
			set_module_pref('bannercount',get_module_pref('bannercount') + 1000);
			addnav("Continue","runmodule.php?module=election&op=campagn");
		}else{
			output("`2Note: `@New Banners will replace your old posters!`n`n");
			output("Banners will already say `@Vote for %s:`n",$session['user']['name']);
			output("What else would you like your banners to say?`n");
			$linkcode="<form action='runmodule.php?module=election&op=campagn&op2=banners' method='POST'>";
			output("%s",$linkcode,true);
			$linkcode="<p><input type=\"text\" name=\"bannermess\" size=\"60\"></p>";
			output("%s",$linkcode,true);
			$linkcode="<p><input type=\"submit\" value=\"Submit\" name=\"B1\"><input type=\"reset\" value=\"Reset\" name=\"B2\"></p>";
			output("%s",$linkcode,true);
			$linkcode="</form>";
			output("%s",$linkcode,true);
			addnav("","runmodule.php?module=election&op=campagn&op2=banners");
			addnav("Cancel","runmodule.php?module=election&op=campagn");
		}
	}else{
		output("This is the Campagn Office, from here you can promote yourself to gain votes.`n");
		output("One tried and true way to get votes is flat out bribery!`n");
		output("Remember YOM is free as well as chatting with the constituents in the villages and pubs.`n");
		if ($session['user']['gold'] > 499) addnav("`2Post a News Blip (`6500 gold`2)","runmodule.php?module=election&op=campagn&op2=news");
		if ($session['user']['gold'] > 4999) addnav("`@Put up posters in the Villages (`65000 gold`@)","runmodule.php?module=election&op=campagn&op2=posters");
		if ($session['user']['gold'] > 4999) addnav("`2Buy 1000 banners (`65000 gold`2)","runmodule.php?module=election&op=campagn&op2=banners");
	}
	addnav("Return to the Hall","runmodule.php?module=townfinance&op=enter");
} elseif ($op=="register") {
	page_header("City Hall");
	$registrationcost=get_module_setting("registrationcost");
	$charmlimit=get_module_setting("charmlimit");
	output("`7At the side of the Hall, `QS`qneakabout `7is... errr... dwarfing a desk, looking very uncomfortable in a suit.");
	output("A couple of warriors seem to be talking to him about putting their names down as candidates for the upcoming election, but they don't look too confident.");
	if ($session['user']['gems']<$registrationcost) {
		output("`n`n`&You do not have the gems to register!");
	} elseif ($session['user']['charm']<$charmlimit) {
		output("`n`n`&You are not charming enough to stand!");
	} else {
		output("`n`n`&Maybe you should stand as a candidate... it'll only cost `%%s gems`& after all.",$registrationcost);
		addnav("Register as a Candidate","runmodule.php?module=election&op=registered");
	}
	addnav("Return to the Hall","runmodule.php?module=townfinance&op=enter");
} elseif ($op=="registered") {
	page_header("City Hall");
	output("`7You stride up to `QS`qneakabout`7 and make a stirring speech about your political intentions and your coherent reforms to be implemented.");
	output("When you look down to see what effect your speech had, `QS`qneakabout`7 is looking at you, obviously bored, with the form filled out waiting for your signature.");
	output("You sign it with a flourish and, slightly more reluctantly, hand over the administration fee.");
	$registrationcost=get_module_setting("registrationcost");
	set_module_pref("haveregistered",1);
	$session['user']['gems']-=$registrationcost;
	debuglog("spent $registrationcost gems on registering as a candidate.");
	$importantnumber=get_module_setting("importantnumber");
	$electioncandidates=get_module_setting("electioncandidates");
	$electioncandidates=unserialize($electioncandidates);
	$importantnumber++;
	output("`n`n`&You are candidate number %s! Be sure not to campaign too hard.... Gods don't like repeated messages.",$importantnumber);
	$electioncandidates[$importantnumber]['name']=$session['user']['name'];
	$electioncandidates[$importantnumber]['acctid']=$session['user']['acctid'];
	$electioncandidates=serialize($electioncandidates);
	set_module_setting("electioncandidates",$electioncandidates);
	set_module_setting("importantnumber",$importantnumber);
	addnav("Return to the Hall","runmodule.php?module=townfinance&op=enter");
} elseif ($op=="vote") {
	page_header("City Hall");
	$machinename=get_module_setting("machinename");
	output("`QS`qneakabout`^ looks you over and consults a scroll with all the names of the warriors in the realm on it.");
	output("As he reaches yours he places a small mark next to it and hands you a small crystal before ushering you towards a %s voting machine in a booth.",$machinename);
	output("`n`nWhilst you're sure that these new-fangled \"clockwork voting\" machines will get the result out faster, it seems very rickety. Indeed, it has a hole in the side where you can see the cogs.");
	output("Behind the curtain of the booth, you insert the crystal into the marked slot, and hear a strange clanking noise before the machine shudders into life.");
	output("An assortment of levers rise up with numbers on them - you are confused for a moment before you examine the scroll hastily attached to the side of the machine explaining the process.");
	output("It explains that the candidates are listed on the scroll and that you need to pull the lever marked with the appropriate number to vote.");
	output("`n`nYou're pretty sure a paper ballot would have been easier and cheaper, but sigh and get down to voting");
	$importantnumber=get_module_setting("importantnumber");
	$electioncandidates=get_module_setting("electioncandidates");
	$electioncandidates=unserialize($electioncandidates);
	$number=0;
	output("`n`nThese are the candidates on the scroll:`n`n");
	while($number<$importantnumber) {
		$number++;
		output("`&Candidate Number %s: %s `n",$number,$electioncandidates[$number]['name']);
	}
	$puzzleinfo = array();
    $puzzleinfo['vote'] = "Your Vote - Please enter the number of the Candidate you choose";
    $row = array();
	require_once("lib/showform.php");
   	output("<form name='reply' id='reply' action='runmodule.php?module=election&op=votecast' method='POST'>",true);
	$puzzle=showform($puzzleinfo,$row,true);
   	addnav("","runmodule.php?module=election&op=votecast");
   	output("<input name='reply' id='reply' type='submit' class='button' value='Pull Lever'>",true);
   	$output.="<input type='hidden' name='reply' id='reply' value=\"".htmlentities(serialize($puzzle))."\">";
   	output("</form>`n",true);
	addnav("Return to the Hall","runmodule.php?module=townfinance&op=enter");
} elseif ($op=="votecast") {
	page_header("City Hall");
	$reply=httppost('reply');
	$vote = httppost('vote');
	$importantnumber=get_module_setting("importantnumber");
	$electionvotes=get_module_setting("electionvotes");
	$electionvotes=unserialize($electionvotes);
	set_module_setting("votescast",get_module_setting("votescast")+1);
	switch($vote) {
		case 0:
		output("`@After carefully looking through the list of candidates and thinking deeply about which one would be best for your interests, you decide to pull an unmarked lever.");
		output("`n`nWell done you, first rate voting there. The machine clanks, shudders and grows silent.");
		break;
		default:
		if ($vote>$importantnumber) {
			output("`@After carefully looking through the list of candidates and thinking deeply about which one would be best for your interests, you decide to pull a number which isn't there.");
			output("`n`nWell done you, first rate voting there. The machine clanks, shudders and grows silent.");
		} else {
			output("`@After carefully looking through the list of candidates and thinking deeply about which one would be best for your interests, you decide to pull Number %s's lever.",$vote);
			output("`n`nWell done you, first rate voting there. The machine clanks, shudders and nearly vibrates itself apart before a loud clunk silences it.");
			$electionvotes[$vote]++;
		}
		break;
	}
	$electionvotes=serialize($electionvotes);
	set_module_setting("electionvotes",$electionvotes);
	output("You leave the booth, not too sure that your vote was counted.");
	set_module_pref("havevoted",1);
	addnav("Return to the City Hall","runmodule.php?module=townfinance&op=enter");
} elseif ($op=="finish") {
	$yn = httpget('yn');
	if ($yn <> "y"){
		page_header("Confirm Please");
		output("`4Are you sure you want to end the Election?");
		addnav("Yes","runmodule.php?module=election&op=finish&yn=y");
		addnav("No","superuser.php");
	}else{
	page_header("Election Triggers");
	output("Voting will now end, and the winner should be announced through a MotD as well as the methods automatic in this module.");
	$electionvotes=get_module_setting("electionvotes");
	$electionvotes=unserialize($electionvotes);
	while(list($key, $val) = each($electionvotes)) {
	$electionvotessort[" {$key}"]=$val;
	}
	array_multisort($electionvotessort,SORT_DESC,SORT_NUMERIC);
	reset($electionvotessort);
	list($key, $val) = each($electionvotessort);
	$key=str_replace(" ","",$key);
	$electionvotes=get_module_setting("electionvotes");
	$electionvotes=unserialize($electionvotes);
	$electioncandidates=get_module_setting("electioncandidates");
	$electioncandidates=unserialize($electioncandidates);
	set_module_setting("leadername",$electioncandidates[$key]['name']);
	set_module_setting("leaderacctid",$electioncandidates[$key]['acctid']);
	set_module_pref("isleader",1,"townfinance",$electioncandidates[$key]['acctid']);
	addnews("`&The elections are now over! After the counting was finished, a total of %s votes were cast and %s was declared the winner, with %s votes!",get_module_setting("votescast"),$electioncandidates[$key]['name'],$electionvotes[$key]);
	set_module_setting("electionon",0);
	set_module_setting("electionregister",0);
	//reset module prefs for all users
	//clear posters
	db_query("Update ".db_prefix("module_userprefs")." SET value = '' WHERE modulename = 'election' AND setting = 'postermess' AND value <> ''");
	//clear registrations
	db_query("Update ".db_prefix("module_userprefs")." SET value = '' WHERE modulename = 'election' AND setting = 'haveregistered' AND value <> ''");
	addnav("Return to the Grotto","superuser.php");
}
} elseif ($op=="votestart") {
	$yn = httpget('yn');
	if ($yn <> "y"){
		page_header("Confirm Please");
		output("`4Are you sure you want to start the Voting?");
		addnav("Yes","runmodule.php?module=election&op=votestart&yn=y");
		addnav("No","superuser.php");
	}else{
	page_header("Election Triggers");
	output("Voting will now start, and should be announced through a MotD as well as the methods automatic in this module.");
	set_module_setting("electionon",1);
	set_module_pref("isleader",0,"townfinance",$currentleader['acctid']);
	set_module_setting("electionregister",0);
	addnews("`&Voting has begun! Everyone should vote in the City Hall!");
	addnav("Return to the Grotto","superuser.php");
	}
} elseif ($op=="registerstart") {
	$yn = httpget('yn');
	if ($yn <> "y"){
		page_header("Confirm Please");
		output("`4Are you sure you want to start Voter Registration?");
		addnav("Yes","runmodule.php?module=election&op=registerstart&yn=y");
		addnav("No","superuser.php");
	}else{
	page_header("Election Triggers");
	output("Registration for being a candidate will now start, and should be announced through a MotD as well as the methods automatic in this module.");
	set_module_setting("electionregister",1);
	set_module_pref("isleader",0,"townfinance",$currentleader['acctid']);
	set_module_setting("electionon",0);
	set_module_setting("electioncandidates",0);
	set_module_setting("electionvotes",0);
	set_module_setting("importantnumber",0);
	set_module_setting("votescast",0);
	set_module_setting("leadername","");
	set_module_setting("leaderacctid",0);
	set_module_setting("currentleader","");
	addnews("`&Elections are coming up! Candidates should register in the City Hall!");
	addnav("Return to the Grotto","superuser.php");
	}
} else {
	page_header("How did you get here?");
	addnews("%s found a hole in the election module! Medic! Somebody needs to patch this module! Stat!",$session['user']['name']);
	output("`@In a shower of sparks and cheap-looking special effects `QS`qneakabout`@ appears before you in a somwehat tatty wizards robe.");
	output("\"`^What are you doing here? Don't you know that you're meant to be voting? Stop lazing around and get back to work!`@\"");
	output("With that he disappears back to wherever he came from with a wave of his cloak, obviously through a trapdoor pathetically concealed in the floor.");
	output("`n`nThere is nothing interesting here. Why not go back to the village?");
	addnav("Return to the Village","village.php");
}
page_footer();
?>