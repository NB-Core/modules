<?php
	global $session;
	$op = httpget('op');
	$fight=httpget('fight');
	
	page_header("Tax Office Guard");
	require_once("lib/fightnav.php");
	if ($fight=="guard") {
		$session['user']['turns']--;
		$badguy = array(
			"creaturename"=>"Tax Office Guard",
			"creaturelevel"=>$session['user']['level'],
			"creatureweapon"=>"Cost-Effective Sword",
			"creatureattack"=>round($session['user']['attack']*0.8, 0),
			"creaturedefense"=>round($session['user']['defense']*0.8, 0),
			"creaturehealth"=>round($session['user']['maxhitpoints']*0.5, 0), 
			"diddamage"=>0,
			"type"=>"tax"
		);
		$session['user']['badguy']=createstring($badguy);
		$battle=true;
	}
	include("battle.php");
	if ($victory) {
		output("The guard falls to the floor, bleeding from the many wounds you gave him. You quickly grab his gold pouch and run into the forest.");
		$goldgain=round(e_rand(90,($session['user']['level']*100)),0);
		output("`n`nYou gain %s gold!",$goldgain);
		$session['user']['gold']+=$goldgain;
		debuglog("gained %s gold from a guard in the tax offices.",$goldgain);
		addnav("Return to the Forest","forest.php");
	} elseif ($defeat) {
		output("The guard's sword pierces you as you breath your last... you are dead! The guard takes your gold and leaves! Your soul drifts to the shades.");
		$session['user']['gold']=0;
		addnav("Return to the News","news.php");
	} else {
		fightnav(true,true,"runmodule.php?module=taxation&fight=ongoing");
	}
	page_footer();
?>