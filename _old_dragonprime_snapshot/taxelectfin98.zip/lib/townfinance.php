<?php
	global $session;
	$op = httpget('op');
	$leader=get_module_setting("leadername","election");
	require_once("lib/systemmail.php");
	
	if ($op=="enter") {
		page_header("City Hall");
		output("`&You make your way through the plain wooden double doors into the grand antechamber of the City Hall.");
		output("Civil servants are wandering around purposefully and carrying important-looking pieces of parchment.");
		output("There are many warriors waiting at several desks, asking after various services and looking uncomfortable as they have to shoulder their weapons and fill in forms.");
		output("Guards flank a grand door leading further into the building, to the offices of %s`& and the audience chamber.",$leader);
		output("`n`nYour attention is brought back to the present day when a somewhat rat-like man inquires impatiently as to your business here.");
		output("What do you need to do here?");
		addnav("Administative Functions");
		if (!get_module_pref("isleader")) {
			addnav("Find Current Tax Status","runmodule.php?module=townfinance&op=taxinfo");
			if ($leader!="") addnav("Petition the Leader","runmodule.php?module=townfinance&op=petition");
		}
		if ($leader!="") addnav("Enter the Audience Chamber","runmodule.php?module=townfinance&op=audience");
		addnav("Other");
		if (get_module_pref("isleader")) {
			addnav("Go to Your Office","runmodule.php?module=townfinance&op=office");
		} elseif ($session['user']['turns']>0) {
			if ($leader!="") addnav("Protest the Leadership","runmodule.php?module=townfinance&op=protest");
			if ($leader!="") addnav("Support the Leadership","runmodule.php?module=townfinance&op=support");
		}
		modulehook("cityhall");
		addnav("Return to the Village","village.php");
	} elseif ($op=="taxinfo") {
		page_header("City Hall");
		$taxrequestfee=get_module_setting("taxrequestfee");
		output("`&You join a short queue to a desk with a sign above it reading \"Tax Information Services\" and wait until it is your turn to talk to the man... errr... manning it.");
		output("He looks up expectantly at you and says, \"`7Well? What do you want to know? All transactions require a handling fee of %s gold....\".`n`nHe looks back to his papers and waits for your request.",$taxrequestfee);
		if ($session['user']['gold']>$taxrequestfee) {
			output("`n`nDo you want the general tax code, or your personal tax status?");
			addnav("Tax Code","runmodule.php?module=townfinance&op=taxcode");
			addnav("Tax Status","runmodule.php?module=townfinance&op=taxstatus");
		} else {
			output("`n`nYou do not have the necessary gold!");
		}
		addnav("Return to the Village","village.php");
	} elseif ($op=="taxcode") {
		page_header("City Hall");
		$taxrequestfee=get_module_setting("taxrequestfee");
		$taxrequestcost=get_module_setting("taxrequestcost");
		$lowrate=get_module_setting("lowrate","taxation");
		$highrate=get_module_setting("highrate","taxation");
		$taxfree=get_module_setting("taxfree","taxation");
		$highlow=get_module_setting("highlow","taxation");
		$session['user']['gold']-=$taxrequestfee;
		$totalcash=round(get_module_setting("totalcash"));
		$totalcash+=($taxrequestfee-$taxrequestcost);
		set_module_setting("totalcash",round($totalcash));
		output("`&He writes out the tax code on a small form, and hands it to you before taking his fee and telling you to return to the main hall.");
		output("The Code says:`n`n");
		output("Current Tax Protocols: Official Viewing only.`n`nGeneral Tax-Free Allowance: %s gold.`nLow Tax Rate Allowance: %s gold.`n",$taxfree,$highlow);
		output("Low Tax Rate: %s percent.`nHigh tax Rate: %s percent.`n",$lowrate,$highrate);
		output("Whilst you suspect that there are items which are being concealed from you, you walk back into the Hall, thinking over the information you have been given.");
		addnav("Return to the Hall","runmodule.php?module=townfinance&op=enter");
	} elseif ($op=="taxstatus") {
		page_header("City Hall");
		$taxrequestfee=get_module_setting("taxrequestfee");
		$taxrequestcost=get_module_setting("taxrequestcost");
		$taxpaid=get_module_pref("taxpaid","taxation");
		$session['user']['gold']-=$taxrequestfee;
		$totalcash=get_module_setting("totalcash");
		$totalcash+=($taxrequestfee-$taxrequestcost);
		set_module_setting("totalcash",round($totalcash));
		$taxavoidance=get_module_pref("taxavoidance","taxation");
		output("`&He turns and rifles through several piles of scrolls for a couple of minutes before finding one with your name on it.");
		output("He seems to be adding something up in his head as he reads down the scroll then turns to you and says, \"");
		output("Your current total for taxed assets is %s gold, ",$taxpaid);
		if ($taxavoidance==1) {
			output("though there seem to be several gross anomalies in your record....\"");
		} else {
			output("and all your finances seem to be in order.\"");
		}
		output("He turns away from you and motions to the next person to step forward. You wander back to the Hall, thinking about what you have learnt.");
		addnav("Return to the Hall","runmodule.php?module=townfinance&op=enter");
	} elseif ($op=="protest") {
		page_header("City Hall");
		$protesttotal=get_module_setting("protesttotal");
		if ($protesttotal>20) {
			output("`@You join the crowd of people protesting %s`@'s leadership for a while, shouting catchy slogans.",$leader);
		} else {
			output("`@You shout against %s`@'s leadership for a bit, feeling a little isolated without much support.",$leader);
		}
		output("After a while, you leave since you're a bit tired, and you feel you've done your bit for the cause.");
		$protesttotal++;
		$session['user']['turns']--;
		debuglog("spent a turn protesting the leadership in front og the City Hall");
		addnav("Return to the Hall","runmodule.php?module=townfinance&op=enter");
	} elseif ($op=="support") {
		page_header("City Hall");
		$protesttotal=get_module_setting("protesttotal");
		if ($protesttotal>20) {
			output("`@You try to fight against the crowd of people protesting %s`@'s leadership for a while, but they are mostly outshouting you.",$leader);
		} else {
			output("`@You shout for %s`@'s leadership for a bit, isolating what few protesters there are.",$leader);
		}
		output("After a while, you leave since you're a bit tired, and you feel you've done your bit for the cause.");
		$protesttotal--;
		$session['user']['turns']--;
		debuglog("spent a turn supporting the leadership in front og the City Hall");
		addnav("Return to the Hall","runmodule.php?module=townfinance&op=enter");
	} elseif ($op=="audience") {
		page_header("City Hall");
		if (get_module_pref("isleader")) {
			output("`&You decide to take time out from your busy schedule and listen to what the plebs are muttering about your rule.");
			output("From a safe vantage point you can hear the rabble.");
		} else {
			output("`&The guards point you to a set of double-doors on the left through a long corridor, where you find a group of active citizens talking about the town's problems.");
			output("Whilst you cannot see %s`& directly, there is no doubt that he listens to what people are saying in here, and that it is a perfect place to voice your concerns or support.",$leader);
		}
		require_once("lib/sanitize.php");
		require_once("lib/commentary.php");
		addcommentary();
		viewcommentary("audiencechamber","Voice Your Opinion");
		addnav("Return to the Hall","runmodule.php?module=townfinance&op=enter");
	} elseif ($op=="petition") {
		page_header("City Hall");
		output("`@You head over to a rather busy desk manned by a rather prim woman who is handing out forms to warriors left and right.");
		output("As you approach she shoves one into your hand without a word, motions to a box on the wall to place it in once you have filled it in, and resumes her busy work.");
		output("You find a nearby flat surface to fill in the suggestion form on, and pause to think on what you want to say.");
		$puzzleinfo = array(
        	"petition"=>"Your Suggestion",
        );
		require_once("lib/showform.php");
       	output("<form name='reply' id='reply' action='runmodule.php?module=townfinance&op=petitionfinished' method='POST'>",true);
		$puzzle=showform($puzzleinfo,$puzzleinfo,true);
       	addnav("","runmodule.php?module=townfinance&op=petitionfinished");
       	output("<input name='reply' id='reply' type='submit' class='button' value='Place In Box'>",true);
       	$output.="<input type='hidden' name='reply' id='reply' value=\"".htmlentities(serialize($puzzle))."\">";
       	output("</form>`n",true);
		addnav("Return to the Hall","runmodule.php?module=townfinance&op=enter");
	} elseif ($op=="petitionfinished") {
		page_header("City Hall");
		$reply=httppost('reply');
		$petition = httppost('petition');
		$acctid=get_module_setting("leaderacctid","election");
		$petitioncost=get_module_setting("petitioncost");
		$totalcash=get_module_setting("totalcash");
		$totalcash-=$petitioncost;
		set_module_setting("totalcash",round($totalcash));
		systemmail($acctid,"`^New Petition!",array("`^A message saying %s has been put in your inbox!",$petition));
		output("`&You place your suggestion in the box, nearly sure that it was worth writing down.");
		addnav("Return to the Hall","runmodule.php?module=townfinance&op=enter");
	} elseif ($op=="office") {
		page_header("Executive Suite");
		output("`^As you make your way through the winding corridors of the City Hall, you breathe a sigh of relief as you reach your office.");
		output("Safely isolated from the taxpayers, with a troop of secretarys to carry out your orders, you can relax into your large comfy chair.");
		output("`n`nJust when you had thought you were safe, Sebastian, your permanent secretary slithers through the door and makes his way to your desk, clutching a sheaf of papers.");
		output("You try to look impassive as he stands there, waiting for your next order. You don't like him much, and you can guess he doesn't like you, but he seems to have been here longer than the building.");
		output("Nobody knows how the whole system works apart from him... and he can give you good advice if he chooses to.");
		output("`n`n\"`\$Hem hem....`^\"`n`nNot to mention that he can be impatient if your thoughts drift too much. The papers he has arranged on your desk remind you that there is %s gold in the treasury. What do you wish to take care of today?",get_module_setting("totalcash"));
		addnav("Administrative Duties");
		addnav("Change Tax Rates","runmodule.php?module=townfinance&op=taxchanges");
		addnav("Make a Proclamation","runmodule.php?module=townfinance&op=proclaimenter");
		if (get_module_setting("expensesactive")) addnav("Claim Expenses","runmodule.php?module=townfinance&op=expensesclaim");
		if (get_module_setting("almsgranting")) addnav("Grant Alms","runmodule.php?module=townfinance&op=almsgrant");
		addnav("Enter the Audience Chamber","runmodule.php?module=townfinance&op=audience");
		addnav("Wartime Powers");
		modulehook("waroffice");
		addnav("Other");
		addnav("Ask Sebastian's Advice","runmodule.php?module=townfinance&op=sebastianadvice");
		addnav("Resign your position","runmodule.php?module=townfinance&op=resignconfirm");
		addnav("Leave City Hall","village.php");
	} elseif ($op=="proclaimenter") {
		page_header("Executive Suite");
		$proclaimcost=get_module_setting("proclaimcost");
		output("`^Sebastian calls over the Chief Herald, who bows extravagantly to you, before reminding you that his fee is %s gold per proclamation, though it is payed from the taxpayer's funds.",$proclaimcost);
		if ($proclaimcost>get_module_setting("totalcash")) {
			output("However, Sebastian coughs gently to remind you that there is not enough gold in the treasury to fund the message. Perhaps you should turn your attention to taxation?");
		} else {
			$puzzleinfo = array(
	        	"proclaim"=>"Your Proclamation",
 	        );
			require_once("lib/showform.php");
 	      	output("<form name='reply' id='reply' action='runmodule.php?module=townfinance&op=proclaim' method='POST'>",true);
			$puzzle=showform($puzzleinfo,$row,true);
 	      	addnav("","runmodule.php?module=townfinance&op=proclaim");
 	      	output("<input name='reply' id='reply' type='submit' class='button' value='Inform the Heralds'>",true);
 	      	$output.="<input type='hidden' name='reply' id='reply' value=\"".htmlentities(serialize($puzzle))."\">";
 	      	output("</form>`n",true);
	    }
		addnav("Return to the Office","runmodule.php?module=townfinance&op=office");
	} elseif ($op=="proclaim") {
		page_header("City Hall");
		$reply=httppost('reply');
		$proclaim = httppost('proclaim');
		if ($proclaim=="") {
			output("`^The Chief Herald nods and leaves the office, to tell his associates to stop their messages.");
			output("Sebastian looks at you with interest, and commends you on your prudence in keeping your powers for more important matters.");
		} else {
			output("The Chief Herald nods and leaves the office, to tell his associates to relay your message to the people.");
			$proclaimcost=get_module_setting("proclaimcost");
			output("Sebastian looks away as he hands %s gold over to the Herald's accountant, seemingly annoyed at the cost.",$proclaimcost);
			$totalcash=(get_module_setting("totalcash")-$proclaimcost);
			set_module_setting("totalcash",round($totalcash));
			addnews("%s",$proclaim);
		}
		set_module_setting("proclaimtext",$proclaim);
		addnav("Return to the Office","runmodule.php?module=townfinance&op=office");
	} elseif ($op=="expensesclaim") {
		page_header("Executive Suite");
		output("`^Sebastian seems to have a mild frown on his face as he goes over your claimed expenses for the day, crossing out such entries as \"Having to get up\" and \"Breathing Allowance\".");
		$expenses=(($session['user']['level']*100)+$session['user']['dragonkills']);
		$totalcash=get_module_setting("totalcash");
		if ($expenses>$totalcash) {
			output("Eventually he looks in the treasury for the gold, but there is not enough there! He then gives you some papers about the state of the treasury, which you desperately pore over, looking for more ways of getting money.");
		} else {
			output("Eventually he hands over a bag of %s gold, and then gives you some papers about the state of the treasury. Which you ignore, as you count your gold.",$expenses);
			$totalcash-=$expenses;
			set_module_setting("totalcash",round($totalcash));
			$session['user']['gold']+=$expenses;
			set_module_pref("expensesclaimed",1);
			debuglog("gained %s gold from expenses",$expenses);
			addnews("%s `^gained %s gold in expenses from the City Hall!",$session['user']['name'],$expenses);
		}
		addnav("Return to the Office","runmodule.php?module=townfinance&op=office");
	} elseif ($op=="almsgrant") {
		page_header("Executive Suite");
		output("`^Sebastian nods at your request and asks who you would like to bestow the taxpayer's money upon, due to their unfortunate circumstances.");
		output("`n`nWhat is the name of the person in need?");
		output("<form action='runmodule.php?module=townfinance&op=almscheck' method='POST'>",true);
		output("`^Name: <input name='almsname'>`n", true);
		output("<input type='submit' class='button' value='Give Alms'></form>",true);
		addnav("","runmodule.php?module=townfinance&op=almscheck");
	} elseif ($op=="almscheck") {
		page_header("Executive Suite");
		$almsname = stripslashes(rawurldecode(httppost('almsname')));
		$name="%";
		for ($x=0;$x<strlen($almsname);$x++){
			$name.=substr($almsname,$x,1)."%";
		}
		$sql = "SELECT acctid,name,login,level,locked FROM " . db_prefix("accounts") . " WHERE name LIKE '".addslashes($name)."' AND locked=0";
		$result = db_query($sql);
		if (db_num_rows($result) == 0) {
			output("`^Sebastian looks confused as he looks through the list of citizens of the realm. There is no record of anyone with that name.");
		} elseif(db_num_rows($result) > 50) {
			output("`^Sebastian looks confused as he looks through the list of citizens of the realm. That name seems to match with too many people, perhaps you should be more specific?");
		} elseif(db_num_rows($result) > 1) {
			output("`^Sebastian looks through the list of citizens of the realm and gives you a list of the matches. Which one did you wish to give alms to?");
			output("<form action='runmodule.php?module=townfinance&op=almsgive' method='POST'>",true);
			output("`^Name: <select name='name'>",true);
			for ($i=0;$i<db_num_rows($result);$i++){
				$row = db_fetch_assoc($result);
				output("<option value=\"".rawurlencode($row['name'])."\">".full_sanitize($row['name'])."</option>",true);
			}
			output("</select>`n`n",true);
			$amount = httppost('amount');
			output("<input type='submit' class='button' value='Give Alms'></form>",true);
			addnav("","runmodule.php?module=townfinance&op=almsgive");
		} else {
			$row = db_fetch_assoc($result);
			output("`^Sebastian nods as you say the name and gets the listing from the roll of citizens.");
			output("He looks to you for confirmation of %s`^'s name.",$row['name']);
			addnav("Give Alms","runmodule.php?module=townfinance&op=almsgive&name=$name");
		}
		addnav("Return to the Office","runmodule.php?module=townfinance&op=office");
	} elseif ($op=="almsgive") {
		page_header("Executive Suite");
		$name=httpget('name');
		if ($name=="") {
			$sql = "SELECT acctid,name,login,level,locked FROM " . db_prefix("accounts") . " WHERE name='".addslashes(rawurldecode(stripslashes(httppost('name'))))."' AND locked=0";
		} else {
			$sql = "SELECT acctid,name,login,level,locked FROM " . db_prefix("accounts") . " WHERE name LIKE '".addslashes($name)."' AND locked=0";
		}
		$result = db_query($sql);
		$row  = db_fetch_assoc($result);
		if ($row['locked']) {
			output("`^Sebastian checks the list again and sees that %s is not available. Perhaps you should select someone who we can give the money to?",$row['name']);
		} elseif ($row['login']==$session['user']['login']) {
			output("`^Sebastian looks at you blankly and kindly suggests that you are not in desperate need of alms. Looking around at the plush office, you see what he means. Maybe you should give to someone really in need?");
		} elseif (get_module_pref("almsgranted",false,$row['acctid'])) {
			output("`^Sebastian looks at you blankly and kindly suggests that %s `^is not in need of alms. After all, you have already granted him aid this day. Perhaps you should use the taxpayer's money better?",$row['name']);
		} elseif (($row['level']*100)>get_module_setting("totalcash")) {
			output("`^Sebastian looks at you blankly and reminds that the total amount in the treasury is less than the alms that you would give. You cannot give out alms when the City Hall is a pauper!");
		} else {
			$almsgold=$row['level']*100;
			$totalcash=(get_module_setting("totalcash")-$almsgold);
			set_module_setting("totalcash",round($totalcash));
			output("`^Sebastian nods at your request, gathers up %s gold from the treasury and informs you that it shall be transferred %s`^'s bank account at once.",$almsgold,$row['name']);
			output("You relax back into your comfy chair, confident that you have made a good decision... after all, the money is going to a good cause. Its not as if anyone would find out who got the money...");
			addnews("%s `^gained %s gold in alms from the City Hall!",$row['name'],$almsgold);
			set_module_pref("almsgranted",1,false,$row['acctid']);
			$sql="UPDATE " . db_prefix("accounts") . " SET goldinbank=goldinbank+$almsgold WHERE acctid={$row['acctid']}";
			db_query($sql);
			systemmail($row['acctid'],"`^You have been given alms!",array("`^ %s gold has been given to you by %s `^on behalf of the taxpayers!",$almsgold,$leader));
		}
		addnav("Return to the Office","runmodule.php?module=townfinance&op=office");
	} elseif ($op=="resignconfirm") {
		page_header("Executive Suite");
		output("`^Sebastian looks at you surprised, as you tell him of your intention to give up your position. Though he cannot contain his amazement, he nods and prepares the paperwork for a new election.");
		output("However, just before you sign the papers, you think over your intention. Do you really want to give up your office?");
		addnav("Resign","runmodule.php?module=townfinance&op=resign");
		addnav("Return to the Office","runmodule.php?module=townfinance&op=office");
	} elseif ($op=="resign") {
		page_header("Executive Suite");
		output("`^Sebastian takes the papers from you and shakes your hand as you leave the office for the last time. You make your way back to the entrance of the City Hall, now a normal citizen again.");
		set_module_pref("isleader",0);
		set_module_setting("electioncandidates",0,"election");
		set_module_setting("electionvotes",0,"election");
		set_module_setting("importantnumber",0,"election");
		set_module_setting("votescast",0,"election");
		set_module_setting("leadername","","election");
		set_module_setting("leaderacctid",0,"election");
		set_module_setting("currentleader",0,"election");
		set_module_setting("electionregister",1,"election");
		addnews("%s `&has resigned his position! Elections are coming up! Candidates should register in the City Hall!",$leader);
		addnav("City Hall Entrance","runmodule.php?module=townfinance&op=enter");
		debuglog("has resigned from political office.");
	} elseif ($op=="sebastianadvice") {
		page_header("Executive Suite");
		output("`^Sebastian smiles a little to himself as you ask him to give you some advice on your duties and powers, due to his greater experience in such matters.");
		output("`n`n\"`\$Well... the most basic advice that I can give you is that you must keep an eye on the money held in the treasury - too little money there and you may have to resort to unpopular measures to raise funds in the case of an emergency.");
		output("Similarly, if you hoard the wealth of the taxpayer they usually find out one way or another, and you had best have a good reason for squeezing their pockets so.");
		output("If you choose to not tax a town, or to tax one excessively, there are two ways of staying in power - the first is to make sure that none of the other towns find out about your deception.");
		output("The second is to ensure that the inhabitants which you oppress are few, unable to mount any kind of organised resistance. In addition, redistributing the wealth of your people is never popular... unless it happens only to those who are disliked or ignored.");
		output("`n`nOn the subject of your powers, you may well be able to claim expenses or grant alms to the poor - this should be seen to be done with a fair and even hand, else merely the appearance of corruption can lead to your downfall.");
		output("Nearly everything which you do costs money.... and they will be aware of that. Act to conserve your funds, exact fair taxes, defens the realm and you will be popular.`^\"");
		addnav("Return to the Office","runmodule.php?module=townfinance&op=office");
	} elseif ($op=="taxchanges") {
		page_header("Executive Suite");
		output("`^Sebastian nods and brings forward the current tax rates for you to approve or change as you will. The alterations will take place on the next new day.");
		$taxfree=get_module_setting("taxfree","taxation");
		$highlow=get_module_setting("highlow","taxation");
		$redistribution=get_module_setting("redistribution","taxation");
		$highestgold=get_module_setting("highestgold","taxation");
		$lowrate=get_module_setting("lowrate","taxation");
		$highrate=get_module_setting("highrate","taxation");
		$notaxtown=get_module_setting("notaxtown");
		$hightaxtown=get_module_setting("hightaxtown");
		$rebate=get_module_setting("rebate","taxation");
		$row=array(
			"taxfree"=>$taxfree,
			"lowrate"=>$lowrate,
			"highlow"=>$highlow,
			"highrate"=>$highrate,
			"redistribution"=>$redistribution,
			"highestgold"=>$highestgold,
			"rebate"=>$rebate,
			"hightaxtown"=>$hightaxtown,
			"notaxtown"=>$notaxtown,
		);
		$puzzleinfo = array(
	       	"normal"=>"Normal Tax Rates,title",
	       	"taxfree"=>"Tax Free Allowance,int",
	       	"lowrate"=>"Low Tax Rate,range,0,40",
	       	"highlow"=>"Low Tax Boundary,int",
	       	"highrate"=>"High Tax Rate,range,0,80",
	       	"redux"=>"Redistributive Policies,title",
	       	"redistribution"=>"Is Asset Seizing Active,enum,No,0,Yes,1",
	       	"highestgold"=>"Wealth at Which Assets are Seized,int",
	       	"rebate"=>"Are Rebates Active,enum,No,0,Yes,1",
	       	"discriminate"=>"Discriminative Policies,title",
	       	"notaxtown"=>"Town Exempt from Tax,",
	       	"hightaxtown"=>"Town Punitively Taxed,",
 	       );
		require_once("lib/showform.php");
       	output("<form name='reply' id='reply' action='runmodule.php?module=townfinance&op=taxchanged' method='POST'>",true);
		$puzzle=showform($puzzleinfo,$row,true);
 	   	addnav("","runmodule.php?module=townfinance&op=taxchanged");
      	output("<input name='reply' id='reply' type='submit' class='button' value='Fill in the Form'>",true);
     	$output.="<input type='hidden' name='reply' id='reply' value=\"".htmlentities(serialize($puzzle))."\">";
      	output("</form>`n",true);
		addnav("Return to the Office","runmodule.php?module=townfinance&op=office");
	} elseif ($op=="taxchanged") {
		page_header("City Hall");
		$reply=httppost('reply');
		$debugmsg = print_r($reply,true);
		debug("Vars are: {$debugmsg}");
		set_module_setting("taxfree",httppost('taxfree'),"taxation");
		set_module_setting("lowrate",httppost('lowrate'),"taxation");
		set_module_setting("highlow",httppost('highlow'),"taxation");
		set_module_setting("highrate",httppost('highrate'),"taxation");
		set_module_setting("redistribution",httppost('redistribution'),"taxation");
		set_module_setting("highestgold",httppost('highestgold'),"taxation");
		set_module_setting("rebate",httppost('rebate'),"taxation");
		set_module_setting("hightaxtown",httppost('hightaxtown'));
		set_module_setting("notaxtown",httppost('notaxtown'));
		output("`^Sebastian nods at your changes, and tells you that they will be implemented immediately.");
		addnav("Return to the Office","runmodule.php?module=townfinance&op=office");
	}
	page_footer();
?>