<?php
	global $session;
	$from = "forest.php?";
	$session['user']['specialinc'] = "module:taxation";
	
	$taxavoidance=get_module_pref("taxavoidance");
	$taxman=get_module_setting("taxman");
	$type = httpget('type');
	$op = httpget('op');
	
	if ($taxman==0) {
		output("`@As you wander through the bracken you spy what seems to be large building through the trees.");
		output("You cautiously walk closer, to find that it is a grand building, with clerks rushing past windows carrying huge amounts of parchment.");
		output("However, before you can investigate further a guard walks up to you and shoves you back into the woods, with a warning not to go here again.");
		output("You decide to leave this place, to search in other parts of the forest.");
		addnav("Return to the Forest","forest.php");
		$session['user']['specialinc'] = "";
	} elseif ($op=="" || $op=="search") {
		output("`@As you wander through the bracken you spy what seems to be large building through the trees.");
		output("You cautiously walk closer, to find that it is a grand building, with clerks rushing past windows carrying huge amounts of parchment and sacks of gold.");
		output("Though the building looks interesting, you notice guards patrolling the clearing.");
		output("`n`nDo you want to look further and investigate this strange building?");
		addnav("Enter the Building","forest.php?op=enter");
		addnav("Snoop Around the Outside","forest.php?op=snoop");
		addnav("Return to the Forest","forest.php?op==leave");
	} elseif ($op=="leave") {
		output("`2You decide to leave this place, to search in other parts of the forest.");
		addnav("Return to the Forest","forest.php");
		$session['user']['specialinc'] = "";
	} elseif ($op=="enter") {
		output("`&You decide that your best chance to get past the guards is to stride in through the front doors.");
		if ($taxavoidance==1) {
			output("However, you are immediately grabbed by the guards, and are dragged through a high hall into a large office at the top of the building.");
			output("A large, rotund, balding man with a brown suit a couple of sizes too small for him coughs at you from behind a desk before saying, `n`n\"");
			output("`^Well! It seems that someone has been investigating the tax offices, eh? Well! Well indeed! Well... I don't know! What are we to do with you?");
			output("`&\"`n`nA small minion scuttles up to the official and whispers in his ear for a few seconds, the fat man nodding to his words, before leaving a stack of papers on his desk and scuttling off.");
			output("`n\"`^Well! Well, well ,well! It seems that by this.... *detailed* audit of your assets, you have been concealing some things from the tax office!");
			output("Bit foolish to come walking in here when you have back-taxes due.... well, I think that a confiscation order is appropriate, yes. Hand over the gold, we will deal with your bank account immediately.`&\"");
			output("`n`nWhile you think of resisting for a moment, the burly guards either side of the door seem very well trained, and you grudgingly hand over your loot before being forcefully expelled from the building.");
			output("Cursing the tax system, you walk back to the edges of the forest, swearing to never go there again.");
			$taxloss=($session['user']['gold']+$session['user']['goldinbank']*0.5);
			$session['user']['goldinbank']*=0.5;
			$session['user']['gold']=0;
			addnav("Return to the Forest","forest.php");
			$session['user']['specialinc'] = "";
			$taxpaid=get_module_pref("taxpaid");
			$taxpaid+=$taxloss;
			$totalcash=get_module_setting("totalcash","townfinance");
			$totalcash+=$taxloss;
			set_module_setting("totalcash",$totalcash,"townfinance");
			set_module_pref("taxpaid",$taxpaid);
			set_module_pref("taxavoidance",0);
		} else {
			$randevent=round(e_rand(1,15),0);
			switch ($randevent) {
				case 1:
				case 2:
				case 3:
				output("However, you are instantly recognised as an intruder by the guards (probably because of your lack of paper) and they chase you off, swords drawn.");
				output("By the time you have outrun them, you are exhausted, and your back bleeding from several places! You stagger back to the village, hurt and tired.");
				$session['user']['hitpoints']*=0.5;
				$session['user']['turns']--;
				break;
				case 4:
				case 5:
				case 6:
				output("Whilst you get past the guards relatively easily, probably through your deception of holding one of the pieces of parchment scattered around, the inside of the building is chaos.");
				output("Though there is plenty of gold around, it is moving so fast that you are barely able to get a handful before people start looking at you suspiciously.");
				$goldgain=e_rand(20,300);
				$session['user']['gold']+=$goldgain;
				debuglog("gained %s gold from the tax offices",$goldgain);
				output("`n`nYou hastily exit the building, %s gold richer.",$goldgain);
				$totalcash=get_module_setting("totalcash","townfinance");
				$totalcash-=$goldgain;
				set_module_setting("totalcash",$totalcash,"townfinance");
				break;
				case 7:
				case 8:
				output("Whilst you get past the guards relatively easily, probably through your deception of holding one of the pieces of parchment scattered around, the inside of the building is chaos.");
				output("You spot an unattended coffer of gold though, and quickly exit the building, the stolen goods under your cloak.");
				$goldgain=e_rand(300,900);
				$session['user']['gold']+=$goldgain;
				debuglog("gained %s gold from the tax offices",$goldgain);
				output("`n`nYou hastily leave the clearing, %s gold richer.",$goldgain);
				$totalcash=get_module_setting("totalcash","townfinance");
				$totalcash-=$goldgain;
				set_module_setting("totalcash",$totalcash,"townfinance");
				break;
				case 9:
				case 10:
				$taxfree=get_module_setting("taxfree");
				$highlow=get_module_setting("highlow");
				$redistribution=get_module_setting("redistribution");
				$highestgold=get_module_setting("highestgold");
				$lowrate=get_module_setting("lowrate");
				$highrate=get_module_setting("highrate");
				$notaxtown=get_module_setting("notaxtown","townfinance");
				$hightaxtown=get_module_setting("hightaxtown","townfinance");
				output("You seem to be mistaken for somebody else as you enter the building and you are shown through the crowded hall filled with parchment and gold to a small back chamber, sadly not filled with gold, but only parchment.");
				output("The small slimy man who showed you through seems to be waiting for a response, and you glance at the parchment in front of you. It reads:`n`n");
				output("Current Tax Protocols: Official Viewing only.`n`nGeneral Tax-Free Allowance: %s gold.`nLow Tax Rate Allowance: %s gold.`n",$taxfree,$highlow);
				output("Low Tax Rate: %s percent.`nHigh tax Rate: %s percent.`n",$lowrate,$highrate);
				if ($redistribution==1) output("Gold Redistribution Level: %s gold.`n",$highestgold);
				if ($notaxtown!="") output("Town Exemption: %s.`n",$notaxtown);
				if ($hightaxtown!="") output("Town for Punitive Taxation: %s.`n",$hightaxtown);
				output("`nYou hastily nod and mutter something about everything being in order as the underling beams at you. You quickly leave the building to digest the information you have just acquired.");
				break;
				case 11:
				case 12:
				case 13:
				case 14:
				case 15:
				$taxpaid=get_module_setting("taxpaid");
				output("Whilst you get past the guards relatively easily, probably through your deception of holding one of the pieces of parchment scattered around, you are immediately grabbed by a civil servant and led through the halls, past all the gold to a small office in the back of the building.");
				output("He grabs the piece of parchment in your hand and studies it for a moment before going through a pile of scrolls on a nearby desk.");
				output("He smiles as he finds one in particular, and puts it into your hand without a word then leads you back out of the building, again without an opportunity to get any of the gold, and chucks you out of the door before you can do anything.");
				output("As you wander back to the forest, you notice that the scroll has your name on it. It has records of a series of payments on it, with a total at the bottom of %s gold.",$taxpaid); // Find personal Tax Records.
				break;
			}
		addnav("Return to the Forest","forest.php");
		$session['user']['specialinc'] = "";
		}
	} elseif ($op=="snoop") {
		output("`7You decide that entering the building would be too risky, so you take a look around the outside.");
		if ($taxavoidance==1) {
			output("However, you immediately get caught by the guards, and are dragged through a high hall into a large office at the top of the building.");
			output("A large, rotund, balding man with a brown suit a couple of sizes too small for him coughs at you from behind a desk before saying, `n`n\"");
			output("`^Well! It seems that someone has been investigating the tax offices, eh? Well! Well indeed! Well... I don't know! What are we to do with you?");
			output("`7\"`n`nA small minion scuttles up to the official and whispers in his ear for a few seconds, the fat man nodding to his words, before leaving a stack of papers on his desk and scuttling off.");
			output("`n\"`^Well! Well, well ,well! It seems that by this.... *detailed* audit of your assets, you have been concealing some things from the tax office!");
			output("Bit foolish to come poking round here when you have back-taxes due.... well, I think that a confiscation order is appropriate, yes. Hand over the gold, we will deal with your bank account immediately.`7\"");
			output("`n`nWhile you think of resisting for a moment, the burly guards either side of the door seem very well trained, and you grudgingly hand over your loot before being forcefully expelled from the building.");
			output("Cursing the tax system, you walk back to the edges of the forest, swearing to never go there again.");
			$taxloss=($session['user']['gold']+$session['user']['goldinbank']*0.5);
			$session['user']['goldinbank']*=0.5;
			$session['user']['gold']=0;
			addnav("Return to the Forest","forest.php");
			$session['user']['specialinc'] = "";
			$taxpaid=get_module_pref("taxpaid");
			$taxpaid+=$taxloss;
			$totalcash=get_module_setting("totalcash","townfinance");
			$totalcash+=$taxloss;
			set_module_setting("totalcash",$totalcash,"townfinance");
			set_module_pref("taxpaid",$taxpaid);
			set_module_pref("taxavoidance",0);
		} else {
			$randevent=round(e_rand(1,15),0);
			switch ($randevent) {
				case 1:
				case 2:
				case 3:
				case 4:
				output("However, you are instantly spotted by the guards (probably because of the lack of cover in the clearing) and they chase you off, swords drawn.");
				output("By the time you have outrun them, you are exhausted, and your back bleeding from several places! You stagger back to the village, hurt and tired.");
				$session['user']['hitpoints']*=0.5;
				$session['user']['turns']--;
				break;
				case 5:
				case 6:
				case 7:
				case 8:
				case 9:
				output("Whilst you get past the guards relatively easily, there seems to be nothing of value around the outside of the building.");
				output("Though there is plenty of gold around, you are only able to pinch a small pouch of gold through an open window which was lying on a desk.");
				$goldgain=e_rand(20,300);
				$session['user']['gold']+=$goldgain;
				debuglog("gained %s gold from the tax offices",$goldgain);
				output("`n`nYou hastily leave the clearing, %s gold richer.",$goldgain);
				$totalcash=get_module_setting("totalcash","townfinance");
				$totalcash-=$goldgain;
				set_module_setting("totalcash",$totalcash,"townfinance");
				break;
				case 10:
				case 11:
				output("Whilst you get past the guards relatively easily, there seems to be nothing of value around the outside of the building.");
				output("You hit jackpot when a forgetful civil servant puts a small sack of gold down near an open window, which is quickly acquired by you.");
				$goldgain=e_rand(300,900);
				$session['user']['gold']+=$goldgain;
				debuglog("gained %s gold from the tax offices",$goldgain);
				output("`n`nYou hastily leave the clearing, %s gold richer.",$goldgain);
				$totalcash=get_module_setting("totalcash","townfinance");
				$totalcash-=$goldgain;
				set_module_setting("totalcash",$totalcash,"townfinance");
				break;
				case 12:
				case 13:
				case 14:
				$taxfree=get_module_setting("taxfree");
				$highlow=get_module_setting("highlow");
				$redistribution=get_module_setting("redistribution");
				$highestgold=get_module_setting("highestgold");
				$lowrate=get_module_setting("lowrate");
				$highrate=get_module_setting("highrate");
				$notaxtown=get_module_setting("notaxtown","townfinance");
				$hightaxtown=get_module_setting("hightaxtown","townfinance");
				output("Whilst you get past the guards relatively easily, there seems to be nothing of value around the outside of the building.");
				output("However, you notice an important-looking piece of paper through a window, and quickly read it. It says:`n`n");
				output("Current Tax Protocols: Official Viewing only.`n`nGeneral Tax-Free Allowance: %s gold.`nLow Tax Rate Allowance: %s gold.`n",$taxfree,$highlow);
				output("Low Tax Rate: %s percent.`nHigh tax Rate: %s percent.`n",$lowrate,$highrate);
				if ($redistribution==1) output("Gold Redistribution Level: %s gold.`n",$highestgold);
				if ($notaxtown!="") output("Town Exemption: %s.`n",$notaxtown);
				if ($hightaxtown!="") output("Town for Punitive Taxation: %s.`n",$hightaxtown);
				output("`nPondering what you have seen, you slip through the guards and back into the forest.");
				break;
				case 15:
				output("As you try to sneak past the guards, you hear a twig snap behind you, and whip round to find a guard standing there, sword drawn! He has a hefty bag of gold at his waist.... you must fight him!");
				addnav("Fight the guard","runmodule.php?module=taxation&fight=guard");
				$continue=1;
				break;
			}
		$session['user']['specialinc'] = "";
		if ($continue==0) {
			addnav("Return to the Forest","forest.php");
		}
		}
	}
?>