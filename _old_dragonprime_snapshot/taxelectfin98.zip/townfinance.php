<?php

function townfinance_getmoduleinfo(){
	$info = array(
		"name"=>"Town Finance System",
		"version"=>"2.0",
		"author"=>"Sneakabout",
		"category"=>"General",
		"download"=>"http://www.pqcomp.com/modules/mydownloads/visit.php?cid=3&lid=19",
		"vertxtloc"=>"http://www.pqcomp.com/",
		"settings"=>array(
			"Town Finance System Settings,title",
			"proclaimcost"=>"How much do proclamations cost?,int|5000",
			"proclaimtext"=>"What is the current proclamation?,",
			"expensesactive"=>"Can the leader claim expenses?,bool|1",
			"totalcash"=>"How much cash is there in the treasury?,int|10000",
			"almsgranting"=>"Can the leader grant alms?,bool|1",
			"almssize"=>"How much are the granted alms per level?,int|100",
			"petitioncost"=>"How much do petitions cost?,int|50",
			"taxrequestcost"=>"How much do information requests cost?,int|500",
			"taxrequestfee"=>"How much is the information request fee?,int|550",
			"protesttotal"=>"How many Forest Fights have been spent protesting?,int|0",
			"hightaxtown"=>"Which town is charged extra tax?,",
			"notaxtown"=>"Which town is not charged tax?,",
		),
		"prefs"=>array(
            "almsgranted"=>"Has this player been granted alms?,bool|0",
            "expensesclaimed"=>"Has this player claimed expenses?,bool|0",
            "isleader"=>"Is this player the leader?,bool|0",
        ),
        "requires"=>array(
	       "taxation"=>"1.0|By Sneakabout, available on DragonPrime",
		),
	);
	return $info;
}

function townfinance_install(){
	module_addhook("village");
	module_addhook("newday");
	module_addhook("newday-runonce");
	return true;
}

function townfinance_uninstall(){
	return true;
}

function townfinance_dohook($hookname,$args){
	global $session;
	switch ($hookname) {
	case "village":
		$proclaimtext=get_module_setting("proclaimtext");
		$protesttotal=get_module_setting("protesttotal");
		tlschema($args['schemas']['fightnav']);
		addnav($args['fightnav']);
		tlschema();
		addnav("City Hall","runmodule.php?module=townfinance&op=enter");
		$leader=get_module_setting("leadername","election");
		if ($proclaimtext !="") {
			output("`^A Herald proclaims, \"`n%s`^`n\" in the name of %s.",$proclaimtext,$leader);
		}
		if ($protesttotal>=20) {
			output("`n`@You can see people chanting catchy slogans outside the City Hall, calling for %s`@'s resignation.`n",$leader);
		}
		if ($protesttotal<=(-20)) {
			output("`n`@You can see people chanting catchy slogans outside the City Hall, cheering on %s`@.`n",$leader);
		}
		break;
	case "newday":
		set_module_pref("almsgranted",0);
		set_module_pref("expensesgranted",0);
		if (get_module_pref("electionplaceholder")) set_module_setting("protesttotal",0);
		break;
	case "newday-runonce":
		$spentamt = e_rand(100,round(get_module_setting("totalcash") * .10));
		$mssg = array(
			1=>"repairing streets",
			2=>"repairing city offices",
			3=>"paying city workers",
			4=>"paying welfare",
			5=>"purchasing supplies",
			6=>"bribing officials",
			7=>"purchasing armaments",
			8=>"buying overpriced toilet seats",
			9=>"on doughnuts for law enforcement",
			10=>"cleaning up trash",
			11=>"on a gardens beautification project",
			12=>"on secret things",
			13=>"on kingdom security",
			14=>"on a government gold spending evaluation",
			15=>"a dragons and how to live with them study",
			16=>"an ale anonymous program",
			17=>"a D.A.R.E. program (Dragons Are Rally Evil)",
			18=>"paying city officials"
		);
		addnews("`#Today the government spent `6%s gold `#on %s.",$spentamt,$mssg[e_rand(1,18)]); 	
		set_module_setting("totalcash",get_module_setting("totalcash") - $spentamt);
		break;
	}
	return $args;
}

function townfinance_runevent($type) {
}

function townfinance_run(){
	global $SCRIPT_NAME;
	if ($SCRIPT_NAME == "runmodule.php"){
		$module=httpget("module");
		if ($module == "townfinance") include("modules/lib/townfinance.php");
	}
}
?>