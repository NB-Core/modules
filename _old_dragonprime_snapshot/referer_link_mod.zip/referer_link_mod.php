----------------------------------------------------------------------------
==
== superadmin removal of referer links mod (ver 0.1)
==
== written by thegleek (thegleek@thegleek.com)
== 3 June 2004
==
== The latest version is always available at: http://dragonprime.cawsquad.net/
==
----------------------------------------------------------------------------
DESCRIPTION

- basically i made this mod because if your running a server with a lot of
  users and if yer the admin going into the superuser.php, clicking on the
  *referring URLs* link wouldnt load due to the fact of 10's of thousands
  of URLs that are inside the sql db... 

- so i created a simple edit to:
  - 1. display how MANY links/URLs are contained in the sql db
  - 2. made it possible to delete the most common links, done by:
       - hit count of 1
       - getting rid of all the links that have your serverurl contained
         within your server settings
  - 3. only allow level 3 admin to click,delete or view this data, as
       theres no valid reason why a level 2 admin should have access to this

an example from: Superuser Grotto

before: Referring URLs (9441)

and after deleting URLs:

-Mechanics�
Game Settings 
Referring URLs (237) 
Delete many URLs 
Stats 

----------------------------------------------------------------------------
INSTALLATION

File Changes:
=============


In superuser.php, find:

	addnav("Referring URLs","referers.php");

REPLACE that with:

        if ($session[user][superuser]>=3){
          $sql="SELECT * FROM referers";
          $result=db_query($sql) or die(sql_error($sql));
          $numref=db_num_rows($result);
          addnav("Referring URLs `#(".$numref.")","referers.php");
          addnav("Delete many URLs","referers.php?op=delref");
        }



referers.php

find:

if ($_GET['op']=="rebuild"){

insert BEFORE:

if ($_GET['op']=="delref"){
	$sql="DELETE FROM referers WHERE site='$settings[serverurl]'"; db_query($sql);
        $sql="DELETE FROM referers where count=1"; db_query($sql);
}

