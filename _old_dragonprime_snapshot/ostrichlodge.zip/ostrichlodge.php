<?php

//addnews ready
/***************************************************************************/
/* Name Garland's Ostrich for the Lodge                                    */
/* ver 1.1                                                                 */
/* Billie Kennedy => dannic06@gmail.com                                    */
/* slightly borrowed from Garland Stable - Lonny Luberts                   */
/***************************************************************************/

function ostrichlodge_getmoduleinfo(){
	$info = array(
		"name"=>"Ostrich Lodge Award",
		"author"=>"Billie Kennedy,Lonny Luberts",
		"version"=>"1.1",
		"download"=>"http://dragonprime.net/users/Dannic/ostrichlodge.zip",
		"category"=>"Lodge",
		"prefs"=>array(
			"eggage"=>"Egg Age,int|0",
		),
		"settings"=>array(
			"Ostrich Lodge Award Settings,title",
			"cost"=>"How many points are needed to get an Ostrich?,int|1000",
			"qcost"=>"How many Quest points are needed to get an Ostrich?,int|1000",
			"eggid"=>"Egg Mount ID,int",
		),
	);
	return $info;
}

function ostrichlodge_install(){

	if (!is_module_installed("garlandstables")) {
      output("Must have Garland Stables for this to work properly.");
      return false;
   }
   
	$sql = "SELECT mountid FROM ".db_prefix("mounts")." where mountname = 'Egg'";
	$result = db_query($sql) or die(db_error(LINK));
	$row = db_fetch_assoc($result);
	if ($row['mountid'] > 0){
		set_module_setting("eggid",$row['mountid']);
		output("`2Set ID for Egg to ".$row['mountid'].".`n");
	}else{
		output("`4Failed to Set ID for Egg!`n");
	}
	
	module_addhook("lodge");
	module_addhook("pointsdesc");
	module_addhook("questhut");
	module_addhook("questhutpointsdesc");
	return true;
}

function ostrichlodge_uninstall(){
	return true;
}

function ostrichlodge_dohook($hookname,$args){
	global $session;
	$cost = get_module_setting("cost");
	switch($hookname){
	case "questhutpointsdesc":
		$args['count']++;
		$format = $args['format'];
		$str = translate("If you are looking to get an Ostrich but just can't seem to scrape up the gold, you can get an Ostrich here.  An Ostrich egg costs %s points.");
		$str = sprintf($str, $qcost);
		output($format, $str, true);
		break;
	case "questhut":
		addnav(array("Fairy Dust (%s points+1 gem)", $qcost),"runmodule.php?module=ostrichlodge&op=qbuy");
		break;
	case "qpointsdesc":
		$args['count']++;
		$format = $args['format'];
		$str = translate("If you are looking to get an Ostrich but just can't seem to scrape up the gold, you can get an Ostrich here.  An Ostrich egg costs %s points.");
		$str = sprintf($str, $qcost);
		output($format, $str, true);
		break;
	case "pointsdesc":
		$args['count']++;
		$format = $args['format'];
		$str = translate("If you are looking to get an Ostrich but just can't seem to scrape up the gold, you can get an Ostrich here.  An Ostrich egg costs %s points.");
		$str = sprintf($str, $cost);
		output($format, $str, true);
		break;
	case "lodge":
		addnav(array("Ostrich Egg (%s points", $cost),"runmodule.php?module=ostrichlodge&op=buy");
		break;
	}
	return $args;
}

function ostrichlodge_run(){
	global $session;
	$op = httpget("op");

	$cost = get_module_setting("cost");
	if ($op=="buy"){
		page_header("Hunter's Lodge");
		output("`7J. C. Petersen turns to you. \"`&An Ostrich egg costs %s points.`7\", he says.  \"`&Will this suit you?`7\"`n`n", $cost);
		addnav("Confirm Ostrich Egg Purchase");
		addnav("Yes", "runmodule.php?module=ostrichlodge&op=buyconfirm");
		addnav("No", "lodge.php");
	}elseif ($op=="buyconfirm"){
		page_header("Hunter's Lodge");
		addnav("L?Return to the Lodge","lodge.php");
		$pointsavailable = $session['user']['donation'] - $session['user']['donationspent'];
		if($pointsavailable >= $cost && $session['user']['gems'] > 0){
			//going to have to read to get id's from the table
			//fix mount id to egg id
			$sql = "SELECT * FROM ".db_prefix("mounts")." where mountid='".get_module_setting('eggid')."'";
			$result = db_query($sql);
			$mount = db_fetch_assoc($result);
			
			if ($session['user']['hashorse']>0){
				output("`7You hand over the reins to your %s `7and the purchase price of your new critter, and J. C. Petersen brings out a fine new`& %s`7 he purchased from Garland for you!`n",$playermount['mountname'],$mount['mountname']);
			}else{
				output("`7You hand over the purchase price of your new egg, and J. C. Petersen brings out a fine `& %s`7 he purchased from Garland for you!`n`n",$mount['mountname']);
			}
				
			$session['user']['hashorse']=$mount['mountid'];
			set_module_pref('eggage',e_rand(1,10));
			$session['bufflist']['mount']=unserialize($mount['mountbuff']);
			$session['user']['donationspent'] += $cost;

		} else {
				output("`7J. C. Petersen looks down his nose at you. \"`&I'm sorry, but you do not have the %s points required to procure an Ostrich egg.  Please return when you do and I'll be happy to sell one to you.`7\"", $cost);
		}
	}
	page_footer();
}
?>