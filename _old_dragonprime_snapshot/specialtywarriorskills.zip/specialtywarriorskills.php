<?php
/*
		Warrior Skills...
			,,,a boon for the warrior,
				you have not been forgotten.

		This was for a friend who asked specifically
		for a Warrior specialty and believed in my
		coding skill to pull this off.  So I gave it
		a shot and here it is.

		Tower Shield
			Defense is heightened by the appearance
			of a gigantic tower-shield.

		Dual {weapon}s.
			Yup, like Dual Rake-wielding, which I
			thought was really rather funny.  It's a
			damage modifier, pretty much.

		Great {weapon}
			Weapon triples in size, the player frequently
			drops it and does mass damage to the poor
			recipient.  WHAM!

		Firing Squad
			A batallion of Eythgim Soldiers materialize
			and let rip with blunderbusses.  This is
			thanks to [backstory - see below *].

		* Yes, I'm lazy.

		~~ History ~~

		1.0.0
			Initial release.

		1.0.1
			A bug in the uninstall() function has been
			fixed thanks to dvd871.

		~~ Credits ~~

		Dannic
			Based on his Elementalist skill.
*/

function specialtywarriorskills_getmoduleinfo(){
	$info = array(
		"name" => "Specialty - Warrior Skills",
		"author" => "Rowne-Wuff Mastaile, some fixes/changes by Christian Rutsch",
		"version" => "1.0.1",
		"category" => "Specialties",
		"settings"=> array(
			"Specialty - Warrior Settings,title",
			"mindk"=>"How many DKs do you need before the specialty is available?,int|0",
			"cost"=>"How many points do you need before the specialty is available?,int|0",
      ),
      "prefs" => array(
			"Specialty - Warrior Skills User Prefs,title",
			"skill"=>"Skill points in Warrior Skills,int|0",
			"uses"=>"Uses of Warrior Skills allowed,int|0",
		),
	);
	return $info;
}

function specialtywarriorskills_install(){
	module_addhook("choose-specialty");
	module_addhook("set-specialty");
	module_addhook("fightnav-specialties");
	module_addhook("apply-specialties");
	module_addhook("newday");
	module_addhook("incrementspecialty");
	module_addhook("specialtynames");
	module_addhook("specialtymodules");
	module_addhook("specialtycolor");
	module_addhook("dragonkill");
	module_addhook("pointsdesc");
	return true;
}

function specialtywarriorskills_uninstall(){
	// Reset the specialty of anyone who had this specialty so they get to
	// rechoose at new day
	$sql = "UPDATE " . db_prefix("accounts") . " SET specialty='' WHERE specialty='WA'";
	db_query($sql);
	return true;
}

function specialtywarriorskills_dohook($hookname,$args){
	global $session,$resline;

	$spec = "WA";
	$name = "Warrior Skills";
	$ccode = "`#";

	switch ($hookname) {

	case "pointsdesc":
		$args['count']++;
		$format = $args['format'];
		$str = translate("The Warrior Specialty is availiable upon reaching %s Dragon Kills and %s points.");
		$str = sprintf($str, get_module_setting("mindk"),
		get_module_setting("cost"));
		output($format, $str, true);
		break;

	case "dragonkill":
		set_module_pref("uses", 0);
		set_module_pref("skill", 0);
		break;

	case "choose-specialty":
		if ($session['user']['specialty'] == "" || $session['user']['specialty'] == '0') {
			if ($session['user']['dragonkills'] < (int)get_module_setting("mindk") || (int)get_module_setting("cost") > $session['user']['donation']) break;
			addnav("$ccode$name`0","newday.php?setspecialty=".$spec."$resline");
			$t1 = translate_inline("From a young age you were tutored by a Master versed in the arts of war and all its weapons.");
			$t2 = appoencode(translate_inline("$ccode$name`0"));
			rawoutput("<a href='newday.php?setspecialty=$spec$resline'>$t1 ($t2)</a><br>");
			addnav("","newday.php?setspecialty=$spec$resline");
		}
		break;

	case "set-specialty":
		if($session['user']['specialty'] == $spec) {
			page_header($name);
			output("`3In your youth, you befriended a gnarly, aged Master of the ways of War and became his apprentice.");
			output("In time, much was learned from him of various forms of the warrior's art and how it might best be applied.");
			output("One night, after a fairly brutal battle with your first mortal foe; Arculis, the High Daemon of War paid you a personal visit.");
			output("He saw in you a most promising warrior of utmost potential and granted you a boon, that every now and then you might call upon his aid.");
			output("Since that night, your abilities as a fighter have only gone from strength to strength.");
		}
		break;

	case "specialtycolor":
		$args[$spec] = $ccode;
		break;
	case "specialtymodules":
		$args[$spec] = "specialtywarriorskills";
		break;
	case "specialtynames":
		$args[$spec] = translate_inline($name);
		break;
	case "incrementspecialty":
		if($session['user']['specialty'] == $spec) {
			$new = get_module_pref("skill") + 1;
			set_module_pref("skill", $new);
			$specialties = modulehook("specialtynames",	array(""=>translate_inline("Unspecified")));
			$c = $args['color'];
			output("`n%sYou gain a level in `&%s%s to `#%s%s!",
					$c, $specialties[$session['user']['specialty']], $c, $new, $c);
			$x = $new % 3;
			if ($x == 0){
				output("`n`^You gain an extra use point!`n");
				set_module_pref("uses", get_module_pref("uses") + 1);
			}else{
				if (3-$x == 1) {
					output("`n`^Only 1 more skill level until you gain an extra use point!`n");
				} else {
					output("`n`^Only %s more skill levels until you gain an extra use point!`n", (3-$x));
				}
			}
			output_notl("`0");
		}
		break;

	case "newday":
		$bonus = getsetting("specialtybonus", 1);
		$specialties = modulehook("specialtynames",	array(""=>translate_inline("Unspecified")));
		if($session['user']['specialty'] == $spec) {
			if ($bonus == 1) {
				output("`n`2For being interested in %s%s`2, you receive `^1`2 extra `&%s%s`2 use for today.`n",$ccode, $specialties[$session['user']['specialty']], $ccode, $specialties[$session['user']['specialty']]);
			} else {
				output("`n`2For being interested in %s%s`2, you receive `^%s`2 extra `&%s%s`2 uses for today.`n",$ccode, $specialties[$session['user']['specialty']],$bonus, $ccode,$specialties[$session['user']['specialty']]);
			}
		}
		$amt = (int)(get_module_pref("skill") / 3);
		if ($session['user']['specialty'] == $spec) $amt = $amt + $bonus;
		set_module_pref("uses", $amt);
		break;

	case "fightnav-specialties":
		$uses = get_module_pref("uses");
		$script = $args['script'];

		if ($uses > 0) {
			addnav(array("$ccode$name (%s points)`0", $uses),"");
			addnav(array("%s &#149; Tower Shield`7 (%s)`0", $ccode, 1),
			$script."op=fight&skill=$spec&l=1", true);
		}

		if ($uses > 1) {
			addnav(array("%s &#149; Dual %ss`7 (%s)`0", $ccode, $session['user']['weapon'], 2),
			$script."op=fight&skill=$spec&l=2",true);
		}

		if ($uses > 2) {
			addnav(array("%s &#149; Great %s`7 (%s)`0", $ccode, $session['user']['weapon'], 3),
			$script."op=fight&skill=$spec&l=3",true);
		}

		if ($uses > 4) {
			addnav(array("%s &#149; Firing Squad`7 (%s)`0", $ccode, 5), $script."op=fight&skill=$spec&l=5",true);
		}
		break;

	case "apply-specialties":
		$skill = httpget('skill');
		$l = httpget('l');

		if ($skill==$spec){
			if (get_module_pref("uses") >= $l){
				switch($l){
					case 1:
						apply_buff('el1',
							array(
								"startmsg"=>"`2You call upon Arculis for defense and a huge Tower Shield appears before you.",
								"name"=>"`2Tower Shield",
								"rounds"=>5,
								"wearoff"=>"Your shield fades away ... only to show {badguy} grinning evilly.",
								"roundmsg"=>"{badguy} slams against your Shield but has great trouble penetrating it.",
								"badguyatkmod"=>0.9,
								"defmod"=>1.6,
								"schema"=>"specialtywarriorskills"
							)
						);
						break;

					case 2:
						apply_buff('el2',
							array(
								"startmsg"=>"`2You spin your {weapon} rapidly and suddenly, as {badguy} watches helplessly it becomes two!",
								"name"=>"`2Dual {weapons}s",
								"rounds"=>5,
								"wearoff"=>"The strange second {weapon} fades out of existance as if it never were.",
								"atkmod"=>2,
								"roundmsg"=>"You quickly slam into {badguy} with the might of two {weapon}s!",
								"schema"=>"specialtywarriorskills"
							)
						);
						break;

					case 3:
						apply_buff('el3',
							array(
								"startmsg"=>"`2You toss your {weapon} up in the air, Artculis strikes it with magical fire and it grows to three times its size!",
								"name"=>"`2Great {weapon}",
								"rounds"=>5,
								"badguydefmod"=>e_rand(0.1,0.2,0.3),
								"wearoff"=>"Your {weapon} shrinks back down to a more wieldly but less deadly size.",
								"roundmsg"=>"`)You fumble and drop your gigantic {weapon} on {badguy} doing tremendous damage!",
								"schema"=>"specialtywarriorskills"
							)
						);
						break;

					case 5:
						apply_buff('el5'
							,array(
								"startmsg"=>"`2You cry out to Arculis for aid and a line of Eythgim Soldiers with Blunderbusses materialize behind you, {badguy} looks terrified!",
								"name"=>"`2Firing Squad",
								"rounds"=>5,
								"wearoff"=>"The Eythgim Soldiers wonder why exactly they're aiding you and decide instead to wander off to a nearby Tavern for a poker game.",
								"minioncount"=>round($session['user']['level']/2)+2,
								"maxbadguydamage"=>round($session['user']['level']/2,0)+3,
								"effectmsg"=>"`)An Eythgim Soldier lets rip with his Blunderbuss!",
								"effectnodmgmsg"=>"`)One of the Soldiers fumbles and shoots one of his friends in the foot!  `\$MISSING`) {badguy} completely.",
								"roundmsg"=>"`&The Eythgim General calls out, \"`2Reddah... Aymm... Fiyahr!`&\" and many Blunderbusses are brought to bare.",
								"schema"=>"specialtywarriorskills"
							)
						);
					break;
				}

				set_module_pref("uses", get_module_pref("uses") - $l);
			}

			else {
				apply_buff('el0',
					array(
						"startmsg"=>"You cry out to Arculis for aid, only to be greeted by his Celestial Answering Machine (MusTEKco, all rights reserved).  {badguy} sputters uproariously.",
						"rounds"=>1,
						"schema"=>"specialtywarriorskills"
					)
				);
			}
		}
		break;
	}
	return $args;
}

function specialtywarriorskills_run() {
}
?>
