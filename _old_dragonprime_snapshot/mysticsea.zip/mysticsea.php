<?php
/*
Nach einer Idee von Todesengel Tatiascha
Umgesetzt von Sir Arvex; � 2005
Erstmalig auf Anagromataf.de erschienen
Bugs und Fehler an arvex@anagromataf.de
*/
function mysticsea_getmoduleinfo(){
	$info = array(
		"name"=>"Mystischer See",
		"author"=>"`)Arvex",
		"version"=>"1.05",
		"category"=>"Forest Specials",
		"download"=>"http://www.arvex.de/index.php?showforum=3",
	);
	return $info;
}

function mysticsea_install(){
	module_addeventhook("forest", "return 100;");
	return true;
}
function mysticsea_uninstall(){
	return true;
}

function mysticsea_runevent($type){
	global $session;
	require_once("lib/http.php");
	require_once('lib/e_rand.php');
	$op = httpget('op');

	$session['user']['specialinc'] = "module:mysticsea";
	$from = "forest.php?";

	page_header("Der mystische See");

	switch ($op) {
		case "":
		output("`cDer mystische See`c`n`n");
		output("`#W�hrend du so durch den Wald spazierst, lichten sich mit einem Male die B�ume.");
		output("Wie aus dem Nichts, taucht vor dir ein kleiner mystischer See auf.`n");
		output("An seinem Ufer stehen riesige Trauerweiden, die silberne Oberfl�che ist spiegelglatt und Nebelschwaden ziehen �ber das Wasser.");
		output("Du wirst von einer merkw�rdigen Stimmung erfasst, wie magisch zieht dich dieser See an`n`n");
		output("`&Was wirst du tun?");
		addnav("Der See");
		addnav("Schwimmen gehen", $from."op=schwimm");
		addnav("Stein springen lassen", $from."op=stein");
		addnav("Trauerweiden ansehen", $from."op=trauer");
		addnav("Lieber nichts", $from."op=nichts");
		break;
	}
	
	if ($op=="schwimm"){
		include("modules/arvex/mysticsea/mysticsea_schwimm.php");
		}
	if ($op=="stein"){
		include("modules/arvex/mysticsea/mysticsea_stein.php");
		}
	if ($op=="trauer"){
		include("modules/arvex/mysticsea/mysticsea_trauer.php");
		}
	if ($op=="nichts"){
		include("modules/arvex/mysticsea/mysticsea_nichts.php");
	}
	return $args;
}
	
function mysticsea_run(){
}
?>