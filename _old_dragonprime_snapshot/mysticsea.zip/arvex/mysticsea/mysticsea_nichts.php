<?php
output("`n`&Du widerstehst der mystischen Anziehung des Sees lieber, irgendwie ist er dir unheimlich. Schnell machst du dich auf den Weg zur�ck in den Wald.");
		$session['user']['specialinc']="";
?>