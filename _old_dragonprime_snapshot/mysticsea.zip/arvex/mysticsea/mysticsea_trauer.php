<?php
switch(e_rand(1,10)){
			case 1:
			case 2: 
        		case 3:
        		case 4:
        		case 5:
			output("`c`b`#Du schaust dir die Trauerweiden an`b`c`n`n");
			output("`@Vorsichtig n�herst du dich den Trauerweiden, doch wohl nicht vorsichtig genug.");
			output("Einer der �ste holt pl�tzlich zu einem Schlag aus, und trifft dich mitten ins Gesicht.`n`n");
			if ($session['user']['hitpoints']<=10) {
				output("`6Der Schlag trifft dich mittem im Gesicht ... das macht dich nicht grade h�bscher.");
				$session['user']['charm']-=2;
				$session['user']['specialinc']="";
			}
			elseif ($session['user']['hitpoints']>=11) {
			output("`2Der Schlag trifft dich sehr sehr hart ins Gesicht ... dabei `4verlierst `2du fast alle Lebenspunkte.");
			$session['user']['hitpoints']=1;
			$session['user']['specialinc']="";
			}
			break;
			case 6:
			case 7:
			case 8:
			case 9:
			output("`c`b`#Du schaust dir die Trauerweiden an`b`c`n`n");
			output("`@Du trittst durch die tiefh�ngenden Zweige der Weiden und untersuchst den Stamm genauer.`n`n");
			if ($session['user']['gold']<=75) {
				output("`2In einer kleinen H�hlung findest du `4%s `2Dukaten.",round($session['user']['level']*75));
				$session['user']['gold']+=round($session['user']['level']*75);
				$session['user']['specialinc']="";
			}
			elseif ($session['user']['gold']>75) {
			output("`2In einer kleinen H�hlung findest du `4%s `2Dukaten.",round($session['user']['gold']*0.25));
			$session['user']['gold']+=round($session['user']['gold']*1.25);
			$session['user']['specialinc']="";
			}
			break;
			case 10:
			output("`c`b`#Du schaust dir die Trauerweiden an`b`c`n`n");
			output("`@Du schiebst die tiefh�ngenden �ste der Weide zur Seite, als du auf dem Boden im Gras etwas funkeln siehst.`n`n");
			output("`2Du findest `4einen `2Edelstein.");
			$session['user']['gems']++;
			$session['user']['specialinc']="";
			break;
			}
?>