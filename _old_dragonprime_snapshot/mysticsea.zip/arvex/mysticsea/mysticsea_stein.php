<?php
switch(e_rand(1,10)){ 
        		case 1:
			case 2: 
        		case 3:
        		case 4:
        		case 5:
			output("`c`b`#Du l��t einen Stein springen`b`c`n`n");
			output("`^Du hebst einen der flachen Steine auf, die am Ufer verstreut liegen und versuchst ihn �ber das Wasser springen zu lassen.");
			output("Der Stein springt 2 mal.`n`n");
			output("`3Du erh�ltst `4einen `3Waldkampf.");
			$session['user']['turns']++;
			$session['user']['specialinc']="";
			break;
			case 6:
			output("`c`b`#Du l��t einen Stein springen`b`c`n`n");
			output("`^Du hebst einen der flachen Steine auf, die am Ufer verstreut liegen und versuchst ihn �ber das Wasser springen zu lassen.");
			output("Der Stein springt 5 mal.`n`n");
			if ($session['user']['experience']<=100) {
				output("`6Du erh�ltst `445 `6Erfahrungspunkte.");
				$session['user']['experience']+=45;
				$session['user']['specialinc']="";
			}
			elseif ($session['user']['experience']>100){	
			output("`6Du erh�ltst `4%s `6Erfahrungspunkte.",round($session['user']['experience']*0.05));
			$session['user']['experience']=round($session['user']['experience']*1.05);
			$session['user']['specialinc']="";
			}
			break;
			case 7:
			case 8:
			case 9: 
        		case 10:
			output("`c`b`#Du l��t einen Stein springen`b`c`n`n");
			output("`^Du hebst einen der flachen Steine auf, die am Ufer verstreut liegen und versuchst ihn �ber das Wasser springen zu lassen.");
			output("Du scheiterst kl�glich, der Stein versinkt mit einem lauten Platschen im Wasser.`n`n");
			if ($session['user']['turns']<=0) {
				output("`6Du f�hlst dich echt deprimiert ... und lauscht noch Stundenlang dem Hall des lauten Platschen");
				$session['user']['specialinc']="";
			}
			elseif ($session['user']['turns']>=1) {
			output("`6Du f�hlst dich echt deprimiert ... und `4verlierst `6einen Waldkampf.");
			$session['user']['turns']--;
			$session['user']['specialinc']="";
			break;
			}
			}
?>