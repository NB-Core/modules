<?php
switch(e_rand(1,10)){ 
        		case 1:
			case 2: 
        		case 3:
        		case 4:
        		case 5:
        		case 6:
			output("`c`b`#Du bist schwimmen gegangen`b`c`n`n");
			output("`#Du steigst aus deinen Kleidern, gehst vorsichtig in das kalte Wasser.");
			output("Nachdem du ein paar Runden geschwommen bist, f�hlst du dich erfrischt.`n`n");
			output("`3Du erh�ltst `42 `3Charmpunkte.");
			$session['user']['charm']+=2;
			$session['user']['specialinc']="";
			break;
			case 7:
			output("`c`b`#Du bist schwimmen gegangen`b`c`n`n");
			output("`#Du steigst aus deinen Kleidern, gehst vorsichtig in das kalte Wasser.");
			output("Nachdem du ein paar Z�ge geschwommen bist, tauchst du mutig auf den Grund des Sees.`n`n");
			output("`3Du findest `4einen `3Edelstein im Schlamm.");
			$session['user']['gems']++;
			$session['user']['specialinc']="";
			break;
			case 8:
			case 9: 
        		case 10:
			output("`c`b`#Du bist schwimmen gegangen`b`c`n`n");
			output("`#Du steigst aus deinen Kleidern, gehst vorsichtig in das kalte Wasser.");
			output("Du schwimmst bis zur Mitte des Sees, als du einen Krampf bekommst, du kannst das rettende Ufer nicht mehr erreichen.`n");
			output("`\$Du ertrinkst.`n`n");
			output("`4Du verlierst 5% deiner Erfahrung.");
			$session['user']['turns']=0;
			$session['user']['hitpoints']=0;
			$session['user']['alive']=false;
			$session['user']['experience']*=0.95;
			$session['user']['specialinc']="";
			addnav("T�gliche News","news.php");
			addnews("%s `\$wurde tot am Ufer des verwunschenen Sees gefunden. `n`#Wer nicht schwimmen kann sollte halt doch besser an Land bleiben.",$session['user']['name']);
			break;
			}
?>