<?php
require_once("lib/villagenav.php");
function poke_getmoduleinfo(){
	$info = array(
		"name" => "Poke",
		"author" => "`QJosh Elwell`0 - `i`&S`7anctum`i `@from an idea by `7NightHawk",
		"version" => "0.4",
		"category" => "General",
		"description" => "Poke Players, will send mail saying You've Been Poked",
		"settings"=>array(
			"Poking Settings,title",
				"maxpokes"=>"Max Pokes a Day,int|5",
		),
		"prefs" => array(
			"poked"=>"Times Player has Poked others today.,int|0",
			"lastpoke1"=>"Last Player Poked,int|0",
			"lastpoke2"=>"2nd Last Player Poked,int|0",
			"lastpoke3"=>"3rd Last Player Poked,int|0",
			"lastpoke4"=>"4th Last Player Poked,int|0",
			"lastpoke5"=>"5th Last Player Poked,int|0",
		),
		);
	return $info;
}
function poke_install(){
	module_addhook("bioinfo");
	module_addhook("newday-runonce");
	return true;
}
function poke_uninstall(){
	return true;
}
function poke_dohook($hookname,$args){
	global $session;
	$op = httpget('op');
	switch ($hookname){
		case "bioinfo":
			$ret = httpget('ret');
			$char = httpget('char');
			$id = $args['acctid'];
			addnav("Poke User", "runmodule.php?module=poke&id=$id&char=$char&ret=$ret");
		break;
		case "newday-runonce":
			set_module_pref("poked",0,"poke",true);
			set_module_pref("lastpoke1",0,"poke",true);
			set_module_pref("lastpoke2",0,"poke",true);
			set_module_pref("lastpoke3",0,"poke",true);
			set_module_pref("lastpoke4",0,"poke",true);
			set_module_pref("lastpoke5",0,"poke",true);
		break;
	}
	return $args;
}
function poke_run(){
	global $session;
	page_header("Poke!");
	$op = httpget('op');
	$ret = httpget('ret');
	$char = httpget('char');
	$id=httpget('id');
	$poked=get_module_pref("poked");
	require_once("lib/systemmail.php");
		$sql="SELECT * FROM " .db_prefix("accounts"). " WHERE acctid = '$id'";
		$res = db_query($sql);
		$row=db_fetch_assoc($res);
		$n=$poked+1;
		if($n>get_module_setting("maxpokes")){
		output("Sorry you have poked the max ammount of times today!!");
		}elseif(get_module_pref("lastpoke1")==$id){
		output("You already poked this person!");
		}elseif(get_module_pref("lastpoke2")==$id){
		output("You already poked this person!");
		}elseif(get_module_pref("lastpoke3")==$id){
		output("You already poked this person!");
		}elseif(get_module_pref("lastpoke4")==$id){
		output("You already poked this person!");
		}elseif(get_module_pref("lastpoke5")==$id){
		output("You already poked this person!");
		}else{
		set_module_pref("poked",$n);
		if(get_module_pref("lastpoke1")==0){
		set_module_pref("lastpoke1",$id);
		}elseif(get_module_pref("lastpoke2")==0){
		set_module_pref("lastpoke2",$id);
		}elseif(get_module_pref("lastpoke3")==0){
		set_module_pref("lastpoke3",$id);
		}elseif(get_module_pref("lastpoke4")==0){
		set_module_pref("lastpoke4",$id);
		}elseif(get_module_pref("lastpoke5")==0){
		set_module_pref("lastpoke5",$id);
		}
		$name = $session[user][name];
		systemmail($id,"`^Poke!`0",sprintf("`^You have been poked by %s`^!!!.","$name"),$session[user][acctid]);
		}
		villagenav();
		
	page_footer();
}

?>

