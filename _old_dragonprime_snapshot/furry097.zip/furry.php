<?php
/********************
Furry - 097 special forest event
Written by Robert for Maddnet LoGD
Must also use Lonny's Clean/odor mod
*********************/
if (!isset($session)) exit(); 
if ($HTTP_GET_VARS[op]==""){ 
    output("`n`n`%It is dark, you can not see too well. `n`2Something furry has just brushed up against your leg. `n`n`& What will you do?"); 
    addnav("something furry"); 
    addnav("(I) Investigate","forest.php?op=see"); 
//    addnav("(R) Run Scared!","forest.php?op=dont");
    $session[user][turns]--; 
    $session[user][specialinc]="furry.php"; 
}else if ($HTTP_GET_VARS[op]=="see"){ 
  if ($session[user][clean]<=12){ 
      output("`n`n`&You lean over to see what it is,`n`n ");
      switch(e_rand(1,8)){ 
            case 1: 
               output("Whatever is was is not there anymore.");
               break; 
            case 2:
               $gold=$session[user][gold]*.3;
               output("that a `2Leprechaun `&wearing a small furry coat has just died at your feet.`n");
               output("You search the `2Leprechaun's `&Pot of Gold and discover `6$gold in Gold`&.`n");
               $gold=$session[user][gold]*.2; 
               $session[user][gold]+=$gold;
               debuglog("found $gold gold on a dead Leprechaun`0"); 
               break; 
            case 3: 
               output("You found a friendly `2Ferret `&and go on your way.");
               break; 
            case 4:
               output("You found a `2Skunk`&, who spray's you and runs away!");
               $session[user][charm]-=5;
               $session[user][clean]+=2;
               break;
            case 5: 
               output("You find a `2Gopher`&, unintentionally step on his tail, he bites you and runs away!"); 
               $session[user][hitpoints]-=5; 
               break; 
            case 6:
               output("You found a `2stray cat `&and go on your way.!"); 
               break;
            case 7:
               output("You found a `2stray dog `&and go on your way."); 
               break;
            case 8:
               output("You find a `2Large St Bernard`&, you look into his collar keg and find a Gem!");
               $session[user][gems]++;
               debuglog("found `^1 gem `0in something furry");
               break;
        }
    }else{ 
      output("`n`n`2You find that a `&Skunk `2has been attracted by your odorous fumes.`n "); 
      output("It rubs your leg amorously! Not very charming, is it?"); 
      output("`n`nMakes you wonder, Do you really smell that bad?");
      $session[user][charm]--; 
      $session[user][clean]++;
    }
}else{ 
      output("`n`n`\$Afraid? `^...NO not YOU!! `n`2Not wanting to see whatever that furry thing was, you run away scared. ");
//    $session[user][coward]++;
}
?>