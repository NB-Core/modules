<?php

/*************************************************
This is partially based on the D&D druid in that it summons monsters, can heal, and can change
shape. It wasn't until after I made it that I actually went out and looked for specialties that
other people had made, and then found a D&D-based druid. So, just take whichever one you like best,
or just give mine a different name or something. I don't really care what you do with it.
*************************************************/

function specialtydruid_getmoduleinfo(){
    $info = array(
        "name" => "Specialty - Druidic Powers",
        "author" => "`6Admin Lexington",
        "version" => "1.0",
        "category" => "Specialties",
        "download"=>"By Request",
        "settings"=> array(
            "Specialty - Druid Settings,title",
            "mindk"=>"How many DKs do you need before the specialty is available?,int|0",
            "cost"=>"How many points do you need before the specialty is available?,int|0",
      ),
      "prefs" => array(
            "Specialty - Druid  User Prefs,title",
            "skill"=>"Skill points in Druid,int|0",
            "uses"=>"Uses of Druid allowed,int|0",
        ),
    );
    return $info;
}

function specialtydruid_install(){
    module_addhook("choose-specialty");
    module_addhook("set-specialty");
    module_addhook("fightnav-specialties");
    module_addhook("apply-specialties");
    module_addhook("newday");
    module_addhook("incrementspecialty");
    module_addhook("specialtynames");
    module_addhook("specialtycolor");
    module_addhook("specialtymodules");
    module_addhook("dragonkill");
    module_addhook("pointsdesc");
    module_addhook("newday");
    return true;
}

function specialtydruid_uninstall(){
    // Reset the specialty of anyone who had this specialty so they get to
    // rechoose at new day
    $sql = "UPDATE " . db_prefix("accounts") . " SET specialty='' WHERE specialty='DR'";
    db_query($sql);
    return true;
}

function specialtydruid_dohook($hookname,$args){
    global $session,$resline;
    tlschema("fightnav");

    $spec = "DR";
    $name = "Druidic";
    $ccode = "`2";
    $cost = get_module_setting("cost");

    switch ($hookname) {

    case "pointsdesc":
        $args['count']++;
        $format = $args['format'];
        $str = translate("The Druid  Specialty is availiable upon reaching %s Dragon Kills and %s points.");
        $str = sprintf($str, get_module_setting("mindk"), $cost);
        output($format, $str, true);
        break;

    case "newday":
        $bonus = getsetting("specialtybonus", 1);

        if($session['user']['specialty'] == $spec) {
            if ($bonus == 1) {
                output("`n`3For being interested in %s%s`3, you gain `^1`3 extra use of `&%s%s`3 for today.`n",$ccode,$name,$ccode,$name);
            }

            else {
                output("`n`3For being interested in %s%s`3, you gain `^%s`3 extra uses of `&%s%s`3 for today.`n",$ccode,$name,$bonus,$ccode,$name);
            }
        }

        $amt = (int)(get_module_pref("skill") / 3);
        if ($session['user']['specialty'] == $spec) $amt++;
        set_module_pref("uses", $amt);
        break;

    case "dragonkill":
        set_module_pref("uses", 0);
        set_module_pref("skill", 0);
    break;

    case "choose-specialty":
        if ($session['user']['specialty'] == "" || $session['user']['specialty'] == '0') {
            $pointsavailable = $session['user']['donation'] - $session['user']['donationspent'];
            if ($session['user']['dragonkills'] < get_module_setting("mindk") || get_module_setting("cost") > $pointsavailable) break;
            addnav("$ccode$name`0","newday.php?setspecialty=".$spec."$resline");
            $t1 = translate_inline("The Druids are masters of nature and all of its elements.");
            $t2 = appoencode(translate_inline("$ccode$name`0"));
            rawoutput("<a href='newday.php?setspecialty=$spec$resline'>$t1 ($t2)</a><br>");
            addnav("","newday.php?setspecialty=$spec$resline");
        }
        break;

    case "set-specialty":
        if($session['user']['specialty'] == $spec) {
            page_header($name);
            $session['user']['donationspent'] = $session['user']['donationspent'] - $cost;
            output("`2All manner of folk have stories of the forest guardians known as Druids.");
            output(" Few there are who are willing to chance angering the druids while within the borders of their forests.");
            output(" But still, there are those who think they may be strong enough to try.");
            output(" And those are the ones who are never seen again.");
            output(" After showing that you were willing, and eager, to learn their ways, you were accepted into their order.");
        }
    break;

    case "specialtycolor":
        $args[$spec] = $ccode;
    break;

    case "specialtynames":
        $pointsavailable = $session['user']['donation'] - $session['user']['donationspent'];
        if ($session['user']['superuser'] & SU_EDIT_USERS || $session['user']['dragonkills'] >= get_module_setting("mindk") || get_module_setting("cost") <= $pointsavailable){
            $args[$spec] = translate_inline($name);
        }
    break;

    case "specialtymodules":
        $args[$spec] = "specialtydruid";
    break;

    case "incrementspecialty":
        if($session['user']['specialty'] == $spec) {
            $new = get_module_pref("skill") + 1;
            set_module_pref("skill", $new);
            $c = $args['color'];
            output("`n%sYou gain a level in `&%s%s to `#%s%s!", $c, $name, $c, $new, $c);
            $x = $new % 3;

            if ($x == 0) {
                output("`n`^You gain an extra use point!`n");
                set_module_pref("uses", get_module_pref("uses") + 1);
            }

            else {
                if (3-$x == 1) {
                    output("`n`^Only 1 more skill level until you gain an extra use point!`n");
                }

                else {
                    output("`n`^Only %s more skill levels until you gain an extra use point!`n", (3-$x));
                }
            }
            output_notl("`0");
        }
        break;

    case "fightnav-specialties":
        $uses = get_module_pref("uses");
        $script = $args['script'];

        if ($uses > 0) {
            addnav(array("$ccode$name (%s points)`0", $uses), "");
            addnav(array("$ccode &#149; Healing Herbs`7 (%s)`0", 1),
            $script."op=fight&skill=$spec&l=1", true);
        }

        if ($uses > 1) {
            addnav(array("$ccode &#149; Summon Wolves`7 (%s)`0", 2),
            $script."op=fight&skill=$spec&l=2",true);
        }

        if ($uses > 2) {
            addnav(array("$ccode &#149; Elemental Magic`7 (%s)`0", 3),
            $script."op=fight&skill=$spec&l=3",true);
        }

        if ($uses > 4) {
            addnav(array("$ccode &#149; Shapechange`7 (%s)`0", 5), $script."op=fight&skill=$spec&l=5",true);
        }
        break;

    case "apply-specialties":
        $skill = httpget('skill');
        $l = httpget('l');

        if ($skill==$spec){
            if (get_module_pref("uses") >= $l){
                switch($l){
                    case 1:
                        apply_buff('dr1',
                            array(
                                "startmsg"=>"`2Pulling out one of your many pouches, you withdraw the herbs that you know to have healing properties.",
                                "name"=>"`2Healing Herbs",
                                "rounds"=>5,
                                "wearoff"=>"You put the healing herbs away and focus once more on fighting.",
                                "regen"=>round($session['user']['level']*1.5),
                                "effectmsg"=>"`2You manage to heal yourself for `^{damage}`2.",
                                "effectnodmgmsg"=>"You have no wounds to tend with your herbs.",
                                "schema"=>"specialtydruid"
                            )
                        );
                        break;

                    case 2:
                        apply_buff('dr2',
                            array(
                                "startmsg"=>"`2You call out to the most powerful protectors of the woodlands.",
                                "name"=>"`2Summon Wolves",
                                "rounds"=>round($session['user']['level']/3,0)+3,
                                "wearoff"=>"`2The wolves howl before disappearing into the woods.",
                                "minioncount"=>round($session['user']['level']/3,0)+1,
                                "maxbadguydamage"=>round($session['user']['level']/2,0)+3,
                                "effectmsg"=>"`2A wolf bits the {badguy}`2 for `^{damage}`2 damage.",
                                "effectnodmgmsg"=>"`2A wolf tries to bite the {badguy}`2 but `\$MISS`2!",
                                "schema"=>"specialtydruid"
                            )
                        );
                        break;

                    case 3:
                        apply_buff('dr3'
                            ,array(
                                "startmsg"=>"`2You call upon the magical powers of the world itself, hurling them at your enemies!",
                                "name"=>"`2Elemental Magic",
                                "rounds"=>5,
                                "wearoff"=>"`2You return the elemental powers to the forest that grants them to you, with a prayer of thanks.",
                                "minioncount"=>1,
                                "minbadguydamage"=>round($session['user']['level']/2,0)+1,
                                "maxbadguydamage"=>round($session['user']['level']*1.5),
                                "effectmsg"=>"`A swirling sphere of `\$fire`2, `!ice`2, `#air`2, and `^earth `2strikes the {badguy}`2 for `^{damage}`2 damage.",
                                "effectnodmgmsg"=>"`2The {badguy} `2manages to dodge the elemental sphere!",
                                "schema"=>"specialtydruid"
                            )
                        );
                    break;

                    case 5:
                        apply_buff('dr5'
                            ,array(
                                "startmsg"=>"`2Calling upon the strongest of your Druidic magics, you yourself take on the form of an powerful beast!",
                                "name"=>"`2Shapechange",
                                "rounds"=>round($session['user']['level']*1.5)+10,
                                "wearoff"=>"`2Unable to keep such powerful magic held within your body, you release it back to the earth.",
                                "lifetap"=>.5,
                                "atkmod"=>round($session['user']['level']/5)+1,
                                "roundmsg"=>"`2You dig your claws deep into the {badguy}'s body, and clench your powerful jaws tightly into their throat!",
                                "schema"=>"specialtydruid"
                            )
                        );
                    break;
                }

                set_module_pref("uses", get_module_pref("uses") - $l);
            }

            else {
                apply_buff('dr0',
                    array(
                        "startmsg"=>"You can not feel the power of Nature swelling inside your stomach...or maybe that's just gas...",
                        "rounds"=>1,
                        "schema"=>"specialtydruid"
                    )
                );
            }
        }
        break;
    }
    return $args;
}

function specialtydruid_run() {
}
?>