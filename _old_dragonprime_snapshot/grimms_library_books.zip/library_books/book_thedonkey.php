<?php
//Hooked into Library Card system
function book_thedonkey_getmoduleinfo(){
	$info = array(
		"name"=>"The Donkey",
		"author"=>"Lonny Luberts - based on Script by WebPixie.",
		"version"=>"1.0",
		"category"=>"Library",
		"download"=>"",
		"prefs" => array(
			"bookread" => "Has the player read this book?, bool|false",
		),
	);
	return $info;
}

function book_thedonkey_install(){
	if (!is_module_installed("library")) {
         output("This module requires the Library module to be installed.");
         return false;
      }
	module_addhook("library");
	return true;
}

function book_thedonkey_uninstall(){
	return true;
}

function book_thedonkey_dohook($hookname, $args){
	global $session;
	$card = get_module_pref("card","library");
	switch($hookname){
	case "library":
	if ($card==1){
			addnav("Grimms Fairy Tales");
			addnav("The Donkey", "runmodule.php?module=book_thedonkey");
		break;
	}
	}
	return $args;
}

function book_thedonkey_run(){
	global $session;
	$op = httpget('op');
	page_header("Town Library");
	output("`#`c`bThe Donkey`b`c`n");
	output("`!`cWritten by The Brothers Grimm`c`n`n");
	output("Once upon a time there lived a king and a queen, who were rich, and had everything they wanted, but no children. The queen lamented over this day and night, and said, I am like a field on which nothing grows. At last God gave her her wish, but when the child came into the world, it did not look like a human child, but was a little donkey. When the mother saw that, her lamentations and outcries began in real earnest. She said she would far rather have had no child at all than have a donkey, and that they were to throw it into the water that the fishes might devour it. But the king said, no, since God has sent him he shall be my son and heir, and after my death sit on the royal throne, and wear the kingly crown. The donkey, therefore, was brought up and grew bigger, and his ears grew up high and straight. And he was of a merry disposition, jumped about, played and took especial pleasure in music, so that he went to a celebrated musician and said, teach me your art, that I may play the lute as well as you do. Ah, dear little master, answered the musician, that would come very hard to you, your fingers are not quite suited to it, and are far too big. I am afraid the strings would not last. But no excuses were of any use. The donkey was determined to play the lute. And since he was persevering and industrious, he at last learnt to do it as well as the master himself. The young lordling once went out walking full of thought and came to a well. He looked into it and in the mirror-clear water saw his donkey's form. He was so distressed about it, that he went out into the wide world and only took with him one faithful companion. They traveled up and down, and at last they came into a kingdom where and old king reigned who had a single but wonderfully beautiful daughter. The donkey said, here we will stay, knocked at the gate, and cried, a guest is without. Open, that he may enter. When the gate was not opened, he sat down, took his lute and played it in the most delightful manner with his two fore-feet. Then the door-keeper opened his eyes, and gaped, and ran to the king and said, outside by the gate sits a young donkey which plays the lute as well as an experienced master. Then let the musician come to me, said the king. But when a donkey came in, everyone began to laugh at the lute-player. And when the donkey was asked to sit down and eat with the servants, he was unwilling, and said, I am no common stable-ass, I am a noble one. Then they said, if that is what you are, seat yourself with the soldiers. No, said he, I will sit by the king. The king smiled, and said good-humoredly, yes, it shall be as you will, little ass, come here to me. Then he asked, little ass, how does my daughter please you. The donkey turned his head towards her, looked at her, nodded and said, I like her above measure, I have never yet seen anyone so beautiful as she is. Well, then, you shall sit next her too, said the king. That is exactly what I wish, said the donkey, and he placed himself by her side, ate and drank, and knew how to behave himself daintily and cleanly. When the noble beast had stayed a long time at the king's court, he thought, what good does all this do me, I shall still have to go home again, let his head hang sadly, and went to the king and asked for his dismissal. But the king had grown fond of him, and said, little ass, what ails you. You look as sour as a jug of vinegar, I will give you what you want. Do you want gold. No, said the donkey, and shook his head. Do you want jewels and rich dress. No. Do you wish for half my kingdom. Indeed, no. Then said the king, if I did but know what would make you content. Will you have my pretty daughter to wife. Ah, yes, said the ass, I should indeed like her, and all at once he became quite merry and full of happiness, for that was exactly what he was wishing for. So a great and splendid wedding was held. In the evening, when the bride and bridegroom were led into their bed-room, the king wanted to know if the ass would behave well, and ordered a servant to hide himself there. When they were both within, the bridegroom bolted the door, looked around, and as he believed that they were quite alone, he suddenly threw off his ass's skin, and stood there in the form of a handsome royal youth. Now, said he, you see who I am, and see also that I am not unworthy of you. Then the bride was glad, and kissed him, and loved him dearly. When morning came, he jumped up, put his animal's skin on again, and no one could have guessed what kind of a form was hidden beneath it. Soon came the old king. Ah, cried he, so the little ass is already up. But surely you are sad, said he to his daughter, that you have not got a proper man for your husband. Oh, no, dear father, I love him as well as if he were the handsomest in the world, and I will keep him as long as I live. The king was surprised, but the servant who had concealed himself came and revealed everything to him. The king said, that cannot be true. Then watch yourself the next night, and you will see it with your own eyes, and hark you, lord king, if you were to take his skin away and throw it in the fire, he would be forced to show himself in his true shape. Your advice is good, said the king, and at night when they were asleep, he stole in, and when he got to the bed he saw by the light of the moon a noble-looking youth lying there, and the skin lay stretched on the ground. So he took it away, and had a great fire lighted outside, and threw the skin into it, and remained by it himself until it was all burnt to ashes. But since he was anxious to know how the robbed man would behave himself, he stayed awake the whole night and watched. When the youth had slept his fill, he got up by the first light of morning, and wanted to put on the ass's skin, but it was not to be found. At this he was alarmed, and, full of grief and anxiety, said, now I shall have to contrive to escape. But when he went out, there stood the king, who said, my son, whither away in such haste. What have you in mind. Stay here, you are such a handsome man, you shall not go away from me. I will now give you half my kingdom, and after my death you shall have the whole of it. Then I hope that what begins so well may end well, and I will stay with you, said the youth. And the old man gave him half the kingdom, and in a year's time, when he died, the youth had the whole, and after the death of his father he had another kingdom as well, and lived in all magnificence.");
	$number = e_rand(1,3);
	if ($number == 3) {
		$session[user][experience]*=1.05;
		output("`n`n`!The book has filled you with wisdom beyond your years!  You gain some Experience!`n");
	}
	    addnav("Return Book to Shelf","runmodule.php?module=library");
	    page_footer();
}
?>