<?php
/*
Module Name:  resets.php
Category:  Administrative
Worktitle:  DK Resets: Align/Gems
Author:  DaveS
Date: April 4, 2006

Description:
Resets Alignment and Gems after a DK

For Alignment, there are 2 choices:
1.  Reset:  Player's alignment is adjusted to the setting
2.  Adjust:  Move the alignment closer to 45 by a percentage of how far away from 45 it is at the dk;
thereby making players closer to neutral with each dk

For Gems:
Players can only keep a certain percentage of gems after a dk

v3.1 Text for during a dragon kill included
*/
function resets_getmoduleinfo(){
	$info = array(
		"name"=>"DK Resets: Align/Gems",
		"category"=>"Administrative",
		"author"=>"DaveS",
		"version"=>"3.1",
		"settings"=>array(
			"DK Resets: Align/Gems - Settings,title",
			"resetalignment"=>"Reset Alignment or Adjust Alignment with DK?,enum,0,Neither,1,Reset,2,Adjust|0",
			"resetalignto"=>"If Reset: Reset alignment to what number?,int|45",
			"improvealign"=>"If Adjust: Percent adjust alignment close to 45 after dk?,range,1,100,1|50",
			"percentgems"=>"Percent Gems kept after DK,range,0,100,1|50",
			),
    );
	return $info;
}
function resets_install(){
	module_addhook("dragonkill");
	return true;
}
function resets_uninstall(){
	return true;
}
function resets_dohook($hookname,$args){
	global $session;
	switch($hookname){
	case "dragonkill":
		if (is_module_active("alignment")){
			if (get_module_setting("resetalignment")==1){
				set_module_pref("alignment",get_module_setting("resetalignto"),"alignment");
			}
			if (get_module_setting("resetalignment")==2){
				$multiply=get_module_setting("improvealign")/100;
				$align=get_module_pref("alignment","alignment");
				if ($align>=45) $newalign=round(($align-45)*(1-($multiply)))+45;
				elseif ($align<45) $newalign=round((45-$align)*(1-($multiply)))+45;
				set_module_pref("alignment",$newalign,"alignment");
			}
		}
		$gems=round($session['user']['gems']*get_module_setting("percentgems")/100);
		$gemlost=$session['user']['gems']-$gems;
		$session['user']['gems']=$gems;
		if (get_module_setting("percentgems")<100 && $gemlost>0) output("``n`@In your disoriented state, you forget to gather all your `%gems`@ together and find that you've lost `%%s `@of them.`n`n",$gemlost);
	break;
	}
	return $args;
}
function resets_run(){
}
?>