<?php

function addimages_getmoduleinfo(){
	$info = array(
		"name"=>"Add Images",
		"version"=>"1.13",
		"author"=>"`#Lonny Luberts",
		"category"=>"PQcomp",
		"download"=>"http://www.pqcomp.com/modules/mydownloads/visit.php?cid=3&lid=29",
		"vertxtloc"=>"http://www.pqcomp.com/",
		"settings"=>array(
			"Add Images Module Settings,title",
			"village-desc"=>"Village Image,bool|0",
			"village-descdrunk"=>"Village Image Drunk,bool|0",
			"dragon"=>"Dragon Image,bool|0",
			"dragondrunk"=>"Dragon Image Drunk,bool|0",
			"forest"=>"Forest Image,bool|0",
			"forestdrunk"=>"Forest Image Drunk,bool|0",
			"gardens"=>"Gardens Image,bool|0",
			"gardensdrunk"=>"Gardens Image Drunk,bool|0",
			"graveyard"=>"Graveyard Image,bool|0",
			"graveyarddrunk"=>"Graveyard Image Drunk,bool|0",
			"gypsy"=>"Gypsy Image,bool|0",
			"gypsydrunk"=>"Gypsy Image Drunk,bool|0",
			"inn-desc"=>"Inn Image,bool|0",
			"inn-descdrunk"=>"Inn Image Drunk,bool|0",
			"lodge"=>"Lodge Image,bool|0",
			"lodgedrunk"=>"Lodge Image Drunk,bool|0",
			"newday"=>"Newday Image,bool|0",
			"newdaydrunk"=>"Newday Image Drunk,bool|0",
			"rock"=>"Rock Image,bool|0",
			"rockdrunk"=>"Rock Image Drunk,bool|0",
			"stables-desc"=>"Stables Image,bool|0",
			"stables-descdrunk"=>"Stables Image Drunk,bool|0",
			"Image File Names:  (Images go in Images folder),note",
			"village-desc.gif & village-descdrunk.gif,note",
			"dragonkill.gif & dragonkilldrunk.gif,note",
			"forestsearch.gif & forestsearchdrunk.gif,note",
			"gardens.gif & gardensdrunk.gif,note",
			"graveyard.gif & graveyarddrunk.gif,note",
			"gypsy.gif & gypsydrunk.gif,note",
			"inn-desc.gif & inn-descdrunk.gif,note",
			"lodge.gif & lodgedrunk.gif,note",
			"newday.gif & newdaydrunk.gif,note",
			"rock.gif & rockdrunk.gif,note",
			"stables-desc.gif & stables-descdrunk.gif,note",
		),
		"prefs"=>array(
			"Add Images Module User Preferences,title",
			"user_addimages"=>"Display Location Images?,bool|1",
		),
	);
	return $info;
}

function addimages_install(){
	if (!is_module_active('addimages')){
		output("`2Installing Add Images Module.`n");
		output("`b`4Be sure to set Image locations from Game Settings!`b`n");
		output("`b`4It is up to you to get and edit your own images!`b`n");
		output("Image Names:`n");
		output("village-desc.gif, village-descdrunk.gif`n");
		output("dragonkill.gif, dragonkilldrunk.gif`n");
		output("forestsearch.gif, forestsearchdrunk.gif`n");
		output("gardens.gif, gardensdrunk.gif`n");
		output("graveyard.gif, graveyarddrunk.gif`n");
		output("gypsy.gif, gypsydrunk.gif`n");
		output("inn-desc.gif, inn-descdrunk.gif`n");
		output("lodge.gif, lodgedrunk.gif`n");
		output("newday.gif, newdaydrunk.gif`n");
		output("rock.gif, rockdrunk.gif`n");
		output("stables-desc.gif, stables-descdrunk.gif`n");
	}
	module_addhook("village-desc");
	module_addhook("dragonkill");
	module_addhook("forestsearch");
	module_addhook("gardens");
	module_addhook("graveyard");
	module_addhook("gypsy");
	module_addhook("inn-desc");
	module_addhook("lodge");
	module_addhook("newday");
	module_addhook("rock");
	module_addhook("stables-desc");
	//bank hook?  armor and weapon hooks?
	return true;
}

function addimages_uninstall(){
		output("`2Un-Installing Add Images Module.`n");
	return true;
}

function addimages_dohook($hookname,$args){
	global $session;
	if (get_module_pref("user_addimages") == 1){
		if (get_module_setting($hookname)){
			if (get_module_pref('drunkeness','drinks') < 50){
				output("`c<IMG SRC=\"images/".$hookname.".gif\">`c<BR>\n",true);
			}else{
				output("`c<IMG SRC=\"images/".$hookname."drunk.gif\">`c<BR>\n",true);	
			}
		}
	}
	return $args;
}
	
?>