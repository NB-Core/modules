<?
if (!isset($session)) exit();

/*
Old Hag Special Forest Event
for Legend of the Green Dragon v0.9.7 +JT
Version 1.0 (08/08/04)
By Gary M. Hartzell

This is my remake of the Old Hag Forest Event from LORD.
Just upload it into your "special" directory.
*/

$hp = $session[user][hitpoints];
$maxhp = $session[user][maxhitpoints];
$halfhp = $hp /2;

if ($HTTP_GET_VARS[op]=="")
{
output("As you are wandering through the forest, an ugly old hag appears before you.`n`n");
output("\"Give me a gem, and I'll make ye feel better,\" she screeches.`n`nDo you give her the gem?");
addnav("Give her a gem","forest.php?op=yes");
addnav("Don't do it","forest.php?op=no");
	$session[user][specialinc]="oldhag.php";
}
else if ($HTTP_GET_VARS[op]=="no")
{
output("\"Humph,\" replies the hag.  She waves her cane before her and vanishes.");
}
else if ($HTTP_GET_VARS[op]=="yes")
{
if ($session[user][gems] < 1)
{
output("\"Ye have no gems, ye lyin' fool!\" the hag screams.  She strikes you between the eyes with her cane and vanishes.");
$session[user][hitpoints] -= $halfhp;
}
else
{
$session[user][gems] --;
if ($session[user][hitpoints] < $maxhp)
{
output("She waves her cane in front of your face, and you feel a surge of energy go through your body`n`nYOU ARE COMPLETELY HEALED!");
$session[user][hitpoints] = $session[user][maxhitpoints];
}
else
{
output("She waves her cane in front of your face, and you feel a surge of energy go through your body`n`nYOU GAIN A MAX HIT POINT!");
$session[user][maxhitpoints]++;
$session[user][hitpoints]++;
}
}
}
?>


  