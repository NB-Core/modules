<?php
//addnews ready
// mail ready
// translator ready
/*

dvd871 released a Psionic Specialty.  This however, is not it.  This is a new
module, but I've retained all his author info, despite the fact that I've
replaced/rewritten the entire module.  It all started with CortalUX's
Ranger module, which was greatly unbalanced.  (Don't get me wrong, I love
most of CortalUX's modules, and there is reason some of them have made it
into the core release.  But the Ranger module was broken.  And when I looked
at how I wanted to rewrite it, it only made sense to create the Ranger along
the lines of the D&D Ranger.  Then I got to thinking, that while LoRD had
a Fighter (Death Knight), Wizard (Magic User), and Rouge (Thief) as it's 3
core classes, LoGD basically has a Rouge/Thief and 2 magic users as it's
core classes.  And next thing you know, I decided to do the 13 core D&D
classes as specialties.  So, this module has been rewritten to create the
Psionicist more in line with the D&D Psionicist.

I'm not trying to take away from dvd871's module.  This version is just
more in line with my preferences.  I'm not trying to get my version in cir-
culation, or replace dvd871's version.  I just have available for download
to be in line with the license.

-- Enderandrew

*/

/******************************************
 Name: Specialty - Psionic Skills
 Ver: 1.0   Date: 12-22-04
 By: dvd871

 ~~ Credits ~~
 Danic
 Based on his Elementalist skill.
******************************************/

function specialtypsionicskills_getmoduleinfo(){
	$info = array(
		"name" => "Specialty - Psionic Skills",
		"author" => "`!Enderandrew<br>original by dvd871",
		"version" => "1.11",
		"description"=>"This will add a D&D inspired Psionic to the game.",
		"download" => "http://dragonprime.net/users/enderwiggin/specialtypsionicskills.zip",
		"vertxtloc"=>"http://dragonprime.net/users/enderwiggin/",
		"category" => "Specialties",
		"settings"=> array(
			"Specialty - Psionic Settings,title",
			"mindk"=>"How many DKs do you need before the specialty is available?,int|0",
			"cost"=>"How many points do you need before the specialty is available?,int|0",
		),
		"prefs" => array(
			"Specialty - Psionic Skills User Prefs,title",
			"skill"=>"Skill points in Psionic Skills,int|0",
			"uses"=>"Uses of Psionic Skills allowed,int|0",
		),
	);
	return $info;
}

function specialtypsionicskills_install(){
	$specialty="PS";
	module_addhook("apply-specialties");
	module_addhook("castlelib");
	module_addhook("castlelibbook");
	module_addhook("choose-specialty");
	module_addhook("dragonkill");
	module_addhook("fightnav-specialties");
	module_addhook("incrementspecialty");
	module_addhook("newday");
	module_addhook("pointsdesc");
	module_addhook("set-specialty");
	module_addhook("specialtycolor");
	module_addhook("specialtymodules");
	module_addhook("specialtynames");
	return true;
}

function specialtypsionicskills_uninstall(){
	// Reset the specialty of anyone who had this specialty so they get to
	// rechoose at new day
	$sql = "UPDATE " . db_prefix("accounts") . " SET specialty='' WHERE specialty='PS'";
	db_query($sql);
	return true;
}

function specialtypsionicskills_dohook($hookname,$args){
	global $session,$resline;
	tlschema("fightnav");

	$spec = "PS";
	$name = "Psionic Powers";
	$ccode = "`@";
	$cost = get_module_setting("cost");
	$op69 = httpget('op69');
		
	switch ($hookname) {
		
	case "apply-specialties":
		$skill = httpget('skill');
		$l = httpget('l');
		if ($skill==$spec){
			if (get_module_pref("uses") >= $l){
				switch($l){
				case 1:
					apply_buff('ps1', array(
						"startmsg"=>"`@You trick {badguy}'s mind into seeing illusionary creatures!",
						"name"=>"`@False Sensory Input",
						"rounds"=>5,
						"wearoff"=>"{badguy} disbelieves in the illusions.",
						"minioncount"=>round(get_module_pref("skill")/3),
						"minbadguydamage"=>round($session['user']['level']/5,0)+1,
						"maxbadguydamage"=>round($session['user']['level']/2,0)+1,
						"effectmsg"=>"`)An illusionary minion hits {badguy}`) for `^{damage}`) damage.",
						"effectnodmgmsg"=>"`)An illusionary minion tries to hit {badguy}`) but `\$MISSES`)!",
						"schema"=>"specialtypsionicskills"
					));
					break;
				case 2:
					apply_buff('ps2', array(
						"startmsg"=>"`@As you attack {badguy}, you drain their will to live and fuel your own psyche!",
						"name"=>"`@Vampiric Blade",
						"rounds"=>5,
						"wearoff"=>"Your weapon's aura fades.",
						"lifetap"=>0.75,
						"effectmsg"=>"You are healed for {damage} health.",
						"effectnodmgmsg"=>"You feel a tingle as your weapon tries to heal your already healthy body.",
						"effectfailmsg"=>"Your weapon and your will both fail to damage your opponent.",
						"schema"=>"specialtypsionicskills"
					));
					break;
				case 3:
					apply_buff('ps3', array(
						"startmsg"=>"`@{badguy}'s Ego is beaten into submission, and it can not attack.",
						"name"=>"`@Ego Whip",
						"rounds"=>3,
						"wearoff"=>"``@{badguy} yelps like a frightened, confused and helpless child.`)",
						"badguyatk"=>0,
						"schema"=>"specialtypsionicskills"
					));
					break;
				case 5:
					apply_buff('ps5', array(
						"startmsg"=>"`@{badguy}'s world turns upside down as you wield godlike power in bending reality!",
						"name"=>"`@Bend Reality",
						"rounds"=>5,
						"atkmod"=>3,
						"defmod"=>3,
						"roundmsg"=>"`@{badguy} has absolutely no clue or defense as it's own mind turns against it!",
						"schema"=>"specialtypsionicskills"
					));
					break;
				}
				set_module_pref("uses", get_module_pref("uses") - $l);
			}else{
				apply_buff('ps0', array(
					"startmsg"=>"`@Damnit!  Brain fart!",
					"rounds"=>1,
					"schema"=>"specialtypsionicskills"
				));
			}
		}
		break;
		
	case "castlelib":
		if ($op69 == 'psionic'){
			output("You sit down and open up a copy of Dianetics.`n");
			output("You read for a while... in the time it takes you to read you use up`n");
			output("3 Turns.`n`n");
			output("What were you thinking?  God, that book was horrible.  Your brain tried crawling out of`n");
			output("your ear.  The only good news, is that to a powerful psychic aestetic, pain is weakness`n");
			output("leaving your body, or in this case, your mind.`n");
			output("`@Your brain seems tougher now, believe it or not!  You gain a Psionic Power point!`n");
			$session['user']['turns']-=3;
			set_module_pref('skill',(get_module_pref('skill','specialtypsionicskills') + 1),'specialtypsionicskills');
			set_module_pref('uses', get_module_pref("uses",'specialtypsionicskills') + 1,'specialtypsionicskills');
			addnav("Continue","runmodule.php?module=lonnycastle&op=library");
			}
		break;
		
	case "castlelibbook":
		output("Dianetics. (3 Turns)`n");
		addnav("Read a Book");
		addnav("Dianetics","runmodule.php?module=lonnycastle&op=library&op69=psionic");
		break;
		
	case "choose-specialty":
		if ($session['user']['dragonkills']>=get_module_setting("mindk")) {
			if ($session['user']['specialty'] == "" ||
				$session['user']['specialty'] == '0') {
				addnav("$ccode$name`0","newday.php?setspecialty=".$spec."$resline");
				$t1 = translate_inline("Practicing Jedi Mind Tricks");
				$t2 = appoencode(translate_inline("$ccode$name`0"));
				rawoutput("<a href='newday.php?setspecialty=$spec$resline'>$t1 ($t2)</a><br>");
				addnav("","newday.php?setspecialty=$spec$resline");
			}
		}
		break;
		
	case "dragonkill":
		set_module_pref("uses", 0);
		set_module_pref("skill", 0);
		break;
		
	case "fightnav-specialties":
		$uses = get_module_pref("uses");
		$script = $args['script'];
		if ($uses > 0) {
			addnav(array("%s%s (%s points)`0", $ccode, $name, $uses), "");
			addnav(array("%s &#149; False Sensory Input`7 (%s)`0", $ccode, 1), 
					$script."op=fight&skill=$spec&l=1", true);
		}
		if ($uses > 1) {
			addnav(array("%s &#149; Vampiric Blade`7 (%s)`0", $ccode, 2),
					$script."op=fight&skill=$spec&l=2",true);
		}
		if ($uses > 2) {
			addnav(array("%s &#149; Ego Whip`7 (%s)`0", $ccode, 3),
					$script."op=fight&skill=$spec&l=3",true);
		}
		if ($uses > 4) {
			addnav(array("%s &#149; Bend Reality`7 (%s)`0", $ccode, 5),
					$script."op=fight&skill=$spec&l=5",true);
		}
		break;
		
	case "incrementspecialty":
		if($session['user']['specialty'] == $spec) {
			$new = get_module_pref("skill") + 1;
			set_module_pref("skill", $new);
			$c = $args['color'];
			output("`n%sYou gain a level in `&%s%s to `#%s%s!",
					$c, $name, $c, $new, $c);
			$x = $new % 3;
			if ($x == 0){
				output("`n`^You gain an extra use point!`n");
				set_module_pref("uses", get_module_pref("uses") + 1);
			}else{
				if (3-$x == 1) {
					output("`n`^Only 1 more skill level until you gain an extra use point!`n");
				} else {
					output("`n`^Only %s more skill levels until you gain an extra use point!`n", (3-$x));
				}
			}
			output_notl("`0");
		}
		break;
		
	case "newday":
		$bonus = getsetting("specialtybonus", 1);
		if($session['user']['specialty'] == $spec) {
			if ($bonus == 1) {
				output("`n`2For being interested in %s%s`2, you receive `^1`2 extra `&%s%s`2 use for today.`n",$ccode,$name,$ccode,$name);
			} else {
				output("`n`2For being interested in %s%s`2, you receive `^%s`2 extra `&%s%s`2 uses for today.`n",$ccode,$name,$bonus,$ccode,$name);
			}
		}
		$amt = (int)(get_module_pref("skill") / 3);
		if ($session['user']['specialty'] == $spec) $amt++;
		set_module_pref("uses", $amt);
		break;
		
	case "pointsdesc":
		$cost = get_module_setting("cost");
		if ($cost > 0){
			$args['count']++;
			$format = $args['format'];
			$str = translate("The Psionic Specialty is availiable upon reaching %s Dragon Kills and %s points.");
			$str = sprintf($str, get_module_setting("mindk"),$cost);
		}
		output($format, $str, true);
		break;
		
	case "set-specialty":
		if($session['user']['specialty'] == $spec) {
			page_header($name);
			$session['user']['donationspent'] = $session['user']['donationspent'] + $cost;
			output("`@Being a psionicist requires the utmost discipline.  The training is mentally, physically, and emotionally rigorous. ");
			output("Yet despite all that, you somehow made it through anyway.  You now possess great mental powers. .");
			output("Telekinesis alone could serve you well for the rest of your life, however you must be disciplined and not overtly demonstrate your awesome powers. ");
			output("If you continually remind everyone of your little mental tricks, why then you'd be blamed for everything under the sun before you know it. ");
			output("Yep, it stinks.  You have all these amazing powers, and everyone is jealous.  Of course, that means you have to prove your virtue and honor now by slaying that stupid dragon.");
			output("With your superior skills, it should be easy, right?`n`n");
		}
		break;
		
	case "specialtycolor":
		$args[$spec] = $ccode;
		break;
		
	case "specialtymodules":
		$args[$spec] = "specialtypsionicskills";
		break;
		
	case "specialtynames":
		$pointsavailable = $session['user']['donation'] - $session['user']['donationspent'];
		if ($session['user']['superuser'] & SU_EDIT_USERS || $session['user']['dragonkills'] >= get_module_setting("mindk") || get_module_setting("cost") <= $pointsavailable){
			$args[$spec] = translate_inline($name);
		}
		break;
	}
	return $args;
}

function specialtypsionic_run(){
}
?>