<?php
function santanpc_getmoduleinfo(){
	$info = array(
		"name"=>"NPC Characters - Santa",
		"version"=>"1.1",
		"author"=>"WebPixie, template by Lonny Luberts",
		"category"=>"NPCs",
		"download"=>"http://dragonprime.net/users/WebPixie/santanpc98.zip",
		"settings"=>array(
			"NPC Characters - Santa Module Settings,title",
			"npcloc"=>"Where does Santa Hang Out?,location|".getsetting("villagename", LOCATION_FIELDS),
			"howmuch"=>"How much does Santa say?,enum,1500,A Lot,2000,Quite a Bit,2500,Less,3000,Seldom",
			"comment1"=>"Custom commentary 1,text|HoHoHo, Merry Christmas!.",
			"comment2"=>"Custom commentary 2,text|On Doner, On Dancer, On Comit....",
			"comment3"=>"Custom commentary 3,text|Anyone seens my naughty list around here?",
			"npcid"=>"NPC User id,int",
		),
	);
	return $info;
}

function santanpc_install(){
	$password=$_POST['pw'];
	if (!is_module_active('santanpc')){
		output("`4Installing NPC Characters - Santa Module.`n");
		if ($password){
		$sqlz = "INSERT INTO ".db_prefix("accounts")." (login,name,sex,specialty,level,defense,attack,alive,laston,hitpoints,maxhitpoints,gems,password,emailvalidation,title,weapon,armor,race) VALUES ('santanpc','`\$Santa Clause','0','2','15','1000','1000','1','".date("Y-m-d H:i:s")."','1000','1000','10','".md5(md5("$password"))."','','`0Jolly Ol\'e','`#Candy Cane','`!Red Suit','Human')";
		db_query($sqlz) or die(db_error(LINK));
			if (db_affected_rows(LINK)>0){
				output("`2Installed Santa!`n");
			}else{
				output("`4Santa install failed!`n");
			}
			$sqlz = "SELECT acctid FROM ".db_prefix("accounts")." where login = 'santanpc'";
			$resultz = db_query($sqlz) or die(db_error(LINK));
			$rowz = db_fetch_assoc($resultz);
			if ($rowz['acctid'] > 0){
				set_module_setting("npcid",$rowz['acctid']);
				output("`2Set Accout ID for Santa to ".$rowz['acctid'].".`n");
			}else{
				output("`4Failed to Set Account ID for Santa!`n");
			}
		}else{
			output("Santa's Login will be santanpc.`n");
			output("What would you like the password for Santa account to be?`n");
			$linkcode="<form action='modules.php?op=install&module=santanpc' method='POST'>";
			output("%s",$linkcode,true);
			$linkcode="<p><input type=\"text\" name=\"pw\" size=\"37\"></p>";
			output("%s",$linkcode,true);
			$linkcode="<p><input type=\"submit\" value=\"Submit\" name=\"B1\"><input type=\"reset\" value=\"Reset\" name=\"B2\"></p>";
			output("%s",$linkcode,true);
			$linkcode="</form>";
			output("%s",$linkcode,true);
			addnav("","modules.php?op=install&module=santanpc");
		}
	}else{
		output("`4Updating NPC Characters - Santa Module.`n");
	}
	module_addhook("village");
	return true;
}

function santanpc_uninstall(){
	output("`4Un-Installing NPC Characters - Santa Module.`n");
	$sqlz = "DELETE FROM ".db_prefix("accounts")." where acctid='".get_module_setting('npcid')."'";
	db_query($sqlz) or die(db_error(LINK));
	output("Santa deleted.`n");
	return true;
}

function santanpc_dohook($hookname,$args){
	global $session,$texts;
			$sqlz = "SELECT acctid,laston,maxhitpoints,sex,name,location FROM ".db_prefix("accounts")." WHERE acctid = '".get_module_setting('npcid')."' LIMIT 1";
			$resultz = db_query($sqlz) or die(db_error(LINK));
			$rowz = db_fetch_assoc($resultz);
			if ($rowz['laston'] < date("Y-m-d H:i:s")){
				if (is_module_active('whoshere')){
					set_module_pref('playerloc',"village.php",'whoshere',get_module_setting('npcid'));
				}
				$sqlz2="UPDATE ".db_prefix("accounts")." SET laston = '".date("Y-m-d H:i:s",strtotime("+ 300 seconds"))."', alive = '1', loggedin = '1', lasthit = '".date("Y-m-d H:i:s",strtotime("+ 300 seconds"))."', location = '".get_module_setting('npcloc')."', hitpoints = '".$rowz['maxhitpoints']."' WHERE acctid = '".get_module_setting('npcid')."'";
				db_query($sqlz2) or die(db_error(LINK));
				$sqlz3 = "DELETE FROM ".db_prefix("mail")." WHERE msgto='".get_module_setting('npcid')."'";
				db_query($sqlz3) or die(db_error(LINK));
			}
			if (e_rand(1,get_module_setting('howmuch')) < 21 and get_module_setting('npcloc') == $session['user']['location']){
				$smile=e_rand(1,20);
				if ($smile==1) $smile="*grin*";
				if ($smile==2) $smile="*happy*";
				if ($smile==3) $smile="*laugh*";
				if ($smile==4) $smile="*wink*";
				if ($smile==5) $smile="*slimer*";
				if ($smile==6) $smile="*biggrin*";
				if ($smile==7) $smile="*tongue*";
				if ($smile==8) $smile="*wink2*";
				if ($smile==9) $smile="*wink3*";
				if ($smile>9) $smile="";
				$tname = $session['user']['name'];
			switch(e_rand(1,51)){
			case 1:
			case 2:
			$sqlz3 ="INSERT INTO ".db_prefix("commentary")." (postdate,section,author,comment) VALUES (now(),'".$texts['section']."','".get_module_setting('npcid')."',\"".get_module_setting('comment1')."\")";
			break;
			case 3:
			case 4:
			$sqlz3 ="INSERT INTO ".db_prefix("commentary")." (postdate,section,author,comment) VALUES (now(),'".$texts['section']."','".get_module_setting('npcid')."',\"".get_module_setting('comment2')."\")";
			break;
			case 5:
			case 6:
			$sqlz3 ="INSERT INTO ".db_prefix("commentary")." (postdate,section,author,comment) VALUES (now(),'".$texts['section']."','".get_module_setting('npcid')."',\"".get_module_setting('comment3')."\")";
			break;
			case 7:
			$sqlz3 ="INSERT INTO ".db_prefix("commentary")." (postdate,section,author,comment) VALUES (now(),'".$texts['section']."','".get_module_setting('npcid')."',\"Merry Christmas everyone! $smile \")";
			break;
			case 8:
			$sqlz3 ="INSERT INTO ".db_prefix("commentary")." (postdate,section,author,comment) VALUES (now(),'".$texts['section']."','".get_module_setting('npcid')."',\"Have you been good? *biggrin*\")";
			break;
			case 9:
			if (is_module_active('weather')){
			$sqlz3 ="INSERT INTO ".db_prefix("commentary")." (postdate,section,author,comment) VALUES (now(),'".$texts['section']."','".get_module_setting('npcid')."',\"Looks like it might snow. I see it's ".get_module_setting('weather','weather')." *biggrin*\")";
			}
			break;
			case 10:
			if (is_module_active('lonnycastle')){
			$sqlz4 = "SELECT name,acctid,value FROM ".db_prefix("accounts")." LEFT JOIN ".db_prefix("module_userprefs")." ON (acctid = userid) WHERE modulename = 'lonnycastle' and setting = 'evil' ORDER BY RAND(".e_rand().") LIMIT 1";
			$resultz4 = db_query($sqlz4);
		    $rowz4 = db_fetch_assoc($resultz4);
			$tname = $rowz4['name'];
			if ($rowz4['value']>=33) $evil="Naughty";
			if ($rowz4['value']<33 and $rowz4['value']>-32) $evil="Nice";
			if ($rowz4['value']<=-32) $evil="Nice";
			addnews("%s `7has added %s to his %s list.",$rowz['name'],$tname,$evil);
			$sqlz3 ="INSERT INTO ".db_prefix("commentary")." (postdate,section,author,comment) VALUES (now(),'".$texts['section']."','".get_module_setting('npcid')."',\"\":: has added $tname to his $evil list. \")";
			}
			break;
			case 11:
			if (is_module_active('jobs')){
			$sqlz4 = "SELECT name,value FROM ".db_prefix("accounts")." LEFT JOIN ".db_prefix("module_userprefs")." ON (acctid = userid) WHERE modulename = 'jobs' and setting = 'job' ORDER BY RAND(".e_rand().") LIMIT 1";
			$resultz4 = db_query($sqlz4);
		    $rowz4 = db_fetch_assoc($resultz4);
			$tname = $rowz4['name'];
			if ($rowz4['value']==0) $job="Slacker";	
			if ($rowz4['value']==1) $job="Farmer";
			if ($rowz4['value']==2) $job="Miller";
			if ($rowz4['value']==3) $job="Textile Miller";
			if ($rowz4['value']==4) $job="Brewer";
			if ($rowz4['value']==5) $job="Foundry Worker";
			if ($rowz4['value']==6) $job="Farm Manager";
			if ($rowz4['value']==7) $job="Mill Manager";
			if ($rowz4['value']==8) $job="Textile Mill Manager";
			if ($rowz4['value']==9) $job="Brewery Manager";
			if ($rowz4['value']==10) $job="Foundry Manager";
			$sqlz3 ="INSERT INTO ".db_prefix("commentary")." (postdate,section,author,comment) VALUES (now(),'".$texts['section']."','".get_module_setting('npcid')."',\"I hear that $tname is a $job. Maybe he needs something special this Christmas. *wink*\")";
			}
			break;
			case 12:
			$sqlz4 = "SELECT name,charm FROM ".db_prefix("accounts")." ORDER BY RAND(".e_rand().") LIMIT 1";
			$resultz4 = db_query($sqlz4);
		    $rowz4 = db_fetch_assoc($resultz4);
			$tname = $rowz4['name'];
			if ($rowz4['charm'] > -1 and $rowz4['charm'] < 4) $charm="pretty darn ugly";
			if ($rowz4['charm'] > 3 and $rowz4['charm'] < 7) $charm="ugly";
			if ($rowz4['charm'] > 6 and $rowz4['charm'] < 11) $charm="average";
			if ($rowz4['charm'] > 10 and $rowz4['charm'] < 14) $charm="cute";
			if ($rowz4['charm'] > 13 and $rowz4['charm'] < 17) $charm="looking good";
			if ($rowz4['charm'] > 16 and $rowz4['charm'] < 20) $charm="Beautiful";
			if ($rowz4['charm'] > 19 and $rowz4['charm'] < 23) $charm="Hot`n";
			if ($rowz4['charm'] > 22 and $rowz4['charm'] < 27) $charm="Smokin' Hot";
			if ($rowz4['charm'] > 26 and $rowz4['charm'] < 30) $charm="Dreamy";
			if ($rowz4['charm'] > 29) $charm="one of the fairest in the land";
			$sqlz3 ="INSERT INTO ".db_prefix("commentary")." (postdate,section,author,comment) VALUES (now(),'".$texts['section']."','".get_module_setting('npcid')."',\"I hear that $tname is $charm. Even Santa notices these things. *wink2*\")";
			break;
			case 13:
			if (is_module_active('garlandstable')){
			$sqlz3 ="INSERT INTO ".db_prefix("commentary")." (postdate,section,author,comment) VALUES (now(),'".$texts['section']."','".get_module_setting('npcid')."',\"I hear that Garland's Stables might have reindeer for sale. I should go check. $smile \")";
			}
			break;
			case 14:
			if (is_module_active('lonnycastle')){
			$sqlz3 ="INSERT INTO ".db_prefix("commentary")." (postdate,section,author,comment) VALUES (now(),'".$texts['section']."','".get_module_setting('npcid')."',\"Anyone been to".get_module_setting('lonnycastle','castleloc')." Castle? Seems a bit naughty in there. $smile \")";
			}
			break;
			case 15:
			if (is_module_active('voodoopriestess')){
			$sqlz3 ="INSERT INTO ".db_prefix("commentary")." (postdate,section,author,comment) VALUES (now(),'".$texts['section']."','".get_module_setting('npcid')."',\"That Voodoo Priestess is getting coal this Christmas. Cursing all those people is naughty! $smile \")";
			}
			break;
			case 16:
			if (is_module_active('potions')){
			$sqlz3 ="INSERT INTO ".db_prefix("commentary")." (postdate,section,author,comment) VALUES (now(),'".$texts['section']."','".get_module_setting('npcid')."',\"The Village Healer needs more potions this Christmas, she keeps selling hers. $smile \")";
			}
			break;
			case 17:
			if (is_module_active('vesa')){
			$sqlz3 ="INSERT INTO ".db_prefix("commentary")." (postdate,section,author,comment) VALUES (now(),'".$texts['section']."','".get_module_setting('npcid')."',\"Visit the Gem store this year, girls just love gems as presents. $smile \")";
			}
			break;
			case 18:
			if (is_module_active('petra')){
			$sqlz3 ="INSERT INTO ".db_prefix("commentary")." (postdate,section,author,comment) VALUES (now(),'".$texts['section']."','".get_module_setting('npcid')."',\"Do you think Petra will do a tattoo or a reindeer for me? $smile \")";
			}
			break;
			case 19:
			if (is_module_active('pqgiftshop')){
			$sqlz3 ="INSERT INTO ".db_prefix("commentary")." (postdate,section,author,comment) VALUES (now(),'".$texts['section']."','".get_module_setting('npcid')."',\"Make sure to visit the giftshop it's almost Christmas! $smile \")";
			}
			break;
			case 20:
			if (is_module_active('trading')){
			$sqlz3 ="INSERT INTO ".db_prefix("commentary")." (postdate,section,author,comment) VALUES (now(),'".$texts['section']."','".get_module_setting('npcid')."',\"Earn Gems and Gold trading at the various Trading Posts. Then you can buy lots of presents for folks. $smile \")";
			}
			break;
			case 21:
			$sqlz3 ="INSERT INTO ".db_prefix("commentary")." (postdate,section,author,comment) VALUES (now(),'".$texts['section']."','".get_module_setting('npcid')."',\":: laughs and his belly shakes like a bowl full of jelly. $smile \")";
			break;
			case 22:
			$sqlz3 ="INSERT INTO ".db_prefix("commentary")." (postdate,section,author,comment) VALUES (now(),'".$texts['section']."','".get_module_setting('npcid')."',\":: writes on his been naughty list. $smile \")";
			break;
			case 23:
			$sqlz3 ="INSERT INTO ".db_prefix("commentary")." (postdate,section,author,comment) VALUES (now(),'".$texts['section']."','".get_module_setting('npcid')."',\":: tickles $tname $smile \")";
			break;
			case 24:
			$sqlz3 ="INSERT INTO ".db_prefix("commentary")." (postdate,section,author,comment) VALUES (now(),'".$texts['section']."','".get_module_setting('npcid')."',\":: wishes ".($rowz[sex]?"she":"he")." had a bigger sled.$smile \")";
			break;
			case 25:
			$sqlz3 ="INSERT INTO ".db_prefix("commentary")." (postdate,section,author,comment) VALUES (now(),'".$texts['section']."','".get_module_setting('npcid')."',\"What do you want for Christmas? $smile \")";
			break;
			case 26:
			$sqlz3 ="INSERT INTO ".db_prefix("commentary")." (postdate,section,author,comment) VALUES (now(),'".$texts['section']."','".get_module_setting('npcid')."',\"Have you been good this year? $smile \")";
			break;
			case 27:
			$sqlz3 ="INSERT INTO ".db_prefix("commentary")." (postdate,section,author,comment) VALUES (now(),'".$texts['section']."','".get_module_setting('npcid')."',\"So little time...so many presents. $smile \")";
			break;
			case 28:
			$sqlz3 ="INSERT INTO ".db_prefix("commentary")." (postdate,section,author,comment) VALUES (now(),'".$texts['section']."','".get_module_setting('npcid')."',\"Has anyone seen where I parked my sled? $smile \")";
			break;
			case 29:
			$sqlz3 ="INSERT INTO ".db_prefix("commentary")." (postdate,section,author,comment) VALUES (now(),'".$texts['section']."','".get_module_setting('npcid')."',\"This one time at the North Pole.... $smile \")";
			break;
			case 30:
			$sqlz3 ="INSERT INTO ".db_prefix("commentary")." (postdate,section,author,comment) VALUES (now(),'".$texts['section']."','".get_module_setting('npcid')."',\"I need some egg nog. $smile \")";
			break;
			case 31:
			$tname = $session['user']['name'];
			$sqlz3 ="INSERT INTO ".db_prefix("commentary")." (postdate,section,author,comment) VALUES (now(),'".$texts['section']."','".get_module_setting('npcid')."',\"Have you been naughty or nice $tname? $smile \")";
			break;
			case 32:
			$tname = $session['user']['name'];
			$sqlz3 ="INSERT INTO ".db_prefix("commentary")." (postdate,section,author,comment) VALUES (now(),'".$texts['section']."','".get_module_setting('npcid')."',\"$tname come over here and tell me what you want for Christmas. $smile \")";
			break;
			case 33:
			addnews("%s `7was seen flying over town in a reindeer driven sled. .",$rowz['name']);
			break;
			case 34:
			addnews("%s `7has been spotted taking names for his naughty and nice lists.",$session['user']['name']);
			break;
			case 35:
			addnews("%s `7wishes everyone a Merry Christmas.",$rowz['name']);
			break;
			case 36:
			$sqlz3 ="INSERT INTO ".db_prefix("commentary")." (postdate,section,author,comment) VALUES (now(),'".$texts['section']."','".get_module_setting('npcid')."',\":: smiles $tname. $smile \")";
			break;
			case 37:
			$sqlz3 ="INSERT INTO ".db_prefix("commentary")." (postdate,section,author,comment) VALUES (now(),'".$texts['section']."','".get_module_setting('npcid')."',\":: glances at $tname $smile \")";
			break;
			case 38:
			$sqlz3 ="INSERT INTO ".db_prefix("commentary")." (postdate,section,author,comment) VALUES (now(),'".$texts['section']."','".get_module_setting('npcid')."',\":: Gives $tname `&a candy cane. $smile \")";
			break;
			case 39:
			$sqlz3 ="INSERT INTO ".db_prefix("commentary")." (postdate,section,author,comment) VALUES (now(),'".$texts['section']."','".get_module_setting('npcid')."',\":: puts a I am naughty sign on ".$tname."'s `&back $smile \")";
			break;
			case 40:
			$weap = $session['user']['weapon'];
			$sqlz3 ="INSERT INTO ".db_prefix("commentary")." (postdate,section,author,comment) VALUES (now(),'".$texts['section']."','".get_module_setting('npcid')."',\":: looks at ".$tname."'s $weap and shakes his head. \")";
			break;
			case 41:
			$sqlz3 ="INSERT INTO ".db_prefix("commentary")." (postdate,section,author,comment) VALUES (now(),'".$texts['section']."','".get_module_setting('npcid')."',\"You want a cookie $tname\? $smile \")";
			break;
			case 42:
			$sqlz3 ="INSERT INTO ".db_prefix("commentary")." (postdate,section,author,comment) VALUES (now(),'".$texts['section']."','".get_module_setting('npcid')."',\"Do you smell reindeer poop?  Oh it's just $tname\. $smile \")";
			break;
			case 43:
			$sqlz3 ="INSERT INTO ".db_prefix("commentary")." (postdate,section,author,comment) VALUES (now(),'".$texts['section']."','".get_module_setting('npcid')."',\"$tname may look like he doesn't believe in me but don't let that fool you. ".($session[user][sex]?"She":"He")." sends me a list every year. $smile \")";
			break;
			case 44:
			$sqlz3 ="INSERT INTO ".db_prefix("commentary")." (postdate,section,author,comment) VALUES (now(),'".$texts['section']."','".get_module_setting('npcid')."',\"$tname  Are you sure you really want socks for Christmas? Thats whats on my list. $smile \")";
			break;
			case 45:
			$sqlz3 ="INSERT INTO ".db_prefix("commentary")." (postdate,section,author,comment) VALUES (now(),'".$texts['section']."','".get_module_setting('npcid')."',\"$tname  Don't get run over by a reindeer walking home from grandmas Christmas eve. $smile \")";
			break;
			case 46:
			$sqlz3 ="INSERT INTO ".db_prefix("commentary")." (postdate,section,author,comment) VALUES (now(),'".$texts['section']."','".get_module_setting('npcid')."',\"$tname  doesn't know the meaning of the word jolly - but then again ".($session[user][sex]?"she":"he")." doesn't know the meaning of most words. $smile \")";
			break;
			case 47:
			$sqlz3 ="INSERT INTO ".db_prefix("commentary")." (postdate,section,author,comment) VALUES (now(),'".$texts['section']."','".get_module_setting('npcid')."',\"$tname  I just got your Christmas list. Might want to rethink it a bit, try to keep it under 50 presents. $smile \")";
			break;
			case 48:
			$sqlz3 ="INSERT INTO ".db_prefix("commentary")." (postdate,section,author,comment) VALUES (now(),'".$texts['section']."','".get_module_setting('npcid')."',\"Hey $tname do you still love Christmas, despite the fact that I'm bringing you coal this year? $smile \")";
			break;
			case 49:
			$sqlz3 ="INSERT INTO ".db_prefix("commentary")." (postdate,section,author,comment) VALUES (now(),'".$texts['section']."','".get_module_setting('npcid')."',\"Hey $tname is a snowman hugger!  $smile \")";
			break;
			case 50:
			$sqlz3 ="INSERT INTO ".db_prefix("commentary")." (postdate,section,author,comment) VALUES (now(),'".$texts['section']."','".get_module_setting('npcid')."',\"$tname you forgot my cookies and milk last year. Don't expect anything special now.  $smile \")";
			break;
			case 51:
			$sqlz3 ="INSERT INTO ".db_prefix("commentary")." (postdate,section,author,comment) VALUES (now(),'".$texts['section']."','".get_module_setting('npcid')."',\"Hey $tname you've got to stop calling the North Pole, the elves are getting mad.  $smile \")";
			break;
			}
			if ($sqlz3 <> "") db_query($sqlz3) or die(db_error(LINK));	
		}
}
?>