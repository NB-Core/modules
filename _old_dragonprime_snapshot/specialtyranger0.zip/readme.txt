-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
Speciality - Ranger - A module for Legend of the Green Dragon 1.0.3

Legend of the Green Dragon
by  Eric "MightyE" Stevens (http://www.mightye.org)
and JT "Kendaer" Traub (http://www.dragoncat.net)

Software Project Page:
http://sourceforge.net/projects/lotgd

Modification Community Page:
http://dragonprime.net

Author of this Module:
Enderandrew (enderandrew@gmail.com)

Enderandrew's LoGD game:
http://enderandrew.com/lotgd/

Download the latest version of this module from:
http://dragonprime.net/index.php?action=viewfiles&user=enderwiggin

----------------------------------------------
-- STATUS: -----------------------------------
----------------------------------------------
This module is STABLE.

----------------------------------------------
-- INFORMATION: ------------------------------
----------------------------------------------
CortalUX originally did a Ranger specialty.  And while I normally highly
recommend his modules, I felt the Ranger specialty he did to be greatly
unbalanced.  I have greatly changed the speciality, and released this almost
as a completely different specialty with the same name.  While this module
is completely different, I wish to acknowledge and include author infor-
mation for his module.  This is not merely a tweaking of his module.  I
changed each of the Ranger powers.  But if you wish to compare the two, and
decide which is best for your game, I wish to still include his information.

Furthermore, the two letter code for Ranger is different in my specialty.  
You could opt to merely alter the name of the specialty for one of the two
modules and install both if you so desired.

		"name" => "Specialty - Ranger",
		"author" => "CortalUX",
		"version" => "1.0",
		"download" => "http://dragonprime.net/users/cortalux/specialityranger.zip",

----------------------------------------------
-- INSTALLATION: -----------------------------
----------------------------------------------
Copy specialtyranger.php within this zip into your modules directory.

Login to the Superuser Grotto and Install / Activate it.

-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-