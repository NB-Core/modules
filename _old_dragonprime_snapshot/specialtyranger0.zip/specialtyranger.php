<?php
/*

CortalUX originally did a Ranger specialty.  And while I normally highly recommend his modules,
I felt the Ranger specialty he did to be greatly unbalanced.  I have greatly changed the speciality,
and released this almost as a completely different specialty with the same name.  While this module
is completely different, I wish to acknowledge and include author information for his module.  This
is not merely a tweaking of his module.  I changed each of the Ranger powers.  But if you wish to
compare the two, and decide which is best for your game, I wish to still include his information.

Furthermore, the two letter code for Ranger is different in my specialty.  You could opt to merely
alter the name of the specialty for one of the two modules and install both if you so desired.

		"name" => "Specialty - Ranger",
		"author" => "CortalUX",
		"version" => "1.0",
		"download" => "http://dragonprime.net/users/cortalux/specialityranger.zip",

*/

function specialtyranger_getmoduleinfo(){
	$info = array(
		"name" => "Specialty - Ranger",
		"author" => "`!Enderandrew<br>original by CortalUX",
		"version" => "1.11",
		"description"=>"This will install a D&D inspired Ranger specialty.",
		"download" => "http://dragonprime.net/users/enderwiggin/specialityranger.zip",
		"vertxtloc"=>"http://dragonprime.net/users/enderwiggin/",
		"category" => "Specialties",
		"prefs" => array(
			"Specialty - Ranger User Prefs,title",
			"skill"=>"Skill points in Ranger Senses,int|0",
			"uses"=>"Uses of Ranger Senses allowed,int|0",
		),
		"settings"=> array(
			"Specialty - Ranger Settings,title",
			"mindk"=>"How many DKs do you need before the specialty is available?,int|5",
			"cost"=>"How many points do you need before the specialty is available?,int|5",
		),
	);
	return $info;
}

function specialtyranger_install(){
	$specialty="RG";
	module_addhook("apply-specialties");
	module_addhook("castlelib");
	module_addhook("castlelibbook");
	module_addhook("choose-specialty");
	module_addhook("dragonkill");
	module_addhook("fightnav-specialties");
	module_addhook("incrementspecialty");
	module_addhook("newday");
	module_addhook("pointsdesc");
	module_addhook("set-specialty");
	module_addhook("specialtycolor");
	module_addhook("specialtymodules");
	module_addhook("specialtynames");
//      This will replace the old Ranger with the new one.  If you want to somehow have both installed, comment out
//      the next two lines.
	$sql = "UPDATE " . db_prefix("accounts") . " SET specialty='RG' WHERE specialty='RT'";
	db_query($sql);
	return true;
}

function specialtyranger_uninstall(){
	// Reset the specialty of anyone who had this specialty so they get to
	// rechoose at new day
	$sql = "UPDATE " . db_prefix("accounts") . " SET specialty='' WHERE specialty='RG' OR specialty='RT'";
	db_query($sql);
	return true;
}

function specialtyranger_dohook($hookname,$args){
	global $session,$resline;
	tlschema("fightnav");

	$spec = "RG";
	$name = "Ranger Talents";
	$ccode = "`6";
	$cost = get_module_setting("cost");
	$op69 = httpget('op69');

	switch ($hookname) {

	case "apply-specialties":
		$skill = httpget('skill');
		$l = httpget('l');
		if ($skill==$spec){
			if (get_module_pref("uses") >= $l){
				switch($l){
				case 1:
					apply_buff('rg1', array(
						"startmsg"=>"`^You grip your weapon with firm resolve.  This creature shall die!",
						"name"=>"`6Favored Enemy",
						"rounds"=>5,
						"wearoff"=>"You gave it all you had, and you are spent.",
						"effectmsg"=>"`6With a blood-curdling scream you smash `^{badguy}`6 for `^{damage}`) points.",
						"atkmod"=>1.5,
						"schema"=>"specialtyranger"
					));
					break;
				case 2:
					apply_buff('rg2', array(
						"startmsg"=>"`^You grab a second weapon from you pack and decide to show {badguy} a new trick!",
						"name"=>"`6Dual-Wield",
						"rounds"=>10,
						"wearoff"=>"Your off hand tires.",
						"effectmsg"=>"`^Though it makes it harder to defend, you attack with two weapons at once dealing {damage} to {badguy}.`)",
						"atkmod"=>2,
						"defmod"=>.8,
						"schema"=>"specialtyranger"
					));
					break;
				case 3:
					apply_buff('rg3', array(
						"startmsg"=>"`6The forest is not only home to monsters. It is your home as well and you call upon your allies here.",
						"name"=>"`^Animal Companion",
						"rounds"=>7,
						"wearoff"=>"`^The wolf has done it's best to protect you, and now it returns home to the forest.`)",
						"minioncount"=>1,
						"minbadguydamage"=>$session['user']['level'],
						"maxbadguydamage"=>round($session['user']['level']*2.2),
						"effectmsg"=>"`%Your wolf companion strikes {badguy}`) for `^{damage}`) damage.`)",
						"effectnodmgmsg"=>"Your wolf companion strikes out to hit {badguy},`) but it`\$MISSES`)!",
						"schema"=>"specialtyranger"
					));
					break;
				case 5:
					apply_buff('rg5', array(
						"startmsg"=>"`^You roll back your eyes and become one with the forest around you.  You can sense your enemy's movements, but you blend in seemlessly with your surroundings and become invisible.",
						"rounds"=>5,
						"name"=>"`^Hide in Plain Sight",
						"invulnerable"=>1,
						"roundmsg"=>"`^The enemy can not see you to strike you!!",
						"schema"=>"specialtyranger"
					));
					break;
				}
				set_module_pref("uses", get_module_pref("uses") - $l);
			}else{
				apply_buff('rg0', array(
					"startmsg"=>"You reach out for the spirits of the forest to guide you, but trip on some twigs and branches instead.",
					"rounds"=>1,
					"schema"=>"specialtyranger"
				));
			}
		}
		break;

	case "castlelib":
		if ($op69 == 'ranger'){
			output("You sit down and open up the Leaf-Bound book.`n");
			output("You read for a while... in the time it takes you to read you use up`n");
			output("3 Turns.`n`n");
			output("As you read, you swear your hear a soft, singing voice and the distand sounds of music,`n");
			output("The lure of mother nature reaches out to you.  It is a peaceful melody, but as you put.`n");
			output("down the book, it is violently disturbed by the outside world.  You vow to defend what`n");
			output("little sanctity remains of nature.`n");
			$session['user']['turns']-=3;
			set_module_pref('skill',(get_module_pref('skill','specialtyranger') + 1),'specialtyranger');
			set_module_pref('uses', get_module_pref("uses",'specialtyranger') + 1,'specialtyranger');
			addnav("Continue","runmodule.php?module=lonnycastle&op=library");
			}
		break;

	case "castlelibbook":
		output("Leaf-Bound Book. (3 Turns)`n");
		addnav("Read a Book");
		addnav("Leaf-Bound Book","runmodule.php?module=lonnycastle&op=library&op69=ranger");
		break;

	case "choose-specialty":
		if ($session['user']['dragonkills']>=get_module_setting("mindk")) {
			if ($session['user']['specialty'] == "" ||
				$session['user']['specialty'] == '0') {
				addnav("$ccode$name`0","newday.php?setspecialty=".$spec."$resline");
				$t1 = translate_inline("Sniffing wolf posterior ends");
				$t2 = appoencode(translate_inline("$ccode$name`0"));
				rawoutput("<a href='newday.php?setspecialty=$spec$resline'>$t1 ($t2)</a><br>");
				addnav("","newday.php?setspecialty=$spec$resline");
			}
		}
		break;

	case "dragonkill":
		set_module_pref("uses", 0);
		set_module_pref("skill", 0);
		break;

	case "fightnav-specialties":
		$uses = get_module_pref("uses");
		$script = $args['script'];
		if ($uses > 0) {
			addnav(array("%s%s (%s points)`0", $ccode, $name, $uses), "");
			addnav(array("%s &#149; Favored Enemy`7 (%s)`0", $ccode, 1), 
					$script."op=fight&skill=$spec&l=1", true);
		}
		if ($uses > 1) {
			addnav(array("%s &#149; Dual-Wield`7 (%s)`0", $ccode, 2),
					$script."op=fight&skill=$spec&l=2",true);
		}
		if ($uses > 2) {
			addnav(array("%s &#149; Animal Companion`7 (%s)`0", $ccode, 3),
					$script."op=fight&skill=$spec&l=3",true);
		}
		if ($uses > 4) {
			addnav(array("%s &#149; Hide in Plain Sight`7 (%s)`0", $ccode, 5),
					$script."op=fight&skill=$spec&l=5",true);
		}
		break;

	case "incrementspecialty":
		if($session['user']['specialty'] == $spec) {
			$new = get_module_pref("skill") + 1;
			set_module_pref("skill", $new);
			$c = $args['color'];
			output("`n%sYou gain a level in `&%s%s to `#%s%s!",
					$c, $name, $c, $new, $c);
			$x = $new % 3;
			if ($x == 0){
				output("`n`^You gain an extra use point!`n");
				set_module_pref("uses", get_module_pref("uses") + 1);
			}else{
				if (3-$x == 1) {
					output("`n`^Only 1 more skill level until you gain an extra use point!`n");
				} else {
					output("`n`^Only %s more skill levels until you gain an extra use point!`n", (3-$x));
				}
			}
			output_notl("`0");
		}
		break;

	case "newday":
		$bonus = getsetting("specialtybonus", 1);
		if($session['user']['specialty'] == $spec) {
			if ($bonus == 1) {
				output("`n`2For being interested in %s%s`2, you receive `^1`2 extra `&%s%s`2 use for today.`n",$ccode,$name,$ccode,$name);
			} else {
				output("`n`2For being interested in %s%s`2, you receive `^%s`2 extra `&%s%s`2 uses for today.`n",$ccode,$name,$bonus,$ccode,$name);
			}
		}
		$amt = (int)(get_module_pref("skill") / 3);
		if ($session['user']['specialty'] == $spec) $amt++;
		set_module_pref("uses", $amt);
		break;

	case "pointsdesc":
		$cost = get_module_setting("cost");
		if ($cost > 0){
			$args['count']++;
			$format = $args['format'];
			$str = translate("The Ranger Specialty is availiable upon reaching %s Dragon Kills and %s points.");
			$str = sprintf($str, get_module_setting("mindk"),$cost);
		}
		output($format, $str, true);
		break;

	case "set-specialty":
		if($session['user']['specialty'] == $spec) {
			page_header($name);
			$session['user']['donationspent'] = $session['user']['donationspent'] + $cost;
			output("`@Your `&mind`@ was covered with a great `7cloud`@ until you matured.");
			output("You seemed to `!awake`@ one day, and you looked around you, to see Wolven brethren looking solemnly at you.");
			output("You lived for a time among them, but your heart yearned for more, so you went to search for your own kind, but upon meeting them, you repudiated them, for they were fighting with nature and this alarmed you.");
			output("You set yourself apart, and became `%other`@. ");
			output("`^A Ranger.`@ Running to a secluded part of a nearby forest, you wept into a grassy meadow, and gasped as others like you walked up, and howled like wolves.");
			output("From then onwards, you all hunted as one, and you learnt the ways of the Ranger.`n`n");
			output("`@You `^lost `\$rancor`@ for your `%blood`@ kind, and decided that if you could not accept the world, you would change it.");
			output("Into a hidden, pure glade you wandered, stepping through a mighty waterfall, to enter the world once more...");
		}
		break;

	case "specialtycolor":
		$args[$spec] = $ccode;
		break;

	case "specialtymodules":
		$args[$spec] = "specialtyranger";
		break;

	case "specialtynames":
		$pointsavailable = $session['user']['donation'] - $session['user']['donationspent'];
		if ($session['user']['superuser'] & SU_EDIT_USERS || $session['user']['dragonkills'] >= get_module_setting("mindk") || get_module_setting("cost") <= $pointsavailable){
			$args[$spec] = translate_inline($name);
		}
		break;
	}
	return $args;
}

function specialtyranger_run(){
}
?>