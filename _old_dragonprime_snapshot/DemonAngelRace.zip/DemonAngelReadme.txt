Demon/Angel Race Readme

All right, these races are simple enough.

They are obtained at a specific DK level - 18 is standard. That's when users get the Angel title in default.

They are also obtained by alignment. If their alignment is at the appropriate level for the amount set by the alignment module, then they can choose the race. Evil for demons, good for angels. Angels gain extra defense, demons extra attack.

WARNING! I am at the current unsure whether or not it will run without an alignment module - I'll look into it when I have more time.

Regards,
Jigain To'lerean
Coder