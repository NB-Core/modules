<?php
// translator ready
// addnews ready
// mail ready

function racedemon_getmoduleinfo(){
	$info = array(
		"name"=>"Race - Demon",
		"version"=>"1.0",
		"author"=>"Jigain To'lerean",
		"category"=>"Races",
		"download"=>"none",
		"settings"=>array(
			"Demon Race Settings,title",
			"villagename"=>"Name for the Demon village|Tartaros",
			"minedeathchance"=>"Chance for Demons to die in the mine,range,0,100,1|25",
			"mindk"=>"How many DKs do you need before the race is available?,int|18",
		),
	);
	return $info;
}

function racedemon_install(){
	module_addhook("chooserace");
	module_addhook("setrace");
	module_addhook("newday");
	module_addhook("villagetext");
	module_addhook("travel");
	module_addhook("charstats");
	module_addhook("validlocation");
	module_addhook("validforestloc");
	module_addhook("moderate");
	module_addhook("changesetting");
	module_addhook("raceminedeath");
	module_addhook("pvpadjust");
	module_addhook("adjuststats");
	module_addhook("racenames");
	return true;
}

function racedemon_uninstall(){
	global $session;
	$vname = getsetting("villagename", LOCATION_FIELDS);
	$gname = get_module_setting("villagename");
	$sql = "UPDATE " . db_prefix("accounts") . " SET location='$vname' WHERE location = '$gname'";
	db_query($sql);
	if ($session['user']['location'] == $gname)
		$session['user']['location'] = $vname;
	// Force anyone who was a demon to rechoose race
	$sql = "UPDATE  " . db_prefix("accounts") . " SET race='" . RACE_UNKNOWN . "' WHERE race='Demon'";
	db_query($sql);
	if ($session['user']['race'] == 'Demon')
		$session['user']['race'] = RACE_UNKNOWN;
	return true;
}

function racedemon_dohook($hookname,$args){
	//yeah, the $resline thing is a hack.  Sorry, not sure of a better way
	//to handle this.
	// Pass it in via args?
	global $session,$resline;
	$city = get_module_setting("villagename");
	$race = "Demon";
    $align=get_module_pref("alignment","alignment");
	$evilalign=get_module_setting('evilalign','alignment');
	$goodalign=get_module_setting('goodalign','alignment');
	switch($hookname){
	case "racenames":
		$args[$race] = $race;
		break;
	case "pvpadjust":
		if ($args['race'] == $race) {
			$args['creatureattack']+=(1+floor($args['creaturelevel']/5));
		}
		break;
	case"adjuststats":
		if ($args['race'] == $race) {
			$args['attack'] += (1+floor($args['level']/5));
		}
		break;
	case "raceminedeath":
		if ($session['user']['race'] == $race) {
			$args['chance'] = get_module_setting("minedeathchance");
		}
		break;
	case "changesetting":
		// Ignore anything other than villagename setting changes
		if ($args['setting'] == "villagename" && $args['module']=="racedemon") {
			if ($session['user']['location'] == $args['old'])
				$session['user']['location'] = $args['new'];
			$sql = "UPDATE " . db_prefix("accounts") .
				" SET location='" . addslashes($args['new']) .
				"' WHERE location='" . addslashes($args['old']) . "'";
			db_query($sql);
			if (is_module_active("cities")) {
				$sql = "UPDATE " . db_prefix("module_userprefs") .
					" SET value='" . addslashes($args['new']) .
					"' WHERE modulename='cities' AND setting='homecity'" .
					"AND value='" . addslashes($args['old']) . "'";
				db_query($sql);
			}
		}
		break;
	case "charstats":
		if ($session['user']['race']==$race){
			addcharstat("Vital Info");
			addcharstat("Race", translate_inline($race));
		}
		break;
	case "chooserace":
		        if ($session['user']['dragonkills'] < get_module_setting("mindk"))
			break;
			if ($align<$evilalign){
		output("<a href='newday.php?setrace=$race$resline'>From Tartaros down below,</a> `$Demons `0have risen, striving to achieve total domination over all mortals and the destruction of Order in this world.`n`n", true);
		addnav("`^Demon`0","newday.php?setrace=$race$resline");
		addnav("","newday.php?setrace=$race$resline");
		}
		break;
	case "setrace":
		if ($session['user']['race']==$race){
			output("`^As a Demon, your muscles are supernaturally enhanced, giving you superios strength!`n");
			output("You gain extra attack!");
			if (is_module_active("cities")) {
				if ($session['user']['dragonkills']==0 &&
						$session['user']['age']==0){
					//new farmthing, set them to wandering around this city.
					set_module_setting("newest-$city",
							$session['user']['acctid'],"cities");
				}
				set_module_pref("homecity",$city,"cities");
				if ($session['user']['age'] == 0)
					$session['user']['location']=$city;
			}
		}
		break;
	case "newday":
		if ($session['user']['race']==$race){
			racedemon_checkcity();
			apply_buff("racialbenefit",array(
				"name"=>"`@Demonic Strength`0",
				"attmod"=>"(<attack>?(1+((1+floor(<level>/5))/<attack>)):0)",
				"allowinpvp"=>1,
				"allowintrain"=>1,
				"rounds"=>-1,
				"schema"=>"module-racedemon",
				)
			);
		}
		break;
	case "validforestloc":
	case "validlocation":
		if (is_module_active("cities"))
			$args[$city]="village-$race";
		break;
	case "moderate":
		if (is_module_active("cities")) {
			tlschema("commentary");
			$args["village-$race"]=sprintf_translate("City of %s", $city);
			tlschema();
		}
		break;
	case "travel":
		$capital = getsetting("villagename", LOCATION_FIELDS);
		$hotkey = substr($city, 0, 1);
		tlschema("module-cities");
		if ($session['user']['location']==$capital){
			addnav("Safer Travel");
			addnav(array("%s?Go to %s", $hotkey, $city),"runmodule.php?module=cities&op=travel&city=$city");
		}elseif ($session['user']['location']!=$city){
			addnav("More Dangerous Travel");
			addnav(array("%s?Go to %s", $hotkey, $city),"runmodule.php?module=cities&op=travel&city=$city&d=1");
		}
		if ($session['user']['superuser'] & SU_EDIT_USERS){
			addnav("Superuser");
			addnav(array("%s?Go to %s", $hotkey, $city),"runmodule.php?module=cities&op=travel&city=$city&su=1");
		}
		tlschema();
		break;	
	case "villagetext":
		racedemon_checkcity();
		if ($session['user']['location'] == $city){
			$args['text']=array("`^`c`b%s, Ancient Home of Demons`b`c`n`6You find yourself standing on a patch of completely dead and barren earth.  %s rises about you, just as brown and depressive as the rest of the Underworld.  The buildings around you seems built more to be defendable than to be good-looking.  The harsh climate and dry air makes you cough for a while.  A few small fire demons run past.`n", $city, $city);
			$args['schemas']['text'] = "module-racedemon";
			$args['clock']="`n`6You halt one of these demons and demand to know the time.`nThe demon tells you that it is `^%s`6 before quickly running off.`n";
			$args['schemas']['clock'] = "module-racedemon";
			if (is_module_active("calendar")) {
				$args['calendar']="`n`6Another demon taps you on the shoulder and whispers in your ear, \"`^Today is `&%3\$s %2\$s`^, `&%4\$s`^.  It is `&%1\$s`^.`6\"`n";
				$args['schemas']['calendar'] = "modules-racedemon";
			}
			$args['title']= array("%s City", $city);
			$args['schemas']['title'] = "module-racedemon";
			$args['sayline']="converses";
			$args['schemas']['sayline'] = "module-racedemon";
			$args['talk']="`n`^Nearby some villagers converse:`n";
			$args['schemas']['talk'] = "module-racedemon";
			$new = get_module_setting("newest-$city", "cities");
			if ($new != 0) {
				$sql =  "SELECT name FROM " . db_prefix("accounts") .
					" WHERE acctid='$new'";
				$result = db_query_cached($sql, "newest-$city");
				$row = db_fetch_assoc($result);
				$args['newestplayer'] = $row['name'];
				$args['newestid']=$new;
			} else {
				$args['newestplayer'] = $new;
				$args['newestid']="";
			}
			if ($new == $session['user']['acctid']) {
				$args['newest']="`n`6You stare around in wonder at the brutally brown and ugly buildings, and feel a little queasy..";
			} else {
				$args['newest']="`n`6Looking at the buildings, and looking a little queasy at the prospect of such ugliness is `^%s`6.";
			}
			$args['schemas']['newest'] = "module-racedemon";
			$args['gatenav']="Village Gates";
			$args['schemas']['gatenav'] = "module-racedemon";
			$args['fightnav']="Unholy Services";
			$args['schemas']['fightnav'] = "module-racedemon";
			$args['marketnav']="Evil Equipment";
			$args['schemas']['marketnav'] = "module-racedemon";
			$args['tavernnav']="Tavern Hellhole";
			$args['schemas']['tavernnav'] = "module-racedemon";
			$args['section']="village-$race";
		}
		break;
	}
	return $args;
}

function racedemon_checkcity(){
	global $session;
	$race="Demon";
	$city=get_module_setting("villagename");
	
	if ($session['user']['race']==$race && is_module_active("cities")){
		//if they're this race and their home city isn't right, set it up.
		if (get_module_pref("homecity","cities")!=$city){ //home city is wrong
			set_module_pref("homecity",$city,"cities");
		}
	}	
	return true;
}

function racedemon_run(){

}
?>