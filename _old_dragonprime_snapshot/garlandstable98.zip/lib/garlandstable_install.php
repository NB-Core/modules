<?php
		output("`2Installing Garland's Stables Module.`n");
		$sql = "SELECT mountname FROM ".db_prefix("mounts")." where mountname = 'egg'";
		$result = mysql_query($sql);
		if (db_num_rows($result) < 1){
			output("Installing Ostrich Mounts!");
			$sql = "INSERT INTO ".db_prefix("mounts")."  (mountname,mountdesc,mountcategory,mountbuff,mountcostgems,mountcostgold,mountactive,mountforestfights,newday,recharge,partrecharge) VALUES ('Egg','Ostrich Egg','Exotic Creatures','a:5:{s:4:\"name\";s:3:\"Egg\";s:8:\"roundmsg\";s:50:\"You are extra careful so as not to break your egg.\";s:6:\"rounds\";s:3:\"500\";s:6:\"defmod\";s:3:\"1.1\";s:8:\"activate\";s:15:\"offense,defense\";}',10,100000,0,0,'You carefully pick up your egg and put it in your pack.','','')";
			db_query($sql) or die(db_error(LINK));
			if (db_affected_rows(LINK)>0){
				output("`2Installed Egg Mount!`n");
			}else{
				output("`4Egg Mount install failed!`n");
			}
			$sql = "INSERT INTO ".db_prefix("mounts")."  (mountname,mountdesc,mountcategory,mountbuff,mountcostgems,mountcostgold,mountactive,mountforestfights,newday,recharge,partrecharge) VALUES ('Baby Ostrich','Baby Ostirch','Exotic Creatures','a:7:{s:4:\"name\";s:12:\"Baby Ostrich\";s:8:\"roundmsg\";s:40:\"Your Baby Ostrich Pecks at your Opponent\";s:7:\"wearoff\";s:27:\"Your Baby Ostrich is tired.\";s:6:\"rounds\";s:3:\"200\";s:6:\"atkmod\";s:3:\"1.3\";s:6:\"defmod\";s:3:\"1.3\";s:8:\"activate\";s:15:\"offense,defense\";}',12,125000,0,2,'You strap your {weapon} to your baby ostrich, and head out for some adventure!','`&Remembering that is has been quite some time since you last fed your baby ostrich, you decide this is a perfect time to relax and allow it to graze the field a bit. You doze off enjoying this peaceful serenity.`0','`&You dismount in the field to allow your baby ostrich to graze for a moment even though it has recently been fully fed.  As you lean back in the grass to watch the clouds, your ostrich clucks softly and trots off into the underbrush.  You search for a while before returning to the fields hoping that it\'ll return.  A short time later, your ostrich trots back into the clearing holding its head high, looking much more energized and with a very avian grin on its face.`0')";
			db_query($sql) or die(db_error(LINK));
			if (db_affected_rows(LINK)>0){
				output("`2Installed Baby Ostrich Mount!`n");
			}else{
				output("`4Baby Ostrich Mount install failed!`n");
			}
			$sql = "INSERT INTO ".db_prefix("mounts")."  (mountname,mountdesc,mountcategory,mountbuff,mountcostgems,mountcostgold,mountactive,mountforestfights,newday,recharge,partrecharge) VALUES ('Juvenile Ostrich','Juvenile Ostrich','Exotic Creatures','a:7:{s:4:\"name\";s:16:\"Juvenile Ostrich\";s:8:\"roundmsg\";s:41:\"Your Juvenile Ostrich kicks your Opponent\";s:7:\"wearoff\";s:31:\"Your Juvenile Ostrich is tired.\";s:6:\"rounds\";s:3:\"300\";s:6:\"atkmod\";s:3:\"1.5\";s:6:\"defmod\";s:3:\"1.5\";s:8:\"activate\";s:15:\"offense,defense\";}',15,150000,0,4,'You strap your {weapon} to your juvenile ostrich, and head out for some adventure!','`&Remembering that is has been quite some time since you last fed your juvenile ostrich, you decide this is a perfect time to relax and allow it to graze the field a bit. You doze off enjoying this peaceful serenity.`0','`&You dismount in the field to allow your juvenile ostrich to graze for a moment even though it has recently been fully fed.  As you lean back in the grass to watch the clouds, your ostrich clucks softly and trots off into the underbrush.  You search for a while before returning to the fields hoping that it\'ll return.  A short time later, your ostrich trots back into the clearing holding its head high, looking much more energized and with a very avian grin on its face.`0')";
			db_query($sql) or die(db_error(LINK));
			if (db_affected_rows(LINK)>0){
				output("`2Installed Juvenile Ostrich Mount!`n");
			}else{
				output("`4Juvenile Ostrich Mount install failed!`n");
			}
			$sql = "INSERT INTO ".db_prefix("mounts")."  (mountname,mountdesc,mountcategory,mountbuff,mountcostgems,mountcostgold,mountactive,mountforestfights,newday,recharge,partrecharge) VALUES ('Adult Ostrich','Adult Ostirch','Exotic Creatures','a:7:{s:4:\"name\";s:13:\"Adult Ostrich\";s:8:\"roundmsg\";s:54:\"Your Adult Ostrich flys around and kicks your Opponent\";s:7:\"wearoff\";s:28:\"Your Adult Ostrich is tired.\";s:6:\"rounds\";s:3:\"400\";s:6:\"atkmod\";s:3:\"1.8\";s:6:\"defmod\";s:3:\"1.8\";s:8:\"activate\";s:15:\"offense,defense\";}',17,175000,0,6,'You strap your {weapon} to your adult ostrich, and head out for some adventure!','`&Remembering that is has been quite some time since you last fed your adult ostrich, you decide this is a perfect time to relax and allow it to graze the field a bit. You doze off enjoying this peaceful serenity.`0','`&You dismount in the field to allow your adult ostrich to graze for a moment even though it has recently been fully fed.  As you lean back in the grass to watch the clouds, your ostrich clucks softly and trots off into the underbrush.  You search for a while before returning to the fields hoping that it\'ll return.  A short time later, your ostrich trots back into the clearing holding its head high, looking much more energized and with a very avian grin on its face.`0')";
			db_query($sql) or die(db_error(LINK));
			if (db_affected_rows(LINK)>0){
				output("`2Installed Adult Ostrich Mount!`n");
			}else{
				output("`4Adult Ostrich Mount install failed!`n");
			}
			$sql = "INSERT INTO ".db_prefix("mounts")."  (mountname,mountdesc,mountcategory,mountbuff,mountcostgems,mountcostgold,mountactive,mountforestfights,newday,recharge,partrecharge) VALUES ('Mature Ostrich','Mature Ostirch','Exotic Creatures','a:7:{s:4:\"name\";s:14:\"Mature Ostrich\";s:8:\"roundmsg\";s:55:\"Your Mature Ostrich flys around and kicks your Opponent\";s:7:\"wearoff\";s:29:\"Your Mature Ostrich is tired.\";s:6:\"rounds\";s:3:\"500\";s:6:\"atkmod\";s:3:\"1.9\";s:6:\"defmod\";s:3:\"1.9\";s:8:\"activate\";s:15:\"offense,defense\";}',20,200000,0,9,'You strap your {weapon} to your mature ostrich, and head out for some adventure!','`&Remembering that is has been quite some time since you last fed your mature ostrich, you decide this is a perfect time to relax and allow it to graze the field a bit. You doze off enjoying this peaceful serenity.`0','`&You dismount in the field to allow your mature ostrich to graze for a moment even though it has recently been fully fed.  As you lean back in the grass to watch the clouds, your ostrich clucks softly and trots off into the underbrush.  You search for a while before returning to the fields hoping that it\'ll return.  A short time later, your ostrich trots back into the clearing holding its head high, looking much more energized and with a very avian grin on its face.`0')";
			db_query($sql) or die(db_error(LINK));
			if (db_affected_rows(LINK)>0){
				output("`2Installed Mature Ostrich Mount!`n");
			}else{
				output("`4Mature Ostrich Mount install failed!`n");
			}
			$sql = "SELECT mountid FROM ".db_prefix("mounts")." where mountname = 'Egg'";
			$result = db_query($sql) or die(db_error(LINK));
			$row = db_fetch_assoc($result);
			if ($row['mountid'] > 0){
				set_module_setting("eggid",$row['mountid']);
				output("`2Set ID for Egg to ".$row['mountid'].".`n");
			}else{
				output("`4Failed to Set ID for Egg!`n");
			}
			$sql = "SELECT mountid FROM ".db_prefix("mounts")." where mountname = 'Baby Ostrich'";
			$result = db_query($sql) or die(db_error(LINK));
			$row = db_fetch_assoc($result);
			if ($row['mountid'] > 0){
				set_module_setting("babyid",$row['mountid']);
				output("`2Set ID for Baby Ostrich to ".$row['mountid'].".`n");
			}else{
				output("`4Failed to Set ID for Baby Ostrich!`n");
			}
			$sql = "SELECT mountid FROM ".db_prefix("mounts")." where mountname = 'Juvenile Ostrich'";
			$result = db_query($sql) or die(db_error(LINK));
			$row = db_fetch_assoc($result);
			if ($row['mountid'] > 0){
				set_module_setting("juvenileid",$row['mountid']);
				output("`2Set ID for Juvenile Ostrich to ".$row['mountid'].".`n");
			}else{
				output("`4Failed to Set ID for Juvenile Ostrich!`n");
			}
			$sql = "SELECT mountid FROM ".db_prefix("mounts")." where mountname = 'Adult Ostrich'";
			$result = db_query($sql) or die(db_error(LINK));
			$row = db_fetch_assoc($result);
			if ($row['mountid'] > 0){
				set_module_setting("adultid",$row['mountid']);
				output("`2Set ID for Adult Ostrich to ".$row['mountid'].".`n");
			}else{
				output("`4Failed to Set ID for Adult Ostrich!`n");
			}
			$sql = "SELECT mountid FROM ".db_prefix("mounts")." where mountname = 'Mature Ostrich'";
			$result = db_query($sql) or die(db_error(LINK));
			$row = db_fetch_assoc($result);
			if ($row['mountid'] > 0){
				set_module_setting("matureid",$row['mountid']);
				output("`2Set ID for Mature Ostrich to ".$row['mountid'].".`n");
			}else{
				output("`4Failed to Set ID for Mature Ostrich!`n");
			}
	}
?>