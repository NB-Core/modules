<?php
global $playermount;
			if (get_module_pref('eggage') <> 0){
				if ($playermount['mountid'] == get_module_setting("eggid") or $playermount['mountid'] == get_module_setting("babyid") or $playermount['mountid'] == get_module_setting("juvenileid") or $playermount['mountid'] == get_module_setting("adultid") or $playermount['mountid'] == get_module_setting("matureid")){
					set_module_pref('eggage',get_module_pref('eggage') + 1);
					output("`#Your %s ages another day.`n",$playermount['mountname']);
				}else{
					set_module_pref('eggage',0);
				}
			}
			if (get_module_pref('eggage') > 40 and $session['user']['hashorse']==get_module_setting('eggid')){
			//lets hatch the egg
			output("Your Egg is Hatching!`n");
			output("You have hatched a Baby Ostrich!`7`n");
			$session['user']['hashorse']=get_module_setting('babyid');
			$sql = "SELECT * FROM ".db_prefix("mounts")." where mountid='".get_module_setting('babyid')."'";
			$result = db_query($sql);
			$mount = db_fetch_assoc($result);
			apply_buff('mount',unserialize($mount['mountbuff']));
			}
			if (get_module_pref('eggage') > 80 and $session['user']['hashorse']==get_module_setting('babyid')){
			//lets make him a juvenile
			output("Your Ostrich is maturing!`n");
			output("Your Ostrich is now a Juvenile Ostrich.`7`n");
			$session['user']['hashorse']=get_module_setting('juvenileid');
			$sql = "SELECT * FROM ".db_prefix("mounts")." where mountid='".get_module_setting('juvenileid')."'";
			$result = db_query($sql);
			$mount = db_fetch_assoc($result);
			apply_buff('mount',unserialize($mount['mountbuff']));
			}
			if (get_module_pref('eggage') > 120 and $session['user']['hashorse']==get_module_setting('juvenileid')){
			//lets make him an adult
			output("Your Ostrich is maturing!`n");
			output("Your Ostrich is now an Adult Ostrich!`7`n");
			$session['user']['hashorse']=get_module_setting('adultid');
			$sql = "SELECT * FROM ".db_prefix("mounts")." where mountid='".get_module_setting('adultid')."'";
			$result = db_query($sql);
			$mount = db_fetch_assoc($result);
			apply_buff('mount',unserialize($mount['mountbuff']));
			$playermount = getmount($mount['mountid']);
			}
			if (get_module_pref('eggage') > 160 and $session['user']['hashorse']==get_module_setting('adultid')){
			//lets make him mature
			//now we need to clear eggage
			output("Your Ostrich is maturing!`n");
			output("Your Ostrich has fully Matured!`7`n");
			$session['user']['hashorse']=get_module_setting('matureid');
			$sql = "SELECT * FROM ".db_prefix("mounts")." where mountid='".get_module_setting('matureid')."'";
			$result = db_query($sql);
			$mount = db_fetch_assoc($result);
			apply_buff('mount',unserialize($mount['mountbuff']));
			$playermount = getmount($mount['mountid']);
			set_module_pref('eggage',0);
			}
?>