<?
	global $session,$playermount;
	$op = httpget('op');
	page_header("Garland's Stables");
	output("`c`b`&Garland's Stables`0`b`c`n`n");
	$repaygold = round($playermount['mountcostgold']*2/3,0);
	$repaygems = round($playermount['mountcostgems']*2/3,0);
	if ($op == ""){
	output("`2You enter the stables and see the proprietor, Garland. He is wearing armor from head to toe.  ");
	output("Rumors say that he never takes it off, and that he wears it to hide scars of a battle with a  ");
	output("great dragon in which he lost all of his comrades. His helmet is cracked, but he seems to  ");
	output("wear it as some sort of badge of pride.`n");
	switch(e_rand(1,7)){
		case 1:
		output("`@Garland stares blankly at you and says nothing as he wipes the drool from his mouth.`n");
		break;
		case 2:
		output("`@Garland seems to be studying a few books and writing something down.`n");
		break;
		case 3:
		output("`@Garland heads into the back room. You hear a strange sound, between a hissing and`n");
		output("a roar, and then Garland comes back in. He asks what you have come here for.`n");
		break;
		case 4:
		output("`@Garland looks in your general direction, but it's hard to tell if he's actually`n");
		output("looking at you, as his eyes point in different directions.`n");
		break;
		case 5:
		output("`@Garland seems to be eating a very large fryed egg.`n");
		break;
		case 6:
		output("`@Garland is wearing a feather suit and sitting on an egg.`n");
		break;
		case 7:
		output("`@Garland is washing Ostrich poo from his face.`n");
		break;
	}
	output("`3Garland is a Ostrich Breeder, an Ostrich is a strange bird from a far away land.  These mounts are  ");
	output("very unique and very hard to come by.  Garland tells you that he has no Ostrich for sale as they  ");
	output("are in very high demand.  However he has an egg that you can buy, and if you care for it properly  ");
	output("it will hatch into an ostrich that will be very loyal to you, it's proud parent.  ");
	output("With patience and time your Ostrich will grow to a mighty beast.  ");
	output("Garland is selling his eggs for 100000 gold and 10 gems.`n");
	if ($session['user']['hashorse']>0){
		output("`#As the Ostrich egg is a mount you will have to give up your current mount to get it.  ");
		output("Garland tells you that he can find a good home for your %s,  ",$playermount['mountname']);
		output("and will give you %s gold and %s gems for it.`n",$repaygold,$repaygems);
	}
	addnav("Buy Egg","runmodule.php?module=garlandstable&op=buy");
	}
	addnav("Back to the Village","village.php");
	if ($op == "buy"){
		//going to have to read to get id's from the table
		//fix mount id to egg id
		$sql = "SELECT * FROM ".db_prefix("mounts")." where mountid='".get_module_setting('eggid')."'";
		$result = db_query($sql);
		$mount = db_fetch_assoc($result);
		if ( 
				($session['user']['gold']+$repaygold) < $mount['mountcostgold']
				 || 
				($session['user']['gems']+$repaygems) < $mount['mountcostgems']
			){
				//lets fix this text to work for the egg.
				output("`7Garland looks at you sorta sideways with his googly eyes.  \"`&'Yey, whatcha think yer doin'?  Can't you see that %s costs`^ %s`& gold an'`% %s`& gems?`7\"",$mount['mountname'],$mount['mountcostgold'],$mount['mountcostgems']);
			}else{
				if ($session['user']['hashorse']>0){
					output("`7You hand over the reins to your %s `7and the purchase price of your new critter, and Garland brings out a fine new`& %s`7 for you!`n",$playermount['mountname'],$mount['mountname']);
					output("`7Garland leads your %s `7over to a pen labeled \"Process into Ostrich food\", you wonder what that means.`n`n",$playermount['mountname']);
				}else{
					output("`7You hand over the purchase price of your new egg, and Garland brings out a fine`& %s`7 for you!`n`n",$mount['mountname']);
			    }
				$session['user']['hashorse']=$mount['mountid'];
				$goldcost = $repaygold-$mount['mountcostgold'];
				$session['user']['gold']+=$goldcost;
				$gemcost = $repaygems-$mount['mountcostgems'];
				set_module_pref('eggage',e_rand(1,10));
				$session['user']['gems']+=$gemcost;
				debuglog(($goldcost <= 0?"spent ":"gained ") . abs($goldcost) . " gold and " . ($gemcost <= 0?"spent ":"gained ") . abs($gemcost) . " gems trading for a new mount");
				$session['bufflist']['mount']=unserialize($mount['mountbuff']);
				// Recalculate so the selling stuff works right
				$playermount = getmount($mount['mountid']);
				$repaygold = round($playermount['mountcostgold']*2/3,0);
				$repaygems = round($playermount['mountcostgems']*2/3,0);
			}
		}
//I cannot make you keep this line here but would appreciate it left in.
rawoutput("<br><br><div style=\"text-align: left;\"><a href=\"http://www.pqcomp.com\" target=\"_blank\">Garland's Stables by Lonny @ http://www.pqcomp.com</a><br>");	
page_footer();
?>