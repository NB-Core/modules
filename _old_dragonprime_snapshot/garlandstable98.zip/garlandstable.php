<?php

function garlandstable_getmoduleinfo(){
	$info = array(
		"name"=>"Garland's Stables",
		"version"=>"2.12",
		"author"=>"`#Lonny Luberts",
		"category"=>"PQcomp",
		"download"=>"http://www.pqcomp.com/modules/mydownloads/visit.php?cid=3&lid=45",
		"vertxtloc"=>"http://www.pqcomp.com/",
		"prefs"=>array(
			"Garland's Stables Module User Preferences,title",
			"garlandstable"=>"Admin/Moderator Access,bool|0",
			"eggage"=>"Egg Age,int|0",
		),
		"settings"=>array(
			"`#Garland's Stables Module Settings,title",
			"garlandloc"=>"Where does Garland's Stables appear,location|".getsetting("villagename", LOCATION_FIELDS),
			"`4Changing these values not recommended!,note",
			"`4They must match the mountid for these mounts!,note",
			"eggid"=>"Egg Mount ID,int",
			"babyid"=>"Baby Ostrich Mount ID,int",
			"juvenileid"=>"Juvenile Ostrich Mount ID,int",
			"adultid"=>"Adult Ostrich Mount ID,int",
			"matureid"=>"Mature Ostrich Mount ID,int",
		),
	);
	return $info;
}

function garlandstable_install(){
	if (!is_module_active('garlandstable')){
		include("modules/lib/garlandstable_install.php");
	}
	module_addhook("village");
	module_addhook("newday");
	return true;
}

function garlandstable_uninstall(){
		output("`2Un-Installing Garland's Stables Module.`n");
		$sql = "DELETE FROM ".db_prefix("mounts")." where mountname='Egg'";
		db_query($sql);
		output("Egg Mount deleted.`n");
		$sql = "DELETE FROM ".db_prefix("mounts")." where mountname='Baby Ostrich'";
		db_query($sql);
		output("Baby Ostrich Mount deleted.`n");
		$sql = "DELETE FROM ".db_prefix("mounts")." where mountname='Juvenile Ostrich'";
		db_query($sql);
		output("Juvenile Ostrich Mount deleted.`n");
		$sql = "DELETE FROM ".db_prefix("mounts")." where mountname='Adult Ostrich'";
		db_query($sql);
		output("Adult Ostrich Mount deleted.`n");
		$sql = "DELETE FROM ".db_prefix("mounts")." where mountname='Mature Ostrich'";
		db_query($sql);
		output("Mature Ostrich Mount deleted.`n");
	return true;
}

function garlandstable_dohook($hookname,$args){
	global $session;
	switch($hookname){
		case "village":
			if ($session['user']['location'] == get_module_setting("garlandloc")){
				tlschema($args['schemas']['tavernnav']);
    			addnav($args['tavernnav']);
    			tlschema();
				addnav("Garland's Stables","runmodule.php?module=garlandstable");
			}
		break;
		case "newday":
			include("modules/lib/garlandstable_newday.php");
		break;
	}
	return $args;
}

function garlandstable_run(){
	global $SCRIPT_NAME;
	if ($SCRIPT_NAME == "runmodule.php"){
		$module=httpget("module");
		if ($module == "garlandstable") include("modules/lib/garlandstable.php");
	}
}
?>