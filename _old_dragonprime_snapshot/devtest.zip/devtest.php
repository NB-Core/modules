<?
/**************************************
Developer Test Module v1.6
Logd.ecsportal.com 1.0+
By: Arune - Kevin Hatfield
Copyright 2004
khatfield@ecsportal.com
***************************************/
require_once("lib/http.php");
function devtest_getmoduleinfo(){
        $info = array(
                 "name"=>"Developer Test Module",
                 "version"=>"1.6",
                 "author"=>"Kevin Hatfield - Arune",
                 "category"=>"Administrative",
                 "download"=>"http://dragonprime.net/users/khatfield/devtest.zip",
	             "prefs"=>array(
				 "developer"=>"Needs Privileged Developer Access?,enum,0,No Access,1,Non Privileged,2,Privileged",
                 ),
                 );
        return $info;
}
function devtest_install(){
        if (!is_module_active('devtest')){
                output("`$Installing Developer Test Module.`n");
        }else{
                output("`$Updating Developer Test Module.`n");
        }
        module_addhook("superuser");
        module_addhook("charstats");
		module_addhook("village");
	return true;
}
function devtest_uninstall(){
        return true;
}
function devtest_dohook($hookname, $args){
        global $session;
        switch($hookname){
        case "superuser":
	     addnav("Developer Tools");	
             if (get_module_pref('developer') > 0) addnav("Developer Test-Mod","runmodule.php?module=devtest");
	     break;
        case "charstats":
        if (get_module_pref('developer') == 2){
     	$dev1 = "<a href='runmodule.php?module=devtest'>`&Click Here`0</a>";
        setcharstat("Developer Tools", "Testing Area", $dev1);
        addnav("","runmodule.php?module=devtest");
    	}
        break;
       	case "village":
             addnav("Beta-Module Testing");
             if (get_module_pref('developer') > 0) addnav("Developer Test-Mod","runmodule.php?module=devtest");
             break;
        }
		return $args;
}
function devtest_run(){
require_once("common.php");
require_once("lib/villagenav.php");
global $session;
$op = httpget('op');
$goldamt = $_POST['goldamt'];
$gemamt = $_POST['gemamt'];
if (get_module_pref('developer') == 2) { addnav("`b---Currency---`b");
	 addnav("Add Gems","runmodule.php?module=devtest&op=gemamt");
	 addnav("Add Gold","runmodule.php?module=devtest&op=goldamt");
         addnav("Dump Gold","runmodule.php?module=devtest&op=dumpgold");
         addnav("Dump Gems","runmodule.php?module=devtest&op=dumpgems");
         addnav("--------");
	 }
if (is_module_active('fixnavs')) {
if (get_module_pref('developer') == 2) addnav("Fix Broken Navs","runmodule.php?module=fixnavs");
}
if (is_module_active('listproc')) {
if (get_module_pref('developer') == 2) addnav("List MYSQL Processes","runmodule.php?module=listproc");
addnav("-------");
}
villagenav();
if ($session['user']['superuser']>1) addnav("Return to the Grotto","superuser.php");
addnav("Modules");
if ($op=="dumpgold"){
        $session['user']['gold']=0;
        debuglog("dumped all gold in devtest");
}
if ($op=="dumpgems"){
        $session['user']['gems']=0;
        debuglog("dumped all gems in devtest");
}

if ($op=="goldamt"){
        output("`%How much gold would you like?`n`0");
        $linkcode="<form action='runmodule.php?module=devtest&op=goldamt2' method='POST'><input name='goldamt' id='goldamt'><input type='submit' class='button' value='Submit'></form>";
        output("%s",$linkcode,true);
        $linkcode="<script language='JavaScript'>document.getElementById('bet').focus();</script>";
        output("%s",$linkcode,true);
        addnav("","runmodule.php?module=devtest&op=goldamt2");
	addnav("`bCancel Gold Request`b","runmodule.php?module=devtest");
	addnav("--");
}

if ($op=="goldamt2"){
                set_module_pref('message',"`!The man takes your money and hands you %s gold.`0",$goldamt);
                $session['user']['gold']+=$goldamt;
                redirect("runmodule.php?module=devtest&op=get3");
    }
if ($op=="get3"){
        output_notl(get_module_pref('message'));
}
if ($op=="gemamt"){
        output("`%How many gems would you like?`n`0");
        $linkcode="<form action='runmodule.php?module=devtest&op=gemamt2' method='POST'><input name='gemamt'id='gemamt'><input type='submit' class='button' value='Submit'></form>";
        output("%s",$linkcode,true);
        $linkcode="<script language='JavaScript'>document.getElementById('bet').focus();</script>";
        output("%s",$linkcode,true);
	addnav("`bCancel Gem Request`b","runmodule.php?module=devtest");
	addnav("--");
	addnav("","runmodule.php?module=devtest&op=gemamt2");
}

if ($op=="gemamt2"){
                set_module_pref('message',"`!The man takes your money and hands you %s gems.`0",$goldamt);
                $session['user']['gems']+=$gemamt;
                redirect("runmodule.php?module=devtest&op=get3");
}
page_header("Developer Test Module");
output("This module is used for hooking into so that developer's can easily hook here and test new developmental creations without letting hazardous/broken code to be open to the public.`n`n");
output("I hope you can find a use for this script as I have.`n");
output("Thanks,`n`#Arune");
modulehook("devtest", array(), true);
page_footer();
}
?>
