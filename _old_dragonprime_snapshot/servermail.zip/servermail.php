<?php
/*
A server mail tool for sending mail to groups of people.

Basic layout:
-=-=-=-=-=-=-=-
To:
Everyone
Admins (if superuser > [input])
Non-admins
Clan (by clanid [input])
Specific person (by acctid [input])

[checkbox] Include Me (if applicable)

From:
System
You
Specific Person (by acctid [input])

[subject]

[content]

[send button]
-=-=-=-=-=-=-=-

Please do not edit this module or rename it without giving me credit for it. Thanks.
*/
require_once("common.php");
require_once("lib/http.php");
require_once("lib/systemmail.php");

function servermail_getmoduleinfo(){
				$info = array(
						"name"=>"Server Mail",
						"author"=>"`b`@Radioactivebloke`b",
						"version"=>"1.0",
						"category"=>"Administrative",
						"download"=>"dragonprime.net/users/Radioactivebloke/servermail.php_",
						"description"=>"A tool to send mail to groups of people.",
						"prefs"=>array(
								"Preferences,title",
								"su_mail"=>"Can send server mail?,bool|0",
						),
				);
				return $info;
}

function servermail_install(){
		module_addhook("superuser");
		return true;
}

function servermail_uninstall(){
		return true;
}
				
function servermail_dohook($hookname, $args){
		switch($hookname){
				case "superuser":
						if(get_module_pref("su_mail")==1){
								addnav("Actions");
								addnav("Server Mail","runmodule.php?module=servermail");
						}
				break;
		}
		return $args;
}

function servermail_run(){
		global $session;
		page_header("Server Mail");
		$op = httpget('op');
		switch($op){
				case "":
						$to = httppost('to');
						$from = httppost('from');
						if($from=="other" && httppost('o_from')!=null) $from = httppost('o_from');
						if($to=="specific")	$to_spec = httppost('to_spec');
						if(httppost('su_gt')==null) $su_gt = 0;
						if($to=="clan") $clani = httppost('clani');
						$inc_me = httppost('inc_me');
						$subject = translate_inline(httppost('subject'));
						$content = translate_inline(substr(httppost('content'),0,4096));
						if ($to!=null && $subject!=null && $content!=null){
								output("`^To=[%s] From=[%s] Subject=[%s] Content=[%s] Inc_me=[%s]`n",$to,$from,$subject,$content,$inc_me);
								$sql = "SELECT max(acctid) AS max FROM ".db_prefix("accounts");
								$result = db_query($sql);
								$row = db_fetch_assoc($result);
								$max = $row['max'];
								
								switch($to){
										case "everyone":
												for($id = 1; $id <= $max; $id++){	
														if($inc_me!=null){
																systemmail($id,$subject,$content,$from);					
														}elseif($inc_me==null){
																if($id!=$session['user']['acctid']){
																		systemmail($id,$subject,$content,$from);
																}
														}
												}
										break;
										case "admin":
												for($id = 1; $id <= $max; $id++){
														$sql = "SELECT superuser FROM ".db_prefix("accounts")." WHERE acctid=".$id;
														$result = db_query($sql);
														$row = db_fetch_assoc($result);
														$superuser = $row['superuser'];
														if($superuser!=null && $superuser > $su_gt){
																if($inc_me!=null){
																		systemmail($id,$subject,$content,$from);					
																}elseif($inc_me==null){
																		if($id!=$session['user']['acctid']){
																				systemmail($id,$subject,$content,$from);
																		}
																}
														}
												}
										break;
										case "nonadmin":
												for($id = 1; $id <= $max; $id++){
														$sql = "SELECT superuser FROM ".db_prefix("accounts")." WHERE acctid=".$id;
														$result = db_query($sql);
														$row = db_fetch_assoc($result);
														$superuser = $row['superuser'];
														if($superuser!=null && $superuser==0){
																if($inc_me!=null){
																		systemmail($id,$subject,$content,$from);					

																}elseif($inc_me==null){
																		if($id!=$session['user']['acctid']){
																				systemmail($id,$subject,$content,$from);
																		}
																}
														}
												}
										break;
										case "clanless":
												for($id = 1; $id <= $max; $id++){
														$sql = "SELECT clanid FROM ".db_prefix("accounts")." WHERE acctid=".$id;
														$result = db_query($sql);
														$row = db_fetch_assoc($result);
														$clanid = $row['clanid'];
														if($clanid!=null && $clanid==0){
																if($inc_me!=null){
																		systemmail($id,$subject,$content,$from);					
																}elseif($inc_me==null){
																		if($id!=$session['user']['acctid']){
																				systemmail($id,$subject,$content,$from);
																		}else{
																		}
																}
														}
												}
										break;
										case "clan":
												for($id = 1; $id <= $max; $id++){
														$sql = "SELECT clanid FROM ".db_prefix("accounts")." WHERE acctid=".$id;
														$result = db_query($sql);
														$row = db_fetch_assoc($result);
														$clanid = $row['clanid'];
														if($clanid!=null && $clanid==$clani){
																if($inc_me!=null){
																		systemmail($id,$subject,$content,$from);					
																}elseif($inc_me==null){
																		if($id!=$session['user']['acctid']){
																				systemmail($id,$subject,$content,$from);
																		}
																}
														}
												}
										break;
										case "specific":
												if($to_spec==null or $to_spec==0)	$to_spec = $session['user']['acctid'];
												systemmail($to_spec,$subject,$content,$from);
										break;
								}   
						}
						$my_acctid = translate_inline($session['user']['acctid']);
						$my_clanid = translate_inline($session['user']['clanid']);
						rawoutput("<form action='runmodule.php?module=servermail' method='POST'>");
						addnav("","runmodule.php?module=servermail");
						output("`7`bTo:`b`n");
						rawoutput("<input type='radio' name='to' value='everyone'> Everyone</input><br>");
						rawoutput("<input type='radio' name='to' value='admin'> Admins - if superuser is greater than </input><input type='text' name='su_gt' value='".translate_inline($su_gt==null?"0":$su_gt)."'></input><br>");
						rawoutput("<input type='radio' name='to' value='nonadmin'> Non-admins</input><br>");
						rawoutput("<input type='radio' name='to' value='clanless'> Clanless members</input><br>");
						rawoutput("<input type='radio' name='to' value='clan'> Members of clan </input><input type='text' name='clani' value='".translate_inline($clani==null?$my_clanid:$clani)."'> (By Clanid)</input><br>");
						rawoutput("<input type='radio' name='to' value='specific'> Specific person </input><input type='text' name='to_spec' value='".translate_inline($to_spec==null?$my_acctid:$to_spec)."'> (By Acctid)</input><br>");
						rawoutput("<br><input type='checkbox' name='inc_me' checked> Send a copy to me (if applicable)</input><br>");
						output("`n`bFrom:`b`n");
						rawoutput("<input type='radio' name='from' value='0' checked> System</input><br>");
						rawoutput("<input type='radio' name='from' value='".$my_acctid."'> Me</input><br>");
						rawoutput("<input type='radio' name='from' value='other'> Other </input><input type='text' name='o_from' value='".translate_inline($o_from==null?$my_acctid:$o_from)."'> (By Acctid)</input>");
						output("`n`n`bSubject`b (optional)`b:`b`n");
						rawoutput("<input type='text' name='subject' cols=5 value='".translate_inline($subject==null?"Message subject.":$subject)."'></input><br><br>");
						output("`bMessage Body:`b");
						rawoutput("<textarea name='content' cols='40' rows='5' style='width:100%'>".translate_inline($content==null?"Message contents.":$content)."</textarea><br>");
						$save = translate_inline("Send Mail");
						rawoutput("<input type='submit' class='button' value='$save'>");
						rawoutput("</form>");
				break;
		}
		addnav("Return");
		addnav("Return to the Grotto","superuser.php");
		page_footer();
}

?>