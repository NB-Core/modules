<?php
/************************************************************************
  Item Drop Module for LoGD .9.8-pr12+
  By: Turock
  v 1.0    Date: 01/12/05

- Info:
  Allows badguys in the forest to drop rare weapons and armor after
  battle. Only one weapon and one armor can be found until the user
  dk's.
- Credits:
  - I used some of the weapon and armor names from Eth's Citidel mod
    for LoGD .9.7, thought they were cool ;)
- Install:
  - Drop into your modules directory and install
************************************************************************/
require_once("common.php");

function itemdrop_getmoduleinfo(){
	$info = array(
		"name"=>"Item Drop Module",
		"author"=>"Turock",
		"version"=>"1.0",
		"category"=>"Forest",
        "download"=>"http://dragonprime.net/users/Turock/itemdrop.zip",
		"settings"=>array(
            "Item Drop Module Settings,title",
            "armorchance"=>"Chance for armor to be found in forest?,int|1000",
            "armormindks"=>"Minimum DK's before armor can be found?,int|1",
            "weaponchance"=>"Chance for armor to be found in forest?,int|1000",
            "weaponmindks"=>"Minimum DK's before weapons can be found?,int|1",
            
            "Armor Settings,title",
            "armor1"=>"Name of rare armor #1:,text|Golden Hauberk",
            "armor1def"=>"Defense of armor #1:,int|17",
            "armor1value"=>"Value of armor #1:,int|15000",
            "armor2"=>"Name of rare armor #2:,text|Mithril Plate",
            "armor2def"=>"Defense of armor #2:,int|17",
            "armor2value"=>"Value of armor #2:,int|15000",
            "armor3"=>"Name of rare armor #3:,text|Emerald Mail",
            "armor3def"=>"Defense of armor #3:,int|17",
            "armor3value"=>"Value of armor #3:,int|15000",
            "armor4"=>"Name of rare armor #4:,text|Armor of Kor",
            "armor4def"=>"Defense of armor #4:,int|17",
            "armor4value"=>"Value of armor #4:,int|15000",
            "armor5"=>"Name of rare armor #5:,text|Mithril Sword",
            "armor5def"=>"Defense of armor #5:,int|18",
            "armor5value"=>"Value of armor #5:,int|16500",
            "armor6"=>"Name of rare armor #6:,text|Mystic Robes",
            "armor6def"=>"Defense of armor #6:,int|18",
            "armor6value"=>"Value of armor #6:,int|16500",
            "armor7"=>"Name of rare armor #7:,text|Winter's Shroud",
            "armor7def"=>"Defense of armor #7:,int|18",
            "armor7value"=>"Value of armor #7:,int|16500",
            "armor8"=>"Name of rare armor #8:,text|Dragon Scale Mail",
            "armor8def"=>"Defense of armor #8:,int|18",
            "armor8value"=>"Value of armor #8:,int|16500",
            "armor9"=>"Name of rare armor #9:,text|Mantle of Kings",
            "armor9def"=>"Defense of armor #9:,int|19",
            "armor9value"=>"Value of armor #9:,int|18000",
            "armor10"=>"Name of rare armor #10:,text|Champion's Hauberk",
            "armor10def"=>"Defense of armor #10:,int|19",
            "armor10value"=>"Value of armor #10:,int|18000",
            "armor11"=>"Name of rare armor #11:,text|Kendaer's Cloak",
            "armor11def"=>"Defense of armor #11:,int|19",
            "armor11value"=>"Value of armor #11:,int|18000",
            "armor12"=>"Name of rare armor #12:,text|Armor of Xerxes",
            "armor12def"=>"Defense of armor #12:,int|19",
            "armor12value"=>"Value of armor #12:,int|18000",
            "armor13"=>"Name of rare armor #13:,text|Soul Shroud",
            "armor13def"=>"Defense of armor #13:,int|20",
            "armor13value"=>"Value of armor #13:,int|19500",
            "armor14"=>"Name of rare armor #14:,text|Tiger Robes",
            "armor14def"=>"Defense of armor #14:,int|20",
            "armor14value"=>"Value of armor #14:,int|19500",

            "Weapon Settings,title",
            "weapon1"=>"Name of rare weapon #1:,text|Shortsword Sting",
            "weapon1atk"=>"Attack of weapon #1:,int|16",
            "weapon1value"=>"Value of weapon #1:,int|16000",
            "weapon2"=>"Name of rare weapon #2:,text|Sword of Torm",
            "weapon2atk"=>"Attack of weapon #2:,int|16",
            "weapon2value"=>"Value of weapon #2:,int|16000",
            "weapon3"=>"Name of rare weapon #3:,text|Brightstar Mace",
            "weapon3atk"=>"Attack of weapon #3:,int|16",
            "weapon3value"=>"Value of weapon #3:,int|16000",
            "weapon4"=>"Name of rare weapon #4:,text|Crimson Dagger",
            "weapon4atk"=>"Attack of weapon #4:,int|16",
            "weapon4value"=>"Value of weapon #4:,int|16000",
            "weapon5"=>"Name of rare weapon #5:,text|Mithril Sword",
            "weapon5atk"=>"Attack of weapon #5:,int|17",
            "weapon5value"=>"Value of weapon #5:,int|18000",
            "weapon6"=>"Name of rare weapon #6:,text|Axe of Kor",
            "weapon6atk"=>"Attack of weapon #6:,int|17",
            "weapon6value"=>"Value of weapon #6:,int|18000",
            "weapon7"=>"Name of rare weapon #7:,text|Moonblade Scimitar",
            "weapon7atk"=>"Attack of weapon #7:,int|17",
            "weapon7value"=>"Value of weapon #7:,int|18000",
            "weapon8"=>"Name of rare weapon #8:,text|Staff of the Magus",
            "weapon8atk"=>"Attack of weapon #8:,int|17",
            "weapon8value"=>"Value of weapon #8:,int|18000",
            "weapon9"=>"Name of rare weapon #9:,text|Dragontooth Warhammer",
            "weapon9atk"=>"Attack of weapon #9:,int|18",
            "weapon9value"=>"Value of weapon #9:,int|19500",
            "weapon10"=>"Name of rare weapon #10:,text|Soul Blighter",
            "weapon10atk"=>"Attack of weapon #10:,int|18",
            "weapon10value"=>"Value of weapon #10:,int|19500",
            "weapon11"=>"Name of rare weapon #11:,text|Shortsword Frostbite",
            "weapon11atk"=>"Attack of weapon #11:,int|18",
            "weapon11value"=>"Value of weapon #11:,int|19500",
            "weapon12"=>"Name of rare weapon #12:,text|Phoenix Sword",
            "weapon12atk"=>"Attack of weapon #12:,int|18",
            "weapon12value"=>"Value of weapon #12:,int|19500",
            "weapon13"=>"Name of rare weapon #13:,text|Tiger Staff",
            "weapon13atk"=>"Attack of weapon #13:,int|19",
            "weapon13value"=>"Value of weapon #13:,int|22000",
            "weapon14"=>"Name of rare weapon #14:,text|Seeker Blade",
            "weapon14atk"=>"Attack of weapon #14:,int|19",
            "weapon14value"=>"Value of weapon #14:,int|22000"
		),
        "prefs"=>array(
            "userhasweapon"=>"Does user have a rare weapon?,bool|0",
            "rareweaponname"=>"Name of users rare weapon:,text|none",
            "rareweaponatk"=>"Attack value of users rare weapon:,int|0",
            "rareweaponvalue"=>"Value of users rare weapon:,int|0",
            "userhasarmor"=>"Does user have rare armor?,bool|0",
            "rarearmorname"=>"Name of users rare armor:,text|none",
            "rarearmordef"=>"Defense value of users rare armor:,int|0",
            "rarearmorvalue"=>"Value of users rare armor:,int|0"
        )
	);
	return $info;
}

function itemdrop_install(){
    module_addhook("battle-victory");
    module_addhook("dragonkill");
	return true;
}

function itemdrop_uninstall(){
	return true;
}

function itemdrop_dohook($hookname, $args){
    global $session;
    switch($hookname) {
        case "battle-victory":
        $weaponchance = get_module_setting("weaponchance");
        $weaponmindks = get_module_setting("weaponmindks");
        if(get_module_pref("userhasweapon") == 0){
            if((e_rand(1,$weaponchance) == 1) && ($session['user']['dragonkills'] > $weaponmindks)) {
                $weaponnumber = e_rand(1,14);
                $weaponname = get_module_setting("weapon".$weaponnumber);
                $weapondmg = get_module_setting("weapon".$weaponnumber."atk");
                $weaponvalue = get_module_setting("weapon".$weaponnumber."value");
                set_module_pref("userhasweapon", 1);
                set_module_pref("rareweaponname", $weaponname);
                set_module_pref("rareweaponatk", $weapondmg);
                set_module_pref("rareweaponvalue", $weaponvalue);
                output("`n`n`b`%You found a rare weapon: `&%s`&`b`n`n", $weaponname);
                $session['user']['attack']-=$session['user']['weapondmg'];
                $session['user']['weapondmg'] = $weapondmg;
                $session['user']['attack']+=$session['user']['weapondmg'];
                $session['user']['weaponvalue'] = $weaponvalue;
                $session['user']['weapon'] = $weaponname;
                addnews("`&`b%s `^has found an very rare weapon called: `&%s!`&`b",$session['user']['name'], $weaponname);
                debuglog("found rare weapon $weaponname after slaying a monster in the forest");
            } else {
                // do nothing
            }
        }
        $armorchance = get_module_setting("armorchance");
        $armormindks = get_module_setting("armormindks");
        if(get_module_pref("userhasarmor") == 0){
            if((e_rand(1,$armorchance) == 1) && ($session['user']['dragonkills'] > $armormindks)) {
                $armornumber = e_rand(1,14);
                $armorname = get_module_setting("armor".$armornumber);
                $armordfs = get_module_setting("armor".$armornumber."def");
                $armorvalue = get_module_setting("armor".$armornumber."value");
                set_module_pref("userhasarmor", 1);
                set_module_pref("rarearmorname", $armorname);
                set_module_pref("rarearmordef", $armordfs);
                set_module_pref("rarearmorvalue", $armorvalue);
                output("`n`n`b`%You found rare armor: `&%s`&`b`n`n", $armorname);
                $session['user']['armor'] = $armorname;
                $session['user']['defense']-=$session['user']['armordef'];
                $session['user']['armordef'] = $armordfs;
                $session['user']['defense']+=$session['user']['armordef'];
                $session['user']['armorvalue'] = $armorvalue;
                addnews("`&`b%s `^has found an very rare armor called: `&%s!`&`b",$session['user']['name'], $armorname);
                debuglog("found rare armor $armorname after slaying a monster in the forest");
            } else {
                // do nothing
            }
        }
        break;
        case "dragonkill":
            if(get_module_pref("userhasarmor") == 1) {
                set_module_pref("userhasarmor", 0);
                set_module_pref("rarearmorname", "none");
                set_module_pref("rarearmordef", 0);
                set_module_pref("rarearmorvalue", 0);
            }
            if(get_module_pref("userhasweapon") == 1) {
                set_module_pref("userhasweapon", 0);
                set_module_pref("rareweaponname", "none");
                set_module_pref("rareweaponatk", 0);
                set_module_pref("rareweaponvalue", 0);
            }
        break;
    }
    return $args;
}

function itemdrop_run(){
}
?>
