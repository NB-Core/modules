<?php 

function strangebox_getmoduleinfo(){
	$info = array(
		"name"=>"Strange Box",
		"version"=>"1.1",
		"author"=>"Jeffrey Riddle-Built with Module Builder by `3Lonny Luberts`0",
		"category"=>"Forest Specials",
		"download"=>"",
		"settings"=>array(
			"Strange Box Settings,title",
			"basestat"=>"Stat to base increase and decrease on,enum,charm,Charm,hitpoints,Hitpoints,attack,Attack,defense,Defense,gold,Gold,gems,Gems,1,Random|Random",
			"goodevent"=>"Percent chance the event will be good,range,0,100,1|65",
			"goldchange"=>"Amount to increase or decrease gold:,int|100",
			"hpchange"=>"Percent to increase or decrease hitpoints:,range,0,100,1|50",
		),
		"prefs"=>array(
			"Strange Box Preferences,title",
			"strangebox"=>"Found the strange box this newday?,bool|0",
		),
	);
return $info;
}
function strangebox_chance() {
	global $session;
	$ret = 0;
	if (get_module_pref('strangebox','strangebox')==0) $ret=100;
	return $ret;
}
function strangebox_install(){
	module_addeventhook("forest","require_once(\"modules/strangebox.php\"); 
	return strangebox_chance();");
	module_addhook("newday");
return true;
}

function strangebox_uninstall(){
return true;
}

function strangebox_dohook($hookname,$args){
	global $session;
	switch($hookname){
	case "newday":
		set_module_pref("strangebox",0);
	break;
	}
return $args;
}

function strangebox_runevent($type,$link) {
global $session;
$from = $link;
$op = httpget('op');
$session['user']['specialinc'] = "module:strangebox";
$basestat = get_module_setting("basestat");
$goldchange = get_module_setting("goldchange");
$hpchange = get_module_setting("hpchange")/100;
if ($basestat==1){
	$random= e_rand(1,6);
	if ($random==1) $basestat="charm";
	if ($random==2) $basestat="hitpoints";
	if ($random==3) $basestat="attack";
	if ($random==4) $basestat="defense";
	if ($random==5) $basestat="gold";
	if ($random==6) $basestat="gems";
}
if ($basestat=="gold"){
	$amt=$goldchange;
}elseif($basestat=="hitpoints"){
	$amt=round($hpchange*$session['user']['hitpoints']);
}else{
	$amt=1;
}
if (($session['user'][$basestat]-$amt)<=0) $amt=0;
if ($op==""){
	output("`2`2 Walking through the forest, you come across a little box. Upon further inspection, you see it has a button on it. `n`n");
	output("`\$Do you want to push the button?`0");
	set_module_pref("strangebox",1);
	addnav("Push Button",$from."op=yes");
	addnav("Continue on your way",$from."op=no");
}
if ($op=="no") {
	output("`2You decide not to push the button and leave it.`0");
	$session['user']['specialinc'] = "";
}
if ($op=="yes"){
	output("`2You decide to push the button and see what happens.`n`n`0");
	if ($amt==0){
		output("Oh well.  Nothing happens!");
	}elseif (e_rand(0,100) <= get_module_setting("goodevent")) {
		$session['user'][$basestat]+=$amt;
		output("`^`2As you push the button, a mysterious gas comes out the box. As you smell it, you start to feel improved!");
		if (($basestat=="hitpoints" && $amt>1)||$basestat=="gems") output("`n`n`@Your %s have increased by %s!`0",$basestat,$amt);
		else output("`n`n`@Your %s has increased by %s!`0",$basestat,$amt);
	}else{
		$session['user'][$basestat]-=$amt;
		output("`4`2As you push the button, a mysterious gas comes out the box. As you smell it, you begin to pass out. After a while, you completely pass out. You wake up hours later, not feeling too good.");
		if (($basestat=="hitpoints" && $amt>1)||$basestat=="gems") output("`n`n`\$Your %s have decreased by %s!`0",$basestat,$amt);
		else output("`n`n`\$Your %s has decreased by %s!",$basestat,$amt);
	}
	$session['user']['specialinc'] = "";
}
}

function strangebox_run(){
}

 
?>

