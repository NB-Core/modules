<?php

require_once("lib/http.php");

function aelia_getmoduleinfo(){
	$info = array(
		"name"=>"Aelia's Gem Shop",
		"author"=>"Aelia",
		"version"=>"1.0",
		"category"=>"Village",
		"download"=>"Ask Admin For Release",
	);
	return $info;
}

function aelia_install(){
	module_addhook("village");
}

function aelia_uninstall(){
	output("Uninstalling this module.`n");
	return true;
}

function aelia_dohook($hookname, $args){
	global $session;
	switch($hookname){
	case "village":
		if ($session['user']['location'] == getsetting("villagename", LOCATION_FIELDS)){
			tlschema($args['schemas']['marketnav']);
			addnav($args["marketnav"]);
			tlschema();
			addnav("A?Aelia's Gem Shop","runmodule.php?module=aelia");
		}
		break;
	}
	return $args;
}

function aelia_run(){
	global $session;
	// Does the player have enough gold to use the Private Toilet?
	page_header("Aelia's Gem Shop");
	$op = httpget('op');
	if ($op == "pay10"){
		if ($session['user']['gems'] < 10) {
			output("`7You dont have that many!");
		} else {
		$session['user']['gems'] -= 10;
		$session['user']['donation'] += 10;
		debuglog("spent 10 gems to buy 10 donation points");
		output("`2You spent `%10 gems `2to buy `$10 donation points`2!");
		}
	}elseif ($op == "pay100"){
		if ($session['user']['gems'] < 100) {
			output("`7You dont have that many!");
		} else {
		$session['user']['gems'] -= 100;
		$session['user']['donation'] += 100;
		debuglog("spent 100 gems to buy 10 donation points");
		output("`2You spent `%100 gems `2to buy `$100 donation points`2!");
		}
	} else {
		output("`2This is Aelia's Gem Shop. Here, you can exchange gems for dontation points at a rate of 1 to 1`n`n");
				addnav("Pay `%10 Gems", "runmodule.php?module=aelia&op=pay10");
				addnav("Pay `%100 Gems", "runmodule.php?module=aelia&op=pay100");
	}
	require_once("lib/villagenav.php");
	villagenav();
	page_footer();
}
?>
