<?
/********************
The Black Knight2 - ver1.1
22MAR2004
Special Forest Event
Written by Robert for Maddnet LoGD
To be used ONLY if you also use Lonny's Battle Arena
*********************/
if ($session[user][level]< 5){
    redirect("forest.php?op=search");
}else{
if ($session[user][battlepoints]<25){

     output("`n`n`2The `5Black Knight `2can easily tell that you are not a worthy warrior!`n");
     output("He takes advantage of your lack of skills and makes a quick ambush upon you.`n");
     output("Upon awakening you find yourself badly beaten and have lost some hitpoints.`n");
     output("`&Looks like a visit to the `2Battle Arena `&may do you some good");
     debuglog("Lost 1 MAXhitpoint to Black Knight for lack of battle points");
     $session[user][hitpoints] -= 9;
     $session[user][maxhitpoints] --;
     if ($session[user][hitpoints]< 0) $session[user][hitpoints] = 0;
}else{
	output("`n`n`2The `5Black Knight `2is quick to see that you are a skilled warrior.`n");
	output("The `5Black Knight `2gives you a gesture of respect and goes on his way.`n");
    output("You feel a little better about yourself.`n");
    $session[user][turns]++;
}
}
?>