<?php
function backpack_getmoduleinfo(){
	$info = array(
		"name"=>"Backpack for use with trading mod by LonnyL",
		"author"=>"WebPixie, trading mod code by and alterations `#Lonny Luberts",
		"version"=>"1.1",
		"category"=>"General",
		"download"=>"http://www.pqcomp.com/modules/mydownloads/visit.php?cid=3&lid=33",
		"override_forced_nav"=>true,
	);
	return $info;
}

function backpack_install(){
	if (!is_module_installed("trading")) {
		output("This mod is for use with Trading Mod by LonnyL");
		return false;
	}
		module_addhook("tradebackpack");
        return true;
}

function backpack_uninstall(){
        return true;
}

function backpack_dohook($hookname,$args){
	global $session;
        $backpack.="<a href='runmodule.php?module=backpack' onClick=\"".popup("runmodule.php?module=backpack").";return false;\" target='_blank' align='center' class=\"charinfo\" style=\"font-size:10px\">View Contents</a>";	
		addcharstat("Equipment Info");
		addcharstat("Backpack", $backpack);
		addnav("","runmodule.php?module=backpack");
	return $args;
}

function backpack_run(){
	global $session;
	popup_header("Your Backpack Inventory");
	$myname=$session['user']['name'];
	//check and display inventory
	output("`2You have in your pack.`n");
	$fox=get_module_pref('fox','trading');
	output("`1Fox Pelts - %s`n",$fox);
	$inventory=get_module_pref('fox','trading');
	$fish=get_module_pref('fish','trading');
	output("`!Fish Eyes - %s`n",$fish);
	$inventory+=get_module_pref('fish','trading');
	$worms=get_module_pref('worms','trading');
	output("`1Worms - %s`n",$worms);
	$inventory+=get_module_pref('worms','trading');
	$bat=get_module_pref('bat','trading');
	output("`!Bat Wings - %s`n",$bat);
	$inventory+=get_module_pref('bat','trading');
	$newt=get_module_pref('newt','trading');
	output("`1Eye of Newt - %s`n",$newt);
	$inventory+=get_module_pref('newt','trading');
	$dog=get_module_pref('dog','trading');
	output("`!Puppy Dog Tails - %s`n",$dog);
	$inventory+=get_module_pref('dog','trading');
	$frog=get_module_pref('frog','trading');
	output("`1Frog Legs - %s`n",$frog);
	$inventory+=get_module_pref('frog','trading');
	$wort=get_module_pref('wort','trading');
	output("`!Wort - %s`n",$wort);
	$inventory+=get_module_pref('wort','trading');
	$heads=get_module_pref('heads','trading');
	output("`1Shrunken Heads - %s`n",$heads);
	$inventory+=get_module_pref('heads','trading');
	$wool=get_module_pref('wool','trading');
	output("`!Wool - %s`n",$wool);
	$inventory+=get_module_pref('wool','trading');
	$cloth=get_module_pref('cloth','trading');
	output("`1Cloth - %s`n",$cloth);
	$inventory+=get_module_pref('cloth','trading');
	$leather=get_module_pref('leather','trading');
	output("`!Leather - %s`n",$leather);
	$inventory+=get_module_pref('leather','trading');
	$space=(50 - $inventory);
	if ($inventory < 50) output("`2You have space left for %s more items.`n`n",$space);
	if ($inventory > 49) output("`4You notice that your Pack is full.`n`n");
	popup_footer();
}

?>
