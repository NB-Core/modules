<?php

function goosewalk_getmoduleinfo(){
	$info = array(
	"name"=>"Goose Walk",
	"version"=>"1.0",
	"author"=>"`6Harry Balzitch",
	"category"=>"Forest Specials",
	"download"=>"http://dragonprime.net/users/Harry%20B/goosewalk.zip",
	"settings"=>array(
	"Goose Walk Settings,title",
	"mingold"=>"Minimum gold to find (multiplied by level),range,50,100,1|10",
	"maxgold"=>"Maximum gold to find (multiplied by level),range,100,500,1|50"
	),
	);
	return $info;
}

function goosewalk_install(){
	module_addeventhook("forest","return 100;");
	return true;
}

function goosewalk_uninstall(){
	return true;
}

function goosewalk_dohook($hookname,$args){
	return $args;
}

function goosewalk_runevent($type)
{
	global $session;
	$min = $session['user']['level']*get_module_setting("mingold");
	$max = $session['user']['level']*get_module_setting("maxgold");
	$gold = e_rand($min, $max);
	output("`n`2You stumble upon a flock of geese, while wading through the poo you find %s gold!`0", $gold);
	$session['user']['gold']+=$gold;
	debuglog("found $gold gold in the forest");
}

function goosewalk_run(){
}
?>