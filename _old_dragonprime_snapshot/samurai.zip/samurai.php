<?php

function samurai_getmoduleinfo(){
	$info = array(
	"name"=>"Samurai",
	"version"=>"1.0",
	"author"=>"`6Harry B and Kenny Chu",
	"category"=>"Forest Specials",
	"download"=>"http://dragonprime.net/users/Harry%20B/samurai.zip",
	);
	return $info;
}

function samurai_install(){
	module_addeventhook("forest","return 100;");
	return true;
}

function samurai_uninstall(){
	return true;
}

function samurai_dohook($hookname,$args){
	return $args;
}

function samurai_runevent($type)
{
	global $session;
	if ($session['user']['level']<15){
	output("`n`n `2You come upon a clearing where a Samurai is practicing his sword skills.");
	output("`n`n He is completely started by your sudden appearance and cuts off one of his fingers.");
	output("`n`n You quickly rush to his aide and help him recover.");
	output("`n`n You expedend all your remaining turns with the Samurai.");
	output("`n`n In deep gratitude the Samurai teach's you things which help you become a better warrior.");
	output("`n`n `^You gain a level from such great knowledge!");
	$session['user']['turns']=0;
	$session['user']['level']++;
	$session['user']['attack']++;
	$session['user']['defense']++;
	$session['user']['hitpoints']+=10;
	$session['user']['maxhitpoints']+=10;
	$session['user']['experience']+=500;
	debuglog("gained 1 level helping the samurai");
}else{
	$weapon = $session['user']['weapon'];
	$gold = e_rand(500,5000);
	output("`n`n You come upon a clearing where a Samurai is practicing his sword skills.");
	output("`n`n He see's your %s and asks if you could train him in how to use it.", $weapon);
	output("`n`n In total agreement, you train the Samurai and he gives you  %s gold for the lessons.", $gold);
	$session['user']['gold']+=$gold;
	debuglog("got $gold gold from the samurai");
}
}

function samurai_run(){
}
?>