<?php
/* Rock, Paper, Scissors 
An Add on for inn.php LoGD version 097
Written by Robert of Maddnet
version 1.3 Sep2004
Latest version is available at Dragon Prime
http://dragonprime.net

Simple little game to entertain players
INSTALL INSTRUCTIONS:
	open inn.php
	find: addnav("Ask Seth to entertain","inn.php?op=seth&subop=hear");
	add under:  addnav("Play Seth a game","rockpaper.php");

Game default settings can be changed - see below
Feel free to alter to suit but please keep this entire comment tag intact
*/
require_once "common.php";
// To make a free game (no wagering) change the next line from 1 to 0
$money = 1;
// You can change the cost to whatever you like in the next line (default is 2 gold)
// IF you make a FREE game, no wager (see lines 16-17 above) change to 0
$cost = 2;
// Do not change the rest unless you know what your doing!!
$who="Seth";
$a="`6Rock";
$b="`&Paper";
$c="`2Scissors";
$d="You throw";
$e="has thrown";
// Free game lose message
$lmsg="Better luck next time";
// Free game win message
$wmsg="Is'nt that nice";
page_header("Rock, Paper, Scissors");
output("`c<font size='+1'>`3You and Seth play a game</font>`c`n",true);
if ($session['user']['gold']>= $cost) addnav("Select");
if ($session['user']['gold']>= $cost) addnav("(R) Rock","rockpaper.php?op=1");
if ($session['user']['gold']>= $cost) addnav("(P) Paper","rockpaper.php?op=2");
if ($session['user']['gold']>= $cost) addnav("(S) Scissors","rockpaper.php?op=3");
if ($session['user']['gold']>= $cost) addnav("other");
addnav("(G) Game Rules","rockpaper.php?op=rule");
addnav("exit game");
addnav("(I) Return to Inn","inn.php");
// While I can't force you to keep the next line - It would be appreciated
output("`n`n`n`n`n`n`n`n`7 This game written by Robert of Maddnet LoGD");
if ($HTTP_GET_VARS[op]==""){
	output("`n`n You noticed that $who is mulling around with an extreme bored look on his face,");
	output("`n if you really wanted to cheer him up,`n you could ask him to play a few rounds of $a`3, $b`3, $c`3.");
if ($money == 1){
	output("`n`n Each round will cost you $cost gold");
	if ($session['user']['gold']< $cost) output("`n`n `& Too bad, you dont have enough to play.");
	}else{
	output("You know, $who is `ialways`i glad to play a friendly game with you");
	}

}else if ($HTTP_GET_VARS[op]=="1"){
	switch(e_rand(1,3)){
		case 1:	output("`n`n`3 $d $a`3- $who $e $a`3 - it's a draw!");break;
		case 2:	output("`n`n`3 $d $a`3- $who $e $b`n $b `3covers $a`3, `\$ You Lose`3! ");
		if ($money == 1){
			output("`n You pass $cost gold coins to $who");
			$session['user']['gold']-=$cost;
		}else{ output("`n $lmsg ");} 
		break;
		case 3:	output("`n`n`3 $d $a`3- $who $e $c`n $a `3dulls $c`3, `^ You Win`3! ");
		if ($money == 1){
			output("`n $who passes $cost gold coins to you "); $session['user']['gold']+=$cost;
		}else{ output("`n $wmsg "); }break;
	}
}	
else if ($HTTP_GET_VARS[op]=="2"){
	switch(e_rand(1,3)){
		case 1:	output("`n`n`3 $d $b`3- $who $e $a `n $b `3covers $a`3, `^ You Win`3! ");
		if ($money == 1){
			output("`n $who passes $cost gold coins to you "); $session['user']['gold']+=$cost;
		}else{ output("`n $wmsg "); }
		break;
		case 2:	output("`n`n`3 $d $b`3- $who $e $b `3 - it's a draw! ");break;
		case 3:	output("`n`n`3 $d $b`3- $who $e $c `n $c `3cuts $b, `\$ You Lose`3 ");
		if ($money == 1){
			output("`n You pass $cost gold coins to $who");
			$session['user']['gold']-=$cost;
		}else{ output("`n $lmsg ");}
		break;
	}
}else if ($HTTP_GET_VARS[op]=="3"){
	switch(e_rand(1,3)){
		case 1:	output("`n`n`3 $d $c`3- $who $e $a`n $a `3dulls $c`3, `\$ You Lose`3! ");
		if ($money == 1){
			output("`n You pass $cost gold coins to $who");
			$session['user']['gold']-=$cost;
		}else{ output("`n $lmsg ");}
		break;
		case 2:	output("`n`n`3 $d $c`3- $who $e $b`n $c `3cuts $b`3, `^ You Win`3! ");
		if ($money == 1){
			output("`n $who passes $cost gold coins to you "); $session['user']['gold']+=$cost;
		}else{ output("`n $wmsg "); }
		break;
		case 3:	output("`n`n`3 $d $c`3- $who $e $c`3 - it's a draw! ");break;
	}
}else if ($HTTP_GET_VARS[op]=="rule"){
	output("`n`n$a`3, $b`3, $c `3is a very common and easy game to play.`n`n");
	output("You select 1 of the 3 choices: $a`3, $b `3or $c`3.`n");
	output("Your opponent will select either: $a`3, $b `3or $c`3.`n`n");
	output("`^Who is the winner?`n");
	output("`3If both are the same; it's a draw, no one wins`n");
	output("$a `3wins over $c `3because $a `3dulls $c`n");
	output("$b `3wins over $a `3because $b `3can cover $a`n");
	output("$c `3wins over $b `3because $c `3can cut $b`n");
}
page_footer();
?>