
// Todo:
//	Add something in the mail screen to manage contacts (searching/etc)
//	personal user icons displayed in the stats

// Replacement mail.php
// Don't have time at the mo to work out the diffs for the mail script, sorry
// 28th Feb 2004


<?
// Original code from sourceforge
// Contact Mods by Dasher on www.sembrance.uni.cc/rpg (MSN: david@ashwood.net/ Mail: david@inspiredthinking.co.uk)
// Any comments/suggestions let me know
// 28th Feb 2004

require_once "common.php";

// Delete old mail
$sql = "DELETE FROM mail WHERE sent<'".date("Y-m-d H:i:s",strtotime("-".getsetting("oldmail",14)."days"))."'";
db_query($sql);

popup_header("The Mail System");
output("<a href='mail.php' class='motd'>Inbox</a><a href='mail.php?op=address' class='motd'>Write</a><a href='mail.php?op=contacts' class='motd'>Contacts</a>`n`n",true);

switch ($HTTP_GET_VARS[op]){
	case "del":
		$sql = "DELETE FROM mail WHERE msgto='".$session[user][acctid]."' AND messageid='$_GET[id]'";
		db_query($sql);
		header("Location: mail.php");
		exit();	
	break;
	case "process":
		if (!is_array($_POST['msg']) || count($_POST['msg'])<1){
			$session['message'] = "`\$`bYou cannot delete zero messages!  What does this mean?  You pressed \"Delete Checked\" but there are no messages checked!  What sort of world is this that people press buttons that have no meaning?!?`b`0";
			header("Location: mail.php");
		}else{
			$sql = "DELETE FROM mail WHERE msgto='".$session[user][acctid]."' AND messageid IN ('".join("','",$_POST[msg])."')";
			db_query($sql);
			header("Location: mail.php");
			exit();
		}
	break;
	case "delcontacts":
		if (!is_array($_POST['contact']) || count($_POST['contact'])<1){
			$session['message'] = "`\$`bYou cannot delete zero contacts!  What does this mean?  You pressed \"Delete Checked\" but there are no contacts checked!  What sort of world is this that people press buttons that have no meaning?!?`b`0";
			header("Location: mail.php");
		}else{
			$sql = "DELETE FROM lotbd_contacts WHERE ownerAcctID='".$session['user']['acctid']."' AND rowID IN ('".join("','",$_POST[contact])."')";
			db_query($sql);
//			redirect("mail.php");
			header("Location: mail.php");
			exit();
		}
	break;

	case "AddToContacts":
		$id=$HTTP_GET_VARS['id'];
		if ($id=="") {
			output("You cannot add an ID of nothing!`n");
		} else {
			if (array_key_exists("ID:".$id,$session['contacts'])!=true) {
				// Not found in current contacts
				$sql = "INSERT INTO lotbd_contacts (owneracctid, contactacctid, notifywhenonline) VALUES (".$session['user']['acctid'].", ".$id.",1 )";
				$result = db_query($sql);
				output("Contact Added");
			} else {
				// Found in the current contacts
				output($session['contacts']["ID:".$id]['name']."`n");
				output("That person already exists in your contacts");
			}
		}
	break;

	case "contacts":
		output("`b`iHere are your contacts`i`b`n`n");
		output($session['message']);
		$session['message']="";
		$sql = "SELECT * FROM lotbd_contacts LEFT JOIN accounts ON accounts.acctid=lotbd_contacts.contactAcctID WHERE lotbd_contacts.ownerAcctID=\"".$session['user']['acctid']."\" ";
		$result = db_query($sql);
		if (db_num_rows($result)>0){
			output("<form action='mail.php?op=delcontacts' method='POST'><table>",true);
			for ($i=0;$i<db_num_rows($result);$i++){
				$row = db_fetch_assoc($result);
				output("<tr>",true);
				output("<td nowrap><input id='checkbox$i' type='checkbox' name='contact[]' value='$row[rowID]'></td>",true);
				$link = "bio.php?char=".rawurlencode($row[login]) . "&ret=".URLEncode($_SERVER['REQUEST_URI']);
//				output("<td><a href='mail.php?op=read&id=$row[messageid]'>",true);
				output("<td><a href='".$link."'>",true);
				output($row[name]);
				output("</a></td></tr>",true);
			}
			output("</table>",true);
			$out="<input type='button' value='Check All' class='button' onClick='";
			for ($i=$i-1;$i>=0;$i--){
				$out.="document.getElementById(\"checkbox$i\").checked=true;";
			}
			$out.="'>";
			output($out,true);
			output("<input type='submit' class='button' value='Delete Checked'>",true);
			output("</form>",true);
			output("`n`n`iYou have ".db_num_rows($result)." Contacts.`n");
		}else{
			output("`iYou have no contacts.`i");
		}

	break;
	case "read":
		$sql = "UPDATE mail SET seen=1 WHERE  msgto=\"".$session[user][acctid]."\" AND messageid=\"".$_GET[id]."\"";
		db_query($sql);
		$sql = "SELECT mail.*,accounts.name FROM mail LEFT JOIN accounts ON accounts.acctid=mail.msgfrom WHERE msgto=\"".$session[user][acctid]."\" AND messageid=\"".$_GET[id]."\"";
		$result = db_query($sql) or die(db_error(LINK));
		if (db_num_rows($result)>0){
			$row = db_fetch_assoc($result);
			if ($row[msgfrom]=="") $row[name]="`iSystem`i";
			if (array_key_exists("ID:".$row[msgfrom],$session[contacts])!=false) {
				$Img="contact.GIF";
				$altText="Your Contact";
				output("<img src='images/".$Img."' width='16' height='16' alt='".$altText."'>",true);
				output("`n");
			}
			output("`b`2From:`b `^$row[name]`n");
			output("`b`2Subject:`b `^$row[subject]`n");
			output("`b`2Sent:`b `^{$row['sent']}`n");
			output("<img src='images/uscroll.GIF' width='182' height='11' alt='' align='center'>`n",true);
			output(str_replace("\n","`n","$row[body]"));
			output("`n<img src='images/lscroll.GIF' width='182' height='11' alt='' align='center'>`n",true);
			if (array_key_exists("ID:".$row[msgfrom],$session[contacts])!=false) {
				output("<a href='mail.php?op=write&replyto=$row[messageid]' class='motd'>Reply</a><a href='mail.php?op=del&id=$row[messageid]' class='motd'>Del</a>",true);
			} else {
				output("<a href='mail.php?op=write&replyto=$row[messageid]' class='motd'>Reply</a><a href='mail.php?op=del&id=$row[messageid]' class='motd'>Del</a><a href='mail.php?op=AddToContacts&id=$row[msgfrom]' class='motd'>&nbsp;Add&nbsp;to&nbsp;Contacts</a>",true);
			}
		}else{
			output("Eek, no such message was found!");
		}
	break;
	case "send":
		$sql = "SELECT acctid FROM accounts WHERE login='$_POST[to]'";
		$result = db_query($sql);
		if (db_num_rows($result)>0){
			$row1 = db_fetch_assoc($result);
			$sql = "SELECT count(messageid) AS count FROM mail WHERE msgto='".$row1[acctid]."' AND seen=0";
			$result = db_query($sql);
			$row = db_fetch_assoc($result);
			if ($row[count]>getsetting("inboxlimit",50)) {
				output("You cannot send that person mail, their mailbox is full!");
			}else{
				$_POST[subject]=str_replace("`n","",$_POST[subject]);
				$_POST[body]=str_replace("`n","\n",$_POST[body]);
				$_POST[body]=str_replace("\r\n","\n",$_POST[body]);
				$_POST[body]=str_replace("\r","\n",$_POST[body]);
				$_POST[body]=substr($_POST[body],0,(int)getsetting("mailsizelimit",1024));
				systemmail($row1[acctid],$_POST[subject],$_POST[body],$session[user][acctid]);
				output("Your message was sent!`n");
			}
		} else {
			output("Could not find the recipient, please try again.`n");
		}
		$_GET['op']="";
	break;
	case "address":
		output("<form action='mail.php?op=write' method='POST'>",true);
		output("`b`2Address:`b`n");
		output("`2T<u>o</u>: <input name='to' accesskey='o'> <input type='submit' class='button' value='Search'></form>",true);
	break;
	case "write":
		$subject="";
		$body="";
		output("<form action='mail.php?op=send' method='POST'>",true);
		if ($_GET[replyto]!=""){
			$sql = "SELECT mail.body,mail.subject,accounts.login,accounts.name FROM mail LEFT JOIN accounts ON accounts.acctid=mail.msgfrom WHERE msgto=\"".$session[user][acctid]."\" AND messageid=\"".$_GET[replyto]."\"";
			$result = db_query($sql) or die(db_error(LINK));
			if (db_num_rows($result)>0){
				$row = db_fetch_assoc($result);
				if ($row[login]=="") {
					output("You cannot reply to a system message.`n");
					$row=array();
				}
			}else{
				output("Eek, no such message was found!`n");
			}
		}
		if ($_GET[to]!=""){
			$sql = "SELECT login,name FROM accounts WHERE login=\"$_GET[to]\"";
			$result = db_query($sql) or die(db_error(LINK));
			if (db_num_rows($result)>0){
				$row = db_fetch_assoc($result);
			}else{
				output("Could not find that person.`n");
			}
		}
		if (is_array($row)){
			if ($row[subject]!=""){
				$subject=$row[subject];
				if (substr($subject,0,4)!="Rply: ") $subject="Rply: $subject";
			}
			if ($row[body]!=""){
				$body="\n\n---Replying to---\n".$row[body];
			}
		}
		if ($row[login]!=""){
			output("<input type='hidden' name='to' value=\"".HTMLEntities($row[login])."\">",true);
			output("`2To: `^$row[name]`n");
		}else{
			output("`2To: ");
			$string="%";
			for ($x=0;$x<strlen($_POST['to']);$x++){
				$string .= substr($_POST['to'],$x,1)."%";
			}
			$sql = "SELECT login,name FROM accounts WHERE name LIKE '".addslashes($string)."' AND locked=0 ORDER BY login";
			$result = db_query($sql);
			if (db_num_rows($result)==1){
				$row = db_fetch_assoc($result);
				output("<input type='hidden' name='to' value=\"".HTMLEntities($row[login])."\">",true);
				output("`^$row[name]`n");
			}else{
				output("<select name='to'>",true);
				for ($i=0;$i<db_num_rows($result);$i++){
					$row = db_fetch_assoc($result);
					output("<option value=\"".HTMLEntities($row[login])."\">",true);
					output(preg_replace("/[`]./","",$row[name]));
				}
				output("</select>`n",true);
			}
		}
		output("`2Subject:");
		$output.=("<input name='subject' value=\"".HTMLEntities($subject).HTMLEntities(stripslashes($_GET['subject']))."\">");
		output("`n`2Body:`n");
		$output.="<textarea name='body' class='input' cols='40' rows='9'>".HTMLEntities($body).HTMLEntities(stripslashes($_GET['body']))."</textarea><br>";
		output("<input type='submit' class='button' value='Send'>`n",true);
		output("</form>",true);
	break;
	default;
		output("`b`iHere is your mailbox...`i`b");
		output($session['message']);
		$session['message']="";
		$sql = "SELECT subject,messageid,accounts.name,msgfrom,seen,sent FROM mail LEFT JOIN accounts ON accounts.acctid=mail.msgfrom WHERE msgto=\"".$session[user][acctid]."\" ORDER BY seen,sent";
		$result = db_query($sql);
		if (db_num_rows($result)>0){
			output("<form action='mail.php?op=process' method='POST'><table>",true);
			for ($i=0;$i<db_num_rows($result);$i++){
				$row = db_fetch_assoc($result);
				if ((int)$row[msgfrom]==0) $row[name]="`i`^System`0`i";
				output("<tr>",true);
				if (array_key_exists("ID:".$row[msgfrom],$session[contacts])!=false) {
					$Img="contact.GIF";
					$altText="Your Contact";
					output("<td nowrap><input id='checkbox$i' type='checkbox' name='msg[]' value='$row[messageid]'><img src='images/".($row[seen]?"old":"new")."scroll.GIF' width='16' height='16' alt='".($row[seen]?"Old":"New")."'><img src='images/".$Img."' width='16' height='16' alt='".$altText."'></td>",true);
				} else {
					$Img="trans.gif";
					$altText="Not Your Contact";
					output("<td nowrap><input id='checkbox$i' type='checkbox' name='msg[]' value='$row[messageid]'><img src='images/".($row[seen]?"old":"new")."scroll.GIF' width='16' height='16' alt='".($row[seen]?"Old":"New")."'></td>",true);
				}
//				output("<td nowrap><input id='checkbox$i' type='checkbox' name='msg[]' value='$row[messageid]'><img src='images/".($row[seen]?"old":"new")."scroll.GIF' width='16' height='16' alt='".($row[seen]?"Old":"New")."'></td>",true);
				output("<td><a href='mail.php?op=read&id=$row[messageid]'>",true);
				output($row[subject]);
				output("</a></td><td><a href='mail.php?op=read&id=$row[messageid]'>",true);
				output($row[name]);
				output("</a></td><td><a href='mail.php?op=read&id=$row[messageid]'>".date("M d, h:i a",strtotime($row[sent]))."</a></td>",true);
				output("</tr>",true);
			}
			output("</table>",true);
			$out="<input type='button' value='Check All' class='button' onClick='";
			for ($i=$i-1;$i>=0;$i--){
				$out.="document.getElementById(\"checkbox$i\").checked=true;";
			}
			$out.="'>";
			output($out,true);
			output("<input type='submit' class='button' value='Delete Checked'>",true);
			output("</form>",true);
		}else{
			output("`iYou have no new messages.`i");
		}
		output("`n`n`iYou have ".db_num_rows($result)." messages in your inbox.`nYou may only have ".getsetting('inboxlimit',50)." messages in your inbox.  `nMessages are deleted after ".getsetting("oldmail",14)." days");

	break;
}

popup_footer();
?>


// Changes to common.php
// Right at the bottom of the script above the $beta setting
// CR#Dasher#003 - 28th Feb 2004
// Contacts - both for the mail and showing when people are online via the contacts panel
$session['contacts']=array();
$loggedin=false;
$sql = "SELECT name, loggedin, alive, superuser, laston, contactacctid  FROM lotbd_contacts LEFT JOIN accounts ON accounts.acctid=lotbd_contacts.contactAcctID WHERE lotbd_contacts.ownerAcctID=\"".$session[user][acctid]."\" ";
// alive selected to show when they are dead
$result = db_query($sql);
if (db_num_rows($result)>0){
	for ($i=0;$i<db_num_rows($result);$i++){
		$row = db_fetch_assoc($result);
		if ($row['loggedin']==1) {
			$loggedin=true;
		} else {
			$loggedin=false;
		}
		$session[contacts]["ID:".$row['contactacctid']]=array("name"=>$row['name'], "online"=>$loggedin, "alive"=>$row['alive'], "superuser"=>$row['superuser'], "laston"=>$row['laston']);
	}
} else {
	// No contacts defined
}
// --


// Updated Charstats
function charstats(){
	global $session;
	$u =& $session[user];
	if ($session[loggedin]){
		$u['hitpoints']=round($u['hitpoints'],0);
		$u['experience']=round($u['experience'],0);
		$u['maxhitpoints']=round($u['maxhitpoints'],0);
		$spirits=array("-6"=>"Resurrected","-2"=>"Very Low","-1"=>"Low","0"=>"Normal","1"=>"High","2"=>"Very High");
		if ($u[alive]){ }else{ $spirits[$u[spirits]] = "DEAD"; }
		reset($session[bufflist]);
		$atk=$u[attack];
		$def=$u[defence];
		while (list($key,$val)=each($session[bufflist])){
			$buffs.=appoencode("`#$val[name] `7($val[rounds] rounds left)`n",true);
			if (isset($val[atkmod])) $atk *= $val[atkmod];
			if (isset($val[defmod])) $def *= $val[defmod];
		}

// Contacts
		reset($session['contacts']);
		while (list($key,$val)=each($session['contacts'])){
			if ($val['online']==true) {
				if ($val['superuser']>=2) {
					$timeout=getsetting("ADMINLOGINTIMEOUT",2700);
				} else {
					$timeout=getsetting("LOGINTIMEOUT",900);
				}
				$loggedin=(date("U") - strtotime($val['laston']) < $timeout && $val['online']);
				if ($val['alive']==1) {
					if ($loggedin) $contacts.=appoencode($val['name']."`&is online`n",true);
				} else {
					if ($loggedin) $contacts.=appoencode($val['name']."`&is online but `iDead`i`n",true);
				}

			} else {
				$contacts.=appoencode($val['name']."`7is not online`n",true);
			}
		}

		if (count($session['contacts'])==0){
			$contacts.=appoencode("`^No Contacts defined`0",true);
		}
// --

		$atk = round($atk, 2);
		$def = round($def, 2);
		$atk = ($atk == $u[attack] ? "`^" : ($atk > $u[attack] ? "`@" : "`$")) . "`b$atk`b`0";
		$def = ($def == $u[defence] ? "`^" : ($def > $u[defence] ? "`@" : "`$")) . "`b$def`b`0";

		if (count($session[bufflist])==0){
			$buffs.=appoencode("`^None`0",true);
		}
		$charstat=appoencode(templatereplace("statstart")
		.templatereplace("stathead",array("title"=>"Vital Info"))
		.templatereplace("statrow",array("title"=>"Name","value"=>appoencode($u[name],false)))
		,true);
		if ($session['user']['alive']){

			$charstat.=appoencode(
			templatereplace("statrow",array("title"=>"Hitpoints","value"=>"$u[hitpoints]`0/$u[maxhitpoints]"))
			.templatereplace("statrow",array("title"=>"Turns","value"=>$u['turns']))
			,true);
		}else{
			$charstat.=appoencode(
			 templatereplace("statrow",array("title"=>"Soul Points","value"=>$u['soulpoints']))
			.templatereplace("statrow",array("title"=>"Torments","value"=>$u['gravefights']))
			,true);
		}
		$charstat.=appoencode(
		templatereplace("statrow",array("title"=>"Spirits","value"=>"`b".$spirits[(string)$u['spirits']]."`b"))
		.templatereplace("statrow",array("title"=>"Level","value"=>"`b".$u['level']."`b"))
		.($session['user']['alive']?
			 templatereplace("statrow",array("title"=>"Attack","value"=>$atk))
			.templatereplace("statrow",array("title"=>"Defense","value"=>$def))
			:
			 templatereplace("statrow",array("title"=>"Psyche","value"=>10 + round(($u['level']-1)*1.5)))
			.templatereplace("statrow",array("title"=>"Spirit","value"=>10 + round(($u['level']-1)*1.5)))
			)
		.templatereplace("statrow",array("title"=>"Gems","value"=>$u['gems']))
		.templatereplace("stathead",array("title"=>"Miscellaneous info"))
		.templatereplace("statrow",array("title"=>"Gold","value"=>$u['gold']))
		.templatereplace("statrow",array("title"=>"Experience","value"=>$u['experience']))
		.templatereplace("statrow",array("title"=>"Weapon","value"=>$u['weapon']))
		.templatereplace("statrow",array("title"=>"Armor","value"=>$u['armor']))
		,true);
		if (!is_array($session[bufflist])) $session[bufflist]=array();
		$charstat.=appoencode(templatereplace("statbuff",array("title"=>"Buffs:","value"=>$buffs)),true);
// Contacts
		$charstat.=appoencode(templatereplace("statcontacts",array("title"=>"Contacts:","value"=>$contacts)),true);
//
		$charstat.=appoencode(templatereplace("statend"),true);
		return $charstat;
	}else{
		//return "Your character info will appear here after you've logged in.";
		//$sql = "SELECT name,alive,location,sex,level,laston,loggedin,lastip,uniqueid FROM accounts WHERE locked=0 AND loggedin=1 ORDER BY level DESC";
		$sql="SELECT name,alive,location,sex,level,laston,loggedin,lastip,uniqueid FROM accounts WHERE locked=0 AND loggedin=1 AND laston>'".date("Y-m-d H:i:s",strtotime("-".getsetting("LOGINTIMEOUT",900)." seconds"))."' ORDER BY level DESC";
		$ret.=appoencode("`bOnline Characters:`b`n");
		$result = db_query($sql) or die(sql_error($sql));
		for ($i=0;$i<db_num_rows($result);$i++){
			$row = db_fetch_assoc($result);
			//$loggedin=(date("U") - strtotime($row[laston]) < getsetting("LOGINTIMEOUT",900) && $row[loggedin]);
			//if ($loggedin) {
				$ret.=appoencode("`^$row[name]`n");
				$onlinecount++;
			//}
		}
		db_free_result($result);
		if ($onlinecount==0) $ret.=appoencode("`iNone`i");
		return $ret;
	}
}

// Template changes
// in templatename.htm in the stats section (ie yarbrough.htm)
<!--!statcontacts--><tr><td class='charinfo' colspan='2'><b>{title}:</b>`n{value}</td></tr>


// DB Changes
// New table
CREATE TABLE `lotbd_contacts` (
  `rowID` bigint(20) unsigned NOT NULL auto_increment,
  `ownerAcctID` int(10) unsigned NOT NULL default '0',
  `contactAcctID` int(10) unsigned NOT NULL default '0',
  `notifyWhenOnline` tinyint(1) default '0',
  PRIMARY KEY  (`rowID`,`ownerAcctID`),
  KEY `idx_Contacts` (`ownerAcctID`)
) TYPE=MyISAM COMMENT='Contacts table for email and notifying when people are online'; 






