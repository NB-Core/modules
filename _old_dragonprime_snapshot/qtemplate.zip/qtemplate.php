<?php
/*    LotGD version 097
      Simple 2 step quest template
      
      created to help newbie coders

	Fill in the text for your story
	Insure a nav link is in each block
	rename this page to whatever you choose
	make a link to this page from somewhere in your realm
*/

require_once "common.php";
checkday();
// Page Header - Name that appears on top of page
page_header(" Spiders Web ");

// first thing player reads when entering
if ($HTTP_GET_VARS[op]==""){
output("`n`n`7 Along the path you come upon a crevice in the ground. ");
output("`n`n You look and see it is big enough to squeeze through. ");
output("`n`n However, the opening is blocked by a spiders web. ");
output("`n`n You begin to wonder what else lies in the crevice. ");
output("`n`n What will you do?. ");
addnav(" Spiders Web ");
addnav("(C) Cut the Web","qtemplate.php?op=cut");
addnav("(R) Run Away! ","qtemplate.php?op=run");
}
// If they run away and choose not to continue
if ($HTTP_GET_VARS[op]=="run"){
output("`n`n`7 You run all the way back to the Forest. ");
output("`n`n Completely frightened, you decide you are not brave enough to make this adventure. ");
addnav(" exit ");
addnav("(R) Return to Forest","forest.php");
}
// This is if they choose to begin
if ($HTTP_GET_VARS[op]=="cut"){
	output("`n`n`7 You decide to venture forth and hack your way through the spiders web");
	output(" something happens - something is discovered - or make more options ");
	addnav(" choices ");
	addnav("(1) option 1","qtemplate.php?op=xxxx1a");
	addnav("(2) option 2","qtemplate.php?op=xxxx1b");
}
// option 1a
if ($HTTP_GET_VARS[op]=="xxxx1a"){
	output("`n`n`7 they choose to take option 1 ");
	output("`n`n what happens if they do is inserted here ");
	// end of quest? add a link back to forest or village - remove next line if NO
	addnav("(R) Return to wherever","forest.php");
	// Do they continue? if yes:
	addnav(" choices ");
	addnav("(1) step 2a","qtemplate.php?op=xxxx2a");
	// - there must be a nav link to somewhere 
}
// option 1b
if ($HTTP_GET_VARS[op]=="xxxx1b"){
	output("`n`n`7 they choose to take option 2 ");
	output("`n`n what happens if they do is inserted here ");
	// end of quest? add a link back to forest or village - remove next line if NO
	addnav("(R) Return to wherever","forest.php");
	// Do they continue? if yes:
	addnav(" choices ");
	addnav("(1) step 2b","qtemplate.php?op=xxxx2b");
	// - there must be a nav link to somewhere 
}
// step 2 1st choice
if ($HTTP_GET_VARS[op]=="xxxx2a"){
	output("`n`n`7 step 2 - 1st choice ");
	output("`n`n what happens if they do is inserted here ");
	// end of quest? add a link back to forest or village - must have a nav link out
	addnav("(R) Return to wherever","forest.php");
}
// step 2 2nd choice
if ($HTTP_GET_VARS[op]=="xxxx2b"){
	output("`n`n`7 step 2 - 2nd choice ");
	output("`n`n what happens if they do is inserted here ");
	// end of quest? add a link back to forest or village - must have a nav link out
	addnav("(R) Return to wherever","forest.php");
}

page_footer();
?>