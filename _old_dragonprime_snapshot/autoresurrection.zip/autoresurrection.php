<?php
//Logd 0.9.8 autoresurrection module
//Created by Damien(JV)
//Tested with pre-rel 7 and later

function autoresurrection_getmoduleinfo(){
	$info = array(
		"name"=>"AutoResurrection",
		"author"=>"Damien",
		"version"=>"1.3",
		"category"=>"General",
		"download"=>"http://dragonprime.net/users/Damien",
		"settings"=>array(
			"Resurrection settings,title",
			"deadtime_nodks"=>"How many days a player has to be dead until automatic resurrection (DKs=0),range,1,30,1|4",
			"deadtime_dks"=>"How many days a player has to be dead until automatic resurrection (DKs>0),range,1,30,1|4",
		),
		"prefs"=>array(
		        "Resurrection user preferences,title",
			"deadflag"=>"Has died,bool|0",
			"timeofdead"=>"Time of dead,int|0",
		),
	);
	return $info;
}

function autoresurrection_install(){
	module_addhook("footer-shades");
	module_addhook("footer-graveyard");
	module_addhook("newday-runonce");
	module_addhook("newday");
	module_addhook("footer-news");
	module_addhook("battle-victory");
        return true;
}

function autoresurrection_uninstall(){
        return true;
}

function autoresurrection_dohook($hookname,$args){
	global $session;

        switch($hookname){

	case "footer-shades":
	     //If a player ends up to the shades straight after dying(e.g. dying in a module?)
	     if($session['user']['alive']==0 and get_module_pref("deadflag")==0){
                $timeofdead=time();
		set_module_pref("deadflag",1);
	        set_module_pref("timeofdead",$timeofdead);
	     }
	     if($session['user']['dragonkills']>0)
	        output("`n`n`$ You'll be automatically resurrected in %s days (real time).", get_module_setting("deadtime_dks"));
	     else
	        output("`n`n`$ You'll be automatically resurrected in %s days (real time).", get_module_setting("deadtime_nodks"));
	break;
	
	case "footer-graveyard":
	     //If a player ends up to the graveyard straight after dying(e.g. dying in a module?)
	     if($session['user']['alive']==0 and get_module_pref("deadflag")==0){
	        $timeofdead=time();
		set_module_pref("deadflag",1);
	        set_module_pref("timeofdead",$timeofdead);
	     }
	     if($session['user']['dragonkills']>0)
	        output("`n`n`$ You'll be automatically resurrected in %s days (real time).", get_module_setting("deadtime_dks"));
	     else
	        output("`n`n`$ You'll be automatically resurrected in %s days (real time).", get_module_setting("deadtime_nodks"));
	break;

	case "footer-news":
	     //Sometime after dying a player has to go to the shades via news(forest dying or pvp dying)
	     if($session['user']['loggedin']==1 and $session['user']['alive']==0 and get_module_pref("deadflag")==0){
	        $timeofdead=time();
		set_module_pref("deadflag",1);
	        set_module_pref("timeofdead",$timeofdead);
	     }
	     //This is here because a player might have been killed in pvp and when he/she logs in again he/she is alive again
	     //so we need to zero the values(after login player comes first to news page, at least it did when I tested this)
	     if($session['user']['loggedin']==1 and $session['user']['alive']==1 and get_module_pref("deadflag")==1){
		set_module_pref("deadflag",0);
	        set_module_pref("timeofdead",0);
	     }
	break;
	
	case "battle-victory":
	     //if a player is killed by someone in a pvp fight we need to set values for it
	     global $badguy;
	     if($badguy['type']=='pvp'){
	        $timeofdead=time();
	        set_module_pref("timeofdead",$timeofdead,"autoresurrection",$badguy['acctid']);
	        set_module_pref("deadflag",1,"autoresurrection",$badguy['acctid']);
	     }

	break;
	
	case "newday":
	     //Zero time of dead and deadflag if a player is resurrected by himself(new day or ramius)
	     set_module_pref("deadflag",0);
	     set_module_pref("timeofdead",0);
	break;

	case "newday-runonce":
	     //current date and time in seconds
	     $currenttime = time();
	     //How many days a player must be dead until autom. resurrection
	     $deadtime_nodks = get_module_setting("deadtime_nodks");
	     $deadtime_dks = get_module_setting("deadtime_dks");
	     //Initiate counter for resurrected players
	     $resurrections=0;
	     //Fetch all players who are dead at the moment
	     $sql = "SELECT acctid,dragonkills FROM ".db_prefix("accounts")." WHERE alive=0";
	     $result = db_query($sql);
	     //Start creating a new query to bring people alive
	     $sql2 = "UPDATE ".db_prefix("accounts")." SET alive=1 WHERE ";
	     while($row = db_fetch_assoc($result)){
		   //We have different setting for people with DKs and people without DKs
		   if($row['dragonkills']>0)
		      $deadtime = $deadtime_dks;
		   else
                      $deadtime = $deadtime_nodks;

		   //Fetch time of dead for each player.
		   $timeofdead = get_module_pref("timeofdead","autoresurrection",$row['acctid']);
		   
		   //If current date&time - date&time of dead >= autom. res. days
		   if((int)(((($currenttime-$timeofdead)/60)/60)/24)>=$deadtime){
		      //Add player into sql query
		      $sql2.="acctid=".$row['acctid']." OR ";
		      //Zero player's time of dead and deadflag
		      set_module_pref("timeofdead",0,"autoresurrection",$row['acctid']);
		      set_module_pref("deadflag",0,"autoresurrection",$row['acctid']);
		      //Add one into resurrections counter
		      $resurrections++;
		      //debuglog("resurrected automatically",$row['acctid']);
		   }//end if
	     
	     }//end while
	     
	     //If one of more players resurrected
	     if($resurrections>0){
	        //Cut away the last OR from the sql query
		$finalsql = substr_replace($sql2, '', strlen($sql2)-4, -1);
		//Run sql query
		db_query($finalsql);
		//Add information about new targets into daily news
		addnews("Some of us are once again back in the book of the living.");
	     }

	break;

	}
	
	return $args;
}


?>
