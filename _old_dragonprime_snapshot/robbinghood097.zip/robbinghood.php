<? 
/********************
Robbing Hood - Ver2 Mar2004
Written by Robert for Maddnet LoGD
Robbing Hood trades gems for torments
ver 1-Feb2004
You need to add a link to robbinghood.php in your graveyard.php:
Line 120 or near there under: addnav("Return to the shades","shades.php");
ADD THIS ->	if ($session[user][gravefights]<1) addnav("(H) Robbing Hood","robbinghood.php");
*********************/
require_once "common.php";  

if ($session['user']['gems']<2) {
     page_header("Graveyard");
     output("`c<font size='+1'>`4Squire Robbing Hood</font>`c`n`n",true);
	 output("`n`n'`&Sorry mate - you have nothing of value I want!`4'");
	 addnav("(R) Return to Graveyard" ,"graveyard.php");}
else{

checkday();
page_header("Graveyard");
output("`c<font size='+1'>`4Squire Robbing Hood</font>`c`n`n",true);
if ($HTTP_GET_VARS[op]==""){ 
      output("`7You approach `4Squire Robbing Hood `7to see what kind of deal can be made to leave this foresaken place.`6`n");
      output(" 'G'day mate!' says `4Robbing Hood`6, 'I see you had a bit of trouble' `n"); 
      output(" 'And seeing how you got some Gems, I'm willing to make you an offer. `n"); 
      output(" 'For the small price of only `^2 Gems`6 - I can arrange for you to get some more torments'.`n"); 
      output(" 'So, what do you say mate, Do we have a deal?' `n");  
      addnav("Make a Deal"); 
      addnav("(M) Make the deal","robbinghood.php?op=agree"); 
      addnav("Leave");
      addnav("(R) Never mind","graveyard.php"); 
      
}else if ($HTTP_GET_VARS[op]=="agree"){ 
 
      output(" `n`7You made a deal with `4Squire Robbing Hood!.`n"); 
      output(" `n`b`7You agreed to give `4Squire Robbing Hood `72 of your precious Gems.`b`n"); 
      output(" Robbing Hood gives you a small vial with a potion that will grant you 3 more torments. `n`n "); 
      output(" `6'By the way mate, if you run out of torments and have some Gems, I'll come see you again!'`7 `n");  
      addnav("Leave");
      addnav("(R) Return to Graveyard","graveyard.php");
        $session[user][gems] -= 2; 
        $session['user']['gravefights']+=3;
        $session['user']['soulpoints']+=5; 
        debuglog("gave 2 gems to Robbing Hood"); 
        addnews($session[user][name]." `7was helped by Robbing Hood in the Graveyard!");
    } 
}
page_footer();
?> 