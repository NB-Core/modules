<?php
function holiday_thanksgiving_getmoduleinfo(){
	$info = array(
		"name"=>"Holiday - Thanksgiving",
		"version"=>"20051123",
		"author"=>"Sixf00t4",
		"category"=>"Holiday Texts",
		"download"=>"",
		"settings"=>array(
			"Thanksgiving Holiday Settings,title",
			"activate"=>"Activation date (mm-dd)|11-24",
		),
		"prefs"=>array(
			"Thanksgiving Holiday User Preferences,title",
			"user_ignore"=>"Ignore Thanksgiving Holiday text,bool|0",
		),
	);
	return $info;
}

function holiday_thanksgiving_install(){
	module_addhook("holiday");
	return true;
}

function holiday_thanksgiving_uninstall(){
	return true;
}

function holiday_thanksgiving_munge($in) {
	$out = $in;
	$out = preg_replace("'([^[:alpha:]])ale([^[:alpha:]])'i","\\1cranberry juice\\2",$out);
	$out = preg_replace("'([^[:alpha:]])hi([^[:alpha:]])'i","\\1gobble gooble\\2",$out);
	$out = preg_replace("'([^[:alpha:]])hello([^[:alpha:]])'i","\\1gobble gobble\\2",$out);
	$out = preg_replace("'Forest'i","Place of Thanks",$out);
	$out = preg_replace("'Green Dragon'i","Fat Turkey",$out);
	$out = preg_replace("'Dragon'i","Turkey",$out);
	$out = preg_replace("'dragon'i","turkey",$out);
	$out = str_replace("Fists","Turkey baster",$out);
	$out = str_replace("MightyE","William Bradford",$out);
	$out = str_replace("Bluspring", "Samoset", $out);
	$out = preg_replace("'Bank'i"," Squanto's TeePee",$out);
	$out = preg_replace("'([^[:alpha:]])inn([^[:alpha:]])'i","\\1cornucopia\\2",$out);
	$out = preg_replace("'garden'i","dining table",$out);
	$out = str_replace("Merick","Massasoit",$out);
	$out = str_replace("kill","harvest",$out);
	$out = str_replace("Slay","Harvest",$out);
	$out = str_replace("the dead", "the harvested", $out);
	$out = preg_replace("'Village'i","Plymouth Rock",$out);
	$vname = getsetting("villagename", LOCATION_FIELDS);
	$out = preg_replace("'$vname'i","Plymouth Rock",$out);
	$out = preg_replace("'farmboy'i","Pilgrim",$out);
	$out = preg_replace("'farmie'i","Pilgrim",$out);
	$out = preg_replace("'farmgirl'i","Pilgrim",$out);
	$out = str_replace(". ",". Gobble. ",$out);
	$out = str_replace(", ",", gobble gobble, ",$out);
	return $out;
}

function holiday_thanksgiving_dohook($hookname,$args){
	switch($hookname){
	case "holiday":
		if(get_module_pref("user_ignore")) break;
		$mytime = get_module_setting("activate");
		list($amonth,$aday) = split("-", $mytime);
		$amonth = (int)$amonth;
		$aday = (int)$aday;
		$month = (int)date("m");
		$day = (int)date("d");
		if ($month == $amonth && $day == $aday) {
			$args['text'] = holiday_thanksgiving_munge($args['text']);
		}
		break;
	}
	return $args;
}

function holiday_thanksgiving_run(){

}
?>
