<?php
/*
A port of the banking vulture from LoRD.  There's an invisible keyboard-only nav
in the forest ("B"). Deposits all your gold on hand into the bank.
The secret is, you have to know about this first to make use of it.

Also a proof of concept for "secret" navs. I'm almost completely certain this works safely.
*/

function forestbankvulture_getmoduleinfo(){
	$info = array(
		"name"=>"Forest Banking Vulture",
		"version"=>"1.0",
		"author"=>"Catscradler",
		"category"=>"Forest",
		"download"=>"http://dragonprime.net",
	);
	return $info;
}

function forestbankvulture_install(){
	module_addhook("forest");
	return true;
}

function forestbankvulture_uninstall(){
	return true;
}

function forestbankvulture_dohook($hookname,$args){
	global $session;
	if ($session['user']['gold']<=0) return $args;

	global $accesskeys,$quickkeys;
	//ALWAYS pass through strtolower as accesskeys is indexed by lowercase
	$hkey=strtolower('b');
	
	//Check if the key's taken or the nav is blocked
	//Even if blocknav has been called on this, it can still be added through this
	//method, but will result in a badnav if followed.
	if ($accesskeys[$hkey]==1 || is_blocked("runmodule.php?module=forestbankvulture"))
		return $args;

	//declare the key taken
	$accesskeys[$hkey]=1;

	//set the action for the key
	$quickkeys[$hkey]="window.location='runmodule.php?module=forestbankvulture'";

	//add it to allowed navs
	addnav("","runmodule.php?module=forestbankvulture");
	return $args;
}

function forestbankvulture_run(){
	global $session;
	page_header("Vulture!");
	output("`&You throw your gold pouch up into the air gleefully.`n`n");
	output("`0AN UGLY VULTURE `4GRABS `0IT IN MID AIR!");
	$amount=$session['user']['gold'];
	$session['user']['goldinbank']+=$amount;
	$session['user']['gold']=0;
	debuglog("deposited $amount gold in the bank by vulture");
	require_once("lib/forest.php");
	forest(true);
	page_footer();
}
?>
