<?php
/*Resurrection abuse protection

This script save the amount of turns that the user has when they die and sets that as their base value when they are resurected*/
function dieabuse_getmoduleinfo(){
	$info = array(
		"name"=>"Resurrection Abuse Protection",
		"author"=>"Michael Tartre",
		"version"=>"1.0",
		"category"=>"General",
		"download"=>"http://dragonprime.net/users/SpiritOfFire/dieabuse.zip",
		"settings"=>array(
			"Resurrection Abuse Settings, title",
			"penalty"=>"What is the penalty in Forest Fights for a resurrection,int|6"
		),
		"prefs"=>array(
			"Resurrection Abuse Prefs, title",
			"ff_left"=>"How many forest fights does the user have,int|0"
		)
	);
	return $info;
};
function dieabuse_install() {
	module_addhook("newday");
	module_addhook("creatureencounter");
	module_addhook("village");
	return true;
};
function dieabuse_uninstall() {
	return true;
};
function dieabuse_dohook($hookname, $args) {
	global $session;
	$resurrection = httpget("resurrection");
	if($hookname == "newday") {
		if($resurrection) {
			$session['user']['turns'] = get_module_pref('ff_left') - get_module_setting('penalty');
			if($session['user']['turns'] < 0) {
				$session['user']['turns'] = 0;
			}
		}
	} else {
		if($session['user']['alive'] == 1) {
			set_module_pref('ff_left', $session['user']['turns']);
		}
	}
};