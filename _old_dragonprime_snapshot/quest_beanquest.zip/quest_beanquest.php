<?php
require_once("lib/villagenav.php");
require_once("lib/quests.php");

function quest_beanquest_getmoduleinfo(){
$info = array(
"name"=>"Quest - Search for the Lost Bean",
"version"=>"1.0",
"author" => "Lonny Luberts - Built with Module Builder by `3Lonny Luberts`0",
"category"=>"Quest",
"download" => "specialty_beanquest.zip",
"requires"=>array(
"questbasics" => "1.0|XChrisX, http://beta.lotgd.de/downloads/questpack.zip",
"cities" => "1.0|Eric Stevens, core_module",
"haberdasher" => "2.5|core distrobution",
),
"settings"=>array(
"questloc"=>"Where is the host module located?,location|".getsetting("villagename", LOCATION_FIELDS),
"req_min_hw" => "Required Hero Points to receive the quest, int|5",
"req_max_hw" => "Maximum Hero Points to receive the quest, int|10",
"req_min_dk" => "Required Dragon Kills to receive the quest, int|0",
"req_max_dk" => "Maximum Dragon Kills to receive the quest, int|0",
"req_min_lev" => "Minimum level to receive the quest, int|1",
"req_max_lev" => "Maximum level to receive the quest, int|2",
"req_quest" => "Is another quest required before starting this quest?, string|",
"req_superuser" => "Can the quest be done by superusers at any time?, bool|true",
"reward_exp" => "Reward (Experience), int|1000",
"reward_explevel" => "Additional experience points per level, int|50",
"reward_gems" => "Reward (Gems), int|1",
"reward_gold" => "Reward (Gold), int|500",
"reward_goldlevel" => "Additional gold per level, int|75",
"reward_quest" => "Number of quest points the player receives?, int|50",
),
"prefs" => array(
"queststarted" => "Has the player accepted the quest?, bool|false",
"queststation" => "What point in the quest is the player at?, int|0",
),
);
return $info;
}

function quest_beanquest_chance($where){
global $session;
$queststation = get_module_pref("queststation", "quest_beanquest");
if (requirements_met("quest_beanquest") || get_module_pref("queststarted", "quest_beanquest")) {
if ($where == "forest") {
if (($queststation == 0 || $queststation == 4) && $session['user']['location'] == get_module_setting("questloc")) {
$encounter = 50;
}else{
$encounter = 100;
}
} else if ($where == "forest" && $queststation == 2) {
$encounter = 100;
} else {
$encounter = 0;
}
return $encounter;
} else {
return 0;
}
}

function quest_beanquest_install() {

$station = array(
"-2" => "`\ Our hero has failed to complete the quest. `0",
"-1" => "`@ Our hero has completed the quest! `0",
"0" => "`6 - The Lost Bean - `0",
"1" => "`6 Our hero has begun his/her quest. `0",
"2" => "`6 Our hero has completed the second step. `0",
"3" => "`6 Our hero has completed step 3 `0",
"4" => "`6 Our hero has completed step 4 of the quest! `0",
);
$questfilename = "quest_beanquest";
db_query("DELETE FROM quests WHERE questname = '".$questfilename."'");
foreach($station as $outputstation => $entry) {
$sql = "INSERT INTO quests (questname, queststation, questdescription) VALUES ('".$questfilename."', '".$outputstation."', '".$entry."')";
db_query($sql);
}

module_addeventhook("village", "require_once(\"modules/quest_beanquest.php\"); return quest_beanquest_chance(\"village\");");
module_addeventhook("forest", "require_once(\"modules/quest_beanquest.php\"); return quest_beanquest_chance(\"forest\");");
module_addeventhook("travel", "require_once(\"modules/quest_beanquest.php\"); return quest_beanquest_chance(\"travel\");");
module_addhook("footer-runmodule");
return true;
}

function quest_beanquest_uninstall(){
return true;
}

function quest_beanquest_dohook($hookname,$args) {
global $session, $SCRIPT_NAME;
$script = substr($SCRIPT_NAME,0,strpos($SCRIPT_NAME,"."));
if ($script == "runmodule") $script = httpget('module');
$queststation = get_module_pref("queststation", "quest_beanquest");
if ($hookname == "footer-runmodule" && $queststation == 1 && $script == "haberdasher") {
addnav("-","");
addnav("Ask about the Bean.", "runmodule.php?module=quest_beanquest&step=haberdasher1");
} else if ($hookname == "footer-runmodule" && $queststation == 3 && $script == "haberdasher") {
addnav("-","");
addnav("Get the Bean.", "runmodule.php?module=quest_beanquest&step=haberdasher2");
}
return $args;
}

function quest_beanquest_runevent($type) {
global $session;

$queststation = get_module_pref("queststation", "quest_beanquest");
$questinprogress = get_module_pref("questinprogress", "questbasics");

if ($type == "village" && $queststation == 0 && $questinprogress < 1) {
output("`7 `@You are walking the village minding you own business... `n A Man walks up to you and says \"Hey there, I have lost my bean! If you find it for me, I will be forever grateful. I was visiting the Haberdashery when I discovered it missing\" `n`n");
start_quest("quest_beanquest");
} else if ($type == "forest" && $queststation == 2) {
output("`7 You come across Deimos in the forest...`nDeimos stops you and says \"Hey, I found that bean.. stop by my shop to pick it up.\"`n`n`n");
advance_quest("quest_beanquest");
} else if ($type == "village" && $queststation == 4) {
page_header(" ");
output("`7 As luck would have it you bump into the ban man. You hand him his bean! All is good in the world.");
end_quest("quest_beanquest");
villagenav();
page_footer();
}
}

function quest_beanquest_run(){
global $session;
$step = httpget('step');

if ($step == "haberdasher1") {
page_header(" The Search for the Lost Bean ");
output("`7 `@You step up to Deimos... `n\"Have you seen a bean? `nDeimos replies \"I may have.. What\'s it to you?\"`n\"Well, it has turned up missing and I would like to return it to it\'s rightful owner.\"`nDeimos replies helps you look, but to no avail.`nDeimos replies, if I find it I will let you know.`n `n`n");
advance_quest("quest_beanquest");
villagenav();
page_footer();
} else if ($step == "haberdasher2") {
page_header(" The Search for the Lost Bean ");
output("`7 You step up and ask Deimos for the bean, which he gladly hands to you. He wishes you luck on your journey and bids you farewell.`n`n`n");
advance_quest("quest_beanquest");
villagenav();
page_footer();
}
}

?> 