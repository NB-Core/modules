<? 
/***************************************
Merlin's Magic Shoppe v1.3
Written by Robert for Maddnet.com LoGD
Using apathocary.php & rock.php as a guide.
1st version - 14Jan2004 -with tech help from JT Traub and Anpera
Completely rewritten to this version - Feb2004
Player must have 2 dragon kills to purchase
****************************************/
require_once "common.php"; 
checkday();

    addnav("`bPurchase Knowledge`b");
    addnav("");
if ($session['user']['dragonkills']>1) addnav("Mystic Wisdom","merlinsmagic.php?op=mystic");
if ($session['user']['dragonkills']>1) addnav("Dark Arts","merlinsmagic.php?op=dark");
if ($session['user']['dragonkills']>1) addnav("Thievery","merlinsmagic.php?op=thievery");
if ($session['user']['dragonkills']>1) addnav("Pixie Dust","merlinsmagic.php?op=pixie");
if ($session['user']['dragonkills']>1) addnav("Love Secrets","merlinsmagic.php?op=love");
    addnav("`bLeave`b");
    addnav("(R) Return to Village","village.php"); 
    page_header("Merlins Magic Shoppe"); 
    output("`c<font size='+1'>`@Merlins Magic Shoppe</font>`c",true); 
if ($HTTP_GET_VARS[op]==""){ 
    output(" `&You have come upon Merlin the Magicians little hut that is next to the Curious Rock.`n ");
    output(" There is a sign on the door,`n");
    output(" `n`c`b`^Welcome worthy Dragon Slayer's`b`c`n`n");
    output(" `@Merlin the Magician `&is busy reading today's News behind the counter as you enter, `n"); 
    output(" and gives you only a casual glance before returning to his paper.`n "); 
    output(" You see a very large book that sits upon a fine crafted pedestal. `n");
    output(" It is `@Merlin's `&famed `3Book of Knowledge.`&`n"); 
    output(" Merlin puts down his paper, seeing that you are getting too close to his book.`n");
    output(" What Knowledge do you ask of Merlin today? `n");
    output(" I have Knowledge for sale that will grant ye 1 use of the Special Magic Ability, `n");
    output(" or maybe yer seekin knowledge dealing with affairs of the heart? `n");
    output(" All knowledge ye seek is good and comes straight from me `3Book of Knowledge`&.`n ");
    output(" Each lesson I teach ye will cost only `^10000 gold, `&payable to me. `n ");

}else if ($_GET[op]=="mystic"){ 
if ($session[user][gold] > 9999) {
    $session[user][gold]-=10000; 
             output(" `&You purchase from Merlin the `3Knowledge of Mystic Wisdom`&, and after paying `^10,000 gold`&,`n "); 
             output(" `@Merlin `&thank's you and bids you a good day. `n ");
             output(" You gain one use in Magic! `n ");
             output(" You can feel the Forest calling for you." ); 
             debuglog("Gave 10000 Gold to Merlin for magic use"); 
             $session[user][magicuses]++;
 } else { 
             output("`@Merlin `&says you can't afford this"); 
} 
}else if ($_GET[op]=="dark"){ 
if ($session[user][gold] > 9999) {
    $session[user][gold]-=10000; 
             output(" `&You purchase from Merlin the `3Knowledge of Dark Arts`&, and after paying `^10,000 gold`&,`n "); 
             output(" `@Merlin `&thank's you and bids you a good day. `n ");
             output(" You gain one use in Dark Arts! `n "); 
             output(" You can feel the Forest calling for you. "); 
             debuglog("Gave 10000 Gold to Merlin for dark arts use");
             $session[user][darkartuses]++;
 } else { 
             output("`@Merlin `&says you can't afford this"); 
} 
}else if ($_GET[op]=="thievery"){ 
if ($session[user][gold] > 9999) {
    $session[user][gold]-=10000; 
             output(" `&You purchase from Merlin the `3Knowledge of Thievery`&, and after paying `^10,000 gold`&, `n ");
             output(" `@Merlin `&thank's you and bids you a good day. `n ");
             output(" You gain one use in Thievery! `n "); 
             output(" You can feel the Forest calling for you."); 
             debuglog("Gave 10000 Gold to Merlin for thievery use"); 
             $session[user][thieveryuses]++;
 } else { 
             output("`@Merlin `&says you can't afford this"); 
} 
}else if ($_GET[op]=="pixie"){ 
if ($session[user][gold] > 9999);
             output(" `&Merlin tells you, I'm sorry, the knowledge ye seek is not for ye. `n ");
             output(" The `3Knowledge of Pixie Dust `&is bestowed `ionly`i upon Fairies, and myself of course! `n ");
             output(" I keep it in me inventory fer the Fairies that have lost their memory. `n ");
             output(" Feel free to select from the other's I offer. ");  

}else if ($_GET[op]=="love"){ 
if ($session[user][gold] > 9999){
    $session[user][gold]-=10000; 
             output(" `&You purchase from Merlin the `3Knowledge of Love`&, and after paying `^10000 gold`&, `n ");
             output(" `@Merlin `&thank's you and bids you a good day. `n ");
             output(" You feel `ivery`i charming. "); 
             debuglog("Gave 10000 gold to Merlin for Charm"); 
             $session[user][charm]+=20;
 } else { 
             output("`@Merlin `&says you can't afford this"); 
} 
}
checkday();
if ($session[user][dragonkills]<1){
	output("`n`@Merlin `&politely informs you he will only sell his knowledge to `2Green Dragon Slayer's`&`n");
	output(" that have defeated the `@Green Dragon `&two times.`n");
}
page_footer();
?>