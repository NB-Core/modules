<?php

// The Strange Rock v1.0
// Written by Lurch 
// www.taf.co.nz

require_once("lib/villagenav.php");

function rock_getmoduleinfo(){
	$info = array(
		"name"=>"The Strange Rock",
		"version"=>"1.0",
		"author"=>"Lurch",
		"category"=>"Forest Specials",
    	"download"=>"http://dragonprime.net/users/Lurch/rock.zip",
	);
	return $info;
}


function rock_install() {
	if (!is_module_active('rock')){
		output("`4Installing The Strange Rock Module.`n");
	}else{
		output("`4Updating The Strange Rock Module.`n");
	}
	module_addeventhook("forest", "return 100;");
		return true;
}


function rock_uninstall(){
	output("`4Uninstalling The Strange Rock Module.`n");
	return true;
}

function rock_runevent($type) {
	global $session;
	$op = httpget('op');
	$from = "forest.php?";

	page_header();

	switch ($op) {
		case "":
			output("`2You wondering through the forest minding your own business when you suddenly trip over something.`n`n");
			output("You mumble what the heck was that and look around to see, you find a strange looking rock laying in front of you.`n`n");
			switch(e_rand(1,4)) {
				case 1:
					output("You pickup the rock and just as you are about to chuck it away you notice something gleaming inside it, so you smash it open on the ground and find it filled with gold coins.`n`n");
					$gold = $session['user']['level'] * 15;
					$session['user']['gold'] += $gold;
					output("`&You find `^%s`& pieces of gold.`n`n", $gold);
					debuglog("Recieved %s gold after find rock.", $gold);
					break;
				case 2:
					output("You pickup the rock and throw it away but it bounces off a nearby tree and strikes you right in the middle of your forehead. `n`n");
					output("You loose some charm for this...`n`n");
					addnews("%s gets hit by a small liddle rock.... boo hoo...",$session['user']['name']);
					$session['user']['charm']--;
					break;
				case 3:
					output("you decide to leave the rock where it is and continue on.`n`n");
					output("You find yourself back in the forest.");
					break;
			} 
	}

}

?>