<?php
/*
Module Name:  towndonate.php
Category:  Village
Worktitle:  Town Donation
Author:  DaveS
Date: October 3, 2005
Required Modules:
taxation.php by Sneakabout
townfinance.php by Sneakabout

Description:
For all those players complaining there's nothing to do with extra gold before a dk.
A simple hook that allows players to donate extra gold to benefit the kingdom.  Money donated gets placed
in the town finance coffer.  A hall of fame tracks the most generous philathropists.

v1.1 2nd page hof fixed
v3.0  added vertxtloc
*/
function towndonate_getmoduleinfo(){
	$info = array(
		"name"=>"Town Donation",
		"version"=>"3.0",
		"author"=>"DaveS",
		"category"=>"General",
		"download"=>"http://dragonprime.net/index.php?module=Downloads;sa=dlview;id=180",
		"vertxtloc"=>"",
		"settings"=>array(
			"Town Donation Settings,title",
			"totaldonated"=>"How much total has been donated?,int|0",
			"usehof"=>"Use Hall of Fame?,bool|1",
			"pp"=>"How many players per page in Hall of Fame?,int|25",
		),
		"prefs"=>array(
			"Town Donation Preferences,title",
			"donated"=>"How much has player donated?,int|0",

		),
		"requires"=>array(
			"townfinance"=>"2.0|By Sneakabout, available on DragonPrime",
			"taxation"=>"1.0|By Sneakabout, available on DragonPrime",
		),
	);
	return $info;
}

function towndonate_install(){
	module_addhook("village");
	module_addhook("footer-hof");
	module_addhook("cityhall");
	return true;
}

function towndonate_uninstall(){
	return true;
}
function towndonate_dohook($hookname,$args){
	global $session;
	switch ($hookname) {
		case "cityhall":
			addnav("Donate to the Kingdom","runmodule.php?module=towndonate&op=donate");		
		break;
		case "footer-hof":
			if(get_module_setting('usehof')==1){
				addnav("Warrior Rankings");
				addnav("Philanthropists", "runmodule.php?module=towndonate&op=hof");	
			}
		break;	
	}
	return $args;
}
function towndonate_run(){
	global $session;
	$page = httpget('page');
	$op = httpget('op');
	page_header("The Treasury");
if ($op=="donate") {
	addnav("Return to the Hall","runmodule.php?module=townfinance&op=enter");
	addnav("Return to the Village","village.php");
	output("`&You go to the Treasurer to offer a donation.`n`nHe takes out a ledger and looks at you happily.`n`n'Although we can't offer any special gifts for donating, it does help maintain
		the fiscal strength of our kingdom.'`n`n'How much will you be able to donate today?'");
	output("<form action='runmodule.php?module=towndonate&op=donategold' method='POST'><input name='donate' id='donate'><input type='submit' class='button' value='donate'></form>",true);
	addnav("","runmodule.php?module=towndonate&op=donategold");
}
if ($op=="donategold"){
	addnav("Treasurer's Office");
	addnav("Donate More","runmodule.php?module=towndonate&op=donate");
	addnav("Return to the Hall","runmodule.php?module=townfinance&op=enter");
	addnav("Return to Village","village.php");
	$donate = httppost('donate');
	$max = $session['user']['gold'];
	if ($donate < 0) $donate = 0;
	if ($donate >= $max) $donate = ($max);
	if ($max < $donate) {
		output("The Treasurer looks at you bewildered. 'You know, you don't have that much gold!'`n`n");
	}else{
		set_module_pref("donated",get_module_pref("donated")+$donate);
		set_module_setting("totaldonated",get_module_setting("totaldonated")+$donate);
		set_module_setting("totalcash",get_module_setting("totalcash","townfinance")+$donate,"townfinance");
		output("`&The Treasurer happily accepts your donation of`^ %s gold`& and records the amount for the Top Donors List.`n`n`&'So far you've donated `^%s gold`& to our Kingdom.  Thank you very much!'`n`n",$donate,get_module_pref("donated"));
		output("Due to the generosity of the members of our Kingdom, we have raised `^%s gold`& so far through donations!",get_module_setting("totaldonated"));
		$session['user']['gold']-=$donate;
		debuglog("donated $donate gold to the village treasurer.");
	}
}
if ($op == "hof") {
	page_header("Hall of Fame");
	$pp = get_module_setting("pp");
	$pageoffset = (int)$page;
	if ($pageoffset > 0) $pageoffset--;
	$pageoffset *= $pp;
	$limit = "LIMIT $pageoffset,$pp";
	$sql = "SELECT COUNT(*) AS c FROM " . db_prefix("module_userprefs") . " WHERE modulename = 'towndonate' AND setting = 'donated' AND value > 0";
	$result = db_query($sql);
	$row = db_fetch_assoc($result);
	$total = $row['c'];
	$count = db_num_rows($result);
	if (($pageoffset + $pp) < $total){
		$cond = $pageoffset + $pp;
	}else{
		$cond = $total;
	}
	$sql = "SELECT ".db_prefix("module_userprefs").".value, ".db_prefix("accounts").".name FROM " . db_prefix("module_userprefs") . "," . db_prefix("accounts") . " WHERE acctid = userid AND modulename = 'towndonate' AND setting = 'donated' AND value > 0 ORDER BY (value+0) DESC $limit";
	$result = db_query($sql);
	$rank = translate_inline("Rank");
	$name = translate_inline("Name");
	$donated = translate_inline("Total Amount Donated");
	$none = translate_inline("No Donations Received");
	rawoutput("<table border='0' cellpadding='2' cellspacing='1' align='center' bgcolor='#999999'>");
	rawoutput("<tr class='trhead'><td>$rank</td><td>$name</td><td>$donated</td></tr>");
	if (db_num_rows($result)==0){
		output_notl("<tr class='trlight'><td colspan='3' align='center'>`&$none`0</td></tr>",true);
	}
	if (db_num_rows($result)>0){
		for($i = $pageoffset; $i < $cond && $count; $i++) {
			$row = db_fetch_assoc($result);
			if ($row['name']==$session['user']['name']){
				rawoutput("<tr class='trhilight'><td>");
			}else{
				rawoutput("<tr class='".($i%2?"trdark":"trlight")."'><td>");
			}
			$j=$i+1;
			output_notl("$j.");
			rawoutput("</td><td>");
			output_notl("`&%s`0",$row['name']);
			rawoutput("</td><td>");
			output_notl("`c`b`Q%s`c`b`0",$row['value']);
			rawoutput("</td></tr>");
		}
	}
	rawoutput("</table>");
	if ($total>$pp){
		addnav("Pages");
		for ($p=0;$p<$total;$p+=$pp){
			addnav(array("Page %s (%s-%s)", ($p/$pp+1), ($p+1), min($p+$pp,$total)), "runmodule.php?module=towndonate&op=hof&page=".($p/$pp+1));
		}
	}
	addnav("Other");
	addnav("Back to HoF", "hof.php");
	villagenav();
}
page_footer();
}
?>