lib/module.php

/**
 * Get a setting for a module for a user
 *
 * @param string $name The setting to retrieve
 * @param string $module The module name to use
 * @param int $user The acctid of the user
 * @return mixed The value of the setting
 */
function get_module_pref($name, $module=false, $user=false){
	global $module_prefs,$mostrecentmodule, $session;
	
	if ($module === false) $module = $mostrecentmodule;
	
	if ($user===false){
		load_module_prefs($module);
	
		if (isset($module_prefs[$module][$session['user']['acctid']][$name])) {
			return $module_prefs[$module][$session['user']['acctid']][$name];
		}
	}else{
		//this is for another user, we'll just load this in a single shot.
		$sql = "SELECT * FROM ".db_prefix("module_userprefs")." WHERE modulename='$module' AND setting='".addslashes($name)."' AND userid='$user' ";
		$result = db_query($sql);
		if (db_num_rows($result)>0){
			$row = db_fetch_assoc($result);
			return $row['value'];
		}
	}
	//we couldn't find this elsewhere, load the default value if it exists.
	$info = get_module_info($module);
	if (isset($info['prefs'][$name])){
		$x = explode("|",$info['prefs'][$name]);
		if (isset($x[1])){
			if ($user===false) set_module_pref($name,$x[1],$module,$session['user']['acctid']);
			return $x[1];
		}
	}
	return NULL;
}

/**
 * Assign a value to a setting for a module
 *
 * @param string $name The name of the setting
 * @param mixed $value The value of the setting
 * @param string $module The module
 * @param int $user The acctid of the user
 */
function set_module_pref($name, $value, $module=false, $user=false){
	global $module_prefs,$mostrecentmodule, $character;
	
	if ($module === false) $module = $mostrecentmodule;
	
	if ($user === false) {
		$userID=$session['user']['acctid'];
	} else {
		$userID = $user;
	}
	
	load_module_prefs($module, $userID);

	//don't write to the DB if the user isn't logged in.
	if (!$session['user']['loggedin'] && !$user) {
		// We do need to save to the loaded copy here however
		$module_prefs[$module][$userID][$name] = $value;
		return;
	}

	if (isset($module_prefs[$module][$userID][$name])){
		$sql = "UPDATE " . db_prefix("module_userprefs") . " SET value='".addslashes($value)."' WHERE modulename='$module' AND setting='$name' AND userid='$userID'";
		db_query($sql);
	}else{
		$sql = "INSERT INTO " . db_prefix("module_userprefs"). " (modulename,setting,userid,value) VALUES ('$module','$name','$userID','".addslashes($value)."')";
		db_query($sql);
	}
	$module_prefs[$module][$userID][$name] = $value;
}

/**
 * Load module prefs 
 *
 * @param string $module  The module to load the prefs for
 * @param int $user The acctid of the user
 * @param bool $force Should the prefs be forced loaded (aids development)
 */
function load_module_prefs($module, $user=false, $force=false){
	// Added $force to aid development of modules
	
	global $module_prefs, $character;
	
	if ($user===false) $user = $session['user']['acctid'];
	
	if (!isset($module_prefs[$module]))
		$module_prefs[$module]=array();
	
	if (!isset($module_prefs[$module][$user]) || $force==true){
		$module_prefs[$module][$user] = array();
		$sql = "SELECT * FROM " . db_prefix("module_userprefs") . " WHERE modulename='$module' AND userid='$user'";
		$result = db_query($sql);
		while ($row = db_fetch_assoc($result)){
			$module_prefs[$module][$user][$row['setting']] = stripslashes($row['value']);
		}//end while
	}//end if
}//end function
