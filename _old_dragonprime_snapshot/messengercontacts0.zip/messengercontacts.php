<?php
/* Messenger Contacts module by Sixf00t4

Allows users to enter there MSN, AIM, Yahoo, ICQ and URL contacts for others.

Installation:
copy entire contents of zip to /modules

Optional:
find:
messengercontacts/icq.gif

and replace with:
http://web.icq.com/whitepages/online?icq=$icq&img=21
to make dynamic content to display if the user is online or not.
*/

function messengercontacts_getmoduleinfo(){
	$info = array(
		"name"=>"Messenger Contacts",
		"version" => "20050909",
		"vertxtloc"=>"http://dragonprime.net/users/sixf00t4/",
		"author"=>"<a href='http://www.sixf00t4.com' target=_new>Sixf00t4</a>",
		"category"=>"General",
		"description"=>"Adds messenger links in bios.",
		"download"=>"http://dragonprime.net/users/sixf00t4/messengercontacts.zip",
		"prefs"=>array(
			"Messenger Contacts,title",
			"user_aim"=>"AIM screen name|",
			"user_yahoo"=>"Yahoo screen name|",
			"user_msn"=>"MSN Address|",
			"user_icq"=>"ICQ Number|",
			"user_web"=>"Web page URL  http://|",
					),
		"settings"=>array(
			"Messenger Contacts Settings,title",
            "show_aim"=>"Display aim in bios?,bool|1",
			"show_yahoo"=>"Display yahoo in bios?,bool|1",
			"show_msn"=>"Display msn in bios?,bool|1",
			"show_icq"=>"Display icq in bios?,bool|1",
			"show_web"=>"Display URL in bios?,bool|1",
			"show_images"=>"Display images for clients?,bool|1",
			"use_links"=>"Should images link to application launch?,bool|1",
		),
	);
	return $info;
}

function messengercontacts_install(){
	debug("Installing Messenger Contacts.");
	module_addhook("bioinfo");
	module_addhook("footer-prefs");
	return true;
}

function messengercontacts_uninstall(){
	debug("Uninstalled Messenger Contacts.");
	return true;
}

function messengercontacts_dohook($hookname,$args){
	global $session;
	switch($hookname){
	case "bioinfo":
rawoutput("<table><tr><td valign='top'>");

			$aim = get_module_pref("user_aim","messengercontacts",$args['acctid']);
			$aim = stripslashes(preg_replace("'[\"\'\\><@?*&#; ]'","",$aim));

			$msn = get_module_pref("user_msn","messengercontacts",$args['acctid']);
			$msn = stripslashes(preg_replace("'[\"\'\\><?*&#; ]'","",$msn));

			$icq = get_module_pref("user_icq","messengercontacts",$args['acctid']);
			$icq = stripslashes(preg_replace("'[\"\'\\><@?*&#; ]'","",$icq));
			
			$yahoo = get_module_pref("user_yahoo","messengercontacts",$args['acctid']);
			$yahoo = stripslashes(preg_replace("'[\"\'\\><@?*&#; ]'","",$yahoo));

			$web = get_module_pref("user_web","messengercontacts",$args['acctid']);
			$web = stripslashes(preg_replace("'[\"\'\\><@?*&#; ]'","",$web));
			
if ($aim>"" || $msn>"" || $icq>"" || $web>"" || $web>""){
output("`^Contact Wizardry:`0");
}
		 if (get_module_setting("show_aim")==1){

                                if ($aim>""){
                                	rawoutput("</td><td valign='top'>");
                                	$close="";
                                	if (get_module_setting("use_links")==1){
                                		$message = translate_inline("Hi.+Are+you+there?");
                                		rawoutput("<a href= \"aim:goim?screenname=$aim&message=$message\" target=_new>");
                                		$close="</a>";
                                		}
                                	if (get_module_setting("show_images")==1){
                                		rawoutput("<img src=\"modules/messengercontacts/aim.gif\" alt= $aim border=0> $close");
                                		}else rawoutput(" AIM: $aim $close");

			}
		}

		 if (get_module_setting("show_msn")==1){

                                if ($msn>""){
                                	rawoutput("</td><td valign='top'>");
                                 	if (get_module_setting("show_images")==1){
                                		rawoutput("<img src=\"modules/messengercontacts/msn.gif\" alt= $msn border=0> $close");
                                		}else rawoutput(" MSN: $msn");
			}
		}

		 if (get_module_setting("show_icq")==1){

                                if ($icq>""){
                                	rawoutput("</td><td valign='top'>");
                                	$close="";
                                	if (get_module_setting("use_links")==1){
                                		rawoutput("<a href= \"http://wwp.icq.com/scripts/search.dll?to=$icq\" target=_new>");
                                		$close="</a>";
                                		}
                                	if (get_module_setting("show_images")==1){
                                		rawoutput("<img src=\"modules/messengercontacts/icq.gif\" alt= $icq border=0> $close");
                                		}else rawoutput(" ICQ: $icq $close");
			}
		}

		 if (get_module_setting("show_yahoo")==1){

                                if ($yahoo>""){
                                 	rawoutput("</td><td valign='top'>");
                                	$close="";
                                	if (get_module_setting("use_links")==1){
                                		rawoutput("<a href= \"ymsgr:sendIM?$yahoo\" target=_new>");
                                		$close="</a>";
                                		}
                                	if (get_module_setting("show_images")==1){
                                		rawoutput("<img src=\"modules/messengercontacts/yahoo.gif\" alt= $yahoo border=0> $close");
                                		}else rawoutput(" Yahoo: $yahoo $close");

            }
		}

		if (get_module_setting("show_web")==1){

                                if ($web>""){
                                 	rawoutput("</td><td valign='top'>");
                                	$close="";
                                	if (get_module_setting("use_links")==1){
                                		rawoutput("<a href= \"http://$web\" target=_new>");
                                		$close="</a>";
                                		}
                                	if (get_module_setting("show_images")==1){
                                		rawoutput("<img src=\"modules/messengercontacts/web.gif\" alt= $web border=0> $close");
                                		}else rawoutput(" URL: $web $close");

			}
		}

rawoutput("</td></tr></table>");
		break;
		}
return $args;
        }

function messengercontacts_run(){
	global $session;

}

?>