<?php
page_header("Der verzauberte See");
		output("`c`b`#Der verzauberte See`b`c`n`n");
		output("Du wanderst weiter die verschlungenen Pfade entlang und gelangst an einen kleinen See.");
		output("Das Sonnenlicht spiegelt sich auf den Wellen, die leise an den kleinen Sandstrand vor die pl�tschern.");
		output("Schattenspendende Weiden s�umen sein Ufer, durch deren Bl�tter die Sonne malerische Schatten wirft.");
		output("Du wirst von einer inneren Ruhe erfasst, als du die Sch�nheit deiner Umgebung wahrnimmst.`n`n");
		output("`3Eine der Feen, die hier umherschwirren, erinnert dich daran, dass der See ein Platz f�r Rollenspiel ist, und dass dieser Bereich vollst�ndig auf charakterspezifische Kommentare beschr�nkt ist.`n`n");
		addcommentary();
		viewcommentary("see","Hier fl�stern",20,"fl�stert");
		addnav("Wandern");
		addnav("Zur�ck zum Garten","gardens.php");
?>