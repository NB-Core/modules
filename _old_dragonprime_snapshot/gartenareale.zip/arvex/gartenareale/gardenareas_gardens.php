<?php
addnav("Wandern");
		addnav("Der verzauberte See","runmodule.php?module=gardenareas&op=see");
		addnav("Kastanie der Tr�ume","runmodule.php?module=gardenareas&op=kast");
		addnav("Steingarten der W�nsche","runmodule.php?module=gardenareas&op=stein");
		addnav("Springbrunnen der Seelen","runmodule.php?module=gardenareas&op=spring");
?>