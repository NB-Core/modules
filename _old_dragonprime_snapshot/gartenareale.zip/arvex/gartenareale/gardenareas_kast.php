<?php
page_header("Kastanie der Tr�ume");
		output("`c`b`@Kastanie der Tr�ume`b`c`n`n");
		output("Einer der Pfade f�hrt dich zu einer gro�en, jahrhunderte alten Kastanie, deren dichtes Bl�tterwerk, selbst im Sommer Schatten spendet.");
		output("Der Wind rauscht leise in den Zweigen �ber deinem Kopf, und zu deinen F�ssen bl�hen unz�hlige Blumen.");
		output("Eine Bank ist um den m�chtigen Stamm herum gebaut worden, die zum verweilen und tr�umen an diesem malerischen Ort einl�dt.`n`n");
		output("`2Eine der Feen, die hier umherschwirren, erinnert dich daran, dass der See ein Platz f�r Rollenspiel ist, und dass dieser Bereich vollst�ndig auf charakterspezifische Kommentare beschr�nkt ist.`n`n");
		addcommentary();
		viewcommentary("kast","Hier fl�stern",20,"fl�stert");
		addnav("Wandern");
		addnav("Zur�ck zum Garten","gardens.php");
?>