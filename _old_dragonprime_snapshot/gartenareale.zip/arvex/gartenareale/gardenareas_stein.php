<?php
page_header("Steingarten der W�nsche");
		output("`c`b`^Steingarten der W�nsche`b`c`n`n");
		output("Durch ein kleines Waldst�ck gelangst du in den Steingarten.");
		output("Auf einer kleinen Anh�he, sind aus Granitfelsen viele kleine und gro�e Becken gefertigt worden, durch die das Wasser sanft hinunter pl�tschert.");
		output("Zwischen den Felsen wachsen seltene Blumen und ganz oben auf der Anh�he steht ein kleiner Pavillon, der vor Wind und Wetter sch�tzt.");
		output("Die friedliche Stimmung hier, l�sst dich all deine Sorgen vergessen.`n`n");
		output("`6Eine der Feen, die hier umherschwirren, erinnert dich daran, dass der See ein Platz f�r Rollenspiel ist, und dass dieser Bereich vollst�ndig auf charakterspezifische Kommentare beschr�nkt ist.`n`n");
		addcommentary();
		viewcommentary("stein","Hier fl�stern",20,"fl�stert");
		addnav("Wandern");
		addnav("Zur�ck zum Garten","gardens.php");
?>