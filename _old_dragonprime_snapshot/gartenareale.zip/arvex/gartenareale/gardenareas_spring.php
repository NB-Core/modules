<?php
page_header("Springbrunnen der Seelen");
		output("`c`b`%Springbrunnen der Seelen`b`c`n`n");
		output("Inmitten einer weitl�ufigen Wiese, auf der die Wildblumen wuchern, steht ein Springbrunnen aus schneewei�em Marmor.");
		output("Um den Brunnen herum sind steinerne B�nke angeordnet.");
		output("An diesem einsamen Ort kann man seine Seele baumeln lassen und den Alltag vergessen.`n`n");
		output("`5Eine der Feen, die hier umherschwirren, erinnert dich daran, dass der See ein Platz f�r Rollenspiel ist, und dass dieser Bereich vollst�ndig auf charakterspezifische Kommentare beschr�nkt ist.`n`n");
		addcommentary();
		viewcommentary("spring","Hier fl�stern",20,"fl�stert");
		addnav("Wandern");
		addnav("Zur�ck zum Garten","gardens.php");
?>