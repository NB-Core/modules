<?php
/*
Nach einer Idee von Todesengel Tatiascha
Umgesetzt von Sir Arvex; � 2005
Erstmalig auf Anagromataf.de erschienen
Bugs und Fehler an arvex@anagromataf.de
*/

function gardenareas_getmoduleinfo(){
	$info = array(
		"name"=>"Gartenareale",
		"author"=>"`)Arvex",
		"version"=>"1.02",
		"category"=>"Gardens",
		"download"=>"http://www.arvex.de/index.php?showforum=3",
	);
	return $info;
}

function gardenareas_install(){
	module_addhook("gardens");
	module_addhook("moderate");
	return true;
}

function gardenareas_uninstall(){
	return true;
}

function gardenareas_dohook($hookname,$args){
	global $session;
	require_once("lib/http.php");
	switch($hookname){
		case "gardens":
		include("modules/arvex/gartenareale/gardenareas_gardens.php"); 
		break;
		case "moderate":
		$args['gardenareas'] = "Gartenareale";
		break; 
		}	
	return $args;
}

function gardenareas_run(){
	global $session;
	require_once("lib/commentary.php");
	$op = httpget('op');
	checkday();
	if($op=="see"){
		include("modules/arvex/gartenareale/gardenareas_see.php");
		}
	if($op=="kast"){
		include("modules/arvex/gartenareale/gardenareas_kast.php");
		}
	if($op=="stein"){
		include("modules/arvex/gartenareale/gardenareas_stein.php");
		}
	if($op=="spring"){
		include("modules/arvex/gartenareale/gardenareas_spring.php");
		}
	page_footer();			
}
?>