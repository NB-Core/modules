Turn Tavern

Version 2.01
Written by RPGSL
Download: http://dragon.com/lotgd/turntavern.zip
Mirror: http://rpgsl.com/lotgd/turntavern.zip

Game: http://rpdragon.com/


Installation

1) Copy turntavern.php into your LotGD modules folder
2) Log in to LotGD with your admin account
3) Enter the Superuser Grotto
4) Click Manage Modules
5) Install turntavern.php (Turn Tavern)
6) Configure settings and save
7) Activate


Questions/Comments?

alex@rpgsl.com


Visit www.rpgsl.com today for your RPG needs