<?php

//Tavern's random move snippet from The Potion Shop by CortalUX - http://dragonprime.net/users/CortalUX/
//Original idea stemmed from Muad's Smoothie Shoppe by Chris Vorndran - http://dragonprime.net/users/Sichae/

function turntavern_getmoduleinfo()
{
	$info = array
	(
		"name"			=> "Turn Tavern",
		"author"		=> "RPGSL",
		"version"		=> "2.01",
		"category"		=> "RPGSL",
		"download"		=> "http://www.rpdragon.com/lotgd/turntavern.zip",
		"vertxtloc"		=> "http://www.rpdragon.com/",
		"description"	=> "A tavern that allows turns to be bought. Costs and turns gained can be changed.",
		"settings"		=> array
		(
			"General, title",
				"name"				=> "1) Name of Turn Tavern?, text|Turn Tavern",
				"drinksallowed"		=> "2) Number of turns allowed on new day?, int|15",
				"runonce"			=> "3) Does the number of drinks only reset on a new `b`^GAME`7`b day?, bool|0",
				"Yes: Will only be allowed to gain the allowed amount of turns for each actual game day. Resurrections will not reset the number of turns that the character has gained., note",				
			"Costs and Effects, title",
				"smallperlevel"		=> "1) Cost of Small Tankard per level, int|30",
				"smallturns"		=> "2) How many turns are gained from a small tankard?, int|1",
				"mediumperlevel"	=> "3) Cost of Medium Tankard pet level, int|80",
				"mediumturns"		=> "4) How many turns are gained from a medium tankard?, int|3",
				"largeperlevel"		=> "5) Cost of Large Tankard per level, int|130",
				"largeturns"		=> "6) How many turns are gained from a large tankard?, int|5",
			"Special Effects, title",
				"extra"				=> "1) Is there a chance for extra turns?, bool|0",
				"extrachance"		=> "2) Percent per turn bought that extra turns will be awarded if `b1`b is Yes (cumulative), range,1,100,1|1",
				"turnsgained"		=> "3) Multiply turns bought by this amount for extra turns gained, floatrange,1,10,.25|2",			
				"canlose"			=> "4) Characters lose hit points if extra turns are rewarded?, bool|1",
				"hploss"			=> "5) Percent of max hit points per turn bought substracted from regular hit points if `b9`b is Yes?, range,1,100,1|10",
				"If character has 200 MAX HP and this is set to 10 they will lose 20 HP (not permanent) for each turn they bought., note",				
				"maxloss"			=> "6) Maximum percentage of hit points lost if `b9`b is Yes?, range,1,100,1|75",
				"candie"			=> "7) Characters can die if `b4`b is Yes?, bool|1",
				"No: Characters will not die but their hit points will be set to 1., note",				
			"Location, title",
				"move"				=> "1) Should the tavern randomly move?, bool|0",
				"move_runonce"		=> "2) Should the tavern only move on each new `b`^GAME`7`b day if `b1`b is Yes?, bool|1",
				"Yes: The tavern will only move each time the server creates a new day. No: The tavern will move to a different location for each character each new day - resurrections included., note",				
				"place" 			=> "3) Where is the tavern located today if `b2`b is Yes?, location|".getsetting("villagename", LOCATION_FIELDS),
				"If `b2`b is set to No then you can set each individual character's tavern location by editing the user., note",				
				"mloc"				=> "4) Location of Turn Tavern if `b1`b is No:, location|".getsetting("villagename", LOCATION_FIELDS),
		),
		"prefs"			=> array
		(
			"Turn Tavern - Prefs,title",
				"drinks"			=> "Number of drinks character bought today,int|0",
				"userplace" 		=> "Where is the tavern located today for this character?, location|".getsetting("villagename", LOCATION_FIELDS),
		),
	);
	return $info;
}

function turntavern_install()
{
	if (!is_module_installed("turntavern"))
	{
		output("Installing `bTurn Tavern`b (turntavern.php) module by Role Play Game Story Lines (www.rpgsl.com)`n`n");
	}
	else
	{
		output("Updating `bTurn Tavern`b (turntavern.php) module by Role Play Game Story Lines (www.rpgsl.com)`n`n");
	}
	module_addhook("newday-runonce");
	module_addhook("newday");
	module_addhook("village");
	module_addhook("changesetting");
	return true;
}

function turntavern_uninstall()
{
	output("Uninstalling `bTurn Tavern`b (turntavern.php) module by Role Play Game Story Lines (www.rpgsl.com)`n");
	return true;
}

function turntavern_dohook($hookname, $args)
{
	global $session;
	switch ($hookname)
	{	
		case "newday-runonce":
        	if (get_module_setting("move_runonce") && get_module_setting("move"))
        	{
				$vloc 			= array();
				$vname 			= getsetting("villagename", LOCATION_FIELDS);
				$vloc[$vname] 	= "village";
				$vloc 			= modulehook("validlocation", $vloc);
				$key 			= array_rand($vloc);
				set_module_setting("place", $key);
        	}
        	if (get_module_setting("runonce"))
        	{
        		$sql = "update ".db_prefix("module_userprefs")." set value=0 where value>0 and setting='drinks' and modulename='turntavern'";
        		db_query($sql);
        	}
		break;		
		case "newday":
        	if (!get_module_setting("move_runonce") && get_module_setting("move"))
        	{
				$vloc 			= array();
				$vname 			= getsetting("villagename", LOCATION_FIELDS);
				$vloc[$vname] 	= "village";
				$vloc 			= modulehook("validlocation", $vloc);
				$key 			= array_rand($vloc);
				set_module_pref("userplace", $key);
        	}
	       	if (!get_module_setting("runonce"))
	       	{
				set_module_pref("drinks", 0);
			}
		break;
		case "village":
			$place = get_module_setting("place");
			if (!get_module_setting("move"))
			{
				if ($session['user']['location'] == get_module_setting("mloc"))
				{
					tlschema($args['schemas']['tavernnav']);
					addnav($args['tavernnav']);
					tlschema();
					addnav(array("%s", get_module_setting('name')), "runmodule.php?module=turntavern&op=enter");
				}
			}
			elseif (get_module_setting("move") && get_module_setting("runonce"))
			{
				if (get_module_setting('place') == $session['user']['location'])
				{
					tlschema($args['schemas']['tavernnav']);
					addnav($args['tavernnav']);
					tlschema();
					addnav(array("%s", get_module_setting('name')), "runmodule.php?module=turntavern&op=enter");
				}
			}
			elseif (get_module_setting("move") && !get_module_setting("runonce"))
			{
				if (get_module_pref('userplace') == $session['user']['location'])
				{
					tlschema($args['schemas']['tavernnav']);
					addnav($args['tavernnav']);
					tlschema();
					addnav(array("%s", get_module_setting('name')), "runmodule.php?module=turntavern&op=enter");
				}
			}
		break;
		case "changesetting":
			if ($args['setting'] == "villagename")
			{
				if ($args['old'] == get_module_setting("mloc"))
				{
				   set_module_setting("mloc", $args['new']);
				}
			}
		break;
	}
	return $args;
}

function turntavern_run()
{
	global $session;
	$op 			= httpget('op');
	$sub 			= httpget('sub');
	$small 			= get_module_setting("smallperlevel") * $session['user']['level'];
	$medium 		= get_module_setting("mediumperlevel") * $session['user']['level'];
	$large 			= get_module_setting("largeperlevel") * $session['user']['level'];
	$drinks 		= get_module_pref("drinks");
	$drinksallowed 	= get_module_setting("drinksallowed");
	$smallturns		= get_module_setting("smallturns");
	$mediumturns	= get_module_setting("mediumturns");
	$largeturns		= get_module_setting("largeturns");
	page_header(get_module_setting("name"));
	switch ($op)
	{
		case "enter":
			if ($drinks >= $drinksallowed)
			{
				output("You've had enough today. Come back tomorrow!");
				break;
			}
			else
			{
				output("A small, rotund man is cleaning tankards behind the bar as you enter. He looks over to you with a smile and a nod.");
				output("`n`n`^Welcome to my little place.`0`n`n");
				output("Looking around, you see an a massive vat in the large brewery in the back area of the tavern.");
				output("Bubbles can be heard churning within.");
				addnav("View");
				addnav("Menu", "runmodule.php?module=turntavern&op=menu");
				break;
			}
		case "menu":
			output("You've received %s turns today. You can buy %s more turns today.`n`n", $drinks, $drinksallowed - $drinks);
			output("`^What can I get you?`0");
			addnav("Menu");
			if ($session['user']['gold'] >= $small && $drinks <= $drinksallowed - $smallturns)
			{
				addnav(array("Small Tankard (%s Gold)", $small), "runmodule.php?module=turntavern&op=pick&sub=sm");
			}
			if ($session['user']['gold'] >= $medium && $drinks <= $drinksallowed - $mediumturns)
			{
				addnav(array("Medium Tankard (%s Gold)", $medium), "runmodule.php?module=turntavern&op=pick&sub=md");
			}
			if ($session['user']['gold'] >= $large && $drinks <= $drinksallowed - $largeturns)
			{	
				addnav(array("Large Tankard (%s Gold)", $large), "runmodule.php?module=turntavern&op=pick&sub=lg");
			}
			break;
		case "pick":
			output("Enjoy your drink.`n`n");
			output("`%The drink courses through your body like a zephyr in summer. Your extremities tingle and turn a flushed red. You feel ready to take on more creatures!`0");
			switch ($sub)
			{
				case "sm":
					if (get_module_setting("extra"))
					{
						if (e_rand(1,100) <= get_module_setting("extrachance") * $smallturns)
						{
							$smallturns = get_module_setting("turnsgained") * $smallturns;
							output("`n`nWow! That tankard had a zing to it! You gained %s turns instead of %s!`n`n", $smallturns, get_module_setting("smallturns"));
							if (get_module_setting("canlose"))
							{
								$hploss = get_module_setting("hploss") / 100 * $smallturns;
								if ($hploss > get_module_setting("maxloss") / 100)
								{
									$hploss = get_module_setting("maxloss") / 100;
								}
								$hploss *= $session['user']['maxhitpoints'];
								$hploss = round($hploss);
								if (!get_module_setting("candie"))
								{
									$hploss = $session['user']['hitpoints'] -= 1;
								}
								$session['user']['hitpoints'] -= $hploss;
								output("`n`nOh brother!! That tankard made you feel sick to the stomach! You lose %s hit points.`n`n", $hploss);
								debuglog("lost $hploss hit points at the Turn Tavern");
							}
						}
					}
					$session['user']['gold'] -= $small;
					$session['user']['turns'] += $smallturns;
					$drinks += $smallturns;
					debuglog("spent $small gold on $smallturns at the Turn Tavern");
					break;
				case "md":
					if (get_module_setting("extra"))
					{
						if (e_rand(1,100) <= get_module_setting("extrachance") * $mediumturns)
						{
							$mediumturns *= get_module_setting("turnsgained");
							output("`n`nWow! That tankard had a zing to it! You gained %s turns instead of %s!`n`n", $mediumturns, get_module_setting("mediumturns"));
							if (get_module_setting("canlose"))
							{
								$hploss = get_module_setting("hploss") / 100 * $mediumturns;
								if ($hploss > get_module_setting("maxloss") / 100)
								{
									$hploss = get_module_setting("maxloss") / 100;
								}
								$hploss *= $session['user']['maxhitpoints'];
								$hploss = round($hploss);
								if (!get_module_setting("candie"))
								{
									$hploss = $session['user']['hitpoints'] -= 1;
								}
								$session['user']['hitpoints'] -= $hploss;
								output("`n`nOh brother!! That tankard made you feel sick to the stomach! You lose %s hit points.`n`n", $hploss);
								debuglog("lost $hploss hit points at the Turn Tavern");
							}
						}
					}
					$session['user']['gold'] -= $medium;
					$session['user']['turns'] += $mediumturns;
					debuglog("spent $medium gold on $mediumturns at the Turn Tavern");
					$drinks += $mediumturns;
					break;
				case "lg":
					if (get_module_setting("extra"))
					{
						if (e_rand(1,100) <= get_module_setting("extrachance") * $largeturns)
						{
							$largeturns = get_module_setting("turnsgained") * $largeturns;
							output("`n`nWow! That tankard had a zing to it! You gained %s turns instead of %s!`n`n", $largeturns, get_module_setting("largeturns"));
							if (get_module_setting("canlose"))
							{
								$hploss = get_module_setting("hploss") / 100 * $largeturns;
								if ($hploss > get_module_setting("maxloss") / 100)
								{
									$hploss = get_module_setting("maxloss") / 100;
								}
								$hploss *= $session['user']['maxhitpoints'];
								$hploss = round($hploss);
								if (!get_module_setting("candie"))
								{
									$hploss = $session['user']['hitpoints'] -= 1;
								}
								$session['user']['hitpoints'] -= $hploss;
								output("`n`nOh brother!! That tankard made you feel sick to the stomach! You lose %s hit points.`n`n", $hploss);
								debuglog("lost $hploss hit points at the Turn Tavern");
							}
						}
					}
					$session['user']['gold'] -= $large;
					$session['user']['turns'] += $largeturns;
					debuglog("spent $large gold on $largeturns at the Turn Tavern");
					$drinks += $largeturns;
					break;
			}
			if ($drinks < $drinksallowed  && $session['user']['hitpoints'] > 0)
			{
				addnav("More!", "runmodule.php?module=turntavern&op=menu");
			}
			break;
	}
	set_module_pref("drinks", $drinks);
	villagenav();
	page_footer();
}

?>