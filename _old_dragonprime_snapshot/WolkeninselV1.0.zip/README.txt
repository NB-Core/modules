===============================================================================================================================

*** Kurzbeschreibung: ***

Diese zip-Datei beinhaltet die Umsetzung von Apollons Wolkeninsel aus 0.9.7 f�r 1.0.X Server
(urspr�nglich in 0.9.7 f�r die pool.php konstruiert, hier f�r die Burg umgesetzt)

===============================================================================================================================

*** Installation: ***

Die Datei ins Modulverzeichnis kopieren.
Anschlie�end in die Grotte wechseln und das Modul "wolkeninsel.php" installieren.
Modul aktivieren.

===============================================================================================================================

*** Erweiterungen: ***

Die Wolkeninsel ist eine kleine Erweiterung der Burg und geh�rt ebenfalls in die Kategorie "Stadtmauer".
Die Burg wird nun um einen kleinen Burggarten mit Burgteich erweitert, worauf sich die Wolkeninsel befindet.

===============================================================================================================================


Viel Spa�! :)
Apollon und BansheeElhayn.


**************************

Versionshistorie:

21.12.2005  --  Version 1.0, Umsetzung der 0.9.7 Version f�r 1.0.X, erste Ver�ffentlichung