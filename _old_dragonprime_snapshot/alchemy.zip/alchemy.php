<?php

// Require these scripts will allow us to use functions that are in them
// Technically, these are already called by runmodule.php, so we don't really need them.

function alchemy_getmoduleinfo(){
	$info = array(
		"name"=>"Angul's Alchemy",
		"author"=>"Chris Vorndran",
		"version"=>"1.3",
		"category"=>"Village",
		"download"=>"http://dragonprime.net/index.php?module=Downloads;sa=dlview;id=17",
		"vertxtloc"=>"http://dragonprime.net/users/Sichae/",
		"description"=>"User can purchase elixirs with Gems/Gold and will be booned accordingly.",
		"settings"=>array(
			"Angul's Alchemy Module Settings,title",
				"gemcost"=>"Cost in gems for the Elixir,int|10",
				"goldcost"=>"Cost in gold for the Elixir,int|5000",
				"allow"=>"Amount of Elixirs per day,int|2",
				"expgain"=>"Experience multiplier,floatrange,0,1,.1|.1",
				"mindk"=>"What is the minimum DK before this shop will appear to a user?,int|0",
				"alchemyloc"=>"Where does Angul appear,location|".getsetting("villagename", LOCATION_FIELDS)
			),
			"prefs"=>array(
			"Angul's Alchemy Module Preferences,title",
				"times"=>"How many times has an Elixir been bought today,int|0",
			)
		);
	return $info; // This will make sure that when the function is called, that it returns the array as a variable
}
function alchemy_install(){
	module_addhook("village"); // Hooking to Village, so we can see the nav
	module_addhook("changesetting"); // Making sure that we properly change cities, in case multiple cities are installed
	module_addhook("newday"); // Hook here, so we can clean out the Elixirs from the blood. ;)
	return true;
}
function alchemy_uninstall(){
	return true;
}
function alchemy_dohook($hookname,$args){
	global $session;
	
	/*
	Okay, Explanation of $args:
	
	For each modulehook, there is an option to have arguments passed down it, 
	so that when it is called, a person can use those to interperet data. 	
	
	So, let's take the bioinfo modulehook for instance:
	modulehook("bioinfo", $target);
	The $target, is the arguments that are going to be called down the modulehook.
	So, we can either call it $args or we can call it in by global $target, and do it that way. 
	Both ways are the same.
	
	So, let's do some examples:
	Say, we want to display if a person has had any elixirs in their bio.
	We would hook to bioinfo: module_addhook("bioinfo");
	Then, when we get to the switch ($hookname):
	case "bioinfo":
	// We can call in all sorts of things, that are passed by the $target argument.
		$has_drank = get_module_pref("times",$args['acctid'];
	// Similarly, we can call it thusly:
		global $target;
		$has_drank = get_module_pref("times",$target['acctid'];
	// Each modulehook has it's own set of variables that are passed down the hook, if any. :)
	
	Get it? Good.
	*/
	$times = get_module_pref("times"); // Call this variable, so that we can assess if the person has had anything.
	switch($hookname){
		case "changesetting":
			if ($args['setting'] == "villagename"){ 
				/*
				Let's use what we learned about arguments to understand this part.
				We are in the changesetting modulehook, so, we can go to configuration.php, 
				where the hook is nested, and see that it has to offer.
				modulehook("changesetting",
					array("module"=>"core", "setting"=>$key,
						"old"=>$old[$key], "new"=>$val), true);
				Passed down this modulehook:
					module = module filename
					setting = name of the setting
					old = what it was before the change
					new = what it was after the change
					
				So, knowing this, we can see that we are checking to see if the villagename setting was affected.
				If the old value was equal to the module_setting, then we are going to set this to the new value.
				This is mainly to check if the Capital City Name was changed.
				
				Understand?
				*/
				if ($args['old'] == get_module_setting("alchemyloc")) {
					set_module_setting("alchemyloc", $args['new']);
				}
			}
			break;
		case "village":
			if ($session['user']['location'] == get_module_setting("alchemyloc")
			&& $session['user']['dragonkills'] >= get_module_setting("mindk")) {
				// Check to see if the user is in the same location as the shop
				tlschema($args['schemas']['marketnav']);
				addnav($args['marketnav']);
				tlschema();
				/*
				Brief explanation of tlschema();
				
				tlshcema is involved in translation. 
				This groups things and parcels of text into different schemes, so they can be called easily from the database.
				
				Nothing really to it... you need it if you want to have a translation ready module.
				*/
				addnav("Angul's Alchemy","runmodule.php?module=alchemy&op=enter");
			}
			break;
		case "newday":
			if ($times>0){ // Check if they drank at all
				output("`n`QYou feel the power of Angul's Elixirs leave your body...`n");
				set_module_pref("times",0); // Set times to 0
			}
			break;
		}
	return $args;
}
function alchemy_run(){
	global $session;
    $times = get_module_pref("times"); // Times variable
    $allow = get_module_setting("allow"); // How many are allowed.
    $tgold = $session['user']['gold']; // User's Gold
    $tgems = $session['user']['gems']; // User's Gems
	$goldcost = get_module_setting("goldcost"); // Gold Cost
	$gemcost = get_module_setting("gemcost"); // Gem Cost
    $op = httpget("op"); // The ability to fetch the op in the HTTP/Address bar.
    page_header("Angul's Alchemy");
    
    switch ($op){
		case "enter":
		if ($tgold >= $goldcost && $tgems >= $gemcost){
			// If their gold is greater than or equal to the goldcost, and their gems are greater than or equal to the gem cost, let them proceed.
			output("`4You walk into a narrow alley. A wandering minstrel strums out a tune, as you toss a coin into his hat.");
			output("`4 You come upon a grand black door, with an intricate design of hell traced upon it�s oaken boards. ");
			output("`4You stare at the door wondering who in the world would appreciate such a dark scene, where the pain of a thousand victims is so well portrayed, that the scene seems alive and that you yourself hurt with the image.`n`n");
			output("`7Two large Gryphon knockers animate themselves.`n`n"); 
			output("`\$\"So, you wish to enter here?`4\" the left knocker speaks. The right knocker looks accosted.`n`n"); 
			output("\"`QYou wish to let in this Mongrel?`4\"`n`n"); 
			output("`4They begin to bicker back and forth and eventually you determine that there is no point listening to them and shove the doors open.");
			output(" `4A tall and elegant Blood Seraph, with beautiful black and silver wings looks up at you.");
			output(" `4Her name is An`\$g`Qul`4. Upon her walls, rest a vast assortment of \"questionable\" equipment.`n`n");
			output("`Q\"How may I help you today?\"`4 She looks at you with a sly smile, appraising you.");
			output(" `4You know other things are going through her head other than you buying her elixirs.");
			addnav("Browse Angul's Wares","runmodule.php?module=alchemy&op=browse");
		}elseif ($tgold < $goldcost){
			// However, if their gold is less than the goldcost, reject them
			output("`4An`\$g`Qul`4 looks at you, her eyes fiery.`n"); 
			output("\"`QI am sorry, but you do not have enough gold to taste my wares. You must have at least `%%s `Qgold for an elixir.",$goldcost);
			output(" She flicks a fireball at you as you run out the door to escape her wrath.");
		}elseif ($tgems < $gemcost){
			// Also, if their gems are less than the gemcost, reject them
			output("`4An`\$g`Qul`4 looks at you, her eyes fiery.`n"); 
			output("\"`QI am sorry, but you do not have enough gems to taste my wares. You must have at least `%%s `Qgems for an elixir.",$gemcost);
			output(" She flicks a fireball at you as you run out the door to escape her wrath.");		
		}
		break;
    case "browse":
		if ($times < $allow){
			// So, we have enough gold and gems, seeing as how we had access to the nav to bring us into this new op.
			output("`4You wander over into a small room, where many small crystals adorn the walls, each a different hue.");
			output(" `4You walk over to the shelves and glance upon all of the elixirs upon them.");
			output(" `4An`\$g`Qul`4 follows you in, stalking you really. \"`QYou like my elixirs? Well, they cost %s %s %s %s...",
			($gemcost>1?$gemcost:""),
			translate_inline($gemcost==1?"gem":"gems"),
			translate_inline($goldcost>0&&$gemcost>0?"and":""),
			translate_inline($goldcost>1?$goldcost." gold":""));
			/* 
			All of this is just to make conditional statements.
			translate_inline is used in... guess what? Translation! :P
			The next part to it, is like a mini if/else statement.
			($condition?"if the condition is met, play this one":"else, play this")
			*/
			output(" `QWhat kind of elixir were you interested in?\"");
			addnav("Options");
			addnav("Test Angul's Wares","runmodule.php?module=alchemy&op=elixir");
			addnav("Leave");
		}else{
			// Oh no, they used it too much... byebye. :)
			output("`4An`\$g`Qul`4 brandishes a whip and snaps it in your general direction.`n");
			output("\"`QGet out of here and do not come back...I can smell my elixirs in your blood...`4\"");
		}
		break;
	case "elixir":
		alchemy_elixir(); // Run the elixir function.
		break;
	}
	villagenav(); // Create a nav back to the village, that will run at the bottom of each nav section, due to placement in the script
page_footer();
}
function alchemy_elixir(){
	global $session;
	$times = get_module_pref("times");
    $goldcost = get_module_setting("goldcost");
	$gemcost = get_module_setting("gemcost");
	$sex = translate_inline($session['user']['sex'] ? "woman." : "man.");
	// Again, you know what all of this is for
	
	switch (e_rand(1,8)){ //  We are going to select a single number from 1-8, and then have a different outcome for each
		case 1: // Random number is equal to 1
			output("`4You sit and ponder for a while. Eventually you stand and walk over to a small alcove.");
			output(" `4A shimmering blue light is emitted.");
			output(" `4You clutch the blue elixir.");
			output(" `4An`\$g`Qul`4 grabs you and throws you into the chair, straddling you.");
			output(" `4She breaks open the bottle and forces the liquid down your throat. `@You feel slightly stronger!");
			debuglog("gained Elixir Buff from blue Elixir");
			$session['user']['gems']-=$gemcost; // Reduce Gems
			$session['user']['gold']-=$goldcost; // Reduce Gold
			$times++; //  Increment (++) times by 1
			set_module_pref("times",$times); // Set the new times value
			if (isset($session['bufflist']['elixir'])) {
						$session['bufflist']['elixir']['rounds'] += 20;
						// If the buff is already set, add 20 rounds to it. ;)
			} else {
				apply_buff('elixir',
					array(
						"name"=>"`3Oceans Strength",
						"rounds"=>20,
						"wearoff"=>"The Elixir dissipates in your blood...",
						"atkmod"=>1.4, //  Multiplier, 20 base attack would become 20+8
						"roundmsg"=>"`#You look behind you and see a gigantic tidal wave, it fuses with the Elixir in your blood and empowers you!", // The message to play each round
						"schema"=>"module-alchemy",
							)
						);
					}
				break;
		case 2:
			output("`4You sit and ponder for a while. Eventually you stand and walk over to a rather large alcove.");
			output(" `4A serene green light is emitted.");
			output(" `4You grasp the green elixir.");
			output(" `4An`\$g`Qul`4 grabs you and throws you against the wall roughly.");
			output(" `4She breaks open the bottle and forces the liquid down your throat. `@You feel like you have gained some defense!");
			debuglog("gained Elixir Buff from green Elixir");
			$session['user']['gems']-=$gemcost;
			$session['user']['gold']-=$goldcost;
			$times++;
			set_module_pref("times",$times);  
			if (isset($session['bufflist']['elixir'])) {
						$session['bufflist']['elixir']['rounds'] += 20;
			} else {
				apply_buff('elixir',
					array(
						"name"=>"`2Forest Serernity",
						"rounds"=>20,
						"wearoff"=>"The Elixir dissipates in your blood...",
						"defmod"=>1.4,
						"roundmsg"=>"`@A gigantic tree appears behind you, fusing with the elixir in your blood, empowering you!",
						"schema"=>"module-alchemy",
								)
							);
						}	
			break;
		case 3:
			output("`4You sit and ponder for a while.");
			output(" `4Eventually you stand and walk over to a deep well.");
			output(" `4A furious red light is emitted.");
			output(" `4You reach for the red elixir.");
			output(" `4An`\$g`Qul`4 tosses you onto a couch, and straps come out and bind you.");
			output(" `4She breaks open the bottle and forces the liquid down your throat. `@You feel stronger!");
			debuglog("gained Elixir Buff from red Elixir");
			$session['user']['gems']-=$gemcost;
			$session['user']['gold']-=$goldcost;
			$times++;
			set_module_pref("times",$times);       
			if (isset($session['bufflist']['elixir'])) {
						$session['bufflist']['elixir']['rounds'] += 20;
			} else {
				apply_buff('elixir',
					array(
						"name"=>"`\$Fire's Well",
						"rounds"=>20,
						"wearoff"=>"The Elixir dissipates in your blood...",
						"atkmod"=>1.6,
						"defmod"=>.8,
						"roundmsg"=>"`\$A gigantic blaze breaks from the ground, it fuses with the Elixir in your blood and empowers you!",
						"schema"=>"module-alchemy",
								)
							);
						}
			break;
		case 4:
			output("`4You sit and ponder for a while.");
			output(" `4Eventually you stand and walk over to a small basin.");
			output(" `4A bright yellow light is emitted.");
			output(" `4You clutch the yellow elixir.");
			output(" `4An`\$g`Qul`4 grabs you and ties your hands behind your back and to a whipping post.");
			output(" `4She breaks open the bottle and forces the liquid down your throat. `@You feel stronger!");
			debuglog("gained Elixir Buff from yellow Elixir");
			$session['user']['gems']-=$gemcost;
			$session['user']['gold']-=$goldcost;
			$times++;
			set_module_pref("times",$times);       
			if (isset($session['bufflist']['elixir'])) {
						$session['bufflist']['elixir']['rounds'] += 20;
			} else {
				apply_buff('elixir',
					array(
						"name"=>"`^Sun Shine",
						"rounds"=>20,
						"wearoff"=>"The Elixir dissipates in your blood...",
						"atkmod"=>.8,
						"defmod"=>1.6,
						"roundmsg"=>"`^You look into the sky and see the sun shining bright. The light infuses with the elixir in your blood and empowers you!",
						"schema"=>"module-alchemy",
								)
							);
						}
			break;
		case 5:
			$loss = $session['user']['hitpoints']/2;
			output("`4You sit and ponder for a while.");
			output(" `4Eventually you stand and walk over to a broken basin.");
			output(" `4A dull orange light is emitted.");
			output(" `4You clutch the orange elixir.");
			output(" `4An`\$g`Qul`4 grabs you and runs her sharp nails down your body, drawing blood.");
			output(" `4She breaks open the bottle and forces the liquid down your throat. `@You feel VERY strong but lose hitpoints!");
			debuglog("gained Elixir Buff from orange Elixir");
			$session['user']['gems']-=$gemcost;
			$session['user']['gold']-=$goldcost;
			$session['user']['hitpoints']-=$loss; //  Reduce HP
			$times=get_module_pref("times")+2; // Increment by 2
			set_module_pref("times",$times); // Set value
			if (isset($session['bufflist']['elixir'])) {
						$session['bufflist']['elixir']['rounds'] += 10;
			} else {
				apply_buff('elixir',
					array(
						"name"=>"`QAngul's Fury",
						"rounds"=>30,
						"wearoff"=>"The Elixir dissipates in your blood...",
						"atkmod"=>1.4,
						"defmod"=>1.4,
						"roundmsg"=>"`QYou look to your side and see Angul, she caresses your skin and fuses with the Elixir in your blood and empowers you!",
						"schema"=>"module-alchemy",
								)
							);
						}
			break;
		case 6:
			$charm = e_rand(1,10);
			output("`4You sit and ponder for a while. Eventually you stand and walk over to a small shrine.");
			output(" `4A luminous purple light is emitted.");
			output(" `4You clutch the purple elixir.");
			output(" `4An`\$g`Qul`4 grabs you and takes you into another room and shuts the door.");
			output(" `4When you emerge, with a smug grin on your face, you feel like a new %s! `@You gain charm!", $sex);
			debuglog("gained $charm Charm from purple Elixir");
			$session['user']['charm']+=$charm; // Increase Charm
			$session['user']['gems']-=$gemcost;
			$session['user']['gold']-=$goldcost;
			$times++;
			set_module_pref("times",$times);
			break;
		case 7:
			$turns =  e_rand(2,5);
			output("`4You sit and ponder for a while.");
			output(" `4Eventually you stand and walk over to a shallow pool.");
			output(" `4An innocent pinkish light is emitted.");
			output(" `4You clutch the pink elixir.");
			output(" `4An`\$g`Qul`4 comes up behind you with a flogger with steel tips, whipping you across the back!");
			output(" `4For some odd reason you feel energized. `@You gain %s forest fights!",$turns);
			debuglog("gained $turns turns from pink Elixir");
			$session['user']['turns']+=$turns; // Increase Turns
			$session['user']['gems']-=$gemcost;
			$session['user']['gold']-=$goldcost;
			$times++;
			set_module_pref("times",$times);
			break;
		case 8:
			$loss = $session['user']['hitpoints']/2;
			output("`4You sit and ponder for a while.");
			output(" `4Eventually you stand and walk over to a dark liquid-like wall.");
			output(" `4A shimmery black light is emitted.");
			output(" `4You question whether or not it would be a good idea to take this, but you clutch the black elixir.");
			output(" `4An`\$g`Qul`4 suddenly strikes you across the face, drawing blood.");
			output(" `4She drags you by the head into another room.");
			output(" `4You emerge bloodied while she has a satisfied look on her face. `@You gain experience, but lose hitpoints!");
			$expgain = round($session['user']['experience']*get_module_setting("expgain"));
			debuglog("gained $expgain percent EXP from Black Elixir");
			$session['user']['experience']+=$expgain; // Increase EXP, by a module_setting
			$session['user']['gems']-=$gemcost;
			$session['user']['gold']-=$goldcost;
			$session['user']['hitpoints']-=$loss;
			$times = get_module_pref("times")+2;
			set_module_pref("times",$times);
			break;
	}
}
?>	