<?php
/**************
Name: Forest Spook
Author: Eth - ethstavern(at)gmail(dot)com 
Version: 1.0
Release Date: 03-07-2005
Rerelease Date: 12-24-2005 (for 1.0.x)
About: Encounter a ghost in the forest. Exciting.      
Translation compatible.
*****************/
require_once("lib/villagenav.php");
function forestspook_getmoduleinfo(){
	$info = array(
		"name"=>"Forest Spook",
		"version"=>"1.0",
		"author"=>"Eth",
		"category"=>"Forest Specials",
		"download"=>"http://dragonprime.net/users/Eth/forestspook.zip",
		"vertxtloc"=>"http://dragonprime.net/users/Eth/",
		"settings"=>array(
			"Forest Spook - Main,title",
			"spookchance"=>"Chance of encountering spook?,range,0,100,5|50",						
		),				
		"prefs"=>array(	
			"seenspook"=>"Seen spook yet?,bool|0"				
		),
	);
	return $info;
}
function forestspook_install(){	
	module_addeventhook("forest", "require_once(\"modules/forestspook.php\"); return forestspook_test();");	
	module_addhook("newday");	
	return true;
}
function forestspook_uninstall(){
	return true;
}
function forestspook_test(){
	global $session;	
	$chance = get_module_setting("spookchance","forestspook");
	if (get_module_pref("seenspook","forestspook") == 1) return 0; 
	return $chance; 
}
function forestspook_dohook($hookname,$args){
	global $session;
	switch ($hookname) {
		case "newday":
		if (get_module_setting("spookencounter") == 0){	
		set_module_pref("seenspook",0);	
		}
		break;	
	}
	return $args;
}
function forestspook_runevent($type){
	global $session;
	$op = httpget('op');
	if ($type == "forest") $from = "forest.php?";				
	$session['user']['specialinc'] = "module:forestspook";	
	output("`n");
	switch($type){
		case forest:
		if ($op==""){
			output("`2You suddenly stop in midstep as you see the nebulous form of a ghost approaching you!");
			output(" `2Teeth chattering and hair standing up on the back of your neck, you quickly try to think of what to do.`n`n");
			addnav("Yell Boo!",$from."op=boo");
			addnav("Run Away!",$from."op=runaway");
		}else if ($op=="boo"){
			set_module_pref("seenspook",1);
			output("`2Using all the strength you have, you scream `3\"BOO\" `2at the ghost as it draws closer.`n`n");
			switch(e_rand(1,15)){				
				case 1:
				case 2:
				case 3:
				output("`3The ghost pauses a moment and stares at you in confusion.");
				output(" `3After a minute, it simply floats away.`n`n");
				$session['user']['specialinc'] = "";
				break;
				case 4:
				case 5:
				case 6:
				output("`3Noticing the ghost is unfazed, you decide your best course of action would be to simply run away, which you do with great gusto.`n`n");
				$session['user']['specialinc'] = "";
				break;
				case 7:
				case 8:
				case 9:				
				output("`3It pauses a moment and looks at you with it's burning blue eyes, then bursts out laughing.`n`n");
				output("`2\"Ye gods, everyone thinks they're a comedian these days...\" it says wryly, and floats off in the direction it came.`n`n");
				$session['user']['specialinc'] = "";
				break;
				case 10:
				case 11:
				case 12:
				output("`3Pausing a moment to stare at you in confusion, the ghost suddenly yells \"BOO\" right back at you!`n`n");
				output("`3Before you know it, you're running away in sheer terror.`n`n");
				if ($session['user']['turns']>0) { $session['user']['turns']--; }
				$session['user']['specialinc'] = "";
				break;	
				case 13:
				case 14:
				case 15:
				//this idea is borrowed from Lonny's Castle mod. 
				output("`3The ghost seems to ignore you, and instead, floats on right `ithrough`i you!");
				output(" `3You grimace as you wipe the slime off your face and clothes.`n`n");
				output("`2This is not your day, you think, as you return to your journeys covered in ghost slime.`n`n");
				addnews("`3%s `2was `@slimed `2by a ghost in the forest today!",$session['user']['name']);
				$session['user']['specialinc'] = "";
				break;
			}
		}else if ($op=="runaway"){
			set_module_pref("seenspook",1);
			output("`2Not one to challenge a ghost, you take off running into the woods like a coward, the ghost's laughter echoing in your wake.`n`n");
			$session['user']['specialinc'] = "";
		}	
		break;
	}
}
function forestspook_run(){	
}
?>