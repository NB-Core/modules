Abandonded Castle with Mazed Editor

Lonny Luberts - logd@pqcomp.com

The Castle comes with a Maze editor that generates copy and paste code.
Code Generated for the Maze MUST be shared at http://dragonprime.net

The Castle and editor modules need to be installed seperately.

The Castle has superuser settings that need to be set for each individual user
that needs superuser access.  Do this from the user editor.

The Caslte also can be used as either a Village Location or a forest event, this setting
is accessable from game settings.

The Maze editor may have some problems with your screen resolution if you have a scheme
selected that has right hand stats.  Either increase your screen size or select a theme
with no right hand stats.