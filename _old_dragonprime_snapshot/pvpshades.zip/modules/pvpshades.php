<?

require_once("common.php");
require_once("lib/fightnav.php");
require_once("lib/pvpwarning.php");
require_once("lib/pvplist.php");
require_once("lib/pvpshadessupport.php");
require_once("lib/http.php");
require_once("lib/taunt.php");
require_once("lib/villagenav.php");

function pvpshades_getmoduleinfo(){
	$info = array(
		"name"=>"PvP in Shades",
		"version"=>"0.1",
		"author"=>"`qThe FaTMaN",
		"category"=>"Shades",
		"download"=>"No se",
		"settings"=>array(
			"PvP in Shades,title",
			"leveldifference"=>"Max level difference for PvP battles,range,1,15,1|3",
			"pvps"=>"Player Fights per day,range,1,15,1|5",
			"Favor distribution in PvP in Shades,title",
			"favorattwon"=>"Percent of victim favor attacker gains on win ,floatrange,0,50,.25|5",
			"favorattlost"=>"Percent of favor attacker loses on loss ,floatrange,0,50,.25|0",
			"favordefwon"=>"Percent of attacker favor defender gains on win ,floatrange,0,50,.25|2.5",
			"favordeflost"=>"Percent of favor defender loses on loss ,floatrange,0,50,.25|0",
			"Experience distribution in PvP in Shades,title",
			"expattwon"=>"Percent of victim experience attacker gains on win ,floatrange,0,50,.25|0",
			"expattlost"=>"Percent of experience attacker loses on loss ,floatrange,0,50,.25|0",
			"expdefwon"=>"Percent of attacker experience defender gains on win ,floatrange,0,50,.25|0",
			"expdeflost"=>"Percent of experience defender loses on loss ,floatrange,0,50,.25|0",
		),

	);
	return $info;
}

function pvpshades_install(){
	debug("Installing module");
	debug("Creating table");
	$sqlfunc = DBTYPE."_query";
	if(!@$sqlfunc("SELECT `pvpshades` FROM `".db_prefix("accounts")."`"))db_query("ALTER TABLE `".db_prefix("accounts")."` ADD `pvpshades` INT");

	module_addhook("footer-shades");
	module_addhook("footer-graveyard");
	module_addhook("newday");
}

function pvpshades_uninstall(){
	debug("Uninstalling module");
	debug("Deleting table");
	db_query("ALTER TABLE ".db_prefix("accounts")." DROP `pvpshades`");
}

function pvpshades_dohook($hookname,$args){
		
		global $session;
		
		switch($hookname){
		case "footer-graveyard":
			addnav("PvP");
			addnav("Look for dead warriors","runmodule.php?module=pvpshades");
		break;
		case "footer-shades":
			addnav("PvP");
			addnav("Look for dead warriors","runmodule.php?module=pvpshades");
		break;
		case "newday":
			db_query("UPDATE ".db_prefix("accounts")." SET `pvpshades` = ".get_module_setting("pvps")." WHERE `acctid` = ".$session['user']['acctid']." LIMIT 1");
		break;
	}
	return $args;
}

function pvpshades_run(){
		
		page_header("PvP in Shades");	
		
	global $session;
	$op = httpget("op");
	$act = httpget("act");

	if($op == "" && $act != "attack"){
		

		
		addnav("L?Refresh List of Souls","runmodule.php?module=pvpshades");
		addnav("Places");
		villagenav();
	
			$lowerlevel = $session['user']['level']-get_module_setting("leveldifference");
			$uperlevel = $session['user']['level']+get_module_setting("leveldifference");
			$sql = "SELECT acctid, name, alive, location, sex, level, laston, loggedin, login, soulpoints, pvpflag, clanshort, clanrank, dragonkills, ".db_prefix("accounts") . ".clanid FROM " .	db_prefix("accounts") . " LEFT JOIN " .	db_prefix("clans") . " ON " . db_prefix("clans") . ".clanid=" .	db_prefix("accounts") . ".clanid WHERE alive = 0 AND acctid != ".$session['user']['acctid']." AND level >= '".$lowerlevel."' AND level <= '".$uperlevel."' AND soulpoints != 0 AND loggedin = 0 ORDER BY level DESC,experience DESC, dragonkills DESC";
			$result = db_query($sql);
			$num = db_num_rows($result);
		
		if($session['user']['pvpshades'] != 0){
			
			$pvp = array();
			for ($i=0;$i<$num;$i++){
				$row = db_fetch_assoc($result);
				$pvp[] = $row;
			}

			$pvp = modulehook("pvpmodifytargets", $pvp);

			tlschema("pvp");
			$n = translate_inline("Name");
			$l = translate_inline("Level");
			$ops = translate_inline("Ops");
			$bio = translate_inline("Bio");
			$att = translate_inline("Attack");

			output("`)`c`bPvP in The Land of Shades`b`c");
			output("Here you are some dead warriors, that were killed in the world of above witch you can torment because they can be bad for `\$Ramius`).`n`n");
			output("You can fight with %s souls now.`n`n",$session['user']['pvpshades']);
			rawoutput("<center><table border='0' cellpadding='3' cellspacing='0'>");
			rawoutput("<tr class='trhead'><td>$n</td><td>$l</td><td>$ops</td></tr>");
			$num = count($pvp);
			$j = 0;
			for ($i=0;$i<$num;$i++){
				$row = $pvp[$i];

				$j++;
				$biolink="bio.php?char=".rawurlencode($row['login']);
				rawoutput("<tr class='".($j%2?"trlight":"trdark")."'>");
				rawoutput("<td>");
				if ($row['clanshort']>"" && $row['clanrank'] > CLAN_APPLICANT) {
					output_notl("%s&lt;`2%s%s&gt;`0 ",
							$clanrankcolors[$row['clanrank']], $row['clanshort'],
							$clanrankcolors[$row['clanrank']], true);
				}
				output_notl("`@%s`0", $row['name']);
				rawoutput("</td>");
				rawoutput("<td>");
				output_notl("%s", $row['level']);
				rawoutput("<td>[ <a href='$biolink'>$bio</a>");
				if($session['user']['soulpoints'] != 0){
					rawoutput(" | <a href='runmodule.php?module=pvpshades&act=attack&name=".rawurlencode($row['login'])."'>$att</a>");
					addnav("","runmodule.php?module=pvpshades&act=attack&name=".rawurlencode($row['login']));
				}
				addnav("","$biolink");
				rawoutput(" ]</td>");
				rawoutput("</tr>");
			}

			rawoutput("</table></center>",true);
		}else{
			output("`)`c`bPvP in The Land of Shades`b`c");
			output("Here you are some dead warriors, that were killed in the world of above witch you can torment because they can be bad for `\$Ramius`).`n`n");
			output("But you think that you have tormented enough souls for today.");
		}
		if($session['user']['soulpoints'] == 0)output("`n`n`c`bBut you can't torment souls now because your soul is soo tired`b`c");
	}else{
if ($act == "attack") {
	$name = httpget('name');
	$badguy = setup_target($name);
	$failedattack = false;
	if ($badguy == false) {
		$failedattack = true;
	} else {
		$battle=true;
		$session['user']['badguy']=createstring($badguy);
		$session['user']['pvpshades']--;
	}

	if ($failedattack){
			addnav("Return to Listing","runmodule.php?module=pvpshades");
	}
}

if ($op=="run"){
  output("Your pride prevents you from running");
  $op="fight";
  httpset('op', $op);
}

$skill = httpget('skill');
if ($skill!=""){
  output("Your honor prevents you from using any special ability");
  $skill="";
  httpset('skill', $skill);
}
if ($op=="fight" || $op=="run"){
	$battle=true;
}
if ($battle){
	$originalhitpoints = $session['user']['hitpoints'];
	$session['user']['hitpoints'] = $session['user']['soulpoints'];
	$originalattack = $session['user']['attack'];
	$originaldefense = $session['user']['defense'];
	$session['user']['attack'] =
		10 + round(($session['user']['level'] - 1) * 1.5);
	$session['user']['defense'] =
		10 + round(($session['user']['level'] - 1) * 1.5);
	require_once("battle.php");
	$session['user']['attack'] = $originalattack;
	$session['user']['defense'] = $originaldefense;
	$session['user']['soulpoints'] = $session['user']['hitpoints'];
	$session['user']['hitpoints'] = $originalhitpoints;

	if ($victory){
		$killedin = $badguy['location'];
		$handled = pvpvictory($badguy, $killedin);

		// Handled will be true if a module has already done the addnews or
		// whatever was needed.
		if (!$handled) {
				addnews("`4%s`3 defeated `4%s`3 in fair combat in The Land of Shades.", $session['user']['name'],$badguy['creaturename']);
		}

		$op = "";
		httpset('op', $op);
			villagenav();
	}elseif($defeat){
		$taunt = select_taunt_array();
		// This is okay because system mail which is all it's used for is
		// not translated
		$handled = pvpdefeat($badguy, $killedin, $taunt);
		// Handled will be true if a module has already done the addnews or
		// whatever was needed.
		if (!$handled) {
				addnews("`%%s`5 has been slain while attacking `^%s`5 in `&The Land of Shades`5.`n%s`0", $session['user']['name'], $badguy['creaturename'], $taunt);
		}
	}else{
		fightnav(false,false, "runmodule.php?module=pvpshades");
	}
}
}
	page_footer();
}
?>