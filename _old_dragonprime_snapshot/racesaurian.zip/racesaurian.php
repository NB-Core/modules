<?php

function racesaurian_getmoduleinfo(){
	$info = array(
		"name"=>"Race - Saurian",
		"version"=>"1.0",
		"author"=>"Sneakabout",
		"category"=>"Races",
		"download"=>"Ask Nicely!",
		"settings"=>array(
			"Saurian Race Settings,title",
			"minedeathchance"=>"Percent chance for Saurians to die in the mine,range,0,100,1|85",
			"mindk"=>"How many DKs do you need before the race is available?,int|5",
		),
	);
	return $info;
}

function racesaurian_install(){
	if (!is_module_installed("racetroll")) {
		output("Saurians are only found in the depths of the Trollish swamps. You must install that race module.");
		return false;
	}
	module_addhook("chooserace");
	module_addhook("setrace");
	module_addhook("newday");
	module_addhook("charstats");
	module_addhook("raceminedeath");
	module_addhook("pvpadjust");
	return true;
}

function racesaurian_uninstall(){
	global $session;
	$sql = "UPDATE  " . db_prefix("accounts") . " SET race='" . RACE_UNKNOWN . "' WHERE race='Saurian'";
	db_query($sql);
	if ($session['user']['race'] == 'Saurian')
		$session['user']['race'] = RACE_UNKNOWN;
	return true;
}

function racesaurian_dohook($hookname,$args){
	global $session,$resline;

	if (is_module_active("racetroll")) {
		$city = get_module_setting("villagename", "racetroll");
	} else {
		$city = getsetting("villagename", LOCATION_FIELDS);
	}
	$race = "Saurian";
	switch($hookname){
	case "pvpadjust":
		if ($args['race'] == $race) {
			$args['creatureattack']+=(2+floor($args['creaturelevel']/5));
		}
		break;
	case "raceminedeath":
		if ($session['user']['race'] == $race) {
			$args['chance'] = get_module_setting("minedeathchance");
			$args['racesave'] = "You tear your way through the rocks to freedom.`n";
			$args['schema']="module-racesaurian";
		}
		break;
	case "charstats":
		if ($session['user']['race']==$race){
			addcharstat("Vital Info");
			addcharstat("Race", translate_inline($race));
		}
		break;
	case "chooserace":
		if ($session['user']['dragonkills'] < get_module_setting("mindk"))
			break;
		output("<a href='newday.php?setrace=Saurian$resline'>People say that if you need muscle, you want a troll from the swamps of %s</a>. Well, when the Trolls need muscle they turn to the Saurians, great lizard-like creatures with inhuman strength and aggression but cold blood.`n`n",$city, true);
		addnav("`7Saurian`0","newday.php?setrace=$race$resline");
		addnav("","newday.php?setrace=$race$resline");
		break;
	case "setrace":
		if ($session['user']['race']==$race){
			output("`7As a Saurian, you have bulging muscles! You are more aggressive and attack better!`n");
			output("Your cold blood means you are always the last to get up!`n");
			if (is_module_active("cities")) {
				set_module_pref("homecity",$city,"cities");
				$session['user']['location']=$city;
			}
		}
		break;
	case "newday":
		if ($session['user']['race']==$race){
			racesaurian_checkcity();
			apply_buff("racialbenefit",array(
				"name"=>"`@Saurian Strength`0",
				"atkmod"=>"(<attack>?(2+((1+floor(<level>/5))/<attack>)):0)",
				"allowinpvp"=>1,
				"allowintrain"=>1,
				"rounds"=>-1,
				"schema"=>"module-racesaurian",
				)
			);
			$turnloss=round(($session['user']['turns']*0.25),0);
			output("`n`7You feel blood lust! You gain a PvP fight! Your cold blood slows you down! You lose %s Forest Fights!",$turnloss);
			$session['user']['turns']-=$turnloss;
			if ($session['user']['spirite']!=-6) $session['user']['playerfights']++;
		}
		break;
	}
	return $args;
}

function racesaurian_checkcity(){
	global $session;
	$race="Saurian";
	if (is_module_active("racetroll")) {
		$city = get_module_setting("villagename", "racetroll");
	} else {
		$city = getsetting("villagename", LOCATION_FIELDS);
	}
	
	if ($session['user']['race']==$race && is_module_active("cities")){
		//if they're this race and their home city isn't right, set it up.
		if (get_module_pref("homecity","cities")!=$city){ //home city is wrong
			set_module_pref("homecity",$city,"cities");
		}
	}	
	return true;
}

function racesaurian_run(){
}
?>