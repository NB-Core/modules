<?
/*

Dannic released a Monk Specialty.  That file was the template for this
module, but I've retained all his author info, despite the fact that I've
replaced/rewritten almost the entire module.  It all started with CortalUX's
Ranger module, which was greatly unbalanced.  (Don't get me wrong, I love
most of CortalUX's modules, and there is reason some of them have made it
into the core release.  But the Ranger module was broken.  And when I looked
at how I wanted to rewrite it, it only made sense to create the Ranger along
the lines of the D&D Ranger.  Then I got to thinking, that while LoRD had
a Fighter (Death Knight), Wizard (Magic User), and Rouge (Thief) as it's 3
core classes, LoGD basically has a Rouge/Thief and 2 magic users as it's
core classes.  And next thing you know, I decided to do the 13 core D&D
classes as specialties.  So, this module has been rewritten to create the
Monk more in line with the D&D Monk.

After much debate, I've kept some of Dannic's ideas, such as forcing Monks
to fight without weapons or armor.  Their attack and defense do get bonuses
for being a Monk, which offsets the lack of weapons/armor.  However, they
also recelve less gold in combat (module preference).  This module is just
more in line with my preferences.  I'm not trying to get my version in cir-
culation, or replace Dannic's version.  I just have available for download
to be in line with the license.

-- Enderandrew

*/

/***************************************************************************/
/* Name: Specialty - Monk Skills                                           */
/* ver 1.4                                                                 */
/* Billie Kennedy => dannic06@gmail.com                                    */
/*                                                                         */
/* 12-29-2004                                                              */
/*   Fixed major flaw where it would take away everyones weapons and armor */
/*   updated pointdesc so that it doesn't show up in the lodge unless the  */
/*      lodge cost is set                                                  */
/* 1-6-2005                                                                */
/*   Fixed Translation readiness and typo                                  */
/*   Changed the weapon and armor dropping code in the fightnav            */
/***************************************************************************/

function specialtymonkskills_getmoduleinfo(){
	$info = array(
		"name" => "Specialty - Monk Skills",
		"author" => "`!Enderandrew<br>Original by Billie Kennedy",
		"version" => "1.61",
		"description"=>"This will add a D&D inspired Monk to the game.",
		"download" => "http://dragonprime.net/users/enderwiggin/specialtymonkskills.zip",
		"vertxtloc"=>"http://dragonprime.net/users/enderwiggin/",
		"category" => "Specialties",
		"settings"=> array(
			"Specialty - Monk Settings,title",
			"mindk"=>"How many DKs do you need before the specialty is available?,int|0",
			"cost"=>"How many points do you need before the specialty is available?,int|0",
			"goldloss"=>"How much less gold (in percent) do the Monks find?,range,0,100,1|15",
		),
		"prefs" => array(
			"Specialty - Monk Skills User Prefs,title",
			"skill"=>"Skill points in Monk Skills,int|0",
			"uses"=>"Uses of Monk Skills allowed,int|0",
		),
	);
	return $info;
}

function specialtymonkskills_install(){
	module_addhook("apply-specialties");
	module_addhook("castlelibbook");
	module_addhook("castlelib");
	module_addhook("choose-specialty");
	module_addhook("creatureencounter");
	module_addhook("dragonkill");
	module_addhook("fightnav-specialties");
	module_addhook("incrementspecialty");
	module_addhook("newday");
	module_addhook("pointsdesc");
	module_addhook("set-specialty");
	module_addhook("specialtycolor");
	module_addhook("specialtynames");
	module_addhook("specialtymodules");
	module_addhook("village");
	return true;
}

function specialtymonkskills_uninstall(){
	// Reset the specialty of anyone who had this specialty so they get to
	// rechoose at new day
	$sql = "UPDATE " . db_prefix("accounts") . " SET specialty='' WHERE specialty='MN'";
	db_query($sql);
	return true;
}

function specialtymonkskills_dohook($hookname,$args){
	global $session,$resline;


	$spec = "MN";
	$name = "Monk Skills";
	$ccode = "`Q";
	$cost = get_module_setting("cost");
	$op69 = httpget('op69');
	
	switch ($hookname) {

	case "apply-specialties":
		$skill = httpget('skill');
		$l = httpget('l');
		if ($skill==$spec){
			if (get_module_pref("uses") >= $l){
				switch($l){
				case 1:
					apply_buff('mn1',array(
						"startmsg"=>"`^Your arms and legs fly at an amazing speed, attacking and blocking.",
						"name"=>"`^Flurry of Blows",
						"rounds"=>5,
						"wearoff"=>"Your concentration is broken and you can't seem to get back into rythm.",
						"roundmsg"=>"`^Wax on, wax off.  You wax the bastard for {damage} damage.",
						"atkmod"=>1,6,
						"defmod"=>0.9,
						"schema"=>"specialtymonkskills"
					));
					break;
				case 2:
					apply_buff('mn2',array(
						"startmsg"=>"`^You movements are fluid, and thoughtless.  You evade attacks almost before they are made.",
						"rounds"=>7,
						"wearoff"=>"Your concentration is broken and you can no longer sense incoming attacks.",
						"name"=>"`^Evasion",
						"defmod"=>1.4,
						"schema"=>"specialtymonkskills"
					));
					break;
				case 3:
					apply_buff('mn3', array(
						"startmsg"=>"`^You focus all your Ki into one crippling blow, the Quivering Palm technique.",
						"name"=>"`^Quivering Palm Technique",
						"atkmod"=>3.0,
						"effectmsg"=>"`^You thrust a concertrated strike into {badguy} for `&{damage}`^ points!",
						"schema"=>"specialtymonkskills"
					));
					break;
				case 5:
					apply_buff('mn5',array(
						"startmsg"=>"`^You pushed your body, mind and soul.  Now you harness strength from all three.",
						"name"=>"`^Perfect Self",
						"rounds"=>5,
						"wearoff"=>"Your resolve falters, and your state of perfect being fades away.",
						"defmod"=>4,
						"roundmsg"=>"`&Your body is no longer that of a simple human.  Your movements are pure, and perfect!",
						"schema"=>"specialtymonkskills"
					));
					break;
				}
				set_module_pref("uses", get_module_pref("uses") - $l);
			}else{
				apply_buff('MN0', array(
					"startmsg"=>"Grasshopper, your moves are tired and weak.  Try again when you don't suck so much.",
					"rounds"=>1,
					"schema"=>"specialtymonkskills"
				));
			}
		}
		break;

	case "castlelibbook":
		output("The five point exploding heart palm technique. (2 Turns)`n");
		addnav("Read a Book");
		addnav("The five point exploding heart palm technique","runmodule.php?module=lonnycastle&op=library&op69=monk");
		break;

	case "castlelib":
		if ($op69 == 'Monk'){
			output("You sit down and open up \"The five point exploding heart palm technique\" book.`n");
			output("You read for a while... in the time it takes you to read you use up`n");
			output("2 Turns.`n`n");
			output("`^This technique can kill in one quick blow, and is near impossible to defend against.`n");
			output("`^Too bad it only works against someone named Bill, whoever that is.  But you might be`n");
			output("`^able to apply this somewhat to improve the Quivering Palm technique a bit.`n");
			output("You now know a little more about your Monk skills than you knew before.`n");
			$session['user']['turns']-=2;
			set_module_pref('skill',(get_module_pref('skill','specialtymonkskills') + 3),'specialtymonkskills');
			set_module_pref('uses', get_module_pref("uses",'specialtymonkskills') + 1,'specialtymonkskills');
			addnav("Continue","runmodule.php?module=lonnycastle&op=library");
			}
		break;

	case "choose-specialty":
		if ($session['user']['specialty'] == "" ||
				$session['user']['specialty'] == '0') {
			$pointsavailable = $session['user']['donation'] - $session['user']['donationspent'];
			if ($session['user']['dragonkills'] < get_module_setting("mindk") || $cost > $pointsavailable)
				break;
			addnav("$ccode$name`0","newday.php?setspecialty=".$spec."$resline");
			$t1 = translate_inline("Wishing you were a ninja.  You did become pretty bad-ass in hand-to-hand combat.");
			$t2 = appoencode(translate_inline("$ccode$name`0"));
			rawoutput("<a href='newday.php?setspecialty=$spec$resline'>$t1 ($t2)</a><br>");
			addnav("","newday.php?setspecialty=$spec$resline");
		}
		break;

	case "creatureencounter":
		if($session['user']['specialty'] == 'MN'){
			$loss = (100 - get_module_setting("goldloss"))/100;
			$args['creaturegold']=round($args['creaturegold']*$loss,0);
		}
		break;

	case "dragonkill":
		set_module_pref("uses", 0);
		set_module_pref("skill", 0);
		break;

	case "fightnav-specialties":
		$uses = get_module_pref("uses");
		$script = $args['script'];
		if($session['user']['specialty'] == 'MN'){
			if ($session['user']['armordef']>=1){
				output("You feel rather silly in your %s and remove your armor. A Karate Gi is much less restricting.`n",$session['user']['armor']);
			}
				$session['user']['armor'] = "Karate Gi";
				$session['user']['defense']-=$session['user']['armordef'];
				$session['user']['armordef']=0;
				$session['user']['armorvalue']=0;	
		
			if ($session['user']['weapondmg']>=1){
				output("It just doesn't feel right to use %s. You lay the weapon down and go back to just your bare hands.`n",$session['user']['weapon']);
			}
				$session['user']['weapon'] = "Kung-Fu Grip";
				$session['user']['attack']-=$session['user']['weapondmg'];
				$session['user']['weapondmg']=0;
				$session['user']['weaponvalue']=0;
				$session['user']['attack']=$session['user']['level']*2;			
		
		}
		if ($uses > 0) {
			addnav(array("$ccode$name (%s points)`0", $uses),"");
			addnav(array("$ccode &#149; Flurry of Blows`7 (%s)`0", 1), 
					$script."op=fight&skill=$spec&l=1", true);
		}
		if ($uses > 1) {
			addnav(array("$ccode &#149; Evasion`7 (%s)`0", 2),
					$script."op=fight&skill=$spec&l=2",true);
		}
		if ($uses > 2) {
			addnav(array("$ccode &#149; Quivering Palm Technique`7 (%s)`0", 3),
					$script."op=fight&skill=$spec&l=3",true);
		}
		if ($uses > 4) {
			addnav(array("$ccode &#149; Perfect Self`7 (%s)`0", 5),
					$script."op=fight&skill=$spec&l=5",true);
		}
		break;

	case "incrementspecialty":
		if($session['user']['specialty'] == $spec) {
			$new = get_module_pref("skill") + 1;
			set_module_pref("skill", $new);
			$c = $args['color'];
			$name = translate_inline($name);
			output("`n%sYou gain a level in `&%s%s to `#%s%s!",
					$c, $name, $c, $new, $c);
			$x = $new % 3;
			if ($x == 0){
				output("`n`^You gain an extra use point!`n");
				set_module_pref("uses", get_module_pref("uses") + 1);
			}else{
				if (3-$x == 1) {
					output("`n`^Only 1 more skill level until you gain an extra use point!`n");
				} else {
					output("`n`^Only %s more skill levels until you gain an extra use point!`n", (3-$x));
				}
			}
			output_notl("`0");
		}
		break;

	case "newday":
		$bonus = getsetting("specialtybonus", 1);
		if($session['user']['specialty'] == $spec) {
		$name = translate_inline($name);
			if ($bonus == 1) {
				output("`n`2For being interested in %s%s`2, you receive `^1`2 extra `&%s%s`2 use for today.`n",$ccode,$name,$ccode,$name);
			} else {
				output("`n`2For being interested in %s%s`2, you receive `^%s`2 extra `&%s%s`2 uses for today.`n",$ccode,$name,$bonus,$ccode,$name);
			}
		}
		$amt = (int)(get_module_pref("skill") / 3);
		if ($session['user']['specialty'] == $spec) $amt = $amt + $bonus;
			set_module_pref("uses", $amt);
		break;

	case "pointsdesc":
		if ($cost > 0){
			$args['count']++;
			$format = $args['format'];
			$str = translate("The Monk Specialty is availiable upon reaching %s Dragon Kills and %s points.");
			$str = sprintf($str, get_module_setting("mindk"),$cost);
		}
			output($format, $str, true);
		break;

	case "set-specialty":
		if($session['user']['specialty'] == $spec) {
			page_header($name);
			
			$session['user']['donationspent'] = $session['user']['donationspent'] - $cost;
			$session['user']['armor'] = "Karate Gi";
			$session['user']['weapon'] = "Kung-Fu Grip";
			$session['user']['defense']= $session['user']['defense']+1;
			$session['user']['attack']=$session['user']['attack']+1;
			
			output("`3Showing up at the great doors of the Monestary, the monks told you to go away. ");
			output("You were persistant, and strong of will.  You demanded to learn how to be a bad-ass and kick butt ninja-style.`n`n");
			output("A Master came out to speak with you briefly.  He said if you could remove the pebble from his hand before he closed it, then he would train you.`n`n");
			output("You grasped as quickly as you could, but while you were focused on the pebble, he smacked you upside the head. Then he offered to train you to do the same. ");
			output("It's been years and years of intense and grueling training, but you you feel confident that you too can trick a small child and smack them upside the head.`n`n");
			output("It's time to leave the Monestary and walk the earth, you jobless bum.");		
			}
		break;

	case "specialtycolor":
		$args[$spec] = $ccode;
		break;

	case "specialtymodules":
		$args[$spec] = "specialtymonkskills";
	    break;

	case "specialtynames":
		$pointsavailable = $session['user']['donation'] - $session['user']['donationspent'];
		if ($session['user']['superuser'] & SU_EDIT_USERS || $session['user']['dragonkills'] >= get_module_setting("mindk") || get_module_setting("cost") <= $pointsavailable){
			$args[$spec] = translate_inline($name);
		}
		break; 

	case "village":
		if ($session['user']['specialty']=='MN'){
			blocknav("weapons.php");
			blocknav("armor.php");
			output("`n`n$ccodeAs a Monk, you find no use for the Weapon and Armor shops... so you just ignore them...`n`n`0");
		}
	break; 
  }
	return $args;
}

function specialtymonkskills_run(){
}
?>