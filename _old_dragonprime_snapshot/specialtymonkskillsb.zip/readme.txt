-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
Speciality - Monk - A module for Legend of the Green Dragon 1.0.3

Legend of the Green Dragon
by  Eric "MightyE" Stevens (http://www.mightye.org)
and JT "Kendaer" Traub (http://www.dragoncat.net)

Software Project Page:
http://sourceforge.net/projects/lotgd

Modification Community Page:
http://dragonprime.net

Author of this Module:
Original - Billie Kennedy (Dannic)
Altered by - Enderandrew (enderandrew@gmail.com)

Enderandrew's LoGD game:
http://enderandrew.com/lotgd/

Download the latest version of this module from:
http://dragonprime.net/index.php?action=viewfiles&user=enderwiggin

----------------------------------------------
-- STATUS: -----------------------------------
----------------------------------------------
This module is STABLE.

----------------------------------------------
-- INFORMATION: ------------------------------
----------------------------------------------
Dannic released a Monk Specialty.  That file was the template for this
module, but I've retained all his author info, despite the fact that I've
replaced/rewritten almost the entire module.  It all started with CortalUX's
Ranger module, which was greatly unbalanced.  (Don't get me wrong, I love
most of CortalUX's modules, and there is reason some of them have made it
into the core release.  But the Ranger module was broken.  And when I looked
at how I wanted to rewrite it, it only made sense to create the Ranger along
the lines of the D&D Ranger.  Then I got to thinking, that while LoRD had
a Fighter (Death Knight), Wizard (Magic User), and Rouge (Thief) as it's 3
core classes, LoGD basically has a Rouge/Thief and 2 magic users as it's
core classes.  And next thing you know, I decided to do the 13 core D&D
classes as specialties.  So, this module has been rewritten to create the
Monk more in line with the D&D Monk.

After much debate, I've kept some of Dannic's ideas, such as forcing Monks
to fight without weapons or armor.  Their attack and defense do get bonuses
for being a Monk, which offsets the lack of weapons/armor.  However, they
also recelve less gold in combat (module preference).  This module is just
more in line with my preferences.  I'm not trying to get my version in cir-
culation, or replace Dannic's version.  I just have available for download
to be in line with the license.

This module requires version 1.0.3 or later of LotGD.

----------------------------------------------
-- INSTALLATION: -----------------------------
----------------------------------------------
Copy specialtymonkskills.php within this zip into your modules directory.

Login to the Superuser Grotto and Install / Activate it.

-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-