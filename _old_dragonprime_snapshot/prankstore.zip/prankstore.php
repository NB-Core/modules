<?php

function prankstore_getmoduleinfo(){
	require_once("modules/prankstore/prankstore_getmoduleinfo.php");
	return $info;
}
function prankstore_install(){
	module_addhook("changesetting");
	module_addhook("village");
	module_addhook("newday-runonce");
	module_addhook("dragonkill");
	module_addhook("charstats");
	return true;
}
function prankstore_uninstall(){
	return true;
}
function prankstore_dohook($hookname,$args){
	global $session;
	require("modules/prankstore/dohook/$hookname.php");
	return $args;
}
function prankstore_run(){
	require_once("modules/prankstore/prankstore_func.php");
	include("modules/prankstore/prankstore.php");
}
?>