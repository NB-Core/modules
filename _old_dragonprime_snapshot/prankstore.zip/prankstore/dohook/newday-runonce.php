<?php
 	for ($i = 10; $i < 13; $i++){
		$who=get_module_setting("prankon".$i);
		//check to see if anyone had the weapon prank pulled on them
		if ($who>0){
			$sql = "SELECT weapon FROM " . db_prefix("accounts") . " WHERE acctid='$who'";
			$result = db_query($sql);
			$row = db_fetch_assoc($result);
			$weapon=$row['weapon'];
			$oldweapon=get_module_setting("weapon".$i);
			$whichprank=get_module_setting("result".$i);
			$prankweapon=get_module_setting($whichprank."prank".$i);
			//if the current weapon is the same as the prank weapon, then update with the old weapon
			if ($weapon==$prankweapon){
				$sql = "UPDATE " . db_prefix("accounts") . " SET weapon='$oldweapon' WHERE acctid='$who'";
				db_query($sql);
			}
			set_module_setting("weapon".$i,"");
		}
	}
 	$sql = "update ".db_prefix("module_userprefs")." set value=16 where value<>0 and setting='pranker' and modulename='prankstore'";
 	db_query($sql);		
 	for ($i = 1; $i < 16; $i++){
		set_module_setting("prankon".$i,0);
		set_module_setting("result".$i,0);
		$random=e_rand(1,100);
		if ($random<=get_module_setting("percent".$i)){
			$type=e_rand(1,3);
			set_module_setting("result".$i,$type);
		}
	}
?>