<?
/*
    The Anti-Acronymist movement...
        ,,,just because they deserve it.
        
    Well, the darker side of Rowne shows itself here.
    Though it is rather funny if I do say so myself.
    If you find it funny too then hurrah, enjoy!
    
    Credits:
    
    I borrowed from...
    
    findgold.php - Eric Stevens (core example).
    robinhood.php - Lonny Luberts and Frederic Hutow.
    
    I learned how to do certain things I had no clue
    how I would do otherwise.  I hope that's not a
    bad thing...
*/

function antiacronym_getmoduleinfo(){
    $info = array(
        "name"=>"Anti-Acronymist Movement",
        "author"=>"Rowne-Wuff Mastaile",
        "version"=>"0.2",
        "category"=>"Forest Specials",
            "settings"=>array(
            "Anti-Acronymist Movement Settings,title",
            "mingold"=>"Minimum gold given (multiplied by level),range,0,50,1|10",
            "maxgold"=>"Maximum gold given (multiplied by level),range,20,150,1|50",
        ),
    );
    return $info;    
}

function antiacronym_install(){
    module_addeventhook("forest", "return 100;");
    return true;
}

function antiacronym_uninstall(){
    return true;
}

function antiacronym_dohook($hookname,$args){
    return $args;
}

function antiacronym_runevent($type){
  global $session;
  $session['user']['specialinc'] = "module:antiacronym";
  $op = httpget('op');
    if ($op=="" || $op=="search"){
        $movement = e_rand(1,2);
        output("`7Wandering randomly through forests can often result in the strangest of things, as you've just learned.");
        output("The sight you see before you is very odd indeed. A mob of robed scholars complete with torches is crowding around...");
        output("is that a gigantic rocket? As in, a firecracker rocket? It seems to be but what would they be doing there?");
        output("`n`nAs you watch, two more students looking more decorated than the rest drag in a very reluctant, scruffy looking urchin");
        if ($movement == 1) {
            output("and tie him to the rocket!  \"`6wtf?? omg omg omg! wtf? omg!!! afaik im gonna do teh final afk!`7\" yells the urchin pitifully.");
        } else {
            output("and tie him to the rocket!  \"`6][ \/\/l|_|_ k1|_|_ j00 4|_|_, ][ wl|_|_ P\/\/|\|Z j00. j00 \/\/1|_|_ |=33|_ /\/\\`/ b00{V}571|<z \/\/r47|-|!`7\" yells the urchin angrily, in that weird dialect.");
        }
        output("`n`nSomewhat curious as to what the hell all this is about, you wander up to one of the more amiable looking scholars and ask.");
        output("Though after what you've just seen, you're sure to put on your most grammarian of faces. \"`6My good fellow, you there!`7\"");
        output("you call to him. With a quick heelspin he's facing you, eyebrow raised. \"`6May I ask what's transpirin' here?`7\" you query,");
        if ($movement == 1) {
            $movementsay = "Anti-Acronymist Movement";
        } else {
            $movementsay = "Anti-Leetist Movement";
        }
        output("gesturing towards the giant firecracker. \"`6Oh, `ithat`i...`7\" he murmurs, \"`6we're the %s.", $movementsay);
        output("As you can see we've got one of the stupid buggers here and we're about to launch him into space! You may watch if you wish.`7\"");
        output("What do you wish to do however... ?");
        addnav("Watch the Show","forest.php?op=watch");
        if ($movement == 1) {
            addnav("OMG Save Him!","forest.php?op=save");
        } else {
            addnav("][ S4\/3 j00!!","forest.php?op=save");
        }
        addnav("Leave","forest.php?op=leave");
    }

    if ($op == "watch"){
        $session['user']['specialinc'] = "";
        if ($movement == 1) {
            addnews("%s`2 helped rid the World of another pesky acronym user!", $session['user']['name']);
        } else {
            addnews("%s`2 helped rid the World of another pesky l33t-speaker!", $session['user']['name']);
        }        
        $min = $session['user']['level']*get_module_setting("mingold");
        $max = $session['user']['level']*get_module_setting("maxgold");
        $gold = e_rand($min, $max);
        $session['user']['gold']+=$gold;
        if (is_module_active('alignment')) {
		require_once("./modules/alignment/func.php");
            align("-2");
        }
        output("`7After a short speech about the evils of acronyms, the most prominent of the two students that entered earlier takes a torch.");
        output("He leans down and sets the firecracker's ignition thread alight, within seconds it burns and up goes the scruffy urchin with it!");
        if ($movement == 1) {
            output("As his last act, he screams \"`6omg lolrofl f u f u kthxgoooooaaaaaal . . .`7\"");
        } else {
            output("As his last act, he screams \"`6][ \/\/1|_|_ R35p4444444444\/\/|\||\| . . .`7\"");
        }
        output("and explodes into a flurry of beautiful fireworks.");
        output("`n`nThere's much cheering and you can't help but salute and once the festivities are over, you decide to leave. However...");
        output("on your way out, one of the students stops you and congratulates you on being intelligent enough to not try to intervene,");
        output("he hands you a bag of %s gold coins as his thanks.", $gold);
        output("`n`n`&You've gained `$%s`& gold coins!", $gold);
    }

    if ($op == "save"){
        output("`7You skirt around the crowd and raise your %s sharply upwards, only to bring it down in a clean slice, cutting the ropes!", $session['user']['weapon']);
        output("Despite being scholarly, the crowd immediately turns angry and an angry crowd quickly turns into an angry mob...");
        output("You'd better prepare yourself for a fight! This is going to get ugly...");
        addnav("WTF Fight","forest.php?op=fight1");
    }

    if ($op == "win"){
        $session['user']['specialinc'] = "";
        $session['user']['charm']++;
        output("`7For a moment you hold your head high, until you realize that for all their pretentiousness, they're still just schoolkids.");
        output("Suddenly you feel a little bad over what you've done but they were going to launch an 'innocent' into orbit.");
        output("So your actions were a good deed at least, you did save someone and right now, that someone thinks of you as a hero.");
        output("How you feel about that, you're not sure. You wander away from the site having mixed feelings about the whole thing");
        output("but it seems more good than bad.");
        output("`n`n`&For helping an 'innocent', you gain a charm point!");
    }

    if ($op == "lose"){
        $session['user']['specialinc'] = "";
        output("`7The crowd of scholarly brats that tanned your hide is still breighing in the distance as you skulk away.");
        output("Still, you `idid`i rob them of their fun and some satisfaction can be taken in that, at least.`n`nHo well, another day.");
    }

    if ($op == "leave"){
        $session['user']['specialinc'] = "";
        output("You realize you have no time for such pointless frivolitous folly, you left your college days behind years ago!");
    }

    if ($op == "fight1"){
        $badguy = array( "creaturename"=>"`%a Mob of Intellectual Warriors`0"
                                ,"creaturelevel"=>2
                                ,"creatureweapon"=>"Logical Inquiries"
                                ,"creatureattack"=>3
                                ,"creaturedefense"=>4
                                ,"creaturehealth"=>2
                                ,"creaturegold"=>0
                                ,"diddamage"=>0);
        $userlevel=$session['user']['level'];
        $$userattack=e_rand(2,$session['user']['atack'])+8;
        $userhealth=e_rand(60,140)+$session['user']['level'];
        $userdefense=e_rand(2,$session['user']['defense'])+8;
        $badguy[creaturelevel]+=$userlevel;
        $badguy[creatureattack]+=$userattack;
        $badguy[creaturehealth]=$userhealth;
        $badguy[creaturedefense]+=$userdefense;
        $badguy[creaturegold]=0;
        $session[user][badguy]=createstring($badguy);
        $op="fight";
    }
    
    if ($op == "fight"){
        $battle=true;                               
    }

    if ($battle){
        include_once("battle.php");
        if ($victory){
            output("You have beaten `^The Mob of Intellectual Warriors`7. `&That'll teach `ithem`i the power of chaos theory, baby!");
            addnav("Continue","forest.php?op=win");
            $badguy=array();
            $session['user']['badguy']="";
        }elseif ($defeat){
            output("You crawl away, cowering from the snorting, breighing laughter of the robed students.");
            addnews("`%%s`5 was defeated by a mob of angered, pimply students after %s tried to rescue an acronymist from them!",$session['user']['name'], translate_inline(($session['user']['sex']?"she":"he")));
            $session['user']['hitpoints']=1;
            addnav("Continue","forest.php?op=lose");
        }else{
            require_once("lib/fightnav.php");
            fightnav(true,false);
        }
    }else{
    }
}

function antiacronym_run(){
}
?> 