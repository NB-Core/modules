<?php
// I have no idea how to make a module translation ready.  In fact, this is my first module, and I really don't know
// what I'm doing.  This module is largely based upon the existing racial modules.  So I can't take any credit for the
// code contained within.  I just assembled existing pieces with a concept I had.  The real credit for this mod goes to
// the entire community at Dragonprime.net who paved the way with all the other racial modules, and who will likely point
// out the mistakes I made and help correct them.
//
// Sichae and Dannic both get credit for some bug fixes!

function racegnome_getmoduleinfo(){
	$info = array(
		"name"=>"Race - Gnome (no city)",
		"version"=>"1.34",
		"author"=>"T. J. Brumfield - Enderandrew",
		"category"=>"Races",
		"description"=>"A Gnome race with their own city.  Gnomes are obsessed with gems.",		
		"download"=>"http://dragonprime.net/users/enderwiggin/racegnome.zip",
		"requires"=>array(
			"racedwarf" => "1.0|core_module",
		),
		"vertxtloc"=>"http://dragonprime.net/users/enderwiggin/",
		"settings"=>array(
			"Gnome Race Settings,title",
			"minedeathchance"=>"Chance for Gnomes to die in the mine,range,0,100,1|80",
			"mindk"=>"How many DKs do you need before the race is available?,int|0",
			"cost"=>"How many Donation points do you need before the race is available?,int|0",
			"gemchance"=>"Percent chance for Gnomes to find a gem on battle victory,range,0,100,1|5",
			"gemmessage"=>"Message to display when finding a gem|`&Your Gnome nose and cheeks turn a ruddy red as you gleefully discover a `%gem`&!",
		),
	);
	return $info;
}

function racegnome_install(){
	if (!is_module_installed("racedwarf")) {
		output("The Gnome only choose to live with Dwarves.   You must install that race module.");
		return false;
	}
	module_addhook("battle-victory");
	module_addhook("charstats");
	module_addhook("chooserace");
	module_addhook("newday");
	module_addhook("pointsdesc");;
	module_addhook("pvpadjust");
	module_addhook("raceminedeath");
	module_addhook("setrace");
	$sql = "UPDATE  " . db_prefix("accounts") . " SET race='Gnome' WHERE race='gnome'";
	db_query($sql);	
	return true;
}

function racegnome_uninstall(){
	global $session;
	$vname = getsetting("villagename", LOCATION_FIELDS);
	$gname = get_module_setting("villagename");
	$sql = "UPDATE " . db_prefix("accounts") . " SET location='$vname' WHERE location = '$gname'";
	db_query($sql);
	if ($session['user']['location'] == $gname)
		$session['user']['location'] = $vname;
	$sql = "UPDATE  " . db_prefix("accounts") . " SET race='" . RACE_UNKNOWN . "' WHERE race='Gnome'";
	db_query($sql);
	if ($session['user']['race'] == 'Gnome')
		$session['user']['race'] = RACE_UNKNOWN;
	return true;
}

function racegnome_dohook($hookname,$args){
	//yeah, the $resline thing is a hack.  Sorry, not sure of a better way
	// to handle this.
	// Pass it in via args?
	global $session,$badguy,$resline;
	if (is_module_active("racedwarf")) {
		$city = get_module_setting("villagename", "racedwarf");
	} else {
		$city = getsetting("villagename", LOCATION_FIELDS);
	}
	$race = "Gnome";
	$cost = get_module_setting("cost");
	$gnome = (int)($session['user']['level']*$session['user']['gems']/2);
	switch($hookname){

	case "battle-victory":
		if ($session['user']['race'] != $race) break;
		if ($args['type'] != "forest") break;
		if ($session['user']['level'] < 15 &&
				e_rand(1,100) <= get_module_setting("gemchance")) {
			output(get_module_setting("gemmessage")."`n`0");
			$session['user']['gems']++;
			debuglog("found a gem when slaying a monster, for being a Gnome.");
		}
		break;

	case "charstats":
		if ($session['user']['race']==$race){
			addcharstat("Vital Info");
			addcharstat("Race", $race);
		}
		break;

	case "chooserace":
		$pointsavailable = $session['user']['donation'] - $session['user']['donationspent'];
		if ($session['user']['dragonkills'] < get_module_setting("mindk") || get_module_setting("cost") > $pointsavailable)
			break;
		output("<a href='newday.php?setrace=$race$resline'>`5The mountainous lands around %s,</a>`5 both the `%Gnomes`5 and Dwarves make their home.  Here, adventure and excitement are just a means to increase your precious gem collection!`n`n",$city,true);
		addnav("`@Gnome`0","newday.php?setrace=$race$resline");
		addnav("","newday.php?setrace=$race$resline");
		break;

	case "newday":
		if ($session['user']['race']=="Gnome"){
			racegnome_checkcity();
			$session['user']['hitpoints']+=$gnome;
			output("`nYour gems shine briefly and fuse your Gnome body with vitality.  You gain %s hit points!`n", $gnome);
			apply_buff("racialbenefit",array(
				"name"=>"`#Crystal Obsession`0",
				"atkmod"=>0.9,
				"badguydmgmod"=>1.05,
				"allowinpvp"=>1,
				"allowintrain"=>1,
				"rounds"=>-1,
				"schema"=>"module-racegnome",
				)
			);
			if ($session['user']['marriedto']==1) {
				output("`n`@Thanks to your significant other, you are considerably less unkempt, and better grounded.`n");
				$session['user']['charm']++;
			}
		}
		break;

	case "pointsdesc":
		if (get_module_setting("mindk")>0 || $cost>0)
		{
			$args['count']++;
			$format = $args['format'];
			$str = translate("The Gnome race is availiable upon reaching %s Dragon Kills and %s Donation points.");
			$str = sprintf($str, get_module_setting("mindk"),
					get_module_setting("cost"));
			output($format, $str, true);
		}
		break;

	case "pvpadjust":
		if ($args['race'] == $race) {
			$badguy['stats']['attack']*=(0.9);
		}
		break;

	case "raceminedeath":
      	if ($session['user']['race'] == $race) {
            	$args['chance'] = get_module_setting("minedeathchance");
		$args['racesave'] = "It was dumb luck and your oblivious nature as a Gnome that allowed you to stumble out unscathed.`n";
		$args['schema']="module-racegnome";
      	}
	      break;

	case "setrace":
		if ($session['user']['race']==$race){
			output("`5As a `%Gnome`5, you are magically attuned to gems and crystals. ");
			output("`n`5Your preternatural senses draw you to find more gems, and as your collection of gems grows, so will your vitality!`n");
			output("You find more gems and get bonus hitpoints each day based upon your gems!`n");
			output("However, your obsession with all things metaphysical has distracted you from martial training.  ");
			output("As such, you're not quite as adept in attacking.`n");
			if (is_module_active("cities")) {
				if ($session['user']['dragonkills']==0 &&
						$session['user']['age']==0){
					//new farmthing, set them to wandering around this city.
					set_module_setting("newest-$city",
							$session['user']['acctid'],"cities");
				}
				set_module_pref("homecity",$city,"cities");
				$session['user']['location']=$city;
			}
		}
		break;

	}
	return $args;
}

function racegnome_checkcity(){
    global $session;
    $race="Gnome";
    if (is_module_active("racedwarf")) {
		$city = get_module_setting("villagename", "racedwarf");
	} else {
		$city = getsetting("villagename", LOCATION_FIELDS);
	}
	
	if ($session['user']['race']==$race && is_module_active("cities")){
		//if they're this race and their home city isn't right, set it up.
		if (get_module_pref("homecity","cities")!=$city){ //home city is wrong
			set_module_pref("homecity",$city,"cities");
		}
	}
    return true;
}

function racegnome_run(){

}
?>
