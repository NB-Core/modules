<?php
// I have no idea how to make a module translation ready.  In fact, this is my first module, and I really don't know
// what I'm doing.  This module is largely based upon the existing racial modules.  So I can't take any credit for the
// code contained within.  I just assembled existing pieces with a concept I had.  The real credit for this mod goes to
// the entire community at Dragonprime.net who paved the way with all the other racial modules, and who will likely point
// out the mistakes I made and help correct them.
//
// Sichae and Dannic both get credit for some bug fixes!

function racegnome_getmoduleinfo(){
	$info = array(
		"name"=>"Race - Gnome (city)",
		"version"=>"1.34",
		"author"=>"T. J. Brumfield - Enderandrew",
		"category"=>"Races",
		"description"=>"A Gnome race with their own city.  Gnomes are obsessed with gems.",
		"download"=>"http://dragonprime.net/users/enderwiggin/racegnome.zip",
		"vertxtloc"=>"http://dragonprime.net/users/enderwiggin/",
		"settings"=>array(
			"Gnome Race Settings,title",
			"villagename"=>"Name for the Gnome village|Elysombra",
			"minedeathchance"=>"Chance for Gnomes to die in the mine,range,0,100,1|80",
			"mindk"=>"How many DKs do you need before the race is available?,int|0",
			"cost"=>"How many Donation points do you need before the race is available?,int|0",
			"gemchance"=>"Percent chance for Gnomes to find a gem on battle victory,range,0,100,1|5",
			"gemmessage"=>"Message to display when finding a gem|`&Your Gnome nose and cheeks turn a ruddy red as you gleefully discover a `%gem`&!",
		),
	);
	return $info;
}

function racegnome_install(){
	module_addhook("battle-victory");
	module_addhook("changesetting");
	module_addhook("charstats");
	module_addhook("chooserace");
	module_addhook("moderate");
	module_addhook("newday");
	module_addhook("pointsdesc");
	module_addhook("pvpadjust");
	module_addhook("raceminedeath");
	module_addhook("setrace");
	module_addhook("travel");
	module_addhook("validlocation");
	module_addhook("villagetext");

	// Update from commentary sections using village-$city to village-$race;
	// This is pretty much a one-time thing
	$sql = "UPDATE  " . db_prefix("accounts") . " SET race='Gnome' WHERE race='gnome'";
	db_query($sql);
	$sql = "UPDATE " . db_prefix("commentary") . " SET section='village-Gnome' WHERE section='village-Elysombra'";
	db_query($sql);
	return true;
}

function racegnome_uninstall(){
	global $session;
	$vname = getsetting("villagename", LOCATION_FIELDS);
	$gname = get_module_setting("villagename");
	$sql = "UPDATE " . db_prefix("accounts") . " SET location='$vname' WHERE location = '$gname'";
	db_query($sql);
	if ($session['user']['location'] == $gname)
		$session['user']['location'] = $vname;
	$sql = "UPDATE  " . db_prefix("accounts") . " SET race='" . RACE_UNKNOWN . "' WHERE race='Gnome'";
	db_query($sql);
	if ($session['user']['race'] == 'Gnome')
		$session['user']['race'] = RACE_UNKNOWN;
	return true;
}

function racegnome_dohook($hookname,$args){
	//yeah, the $resline thing is a hack.  Sorry, not sure of a better way
	// to handle this.
	// Pass it in via args?
	global $session,$badguy,$resline;
	$cost = get_module_setting("cost");
	$city = get_module_setting("villagename");
	$race = "Gnome";
	$races = "Gnomes";
	$gnome = (int)($session['user']['level']*$session['user']['gems']/2);
	switch($hookname){

	case "battle-victory":
		if ($session['user']['race'] != $race) break;
		if ($args['type'] != "forest") break;
		if ($session['user']['level'] < 15 &&
				e_rand(1,100) <= get_module_setting("gemchance")) {
			output(get_module_setting("gemmessage")."`n`0");
			$session['user']['gems']++;
			debuglog("found a gem when slaying a monster, for being a Gnome.");
		}
		break;

	case "changesetting":
		// Ignore anything other than villagename setting changes
		if ($args['setting'] == "villagename" && $args['module']=="racegnome") {
			if ($session['user']['location'] == $args['old'])
				$session['user']['location'] = $args['new'];
			$sql = "UPDATE " . db_prefix("accounts") .
				" SET location='" . $args['new'] .
				"' WHERE location='" . $args['old'] . "'";
			db_query($sql);
			if (is_module_active("cities")) {
				$sql = "UPDATE " . db_prefix("module_userprefs") .
					" SET value='" . $args['new'] .
					"' WHERE modulename='cities' AND setting='homecity'" .
					"AND value='" . $args['old'] . "'";
				db_query($sql);
			}
		}
		break;

	case "charstats":
		if ($session['user']['race']==$race){
			addcharstat("Vital Info");
			addcharstat("Race", $race);
		}
		break;

	case "chooserace":
		$pointsavailable = $session['user']['donation'] - $session['user']['donationspent'];
		if ($session['user']['dragonkills'] < get_module_setting("mindk") || get_module_setting("cost") > $pointsavailable)
			break;
		output("<a href='newday.php?setrace=$race$resline'>`5The bustle of %s</a>`5 is lost to you as a `%Gnome`5.  Adventure and excitement are just a means to increase your precious gem collection!`n`n",$city,true);
		addnav("`%Gnome`0","newday.php?setrace=$race$resline");
		addnav("","newday.php?setrace=$race$resline");
		break;

        case "moderate":
            if (is_module_active("cities")) {
               tlschema("commentary");
               $args["village-$race"]=sprintf_translate("City of %s", $city);
               tlschema();
               }
               break;

	case "newday":
		if ($session['user']['race']==$race){
			racegnome_checkcity();
			$session['user']['hitpoints']+=$gnome;
			output("`nYour gems shine briefly and fuse your %s body with vitality.  You gain %s hit points!`n", $race, $gnome);
			apply_buff("racialbenefit",array(
				"name"=>"`%Crystal Obsession`0",
				"atkmod"=>0.9,
				"badguydmgmod"=>1.05,
				"allowinpvp"=>1,
				"allowintrain"=>1,
				"rounds"=>-1,
				"schema"=>"module-racegnome",
				)
			);
			if ($session['user']['marriedto']==1) {
				output("`n`%Thanks to your significant other, you are considerably less unkempt, and better grounded.`n");
				$session['user']['charm']++;
			}
		}
		break;

	case "pointsdesc":
		if (get_module_setting("mindk")>0 || $cost>0)
		{
			$args['count']++;
			$format = $args['format'];
			$str = translate("The %s race is availiable upon reaching %s Dragon Kills and %s Donation points.");
			$str = sprintf($str, $race, get_module_setting("mindk"),
					get_module_setting("cost"));
			output($format, $str, true);
		}
		break;

	case "pvpadjust":
		if ($args['race'] == $race) {
			$badguy['stats']['attack']*=(0.9);
		}
		break;

	case "raceminedeath":
      	if ($session['user']['race'] == $race) {
            	$args['chance'] = get_module_setting("minedeathchance");
		$args['racesave'] = ("It was dumb luck and your oblivious nature as a $race that allowed you to stumble out unscathed.`n");
		$args['schema']="module-racegnome";
      	}
	      break;

	case "setrace":
		if ($session['user']['race']==$race){
			output("`5As a `%Gnome`5, you are magically attuned to gems and crystals. ");
			output("`n`5Your preternatural senses draw you to find more gems, and as your collection of gems grows, so will your vitality!`n");
			output("You find more gems and get bonus hitpoints each day based upon your gems!`n");
			output("However, your obsession with all things metaphysical has distracted you from martial training.  ");
			output("As such, you're not quite as adept in attacking.`n");
			if (is_module_active("cities")) {
				if ($session['user']['dragonkills']==0 &&
						$session['user']['age']==0){
					//new farmthing, set them to wandering around this city.
					set_module_setting("newest-$city",
							$session['user']['acctid'],"cities");
				}
				set_module_pref("homecity",$city,"cities");
				$session['user']['location']=$city;
			}
		}
		break;

	case "travel":
		$capital = getsetting("villagename", LOCATION_FIELDS);
		$hotkey = substr($city, 0, 1);
		tlschema("module-cities");
		if ($session['user']['location']==$capital){
			addnav("Safer Travel");
			addnav(array("%s?Go to %s", $hotkey, $city),"runmodule.php?module=cities&op=travel&city=$city");
		}
		elseif ($session['user']['location']!=$city){
			addnav("More Dangerous Travel");
			addnav(array("%s?Go to %s", $hotkey, $city),"runmodule.php?module=cities&op=travel&city=$city&d=1");
		}
		if ($session['user']['superuser'] & SU_EDIT_USERS){
			addnav("Superuser");
			addnav(array("%s?Go to %s", $hotkey, $city),"runmodule.php?module=cities&op=travel&city=$city&su=1");
		}
		tlschema();
		break;
	
	case "validlocation":
		if (is_module_active("cities"))
			$args[$city] = "village-$race";
		break;

	case "villagetext":
		racegnome_checkcity();
		if ($session['user']['location'] == $city){
			$args['text']=("`5`b`c$city, Home to the Gnomes.`c`b`n`2The air has as crystaline quality about it and busy little Gnomes scuttle about before you with little concern as to the world around them.  Candles, crystals, and fairies dance in the sky in vibrant fashion.  The townsfolk seem only interested in their own crystal/gem adornments.  Whether or not their oblivious nature to the mundane world is a blessing, or a hinderance, remains to be seen.`n");
			$args['schemas']['text'] = "module-racegnome";
			$args['clock']="`n`5Capturing one of the tiny lights, you peer delicately into your hands.`nThe fairy within tells you that it is `^%s`5 before disappearing in a tiny sparkle.`n";
			$args['schemas']['clock'] = "module-racegnome";
			if (is_module_active("calendar")) {
				$args['calendar']="`n`5Another fairy whispers in your ear, \"`%Today is `&%3\$s %2\$s`%, `&%4\$s`%.  It is `&%1\$s`%.`5\"`n";
				$args['schemas']['calendar'] = "modules-racegnome";
			}
			$args['title']= array("%s City", $city);
			$args['schemas']['title'] = "module-racegnome";
			$args['sayline']="mutters";
			$args['schemas']['sayline'] = "module-racegnome";
			$args['talk']="`n`^Nearby some townsfolk mutter:`n";
			$args['schemas']['talk'] = "module-racegnome";
			$new = get_module_setting("newest-$city", "cities");
			if ($new != 0) {
				$sql =  "SELECT name FROM " . db_prefix("accounts") .
					" WHERE acctid='$new'";
				$result = db_query_cached($sql, "newest-$city");
				$row = db_fetch_assoc($result);
				$args['newestplayer'] = $row['name'];
				$args['newestid']=$new;
			} else {
				$args['newestplayer'] = $new;
				$args['newestid']="";
			}
			if ($new == $session['user']['acctid']) {
				$args['newest']="`n`5You wander the village, trying not to stick out like a sore thumb.  You can't help but stare none the less at the unique crystaline architecture, and the brilliant glare of reflecting lights the city offers up to new visitors.  If it's any consolation, the native Gnomes are all too distracted to notice how much you stick out.";
			} else {
				$args['newest']="`n`5Looking at all the crystaline buildings, you can't be helped but be distracted by `%%s`5.";
			}
			$args['schemas']['newest'] = "module-racegnome";
			$args['gatenav']="Gem-Encrusted Gates";
			$args['schemas']['gatenav'] = "module-racegnome";
			$args['fightnav']="The Academy";
			$args['schemas']['fightnav'] = "module-racegnome";
			$args['marketnav']="Goods and Services";
			$args['schemas']['marketnav'] = "module-racegnome";
			$args['tavernnav']="Crystaline Cafe";
			$args['schemas']['tavernnav'] = "module-racegnome";
			$args['section']="village-$race";
		}
		break;

	}
	return $args;
}

function racegnome_checkcity(){
	global $session;
	$race="Gnome";
	$city=get_module_setting("villagename");
	
	if ($session['user']['race']==$race && is_module_active("cities")){
		//if they're this race and their home city isn't right, set it up.
		if (get_module_pref("homecity","cities")!=$city){ //home city is wrong
			set_module_pref("homecity",$city,"cities");
		}
	}	
	return true;
}

function racegnome_run(){

}
?>
