-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
Race - Gnome - A module for Legend of the Green Dragon 1.0.3

Legend of the Green Dragon
by  Eric "MightyE" Stevens (http://www.mightye.org)
and JT "Kendaer" Traub (http://www.dragoncat.net)

Software Project Page:
http://sourceforge.net/projects/lotgd

Modification Community Page:
http://dragonprime.net

Author of this Module:
Enderandrew (enderandrew@gmail.com)

Enderandrew's LoGD game:
http://enderandrew.com/lotgd/

Download the latest version of this module from:
http://dragonprime.net/index.php?action=viewfiles&user=enderwiggin

----------------------------------------------
-- STATUS: -----------------------------------
----------------------------------------------
This module is STABLE.

----------------------------------------------
-- INFORMATION: ------------------------------
----------------------------------------------
There are two versions of this module, and I will likely release all race
modules like this.  The first gives the Gnomes their own city.  The second
version has the Gnomes sharing a city with the Dwarves, and thusly they need
to be installed and active for the second version to work.  The choice is
yours on which to use.  I was considering creating a setting in the module
to allow you to change whether or not there was a city.  However, this is
the easiest way to go.  If someone has a better method of handling the option
of city versus shared city, please drop me a line on the Dragonprime forums
or at enderandrew@gmail.com

This module was originally developed for prerelease 12.  However, with the
addition of the description field, this will only work with 1.0.3 and newer.
You can continue to run older versions of this module, but I recommend just
updating to the latest build of the game.

This is my very first module for LotGD, and my first ever PHP file to boot. So
there may be bugs or mistakes.

Thanks go to Sichae and Dannic for spotting bugs!

Hope you enjoy!

----------------------------------------------
-- INSTALLATION: -----------------------------
----------------------------------------------
Copy ONE of the racegnome.php files within this zip into your modules
directory.

Login to the Superuser Grotto and Install / Activate it.

-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-


