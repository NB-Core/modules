<?
output("You twiddle your thumbs for a while.`n`nYou are in your jail cell, there is nothing to do.");
require_once("lib/commentary.php");
addcommentary();
viewcommentary("jail", "Whine about being in jail", 20, "whines"); 
injailnav();
?>