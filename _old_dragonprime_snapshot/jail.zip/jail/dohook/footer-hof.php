<?
addnav("Wanted List");
addnav("Most Wanted", "runmodule.php?module=jail&op=hof");
?>