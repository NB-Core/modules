<?
if(get_module_pref('wantedlevel') > 1)
	output
	(
		" You tread lightly in the village, avoiding eye contact with anyone that may have seen your face 
		on a wanted poster. "
	);
?>