<?php
/**************
Name: The Forest Fool
Author: Eth - ethstavern(at)gmail(dot)com 
Version: 1.0
Release Date: 01-03-2006
About: Just a silly forest event that has a random player jump out
       and hit the player in the face with a random object. 
Translation compatible. No, seriously!
*****************/
function forestfool_getmoduleinfo(){
	$info = array(
		"name"=>"Forest Fool",
		"version"=>"1.0",
		"author"=>"Eth",
		"category"=>"Forest Specials",
		"download"=>"http://dragonprime.net/users/Eth/forestfool.zip",
		"settings"=>array(
            "Forest Fool - Settings,title",
			"creepchance"=>"Chance to appear?,range,0,100,1|25",
			"happenwhen"=>"Happen once per Day or Dragon Kill?,enum,0,New Day,1,Dragon Kill",
        ),
        "prefs"=>array(
            "Forest Fool - User Preferences,title",
			"beenspooked"=>"Has the user been scared already?,bool|0",
        )
	);
	return $info;
}

function forestfool_install(){
	module_addeventhook("forest", "require_once(\"modules/forestfool.php\"); return forestfool_test();");
	module_addhook("newday");
	module_addhook("dragonkill");	
	return true;
}

function forestfool_uninstall(){
	return true;
}
function forestfool_test(){
	global $session;	
	$chance = get_module_setting("creepchance","forestfool");
	if (get_module_pref("beenspooked","forestfool") == 1) return 0; 
	return $chance; 
}

function forestfool_dohook($hookname,$args){
	global $session;
	switch($hookname){		
		case "dragonkill":		
		if (get_module_setting("happenwhen") == 1){
			set_module_pref("beenspooked",0);
		}
		break;
		case "newday":
		if (get_module_setting("happenwhen") == 0){
			set_module_pref("beenspooked",0);
		}
		break;
	}
	return $args;
}

function forestfool_runevent($type,$link){
	global $session;
	$op = httpget('op');
	//$from = "runmodule.php?module=forestfool&";
	$session['user']['specialinc'] = "module:forestfool";
	switch ($type) {
		case forest:
			if ($op==""){
				$fists = translate_inline("Fists");
				output("`n`2While venturing through the forest, minding your own business, your eyes are suddenly drawn to movement in the bushes up ahead.");
				if ($session['user']['weapon'] == $fists){
					output(" `2Clenching your fists, you brace yourself for the prospect of trouble.`n`n");
				}else{
					output(" `2Taking hold of your %s, you brace yourself for any possible trouble.`n`n", $session['user']['weapon']);
				}
				//let's pick another player at random
				$sql = "SELECT acctid, name, sex FROM ".db_prefix("accounts")." WHERE acctid <> ".$session['user']['acctid']." AND locked=0 AND alive=1 ORDER BY rand(".e_rand().") LIMIT 1";
				$result = db_query($sql);
				$count = db_num_rows($result); 	
				$row = db_fetch_assoc($result);
				$who = $row['name'];
				$sex = translate_inline($row['sex']?"she":"he");
				$what = translate_inline(array(1=>"cream pie",2=>"tomato",3=>"wet trout",4=>"baby diaper",5=>"smelly sock"));
				$object = $what[e_rand(1,5)];		
				//just in case it couldn't find anyone, enter the young fop
				if ($count == 0){
					output("`2Suddenly, a leering young fop leaps from the bushes, smacks you in the face with a `^%s`2, and runs off giggling like a fool.", $object); 
					output(" `2Wiping the mess from your face, you conclude he needs some professional help.`n`n");
				//otherwise, a random player will play the part of the fool	
				}else{
					output("`2Suddenly, `3%s `2leaps from the bushes, hits you in the face with a `^%s`2, and runs off giggling like a fool.", $who,$object);
					output(" `2Wiping the mess from your face, you conclude %s needs some professional help.`n`n", $sex);
					addnews("`3%s `2was smacked in the face with a `3%s `2by `6%s `2in the forest today!",$session['user']['name'],$object,$who);
					if (e_rand(1,5)==1){
						output("`3Glancing down, you happen to spot a gem that silly fool dropped in all the excitement!`n`n");
						$session['user']['gems']++;
					}
				}
				set_module_pref("beenspooked",1);					
				$session['user']['specialinc'] = "";
				addnav("Return to Forest","forest.php");
			}
		break;									
	}		
}
function forestfool_run(){}
?>