****************************************************************
Name: The Forest Fool
Author: Eth - ethstavern(at)gmail(dot)com 
Version: 1.0
Release Date: 12-28-2005
About: Readme file for forestfool.zip
Files: forestfool.php
***************************************************************

To install, drop into your modules directory and activate 
via the Modules Manager. 