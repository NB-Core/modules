#########################
Name: Fundraiser Status
Author: Salem - christer(dot)edwards(at)gmail(dot)com
Version: 1.0
Release Date: 04.25.05
Files: donation.php, readme.txt

This has been tested on v1.0.2 only!
#########################

This is just a simple module that lets you set two values in a fundraiser
1) amount needed
2) amount received

These values need to be manually placed as I have no idea how to automatically retrive paypal reciept values lol.
The status appears in the Personal Info bar (for now) and mimmicks the exp/health bars for progress.

Found in the Admin modules section.