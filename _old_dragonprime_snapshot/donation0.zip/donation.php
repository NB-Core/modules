<?php

function donation_getmoduleinfo(){
	$info = array(
		"name"=>"Fundraiser Status",
		"version"=>"1.0",
		"author"=>"Salem",
		"category"=>"Administrative",
		"download"=>"http://www.christeredwards.com/php/donation.zip",
		"settings"=>array(
			"needed"=>"Amount Needed,int|100",
			"have"=>"Amount Recieved,int|0",
		)		
	);
	return $info;
}

function donation_install(){
	module_addhook("charstats");
	return true;
}

function donation_uninstall(){
	return true;
}

function donation_dohook($hookname,$args){
	switch($hookname){
	case "charstats":	

//	$needed = 100;
//	$have = 10;

	$needed = get_module_setting("needed");
	$have = get_module_setting("have");
	$color = "blue";

	$nonpercent = ($needed-$have);
	$percent = 100-$nonpercent;
		if ($have > 100) {
			$pct = 100;
			}
		if ($have < 0) {
			$pct = 0;
			}

// Display results in percentage bar
	$display .= "<table style='border: solid 1px #000000;' bgcolor='white' cellpadding='0' cellspacing='0' width='70' height='5'>
	<tr><td width='$percent' bgcolor='$color'></td><td width='$nonpercent'></td></tr></table>";
	setcharstat("Personal Info", "Fundraiser", $display);
	break;
	}
	return $args;
}

function donation_run(){
}
?>