<?php
	module_addhook("changesetting");
	module_addhook("village");
	module_addhook("newday");
	module_addhook("newday-runonce");
?>