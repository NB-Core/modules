<?php
$tc	= get_module_setting('turquoisecost') * $ul;
$mac	= get_module_setting('malachitecost') * $ul;
$moc	= get_module_setting('moonstonecost') * $ul;
$hc	= get_module_setting('hematitecost') * $ul;
$sc	= get_module_setting('starsapphirecost') * $ul;
$dc	= get_module_setting('diamondcost') * $ul;
?>