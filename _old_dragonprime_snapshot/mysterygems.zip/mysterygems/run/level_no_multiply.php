<?php
$tc	= get_module_setting('turquoisecost');
$mac	= get_module_setting('malachitecost');
$moc	= get_module_setting('moonstonecost');
$hc	= get_module_setting('hematitecost');
$sc	= get_module_setting('starsapphirecost');
$dc	= get_module_setting('diamondcost');
?>