<?php
function modules_getmoduleinfo(){
	$info = array(
		"name"=>"Show Modules link on Home page",
		"author"=>"`%Kickme",
		"version"=>"1.0.1",
		"vertxtloc"=>"http://dragonprime.net/users/kickme/",
		"category"=>"General",
		"download"=>"http://dragonprime.net/users/kickme/modules.txt",
		);
	return $info;
}
function modules_install(){
	module_addhook("index");
	return true;
}
function modules_uninstall(){
	return true;
}
function modules_dohook($hookname,$args){
	switch($hookname){
	case "index":
		addnav("Other Info");
		addnav("Module Info","about.php?op=listmodules");
		break;
	}
	return $args;
}
?>