<?php
// translator ready
// addnews ready
// mail ready

function rainyweather_getmoduleinfo(){
		$info = array(
		"name"=>"Rainy Weather Addon",
		"author"=>"`7S`&ephiroth",
		"category"=>"General",
		"download"=>"",
		"version"=>"1.0",
	);
	return $info;
}

function rainyweather_install(){
	if (!is_module_active('rainyweather')){
		output("`c`b`QInstalling Rainy Weather Module.`b`n`c");
	}else{
		output("`c`b`QUpdating Rainy Weather Module.`b`n`c");
	}
	module_addhook("village");
	return true;
}

function rainyweather_uninstall(){
	output("`n`c`b`QRainy Weather Module Uninstalled`0`b`c");
	return true;
}

function rainyweather_dohook($hookname, $args){
	global $session;
	case "village":
rawoutput("<SCRIPT LANGUAGE=\"JavaScript\">",true);
rawoutput("<!-- Begin",true);
rawoutput("var no = 50;",true);
rawoutput("var speed = 1;",true);
rawoutput("var ns4up = (document.layers) ? 1 : 0;",true);
rawoutput("var ie4up = (document.all) ? 1 : 0;",true);
rawoutput("var s, x, y, sn, cs;",true);
rawoutput("var a, r, cx, cy;",true);
rawoutput("var i, doc_width = 800, doc_height = 600;",true);
rawoutput("if (ns4up) {",true);
rawoutput("doc_width = self.innerWidth;",true);
rawoutput("doc_height = self.innerHeight;",true);
rawoutput("}",true);
rawoutput("else",true);
rawoutput("if (ie4up) {",true);
rawoutput("doc_width = document.body.clientWidth;",true);
rawoutput("doc_height = document.body.clientHeight;",true);
rawoutput("}",true);
rawoutput("x = new Array();",true);
rawoutput("y = new Array();",true);
rawoutput("r = new Array();",true);
rawoutput("cx = new Array();",true);
rawoutput("cy = new Array();",true);
rawoutput("s = 8;",true);
rawoutput("for (i = 0; i < no; ++ i) {",true);
rawoutput("initRain();",true);
rawoutput("if (ns4up) {",true);
rawoutput("if (i == 0) {",true);
rawoutput("document.write(\"<layer name=\"dot\"+ i +\"\" left=\"1\" \");",true);
rawoutput("document.write(\"top=\"1\" visibility=\"show\"><font color=\"blue\">\");",true);
rawoutput("document.write(\",</font></layer>\");",true);
rawoutput("}",true);
rawoutput("else {",true);
rawoutput("document.write(\"<layer name=\"dot\"+ i +\"\" left=\"1\" \");",true);
rawoutput("document.write(\"top=\"1\" visibility=\"show\"><font color=\"blue\">\");",true);
rawoutput("document.write(\",</font></layer>\");",true);
rawoutput("   }",true);
rawoutput("}",true);
rawoutput("else ",true);
rawoutput("if (ie4up) {",true);
rawoutput("if (i == 0) {",true);
rawoutput("document.write(\"<div id=\"dot\"+ i +\"\" style=\"POSITION: \");",true);
rawoutput("document.write(\"absolute; Z-INDEX: \"+ i +\"; VISIBILITY: \");",true);
rawoutput("document.write(\"visible; TOP: 15px; LEFT: 15px;\"><font color=\"blue\">\");",true);
rawoutput("document.write(\",</font></div>\");",true);
rawoutput("}",true);
rawoutput("else {",true);
rawoutput("document.write(\"<div id=\"dot\"+ i +\"\" style=\"POSITION: \");",true);
rawoutput("document.write(\"absolute; Z-INDEX: \"+ i +\"; VISIBILITY: \");",true);
rawoutput("document.write(\"visible; TOP: 15px; LEFT: 15px;\"><font color=\"blue\">\");",true);
rawoutput("document.write(\",</font></div>\");",true);
rawoutput("      }",true);
rawoutput("   }",true);
rawoutput("}",true);
rawoutput("function initRain() {",true);
rawoutput("a = 6;",true);
rawoutput("r[i] = 1;",true);
rawoutput("sn = Math.sin(a);",true);
rawoutput("cs = Math.cos(a);",true);
rawoutput("cx[i] = Math.random() * doc_width + 1;",true);
rawoutput("cy[i] = Math.random() * doc_height + 1;",true);
rawoutput("x[i] = r[i] * sn + cx[i];",true);
rawoutput("y[i] = cy[i];",true);
rawoutput("}",true);
rawoutput("function makeRain() {",true);
rawoutput("r[i] = 1;",true);
rawoutput("cx[i] = Math.random() * doc_width + 1;",true);
rawoutput("cy[i] = 1;",true);
rawoutput("x[i] = r[i] * sn + cx[i];",true);
rawoutput("y[i] = r[i] * cs + cy[i];",true);
rawoutput("}",true);
rawoutput("function updateRain() {",true);
rawoutput("r[i] += s;",true);
rawoutput("x[i] = r[i] * sn + cx[i];",true);
rawoutput("y[i] = r[i] * cs + cy[i];",true);
rawoutput("}",true);
rawoutput("function raindropNS() {",true);
rawoutput("for (i = 0; i < no; ++ i) {",true);
rawoutput("updateRain();",true);
rawoutput("if ((x[i] <= 1) || (x[i] >= (doc_width - 20)) || (y[i] >= (doc_height - 20))) {",true);
rawoutput("makeRain();",true);
rawoutput("doc_width = self.innerWidth;",true);
rawoutput("doc_height = self.innerHeight;",true);
rawoutput("}",true);
rawoutput("document.layers[\"dot\"+i].top = y[i];",true);
rawoutput("document.layers[\"dot\"+i].left = x[i];",true);
rawoutput("}",true);
rawoutput("setTimeout(\"raindropNS()\", speed);",true);
rawoutput("}",true);
rawoutput("function raindropIE() {",true);
rawoutput("for (i = 0; i < no; ++ i) {",true);
rawoutput("updateRain();",true);
rawoutput("if ((x[i] <= 1) || (x[i] >= (doc_width - 20)) || (y[i] >= (doc_height - 20))) {",true);
rawoutput("makeRain();",true);
rawoutput("doc_width = document.body.clientWidth;",true);
rawoutput("doc_height = document.body.clientHeight;",true);
rawoutput("}",true);
rawoutput("document.all[\"dot\"+i].style.pixelTop = y[i];",true);
rawoutput("document.all[\"dot\"+i].style.pixelLeft = x[i];",true);
rawoutput("}",true);
rawoutput("setTimeout(\"raindropIE()\", speed);",true);
rawoutput("}",true);
rawoutput("if (ns4up) {",true);
rawoutput("raindropNS();",true);
rawoutput("}",true);
rawoutput("else",true);
rawoutput("if (ie4up) {",true);
rawoutput("raindropIE();",true);
rawoutput("}",true);
rawoutput("//  End -->",true);
rawoutput("</script>",true);
	
	break;

}

function rainyweather_run(){


}
?>