<?php
function newday_sql_getmoduleinfo(){
	$info = array(
		"name"=>"Newday Sql",
		"description"=>"Allows admins to run SQL and PHP querys on newdays",
		"author"=>"`%kickme`0",
		"vertxtloc"=>"http://simon.geek.nz/",
		"category"=>"Administrative",
		"version"=>"1.1.0",
		"settings"=>array(
			"Newday Sql - Run once,title",
			"This query gets exucted once per game day,note",
			"sql1"=>"Query to run:,textarea",
			"disablesql1"=>"Run sql?,bool|1",
			"Newday Sql,title",
			"This query gets exucted on `bevery`b newday,note",
			"sql2"=>"Query to run:,textarea",
			"disablesql2"=>"Run sql?,bool|1",
			"Newday php - Run once,title",
			"This query gets exucted once per game day,note",
			"php1"=>"Query to run:,textarea",
			"disablephp1"=>"Run php?,bool|1",
			"Newday php,title",
			"This query gets exucted on `bevery`b newday,note",
			"php2"=>"Query to run:,textarea",
			"disablephp2"=>"Run php?,bool|1",
		)
	);
	return $info;
}
function newday_sql_install(){
	module_addhook("newday-runonce");
	module_addhook("newday");
	return true;
}
function newday_sql_uninstall(){
	return true;
}
function newday_sql_dohook($loc,$args){
	switch($loc){
		case "newday":
			if(get_module_setting("disablesql2") == 1){
				$sql = get_module_setting("sql2");
				if($sql) db_query($sql);
			}
			if(get_module_setting("disablephp2") == 1){
				$sql = stripslashes(get_module_setting("php2"));
				if ($sql<="") break;
				eval($sql);
				output(ob_get_contents(),true);
				ob_end_clean();
			}
		break;
		case "newday-runonce":
			if(get_module_setting("disablesql1") == 1){
				$sql = get_module_setting("sql1");
				if($sql) db_query($sql);
			}
			if(get_module_setting("disablephp1") == 1){
				$sql = stripslashes(get_module_setting("php1"));
				if ($sql<="") break;
				ob_start();
				eval($sql);
				output(ob_get_contents(),true);
				ob_end_clean();
			}
		break;
		
	}
	return $args;
}
?>