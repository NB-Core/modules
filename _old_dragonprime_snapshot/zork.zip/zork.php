<?php
/*
Module Name:  Zork
Category:  Forest Specials
Worktitle:  zork
Author:  Deadmouse with help from DaveS

Description:
This mod is a forest special with several options.

A random event pulls the player into a dangerous situation that only quick thinking will get them out of alive.

Here are the four rewards for finishing the event:
1.  Gain 500 gold + news
2.  Gain 100 favor with Ramius + news
3.  Gain 25-50/level + 10/DK EXP + news
4.  Gain 5 Forest Fights + news

The user also may have to fight A Grue, depending on choices made durring the event.  Killing it results in 1 gold, and  exp + news, dying results in Lose 10% exp, and lose all gold.  + news
*/

function zork_getmoduleinfo(){
    $info = array(
        "name"=>"Zork",
        "version"=>"1.01",
        "author"=>"`\$Dead`7mouse`2 with help from DaveS",
        "description"=>"Get out alive!",
        "category"=>"Forest Specials",
        "download"=>"http://dragonprime.net/users/deadmouse/zork.zip",
        "settings"=>array(
            "Zork - Settings,title",
            "The reward is one of the 4 following results,note",
            "mingold"=>"1 Min gold received for rescue:,int|25",
            "maxgold"=>"1 Max gold a received for rescue:,int|1000",
            "ffgain"=>"2 Number of forest fights received for rescue:,int|4",
            "dmexp"=>"3 XP gained per level for rescue:,int|50",
            "dmdkbonus"=>"3 XP bonus for each dragonkill for rescue:,int|4",
            "dmdeath"=>"4 Favor received for rescue:,int|100",
            "Creature settings,title",
            "creaturelevel"=>"User level plus this number for creature level,int|1",
            "creatureattack"=>"Multiplier of player's attack for Grue Attack,int|1.4",
            "creaturedefense"=>"Multiplier of player's defense for Grue Defense, int|0.9",
            "creaturehealth"=>"Multiplier of player's maxHP for Grue HP,int|1",
            "exploss"=>"XP loss per level on defeat,int|100",
            "expgain"=>"XP gained per level for killing Grue,int|50",
            "expbonus"=>"XP bonus for each dragonkill for killing Grue,int|4",
            ), 
        "prefs"=>array(
            "Zork - Preferences,title",
            "zorkperf"=>"Participated in Zork this newday?,bool|0",
            "searchtimes"=>"How many times have they searched?,int|0",
            "wrong1"=>"Did they pick the first wrong place?,bool|0",
            "wrong2"=>"Did they pick the second wrong place ?,bool|0",
            "wrong3"=>"Did they pick the third wrong place?,bool|0",
            ),
    );
    return $info;
}

function zork_chance() {
    global $session;
    if (get_module_pref('zorkperf','zork',$session['user']['acctid'])==1) return 0;
    return 100;
}

function zork_install(){
    module_addeventhook("forest","require_once(\"modules/zork.php\"); 
    return zork_chance();");
    module_addhook("newday");
    return true;
}

function zork_uninstall(){
    return true;
}

function zork_dohook($hookname,$args){
    global $session;
    switch ($hookname) {
        case "newday":
            set_module_pref("zorkperf",0);
            set_module_pref("searchtimes",0);
            set_module_pref("wrong1",0);
            set_module_pref("wrong2",0);
            set_module_pref("wrong3",0);
        break;
    }
    return $args;
}

function zork_runevent($type) {
    global $session;
    $session['user']['specialinc']="module:zork";
    $op = httpget('op');

if ($op==""){
   set_module_pref("zorkperf",1);
   output("`2`n`nAs you are making your way through the forest, daydreaming about slaying the `b`@Green Dragon`2`b, you suddenly realize you've wandered wayyyy off the trail... `n`nYou notice it is getting `)dark `2and `)cloudy `2very rapidly. Glancing around in a panic, you begin to look for anything that might provide you with a wee bit o' `^light`2.`n`n  If you stay in the dark too long, you are likely to be eaten by a `\$`bGrue`b`2. `n`n");
   output("`7You are in an open field west of a big white house with a boarded front door.`n`n");
   output("`7There is a small mailbox here. `n`n");
   output(">_");
   addnav("What would you like to do?");
   addnav("Search");
   addnav("The Bushes","forest.php?op=bushes");
   addnav("The Trees","forest.php?op=trees");
   addnav("The House","forest.php?op=house");
   addnav("The Mailbox","forest.php?op=mailbox");
}

if($op=="bushes"){
    set_module_pref("wrong1",1);
	increment_module_pref("searchtimes",1);
    if (get_module_pref("searchtimes")>=3) {
       addnav("Grue Attack","forest.php?op=attack");
       output("`n`2As you franticly search the `&bushes`2, you realize that you've taken too long!  The `\$Grue`2 found you! It's a fight to the death!`n`n");
    }else{
       output("`n`2You decide to search the bushes, hoping to find a discarded `^lantern `2or mayhap a `^torch`2. `n`n");
       output("`2Alas, you are not able to find anything suitable to set on `\$f`4ire`2.`n`n");
       output("`2You hear a `b`\$Grue`2`b nearby... better hurry!`n`n");
       if (get_module_pref("wrong2")==0) addnav("Search the House","forest.php?op=house");
       addnav("Search the Trees","forest.php?op=trees");
       if (get_module_pref("wrong3")==0) addnav("Search the Mailbox","forest.php?op=mailbox");
    }
}

if($op=="trees"){
    output("`n`2You decide to search the trees, hoping to find a branch to `\$burn`2. `n`n");
    output("`2You find a `\$J`@e`#w`\$e`%l `^E`&n`Qc`!r`@u`#s`\$t`%e`^d `&E`Qg`\$g`2!`n`n");
    output("`2You notice a slight rattle from within the `&E`Qg`\$g`2!`n`n");
    //Now we reset all the wrong answers since we got past that phase so we can use them again for the next phase
    set_module_pref("wrong1",0);
    set_module_pref("wrong2",0);
    set_module_pref("wrong3",0);
    set_module_pref("searchtimes",0);
    addnav("Continue On","forest.php?op=continue1");
}

if($op=="house"){
    set_module_pref("wrong2",1);
	increment_module_pref("searchtimes",1);
    if (get_module_pref("searchtimes")>=3) {
       addnav("Grue Attack","forest.php?op=attack");
       output("`n`2As you franticly search around the `&house`2, you realize that you've taken too long!  The `\$Grue`2 found you! It's a fight to the death!`n`n");
    }else{
       output("`n`2You decide to search the house, hoping to find a `bold chair or table leg`b to `\$b`4urn`2. `n`n");
       output("`2Alas, you are not able to find anything suitable to set on `\$f`4ire`2.`n`n");
       output("`2You hear a `b`\$Grue`2`b nearby... better hurry!`n`n");
       if (get_module_pref("wrong1")==0) addnav("Search Bushes","forest.php?op=bushes");
       addnav("Search Tree","forest.php?op=trees");
       if (get_module_pref("wrong3")==0) addnav("Search Mailbox","forest.php?op=mailbox");
    }
}

if($op=="mailbox"){
    set_module_pref("wrong3",1);
	increment_module_pref("searchtimes",1);
    if (get_module_pref("searchtimes")>=3) {
       addnav("Grue Attack","forest.php?op=attack");
       output("`n`2As you frantically search the `&mailbox`2, you realize that you've taken too long!  The `\$Grue`2 found you! It's a fight to the death!`n`n");
    }else{
       output("`n`2You decide to search the mailbox, hoping to find a letter or one of those annoying `bye olde credit card`b applications to burn. `n`n");
       output("`2You find a very small leaflet inside.  It says `6'Welcome to `@Legend of the Green Dragon`6!  `@LoGD`6 is a game of adventure, danger, and low cunning. In it you will explore some of the most amazing territory ever seen by mortals. No computer should be without one!'`n`n  `7\"What in the name of `QSix `7is a computer? `&you think to yourself.`7\"`n`n");
       output("`2Alas, you are not able to find anything suitable to set on `\$f`4ire`2.`n`n");
       output("`2You hear a `b`\$Grue`2`b nearby... better hurry!`n`n");
       if (get_module_pref("wrong2")==0) addnav("Search House","forest.php?op=house");
       if (get_module_pref("wrong1")==0) addnav("Search Bushes","forest.php?op=bushes");
       addnav("Search Tree","forest.php?op=trees");
    }
}

if ($op=="continue1"){
   output("`2`n`nYou are about ten feet above the ground nestled among some large branches.  The nearest branch above you is beyond your reach.`n`n");
   output("`2Beside you on the branch is a small `Qb`qird's `Qn`qest`2.  In the `Qn`qest`2 is a large `\$J`@e`#w`\$e`%l `^E`&n`Qc`!r`@u`#s`\$t`%e`^d `&E`Qg`\$g`2, `2apparently scavenged by a childless songbird.  Unlike most eggs, this one is hinged and closed with a delicate looking clasp.  The egg appears extremely fragile `7[it must be `2it`&al`\$ian`2!`7] `n`n");
   output("`2It's getting `)darker `2and `)darker `2by the second.  If only you had a wee bit o' `^light`2.`n`n  If you stay in the dark too long, you are likely to be eaten by a `\$`bGrue`b`2. `n`n");
   output("`7You are in an open field west of a big white house with a boarded front door.`n`n");
   output("`7There is a small mailbox here. `n`n");
   output(">_");
   addnav("Take Action!");
   addnav("Smash the Egg","forest.php?op=smash");
   addnav("Throw the Egg","forest.php?op=throw");
   addnav("Eat the Egg","forest.php?op=eat");
   addnav("Open the Egg","forest.php?op=open");
}

if($op=="smash"){
    output("`n`2Success!  You find a `^Golden Key `2inside! `n`n");
    output("`2Now, what to do with this key?`n`n");
    //Reset all the wrong answers since we got past that phase so we can use them again for the next phase
    set_module_pref("wrong1",0);
    set_module_pref("wrong2",0);
    set_module_pref("wrong3",0);
    set_module_pref("searchtimes",0);
    addnav("Continue On","forest.php?op=continue2");
}

if($op=="throw"){
    set_module_pref("wrong1",1);
	increment_module_pref("searchtimes",1);
    if (get_module_pref("searchtimes")>=3) {
      addnav("Grue Attack","forest.php?op=attack");
       output("`n`2You hit the `\$Grue`2 with the egg!  Oh No! It's a fight to the death!`n`n");
    }else{
      output("`n`2If you throw it, how will you find it in the `)dark`2? `n`n");
      output("`2D'oh!`n`n");
      output("`2You hear a `b`\$Grue`2`b nearby... better hurry!`n`n");
      addnav("Smash the Egg","forest.php?op=smash");
      if (get_module_pref("wrong2")==0) addnav("Eat the Egg","forest.php?op=eat");
      if (get_module_pref("wrong3")==0) addnav("Open the Egg","forest.php?op=open");
  }
}

if($op=="eat"){
    set_module_pref("wrong2",1);
	increment_module_pref("searchtimes",1);
    if (get_module_pref("searchtimes")>=3) {
       addnav("Grue Attack","forest.php?op=attack");
       output("`n`2You sit down to enjoy the egg!  You hear creeping behind you!  The `\$Grue`2 found you! It's a fight to the death!`n`n");
    }else{
       output("`n`2Opening your drooling maw, you prepare to take a bite out of this not-so-tasty looking `&E`Qg`\$g`2... `n`n");
      output("`2Now thats just silly, you cant eat a `\$J`@e`#w`\$e`%l `^E`&n`Qc`!r`@u`#s`\$t`%e`^d `&E`Qg`\$g`2! `n`n");
      output("`2You hear a `b`\$Grue`2`b nearby... better hurry!`n`n");
      if (get_module_pref("wrong1")==0) addnav("Throw the Egg","forest.php?op=throw");
      addnav("Smash the Egg","forest.php?op=smash");
      if (get_module_pref("wrong3")==0) addnav("Open the Egg","forest.php?op=open");
  }
}

if($op=="open"){
    set_module_pref("wrong3",1);
	increment_module_pref("searchtimes",1);
    if (get_module_pref("searchtimes")>=3) {
       addnav("Grue Attack","forest.php?op=attack");
       output("`n`2You use your head to try to open the egg.  The `\$Grue `2hears the loud hollow coconut sound of your head!  It's a fight to the death!`n`n");
    }else{
       output("`n`2You have neither the tools nor the expertise. `n`n");
       output("`2Alas, the `&E`Qg`\$g `2proves to be one tough nut to crack... errr, `&E`Qg`\$g`2, to crack, that is.`n`n");
       output("`2You hear a `b`\$Grue`2`b nearby... better hurry!`n`n");
       if (get_module_pref("wrong1")==0) addnav("Throw The Egg","forest.php?op=throw");
       if (get_module_pref("wrong2")==0) addnav("Eat the Egg","forest.php?op=eat");
       addnav("Smash the Egg","forest.php?op=smash");
    }
}

if ($op=="continue2"){
   output("`2`n`nFlippin' Sweet!  After you bust open the `\$J`@e`#w`\$e`%l `^E`&n`Qc`!r`@u`#s`\$t`%e`^d `&E`Qg`\$g `2and get the `^Golden Key `2 out, you put two and two together, and figure this key must go somewhere, right?  Besides, it's getting `)darker `2and `)darker `2by the second.`n  If only you had a wee bit o' `^light`2.`n`n  If you stay in the dark too long, you are likely to be eaten by a `\$`bGrue`b`2. `n`n");
   output("`7You are in an open field west of a big white house with a boarded front door.`n`n");
   output("`7There is a small mailbox here. `n`n");
   output(">_");
   addnav("Hurry Up And...");
   addnav("Search the House","forest.php?op=house1");
   addnav("Search the Rocks","forest.php?op=rocks");
   addnav("Search the Bushes","forest.php?op=bush");
   addnav("Search the Leaves","forest.php?op=leaves");
}

if($op=="house1"){
    set_module_pref("wrong1",1);
	increment_module_pref("searchtimes",1);
    if (get_module_pref("searchtimes")>=3) {
       addnav("Grue Attack","forest.php?op=attack");
       output("`n`2You took too long searching the `&house`2!  The `\$Grue`2 found you! It's a fight to the death!`n`n");
    }else{
       output("`n`2You begin to stumble in the `6fading daylight `2towards the house when you realize... `n`n");
       output("`n`2It is far to `)dark `2to do this safely... `n`n");
       output("`2You hear a `b`\$Grue`2`b nearby... better hurry!`n`n");
       if (get_module_pref("wrong3")==0) addnav("Search the Bush","forest.php?op=bush");
       addnav("Search the Leaves","forest.php?op=leaves");
       if (get_module_pref("wrong2")==0) addnav("Search the Rocks","forest.php?op=rocks");
    }
}

if($op=="rocks"){
    set_module_pref("wrong2",1);
	increment_module_pref("searchtimes",1);
    if (get_module_pref("searchtimes")>=3) {
    addnav("Grue Attack","forest.php?op=attack");
    output("`n`2You took too long searching the `7rocks`2!  The `\$Grue`2 found you! It's a fight to the death!`n`n");
    }else{
    output("`2You get down on your hands and knees and begin to push `7rocks `2and `7stones`2 around, only to realize... `n`n");
    output("`2It is far to `)dark`2 to do this safely...`n`n");
    output("`2You hear a `b`\$Grue`2`b nearby... better hurry!`n`n");
    if (get_module_pref("wrong1")==0) addnav("Search the House","forest.php?op=house1");
    if (get_module_pref("wrong3")==0) addnav("Search the Bush","forest.php?op=bush");
    addnav("Search the Leaves","forest.php?op=leaves");
  }
}

if($op=="bush"){
    set_module_pref("wrong3",1);
	increment_module_pref("searchtimes",1);
    if (get_module_pref("searchtimes")>=3) {
       addnav("Grue Attack","forest.php?op=attack");
       output("`n`2You took too long searching the `@bushes`2!  The `\$Grue`2 found you! It's a fight to the death!`n`n");
    }else{
       output("`n`2Thinking that perhaps something might be hidden in the `@bushes`2, you frantically search them, only to realize... `n`n");
       output("`2It is far to `)dark`2 to do this safely...`n`n");
       output("`2You hear a `b`\$Grue`2`b nearby... better hurry!`n`n");
       addnav("Search the Leaves","forest.php?op=leaves");
       if (get_module_pref("wrong1")==0) addnav("Search the House","forest.php?op=house1");
       if (get_module_pref("wrong2")==0) addnav("Search the Rocks","forest.php?op=rocks");
    }
}

if($op=="leaves"){
    output("`n`2As you crawl towards a huge `qPile of Leaves`2, you discover a grating built right into the dirt! `n`n");
    output("`2Quickly, you slip the `^Golden Key`2 into the `QR`qu`Qs`qt`Qy `QP`qa`Qd`ql`Qo`qc`Qk`2, thus opening it and the grate! You see a metal ladder embedded into the wall of the hole.`n`n");
    //Reset all the wrong answers since we got past that phase so we can use them again for the next phase
    set_module_pref("wrong1",0);
    set_module_pref("wrong2",0);
    set_module_pref("wrong3",0);
    set_module_pref("searchtimes",0);
    addnav("Continue On","forest.php?op=continue3");
}

if ($op=="continue3"){
   output("`2`n`nStanding in front of this mysterious looking hole in the ground, you think to yourself `&'Well, there are really only two choices now:  Stay here and be a wuss, or take the ladder down into that hole!'  `2Besides, it's almost `)pitch black `2by now.  If only you had a wee bit o' `^light`2.`n`n  If you stay in the dark too long, you are likely to be eaten by a `\$`bGrue`b`2. `n`n");
   output("`7You are in an open field west of a big white house with a boarded front door.`n`n");
   output("`7There is a small mailbox here. `n`n");
   output(">_");
   addnav("What Will You Do?");
   addnav("No way, i am not going down there!","forest.php?op=noway");
   addnav("What the hell, down the hatch!","forest.php?op=hatch");
   }

if($op=="hatch"){
             $sql = "SELECT acctid,name,gold,sex FROM ".db_prefix("accounts")." WHERE alive=1 and acctid<>'$id' ORDER BY rand(".e_rand().") LIMIT 1";
             $res = db_query($sql);
             $row = db_fetch_assoc($res);
             $name = $row['name'];
             if ($name==$session['user']['name']) $name="`&P`)hair";
             output("`n`n `2Finally!  You made it! You go down the ladder into the hole.  You are standing in a small room, about 10 feet by 10 feet.  As the last of the daylight slips away, you have just enough time to see a table by the north wall with a `^Lantern `2resting upon it (which you immediately light!) `n`n");
    output("`2After turning on the `^Lantern`2, you see `\$Dead`7mouse `2 sitting there on a chair, giving you quite the scare!`n`n`Q\"Thanks for finally getting that stupid grate open!  `&%s `Qlocked me in here, and then hid the `^Golden Key `Qin that `\$J`@e`#w`\$e`%l `^E`&n`Qc`!r`@u`#s`\$t`%e`^d `&E`Qg`\$g `Qup in the tree.  That scoundrel is in for a thrashing when I get out of here!  Here, you can have this as a reward for busting me out of here.\" `n`n",$name);
       switch(e_rand(1,4)){
        case 1:
            $mingold=get_module_setting("mingold");
            $maxgold=get_module_setting("maxgold");
            $goldgain =e_rand($mingold,$maxgold);
            $session['user']['gold']+=$goldgain;
            output("`\$Dead`7mouse `6gives you  a small leather pouch, filled with `^GOLD`6!  SCORE!`n");
            output("`@You've gained `^%s gold.",$goldgain);
            $session['user']['specialinc']="";
            addnews("". ($session['user']['name']) . "`@ has escaped the `\$Grue `@ and made out like a bandit!");
            addnav("To the forest","forest.php");
            output("`n`n`2You take your loot, stash it away safely, and climb up the ladder and head back to the forest.  The `^Lantern `2starts to flicker wildly, so you make haste for the Village...`n`n");
        break;
        case 2:
            $expgain =(($session['user']['level']*get_module_setting("dmexp"))+($session['user']['dragonkills']*get_module_setting("dmdkbonus")));
            output("`\$Dead`7mouse `6hurls sparkling dust into your face!  You feel strange, but more experienced.`n");
            output("`@You've gained `#%s `@experience.`n",$expgain);
            $session['user']['experience']+=$expgain;
            $session['user']['specialinc']="";
            addnews("". ($session['user']['name']) . "`@ has escaped the `\$Grue `@ and made out like a bandit!");
            addnav("To the forest","forest.php");
            output("`n`n`2Feeling more experienced, you climb up the ladder and head back to the forest.  The `^Lantern `2starts to flicker wildly, so you make haste for the Village...`n`n");
        break;
        case 3:
            $session['user']['turns']+=get_module_setting("ffgain");
            output("`\$Dead`7mouse `6shares some of the `\$Red Bull� `6 he was drinking with you!`n");
            output("`6You've gained `&%s`6 Forest Fights!",get_module_setting("ffgain"));
            $session['user']['specialinc']="";
            addnews("". ($session['user']['name']) . "`@ has escaped the `\$Grue `@ and made out like a bandit!");
            addnav("To the forest","forest.php");
            output("`n`n`2You are giddy like a schoolgirl after the drink! You climb up the ladder and head back to the forest.  The `^Lantern `2starts to flicker wildly, so you make haste for the Village...`n`n");
        break;
        case 4:
            $session['user']['deathpower']+=get_module_setting("dmdeath");
            output("`\$Dead`7mouse `6tells you that you don't look so good.  In fact, you look almost dead!`n");
            output("`6You've gained %s favor with `\$Ramius`6!",get_module_setting("dmdeath"));
            $session['user']['specialinc']="";
            addnews("". ($session['user']['name']) . "`@ has escaped the `\$Grue `@ and made out like a bandit!");
            addnav("To the forest","forest.php");
            output("`n`n`2Feeling a wee bit out of sorts, you climb up the ladder and head back to the forest.  The `^Lantern `2starts to flicker wildly, so you make haste for the Village...`n`n");
        break;
    }
}

if($op=="noway"){
   output("`n`n `2As you are standing there shivering with fear, the `\$Grue `2 finally makes its move! Prepare for battle! `n`n");
   addnav("Grue Attack!","forest.php?op=attack");
    }

if ($op=="attack") {
        $creaturelevel = $session['user']['level']+get_module_setting("creaturelevel");
        $creatureattack = round($session['user']['attack']*get_module_setting("creatureattack"));
        $creaturedefense = round($session['user']['defense']*get_module_setting("creaturedefense"));
        $creaturehealth = round($session['user']['maxhitpoints']*get_module_setting("creaturehealth"));
        if ($creaturelevel<=0) $creaturelevel=1;
        $badguy = array(
            "creaturename"=>"`\$The Grue",
            "creatureweapon"=>"`@its `%Slavering Maw of DOOM",
            "creaturelevel"=>$creaturelevel,
            "creatureattack"=>$creatureattack,
            "creaturedefense"=>$creaturedefense,
            "creaturehealth"=>$creaturehealth,
            "diddamage"=>0,
            "type"=>"grue",
            );
        $session['user']['badguy']=createstring($badguy);
        $op="fight";
        }

if ($op=="fight"){ $battle=true; }

    if ($battle){
        include("battle.php");  
        if ($victory){
            output("`n`6You killed the vile `\$Grue`6!  Now if only you had more time to explore this area... Mayhap next time.`n`n");
            $goldgain = 1;
            $session['user']['gold']+=$goldgain;
            output("`@You gained `^1 `@gold.  `\$Grues `@dont have much money!`n`n");
            $expbonus=$session['user']['dragonkills']*get_module_setting("expbonus");
            $expgain =($session['user']['level']*get_module_setting("expgain")+$expbonus);
            $session['user']['experience']+=$expgain;
            output("`@You gained `#%s `@experience.`n",$expgain);
            addnews("". ($session['user']['name']) . "`@ has slain the vile `\$Grue `@!");
                           }
elseif($defeat){
        $session['user']['specialinc'] = "";
        require_once("lib/taunt.php");
        $taunt = select_taunt_array();
        output("`n`n`b`6The `\$Grue `6took advantage of `)the darkness `6and bit your face off!`n");
        output("`4All gold on hand has been lost!`n");
        $exploss=$session['user']['level']*get_module_setting("exploss");
        output(" You lose `^%s `4experience.`b`c`0",$exploss);
        output("`@`bYou may begin fighting again tomorrow.`b");
        addnav("Daily news","news.php");
        $session['user']['alive'] = false;
        $session['user']['hitpoints'] = 0;
        $session['user']['gold']=0;
        addnews("%s `@had thier face bitten off by `\$A Grue `@while wandering the forest!`n%s",$session['user']['name'],$taunt);
        }
      else
        {
        fightnav(true,true);
            }
}
}
?>