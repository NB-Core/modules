<?php
// translator ready
// addnews ready
// mail ready

function racekronos_getmoduleinfo(){
	$info = array(
		"name"=>"Race - Kronos",
		"version"=>"1.0",
		"author"=>"Jigain To'lerean",
		"category"=>"Races",
		"download"=>"none",
		"settings"=>array(
			"Kronos Race Settings,title",
			"villagename"=>"Name for the kronos village|Athanasius",
			"minedeathchance"=>"Chance for Kronos to die in the mine,range,0,100,1|90",
		),
	);
	return $info;
}

function racekronos_install(){
	module_addhook("chooserace");
	module_addhook("setrace");
	module_addhook("newday");
	module_addhook("villagetext");
	module_addhook("travel");
	module_addhook("charstats");
	module_addhook("validlocation");
	module_addhook("validforestloc");
	module_addhook("moderate");
	module_addhook("changesetting");
	module_addhook("raceminedeath");
	module_addhook("pvpadjust");
	module_addhook("adjuststats");
	module_addhook("racenames");
	return true;
}

function racekronos_uninstall(){
	global $session;
	$vname = getsetting("villagename", LOCATION_FIELDS);
	$gname = get_module_setting("villagename");
	$sql = "UPDATE " . db_prefix("accounts") . " SET location='$vname' WHERE location = '$gname'";
	db_query($sql);
	if ($session['user']['location'] == $gname)
		$session['user']['location'] = $vname;
	// Force anyone who was a kronos to rechoose race
	$sql = "UPDATE  " . db_prefix("accounts") . " SET race='" . RACE_UNKNOWN . "' WHERE race='Kronos'";
	db_query($sql);
	if ($session['user']['race'] == 'Kronos')
		$session['user']['race'] = RACE_UNKNOWN;
	return true;
}

function racekronos_dohook($hookname,$args){
	//yeah, the $resline thing is a hack.  Sorry, not sure of a better way
	//to handle this.
	// Pass it in via args?
	global $session,$resline;
	$city = get_module_setting("villagename");
	$race = "Kronos";
	switch($hookname){
	case "racenames":
		$args[$race] = $race;
		break;
	case "pvpadjust":
		if ($args['race'] == $race) {
			$args['creaturedefense']+=(1+floor($args['creaturelevel']/5));
		}
		break;
	case"adjuststats":
		if ($args['race'] == $race) {
			$args['defense'] += (1+floor($args['level']/5));
		}
		break;
	case "raceminedeath":
		if ($session['user']['race'] == $race) {
			$args['chance'] = get_module_setting("minedeathchance");
		}
		break;
	case "changesetting":
		// Ignore anything other than villagename setting changes
		if ($args['setting'] == "villagename" && $args['module']=="racekronos") {
			if ($session['user']['location'] == $args['old'])
				$session['user']['location'] = $args['new'];
			$sql = "UPDATE " . db_prefix("accounts") .
				" SET location='" . addslashes($args['new']) .
				"' WHERE location='" . addslashes($args['old']) . "'";
			db_query($sql);
			if (is_module_active("cities")) {
				$sql = "UPDATE " . db_prefix("module_userprefs") .
					" SET value='" . addslashes($args['new']) .
					"' WHERE modulename='cities' AND setting='homecity'" .
					"AND value='" . addslashes($args['old']) . "'";
				db_query($sql);
			}
		}
		break;
	case "charstats":
		if ($session['user']['race']==$race){
			addcharstat("Vital Info");
			addcharstat("Race", translate_inline($race));
		}
		break;
	case "chooserace":
		output("<a href='newday.php?setrace=$race$resline'>Amoungst the brimstone cliffs</a> that is %s, an ancient city of the Kronos Empire. Despite %s now comprising of ruins and ancient structures, you think back to hundreds of years ago where, in your youth, you remember how many were slaughtered in a great war for power and conquest.
.`n`n", $city, $city, true);
		addnav("`4Kronos`0","newday.php?setrace=$race$resline");
		addnav("","newday.php?setrace=$race$resline");
		break;
	case "setrace":
		if ($session['user']['race']==$race){
			output("`&As a Kronos, you have the ability to withstand extreme temperatures and last longer in battle.`n`^You gain extra defense!");
			if (is_module_active("cities")) {
				if ($session['user']['dragonkills']==0 &&
						$session['user']['age']==0){
					//new farmthing, set them to wandering around this city.
					set_module_setting("newest-$city",
							$session['user']['acctid'],"cities");
				}
				set_module_pref("homecity",$city,"cities");
				if ($session['user']['age'] == 0)
					$session['user']['location']=$city;
			}
		}
		break;
	case "newday":
		if ($session['user']['race']==$race){
			racekronos_checkcity();
			apply_buff("racialbenefit",array(
				"name"=>"`4Kronos Barrier`0",
				"defmod"=>"(<defense>?(1+((1+floor(<level>/5))/<defense>)):0)",
				"allowinpvp"=>1,
				"allowintrain"=>1,
				"rounds"=>-1,
				"schema"=>"module-racekronos",
				)
			);
		}
		break;
	case "validforestloc":
	case "validlocation":
		if (is_module_active("cities"))
			$args[$city]="village-$race";
		break;
	case "moderate":
		if (is_module_active("cities")) {
			tlschema("commentary");
			$args["village-$race"]=sprintf_translate("Ruins of %s", $city);
			tlschema();
		}
		break;
	case "travel":
		$capital = getsetting("villagename", LOCATION_FIELDS);
		$hotkey = substr($city, 0, 1);
		tlschema("module-cities");
		if ($session['user']['location']==$capital){
			addnav("Safer Travel");
			addnav(array("%s?Go to %s", $hotkey, $city),"runmodule.php?module=cities&op=travel&city=$city");
		}elseif ($session['user']['location']!=$city){
			addnav("More Dangerous Travel");
			addnav(array("%s?Go to %s", $hotkey, $city),"runmodule.php?module=cities&op=travel&city=$city&d=1");
		}
		if ($session['user']['superuser'] & SU_EDIT_USERS){
			addnav("Superuser");
			addnav(array("%s?Go to %s", $hotkey, $city),"runmodule.php?module=cities&op=travel&city=$city&su=1");
		}
		tlschema();
		break;	
	case "villagetext":
		racekronos_checkcity();
		if ($session['user']['location'] == $city){
			$args['text']=array("`^`c`b%s, the last city of Kronos`b`c`n`6As you enter %s, you find that the air and sky is thick with a smoke-like substance, suggesting a fusion of brimstone and lava. Nestled within tall brimstone cliffs, the ruins appear to be scarred by war. Small dragons can be seen in the distance circling what appears to be an ancient castle. `n", $city, $city);			$args['schemas']['text'] = "module-racekronos";
			$args['clock']="`n`6As you enter the city, your mind clouds with unfamiliar voices.`nYou realize that these voices are lost souls from the massacre that happened here. One voice mutters `^%s`6, and at that, the voices stop.`n";
			$args['schemas']['clock'] = "module-racekronos";
			if (is_module_active("calendar")) {
				$args['calendar']="`n`6A local tries to sell you a cheap calender, and you read: \"`^Today is `&%3\$s %2\$s`^, `&%4\$s`^.  It is `&%1\$s`^.`6\"`n";
				$args['schemas']['calendar'] = "modules-racekronos";
			}
			$args['title']= array("%s Ruins", $city);
			$args['schemas']['title'] = "module-racekronos";
			$args['sayline']="whispers";
			$args['schemas']['sayline'] = "module-racekronos";
			$args['talk']="`n`^Breaking the silence, nearby villagers speak:`n";
			$args['schemas']['talk'] = "module-racekronos";
			$new = get_module_setting("newest-$city", "cities");
			if ($new != 0) {
				$sql =  "SELECT name FROM " . db_prefix("accounts") .
					" WHERE acctid='$new'";
				$result = db_query_cached($sql, "newest-$city");
				$row = db_fetch_assoc($result);
				$args['newestplayer'] = $row['name'];
				$args['newestid']=$new;
			} else {
				$args['newestplayer'] = $new;
				$args['newestid']="";
			}
			if ($new == $session['user']['acctid']) {
				$args['newest']="`n`6Paying closer attention to the destructive marks on the structures, you begin to feel a sense of curiosity sweep through you body...";
			} else {
				$args['newest']="`n`6You see curiosity sweep through the eyes of `^%s`6, as they pay closer attention to the destructive marks on the Ancient structures.";
			}
			$args['schemas']['newest'] = "module-racekronos";
			$args['gatenav']="Brimstone Gateway";
			$args['schemas']['gatenav'] = "module-racekronos";
			$args['fightnav']="Ancient Castle";
			$args['schemas']['fightnav'] = "module-racekronos";
			$args['marketnav']="The Square";
			$args['schemas']['marketnav'] = "module-racekronos";
			$args['tavernnav']="Cave Atruim";
			$args['schemas']['tavernnav'] = "module-racekronos";
			$args['section']="village-$race";
		}
		break;
	}
	return $args;
}

function racekronos_checkcity(){
	global $session;
	$race="Kronos";
	$city=get_module_setting("villagename");
	
	if ($session['user']['race']==$race && is_module_active("cities")){
		//if they're this race and their home city isn't right, set it up.
		if (get_module_pref("homecity","cities")!=$city){ //home city is wrong
			set_module_pref("homecity",$city,"cities");
		}
	}	
	return true;
}

function racekronos_run(){

}
?>