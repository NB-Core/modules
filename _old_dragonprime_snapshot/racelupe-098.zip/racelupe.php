<?php
// translator ready
// addnews ready

function racelupe_getmoduleinfo(){
	$info = array(
		"name"=>"Race - Lupine",
		"version"=>"1.0",
		"author"=>"Rowne Mastaile",
		"category"=>"Races",
		"allowanonymous"=>true,
		"settings"=>array(
			"Lupine Race Settings,title",
			"villagename"=>"Name for the Lupine village|Thundarulf",
			"minedeathchance"=>"Chance for Lupines to die in the mine,range,0,100,1|90",
		),
	);
	return $info;
}

function racelupe_install(){
	module_addhook("chooserace");
	module_addhook("setrace");
	module_addhook("newday");
	module_addhook("villagetext");
	module_addhook("stabletext");
	module_addhook("travel");
	module_addhook("charstats");
	module_addhook("validlocation");
	module_addhook("moderate");
	module_addhook("changesetting");
	module_addhook("raceminedeath");
	module_addhook("stablelocs");
	module_addhook("lupehome");
	return true;
}

function racelupe_uninstall(){
	global $session;
	$vname = getsetting("villagename", LOCATION_FIELDS);
	$gname = get_module_setting("villagename");
	$sql = "UPDATE " . db_prefix("accounts") . " SET location='$vname' WHERE location = '$gname'";
	db_query($sql);
	if ($session['user']['location'] == $gname)
		$session['user']['location'] = $vname;
	// Force anyone who was a Lupine to rechoose race
	$sql = "UPDATE  " . db_prefix("accounts") . " SET race='" . RACE_UNKNOWN . "' WHERE race='Lupine'";
	db_query($sql);
	if ($session['user']['race'] == 'Lupine')
		$session['user']['race'] = RACE_UNKNOWN;
	return true;
}

function racelupe_dohook($hookname,$args){
	//yeah, the $resline thing is a hack.  Sorry, not sure of a better way
	// to handle this.
	// Pass it as an arg?
	global $session,$resline;
	$city = get_module_setting("villagename");
	$race = "Lupine";
	switch($hookname){
	case "raceminedeath":
		if ($session['user']['race'] == $race) {
			$args['chance'] = get_module_setting("minedeathchance");
		}
		break;
	case "changesetting":
		// Ignore anything other than villagename setting changes
		if ($args['setting'] == "villagename" && $args['module']=="racelupe") {
			if ($session['user']['location'] == $args['old'])
				$session['user']['location'] = $args['new'];
			$sql = "UPDATE " . db_prefix("accounts") .
				" SET location='" . $args['new'] .
				"' WHERE location='" . $args['old'] . "'";
			db_query($sql);
			if (is_module_active("cities")) {
				$sql = "UPDATE " . db_prefix("module_userprefs") .
					" SET value='" . $args['new'] .
					"' WHERE modulename='cities' AND setting='homecity'" .
					"AND value='" . $args['old'] . "'";
				db_query($sql);
			}
		}
		break;
	case "charstats":
		if ($session['user']['race']==$race){
			addcharstat("Vital Info");
			addcharstat("Race", translate_inline($race));
		}
		break;
	case "chooserace":
		output("`0<a href='newday.php?setrace=$race$resline'>In the Ancestral Encampment of %s</a>, the home of `&Lupines`0; you were brought up to respect the land and your ancestors and in doing so, you learned many secrets from both than the other races could not hope to know.`n`n", $city, true);
		addnav("`&Lupine`0","newday.php?setrace=$race$resline");
		addnav("","newday.php?setrace=$race$resline");
		break;
	case "setrace":
		if ($session['user']['race']==$race){
			output("`&You grew up in the encampment of your ancestors and you were taught respect for the land from a very young age.  You have a strong bond with your lands and your peoples.`n`^You can wish yourself home at any time (but it will cost you) and your Ancestors will often aid you in battle!");
			if (is_module_active("cities")) {
				if ($session['user']['dragonkills']==0 &&
						$session['user']['age']==0){
					//new farmthing, set them to wandering around this city.
					set_module_setting("newest-$city",
							$session['user']['acctid'],"cities");
				}
				set_module_pref("homecity",$city,"cities");
				$session['user']['location']=$city;
			}
		}
		break;
	case "newday":
		if ($session['user']['race']==$race){
			racelupe_checkcity();
			$args['turnstoday'] .= ", Race (Lupine): 1";
			apply_buff('lupinebuff',
				array(
					"name"=>"`6Ancestral Spirits",
					"rounds"=>5,
					"wearoff"=>"You stop puking your guts up.  Literally.",
					"atkmod"=>1.40,
					"defmod"=>1.40,
					"roundmsg"=>"`^Spirits of your ancestors rise up to fight beside you, empowering your own passion for the hunt!",
					"survivenewday"=>1,
					"newdaymessage"=>"`^The spirits are with you!  `&And you feel stronger for it but you know they can offer their aid for a short time.",
					"schema"=>"racelupe"
				)
			);
			output("`&You feel as if the spirits are with you today, watching over you as one of their children.`n`&You gain a `2five round`& buff!");
		}
		break;
	case "validlocation":
		if (is_module_active("cities"))
			$args[$city]="village-$race";
		break;
	case "moderate":
		if (is_module_active("cities")) {
			tlschema("commentary");
			$args["village-$race"]=sprintf_translate("City of %s", $city);
			tlschema();
		}
		break;
	case "travel":
		$capital = getsetting("villagename", LOCATION_FIELDS);
		$hotkey = substr($city, 0, 1);
		tlschema("module-cities");
		if ($session['user']['location']==$capital){
			addnav("Safer Travel");
			addnav(array("%s?Go to %s", $hotkey, $city),"runmodule.php?module=cities&op=travel&city=$city");
		}elseif ($session['user']['location']!=$city){
			addnav("More Dangerous Travel");
			addnav(array("%s?Go to %s", $hotkey, $city),"runmodule.php?module=cities&op=travel&city=$city&d=1");
		}
		if ($session['user']['superuser'] & SU_EDIT_USERS){
			addnav("Superuser");
			addnav(array("%s?Go to %s", $hotkey, $city),"runmodule.php?module=cities&op=travel&city=$city&su=1");
		}
		tlschema();
		break;	
	case "villagetext":
		racelupe_checkcity();
		if ($session['user']['location'] == $city){
			$args['text']=array("`&`c`b%s, the Ancestral Encampment of the Lupines`b`c`n`7You find yourself in an encampment of tents and ramshackle buildings, all of them are painted up in beautiful tribal designs picturing stylized variations of different animals.  Painted mats and featherbound clothes are easily seen wherever you look.  At the heart of this grand encampment is an insurmountable totem pole depicting the Lupines and their closest kin, it is a sight to be seen.  A number of gatherers crowd around it, discussing tomorrow's hunt.`n", $city, $city);
			$args['schemas']['text'] = "module-racelupe";
			$args['clock']="`n`7Amongst the dreamcatchers mounted on the totem-pole, there's also a Mustelid-crafted sundial which reads `&%s`7.`n";
			$args['schemas']['clock'] = "module-racelupe";
			if (is_module_active("calendar")) {
				$args['calendar'] = "`n`7A smaller contraption next to it reads `&%s`7, `&%s %s %s`7.`n";
				$args['schemas']['calendar'] = "module-racelupe";
			}
			$args['title']=array("%s, Encampment of Lupines", $city);
			$args['schemas']['title'] = "module-racelupe";
			$args['sayline']="says";
			$args['schemas']['sayline'] = "module-racelupe";
			$args['talk']="`n`&Nearby some villagers talk:`n";
			$args['schemas']['talk'] = "module-racelupe";
			$new = get_module_setting("newest-$city", "cities");
			if ($new != 0) {
				$sql =  "SELECT name FROM " . db_prefix("accounts") .
					" WHERE acctid='$new'";
				$result = db_query_cached($sql, "newest-$city");
				$row = db_fetch_assoc($result);
				$args['newestplayer'] = $row['name'];
				$args['newestid']=$new;
			} else {
				$args['newestplayer'] = $new;
				$args['newestid']="";
			}
			if ($new == $session['user']['acctid']) {
				$args['newest']="`n`7As you wander your new home, you feel your jaw dropping at the wonders around you.";
			} else {
				$args['newest']="`n`7Wandering the village, jaw agape, is `&%s`7.";
			}
			$args['schemas']['newest'] = "module-racelupe";
			$args['section']="village-$race";
			$args['stablename']="Silent Mountain's Companions";
			$args['schemas']['stablename'] = "module-racelupe";
			$args['gatenav']="Encampment Boundary";
			$args['schemas']['gatenav'] = "module-racelupe";
			unblocknav("stables.php");
		}
		break;
	case "stabletext":
		if ($session['user']['location'] != $city) break;
		$args['title'] = "Silent Mountain's Companions";
		$args['schemas']['title'] = "module-racelupe";
		$args['desc'] = "Near the totem pole there's a patchwork tent hung loosely over a pen and stables, attending it is the largest Lupine you've ever seen!  You can see why they call him mountain and as he offers naught but a wave at the sight of you, you can gather why they call him silent, too.";
		$args['schemas']['desc'] = "module-racelupe";
		$args['lad']="friend";
		$args['schemas']['lad'] = "module-racelupe";
		$args['lass']="friend";
		$args['schemas']['lass'] = "module-racelupe";
		$args['nosuchbeast']="Silent Mountain closes his eyes and shakes his head once, gently.  Apparently that's not a mount he stocks.";
		$args['schemas']['nosuchbeast'] = "module-racelupe";
		$args['finebeast']=array(
			"Silent Mountain smiles fondly at the mount in quest, he seems to like it a lot.`n`n",
			"There's a gleam in Silent Mountain's eyes and his muzzle curls to a slight grin, you barely notice it but still ... this must be an impressive mount`n`n",
			"Silent Mountain reaches over and playfully slaps the haunches of one of his charges, the creature doesn't even flinch.  They're trained well!`n`n",
			"With a snap of his fingers, all of his charges gather around attentively.  You're not sure what methods he uses to train them but they're good.  Then again, perhaps it's simply friendship?`n`n",
			"There is silence and Silent Mountain says nothing to break that silence, even though you might expect him to.  Though why you'd expect that is beyond you at this moment in time.`n`n",
			);
		$args['schemas']['finebeast'] = "module-racelupe";
		$args['toolittle']="With a cursory glance at the amount in hand, he looks angry for a moment then simply tosses the gold and gems to the ground.  It seems you don't have enough for this mount and your meagre offer has offended him.";
		$args['schemas']['toolittle'] = "module-racelupe";
		$args['replacemount']="`6Patting %s`6 on the rump, you hand the reins as well as the money for your new creature, and Silent Mountain hands you the reins of a `&%s`6.";
		$args['schemas']['replacemount'] = "module-racelupe";
		$args['newmount']="`6You hand over the money for your new creature, and Silent Mountain hands you the reins of a new `&%s`6.";
		$args['schemas']['newmount'] = "module-racelupe";
		$args['nofeed']="`6\"`^I'm terribly sorry %s, but I don't stock feed here.  I'm not a common stable after all!  Perhaps you should look elsewhere to feed your creature.`6\"";
		$args['schemas']['nofeed'] = "module-racelupe";
		$args['nothungry']="`&%s`6 picks briefly at the food and then ignores it.  Silent Mountain, being the earnest and proud Lupine that he is, shakes his head and hands you back your gold.";
		$args['schemas']['nothungry'] = "module-racelupe";
		$args['halfhungry']="`&%s`6dives into the provided food and gets through about half of it before stopping.  Silent Mountain motions you over as he offers food but your charge must be more full than he appeared, at that he hands you back all but %s gold.";
		$args['schemas']['halfhungry'] = "module-racelupe";
		$args['hungry']="`6%s`6 seems to inhale the food provided.  %s`6, the greedy creature that it is, then goes snuffling at Silent Mountain's belt satchels for more food.`nSilent Mountain shakes his head in amusement and collects `&%s`6 gold from you.";
		$args['schemas']['hungry'] = "module-racelupe";
		$args['mountfull']="`n`6\"`^For a moment, your mount wonders if this stranger's food is as good as its' owner %s's.  At that, the %s`^ literally `idives`i into the food, which causes Silent Mountain to jump back slightly with surprise.  Apparently he likes the feed here and the warm smile on Silent Mountain's muzzle shows that he enjoys feeding your charge.";
		$args['schemas']['mountfull'] = "module-racelupe";
		$args['nofeedgold']="Silent Mountain simply stares at you for a long, long time and after a while you realize you're not going to get a response and you lead %s away to find other places for feeding.";
		$args['schemas']['nofeedgold'] = "module-racelupe";
		$args['confirmsale']="`n`n`6Silent Mountain simply gazes into the eyes of your mount for a few moments, he offers a nod to state that the creature is more than acceptable.  He turns to you however with a look of concern, almost as if to ascertain whether you truly wished to part with your friend so easily.";
		$args['schemas']['confirmsale'] = "module-racelupe";
		$args['mountsold']="`6With but a single tear, you hand over the reins to your %s`6 to Silent Mountain.  The tear dries quickly, and the %s in hand helps you quickly overcome your sorrow.";
		$args['schemas']['mountsold'] = "module-racelupe";
		$args['offer']="`n`n`6Silent Mountain strokes your creature's flank and offers you `&%s`6 gold and `%%s`6 gems for %s`6.";
		$args['schemas']['offer'] = "module-racelupe";
		break;
	case "stablelocs":
		tlschema("mounts");
		$args[$city]=sprintf_translate("The Village of %s", $city);
		tlschema();
		break;
	case "lupehome":
		if ($session['user']['race'] == "Lupine") {
			if($session['user']['hitpoints'] < 2) {
				output("You are too drained to spirit~ride home.  You will not be able to do that until you have healed.");
			} else {
				addnav("Lupine Special");
				addnav("To my home...","runmodule.php?module=racelupe&op=spiritride");
			}
		}
		break;
	}
	return $args;
}

function racelupe_checkcity(){
	global $session;
	$race="Lupine";
	$city=get_module_setting("villagename");
	
	if ($session['user']['race']==$race && is_module_active("cities")){
		//if they're this race and their home city isn't right, set it up.
		if (get_module_pref("homecity","cities")!=$city){ //home city is wrong
			set_module_pref("homecity",$city,"cities");
		}
	}	
	return true;
}

function racelupe_run(){
	global $session;
	$op = httpget("op");
        page_header("To your homeland, young Lupine!");
	if ($op == "spiritride") {
		output("`b`^You close your eyes and concentrate on your homeland...`b");
		output("`n`n`7Your head swims and after a moment, you pass out.  You awaken moments later, you are weakened but you find you have returned alive to...");
		addnav("Continue","runmodule.php?module=cities&op=travel&city=Thundarulf");
		$session['user']['hitpoints'] = 1;
		$session['user']['turns'] = 0;
	}
	page_footer();
}
?>
