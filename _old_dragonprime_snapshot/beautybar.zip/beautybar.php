<?php

//09112005
/* *******************
Codierung von Ray
Ideen von Ray
ICQ:230406044
******************* */

/****************************************************************
Einbauanleitung:																										�ffne village.php und suche:
addnav("Z?Zigeunerzelt","gypsy.php");
f�ge darunter:
addnav("Beauty-Bar","beautybar.php");

ansonsten noch viel spass...
****************************************************************/
require_once"common.php";
page_header("Beauty-Bar");

if ($_GET['op']==""){
output("`#Du gehst ein wenig im Einkaufszentrum umher und siehst eine Beauty-Bar. Du denkst dir das es nicht schaden k�nnte eine Gurkenmaske oder Manik�re zu nehmen. Was willst du nehmen?`n`n");

addnav("Sch�ner werden");
addnav("G?Eine Gurkenmaske nehmen 6000 Gold","beautybar.php?op=gu");
addnav("M?Eine Manik�re nehmen 3000 Gold","beautybar.php?op=ma");
addnav("Sich verunstalten lassen");
addnav("V?Von den Azubi's die Haare schneiden lassen ","beautybar.php?op=azubi");
addnav("D?Zur�ck ins Dorf","village.php");


}else if ($_GET['op']=="gu"){
 if ($session['user']['gold']>5999){
    output("Du bezahlst `^6000 `$Gold");
    output("`#Du gehst schonmal auf deinen platz und machst es dir gem�tlich, da das sowieso dauert machst du ein kleines Nickerchen.");
    output("`#Nach einigen Stunden Erhohlsamen schlafes wachst du schlie�lich auf und merkst das die Gurkenmaske wirklich wunder gewirkt hat.`n`n`&Du wirkst Charmanter du Kriegst 2 charme punkte.");
	$session['user']['charm']+=2;
	$session['user']['gold']-=6000;
	addnav("Zur�ck ins Dorf","village.php");
	}else{
	output("`#Du hast nicht gen�gend Gold.");
	addnav("Zur�ck ins Dorf","village.php");
	}

}else if ($_GET['op']=="ma"){
 if ($session['user']['gold']>2999){
	output("`#Du entschlie�t dich dazu eine Manik�re zu nehmen, du gehst zu deinen platz und wartest auf die bedienung.....du wartest ewig aber es kommt keiner du willst dich grade beschweren als die Frau grade kommt.");
	output("Es �rgert dich bereits das sie sich so sehr versp�tet hat also bittest du sie das sie sofort anf�ngt.`n`n");
	output("`&Du wirkst Charmanter du Kriegst 1 charme punkte.");
	$session['user']['charm']+=1;
	$session['user']['gold']-=3000;
	addnav("Zur�ck ins Dorf","village.php");
	}else{
	output("`#Du hast nicht gen�gend Gold.");
	addnav("Zur�ck ins Dorf","village.php");
	}
}else if ($_GET['op']=="azubi"){
	output("`#Du l�sst dir von den auszubildenen Friseuren die Haare schneiden....nur wie es aussieht m�ssen die noch viel lernen du siehst total verunstaltet aus damit sinkt dein charme um 1 punkte.... aber einen vorteil gibts du hast dir grade `^2000 `# Gold verdient.");
	$session['user']['charm']-=1;
	$session['user']['gold']+=2000;
	addnav("Zur�ck ins Dorf","village.php");
	}


page_footer();
?>