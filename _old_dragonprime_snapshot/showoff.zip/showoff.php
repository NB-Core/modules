<?php 

function showoff_getmoduleinfo(){
		$info = array(
			"name"=>"Showing Off",
			"author"=>"Steve McCorry",
			"version"=>"0.1",
			"category"=>"Forest Specials",
			"download"=>"http://dragonprime.net/users/Selekta/showoff.zip",
			"settings"=>array(
			"Showing Off Settings,title",
				"charm"=>"How much charm does a player get for showing off?,int|5",
				"gold"=>"How much gold does the player get for showing off?<br>`imultiplied by level`i,int|100",
			),
	);
	return $info;
}
function showoff_install(){
	module_addeventhook("forest","return 100;");
	return true;
}
function showoff_uninstall(){
	return true;
}
function showoff_runevent($type){
	global $session;
	$from = "forest.php?";
	$session['user']['specialinc'] = "";
	$op = httpget("op");
	$gold = ($session['user']['level']*get_module_setting("gold"));
	
	if ($op == "" || $op == "search"){
	$session['user']['specialinc'] = "module:showoff";
		output("`)While traveling through the forest, you come across a large crowd of people.");
		output("After a moment, all eyes are on you.");
		output("You can feel them analyzing your every movement.");
		output("Never wanting to pass up an opportunity, you decide that you should show off for them, and boost your ego a bit.");
		addnav("Show off!", $from. "op=showoff");
		addnav("Pass on by", $from. "op=passby");
	}elseif($op == "showoff"){
		switch (e_rand(1,3)){
			case 1:
			case 2:
				output("`)You flex your muscles a bit as you strut through the crowd.");
				output("The onlookers`& \"ooh\" `)and`& \"ah\" `)as you bow humbly before them.");
				output("You smile as peasents approach you, to shine away the blood from your armour.");
				output("`^You feel Charming`)! You are surprised to see the crowd rolling `^%s `)gold pieces at your feet.",$gold);
				$session['user']['charm']+=get_module_setting("charm");
				$session['user']['gold']+=$gold;
				break;
			case 3:
				output("`)You strut through smugly, flashing heroic smirks at the onlooking crowd.");
				output("Unfortunately for you, they take no liking to your ego, or your accomplishments.");
				output("You tear through at top speed as the crowd pelts you with `\$tomatoes.");
				output("`^You lose some charm!`).");
				$session['user']['charm']-=get_module_setting("charm");
				break;
			}
	}elseif($op == "passby"){
		output("`)You think about showing off, but decide that it might not be a good idea.");
		output("Some crowds have been known to attack smug \"`\$Heroes`).\"");
	}
}
?>