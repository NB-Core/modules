<?
require_once("common.php");
require_once("lib/commentary.php");
require_once("lib/http.php");
require_once("lib/villagenav.php");
function arcadiadist_getmoduleinfo(){
	$info = array(
		"name"=>"The Arcadian District",
		"version"=>"3.0",
		"author"=>"`4S`)ig`4g, based on `4D`)hampir `4K`)ampf's `@Arcadia Village",
		"category"=>"Streets",
		"download"=>"",
		"vertxtloc"=>"",
		"requires"=>array(
			"streetsplus"=>"Streets Plus |Primarily by Sigg"
		),	
		"settings"=>array(
			"Aracadia Settings,title",
			"adks"=>"How many dragon kills are required to visit the Arcadian District?,int|31"
		),
		"prefs"=>array(
			"Arcadia Prefs,title",
			"banned"=>"Is this user banned from Arcadia?,bool|0",
			"allowed"=>"Is this user allowed to visit Arcadia?,bool|0"
			),
	);
	return $info;
}
function arcadiadist_install(){
	module_addhook("village");
	module_addhook("moderate");
	module_addhook("f5street");
	return true;
}
function arcadiadist_uninstall(){
	return true;
}
function arcadiadist_dohook($hookname,$args){
	global $session;
	switch($hookname){
		case "f5street";
			arcadiadist_show();
			break;
		case "moderate":
				$args['arcadia'] = "Arcadia";
				break;
				}
		return $args;
}
function arcadiadist_show(){
	global $session;
	$name = get_module_setting("f5name","streetsplus");
	if(get_module_pref("banned")!=1 && ($session['user']['dragonkills']>=get_module_setting("adks") || get_module_pref("allowed") == 1)){
		output("`7Seeing as how you are currently in `@`i%s`i`7, you should give yourself a pat on the back; ",get_module_setting("f5name","streetsplus"));
		output("the magic around this mystical place has allowed you to enter!  Instead of just seeing a deserted street, you can ",$name);
		output("view this whole area.  This is an area just for those powerful enough to have %s ",get_module_setting('adks'));
		output(" dragon kills to have a place to come to get away from the hectic streets of the main city.  So have fun!`n`n`n");;
		modulehook("arcadia");
		addcommentary();
		viewcommentary ("arcadia","Speak", 25, "says");
		set_module_pref("seechat",0,"streetsplus");
		set_module_pref("seedesc",0,"streetsplus");
	}else{
		output("`4You look around and see nothing but a decrepit old sign that reads \"`@`i%s`4\"",$name);
		set_module_pref("seedesc",0,"streetsplus");
		set_module_pref("seelinks",0,"streetsplus");
	}
}
?>