[11:48:17] STELI says, "This is a test chat line"

I only wanted to show the time, not the date and because of this I've created a new field in "commentary" table called time (type=time, default=00:00:00). 

(You could use the "postdate" field which already exists in the table, but this way you will display the date and time in the commentary.)

Now let's begin:
In common.php:

IF YOU WISH TO USE POSTDATE INSTEAD OF TIME, SKIP THIS PART:

PART 1:
--------------------------------------------------------------------------------------------------------------
FIND:
[code]
$sql = "INSERT INTO commentary (postdate,section,author,comment) VALUES (now(),'$section',".$session[user][acctid].",\"$commentary\")";
[/code]

REPLACE WITH:
[code]
$sql = "INSERT INTO commentary (time,postdate,section,author,comment) VALUES (now(),now(),'$section',".$session[user][acctid].",\"$commentary\")";
[/code]
--------------------------------------------------------------------------------------------------------------

PART 2:
--------------------------------------------------------------------------------------------------------------
FIND:
[code]
			if ($x!==false){
				if ($linkbios)
					$op[$i] = str_replace("&amp;","&",HTMLEntities(substr($row[comment],0,$x)))
					."`0<a href='$link' style='text-decoration: none'>\n`&$row[name]`0</a>\n`& "
					.str_replace("&amp;","&",HTMLEntities(substr($row[comment],$x+strlen($ft))))
						."`0`n";
				else
					$op[$i] = str_replace("&amp;","&",HTMLEntities(substr($row[comment],0,$x)))
					."`0\n`&$row[name]`0\n`& "
					.str_replace("&amp;","&",HTMLEntities(substr($row[comment],$x+strlen($ft))))
						."`0`n";
			}
		}
		if ($op[$i]=="") 
			if ($linkbios)
				$op[$i] = "`0<a href='$link' style='text-decoration: none'>`&$row[name]`0</a>`3 says, \"`#"
					.str_replace("&amp;","&",HTMLEntities($row[comment]))."`3\"`0`n";
			else
				$op[$i] = "`0`&$row[name]`0`3 says, \"`#"
				    .str_replace("&amp;","&",HTMLEntities($row[comment]))."`3\"`0`n";
		if ($message=="X") $op[$i]="`0($row[section]) ".$op[$i];
		if ($row['postdate']>=$session['user']['recentcomments']) $op[$i]="<img src='images/new.gif' alt='&gt;' width='3' height='5' align='absmiddle'> ".$op[$i];
		addnav("",$link);
	}
[/code]

REPLACE WITH:
[code]
			if ($x!==false){
				if ($linkbios)
					$op[$i] = str_replace("&amp;","&",HTMLEntities(substr($row[comment],0,$x)))
					."<font size=1>`)[".$row['time']."]</font>" // use $row['postdate'] intead of $row['time'] if you wish to show the date & time
					."`0<a href='$link' style='text-decoration: none'>\n`&$row[name]`0</a>\n`& "
					.str_replace("&amp;","&",HTMLEntities(substr($row[comment],$x+strlen($ft))))
						."`0`n";
				else
					$op[$i] = str_replace("&amp;","&",HTMLEntities(substr($row[comment],0,$x)))
					."<font size=1>`)[".$row['time']."]</font>" // use $row['postdate'] intead of $row['time'] if you wish to show the date & time
					."`0\n`&$row[name]`0\n`& "
					.str_replace("&amp;","&",HTMLEntities(substr($row[comment],$x+strlen($ft))))
						."`0`n";
			}
		}
		if ($op[$i]=="") 
			if ($linkbios)
				$op[$i] = "<font size=1>`)[".$row['time'] // use $row['postdate'] intead of $row['time'] if you wish to show the date & time
					."]</font> `0<a href='$link' style='text-decoration: none'>`&$row[name]`0</a>`3 says, \"`#" 
					.str_replace("&amp;","&",HTMLEntities($row[comment]))."`3\"`0`n";
			else
				$op[$i] = "`0`&$row[name]`0`3 says, \"`#"
				    .str_replace("&amp;","&",HTMLEntities($row[comment]))."`3\"`0`n";
		if ($message=="X") $op[$i]="`0($row[section]) ".$op[$i];
		if ($row['postdate']>=$session['user']['recentcomments']) $op[$i]="<img src='images/new.gif' alt='&gt;' width='3' height='5' align='absmiddle'> ".$op[$i];
		addnav("",$link);
	}
[/code]

This worked for me.