<?
// Brimstone Cave
// Simple mod for use in Graveyard - allows players something to do.
// This file is not intended to "do" anything but amuse players.
// Written by Robert (Maddnet Logd) and Talisman (Dragon Prime)
// 1June2004 - 2nd version - added 2 new events
// 23May2004 - 1st version
// File available for download at Dragone Prime: http://dragonprime.cawsquad.net/
// For LotGD .97
//
// To install open shades.php ADD:  addnav("Brimstone Cave","bcave.php");
// above: addnav("The Graveyard","graveyard.php"); 
// Save and upload both shades.php and bcave.php to your main directory  - thats it!
// Enjoy!!
//
require_once "common.php"; 

addnav("things to do");  
addnav("Finger Wrestle","bcave.php?op=wrestle");  
addnav("Grab Shovel","bcave.php?op=shovel");  
addnav("Hum a tune","bcave.php?op=hum");  
addnav("Pick up Rocks","bcave.php?op=rocks"); 
addnav("Read etchings","bcave.php?op=walls"); 
addnav("Read another etching","bcave.php?op=another");
addnav("Sit Down","bcave.php?op=sit"); 
addnav("Walk Around","bcave.php?op=walk"); 
addnav("Leave");
addnav("Return to Shades","shades.php"); 

page_header("Brimstone Cave"); 
output("`c<font size='+1'>`4 Brimstone Cave</font>`c`0",true);
output(" `nYou wander around the Graveyard and come upon a Brimstone Cave. `n"); 
output(" Bored out of your mind you decided to enter this place and look around.`n"); 

if ($_GET[op]=="walk") output("`nYou are bored and decide to walk in circles, now you're dizzy.`n");

if ($_GET[op]=="sit") output(" `nYou see a large stone that is shaped like a chair and decide to sit down.`n As you sit, it seems to be quite comfortable. You drift to sleep and fall out of your chair.`n"); 

if ($_GET[op]=="rocks") output("`nSeeing many colored rocks on the ground, you decide to pick some up and look at them.`n"); 

if ($_GET[op]=="hum") output("`nThis place reminds you of one of your favorite tune's, you start humming it.`n"); 

if ($_GET[op]=="wrestle") output("`nYou fold the fingers of both hands together and prepare for the battle of the wrestling thumbs! You WIN!!!!  Pity there's no prize. Shortly afterward, this little game of yours becomes boring`n"); 

if ($_GET[op]=="walls"){ 

output("`nYou look upon a wall and notice someone etched into it . . ");
   switch(e_rand(1,4)){ 
	case 1:
	output("`%\"beware of Gorlock\"");
	break;
	case 2:
	output("`%for a good time call: 555-3525");
	break;
	case 3:
	output("`%LotGD Rocks!`n");
	break;
	case 4:
	output("`%I would rather be alive than be here");
	break;
    }
}
if ($_GET[op]=="another") output("`nAs you near another wall, you can make out what appears to be a head looking over a wall, `nnext to the words \"`&Kilroy wuz here\".`n");

if ($_GET[op]=="shovel") output("`nYou found an old shovel near a small pit that someone else dug.`nSeeing how hard the soil is here, you give up any effort to continue digging this hole.`n");

page_footer(); 
?>