<?php

// gardenflirt 1.0 (german) by anpera
// uses 'charisma' entry in database to determine how far a love goes, and 'marriedto' to know who with whom. ;)
// no changes necessary in database
// some changes in newday.php, hof.php, dragon.php, and inn.php required and in user.php optional!
// See http://www.anpera.net/forum/viewforum.php?f=27 for details
//
// translation into english by anpera

require_once "common.php";

$buff = array("name"=>"`!Lover's Protection","rounds"=>60,"wearoff"=>"`!You miss your love!.`0","defmod"=>1.2,"roundmsg"=>"Your lover inspires you to keep safe!","activate"=>"defense");

page_header("The Gardens");
if ($_GET[op]=="flirt1"){
// output("`b`c`\$IN �BERARBEITUNG`b`c`0`n");
	if ($session[user][seenlover]){
  		$sql = "SELECT name FROM accounts WHERE locked=0 AND acctid=".$session[user][marriedto]."";
  		$result = db_query($sql) or die(db_error(LINK));
		$row = db_fetch_assoc($result);
		$partner=$row[name];
		if ($partner=="") $partner = $session[user][sex]?"`^Seth`0":"`5Violet`0";
		output("You try to prepare for a flirt, but you can't think of anything else than `3 $partner`0. Maybe you should wait until tomorrow.");
 		addnav("Back to gardens","gardens.php");
	} else {
		$ppp=25; // Player Per Page to display
		if (!$_GET[limit]){
			$page=0;
		}else{
			$page=(int)$_GET[limit];
			addnav("Previous page","gardens.php?op=flirt1&limit=".($page-1)."");
		}
		$limit="".($page*$ppp).",".($ppp+1);
		if ($session[user][marriedto]==4294967295) output("You shortly think about your marriage with ".($session[user][sex]?"`^Seth`0":"`5Violet`0")." and if you should visit ".($session[user][sex]?"him":"her")." in the inn.`n");
		if($session[user][charme]==4294967295) output("You think that it is about time to take some time for your ".($session[user][sex]?"husband":"wife").". But while you're walking through the gardens you see a lot of other nice ".($session[user][sex]?"men":"women").".`n");
		output("Whom do you choose?`n`n");
  		$sql = "SELECT acctid,name,sex,level,race,login,marriedto,charisma FROM accounts WHERE 
		(locked=0) AND
		(sex <> ".$session[user][sex].") AND
		(alive=1) AND 
		(acctid <> ".$session[user][acctid].") AND
		(laston > '".date("Y-m-d H:i:s",strtotime("-346000 sec"))."' OR (charisma=4294967295 AND acctid=".$session[user][marriedto].") )
		ORDER BY charm DESC LIMIT $limit";
  		$result = db_query($sql) or die(db_error(LINK));
		output("<table border='0' cellpadding='3' cellspacing='0'><tr><td>",true);
		output(($session[user][sex]?"<img src=\"images/male.gif\">":"<img src=\"images/female.gif\">")."</td><td><b>Name</b></td><td><b>Level</b></td><td><b>Race</b></td><td><b>Status</b><td><b>Ops</b></td></tr>",true);
		if (db_num_rows($result)>$ppp) addnav("Next page","gardens.php?op=flirt1&limit=".($page+1)."");
		for ($i=0;$i<db_num_rows($result);$i++){
			$row = db_fetch_assoc($result);
	  		$biolink="bio.php?char=".rawurlencode($row[login])."&ret=".urlencode($_SERVER['REQUEST_URI']);
	  		addnav("", $biolink);
			if ($session[user][charisma]<=$row[charisma]) $flirtnum=$session[user][charisma];
			if ($row[charisma]<$session[user][charisma]) $flirtnum=$row[charisma];
	  		output("<tr class='".($i%2?"trlight":"trdark")."'><td></td><td>$row[name]</td><td>$row[level]</td><td>",true);
			switch($row['race']){
				case 0:
				output("`7Unknown`0");
				break;
				case 1:
				output("`2Troll`0");
				break;
				case 2:
				output("`^Elf`0");
				break;
				case 3:
				output("`0Human`0");
				break;
				case 4:
				output("`#Dwarf`0");
				break;
				case 5:
				output("`5Saurian`0");
				break;
			}
			output("</td><td>",true);
			if ($session[user][acctid]==$row[marriedto] && $session[user][marriedto]==$row[acctid]){
				if ($session[user][charisma]==4294967295 && $row[charisma]==4294967295){
					output("`@`bYour".($session[user][sex]?" husband":" wife")."!`b`0");
				}else if ($flirtnum>=5){
					output("`\$Proposal!`0");
				} else {	
					output("`^$flirtnum of ".$session[user][charisma]." flirts returned!`0");
				}
			} else if ($session[user][acctid]==$row[marriedto]) {
				output("Flirted ".$row[charisma]." times with you");
			} else if ($session[user][marriedto]==$row[acctid]) {
				output("Your last ".$session[user][charisma]." flirts");
			} else if ($row[marriedto]==4294967295 || $row[charisma]==4294967295){
				output("`iMarried`i");
			} else {
				output("-");
			}
			output("</td><td>[ <a href='$biolink'>Bio</a> | <a href='gardens.php?act=flirt&name=".rawurlencode($row[login])."'>Flirt</a> ]</td></tr>",true);
			addnav("","gardens.php?act=flirt&name=".rawurlencode($row[login]));
		}
		output("</table>",true);
		addnav("Back to gardens","gardens.php");
	}
} else if ($_GET[act]=="flirt"){
 	if ($session[user][goldinbank]>0) $getgold=round($session[user][goldinbank]/2);
 	$sql = "SELECT acctid,name,experience,charm,charisma,lastip,emailaddress,race,marriedto FROM accounts WHERE login=\"$_GET[name]\"";
	$result = db_query($sql) or die(db_error(LINK));
	if (db_num_rows($result)>0){
		$row = db_fetch_assoc($result);
		if ($session[user][charisma]<=$row[charisma]) $flirtnum=$session[user][charisma];
		if ($row[charisma]<$session[user][charisma]) $flirtnum=$row[charisma];
		if ($session[user][lastip]==$row[lastip] || ($session[user][emailaddress]==$row[emailaddress] && $row[emailaddress])){
			output("`\$`bYou can't do that!`b You can't flirt or marry your own characters or characters with such an grade of affinity!");
 			addnav("Back to gardens","gardens.php");
		} else if (($session[user][race]==2 && $row[race]==4) || ($session[user][race]==4 && $row[race]==2)){
			output("You wait for `6$row[name]`0 and watch ".($session[user][sex]?"ihn":"sie")." for a while. Then you decide that there is a good reason why elfs and dwarfs never will fit together.");
			output(" So you leave gardens.");
		} else if ($session[user][turns]<1){
			output("You see `6$row[name]`0 entering the gardens but suddenly you feel so tired from fighting that you decide to wait until tomorrow. ");
		} else if ($session[user][charm]<=1 && $session[user][charisma]!=4294967295){
			output("You stroll over to `6$row[name]`0. With the charm of a greenfly you begin to talk to ".($session[user][sex]?"him":"her").". Nearly offended $row[name] turns away from you and leaves the gardens.`nMaybe you should work on your charm first?");
		} else if ($row[charm]<=1 && $session[user][charisma]!=4294967295){
			output("You stroll over to `6$row[name]`0. The closer you come to ".($session[user][sex]?"him":"her")." the uglier ".($session[user][sex]?"he":"she")." seems to be. Finally ".($session[user][sex]?"he":"she")." looks so ugly to you that you walk by without a further look.");
		} else if (abs($row[charm]-$session[user][charm])>10 && $session[user][charisma]!=4294967295){
			output("You stroll over to  `6$row[name]`0. You start to talk with each other but somehow it does not want to turn into a flirt. You decide to try again later and go back into the village.");
		} else if ($session[user][drunkenness]>66){
			output("You encounter `6$row[name]`0 in the shadow of two - three ... no, two trees and somekind of walk over to ".($session[user][sex]?"him":"her").". With your boozy breath you begin to ... talk. As ".($session[user][sex]?"he":"she")." doesn't react ");
			output("in any way and still seem to stare on the ground, you dare to raise ".($session[user][sex]?"his":"her")." head on the chin - and grab fully into the thornbush infront of you.`n");
			output("With your buzz you recognized this bush as $row[name]`0!! Maybe it is better to not drink that much before a flirt.`n`n");
			output("`^This error costs you a forest fight and a charmpoint!");
			$session[user][turns]-=1;
			$session[user][charm]-=1;
		} else if (($session[user][marriedto]==4294967295 || $session[user][charisma]==4294967295) && ($row[marriedto]==4294967295 || $row[charisma]==4294967295)) { // M�glichkeiten, wenn beide verheiratet
			if ($session[user][marriedto]==$row[acctid] && $session[user][acctid]==$row[marriedto]){
				output("`%You guide ".($session[user][sex]?"your husband":"your wife")." `6$row[name]`% in the gardens where you take some time for each other. ");
				output("`nYou gain one charmpoint.");
				$session['bufflist']['lover']=$buff;
				$session['user']['charm']++;
				$session['user']['seenlover']=1;
			} else if ($session[user][charm]==$row[charm]){
				output("`%You get near to `6$row[name]`%. Immediatly a heavy flirt arises. Du get on perfectly with `6$row[name]`%!");
				output(" You find a place somewhere out of range and");
				output(" spend a few very beautiful hours together. Because both of you are married you decide that none of your partners will ever be told something about it.");
				output("`n`nYou both gain one charmpoint!");
				$session[user][charm]+=1;
				$session['user']['seenlover']=1;
				$sql = "UPDATE accounts SET charm=charm+1 WHERE acctid='$row[acctid]'";
				db_query($sql);
				systemmail($row['acctid'],"`%Gardenflirt!`0","`&{$session['user']['name']}`6 spent a few very beautiful hours with you in the gardens. You both gained one charmpoint and none of your partners should ever know about your secret.");
			} else {
				output("`%You come near to `6$row[name]`% and start to flirt like there is no tomorrow. `6$row[name]`% gets on with you, ");
				switch(e_rand(1,4)){
					case 1:
					case 2:
					output("`% and because both of you are married, you promise each other to never tell you partner about it.");
					output("`n`nYou both LOSE a charmpoint, because your bad conscience can't be hidden away from your partners!");
					$sql = "UPDATE accounts SET charm=charm-1 WHERE acctid='$row[acctid]'";
					$session[user][charm]-=1;
					systemmail($row['acctid'],"`%Gardenflirt!`0","`&{$session['user']['name']}`6 spent a few beautiful hours with you in the gardens. Both of you LOST a charmpoint because you couldn't keep the bad conscience secret for your partner.");
					db_query($sql);
					$session['user']['seenlover']=1;
					break;
					case 3:
					output("`% and because both of you are married, you promise each other to never tell you partner about it.");
					output("`n`nBoth of you gain one charmpoint!");
					$sql = "UPDATE accounts SET charm=charm+1 WHERE acctid='$row[acctid]'";
					$session[user][charm]+=1;
					systemmail($row['acctid'],"`%Gardenflirt!`0","`&{$session['user']['name']}`6 spent a few beautiful hours with you in the gardens. Both of you gained a charmpoint and keep this secret hidden for your partner.");
					db_query($sql);
					$session['user']['seenlover']=1;
					break;
					case 4:
					output(" but you were caught by ".($session[user][sex]?"your husband":"your wife")." right as it was about to become interesting.`nThe catastrophy is perfect.`0`n`n".($session[user][sex]?"Your husband":"Your wife")." leaves you"); 
					if ($session[user][charisma]==4294967295){
						output(" and gets 50% of your gold from bank");
						$sql = "UPDATE accounts SET marriedto=0,charisma=0,goldinbank=goldinbank+$getgold WHERE acctid='{$session['user']['marriedto']}'";
						db_query($sql);
						systemmail($session[user]['marriedto'],"`\$Divorce!`0","`6You caught `&{$session['user']['name']}`6 with `&{$row[name]} in the gardens and leave ".($session[user][sex]?"her":"him").".`nYou get `^$getgold`6 Gold.");
						$session[user][goldinbank]-=$getgold;
					}
					output(".`nYou lose one charmpoint.");
					$session[user][marriedto]=$row[acctid];
					$session[user][charisma]=1;
					$session['user']['seenlover']=1;
					systemmail($row['acctid'],"`%Gardenflirt!`0","`&{$session['user']['name']}`6 flirted with you and was caught by ".($session[user][sex]?"her husband":"his wife").".");
					$session[user][charm]-=1;
					addnews("`\$".$session[user][name]."`\$  was caught red-handed flirting with  $row[name] `\$in the gardens by ".($session[user][sex]?"her husband":"his wife")." and now is single again.");
					break;
				}
			}
		} else if ($session[user][marriedto]==4294967295 || $session[user][charisma]==4294967295) { // M�glichkeiten, wenn nur selbst verheiratet
			if ($session[user][marriedto]==4294967295 && $session[user][charisma]>=5){
				output("`6".($session[user][sex]?"Seth":"Violet")." jumps out of a shrubbery and insults you with heavy words, right as you get near to $row[name] `6. ".($session[user][sex]?"He":"She")."  watched your \"garden work\" quite a while!`0`n`n".($session[user][sex]?"Seth":"Violet")." leaves you.`nYou lose one charmpoint."); 
				$session[user][marriedto]=$row[acctid];
				$session[user][charisma]-=1;
				$session['user']['seenlover']=1;
				$session[user][charm]-=1;
				addnews("`\$".$session[user][name]."`\$ was caught red-handed flirting with  $row[name]`\$ in the gardens by ".($session[user][sex]?"Seth":"Violet")." and now is single again.");
			} else {
				if ($session[user][acctid]==$row[marriedto]){
					output("`%Although you are married, you respond to the flirts of $row[name]`%. You sympathize and for a short moment you forget about ".($session[user][sex]?"your husband":"your wife").". ");
				} else {
					output("`%Although you are married, you risk a flirt with $row[name]`%. You sympathize and for a short moment you forget about ".($session[user][sex]?"your husband":"your wife").". ");
				}
				switch(e_rand(1,4)){
					case 1:
					case 2:
					case 3:
					output("`% But you know that this relationship has no future as long as you are married.");
					systemmail($row['acctid'],"`%Gardenflirt!`0","`&{$session['user']['name']}`6 spent a few beautiful hours with you in the gardens.");
					$session['user']['seenlover']=1;
					if ($session[user][marriedto]==4294967295) $session[user][charisma]+=1;
					break;
					case 4:
					output(" But ".($session[user][sex]?"he":"she")." calls ".($session[user][sex]?"himself":"herself")." back in mind with a loud bang!`nThe catastrophy is perfect.`0`n`n".($session[user][sex]?"Your husband":"Your wife")." leaves you.");
					if ($session[user][charisma]==4294967295){
			 			output(" and gets 50% of your gold in bank.`nYou lose one charmpoint"); 
						$sql = "UPDATE accounts SET marriedto=0,charisma=0,goldinbank=goldinbank+$getgold WHERE acctid='{$session['user']['marriedto']}'";
						db_query($sql);
						systemmail($session[user]['marriedto'],"`\$Divorce!`0","`6You found `&{$session['user']['name']}`6 with `&{$row[name]} in the gardens and part from ".($session[user][sex]?"her":"him").".`nYou get `^$getgold`6 Gold.");
						$session[user][goldinbank]-=$getgold;
					} 
					output(".");
					$session[user][marriedto]=$row[acctid];
					$session[user][charisma]=1;
					$session['user']['seenlover']=1;
					systemmail($row['acctid'],"`%Gardenflirt!`0","`&{$session['user']['name']}`6 flirted with you in the gardens and was caught by ".($session[user][sex]?"her husbund":"his wife").".");
					$session[user][charm]-=1;
					addnews("`\$".$session[user][name]."`\$ was caught red-handed by ".($session[user][sex]?"her husband":"his wife")." while flirting in the gardens and is now single again.");
					break;
				}
			}
		} else if ($row[marriedto]==4294967295 || $row[charisma]==4294967295) { // M�glichkeiten, wenn nur Gegen�ber verheiratet
			if ($session[user][marriedto]==$row[acctid]){
				$session[user][charisma]+=1;
				$session['user']['seenlover']=1;
				output("`%You flirt the `^{$session[user][charisma]}.`% time with $row[name] `%, but you know that this flirt will stay unreturned, because $row[name]`% (still) is married.");
			} else {
				output("`%You flirt with $row[name]`% and you spend some time together in the gardens.");
				$session[user][charisma]=1;
				$session['user']['seenlover']=1;
			}
			systemmail($row['acctid'],"`%Gardenflirt!`0","`&{$session['user']['name']}`6 flirted with you in the gardens.");
			$session[user][marriedto]=$row[acctid];
		} else { // beide unverheiratet
			if ($session[user][acctid]==$row[marriedto]){
				if ($flirtnum>=5){
					output("`c`b`&Marriage!`0`b`c");
					output("`&`n`nBoth of you know each other well enough now that you decide to marry.");
					output(" The matrimony is a gigantic celebration! You really know how to celebrate.`n`nFrom noe on you are married!");
// part from free ale script
					if (getsetting("paidales",0)>=1){
						$amt=e_rand(2,6);
						output("`n$amt Ale is all that is left from your matrimony and they were spent to the inn.");
						savesetting("paidales",getsetting("paidales",0)+$amt);
					}
// end free ale
					$session[user][charisma]=4294967295;
					$sql = "UPDATE accounts SET charisma='4294967295',charm=charm+1 WHERE acctid='$row[acctid]'";
					db_query($sql);
					systemmail($row[acctid],"`&Marriage!`0","`6 After a lot of flirts in the gardens you and `&".$session['user']['name']."`& are joined today in joyous matrimony!");
					$session[user][seenlover]=1;
					$session[bufflist][lover]=$buff;
					$session[user][charm]+=1;
					$session[user][donation]+=1;
					addnews("`%".$session[user][name]." `&and `%$row[name]`& are joined today in joyous matrimony!!!");
					addnav("List of couples","hof.php?op=paare");
				} else if ($flirtnum>0){
					$session[user][charisma]+=1;
					$session['user']['seenlover']=1;
					$session[user][charm]+=1;
					output("`%You flirt the `^{$session[user][charisma]}. `%time with your love $row[name] `%.`n");
					output("You responded $flirt flirts now. If you reach  5 flirts together, $row[name] `%promisses you to marry you!");
					output("`n`n`^You gain one charmpoint.");
					systemmail($row['acctid'],"`%Gardenflirt!`0","`&{$session['user']['name']}`6 spent a few beautiful hours with you in the gardens. Now you have $flirtnum flirts together. With the 5th returned flirt you are able to marry!");
				} else {
					$session[user][charisma]+=1;
					$session['user']['seenlover']=1;
					$session[user][charm]+=1;
					output("`%You return a flirt from $row[name] `%and spend some time with ".($session[user][sex]?"him":"her")." in the gardens.`n");
					systemmail($row['acctid'],"`%Gardenflirt!`0","`&{$session['user']['name']}`6 returned your flirts and both of you spent a few beautiful housr in the gardens.");
					output("`n`n`^You gain one charmpoint.");
				}
				$session[user][marriedto]=$row[acctid];
			} else if ($session[user][marriedto]==$row[acctid]){
				$session[user][charisma]+=1;
				$session['user']['seenlover']=1;
				output("`%You flirt with $row[name] `%the `^{$session[user][charisma]}.`% time. and hope that you will get a response.");
				systemmail($row['acctid'],"`%Gardenflirt!`0","`&{$session['user']['name']}`6 spent a few beautiful hours with you in the gardens.`nDon't you want to return this?");
			} else {
				output("`%You flirt with $row[name]`% and both of you spend some time together in the gardens.");
				systemmail($row['acctid'],"`%Gardenflirt!`0","`&{$session['user']['name']}`6 spent a few beautiful hours with you in the gardens.");
				$session[user][charisma]=1;
				$session['user']['seenlover']=1;
				$session[user][marriedto]=$row[acctid];
			}
		}
	}else{
		output("`\$Error:`4 This character can't be found. May I ask how you got here?");
	}
} else {
	addcommentary();
	checkday();
	output("`b`c`2The Gardens`0`c`b");
	output("`n`n You walk through a gate and on to one of the many winding paths that makes its way through the well-tended gardens.  From the flowerbeds that bloom even in darkest winter, to the hedges whose shadows promise forbidden secrets, these gardens provide a refuge for those seeking out the Green Dragon; a place where they can forget their troubles for a while and just relax.");
	output("`n`nOne of the fairies buzzing about the garden flies up to remind you that the garden is a place for roleplaying, and to confine out-of-character comments to the other areas of the game.");
	output("`n`n");
	viewcommentary("gardens","Whisper here",30,"whispers");
	addnav("Flirt","gardens.php?op=flirt1");
}
addnav("Back to village","village.php");
page_footer();
?>
