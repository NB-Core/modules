<?
/* the picnic basket - 
   by robert of maddnet logd
   written for LoGD 097
   uses lonnys hunger and thirst mod
*/
if (!isset($session)) exit(); 
if ($HTTP_GET_VARS[op]==""){ 
    output("`n`n`2You come to a small clearing and see a blanket stretched out on the ground. On the blanket you see a flask and a picnic basket. "); 
    output("You look around and see nor hear anyone. How strange? You think to yourself.  `n`&What will you do?"); 
    addnav("the picnic basket"); 
    addnav("(B) Open the basket","forest.php?op=open"); 
    addnav("(L) Leave it there","forest.php?op=dont"); 
    $session[user][specialinc]="picnic.php"; 
}else if ($HTTP_GET_VARS[op]=="open"){ 
  if ($session[user][hunger]>=2){ 
      output("`n`2Being a little bit hungry, you peek inside and find  "); 
      $session[user][turns]--;
        switch(e_rand(1,6)){ 
          case 1: output(" the basket is empty. `nDarn it! Because now you're more hungry than before."); 
                $session[user][hunger]++; break;
	      case 2: output(" some fried chicken and eat it. `nmmmmm ... it was really good!"); 
                $session[user][hunger]--; break; 
          case 3: output(" fresh salad greens and eat it. `nmmmmm ... it was really good!"); 
                $session[user][hunger]--; break;
          case 4: output(" a sandwich and eat it. `nmmmmm ... it was really good!"); 
                $session[user][hunger]--; break;
          case 5: output(" fresh roasted fowl and eat it. `nmmmmm ... it was really good!"); 
                  output(" Just as you finish eating all the food, `nyou see Violet and Seth come out from the bushes . . .`\$how embarassing!!"); 
                $session[user][hunger]--; $session[user][charm]--; break;
          case 6: output(" its filled with Fresh Salad, Pork Chops and cake.. and eat it. `nmmmmm ... it was really good!"); 
                  output(" Just as you finish eating all the food, `nyou see Violet and Seth come out from the bushes . . .`\$oops! how embarassing!!"); 
                $session[user][hunger]-=2; $session[user][charm]--; break;
                }
}else if ($session[user][thirst]>=2){ 
      output("`n`2Being a little bit thirsty, you reach for the flask and  "); 
      $session[user][turns]--;
        switch(e_rand(1,5)){ 
          case 1: output(" find it is empty. `nDarn it! Because now you're more thirsty than before."); 
                $session[user][thirst]++; break;
	      case 2: output(" find it contains cold water and drink it. `naahhhh! ... refreshing!"); 
                $session[user][thirst]--; break; 
          case 3: output(" find some cool water in it, and drink it. `naahhhh! ... refreshing!"); 
                $session[user][thirst]--; break;
          case 4: output(" find it is empty. `nDarn it!"); break;
          case 5: output(" find it filled with wine, and drink it. `naahhhh! ... refreshing!"); 
                $session[user][thirst]--; $session[user][hitpoints]++; break;
                }
    }else{ 
      output("`2Not that the picnic basket is inviting. You decide you would rather like to lie down and rest abit "); 
      output("on the comfy looking blanket. After a quick little nap you feel better. ");
      $session[user][turns]--; $session[user][hitpoints]++;
    }
}else{ 
  output("`n`n`2Not wanting to peek inside of a simple picnic basket, you return to the forest. "); 
} 
?>