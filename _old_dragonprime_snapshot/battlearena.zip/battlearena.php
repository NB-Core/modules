<?php
//Origial 0.9.8 Conversion by Frederic Hutow
require_once("lib/http.php");
require_once("lib/villagenav.php");

function battlearena_getmoduleinfo(){
	$info = array(
		"name"=>"Battle Arena",
		"version"=>"2.12",
		"author"=>"`#Lonny Luberts",
		"category"=>"PQcomp",
		"download"=>"http://www.pqcomp.com/modules/mydownloads/visit.php?cid=3&lid=34",
		"vertxtloc"=>"http://www.pqcomp.com/",
		"prefs"=>array(
			"Battle Arena User Preference,title",
				"battlepoints"=>"Number of Battle Points Received,int|0",
				"The next values are used in battle announcements and display.,note",
				"crhealth"=>"Creature's Health,viewonly|",
				"healthtemp"=>"Creature's Temp Health,viewonly|",
				"newfight"=>"Creature's Health,viewonly|",
				"health"=>"User's Health,viewonly|",
		),
		"settings"=>array(
			"Battle Arena Settings,title",
				"leader"=>"Current Tournament Leader (userid),int|0",
				"arena_name"=>"What is the name of the Arena?,text|Battle Arena",
				"ent"=>"Entry Fee,int|50",
				"pp"=>"Display how many results with ranking page,int|50",
				"arenaloc"=>"Where does the arena appear,location|".getsetting("villagename", LOCATION_FIELDS),
				"allowspecial"=>"Allow specialties in fight?, bool|0",
				"indexstats"=>"Show Battle Arena Leader on Index Page?,bool|1",
				"display-bar"=>"Display HP Bars during battle?,bool|1",
		),
	);
	return $info;
}

function battlearena_install(){
	if (!is_module_active('battlearena')){
		debug("`4Installing Battle Arena Module.`n");
	}else{
		debug("`4Updating Battle Arena Module.`n");
	}
	module_addhook("village");
	module_addhook("index");
	module_addhook("dragonkill");
	module_addhook("namechange");
	module_addhook("biostat");
	return true;
}

function battlearena_uninstall(){
	output("`4Un-Installing Battle Arena Module.`n");
	return true;
}

function battlearena_dohook($hookname,$args){
	global $session;
	$leader = get_module_setting("leader");

	switch($hookname){
		case "village":
			if ($session['user']['location'] == get_module_setting("arenaloc")){
				tlschema($args['schemas']['fightnav']);
				addnav($args['fightnav']);
				tlschema();
				addnav(array("%s",get_module_setting("arena_name")),"runmodule.php?module=battlearena");
			}
			break;
		case "index":
			if (get_module_setting("indexstats")){
				if ($leader != 0) {
					$sql = "SELECT name FROM " . db_prefix("accounts") . " WHERE acctid='$leader'";
					$result = db_query_cached($sql, "battleleader");
					$row = db_fetch_assoc($result);
					$leadername = $row['name'];
				}
				if ($leadername) {
					output("`@The current Battle Arena Leader is: `&%s`@.`0`n",$leadername);
				} else {
					output("`@There is `&no`@ leader in the Battle Arena. Will you be the first one?`0`n");
				}
			}
			break;
		case "biostat":
			global $target;
			$bpoints = get_module_pref("battlepoints","battlearena",$target['acctid']);
			if ($bpoints > 0) output("`^Battlepoints: `@%s`0`n",$bpoints);
			break;
		case "dragonkill":
		case "namechange":
			if ($leader == $session['user']['acctid']) {
				invalidatedatacache("battleleader");
			}
			break;
	}
	return $args;
}

function battlearena_run(){
	global $SCRIPT_NAME;
	if ($SCRIPT_NAME == "runmodule.php"){
		$module = httpget("module");
		if ($module == "battlearena") include("modules/lib/battlearena.php");
	}
}

function battlearena_isnewleader() {
		$currentleader = get_module_setting("leader");
		$sql = "SELECT userid,value FROM " . db_prefix('module_userprefs') . " WHERE modulename='battlearena' AND setting='battlepoints' AND value <> '' ORDER BY value + 0 DESC LIMIT 1";
		$result = db_query($sql);
		$row = db_fetch_assoc($result);
		if ($row['userid'] != $currentleader) {
			set_module_setting("leader", $row['userid']);
			invalidatedatacache("battleleader");
		}
}
?>