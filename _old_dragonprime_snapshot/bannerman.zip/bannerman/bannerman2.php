<?php
//fix all queries
function bannerman2_getmoduleinfo(){
	$info = array(
		"name"=>"bannerman2",
		"version"=>"2.01",
		"author"=>"`#Lonny Luberts",
		"category"=>"PQcomp",
		"download"=>"http://www.pqcomp.com/modules/mydownloads/visit.php?cid=3&lid=173",
		"vertxtloc"=>"http://www.pqcomp.com/",
		"prefs"=>array(
			"Banner Manager User Preferences,title",
			"administrate"=>"Admin/Moderator Access,bool|0",
		),
	);
	return $info;
}

function bannerman2_install(){
	module_addhook("everyfooter");
	module_addhook("superuser");
	//fix sql to create table and check if install
	if (!db_table_exists(db_prefix("banners"))){
		output("Creating table: banners `n");
		$sql = "CREATE TABLE `".db_prefix("banners")."` (";
		$sql .= "`id` int(11) NOT NULL auto_increment,";
		$sql .= "`code` text NOT NULL,";
		$sql .= "PRIMARY KEY  (`id`)";
		$sql .= ") TYPE=MyISAM;";
		db_query($sql);
		output("- created successfully.`n");
	}
	return true;
}

function bannerman2_uninstall(){
	//drop the table
	$sql = "DROP TABLE ".db_prefix("banners");
    db_query($sql);
	return true;
}

function bannerman2_dohook($hookname,$args){
	global $session;
	switch ($hookname){
		case "everyfooter":
			$res = db_query("SELECT COUNT(*) as id FROM ".db_prefix("banners")."");
			$row = db_fetch_assoc($res);
			$bannercount = $row['id'];
			$whichban = e_rand(1,$bannercount);
			$res = db_query("SELECT * FROM ".db_prefix("banners")."");
			for($i=0;$i < $whichban;$i++){
				$banner = db_fetch_assoc($res);
			}
			if ($banner['code'] <> "") rawoutput("<br><center>".$banner['code']."</center>");
		break;
		case "superuser":
			if (get_module_pref('administrate')){
				addnav("Editors");
				addnav("Banner Editor","runmodule.php?module=bannerman2");
			}
		break;
	}
	return $args;
}

function bannerman2_run(){
	//have to get values
	foreach ($_GET as $key => $value) {
		$$key = $value;
	}
	foreach ($_POST as $key => $value) {
		$$key = $value;
	}
	page_header("Banner Editor");
	if ($op <> "save"){
	    $res = db_query("SELECT COUNT(*) as id FROM ".db_prefix("banners")."");
		$bannercount = db_fetch_assoc($res);
		rawoutput("Clear Banner code and save to delete a banner.<br>");
		rawoutput("Insert your Banner code as a single line with no return characters.<br>");
	    rawoutput("<form ACTION='runmodule.php?module=bannerman2' method='POST'>");
	    $res2 = db_query("SELECT * FROM ".db_prefix("banners")."");
		//will propably have to fix end of file statement here
		for ($i=1;$i<db_num_rows($res2)+1;$i++){
			$banner = db_fetch_assoc($res2);
			rawoutput("<p><input type='hidden' name='bannerid".$i."' size='20' value='".$banner['id']."'></p>");
			rawoutput("<p>Banner ".$i." Code: <textarea rows='2' name='BAN".$i."' cols='50'>".$banner['code']."</textarea></p>");
		}
		rawoutput("<p><input type='hidden' name='bcount' value='$i'></p>");
		rawoutput("<p><input type='hidden' name='bannerid".$i."' size='20' value='0'></p>");
		rawoutput("<p>Banner ".$i." Code: <textarea rows='2' name='BAN".$i."' cols='50'></textarea></p><br>");
		rawoutput("<INPUT TYPE=HIDDEN NAME=op VALUE='save'>");
		rawoutput("<p><input type='submit' value='Submit' name='B1'><input type='reset' value='Reset' name='B2'></p></form>");
		addnav("","runmodule.php?module=bannerman2");
	}else{
		rawoutput("Banner count: ".$bcount."<br>");
		for ($i=1;$i < ($bcount + 1);$i++){
			$bannerid = "bannerid".$i;
			$BAN = "BAN".$i;
			rawoutput("Banner ".$i." save operation - ");
			if (${$bannerid} == 0){
				if (${$BAN} <> ""){
					if(db_query("INSERT INTO ".db_prefix("banners")." (code) VALUES ('${$BAN}')")){
						rawoutput("Saved!<br>");
					}else{
						rawoutput("Error!<br>");
					}
				}else{
					rawoutput("Nothing to save.<br>");
				}
			}else{
				if (${$BAN} <> ""){
					if (db_query("UPDATE ".db_prefix("banners")." SET code = '${$BAN}' WHERE id = '${$bannerid}'")){
						rawoutput("Saved!<br>");
					}else{
						rawoutput("Error!<br>");
					}	
				}else{
					if (db_query("DELETE FROM ".db_prefix("banners")." WHERE id = '${$bannerid}'")){
						rawoutput("Deleted!<br>");
					}else{
						rawoutput("Error!<br>");
					}
				}
			}
		}
		rawoutput("Data Save operation complete.<br>");
		rawoutput("<p>");
	    rawoutput("<FORM ACTION=runmodule.php?module=bannerman2 METHOD=POST>");
	    rawoutput("<INPUT TYPE=HIDDEN NAME=op VALUE=''>");
	    rawoutput("<INPUT TYPE=SUBMIT VALUE=\"Return to Banner Manager\">");
	    rawoutput("</FORM>");
	    addnav("","runmodule.php?module=bannerman2");
	}
	addnav("Return to the Grotto", "superuser.php");
	page_footer();
}
?>