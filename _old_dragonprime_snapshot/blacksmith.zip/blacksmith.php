<?php

require_once("common.php");
require_once("lib/http.php");
require_once("lib/commentary.php");

function blacksmith_getmoduleinfo(){
        $info = array(
                "name"=>"Blacksmith Weapon and Armor Replacement",
                "version"=>"1.0",
                "author"=>"`4S`)ig`4g",
                "category"=>"Sigg",
                "download"=>"http://dragonprime.net/users/Sig/blacksmith.zip",
                "vertxtloc"=>"http://dragonprime.net/users/Sig/",
                "settings"=>array(
                        "Blacksmith Basics,title",
						"smith"=>"What is the name of the blacksmith?,text|`4Sichae",
                        "kills1"=>"How many monsters must users kill to get the next piece of equipment for the first tier?,int|25",
                        "kills2"=>"How many monsters must users kill to get the next piece of equipment for the second tier?,int|50",
						"kills3"=>"How many monsters must users kill to get the next piece of equipment for the third tier?,int|100",
						"kills4"=>"How many monsters must users kill to get the next piece of equipment for the fourth tier?,int|200",
						"kills5"=>"How many monsters must users kill to get the next piece of equipment for the fifth tier?,int|300",
						"Blacksmith in Town,title",
						"bsname"=>"What is the name of the blacksmith's shoppe?,text|Blacksmith's Shoppe",
						"bsloc"=>"Where does the blacksmith's shoppe appear?,location|".getsetting("villagename", LOCATION_FIELDS),
						"Equipment Strengths,title",
						"base1"=>"What is the base strength of a first tier piece of equipment?,int|1",
						"base2"=>"What is the base strength of a second tier piece of equipment?,int|7",
						"base3"=>"What is the base strength of a third tier piece of equipment?,int|13",
						"base4"=>"What is the base strength of a fourth tier piece of equipment?,int|19",
						"base5"=>"What is the base strength of a fifth tier piece of equipment?,int|25",
						"Costs,title",
						"cost1"=>"Cost in gems of first tier upgrades,int|2",
						"cost2"=>"Cost in gems of second tier upgrades,int|10",
						"cost3"=>"Cost in gems of third tier upgrades,int|50",
						"cost4"=>"Cost in gems of fourth tier upgrades,int|250",
						"cost5"=>"Cost in gems of fifth tier upgrades,int|500",
                        ),
                "prefs"=>array(
                        "Blacksmith User Preferences,title",
						"bsid"=>"Which tier is currently being used by this user?,int|0",
                        "wlvl"=>"What level is the user's weapon?,int|1",
						"alvl"=>"What level is the user's armor?,int|1",
						"wname"=>"What is the name of the user's weapon?,text|Short Sword",
						"aname"=>"What is the name of the user's armor?,text|Tunic",
						"mks"=>"How many monsters has the user killed?, int|0",
						"tempwname"=>"Temporary weapon name,hidden|null",
						"tempaname"=>"Temporary armor name,hidden|null",
						"finalwname"=>"Weapon name (with level),hidden|null",
						"finalaname"=>"Armor name (with level) ,hidden|null",
						"kills"=>"Kills needed for current tier,hidden|10"
                        ),
                );

        return $info;
}

function blacksmith_install(){
	module_addhook("header-village");
	module_addhook("village");
	module_addhook("newday");
	module_addhook("battle-victory");
	module_addhook("charstats");
	return true;
}

function blacksmith_uninstall(){
	return true;
}

function blacksmith_dohook($hookname,$args){
	global $session;
	$shopname = get_module_setting("bsname");
	switch($hookname){
		case "charstats";
			setcharstat("Personal Info","Kills",get_module_pref('mks'));
			break;
		case "header-village";
			blocknav(weapons,true);
			blocknav(armor,true);
			break;
		case "village":
		if($session['user']['location'] == get_module_setting("bsloc")) {
			tlschema($args['schemas']['marketnav']);
			addnav($args['marketnav']);
			tlschema();
			addnav(array("%s",$shopname),"runmodule.php?module=blacksmith&op=main");
		}
			break;
		case "newday":
			blacksmith_checkeq();
			break;
		case "battle-victory";
		if(get_module_pref('bsid') > 0){
			$mks = get_module_pref('mks') + 1;
			set_module_pref('mks',$mks);
			if($mks == 1){
				output("You put your first notch into this weapon.`n");
			}else{
				output("You make another notch in your weapon.  You have slain %s beasts with it.`n",$mks);
			}
		}
			break;
	}
	return $args;
}

function blacksmith_run(){
	global $session;
	$shopname = get_module_setting("bsname");
	$smith = get_module_setting("smith");
	$op = httpget("op");
	$bsid = get_module_pref("bsid");
	page_header(array("%s",$shopname));
	
	$cost1	=	get_module_setting('cost1');
	$cost2	=	get_module_setting('cost2');
	$cost3	=	get_module_setting('cost3');
	$cost4	=	get_module_setting('cost4');
	$cost5	=	get_module_setting('cost5');
	$kills1	=	get_module_setting('kills1');
	$kills2	=	get_module_setting('kills2');
	$kills3	=	get_module_setting('kills3');
	$kills4	=	get_module_setting('kills4');
	$kills5	=	get_module_setting('kills5');
	
	output("`3This is the shoppe of %s`3, the famous blacksmith.`n`n",$smith);
	output("`7On the wall you see a sign reading:`n");
	output("`6First Tier Weapon Upgrades: %s gems, %s kills`n",$cost1,$kills1);
	output("`6Second Tier Weapon Upgrades: %s gems, %s kills`n",$cost2,$kills2);
	output("`6Third Tier Weapon Upgrades: %s gems, %s kills`n",$cost3,$kills3);
	output("`6Fourth Tier Weapon Upgrades: %s gems, %s kills`n",$cost4,$kills4);
	output("`6Fifth Tier Weapon Upgrades: %s gems, %s kills`n`n",$cost5,$kills5);
	addnav("Blacksmith Options");
	switch($op){
		case "firsttime";
			set_module_pref('bsid',0);
			output("`3The smith walks up to you and says, \"Welcome friend, my name is %s`3 and I own this establishment.  ",$smith);
			output("`3I see that you've never been here before.  ");
			output("`3In this shoppe, you can buy or upgrade your very own weapon, since the people around here all prefer custom weapons.  ");
			output("`3Those idiots like MightyE just try to make a one-size-fits-all weapon, but who actually wants something like that?  ");
			output("`3Let me make you your first real weapon!\"");
			addnav("N?Name your weapons","runmodule.php?module=blacksmith&op=new");
			break;
		case "setnames1";
			set_module_pref("tempwname",httppost('wname'));
			set_module_pref("tempaname",httppost('aname'));
			$aname = get_module_pref('tempaname');
			$wname = get_module_pref('tempwname');
			output("`3Are you sure you wish to name your weapon %s`3 and your armor %s`3?",$wname,$aname);
			addnav("Decide");
			addnav("Yes","runmodule.php?module=blacksmith&op=setnames2");
			addnav("No","runmodule.php?module=blacksmith&op=new");
			break;
		case "setnames2";
			$armor = get_module_pref('tempaname');
			$weapon = get_module_pref('tempwname');
			set_module_pref('wname',$weapon);
			set_module_pref('aname',$armor);
			set_module_pref('alvl',"1");
			set_module_pref('wlvl',"1");
			$alvl = get_module_pref('alvl');
			$wlvl = get_module_pref('wlvl');
			blacksmith_setnames();
			$session['user']['weapon'] = get_module_pref('finalwname');
			$session['user']['armor'] = get_module_pref('finalaname');
			set_module_pref('bsid',(get_module_pref('bsid') + 1));
			set_module_pref('kills',(get_module_setting('kills'.get_module_pref('bsid'))));
			set_module_pref('mks',"0");
			blacksmith_checkeq();
			output("`3You put the armor on your body.  ");
			output("`3Swinging your new %s`3 around, you realize what a fine weapon it is!",$weapon);
			villagenav();
			break;
		case "upgrade";
			$choice	=	httpget("choice");
			$cost	=	get_module_setting('cost'.get_module_pref('bsid'));
			$gems	=	$session['user']['gems'];
			$armor	=	get_module_pref('aname');
			$weapon	=	get_module_pref('wname');
			$alvl	=	get_module_pref('alvl');
			$wlvl	=	get_module_pref('wlvl');
			if($choice == weapon) {
				$wlvl++;
				output("`3You hand your %s`3 to %s`3 along with %s gems and he goes to work on your weapon.",$weapon,$smith,$cost);
				set_module_pref('wlvl',$wlvl);
				set_module_pref('mks','0');
				blacksmith_checkeq();
				$session['user']['gems'] -= $cost;
				addnav("Return");
				villagenav();
			}elseif($choice == armor){
				$alvl++;
				output("`3You hand your %s`3 to %s`3 along with %s gems and he goes to work on your weapon.",$armor,$smith,$cost);
				set_module_pref('alvl',$alvl);
				set_module_pref('mks','0');
				blacksmith_checkeq();
				$session['user']['gems'] -= $cost;
				addnav("Return");
				villagenav();
			}else{
			if($alvl + $wlvl < 20 || $bsid = 5){
				output("%s`3 says \"It looks like you're ready to upgrade your weapon or armor.  It will cost you",$smith);
				output("%s gems to upgrade an item.  Which would you like to upgrade?\"",$cost);
				if($gems >= $cost) {
					addnav("W?Upgrade Weapon","runmodule.php?module=blacksmith&op=upgrade&choice=weapon");
					addnav("A?Upgrade Armor","runmodule.php?module=blacksmith&op=upgrade&choice=armor");
				}else{
					output("`n`nLooking in your gem purse, you realize you will not be able to afford to upgrade anything today.");
				}
			}else{
				output("%s`3says dumbfoundedly \"I don't think that I can upgrade these anymore!  If you want I'll make you new weapons with even more potential, but I warn you, they will start weaker than these are right now.\"",$smith);
				addnav("N?New Weapons","runmodule.php?module=blacksmith&op=new");
			}
			blacksmith_checkeq();
			addnav("Return");
			villagenav();
			}
			break;
		case "new";
			rawoutput("<form action='runmodule.php?module=blacksmith&op=setnames1' method='POST'>");
			output("%s`3 walks over to his anvil and forge as you walk aimlessly around his shop.  After a few minutes, you pass out from boredom.  When you wake, you see that the smith has finished his work.  He says:`n",$smith);
			output("`3\"Ah, a fine weapon and a fine piece of armor, now you just have to name them.\"`n`n`n`n");
			output("`3Name your weapon (Colors allowed):");
			rawoutput("<input name='wname'>");
			output("`n`n");
			output("`3Name your armor (Colors allowed):");
			rawoutput("<input name='aname'>");
			output("`n`n");
			$name = translate_inline("Name your equipment");
			rawoutput("<input type='submit' class='button' value='$name'>");
			rawoutput("</form>");
			addnav("","runmodule.php?module=blacksmith&op=setnames1");
			break;
		case "main";
			blacksmith_checkeq();
			$bsid = get_module_pref('bsid');
			$mks = get_module_pref('mks');
			$neededmks = get_module_pref('kills');
			if($bsid == 0){
				redirect('runmodule.php?module=blacksmith&op=firsttime');
			}elseif($mks >= $neededmks){
				addnav("U?Upgrade Equipment",'runmodule.php?module=blacksmith&op=upgrade');
			}
			//addnav("Force First",'runmodule.php?module=blacksmith&op=firsttime');
			addnav("Return");
			villagenav();
	}
page_footer();
}

function blacksmith_setnames(){
	$aname = get_module_pref('aname');
	$wname = get_module_pref('wname');
	$alvl = get_module_pref('alvl');
	$wlvl = get_module_pref('wlvl');
	set_module_pref('finalaname',"$aname ($alvl)");
	set_module_pref('finalwname',"$wname ($wlvl)");
	}

function blacksmith_checkeq(){
global $session;
	blacksmith_setnames();
	$bsid = get_module_pref('bsid');
if($bsid > 0){
	$wname = get_module_pref('finalwname');
	$basedam = get_module_setting('base'.get_module_pref('bsid'));
	$cwd = $session['user']['weapondmg'];
	$ewd = get_module_pref('wlvl') + $basedam;
	$aname = get_module_pref('finalaname');
	$cad = $session['user']['armordef'];
	$ead = get_module_pref('alvl') + $basedam;
	$smith = get_module_setting('smith');
	if($ewd != $cwd){
		$session['user']['attack'] -= $cwd;
		$session['user']['attack'] += $ewd;
		$session['user']['weapondmg'] = $ewd;
		$gw = 1;
	}
	if($session['user']['weapon'] != $wname){
		$session['user']['weapon'] = $wname;
		$gw = 1;
	}
	if($ead != $cad){
		$session['user']['defense'] -= $cad;
		$session['user']['defense'] += $ead;
		$session['user']['armordef'] = $ead;
		$ga = 1;
	}
	if($session['user']['armor'] != $aname){
		$session['user']['armor'] = $aname;
		$ga = 1;
	}
	if($ga && $gw){
		output("`n`n%s`3 walks over to you and hands you your %s`3 and %s`3.`n",$smith,$aname,$wname);
	}elseif($ga){
		output("`n`n%s`3 walks over to you and hands you your %s`3.`n",$smith,$aname);
	}elseif($gw){
		output("`n`n%s walks over to you and hands you your %s`3.`n",$smith,$wname);
	}
}
}

?>