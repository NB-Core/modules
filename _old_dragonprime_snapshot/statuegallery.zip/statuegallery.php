<?php
/***********************************************************************
Name: Statue Shop
Author: Eth - ethstavern(at)gmail(dot)com 
Version: 1.2
Release Date: 01-03-2006
About: Allows players to construct statues of themselves.
       Just a needless gem waste. Also features compatibility with
       the Quarry module by DaveS, which you can find here:
       http://dragonprime.net/index.php?board=17;action=display;threadid=2973
Translation compatible. No, seriously!
************************************************************************/

require_once("lib/villagenav.php");
require_once("common.php");
require_once("lib/showform.php");
require_once("lib/http.php");
require_once("lib/commentary.php");
function statuegallery_getmoduleinfo(){
    $info = array(
        "name"=>"Statue Gallery",
        "version"=>"1.2",
        "author"=>"Eth",
        "category"=>"Village",
        "download"=>"http://dragonprime.net/users/Eth/statuegallery.zip",
        "vertxtloc"=>"http://dragonprime.net/users/Eth/",
        "settings"=>array(
            "Statue Gallery - Settings,title",
			"shopname"=>"Name of Gallery?|Ye Olde Statue Gallery",
			"dklimit"=>"DK's needed to build a statue?,int|5",
			"statuegalleryloc"=>"Where does the gallery appear,location|".getsetting("villagename", LOCATION_FIELDS),
			"Statue Gallery - Cost Settings,title",
			"namecost"=>"Cost in Gems for a Name Change?,int|3",
			"desccost"=>"Cost in Gems for an Inscription Change?,int|5",
			"medium"=>"Multiplier for Medium Statue?,int|1.5",
			"large"=>"Multiplier for Large statue?,int|2.5",
			"xlarge"=>"Multiplier for Extra Large statue?,int|3.5",
			"Statue Gallery - Quarry Settings,title",
			"These settings only apply if the Quarry module by DaveS is installed,note",
			"usestone"=>"Allow the use of quarried stone too?,bool|0",
			"laborcharge"=>"How much is the labor charge in gems?,int|50",
			"stonesmall"=>"How much stone for small statue?,int|30",
			"stonemed"=>"How much stone for medium statue?,int|45",
			"stonelarge"=>"How much stone for large statue?,int|60",
			"stonexlarge"=>"How much stone for xlarge statue?,int|75",			
        ),
        "prefs"=>array(
            "Statue Gallery - User Preferences,title",
			"havestatue"=>"Does this player own a statue?,bool|0",
			"statuewhat"=>"Statue of What?,enum,0,Player,1,Pet,2,Other",
			"statuename"=>"Name of statue?|",
			"statuedesc"=>"Statue Inscription|",
			"statuetype"=>"What's the statue made of?,int|0",
			"statuesize"=>"What's the size of the statue?,int|0",
			"valuegold"=>"What's the statue's value in gold?,int|0",
			"valuegems"=>"What's the statue's value in gems?,int|0",
			"Statue Gallery - Admin Settings,title",		
			"candelete"=>"Can this admin delete statues?,bool|0",
        )
    );
    return $info;
}

function statuegallery_install(){
	if (db_table_exists(db_prefix("statues"))) {
		output("");
	}else{
	output("`6Installing the statue shop database now.`n");	
	output("`6Presto. Done.`n`n");	
	$sql = array(
		"CREATE TABLE ".db_prefix("statues")." (
		`id` TINYINT( 3 ) NOT NULL AUTO_INCREMENT ,
		`name` VARCHAR( 50 ) NOT NULL ,
		`valuegems` INT( 11 ) DEFAULT '0' NOT NULL ,
		`dk` INT( 11 ) DEFAULT '0' NOT NULL ,
		PRIMARY KEY ( `id` ))
		TYPE = InnoDB;",
		"INSERT INTO ".db_prefix("statues")." VALUES (0, 'Wood', 15, 5);",
		"INSERT INTO ".db_prefix("statues")." VALUES (0, 'Granite', 20, 5);",
		"INSERT INTO ".db_prefix("statues")." VALUES (0, 'Basalt', 23, 5);",
		"INSERT INTO ".db_prefix("statues")." VALUES (0, 'Bronze', 48, 7);",
		"INSERT INTO ".db_prefix("statues")." VALUES (0, 'Iron', 62, 8);",
		"INSERT INTO ".db_prefix("statues")." VALUES (0, 'Marble', 80, 10);",
		"INSERT INTO ".db_prefix("statues")." VALUES (0, 'Jade', 95, 15);",
		"INSERT INTO ".db_prefix("statues")." VALUES (0, 'Ivory', 85, 15);",
		"INSERT INTO ".db_prefix("statues")." VALUES (0, 'Quartz', 75, 10);",
		"INSERT INTO ".db_prefix("statues")." VALUES (0, 'Mashed Potatoes', 125, 30);",
		"INSERT INTO ".db_prefix("statues")." VALUES (0, 'Licorice Sticks', 115, 30);",
		);		
		foreach ($sql as $statement) { db_query($statement); }
	}		
	module_addhook("changesetting");
	module_addhook("moderate");
	module_addhook("village");
	module_addhook("superuser");
    return true;
}

function statuegallery_uninstall(){
	//now lets get rid of that pesky table...		
	output("`6Dropping the statuegallery table, watch out below!`n`n");	
	$sql = "DROP TABLE IF EXISTS " . db_prefix("statues");
	db_query($sql);	
    return true;
}

function statuegallery_dohook($hookname,$args){
    global $session;
    $from = "runmodule.php?module=statuegallery&";
    switch($hookname){
   	case "changesetting":
		if ($args['setting'] == "villagename") {
			if ($args['old'] == get_module_setting("statuegalleryloc")) {
				set_module_setting("statuegalleryloc", $args['new']);
			}
		}
	break;
	case "moderate":
	$args['statuegallery'] = translate_inline("Statue Gallery");
	break;
	case "superuser":
		$edit = translate_inline("Editors");
		$link = translate_inline("Statue Material Editor");
		if ($session['user']['superuser'] & SU_EDIT_MOUNTS)addnav("$edit");	
		if ($session['user']['superuser'] & SU_EDIT_MOUNTS)addnav("$link", $from."op=editor&what=view");
	break;
	case "village":
		if ($session['user']['location'] == get_module_setting("statuegalleryloc")) {
            tlschema($args['schemas']['marketnav']);
			addnav($args['marketnav']);
            tlschema();
            $shopname = translate_inline(get_module_setting("shopname"));
			addnav("$shopname","runmodule.php?module=statuegallery");
		}
		break;
	}
    return $args;
}
//here's yet another one of my "simple" projects that have grown into a monstrosity
//the things we do for the sake of vanity, eh?
function statuegallery_run() {
    global $session;
	$op = httpget('op');
	$from = "runmodule.php?module=statuegallery&";
	$shopname = translate_inline(get_module_setting("shopname"));
	page_header($shopname);
	$dklimit = get_module_setting("dklimit");
	if ($op == ""){
		output("`2Your eyes take a moment to readjust as you walk into the lobby of the gallery.`n`n");
		output("`2Here in the spacious lobby, you see various people conversing with one another,");
		output(" `2while others stroll down the two wings of the gallery, viewing the impressive statues of heroes, local and foreign, that line them from end to end.`n`n");
		addnav("Gallery Choices");
		if ($session['user']['dragonkills']>=$dklimit){
			output("`3Near the end of the lobby you catch sight of a famous local dragon killer nonchalantly disappearing into another room marked \"No Entry\".`n`n");
			addnav("`^Visit Artisans Studio",$from."op=shop&what=enter");
		}else{
			output("`2Seeing the statues, you idly wonder how one goes about commissioning such a work of art.`n`n");
		}
		addnav("Chat in Lobby",$from."op=chat");
		addnav("View Collection",$from."op=display&what=list");
		addnav("Other");
		villagenav();
	//Little area for players to chat in	
	}else if ($op == "chat"){
		addcommentary();
		output("`2You decide it would be nice to speak to others gathered in the lobby.`n`n");
		viewcommentary("statuegallery","Speak Quietly",15,"says");	
		addnav("Go Back",$from."op=");	
	//the studio, where you commission your statue	
	}else if ($op == "shop"){
		switch(httpget('what')){
			case "enter":
			$basecost = 10;
			if (get_module_pref("havestatue") == 1){
				output("`2\"Welcome back, %s`2,\" says Cragg. \"What can I do for you today?\"", $session['user']['login']);
				addnav("Choice");
				addnav("Upgrade Statue",$from."op=upgrade&what=choose");
				addnav("Retire Statue",$from."op=shop&what=sell");
			}else{
				output("`2\"G'day and well met,\" comes the gruff, yet cheerful voice of a balding dwarf as you enter the workshop.");
				output(" `2\"The name is Cragg. I take it you've come to have a statue commissioned?\"`n`n");
				output("\"Aye, of course you have. Let me explain it for you then:\"`n`n");
				output("`3\"All statues are priced based on their size and material, this includes a fee for labor as well. Other future embellishments are, of course, extra.\"`n`n", $basecost);
				if (is_module_active("quarry") && get_module_setting("usestone") == 1){
					output("`2\"Alternatively, if you have your own supply of stone quarried, we'll be happy to make use of that instead. Keep in a mind a labor charge will be included, as well.\"`n`n");
				}
				output("`3\"All statues come in varying sizes; from small mantle pieces to larger, more grandiose works of art befitting a temple or palace.\"`n`n");
				output("`3\"We also allow `2only one per person`3.");
				output(" `3Keep in mind though you can have your statue upgraded any time you wish, for a price of course. You may even retire it and have a new one commisioned.\"`n`n");
				output("`2\"Ready then? I'll guide you through the paperwork, and leave the rest up to the artisans.\"`n`n");
				addnav("Choice");
				addnav("Commision Statue",$from."op=shop&what=choose");
			}										
			break;
			case "choose":
			$material = httpget('material');
			$aname = translate_inline("`bMaterial Name`b");
			$smallcost = translate_inline("`bSmall`b");
			$stonename = translate_inline("Quarried Stone");			
			$medcost = translate_inline("`bMedium`b");
			$largecost = translate_inline("`bLarge`b");
			$xlargecost = translate_inline("`bExtra Large`b");
			$gems = translate_inline("Gems");
			$stone = translate_inline("Stone");
			$costmed = get_module_setting("medium");
			$costlarge = get_module_setting("large");
			$costxlarge = get_module_setting("xlarge");
			//if (is_module_active("quarry"))
			if ($material == "stone"){
				$stoneamt = get_module_pref("blocks","quarry");
				output("`2\"Ah, you'd rather use stone you quarried yourself, eh? Fair enough,\" Cragg says, handing you a list of prices.`n`n");				
				output("`3You currently have `^%s `&blocks of stone `3at your disposal.`n`n",$stoneamt);
				rawoutput("<table border='0' cellpadding='1'>");
				rawoutput("<tr class='trhead'><td>");
				output_notl($aname);
				rawoutput("</td><td align='center'>");
				output_notl($smallcost);			
				rawoutput("</td><td align='center'>");
				output_notl($medcost);			
				rawoutput("</td><td align='center'>");
				output_notl($largecost);			
				rawoutput("</td><td align='center'>");
				output_notl($xlargecost);
				rawoutput("</td></tr>");
				rawoutput("<tr class='".($i%2==1?"trlight":"trdark")."'>");
				rawoutput("<td>");
				output_notl("%s",$stonename);
				rawoutput("</td>");
				rawoutput("<td align='center'>");	
				$stonesmall = get_module_setting("stonesmall");				
				rawoutput("<a href='runmodule.php?module=statuegallery&op=shop&what=size&id=9999&size=0&cost=$stonesmall'>");
				output_notl("%s %s`0",get_module_setting("stonesmall"), $stone);
				rawoutput("</a>");
				addnav("","runmodule.php?module=statuegallery&op=shop&what=size&id=9999&size=0&cost=$stonesmall");
				rawoutput("</td>");
				rawoutput("<td align='center'>");
				$stonemed = get_module_setting("stonemed");
				rawoutput("<a href='runmodule.php?module=statuegallery&op=shop&what=size&id=9999&size=1&cost=$stonemed'>");
				output_notl("%s %s`0",get_module_setting("stonemed"), $stone);
				rawoutput("</a>");
				addnav("","runmodule.php?module=statuegallery&op=shop&what=size&id=9999&size=1&cost=$stonemed");
				rawoutput("</td>");
				rawoutput("<td align='center'>");
				$stonelarge = get_module_setting("stonelarge");					
				rawoutput("<a href='runmodule.php?module=statuegallery&op=shop&what=size&id=9999&size=2&cost=$stonelarge'>");
				output_notl("%s %s`0",get_module_setting("stonelarge"), $stone);
				rawoutput("</a>");
				addnav("","runmodule.php?module=statuegallery&op=shop&what=size&id=9999&size=2&cost=$stonelarge");
				rawoutput("</td>");
				rawoutput("<td align='center'>");	
				$stonexlarge = get_module_setting("stonexlarge");				
				rawoutput("<a href='runmodule.php?module=statuegallery&op=shop&what=size&id=9999&size=3&cost=$stonexlarge'>");
				output_notl("%s %s`0",get_module_setting("stonexlarge"), $stone);
				rawoutput("</a>");
				addnav("","runmodule.php?module=statuegallery&op=shop&what=size&id=9999&size=3&cost=$stonexlarge");
				rawoutput("</td></tr>");
				rawoutput("<tr class='trhead'><td colspan=5>");	
				output("There is a flat labor fee of %s gems for statues made of quarried stone.",get_module_setting("laborcharge"),true);
				rawoutput("</td></tr>");														
				//idiot-proofing is probably needed here
				rawoutput("<tr><td>Click on the price to move forward.</td></tr>");
				rawoutput("</table>",true);				
			}else{	
				$userdk = $session['user']['dragonkills'];
				output("`2\"Right then,\" Cragg says, pointing to a list of materials. \"First, choose a material you'd like your statue made from, and the size you wish it to be.\"`n`n");									
				$sql = "SELECT * FROM " . db_prefix("statues") . " WHERE dk<=$userdk ORDER BY valuegems";
				$result = db_query($sql);
				rawoutput("<table border='0' cellpadding='1'>");
				rawoutput("<tr class='trhead'><td>");
				output_notl($aname);
				rawoutput("</td><td align='center'>");
				output_notl($smallcost);			
				rawoutput("</td><td align='center'>");
				output_notl($medcost);			
				rawoutput("</td><td align='center'>");
				output_notl($largecost);			
				rawoutput("</td><td align='center'>");
				output_notl($xlargecost);
				rawoutput("</td></tr>");
				for ($i=0;$i<db_num_rows($result);$i++){
					$row = db_fetch_assoc($result);				
					rawoutput("<tr class='".($i%2==1?"trlight":"trdark")."'>");
					rawoutput("<td>");
					output_notl("%s",$row['name']);
					rawoutput("</td>");
					rawoutput("<td align='center'>");					
					rawoutput("<a href='runmodule.php?module=statuegallery&op=shop&what=size&id={$row['id']}&size=0&cost={$row['valuegems']}'>");
					output_notl("%s %s`0",$row['valuegems'], $gems);
					rawoutput("</a>");
					addnav("","runmodule.php?module=statuegallery&op=shop&what=size&id={$row['id']}&size=0&cost={$row['valuegems']}");
					rawoutput("</td>");
					rawoutput("<td align='center'>");
					rawoutput("<a href='runmodule.php?module=statuegallery&op=shop&what=size&id={$row['id']}&size=1&cost={$row['valuegems']}'>");
					output_notl("%s %s`0",round($row['valuegems']*$costmed), $gems);
					rawoutput("</a>");
					addnav("","runmodule.php?module=statuegallery&op=shop&what=size&id={$row['id']}&size=1&cost={$row['valuegems']}");
					rawoutput("</td>");
					rawoutput("<td align='center'>");					
					rawoutput("<a href='runmodule.php?module=statuegallery&op=shop&what=size&id={$row['id']}&size=2&cost={$row['valuegems']}'>");
					output_notl("%s %s`0",round($row['valuegems']*$costlarge), $gems);
					rawoutput("</a>");
					addnav("","runmodule.php?module=statuegallery&op=shop&what=size&id={$row['id']}&size=2&cost={$row['valuegems']}");
					rawoutput("</td>");
					rawoutput("<td align='center'>");					
					rawoutput("<a href='runmodule.php?module=statuegallery&op=shop&what=size&id={$row['id']}&size=3&cost={$row['valuegems']}'>");
					output_notl("%s %s`0",round($row['valuegems']*$costxlarge), $gems);
					rawoutput("</a>");
					addnav("","runmodule.php?module=statuegallery&op=shop&what=size&id={$row['id']}&size=3&cost={$row['valuegems']}");
					rawoutput("</td></tr>");								
				}			
			//idiot-proofing is probably needed here
				rawoutput("<tr><td>Click on the price to move forward.</td></tr>");
				rawoutput("</table>",true);
			}	
			if (is_module_active("quarry") && get_module_setting("usestone") == 1) addnav("`^Use Quarried Stone",$from."op=shop&what=choose&material=stone");		
			addnav("Refresh List",$from."op=shop&what=choose");						
			break;
			case "size":
			$id = httpget("id");
			$size = httpget("size");
			$cost = httpget("cost");
			$names = array(0=>"small",1=>"medium",2=>"large",3=>"extra large");
			$smallname = $names[$size];		
			$laborcharge = get_module_setting("laborcharge");	
			if (is_module_active("quarry")) $stone = get_module_pref("blocks","quarry");			
			if ($id == "9999"){
				output("`2\"A `3%s `2statue made from `^%s `&blocks of stone `2is it? Excellent choice.", $smallname,$cost);
				output(" `2I'll have a team fetch the stone from the quarry right away!\"`n`n");
				output("`2\"Now then, the final charge comes to `&%s blocks of stone`2, and `%%s gems `2for labor costs. Is this agreeable?\"`n`n", $cost,$laborcharge);
				if ($stone<$cost OR $session['user']['gems']<$laborcharge){
					output("`3Upon realizing you're lacking in either supplies or gems, you inform Cragg.`n`n");
					output("`3\"I see,\" he says, visibly disappointed. \"Perhaps you'd like to choose something more in your price range?\"`n`n");	
				}else{
					addnav("Finalize Deal",$from."op=shop&what=inscribe&stone=$cost&payment=$laborcharge");
				}
			}else{			
				$sql = "SELECT * FROM " . db_prefix("statues") . " WHERE id=$id";
				$result = db_query($sql);
				$row = db_fetch_assoc($result);
				//$sale = $cost;			
				$costmed = get_module_setting("medium");
				$costlarge = get_module_setting("large");
				$costxlarge = get_module_setting("xlarge");			
				if ($size == 0) $sale = $cost;
				else if ($size == 1) $sale = round($cost*$costmed); 
				else if ($size == 2) $sale = round($cost*$costlarge); 
				else if ($size == 3) $sale = round($cost*$costxlarge);				
				$smallname1 = strtolower($row['name']);
				output("`2\"So, you've chosen to have a `3%s `2statue made of `3%s `2built? Excellent choice.\"`n`n", $smallname,$smallname1);
				output("`2\"The total cost of statue is `%%s gems`2, this includes material and labor. Is this agreeable?\"`n`n", $sale);
				addnav("Choice");
				if ($session['user']['gems']>=$sale) {
					//If the user can afford it, let then go forward. What a bum.				
					addnav("Finalize Deal",$from."op=shop&what=inscribe&payment=$sale");
				}else{
					output("`3Upon realizing you can't afford to have this statue commissioned, you inform Cragg.`n`n");
					output("`3\"I see,\" he says, visibly disappointed. \"Perhaps you'd like to choose something more in your price range?\"`n`n");				
				}
			}
			addnav("Go Back",$from."op=shop&what=choose");					
			set_module_pref("statuetype",$id);
			set_module_pref("statuesize",$size);									
			break;
			//Is there *any* way to hook these into the word filter?			
			case "inscribe":
			set_module_pref("havestatue",1);
			$stonecost = httpget('stone');
			$finalcost = httpget('payment');			
			output("`2You hand over the final price to Cragg, who meticulously counts the gems and then places them in a box beside him.`n`n");
			output("\"Now then, for the last step: name your statue, and an inscription to go on the plaque.");			
			output(" `2These are included at no extra cost.\"`n`n");
			output("`3Name is what is listed in the Gallery.`n");			
			output("`3Inscriptions appear beneath your statue when viewed in the Gallery.`n");
			output("`3No profanity or other objectionable content.`n");
			output("`3Owners of offending statues will be tarred, feathered, cast in the dung pile, and summarily `bbanned`b for life.`n");
			$session['user']['gems']-=$finalcost;	
			if (is_module_active("quarry")) set_module_pref("blocks",get_module_pref("blocks","quarry")-$stonecost,"quarry");
			//set_module_pref($currency,get_module_pref($currency) + $quantity);		
			$row = array(
			"statuename"=>"",			
			"statuedesc"=>"",					
			);
			$statueinfo = array(
			"Add a name for the statue below. Color codes and formatting allowed.,note",
			"statuename"=>",Desc|",
			"Add an inscription below. Color codes and formatting allowed.,note",						
			"statuedesc"=>",textarea",					
			);
			rawoutput("<form action='runmodule.php?module=statuegallery&op=shop&what=done' method='POST'>");
			showform($statueinfo,$row);
			addnav("", $from . "op=shop&what=done");
			rawoutput("</form>");						
			addnav("Finish",$from."op=shop&what=done");
			break;
			case "done":
			$name = stripslashes(httppost('statuename'));			
			$desc = stripslashes(httppost('statuedesc'));
			set_module_pref("statuename",$name);			
			set_module_pref("statuedesc",$desc);						
			$type = get_module_pref("statuetype");
			$size = get_module_pref("statuesize");
			$name = get_module_pref("statuename");			
			$desc = get_module_Pref("statuedesc");
			$names = array(0=>"Small",1=>"Medium",2=>"Large",3=>"Extra Large");			
			$namedtype = translate_inline($names[$size]);
			$sql = "SELECT * FROM " . db_prefix("statues") . " WHERE id=$type";			
			$result = db_query($sql);
			$row = db_fetch_assoc($result);						
			$ofwhat = translate_inline(array(0=>"Yourself",1=>"Other Object or Person"));
			output("`2\"You've made a wise decision, friend,\" Cragg comments.");
			output(" `2\"If ever you're unhappy with an aspect of your statue, simply visit us again and we can modify that for you, for a small fee of course.\"`n`n");
			output("`2Statue Name: `3%s`n",$name);
			if ($type == "9999") output("`2Statue Type: `3Quarried Stone`n");			
			else output("`2Statue Type: `3%s`n",$row['name']);
			output("`2Statue Size: `3%s`n",$namedtype);
			output("`2Statue Inscription:`n");
			output("`3%s`n`n",$desc);
			output("`2Your statue is now viewable in the Gallery!`n`n");
			//Here's a secret: magic garden gnomes on speed are the reason why the statues get built so quickly
			break;
			case "sell":
			$refund = get_module_pref("valuegems");
			output("`2\"Aye, I'm sorry to hear you wish to retire your statue, friend.\"`n`n");
			output("`2Cragg pulls your file from a cabinet next to his desk and scans down it quickly. After a moment, he looks back up to you.`n`n");
			output("`2\"Any gems you fitted with the statue shall be returned,\" he notes. \"Any gold detail, however, isn't refundable. We're not minters, here, and don't want to run afoul of the law.");
			output(" `2As for the statue itself, it'll be kept here in storage and we're sadly unable to reimburse you for it.\"`n`n");
			output("`2Cragg offers you `%%s gems `2as a refund.`n`n", $refund);			
			addnav("Accept",$from."op=shop&what=sell-done&refund=$refund");
			break;
			case "sell-done":
			$cost = httpget('refund');
			output("`2Cragg nods.`n`n");
			output("`2\"So be it, friend,\" he says sadly. \"Your statue shall be retired and any gems fitted on it returned.\"`n`n");
			output("`2He disappears for a moment into an adjoining room, leaving you to stare at his empty desk.`n`n");
			output("`2\"I do hope you consider having another statue commissioned in the future,\" he says a moment later as he emerges from the other room with your gems in hand.`n`n");
			$session['user']['gems']+=$cost;
			set_module_pref("havestatue",0);
			set_module_pref("statuetype",0);
			set_module_pref("statuesize",0);
			set_module_pref("valuegold",0);
			set_module_pref("valuegems",0);
			break;
		}
	addnav("Other");
	addnav("Return to Shop",$from."op=shop&what=enter");
	addnav("Return to Lobby",$from."op=");
	addnav("Visit Gallery",$from."op=display&what=list");
	//Gallery listing		
	}else if ($op == "display"){
		switch(httpget('what')){
			case "list":			 			
			$subop = httpget('subop');
			$show = get_module_setting("shownum");			
			//pages
			$perpage = 10;
            if ($subop=="") $subop=1;
            $min = ($subop-1)*$perpage;
            //pages display
            $limit = "LIMIT $min,$perpage";
            $sql = "SELECT COUNT(*) AS c FROM " . db_prefix('module_userprefs') . " LEFT JOIN " . db_prefix('accounts') . " ON (acctid = userid) WHERE modulename='statuegallery' AND setting='havestatue' and value > 0 ORDER BY value + 0";           
            $result = db_query($sql);
            $row = db_fetch_assoc($result);
            $total = $row['c'];
            addnav("Pages");
            for($i = 0; $i < $total; $i+= $perpage) {
	            $pnum = ($i/$perpage+1);
	            $min = ($i+1);
	            $max = min($i+$perpage,$total);
	            addnav(array("Page %s (%s-%s)", $pnum, $min, $max), "runmodule.php?module=statuegallery&op=display&what=list&subop=$pnum");
            }          
        $sql = "SELECT userid,name,value FROM " . db_prefix('module_userprefs') . " LEFT JOIN " . db_prefix('accounts') . " ON (acctid = userid) WHERE modulename='statuegallery' AND setting='havestatue' and value > 0 ORDER BY value + 0 DESC,name";                
        $result = db_query($sql);
        $count = db_num_rows($result);
        if ($count == 0){
			output("`6No statues are on display yet.`n`n");				
		}else{	
	        output("<table cellspacing=0 cellpadding=2 width='500' align='center'><tr><td>`bNumber`b</td><td>`bPlayer Name`b</td><td>`bStatue Name`b</td></tr>",true);    
	        for ($i=0;$i<db_num_rows($result);$i++){
	        $row = db_fetch_assoc($result);  
	        $statuename = get_module_pref('statuename', 'statuegallery', $row['userid']);                         
	        $delconfirm = translate_inline("Are you sure you wish to delete this Statue?");
	        $candelete = get_module_pref("candelete");
	        output("<tr class='".($i%2?"trlight":"trdark")."'>",true);        
	        output("<td>%s</td>",$i+1,true); 
	        output("<td>%s</td>",$row['name'],true);        	
        	if ($session['user']['superuser']&& $candelete == 1){
	        	output("<td>",true);
	        	$delete = translate_inline("Delete");
		   		output("<a href=\"runmodule.php?module=statuegallery&op=display&what=viewdetail&id={$row['userid']}\">$statuename</a>", true);      	 	   
				addnav("","runmodule.php?module=statuegallery&op=display&what=viewdetail&id={$row['userid']}");             
	        	output(" [<a href=\"runmodule.php?module=statuegallery&op=display&what=sudelete&id={$row['userid']}\" onClick='return confirm(\"$delconfirm\");'>$delete</a>]", true);   	   
				addnav("","runmodule.php?module=statuegallery&op=display&what=sudelete&id={$row['userid']}");                         
	        	output("</td></tr>",true);
        	}else{	
	        	output("<td>",true);
		   		output("<a href=\"runmodule.php?module=statuegallery&op=display&what=viewdetail&id={$row['userid']}\">$statuename</a>", true);      	 	   
				addnav("","runmodule.php?module=statuegallery&op=display&what=viewdetail&id={$row['userid']}");             
	        	output("</td></tr>",true);
        	}
	        }
	        //More idiot-proofing. 
	        rawoutput("<tr><td colspan=5>Click on the statue's name to view it's description.</td></tr>");      
	        output("</table>",true);  
    	}      
		break;
		case "viewdetail":
		$id = httpget('id');			
		$sql = "SELECT userid,name,value FROM " . db_prefix('module_userprefs') . " LEFT JOIN " . db_prefix('accounts') . " ON (acctid = userid) WHERE userid = $id AND modulename='statuegallery' AND setting='havestatue' and value > 0 ORDER BY value + 0 DESC,name"; 
		$result = db_query($sql);
        $row = db_fetch_assoc($result);
		output("Viewing details for statue:`n`n");
		$statuename = get_module_pref('statuename', 'statuegallery', $row['userid']);
		$statuetype = get_module_pref('statuetype', 'statuegallery', $row['userid']);
		$statuedesc = get_module_pref('statuedesc', 'statuegallery', $row['userid']);
		$statuesize = get_module_pref('statuesize', 'statuegallery', $row['userid']);		
		$sql1 = "SELECT name FROM " . db_prefix("statues") . " WHERE id='$statuetype'";				
		$result1 = db_query($sql1);
		$row1 = db_fetch_assoc($result1);		
		$names = array(0=>"Small",1=>"Medium",2=>"Large",3=>"Extra Large");
		$size = translate_inline($names[$statuesize]); 
		output("`2Statue Owner: `3%s`n", $row['name']);
		output("`2Statue Name: `3%s`n",$statuename);
		if ($statuetype == "9999") output("`2Statue Type: `&Quarried Stone`n");
		else output("`2Statue Type: `3%s`n",$row1['name']);
		output("`2Statue Size: `3%s`n",$size);
		output("`2Statue Inscription:`n");
		output("`3%s`n`n",$statuedesc);
		output("`2Statue is befitted with `%%s gems`2.`n", get_module_pref('valuegems', 'statuegallery', $row['userid']));
		output("`2Statue is plated with a value of `^%s gold`2.`n`n", get_module_pref('valuegold', 'statuegallery', $row['userid']));
		break;
		case "sudelete":
		$id = httpget('id');
		output("`2Statue has been deleted and a message sent to the player in question.`n`n");
		set_module_pref("havestatue",0,"statuegallery",$id);
		set_module_pref("statuetype",0,"statuegallery",$id);
		set_module_pref("statuesize",0,"statuegallery",$id);
		set_module_pref("valuegold",0,"statuegallery",$id);
		set_module_pref("valuegems",0,"statuegallery",$id);
		//send a mail(for the clueless)
		require_once("lib/systemmail.php");
		$subject = translate_inline("Your Statue was Deleted.");
		$mailmessage="".$session['user']['name']." `2has deleted your statue due to possible offensive content and/or a violation of the rules.`n`nLet's be more mindful next time, shall we?";			
		$message = translate_inline($mailmessage);
		systemmail($id,$subject,$message);			
		break;
	}
	addnav("Other");
	addnav("Gallery Listing",$from."op=display&what=list");		
	addnav("Return to Lobby",$from."op=");	
	//Ties in with the shop, upgrade statues here						
	}else if ($op == "upgrade"){	
		switch (httpget('what')){
			case "choose":
			output("`2\"So you're interested in making some changes to your statue?\" Cragg asks. \"Well then, what would you like to have done?\"`n`n");
			//for the time being, these are commented out until I can work out the pricing scheme
			//They *are* fully functioning, however.
			//addnav("Change Material",$from."op=upgrade&what=material");
			//addnav("Change Size",$from."op=upgrade&what=size");
			addnav("Change Name",$from."op=upgrade&what=text&change=name");
			addnav("Change Inscription",$from."op=upgrade&what=text&change=desc");
			addnav("Fit with Jewels",$from."op=upgrade&what=detail");
			addnav("Detail with Gold",$from."op=upgrade&what=detail");
			break;
			case "material":
			output("`2\"Right, what kind of material would you like your statue refitted with?\"`n`n");
			//
			$userdk = $session['user']['dragonkills'];
			$sql = "SELECT * FROM " . db_prefix("statues") . " ORDER BY valuegems";
			$result = db_query($sql);
			$aname = translate_inline("`bMaterial Name`b");			
			$gems = translate_inline("Gems");
			rawoutput("<table border='0' cellpadding='1'>");
			rawoutput("<tr class='trhead'><td>");
			output_notl($aname);
			rawoutput("</td><td align='center'>");
			output_notl($smallcost);			
			rawoutput("</td></tr>");
			for ($i=0;$i<db_num_rows($result);$i++){
				$row = db_fetch_assoc($result);				
				rawoutput("<tr class='".($i%2==1?"trlight":"trdark")."'>");
				rawoutput("<td>");
				output_notl("%s",$row['name']);
				rawoutput("</td>");
				rawoutput("<td align='center'>");					
				rawoutput("<a href='runmodule.php?module=statuegallery&op=upgrade&what=material-done&id={$row['id']}&cost={$row['valuegems']}'>");
				output_notl("%s %s`0",$row['valuegems'], $gems);
				rawoutput("</a>");
				addnav("","runmodule.php?module=statuegallery&op=upgrade&what=material-done&id={$row['id']}&cost={$row['valuegems']}");
			rawoutput("</td></tr>");								
			}
			rawoutput("</table>",true);			
			addnav("Refresh List",$from."op=upgrade&what=material");
			addnav("Go Back",$from."op=upgrade&what=choose");						

			break;
			case "material-done":
			$type = httpget('id');
			$cost = httpget('cost');
			if ($session['user']['gems']>=$cost){
			output("Type is %s`n`n",$type);
			set_module_pref("statuetype",$type);
			$sql = "SELECT * FROM " . db_prefix("statues") . " WHERE id=$type";
			$result = db_query($sql);
			$row = db_fetch_assoc($result);			
			output("`2\"You got it. Your statue shall be recast in `3%s`2,\" Cragg informs you.`n`n", $row['name']);
			$session['user']['gems']-=$cost;
			}else{
				output("`2\"Erm,\" Cragg sputters. \"I'm afraid you haven't enough gems for that material.\"`n`n");
			}
			addnav("Go Back",$from."op=upgrade&what=choose");
			break;
			case "size":
			output("`2\"Alright,\" Cragg says. \"You want to change the size of your statue?");
			output(" `2That'll cost %s gems, for time and labor.\"`n`n");
			$row = array(
			"statuesize"=>"",								
			);
			$statueinfo = array(			
			"statuesize"=>"Statue Type,enum,0,Small,1,Medium,2,Large,3,Extra Large",								
			);
			rawoutput("<form action='runmodule.php?module=statuegallery&op=upgrade&what=size-done' method='POST'>");
			showform($statueinfo,$row);
			addnav("", $from . "op=upgrade&what=size-done");
			rawoutput("</form>");
			break;
			case "size-done":
			$size = httppost('statuesize');	
			set_module_pref("statuesize",$size);
			output("`2\"Duelly noted, friend,\" Cragg says. \"The artisans will be at work right away.\"`n`n");	
			addnav("Go Back",$from."op=upgrade&what=choose");
			break;
			case "text":
			$change = httpget('change');
			$name = stripslashes(httppost('statuename'));
			$namecost = get_module_setting("namecost");
			$desccost = get_module_setting("desccost");
			output("`2\"Oh? You want to change the name or inscription on your plaque?`n`n");
			output(" `2Changing the name costs `%%s gems`2, while changing the inscription costs `%%s gems`2.\"`n`n",$namecost,$desccost);
			output("`3`iIf you don't want to change a field, you can simply leave it blank.`n`n");
			$row = array(
			"statuename"=>"",			
			"statuedesc"=>"",					
			);
			if ($change == "name"){
			$cost = $namecost;
			$statueinfo = array(
				"Add a name for the statue below. Color codes and formatting allowed.,note",
				"statuename"=>",Desc|",
				"namecost"=>"Cost: $namecost Gems,note",					
			);
			}else if ($change == "desc"){
			$cost = $desccost;
			$statueinfo = array(
				"Add an inscription below. Color codes and formatting allowed.,note",						
				"statuedesc"=>",textarea",
				"desccost"=>"Cost: $desccost Gems,note",					
			);
			}
			rawoutput("<form action='runmodule.php?module=statuegallery&op=upgrade&what=text-done&cost=$cost' method='POST'>");
			showform($statueinfo,$row);
			addnav("", $from . "op=upgrade&what=text-done&cost=$cost");
			rawoutput("</form>");
			addnav("Go Back",$from."op=upgrade&what=choose");
			break;
			case "text-done":
			$cost = httpget('cost');
			$name = stripslashes(httppost('statuename'));
			$desc = stripslashes(httppost('statuedesc'));
			if ($session['user']['gems']>=$cost){
				output("`2\"Right then, I'll have that taken care of at once,\" Cragg notes happily.`n`n");
				output("`^That cost %s gems.`n`n", $cost);
				if ($name>"")set_module_pref("statuename",$name);			
				if ($desc>"") set_module_pref("statuedesc",$desc);
				$session['user']['gems']-=$cost;
			}else{
				output("`2\"Sorry,\" Cragg notes. \"You don't seem to have enough for that.\"`n`n");
			}
			addnav("Go Back",$from."op=upgrade&what=choose");
			break;
			case "detail":
			output("`2Want a little extra flair to your statue, eh?\" Cragg asks with a smirk.`n`n");
			output("`2\"Aye, we can do that. You can fit your statue with extra gems, or have the coins you carry melted down and then applied as gold leaf.\"`n`n");
			output("`3`iIf you don't want to change a field, you can simply leave it blank.`n`n");
			$row = array(
			"valuegems"=>"",			
			"valuegold"=>"",					
			);
			$statueinfo = array(
			"valuegems"=>"Gems to Add,int|0",			
			"valuegold"=>"Gold to Add,int|0",					
			);
			rawoutput("<form action='runmodule.php?module=statuegallery&op=upgrade&what=detail-done' method='POST'>");
			showform($statueinfo,$row);
			addnav("", $from . "op=upgrade&what=detail-done");
			rawoutput("</form>");
			addnav("Go Back",$from."op=upgrade&what=choose");
			break;
			case "detail-done":
			$gold = httppost('valuegold');
			$gems = httppost('valuegems');
			if ($gold == "") $gold = 0;
			if ($gems == "") $gems = 0;
			if ($session['user']['gold']>=$gold){
				output("`2\"I'll see to it that these coins are melted down and turned into some marvelous detailing for your statue, %s`2.`n`n", $session['user']['login']);
				set_module_pref("valuegold",get_module_pref("valuegold")+$gold);
				$session['user']['gold']-=$gold;
			}else{
				output("`2\"Afraid you don't have that sum of gold for the detail, friend.\"`n`n");	
			}			
			if ($session['user']['gems']>=$gems){
				output("`2\"Right then,\" Cragg says, taking your gems. \"Your statue shall be fitted with `%%s gems`2.`n`n", $gems);
				set_module_pref("valuegems",get_module_pref("valuegems")+$gems);
				$session['user']['gems']-=$gems;
			}else{
				output("`2\"Sorry, %s`2,\" Cragg notes. \"You don't have that many gems.\"`n`n", $session['user']['login']);
			}
			addnav("Go Back",$from."op=upgrade&what=choose");
			break;			
						
		}
	addnav("Other");
	addnav("Return to Shop",$from."op=shop&what=enter");
	addnav("Return to Lobby",$from."op=");
	//What's a mod from me without an editor? Hah. 
	//Add materials here						
	}else if ($op == "editor"){
		$id = httpget('id');
		$cat = httpget('cat');		
		$itemarray=array(
			"Item Properties,title",
			"id"=>"Item ID,hidden",								
			"name"=>"Material Name,Name|",
			"valuegems"=>"Item Cost in Gems,int|0",
			"dk"=>"DK's needed to buy,int|0",
			);	
			switch (httpget('what')){
				case "view":							
				$edit = translate_inline("Edit");
				$del = translate_inline("Delete");				
				$delconfirm = translate_inline("Are you sure you wish to delete this item?");	
				$sql = "SELECT * FROM " . db_prefix("statues") . " WHERE id>=0 ORDER BY valuegems";				
				$result = db_query($sql);
				$count = db_num_rows($result);								
				if ($count == 0){
				output("`6No Materials on record yet.");				
				}else{				
    			output("<table cellspacing=0 cellpadding=2 width='100%' align='center'><tr><td>`bOps`b</td><td>`bItem ID`b</td><td>`bMaterial Name`b</td><td>`bCost Gems`b</td><td>`bDK Req`b</td></tr>",true);      			
    			$result = db_query($sql);
    			for ($i=0;$i<db_num_rows($result);$i++){
				$row = db_fetch_assoc($result);
    			output("<tr class='".($i%2?"trlight":"trdark")."'>",true); 
    			rawoutput("<td>[<a href='runmodule.php?module=statuegallery&op=editor&what=edit&id={$row['id']}'>$edit</a>|<a href='runmodule.php?module=statuegallery&op=editor&what=delete&id={$row['id']}' onClick='return confirm(\"$delconfirm\");'>$del</a>]</td>");   	   
    			addnav("","runmodule.php?module=statuegallery&op=editor&what=edit&id={$row['id']}");
				addnav("","runmodule.php?module=statuegallery&op=editor&what=delete&id={$row['id']}"); 
    			output("<td>`6%s</td>",$row['id'],true);
				output("<td>%s</td>",$row['name'],true);    			
    			output("<td>`%%s Gems</td>",$row['valuegems'],true); 
    			output("<td>`@%s</td>",$row['dk'],true);   	       			    	
    			output("</tr>",true);    			
    			}    	
   				output("</table>",true);
				}
				break;
	
				break;
				case "add":
				$row=array(				
					"id"=>"",									
					"name"=>"",
					"valuegems"=>"",				
					"dk"=>"",
				);
				rawoutput("<form action='runmodule.php?module=statuegallery&op=editor&what=save&id=$id' method='POST'>");
				addnav("","runmodule.php?module=statuegallery&op=editor&what=save&id=$id");				
				showform($itemarray,$row);
				rawoutput("</form>");							
				break;
				case "edit":
				$sql = "SELECT * FROM " . db_prefix("statues") . " WHERE id='$id'";				
				$result = db_query($sql);
				$row = db_fetch_assoc($result);
				rawoutput("<form action='runmodule.php?module=statuegallery&op=editor&what=save&id=$id' method='POST'>");
				addnav("","runmodule.php?module=statuegallery&op=editor&what=save&id=$id");				
				showform($itemarray,$row);
				rawoutput("</form>");			
				break;
				case "save":				
				$itemid = httppost('id');				
				$name = stripslashes(httppost('name'));				
				//catch the submitted value, check to see if it's empty. if it is, declare it as 0 and move on
				//if it isn't, use original value instead. This fixes an sql error due to lazy admins :P
				$valuegems = httppost('valuegems');
				if ($valuegems == "") $valuegems = 0;
				else $valuegems = httppost('valuegems');
				$dk = httppost('dk');
				if ($dk == "") $dk = 0;
				else $dk = httppost('dk');
				//
				if ($itemid>0){
				$sql = "UPDATE ".db_prefix("statues")." SET name=\"$name\",valuegems=$valuegems,dk=$dk WHERE id=$itemid";
					output("`6The material \"`^$name`6\" has been successfully edited.`n`n");
				}else{					
					$sql = "INSERT INTO ".db_prefix("statues")." (name,valuegems,dk) VALUES (\"$name\",$valuegems,$dk)";					
				output("`6The material \"`^$name`6\" has been saved to the database.`n`n");				
				}
				db_query($sql);				  
				$op = "";
				httpset("op", $op);							
				break;
				case "delete":				
				$sql = "DELETE FROM " . db_prefix("statues") . " WHERE id='$id'";
				db_query($sql);
				output("Item deleted!`n`n");
				redirect($from."op=editor&what=view");				
				$op = "";
				httpset("op", $op);
				break;				
				}
   				modulehook("statuegallery-editor", array());      
    			addnav("Functions");
				addnav("Admin Tools");
    			addnav("Add a Material", $from."op=editor&what=add");     			
    			addnav("View/Refresh List", $from."op=editor&what=view");    			
    			addnav("Other");	
				addnav("Return to the Grotto", "superuser.php");
		}			
	page_footer();
}
?>