****************************************************************
Name: Statue Gallery
Author: Eth - ethstavern(at)gmail(dot)com 
Version: 1.2
Release Date: 01-06-2006
About: Readme file for statuegallery.zip
Files: statuegallery.php
***************************************************************

To install, drop into your modules directory and activate 
via the Modules Manager. 

Allows players to commission statues of themselves to be built and put on display.
A vanity item more or less, and allows for bragging rights. Also includes compatibility
with the Quarry module by DaveS. 