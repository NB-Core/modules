<?
/* Santa workshop made by Adam Reimer
Orochi@glebeci.ca
Nick: Orochi
Forest event
Please email me if you use this....

WARNING: *** THE REWARDS ARE A LITTLE HIGH.... YOU MAY WANT TO LOWER THEM ***
*/
if (!isset($session)) exit();
if ($HTTP_GET_VARS[santa]==""){
  output("`@You stumble across a clearing. You notice there are `^3 odd candy houses,`^a barn,`#and a factory with large smokestacks.`n");
	output("  `@.Each house has a wreath with a picture on it. On the first wreath there is `#A Candy Cane`n");
	output("  `@.On the second house there is `% A Jolly Old Man`n");
	output("  `@.On the third house there is `^An Old Elf.`n");
	output("  `@.Behind the Factory you see an Odd glowing light`n");
	output("  `@You know that if this isent the real santa's workshop, then it will cost you one forest fight.`n`n`n");
	addnav("Go To the `#CandyCane House","forest.php?santa=candycane");
	addnav("Go To the `%Jolly Old Man House","forest.php?santa=santa");
	addnav("Go To the `^Old Elf House","forest.php?santa=elfhouse");
	addnav("Go To the Barn","forest.php?santa=reindeer");
	addnav("Go To The Factory","forest.php?santa=factory");
	addnav("Investigate The Light","forest.php?santa=light");
	addnav("Leave the Alter Undisturbed","forest.php?santa=goodbye");
	$session[user][specialinc] = "santa.php";

}else if ($HTTP_GET_VARS[santa]=="candycane"){
  $session[user][turns]++; 
  output("`# You enter the house with the Candy Cane wreath. Mrs. Claus is here baking cookies. `n`n She is startled to see you, but welcomes you all the same. She offeres you some Milk And Cookies, Which you accept Graciously. `n`n When your finished, you seem to be back in the outskirts of the forest, the house has disappeared. `n`n`n Your magic has increased by 3.`n You gain 1000 Gold and Gems.`n You gain 500 experience.`n You find youself extremly energetic (+5 turns) `n Your Attack and Defence has grown by 5");
		$session[user][magic] = $session[user][magic] + 3;
		$session[user][magicuses]++;
		$session[user][gold]+=1000;
		$session[user][gems]+=1000;
		$session[user][experience]+=500;
		$session[user][turns]+=5;
		$session[user][attack]+=5;
		$session[user][defence]+=5;      
	addnav("Return to the forest","forest.php");
	addnews($session[user][name]. " `@met Mrs. Clause today and was offered Milk And Cookies. Because of the `^mystical Powers `@in the cookies, ". ($session [user] [sex]? "she":"he") ." has gained alot of stats... `#YOU `@ should try and find the mystical `7 Santa's Workshop!!!!");
	$session[user][specialinc]="";
}else if ($HTTP_GET_VARS[santa]=="santa"){
  $session[user][turns]++; 
  output("`# You enter the house with the Jolly Old Man wreath. . `n`n`n Santa looks at you, clearly expecting you (how creepy you think). Slowly walking towards you, he invites you into his sleigh. Accepting, you get into his sleigh and marvel at the sights you see as you fly back to the village. Santa drops you right outside the Boars Head Inn. `n Getting out, you thank Santa for getting you back to the forest. Santa Reaches into his bag and take two presents from his sack. `n When you open the first one, you feel odd..... and the second one has two bags inside. `n`n`n `^Your magic has increased by 3.`n You gain 3000 Gold and Gems.`n You gain 1500 experience.`n You find youself extremly energetic (+5 turns) `n`n`n`n");
		$session[user][magic] = $session[user][magic] + 3;
		$session[user][magicuses]++;
		$session[user][gold]+=3000;
		$session[user][gems]+=3000;
		$session[user][experience]+=1500;
		$session[user][turns]+=10;
		$session[user][attack]+=0;
		$session[user][defence]+=0;      
	addnav("Enter the inn","inn.php");
	addnav("Return to the village","village.php");
	addnav("Return to the forest","forest.php");
	addnews($session[user][name]. " `@Met the big man himself today. Scince ". ($session [user] [sex]? "she":"he") ." was really polite, santa let him rest up and then drove him home in his sleigh. Also, santa decided to give him an early present...  `#Wait a minute... maybe YOU `@ should try and find the mystical `7 Santa's Workshop!!!!");
	$session[user][specialinc]="";
}
?>