<?php
/*
* History:   1.2 adds an admin config for 'who'
* History:   1.1 adds the download link missing from 1.0
* Date:      January 26, 2005
* Version:   1.0, Robert of Maddnet / Converted by: Kevin Hatfield - Arune
* LOGD VER:  Forest event converted from v097 to v1.0 compliance
*/
function smile_getmoduleinfo(){
   $info = array(
    "name"=>"Guiniveres Smile",
    "version"=>"1.2",
    "author"=>"`2Robert `7- Converted By: Arune",
    "category"=>"Forest Specials",
    "download"=>"http://dragonprime.net/users/Robert/smile098.zip",
    "settings"=>array(
	"Guiniveres Smile Settings,title",
	"who"=>"Name of person, must be Female! ,|`!Lady Guinivere",
	"where"=>"Name of city they are from? ,|Camelot"
	),
    );
    return $info;
}

function smile_install(){
        module_addeventhook("forest", "return 100;");
        return true;
}

function smile_uninstall(){
        return true;
}

function smile_dohook($hookname,$args){
        return $args;
}

function smile_runevent($type){
global $session;
$who = get_module_setting("who");
$where = get_module_setting("where");
output("`n`n`^ You step aside to make way for a traveler on horseback. Oh my! you say.`n"); 
output(" You notice the traveler is %s `^of %s `^.  As she is passing by you . .`n",$who,$where); 
output(" She is smiling and seems to be admiring your %s or maybe you.`n`n",$session['user']['armor']); 
output(" You are `imore charming`i than you think! "); 
$session['user']['charm']++; 
}
function smile_run(){
}
?>