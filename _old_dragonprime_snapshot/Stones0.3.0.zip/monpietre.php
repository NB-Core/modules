<?php
/* This file is part of "Magic Stones"
* made by Excalibur, refer to pietre.php
* for instructions and copyright notice */
require_once "common.php";
page_header("Aris' Stones");
addnav("V?Back to Village","village.php");
addnav("F?Back to Forest","forest.php");
output("`!`b`c<font size='+1'>Aris' Stones</font>`c`b`n`n",true);
output("`@You want to know who are the owner of `&Aris' Stones`@ and if any of them are still available ?`n");
output("Here we go, my young warrior.`n");
output("<table cellspacing=2 cellpadding=2 align='center'>",true);
output("<tr bgcolor='#FF0000'><td align='center'>`&`bStone N�`b</td><td align='center'>`&`bStone`b</td><td align='center'>`b`&Warrior`b</td></tr>",true);
for ($i = 1; $i < 21; $i++){
    $sql = "SELECT owner FROM pietre WHERE pietra=$i";
    $result = db_query($sql);
    $row = db_fetch_assoc($result);
    if (db_num_rows($result) == 0) {
        $rown[name]="`b`\$Available`b";
        $pietra1="`5Unknown";
    }else {
          $pietra1=$pietre[$i];
          $sqln="SELECT name FROM accounts WHERE acctid = {$row['owner']}";
          $resultn = db_query($sqln);
          $rown = db_fetch_assoc($resultn);
    }
    if ($rown[name] == $session[user][name]) {
        output("<tr bgcolor='#007700'>", true);
    } else {
        output("<tr class='" . ($i % 2?"trlight":"trdark") . "'>", true);
        }
    output("<td align='center'>`&".$i."</td><td align='center'>`&`b$pietra1`b</td><td align='center'>`&`b{$rown[name]}`b</td></tr>",true);
}
output("</table>", true);
page_footer();
?>