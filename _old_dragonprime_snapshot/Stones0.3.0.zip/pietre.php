<?php
/*
/ pietre.php - Magic Stones V0.3.0
/ Originally by Excalibur (www.ogsi.it)
/ English cleanup by Talisman (dragonprime.cawsquad.net)
/ Contribution LonnyL (www.pqcomp.com)
/ Original concept from Aris (www.ogsi.it)
/ July 2004

----install-instructions--------------------------------------------------
DIFFICULTY SCALE: easy

Forest Event for LotGD 0.9.7
Drop into your "Specials" folder
--------------------------------------------------------------------------
SQL Modification
#
# Table structure `pietre`
#

CREATE TABLE `pietre` (
  `pietra` int(4) unsigned NOT NULL default '0',
  `owner` int(4) unsigned NOT NULL default '0'
) TYPE=MyISAM;

--------------------------------------------------------------------------
----- In File:
newday.php

----- Find:
    $session['user']['bounties'] = 0;
}

----- Add after:
//Modification for pietre.php
$owner1=$session['user']['acctid'];
$sql="SELECT * FROM pietre WHERE owner=$owner1";
$result = db_query($sql);
$pot = db_fetch_assoc($result);
if (db_num_rows($result) != 0) {
    $flagstone=$pot['pietra'];
    switch ($flagstone) {
    case 1:
         output("`n`n`%Poich� possiedi la {$pietre[$flagstone]}`% della `&Fonte di Aris`% perdi un combattimento supplementare !`n");
         $session['user']['turns']-=1;
    break;

    case 2:
         output("`n`n`%Poich� possiedi la {$pietre[$flagstone]}`% della `&Fonte di Aris`% guadagni un punto di fascino !`n");
         $session['user']['charm']+=1;
    break;

    case 3:
         output("`n`n`%Poich� possiedi la {$pietre[$flagstone]}`% della `&Fonte di Aris`% guadagni un combattimento supplementare !`n");
         $session['user']['turns']+=1;
    break;

    case 4:
         output("`n`n`%Poich� possiedi la {$pietre[$flagstone]}`% della `&Fonte di Aris`% guadagni 300 pezzi d'oro !`n");
         $session['user']['gold']+=300;
    break;

    case 5:
         output("`n`n`%Poich� possiedi la {$pietre[$flagstone]}`% della `&Fonte di Aris`% guadagni potenza in attacco !`n");
         $session[bufflist][120] = array("name"=>"{$pietre[$flagstone]}","rounds"=>200,"wearoff"=>"`4La luminescenza scompare dalla tua {$pietre[$flagstone]}.","atkmod"=>1.3,"roundmsg"=>"`4La {$pietre[$flagstone]} potenzia il tuo attacco!.","activate"=>"offense");
    break;

    case 6:
         output("`n`n`%Poich� possiedi la {$pietre[$flagstone]}`% della `&Fonte di Aris`% la tua difesa viene potenziata !`n");
         $session[bufflist][120] = array("name"=>"{$pietre[$flagstone]}","rounds"=>200,"wearoff"=>"`4La luminescenza scompare dalla tua {$pietre[$flagstone]}.","defmod"=>1.3,"roundmsg"=>"`4La {$pietre[$flagstone]} potenzia la tua difesa!.","activate"=>"offense");
    break;

    case 7:
         output("`n`n`%Poich� possiedi la {$pietre[$flagstone]}`% della `&Fonte di Aris`% attacchi e difendi meglio !`n");
         $session[bufflist][120] = array("name"=>"{$pietre[$flagstone]}","rounds"=>200,"wearoff"=>"`4La luminescenza scompare dalla tua {$pietre[$flagstone]}.","atkmod"=>1.3,"defmod"=>1.3,"roundmsg"=>"`4La {$pietre[$flagstone]} acuisce le tue capacit�!.","activate"=>"offense");
    break;

    case 8:
         output("`n`n`%Poich� possiedi la {$pietre[$flagstone]}`% della `&Fonte di Aris`% acquisisci capacit� supplementari in alcune arti !`n");
         $session['user']['darkartuses']+=6;
         $session['user']['magicuses']+=6;
         $session['user']['thieveryuses']+=6;
         $session['user']['militareuses']+=6;
    break;

    case 9:
         output("`n`n`%Poich� possiedi la {$pietre[$flagstone]}`% della `&Fonte di Aris`% guadagni un combattimento supplementare !`n");
         $session['user']['turns']+=1;
    break;

    case 10:
         output("`n`n`%Poich� possiedi la {$pietre[$flagstone]}`% della `&Fonte di Aris`% ti senti meno colpevole (perdi alcuni punti cattiveria) !`n");
         $session['user']['evil']-=5;
    break;

    case 11:
         output("`n`n`%Poich� possiedi la {$pietre[$flagstone]}`% della `&Fonte di Aris`% guadagni 200 pezzi d'oro !`n");
         $session['user']['gold']+=200;
    break;

    case 12:
         output("`n`n`%Poich� possiedi la {$pietre[$flagstone]}`% della `&Fonte di Aris`% guadagni 500 pezzi d'oro !`n");
         $session['user']['gold']+=500;
    break;

    case 13:
         output("`n`n`%Poich� possiedi la {$pietre[$flagstone]}`% della `&Fonte di Aris`% guadagni 800 pezzi d'oro !`n");
         $session['user']['gold']+=800;
    break;

    case 14:
         output("`n`n`%Poich� possiedi la {$pietre[$flagstone]}`% della `&Fonte di Aris`% attacchi e difendi meglio !`n");
         $session[bufflist][120] = array("name"=>"{$pietre[$flagstone]}","rounds"=>500,"wearoff"=>"`4La luminescenza scompare dalla tua {$pietre[$flagstone]}.","atkmod"=>1.5,"defmod"=>1.5,"roundmsg"=>"`4La {$pietre[$flagstone]} acuisce le tue capacit�!.","activate"=>"offense");
    break;

    case 15:
         output("`n`n`%Poich� possiedi la {$pietre[$flagstone]}`% della `&Fonte di Aris`% guadagni favori con Ramius !`n");
         $session['user']['deathpower']=200;
    break;

    case 16:
         output("`n`n`%Poich� possiedi la {$pietre[$flagstone]}`% della `&Fonte di Aris`% sei ubriaco !`n");
         $session['user']['drunkenness']=66;
    break;

    case 17:
         output("`n`n`%Poich� possiedi la {$pietre[$flagstone]}`% della `&Fonte di Aris`% guadagni due combattimenti supplementari !`n");
         $session['user']['turns']+=2;
    break;

    case 18:
         output("`n`n`%Poich� possiedi la {$pietre[$flagstone]}`% della `&Fonte di Aris`% ti senti pi� puro (perdi alcuni punti cattiveria) !`n");
         $session['user']['evil']-=3;
    break;

    case 19:
         output("`n`n`%Poich� possiedi la {$pietre[$flagstone]}`% della `&Fonte di Aris`% guadagni un combattimento supplementare !`n");
         $session['user']['turns']+=1;
    break;

    case 20:
         output("`n`n`%Poich� possiedi la {$pietre[$flagstone]}`% della `&Fonte di Aris`% guadagni una gemma !`n");
         $session['user']['gems']+=1;
    break;
    }
}
//end pietre.php modification


----- In File:
common.php

----- Find:
$races=array(1=>"Troll",2=>"Elf",3=>"Human",4=>"Dwarf");

----- Add before:

$pietre=array(1=>"`\$Poker's Stone",2=>"`^Love's Stone",3=>"`^Friendship's Stone",4=>"`#King's Stone",5=>"`#Mighthy's Stone",6=>"`#Pegasus' Stone",7=>"`@Aris' Stone",8=>"`@Excalibur's Stone",9=>"`@Luke's Stone",10=>"`&Innocence's Stone",11=>"`#Queen's Stone",12=>"`#Imperator's Stone",13=>"`!Gold's Stone",14=>"`%Power's Stone",15=>"`\$Ramius' Stone",16=>"`#Cedrik's Stone",17=>"`%Honour's Stone",18=>"`&Purity's Stone",19=>"`&Light's Stone",20=>"`&Diamond's Stone");

--------------------------------------------------------------------------

Drop the code of monpietre.php where you like ... You can put in in hof.php (the new version from 0.9.8)
or you can use it "as is" giving a link from village.

Version History:
Ver. Alpha Created by Excalibur (www.ogsi.it)
Original Version posted to DragonPrime

// -Originally by: Excalibur
// -Contributors: Excalibur, Talisman, LonnyL
// July 2004
*/

page_header("Aris' Spring");
output("<font size='+1'>`c`b`!Aris' Spring`b`c`n</font>",true);
$session['user']['specialinc']="pietre.php";
$numpietre="20";
$rango=array(0=>"`\$Eretico",1=>"`)Seguace",2=>"`7Accolito",3=>"`2Chierico",4=>"`3Sacerdote",9=>"`#Gran Sacerdote",5=>"`7Garzone",
6=>"`3Apprendista",7=>"`2Fabbro",8=>"`@Mastro Fabbro");
$owner1=$session['user']['acctid'];
$sql="SELECT * FROM pietre WHERE owner=$owner1";
$result = db_query($sql);
$pot = db_fetch_assoc($result);
$flagstone=$pot['pietra'];
if (db_num_rows($result) == 0) {
switch($HTTP_GET_VARS['op']){
    case "":
        page_header("The Spring");
        output("`@Wandering through the forest looking for adventure, you find a natural spring from which`n emanates a mysterious glow. You've stumbled across the mythical `&Aris' Spring'`@, `nnamed after the wandering sage said to have discovered it.");
        output("`n`nAlthough little is known of the spring, Aris did discover some knowledge of it, `nwhich is recorded in the annals of legend. `nHe found that the stones found in the spring emanate a powerful force, able to `naugment the energy of its owners, giving them an additional forest fight each day.`n");
        output("The stones are limited in quantity, and each stone can be possessed by only one warrior at a time. `nYou could become the holder of one of these magic stones, with a bit of luck.`n`n");
        output("You noticed a rough button inserted in the bedrock near the spring, with some runic symbols engraved around it. `n");
        output("You do not understand the symbols - are they an invitation?   Or...perhaps...a warning?");
        addnav("`\$Leave the Spring","forest.php?op=lascia");
        addnav("`^Push the Button","forest.php?op=premi");
    break;
    case "premi";
        output("`@Your hand pauses over the button as you sense the strength of the mystical power `ncoming from Aris' Spring and its hidden treasures.`n");
        output("You begin to wonder if the legends were true, or if you're about to make a deadly mistake.`nAs you feel a flux of energy coming from the stone, you close your eyes and push the button firmly. `n");
        output("As the button gives way under pressure, you hear mechanical noises coming from inside the stone. `nWhen you open your eyes, you see a pool of water has been revealed. `nA golden glitter in the water makes you wonder if the Earth Goddess will grant you a favour .... `n`n");
        $session['user']['specialinc']="";
        addnav("V?`@Back to Village","village.php");
        addnav("F?`\$Back to Forest","forest.php");
        $pietra=e_rand(1,$numpietre);
        $sql="SELECT pietra,owner FROM pietre WHERE pietra = $pietra";
        $result = db_query($sql) or die(db_error(LINK));
        //$numpietre=db_num_rows($result);
        if (db_num_rows($result) == 0) {
            // The stone is available
            output("`#... you hear something rolling inside the stone, then a marvelous stone magically appears in the pool!!
            `n`nIt has some runes engraved on it, ");
            if ($pietra==1){
                output("and you discover with horror that is {$pietre[$pietra]} `#!!!`n Owning this cursed stone will cause you to lose 1 forest fight each day. `nYour only hope is that some other unlucky warrior will unwittingly stumble onto `&Aris' Source`# and claim the stone from you. ");
                $session['user']['turns']-=1;
                //$session['user']['pietra']=$pietra;
                $id=$session[user][acctid];
                $sql="INSERT INTO pietre (pietra,owner) VALUES ('$pietra','$id')";
                db_query($sql);
            }else{
                output("and you discover with great joy that is {$pietre[$pietra]}`#!! `nAs owner of this stone, you gain a special power each newday. `nToday has been your lucky day, {$session[user][name]}!!!`n");
                //$session['user']['pietra']=$pietra;
                //$session['user']['turns']+=1;
                $id=$session[user][acctid];
                $sql="INSERT INTO pietre (pietra,owner) VALUES ('$pietra','$id')";
                db_query($sql);
            }
        }else{
            $row = db_fetch_assoc($result);
            output("`# you hear a whistle sound which grows in intensity, until it becomes a lament, stopping as suddenly as it started. `nA deep, calm voice speaks: `n`n\"");
            $caso=e_rand(0,1);
            $account=$row['owner'];
            $sqlz="SELECT name FROM accounts WHERE acctid = $account";
            $resultz = db_query($sqlz) or die(db_error(LINK));
            $rowz = db_fetch_assoc($resultz);
            if ($pietra==1) $switch=1;
            if ($caso==0){
                output("`%".($switch?"Luckily":"Unluckily")." my dear {$session[user][name]}`%, the {$pietre[$pietra]}`% is the possession of `@{$rowz[name]}`%. `nIt is not in my nature to take it from him for you. `nYou will have to be satisfied with `^`b5`b`% more forest fights which I will grant you instead.`#\" `n`nYou feel a flow of energy run through your body, and discover the voice's promise was kept!!! `n");
                $session['user']['turns']+=5;
                }else{
                    output("`^The stone selected for you is possessed by `@{$rowz[name]}`^. As he has fallen from my favour, `nI have chosen to retrieve and place it in your deserving care.`#\". `n`nYou see a beautiful stone materialize in the pool, `nand you grab it.");
                    if ($pietra != 1){
                        output("You admire the {$pietre[$pietra]}`#, knowing you'll have a special power each day. `n");
                        //$session['user']['turns']+=1;
                    }else{
                        output("You discover with horror that is the {$pietre[$pietra]} `#!!!`n Ownership of this stone will costs you 1 forest fight each day. `nOur only hope is that some other unlucky warrior will unwittingly stumble onto `&Aris' Source`# and claim the stone from you.");
                        $session['user']['turns']-=1;
                    }
                    //$sqlp="UPDATE accounts SET pietra = '0' WHERE acctid = $account";
                    //db_query($sqlp);
                    //$session['user']['pietra']=$pietra;
                    $account1=$session[user][acctid];
                    $sqlr="UPDATE pietre SET owner = $account1 WHERE pietra = $pietra";
                    db_query($sqlr);
                    $mailmessage = "`@{$session['user']['name']} `@has found `&Aris' Source`@ and the earth goddess has decided to give him your {$pietre[$pietra]} stone`@!! It's your ".($switch?"":"un")."lucky day.";
                    systemmail($account,"`2Your stone has been given to the care of {$session['user']['name']} `2",$mailmessage);
                }
            }
    break;
    case "lascia";
        $session['user']['specialinc']="";
        $perdita=intval($session[user][maxhitpoints]*0.3);
        $session[user][hitpoints]-=$perdita;
        if ($session[user][hitpoints] < 1) {
            $perdita += $session[user][hitpoints];
            $session[user][hitpoints] = 1;
        }
        output("`6Terrified by the power of the spring, you decide not to tempt fate. `nYou turn back to forest and its relative safety.  As you turn your back, you hear a bubbling `nsound coming from the spring of water. `n`n`^A jet of water hits the back of your head like a mallet `nand throwing you to the ground!`n`n `\$`bYou lose $perdita hit points from the fall!!!!`b");
        addnav("`\$Back to Forest","forest.php");
    break;
}//chiusura switch
}else{ //chiusura if iniziale
    $session['user']['specialinc']="";
    output("`@Wandering through the forest looking for adventure, you find a natural spring from which`n emanates a mysterious glow. You've stumbled across the mythical `&Aris' Spring'`@, `nnamed after the wandering sage said to have discovered it.");
    output("`nYou are no stranger to the spring, and are well aware of it's power, `nas you already possess the {$pietre[$session[user][pietra]]} stone. `n`nDon't be greedy, let other warriors benefit from the magic property of these stones as well.   `nWhile you are here, you drink of the clear water and feel refreshed.`n`n`%You lose 1 turn for the time spent here, but are fully healed.");
    $session[user][turns]-=1;
    if ($session[user][hitpoints]<$session[user][maxhitpoints]) $session[user][hitpoints]=$session[user][maxhitpoints];
    addnav("`\$Back to Forest","forest.php");
    }
page_footer();
?>