<?
//**************************************************************************
///      Trump Tower
///      Created to give admin easy access to gold and gems without 
///      the bother of using the User Editor
///
///      ADD TO ANY PAGE:
///      if ($session['user']['superuser']>2) addnav("Trump Tower","trumptower.php");
///
///      Also helpful to add to any page:
///      if ($session['user']['superuser']>2) addnav("X? Admin Access","superuser.php");
///
//***************************************************************************
require_once "common.php"; 

addnav("Gems"); 
addnav("take a little","trumptower.php?op=gems"); 
addnav("take a lot","trumptower.php?op=gemslot"); 
addnav("Gold");
addnav("take a little","trumptower.php?op=gold"); 
addnav("take a lot","trumptower.php?op=goldlot"); 
addnav("leave");
///   Change to wherever you place a link to or add a series of links to wherever
addnav("(R) Return to Village","village.php"); 

page_header("Trump Tower"); 
output("`c<font size='+1'>`@Trump Tower</font>`c`n`n",true);
output(" `2You enter into Trump Tower, you are amazed that you are walking on floors made of Gold.`n"); 
output(" The walls are studded with gems, rubies, emeralds, pearls and diamonds.`n`n"); 
output(" Being a little short of cash and full of greed, you decide to help yourself to the wealth`n");
output(" that surrounds you.`n`n"); 

if ($_GET[op]=="gems"){ 

$gems = e_rand(10,50);
$session[user][gems]+=$gems;
//addnav("(T) Trump Tower","trumptower.php"); 
output("You open your pouch and fill it $gems gems for yourself.`n");  
debuglog("got $gems gold at trump tower");

}if ($_GET[op]=="gemslot"){ 

$gemslot = e_rand(100,300);
$session[user][gems]+=$gemslot; 
//addnav("(T) Trump Tower","trumptower.php"); 
output("You grab a Gold Shovel and scoop up $gemslot gems for yourself.`n");  
debuglog("got $gemslot gold at trump tower");

}if ($_GET[op]=="gold"){ 
$gold = e_rand(100,500);
$session[user][gems]+=$gold; 
//addnav("(T) Trump Tower","trumptower.php"); 
output("You open your pouch and fill it with $gold gold for yourself.`n"); 
debuglog("got $gold gold at trump tower");
 
}if ($_GET[op]=="goldlot"){ 

$goldlot = e_rand(1000,5000);
$session[user][gems]+=$goldlot; 
//addnav("(T) Trump Tower","trumptower.php"); 
output("You grab a solid sterling silver shovel and scoop up $goldlot gold for yourself.`n"); 
debuglog("got $goldlot gold at trump tower");
} 
page_footer(); 
?>