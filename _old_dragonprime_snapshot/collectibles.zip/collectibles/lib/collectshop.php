<?php
	global $session;
	if (($session['user']['location'] == get_module_setting("collectshoploc0")) &&
			(get_module_setting("collectshoponoff0") == 1)) {
		$shopname = get_module_setting("collectshopname0");
		$shopdesc = get_module_setting("collectshopdesc0");
	}
	if (($session['user']['location'] == get_module_setting("collectshoploc1")) &&
			(get_module_setting("collectshoponoff1") == 1)) {
		$shopname = get_module_setting("collectshopname1");
		$shopdesc = get_module_setting("collectshopdesc1");
	}
	if (($session['user']['location'] == get_module_setting("collectshoploc2")) &&
			(get_module_setting("collectshoponoff2") == 1)) {
		$shopname = get_module_setting("collectshopname2");
		$shopdesc = get_module_setting("collectshopdesc2");
	}
	if (($session['user']['location'] == get_module_setting("collectshoploc3")) &&
			(get_module_setting("collectshoponoff3") == 1)) {
		$shopname = get_module_setting("collectshopname3");
		$shopdesc = get_module_setting("collectshopdesc3");
	}
	if (($session['user']['location'] == get_module_setting("collectshoploc4")) &&
			(get_module_setting("collectshoponoff4") == 1)) {
		$shopname = get_module_setting("collectshopname4");
		$shopdesc = get_module_setting("collectshopdesc4");
	}
	if (($session['user']['location'] == get_module_setting("collectshoploc5")) &&
			(get_module_setting("collectshoponoff5") == 1)) {
		$shopname = get_module_setting("collectshopname5");
		$shopdesc = get_module_setting("collectshopdesc5");
	}
	if (($session['user']['location'] == get_module_setting("collectshoploc6")) &&
			(get_module_setting("collectshoponoff6") == 1)) {
		$shopname = get_module_setting("collectshopname6");
		$shopdesc = get_module_setting("collectshopdesc6");
	}
	$shopname = translate_inline($shopname);

	$op = httpget('op');	
	$from = "runmodule.php?module=collectshop&";
	$id = httpget('id');
	$uid = $session['user']['acctid']; 	
	$buy = translate_inline("Purchase");
	//Collectibles shop main
	if ($op=="enter"){		
		page_header("$shopname");
		output("`b`c%s`c`b`n`n", $shopname);
		output($shopdesc . "`n");
		output("A small bell over the door announces your arrival. Loads of trinkets and treasures sit on the shelves which line the walls.");
		output(" A young woman comes in from a backdoor and gives you a friendly smile.`n`n");
		output("\"Welcome to the souvenir shop, traveler,\" she greets you. \"We sell all kinds of lovely keepsakes for you to collect and cherish. May I help you with anything?\"`n`n");
		
		// Get player's location to define the category sold in this shop
		if (($session['user']['location'] == get_module_setting("collectshoploc0")) &&
			(get_module_setting("collectshoponoff0") == 1)) $cat= 0;
		if (($session['user']['location'] == get_module_setting("collectshoploc1")) &&
			(get_module_setting("collectshoponoff1") == 1)) $cat= 1;
		if (($session['user']['location'] == get_module_setting("collectshoploc2")) &&
			(get_module_setting("collectshoponoff2") == 1)) $cat= 2;
		if (($session['user']['location'] == get_module_setting("collectshoploc3")) &&
			(get_module_setting("collectshoponoff3") == 1)) $cat= 3;
		if (($session['user']['location'] == get_module_setting("collectshoploc4")) &&
			(get_module_setting("collectshoponoff4") == 1)) $cat= 4;
		if (($session['user']['location'] == get_module_setting("collectshoploc5")) &&
			(get_module_setting("collectshoponoff5") == 1)) $cat= 5;
		if (($session['user']['location'] == get_module_setting("collectshoploc6")) &&
			(get_module_setting("collectshoponoff6") == 1)) $cat= 6;
		$userdk = $session['user']['dragonkills'];

		// Select shop items available
		$sql = "SELECT " .  db_prefix("collect").".* FROM " . db_prefix("collect") .
			   " NATURAL JOIN " . db_prefix("crare").
			   " WHERE collectcat=$cat and $userdk>=collectdk".
			   " ORDER BY " . db_prefix("collect").".collectdk DESC, " . db_prefix("collect").".collectname";	

		$tabletext = translate_inline("Below is a Listing of Souvenirs");
		$choice = translate_inline("Choice");
		$souvenir = translate_inline("Souvenir");
		$costgold = translate_inline("Gold Cost");
		$costgem = translate_inline("Gem Cost");
		rawoutput("<table cellspacing=0 cellpadding=2 width='500' align='center'><tr><td align='center'><b>$tabletext</b></td></tr><tr><td>");
    	$result = db_query($sql);
    	if (db_num_rows($result)>0) rawoutput("<table cellspacing=0 cellpadding=2 width='500' align='center'><tr><td><b>$choice</b></td><td>&nbsp;</td><td><b>$souvenir</b></td><td><b>$costgold</b></td><td><b>$costgem</b></td></tr>");    
    	for ($i=0;$i<db_num_rows($result);$i++){
			$row = db_fetch_assoc($result);	
   			rawoutput("<tr class='".($i%2?"trlight":"trdark")."'>"); 
			$sql2 ="SELECT * FROM "  . db_prefix("cowner") . " WHERE collectid =" .
			$row['collectid'] . " AND userid =" . $session['user']['acctid'];
			$result2 = db_query($sql2);
			if (db_num_rows($result2)>0)
			{
				output("<td>Already bought!</td>",true);
			} else {
	   			rawoutput("<td>[<a href='runmodule.php?module=collectshop&op=buycollect&id={$row['collectid']}'>$buy</a>]</td>");
			}      	 	   
   			addnav("","runmodule.php?module=collectshop&op=buycollect&id={$row['collectid']}");	
 
			rawoutput("<td><img src='". $row['collectimage'] ."'></td><td>");
			output($row['collectname']);
			rawoutput("</td><td>");
			output("`^%s Gold",$row['collectcostgold']);
			rawoutput("</td><td>");
    		output("`@%s Gems",$row['collectcostgems']); 
			rawoutput("</td></tr>");
		}
		if (db_num_rows($result)==0) {
			output("Sorry, we're sold out for today! Please stop by tomorrow.");
		} else {
    		rawoutput("</table>");
		}
    	rawoutput("</td></tr></table>");

		if (get_module_setting("showcredit"))
		{
			$graphcredit = get_module_setting("graphcredit");
			output("`n`n`cGraphics credits go to: %s. Licensed for use in LotGD.`c",$graphcredit);
		}

		villagenav();
	}
	else if ($op=="purchase"){	
		page_header("$shopname");
		output("`b`c`2%s`c`b`n`n", $shopname);
		$sql = "SELECT collectid,collectname FROM " . db_prefix("collect") . " WHERE collectid=$collectid";
		$result = db_query($sql);
		$row = db_fetch_assoc($result);						
	//BUY SOUVENIRS
	}else if ($op=="buycollect"){		
		page_header("$shopname");
		output("`b`c`2%s`c`b`n`n", $shopname);
		$sql = "SELECT * FROM " . db_prefix("collect") . " WHERE collectid='$id'";
		$result = db_query($sql);
		$row = db_fetch_assoc($result);		
		$collect = translate_inline($row['collectname']);
		$collectid = $row['collectid'];
		$costgold = $row['collectcostgold'];
		$costgems = $row['collectcostgems'];
		$ugold = $session['user']['gold'];
		$ugems = $session['user']['gems'];		
		//sorry, not enough money...	
		if ($ugold<$costgold){
			output("The shopkeeper informs you with a sad look that you haven't enough gold to purchase this `^%s.`n`n", $collect);			
			addnav("Go Back", $from."op=enter");
		}else if ($ugems<$costgems){
			output("You count your gems and realize you don't have enough to purchase this `^%s.`n`n", $collect);
			addnav("Go Back", $from."op=enter");
		//My mistake, carry on...
		} else {
			output("The shopkeeper smiles warmly and congratulates on your purchase of a `3%s.", $collect);
			//set prefs and what not
			// Patrick: add row to cowner table.
			$userid=$session['user']['acctid'];

			$sql = "INSERT into " . db_prefix("cowner") . " (collectid, userid) VALUES (".$collectid.",".$userid.")";
			$result = db_query($sql);
			
			//deduct cost of collectible
			$session['user']['gold']-=$costgold;
			$session['user']['gems']-=$costgems;			
			addnav("Go Back", $from."op=enter");						
			
		} 
		} else if ($op=="viewbio"){
		$page = httpget('page');
		$cat = httpget('cat');
		collectshop_viewcollection($page, $cat, $session['user']['login'], $op);
		addnav("Return to the village","village.php");
	}else if ($op=="biotop"){
		// this part allows you to view other player's collection in their bio
		$ouser = httpget('ouser');
		$page = httpget('page');
		$cat = httpget('cat');
		collectshop_viewcollection($page, $cat, $ouser, $op);
		addnav("Return to user bio","bio.php?char=".$ouser);
	}

page_footer();	
?>