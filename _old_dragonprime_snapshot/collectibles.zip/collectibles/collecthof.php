<?php

function collecthof_getmoduleinfo(){
	$info = array(
		"name"=>"Collectibles HoF",
		"author"=>"Dorian, based on code by Chris Vorndran",
		"version"=>"1.0",
		"category"=>"Stat Display",
		"download"=>"http://www.ephralon.de/z_logd/ephstuff/collectibles.zip",
		"description"=>"This module will track the amount of collectibles that a user has, and generate a Hall of Fame page from the information.",
		"settings"=>array(
			"Collection Size Settings,title",
			"pp"=>"Display how many results in the HoF page,int|50",
			"dispad"=>"Show superusers in HoF listing,enum,0,Yes,1,No|1",
			"This applies to even those that have the 'Account Never Expires' Flag,note",
		),
		);
	return $info;
}
function collecthof_install(){
	module_addhook("footer-hof");
	return true;
	}
function collecthof_uninstall(){
	return true;
}
function collecthof_dohook($hookname,$args){
	global $session;
	$char = httpget('char');
	switch ($hookname){
		case "footer-hof":
			addnav("Warrior Rankings");
			addnav("Collectibles","runmodule.php?module=collecthof&op=hof");
			break;
		}
	return $args;
}
function collecthof_run(){
	global $session;
	$op = httpget('op');
	$page = httpget('page');
	$f = 1;
	if (get_module_setting("dispad") == 1){
		$g = "AND superuser = 0";
	}else{
		$g = "";
	}
	
	switch ($op){
		case "hof":
			$superusermask = SU_HIDE_FROM_LEADERBOARD;
			$standardwhere = "(locked=0 AND (superuser & $superusermask) = 0)";
			page_header("Hall of Fame");
			$pp = get_module_setting("pp");
			$pageoffset = (int)$page;
			if ($pageoffset > 0) $pageoffset--;
			$pageoffset *= $pp;
			$from = $pageoffset+1;
			$sql = "SELECT userid, COUNT(*) AS rank, login FROM " . db_prefix("cowner") . " JOIN  " . 
					db_prefix("accounts") .
				   " WHERE " . db_prefix("cowner") . ".userid=" . db_prefix("accounts") . ".acctid AND  " . $standardwhere . 
				   " GROUP BY " . db_prefix("cowner") . ".userid ORDER BY rank DESC";
			$result = db_query($sql);
			$total = db_num_rows($result);
			if ($from + $pp < $total){
				$cond = $pageoffset + $pp;
			}else{
				$cond = $total;
			}

			$result = db_query($sql);
			$rank = translate_inline("Rank");
			$name = translate_inline("Name");
			$pk = translate_inline("No. of Collectibles");
			rawoutput("<big>");
			output("`c`b`^Warriors with the most collectibles in the land`b`c`0`n");
			rawoutput("</big>");
			rawoutput("<table border='0' cellpadding='2' cellspacing='1' align='center' bgcolor='#999999'>");
			rawoutput("<tr class='trhead'><td>$rank</td><td>$name</td><td>$pk</td></tr>");
			if (db_num_rows($result)>0){
				for ($i = 0; $i < $pageoffset; $i++){
					$row = db_fetch_assoc($result);
				}
				for ($i = $pageoffset; $i < $cond; $i++) {
					$row = db_fetch_assoc($result);
					if ($row['login']==$session['user']['name']){
						rawoutput("<tr class='trhilight'><td>");
					} else {
						rawoutput("<tr class='".($i%2?"trdark":"trlight")."'><td>");
					}
					$j=$i+1;
					output_notl("$j.");
					rawoutput("</td><td>");
					output_notl("`&%s`0",$row['login']);
					rawoutput("</td><td>");
					output_notl("`c`@%s`c`0",$row['rank']);
					rawoutput("</td>");
					}
			}
			rawoutput("</table>");
		if ($total>$pp){
			addnav("Pages");
			for ($p=0;$p<$total;$p+=$pp){
				addnav(array("Page %s (%s-%s)", ($p/$pp+1), ($p+1), min($p+$pp,$total)), "runmodule.php?module=collecthof&op=hof&page=".($p/$pp+1));
			}
		}
		break;
	}
addnav("Other");
addnav("Back to HoF", "hof.php");
if ($session['user']['alive']){
	villagenav();
}else{
	addnav("Return to the Shades", "shades.php");
}
page_footer();
}
?>