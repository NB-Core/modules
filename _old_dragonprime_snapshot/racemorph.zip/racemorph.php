<?php

function racemorph_getmoduleinfo(){
	$info = array(
		"name"=>"Rasse - Morph",
		"version"=>"1.0",
		"author"=>"`QBasilius `qSauter",
		"category"=>"Rassen",
		"download"=>"http://dragonprime.net/users/Eliwood/racepack1.zip",
		"settings"=>array(
			"Morph-Einstellungen,title",
			"villagename"=>"Name der Stadt|Jahkt Sadal",
			"minedeathchance"=>"Morphs sterben in der Mine zu (%),range,0,100,1|80",
		),
	);
	return $info;
}

function racemorph_install(){
	module_addhook("chooserace");
	module_addhook("setrace");
	module_addhook("newday");
	module_addhook("villagetext");
	//module_addhook("stabletext");
	module_addhook("travel");
	module_addhook("charstats");
	module_addhook("validlocation");
	module_addhook("validforestloc");
	module_addhook("moderate");
	module_addhook("changesetting");
	module_addhook("raceminedeath");
	//module_addhook("stablelocs");
	module_addhook("racenames");
	return true;
}

function racemorph_uninstall(){
	global $session;
	$vname = getsetting("villagename", LOCATION_FIELDS);
	$gname = get_module_setting("villagename");
	$sql = "UPDATE " . db_prefix("accounts") . " SET location='$vname' WHERE location = '$gname'";
	db_query($sql);
	if ($session['user']['location'] == $gname)
		$session['user']['location'] = $vname;
	$sql = "UPDATE  " . db_prefix("accounts") . " SET race='" . RACE_UNKNOWN . "' WHERE race='Morph'";
	db_query($sql);
	if ($session['user']['race'] == 'Morph')
		$session['user']['race'] = RACE_UNKNOWN;
	return true;
}

function racemorph_dohook($hookname,$args){
	//yeah, the $resline thing is a hack.  Sorry, not sure of a better way
	// to handle this.
	// Pass it as an arg?
	global $session,$resline;
	$city = get_module_setting("villagename");
	$race = "Morph";
	switch($hookname){
	case "racenames":
		$args[$race] = $race;
		break;
	case "raceminedeath":
		if ($session['user']['race'] == $race) {
			$args['chance'] = get_module_setting("minedeathchance");
		}
		break;
	case "changesetting":
		// Ignore anything other than villagename setting changes
		if ($args['setting'] == "villagename" && $args['module']=="racemorph") {
			if ($session['user']['location'] == $args['old'])
				$session['user']['location'] = $args['new'];
			$sql = "UPDATE " . db_prefix("accounts") .
				" SET location='" . $args['new'] .
				"' WHERE location='" . $args['old'] . "'";
			db_query($sql);
			if (is_module_active("cities")) {
				$sql = "UPDATE " . db_prefix("module_userprefs") .
					" SET value='" . $args['new'] .
					"' WHERE modulename='cities' AND setting='homecity'" .
					"AND value='" . $args['old'] . "'";
				db_query($sql);
			}
		}
		break;
	case "charstats":
		if ($session['user']['race']==$race){
			addcharstat("Vital Info");
			addcharstat("Race", translate_inline($race));
		}
		break;
	case "chooserace":
		output("`0<a href='newday.php?setrace=$race$resline'>In %s aufgewachsen</a>, einem Jakht, das eines der elendesten ist, doch daf�r haben deinesgleichen enorme Vitale F�higkeiten.`n`n", $city, true);
		addnav("`qMorph`0","newday.php?setrace=$race$resline");
		addnav("","newday.php?setrace=$race$resline");
		break;
	case "setrace":
		if ($session['user']['race']==$race){
			output("`qDa du ein Morph bist, bekommst du zus�tzliche 5 Lebenspunkte.");
			$session['user']['maxhitpoints']+=5;
			if (is_module_active("cities")) {
				if ($session['user']['dragonkills']==0 &&
						$session['user']['age']==0){
					set_module_setting("newest-$city",
							$session['user']['acctid'],"cities");
				}
				set_module_pref("homecity",$city,"cities");
				if ($session['user']['age'] == 0)
					$session['user']['location']=$city;
			}
		}
		break;
	case "newday":
		if ($session['user']['race']==$race){
			raceelf_checkcity();
			apply_buff("racialbenefit",array(
				"name"=>"`qVitale Morphkraft",
				"regen"=>0.5,
				"allowinpvp"=>1,
				"allowintrain"=>1,
				"rounds"=>20,
				"schema"=>"module-racemorph",
				)
			);
		}
		break;
	case "validforestloc":
	case "validlocation":
		if (is_module_active("cities"))
			$args[$city]="village-$race";
		break;
	case "moderate":
		if (is_module_active("cities")) {
			tlschema("commentary");
			$args["village-$race"]=sprintf_translate("%s, Jahkt der Morph", $city);
			tlschema();
		}
		break;
	case "travel":
		$capital = getsetting("villagename", LOCATION_FIELDS);
		$hotkey = substr($city, 0, 1);
		tlschema("module-cities");
		if ($session['user']['location']==$capital){
			addnav("Safer Travel");
			addnav(array("%s?Go to %s", $hotkey, $city),"runmodule.php?module=cities&op=travel&city=$city");
		}elseif ($session['user']['location']!=$city){
			addnav("More Dangerous Travel");
			addnav(array("%s?Go to %s", $hotkey, $city),"runmodule.php?module=cities&op=travel&city=$city&d=1");
		}
		if ($session['user']['superuser'] & SU_EDIT_USERS){
			addnav("Superuser");
			addnav(array("%s?Go to %s", $hotkey, $city),"runmodule.php?module=cities&op=travel&city=$city&su=1");
		}
		tlschema();
		break;	
	case "villagetext":
		racemorph_checkcity();
		if ($session['user']['location'] == $city){
			$args['text']=array("`&`c`b%s, das Jahkt der Morph`b`c`n`7DTraurigkeit h�ngt �ber diesem Jahkt. Hier und da liegen tote K�rper auf dem Boden, ein Gestank von verwesenheit liegt in der Luft. Du musst dich hier sehr vor Dieben in Acht nehmen, denn hier wird alles gestohlen, was nicht zu schwer ist. Du siehst traurige Kinder, wie sie mit einem zerstochenen Ball spielen.`n", $city, $city);
			$args['schemas']['text'] = "module-racemorph";
			$args['clock']="`n`7Am Gestank, der in der Luft h�ngt, merkst du, dass es `&%s`7 Uhr ist.`n";
			$args['schemas']['clock'] = "module-racemorph";
			if (is_module_active("calendar")) {
				$args['calendar'] = "`n`7Heute ist der `&%s`7, `&%s %s %s`7.`n";
				$args['schemas']['calendar'] = "module-racemorph";
			}
			$args['title']=array("%s, das Jahkt der Morph", $city);
			$args['schemas']['title'] = "module-racemorph";
			$args['sayline']="seufzt";
			$args['schemas']['sayline'] = "module-racemorph";
			$args['talk']="`n`&In seufzen einige Morphs:`n";
			$args['schemas']['talk'] = "module-racemorph";
			$new = get_module_setting("newest-$city", "cities");
			if ($new != 0) {
				$sql =  "SELECT name FROM " . db_prefix("accounts") .
					" WHERE acctid='$new'";
				$result = db_query_cached($sql, "newest-$city");
				$row = db_fetch_assoc($result);
				$args['newestplayer'] = $row['name'];
				$args['newestid']=$new;
			} else {
				$args['newestplayer'] = $new;
				$args['newestid']="";
			}
			if ($new == $session['user']['acctid']) {
				$args['newest']="`n`7Als Neuling in diesem dorf wanderst du ziellos umher.";
			} else {
				$args['newest']="`n`7`&%s`7 wandert ziellos durch das elende Jahkt.";
			}
			$args['schemas']['newest'] = "module-racemorph";
			$args['section']="village-$race";
			$args['gatenav']="Village Gates";
			$args['schemas']['gatenav'] = "module-racemorph";
			unblocknav("stables.php");
		}
		break;
	}
	return $args;
}

function racemorph_checkcity(){
	global $session;
	$race="Morph";
	$city=get_module_setting("villagename");
	
	if ($session['user']['race']==$race && is_module_active("cities")){
		if (get_module_pref("homecity","cities")!=$city){ //home city is wrong
			set_module_pref("homecity",$city,"cities");
		}
	}	
	return true;
}

function racemorph_run(){

}

?>