<?php
/*
Module Name: quizload.php
Category: Village
Worktitle: Quiz Loader
Version: 3.0
Author: DaveS
Date:  February 6, 2006
Based on a concept by DaveS and Kestrel Charm

Description: 
A versatile program to give players a chance to participate in quizzes.
Allows for configurations by Staff to change/update/reset quizzes.  Can use as a base to load
other quiz modules.

*/
require_once("lib/villagenav.php");
require_once("lib/titles.php");
require_once("lib/names.php");
function quizload_getmoduleinfo() {
	$info = array(
		"name"=>"Quiz Loader",
		"author"=>"DaveS",
		"version"=>"3.01",
		"category"=>"Village",
		"download"=>"http://dragonprime.net/index.php?module=Downloads;sa=dlview;id=187",
		"vertxtloc"=>"",
		"settings"=>array(
			"Quiz Load,title",
			"quizloadloc"=>"Where does the Guide Office appear?,location|".getsetting("villagename", LOCATION_FIELDS),
			"introperson1"=>"Who is person 1 to operate the office?,text|Phair",
			"sexintro1"=>"What is the sex of person 1?,enum,0,Female,1,Male|1",
			"introperson2"=>"Who is person 2 to operate the office?,text|Lan",
			"quizbookbio"=>"Show list of completed quizzes in Quiz Book under Bio?,bool|1",
			"Quiz Settings,title",
			"gemaward"=>"Gems Awarded,int|1",
			"goldaward"=>"Gold Awarded,int|250",
			"quizname"=>"What is the name of the Quiz?,text|Sequences & Series Quiz",
			"announce1"=>"First line of your description of this quiz,text|Look for patterns to solve this quiz",
			"announce2"=>"Second line of your description of this quiz,text|Some take work and others take thought.",
			"announce3"=>"Third line of your description of this quiz,text|If at first you fail, try again and again",
			"announce4"=>"Fourth line of your description of this quiz,text|Reflect on the sequences you have been taught.",
			"riddlenum"=>"How many riddles will be in this quiz?,range,1,8,1|8",
			"titleyes"=>"Would you like to offer a title for completing this quiz?,bool|1",
			"titleto"=>"What title would you like to use? (no spaces),text|Mathemagician",
			"limitwin"=>"If you wish to limit to a certain number of winners; how many?,int|-1",
			"Set to -1 if you do not want a limit to the number of winners,note",
			"currentwin"=>"How many winners are there so far?,int|0",
			"limitlong"=>"If you wish to autoclose the quiz; how many game days until it closes?,int|-1",
			"Set to -1 if you do not want the quiz to autoclose,note",
			"currentlong"=>"How many days has this quiz been open so far?,int|0",
			"quizhold"=>"Close the quiz?,bool|0",
			"resetquiz"=>"Reload the quiz at the next day?,bool|0",
			"This will reset and open everything at next newday so use it only if you are ready with a new quiz,note",
			"quiznamea"=>"What is the name of the Backup Quiz?,text|Creatures of the Kingdom",
			"announce1a"=>"First line of your description of the backup quiz,text|Danger lurks around every cave",
			"announce2a"=>"Second line of your description of the backup quiz,text|With knowledge and learning you can be brave",
			"announce3a"=>"Third line of your description of the backup quiz,text|And face the great creatures that live in our land",
			"announce4a"=>"Fourth line of your description of the backup quiz,text|If you're stuck do some research to give you a hand.",
			"riddlenuma"=>"How many riddles will be in the Backup quiz?,range,1,8,1|8",
			"titleyesa"=>"Would you like to offer a title for completing the Backup quiz?,bool|1",
			"titletoa"=>"What title would you like to use for the backup quiz? (no spaces),text|Invoker",			
			"Question 1,title",
			"Leave extra lines blank if there is no additional text,note",
			"riddle1a"=>"What is the first line of riddle 1?,text|What comes next in the series:",
			"riddle1b"=>"What is the second line of riddle 1?,text|1,1,2,3,5,8,13...",
			"riddle1c"=>"What is the third line of riddle 1?,text|",
			"riddle1d"=>"What is the fourth line of riddle 1?,text|",
			"riddle1e"=>"What is the fifth line of riddle 1?,text|",
			"answer1"=>"What is the correct answer?,text|21",
			"wrong1a"=>"What is wrong answer 1?,text|22",
			"wrong1b"=>"What is wrong answer 2?,text|18",
			"wrong1c"=>"What is wrong answer 3?,text|14",
			"wrong1d"=>"What is wrong answer 4?,text|28",
			"wrong1e"=>"What is wrong answer 5?,text|8",
			"wrong1f"=>"What is wrong answer 6?,text|29",
			"wrong1g"=>"What is wrong answer 7?,text|9",
			"wrong1h"=>"What is wrong answer 8?,text|15",
			"wrong1i"=>"What is wrong answer 9?,text|16",
			"May have any number of wrong answers,note",
			"reminder1"=>"Where is the answer to this question from?,text|Add previous 2 numbers",
			"quizzer1"=>"Person asking question 1,text|Dr. Fibonacci",
			"sexofq1"=>"What is the sex of Person 1?,enum,0,Female,1,Male|1",
			"Use the next set to prepare the next quiz,note",
			"riddle1aa"=>"Backup first line of riddle 1?,text|What metal should you carry",
			"riddle1bb"=>"Backup second line of riddle 1?,text|If you're seeing a full moon...",
			"riddle1cc"=>"Backup third line of riddle 1?,text|And you're attack by something scary",
			"riddle1dd"=>"Backup fourth line of riddle 1?,text|If you don't want to be dead soon?",
			"riddle1ee"=>"Backup fifth line of riddle 1?,text|",
			"answer11"=>"Backup correct answer?,text|Silver",
			"wrong1aa"=>"Backup wrong answer 1?,text|Gold",
			"wrong1bb"=>"Backup wrong answer 2?,text|Copper",
			"wrong1cc"=>"Backup wrong answer 3?,text|Platinum",
			"wrong1dd"=>"Backup wrong answer 4?,text|Bronze",
			"wrong1ee"=>"Backup wrong answer 5?,text|Mercury",
			"wrong1ff"=>"Backup wrong answer 6?,text|Steel",
			"wrong1gg"=>"Backup wrong answer 7?,text|Aluminum",
			"wrong1hh"=>"Backup wrong answer 8?,text|Tin",
			"wrong1ii"=>"Backup wrong answer 9?,text|Electrum",
			"reminder1a"=>"Where is the answer to this question from?,text|Kill a Werewolf",
			"quizzer11"=>"Backup Person asking question 1,text|Dr. Jeckyll",
			"sexofq11"=>"What is the sex of Backup Person 1?,enum,0,Female,1,Male|0",
			"Question 2,title",
			"Leave extra lines blank if there is no additional text,note",
			"riddle2a"=>"What is the first line of riddle 2?,text|What comes next in the series:",
			"riddle2b"=>"What is the second line of riddle 2?,text|S, S, F, F, T, T, O...",
			"riddle2c"=>"What is the third line of riddle 2?,text|",
			"riddle2d"=>"What is the fourth line of riddle 2?,text|",
			"riddle2e"=>"What is the fifth line of riddle 2?,text|",
			"answer2"=>"What is the correct answer?,text|Z",
			"wrong2a"=>"What is wrong answer 1?,text|H",
			"wrong2b"=>"What is wrong answer 2?,text|T",
			"wrong2c"=>"What is wrong answer 3?,text|O",
			"wrong2d"=>"What is wrong answer 4?,text|S",
			"wrong2e"=>"What is wrong answer 5?,text|F",
			"wrong2f"=>"What is wrong answer 6?,text|E",
			"wrong2g"=>"What is wrong answer 7?,text|N",
			"wrong2h"=>"What is wrong answer 8?,text|A",
			"wrong2i"=>"What is wrong answer 9?,text|B",
			"May have any number of wrong answers,note",
			"reminder2"=>"Where is the answer to this question from?,text|First letter of first 7 numbers backwards to zero",
			"quizzer2"=>"Person asking question 2,text|The Count",
			"Use the next set to prepare the next quiz,note",
			"riddle2aa"=>"Backup first line of riddle 2?,text|Wandering through the swamps at night",
			"riddle2bb"=>"Backup second line of riddle 2?,text|You notice a shimmering floating blue light.",
			"riddle2cc"=>"Backup third line of riddle 2?,text|You run, you hide, yet you live by your flight.",
			"riddle2dd"=>"Backup fourth line of riddle 2?,text|What creature just gave you such a chilling fright?",
			"riddle2ee"=>"Backup fifth line of riddle 2?,text|",
			"answer21"=>"Backup correct answer?,text|Will o' the Wisp",
			"wrong2aa"=>"Backup wrong answer 1?,text|Dryad",
			"wrong2bb"=>"Backup wrong answer 2?,text|Night Hag",
			"wrong2cc"=>"Backup wrong answer 3?,text|Hippogriff",
			"wrong2dd"=>"Backup wrong answer 4?,text|Doppleganger",
			"wrong2ee"=>"Backup wrong answer 5?,text|Couatl",
			"wrong2ff"=>"Backup wrong answer 6?,text|Mindflayer",
			"wrong2gg"=>"Backup wrong answer 7?,text|Fire Elemental",
			"wrong2hh"=>"Backup wrong answer 8?,text|Troglodyte",
			"wrong2ii"=>"Backup wrong answer 9?,text|Lammasu",
			"quizzer21"=>"Backup Person asking question 2,text|Grimmoire",
			"reminder2a"=>"Where is the answer to this question from?,text|Classic Dungeons and Dragons",
			"Question 3,title",
			"Leave extra lines blank if there is no additional text,note",
			"riddle3a"=>"What is the first line of riddle 3?,text|What comes next in the series:",
			"riddle3b"=>"What is the second line of riddle 3?,text|T, W, T, F, S, S...",
			"riddle3c"=>"What is the third line of riddle 3?,text|",
			"riddle3d"=>"What is the fourth line of riddle 3?,text|",
			"riddle3e"=>"What is the fifth line of riddle 3?,text|",
			"answer3"=>"What is the correct answer?,text|M",
			"wrong3a"=>"What is wrong answer 1?,text|T",
			"wrong3b"=>"What is wrong answer 2?,text|W",
			"wrong3c"=>"What is wrong answer 3?,text|F",
			"wrong3d"=>"What is wrong answer 4?,text|S",
			"wrong3e"=>"What is wrong answer 5?,text|A",
			"wrong3f"=>"What is wrong answer 6?,text|E",
			"wrong3g"=>"What is wrong answer 7?,text|I",
			"wrong3h"=>"What is wrong answer 8?,text|O",
			"wrong3i"=>"What is wrong answer 9?,text|U",
			"May have any number of wrong answers,note",
			"reminder3"=>"Where is the answer to this question from?,text|Days of the Week",
			"quizzer3"=>"Person asking question 3,text|Thor",
			"Use the next set to prepare the next quiz,note",
			"riddle3aa"=>"Backup first line of riddle 3?,text|A flash of lightning",
			"riddle3bb"=>"Backup second line of riddle 3?,text|From a dragon colored this...",
			"riddle3cc"=>"Backup third line of riddle 3?,text|Makes the strongest weak",
			"riddle3dd"=>"Backup fourth line of riddle 3?,text|And the most accurate miss.",
			"riddle3ee"=>"Backup fifth line of riddle 3?,text|",
			"answer31"=>"Backup correct answer?,text|Blue",
			"wrong3aa"=>"Backup wrong answer 1?,text|Black",
			"wrong3bb"=>"Backup wrong answer 2?,text|Red",
			"wrong3cc"=>"Backup wrong answer 3?,text|Brass",
			"wrong3dd"=>"Backup wrong answer 4?,text|Bronze",
			"wrong3ee"=>"Backup wrong answer 5?,text|Red",
			"wrong3ff"=>"Backup wrong answer 6?,text|Platinum",
			"wrong3gg"=>"Backup wrong answer 7?,text|Silver",
			"wrong3hh"=>"Backup wrong answer 8?,text|White",
			"wrong3ii"=>"Backup wrong answer 9?,text|Pink",
			"reminder3a"=>"Where is the answer to this question from?,text|Classic Dungeons and Dragons",
			"quizzer31"=>"Backup Person asking question 3,text|Tiamat",
			"Question 4,title",
			"Leave extra lines blank if there is no additional text,note",
			"riddle4a"=>"What is the first line of riddle 4?,text|What comes next in the series:",
			"riddle4b"=>"What is the second line of riddle 4?,text|1, 2, 6, 24, 120...",
			"riddle4c"=>"What is the third line of riddle 4?,text|",
			"riddle4d"=>"What is the fourth line of riddle 4?,text|",
			"riddle4e"=>"What is the fifth line of riddle 4?,text|",
			"answer4"=>"What is the correct answer?,text|720",
			"wrong4a"=>"What is wrong answer 1?,text|480",
			"wrong4b"=>"What is wrong answer 2?,text|0",
			"wrong4c"=>"What is wrong answer 3?,text|440",
			"wrong4d"=>"What is wrong answer 4?,text|1054",
			"wrong4e"=>"What is wrong answer 5?,text|900",
			"wrong4f"=>"What is wrong answer 6?,text|240",
			"wrong4g"=>"What is wrong answer 7?,text|144",
			"wrong4h"=>"What is wrong answer 8?,text|345",
			"wrong4i"=>"What is wrong answer 9?,text|660",
			"reminder4"=>"Where is the answer to this question from?,text|Factorial sequence",
			"May have any number of wrong answers,note",
			"quizzer4"=>"Person asking question 4,text|Jennings",
			"Use the next set to prepare the next quiz,note",
			"riddle4aa"=>"Backup first line of riddle 4?,text|Creature of evil",
			"riddle4bb"=>"Backup second line of riddle 4?,text|Head of Man",
			"riddle4cc"=>"Backup third line of riddle 4?,text|Wings of a Bat",
			"riddle4dd"=>"Backup fourth line of riddle 4?,text|Body of a Lion.",
			"riddle4ee"=>"Backup fifth line of riddle 4?,text|What do you face?",
			"answer41"=>"Backup correct answer?,text|Manticore",
			"wrong4aa"=>"Backup wrong answer 1?,text|Locathah",
			"wrong4bb"=>"Backup wrong answer 2?,text|Medusa",
			"wrong4cc"=>"Backup wrong answer 3?,text|Minotaur",
			"wrong4dd"=>"Backup wrong answer 4?,text|Merman",
			"wrong4ee"=>"Backup wrong answer 5?,text|Djinni",
			"wrong4ff"=>"Backup wrong answer 6?,text|Displacer Beast",
			"wrong4gg"=>"Backup wrong answer 7?,text|Catoblepas",
			"wrong4hh"=>"Backup wrong answer 8?,text|Spectre",
			"wrong4ii"=>"Backup wrong answer 9?,text|Titanothere",
			"reminder4a"=>"Where is the answer to this question from?,text|Classic Dungeons and Dragons",
			"quizzer41"=>"Backup Person asking question 4,text|Ixitxachitl",
			"Question 5,title",
			"Leave extra lines blank if there is no additional text,note",
			"riddle5a"=>"What is the first line of riddle 5?,text|What comes next in the series:",
			"riddle5b"=>"What is the second line of riddle 5?,text|3,1,4,1,5,9...",
			"riddle5c"=>"What is the third line of riddle 5?,text|",
			"riddle5d"=>"What is the fourth line of riddle 5?,text|",
			"riddle5e"=>"What is the fifth line of riddle 5?,text|",
			"answer5"=>"What is the correct answer?,text|2",
			"wrong5a"=>"What is wrong answer 1?,text|1",
			"wrong5b"=>"What is wrong answer 2?,text|3",
			"wrong5c"=>"What is wrong answer 3?,text|4",
			"wrong5d"=>"What is wrong answer 4?,text|5",
			"wrong5e"=>"What is wrong answer 5?,text|6",
			"wrong5f"=>"What is wrong answer 6?,text|7",
			"wrong5g"=>"What is wrong answer 7?,text|8",
			"wrong5h"=>"What is wrong answer 8?,text|9",
			"wrong5i"=>"What is wrong answer 9?,text|0",
			"reminder5"=>"Where is the answer to this question from?,text|Pi",
			"May have any number of wrong answers,note",
			"quizzer5"=>"Person asking question 5,text|Archimedes",
			"Use the next set to prepare the next quiz,note",
			"riddle5aa"=>"Backup first line of riddle 5?,text|Dinosaurs roam and the wise fill with fear",
			"riddle5bb"=>"Backup second line of riddle 5?,text|This one has a bill and snaps it at you.",
			"riddle5cc"=>"Backup third line of riddle 5?,text|A lashing tail if you get too near...",
			"riddle5dd"=>"Backup fourth line of riddle 5?,text|Tell me its name before you are through!",
			"riddle5ee"=>"Backup fifth line of riddle 5?,text|",
			"answer51"=>"Backup correct answer?,text|Anatosaurus",
			"wrong5aa"=>"Backup wrong answer 1?,text|Apatosaurus",
			"wrong5bb"=>"Backup wrong answer 2?,text|Ceratasaurus",
			"wrong5cc"=>"Backup wrong answer 3?,text|Gorgosaurus",
			"wrong5dd"=>"Backup wrong answer 4?,text|Iguanadon",
			"wrong5ee"=>"Backup wrong answer 5?,text|Elasmosaurus",
			"wrong5ff"=>"Backup wrong answer 6?,text|Dinichtys",
			"wrong5gg"=>"Backup wrong answer 7?,text|Paleoscincus",
			"wrong5hh"=>"Backup wrong answer 8?,text|Monoclonius",
			"wrong5ii"=>"Backup wrong answer 9?,text|Pteranodon",
			"reminder5a"=>"Where is the answer to this question from?,text|Dinosaur literature",
			"quizzer51"=>"Backup Person asking question 5,text|Mr. Hammond",
			"Question 6,title",
			"Leave extra lines blank if there is no additional text,note",
			"riddle6a"=>"What is the first line of riddle 6?,text|What comes next in the series:",
			"riddle6b"=>"What is the second line of riddle 6?,text|A, T, G, C, L, V, L, S, S...",
			"riddle6c"=>"What is the third line of riddle 6?,text|",
			"riddle6d"=>"What is the fourth line of riddle 6?,text|",
			"riddle6e"=>"What is the fifth line of riddle 6?,text|",
			"answer6"=>"What is the correct answer?,text|C",
			"wrong6a"=>"What is wrong answer 1?,text|A",
			"wrong6b"=>"What is wrong answer 2?,text|T",
			"wrong6c"=>"What is wrong answer 3?,text|G",
			"wrong6d"=>"What is wrong answer 4?,text|D",
			"wrong6e"=>"What is wrong answer 5?,text|L",
			"wrong6f"=>"What is wrong answer 6?,text|V",
			"wrong6g"=>"What is wrong answer 7?,text|S",
			"wrong6h"=>"What is wrong answer 8?,text|R",
			"wrong6i"=>"What is wrong answer 9?,text|M",
			"May have any number of wrong answers,note",
			"reminder6"=>"Where is the answer to this question from?,text|Signs of the Zodiac",
			"quizzer6"=>"Person asking question 6,text|Dr. Von Strunckel",
			"Use the next set to prepare the next quiz,note",
			"riddle6aa"=>"Backup first line of riddle 6?,text|Beware of Juiblex,",
			"riddle6bb"=>"Backup second line of riddle 6?,text|Orcus can harm.",
			"riddle6cc"=>"Backup third line of riddle 6?,text|Dispater is dangerous,",
			"riddle6dd"=>"Backup fourth line of riddle 6?,text|Asmodeus will charm.",
			"riddle6ee"=>"Backup fifth line of riddle 6?,text|What creatures do you face?",
			"answer61"=>"Backup correct answer?,text|Devils",
			"wrong6aa"=>"Backup wrong answer 1?,text|Dragons",
			"wrong6bb"=>"Backup wrong answer 2?,text|Undead",
			"wrong6cc"=>"Backup wrong answer 3?,text|Clerics",
			"wrong6dd"=>"Backup wrong answer 4?,text|worms",
			"wrong6ee"=>"Backup wrong answer 5?,text|Titans",
			"wrong6ff"=>"Backup wrong answer 6?,text|Angels",
			"wrong6gg"=>"Backup wrong answer 7?,text|Golems",
			"wrong6hh"=>"Backup wrong answer 8?,text|Mermen",
			"wrong6ii"=>"Backup wrong answer 9?,text|Harpies",
			"reminder6a"=>"Where is the answer to this question from?,text|Classic Dungeons and Dragons",
			"quizzer61"=>"Backup Person asking question 6,text|MacNeil",
			"Question 7,title",
			"Leave extra lines blank if there is no additional text,note",
			"riddle7a"=>"What is the first line of riddle 7?,text|What comes next in the series:",
			"riddle7b"=>"What is the second line of riddle 7?,text|67, 71, 73, 79, 83...",
			"riddle7c"=>"What is the third line of riddle 7?,text|",
			"riddle7d"=>"What is the fourth line of riddle 7?,text|",
			"riddle7e"=>"What is the fifth line of riddle 7?,text|",
			"answer7"=>"What is the correct answer?,text|89",
			"wrong7a"=>"What is wrong answer 1?,text|87",
			"wrong7b"=>"What is wrong answer 2?,text|85",
			"wrong7c"=>"What is wrong answer 3?,text|91",
			"wrong7d"=>"What is wrong answer 4?,text|93",
			"wrong7e"=>"What is wrong answer 5?,text|95",
			"wrong7f"=>"What is wrong answer 6?,text|97",
			"wrong7g"=>"What is wrong answer 7?,text|99",
			"wrong7h"=>"What is wrong answer 8?,text|101",
			"wrong7i"=>"What is wrong answer 9?,text|103",
			"May have any number of wrong answers,note",
			"reminder7"=>"Where is the answer to this question from?,text|Prime numbers",
			"quizzer7"=>"Person asking question 7,text|Cray",
			"Use the next set to prepare the next quiz,note",
			"riddle7aa"=>"Backup first line of riddle 7?,text|It will turn you to stone",
			"riddle7bb"=>"Backup second line of riddle 7?,text|If you glance over its way.",
			"riddle7cc"=>"Backup third line of riddle 7?,text|This feathered gazer",
			"riddle7dd"=>"Backup fourth line of riddle 7?,text|Can make an end of your day.",
			"riddle7ee"=>"Backup fifth line of riddle 7?,text|",
			"answer71"=>"Backup correct answer?,text|Cockatrice",
			"wrong7aa"=>"Backup wrong answer 1?,text|Medusa",
			"wrong7bb"=>"Backup wrong answer 2?,text|Basilisk",
			"wrong7cc"=>"Backup wrong answer 3?,text|Pyrolisk",
			"wrong7dd"=>"Backup wrong answer 4?,text|Asphynx",
			"wrong7ee"=>"Backup wrong answer 5?,text|Catoblepas",
			"wrong7ff"=>"Backup wrong answer 6?,text|Couatl",
			"wrong7gg"=>"Backup wrong answer 7?,text|Spectre",
			"wrong7hh"=>"Backup wrong answer 8?,text|Mimic",
			"wrong7ii"=>"Backup wrong answer 9?,text|Leucrotta",
			"reminder7a"=>"Where is the answer to this question from?,text|Classic Dungeons and Dragons",
			"quizzer71"=>"Backup Person asking question 7,text|Perseus",
			"Question 8,title",
			"Leave extra lines blank if there is no additional text,note",
			"riddle8a"=>"What is the first line of riddle 8?,text|What comes next in the series:",
			"riddle8b"=>"What is the second line of riddle 8?,text|1, 4, 27, 256...",
			"riddle8c"=>"What is the third line of riddle 8?,text|",
			"riddle8d"=>"What is the fourth line of riddle 8?,text|",
			"riddle8e"=>"What is the fifth line of riddle 8?,text|",
			"answer8"=>"What is the correct answer?,text|3125",
			"wrong8a"=>"What is wrong answer 1?,text|1024",
			"wrong8b"=>"What is wrong answer 2?,text|512",
			"wrong8c"=>"What is wrong answer 3?,text|625",
			"wrong8d"=>"What is wrong answer 4?,text|7725",
			"wrong8e"=>"What is wrong answer 5?,text|10,555",
			"wrong8f"=>"What is wrong answer 6?,text|4481",
			"wrong8g"=>"What is wrong answer 7?,text|1",
			"wrong8h"=>"What is wrong answer 8?,text|88",
			"wrong8i"=>"What is wrong answer 9?,text|257",
			"May have any number of wrong answers,note",
			"reminder8"=>"Where is the answer to this question from?,text|Number to the power of itself",
			"quizzer8"=>"Person asking question 8,text|Chole",
			"Use the next set to prepare the next quiz,note",
			"riddle8aa"=>"Backup first line of riddle 8?,text|To the sea you must go",
			"riddle8bb"=>"Backup second line of riddle 8?,text|If you wish to speak to this race",
			"riddle8cc"=>"Backup third line of riddle 8?,text|For they live in the water",
			"riddle8dd"=>"Backup fourth line of riddle 8?,text|Take a deep breath to meet face to face.",
			"riddle8ee"=>"Backup fifth line of riddle 8?,text|",
			"answer81"=>"Backup correct answer?,text|Locathah",
			"wrong8aa"=>"Backup wrong answer 1?,text|Halfling",
			"wrong8bb"=>"Backup wrong answer 2?,text|Bugbear",
			"wrong8cc"=>"Backup wrong answer 3?,text|Ki-rin",
			"wrong8dd"=>"Backup wrong answer 4?,text|Xorn",
			"wrong8ee"=>"Backup wrong answer 5?,text|Neo-Otyugh",
			"wrong8ff"=>"Backup wrong answer 6?,text|Lammasu",
			"wrong8gg"=>"Backup wrong answer 7?,text|Homonculous",
			"wrong8hh"=>"Backup wrong answer 8?,text|Gnoll",
			"wrong8ii"=>"Backup wrong answer 9?,text|Ettin",
			"reminder8a"=>"Where is the answer to this question from?,text|Classic Dungeons and Dragons",
			"quizzer81"=>"Backup Person asking question 8,text|Icthion",
		),
		"prefs"=>array(
			"Quiz Load Preferences,title",
			"mainintro"=>"Has the player heard the Main opening Spiel?,bool|0",
			"current"=>"What riddle is the player currently solving?,int|0",
			"solved1"=>"Solved Riddle 1?,bool|0",
			"solved2"=>"Solved Riddle 2?,bool|0",
			"solved3"=>"Solved Riddle 3?,bool|0",
			"solved4"=>"Solved Riddle 4?,bool|0",
			"solved5"=>"Solved Riddle 5?,bool|0",
			"solved6"=>"Solved Riddle 6?,bool|0",
			"solved7"=>"Solved Riddle 7?,bool|0",
			"solved8"=>"Solved Riddle 8?,bool|0",
			"solvedquiz"=>"Has the player solved all riddles in this quiz?,bool|0",
			"triedtoday"=>"Tried Today?,bool|0",
			"Quiz History,title",
			"quiztotal"=>"How many quizzes has this player solved?,int|0",
			"quizsolv1"=>"1st Quiz solved:,text|0",
			"quizsolv2"=>"2nd Quiz solved:,text|0",
			"quizsolv3"=>"3rd Quiz solved:,text|0",
			"quizsolv4"=>"4th Quiz solved:,text|0",
			"quizsolv5"=>"5th Quiz solved:,text|0",
			"quizsolv6"=>"6th Quiz solved:,text|0",
			"quizsolv7"=>"7th Quiz solved:,text|0",
			"quizsolv8"=>"8th Quiz solved:,text|0",
			"quizsolv9"=>"9th Quiz solved:,text|0",
			"quizsolv10"=>"10th Quiz solved:,text|0",
			"quizsolv11"=>"11th Quiz solved:,text|0",
			"quizsolv12"=>"12th Quiz solved:,text|0",
			"quizsolv13"=>"13th Quiz solved:,text|0",
			"quizsolv14"=>"14th Quiz solved:,text|0",
			"quizsolv15"=>"15th Quiz solved:,text|0",
			"quizsolv16"=>"16th Quiz solved:,text|0",
			"quizsolv17"=>"17th Quiz solved:,text|0",
			"quizsolv18"=>"18th Quiz solved:,text|0",
			"quizsolv19"=>"19th Quiz solved:,text|0",
			"quizsolv20"=>"20th Quiz solved:,text|0",
		),
	);
	return $info;
}

function quizload_install() {
	module_addhook("village");
	module_addhook("newday");
	module_addhook("newday-runonce");
	module_addhook("changesetting");
	module_addhook("bioinfo");
    module_addhook("footer-prefs");
	return true;
}
function quizload_uninstall() {
	return true;
}

function quizload_dohook($hookname,$args) {
	global $session;
	global $session, $REQUEST_URI;
	$userid = $session[user][acctid];
	$argsid = $args[acctid];
	$argsname = $args[login];
	switch($hookname) {
		case "changesetting":
			if ($args['setting'] == "villagename") {
				if ($args['old'] == get_module_setting("quizloadloc")) set_module_setting("quizloadloc", $args['new']);
			}
		break;
		case "village":
			if ($session['user']['location'] == get_module_setting("quizloadloc") && get_module_setting("quizhold")==0){
				tlschema($args["schemas"]["marketnav"]);
				addnav($args["marketnav"]);
				tlschema();
				addnav("Quiz HQ","runmodule.php?module=quizload&op=quizload");
			}
		break;
		case "bioinfo":
			if (get_module_setting("quizbookbio")==1 && get_module_pref("quiztotal","quizload",$args[acctid])>=1) addnav("Quiz Book","runmodule.php?module=quizload&op=quizbook&user=$argsid&username=$argsname&return=".URLencode($_SERVER['REQUEST_URI']));
		break;
		case "newday-runonce":
			increment_module_setting("currentlong",1);
			if (get_module_setting("resetquiz")==1){
       			$sql = "update ".db_prefix("module_userprefs")." set value=0 where value<>0 and setting='solvedquiz' and modulename='quizload'";
       			db_query($sql);
       			$sql = "update ".db_prefix("module_userprefs")." set value=0 where value<>0 and setting='triedtoday' and modulename='quizload'";
       			db_query($sql);				
       			$sql = "update ".db_prefix("module_userprefs")." set value=0 where value<>0 and setting='solved1' and modulename='quizload'";
       			db_query($sql);				
       			$sql = "update ".db_prefix("module_userprefs")." set value=0 where value<>0 and setting='solved2' and modulename='quizload'";
       			db_query($sql);				
       			$sql = "update ".db_prefix("module_userprefs")." set value=0 where value<>0 and setting='solved3' and modulename='quizload'";
       			db_query($sql);				
       			$sql = "update ".db_prefix("module_userprefs")." set value=0 where value<>0 and setting='solved4' and modulename='quizload'";
       			db_query($sql);				
       			$sql = "update ".db_prefix("module_userprefs")." set value=0 where value<>0 and setting='solved5' and modulename='quizload'";
       			db_query($sql);				
       			$sql = "update ".db_prefix("module_userprefs")." set value=0 where value<>0 and setting='solved6' and modulename='quizload'";
       			db_query($sql);				
       			$sql = "update ".db_prefix("module_userprefs")." set value=0 where value<>0 and setting='solved7' and modulename='quizload'";
       			db_query($sql);				
       			$sql = "update ".db_prefix("module_userprefs")." set value=0 where value<>0 and setting='solved8' and modulename='quizload'";
       			db_query($sql);				
				set_module_setting("resetquiz",0);
				set_module_setting("quizhold",0);
				set_module_setting("currentlong",0);
				set_module_setting("currentwin",0);
			}
		break;
		case "newday":
			set_module_pref("triedtoday",0);
		break;
	}
	return $args;
}
function quizload_run(){
	$op = httpget('op');
	global $SCRIPT_NAME;
	if ($SCRIPT_NAME == "runmodule.php"){
		$module=httpget("module");
		if ($module == "quizload") include("modules/quizload/quizload.php");
	}
}
?>