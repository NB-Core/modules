<?php
/*
"name"=>     the Fireplace, 
"version"=>  1.0 THIS ONE IS FOR LOGD v097 - check which version of LoGD you run!!, 
"author"=>   Robert of Maddnet LoGD, 
"category"=> Inn ADD-ON - Holiday mod, 
"install"=>  Very easy
"download"=> Available at Dragon Prime - http://dragonprime.net/

This mod offers each player 1 gift on Christmas Day and Valentines Day
-- Just think of how many other occassions or holidays you can add to it!!

Install instructions:
install a field in your db:

ALTER TABLE `accounts` ADD `gift` TINYINT( 1 ) DEFAULT '0' NOT NULL ;

1). Look through the file to see if you need to edit anything
2). open inn.php
	look for:  addnav("Cedrik the Barkeep","inn.php?op=bartender");
	ADD this UNDER it:  if (@file_exists("fireplace.php"))  addnav("the fireplace","fireplace.php");
3). Open user.php
	find:  "seenbard"=>"Heard bard,bool",
	UNDER it add:  "gift"=>"Got free Inn gift?,bool",                      
3). SAVE and upload inn.php, user.php and fireplace.php into your logd folder

Feel free to edit as you need to but please leave this entire comment tag unedited and in place
*/
require_once "common.php";
page_header("the Inn");
$name=$session['user']['name'];
output("`c`b<font size='+1'>`\$the Fireplace`b`c`n`n`&</font>",true);
output(" You stroll over to the Large Granite Stone fireplace - you can see there are many logs ablaze and the fire is cracklin. ");
if (date("m-d")=="12-05"){
	output("`nTodays date is 5 Dec - only 20 days till xmas");
	addnav("leave fireplace");
	addnav("(R) Return to Inn","inn.php");
}
else if (date("m-d")=="12-10"){
	output("You notice Violet the Barmaid and Seth the Bard are putting up a Christmas tree. You watch as they decorate ");
	output(" the tree with beautiful ornaments. ");
	addnav("leave fireplace");
	addnav("(R) Return to Inn","inn.php");
}
else if (date("m-d")=="12-20"){
	output("You notice Violet the Barmaid is busy hanging stockings on the mantle above the fireplace. As you get a closer look, ");
	output(" you can see each stocking has a name scribed upon it. HEY! she's putting one up right now with YOUR name on it! ");
	addnav("leave fireplace");
	addnav("(R) Return to Inn","inn.php");
}
else if (date("m-d")=="12-21"){
	output("`& You notice all the `2s`\$t`2o`\$c`2k`\$i`2n`\$g`2s `&on the mantle above the fireplace. As you get a closer look, ");
	output(" you search for the one with your name scribed upon it. Ah! There it is! `n`n`&Only four more days till Christmas. ");
	addnav("leave fireplace");
	addnav("(R) Return to Inn","inn.php");
}
else if (date("m-d")=="12-22"){
	output("`& You notice all the `2s`\$t`2o`\$c`2k`\$i`2n`\$g`2s `&on the mantle above the fireplace. As you get a closer look, ");
	output(" you search for the one with your name scribed upon it. Ah! There it is! `n`n`&Only three more days till Christmas. ");
	addnav("leave fireplace");
	addnav("(R) Return to Inn","inn.php");
}
else if (date("m-d")=="12-23"){
	output("`& You notice all the `2s`\$t`2o`\$c`2k`\$i`2n`\$g`2s `&on the mantle above the fireplace. As you get a closer look, ");
	output(" you search for the one with your name scribed upon it. Ah! There it is! `n`n`&Only two more days till Christmas. ");
	addnav("leave fireplace");
	addnav("(R) Return to Inn","inn.php");
}
else if (date("m-d")=="12-24"){
	output("`& You notice all the `2s`\$t`2o`\$c`2k`\$i`2n`\$g`2s `&on the mantle above the fireplace. As you get a closer look, ");
	output(" you search for the one with your name scribed upon it. Ah! There it is! `n`n");
	output(" Villager's gather around the Fireplace and sing Christmas Carols. `n`n`&Only one more day till Christmas. ");
	addnav("leave fireplace");
	addnav("(R) Return to Inn","inn.php");
}
else if (date("m-d")=="12-25"){
	if ($session['user']['gift']==0){
	output("`& You notice all the `2s`\$t`2o`\$c`2k`\$i`2n`\$g`2s `&on the mantle above the fireplace. As you get a closer look, ");
	output(" you search for the one with your name scribed upon it. Ah! There it is!! `n`n`&Hey! It looks as if your stocking is full!! ");
	output(" `n`nYou reach for the stocking that says $name `&on it and take it down. Looking inside you find ");
	addnav("leave fireplace");
	addnav("(R) Return to Inn","inn.php");
	$session['user']['gift']=1;
	switch (e_rand(1,6)) {
		case 1:
		output(" someone has given you 10 forest fights!  ");
		$session['user']['turns']+=10;
		break;
		case 2:
		output(" someone has given you 2 gems!  ");
		$session['user']['gems']+=2;
		debuglog(" received `^2 gems `0from the Fireplace in the Inn");
		break;
		case 3:
		output(" someone has given you 200 gold!  ");
		$session['user']['gold']+=200;
		debuglog(" received `^200 gold `0from the Fireplace in the Inn");
		break;
		case 4:
		output(" someone has given you 3 gems!  ");
		$session['user']['gems']+=3;
		debuglog(" received `^3 gems `0from the Fireplace in the Inn");
		break;
		case 5:
		output(" someone has given you 300 gold!  ");
		$session['user']['gold']+=300;
		debuglog(" received `^300 gold `0from the Fireplace in the Inn");
		break;
		case 6:
		output(" someone has given you a basket of cheer!  ");
		$buff = array("name"=>"`2Holiday Cheer`0","rounds"=>75,"wearoff"=>"`4`bYou're happiness fades!.`b`0","atkmod"=>1.2,"defmod"=>1.2,"roundmsg"=>"`2Your joy increase's your fighting abilities!`0","activate"=>"offense");
        $session['bufflist']['magicweak']=$buff;
		break;
		}
	}else{
	output(" You appoach the Fireplace `ionce more`i today - DOH! you already emptied your stocking!!");
	addnav("leave fireplace");
	addnav("(R) Return to Inn","inn.php");
	}
}
else if (date("m-d")=="02-13"){
	output("You notice Violet the Barmaid is busy placing `\$red heart shaped `i`^Valentines Day cards`i `&on the mantle above the fireplace. As you get a closer look, ");
	output(" you can see each heart shaped card has a name scribed upon it. HEY! she's putting one up right now with YOUR name on it! ");
	addnav("leave fireplace");
	addnav("(R) Return to Inn","inn.php");
}
else if (date("m-d")=="02-14"){
	if ($session['user']['gift']==0){
	output("You approach the Fireplace and search for card that says $name on it. Ahh! There it is! ");
	output(" You open the card and see it is from your true love! You read what it says,`n`n");
	output(" `\$Roses are Red, `%Violets are `!blue,`n");
	output(" `^besides my Love, I send to you,`n");
	addnav("leave fireplace");
	addnav("(R) Return to Inn","inn.php");
	$session['user']['gift']=1;
	switch (e_rand(1,6)) {
		case 1:
		output(" the endurance for 5 more forest fights!  ");
		$session['user']['turns']+=5;
		break;
		case 2:
		output(" this lovely gem!  ");
		$session['user']['gems']+=1;
		debuglog(" received `^1 gem `0from the Fireplace in the Inn");
		break;
		case 3:
		output(" a big wet sloppy kiss and 10 charm points!  ");
		$session['user']['charm']+=10;
		debuglog(" received `^10 charm `0from the Fireplace in the Inn");
		break;
		case 4:
		output(" these 2 beautiful gems!  ");
		$session['user']['gems']+=2;
		debuglog(" received `^2 gems `0from the Fireplace in the Inn");
		break;
		case 5:
		output(" my pouch with 200 gold in it!  ");
		$session['user']['gold']+=200;
		debuglog(" received `^200 gold `0from the Fireplace in the Inn");
		break;
		case 6:
		output(" a basket of cheer!  ");
		$buff = array("name"=>"`2Holiday Cheer`0","rounds"=>50,"wearoff"=>"`4`bYou're happiness fades!.`b`0","atkmod"=>1.2,"defmod"=>1.2,"roundmsg"=>"`2Your joy increase's your fighting abilities!`0","activate"=>"offense");
        $session['bufflist']['magicweak']=$buff;
		break;
		}
	}else{
	output(" `&You approach the Fireplace `ionce more`i - DOH! You already looked at your Valentines Day Card!");
	addnav("leave fireplace");
	addnav("(R) Return to Inn","inn.php");
	}
}else{
	output(" You notice how really `\$hot `&it is standing next to it. ");
	addnav("leave fireplace");
	addnav("(R) Return to Inn","inn.php");
}
page_footer();
?>