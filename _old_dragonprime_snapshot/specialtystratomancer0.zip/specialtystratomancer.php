<?php
//addnews ready
//mail ready
//translator ready

/****************************************************\
*         The Stratomancer - Version 1.0             *
*   Proposed feature - Weather change button hooked  *
*   into the village (will tie in with future weather*
*   related modules	       							             *
\****************************************************/

// Made the weather control work
// Made the 'How many points do you need before the specialty is available?' work
// -- CortalUX


function specialtyStratomancer_getmoduleinfo(){
	$info = array(
		"name"=>"Specialty - Stratomancer",
		"author"=>"`#Lightbringer`3<br>modified by `@CortalUX`3<br>and `!Enderwiggin`3",
		"version"=>"1.1",
		"download"=>"http://dragonprime.net/users/Enderwiggin/specialitystratomancer.zip",
		"vertxtloc"=>"http://dragonprime.net/users/enderwiggin/",
		"category"=>"Specialties",
		"prefs"=>array(
			"Stratomancer,title",//shortened it to look better in the userprefs
			"check_img"=>"Show stratomancer summon IMAGES or text?,enum,0,Use an Image,1,Use Text|0",
			"skill"=>"Skill points in Weather Control,int|0",
			"uses"=>"Uses of Weather Control allowed,int|0",
		),
		"settings"=>array(
			"Specialty - Stratomancer Settings,title",
			"mindk"=>"How many DKs do you need before the specialty is available?,int|5",
			"cost"=>"How many points do you need before the specialty is available?,int|5",
		),
	);
	return $info;
}

function specialtystratomancer_install(){
	if (!is_module_active('specialtystratomancer')){
		output("`n`c`b`QSpecialty Stratomancer - Module - Installed`0`b`c");
	}else{
		output("`n`c`b`QSpecialty Stratomancer - Module - Updated`0`b`c");
	}
	$specialty="ST";
	module_addhook("apply-specialties");
	module_addhook("castlelibbook");
	module_addhook("castlelib");
	module_addhook("checkuserpref");
	module_addhook("choose-specialty");
	module_addhook("dragonkill");
	module_addhook("fightnav-specialties");
	module_addhook("incrementspecialty");
	module_addhook("newday");
	module_addhook("pointsdesc");
	module_addhook("set-specialty");
	module_addhook("shades");
	module_addhook("specialtycolor");
	module_addhook("specialtymodules");
	module_addhook("specialtynames");
	module_addhook("village");
	return true;
}

function specialtystratomancer_uninstall(){
	output("`n`c`b`QSpecialty Stratomancer - Module - Uninstalled`0`b`c");
	// Reset the specialty of anyone who had this specialty so they get to
	// rechoose at new day
	$sql = "UPDATE " . db_prefix("accounts") . " SET specialty='' WHERE specialty='ST'";
	db_query($sql);
	return true;
}

function specialtystratomancer_dohook($hookname,$args){
	global $session,$resline;
	tlschema("fightnav");

	$spec = "ST";
	$name = "Weather Control";
	$ccode = "`!";
	$cost = get_module_setting("cost");
	$op69 = httpget('op69');

	switch ($hookname) {
	case "apply-specialties":
		$skill = httpget('skill');
		$l = httpget('l');
		if ($skill==$spec){
			if (get_module_pref("uses") >= $l){
				switch($l){

                case 1:
					apply_buff('st1', array(
						"startmsg"=>"`^The fog envelops your target!",
						"name"=>"`@Fogweaving",
						"rounds"=>5,
						"wearoff"=>"The fog disperses into the aether.",
						"badguyatkmod"=>0.5,
						"effectmsg"=>"The {badguy} is wrapped in fog, making it near impossible for it to see.",
						"minbadguydamage"=>0.5,
						"schema"=>"specialtystratomancer"
					));
					break;
				case 2:
					apply_buff('st2', array(
						"startmsg"=>"`@You smile sernely at`^{badguy}`@ and feel the temperature drop as you weave your spell!",
						"name"=>"`@Blizzard Summoning",
						"rounds"=>8,
						"wearoff"=>"The sun shines through the storm clouds...",
						"minioncount"=>5,
                        "badguydefmod"=>0.3,
                        "effectmsg"=>"`^Sharp slivers of ice hail down from the clouds, and pierce {badguy} like a pincushion, incurring `@{damage}`^ points.`)",
						"minbadguydamage"=>15,
						"maxbadguydamage"=>$session['user']['level']*10,
						"schema"=>"specialtystratomancer"
					));
					break;
				case 3:
					apply_buff('st3', array(
						"startmsg"=>"`@A swirling vortex of harnessed wind energy appears between you and your enemy!",
						"name"=>"`@Wind Wall",
						"rounds"=>10,
						"wearoff"=>"`^The wind dissipates and {badguy} grins evilly as he prepares to launch an attack!`)",
						"atkmod"=>-5,
						"defmod"=>5,
                        "badguyatkmod"=>0.75,
                        "badguydefmod"=>1.5,
                        "effectmsg"=>"`%The wind wall forms an almost impassable barrier.`)",
						"effectfailmsg"=>"The wind howls in rage at {badguy}.",
						"schema"=>"specialtystratomancer"
					));
					break;
				case 5:
					apply_buff('st5', array(
						"startmsg"=>"`^Pouring all of your power out, you call forth an ominous storm cloud. The air crackles with electricity",
						"name"=>"`@Call Lightning",
						"rounds"=>5,
                        "minioncount"=>5,
                        "minbadguydamage"=>round($session['user']['attack']*2,0),
                        "maxbadguydamage"=>round($session['user']['attack']*4,0),
                        "effectmsg"=>"{badguy}`% falls to the ground convulsing as pure electricity arcs through him for`^{damage}`% damage.",
						"effectnodmg"=>"{badguy}`& is slightly charred and less than amused.",
						"schema"=>"specialtystratomancer"
					));
					break;
				}

                    set_module_pref("uses", get_module_pref("uses") - $l);
			}else{
				apply_buff('st0', array(
					"startmsg"=>"You attempt to draw the forces of nature back in for your assault - a flashing display of harnessed lightning, but you just sense a void. {badguy} shakes his head and charges.",
					"rounds"=>1,
					"schema"=>"specialtystratomancer"
				));
			}
		}
		break;
	case "castlelibbook":
		output("Meteorology for Dummies. (3 Turns)`n");
		addnav("Read a Book");
		addnav("Meteorology for Dummies","runmodule.php?module=lonnycastle&op=library&op69=stratomancer");
		break;
	case "castlelib":
		if ($op69 == 'stratomancer'){
			output("You sit down and open up the Meteorology for Dummies book.`n");
			output("You read for a while... in the time it takes you to read you use up`n");
			output("3 Turns.`n`n");
			output("You find the book quite informative on how to predict whether it's going to hail or  `n");
			output("snow by sniffing various animal crotches.  You wonder if finding the book useful makes `n");
			output("you a Dummie.  Oh well, now you feel more confident in your abilities to control the weather!`n");
			$session['user']['turns']-=3;
			set_module_pref('skill',(get_module_pref('skill','specialtystratomancer') + 1),'specialtystratomancer');
			set_module_pref('uses', get_module_pref("uses",'specialtystratomancer') + 1,'specialtystratomancer');
			addnav("Continue","runmodule.php?module=lonnycastle&op=library");
		}
		break;
	case "checkuserpref":
			$args['allow']=false;
			if ($session['user']['specialty']==$spec) {
				$args['allow']=true;
			}
	break;
	case "choose-specialty":
		if ($session['user']['dragonkills']>=get_module_setting("mindk")&&$session['user']['donation']>=get_module_setting("cost")) {
			if ($session['user']['specialty'] == "" ||
				$session['user']['specialty'] == '0') {
				addnav("$ccode$name`0","newday.php?setspecialty=".$spec."$resline");
				$t1 = translate_inline("Harnessing weather to your advantage");
				$t2 = appoencode(translate_inline("$ccode$name`0"));
				rawoutput("<a href='newday.php?setspecialty=$spec$resline'>$t1 ($t2)</a><br>");
				addnav("","newday.php?setspecialty=$spec$resline");
			}
		}
		break;
	case "dragonkill":
		set_module_pref("uses", 0);
		set_module_pref("skill", 0);
	break;
	case "fightnav-specialties":
		$uses = get_module_pref("uses");
		$script = $args['script'];
		if ($uses > 0) {
			addnav(array("%s%s (%s points)`0", $ccode, $name, $uses), "");
			addnav(array("%s &#149; Fogweaving`7 (%s)`0", $ccode, 1),
					$script."op=fight&skill=$spec&l=1", true);
		}
		if ($uses > 1) {
			addnav(array("%s &#149; Blizzard Summoning`7 (%s)`0", $ccode, 2),
					$script."op=fight&skill=$spec&l=2",true);
		}
		if ($uses > 2) {
			addnav(array("%s &#149; Wind Wall`7 (%s)`0", $ccode, 3),
					$script."op=fight&skill=$spec&l=3",true);
		}
		if ($uses > 4) {
			addnav(array("%s &#149; Call Lightning`7 (%s)`0", $ccode, 5),
					$script."op=fight&skill=$spec&l=5",true);
		}
		break;
	case "incrementspecialty":
		if($session['user']['specialty'] == $spec) {
			$new = get_module_pref("skill") + 1;
			set_module_pref("skill", $new);
			$c = $args['color'];
			output("`n%sYou gain a level in `&%s%s to `#%s%s!",
					$c, $name, $c, $new, $c);
			$x = $new % 3;
			if ($x == 0){
				output("`n`^You gain an extra use point!`n");
				set_module_pref("uses", get_module_pref("uses") + 1);
			}else{
				if (3-$x == 1) {
					output("`n`^Only 1 more skill level until you gain an extra use point!`n");
				} else {
					output("`n`^Only %s more skill levels until you gain an extra use point!`n", (3-$x));
				}
			}
			output_notl("`0");
		}
		break;
	case "newday":
		$bonus = getsetting("specialtybonus", 1);
		if($session['user']['specialty'] == $spec) {
			if ($bonus == 1) {
				output("`n`2For being interested in %s%s`2, you receive `^1`2 extra `&%s%s`2 use for today.`n",$ccode,$name,$ccode,$name);
			} else {
				output("`n`2For being interested in %s%s`2, you receive `^%s`2 extra `&%s%s`2 uses for today.`n",$ccode,$name,$bonus,$ccode,$name);
			}
		}
		$amt = (int)(get_module_pref("skill") / 3);
		if ($session['user']['specialty'] == $spec) $amt++;
		set_module_pref("uses", $amt);
		break;
	case "pointsdesc":
		$cost = get_module_setting("cost");
		if ($cost > 0) {
			$args['count']++;
			$format = $args['format'];
			$str = translate("The Stratomancer Specialty is availiable upon reaching %s Dragon Kills and %s points.");
			$str = sprintf($str, get_module_setting("mindk"),$cost);
		}
		output($format, $str, true);
	break;
	case "set-specialty":
		if($session['user']['specialty'] == $spec) {
			page_header($name);
			$t = translate_inline("Kargish barbarians descended upon the realm of Skara - obliterating village after village...You heard the tales of the Kargs sailing over from the western realms on 30 great longships and could sense the fear of the villagers frantically gathering up their meagre possessions. You felt their presence - pure bloodlust and disregard - they are not far....Suddenly - you remembered an old weatherworking charm that was taught to you when you were just a child...It was called fog-weaving, a simplecharm but you instinctively knew how to mould and bend it to your will...You stood there in the middle of the village as the warriors prepare to engage the enemy which are now a scant mile away. You could see the plumes os smoke from your nearby village - Ten Alders. Calling upon the pure power of the skies, you began to softly chant - weaving the fog around every inch of the village...Exhausted and depleted, yoiu simply stated...\"I have hidden us all...\". The Kargs walked right through the village - towards the Atuan Cliffs, those that didn't plummet to their deaths were picked off by the villagers - attacking like thieves from the mist....");
			output("`@".$t."");
		}
		break;
	case "shades":
			if (get_module_pref('uses')>1&&$session['user']['specialty']==$spec&&is_module_active('weather')) {
				rawoutput(specialtystratomancer_image("button2.png","Change the weather...","runmodule.php?module=specialtystratomancer&op=change"));
			}
	break;
	case "specialtycolor":
		$args[$spec] = $ccode;
		break;
	case "specialtymodule":
		$args[$spec] = "specialtystratomancerskills";
	break;
	case "specialtynames":
		$args[$spec] = translate_inline($name);
		break;
	case "village":
			if (get_module_pref('uses')>1&&$session['user']['specialty']==$spec&&is_module_active('weather')) {
				$i=e_rand(1,3);
				rawoutput(specialtystratomancer_image("button$i.png","Change the weather...","runmodule.php?module=specialtystratomancer&op=change"));
			}
	break;
	}
	return $args;
}

function specialtystratomancer_run(){
	global $session;
	$op=httpget('op');
	$micro=get_module_setting('microloc','weather');
	if (get_module_setting('enablemicro','weather')==0) $micro="";
	if ($session['user']['alive']==0&&get_module_setting('enableshades','weather')==1) {
		$cg="shadeswx";
		$xt=translate_inline("the shades");
	} elseif ($session['user']['location']==$micro) {
		$cg="microwx";
		$xt=$micro;
	} else {
		$cg="weather";
		$xt=translate_inline("the wider world");
	}
	$set=get_module_setting($cg,'weather');
	$wthr=array();
	$x=0;
	while ($x<8) {
		$x++;
		$wthr[$x]=get_module_setting($cg."$x",'weather');
	}
	switch ($op) {
		case "change":
			page_header("Weather Changing");
			addnav("","runmodule.php?module=specialtystratomancer&op=changed");
			rawoutput("<form action='runmodule.php?module=specialtystratomancer&op=changed' method='post'>");
			output("`@The weather in your area is currently `^%s`@.`nChoose a weather from below, to change it. You will cast one use point... you have `^%s`@.`n",$set,get_module_pref('uses'));
			foreach ($wthr as $num=>$name) {
				if ($name==$set) {
					output_notl("<input type='radio' checked name='newweth' value='$num'>`7$name</input>`n",true);
				} else {
					output_notl("<input type='radio' name='newweth' value='$num'>`&$name</input>`n",true);
				}
			}
			$c=translate_inline("Change..");
			rawoutput("<input type='submit' class='button' value='$c'></form>");
		break;
		case "changed":
			page_header("Your mighty power...");
			$w=httppost('newweth');
			if (!is_numeric($w)) $w=1;
			set_module_setting($cg,get_module_setting($cg.$w,'weather'),'weather');
			set_module_pref("uses", get_module_pref("uses") - 1);
			output("`@Summoning the power of weather-working, you chant words of power; though words don't always work the same everywhere, it appears to work... the weather changes suddenly.. it is now... `^%s`@.`nYou have `%cast`@ a use point.",get_module_setting($cg.$w,'weather'));
			require_once('lib/addnews.php');
			addnews("%s`0`@ has used stratomancing to change the weather of `^%s`0`@ to `^%s`@...",$session['user']['name'],$xt,get_module_setting($cg.$w,'weather'));
		break;
	}
	addnav("Navigation");
	addnav("Return whence you came...","village.php");
	page_footer();
}

function specialtystratomancer_image($file="",$text="",$page="") {
	$text=translate_inline($text);
	if (get_module_pref('check_img')==0) {
		$str="<div align='center' style='align:center;'><a style='border:0;' href='$page'><img border='0' style='border:0;' src='./images/specialtystratomancer/$file' alt='$text'/></a></div>";
	} else {
		$str=appoencode("`c`&[<a href='$page' class='colLtYellow'>".htmlentities($text)."</a>`&]`c",true);
	}
	addnav("",$page);
	return $str;
}
?>
