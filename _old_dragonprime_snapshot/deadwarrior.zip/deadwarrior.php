<?php

function deadwarrior_getmoduleinfo(){
	$info = array(
	"name"=>"Dead Warrior",
	"version"=>"1.0",
	"author"=>"`6Harry Balzitch",
	"category"=>"Forest Specials",
	"download"=>"http://dragonprime.net/users/Harry%20B/deadwarrior.zip",
	"settings"=>array(
	"Dead Warrior Settings,title",
	"mingold"=>"Minimum gold to find,range,10,50,5|10",
	"maxgold"=>"Maximum gold to find,range,100,1000,10|100"
	),
	);
	return $info;
}

function deadwarrior_install(){
	module_addeventhook("forest","return 100;");
	return true;
}

function deadwarrior_uninstall(){
	return true;
}

function deadwarrior_dohook($hookname,$args){
	return $args;
}

function deadwarrior_runevent($type)
{
	global $session;
	$min = $session['user']['level']*get_module_setting("mingold");
	$max = $session['user']['level']*get_module_setting("maxgold");
	$gold = e_rand($min, $max);
	output("`n`2You stumble over a body! `n`nUpon getting up off the ground you decide to investigate a bit.");
	output("`n`n Under the dirt and leaves, you find the body of a slain warrior. `n`nAs you turn over the remains you find a pouch filled with %s gold!", $gold);
	$session['user']['gold']+=$gold;
	debuglog("found $gold gold in the forest");
}

function deadwarrior_run(){
}
?>