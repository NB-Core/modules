-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
Speciality - Tactics Skills - A module for Legend of the Green Dragon 1.0.3

Legend of the Green Dragon
by  Eric "MightyE" Stevens (http://www.mightye.org)
and JT "Kendaer" Traub (http://www.dragoncat.net)

Software Project Page:
http://sourceforge.net/projects/lotgd

Modification Community Page:
http://dragonprime.net

Author of this Module:
Original - Lonny Luberts
Rewritten by - Enderandrew (enderandrew@gmail.com)

Enderandrew's LoGD game:
http://enderandrew.com/lotgd/

Download the latest version of this module from:
http://dragonprime.net/index.php?action=viewfiles&user=enderwiggin

----------------------------------------------
-- STATUS: -----------------------------------
----------------------------------------------
This module is STABLE.

----------------------------------------------
-- INFORMATION: ------------------------------
----------------------------------------------
I started with one small tweak to this module, and before you know it, I basically
completely rewrote it.  The idea for the module originated from Lonny and Sixf00t4,
but most everything has been replaced.

All the buffs/effects are new.

This module requires version 1.0.3 or later of LotGD.

----------------------------------------------
-- INSTALLATION: -----------------------------
----------------------------------------------
Copy specialtytacticsskills.php within this zip into your modules directory.

Login to the Superuser Grotto and Install / Activate it.

-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-