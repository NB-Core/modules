<?php
// Based on Theivery Skills, Info Based on Sixf00t4's 9.7 Specialties Mod
/*
I started with one small tweak to Lonny's module.  But I wasn't happy with the
balance of the modules, and I have already rewritten half the specialty modules
tonight anyway, so why stop there.  So, this got a complete rewrite.

-- Enderandrew
*/
function specialtytacticsskills_getmoduleinfo(){
	$info = array(
		"name" => "Specialty - Tactics",
		"author" => "Rewritten by `!Enderandrew<br>original by `3Lonny Luberts<br>`^based on work by Sixf00t4",
		"version" => "1.31",
		"description"=>"Adds a Tactical Specialty to the game.",
		"download" => "http://dragonprime.net/users/enderwiggin/specialtytacticssskills.zip",
		"vertxtloc"=>"http://dragonprime.net/users/enderwiggin/",
		"category" => "Specialties",
		"settings"=> array(
			"Specialty - Tactics Settings,title",
			"mindk"=>"How many DKs do you need before the specialty is available?,int|10",
			"cost"=>"How many points do you need before the specialty is available?,int|0",
		),
		"prefs" => array(
			"Specialty - Tactics Skills User Prefs,title",
			"skill"=>"Skill points in Tactics Skills,int|0",
			"uses"=>"Uses of Tactics Skills allowed,int|0",
		),
	);
	return $info;
}

function specialtytacticsskills_install(){
	$specialty="TA";
	module_addhook("apply-specialties");
	module_addhook("castlelib");
	module_addhook("castlelibbook");
	module_addhook("choose-specialty");
	module_addhook("dragonkill");
	module_addhook("fightnav-specialties");
	module_addhook("incrementspecialty");
	module_addhook("newday");
	module_addhook("pointsdesc");
	module_addhook("set-specialty");
	module_addhook("specialtycolor");
	module_addhook("specialtymodules");
	module_addhook("specialtynames");
	return true;
}

function specialtytacticsskills_uninstall(){
	// Reset the specialty of anyone who had this specialty so they get to
	// rechoose at new day
	$sql = "UPDATE " . db_prefix("accounts") . " SET specialty='' WHERE specialty='TA'";
	db_query($sql);
	return true;
}

function specialtytacticsskills_dohook($hookname,$args){
	global $session,$resline;
	tlschema("fightnav");

	$spec = "TA";
	$name = "Tactics Skills";
	$ccode = "`7";
	$cost = get_module_setting("cost");
	$op69 = httpget('op69');

	switch ($hookname) {

	case "apply-specialties":
		$skill = httpget('skill');
		$l = httpget('l');
		if ($skill==$spec){
			if (get_module_pref("uses") >= $l){
				switch($l){
				case 1:
					apply_buff('ta1', array(
						"startmsg"=>"`7A simple yet effective tactical maneuver, you find higher ground!",
						"name"=>"`&Higher Ground",
						"rounds"=>5,
						"wearoff"=>"{badguy} moves so they can be on equal footing with you..",
						"atkmod"=>1.3,
						"defmod"=>1.3,
						"schema"=>"specialtytacticsskills"
					));
					break;
				case 2:
					apply_buff('ta2', array(
						"startmsg"=>"`7You deftly maneuver, and catch {badguy} off-guard, attacking from the flank!",
						"name"=>"`&Flank",
						"rounds"=>2,
						"wearoff"=>"{badguy} turns to face you properly..",
						"badguydefmod"=>0,
						"schema"=>"specialtytacticsskills"
					));
					break;
				case 3:
					apply_buff('ta3', array(
						"startmsg"=>"`7Great tacticians find the Achilles heel, the chink in the armor...",
						"name"=>"`&Weak Spot",
						"rounds"=>7,
						"wearoff"=>"`^Slowly, but surely they catch on and start protecting their vital areas.",
						"atkmod"=>1.8,
						"effectmsg"=>"`&You ruthlessly strike {badguy} for {damage} damage in a tender spot.",
						"schema"=>"specialtytacticsskills"
					));
					break;
				case 5:
					apply_buff('ta5', array(
						"startmsg"=>"`7Tactics 101 - There is strength in numbers, so you take some mercenaries and launch an ambush.",
						"name"=>"`&Ambush",
						"rounds"=>5,
						"minioncount"=>round($session['user']['level']/2)+2,
						"maxbadguydamage"=>round($session['user']['level']/2,0)+4,
						"effectmsg"=>"`)A Mercenary strikes {badguy}!",
						"schema"=>"specialtytacticsskills"
					));
					break;
				}
				set_module_pref("uses", get_module_pref("uses") - $l);
			}else{
				apply_buff('ta0', array(
					"startmsg"=>"You survey the area and try to find a tactical advantage, only to have a brain fart.",
					"rounds"=>1,
					"schema"=>"specialtytacticsskills"
				));
			}
		}
		break;
		
	case "castlelib":
		if ($op69 == 'tactics'){
			output("You sit down and open up The Art of War.`n");
			output("You read for a while... in the time it takes you to read you use up`n");
			output("3 Turns.`n`n");
			output("Sun Tzu's classic book isn't centered on large-scale war like many might suspect.`n");
			output("Like The Prince, it is a treatise on gaining the upper hand, and can be applied to`n");
			output("many different circumstances.`n");
			output("You become a more powerful Tactician!`n");
			$session['user']['turns']-=3;
			set_module_pref('skill',(get_module_pref('skill','specialtytacticsskills') + 1),'specialtytacticsskills');
			set_module_pref('uses', get_module_pref("uses",'specialtytacticsskills') + 1,'specialtytacticsskills');
			addnav("Continue","runmodule.php?module=lonnycastle&op=library");
			}
		break;
		
	case "castlelibbook":
		output("The Art of War. (3 Turns)`n");
		addnav("Read a Book");
		addnav("The Art of War","runmodule.php?module=lonnycastle&op=library&op69=tactics");
		break;
		
	case "choose-specialty":
		if ($session['user']['dragonkills']>=get_module_setting("mindk")) {
			if ($session['user']['specialty'] == "" ||
				$session['user']['specialty'] == '0') {
				addnav("$ccode$name`0","newday.php?setspecialty=".$spec."$resline");
				$t1 = translate_inline("Playing chess and nine-men morris to study tactics.");
				$t2 = appoencode(translate_inline("$ccode$name`0"));
				rawoutput("<a href='newday.php?setspecialty=$spec$resline'>$t1 ($t2)</a><br>");
				addnav("","newday.php?setspecialty=$spec$resline");
			}
		}
		break;
		
	case "dragonkill":
		set_module_pref("uses", 0);
		set_module_pref("skill", 0);
		break;
		
	case "fightnav-specialties":
		$uses = get_module_pref("uses");
		$script = $args['script'];
		if ($uses > 0) {
			addnav(array("%s%s (%s points)`0", $ccode, $name, $uses), "");
			addnav(array("%s &#149; Higher Ground`7 (%s)`0", $ccode, 1), 
					$script."op=fight&skill=$spec&l=1", true);
		}
		if ($uses > 1) {
			addnav(array("%s &#149; Flank`7 (%s)`0", $ccode, 2),
					$script."op=fight&skill=$spec&l=2",true);
		}
		if ($uses > 2) {
			addnav(array("%s &#149; Weak Spot`7 (%s)`0", $ccode, 3),
					$script."op=fight&skill=$spec&l=3",true);
		}
		if ($uses > 4) {
			addnav(array("%s &#149; Ambush`7 (%s)`0", $ccode, 5),
					$script."op=fight&skill=$spec&l=5",true);
		}
		break;
		
	case "incrementspecialty":
		if($session['user']['specialty'] == $spec) {
			$new = get_module_pref("skill") + 1;
			set_module_pref("skill", $new);
			$c = $args['color'];
			output("`n%sYou gain a level in `&%s%s to `#%s%s!",
					$c, $name, $c, $new, $c);
			$x = $new % 3;
			if ($x == 0){
				output("`n`^You gain an extra use point!`n");
				set_module_pref("uses", get_module_pref("uses") + 1);
			}else{
				if (3-$x == 1) {
					output("`n`^Only 1 more skill level until you gain an extra use point!`n");
				} else {
					output("`n`^Only %s more skill levels until you gain an extra use point!`n", (3-$x));
				}
			}
			output_notl("`0");
		}
		break;
		
	case "newday":
		$bonus = getsetting("specialtybonus", 1);
		if($session['user']['specialty'] == $spec) {
			if ($bonus == 1) {
				output("`n`2For being interested in %s%s`2, you receive `^1`2 extra `&%s%s`2 use for today.`n",$ccode,$name,$ccode,$name);
			} else {
				output("`n`2For being interested in %s%s`2, you receive `^%s`2 extra `&%s%s`2 uses for today.`n",$ccode,$name,$bonus,$ccode,$name);
			}
		}
		$amt = (int)(get_module_pref("skill") / 3);
		if ($session['user']['specialty'] == $spec) $amt++;
		set_module_pref("uses", $amt);
		break;
		
	case "pointsdesc":
		$cost = get_module_setting("cost");
		if ($cost > 0){
			$args['count']++;
			$format = $args['format'];
			$str = translate("The Tactician Specialty is availiable upon reaching %s Dragon Kills and %s points.");
			$str = sprintf($str, get_module_setting("mindk"),$cost);
		}
		output($format, $str, true);
		break;
		
	case "set-specialty":
		if($session['user']['specialty'] == $spec) {
			page_header($name);
			$session['user']['donationspent'] = $session['user']['donationspent'] + $cost;
			output("`7You spent much of your childhood playing chess, nine-men-morris and other such strategy games. ");
			output("It just doesn't make sense going through life competing on the same level as everyone else in the world. ");
			output("If you don't have an upper-hand, then you're playing not to lose, and in the superior numbers the world will throw at you, eventually you will lose .");
			output("However, you have decided to set yourself apart from everyone else.  You will be the one to make a difference.`n`n");
			output("`&You will be the one to slay the Dragon, not because a human is really more powerful than a dragon, but because you're smart enough to discover a way. ");
			output("You will be the next hero of the realm, and have statues built in your honor.  You will find a way.`n`n");
		}
		break;
		
	case "specialtycolor":
		$args[$spec] = $ccode;
		break;
		
	case "specialtymodules":
		$args[$spec] = "specialtytacticsskills";
		break;
		
	case "specialtynames":
		$pointsavailable = $session['user']['donation'] - $session['user']['donationspent'];
		if ($session['user']['superuser'] & SU_EDIT_USERS || $session['user']['dragonkills'] >= get_module_setting("mindk") || get_module_setting("cost") <= $pointsavailable){
			$args[$spec] = translate_inline($name);
		}
		break;
		
	}
	return $args;
}

function specialtytacticsskills_run(){
}
?>