<?php
//Logd 0.9.8 Pvps to forest fights module
//Created by Damien(JV)
//Tested with pre-rel 7 and later

function pvpstoforest_getmoduleinfo(){
	$info = array(
		"name"=>"Pvps to forest fights",
		"author"=>"Damien",
		"version"=>"1.0",
		"category"=>"Forest Specials",
		"download"=>"http://dragonprime.net/users/Damien",
		"settings"=>array(
			"Pvps to forest fights Settings, title",
			"onepvp"=>"How many forest fights is 1 PvP,int|1",
			"twopvps"=>"How many forest fights are 2 PvPs,int|3",
			"threepvps"=>"How many forest fights are 3 PvPs,int|5",
		),
	);
	return $info;
}

function pvpstoforest_install(){
	module_addeventhook("forest", "return 100;");
	return true;
}

function pvpstoforest_uninstall(){
	return true;
}

function pvpstoforest_dohook($hookname, $args){
	return $args;
}

function pvpstoforest_runevent($type){

	 page_header("Dealer");
	 $one = get_module_setting("onepvp");
	 $two = get_module_setting("twopvps");
	 $three = get_module_setting("threepvps");
	 output("`@A small hobbit type woman wants to speak with you. `nShe has a special offer just for you: Change your PvP turns to forest turns!`n`n");
	 output("This is how it goes:`n");
	 output("`&1 PvP turn   => %s forest fight`n",$one);
	 output("`^2 Pvp turns => %s forest fights`n",$two);
	 output("`$ 3 Pvp turns => %s forest fights`n",$three);
	 output("`n`@Wanna make a deal or what?");
	 addnav("Give ".$one." forest fight","runmodule.php?module=pvpstoforest&op=deal&amount=1");
	 addnav("Give ".$two." forest fights","runmodule.php?module=pvpstoforest&op=deal&amount=2");
	 addnav("Give ".$three." forest fights","runmodule.php?module=pvpstoforest&op=deal&amount=3");
	 addnav("o?Forget it","forest.php");
	 page_footer();
}

function pvpstoforest_run(){
	global $session;
	page_header("Dealer");
	switch(httpget('op')){
	case "deal":
	     $amount = httpget('amount');
	     switch($amount){

		    case 1:
		    if($session['user']['playerfights']>0){
		       $forests = get_module_setting("onepvp");
		       output("\"`@Alrighty then, it's the deal!\", woman shouts and smiles. \"Here's your `&%s forest fights `@and I'll take your `&1 PvP.\"", $forests);
		       $session['user']['turns']+=$forests;
		       $session['user']['playerfights']--;
		    }
		    else{
		       output("\"`@So you're trying get more forest fights without giving anything to me?\", woman asks threateningly.");
		       output("\"`@You will difinitely give me something!\", woman roars and before you can do anything she jumps onto you and starts her mating ritual.`n");
		       if($session['user']['turns']>0){
		          output("`&It takes it's time and you lose 1 forest fights`n");
                          $session['user']['turns']--;
		       }
		       else{
                          if($session['user']['charm']>0){
			     output("`&After the ritual you don't feel yourself very charmy. You lose 1 charm.`n");
                             $session['user']['charm']--;
                          }
                          else{
                             output("`&You actually enjoyed her treatment and you find yourself a bit more energy!`n");
                             $session['user']['hitpoints']+=20;
			  }
		       }
		    }
		    addnav("Return to the forest","forest.php");
		    break;
		    
		    case 2:
		    if($session['user']['playerfights']>1){
		    $forests = get_module_setting("twopvps");
		    output("\"`@Alrighty then, it's the deal!\", woman shouts and smiles. \"Here's your `^%s forest fights `@and I'll take your `^2 PvPs.\"", $forests);
		    $session['user']['turns']+=$forests;
		    $session['user']['playerfights']-=2;
		    }
		    else{
		       output("\"`@So you're trying get more forest fights without giving anything to me?\", woman asks threateningly.");
		       output("\"`@You will difinitely give me something!\", woman roars and before you can do anything she jumps onto you and starts her mating ritual.`n");
		       if($session['user']['turns']>0){
		          output("`&It takes it's time and you lose 1 forest fights`n");
                          $session['user']['turns']--;
		       }
		       else{
                          if($session['user']['charm']>0){
			     output("`&After the ritual you don't feel yourself very charmy. You lose 1 charm.`n");
                             $session['user']['charm']--;
                          }
                          else{
                             output("`&You actually enjoy her treatment and you find yourself a bit more energy!`n");
                             $session['user']['hitpoints']+=20;
			  }
		       }
		    }
		    addnav("Return to the forest","forest.php");
		    break;

		    case 3:
		    if($session['user']['playerfights']>2){
		    $forests = get_module_setting("threepvps");
		    output("\"`@Alrighty then, it's the deal!\", woman shouts and smiles. \"Here's your `$%s forest fights `@and I'll take your `$ 3 PvPs.\"", $forests);
		    $session['user']['turns']+=$forests;
		    $session['user']['playerfights']-=3;
		    }
		    else{
		       output("\"`@So you're trying get more forest fights without giving anything to me?\", woman asks threateningly.");
		       output("\"`@You will difinitely give me something!\", woman roars and before you can do anything she jumps onto you and starts her mating ritual.`n");
		       if($session['user']['turns']>0){
		          output("`&It takes it's time and you lose 1 forest fights`n");
                          $session['user']['turns']--;
		       }
		       else{
                          if($session['user']['charm']>0){
			     output("`&After the ritual you don't feel yourself very charmy. You lose 1 charm.`n");
                             $session['user']['charm']--;
                          }
                          else{
                             output("`&You actually enjoy her treatment and you find yourself a bit more energy!`n");
                             $session['user']['hitpoints']+=20;
			  }
		       }
		    }
		    addnav("Return to the forest","forest.php");
		    break;


	     }
	break;
	}
	page_footer();
}
?>
