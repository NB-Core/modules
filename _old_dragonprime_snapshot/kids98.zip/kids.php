<?php
function kids_getmoduleinfo(){
        $info = array(
                "name"=>"12 year olds beat up players",
		"version" => "20050217",
		"download" => "http://dragonprime.net/users/sixf00t4/kids98.zip",
		"vertxtloc"=>"http://dragonprime.net/users/sixf00t4/",
                "author"=>"12 year olds beat up players <br> by sixf00t4 <br> Converted by Lurch",
                "category"=>"Forest Specials",
        );

 return $info;
}

function kids_install(){
        module_addeventhook("forest", "return 100;");
        return true;
}

function kids_uninstall(){
        return true;
}

function kids_dohook($hookname,$args){
        return $args;
}

function kids_runevent($type)
{

/*12 year olds beat up players by sixf00t4
made for http://sixf00t4.com/dragon*/
 global $session;
// We assume this event only shows up in the forest currently.
        $from = "forest.php?";

if($session[user][dragonkills]<7){
output("`^As you walk through the forest, you find a familiar looking Warrior.  He looks like he was roughed up a bit.`n");
output("What a pity for him.  You wave and carry on your way`0");
}
if($session[user][dragonkills]>6){
output("As you stroll down the forest path with your nose high in the air, proud of your many dragon slays, you get mugged by bunch of 12 year olds armed with bats.`0");
$ouch=e_rand(2,5);
if($ouch > $session['user']['maxhitpoints'])
	output("`^As you walk through the forest, you find a familiar looking Warrior.  He looks like he was roughed up a bit.`n");
	output("What a pity for him.  You wave and carry on your way`0");
	}else{
	$session['user']['maxhitpoints'] -=$ouch;
	}
}
function kids_run(){
}
?>