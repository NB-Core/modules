<?php
/*
1.1 added the last commentary lines to the submit, also you can enter a comment to the request
*/

function callformod_getmoduleinfo() {
	$info = array(
	    "name"=>"Call for Moderator",
		"description"=>"This module YOMs for help in a comment section to all online moderators",
		"version"=>"1.1",
		"author"=>"`2Oliver Brendel, idea by XChrisX",
		"category"=>"Commentary",
		"override_forced_nav"=>true,
		"download"=>"http://dragonprime.net/dls/callformod.zip",
		);
    return $info;
}

function callformod_install() {
	module_addhook_priority("insertcomment",25);
	return true;
}

function callformod_uninstall() {
	return true;
}


function callformod_dohook($hookname, $args){
	global $session;
	switch ($hookname)
	{
	case "insertcomment":
		$text=appoencode(translate_inline("`rCall for moderator"));
		rawoutput("<a href='runmodule.php?module=callformod&op=call&section={$args['section']}' target='_blank' onClick=\"".popup("runmodule.php?module=callformod&op=call&section={$args['section']}").";return false;\">$text</a>"); //function popup comes from lib/pageparts.php
	break;
	}
	return $args;
}

function callformod_run(){
	global $session;
	popup_header("Call for moderator help");
	$op=httpget('op');
	$limit=5; //for now here, no extra setting
	$section=httpget('section');
	switch ($op) {
		case "call":
			$mods=getmods();
			if (count ($mods)<1) {
				output("`^Sorry, no moderator is online, please petition with the exact content what happened and where.");
				output("`n`nSorry for the inconvenience.");
				output("`n`nYou may refresh this page if you want to wait for a moderator.");
				break;
			}
			$defaulttext="I want to report abusive behaviour that is against the server rules. Please come to the section mentioned in the post.";
			$defaulttext=rep(color_sanitize(translate_inline($defaulttext)));
			$signature=translate_inline("`n`nRegards, %s`0");
			$signature=rep(color_sanitize(sprintf($signature,$session['user']['name'])));
			$value=translate_inline("Submit");
			//now going on
			output("`^The last commentary lines will be mailed to %s`^, as well as the following comment.`n",$mods[0]['name']);
			output("Please describe as precisely as possible why exactly a moderator is needed right now.");
			output(" Remember a misuse of this function might also mean consequences for your person.`n`n");
			rawoutput("<form action='runmodule.php?module=callformod&op=submit&section=$section' method='POST'>");
			addnav("","runmodule.php?module=callformod&op=submit&section=$section");
			rawoutput("<textarea name='reason' class='input' cols='60' rows='5'>".$defaulttext.$signature."</textarea><br>");
			rawoutput("<br><input type='submit' value='$value'>");
			rawoutput("<input type='hidden' name='moderator' value='".$mods[0]['acctid']."'>");
			rawoutput("</form>");
			break;
		case "submit":
			require_once("lib/systemmail.php");
			$moderator=httppost('moderator');
			if (!$moderator) {
				output("Error...moderator invalid.");
				break;
			}
			$sql="SELECT a.name,b.comment FROM ".db_prefix("accounts")." AS a INNER JOIN ".db_prefix("commentary")." AS b ON a.acctid=b.author WHERE section='$section' ORDER BY commentid DESC LIMIT $limit;";
			$result=db_query($sql);
			$lastlines='';
			while ($row=db_fetch_assoc($result)) {
				$lastlines=$row['name']."`& says, \"`2".$row['comment']."`&\"`n".$lastlines;
			}
			$reason=httppost('reason');
			$msg=array("`7A moderator has been requested for the area `\$%s`7 from user `4%s`7 (login %s). Please go there and check up things, or notify another moderator/the user if you cannot go there now.`nThe last commentary lines spoken were:`n%s`n`n`7The reason entered by the user who called was:`n%s`n",$section,$session['user']['name'],$session['user']['login'],$lastlines,$reason);
			systemmail($moderator,array("`\$Urgent Help Request"),$msg);
			output("`^You have requested help for this section, the moderator has been notified.");
			output("`n`nMisuse of this function will be punished.");
			break;
	}
	popup_footer();
}

function getmods($online=true) {
	$sql="SELECT acctid,name,login,superuser FROM ".db_prefix("accounts")." WHERE laston>'".date("Y-m-d G:i:s", strtotime("-".getsetting("LOGINTIMEOUT", 900)." sec"))."' AND superuser>".SU_EDIT_COMMENTS." ORDER BY rand(".e_rand().");";
	$result=db_query($sql);
	$mods=array();
	while ($row=db_fetch_assoc($result)) {
		if ($row['superuser']&SU_EDIT_COMMENTS) $mods[]=$row;
	}
	return $mods;
}

function rep($in) {
	$out=str_replace("`n","\n",$in);
	return $out;
}
?>
