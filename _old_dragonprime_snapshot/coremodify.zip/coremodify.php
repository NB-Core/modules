<?php

function coremodify_getmoduleinfo(){
	$info = array(
		"name"=>"Core Modification",
		"version"=>"3.0",
		"author"=>"DaveS",
		"category"=>"Administrative",
		"download"=>"",
		"settings"=>array(
			"Core Modifications,title",
			"wording"=>"What is the announcement on the modules listing page?,text|The following core modules have been modified. Please  contact the site administrator if you wish copies or to review the modifications:",
			"coremodify"=>"Which modules in the core have you modified?,text|commentary.php, motd.php",
		),
	);
	return $info;
}
function coremodify_install(){
	module_addhook("header-about");
	return true;
}
function coremodify_uninstall(){
	return true;
}
function coremodify_dohook($hookname,$args){
	global $session;
	switch($hookname){
		case "header-about":
			$op = httpget('op');
			if ($op=="listmodules"){
				if (get_module_setting("wording")!="") output("`n%s`n",get_module_setting("wording"));
				if (get_module_setting("coremodify")!="") output("`@`c%s`c`n`n",get_module_setting("coremodify"));
			}
		break;
	}
	return $args;
}

function coremodify_run(){
}
?>