<?php
/*
* Date:     April 20, 2005
* Author:   Robert of MaddRio dot com
* v 1.1     optimized code
*/
function fruittree_getmoduleinfo(){
	$info = array(
	"name"=>"Fruit Tree",
	"version"=>"1.1",
	"author"=>"`2Robert",
	"category"=>"Forest Specials",
	"download"=>"http://dragonprime.net/users/Robert/fruittree098.zip",
	);
	return $info;
}

function fruittree_install(){
	module_addeventhook("forest","return 100;");
	return true;
}

function fruittree_uninstall(){
	return true;
}

function fruittree_dohook($hookname,$args){
	return $args;
}

function fruittree_runevent($type){
global $session;
$chance = 60;
$a="`qPeach";
$b="`6Pear";
$c="`@Apple";
$randx=e_rand(1,4);
if ($randx==1 or 4){ $tree=$a;}
if ($randx==2){ $tree=$b;}
if ($randx==3){ $tree=$c;}
$rand = e_rand(1,100);
$gain=$session['user']['hitpoints']*.1;
if ($rand <= $chance) {
output("`n`n`2 You come upon a wonderful looking %s `2 tree which has fruit that is ready for picking! ",$tree);
output(" Not resisting temptation, you pick and eat several %s's `2 for yourself.`n",$tree);
output(" You feel refreshed, however you notice some annoying flies which have taken a liking to you.`n");
output(" You try to swat away the annoying flies, ...`b`i but now they follow you! `i`b");
$ffly = array(
	"name"=>"`#Fruit Fly",
	"rounds"=>40,
	"defmod"=>.9,
	"atkmod"=>1.0,
	"wearoff"=> "The Fruit Fly is no longer bothering you.",
	"roundmsg"=>"`7A `#Fruit Fly `7is hovering around while you try to fight.",
	"schema"=>"module-fruittree",
	);
apply_buff('ffly',$ffly);

$afly = array(
	"name"=>"`@Annoying Fly",
	"rounds"=>50,
	"defmod"=>1.0,
	"atkmod"=>.9,
	"wearoff"=> "You swat the Annoying Fly to the ground and step on it!",
	"roundmsg"=>"`7An `@Annoying Fly `7is buzzzzing around, making your fight less effective.",
	"schema"=>"module-fruittree",
	);
apply_buff('afly',$afly);
}else{
	output("`n`n`2 You come upon a wonderful looking %s `2 tree which has fruit that is ready for picking! ",$tree);
	output(" Not resisting temptation, you pick and eat several %s's `2 for yourself. `n",$tree);
	output(" You feel really refreshed! `n");
	if ($session['user']['hitpoints'] < $session['user']['maxhitpoints']) {
		output("`6 You gain a few hitpoints! ");
		$session['user']['hitpoints']+=$gain;
	}
}
}

function fruittree_run(){
}
?>