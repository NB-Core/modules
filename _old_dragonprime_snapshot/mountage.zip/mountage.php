<?php

function mountage_getmoduleinfo(){
	$info = array(
		"name"=>"Mount Age",
		"version"=>"1.06",
		"author"=>"Enhas",
		"category"=>"General",
		"download"=>"http://dragonprime.net/users/Enhas/mountage.txt",
		"settings"=>array(
			"Mount Age Settings,title",
			"ageweak"=>"After how many game days can mounts weaken,int|75",
                  "agedie"=>"After how many game days can mounts die,int|200",
                  "prizemountid"=>"ID of Prize Mount (if available),viewonly",
		),
            "prefs"=>array(
			"Mount Age Preferences,title",
                  "mountage"=>"Age of this current mount,int|0",
                  "agebackup"=>"Backup value for age (used for prize mount),viewonly",
                  "oldmountid"=>"ID of mount,viewonly",
		)
	);
	return $info;
}

function mountage_install(){
      module_addhook("stable-mount");
      module_addhook("newday");
	return true;
}

function mountage_uninstall(){
	return true;
}

function mountage_dohook($hookname,$args){
      global $session;
            $ageweak = get_module_setting("ageweak");
            $agedie = get_module_setting("agedie");
            $mountage = get_module_pref("mountage");

            $currentmountid = ($session['user']['hashorse']);
            $oldmountid = get_module_pref("oldmountid");
            $prizemountid = get_module_setting("prizemountid");
            $agebackup = get_module_pref("agebackup");

            if (is_module_active("prizemount")) {
            $prizemountid = get_module_setting("mountid", "prizemount");
            } else {
            $prizemountid = -1;
            }

            set_module_setting("prizemountid",$prizemountid);

            require_once("lib/mountname.php");
		list($name, $lcname) = getmountname();

            if ($currentmountid==$prizemountid){
            $agebackup = $mountage;
            set_module_pref("agebackup",$agebackup);
            }

            if (($currentmountid != $oldmountid) && ($currentmountid != $prizemountid)) {
            set_module_pref("mountage",0);
            set_module_pref("agebackup",0);
            set_module_pref("oldmountid",0);
            }
      switch($hookname){ 
      case "stable-mount":
            if ($currentmountid != $prizemountid){
            set_module_pref("mountage",$agebackup);
            set_module_pref("agebackup",0);
            set_module_pref("oldmountid",0);
            }
            break;
	case "newday":
            $diechance = e_rand(1,10);
            $weakchance = e_rand(1,5);

            if (($session['user']['hashorse'] > 0) && ($currentmountid != $prizemountid)) {
            $mountage++;
            set_module_pref("mountage",$mountage);
            set_module_pref("oldmountid",$currentmountid);
            }

            if (($session['user']['hashorse'] > 0) && ($mountage >= $agedie) && $diechance==10 && ($currentmountid != $prizemountid)) {
            $session['user']['hashorse'] = 0;
            set_module_pref("mountage",0);
            set_module_pref("agebackup",0);
            set_module_pref("oldmountid",0);
	      strip_buff("mount");
            output("`n`7As you try to begin your adventure today, you notice that %s seems to have fallen asleep.  ", $lcname);
            output("Nudging closer, you poke %s to try and awaken it, but to no avail.  As you examine, you notice %s is not breathing!`n`n", $lcname, $lcname);
            output("`\$`b%s has died of old age!`n`n`b", $name);
            output("`7You quietly bury your old friend in a small clearing that it used to graze in, long ago..`n");
            $turnloss=round(($session['user']['turns']*0.25),0);
            $session['user']['turns']-=$turnloss;
            if ($session['user']['turns']<0)
	      $session['user']['turns']=0;
            if ($turnloss > 0) {
            output("`7Due to your despair at losing your old friend, you lose `\$%s`7 of your `@forest fights`7 for today!`n`0", $turnloss);
            }elseif ($turnloss==0) {
            output("`7You feel very sad for your loss.`n`0");
            }
            }

            if (($session['user']['hashorse'] > 0) && ($mountage >= $ageweak) && $weakchance==5 && ($currentmountid != $prizemountid)) {
            $session['bufflist']['mount']['rounds'] = round(($session['bufflist']['mount']['rounds']*0.5),0);
            output("`n`7As you try to begin your adventure today, you notice that %s seems to have fallen asleep.  ", $lcname);
            output("Nudging closer, you poke %s to try and awaken it, which it does after much delay.  %s seems a bit dazed and tired..`0`n", $lcname, $name);
            }
            
		break;
       }
	
	return $args;
}
?>