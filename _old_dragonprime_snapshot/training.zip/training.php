<?php
require_once("common.php");
require_once("lib/http.php");
require_once("lib/villagenav.php");

function training_getmoduleinfo(){
		$info = array(
			"name" => "Training",
			"author" => "`#Kalazaar, based on a concept by Ian Major",
			"version" => "1.0",
			"download" => "http://dragonprime.net/users/Kala/training.zip",
			"category"=>"Village",
			"description"=>"Training turns for experience to level 4",
			"settings"=>array(
				"Training Settings,title",
				"name" => "Village name, text|Training School",
				"trainloc" => "Where does Training School appear,location|".getsetting("villagename", LOCATION_FIELDS),
				"traindk"=>"How many dks are needed to get a room?,int|0",
				"turns" => "How many turns does it take to train,int|5",
				"minturns" => "Minimum number of turns to enable training, int|6",
				"cost" => "How much does it cost to rent a room in training school, int|1000",
				"owner" => "Who owns the Training School, text|Tahlia",
				"tname1" => "First Training School Exercise, text|Gym Class",
				"tname2" => "Second Training School Exercise, text|Cross Country",
				"tname3" => "Third Training School Exercise, text|Wrestling"
			),
			"prefs" => array(
			"Training User Preferences,title",
			"training"=>"Has this user paid for a room?,bool|0"
		),
	);
	return $info;
}
function training_install(){
	module_addhook("village");
	module_addhook("changesetting");
	module_addhook("newday");
	return true;
}
function training_uninstall(){
	return true;
}
function training_dohook ($hookname, $args){
	global $session;
	switch ($hookname){
		case "changesetting":
		    if ($args['setting'] == "villagename") {
		    if ($args['old'] == get_module_setting("trainloc")) {
		       set_module_setting("trainloc", $args['new']);
		       }
			}
		    break;
  		case "village":
			$traindk = get_module_setting("traindk");
            if ($session['user']['dragonkills']>=$traindk){
			if ($session['user']['location'] == get_module_setting("trainloc"))
			tlschema($args['schemas']['marketnav']);
		    addnav($args['marketnav']);
			tlschema();
	        $name=get_module_setting("name");
			addnav(array("%s `0",$name),"runmodule.php?module=training&op=train");
			}
	        break;
	   case "newday":
            set_module_pref("training", 0);
            break;
        }
        return $args;
    }
function training_runevent(){
	return true;
}
function training_run(){
	global $session;
	$name=get_module_setting("name");
	$cost=get_module_setting("cost");
	$training=get_module_pref("training");
	$turns=get_module_setting("turns");
	$minturns=get_module_setting("minturns");
	$tname1=get_module_setting("tname1");
	$tname2=get_module_setting("tname2");
	$tname3=get_module_setting("tname3");
	$owner=get_module_setting("owner");
	$dk = $session['user']['dragonkills'];
	$exp = $session['user']['experience'];
	$tur = $session['user']['turns'];
	$op = httpget("op");
	page_header("Training");
	//$session['user']['specialinc'] = "module:Training";
	if ($op=="" || $op=="train"){
		output(array("`3Walking into the %s, you hear the sounds of others hard at work.  A lady in a leotard looks up from the front desk.`n", $name));
		output(array("`#Welcome to the %s, Can I interest you in a training room? or perhaps you already have one.  With a room you can train up to level 4.`n", $name));
		if ($training==0){
					if(($exp>((75*$dk)+2000)) or ($tur<=$minturns)){
	                output("\"`#Oh I'm sorry, you'll have to come back after you dk, you cannot do anymore training until then.\"");
	                addnav("Leave", "village.php?");
                	}else{
					output(array("`3glancing at a ledger on the counter in front of her she says `#\"You don't have a room yet today.  To hire one for the day will cost you %s gold\"`n",$cost));
					output("\"So can I interest you in a room?\"");
					addnav("Sure I'll take a room", "runmodule.php?module=training&op=room");
					addnav("Not today thanks", "runmodule.php?module=training&op=leave");
					}
				}else if ($training==1){
					output("`#Ahh I see you already have a room.`n");
					if (($exp>((75*$dk)+2000)) or ($tur<=$minturns)){
	                output("\"`#Oh I'm sorry, you'll have to come back after you dk, you cannot do anymore training until then.\"");
	                addnav("Leave", "village.php?");
					//$session['user']['specialinc'] = "";
					}else{
					output("\"`#Please follow me.\" `3she smiles and motions you towards your room."); 
					addnav("Enter Room", "runmodule.php?module=training&op=eroom");
					}
					}
			}else if ($op=="" || $op=="room"){
					if ($session['user']['gold']<$cost){
					output("`^You don't seem to have enough gold.`n");
					addnav("Leave", "village.php?");
					//$session['user']['specialinc'] = "";
					}else{
					output(array("`#\"That'll be %s gold\"`3 Taking your gold, she leads you down a small corridor, many rooms leading off on either side, eventually you come to a door, pushing it open you enter your room.", $cost));
					$session['user']['gold']-=$cost;
					$settraining = set_module_pref("training",1);
					addnav("Enter Room", "runmodule.php?module=training&op=eroom");
					}	
				}else if ($op=="" || $op=="eroom"){
					if (($exp>((75*$dk)+2000)) or ($tur<=$minturns)){
						output("You feel tired from all this exertion, perhaps you'll feel better after a dk");
						villagenav();
						//$session['user']['specialinc'] = "";
					 }else{
					output("Looking around you see various things you can do, which will you pick?");
					addnav("$tname1", "runmodule.php?module=training&op=$tname1");
					addnav("$tname2", "runmodule.php?module=training&op=$tname2");
					addnav("$tname3", "runmodule.php?module=training&op=$tname3");
					}
				}else if ($op=="" || $op=="$tname1"){
					 $session['user']['turns']-=$turns;
					training_outcome();
				
				}else if ($op=="" || $op=="$tname2"){
					 $session['user']['turns']-=$turns;
					training_outcome();
			
					
				}else if ($op=="" || $op=="$tname3"){
					 $session['user']['turns']-=$turns;
					training_outcome();
			
			
			}else if ($op=="" || $op=="leave"){
					output ("`3Smiling she says `#\"Perhaps another time.");
					addnav("Leave", "village.php?");
					//$session['user']['specialinc'] = "";
	}
	
	page_footer();
}
	function training_outcome(){
		global $session;
		$dk = $session['user']['dragonkills'];
		$exp = $session['user']['experience'];		
	switch (e_rand(1, 5)) {
                case 1:
                $expgain = (($dk*20)+$exp)/3;
                $session['user']['experience']+=$expgain;
                output(array("Pushing yourself to your best you gain %s experience",$expgain));
         		addnav("return to room", "runmodule.php?module=training&op=eroom");
                break;
                case 2:
                $expgain = (($dk*20)+$exp)/6;
                $session['user']['experience']+=$expgain;
                output(array("Pushing yourself to your best you gain %s experience",$expgain));
         		addnav("return to room", "runmodule.php?module=training&op=eroom");
                break;
                case 3:
                $expgain = (($dk*20)+$exp)/12;
                $session['user']['experience']+=$expgain;
                output(array("Pushing yourself to your best you gain %s experience",$expgain));
         		addnav("return to room", "runmodule.php?module=training&op=eroom");
                break;
                case 4:
                $expgain = (($dk*20)+$exp)/18;
                $session['user']['experience']+=$expgain;
                output(array("Pushing yourself to your best you gain %s experience",$expgain));
         		addnav("return to room", "runmodule.php?module=training&op=eroom");
                break;
                case 5:
                $expgain = (($dk*20)+$exp)/24;
                $session['user']['experience']+=$expgain;
                output(array("Pushing yourself to your best you gain %s experience",$expgain));
         		addnav("return to room", "runmodule.php?module=training&op=eroom");
                break;
          		case 6:
          		$expgain = (($dk*20)+$exp)/30;
                $session['user']['experience']+=$expgain;
                output(array("Pushing yourself to your best you gain %s experience",$expgain));
         		addnav("return to room", "runmodule.php?module=training&op=eroom");
                break;
				
        
 }
  }   
?>