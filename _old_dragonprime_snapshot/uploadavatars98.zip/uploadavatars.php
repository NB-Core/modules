<?php
function uploadavatars_getmoduleinfo(){
	$info = array(
		"name"=>"Uploadavatars",
		"version"=>"1.12",
		"author"=>"`#Lonny Luberts",
		"category"=>"PQcomp",
		"download"=>"http://www.pqcomp.com/modules/mydownloads/visit.php?cid=3&lid=22",
		"vertxtloc"=>"http://www.pqcomp.com/",
		"settings"=>array(
			"Upload Avatars Module Settings,title",
			"You MUST create an avatar folder and make sure that everyone has write permisions,note",
			"You MUST also get the index.php from this module copied to the avatar folder,note",
			"avatarloc"=>"Full URL to avatar Folder,text|",
		),
	);
	return $info;
}

function uploadavatars_install(){
	if (!is_module_active('uploadavatars')){
		output("`4Installing Uploadavatars Module.`n");
	}else{
		output("`4Updating Uploadavatars Module.`n");
	}
	module_addhook("footer-prefs");
	return true;
}

function uploadavatars_uninstall(){
	output("`4Un-Installing Uploadavatars Module.`n");
	return true;
}

function uploadavatars_dohook($hookname,$args){
	if (get_module_setting('avatarloc')) addnav("Upload Avatar (gif)",get_module_setting('avatarloc')."/uploadgif.php",false,true);
	if (get_module_setting('avatarloc')) addnav("Upload Avatar (jpg)",get_module_setting('avatarloc')."/uploadjpg.php",false,true);
	return $args;
}