<?
/*12 year olds beat up players by sixf00t4
made for http://sixf00t4.com/dragon*/
if($session[user][dragonkills]<7){
output("`^As you walk through the forest, you find a familiar looking Warrior.  He looks like he was roughed up a bit.`n");
output("What a pity for him.  You wave and carry on your way`0");
}
if($session[user][dragonkills]>6){
output("As you stroll down the forest path with your nose high in the air, proud of your many dragon slays, you get mugged by bunch of 12 year olds armed with bats.`0");
$ouch=e_rand(2,5);
$session[user][maxhitpoints] -=$ouch;
}
?>