<?
require_once "common.php";
checkday();

page_header("The Wishing Well");
output("`c`b`@The King's `^Wishing Well`0`b`c`n`n");
if ($HTTP_GET_VARS[op]==""){
    output("`@You have approached a small park at the edge of town. The prominient feature of the park is a large stone water well. Peering into the well you can see a multitude of shining objects at the bottom. Town rumor is that many have tested their fortune here, and some have made their fortune here. Dare you test your luck?`n`n",true);
	output("`2Toss in some gold?",true);
    addnav("Toss in some gold","well.php?op=toss");
    addnav("Return to the village","village.php");
}else if ($HTTP_GET_VARS[op]=="toss"){
        addnav("Return to the village","village.php");
        output("<form action='well.php?op=tossgold' method='POST'>", true);
		output("How much gold should you throw in the well? <input id='input' name='gold' width=5 accesskey='t'><input type='submit' class='button' value='Toss'></form>",true);
        addnav("","well.php?op=tossgold");       
}else if ($HTTP_GET_VARS[op]=="tossgold"){
		addnav("Return to the village","village.php");
		$goldtossed=$HTTP_POST_VARS[gold];
    if ($goldtossed<=$session[user][gold]){
		if ($goldtossed<0){$goldtossed=0;}
		output("`2You reach into your pockets, grab `^$goldtossed gold `2 and toss it in...`n`n",true);
		//vars
		$chance=e_rand(0,100);
		$sql = "SELECT * FROM custom WHERE area='wellGold';";
		$result = db_query($sql);
		$dep = db_fetch_assoc($result);
		$well=$dep['amount'];
		//adsfadsfasfdsadfsad
	  if ($goldtossed>=($session[user][level]*25)){
		if (($well>20000) && ($session[user][jackpot]!=1)){
	                 $jackpot=e_rand(0,10);
					 if ($jackpot==7){
					                   output("`2Suddenly bags of `^GOLD `2start appearing everywhere around you.  `$ JACKPOT BABY!!!",true);
									   output("`2After counting the bags of gold, you gain `^10,000 GOLD!!",true);
									   $session[user][gold]=$session[user][gold]+10000;
									   $cashout=$well-10000;
									   $sql = "UPDATE `custom` SET amount=$cashout WHERE area='wellGold';";
						                            $result = db_query($sql);
									   $session[user][jackpot]=1;
									   debuglog("before winning, the well had $well gold and then after the jackpot of 10000 had $cashout");
									   addnews("`%".$session[user][name]."`3 has won the Well's Jackpot of `^10,000 Gold!!!!");
									   }//jackpot*/
					}//well greater than 20000
					else if (($well>20000) && ($session[user][jackpot]==1)){
						//output("`$ GETTING GREEDY AREN'T WE!!!!`n`n",true);
						$goodjack=e_rand(1,3);
						if ($goodjack==2){
						 $sql="SELECT * FROM accounts";
						 $results=db_query($sql);
						 $rows=mysql_numrows($results);
						 $casheach=round(20000/$rows,0);
						  for ($x=1; $x<=$rows; $x++){
							$dep = db_fetch_assoc($results);
							$luckyguy=$dep['acctid'];
							if ($luckyguy!=$session[user][acctid]){
							 $cashforyou=$casheach+$dep['goldinbank'];
							 $sql="UPDATE accounts SET goldinbank=$cashforyou WHERE acctid=$luckyguy";
							 $result=db_query($sql);
							 
							}
						}
						 $cashout=$well-20000;
						 $sql = "UPDATE `custom` SET amount=$cashout WHERE area='wellGold'";
						 $result = db_query($sql);
						 debuglog("at well had $well gold and then after the jackpot of 20000 had $cashout");
						 output("`#You hit a `^different kind `# of jackpot, for the good of all citizens!",true);
						 $greedy=1;
						 addnews("`%Thanks to `!".$session[user][name]."'s `%generosity, everyone has won `^$casheach Gold!!!!");
						 }
					}
		if (($chance<60) && ($jackpot!=7)&&($greedy!=1)){output("`2..nothing happens.",true);
		  				//output("$well in well",true);
						$well = $well+$goldtossed;
						$sql = "UPDATE `custom` SET amount=$well WHERE area='wellGold';";
						$result = db_query($sql);
						$session[user][gold]=$session[user][gold]-$goldtossed;
						addnav("Lose more money?","well.php?op=toss");
						}
	       else if (($chance>=60) && ($jackpot!=7)&&($greedy!=1)){
						$gchance=e_rand(0,100);
						if ($gchance>=20){
						        addnav("Try your luck again?","well.php?op=toss");
							 output("`2Suddenly your pockets feel a little heavier",true);
							 $cashback=e_rand($goldtossed, (2*$goldtossed));
							 output("`2You find `^$cashback `2more gold than you had `@before!`n`n`",true);
							 $session[user][gold]=$session[user][gold]+$cashback;
							 $cashout=$well-$cashback;
							 $sql = "UPDATE `custom` SET amount=$cashout WHERE area='wellGold';";
						         $result = db_query($sql);
							 debuglog("won $cashback while the well had $well gold and afterwords the well had $cashout");
							 }
						else if (($gchance<25)&&($gchance!=11)){
						   output("`2Suddenly you feel something in your pocket, it's..",true);
						   addnav("Try for more gems?","well.php?op=toss");
						   $gemchance=e_rand(0,100);
						      if ($gemchance<75){
						               output("`$ 1 Gem!",true);
							       $session[user][gems]=$session[user][gems]+1;
							       $session[user][gold]=$session[user][gold]-$goldtossed;
							       $cashout=$well+$goldtossed;
							       $sql = "UPDATE `custom` SET amount=$cashout WHERE area='wellGold';";
						               $result = db_query($sql);
							       debuglog("found 1 gem near the well");
							       }
						      if (($gemchance>=75)&&($session[userid]!=47)){output("`$ 2 Gems!",true);
							      $session[user][gems]=$session[user][gems]+2;
							      $session[user][gold]=$session[user][gold]-$goldtossed;
							      $cashout=$well+$goldtossed;
							      $sql = "UPDATE `custom` SET amount=$cashout WHERE area='wellGold';";
							      $result = db_query($sql);
							      debuglog("found 2 gems near the well");
						        }
							else {
							 output("`2Suddenly your pockets are as light as air!  A thief took all your money and gems while you tossed your gold into the well!!");
							 debuglog("was robbed blind at the well");
							 addnews("`%".$session[user][name]."`3 has been robbed of `^".$session[user][gold] ." gold `3 and `&".$session[user][gems]." gems `3at the well!!!!");
							 $session[user][gold]=0;
							 $session[user][gems]=0;
							 addnav("Try to get your money back?","well.php?op=toss");
							 }
						}
						else {
						 output("`2Suddenly your pockets are as light as air!  A thief took all your money and gems while you tossed your gold into the well!!");
						 debuglog("was robbed blind at the well");
				                 addnews("`%".$session[user][name]."`3 has been robbed of `^".$session[user][gold] ." gold `3 and `$".$session[user][gems]." gems `3at the well!!!!");
						 $session[user][gold]=0;
						 $session[user][gems]=0;
						 addnav("Try to get your money back?","well.php?op=toss");
						 }
	   }//winning chance
	  }//right amount tossed 
	  else {output("`2..nothing happens.",true);
	        output("`2 Suddenly out of the well echos: `#CHEAPO`3CHEAPO`7CHEAPO",true);
		  				$sql = "SELECT amount FROM custom WHERE area='wellGold';";
						$result = db_query($sql);
						$dep = db_fetch_assoc($result);
						$well=$dep['amount'];
						//output("$well in well",true);
						$well = $well+$goldtossed;
						$sql = "UPDATE `custom` SET amount=$well WHERE area='wellGold';";
						$result = db_query($sql);
						$session[user][gold]=$session[user][gold]-$goldtossed;
						addnav("Try tossing MORE money?","well.php?op=toss");
						}
}//enough gold
 else {$a=$session[user][gold];output("`2 You reach into your pockets for `^$goldtossed `2gold.  Hmm...lint...string...`^$a gold`2...You don't have enough!`n`n",true);addnav("Try tossing LESS money?","well.php?op=toss");}
}//toss gold

page_footer();
?>