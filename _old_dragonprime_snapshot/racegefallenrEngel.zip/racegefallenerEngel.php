<?php
// translator ready
// addnews ready
// mail ready

function racegefallenerEngel_getmoduleinfo(){
	$info = array(
		"name"=>"Race - gefallener Engel",
		"version"=>"1.0",
		"author"=>"Haku",
		"category"=>"Spezialrassen",
		"download"=>"http://dragonprime.net/users/chicu/racegefallenerEngel.rar",
		"settings"=>array(
			"gefallener Engel Race Settings,title",
			"villagename"=>"Name for the gefallener Engel village|Glorfindal",
			"minedeathchance"=>"Chance f�r gefallene engel in der mine zu sterben ,range,0,100,1|90",
		),
	);
	return $info;
}

function racegefallenerEngel_install(){
	module_addhook("chooserace");
	module_addhook("setrace");
	module_addhook("newday");
	module_addhook("villagetext");
	module_addhook("travel");
	module_addhook("charstats");
	module_addhook("validlocation");
	module_addhook("validforestloc");
	module_addhook("moderate");
	module_addhook("changesetting");
	module_addhook("raceminedeath");
	module_addhook("pvpadjust");
	module_addhook("racenames");
	return true;
}

function racegefallenerEngel_uninstall(){
	global $session;
	$vname = getsetting("villagename", LOCATION_FIELDS);
	$gname = get_module_setting("villagename");
	$sql = "UPDATE " . db_prefix("accounts") . " SET location='$vname' WHERE location = '$gname'";
	db_query($sql);
	if ($session['user']['location'] == $gname)
		$session['user']['location'] = $vname;
	// Force anyone who was a gefallener Engel to rechoose race
	$sql = "UPDATE  " . db_prefix("accounts") . " SET race='" . RACE_UNKNOWN . "' WHERE race='gefallener Engel'";
	db_query($sql);
	if ($session['user']['race'] == 'gefallener Engel')
		$session['user']['race'] = RACE_UNKNOWN;
	return true;
}

function racegefallenerEngel_dohook($hookname,$args){
	//yeah, the $resline thing is a hack.  Sorry, not sure of a better way
	//to handle this.
	// Pass it in via args?
	global $session,$resline;
	$city = get_module_setting("villagename");
	$race = "gefallener Engel";
	switch($hookname){
	case "racenames":
		$args[$race] = $race;
		break;
	case "pvpadjust":
		if ($args['race'] == $race) {
			$args['creaturedefense']+=(2+floor($args['creaturelevel']/5));
			$args['creatureattack']+=(2+floor($args['creaturelevel']/5));                        
		}
		break;
	case "raceminedeath":
		if ($session['user']['race'] == $race) {
			$args['chance'] = get_module_setting("minedeathchance");
		}
		break;
	case "changesetting":
		// Ignore anything other than villagename setting changes
		if ($args['setting'] == "villagename" && $args['module']=="racegefallenerEngel") {
			if ($session['user']['location'] == $args['old'])
				$session['user']['location'] = $args['new'];
			$sql = "UPDATE " . db_prefix("accounts") .
				" SET location='" . $args['new'] .
				"' WHERE location='" . $args['old'] . "'";
			db_query($sql);
			if (is_module_active("cities")) {
				$sql = "UPDATE " . db_prefix("module_userprefs") .
					" SET value='" . $args['new'] .
					"' WHERE modulename='cities' AND setting='homecity'" .
					"AND value='" . $args['old'] . "'";
				db_query($sql);
			}
		}
		break;
	case "charstats":
		if ($session['user']['race']==$race){
			addcharstat("Vital Info");
			addcharstat("Race", translate_inline($race));
		}
		break;
	case "chooserace":
		output("<a href='newday.php?setrace=$race$resline'>Tief unter der Erde</a> in den tiefen der H�lle, leben die gefallenen Engel. `^gefallene Endel`0 regieren dort die Unterwelt.`n`n", $city, true);
		addnav("`4gefallener Engel`0","newday.php?setrace=$race$resline");
		addnav("","newday.php?setrace=$race$resline");
		break;
	case "setrace":
		if ($session['user']['race']==$race){
			output("`^Als gefallener Engel bist du immun gegen Vampirrassen, da dein Blut wie ein Gift auf sie wirkt.`n");
			output("Du bekommst extra Verteidgung und Attacke!");
			if (is_module_active("cities")) {
				if ($session['user']['dragonkills']==0 &&
						$session['user']['age']==0){
					//new farmthing, set them to wandering around this city.
					set_module_setting("newest-$city",
							$session['user']['acctid'],"cities");
				}
				set_module_pref("homecity",$city,"cities");
				if ($session['user']['age'] == 0)
					$session['user']['location']=$city;
			}
		}
		break;
	case "newday":
		if ($session['user']['race']==$race){
			racegefallenerEngel_checkcity();
			apply_buff("racialbenefit",array(
				"name"=>"`@Engelsinne`0",
				"defmod"=>"(<defense>?(2+((1+floor(<level>/5))/<defense>)):0)",
                        "atkmod"=>"(<attack>?(2+((1+floor(<level>/5))/<defense>)):0)",
				"allowinpvp"=>1,
				"allowintrain"=>1,
				"rounds"=>-1,
				"module-racegefallenerEngel",
				)
			);
		}
		break;
	case "validforestloc":
	case "validlocation":
		if (is_module_active("cities"))
			$args[$city]="village-$race";
		break;
	case "moderate":
		if (is_module_active("cities")) {
			tlschema("commentary");
			$args["village-$race"]=sprintf_translate("City of %s", $city);
			tlschema();
		}
		break;
	case "travel":
		$capital = getsetting("villagename", LOCATION_FIELDS);
		$hotkey = substr($city, 0, 1);
		tlschema("module-cities");
		if ($session['user']['location']==$capital){
			addnav("Safer Travel");
			addnav(array("%s?Go to %s", $hotkey, $city),"runmodule.php?module=cities&op=travel&city=$city");
		}elseif ($session['user']['location']!=$city){
			addnav("More Dangerous Travel");
			addnav(array("%s?Go to %s", $hotkey, $city),"runmodule.php?module=cities&op=travel&city=$city&d=1");
		}
		if ($session['user']['superuser'] & SU_EDIT_USERS){
			addnav("Superuser");
			addnav(array("%s?Go to %s", $hotkey, $city),"runmodule.php?module=cities&op=travel&city=$city&su=1");
		}
		tlschema();
		break;	
	case "villagetext":
		racegefallenerEngel_checkcity();
		if ($session['user']['location'] == $city){
			$args['text']=array("`^`c`b%s, anmutiges Heim der Elfen und gefallenen Engel `b`c`n`6Du findest dich auf dem Waldboden stehend wieder. Vor dir erhebt sich die anmutige Stadt %s , Eins mit dem sie umgebenden Wald. Uralte zerbrechlich wirkende Geb�ude scheinen aus dem Waldboden, den �sten und Baumwipfeln zu erwachsen. Wie ein sanfter Hauch umschliessen die prachtvollen B�ume die Heime der Elfen. Kleine hellleuchtende Lichtschw�rme umschwirren dich als du voranschreitest..`n", $city, $city);
			$args['schemas']['text'] = "module-racegefallenerEngel";
			$args['clock']="`n`6Du f�ngst eines der kleinen Lichter ein, h�lst es behutsam in deiner Hand und betrachtest es.`nEs ist eine winzige Fee, die dir sagt, es sei `^%s`6 , bevor sie in einem hellen Aufblitzen verschwindet.`n";
			$args['schemas']['clock'] = "module-racegefallenerEngel";
			if (is_module_active("calendar")) {
				$args['calendar']="`n`6Eine andere Fee fl�stert in dein Ohr, \"`^Heute ist `&%3\$s %2\$s`^, `&%4\$s`^. Es ist `&%1\$s`^.`6\"`n";
				$args['schemas']['calendar'] = "modules-racegefallenerEngel";
			}
			$args['title']= array("%s City", $city);
			$args['schemas']['title'] = "module-racegefallenerEngel";
			$args['sayline']="converses";
			$args['schemas']['sayline'] = "module-racegefallenerEngel";
			$args['talk']="`n`^Nearby some villagers converse:`n";
			$args['schemas']['talk'] = "module-racegefallenerEngel";
			$new = get_module_setting("newest-$city", "cities");
			if ($new != 0) {
				$sql =  "SELECT name FROM " . db_prefix("accounts") .
					" WHERE acctid='$new'";
				$result = db_query_cached($sql, "newest-$city");
				$row = db_fetch_assoc($result);
				$args['newestplayer'] = $row['name'];
				$args['newestid']=$new;
			} else {
				$args['newestplayer'] = $new;
				$args['newestid']="";
			}
			if ($new == $session['user']['acctid']) {
				$args['newest']="`n`6Du schaust herum, erstaunt �ber die hohen Geb�ude und f�hlst gerdezu die atemeraubende Ausicht.";
			} else {
				$args['newest']="`n`6 `^%s sieht sich die Geb�ude hoch oben an, mit einem mulmigen Gef�hl im Bauch bei dem Gedanken an diese H�he `6";
			}
			$args['schemas']['newest'] = "module-racegefallenerEngel";
			$args['gatenav']="Village Gates";
			$args['schemas']['gatenav'] = "module-racegefallenerEngel";
			$args['fightnav']="Honor Avenue";
			$args['schemas']['fightnav'] = "module-racegefallenerEngel";
			$args['marketnav']="Mercantile";
			$args['schemas']['marketnav'] = "module-racegefallenerEngel";
			$args['tavernnav']="Towering Halls";
			$args['schemas']['tavernnav'] = "module-racegefallenerEngel";
			$args['section']="village-$race";
		}
		break;
	}
	return $args;
}

function racegefallenerEngel_checkcity(){
	global $session;
	$race="gefallener Engel";
	$city=get_module_setting("villagename");
	
	if ($session['user']['race']==$race && is_module_active("cities")){
		//if they're this race and their home city isn't right, set it up.
		if (get_module_pref("homecity","cities")!=$city){ //home city is wrong
			set_module_pref("homecity",$city,"cities");
		}
	}	
	return true;
}

function racegefallenerEngel_run(){

}
?>
