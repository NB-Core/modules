-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
Race - Drow - A module for Legend of the Green Dragon 1.0.3

Legend of the Green Dragon
by  Eric "MightyE" Stevens (http://www.mightye.org)
and JT "Kendaer" Traub (http://www.dragoncat.net)

Software Project Page:
http://sourceforge.net/projects/lotgd

Modification Community Page:
http://dragonprime.net

Author of this Module:
Original Author - Chris Vorndran (Sichae)
Altered by - Enderandrew (enderandrew@gmail.com)

Enderandrew's LoGD game:
http://enderandrew.com/lotgd/

Download the latest version of this module from:
http://dragonprime.net/index.php?action=viewfiles&user=enderwiggin

----------------------------------------------
-- STATUS: -----------------------------------
----------------------------------------------
This module is STABLE.

----------------------------------------------
-- INFORMATION: ------------------------------
----------------------------------------------
This is Sichae's module.  I've altered what city the Drow live in,
and made some rather minute changes.  I thought it more approrpriate
to have the Drow living with the Dark Elves.  I don't advertise this
module, because I'm not trying to suggest people should run this one
rather than Sichae's version. 

This version has a description field and will only run with 1.0.3 or
later versions of LotGD.

Hope you enjoy!

----------------------------------------------
-- INSTALLATION: -----------------------------
----------------------------------------------
Copy the racedrow.php file within this zip into your modules
directory.

Login to the Superuser Grotto and Install / Activate it.

-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-


