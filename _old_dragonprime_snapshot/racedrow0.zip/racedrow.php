<?php

function racedrow_getmoduleinfo(){
	$info = array(
		"name"=>"Race - Drow",
		"version"=>"1.2",
		"author"=>"Chris Vorndran<br>Altered by T. J. Brumfield",
		"category"=>"Races",
		"description"=>"A dark race that gains extra hitpoints.",
		"download"=>"http://dragonprime.net/users/enderwiggin/racedrow.zip",
		"requires"=>array(
			"racedarkelf" => "1.2|Kevin Hatfield - Arune, http://dragonprime.net/users/khatfield/racedarkelf.zip",
			"alignment" => "1.71|`1Enderandrew, http://dragonprime.net/users/enderwiggin/alignment98.zip",
		),		
		"vertxtloc"=>"http://dragonprime.net/users/enderwiggin/",
		"settings"=>array(
			"Drow Race Settings,title",
			"minedeathchance"=>"Chance for Drow to die in the mine,range,0,100,1|80",
			"divide"=>"Favor is divided by this value to provide extra hp perday,int|3",
			"mindk"=>"How many DKs do you need before the race is available?,int|5",
			"cost"=>"How many Donation points do you need before the race is available?,int|0",
		),
	);
	return $info;
}

function racedrow_install(){
	if (!is_module_installed("racedarkelf")) {
		output("The Drow only choose to live with dark elves.   You must install that race module.");
		return false;
	}
	module_addhook("charstats");
	module_addhook("chooserace");
	module_addhook("newday");
	module_addhook("pointsdesc");
	module_addhook("pvpadjust");
	module_addhook("raceminedeath");
	module_addhook("setrace");
	return true;
}

function racedrow_uninstall(){
	global $session, $badguy;
	$vname = getsetting("villagename", LOCATION_FIELDS);
	$gname = get_module_setting("villagename");
	$sql = "UPDATE " . db_prefix("accounts") . " SET location='$vname' WHERE location = '$gname'";
	db_query($sql);
	if ($session['user']['location'] == $gname)
		$session['user']['location'] = $vname;
	$sql = "UPDATE  " . db_prefix("accounts") . " SET race='" . RACE_UNKNOWN . "' WHERE race='Drow'";
	db_query($sql);
	if ($session['user']['race'] == 'Drow')
		$session['user']['race'] = RACE_UNKNOWN;
	return true;
}

function racedrow_dohook($hookname,$args){
	//yeah, the $resline thing is a hack.  Sorry, not sure of a better way
	//to handle this.
	// It could be passed as a hook arg?
	global $session,$resline;
		if (is_module_active("racedarkelf")) {
			$city = get_module_setting("villagename", "racedarkelf");
		} else {
			$city = getsetting("villagename", LOCATION_FIELDS);
		}
	$race = "Drow";
	$cost = get_module_setting("cost");
	$divide = get_module_setting("divide");
	$drow = $session['user']['deathpower']/$divide; 
	$city = get_module_setting("villagename");
	switch($hookname){

	case "charstats":
		if ($session['user']['race']==$race){
			addcharstat("Vital Info");
			addcharstat("Race", $race);
		}
	break;

	case "chooserace":
		$pointsavailable = $session['user']['donation'] - $session['user']['donationspent'];
		if ($session['user']['dragonkills'] < get_module_setting("mindk") || get_module_setting("cost") > $pointsavailable)
			break;
		output("<a href='newday.php?setrace=Drow$resline'>Living in the confines.</a> Your small village of %s `)chambered away from the world. `^Drowish`0 `4structures protecting you, from the High Elves. You are a creature of the darkness, wishing for acceptance...`n`n",$city,true);
		addnav("`)D`7row`0","newday.php?setrace=Drow$resline");
		addnav("","newday.php?setrace=Drow$resline");
        break;

	case "newday":
		if ($session['user']['race']==$race){
		racedrow_checkcity();
		$session['user']['hitpoints']+=$drow;
	}
	break;

	case "pointsdesc":
		if (get_module_setting("mindk")>0 || $cost>0)
		{
			$args['count']++;
			$format = $args['format'];
			$str = translate("The Drow race is availiable upon reaching %s Dragon Kills and %s Donation points.");
			$str = sprintf($str, get_module_setting("mindk"),
					get_module_setting("cost"));
			output($format, $str, true);
		}
		break;

	case "pvpadjust":
		if ($args['race'] == $race) {
			$badguy['hitpoints']+=$drow;
		}
		break;

	case "raceminedeath":
		if ($session['user']['race'] == $race) {
		$args['chance'] = get_module_setting("minedeathchance");
		$args['racesave'] = "Fortunately your Drow skill let you escape unscathed.`n";
		}
        break;

	case "setrace":
		if ($session['user']['race']==$race){
			output("`^As a Drow, you feel the powers of darkness, coursing in your veins.`nYou gain extra hitpoints at the cost of your morality!");
			if (is_module_active('alignment')) {
				align("-5");
			}
		if (is_module_active("cities")) {
			if ($session['user']['dragonkills']==0 &&
				$session['user']['age']==0){
				//new farmthing, set them to wandering around this city.
				set_module_setting("newest-$city",
				$session['user']['acctid'],"cities");
			}
			set_module_pref("homecity",$city,"cities");
			$session['user']['location']=$city;
		}
	}
        break;

	}
	return $args;
}

function racedrow_checkcity(){
	global $session;
	$race="Drow";
	if (is_module_active("racedarkelf")) {
		$city = get_module_setting("villagename", "racedarkelf");
	} else {
		$city = getsetting("villagename", LOCATION_FIELDS);
	}
	
	if ($session['user']['race']==$race && is_module_active("cities")){
		//if they're this race and their home city isn't right, set it up.
		if (get_module_pref("homecity","cities")!=$city){ //home city is wrong
			set_module_pref("homecity",$city,"cities");
		}
	}
	return true;
}

function racedrow_run(){
}
?>