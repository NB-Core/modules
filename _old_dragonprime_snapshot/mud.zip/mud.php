<?
/* Original script by LonnyL
Modified by Excalibur for www.ogsi.it
*/
output("`2You notice a movement behind a bush, and you jump quickly to catch the animal you think it's behind it!  Ohhhh!`n
You stumble and you fall into the mud!  You are covered from head to feet of mud!`n`n");
$dirty = e_rand(1,5);
$session['user']['clean'] += $dirty;
output("While you rise, helping yourself with hands, you feel something in the mud under your your palm:`n");
switch (e_rand(0,5)) {
    case 0:
        output("`@you sort it our and you find yourself to gaze to gaze a marvelous `&gem`@! `n");
        output("In the end it's been a lucky day!`n`n");
        $session['user']['gems']++;
        debuglog("find a gem in the mud");
    break;
    case 1:
        output("raising your hand from the mud you realize you're wounded.`n The `\$blood`2 gushes out plentiful from the cut ");
        output("that you are given yourself. `4Your sight becomes cloudy and you pass out .... `2When you wake up ");
        output("you discover to have lost many of your HitPoints!`n`n");
        $session['user']['hitpoints'] -= intval($session['user']['hitpoints']/3);
        if ($session['user']['hitpoints'] <= 0) $session['user']['hitpoints'] = 0;
    break;
    case 2:
        $gold = e_rand(100,200)*$session['user']['level'];
        output("`#it seems a leather purse, and opening it you find `^$gold `#gold pieces!`n");
        output("In the end it's been a lucky day!`n`n");
        $session['user']['gold'] += $gold;
        debuglog("find $gold in the mud");
    break;
    case 3:
        output("`7it it seems an old parchment. Curiously you unroll it with care and you begin to read it. `n");
        output("`2Finished the reading you feel a shiver cross your back, and feel yourself more `@vigorous!`n");
        output("`@The `7Goddess of the Mud`@ has infused you a greater vigor for your fights!`n`n");
        $turni = e_rand(3,5);
        $session['bufflist']['deadef'] = array(
             "name"=>"`#Goddess of the Mud",
             "rounds"=>$turni,
             "startmsg"=>"`n`^You launch squirts of mud against your enemy!`n",
             "minioncount"=>round($session['user']['level']/3)+1,
             "wearoff"=>"`&You have exhausted the escort of mud",
             "maxbadguydamage"=>round($session['user']['level']/2,0)+1,
             "effectmsg"=>"`&The squirts of mud strike {badguy} and inflict him {damage} damage points.",
             "activate"=>"roundstart"
             );
    break;
    case 4:
        output("`7it it seems an old parchment. Curiously you unroll it with care and you begin to read it. `n");
        output("`2Finished the reading you feel a shiver cross your back, and feel yourself more `@athletic!`n");
        output("`@The `7Goddess of the Mud`@ has infused you a greater vigor for your fights!`n`n");
        $turni = e_rand(5,15);
        $session['bufflist']['deadef'] = array(
             "name"=>"`#Goddess of the Mud",
             "rounds"=>$turni,
             "wearoff"=>"`&You have exhausted the escort of mud",
             "defmod"=>1.3,
             "roundmsg"=>"`&You launch squirts of mud against {badguy} blinding him. His hit comes to target but with reduced power.",
             "activate"=>"defense"
             );
    break;
    case 5:
        output("`5it seems a leather purse, `b`%YOUR`5`b purseo! `n`2You open it to discover with horror that every ");
        output("single gold piece you had are lost in the mud!!`n");
        switch (e_rand(1,2)) {
            case 1:
                $recupero = intval(($session['user']['gold'] * e_rand(1,10))/100);
                output("`3You look for gold in the mud with the hope of finding some pieces, and in the end you succeed in finding `#$recupero`n`n");
                $perdita = $session['user']['gold'] - $recupero;
                debuglog("lose $perdita in the mud");
                $session['user']['gold'] = $recupero;
            break;
            case 2:
                output("You look for gold in the mud with the hope of finding some pieces, but unfortunately you don't succeed in recovering ");
                output("not even a single gold piece! They seem to have been swallowed by the mud!`n`n");
                debuglog("lose {$session['user']['gold']} in the mud");
                $session['user']['gold'] = 0;
            break;
        }
    break;
}
output("`n`n`6Besides you lose a turn to polish up you from the mud that it entirely covers you!`n`n");
$session['user']['turns'] -= 1;
addnav("`@Back to Forest","forest.php");
?>