<?php

function robertconf_getmoduleinfo(){
	$info = array(
		"name"=>"Confections Shop",
		"author"=>"Chris Vorndran<br>`6Idea: `2Robert`0",
		"version"=>"1.0",
		"category"=>"Village",
		"download"=>"http://dragonprime.net/users/Sichae/robertconf.zip",
		"vertxtloc"=>"http://dragonprime.net/users/Sichae/",
		"settings"=>array(
			"Confections Settings,title",
				"max"=>"How many confections can a person purchase?,int|10",
				"cost"=>"Cost per confection,int|10",
				"tophp"=>"Maximum HP that one can gain,int|4",
				"who"=>"What is the name of the owner?,text|Robert",
				"Please no colour codes.,note",
				"If a person goes over this Tummy Aches will occur.,note",
				"oust"=>"How long is a person not allowed to go in after getting a tummy ache (`igame days`i),range,1,10,1|2",
				"shoploc"=>"Location of the shop,location|".getsetting("villagename",LOCATION_FIELDS),
				"cycle"=>"What confections are being served?,enum,0,cookies,1,tarts,2,pastries,3,sugarbombs|0",
		),
		"prefs"=>array(
			"Confections Prefs,title",
				"amnt"=>"How many confections have been bought?,int|0",
				"totalhp"=>"How much HP (total) has the person gained,int|0",
				"tummy"=>"Does the person have a tummy ache?,bool|0",
				"daysleft"=>"How many days left? (`iif the person had a tummy ache`i),int|0",
		),
	);
	return $info;
}
function robertconf_install(){
	module_addhook("village");
	module_addhook("newday-runonce");
	module_addhook("newday");
	module_addhook("changesetting");
	return true;
}
function robertconf_uninstall(){
	return true;
}
function robertconf_dohook($hookname,$args){
	global $session;
	switch ($hookname){
		case "village":
			if ($session['user']['location'] == get_module_setting("shoploc")){
				tlschema($args['schemas']['marketnav']);
				addnav($args['marketnav']);
				tlschema();
				addnav(array("%s's Confections",get_module_setting("who")),"runmodule.php?module=robertconf&op=enter");
			}
			break;
		case "changesetting":
			if ($args['setting'] == "villagename"){
				if ($args['old'] == get_module_setting("shoploc")){
					set_module_setting("shoploc",$args['new']);
				}
			}
			break;
		case "newday-runonce":
			increment_module_setting("cycle",1);
			if (get_module_setting("cycle") > 3) set_module_setting("cycle",0);
			break;
		case "newday":
			$hp = get_module_pref("totalhp");
			if (get_module_pref("tummy") && get_module_pref("daysleft") > 0){
				increment_module_pref("daysleft",-1);
				$session['user']['hitpoints']-=$hp;
				if ($session['user']['hitpoints'] <= 0) $session['user']['hitpoints'] = 1;
				output("`n`@Still having your stomach ache, you lose `\$%s `@%s in pain.`n",
					$hp,translate_inline($hp==1?"hitpoint":"hitpoints"));
			}
			if(get_module_pref("daysleft") <= 0){
				set_module_pref("tummy",0);
				output("`n`@As you have been resting for `^%s `@days, you are now allowed to visit the candy shop once more.`n",get_module_setting("oust"));
				set_module_pref("totalhp",0);
			}
			set_module_pref("amnt",0);
			break;
		}
	return $args;
}
function robertconf_run(){
	global $session;
	$op = httpget('op');
	$days = get_module_pref("daysleft");
	$tummy = get_module_pref("tummy");
	$cycle = get_module_setting("cycle");
	$cost = get_module_setting("cost");
	$who = get_module_setting("who");
	$confections = array("cookie","tart","pastry","sugarbomb");
	$confections = translate_inline($confections);
	$cycle = $confections[$cycle];
	$gen = translate_inline($session['user']['sex']==0?"his":"her");
	page_header(array("%s's Confections",$who));
	
	switch ($op){
		case "enter":
			if ($days <= 0 && !$tummy){
				output("`2%s `2greets you with a warm smile as you enter into his shop.",$who);
				output("\"`@Welcome to my store... would you care to purchase a `Q%s`@ for `^%s `@gold?`2\"",$cycle,$cost);
				addnav(array("%s (%s gold)",ucfirst($cycle),$cost),"runmodule.php?module=robertconf&op=purchase");
			}else{
				output("`2%s `2takes one look at you, seeing the crumbs mussed in with your hair and points to the door.",$who);
				output("\"`@Get out.`2\"");				
			}
			break;
		case "purchase":
			if ($session['user']['gold'] >= $cost){
				$gain = e_rand(1,get_module_setting("tophp"));
				increment_module_pref("amnt",1);
				debug(get_module_pref("amnt"));
				set_module_pref("totalhp",get_module_pref("totalhp")+$gain);
				output("`2%s `2hands you your `Q%s`2, which you gobble down quickly.",$who,$cycle);
				output("Stifling a burp, you can feel yourself feeling a bit stronger.");
				output("`n`n`^You gained `\$%s `^%s.`n",$gain,translate_inline($gain==1?"hitpoint":"hitpoints"));
				$session['user']['hitpoints']+=$gain;
				$session['user']['gold']-=$cost;
				if (get_module_pref("amnt") > get_module_setting("max")){
					set_module_pref("tummy",1);
					addnews("%s `2screamed bloody murder until the healer came and relieved %s tummy ache."
						,$session['user']['name'],$gen);
					output("`nYou clutch your stomach and fall into a fit of pain.");
					output("You awaken, writing in pain.");
					output("It feels as if your stomach is going to burst open and you find yourself screaming for help.");
					output("The healer runs in and bids you away from any candy for %s days.`n",get_module_setting("oust"));
					set_module_pref("daysleft",get_module_setting("oust"));
					// Just do it!
					blocknav("runmodule.php?module=robertconf&op=purchase");
				}
				if (!$tummy) addnav(array("Purchase another %s",ucfirst($cycle)),
									"runmodule.php?module=robertconf&op=purchase");
			}else{
				output("`2%s `2reaches for your gold, but is unable to find the correct amount.",$who);
				output("\`@Please return once you have the correct amount of gold.`2\"");
			}
			break;
	}
	addnav("Leave");
	villagenav();
	page_footer();
}
?>