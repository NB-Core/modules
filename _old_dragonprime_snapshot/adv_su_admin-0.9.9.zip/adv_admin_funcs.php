<?php
// ----------------------------------------------------------------------------
// adv_admin_funcs.php
// CR#Dasher#005
// 30th April 2004
// Version: 0.9.9
// The latest version is always runnning at: www.sembrance.uni.cc/rpg
// (c) 2003 Dasher [david.ashwood@inspiredthinking.co.uk]
// This module is relased under the LOTGD GNU public license
// You may change/modify this module and it's associated modules as you wish but
// this copyright MUST be retained.
//
// I would apprechiate feedback/updates on how it works and changes you make.
// Dasher
// ----------------------------------------------------------------------------
// Introduction
// ------------
// This module provides the functions for Advanced management of Admins
// and allows granular control permissions based on pages.  The code now allows you to define roles and
// assign one or more modules/Admins to a role.
// An example is defined a set of admins to look after users, dealing with petitions and user accounts - but they don't need
// to be able to create creatures or manage guilds.
//
// It's pretty simple to use and implement into your code.
// Pages that provide admin controls tend to come in one of two flavours:
//   a) Those that have isnewday(x)
//      1) Remove or comment out the the isnewday(x) line
//      2) Wrap the page, after the page_header() and before the page_footer(), in:
//         if (SU_Admin_Allowed()) {
//           <--- Insert page here --->
//         } else {
//           addnav("Return to Village","village.php");
//         }
//      3) Save changes & you're done
//
//   b) Those that allow code to be run based on checking the $session['user']['superuser'] variable
//      1) You'll need to change something like:
//            if ($session['user']['superuser']>=2) {
//               <--- Provides Admin controls --->
//            }
//         To:
//            if (SU_Admin_Allowed()) {
//               <--- Provides Admin controls --->
//            }
//
// Overview
// --------
// The functions use the standard superuser field in the database as a bitwise mask.
//
// The first time the page is accessed - the page is registered in the database in the lotbd_su_modules table
// and marked as not configured.  If a page hasn't been configured then the default mode of checking is done
// to determine if the $session['user']['superuser']>=2.
//
// The su_admin.php page allows your to manage the pages that have been registered.
// Initially it displays all the pages that have been registered, you can select a page to change the admin rights
// You'll then be presented with a list of all the admin accounts (using the superuser field>=2)
// and be able to allow or deny admin access to the page.
//
// There are 2 modes of operation, Roles and Modules.
// ROLES:
// Roles allow you to assign 1+ modules to a role and then 1+ Admins to the role
// This happens outside of the superuser field, although currently you can only select users who have a superuser >=1
// This will change in the future when I can think of presenting the list of users in a better way for selection
// NOTE:
//   -> ROLES Don't use the superuser field in the check
//   -> ROLES work with the acctid and the module id
//
// MODULES:
// The mask is 2^(moduleID+2), where moduleID is the idenity from the lotbd_su_modules
// This allows you to setup a single page for one or more admins
//
// Other Info
// This version supports 30 separate pages
// If it turns out that a greater number of pages need to be managed then it should be simple to increase
// using encoded strings.
// ----------------------------------------------------------------------------
// Installation instructions:
// There are 6 simple changes needed to implement Advanced Admin management.
//
// 1) common.php:
//    Why:
//    This will make the SU Admin functions available throughout all pages.
//    What:
//       after => require_once "dbwrapper.php";
//       add => require_once "adv_admin_funcs.php";
//
// 2) superuser.php:
//    Why:
//    This will provide a way to administrator the Admins
//    What:
//       after =>  addnav("Editors");
//       add => addnav("SU Management","su_admin.php");
//
// 3) dbwrapper.php:
//    Why:
//    The funciton returns the identity of the inserted record.
//    What:
//       function db_insert($sql) {
//         global $session,$dbqueriesthishit;
//         $dbqueriesthishit++;
//         $fname = DBTYPE."_query";
//         $r = $fname($sql) or die(($session[user][superuser]>=3 || 1?"<pre>".HTMLEntities($sql)."</pre>":"").db_error(LINK));
//         $fname = DBTYPE."_insert_id";
//         $id=$fname();
//         return $id;
//       }
//
// 4) user.php:
//    Why:
//    The new Admin management no longer fits the enums previously defined
//    What:
//       Change => "superuser"=>"Superuser,enum,0,Standard play days per calendar day,1,Unlimited play days per calendar day,2,Admin creatures and taunts,3,Admin users",
//       To:  "superuser"=>"SuperUser,int", // Changed due to Advanced user management - Dasher
//
// 5) Database:
//    Why:
//    This is where the SU Admin functions look to determine what pages have been registered and configured
//    There is the module table and the roles table
//    What:
//    The SQL for creating the tables is:
//    #
//    # Advanced SU Rights management table
//    # (c) Dasher 2004 - david.ashwood@inspiredthinking.co.uk
//    #
//    CREATE TABLE `lotbd_su_modules` (
//     `ID` int(11) unsigned NOT NULL auto_increment,
//     `ModuleName` varchar(100) NOT NULL default '',
//     `Configured` tinyint(3) unsigned NOT NULL default '0',
//     `Comments` varchar(100) default '',
//      PRIMARY KEY  (`ID`),
//      KEY `idx_SU_Modules` (`ModuleName`)
//    ) TYPE=MyISAM COMMENT='Advanced SU Rights Management - Dasher';
//
//    # Advanced SU Rights management table
//    # (c) Dasher 2004 - david.ashwood@inspiredthinking.co.uk
//  # Table: 'lotbd_su_roles'
//  #
//  CREATE TABLE `lotbd_su_roles` (
//      `ID` int(11) unsigned NOT NULL auto_increment,
//      `Name` varchar(50) NOT NULL default '',
//      `Description` varchar(100) NOT NULL default '',
//      `Rights` varchar(200) NOT NULL default '',
//      `AdminsInRole` blob NOT NULL,
//      PRIMARY KEY  (`ID`)
//  ) TYPE=MyISAM COMMENT='Roles for the lotbd_su_modules & Admins';
//
// 6) Follow the information in the introduction for how to change the pages and have granular control over the Admins
//
// ----------------------------------------------------------------------------
// ChangeLog:
// ----------
// 30th April 2004
// Fixed a passed by reference bug
// Implemented Roles
//    A role is a grouping of one or more modules and one or more Admins
//
// ToDo
// ----
// Improve su_admin.php display and control to make it easier to manage pages/admins
// Possibly support > 30 Admin pages
// Delete Roles
//
// ----------------------------------------------------------------------------
//

require_once "common.php";

// Templates for the Role Creation
$RoleAddTemplate=array(
    "Create Role,title",
    "ID"=>"ID,viewonly",
    "Name"=>"Name of Role",
    "Description"=>"Description",
    "Rights"=>"Rights Assigned,viewonly",
    "AdminsInRole"=>"Admins in this Role,viewonly",
    " ,title"
);

$BlankRoleTemplate=array(
    "ID"=>"",
    "Name"=>"",
    "Description"=>"",
    "Rights"=>array(),
   "AdminsInRole"=>array()
);

function SU_Admin_Allowed() {
//
// Main function - to be called by pages that wish to restrict functionality to specific Admins
// If a calling page isn't known to the database - the page is registered and marked as not
// configured.
//
    global $session;
    $ModuleName=Source_Module(False);
    $RightsMask=-1;

    if (ModuleNameRegisteredForSU($ModuleName, $RightsMask, true)) {
        // They are a superuser
        if ($RightsMask!=0) {
            // Module has been registered and configured by the Admin
            if (CallerInRole($session['user']['acctid'], $RightsMask)) {
                // They are in a defined Role
                return true;
            } else {
                // They are in no role, check if they have a specific right to access the page
                if ((pow(2,$RightsMask+2) & $session['user']['superuser'])==pow(2,$RightsMask+2)) {
                 // We are allowed to admin this function
                 return true;
                } else {
                 // We are not allowed to Admin this function
                 return false;
                }
            }
        } else {
            // The rights mask isn't set for some reason
            return false;
        }
    } else {
        // The module hasn't been registered, so use the old method for allowing access
        if ($session['user']['superuser']>=2) {
            return true;
        } else {
            return false;
        }
    }
}

function CallerInRole($acctid, $ModuleMask) {
//
// A role comprises of zero or more modules and zero or more admins - defined by Acctid
// Determine if the acctid and the module ID has been defined in a role
// If so the function returns true, otherwise returns false
//
    $UserSearch="%i:".$acctid.";s:0:\"\";%";    // This is a bit of a cheat but it's faster in the database than in PHP
    $ModuleSearch="%i:".$ModuleMask.";s:0:\"\";%";
    $sql="select * from lotbd_su_roles where Rights like '".$ModuleSearch."' and AdminsInRole like '".$UserSearch."'";
    $result=db_query($sql);
    $RowCount=db_num_rows($result);
    if ($RowCount>0) {
        return true;
    } else {
        return false;
    }
}

Function Source_Module($AllModules=false) {
// Determines the source page.

    $Modules = array();
    $traceArr = debug_backtrace();
    array_shift($traceArr);
    foreach ($traceArr as $arr) {
        $Modules[] = basename($arr['file']);
    }

    if ($AllModules) {
        return $Modules;
    } else {
        // Return the earliest calling module
        return $Modules[count($Modules)-1];
    }
}

function ModuleNameRegisteredForSU($ModuleName, &$SU_Mask_Index, $Register=true) {

// Verify if a module has been registered
// Return the index through a passed parameter, return true/false depending if it has been registered

    $sql="Select * from LOTBD_su_modules where ModuleName=\"".addslashes($ModuleName)."\"";
    $result=db_query($sql);
    $RowCount=db_num_rows($result);

    if ($RowCount==0) {
        // ModuleName isn't found
        if ($Register) {
            $sql="insert into LOTBD_su_modules set ModuleName=\"".$ModuleName."\", Comments=\"".addslashes($ModuleName)."\"";
            $result=db_insert($sql);
            $SU_Mask_Index=$result;
            return false;
        } else {
            // Return not found
            return false;
        }
    } else {
        // The module has been registered
        $row=db_fetch_assoc($result);
        // Has the module been configured?
        // This handles an admin not getting around to finishing the permissions
        if ($row['Configured']==1) {
            // Yep
            $SU_Mask_Index=$row['ID'];
            return true;
        } else {
            // Nope
            return false;
        }
    }
}

function ReturnSUMaskModules($TheseOnly=false, $FieldList="*") {
// Returns all the modules that have been registered unless the function is passed an array of modules to return
// The optional field list returns only the specific fields, defaulting to all fields
//
    if ($TheseOnly==false) {
        $sql_append="";
    } else {
        $InList=implode(",",array_keys($TheseOnly));
        $sql_append=" where id in (".$InList.")";
    }
    $sql="select ".$FieldList." from lotbd_SU_modules".$sql_append;
    $result=db_query($sql);
    $RowCount=db_num_rows($result);

    $Results=array();

    for ($i=0; $i<$RowCount; $i++) {
        $row=db_fetch_assoc($result);
        $row['Comments']=stripslashes($row['Comments']);
        $Results[$row['ID']]=$row;
    }

    return $Results;
}

function ReturnSUMaskModules_with_Admins($ModuleID=0) {
// Returns the admins that have been configured to Admin the passed in module
//
    if ($ModuleID!=0) {
        $sql="select name, acctid, superuser, lotbd_su_modules.id, modulename, (accounts.superuser  & pow(2,lotbd_su_modules.id+2)) from accounts, lotbd_su_modules where (accounts.superuser & pow(2,lotbd_su_modules.id+2))=pow(2,lotbd_su_modules.id+2) and lotbd_su_modules.id=".$ModuleID;
    } else {
        $sql="select accounts.login, accounts.acctid, superuser, lotbd_su_modules.ID, lotbd_su_modules.ModuleName, lotbd_su_modules.Comments, lotbd_su_modules.configured from lotbd_su_modules left join accounts on (pow(2,ID+2)&accounts.superuser)=pow(2,id+2) ";
    }

    $result=db_query($sql);
    $RowCount=db_num_rows($result);

    $Results=array();

    for ($i=0; $i<$RowCount; $i++) {
        $row=db_fetch_assoc($result);
        $row['Comments']=stripslashes($row['Comments']);
        $Results[$row['acctid']]=$row;
    }
    return $Results;
}

function SUMaskModules_SetConfigured($ModuleID, $ModuleName="", $ModuleComment="") {
// Set a module to indicate it is configured
     if ($ModuleName!="") {
        $sql=", ModuleName=".$ModuleName;
    }
    $sql.=", Comments='".addslashes($ModuleComment)."'";

    $sql="update lotbd_Su_modules set ID=".$ModuleID.$sql.", configured=1 where ID=".$ModuleID;
    db_query($sql);
}

function SUMaskModules_AssignAdmins($ModuleID, $AdminIDs_Array) {
    // Assigns one or more admins to manage a module
    global $session;

    $Mask=pow(2,($ModuleID+2));
    if (count($AdminIDs_Array)>0) {
        if (in_array($session['user']['acctid'],$AdminIDs_Array)) {
            $session['user']['superuser'] = $session['user']['superuser'] | $Mask;
        }
        $SQL_IN=implode(", ",$AdminIDs_Array);
        $sql="update accounts set superuser=(superuser | ".$Mask.") where acctid in (".$SQL_IN.")";
        db_query($sql);
    } else {
        // Nothing passed
    }
}

function SUMaskModules_UnassignAdmins($ModuleID, $AdminIDs_Array) {
    // Assigns one or more admins to manage a module
    global $session;

    $Mask=pow(2,($ModuleID+2));
    if (count($AdminIDs_Array)>0) {
        if (in_array($session['user']['acctid'],$AdminIDs_Array)) {
            $session['user']['superuser'] = $session['user']['superuser'] ^ $Mask;
        }
        $SQL_IN=implode(", ",$AdminIDs_Array);
        $sql="update accounts set superuser=(superuser ^ ".$Mask.") where (accounts.superuser & ".$Mask.")=".$Mask." and acctid in (".$SQL_IN.")";
        db_query($sql);
    } else {
        // Nothing passed
    }
}

function ReturnAdmins($AdminsToReturn=false){
// Returns all the admins from the accounts table
// Admins returned are anybody with superuser>1
// If AdminsToReturn is an array containing ID's then only those admins are returned
//
    if ($AdminsToReturn!=false) {
        if (is_array($AdminsToReturn)) {
            $ids=implode(",", array_keys($AdminsToReturn));
            $sql_include=" and acctid in (".$ids.") ";
        } else {
            die("System Error during Return Admins in adv_admin_funcs.<br>This is a development error and shouldn't be seen in production code<br>".debug_backtrace());
        }
    } else {
        $sql_include="";
    }

    $sql="select acctid, name, superuser from accounts where superuser>1 ".$sql_include." order by superuser desc, acctid desc";
    $result=db_query($sql);
    $rowcount=db_num_rows($result);
    $results=array();

    for ($i=0; $i<$rowcount; $i++) {
        $row=db_fetch_assoc($result);
        $results[$row['acctid']]=$row;
    }
    return $results;
}


Function ReturnRoles($RoleID=false) {
// Returns all Roles defined unless $RoleID has been specified, when it returns just the specified role
//

    if ($RoleID==false) {
        $sql_append="";
    } else {
        $sql_append=" where ID='".$RoleID."'";
    }

    $sql="select * from lotbd_su_roles".$sql_append;
    $result=db_query($sql);
    $rowcount=db_num_rows($result);
    $results=array();

    for ($i=0; $i<$rowcount; $i++) {
        $row=db_fetch_assoc($result);
        if (unserialize($row['Rights'])===false) {  // Turn this field into an array
            $row['Rights']=array();
        } else {
            $row['Rights']=unserialize($row['Rights']);
        }
        if (count($row['Rights'])!=0) {             // Return a pretty list
            // Note: prepending a variable with '.' stops it being saved to the database
            $row['.RightsPretty']=ReturnSUMaskModules($row['Rights']);
        } else {
            // Do nothing
        }
        if (unserialize($row['AdminsInRole'])===false) { // Turn this field into an array
            $row['AdminsInRole']=array();
        } else {
            $row['AdminsInRole']=unserialize($row['AdminsInRole']);
        }
        if (count($row['AdminsInRole'])!=0) {       // Return the real names
            // Note: prepending a variable with '.' stops it being saved to the database
            $row['.AdminsInRole']=ReturnAdmins($row['AdminsInRole']);
        } else {
            // Do nothing
        }
        $results[$row['ID']]=$row;
    }
    return $results;
}

function AddRole($Info) {
// Add a role to the database
//
    $sql="insert into lotbd_su_roles SET ";
    reset($Info);
    while(list($key,$val)=each($Info)){
        if (substr($key,0,1)!="."){     // Ignore any variable that starts with a '.'
            if (is_array($val)){
                  $sql.="$key='".addslashes(serialize($val))."', ";
              }else{
                  $sql.="$key='".addslashes($val)."', ";
              }
      }
    }
    $sql = substr($sql,0,strlen($sql)-2);
    $id=db_insert($sql);
    return $id;
}

function UpdateRole($Info) {
// Update a role
//
    $sql="UPDATE lotbd_su_roles SET ";
    reset($Info);
    while(list($key,$val)=each($Info)){
        if (substr($key,0,1)!="."){         // Ignore any variable that starts with a '.'
            if (is_array($val)){
                  $sql.="$key='".addslashes(serialize($val))."', ";
              }else{
                  $sql.="$key='".addslashes($val)."', ";
              }
      }
    }
    $sql = substr($sql,0,strlen($sql)-2);
    $sql.=" WHERE ID= ".$Info['ID'];
    db_query($sql);

}

function DisplayModules($ExistingModules){
// Just a function to display the modules and a checkbox against each module in a table
// If $ExistingModules is passed then it preselects (checks) those modules
//
    $results=ReturnSUMaskModules();
    output("<table border=0 cellpadding=2 cellspacing=1 bgcolor='#999999' align='center' valign='top' width='100%'>",true);
    while (list($key,$val)=each($results)) {
       output("<tr class=trlight><td>",true);
        if (isset($ExistingModules[$key])==true) {
            output("<input type=checkbox name='module[".$key."]' value='' checked></td>",true);
        } else {
            output("<input type=checkbox name='module[".$key."]' value=''></td>",true);
        }
       output("<td>".$val['ModuleName']."</td>",true);
       output("<td>".$val['Comments']."</td>",true);
       output("</tr>",true);
    }
    output("</table>",true);
}

function DisplayAdmins($ExistingAdmins){
// Just a function to display the Admins and a checkbox against each Admin in a table
// If $ExistingAdmins is passed then it preselects (checks) those Admins
//
    $results=ReturnAdmins();
    output("<table border=0 cellpadding=2 cellspacing=1 bgcolor='#999999' align='center' valign='top' width='100%'>",true);
    while (list($key,$val)=each($results)) {
       output("<tr class=trlight><td>",true);
        if (isset($ExistingAdmins[$key])==true) {
            output("<input type=checkbox name='admin[".$key."]' value='' checked></td>",true);
        } else {
            output("<input type=checkbox name='admin[".$key."]' value=''></td>",true);
        }
       output("<td>".$val['name']."</td>",true);
       output("<td>".$val['acctid']."</td>",true);
       output("</tr>",true);
    }
    output("</table>",true);
}


function Roles() {
// The main Roles code
//

global $HTTP_GET_VARS, $HTTP_POST_VARS;
global $RoleAddTemplate,$BlankRoleTemplate;

    $action=$HTTP_GET_VARS['action'];
    $id=$HTTP_GET_VARS['id'];
    switch ($action) {
        case "manage":
            // Let's manage the roles
            $stage=$HTTP_GET_VARS['stage'];
            switch ($stage) {
                case "save":
                    if (isset($HTTP_POST_VARS['module'])) { // Work out what modules have been set
                        $modules=$HTTP_POST_VARS['module'];
                    } else {
                        $modules=array();
                    }
                    if (isset($HTTP_POST_VARS['admin'])) { // Work out what admins have been defined
                        $admins=$HTTP_POST_VARS['admin'];
                    } else {
                        $admins=array();
                    }
                    $Role=ReturnRoles($id);
                    $Role['Rights']=$modules;
                    $Role['AdminsInRole']=$admins;
                    updateRole($Role);
                    redirect("su_admin.php?op=roles");
                break;

                default:
                    $row=ReturnRoles($id);  // We are working with one role in particular
                    $row=$row[$id];
                    $results=ReturnSUMaskModules();  // Grab a copy of all the modules have have been configured
                    $return=CalcReturnPath(true);
                    // Main display code
                    output("<form action='".$return."&stage=save' method='POST'>",true);
                    addnav("",$return."&stage=save");
                    output("`n`n<table border=0 cellpadding=2 cellspacing=1 bgcolor='#999999' align='center'>",true);
                    output("<tr class='trhead'><td>`c`bManage Role`b`c</td></tr>",true);
                    output("<tr class='trlight'><td>ID: ".$row['ID']."</td></tr>",true);
                    output("<tr class='trlight'><td>Role: ".$row['Name']."</td></tr>",true);
                    output("<tr class='trlight'><td>Description: ".$row['Description']."</td></tr>",true);
                    output("<tr class='trlight'><td>",true);
                    DisplayModules($row['Rights'],true);        // Display all the modules and select those that are already set
                    output("</td></tr>",true);
                    output("<tr class='trlight'><td>",true);
                    DisplayAdmins($row['AdminsInRole'],true);   // Display all the Admins and select those that are already set
                    output("</td></tr>",true);
                    output("<tr class='trlight' align='center'><td><input type='submit' class='button' value='Submit Changes'>",true);
                    output("</td></tr>",true);
                    output("</table>",true);
                    output("</form>",true);
                break;
            }
        break;

        case "add":
            // Add a role
            $stage=$HTTP_GET_VARS['stage'];
            switch ($stage) {
             case "save":
                $info['Name']=$HTTP_POST_VARS['Name'];
                $info['Description']=$HTTP_POST_VARS['Description'];
                $id=addrole($info);
                redirect("su_admin.php?op=roles");  // Return to the main roles page
             break;

             default:
                // Display the empty form
                $return=CalcReturnPath(true);
                output("<form action='".$return."&stage=save' method='POST'>",true);
                addnav("",$return."&stage=save");
                showform($RoleAddTemplate,$BlankRoleTemplate);
                output("</form>",true);

             break;
            }
        break;

        default:
            // Entry into the Roles lists
            $allRoles=ReturnRoles();    // Grab a copy of them all
            // Main display code
            output("`n`n<table border=0 cellpadding=2 cellspacing=1 bgcolor='#999999' align='center'>",true);
            output("<tr class='trhead'><td>`c`bID`b`c</td><td>`c`bName`b`c</td><td>`c`bDescription`b`c</td><td>`c`bRights`b`c</td><td>`c`bWho`b`c</td></tr>",true);
            if (is_array($allRoles) and count($allRoles)>0) { // Handle if nothing has been setup yet
                while (list($key,$val)=each($allRoles)) {
                    output("<tr class=trlight>",true);
                    output("<td>&nbsp;&nbsp;".$val['ID']."&nbsp;&nbsp;</td>",true);
                    output("<td><a href='su_admin.php?op=roles&action=manage&id=".$val['ID']."'>",true);
                    output("&nbsp;&nbsp;".$val['Name']."&nbsp;&nbsp;</a></td>",true);
                    addnav("","su_admin.php?op=roles&action=manage&id=".$val['ID']."");
                    output("<td>&nbsp;&nbsp;".$val['Description']."&nbsp;&nbsp;</td>",true);

                    if (count($val['.RightsPretty'])!=0) {  // If we have some modules already defined, display a pretty list of them
                        output("<td><table border=0 cellpadding=2 cellspacing=0 bgcolor='#999999' align='center'>",true);
                        while (list($key,$value) = each($val['.RightsPretty'])) {
                            output("<tr class='trlight'><td>".$value['ModuleName']."</td><tr>",true);
                        }
                        output("</table></td>",true);
                    } else {
                     output("<td>None</td>",true);  // Otherwise we have none defined
                    }

                    if (count($val['.AdminsInRole'])!=0) {  // If we have some Admins already defined, display them
                        output("<td><table border=0 cellpadding=2 cellspacing=0 bgcolor='#999999' align='center'>",true);
                        while (list($key,$value) = each($val['.AdminsInRole'])) {
                            output("<tr class='trlight'><td>".str_replace(" ","&nbsp;",$value['name'])."</td><tr>",true);
                        }
                        output("</table></td>",true);
                    } else {
                     output("<td>None</td>",true);  // Otherwise we have none
                    }
                    output("</tr>",true);
                }
            }
            output("<tr class=trlight colspan='5'><td colspan='5' width='100%' align='center'><a href='su_admin.php?op=roles&action=add'> Add Role</a></td></tr>",true);
            addnav("","su_admin.php?op=roles&action=add");
            output("</table>",true);
        break;
    }
}


?>