<?php
// ----------------------------------------------------------------------------
//
// su_admin.php
// CR#Dasher#005
// 30th April 2004
// Version: 0.9.9
// The latest version is always runnning at: www.sembrance.uni.cc/rpg
// (c) 2003 Dasher [david.ashwood@inspiredthinking.co.uk]
// This module is relased under the LOTGD GNU public license
// You may change/modify this module and it's associated modules as you wish but
// this copyright MUST be retained.
//
// I would apprechiate feedback/updates on how it works and changes you make.
// Dasher
//
// ----------------------------------------------------------------------------
// For information on it's use, installation and change log see
// adv_admin_funcs.php
// ----------------------------------------------------------------------------

require_once "common.php";

page_header("Superuser Management");
output("`c`& ~ Superuser Management ~ `c",true);

if (SU_Admin_Allowed()) {

    addnav("Display All Admins","su_admin.php?op=displayadmins");
    addnav("Display Pages","su_admin.php");
    addnav("Manage Roles","su_admin.php?op=roles");

    $op=$HTTP_GET_VARS['op'];

    switch ($op) {
        case "roles":
            Roles();
        break;

        case "displayadmins":
            $allAdmins=ReturnAdmins();
            output("`n`n<table border=0 cellpadding=2 cellspacing=1 bgcolor='#999999' align='center'>",true);
            output("<tr class='trhead'><td>`c`bWho`b`c</td><td>`c`b&nbsp;Flags&nbsp;`b`c</td></tr>",true);
            while (list($key,$val)=each($allAdmins)) {
                output("<tr class=trlight>",true);
                output("<td>&nbsp;&nbsp;".$val['name']."&nbsp;&nbsp;</td>`n",true);
                output("<td>&nbsp;&nbsp;".$val['superuser']."&nbsp;&nbsp;</td>`n",true);
                output("</tr>",true);
            }
            output("</table>",true);
        break;

        case "assign":
            $return=CalcReturnPath(true);
            $id=$HTTP_GET_VARS['id'];
            switch ($HTTP_GET_VARS['stage']) {
                case "assign":
                    $ModuleID=$_POST['moduleID'];
                    $comments=$_POST['comments'];
                    $who=$_POST['who'];
                    arsort($who);
                    while (list($key, $val)=each($who)) {
                        if ($val=="no") {
                            $deny[$key]=$key;
                        } else {
                            $allow[$key]=$key;
                        }
                    }
                    SUMaskModules_SetConfigured($ModuleID,"",$comments);
                    if (count($allow)>0) SUMaskModules_AssignAdmins($ModuleID,array_keys($allow));
                    if (count($deny)>0) SUMaskModules_UnassignAdmins($ModuleID,array_keys($deny));
                    redirect("su_admin.php");
                break;

                default:
                    $admins=ReturnSUMaskModules_with_Admins($id);
                    $allAdmins=ReturnAdmins();
                    $comments=unserialize(stripslashes($HTTP_GET_VARS['comments']));
                    $ModuleName=unserialize(stripslashes($HTTP_GET_VARS['modulename']));
                    output("<form action='".$return."&stage=assign' method='POST'>",true);
                    output("<table border=0 cellpadding=2 cellspacing=1 bgcolor='#999999' align='center' valign='top'>",true);
                    output("<tr class='trhead'><td>&nbsp;`bWhat`b&nbsp;</td><td>`bWho`b</td>",true);
                    output("<input type='hidden' name='moduleID' value='".$id."'/>",true);
                    output("<input type='hidden' name='moduleName' value='".$ModuleName."'/>",true);
                    while (list($key,$val)=each($allAdmins)) {
                        output("<tr class=trlight><td>",true);
                        if (array_key_exists($key,$admins)) {
                            output("<input ID='a' type=radio name='who[".$key."]' value='yes' checked>&nbsp;&nbsp;Allow&nbsp;&nbsp;<br>",true);
                            output("<input ID='a' type=radio name='who[".$key."]' value='no'>&nbsp;&nbsp;Deny&nbsp;&nbsp;<br></td>",true);
                            output("<td>".$val['name']."</td>`n",true);
                        } else {
                            output("<input ID='b' type=radio name='who[".$key."]' value='yes' >&nbsp;&nbsp;Allow&nbsp;&nbsp;<br>",true);
                            output("<input ID='b' type=radio name='who[".$key."]' value='no' checked >&nbsp;&nbsp;Deny&nbsp;&nbsp;<br></td>",true);
                            output("<td>".$val['name']."</td>`n",true);
                        }
                        output("</tr>",true);
                    }
                    output("</table>`n`n",true);
                    output("<table border=0 cellpadding=2 cellspacing=1 bgcolor='#999999' align='center'>",true);
                    output("<tr class=trlight><td>Page Name: </td><td>".htmlentities($ModuleName,ENT_QUOTES)."</td></tr>",true);
                    output("<tr class=trlight><td>Comments:  </td><td><input type='text' name='comments' size='50' value= '".htmlentities(stripslashes($comments),ENT_QUOTES)."'/></td></tr>",true);
                    output("<tr class=trlight align='center' colspan='2'><td colspan='2' width='100%'><input type='submit' class='button' value='Save'/></td></tr>",true);
                    output("</table>",true);
                    output("</form>",true);
                    addnav("",$return."&stage=assign");
                break;
            }

        break;

        default:
            $results=ReturnSUMaskModules();

            output("`n`n<table border=0 cellpadding=2 cellspacing=1 bgcolor='#999999' align='center'>",true);
            output("<tr class='trhead'><td>`b`c&nbsp;Action&nbsp;`c`b</td><td>&nbsp;`bModule`b&nbsp;</td><td>&nbsp;`bComment`b&nbsp;</td></tr>",true);

            $count=count($results);
            $id="";

            reset($results);
            while (list($key,$val)=each($results)) {
                output("<tr class=trlight>",true);
                $url="su_admin.php?op=assign&id=".$val['ID'];
                $url.="&comments=".rawurlencode(serialize($val['Comments']));
                $url.="&modulename=".rawurlencode(serialize($val['ModuleName']));
                output("<td><a href='".$url."'>&nbsp;&nbsp;Manage Page&nbsp;&nbsp;</a></td>",true);
                output("<td>&nbsp;&nbsp;".$val['ModuleName']."&nbsp;&nbsp;</td><td>&nbsp;&nbsp;".$val['Comments']."&nbsp;&nbsp;</td></tr>",true);
                addnav("",$url);
            }
            output("</table>",true);
        break;

    }
} else {
    output("You are not authorised to Admin this page!");
}

addnav("~");
addnav("Return","village.php");
page_footer();
?>