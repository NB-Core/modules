<?php
/*
Details:
 * This is a demonstration module
History Log:
 * Version 1.0:
   o Seems stable
*/
require_once('lib/e_rand.php');

function text_talk_demo_getmoduleinfo() {
	$info = array(
		"name"=>"Text Talk - Test",
		"version"=>"1.0",
		"vertxtloc"=>"http://dragonprime.net/users/CortalUX/",
		"author"=>"`@CortalUX",
		"category"=>"General",
		"download"=>"http://dragonprime.net/users/CortalUX/text_talk.zip",
		"requires"=>array(
			"text_talk" => "1.1|`@CortalUX, http://dragonprime.net/users/CortalUX/text_talk.zip",
		),
	);
	return $info;
}

function text_talk_demo_install(){
	module_addhook("texttalk-cline");
	module_addhook("texttalk-str");
	module_addhook("texttalk-preg");
	module_addhook("texttalk-prefs");
	return true;
}

function text_talk_demo_uninstall(){
	return true;
}

function text_talk_demo_dohook($hookname,$args){
	switch($hookname){
		case "texttalk-cline":
			$args['Demo']='testspeaks';
		break;
		case "texttalk-str":
			$args['Demo']=array();
			$args['Demo']['Test']='Test';
		break;
		case "texttalk-preg":
			$args['Demo']=array();
			$args['Demo']['Testing']='Testing';
		break;
		case "texttalk-prefs":
			$args['Demo']='Like a Test Character';
		break;
	}
	return $args;
}

function text_talk_demo_run(){
}
?>