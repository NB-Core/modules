<?php
/*
Details:
 * This contains a module that allows users to change the way they talk
History Log:
 * Version 1.0:
   o Seems stable
 * Version 1.1:
   o Bug fixed
 * Version 1.2:
   o Troll talking added
*/

function text_talk_getmoduleinfo() {
	$info = array(
		"name"=>"Text Transformation",
		"version"=>"1.2",
		"vertxtloc"=>"http://dragonprime.net/users/CortalUX/",
		"author"=>"`@CortalUX",
		"category"=>"General",
		"download"=>"http://dragonprime.net/users/CortalUX/text_talk.zip",
		"prefs"=>array(
			"Text Transformation,title",
			"user_type"=>"How do you want your commentary to appear?,enum,0,Don't change it!,1,Elflike,2,Trollike|0",
		),
	);
	//$x = modulehook('texttalk-prefs');
	$i = 2;
	if (count($x)>0) {
		$info['prefs']['user_type']=str_replace('|0','',$info['prefs']['user_type']);
		foreach ($x as $module => $stuff) {
			$i++;
			$info['prefs']['user_type'].=",".$i.",".$stuff;
		}
		$info['prefs']['user_type'].="|0";
	}
	return $info;
}

function text_talk_install(){
	module_addhook("commentary");
	return true;
}

function text_talk_uninstall(){
	return true;
}

function text_talk_dohook($hookname,$args){
	switch($hookname){
		case "commentary":
			if (get_module_pref('user_type')==0) {
				break;
			}
			$args['commentline'] = text_talk_change($args['commentline']);
			$args['commenttalk'] = text_talk_change($args['commenttalk'],true);
		break;
	}
	return $args;
}

function text_talk_run(){
}

function text_talk_change($text="",$i=false) {
	$num = get_module_pref('user_type');
	if (!$i) {
		$x = text_talk_array($num,true);
		foreach ($x as $orig => $with) {
			$text = str_replace($orig,$with,$text);
		}
		$y = text_talk_array($num,false);
		foreach ($y as $orig => $with) {
			$text = preg_replace($orig,$with,$text);
		}
	} else {
		$text = text_talk_array($num,false,true)." $text";
	}
	return $text;
}

function text_talk_array($num=1,$type=true,$commentline=false) {
	$z=array();
	if ($commentline===true) {
		$z['1']='elvishly';
		$z['2']='trollishly';
		$x = modulehook('texttalk-cline',array());
		$i = 2;
		if (count($x)>0) {
			foreach ($x as $module => $stuff) {
				$i++;
				$z[$i]=$stuff;
			}
		}
		return $z[$num];
	}
	if ($type) {
		// This is for str_replaces
		$z['1']['said ']='spaketh ';
		$z['1']['is this ']='doeth this ';
		$z['1']['fine']='great';
		$z['1']['true ']='pure ';
		$z['1']['you']='thee';
		$z['1']['You']='Thee';
		$z['1']['the ']='ye ';
		$z['1']['I ']='I who am speaking ';
		$z['1']['I\'m ']='I who am speaking ';
		$z['1']['The ']='Ye ';
		$z['1']['your']='thy';
		$z['1']['Your']='Thy';
		$z['1']['true ']='pure ';
		$z['1']['It\'s']='Tis\'';
		$z['1']['it\'s']='tis\'';
		$z['1'][' and ']=' and yet ';
		$z['1'][' says ']=' spake ';
		$z['1'][' god ']=' Holy One ';
		$z['1'][' God ']=' Holy One ';
		$z['1'][' an Orc ']=' a Orc '; // Will be fixed by a preg_replace
		$z['1']['of the human']='human';
		$z['1']['human ']='of the Second Race ';
		$z['1']['hello']='Greetings';
		$z['1']['Hello']='Greetings';
		$z['1']['hi']='Greetings ';
		$z['1']['Hi']='Greetings ';
		$z['1']['hey']='Greetings ';
		$z['1']['Hey']='Greetings ';
		$z['2']['you'] = '\'oo';
		$z['2']['You'] = '\'oo';
		$z['2']['the '] = 't\' ';
		$z['2']['The '] = 't\' ';
		$z['2']['your'] = 'oor';
		$z['2']['Your'] = 'oor';
		$z['2']['It\'s'] = 'Ih a';
		$z['2']['it\'s'] = 'ih a';
		if (e_rand(0,4) == 1) $z['2']['[^`]!'] = ', unh!';
		$z['2']['for'] = 'f\'r';
		$z['2']['my '] = 'meh ';
		$z['2'][' of '] = ' uh ';
		$z['2'][' one '] = ' eeny ';
		$z['2'][' two '] = ' eeny eeny ';
		$z['2'][' three '] = ' eeny eeny eeny ';
		$z['2'][' four '] = ' miney ';
		$z['2'][' five '] = ' miney eeny ';
		$z['2'][' six '] = ' miney eeny eeny ';
		$z['2'][' seven '] = ' miney eeny eeny ';
		$z['2'][' eight '] = ' miney miney ';
		$z['2'][' nine '] = ' miney miney eeny ';
		$z['2'][' ten '] = ' miney miney miney ';
		$z['2'][' is '] = ' ah ';
		$z['2'][' and '] = ' ahn ';
		$z['2'][' am '] = ' b\' ';
		$z['2'][' says '] = ' sa\'s ';
		$z['2'][' to '] = ' t\' ';
		if (e_rand(0,4) == 1)
			$z['2']['. '] = ',ug. ';
		if (e_rand(0,4) == 1)
			$z['2'][', '] = ', ig, ';
		if (e_rand(0,4) == 1)
			$z['2']['. '] = '. Ag, ';
		$z['2']['hello '] = 'eyo ';
		$z['2']['speaks'] = 'sez';
		$z['2']['admin'] = 'fodder';
		$z['2']['Forest'] = 'Grash';
		$z['2']['Hello '] = 'eyo ';
		$z['2']['moon ah'] = 'moon i\'';
		$z['2']['new day'] = 'Nu dah';
		$x = modulehook('texttalk-str',array());
		$i = 2;
		if (count($x)>0) {
			foreach ($x as $module => $stuff) {
				$i++;
				$z[$i]=$stuff;
			}
		}
	} else {
		// This is for preg_replaces
		$z['1']['(elfs|Elfs) ']='Elves ';
		$z['1']['(elflike|Elflike) ']='Elvish ';
		$z['1']['(orc|goblin|troll) ']='fell one ';
		$z['2']['\'(lot|lots|lotsa) \''] = 'lorra ';
		$z['2']['\'[^[:alpha:]]you[^[:alpha:]]\'i'] = ' oo\' ';
		$z['2']['\'([^ .,!?]+)ing \''] = '\\1\'ng ';
		$z['2']['/ [s]{0,1}he /i'] = ' e\' ';
		$z['2']['\'(gems|Gems) \''] = 'Shi\'nies ';	
		$z['2']['\'( |`.)(money|gold)( |`.)\''] = '\\1spahkewes\\3';
		$z['2']['\'(Money|Gold) \''] = 'Spahkewes ';
		$x = modulehook('texttalk-preg',array());
		$i = 2;
		if (count($x)>0) {
			foreach ($x as $module => $stuff) {
				$i++;
				$z[$i]=$stuff;
			}
		}
	}
	if (!isset($z[$num])) {
		$z[$num]=array();
	}
	return $z[$num];
}
?>