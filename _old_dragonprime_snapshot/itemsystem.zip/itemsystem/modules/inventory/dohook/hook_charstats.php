<?
//	if (get_module_setting("withcharstats")==true) {
//		define("OVERRIDE_FORCED_NAV", true);
//		$open = translate_inline("Open Inventory");
//		addnav("runmodule.php?module=inventory&op=charstat");
//		addcharstat("Equipment Info");
//		addcharstat("Inventory", "<a href='runmodule.php?module=inventory&op=charstat' target='inventory' onClick=\"".popup("runmodule.php?module=inventory&op=charstat").";return false;\">$open</a>");
//	}
?>