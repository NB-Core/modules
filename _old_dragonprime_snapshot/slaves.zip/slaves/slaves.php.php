<?
require_once "common.php";
checkday();

/*
Slaves Shop
Version 1.0 (03/05/05)
by Andreas Miedler
*/
/*
////// But this in to your SQL////////////////////////////////////////
  ALTER TABLE `accounts` ADD `slaves` INT UNSIGNED DEFAULT '0' NOT NULL ;
  ALTER TABLE `accounts` ADD `land` INT UNSIGNED DEFAULT '0' NOT NULL ;
  ALTER TABLE `accounts` ADD `farms` INT UNSIGNED DEFAULT '0' NOT NULL ;
  ALTER TABLE `accounts` ADD `manager` INT UNSIGNED DEFAULT '0' NOT NULL ;
//////////////////////////////////////////////////////////////////////

/// In `newday.php` add//////

---Find:---

output("`2Interest Accrued on Debt: `^".-(int)($session['user']['goldinbank']*($interestrate-1))."`2 gold.`n");
			}
		}
		
---under it put:---

if ($session[user][slaves]>=1)
	{
		 $rand = e_rand(1,4);
		 switch ($rand){
	    
			 
	  case 1:
		$slavemoney = $session['user']['slaves']*16;
		$session[user][goldinbank]+=$slavemoney;
		output("`2Your Slaves worked 75%: `^".$slavemoney."`n");
		break;
		
		case 2:
		$slavemoney = $session['user']['slaves']*18;
		$session[user][goldinbank]+=$slavemoney;
		output("`2Your Slaves worked 80%: `^".$slavemoney."`n");
		break;
		
		case 3:
		$slavemoney = $session['user']['slaves']*19;
		$session[user][goldinbank]+=$slavemoney;
		output("`2Your Slaves worked 95%: `^".$slavemoney."`n");
		break;
		
		case 4:
		$slavemoney = $session['user']['slaves']*22;
		$session[user][goldinbank]+=$slavemoney;
		$session[user][slaves]-=10;
		$session[user][gems]+=1;
		output("`2Your Slaves worked 100%: `^".$slavemoney."`n");
		output("`$ 10 of your slaves bought there freedome for 1 Gem !!!`n");
		break;
		
}	
	}
	/////////////////////////////////////////////////////////////////////////////////////////
	---Note---
	
	Put a link in to the village for Farm Managment and change the return links. I use a castle on my server so all my return
	links named "castle.php" need to be replaced!
	
	*/

page_header("Farming Managment");
if ($HTTP_GET_VARS[op]=="")
{

if ($session[user][manager]<=0){
output("`# You should hire a Manger for your farming needs `n");
addnav("Hire Manager","slaves.php?op=managerbuy");
addnav("Returne to the Castle","houses.php?op=inside");


}else{	
output("`^ `c Your  Farm Manager Apophis reports. `c `n `n");
if ($session[user][land]<=0)
{
	output("`$ You should buy some Land so you can build a Farm.`n");
}else{
output("`3 As of now you own `^ ".$session[user][land]." `3 acre of land .`n ");
}
if ($session[user][farms]<=0)
{
	output("`$ You should buy a Farm so you can get some Slaves.`n");
}else{
output("`3 There are `^ ".$session[user][farms]." `3 farms on your land .`n ");
}
if ($session[user][slaves]<=0)
{
	output("`$ You should buy some Slaves so you can make some Gold.`n `n `n `n `n");
}else{
output("`3 And you got `^ ".$session[user][slaves]." `3 slaves working .`n  ");
 
}

$farmneed1 = $session[user][land] / 100;
$farmneed2 = $farmneed1 - $session[user][farms]; 
$farmneed2 = abs((int)$farmneed2);



output("`3 At this moment you can build `^ ".$farmneed2." `3 Farms `n ");

$slaveneed1 = $session[user][farms] * 100;
$slaveneed2 = $slaveneed1 - $session[user][slaves]; 
output("`3 It looks like you need `^ ".$slaveneed2." `3 slaves on your `^ ".$session[user][farms]." `3 farms .");
 addnav("Buy Land","slaves.php?op=buyland");
  addnav("Buy Farm","slaves.php?op=buyfarm");
   addnav("Buy Slaves","slaves.php?op=buyslaves");
    addnav("Returne to the Castle","houses.php?op=inside");

}
}
if ($HTTP_GET_VARS[op]=="managerbuy")
{
	 
output(" `& A Egyptian looking man in silver shining cloths walks up to you. You notice his eyes are glowing mysteriously and ");
 output(" `& his voice is deep and echoed. `n ");
  output(" `3 Hi my name is Apophis and I offer you my services as a Farm manager. I will help you run your farms to its ");
   output(" `3 fullest capacity. If you are interested in my services let me know. If you pay me a one time fee of 100.000 gold ");
   output(" `3 I will enter your services immediately!");
    addnav("Pay him","slaves.php?op=managerget");
     addnav("Talk to Apophis","slaves.php");
}
else if ($HTTP_GET_VARS[op]=="managerget")
{
if ($session[user][gold] <= 99999)
{
 output(" `3 Sorry you should get some gold first and than return again! ");
  addnav("Returne to the Castle","houses.php?op=inside");
}else{
  addnav("Returne to the Castle","houses.php?op=inside");
   output(" `3 Apophis bows in front of you, you feel a unusual power in you and the words 'Jaffa Cree!' pop in your head. Hmmm? Strange!"); 
 
 $session[user][manager]+=1;
 $session[user][gold]-=100000;
}
} 
 //////////////// buy land///////////////
 else if ($HTTP_GET_VARS[op]=="buyland")
{
$landprice = $session['user']['land']*1.1+100;
$landalowed = $session['user']['gold']/$landprice;
output(" `$ `c `b  Neighbors `c `b  `n`n");
output(" `3 You are talking to your neighbors about getting some land from them. `&' I will sell as much as you need to you ,my friend"); 
 output(" `& but remember that my prices will go up in time!'");
  output(" `& The price for 1 acre of land is `^".$landprice." `^ gold.");
   output("`3 As of now you own `^ ".$session[user][land]." `3 acre of land .`n ");
    output("`3 With the money you have on you, you can buy `^ ".(int)($landalowed)." `3 acre of land .`n ");
     output("<form action='slaves.php?op=land10' method='POST'>",true);
	  output("`2How much land do you want to buy: <input name='amount' id='amount' width='5'>`n`n",true);
	   output("<input type='submit' class='button' value='Finalize Contract'></form>",true);
		addnav("","slaves.php?op=land10");
		 addnav("Returne to Apophis","slaves.php");
}
 else if ($HTTP_GET_VARS[op]=="land10")
{
       
	
	
	      $amt = abs((int)$_POST['amount']);
	      
    $landprice = abs((int)$session['user']['land']*1.1+100);	 
    
   $landalowed = $session['user']['gold']/$landprice;
   
   $landalowed = abs((int)$landalowed);
   
     $endprice = $landprice * $amt;
   
   
   	 
if ($landalowed < $amt)
{
output(" `@You don't have enough gold on you for this transaction. You can only buy `^".$landalowed." `@acre of land. And not `^ ".$amt." `@acre.");
 addnav("Returne to Apophis","slaves.php");
 
 
 
}
else
{

	
	$session[user][gold] -= $endprice;
	$session[user][land] += $amt;	
output("`& You buy `^ ".$amt." `& acre of land and are now the owner of `^ ".$session[user][land]." `& acres of land.");	
  addnav("Returne Apophis","slaves.php");
  
} 

} 

////////////////buy farm/////////////
 else if ($HTTP_GET_VARS[op]=="buyfarm")
{
  $farmprice = $session['user']['farms']+5;
      $fact1 = $session['user']['land']/100;
$farmsalowed = $fact1 - $session['user']['farms'];
$farmsalowed = abs((int)$farmsalowed);
      $fact2 = $session['user']['farms']*100;
 $unusedland = $session['user']['land'] - $fact2;
 $totalprice = $farmsalowed * $farmprice;


 output(" `$ `c `b  Architects `c `b  `n`n");
  output(" `@ You are talking to the Architects about building some Farms: `n `n `n"); 
   output(" `&As your architect I have to inform you that you will need `^100 `& acres of land for each farm.`n At this moment you have ");
     output("`^".$unusedland." `& acres unused land available. Which means you can build `^ ".$farmsalowed." `& Farms. `n");
       output("`^ 1 `& Farm will cost`^ ".$farmprice." `& gems at the moment.`n `n ");
       
  output("<form action='slaves.php?op=farm10' method='POST'>",true);
   output("`2How many Farms do you want to build: <input name='amount' id='amount' width='5'>`n`n",true);
    output("<input type='submit' class='button' value='Finalize Contract'></form>",true);
	 addnav("","slaves.php?op=farm10");
	  addnav("Returne to Apophis","slaves.php");
}
 else if ($HTTP_GET_VARS[op]=="farm10")
{
       
	
	
	      $amt = abs((int)$_POST['amount']);
	      
   $farmprice = $session['user']['farms']+5;
       $fact1 = $session['user']['land']/100;
 $farmsalowed = $fact1 - $session['user']['farms'];
 $farmsalowed = abs((int)$farmsalowed);
       $fact2 = $session['user']['farms']*100;
  $unusedland = $session['user']['land'] - $fact2;
  $totalprice = $amt * $farmprice;
        $case = 0; 
        
        
if ($farmsalowed >= $amt)
{ 
	$case+=1;
	}else{
		$case+=3;
}	
if ($totalprice <= $session[user][gems])
{
	$case+=1;
	}else{
	    $case+=3;
}
if ($case==2)
{
	$session[user][gems] -= $totalprice;
	$session[user][farms] += $amt;	
output("`& You buy `^ ".$amt." `& farms and are now the owner of `^ ".$session[user][farms]." `& farms.");	
  addnav("Returne Apophis","slaves.php");

} 	 
else
{
	
output(" `& The architect is quit angry with you:`n`n`n");
 output(" `$ What the hell!!! Don't you understand English? Did you skip math class or what. I explained every thing exactly ");
  output(" to the point. If you don't have enough land or gems to get a farm than don't bother me!!! `n `n");
   output(" `& The troll throws his blueprints in to the mud and storms off.");
    addnav("Returne to Apophis","slaves.php");
 
 
 
}

} 

///////////////////////Slaves//////////////////////
else if ($HTTP_GET_VARS[op]=="buyslaves")
{
  $slaveprice = 1000;
       $fact1 = $session['user']['farms']*100;
$slavesalowed = $fact1 - $session['user']['slaves'];
$slavesalowed = abs((int)$slavesalowed);
 



  output(" `$ `c `b  Slave Market `c `b  `n`n");
   output(" `@ You enter the slave market.");
    output(" `@ A big crowed is hustling around the market. Slaves are being sold to any one who can afford them.");
     output(" `@ Apophis your Farm manager tells you that you could use `^ ".$slavesalowed." `@ slaves. `n");
      output(" `@ The going rate for Slaves is `^1000 gold.");
     
       
  output("<form action='slaves.php?op=slaves10' method='POST'>",true);
   output("`2How many Slaves do you want to buy: <input name='amount' id='amount' width='5'>`n`n",true);
    output("<input type='submit' class='button' value='Finalize Contract'></form>",true);
	 addnav("","slaves.php?op=slaves10");
	  addnav("Returne to Apophis","slaves.php");
}
 else if ($HTTP_GET_VARS[op]=="slaves10")
{
       
	
	
	      $amt = abs((int)$_POST['amount']);
	      
   $slaveprice = 1000;
        $fact1 = $session['user']['farms']*100;
 $slavesalowed = $fact1 - $session['user']['slaves'];
 $slavesalowed = abs((int)$slavesalowed);
   $totalprice = $amt * $slaveprice;

        
        
if ($slavesalowed >= $amt)
{ 
	$case+=1;
	}else{
		$case+=3;
}	
if ($totalprice <= $session[user][gold])
{
	$case+=1;
	}else{
	    $case+=3;
}
if ($case==2)
{

	$session[user][gold] -= $totalprice;
	$session[user][slaves] += $amt;	
output("`& You buy `^ ".$amt." `& Slaves and are now the owner of `^ ".$session[user][slaves]." `& slaves.");	
  addnav("Returne Apophis","slaves.php");

} 	 
else
{

output(" `& Apophis is confused:`n");
 output(" `$ If we don't have the gold or space necessary we should not try to buy slaves.");
  addnav("Returne to Apophis","slaves.php");
 
}
} 

	 
page_footer();

?>