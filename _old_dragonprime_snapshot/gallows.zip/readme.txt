****************************************************************
Name: Village Gallows
Author: Eth - ethstavern(at)gmail(dot)com 
Version: 2.0
Release Date: 12-25-2005
About: Readme file for gallows.zip
Files: gallows.php
***************************************************************

To install, drop into your modules directory and activate 
via the Modules Manager. 
