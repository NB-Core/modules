<?
/*
Eric's Lotto v. 1.0
Based upon the original LORD IGM Seth's Lotto By Joseph Masters
Author: bwatford
Board: http://www.ftpdreams.com/lotgd
Date: 03-2004
Drop this in your main folder.
Install the sql tables included with this zip
Find:
		$session['user']['drunkenness']=0;

After That Add:
		$session[user][lotto]= 0;
		$session[user][lottochoice]=0;
		$session[user][matches]=0;
	
*/

require_once "common.php";
checkday(); 

if ($HTTP_GET_VARS[op]==""){
page_header("Eric's Lotto");
if($session[user][lotto]>0){
addnav("Navigation");
addnav("Back To Village","village.php");
output("`b`n`n`c`bEric's Lotto`b`c`n`n");
output("`@`cThere appears to be an invisible shield, keeping you from advancing on the hill! `n`^'Try again tomorrow!'`^`@`c`n`n");
	}else{
addnav("Try It Out?");
addnav("Yes","eslotto.php?op=yes");
addnav("No","eslotto.php?op=no");
output("`b`n`n`c`bEric's Lotto`b`c`n`n");
output("`@`cFollowing a path instinctively, you come to a large hill. It appears insurmountable, but you feel a warmth");
output(" come over you, And a pulling force brings you to the top of the hill.`n`n");
output("At the top is an oddly-shaped box with buttons next to the numbers 1 through 9. A plaque sits below it.`n`n");
output("`^This Lottery is placed in Honor of Eric Stevens for creating this great game.`n`n");
output("Dedicated by Billy Watford, 3-27-2004`^`@`c`n`n");
output("`@`cThis appears to be some kind of Lottery Machine...`@`c`n`n");

}
}

if ($HTTP_GET_VARS[op]=="no"){
page_header("Eric's Lotto");
addnav("Navigation");
addnav("Back To Village","village.php");
output("`b`n`n`c`bEric's Lotto`b`c`n`n");
output("`@`cYou trudge home, unaware of what you've missed.`@`c`n`n");

}

if ($HTTP_GET_VARS[op]=="yes"){
page_header("Eric's Lotto");
if($session[user][gold]<250){
addnav("Navigation");
addnav("Forget It","eslotto.php?op=no");
output("`b`n`n`c`bEric's Lotto`b`c`n`n");
output("`@`cHowever, you don''t seem to have the kind of money you need to use the machine!`@`c`n`n");
output("`c`^`bIt cost 250 Gold To Use The Machine`c`b`^");
	}else{
addnav("Choose Your Numbers");
addnav("Let me choose","eslotto.php?op=choose");
output("`b`n`n`c`bEric's Lotto`b`c`n`n");
output("`@`cYou deposit 250 gold into the box, and read the directions.`n`n");
output("Press four numbers to come up with your code.  Then, wait for the machine to come up with its.");
output(" If you match one or more numbers, you will win some gold back!`@`c");
$session[user][gold]-=250;

}
}

if ($HTTP_GET_VARS[op]=="choose"){
page_header("Eric's Lotto");
output("`b`n`n`c`bEric's Lotto`b`c`n`n");
if($session[user][lottochoice]==0){
addnav("Choose Your First Number");
addnav("0","eslotto.php?op=choose0");
addnav("1","eslotto.php?op=choose1");
addnav("2","eslotto.php?op=choose2");
addnav("3","eslotto.php?op=choose3");
addnav("4","eslotto.php?op=choose4");
addnav("5","eslotto.php?op=choose5");
addnav("6","eslotto.php?op=choose6");
addnav("7","eslotto.php?op=choose7");
addnav("8","eslotto.php?op=choose8");
addnav("9","eslotto.php?op=choose9");
output("`@`cOk Now It's Time To Choose Your First Number!`@`c`n`n");
output("`^`bYOUR NUMBERS`^`n`n`b");
output("`@First Number: Unknown`n");
output("Second Number: Unknown`n");
output("Third Number: Unknown`n");
output("Fourth Number: Unknown`@`n`n");
	}else{
if($session[user][lottochoice]==1){
addnav("Choose Your Second Number");
addnav("0","eslotto.php?op=choose0");
addnav("1","eslotto.php?op=choose1");
addnav("2","eslotto.php?op=choose2");
addnav("3","eslotto.php?op=choose3");
addnav("4","eslotto.php?op=choose4");
addnav("5","eslotto.php?op=choose5");
addnav("6","eslotto.php?op=choose6");
addnav("7","eslotto.php?op=choose7");
addnav("8","eslotto.php?op=choose8");
addnav("9","eslotto.php?op=choose9");
output("`@`cOk Now It's Time To Choose Your Second Number!`@`c`n`n");
output("`^`bYOUR NUMBERS`^`n`n`b");
output("`@First Number: " . ($session['user']['lotto1']) . "`n");
output("Second Number: Unknown`n");
output("Third Number: Unknown`n");
output("Fourth Number: Unknown`@`n`n");
	}else{
if($session[user][lottochoice]==2){
addnav("Choose Your Third Number");
addnav("0","eslotto.php?op=choose0");
addnav("1","eslotto.php?op=choose1");
addnav("2","eslotto.php?op=choose2");
addnav("3","eslotto.php?op=choose3");
addnav("4","eslotto.php?op=choose4");
addnav("5","eslotto.php?op=choose5");
addnav("6","eslotto.php?op=choose6");
addnav("7","eslotto.php?op=choose7");
addnav("8","eslotto.php?op=choose8");
addnav("9","eslotto.php?op=choose9");
output("`@`cOk Now It's Time To Choose Your Third Number!`@`c`n`n");
output("`^`bYOUR NUMBERS`^`n`n`b");
output("`@First Number: " . ($session['user']['lotto1']) . "`n");
output("Second Number: " . ($session['user']['lotto2']) . " `n");
output("Third Number: Unknown`n");
output("Fourth Number: Unknown`@`n`n");
	}else{
if($session[user][lottochoice]==3){
addnav("Choose Your Final Number");
addnav("0","eslotto.php?op=choose0");
addnav("1","eslotto.php?op=choose1");
addnav("2","eslotto.php?op=choose2");
addnav("3","eslotto.php?op=choose3");
addnav("4","eslotto.php?op=choose4");
addnav("5","eslotto.php?op=choose5");
addnav("6","eslotto.php?op=choose6");
addnav("7","eslotto.php?op=choose7");
addnav("8","eslotto.php?op=choose8");
addnav("9","eslotto.php?op=choose9");
output("`@`cOk Now It's Time To Choose Your Final Number!`@`c`n`n");
output("`^`bYOUR NUMBERS`^`n`n`b");
output("`@First Number: " . ($session['user']['lotto1']) . "`n");
output("Second Number: " . ($session['user']['lotto2']) . " `n");
output("Third Number: " . ($session['user']['lotto3']) . " `n");
output("Fourth Number: Unknown`@`n`n");
	}else{
if($session[user][lottochoice]==4){
addnav("Navigation");
addnav("Match My Numbers","eslotto.php?op=match");
output("`@`cOk Now It's Time To See If You Won!`@`c`n`n");
output("`^`bYOUR NUMBERS`^`n`n`b");
output("`@First Number: " . ($session['user']['lotto1']) . "`n");
output("Second Number: " . ($session['user']['lotto2']) . " `n");
output("Third Number: " . ($session['user']['lotto3']) . " `n");
output("Fourth Number: " . ($session['user']['lotto4']) . " `@`n`n");

}
}
}
}
}
}

if ($HTTP_GET_VARS[op]=="choose0"){
page_header("Eric's Lotto");
addnav("Continue","eslotto.php?op=choose");
output("`b`n`n`c`bEric's Lotto`b`c`n`n");
if($session[user][lottochoice]==0){
output("`b`c`@YOU HAVE CHOSEN THE NUMBER `^0`@ FOR YOUR FIRST NUMBER!`b`c`@`^");
$session[user][lottochoice]+=1;
$session[user][lotto1]=0;
	}else{
if($session[user][lottochoice]==1){
output("`b`c`@YOU HAVE CHOSEN THE NUMBER `^0`@ FOR YOUR SECOND NUMBER!`b`c`@`^");
$session[user][lottochoice]+=1;
$session[user][lotto2]=0;
	}else{
if($session[user][lottochoice]==2){
output("`b`c`@YOU HAVE CHOSEN THE NUMBER `^0`@ FOR YOUR THIRD NUMBER!`b`c`@`^");
$session[user][lottochoice]+=1;
$session[user][lotto3]=0;
	}else{
if($session[user][lottochoice]==3){
output("`b`c`@YOU HAVE CHOSEN THE NUMBER `^0`@ FOR YOUR FOURTH NUMBER!`b`c`@`^");
$session[user][lottochoice]+=1;
$session[user][lotto4]=0;


}
}
}
}
}

if ($HTTP_GET_VARS[op]=="choose1"){
page_header("Eric's Lotto");
addnav("Continue","eslotto.php?op=choose");
output("`b`n`n`c`bEric's Lotto`b`c`n`n");
if($session[user][lottochoice]==0){
output("`b`c`@YOU HAVE CHOSEN THE NUMBER `^1`@ FOR YOUR FIRST NUMBER!`b`c`@`^");
$session[user][lottochoice]+=1;
$session[user][lotto1]=1;
	}else{
if($session[user][lottochoice]==1){
output("`b`c`@YOU HAVE CHOSEN THE NUMBER `^1`@ FOR YOUR SECOND NUMBER!`b`c`@`^");
$session[user][lottochoice]+=1;
$session[user][lotto2]=1;
	}else{
if($session[user][lottochoice]==2){
output("`b`c`@YOU HAVE CHOSEN THE NUMBER `^1`@ FOR YOUR THIRD NUMBER!`b`c`@`^");
$session[user][lottochoice]+=1;
$session[user][lotto3]=1;
	}else{
if($session[user][lottochoice]==3){
output("`b`c`@YOU HAVE CHOSEN THE NUMBER `^1`@ FOR YOUR FOURTH NUMBER!`b`c`@`^");
$session[user][lottochoice]+=1;
$session[user][lotto4]=1;

}
}
}
}
}

if ($HTTP_GET_VARS[op]=="choose2"){
page_header("Eric's Lotto");
addnav("Continue","eslotto.php?op=choose");
output("`b`n`n`c`bEric's Lotto`b`c`n`n");
if($session[user][lottochoice]==0){
output("`b`c`@YOU HAVE CHOSEN THE NUMBER `^2`@ FOR YOUR FIRST NUMBER!`b`c`@`^");
$session[user][lottochoice]+=1;
$session[user][lotto1]=2;
	}else{
if($session[user][lottochoice]==1){
output("`b`c`@YOU HAVE CHOSEN THE NUMBER `^2`@ FOR YOUR SECOND NUMBER!`b`c`@`^");
$session[user][lottochoice]+=1;
$session[user][lotto2]=2;
	}else{
if($session[user][lottochoice]==2){
output("`b`c`@YOU HAVE CHOSEN THE NUMBER `^2`@ FOR YOUR THIRD NUMBER!`b`c`@`^");
$session[user][lottochoice]+=1;
$session[user][lotto3]=2;
	}else{
if($session[user][lottochoice]==3){
output("`b`c`@YOU HAVE CHOSEN THE NUMBER `^2`@ FOR YOUR FOURTH NUMBER!`b`c`@`^");
$session[user][lottochoice]+=1;
$session[user][lotto4]=2;

}
}
}
}
}

if ($HTTP_GET_VARS[op]=="choose3"){
page_header("Eric's Lotto");
addnav("Continue","eslotto.php?op=choose");
output("`b`n`n`c`bEric's Lotto`b`c`n`n");
if($session[user][lottochoice]==0){
output("`b`c`@YOU HAVE CHOSEN THE NUMBER `^3`@ FOR YOUR FIRST NUMBER!`b`c`@`^");
$session[user][lottochoice]+=1;
$session[user][lotto1]=3;
	}else{
if($session[user][lottochoice]==1){
output("`b`c`@YOU HAVE CHOSEN THE NUMBER `^3`@ FOR YOUR SECOND NUMBER!`b`c`@`^");
$session[user][lottochoice]+=1;
$session[user][lotto2]=3;
	}else{
if($session[user][lottochoice]==2){
output("`b`c`@YOU HAVE CHOSEN THE NUMBER `^3`@ FOR YOUR THIRD NUMBER!`b`c`@`^");
$session[user][lottochoice]+=1;
$session[user][lotto3]=3;
	}else{
if($session[user][lottochoice]==3){
output("`b`c`@YOU HAVE CHOSEN THE NUMBER `^3`@ FOR YOUR FOURTH NUMBER!`b`c`@`^");
$session[user][lottochoice]+=1;
$session[user][lotto4]=3;

}
}
}
}
}

if ($HTTP_GET_VARS[op]=="choose4"){
page_header("Eric's Lotto");
addnav("Continue","eslotto.php?op=choose");
output("`b`n`n`c`bEric's Lotto`b`c`n`n");
if($session[user][lottochoice]==0){
output("`b`c`@YOU HAVE CHOSEN THE NUMBER `^4`@ FOR YOUR FIRST NUMBER!`b`c`@`^");
$session[user][lottochoice]+=1;
$session[user][lotto1]=4;
	}else{
if($session[user][lottochoice]==1){
output("`b`c`@YOU HAVE CHOSEN THE NUMBER `^4`@ FOR YOUR SECOND NUMBER!`b`c`@`^");
$session[user][lottochoice]+=1;
$session[user][lotto2]=4;
	}else{
if($session[user][lottochoice]==2){
output("`b`c`@YOU HAVE CHOSEN THE NUMBER `^4`@ FOR YOUR THIRD NUMBER!`b`c`@`^");
$session[user][lottochoice]+=1;
$session[user][lotto3]=4;
	}else{
if($session[user][lottochoice]==3){
output("`b`c`@YOU HAVE CHOSEN THE NUMBER `^4`@ FOR YOUR FOURTH NUMBER!`b`c`@`^");
$session[user][lottochoice]+=1;
$session[user][lotto4]=4;

}
}
}
}
}

if ($HTTP_GET_VARS[op]=="choose5"){
page_header("Eric's Lotto");
addnav("Continue","eslotto.php?op=choose");
output("`b`n`n`c`bEric's Lotto`b`c`n`n");
if($session[user][lottochoice]==0){
output("`b`c`@YOU HAVE CHOSEN THE NUMBER `^5`@ FOR YOUR FIRST NUMBER!`b`c`@`^");
$session[user][lottochoice]+=1;
$session[user][lotto1]=5;
	}else{
if($session[user][lottochoice]==1){
output("`b`c`@YOU HAVE CHOSEN THE NUMBER `^5`@ FOR YOUR SECOND NUMBER!`b`c`@`^");
$session[user][lottochoice]+=1;
$session[user][lotto2]=5;
	}else{
if($session[user][lottochoice]==2){
output("`b`c`@YOU HAVE CHOSEN THE NUMBER `^5`@ FOR YOUR THIRD NUMBER!`b`c`@`^");
$session[user][lottochoice]+=1;
$session[user][lotto3]=5;
	}else{
if($session[user][lottochoice]==3){
output("`b`c`@YOU HAVE CHOSEN THE NUMBER `^5`@ FOR YOUR FOURTH NUMBER!`b`c`@`^");
$session[user][lottochoice]+=1;
$session[user][lotto4]=5;

}
}
}
}
}

if ($HTTP_GET_VARS[op]=="choose6"){
page_header("Eric's Lotto");
addnav("Continue","eslotto.php?op=choose");
output("`b`n`n`c`bEric's Lotto`b`c`n`n");
if($session[user][lottochoice]==0){
output("`b`c`@YOU HAVE CHOSEN THE NUMBER `^6`@ FOR YOUR FIRST NUMBER!`b`c`@`^");
$session[user][lottochoice]+=1;
$session[user][lotto1]=6;
	}else{
if($session[user][lottochoice]==1){
output("`b`c`@YOU HAVE CHOSEN THE NUMBER `^6`@ FOR YOUR SECOND NUMBER!`b`c`@`^");
$session[user][lottochoice]+=1;
$session[user][lotto2]=6;
	}else{
if($session[user][lottochoice]==2){
output("`b`c`@YOU HAVE CHOSEN THE NUMBER `^6`@ FOR YOUR THIRD NUMBER!`b`c`@`^");
$session[user][lottochoice]+=1;
$session[user][lotto3]=6;
	}else{
if($session[user][lottochoice]==3){
output("`b`c`@YOU HAVE CHOSEN THE NUMBER `^6`@ FOR YOUR FOURTH NUMBER!`b`c`@`^");
$session[user][lottochoice]+=1;
$session[user][lotto4]=6;

}
}
}
}
}

if ($HTTP_GET_VARS[op]=="choose7"){
page_header("Eric's Lotto");
addnav("Continue","eslotto.php?op=choose");
output("`b`n`n`c`bEric's Lotto`b`c`n`n");
if($session[user][lottochoice]==0){
output("`b`c`@YOU HAVE CHOSEN THE NUMBER `^7`@ FOR YOUR FIRST NUMBER!`b`c`@`^");
$session[user][lottochoice]+=1;
$session[user][lotto1]=7;
	}else{
if($session[user][lottochoice]==1){
output("`b`c`@YOU HAVE CHOSEN THE NUMBER `^7`@ FOR YOUR SECOND NUMBER!`b`c`@`^");
$session[user][lottochoice]+=1;
$session[user][lotto2]=7;
	}else{
if($session[user][lottochoice]==2){
output("`b`c`@YOU HAVE CHOSEN THE NUMBER `^7`@ FOR YOUR THIRD NUMBER!`b`c`@`^");
$session[user][lottochoice]+=1;
$session[user][lotto3]=7;
	}else{
if($session[user][lottochoice]==3){
output("`b`c`@YOU HAVE CHOSEN THE NUMBER `^7`@ FOR YOUR FOURTH NUMBER!`b`c`@`^");
$session[user][lottochoice]+=1;
$session[user][lotto4]=7;

}
}
}
}
}

if ($HTTP_GET_VARS[op]=="choose8"){
page_header("Eric's Lotto");
addnav("Continue","eslotto.php?op=choose");
output("`b`n`n`c`bEric's Lotto`b`c`n`n");
if($session[user][lottochoice]==0){
output("`b`c`@YOU HAVE CHOSEN THE NUMBER `^8`@ FOR YOUR FIRST NUMBER!`b`c`@`^");
$session[user][lottochoice]+=1;
$session[user][lotto1]=8;
	}else{
if($session[user][lottochoice]==1){
output("`b`c`@YOU HAVE CHOSEN THE NUMBER `^8`@ FOR YOUR SECOND NUMBER!`b`c`@`^");
$session[user][lottochoice]+=1;
$session[user][lotto2]=8;
	}else{
if($session[user][lottochoice]==2){
output("`b`c`@YOU HAVE CHOSEN THE NUMBER `^8`@ FOR YOUR THIRD NUMBER!`b`c`@`^");
$session[user][lottochoice]+=1;
$session[user][lotto3]=8;
	}else{
if($session[user][lottochoice]==3){
output("`b`c`@YOU HAVE CHOSEN THE NUMBER `^8`@ FOR YOUR FOURTH NUMBER!`b`c`@`^");
$session[user][lottochoice]+=1;
$session[user][lotto4]=8;

}
}
}
}
}

if ($HTTP_GET_VARS[op]=="choose9"){
page_header("Eric's Lotto");
addnav("Continue","eslotto.php?op=choose");
output("`b`n`n`c`bEric's Lotto`b`c`n`n");
if($session[user][lottochoice]==0){
output("`b`c`@YOU HAVE CHOSEN THE NUMBER `^9`@ FOR YOUR FIRST NUMBER!`b`c`@`^");
$session[user][lottochoice]+=1;
$session[user][lotto1]=9;
	}else{
if($session[user][lottochoice]==1){
output("`b`c`@YOU HAVE CHOSEN THE NUMBER `^9`@ FOR YOUR SECOND NUMBER!`b`c`@`^");
$session[user][lottochoice]+=1;
$session[user][lotto2]=9;
	}else{
if($session[user][lottochoice]==2){
output("`b`c`@YOU HAVE CHOSEN THE NUMBER `^9`@ FOR YOUR THIRD NUMBER!`b`c`@`^");
$session[user][lottochoice]+=1;
$session[user][lotto3]=9;
	}else{
if($session[user][lottochoice]==3){
output("`b`c`@YOU HAVE CHOSEN THE NUMBER `^9`@ FOR YOUR FOURTH NUMBER!`b`c`@`^");
$session[user][lottochoice]+=1;
$session[user][lotto4]=9;

}
}
}
}
}

if ($HTTP_GET_VARS[op]=="match"){
page_header("Eric's Lotto");
addnav("Navigation");
addnav("Claim Your Winnings","eslotto.php?op=winnings");
output("`b`n`n`c`bEric's Lotto`b`c`n`n");
output("`@`cThe machine buzzes and whistles! Showing your numbers almost magically on the slate black window.`@`c`n`n");
output("`^`bYOUR NUMBERS`^`n`n`b");
output("`@First Number: " . ($session['user']['lotto1']) . "`n");
output("Second Number: " . ($session['user']['lotto2']) . " `n");
output("Third Number: " . ($session['user']['lotto3']) . " `n");
output("Fourth Number: " . ($session['user']['lotto4']) . " `@`n`n");
output("`@`cThe machine buzzes and whistles once again! Showing the winning numbers almost magically on the slate black window right below your numbers!`@`c`n`n");
$win1 = e_rand(0,9);
$win2 = e_rand(0,9);
$win3 = e_rand(0,9);
$win4 = e_rand(0,9);
$session[user][win1]= $win1;
$session[user][win2]= $win2;
$session[user][win3]= $win3;
$session[user][win4]= $win4;
output("`^`bWINNING NUMBERS`^`n`n`b");
output("`@First Number: " . ($session['user']['win1']) . "`n");
output("Second Number: " . ($session['user']['win2']) . " `n");
output("Third Number: " . ($session['user']['win3']) . " `n");
output("Fourth Number: " . ($session['user']['win4']) . " `@`n`n");
if($session[user][lotto1]==0){
output("`^`bSorry none of your numbers matched today, try back tomorrow`^`b`n`n");
}
if($session[user][lotto1]==$session[user][win1]){
output("`^`bYour First Number is a perfect match!`^`b`n`n");
$session[user][matches]+=1;
}
if($session[user][lotto2]==$session[user][win2]){
output("`^`bYour Second Number is a perfect match!`^`b`n`n");
$session[user][matches]+=1;
}
if($session[user][lotto3]==$session[user][win3]){
output("`^`bYour Third Number is a perfect match!`^`b`n`n");
$session[user][matches]+=1;
}
if($session[user][lotto4]==$session[user][win4]){
output("`^`bYour Fourth Number is a perfect match!`^`b`n`n");
$session[user][matches]+=1;
}
}

if ($HTTP_GET_VARS[op]=="winnings"){
page_header("Eric's Lotto");
addnav("Navigation");
addnav("Return To Village","village.php");
output("`b`n`n`c`bEric's Lotto Prize Patrol`b`c`n`n");
if($session[user][matches]==0){
output("`@`cThe machines bells and whistles comes to a complete stop and goes dark.`@`c`n`n");
output("`^`cSorry You Didn't Win Today! Try Back Tomorrow!`^`c");
$session[user][lotto]=1;
	}else{
if($session[user][matches]==1){
output("`@`cThe machine flashes and chirps wildly as 500 Gold comes falling out of it!`@`c`n`n");
output("`^`cYou matched 1 number today! You gain 500 Gold`^`c");
$session[user][lotto]=1;
$session[user][gold]+=500;
	}else{
if($session[user][matches]==2){
output("`@`cThe machine flashes and chirps wildly as 1000 Gold comes falling out of it!`@`c`n`n");
output("`^`cYou matched 2 number today! You gain 1000 Gold`^`c");
$session[user][lotto]=1;
$session[user][gold]+=1000;
	}else{
if($session[user][matches]==3){
output("`@`cThe machine flashes and chirps wildly as 2000 Gold comes falling out of it!`@`c`n`n");
output("`^`cYou matched 3 number today! You gain 2000 Gold`^`c");
$session[user][lotto]=1;
$session[user][gold]+=2000;
	}else{
if($session[user][matches]==4){
output("`@`cThe machine flashes and chirps wildly as 5000 Gold comes falling out of it!`@`c`n`n");
output("`^`cYou HIT THE JACKPOT today! You gain 5000 Gold`^`c");
$session[user][lotto]=1;
$session[user][gold]+=5000;

}
}
}
}
}
}

page_footer();
?> 