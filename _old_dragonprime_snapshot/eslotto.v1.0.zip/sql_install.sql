ALTER TABLE accounts ADD lotto int(1) unsigned not null default '0';
ALTER TABLE accounts ADD lottochoice int(1) unsigned not null default '0';
ALTER TABLE accounts ADD lotto1 int(1) unsigned not null default '0';
ALTER TABLE accounts ADD lotto2 int(1) unsigned not null default '0';
ALTER TABLE accounts ADD lotto3 int(1) unsigned not null default '0';
ALTER TABLE accounts ADD lotto4 int(1) unsigned not null default '0';
ALTER TABLE accounts ADD win1 int(1) unsigned not null default '0';
ALTER TABLE accounts ADD win2 int(1) unsigned not null default '0';
ALTER TABLE accounts ADD win3 int(1) unsigned not null default '0';
ALTER TABLE accounts ADD win4 int(1) unsigned not null default '0';
ALTER TABLE accounts ADD matches int(1) unsigned not null default '0';

