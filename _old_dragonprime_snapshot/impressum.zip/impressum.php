<?php

/*
Idee und Umsetzung von Sir Arvex; � 2005
Erstmalig auf Anagromataf.de erschienen
Bugs und Fehler an arvex@anagromataf.de
*/

require_once("lib/http.php");

function impressum_getmoduleinfo(){
	$info = array(
		"name"=>"Impressum",
		"version"=>"1.02",
		"author"=>"`)Arvex",
		"allowanonymous"=>true,
		"category"=>"Informativ",
		"download"=>"http://www.arvex.de/index.php?showforum=3",
		"settings"=>array(
			"Impressum, title",
				"vorname"=>"Vorname des Serverbetreibers|",
				"nachname"=>"Nachname des Serverbetreibers|",
				"stra�e"=>"Stra�e|",
				"hausnr"=>"Hausnummer|",
				"plz"=>"Postleitzahl|",
				"wohnort"=>"Wohnort|",
				"Die Angaben m�ssen korrekt sein da sonst ein Versto� nach dem TDG vorliegt,note",
			"Kontakm�glichkeiten, title",
				"teleanz"=>"Telefonnummer des Serverbetreibers anzeigen,bool|0",
				"tele"=>"Telefonnummer des Serverbetreibers,int|",
				"Die Vorwahl ohne f�hrende Null angeben,note",
				"email"=>"eMail Adresse des Serverbetreibers|",
				"icqanz"=>"Die ICQ Nummer anzeigen,bool|1",
				"icq"=>"Die ICQ Nummer,int|",
				"pseu"=>"Pseudonym des Serverbetreibers|",
			"Mitverantwortlicher, title",
				"mivorhanden"=>"Gibt es einen Mitverantwortlichen,bool|1",
				"mivorname"=>"Vorname des Mitverantwortlichen|",
				"minachname"=>"Nachname des Mitverantwortlichen|",
				"mistra�e"=>"Stra�e|",
				"mihausnr"=>"Hausnummer|",
				"miplz"=>"Postleitzahl|",
				"miwohnort"=>"Wohnort|",
				"miemail"=>"eMail Adresse des Mitverantwortlichen|",
				"Die Angaben m�ssen korrekt sein da sonst ein Versto� nach dem TDG vorliegt,note",
			"Haftungshinweis, title",
				"yor"=>"Soll ein Haftungshinweis angezeigt werden?,bool|1",
				"haftung"=>"Haftungshinweis,textarea|Haftungshinweis: Trotz sorgf�ltiger inhaltlicher Kontrolle �bernehmen wir keine Haftung f�r die Texte anderer Spieler. F�r den Inhalt von verlinkten Seiten sind ausschlie�lich deren Betreiber verantwortlich.",
		),
	);
	return $info;
}

function impressum_install(){
	module_addhook("index");
	return true;
}

function impressum_uninstall(){
	return true;
}

function impressum_dohook($hookname, $args){
	global $session;
	switch ($hookname){
		case "index":
		addnav("Impressum","runmodule.php?module=impressum");
		break;
	}
	return $args;
}

function impressum_run(){
	$op = httpget('op');
	if ($op==""){	
		include("modules/arvex/impressum/impressum_run.php"); 
	}	
	page_footer();
}
?>