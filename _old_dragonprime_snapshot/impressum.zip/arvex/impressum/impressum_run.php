<?php
page_header("Impressum");
		addnav("LotGD");
		addnav("Login Seite","home.php");
		if (is_module_active('rassenbesch')) {
			addnav("Sonstiges");
			addnav("Rassenliste","runmodule.php?module=rassenbesch");
		}
		if (is_module_active('rules')) {
			addnav("Sonstiges");
			addnav("Regeln dieser Welt","runmodule.php?module=rules&from=impressum");
		}	
		
		$vorname = get_module_setting("vorname");
		$nachname = get_module_setting("nachname");
	
		output("`n`n`@`c`bImpressum`b`c`n`n");
		output("`b`QServerbetreiber`b`n");
		output("`7%s %s`n",$vorname,$nachname);
		output("%s %s`n",get_module_setting("stra�e"),get_module_setting("hausnr"));
		output("%s %s`n`n",get_module_setting("plz"),get_module_setting("wohnort"));
		output("`b`QKontaktm�glichkeiten`b`n");
		if (get_module_setting("teleanz") == 1) {
			output("`7Telefon: +49 %s`n",get_module_setting("tele"));
		}
		
		output("eMail: %s`n",get_module_setting("email"));
		
		if (get_module_setting("icqanz") == 1) {
			output("ICQ#: %s`n",get_module_setting("icq"));
		}
		
		output("Pseudonym: %s`n`n",get_module_setting("pseu"));
		
		if (get_module_setting("mivorhanden") == 1) {
			output("`b`qMitverantwortliche`b`n");
			output("`)%s %s`n",get_module_setting("mivorname"),get_module_setting("minachname"));
			output("%s %s`n",get_module_setting("mistra�e"),get_module_setting("mihausnr"));
			output("%s %s`n`n",get_module_setting("miplz"),get_module_setting("miwohnort"));
			output("eMail: %s`n`n",get_module_setting("miemail"));
		}
	
		output("`@Impressum gem�� TDG; inhaltlich Verantwortlicher gem�� � 10 Absatz 3 MDStV:`n");
		output("%s %s (Anschrift wie oben)`n`n",$vorname,$nachname);
	
		if (get_module_setting("yor") == 1) {
			output("%s",get_module_setting("haftung"));
		}
?>