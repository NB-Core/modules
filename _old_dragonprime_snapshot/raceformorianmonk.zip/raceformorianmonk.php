<?php
/* 	A race that takes advantage of the Monk specialty that Billie Kennedy created.
	Similar to the Felyne reace this race have a chance of regaining a used up 
	usepoint for the Monk Specialty during a forest fight.
	Used racecat.php by Shannon Brown as the templet.
*/

function raceformorianmonk_getmoduleinfo(){
	$info = array(
		"name"=>"Race - Formorian Monk",
		"version"=>"1.0",
		"author"=>"`@DaFish",
		"category"=>"Races",
		"download"=>"http://dragonprime.net/users/DaFish/raceformorianmonk.zip",
		"vertxtloc"=>"http://dragonprime.net/users/DaFish/",
		"requires"=>array(
			"specialtymonkskills"=>"1.6|By Billie Kennedy.",
			),
		"settings"=>array(
			"Formorian Monk Settings,title",
			"minedeathchance"=>"Chance for Monks to die in the mine,range,0,100,1|40",
			"usemessage"=>"Message to display when recharging a specialty|`&Your able to clear your mind to a tranquil state and restore one of your `QMonk `&use point!",
			"usechance"=>"Percent chance for Formorian monks to recieve a specialty recharge on battle victory,range,0,100,1|5",
			"mindk"=>"How many DKs do you need before the race is available?,int|0",
		),
	);
	return $info;
}

function raceformorianmonk_install(){
	// The monks share the city with trolls, so..
	if (!is_module_installed("racetroll")) {
		output("The Monks only choose to live with trolls.   You must install that race module.");
		return false;
	}

	module_addhook("chooserace");
	module_addhook("setrace");
	module_addhook("newday");
	module_addhook("charstats");
	module_addhook("raceminedeath");
	module_addhook("battle-victory");
	module_addhook("pvpadjust");
	module_addhook("adjuststats");
	module_addhook("racenames");
	return true;
}

function raceformorianmonk_uninstall(){
	global $session;
	// Force anyone who was a formorian monk to rechoose race
	$sql = "UPDATE  " . db_prefix("accounts") . " SET race='" . RACE_UNKNOWN . "' WHERE race='Felyne'";
	db_query($sql);
	if ($session['user']['race'] == 'Formorian Monk')
		$session['user']['race'] = RACE_UNKNOWN;
	return true;
}
function raceformorianmonk_dohook($hookname,$args){
	//yeah, the $resline thing is a hack.  Sorry, not sure of a better way
	//to handle this.
	// It could be passed as a hook arg?
	global $session,$resline;
	
	$spec = "MN";

	if (is_module_active("racetroll")) {
		$city = get_module_setting("villagename", "racetroll");
	} else {
		$city = getsetting("villagename", LOCATION_FIELDS);
	}
	$race = "Formorian Monk";
	switch($hookname){
	case "racenames":
		$args[$race] = $race;
		break;
	case "pvpadjust":
		if ($args['race'] == $race) {
			$args['creaturedefense']+=(2+floor($args['creaturelevel']/5));
		}
		break;
	case"adjuststats":
		if ($args['race'] == $race) {
			$args['defense'] += (2+floor($args['level']/5));
		}
		break;
	case "raceminedeath":
		if ($session['user']['race'] == $race) {
			$args['chance'] = get_module_setting("minedeathchance");
			$args['racesave'] = "Fortunately your tranquil mind lets you escape certain death.`n";
			$args['schema']="module-raceformorianmonk";
		}
		break;
	case "charstats":
		if ($session['user']['race']==$race){
			addcharstat("Vital Info");
			addcharstat("Race", translate_inline($race));
		}
		break;
	case "chooserace":
		if ($session['user']['dragonkills'] < get_module_setting("mindk"))
			break;
		output("<a href='newday.php?setrace=Felyne$resline'>Meditating in the temples of %s</a>, the city of trolls, your race of `QFormorian Monks`0, travel across the land in search of inner peace.`n`n",$city, true);
		addnav("`QFormorian Monk`0","newday.php?setrace=$race$resline");
		addnav("","newday.php?setrace=$race$resline");
		break;
	case "setrace":
		if ($session['user']['race']==$race){ // it helps if you capitalize correctly
			output("`&As a Formorian Monk, your years of meditation has allowed you to anticipate and dodge attacks.`n");
			output("You gain extra defense!`n");
			output("Your years of meditation has also allowed you to regain extra Monk-skill usepoints during forest fights. `n");
			if (is_module_active("cities")) {
				if ($session['user']['dragonkills']==0 &&
						$session['user']['age']==0){
					//new farmthing, set them to wandering around this city.
					set_module_setting("newest-$city",
							$session['user']['acctid'],"cities");
				}
				set_module_pref("homecity",$city,"cities");
				if ($session['user']['age'] == 0)
					$session['user']['location']=$city;
			}
		}
		break;
	case "newday":
		if ($session['user']['race']==$race){
			raceformorianmonk_checkcity();
			apply_buff("racialbenefit",array(
				"name"=>"`QDeep Meditation`0",
				"defmod"=>"(<defense>?(1+((2+floor(<level>/3))/<defense>)):0)",
				"allowinpvp"=>1,
				"allowintrain"=>1,
				"rounds"=>-1,
				"schema"=>"module-raceformorianmonk",
				)
			);
		}
		break;
	case "battle-victory":
		$bonus = getsetting("specialtybonus", 1);
		$amt = (int)(get_module_pref("skill", 'specialtymonkskills') / 3);
		$useleft = get_module_pref("uses",'specialtymonkskills');
		
		if ($session['user']['specialty'] != $spec) break;
		if ($args['type'] != "forest") break;
		if ($session['user']['specialty'] = $spec) {
			$amt = $amt + $bonus;
			if ($amt > $useleft && 
					e_rand(1,100) <= get_module_setting("usechance")){
				output(get_module_setting("usemessage")."`n`0");
				set_module_pref('uses', get_module_pref("uses",'specialtymonkskills') + 1,'specialtymonkskills');
				debuglog("increased the usepoint for monk skills by one.");
			}
		}
		break;
	}
	return $args;
}

function raceformorianmonk_checkcity(){
	global $session;
	$race = "Formorian Monk";
	if (is_module_active("racetroll")) {
		$city = get_module_setting("villagename", "racetroll");
	} else {
		$city = getsetting("villagename", LOCATION_FIELDS);
	}
	
	if ($session['user']['race']==$race && is_module_active("cities")){
		if (get_module_pref("homecity","cities")!=$city){
			set_module_pref("homecity",$city,"cities");
		}
	}	
	return true;
}

function raceformorianmonk_run(){
	
}
?>