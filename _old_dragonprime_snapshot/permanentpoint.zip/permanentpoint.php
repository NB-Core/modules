<?
/*in db:

ALTER TABLE `accounts` ADD `bonusattack` INT( 11 ) UNSIGNED DEFAULT '0' NOT NULL AFTER `attack` ,
ADD `bonusdefence` INT( 11 ) UNSIGNED DEFAULT '0' NOT NULL AFTER `bonusattack` ;

*/

/* Modification for dragon.php
find    ,"dragonpoints"=>1
add after:
*/
    ,"bonusattack"=>1
    ,"bonusdefence"=>1



//Modification for train.php
            if ($session['user']['experience']>=$exprequired){
                if ($session['user']['bonusattack']>4 OR $session['user']['bonusdef']>4){
                    //Modified Routine
                    $reinca = 0;
                    $reincaatt = 0;
                    $reincadef = 0;
                    //if ($session['user']['reincarna']>0) $reinca=round(($session['user']['reincarna']/2)*18);
                    if ($session['user']['reincarna']>0) $reinca=round(($session['user']['reincarna']/2)*27);
                    if ($reinca < 18) $reinca = 18;
                    if ($session['user']['bonusattack'] > 0 AND $session['user']['dragonkills'] > 2){
                        if ($session['user']['bonusattack'] > $reinca) {
                            $reincaatt = $reinca+1;
                        } else $reincaatt = ($session['user']['bonusattack'] / 2) + 1;
                    }
                    if ($session['user']['bonusdefence'] > 0 AND $session['user']['dragonkills'] > 2){
                        if ($session['user']['bonusdefence'] > $reinca) {
                            $reincadef = $reinca+1;
                        } else {
                          $reincadef = ($session['user']['bonusdefence'] / 2) + 1;
                        }
                    }
                    $atkflux = e_rand(0,($session['user']['dragonkills']+$reinca)) + e_rand($reincaatt,($session['user']['bonusattack']-3));
                    $defflux = e_rand(0,($session['user']['dragonkills']-$atkflux + $reinca)) + e_rand($reincadef,($session['user']['bonusdefence']-2));
                    $hpflux = (($session['user']['dragonkills'] - ($atkflux+$defflux)) * 5) + e_rand(0,($reinca*$session['user']['maxhitpoints']/5));
                    if ($session['user']['level']>=12){
                        $atkflux -= 2;
                        $defflux -= 2;
                        $hpflux = round($hpflux*0.9);
                    }
                }else {
                    //Normal Routine
                    $atkflux = e_rand(0,$session['user']['dragonkills']);
                    $defflux = e_rand(0,($session['user']['dragonkills']-$atkflux));
                    $hpflux = ($session['user']['dragonkills'] - ($atkflux+$defflux)) * 5;
               }


/*Modification for forest.php
Find:
            if (!$beta) $dk = round($dk * 0.25, 0);
            else $dk = round($dk,0);
after add:
*/
            //Modification made by Excalibur to keep track of PERMANENT ATT & DEF points
            //Modifica di Excalibur per tener conto dei PA e PD PERMANENTI
            $bnsatk=(int)(($session[user][bonusattack]/2.5)+0.99);
            $bnsdef=(int)(($session[user][bonusdefence]/2.5)+0.99);
            $atkflux = e_rand(0, ($dk+$bnsatk));
            if ($beta) $atkflux = min($atkflux, round($dk/4));
            $defflux = e_rand(0, ($dk-$atkflux+$bnsdef));
            // End Modification

/*In dragon.php find:
    if ($beta)
        $points = round($points*1.5,0);
    else
        $points = round($points*.75,0);
after add:
*/
    //Modification made by Excalibur to keep track of PERMANENT ATT & DEF points
    $bnsatk=(int)(($session[user][bonusattack]/1.5)+0.99);
    $bnsdef=(int)(($session[user][bonusdefence]/1.5)+0.99);
    $atkflux = e_rand(0, ($bnsatk+$points));
    $defflux = e_rand(0,($points-$atkflux+$bnsdef));
    $hpflux = ($points + $bnsatk + $bnsdef - ($atkflux+$defflux)) * 5;
    // End Modification



?>


