<?php
/************************************************************
This specialty is based losely on the D&D Prestige class of the same name.
************************************************************/

  function specialtybloodmagus_getmoduleinfo(){
    $info = array(
        "name" => "Specialty - Blood Magus",
        "author" => "`6Admin Lexington",
        "version" => "1.0",
        "category" => "Specialties",
        "download"=>"http://dragonprime.net/users/Sichae/specialtybloodmagus.zip",
        "vertxtloc"=>"http://dragonprime.net/users/Lexington/",
        "settings"=> array(
            "Specialty - Blood Magus Settings,title",
            "mindk"=>"How many DKs do you need before the specialty is available?,int|0",
            "cost"=>"How many points do you need before the specialty is available?,int|0",
      ),
      "prefs" => array(
            "Specialty - Blood Magus User Prefs,title",
            "skill"=>"Skill points in Blood Magus,int|0",
            "uses"=>"Uses of Blood Magus allowed,int|0",
        ),
    );
    return $info;
}

function specialtybloodmagus_install(){
    module_addhook("choose-specialty");
    module_addhook("set-specialty");
    module_addhook("fightnav-specialties");
    module_addhook("apply-specialties");
    module_addhook("newday");
    module_addhook("incrementspecialty");
    module_addhook("specialtynames");
    module_addhook("specialtycolor");
    module_addhook("specialtymodules");
    module_addhook("dragonkill");
    module_addhook("pointsdesc");
    module_addhook("newday");
    return true;
}

function specialtybloodmagus_uninstall(){
    $sql = "UPDATE " . db_prefix("accounts") . " SET specialty='' WHERE specialty='BM'";
    db_query($sql);
    return true;
}

function specialtybloodmagus_dohook($hookname,$args){
    global $session,$resline;
    tlschema("fightnav");

    $spec = "BM";
    $name = "Blood Magus";
    $ccode = "`4";
    $cost = get_module_setting("cost");
    $loss = get_module_setting("loss");

    switch ($hookname) {

    case "pointsdesc":
        $args['count']++;
        $format = $args['format'];
        $str = translate("The Blood Magus Specialty is availiable upon reaching %s Dragon Kills and %s points.");
        $str = sprintf($str, get_module_setting("mindk"), $cost);
        output($format, $str, true);
    break;

    case "newday":
        $bonus = getsetting("specialtybonus", 1);

        if($session['user']['specialty'] == $spec) {
            if ($bonus == 1) {
                output("`n`3For being interested in %s%s`3, you gain `^1`3 extra use of `&%s%s`3 for today.`n",$ccode,$name,$ccode,$name);
            }

            else {
                output("`n`3For being interested in %s%s`3, you gain `^%s`3 extra uses of `&%s%s`3 for today.`n",$ccode,$name,$bonus,$ccode,$name);
            }
        }

        $amt = (int)(get_module_pref("skill") / 3);
        if ($session['user']['specialty'] == $spec) $amt++;
        set_module_pref("uses", $amt);
    break;

    case "dragonkill":
        set_module_pref("uses", 0);
        set_module_pref("skill", 0);
    break;

    case "choose-specialty":
        if ($session['user']['specialty'] == "" || $session['user']['specialty'] == '0') {
            $pointsavailable = $session['user']['donation'] - $session['user']['donationspent'];
            if ($session['user']['dragonkills'] < get_module_setting("mindk") || get_module_setting("cost") > $pointsavailable) break;
            addnav("$ccode$name`0","newday.php?setspecialty=".$spec."$resline");
            $t1 = translate_inline("Having found the key to the powers within, you seek to discover your full potential.");
            $t2 = appoencode(translate_inline("$ccode$name`0"));
            rawoutput("<a href='newday.php?setspecialty=$spec$resline'>$t1 ($t2)</a><br>");
            addnav("","newday.php?setspecialty=$spec$resline");
        }
    break;

    case "set-specialty":
        if($session['user']['specialty'] == $spec) {
            page_header($name);
            $session['user']['donationspent'] = $session['user']['donationspent'] - $cost;
            output("`4You died at a young age of some form of illness, or 'impurity' of your blood.");
            output(" But, that death brought only understanding and insight. And, after having spent an eternity studying such,");
            output(" you were able to unlock powerful magical resources from within.");
            output("For you, blood is far more prescious than gold, gems, and often times, even your friends.");
        }
    break;

    case "specialtycolor":
        $args[$spec] = $ccode;
    break;

    case "specialtynames":
        $pointsavailable = $session['user']['donation'] - $session['user']['donationspent'];
        if ($session['user']['superuser'] & SU_EDIT_USERS || $session['user']['dragonkills'] >= get_module_setting("mindk") || get_module_setting("cost") <= $pointsavailable){
            $args[$spec] = translate_inline($name);
        }
    break;

    case "specialtymodules":
        $args[$spec] = "specialtybloodmagus";
    break;

    case "incrementspecialty":
        if($session['user']['specialty'] == $spec) {
            $new = get_module_pref("skill") + 1;
            set_module_pref("skill", $new);
            $c = $args['color'];
            output("`n%sYou gain a level in `&%s%s to `#%s%s!", $c, $name, $c, $new, $c);
            $x = $new % 3;

            if ($x == 0) {
                output("`n`^You gain an extra use point!`n");
                set_module_pref("uses", get_module_pref("uses") + 1);
            }

            else {
                if (3-$x == 1) {
                    output("`n`^Only 1 more skill level until you gain an extra use point!`n");
                }

                else {
                    output("`n`^Only %s more skill levels until you gain an extra use point!`n", (3-$x));
                }
            }
            output_notl("`0");
        }
    break;

    case "fightnav-specialties":
        $uses = get_module_pref("uses");
        $script = $args['script'];

        if ($uses > 0) {
            addnav(array("$ccode$name (%s points)`0", $uses), "");
            addnav(array("$ccode &#149; `4Scarification`7 (%s)`0", 1),
            $script."op=fight&skill=$spec&l=1", true);
        }

        if ($uses > 1) {
            addnav(array("$ccode &#149; `4Homunculus`7 (%s)`0", 2),
            $script."op=fight&skill=$spec&l=2",true);
        }

        if ($uses > 2) {
            addnav(array("$ccode &#149; `4Awaken Blood`7 (%s)`0", 3),
            $script."op=fight&skill=$spec&l=3",true);
        }

        if ($uses > 4) {
            addnav(array("$ccode &#149; `4Bloodwalk`7 (%s)`0", 5),
            $script."op=fight&skill=$spec&l=5",true);
        }
        break;

    case "apply-specialties":
        $skill = httpget('skill');
        $l = httpget('l');

        if ($skill==$spec){
            if (get_module_pref("uses") >= $l){
                switch($l){
                    case 1:
                        apply_buff('bm1',
                            array(
                                "startmsg"=>"`4You scribe runes of power into your very skin, and calling upon the power of the runes, enhanced by your blood, to destroy {badguy}`7.",
                                "name"=>"`4Scarification",
                                "rounds"=>5,
                                "wearoff"=>"`)The rune-scars finaly fade away, and with them goes their power.",
                                "regen"=>round($session['user']['level']-1),
                                "atkmod"=>2,
                                "schema"=>"specialtybloodmagus"
                            )
                        );
                    break;

                    case 2:
                        apply_buff('bm2',
                            array(
                                "startmsg"=>"`4Unlocking a great, mysterious power within you, you manage to call forth a minion composed entirely of your blood.",
                                "name"=>"`4Homunculus",
                                "rounds"=>round($session['user']['hitpoints']/20),
                                "wearoff"=>"`)Your minion seems to be unable to take, or receive, any further punishment, and soaks itself back into your body.",
                                "minioncount"=>1,
                                "minbadguydamage"=>round($session['user']['level']/3,0),
                                "maxbadguydamage"=>round($session['user']['level']/3,0),
                                "effectmsg"=>"`4Your homunculus strikes {badguy}`4 for `^{damage}`4 damage.`7",
                                "effectnodmgmsg"=>"`4When your homunculus lashes out to hit {badguy},`4 it`^MISSES`4!`7",
                                "schema"=>"specialtybloodmagus"
                            )
                        );
                    break;

                    case 3:
                        apply_buff('bm3'
                            ,array(
                                "startmsg"=>"`4Your link to blood allows you now to tap into the blood of your opponents as well.",
                                "name"=>"`4Awaken Blood",
                                "rounds"=>5,
                                "wearoff"=>"{badguy}`4 finally manages to regain control of his body.`7",
                                "atkmod"=>round($session['user']['hitpoints']/100)+1,
                                "effectmsg"=>"{badguy}`4's blood bursts forth from their skin as you hit for `^{damage}`4 damage.`7",
                                "schema"=>"specialtybloodmagus"
                            )
                        );
                    break;

                    case 5:
                        apply_buff('bm5'
                            ,array(
                                "startmsg"=>"`4You have become perfectly attuned to the song of blood, and are now capable of traveling through the blood of others.",
                                "name"=>"`4Bloodwalk",
                                "rounds"=>round($session['user']['level']/3,0)+1,
                                "wearoff"=>"`)Though your power is great, performing the walk of blood is extremely difficult.",
                                "atkmod"=>round($session['user']['hitpoints']/100,0),
                                "effectmsg"=>"`4You leap clear through {badguy}`4's chest, ripping out through their back as you hit for `^{damage}`4 damage.`7",
                                "schema"=>"specialtybloodmagus"
                            )
                        );
                    break;
                }

                set_module_pref("uses", get_module_pref("uses") - $l);
            }

            else {
                apply_buff('bm0',
                    array(
                        "startmsg"=>"You can not feel the power of the Blood in your veins. But for some reason you can't seem to access it...",
                        "rounds"=>1,
                        "schema"=>"specialtybloodmagus"
                    )
                );
            }
        }
        break;
    }
    return $args;
}

function specialtybloodmagus_run() {
}
?>