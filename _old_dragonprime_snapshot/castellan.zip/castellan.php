<?

function castellan_getmoduleinfo(){
	$info = array(
		"name" => "Specialty - Castellan",
		"author" => "Kalazaar",
		"version" => "1.0",
		"download" => "http://dragonprime.net/users/Kala/castellan.zip",
		"category" => "Specialties",
"settings"=> array(
                "Castellan DK setting,title",
                 "mindk"=>"Minimum DK for specialty,int|100"
                ),
                "prefs" => array(
                        "Specialty - Castellan User Prefs,title",
                        "skill"=>"Skill points in Castellan,int|0",
                        "uses"=>"Uses of Castellan allowed,int|0",
		),
	);
	return $info;
}

function castellan_install(){
$sql = "DESCRIBE " . db_prefix("accounts");
	$result = db_query($sql);
	$specialty="CA";
	while($row = db_fetch_assoc($result)) {
		// Convert the user over
		if ($row['Field'] == "summon") {
			debug("Migrating castellan field");
			$sql = "INSERT INTO " . db_prefix("module_userprefs") . " (modulename,setting,userid,value) SELECT 'castellan', 'skill', acctid, summon FROM " . db_prefix("accounts");
			db_query($sql);
			debug("Dropping summon field from accounts table");
			$sql = "ALTER TABLE " . db_prefix("accounts") . " DROP summon";
			db_query($sql);
		} elseif ($row['Field']=="summonuses") {
			debug("Migrating castellan uses field");
			$sql = "INSERT INTO " . db_prefix("module_userprefs") . " (modulename,setting,userid,value) SELECT 'castellan', 'uses', acctid, summonuses FROM " . db_prefix("accounts");
			db_query($sql);
			debug("Dropping summonuses field from accounts table");
			$sql = "ALTER TABLE " . db_prefix("accounts") . " DROP summonuses";
			db_query($sql);
		}
	}
	debug("Migrating castellan Specialty");
	$sql = "UPDATE " . db_prefix("accounts") . " SET specialty='$specialty' WHERE specialty='2'";
	db_query($sql);
	
	module_addhook("choose-specialty");
	module_addhook("set-specialty");
	module_addhook("fightnav-specialties");
	module_addhook("apply-specialties");
	module_addhook("newday");
	module_addhook("incrementspecialty");
	module_addhook("specialtynames");
	module_addhook("specialtymodules");
	module_addhook("specialtycolor");
	module_addhook("dragonkill");
	
	return true;
}
function castellan_uninstall(){
	$sql = "UPDATE " . db_prefix("accounts") . " SET specialty='' WHERE specialty='MP'";
	db_query($sql);
	return true;
}
function castellan_dohook($hookname,$args){
	global $session,$resline;
	
	$spec = "CA";
	$name = "Castellan";
	$ccode = "`2";
	$ccode2 = "`@";
	
	switch ($hookname) {
	case "dragonkill":
		set_module_pref("uses", 0);
		set_module_pref("skill", 0);
		break;
	case "choose-specialty":
		if ($session['user']['dragonkills'] < get_module_setting("mindk")) 
		break;
		if ($session['user']['specialty'] == "" ||
			$session['user']['specialty'] == '0') {
addnav("$ccode$name`0","newday.php?setspecialty=".$spec."$resline");
		$t1 = translate_inline("Summon Mythical Creatures");
		$t2 = appoencode(translate_inline("$ccode$name`0"));
		rawoutput("<a href='newday.php?setspecialty=$spec$resline'>$t1 ($t2)</a><br>");
		addnav("","newday.php?setspecialty=$spec$resline");
	}
		break;
	case "set-specialty":
		if($session['user']['specialty'] == $spec){
			page_header($name);
		output("`2Growing up you realised the voices weren't in your head, they were the voices of the Mythical Guardians, In time you learnt to call them to your side");
		output("Eventually these guardians helped you to fight teaching you more and more each day.");
		output("Finally you were ready to take on the world and win.");
}
		break;
case "specialtycolor":
	$args[$spec] = $ccode;
	break;
case "specialtynames":
	$args[$spec] = translate_inline($name);
	break;
case "specialtymodules":
	$args[$spec] = "castellan";
	break;
case "incrementspecialty":
		if($session['user']['specialty'] == $spec) {
			$new = get_module_pref("skill") + 1;
			set_module_pref("skill", $new);
			$name = translate_inline($name);
			$c = $args['color'];
			output("`n%sYou gain a level in `&%s%s to `#%s%s!",
					$c, $name, $c, $new, $c);
			$x = $new % 3;
			if ($x == 0){
				output("`n`^You gain an extra use point!`n");
				set_module_pref("uses", get_module_pref("uses") + 1);
			}else{
				if (3-$x == 1) {
					output("`n`^Only 1 more skill level until you gain an extra use point!`n");
				} else {
					output("`n`^Only %s more skill levels until you gain an extra use point!`n", (3-$x));
				}
			}
			output_notl("`0");
		}
		break;
case "newday":
		$bonus = getsetting("specialtybonus", 1);
		if($session['user']['specialty'] == $spec) {
			$name = translate_inline($name);
			if ($bonus == 1) {
				output("`n`2For being interested in %s%s`2, you receive `^1`2 extra `&%s%s`2 use for today.`n",$ccode, $name, $ccode, $name);
		} else {
				output("`n`2For being interested in %s%s`2, you receive `^%s`2 extra `&%s%s`2 uses for today.`n",$ccode, $name,$bonus, $ccode,$name);
		}
		}
		$amt = (int)(get_module_pref("skill") / 3);
		if ($session['user']['specialty'] == $spec) $amt = $amt + $bonus;
		set_module_pref("uses", $amt);
		break;
case "fightnav-specialties":
		$uses = get_module_pref("uses");
		$script = $args['script'];
		if ($uses > 0) {
			addnav(array("$ccode$name (%s points)`0", $uses),"");
			addnav(array("$ccode &#149; Summon Cerberus`7 (%s)`0", 1), 
					$script."op=fight&skill=$spec&l=1", true);
		}
		if ($uses > 1) {
			addnav(array("$ccode &#149; Sphinx Summoning`7 (%s)`0", 2),
					$script."op=fight&skill=$spec&l=2",true);
		}
		if ($uses > 2) {
			addnav(array("$ccode &#149; Hydra Attack`7 (%s)`0", 3),
					$script."op=fight&skill=$spec&l=3",true);
		}
		if ($uses > 4) {
			addnav(array("$ccode &#149; Thalos Protection`7 (%s)`0", 5),
					$script."op=fight&skill=$spec&l=5",true);
}
	break;

case "apply-specialties":
		$skill = httpget('skill');
		$l = httpget('l');
		if ($skill==$spec){
			if (get_module_pref("uses") >= $l){
				switch($l){
         case 1:
           apply_buff('ca1',array(
             "startmsg"=>"`!You Summon Cerberus from the Gates of Hades",
             "name"=>"`)Summon Cerberus",
             "rounds"=>50,
             "wearoff"=>"`!Cerberus returns to the depths of Hades",
             "roundmsg"=>"`!Cerberus breaths fire upon `^{badguy}",
			 "badguyatkmod"=>.4,
			 "badguydefmod"=>.4,
             "schema"=>"module-castellan"
   ));
         break;
       case 2:
         apply_buff('ca2',array(
				"startmsg"=>"`QYou Call upon the Sphinx.",
				"name"=>"`QSphinx Summoning",
				"rounds"=>75,
				"wearoff"=>"`QThe Sphinx returns to her Riddles.",
				"minioncount"=>round($session['user']['level']*1),
				"maxbadguydamage"=>round($session['user']['level']*8,7)+25,
				"effectmsg"=>"`QThe Sphinx punishes `^{badguy} `Qfor {damage}",
				"effectnodmgmsg"=>"`^{badguy} `Qanswers a riddle correctly!",
				"schema"=>"module-castellan"
     ));
       break;
     case 3:
       apply_buff('ca3', array(
         "startmsg"=>"`4 The Hydra heeds your call from the Watery Gates of Hades",
         "name"=>"`4Hydra Attack",
         "rounds"=>90,
         "wearoff"=>"`4The Hydra returns to its watery vigil",
			"effectmsg"=>"Hydra smashes {badguy} for `^{damage}`) damage!",
		 "badguyatkmod"=>.2,
		 "badguydefmod"=>.2,
		 "schema"=>"module-castellan"
   ));
     break;
   case 5:
     apply_buff('ca5',array(
      "startmsg"=>"`6You Call Thalos from his Island Home",
	  "name"=>"`6Thalos Protection",
	  "rounds"=>35,
	  "wearoff"=>"`6Thalos Returns to his Lonely Duty",
	  "minioncount"=>round($session['user']['level']/3),
	  "maxbadguydamage"=>round($session['user']['level']*50,0)+1,
	  "effectmsg"=>"`6Thalos hurls a rock at`^{badguy} `6for `^{damage}`6 damage.",
	  "effectnodmgmsg"=>"{badguy} Laughs, call that a rock!",
	  "effectfailmsg"=>"{badguy} dodges the rock!!.",
	  "schema"=>"module-castellan"
 					));
					break;
				}
			}
		}
		break;
	}
	return $args;
}

function castellan_run(){
}
?> 