<?php

function tactics_getmoduleinfo(){
	$info = array(
		"name"=>"Tactical Studio",
		"author"=>"Chris Vorndran",
		"category"=>"Village",
		"version"=>"1.1",
		"download"=>"http://dragonprime.net/index.php?module=Downloads;sa=dlview;id=34",
		"vertxtloc"=>"http://dragonprime.net/users/Sichae/",
		"description"=>"One can have their time in the forest recorded and compared.",
			"settings"=>array(
				"Tactical Studio Settings,title",
					"wipe"=>"Allow users to wipe their Stats?,bool|1",
					"tloc"=>"Location of the Tactical Studio?,location|".getsetting("villagename", LOCATION_FIELDS),
			),
			"prefs"=>array(
				"Tactical Studio Prefs,title",
					"active"=>"Are this users tactics being recorded?,bool|0",
				"Recorded Stats,title",
					"total"=>"Total Searches,int|0",
					"search"=>"How many times a user \"Looked for Something to Kill\",int|0",
					"slum"=>"How many times has this user \"Go Slumming\",int|0",
					"thrill"=>"How many times has this user \"Go Thrillseeking\",int|0",
					"suicide"=>"How many times has this user \"Search Suicidally\",int|0",
			),
		);
	return $info;
}
function tactics_install(){
	module_addhook("header-forest");
	module_addhook("village");
	module_addhook("changesetting");
	return true;
}
function tactics_uninstall(){
	return true;
}
function tactics_dohook($hookname,$args){
	global $session;
	switch ($hookname){
		case "header-forest":
			if (get_module_pref("active")){
				$op = httpget('op');
				$type = httpget('type');
				if ($op == "search"){
					$total = get_module_pref("total");
					debug($total);
					set_module_pref("total",$total+1);
					if ($type == NULL) $type = "search";
					set_module_pref($type,get_module_pref($type)+1);
				}
			}
			break;
		case "village":
			if ($session['user']['location'] == get_module_setting("tloc")){
				tlschema($args['schemas']['fightnav']);
				addnav($args['fightnav']);
				tlschema();
				addnav("Tactical Studio","runmodule.php?module=tactics&op=enter");
			}
			break;
		case "changesetting":
			if ($args['setting'] == "villagename"){
				if ($args['old'] == get_module_setting("tloc")){
					set_module_setting("tloc",$args['new']);
				}
			}
			break;
		}
	return $args;
}
function tactics_run(){
	global $session;
	$op = httpget('op');
	$d = httpget('d');
	$g = translate_inline($session['user']['sex']==1?"Ms.":"Mr.");
	page_header("Tactical Studio");
	
	switch ($op){
		case "enter":
			output("`@Upon entering a very well-furnished studio, you see two people standing between a pair of desks.");
			output("One having Blonde hair, the other having Brown.");
			output("The one with brown hair adjourns to the back, as the Blonde one walks towards you.");
			output("\"`)Hello, may I introduce myself? I am Ramza Beoulve, a Knight and Tactical Genius.");
			output("My associate, Delita Hyral, was the other man you just saw.");
			output("I am afraid, that he has some work to take care of.");
			output("So, I shall be helping you for today.`@\"");
			if (!get_module_pref("active")){
				output("`@Ramza looks upon you, \"`)I see that you currently are not signed up for our services.");
				output("If you would be so kind as to join Delita in the back, he shall discuss the terms further.`@\"");
				addnav("Options");
				addnav("Sign Up","runmodule.php?module=tactics&op=sign");
			}else{
				output("`@Ramza smiles at the sight of you.");
				output("\"`)Ah, sorry `)%s %s`), for I hadn't recognized you there.",$g,$session['user']['name']);
				output("Please, please... if you would be so kind as to follow me, we shall view your current statistics.`@\"");
				addnav("Options");
				addnav("Check Statistics","runmodule.php?module=tactics&op=stats");
			}
			break;
		case "sign":
			switch ($d){
				case "":
					output("`@You walk back into the shoppe, and notice a flickering light in deeper.");
					output("While venturing towards it, Delita pops out of nowhere and stops you.");
					output("\"`qOi! Where do ye think ye be goin'?");
					output("I bet dat Ramza sent ye back 'ere... 'e never had an eye for the customers.");
					output("Let's 'ave a looksee...`@\"`n`n");
					output("Delita pulls you close, and shakes off the numbskull accent.");
					output("\"`qNow... the purpose of this studio is to assess how you spend your time in the forest.");
					output("This means that I shall be watching your every move in the forest... seeing what risks you are taking and such.");
					output("Now, let it be known... that once you agree to this, you won't be backing out.");
					output("Are ye sure you wish to sign up?`@\"");
					addnav("Options");
					addnav("Yes","runmodule.php?module=tactics&op=sign&d=yes");
					addnav("No","runmodule.php?module=tactics&op=sign&d=no");
					break;
				case "yes":
					output("`@In the end, you see some signed documents in front of you.");
					output("\"`qWell, everything seems to be in order... Welcome to the Tactical Studio!`@\"");
					set_module_pref("active",1);
					break;
				case "no":
					output("`@Delita smiles softly and resumes his pathetic accent, \"`qIf dat be what ye wish...`@\"");
					break;
				}
			break;
		case "wipe":
			switch ($d){
				case "":
					output("`@Ramza drops his pointer and gawks, \"`)You wish to `bwipe`b your stats?!`@\"");
					output("`n`nAll of a suddent, Delita rushes out from the back room and whisks you away.");
					output("He grabs you by the shoulders and looks you square in the eye.");
					output("\"`qNow boyo... are you sure you wish to wipe your stats?`@\"");
					addnav("Options");
					addnav("Yes","runmodule.php?module=tactics&op=wipe&d=yes");
					addnav("No","runmodule.php?module=tactics&op=wipe&d=no");
					break;
				case "yes":
					output("`@Delita nods and starts to hum a low chant.");
					output("He lulls you into a deep sleep and then cracks you over the head with a bat.");
					output("\"`qThere! All gone!`@\"");
					set_module_pref("total",0);
					set_module_pref("search",0);
					set_module_pref("slum",0);
					set_module_pref("thrill",0);
					set_module_pref("suicide",0);
					break;
				case "no":
					output("`@Delita smiles softly and resumes his pathetic accent, \"`qIf dat be what ye wish...`@\"");
					break;
			}
			break;
		case "stats":
			// Lets bring in all of the stats
			$t = get_module_pref("total");
			$searchpref = get_module_pref("search");
			$slumpref = get_module_pref("slum");
			$thrillpref = get_module_pref("thrill");
			$suicidepref = get_module_pref("suicide");
			if ($t > 0){
				if (get_module_setting("wipe")){
					addnav("Options");
					addnav("Wipe Stats","runmodule.php?module=tactics&op=wipe");
				}
				// Now, lets build these stats nicely...
				$se = (round($searchpref/$t,2)*100);
				$sl = (round($slumpref/$t,2)*100);
				$th = (round($thrillpref/$t,2)*100);
				$su = (round($suicidepref/$t,2)*100);
				if ($searchpref > 0){
					$sltose = round($slumpref/$searchpref,2);
					$thtose = round($thrillpref/$searchpref,2);				
					$sutose = round($suicidepref/$searchpref,2);
				}else{
					$sltose = 0;
					$thtose = 0;				
					$sutose = 0;
				}
				if ($slumpref > 0){
					$setosl = round($search/$slumpref,2);
					$thtosl = round($thrill/$slumpref,2);
					$sutosl = round($suicide/$slumpref,2);
				}else{
					$setosl = 0;
					$thtosl = 0;
					$sutosl = 0;
				}
				if ($thrillpref > 0){
					$setoth = round($searchpref/$thrillpref,2);
					$sltoth = round($slumpref/$thrillpref,2);
					$sutoth = round($suicidepref/$thrillpref,2);
				}else{
					$setoth = 0;
					$sltoth = 0;
					$sutoth = 0;
				}
				if ($suicidepref > 0){
					$thtosu = round($thrillpref/$suicidepref,2);
					$setosu = round($searchpref/$suicidepref,2);
					$sltosu = round($slumpref/$suicidepref,2);
				}else{
					$thtosu = 0;
					$setosu = 0;
					$sltosu = 0;
				}
				$type = translate_inline("Types");
				$total = translate_inline("Total");
				$search = translate_inline("Normal");
				$slum = translate_inline("Slumming");
				$thrill = translate_inline("Thrillseeking");
				$suicide = translate_inline("Suicidal");
				output("`@Ramza lays out some plans in front of you.");
				output("You quickly notice them as a spreadsheet and smile.");
				output("Ramza notes, \"`)This took a long time for ME to collect.`@\"");
				output("Ramza points out certain things, and then states,\"`)Okay, you had `^%s `)Normal Searches, `^%s `)Slumming Searches, `^%s `)Thrillseeking Searches and `^%s `)Suicidal Searches.",$searchpref,$slumpref,$thrillpref,$suicidepref);
				output("Mind you, this is all out of `^%s `)Total Searches.`@\"`n`n",$t);
				rawoutput("<table align='center' border='0' cellpadding='2' width='85%' cellspacing='1' bgcolor='#999999'>",true);
				rawoutput("<tr class='trhead'><td align='center'>$type</td><td align='center'>$search</td><td align='center'>$slum</td><td align='center'>$thrill</td><td align='center'>$suicide</td></tr>");
				rawoutput("<tr class='".(1%2?"trlight":"trdark")."'><td align='center'>$total</td><td align='center'>$se%</td><td align='center'>$sl%</td><td align='center'>$th%</td><td align='center'>$su%</td></tr>");
				rawoutput("<tr class='".(2%2?"trlight":"trdark")."'><td align='center'>$search</td><td align='center'><b>--</b></td><td align='center'>$setosl</td><td align='center'>$setoth</td><td align='center'>$setosu</td></tr>");
				rawoutput("<tr class='".(1%2?"trlight":"trdark")."'><td align='center'>$slum</td><td align='center'>$sltose</td><td align='center'><b>--</b></td><td align='center'>$sltoth</td><td align='center'>$sltosu</td></tr>");
				rawoutput("<tr class='".(2%2?"trlight":"trdark")."'><td align='center'>$thrill</td><td align='center'>$thtose</td><td align='center'>$thtosl</td><td align='center'><b>--</b></td><td align='center'>$thtosu</td></tr>");
				rawoutput("<tr class='".(1%2?"trlight":"trdark")."'><td align='center'>$suicide</td><td align='center'>$sutose</td><td align='center'>$sutosl</td><td align='center'>$sutoth</td><td align='center'><b>--</b></td></tr>");
				rawoutput("</table>");
				output_notl("`n");
				output("`@Ramza smiles and points to the bottom 4 Rows.");
				output("\"`)These show the ratio of the left type to the coresponding top type.");
				output("Now... `bthis`b is a free service.`@\"");
			}else{
				output("`@Ramza shakes his head, \"`)You have yet to do ANYTHING!`@\"");
			}
			break;
		}
	addnav("Leave");
	villagenav();
page_footer();
}	
?>