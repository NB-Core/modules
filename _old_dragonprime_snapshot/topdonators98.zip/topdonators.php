<?php
function topdonators_getmoduleinfo(){
	$info = array(
		"name"=>"Top Donators",
		"version"=>"1.02",
		"author"=>"`#Lonny Luberts",
		"category"=>"PQcomp",
		"download"=>"http://www.pqcomp.com/modules/mydownloads/visit.php?cid=3&lid=84",
		"vertxtloc"=>"http://www.pqcomp.com/",
	);
	return $info;
}

function topdonators_install(){
	if (!is_module_active('topdonators')){
		output("`4Installing Top Donators Module.`n");
	}else{
		output("`4Updating Top Donators Module.`n");
	}
	module_addhook("footer-hof");
	return true;
}

function topdonators_uninstall(){
	output("`4Un-Installing Top Donators Module.`n");
	return true;
}

function topdonators_dohook($hookname,$args){
	global $session;
	switch($hookname){
	case "footer-hof":
		addnav("Donators");
		addnav("Top Donators","runmodule.php?module=topdonators");
	break;
	}
	return $args;
}

function topdonators_run(){
global $session;
$op = httpget('op');
require_once("common.php");
require_once("lib/http.php");
require_once("lib/villagenav.php");
page_header("Top Donators");
$sql = "SELECT name FROM ". db_prefix("accounts") . " WHERE donation > 0 ORDER BY donation DESC LIMIT 10";
$result = db_query($sql);
for($i=1;$i<11;$i++){
$row = db_fetch_assoc($result);
	output_notl($i.") ".$row['name']."`n");
}
addnav("Back to HOF","hof.php");
villagenav();
page_footer();
}
?>