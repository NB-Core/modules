<?php


function goodyshop_getmoduleinfo(){
	$info = array(
		"name"=>"Goody Shop",
		"version"=>"1.1",
		"author"=>"Qwyxzl",//With help from Kickme cleaning up a few issues
		"category"=>"Village",
		"download"=>"http://dragonprime.net/",
		"settings"=>array(
			"Goody Shop - Settings,title",
			"shoploc"=>"Where does the kitchen appear,location|".getsetting("villagename", LOCATION_FIELDS),
			"owner"=>"Shop keeper's name,text|`7Pye`3wack`1et",
			"eatsallowed" =>"Number of time a player may eat. Any particular goody is only available once,range,1,3,1|1",
			"petsallowed"=>"Times players are allowed to pet Gizmo per day (0 for infinite),int|1",
			"gizmoattacks"=>"Percent chance for Gizmo to attack,range,1,15,1|10",
			"price"=>"Cost of the low priced goodies per level. Middle priced ones are 2X this and high priced ones are 3X, int|5",
			"gold"=>"Highest value for the gold nugget. This amount will be multiplied the the person's level, int|20"			
			),
		"prefs"=>array(
			"Goody Shop - Preferences,title",
			"eatstoday"=>"Number of times player has eaten today|0",
			"goodyone"=>"Name of the first goody,text|",
			"goodytwo"=>"Name of the second goody,text|",
			"goodythree"=>"Name of the third goody,text|",
			"eatenone"=>"Has player eaten low priced goody,bool|0",
			"eatentwo"=>"Has player eaten middle priced goody,bool|0",
			"eatenthree"=>"Has player eaten high priced goody,bool|0",
			"petstoday"=>"number of times player petted Gizmo today,int|0"
		)
	);
	return $info;
}


function goodyshop_install(){
	if(get_module_pref("goodyone") == "" || get_module_pref("goodytwo") == "" || get_module_pref("goodythree") == ""){
		goody_names();
	}

	module_addhook("changesetting");
	module_addhook("village");
	module_addhook("newday");
	return true;
}


function goodyshop_uninstall(){
	return true;
}


function goodyshop_dohook($hookname,$args){
	global $session;
	
	switch($hookname){
	case "changesetting":
		if ($args['setting'] == "villagename") {
			if ($args['old'] == get_module_setting("shoploc")) {
				set_module_setting("shoploc", $args['new']);
			}
		}
		break;
	case "village":
		if ($session['user']['location'] == get_module_setting("shoploc")) {
			tlschema($args['schemas']['marketnav']);
			addnav($args['marketnav']);
			tlschema();
			addnav("Gizmo's Goodies","runmodule.php?module=goodyshop&op=enter");
		}
		break;
	case "newday":
		set_module_pref("eatstoday",0);
		set_module_pref("petstoday",0);
		set_module_pref("eatenone",0);
		set_module_pref("eatentwo",0);
		set_module_pref("eatenthree",0);
		goody_names();
		break;
	}
	return $args;
}


function goodyshop_run(){
	global $session;
	$eatstoday = get_module_pref("eatstoday");
	$eatsallowed = get_module_setting("eatsallowed");
	$goodyone = translate_inline(get_module_pref("goodyone"));
	$goodytwo = translate_inline(get_module_pref("goodytwo"));
	$goodythree = translate_inline(get_module_pref("goodythree"));
	$eatenone = get_module_pref("eatenone");
	$eatentwo = get_module_pref("eatentwo");
	$eatenthree = get_module_pref("eatenthree");
	$petstoday = get_module_pref("petstoday");
	$petsallowed = get_module_setting("petsallowed");
	$owner = get_module_setting("owner");
	$baseprice = get_module_setting("price") * $session['user']['level'];
	$op = httpget('op');
	
	page_header("Gizmo's Goodies");	
	switch($op){
		case "enter":
			output("`&`c`bSomething smells yummy`b`c`n`n`n");
			output("`%The wonderful smell of baking fills this shop. Sitting on the window sill is `)G`7i`&z`7m`)o`% the cat.");
			if($petstoday < $petsallowed || $petsallowed == 0){
				addnav("Pet `)G`7i`&z`7m`)o`0","runmodule.php?module=goodyshop&op=gizmo");
			}
			if($petstoday > 0){
				output("`n`)G`7i`&z`7m`)o`% jumps down from his window sill and comes over to rub up against you.");
			}
			if ($eatstoday < $eatsallowed) {
				addnav("Look at goodies","runmodule.php?module=goodyshop&op=goodies");
			}else{
				output("`nEven though the all the goodies smell great you are watching your weight and don't think you could eat another.");
			}
			break;
		case "gizmo":
			output("`c`b`&Purrrrrrrrrrrrrrrrrrrrrrrrrrrrrrr`b`c`n`n`n");
			if($petstoday == 0){
				output("`%You walk over to the window and begin to scratch `)G`7i`&z`7m`)o`% behind the ear.");
				output("`nHe loves the attention and begins to purr loudly.");
			}else{
				output("`%You reach down and begin to scratch `)G`7i`&z`7m`)o`% behind the ear. He purrs and weaves his way between your legs.");
			}
			apply_buff('goodyshop',array("name"=>"`)G`7i`&z`7m`)o `0purrs","rounds"=>5,"defmod"=>1.05, "schema"=>"module-goodyshop"));
			$petstoday++;
			set_module_pref("petstoday", $petstoday);
			if ($eatstoday < $eatsallowed){
				addnav("Look at goodies","runmodule.php?module=goodyshop&op=goodies");
			}else{
				output("`n`%Even though the all the goodies smell great you are watching your weight and don't think you could eat another.");
			}
			break;
		case "goodies":
			output("`c`b`&Look at all the yummy goodies`b`c`n`n`n");
			output("`%You walk over to the counter to take a look at all the wonderfull goodies for sale.");
			output("`n%s `%smiles at you and says `#\"Welcome to my shop. Do you see anything that you would like today?\"", $owner);
			output("`n`)G`7i`&z`7m`)o`% walks over and hops up on the counter to see what you are doing.");
			if(!$eatenone){
				addnav(array("%s `^(%s gold)", $goodyone, $baseprice),"runmodule.php?module=goodyshop&op=little");
			}
			if(!$eatentwo){
				addnav(array("%s `^(%s gold)", $goodytwo, $baseprice * 2),"runmodule.php?module=goodyshop&op=medium");
			}
			if(!$eatenthree){
				addnav(array("%s `^(%s gold)", $goodythree, $baseprice * 3),"runmodule.php?module=goodyshop&op=large");
			}
			addnav("Go back to lobby","runmodule.php?module=goodyshop&op=enter");
			break;
		case "little":
			buy_goodies($baseprice, $goodyone, 1);
			break;
		case "medium":
			buy_goodies($baseprice * 2, $goodytwo, 2);
			break;
		case "large":
			buy_goodies($baseprice * 3, $goodythree, 3);
			break;
	}
	addnav("Leave shop","village.php");
	page_footer();
}


function buy_goodies($price, $goody, $size){
	global $session;
	$gizmoattacks = get_module_setting("gizmoattacks");
	$owner = get_module_setting("owner");
	$eats = get_module_pref("eatstoday");
	
	addnav("Go back to lobby","runmodule.php?module=goodyshop&op=enter");
	if($session['user']['gold'] < $price){
		output("`c`b`&Must have left your money back at the bank`b`c`n`n`n");	
		output("%s `%says `#\"Sorry, but you do not have enough money. Please come back when you do.\"", $owner);
	}else{
		$eats++;
		set_module_pref("eatstoday", $eats);
		$session['user']['gold'] -= $price;
		switch($size){
			case 1:
				set_module_pref("eatenone",1);
				break;
			case 2:
				set_module_pref("eatentwo",1);
				break;
			case 3:
				set_module_pref("eatenthree",1);
				break;
		}
		if(e_rand(1,100) < $gizmoattacks){
			output("`c`b`)G`7i`&z`7m`)o`\$ Attacks!`b`c`n`n`n");
			output("`)G`7i`&z`7m`)o`% reaches out a paw as %s`% hands you your goody and knocks your %s`% to the ground. ", $owner, $goody);
			output("`)G`7i`&z`7m`)o`% then jumps down, snatches it up, and runs off to eat it.");
			output("`n\"`#Bad `)G`7i`&z`7m`)o`#!\" `%says %s`%. `#\"I am so sorry about that. Here, take this instead.\"", $owner);
			output("`n%s `%hands you a chocolate heart.", $owner);
			output("`% After eating the heart you feel more charming!");
			$session['user']['charm']++;	
		}else{
			make_reward($size, $goody);
		}
	}
}


function make_reward($size, $goody){
	global $session;
	$gold = $session['user']['level'] * get_module_pref("gold");
	$gold = e_rand(1, $gold);
	
	if(e_rand(1,10) < 5){
		output("`c`b`\$ OH NO!`b`c`n`n`n");
		$bonus = e_rand(0,5);
	}
	else{
		$bonus = e_rand(9,13);
		output("`c`b`&Yummy for your tummy`b`c`n`n`n");
		output("`%You savor the the wonderful taste of your %s`%.", $goody);
	}
	$bonus += $size;
	switch($bonus){
		case 1: case 2: case 3: 
			$starthp = $session['user']['hitpoints'];
			$session['user']['hitpoints'] = ROUND($starthp * (1 - ((.1 * $size) + .2)), 0);
			if($session['user']['hitpoints'] == 0){
				$session['user']['hitpoints'] = 1;
			}
			output("`%You have a cavity! You lose %s hit points.", $starthp - $session['user']['hitpoints']); 
			$debugtext = "Cavity with ".($starthp - $session['user']['hitpoints'])." hp loss";
			break;
		case 4: case 5:
			$session['user']['gold'] += $gold;
			$starthp = $session['user']['hitpoints'];
			$session['user']['hitpoints'] = ROUND($starthp * ((.1 * $size) + .4), 0);
			if($session['user']['hitpoints'] == 0){
				$session['user']['hitpoints'] = 1;
			}
			output("`%You bite into your %s`% and break your tooth on a `6gold`% nugget!", $goody);
			$losthp = $starthp - $session['user']['hitpoints'];
			output("`n`%You lose %s hit points but the nugget is worth `6%s gold`%.", $losthp , $gold); 
			
			$debugtext = "goldnugget with $losthp hp loss and worth $gold";
			break;
		case 6: case 8:
			$session['user']['gems']++;
			$starthp = $session['user']['hitpoints'];
			$session['user']['hitpoints'] = ROUND($starthp * (1 - ((.1 * $size) + .2)), 0);
			if($session['user']['hitpoints'] == 0){
				$session['user']['hitpoints'] = 1;
			}
			$losthp = $starthp - $session['user']['hitpoints'];
			output("`%OUCH! You break a tooth on a gem in your %s`%! You lose %s hitpoints.", $goody, $losthp);
			$debugtext = "Gem with $losthp hp loss";
			break;
		case 7:
			output("`%You get an upset tummy from all the `&sugar`%");
			if($session['user']['turns'] > 1){
				$session['user']['turns']--;
				output(" and dont feel well enough to fight as much");
				$debugtext = "Upset tummy loss of turn";
			}else{
				apply_buff('goodyshop',array("name"=>"Tummyache","rounds"=>5*$size,"atkmod"=>.95, "survivenewday"=>1, "schema"=>"module-goodyshop",
					"newdaymessage"=>array("`%Your tummy still hurts from the %s`% you ate yesterday.", $goody)));
				$debugtext = "Upset tummy loss next day buff";
			}
			output(".");
			break;	
		case 10:
			$session['user']['gold'] += $gold;
			output("`n`%You bite into your %s`% and find a `6gold`% nugget worth %s gold!", $goody, $gold);
			$debugtext = "Gold nugget worth $gold";
			break;
		case 11:
			if($session['user']['hitpoints'] >= $session['user']['maxhitpoints']){
				$session['user']['hitpoints'] = ROUND($session['user']['hitpoints'] * (1 + (.05 * $size)), 0);
			output("`n`%You feel stronger! You gain hit points.");
			$debugtext = "Gain hp more than max";
			}else{
				$session['user']['hitpoints'] = $session['user']['maxhitpoints'];
				output("`n`%All that goodness from your %s`% heals you completely!", $goody);
				$debugtext = "Total heal";
			}
			break;
		case 12:
			apply_buff('goodyshop',array("name"=>"Hyperactivity","rounds"=>5*$size,"atkmod"=>1.05, "schema"=>"module-goodyshop"));
			output("`n`%You feel Hyper!");
			$debugtext = "Hyperactivity buff";
			break;
		case 13:
			$session['user']['hitpoints'] = ROUND($session['user']['hitpoints'] * (1.1 + (.05 * $size)), 0);
			output("`n`%You feel stronger! You gain hit points.");
			$debugtext = "Gain hp no matter current hp";
			break;
		case 14:
			$session['user']['gems']++;
			output("`n`%You find a gem in your %s`%!", $goody);
			$debugtext = "Gain Gem";
			break;			
		case 15: 
			$session['user']['turns'] ++;
			output("`n`%You get a `&Sugar Rush`%! You gain 1 turn!");
			$debugtext = "Gain one turn";
			break;
		case 16:
			$session['user']['turns'] += 2;
			output("`n`%You feel a SUPER `&Sugar Rush`%! You gain 2 turns!"); 
			$debugtext = "Gain two turns";
			break;
	}
	 debuglog("{$session['user']['name']} type of reward:$debugtext,goody name:$goody");
}


function goody_names(){
	$goodies = array("`&Cho`qc`&ola`qt`&e ch`qi`&p co`qo`&kie", "`qOatmeal`& cookie", "`QBrownie", "`^Banana`& bread", 
		"`QPumkin`& bread", "`QCarrot`& cake", "`&German `qchocolate`& cake", "`1Blueberry`& cupcake", "`\$Cherry`& tart",
		"`@Apple`& pie", "`qPecan`& pie");
	$count = 1;
	$stillnaming = true;
	
	while($stillnaming){
		$temp = $goodies[e_rand(0, count($goodies)-1)];
		switch($count){
			case 1:
				set_module_pref("goodyone", $temp);
				$count++;
				break;
			case 2:
				if($temp != get_module_pref("goodyone")){
					set_module_pref("goodytwo", $temp);
					$count++;
				}
				break;
			case 3:
				if($temp != get_module_pref("goodyone") && $temp != get_module_pref("goodytwo")){
					set_module_pref("goodythree", $temp);
					$stillnaming = false;
				}	
				break;
		}
	}

}


?>