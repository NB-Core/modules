<?
require_once "common.php";


page_header("Charm Purchase");

if ($session['user']['gold']>19999){ 
output(" `n`n`2`b`cTraded 20,000 gold for 20 charm points!`n"); 
$session[user][gold] -= 20000; 
$session[user][charm] += 20; 

    }else{ 
    output("`n`n`2You cannot afford this trade...`n"); 
    output("`n`n"); 
} 


	$return = preg_replace("'[&?]c=[[:digit:]]+'","",$_GET[ret]);
	$return = substr($return,strrpos($return,"/")+1);
	addnav("Pathway");
        addnav("Return to the store","charmstore.php");

 
page_footer();

?> 