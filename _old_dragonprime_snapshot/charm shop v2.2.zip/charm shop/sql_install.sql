ALTER TABLE accounts ADD bluepill int(11) unsigned not null default '0';
ALTER TABLE accounts ADD redpill int(11) unsigned not null default '0';
ALTER TABLE accounts ADD blackpill int(11) unsigned not null default '0';
ALTER TABLE accounts ADD charmstore tinyint(11) unsigned not null default '0';