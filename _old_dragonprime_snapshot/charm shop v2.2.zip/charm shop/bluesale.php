<?
require_once "common.php";


page_header("Wage Claim");
$bluepills=$session[user][bluepill]; 

if ($session['user']['bluepill']>9){ 
output(" `n`n`2`cRecieved your wage of `b`^5,000 gold`b`^ for `!`b10 blue pills`!`b...!`n"); 
$session[user][bluepill] -= 10; 
$session[user][gold] += 5000; 

    }else{ 
    output("`n`n`2You open up your box to find you only have `b$bluepills`b blue pills!`n"); 
    output("`@Im afraid you dont have enough pills for your wage, keep working..."); 
    output("`n`n"); 
} 


	$return = preg_replace("'[&?]c=[[:digit:]]+'","",$_GET[ret]);
	$return = substr($return,strrpos($return,"/")+1);
	addnav("Pathway");
        addnav("Return to the store","charmstore.php");

 
page_footer();

?> 