<?
require_once "common.php";


page_header("Charm Purchase");

if ($session['user']['gold']>4999){ 
output(" `n`n`2`b`cTraded 5000 gold for 5 charm points!`n"); 
$session[user][gold] -= 5000; 
$session[user][charm] += 5; 

    }else{ 
    output("`n`n`2You cannot afford this trade...`n"); 
    output("`n`n"); 
} 


	$return = preg_replace("'[&?]c=[[:digit:]]+'","",$_GET[ret]);
	$return = substr($return,strrpos($return,"/")+1);
	addnav("Pathway");
        addnav("Return to the store","charmstore.php");

 
page_footer();

?> 