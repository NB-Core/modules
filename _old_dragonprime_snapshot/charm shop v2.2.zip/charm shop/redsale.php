<?
require_once "common.php";


page_header("Wage Claim");
$redpills=$session[user][redpill]; 

if ($session['user']['redpill']>9){ 
output(" `n`n`2`cRecieved your wage of `b`^10,000`b gold`^ for `$`b10`b red pills`$...!`n"); 
$session[user][redpill] -= 10; 
$session[user][gold] += 10000; 

    }else{ 
    output("`n`n`2You open up your box to find you only have `b$redpills`b red pills!`n"); 
    output("`@Im afraid you dont have enough pills for your wage, keep working..."); 
    output("`n`n"); 
} 


	$return = preg_replace("'[&?]c=[[:digit:]]+'","",$_GET[ret]);
	$return = substr($return,strrpos($return,"/")+1);
	addnav("Pathway");
        addnav("Return to the store","charmstore.php");

 
page_footer();

?> 