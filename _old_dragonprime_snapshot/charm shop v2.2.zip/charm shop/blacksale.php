<?
require_once "common.php";


page_header("Wage Claim");
$blackpills=$session[user][blackpill]; 

if ($session['user']['blackpill']>9){ 
output(" `n`n`2`cRecieved your wage of `b`^20,000`b gold`^ for `&`b10`b black pills`&...!`n"); 
$session[user][blackpill] -= 10; 
$session[user][gold] += 20000; 

    }else{ 
    output("`n`n`2You open up your box to find you only have `b$blackpills`b black pills!`n"); 
    output("`@Im afraid you dont have enough pills for your wage, keep working..."); 
    output("`n`n"); 
} 


	$return = preg_replace("'[&?]c=[[:digit:]]+'","",$_GET[ret]);
	$return = substr($return,strrpos($return,"/")+1);
	addnav("Pathway");
        addnav("Return to the store","charmstore.php");

 
page_footer();

?> 