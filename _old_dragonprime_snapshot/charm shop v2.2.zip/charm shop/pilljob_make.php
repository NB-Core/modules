<?
require_once "common.php";


page_header("Working");

output("`c.:Working:.");
output("`n`n");
output("`^Welcome to the grand backstore workhouse, as you look around you see hundreds of other workers");
output("pouring precious charm and various other items into gold arrays, as you continue to watch");
output("you see then forwarding there ready made pots into a giant heating machine, it has a high flame");
output("and you feel the heat come off in your direction, just as you spot the pills coming from the reverse");
output("side of the machine, `!Mis `^spots you and comes over. What would you like to start with today?");
output("`c`n`n");
output("`@ She shows you a number of different machines and tells you what each one requires:");
output("`n`n");
output("`! Blue pills need:");
output("3 charm points`!");
output("`^2 Turns`^");
output("`n`n");
output("`$ Red pills need:");
output("5 charm points`!");
output("`^3 Turns`^");
output("`n`n");
output("`& Black pills need:");
output("`^10 charm points`!");
output("4 Turns`^");
output("`n`n");

if ($_GET[op]=="blue"){ 
   
output("`!`bCreated a Blue Pill!`b`!`n"); 
$session[user][charm] -= 3;
$session[user][turns] -= 2;
$session[user][bluepill] += 1;
} 

if ($_GET[op]=="red"){ 
   
output("`$`bCreated a Red Pill!`b`$`n"); 
$session[user][charm] -= 5;
$session[user][turns] -= 3;
$session[user][redpill] += 1; 
} 

if ($_GET[op]=="black"){ 
   
output("`&`bCreated a Black Pill!`&`b`n"); 
$session[user][charm] -= 10;
$session[user][turns] -= 4;
$session[user][blackpill] += 1;
} 

	$return = preg_replace("'[&?]c=[[:digit:]]+'","",$_GET[ret]);
	$return = substr($return,strrpos($return,"/")+1);
	addnav("Machines");
if ($session[user][charm]>=3)
if ($session[user][turns]>=2){
  addnav("Blue Machine","pilljob_make.php?op=blue");
}
if ($session[user][charm]>=5)
if ($session[user][turns]>=3){
  addnav("Red Machine","pilljob_make.php?op=red");
}
if ($session[user][charm]>=10)
if ($session[user][turns]>=4){
  addnav("Black Machine","pilljob_make.php?op=black");
}
if ($session[user][charm]<=3){
  addnav("You dont have enough charm to make any pills","charmstore.php");
}
if ($session[user][turns]<=2){
  addnav("You dont have enough turns to make any pills","charmstore.php");
}
	addnav("Pathway");
        addnav("Back to the store","charmstore.php");
 
page_footer();

?>