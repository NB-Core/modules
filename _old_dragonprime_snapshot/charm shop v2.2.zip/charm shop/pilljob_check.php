<?
require_once "common.php";


page_header("Your Box");

output("`c.:Your Box:.`c`n`n");
output("`%You peer down into your box and see:");
output("`n`n");
output("`! `bBlue Pills: `@".$session[user][bluepill]."`n"); 
output("`$ Red Pills: `@".$session[user][redpill]."`n"); 
output("`& Black Pills: `@".$session[user][blackpill]."`n"); 


	$return = preg_replace("'[&?]c=[[:digit:]]+'","",$_GET[ret]);
	$return = substr($return,strrpos($return,"/")+1);
	addnav("Updates");
        addnav("Back to the shop","charmshop.php");
 
page_footer();

?>