<?
require_once "common.php";


page_header("Wages For Pills");
$myname=$session[user][name]; 

output("`c`b.:Wages For Pills:.`c`b");
output("`n`n");
output("Hey $myname! `n`n So you wish to sell me some of your produce well lets see now...");
output("`n`n");
output("`@What would you like to sell today?");
output("`n`n");



	$return = preg_replace("'[&?]c=[[:digit:]]+'","",$_GET[ret]);
	$return = substr($return,strrpos($return,"/")+1);
	addnav("Wage Packet");
        addnav("Sell 10 blue pills","bluesale.php");
        addnav("Sell 10 red pills","redsale.php");
        addnav("Sell 10 black pills","blacksale.php");
	addnav("Updates");
        addnav("Back to the shop","charmshop.php");
 
page_footer();

?>