<?
require_once "common.php";


page_header("Pill Making Apply");

output("`c`b.:APPLIED!:.`b");
output("`n`n");
output("`^Apply form was sent to mis the love shop owner. `n`n`%He will send you an answer soon!");
output("`n`n");
$session[user][charmstore] = 1; 
systemmail($session['user']['acctid'],"`^Job Reply!`0","`%Congradulations!`n`n`@Your job appliance has been accepted`nvisit the love shop to start earning!`n`n`^Happy Working!!"); 


	$return = preg_replace("'[&?]c=[[:digit:]]+'","",$_GET[ret]);
	$return = substr($return,strrpos($return,"/")+1);
	addnav("Pathway");
        addnav("Back to the store","charmstore.php");
 
page_footer();

?>