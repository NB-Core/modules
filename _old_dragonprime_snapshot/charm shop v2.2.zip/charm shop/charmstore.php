<?
require_once "common.php";


page_header("Love Shop");

output("`c`b.:Love Shop:.`c`b");
output("`n`n");
output("`! 5,000 Gold for the Blue pill");
output("`n`n");
output("`$ 10,000 Gold for the Red pill");
output("`n`n");
output("`& 20,000 Gold for the Black pill");
output("`n`n");



	$return = preg_replace("'[&?]c=[[:digit:]]+'","",$_GET[ret]);
	$return = substr($return,strrpos($return,"/")+1);
	addnav("Table");
        addnav("Take the blue pill","charm_lock_buy5.php");
        addnav("Take the red pill","charm_lock_buy10.php");
        addnav("Take the black pill","charm_lock_buy20.php");
        addnav("Pathway");
        addnav("Back to the village","village.php");
	addnav("Job Options");
if ($session[user][charmstore]<=0){
  addnav("`bapply for a job`b","pilljob_apply.php");
}
if ($session[user][charmstore]>=1){
  addnav("`bMake some goods`b","pilljob_make.php");
}
if ($session[user][charmstore]>=1){
  addnav("`bYour Box`b","pilljob_check.php");
}
if ($session[user][charmstore]>=1){
  addnav("`bSell Your Goods`b","pilljob_sell.php");
} 



 
page_footer();

?>