<?php
/*
Module Name:  Heads Hunters
Category:  Forest Specials
Worktitle: Heads Hunter
Author:  Oberon FantasyItalia

Description:
Quest in foresta associata all'allineamento del personaggio
*/

function headhunters_getmoduleinfo(){
	$info = array(
		"name"=>"Heads Hunter",
		"version"=>"1.0",
		"author"=>"Oberon of 'Fantasy Italia'",
		"category"=>"Forest Specials",
		"download"=>"http://dragonprime.net/users/Oberon/headhunters.zip",
		"vertxtloc"=>"http://dragonprime.net/users/Oberon/",
		"settings"=>array(
			"huntername"=>"Nome del cacciatore,text|Cacciatore Oberon",
			"alignmin"=>"Punti Allineamento minimo per essere catturati, int|50",
			"weaponhunter"=>"Arma del cacciatore,text|Spadone pesantissimo",
			"attackhunter"=>"Attacco del cacciatore,int|50",
			"defensehunter"=>"Difesa del cacciatore,int|50",
			"hphunter"=>"Punti Ferita del cacciatore,int|100",
			"lvlhunter"=>"Livello del cacciatore,int|15",
		),
	);
	return $info;
}

function headhunters_install(){
	module_addeventhook("forest", "require_once(\"modules/headhunters.php\"); return 100;");
	return true;
}
function headhunters_uninstall(){
	return true;
}
function headhunters_dohook($hookname,$args){
	return $args;
}
function headhunters_runevent($type) {
	
	global $session;
	
	$from = "forest.php?";
	$session['user']['specialinc'] = "module:headhunters";
	$evil = "";
	$userid = $session['user']['acctid'];
	
	if (is_module_active('alignment')) {
  	$evil = get_module_pref('alignment','alignment',$userid);
	}

	$alignmin= get_module_setting("alignmin");

	$op = httpget('op');
	if ($op==""){
		
		if ($evil <> "" and $evil <= $alignmin) {
		
				$huntername= get_module_setting("huntername");
				output("`2Corri con agilit� tra le fronde della foresta in cerca di strane creature quando ad un tratto ti senti osservato.`n Guardi in alto, tra i rami di un albero, noti la presenza di una strana figura umana.`n");
				output("`2Noti che si tratta di un uomo dal volto coperto da una maschera nera... `n`n");
				output("`\$Il mio nome � %s... Nessuno conosce il mio volto. Sono un cacciatore di esseri malvagi, e noto con piacere che sei nella mia lista!`n`n", $huntername);
				output("`2Subito dopo, estrae una pesantissima spada e ti si pone davanti. `n");  
				
				addnav("Cacciatore di Taglie");
				addnav("Arrenditi","forest.php?op=arrest");
				addnav("Fuggi","forest.php?op=escape");
				addnav("Attacca!","forest.php?op=attackhu");

		} else {

				$huntername = get_module_setting("huntername");
				output("`2Corri con agilit� tra le fronde della foresta in cerca di strane creature quando ad un tratto ti senti osservato.`n Guardi in alto, tra i rami di un albero, noti la presenza di una strana figura umana.`n");
				output("`2Noti che si tratta di un uomo dal volto coperto da una maschera nera... `n`n");
				output("`\$Il mio nome � %s... Nessuno conosce il mio volto. Sono un cacciatore di esseri malvagi, ma noto con piacere che non sei nella mia lista!`n`n", $huntername);
				output("`2Subito dopo, estrae una pesantissima spada e ti si pone davanti. Ti saluta e scappa nel buio della foresta. `n`n");  
				
				
				output("`3Hai un totale di");
				output($evil);
				output("`3Punti Reputazione. `n");  
				
				
				addnav("Cacciatore di Taglie");
				addnav("Prosegui","forest.php?op=proshead");
		}
	
	} else if($op=="proshead") {
	
		$session['user']['specialinc']="";
		output("`@Provi a incamminarti nella stessa direzione di dove era andato il Cacciatore di Taglie quando noti `\$10 `@monete d'oro per terra.`n");
		output("`@Un foglietto accanto dice: `2'Per la tua onest�...'.`n`n");
	  $session['user']['gold'] = $session['user']['gold']+10;	
		
	} else if ($op=="attackhu") {
		
		$weaponhunter = get_module_setting("weaponhunter");
		$attackhunter = get_module_setting("attackhunter");
		$defensehunter = get_module_setting("defensehunter");
		$hphunter = get_module_setting("hphunter");
		$huntername = get_module_setting("huntername");
		$lvlhunter = get_module_setting("lvlhunter");
		
		$badguy = array(
		"creaturename"=>$huntername,
		"creaturelevel"=>$lvlhunter,
		"creatureweapon"=>$weaponhunter,
		"creatureattack"=>$attackhunter,
		"creaturedefense"=>$defensehunter,
		"creaturehealth"=>$hphunter,			
		"creatureexp"=>round($session['user']['level']*20, 0),			
		"diddamage"=>0,
		"type"=>"forest");
		$session['user']['badguy']=createstring($badguy);
		$op="fight";
		httpset('op', "fight");					
	
	} else if($op=="arrest") {
			
			output("`3Il tuo rimorso � pi� forte del tuo orgoglio! Chinando la testa ti inginocchi al tuo nemico e gli porgi le mani avanti.`n");
			
			// In Prigione
			set_module_pref("injail",1,"jail");
			addnav("In Prigione","runmodule.php?module=jail");
			
			$session['user']['specialinc'] = "";
	
	}	else if ($op=="escape") {
	
				$huntername= get_module_setting("huntername");
				output("`2Provi a fuggire e con un gesto fulmineo ti giri dalla parte opposta del tuo avversario e cominci a correre nei meandri della foresta.`n");
				output("`2Ma dopo alcune miglia, ti ritrovi nuovamente davanti a quello strano uomo che risponde a %s... !`n", $huntername);
				output("`2Ridendo verso di te ti sussura: `n`n");  
				output("`\$E' ora di combattere!!!! `n`n");
				addnav("Cacciatore di Taglie");
				addnav("Arrenditi","forest.php?op=arrest");
				addnav("Attacca!","forest.php?op=attackhu");
	}
	
	if ($op=="run"){
		//I gave you the chance to escape earlier, no turning back now
		output("`3Provi a fuggire, ma il tuo avversario ti blocca la strada!`n");
		$op="fight";
		httpset('op', "fight");			
	}
	
	if ($op=="fight"){ 
		$battle=true; 
	}
	
	if ($battle){		
		
		include("battle.php");	
		
		if ($victory){
			$goldreward = $session['user']['level']*45;
			$gemreward = e_rand(1,3);
			output("`n");
			output("`3Con un colpo finale, grazie alla tua $1 riesci a stendere il difficilissimo avversario.`n`n", $session['user']['weapon']);
			output("`3Cercando tra le sue spoglia, trovi `^%s monete d'oro `3 e", $goldreward);			
			if ($gemreward == 1){ output(" una `%gemma`2.`n`n", $gemreward);
			}else{ output(" `%%s gemme`2.`n`n",$gemreward); }
			$session['user']['gold']+=$goldreward;
			$session['user']['gems']+=$gemreward;
			$session['user']['experience']+=$badguy['creatureexp'];				
			output("`2Guadagni `3%s punti esperienza `2 dal combattimento.`n`n",$badguy['creatureexp']);
			set_module_pref("seenspook",1);
			$badguy=array();
			$session['user']['badguy']="";				
			$session['user']['specialinc'] = "";
			addnav("Ritorna in Foresta","forest.php");
			
		}else if ($defeat){	
			output("`n`3Non sei riuscito a batterlo e solo dopo che giaci tramortito per terra ti accorgi della sua forza.`n`n");
			output(" `3Ansimando provi ancora a rialzarti quando il Cacciatore ti solleva e ti porta in prigione.`n`n");
			addnews("`3%s `2� stato portato in prigione dal `3Cacciatore di Taglie `2nella Foresta oggi!", $session['user']['name']);
			
			// Perde tutto il denaro
			output("`#Perdi tutto il tuo denaro che viene devoluto in beneficenza!`n`n");
			$session['user']['gold']=0;
			
			// In Prigione
			set_module_pref("injail",1,"jail");
			addnav("In Prigione","runmodule.php?module=jail");
			
			$session['user']['specialinc'] = "";

		}else{

			fightnav(true,true);

		}
	}
}

function headhunters_run(){	
}

?>