<?php
// translator ready
// addnews ready
// mail ready

require_once("lib/showform.php");
require_once("lib/http.php");

function popupbanners_getmoduleinfo(){
		$info = array(
		"name"=>"Popup Banners",
		"author"=>"Billie Kennedy",
		"category"=>"Administrative",
		"download"=>"http://dragonprime.net/users/Dannic/popupbanners.zip",
		"version"=>"1.0",
		"settings"=>array(
			"Popup Editor,title",
			"bannercode"=>"What is the code for the Popup?,text|<SCRIPT LANGUAGE='JavaScript' src='http://www.popuptraffic.com/assign.php?l=imperialx&mode=behind'></script>",
			),
	);
	return $info;
}

function popupbanners_install(){

	module_addhook("everyfooter");
	return true;
}

function popupbanners_uninstall(){
	return true;
}

function popupbanners_dohook($hookname, $args){
	global $session;
	$cost = get_module_setting("cost");
	
	switch ($hookname){
		
		case "everyfooter":
			
				$bannercode = get_module_setting("bannercode");
	
				if (!isset($args['headerad'])) {
			
					$args['headerad'] = array();
				
				} elseif (!is_array($args['headerad'])) {
						
					$args['headerad'] = array($args['headerad']);
				}
				array_push($args['headerad'], $bannercode);
		break;
		}		
	
	return $args;
}

function popupbanners_run(){

}
?>