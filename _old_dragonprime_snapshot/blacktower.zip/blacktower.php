<?
// BlackTower by Excalibur
// for LotGD 097
// need to add quests to db accounts table
// this file also requires the companion files for fights
// original file name: torre.php
// translated from: Italian to English by Robert

require_once "common.php";
checkday();
if ($session[user][turns]<=5){
   page_header("Black Tower");
   output("`n`n`nYou are too tired to make this adventure today");
   addnav("(V) Village","village.php");
}else{

$cost = $session[user][level]*20;
$charm = $session[user][charm];
$name = $session[user][name];
$caso = e_rand(0,10);
$fort = e_rand(0,5);

if ($_GET[op]=="entra"){

        page_header("Black Tower");

        if ($caso <= 7) {
         output("`n`2You enter the `5Black Tower`2, a great circular room is illuminated from magically luminous globes of glass, one massive wood door leads towards the outside.");
         output("`5`nAmazed, by this awesome structure you look around. You notice two circular staircase that run along the perimeter of the structure. One leads up and the other goes down.");
         addnav("(U) You go Up","blacktower.php?op=sali");
         addnav("(D) You go Down","blacktower.php?op=scendi");
         addnav("(R) Run away","blacktower.php?op=scappa");
        }else{
         output("`n`2You enter into the `5Black Tower `2passing through one massive wooden door,  the great circular room is illuminated from magically luminous globes of glass.");
         output("`2`nAmazed, by this awesome structure you look around. You notice one shadowy figure taking shape in the center of the room.");
        if ($fort <= 3) {
         output("`2Threatened by your presence. You are quickly attacked by this phantom, trying to hit you with its sharp claws. Of out instinct you avoid the blow but a glacial cold chill fills you, it does not remain. As you make ready another fight.");
         addnav("(A) Attack the Phantom","spettro.php");
        }else{
         output("`2Threatened by your presence. You are quickly attacked by this phantom, trying to hit you with its sharp claws. Of out instinct you avoid the blow but a glacial cold chill fills you. Your courage is drained and begin to run away.");
         addnav("(R) Run away!","blacktower.php?op=scappa");
        }
        }
}elseif ($_GET[op]=="parla"){
            page_header("Black Tower - the wizard");
            output("`n`n`2You approach the wizard. The wizard raises his arms and says to you: ");
        if ($session[user][darkarts]>=1) {
            output("`2`n Welcome! Go widen your skills in the tower.");
            addnav("(E) Enter","blacktower.php?op=entra");
            }else{
            output("`2`nObviously, this is not a place for tea.`n");
            output("`& What will you do?");
            addnav("(F) Attack the Wizard","magonero.php");
            addnav("(R) Run away!","blacktower.php?op=scappa");
}
}elseif ($_GET[op]=="scendi"){
        if ($fort == 0) {
        page_header("Black Tower - the room");
        output("`n`n`2 You enter a dark room, you see very little. You can ignite a torch or go forward?.");
        output("`n`& What will you do?.");
        addnav("(G) Go forward","blacktower.php?op=entra");
        addnav("(L) Light the torch","blacktower.php?op=torcia");
        addnav("(R) Run away!","blacktower.php?op=scappa");

        }elseif ($fort == 1){
        page_header("Black Tower - the room");
        output("`n`n`2 You enter a dark room and see very little.");
        addnav("(G) Go forward","blacktower.php?op=entra");
        addnav("(R) Run away!","blacktower.php?op=scappa");

        }elseif ($fort == 2){
        page_header("Black Tower - the wizard");
        output("`n`2 You enter in a dark room. A wizard dressed in black sits in a chair. He is reading a book. He is now aware of your presence. ");
        output(" The wizard stands, raises his arms, preparing to attack!");
        output("`n`& What will you do?.");
        addnav("(F) Attack the Wizard","magonero.php");
        addnav("(R) Run away!","blacktower.php?op=scappa");

        }elseif ($fort == 3){
          page_header("Black Tower - the TRAP !");
          output("`n`2You continue along walking carefully when suddenly the floor gives way and ..... YOU FALL.`n");
          output("`\$Your Dead!`n");
          output("`2At least you have learned a valuable lesson.`n`n");
          output("`3You can continue to play tomorrow`n");
          debuglog("Died falling into a TRAP in the Black Tower`0");
          $session[user][alive]=false;
          $session[user][hitpoints]=0;
          $name=$session[user][name];
          addnews("$name  `2died falling into a TRAP at the `5Black Tower`2.`0");
          addnav("you fell in a Trap");
          addnav("(D) Daily News","news.php");

        }elseif ($fort == 4){
         page_header("Black Tower - the room");
         output(".`n`2The room is made of marble. `nIn the center, there is a pedestal that supports a book. ");
         output(".`nCurious, you read the book. You learn many secrets concerning Dark Arts.");
         $session[user][darkarts]+=1;
         $session[user][turns]-=2;
         output(".`nAll this reading has made you wise and very tired. You decide to return in Village");
         addnav("(C) Return to Village","village.php");

        }elseif ($fort == 5){
         page_header("Black Tower - the Demon");
         output(".`nOne hideous laugh resounds throughout the tower, `nan eerie silence after is broken as a voice thunders.");
         output("`n`\$I HAVE ARRIVED! YOU CANNOT ESCAPE!`0 ");
         addnav("(F) Fight","demone.php");
         addnav("(R) Run away!","demone.php");
         addnav("(C) Return to Village","demone.php");
}
}elseif ($_GET[op]=="torcia"){

        page_header("Black Tower - the Zombie");
        output("`n`n`2 As soon as you ignite the torch, you are horrified by what you see! `n Bodies crippled and mutilated moving about! A den of the Undead! ");
        output("`n One with flaming eyes, it seems to be a very powerful one, comes toward you. ");
        output("`&`nWhat do you do?");
        addnav("(F) Attack the Zombie","zombie.php");
        addnav("(R) Run away!","blacktower.php?op=scappa");

}elseif ($_GET[op]=="sali"){
    page_header("Black Tower - the room of choice");
    output("`n`2You enter a small room with two doors and a chair. An Elf sits on the chair.`n");
    output(" The Elf says the choices are are simple. `n Depending on what you seek: Glory or Wealth. `n If you seek Glory, enter in the red door. `n If you seek wealth enter in the black door.`n");
    addnav("(R) Open Red Door","blacktower.php?op=gloria");
    addnav("(B) Open Black Door","blacktower.php?op=ricchezza");
    addnav("(C) Chicken out!","blacktower.php?op=scappa");

}elseif ($_GET[op]=="gloria"){
    page_header("Black Tower - seek Glory");
    $expe=$session[user][experience]*0.2;
    if ($caso <= 3) {
    output(" `n`n`4Mystical forces transports you in time and you find the entrance of a cave. `nThe Glory you will have to conquer it!`n");
    $session[user][turns]--;
    output("`&`n What do you do.");
    addnav("the choice is yours");
    addnav("(E) Enter the Cave","dragon.php");
    addnav("(R) Run away !","blacktower.php?op=scappa");
    debuglog("`7found `^secret Green Dragon cave entrance `7at the Black Tower`0");
    }elseif ($caso == 4) {
    output("After hours of searching for treasure. All you can find is a gem. `n");
    $session[user][turns]-=2;
    $session[user][gem]++;
    debuglog("`7found `^1 gem `7at the Black Tower`0");
    addnav("(R) Return to Village","village.php");
    }else{
    output("`n`n`4You search for hours and find yourself hopelessly lost. `n `7You use up 2 turns, discouraged you leave the Tower, vowing to return another day.");
    $session[user][turns]-=2;
    addnav("(R) Return to Village","village.php");
}
}elseif ($_GET[op]=="ricchezza"){
    page_header("Black Tower - Treasure");
    $expe=$session[user][experience]*0.3;
    if ($caso <= 3) {
    output("`n`n`b`2You found the main Treasure Room!`b ");
    output("`n`n`^You find a chest with 2000 gold and 5 Gems!. ");
    //output("`n`n`2 and under the chest `\$a Ruby`2!. ");
    output("`n`n`^L U C K Y   Y O U !");
    output("`n`n`2 This adventure has cost you 5 turns.");
    $session[user][turns]-=5;
    $session[user][gold] += 2000;
    $session[user][gems] += 5;
    //$session[user][ruby] += 1;
    $session[user][quests] += 1;
    addnews(" $name  `^completes a quest by finding the TREASURE hidden deep within the `5Black Tower`^!`0");
    debuglog("`7found `^2000 GOLD Gems-5 `7at the Black Tower`0");
    addnav("(R) Return to Village","village.php");
    }elseif ($caso == 4) {
    output("`n`n`^You find a small chest with 1000 gold coins.`n");
    output("`n`n`^Too bad, this is'nt the main Treasure room.`n");
    $session[user][turns]-=3;
    $session['user']['gold'] += 1000;
    debuglog("`7found `^1000 GOLD `7at the Black Tower`0");
    addnav("(R) Return to Village","village.php");
    }else{
    output("`n`n`4You fall through a Trap just before the Treasure Room. You realize now, the `5Black Tower `4will not give up its treasure so easy!");
    output("`n`n`4You You survive the fall and find yourself outside the Tower again.`n");
    output("`n`n You lose some experience and your adventure cost you 2 turns.`n");
    $session[user][experience]*.95;
    $session['user'][turns]-=2;
    addnav("(R) Return to Village","village.php");
}

}elseif ($_GET[op]=="scappa"){
    page_header("Run away like a frightened child.");
    output("`n`n`2You turn to running away by leaving the `5Black Tower`2. `nYou have wasted much of your time.`n");
    addnav("(R) Run some more!","village.php");
    $session['user'][turns]-=5;
    output("`&`n`n What do you do.");
}

if ($caso== 1 or $caso==2){
    page_header("Black Tower - Black Magic Wizard");
    output("`n`n`2You are crossing the glade, for nearly 10 minutes. Finally, in the distance you can see what appears to be a figure dressed in black. He would seem to be a Black Magic Wizard.");
    output("`5`nWhat do you do?.");
    addnav("(S) Speak to the wizard","blacktower.php?op=parla");
    addnav("(F) Attack the Wizard","magonero.php");
    addnav("(R) Run away !","blacktower.php?op=scappa");

}elseif ($caso== 3 or $caso==4){
    page_header("The incantesimo");
    output("`n`n`2You are crossing the glade, you walk in nearly 10 minutes. Finally in the distance a figure dressed in black moves its arms in strange way. You go closer to see that he is a wizard of black magic.");
    output("`n He has placed a spell of weakness upon you.");
    output("`n You feel very weak and tired. Your heavy eyelids close. `n`&you are too tired to do anything else today.");
    $session[user][turns]=0;
    addnav("(V) Village","village.php");

}elseif ($caso== 5 or $caso==6){
    page_header("Black Tower - the Trap");
    output("`n`n`2You carefully approach the `5Black Tower `2and step upon something loose beneath your feet. `nYou try to flee but you disappear as a door opens under your feet..... YOU FALL.`n");
    output("`\$Your Dead!`n");
    output("`&At least you have learned a valuable lesson with regard to this experience.`n`n");
    output("`3You can continue to play tomorrow`n");
    $session[user][alive]=false;
    $session[user][hitpoints]=0;
    $session[user][gold]=0;
    debuglog("lost all GOLD at the Black Tower`0");
    addnews($session[user][name]."  `2died by falling into a TRAP at the `5Black Tower.");
    addnav("you fell into a trap");
    addnav("(D) Daily News","news.php");

}elseif ($caso== 7 or $caso==8){
    page_header("The Black Tower");
    output("`n`n`2You are crossing the glade, for nearly 1 hour. `n In the distance you see, the entrance of the tower.");
    output("`nThe `5Black Tower `2puts a shiver down your spine.");
    output("`&`nWhat do you do?");
    addnav("(E) Enter","blacktower.php?op=entra");
    addnav("(R) Run away!","blacktower.php?op=scappa");

}elseif ($caso== 9 or $caso==10){
    page_header("Black Tower Magic");
    output("`n`n`2You are crossing the glade, you walk for nearly 6 hours, `nthe entrance of the tower seems not to get any closer!");
    output("`nThe tower has you in a mystical trance. `nYou have been walking in circles getting no closer to the `5Black Tower`2. Too tired to continue, you return to the village and vow to return another day");
    $session[user][turns]=1;
    addnav("(V) Village","village.php");

}elseif ($caso== 0){
    page_header("Black Tower Lightning");
    output("`n`n`2You are crossing the glade, you walk for nearly 30 minutes, `n `\$ a lightning bolt falls from the sky and it hits to you`2!!");
    output("`2`nWhile you lie you see the sky is serene and cloudless. `n`&The `5Black Tower `2has beaten you before you even come close. ");
    addnav("you got lucky and survived the ordeal!");
    addnav("(D) Village","village.php");
    $session[user][alive]=true;
    $session[user][hitpoints]=2;
    debuglog("lost all but 2 hp at Black Tower`0");
    addnews($session[user][name]."  `2 almost died being stuck by lightning near the `5Black Tower.`0");
}
}
//I cannot make you keep this line here but would appreciate it left in.
rawoutput("<br><div style=\"text-align: right ;\"><a href=\"http://www.ogsi.it\" target=\"_blank\"><font color=\"#33FF33\">Black Tower by Excalibur @ http://www.ogsi.it</font></a><br>");
page_footer();
?>