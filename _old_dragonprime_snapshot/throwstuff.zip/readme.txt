****************************************************************
Name: Throw Produce
Author: Eth - ethstavern(at)gmail(dot)com 
Version: 1.1
Release Date: 12-24-2005
About: Readme file for throwstuff.zip
Files: throwstuff.php
***************************************************************

To install, drop into your modules directory and activate 
via the Modules Manager. 
