<?
require_once "common.php";
page_header("Market Place");

$itemtype=array(0=>"Unknown",1=>"Helm",2=>"Shield",3=>"Boots",4=>"Amulet",5=>"Ring",6=>"staff");

if ($HTTP_GET_VARS[op]==""){
output("Walking into the Market you see carts and hear the barkers trying to get you to buy their items.");
output("`c`^Your Items`0`c");
output("<table border=0 cellpadding=2 cellspacing=1>", true);
$sql="SELECT type, id, name, atkmod, defmod FROM inventory WHERE owner=".$session[user][acctid]."";
$result= db_query($sql) or die(db_error(LINK));
        for ($i=0;$i<db_num_rows($result);$i++){
                $row = db_fetch_assoc($result);
                if ($i==0){
                    output("<tr>",true);
                        output("<td>`bOptions`b</td><td>`bType/#`b</td>",true);
                        $itemstable = array("id"=>"`bItem#`b","name"=>"`bName`b","atkmod"=>"`bAtk Mod`b","defmod"=>"`bDef Mod`b");
                        while (list($key,$val)=each($row)){
                        	output("<td>$itemstable[$key]</td>", true);
								}
							output("</tr>",true);
                        reset($row);
                }
                output("<tr>",true);
                output("<td><a href='market.php?op=sell&item=$row[id]'>Sell</a></td>",true);
				  output("<td>{$itemtype[$row['type']]}</td>",true);
		         addnav("","market.php?op=sell&item=$row[id]");
                while (list($key,$val)=each($row)){
                        output("<td>$val</td>",true);
                }
                output("</tr>",true);
        }
        output("</table>",true);

output("`n`n");


output("`c`\$Items to buy`0`c");
output("<table border=0 cellpadding=2 cellspacing=1>", true);
$sql = "SELECT id, name, atkmod, defmod, type FROM inventory WHERE owner = '0' ";
        $res = db_query($sql);
        $row = db_fetch_assoc($res);
        
        output("<table>",true);
        $sql = "SELECT type, id, name, atkmod, defmod FROM inventory WHERE owner = '0' ORDER BY type";
        $result= db_query($sql) or die(db_error(LINK));
        for ($i=0;$i<db_num_rows($result);$i++){
                $row = db_fetch_assoc($result);
                if ($i==0){
                        output("<tr>",true);
                        output("<td>`bOptions`b</td><td>`bType/#`b</td>",true);
                        $itemstable = array("id"=>"`bItem#`b","name"=>"`bName`b","atkmod"=>"`bAtk Mod`b","defmod"=>"`bDef Mod`b");
                        while (list($key,$val)=each($row)){
                                output("<td>$itemstable[$key]</td>",true);
                        }
                        output("</tr>",true);
                        reset($row);
                }
                output("<tr>",true);
                output("<td><a href='market.php?op=buy&item=$row[id]'>Buy</a></td>",true);
				  output("<td>{$itemtype[$row['type']]}</td>",true);
                addnav("","market.php?op=buy&item=$row[id]");
                while (list($key,$val)=each($row)){
                        output("<td>$val</td>",true);
                }
                output("</tr>",true);
        }
        output("</table>",true);

addnav("Back to the Village","village.php");
}

if ($HTTP_GET_VARS[op]=="sell"){
page_header("Sell");
$sql = "SELECT  gold, gems, name, id FROM inventory WHERE id='$_GET[item]'";
$result = db_query($sql);
$row = db_fetch_assoc($result);
$sellgold = round(($row[gold]*.8),0);
$sellgems = round(($row[gems]*.7),0);
output("Do you wish to sell your $row[name] for");
output("`^$sellgold `0gold and `^$sellgems `0gems?`n`n`n");
output("<a href='market.php?op=yes&item=$row[id]' onClick='return confirm(\"Are you sure you want to sell this Item?\");'>Yes</a>", true); 
output("<a href='market.php?'>No</a>", true);
addnav("","market.php?op=yes&item=$row[id]");
addnav("","market.php?");
}

if ($HTTP_GET_VARS[op]=="yes"){
page_header("Sell");
$sql = "SELECT gold, gems, name, id FROM inventory WHERE id='$_GET[item]'";
$result = db_query($sql);
$row = db_fetch_assoc($result);
$sellgold = $row[gold]*.8;
$sellgems = $row[gems]*.7;
output("Eager for your `^$row[name] `0the merchant holds out his hand. As promised he gives you `^$sellgold`0 gold and `^$sellgems `0gems for your `^$row[name]`0`n`n");
output("Holding your new small fortune you got for your $row[name] you ponder on wheather or not to spend it right away.");

$session[user][gold]+="$sellgold";
$session[user][gold]+="$sellgems";
$sql="UPDATE inventory SET owner = '0' WHERE id='$_GET[item]' ";
$result = db_query($sql);
addnav("Back to the Market","market.php");
}

if ($HTTP_GET_VARS[op]=="buy"){
page_header("Sell");
$sql = "SELECT  gold, gems, name, id FROM inventory WHERE id='$_GET[item]'";
$result = db_query($sql);
$row = db_fetch_assoc($result);
output("Do you wish to buy the $row[name] for");
output("`^$row[gold] `0gold and `^$row[gems] `0gems?`n`n`n");
if ($session[user][gold]>="$sellgold" && $session[user][gems]>="$sellgems"){
output("<a href='market.php?op=sure&item=$row[id]' onClick='return confirm(\"Are you sure you want to buy this Item?\");'>Yes</a>", true);
}else {

output("`nSorry me lad, but it seems as you dont have enough to buy this `^$row[name]`7."); }
output("<a href='market.php?'>No</a>", true);
addnav("","market.php?op=sure&item=$row[id]");
addnav("","market.php?");
}
if ($HTTP_GET_VARS[op]=="sure"){
page_header("Sell");
$sql = "SELECT gold, gems, name, id FROM inventory WHERE id='$_GET[item]'";
$result = db_query($sql);
$row = db_fetch_assoc($result);
if ($session['user']['gold']>=$row[gold] && $session['user']['gems']>=$row[gems]){
output("Eager for your `^$row[name] `0you hold out your hand. As promised, you give him `^$row[gold]`0 gold and `^$row[gems] `0gems for his `^$row[name]`0`n`n");
output("Holding your new $row[name] you ponder on whether or not it was a good idea.");
$session['user']['gold']-="$row[gold]";
$session['user']['gems']-="$row[gems]";
$sql="UPDATE inventory SET owner = ".$session['user'][acctid]." WHERE id='$_GET[item]' ";
$result = db_query($sql);
addnav("Back to the Market","market.php");
}
else{
output("Ummm..I think you aren't rich enough to do this, come back later.");
addnav("Back to the Market","market.php");}
}
page_footer();
?>
