<?
require_once "common.php";
page_header ("Items Editor");

$item = (int)$_GET[item];

addnav("Add a new Item","itemedit.php?op=add&item=$item");
addnav("Items Main","itemedit.php");
addnav("Other");
addnav("Village","village.php");
addnav("Grotto","grotto.php");
output("`nItem type numbers, use the numbers in the field not the name.`n");
output("1=>Helm`n2=>Shield`n3=>Boots`n4=>Amulet`n5=>Ring`n6=>staff");
if($HTTP_GET_VARS[op]=="") {
$sql = "SELECT id, name, atkmod, defmod, type, owner, startmsg, effectmsg, roundmsg FROM inventory";
        $res = db_query($sql);
        $row = db_fetch_assoc($res);
output("<table>",true);
$sql = "SELECT id, name, atkmod, defmod, type, owner, startmsg, effectmsg, roundmsg FROM inventory ORDER BY id";

$result= db_query($sql) or die(db_error(LINK));
        for ($i=0;$i<db_num_rows($result);$i++){
                $row = db_fetch_assoc($result);
                $id = $row[id];
					if ($i==0){ 
output("<tr><td>Options</td>",true);
$itemlist = array("id"=>"`bitem#`b","name"=>"`bItem Name`b","owner"=>"`bOwner`b","atkmod"=>"`bAttack Mod`b","defmod"=>"`bDefence Mod`b","effectmsg"=>"`bEffect Msg`b","roundmsg"=>"`bRound Msg`b","startmsg"=>"`bStart Msg`b","type"=>"`bType`b");
while (list($key,$val)=each($row)){

output("<td>$itemlist[$key]</td>",true); }
output("</tr>",true);
reset($row); }
output("<tr><td><a href='itemedit.php?op=edit&item=$id'>Edit</a>-<a href='itemedit.php?op=del&item=$id' onClick='return confirm(\"Delete this Item?\");'>Delete</a></td>",true);

addnav("","itemedit.php?op=edit&item=$id");
addnav("","itemedit.php?op=del&item=$id");

while (list($key,$val)=each($row)){
output("<td>$val</td>",true); }
output("</tr>",true); }
output("</table>",true);}

if ($HTTP_GET_VARS[op]=="edit") {
$sql = "SELECT * FROM inventory WHERE id='$_GET[item]'";
                $result = db_query($sql);
                $row = db_fetch_assoc($result);
$itemform=array(
        "Item Edit,title",
        "name"=>"Name",
        "atkmod"=>"Attack Mod",
        "defmod"=>"Defence Mod",
        "gold"=>"Amount Gold",
		 "gems"=>"Amount Gems",
		 "startmsg"=>"Start Msg",
		 "effectmsg"=>"Effect Msg",
		 "roundmsg"=>"Round Msg",
		 "type"=>"Type",
		 "owner"=>"Owner ID",
		 "Item Edit,title");
output("<form action='itemedit.php?op=update&item=$item' method='POST'>",true);
showform($itemform,$row);
output("</form>",true);
addnav("","itemedit.php?op=update&item=$item");
}

if ($HTTP_GET_VARS[op]=="add") {
$sql = "SELECT * FROM inventory WHERE id='$_GET[item]'";
                $result = db_query($sql);
                $row = db_fetch_assoc($result);
$itemaddform=array(
        "Item Add,title",
        "name"=>"Name",
        "atkmod"=>"Attack Mod",
        "defmod"=>"Defence Mod",
        "gold"=>"Amount Gold",
		 "gems"=>"Amount Gems",
           "startmsg"=>"Start Msg",
		 "effectmsg"=>"Effect Msg",
		 "roundmsg"=>"Round Msg",
		 "type"=>"Type",
		 "owner"=>"Owner ID",
		 "Item Add,title");
output("<form action='itemedit.php?op=save&item=$item' method='POST'>",true);
showform($itemaddform,$row);
output("</form>",true);
addnav("","itemedit.php?op=save&item=$item");
}

if ($HTTP_GET_VARS[op]=="save"){
				   $sql = "INSERT INTO inventory (name, owner, type, startmsg, roundmsg, effectmsg, atkmod, defmod, gold, gems) VALUES (\"$_POST[name]\",\"$_POST[owner]\",\"$_POST[type]\",\"$_POST[startmsg]\",\"$_POST[roundmsg]\",\"$_POST[effectmsg]\",\"$_POST[atkmod]\",\"$_POST[defmod]\",\"$_POST[gold]\",\"$_POST[gems]\")";
db_query($sql);
redirect("itemedit.php?");
}

if ($HTTP_GET_VARS[op]=="update"){

//$sql = "DELETE FROM inventory WHERE id='$row[id]'";
//db_query($sql);

$sql = "UPDATE inventory SET id=\"$_GET[item]\",name=\"$_POST[name]\",type=\"$_POST[type]\",atkmod=\"$_POST[atkmod]\",defmod=\"$_POST[defmod]\",startmsg=\"$_POST[startmsg]\",roundmsg=\"$_POST[roundmsg]\",effectmsg=\"$_POST[effectmsg]\",owner=\"$_POST[owner]\",gold=\"$_POST[gold]\",gems=\"$_POST[gems]\" WHERE id='$_GET[item]'";
db_query($sql);
redirect("itemedit.php?");
}


if ($HTTP_GET_VARS[op]=="del"){
$sql = "DELETE FROM inventory WHERE id='$_GET[item]'";
db_query($sql);
redirect("itemedit.php?"); }

page_footer();
?>