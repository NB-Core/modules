<?php

function integra_getmoduleinfo(){
	$info = array(
		"name"=>"Integra the Tailor",
		"author"=>"Chris Vorndran",
		"version"=>"0.1",
		"category"=>"Village",
		"download"=>"http://dragonprime.net/index.php?module=Downloads;sa=dlview;id=24",
		"vertxtloc"=>"http://dragonprime.net/users/Sichae/",
		"description"=>"Allows a user to be able to spend a certain amount of Gems, in order to change their weapon/armor name. Doesn't stick, this is deliberate.",
		"settings"=>array(
			"Integra the Tailor Settings,title",
			"cost"=>"Cost `iin gems`i for Weapon/Armor Name,int|5",
			"mindk"=>"What is the minimum DK before this shop will appear to a user?,int|0",
			"integraloc"=>"Where does Integra appear,location|".getsetting("villagename", LOCATION_FIELDS)
		),
		"prefs"=>array(
			"Integra the Tailor Prefs,title",
			"weapon"=>"What is this user's weapon name,text|",
			"armor"=>"What is this user's armor name,text|",
		)
		);
	return $info;
}
function integra_install(){
	module_addhook("village");
	module_addhook("changesetting");
	return true;
}
function integra_uninstall(){
	return true;
}
function integra_dohook($hookname,$args){
	global $session;
	switch ($hookname){
		case "village":
			if ($session['user']['location'] == get_module_setting("integraloc")
			&& $session['user']['dragonkills'] >= get_module_setting("mindk")) {
				tlschema($args['schemas']['marketnav']);
		        addnav($args['marketnav']);
				tlschema();
		        addnav("Integra's Tailoring","runmodule.php?module=integra&op=enter");
			}
			break;
		case "changesetting":
			if ($args['setting'] == "villagename") {
				if ($args['old'] == get_module_setting("integraloc")) {
			        set_module_setting("integraloc", $args['new']);
			    }
			}
	    	break;
		}
	return $args;
}
function integra_run(){
	global $session;
	$op = httpget('op');
	$cost = get_module_setting("cost");
	$armor = $session['user']['armor'];
	$weapon = $session['user']['weapon'];
	$arm = httppost('arm');
	$weap = httppost('weap');
	page_header("Integra's Tailoring");

	switch ($op){
		case "enter":
			if ($session['user']['gems'] >= $cost){
				output("`qYou wander into a nice, cozy den.");
				output(" Off in the distance, you can hear the soft mewing of baby foxes.");
				output(" A tall figure walks out from the shadows and casts a glare upon you.");
				output(" His eyes are a deep orange color, and the gaze pierces your inner depths.");
				output(" He chuckles a bit and pulls his tail into his hands and wrings it softly.`n`n");
				output("He looks at you and smiles, \"`QWhy are you present in my den?");
				output(" Is it that you wish to have something tailored for you?`q\"`n`n");
				output("He eyes your %s `qand your %s `qwarily.",$weapon, $armor);
				output(" Integra then points to them and smiles, \"`QDo you wish for me to tailor those for you?`q\"");
				output(" His voice has a soothing quality to it, and you grow euphoric.");
				output(" He points to a sign saying, \"`QAll Deals Cost `%%s `QGems`q\"",$cost);
				addnav(array("Tailor: %s",$weapon),"runmodule.php?module=integra&op=weapon");
				addnav(array("Tailor: %s",$armor),"runmodule.php?module=integra&op=armor");
			}else{
				output("`qIntegra eyes you warily and points a furry finger towards the door.");
				output(" He says in a low growl, \"`QPlease come back when you have at least `%%s `Qgems.`q\"",$cost);
				output(" He then flashes his fangs at you and growls louder, barking at you.");
				output(" You run off scared into the corner.");
			}
				break;
		case "weapon":
			if ($weap == ""){
				output("`qIntegra looks at you and then to your %s`q.",$weapon);
				output(" He strides over and picks it up, then walks off into the back of the den.`n`n");
				output("\"`QYou may play with my children if you wish...`q\" he calls back in a soft voice.");
				output("You walk over to the small pups and stroke them softly.");
				integra_foxes();	
				output("`qIntegra calls back to you, \"`QWhat do you wish to engrave on your %s`Q?`q\"",$weapon);
				rawoutput("<form action='runmodule.php?module=integra&op=weapon' method='POST'>");
                output("`^New Name:");
                rawoutput("<input id='input' name='weap' value='".get_module_pref("weapon")."' width=5> <input type='submit' class='button' value='".translate_inline("Rename")."'>");
                rawoutput("</form>");
                output("<script language='javascript'>document.getElementById('input').focus();</script>",true);
                addnav ("", "runmodule.php?module=integra&op=weapon");
			}else{
				output("`qIntegra walks back and hands your %s `qback to you.",$armor);
				output(" You look upon the side and read, \"%s`q.\"",$weap);
				output(" `qYou shake Integra's hand, smile, and hands him `%%s`q gems.",$cost);
				output(" You turn around and walk out of the shoppe, smiling happily.");
				$session['user']['gems']-=$cost;
				$session['user']['weapon']=$weap."`0";
			}
			break;
		case "armor":
			if ($arm == ""){
				output("`qIntegra looks at you and then to your %s`q.",$armor);
				output(" He strides over and picks it up, then walks off into the back of the den.`n`n");
				output("\"`QYou may play with my children if you wish...`q\" he calls back in a soft voice.");
				output("You walk over to the small pups and stroke them softly.");
				integra_foxes();	
				output("`qIntegra calls back to you, \"`QWhat do you wish to engrave on your %s`Q?`q\"",$armor);
				rawoutput("<form action='runmodule.php?module=integra&op=armor' method='POST'>");
                output("`^New Name:");
                rawoutput("<input id='input' name='arm' value='".get_module_pref("armor")."' width=5> <input type='submit' class='button' value='".translate_inline("Rename")."'>");
                rawoutput("</form>");
                output("<script language='javascript'>document.getElementById('input').focus();</script>",true);
                addnav ("", "runmodule.php?module=integra&op=armor");
			}else{
				output("`qIntegra walks back and hands your %s `qback to you.",$weapon);
				output(" You look upon the side and read, \"%s`q.\"",$arm);
				output(" You shake Integra's hand, smile, and hands him `%%s `qgems.",$cost);
				output(" You turn around and walk out of the shoppe, smiling happily.");
				$session['user']['gems']-=$cost;
				$session['user']['armor']=$arm."`0";
			}
			break;
	}
	villagenav();
page_footer();
}
function integra_foxes(){
	global $session;
	$hploss = $session['user']['level'];
	$goldloss = $session['user']['level']*$session['user']['dragonkills'];
		switch (e_rand(1,3)){
			case 1:
				output("`n`n`qOne of them steals `^%s `qgold from you.`n`n",$goldloss);
				$session['user']['gold']-=$goldloss;
				break;
			case 2:
				output("`n`n`qOne of them scratches your nose.`n`n");
				output(" You lost `\$%s `qhitpoints.",$hploss);
				$session['user']['hitpoints']-=$hploss;
				break;
			case 3:
				output("`n`n`qOne of them rubs up against you, leaving some small fluffballs on you.`n`n");
					if (isset($session['bufflist']['fox'])) {
						$session['bufflist']['fox']['rounds'] += 5;
					}else{
						apply_buff('fox',
							array(
								"name"=>"`QFox Fluffballs",
								"rounds"=>10,
								"wearoff"=>"`QThe fluffballs are slowly blown off.",
								"defmod"=>1.05,
								"roundmsg"=>"The fluffballs make you feel fuzzy inside!",
								"schema"=>"module-integra",
								)
							);
					}
					break;
		}
}
?>