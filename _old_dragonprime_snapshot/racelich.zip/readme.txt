-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
Race - Lich - A module for Legend of the Green Dragon 1.0.3

Legend of the Green Dragon
by  Eric "MightyE" Stevens (http://www.mightye.org)
and JT "Kendaer" Traub (http://www.dragoncat.net)

Software Project Page:
http://sourceforge.net/projects/lotgd

Modification Community Page:
http://dragonprime.net

Author of this Module:
Original Author - Sneakabout
Altered by - Enderandrew (enderandrew@gmail.com)

Enderandrew's LoGD game:
http://enderandrew.com/lotgd/

Download the latest version of this module from:
http://dragonprime.net/index.php?action=viewfiles&user=enderwiggin

----------------------------------------------
-- STATUS: -----------------------------------
----------------------------------------------
This module is STABLE.

----------------------------------------------
-- INFORMATION: ------------------------------
----------------------------------------------
This is Sneakabout's module.  I've altered what city the Liches
live in, and made some rather minute changes.  I thought some of the
cities were getting cramped, so I moved the Liches in with the evil
Vampires.  I don't advertise this module, because I'm not trying to
suggest people should run this one rather than Sneakabout's
version.

This version of the module will only run with version 1.0.3 or later
of LotGD.

Hope you enjoy!

----------------------------------------------
-- INSTALLATION: -----------------------------
----------------------------------------------
Copy the racelich.php file within this zip into your modules
directory.

Login to the Superuser Grotto and Install / Activate it.

-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-


