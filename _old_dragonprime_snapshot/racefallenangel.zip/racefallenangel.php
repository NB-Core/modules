<?php
/*
Sir Arvex; � 2005
Erstmalig auf Anagromataf.de erschienen
Bugs und Fehler an arvex@anagromataf.de
*/
function racefallenangel_getmoduleinfo(){
   	$info = array(
        	"name"=>"Race - Gefallener Engel",
        	"version"=>"1.10",
        	"author"=>"`)Arvex",
        	"category"=>"Races",
        	"download"=>"http://www.arvex.de/index.php?showforum=3",
        	"requires"=>array(
				"racevamp"=>"1.1 |By Chris Vorndran http://dragonprime.net/users/Sichae/racevamp.zip",
				"alignment" => "1.6 | WebPixie `#Lonny Luberts `^and Chris Vorndran, http://dragonprime.net/users/Sichae/alignment.zip"
				),
        	"settings"=>array(
            		"Gefallener Engel Einstellungen,title",
            		"mindk"=>"Wieviele DKs erfoderlich um die Rasse w�hlen zu k�nnen?,int|25",
			"cost"=>"Wieviele Donationpoints erforderlich um die Rasse w�hlen zu k�nnen?,int|1000",
            		"minedeathchance"=>"Chance f�r Gefallener Engel in der Mine zu sterben,range,0,100,1|55",
            		"goldloss"=>"Wieviel weniger Dukaten findet ein Gefallener Engel (prozentual) ?,range,5,25,1|10",
			"creaturexp"=>"Wieviel mehr an Erfahrung erhalten Gefallene Engel (prozentual) ?,floatrange,1,10,.5|5",
			"gemchance"=>"Chance f�r Gefallener Engel einen Edelstein pro neuen Tag zu finden,range,0,10,1|2",
			"gemmessage"=>"Nachricht f�r finden eines Edelsteins|`)Deine verk�mmerten engelhaften Sinne bemerken `\$einen Edelstein `)in deiner N�he!",
			"creaturehp"=>"Um wieviel Prozent haben Gegner weniger Lebenspunkte?,range,1,9,1|5",
			"randhp"=>"Um wieviel Prozent werden die Lebenspunkte bei neuen Tag tempor�r erh�ht?,floatrange,0,100,.25|22.5",
			"align"=>"Wieviel an Gesinnung mu� man haben um tempor�re Lebenspunkte zu erhalten?,int|67",
			"hpheal"=>"Um wieviel Prozent werden Gefallene Engel nach einen Kampf geheilt,range,0,10,1|5",
			"Gefallene Engel heilen sich selbst um den angegebenen Prozentsatz wenn die Lebenspunkte kleiner gleich 75% der maximalen Lebenspunkte sind.,note",
			),
       	 );
   	 return $info;
}

function racefallenangel_install(){
		include("modules/arvex/racefallenangel/racefallenangel_install.php");
		}

function racefallenangel_uninstall(){
		include("modules/arvex/racefallenangel/racefallenangel_uninstall.php");
}

function racefallenangel_dohook($hookname,$args){
    	global $session,$resline;
    	if (is_module_active("racevamp")) {
		$city = get_module_setting("villagename", "racevamp");
	} else {
		$city = getsetting("villagename", LOCATION_FIELDS);
	}
	
	if (is_module_active('alignment')) 
    	{
		$al = get_align();
	}
    	include("modules/arvex/racefallenangel/racefallenangel_dohook.php");
	$race = "Gefallener Engel";	
    	switch($hookname){
    		case "racenames":
			$args[$race] = $race;
   			 break;
    		case "pointsdesc":
    			include("modules/arvex/racefallenangel/racefallenangel_pointsdesc.php");
			break;
    		case "raceminedeath":
    			include("modules/arvex/racefallenangel/racefallenangel_raceminedeath.php");
        		break;
    		case "charstats":
    			include("modules/arvex/racefallenangel/racefallenangel_charstats.php");
       			break;
     		case "chooserace":
     			include("modules/arvex/racefallenangel/racefallenangel_chooserace.php");
        		break;
    		case "setrace":
    			include("modules/arvex/racefallenangel/racefallenangel_setrace.php");
        		break;
    		case "newday":
    			include("modules/arvex/racefallenangel/racefallenangel_newday.php");
			break;
    		case "battle-victory":
    			include("modules/arvex/racefallenangel/racefallenangel_battle-victory.php");
			break;
    		case "battle-defeat":
    			include("modules/arvex/racefallenangel/racefallenangel_battle-defeat.php");
			break;
    		case "creatureencounter":
    			include("modules/arvex/racefallenangel/racefallenangel_creatureencounter.php");
        		break;
    		case "pvpadjust":
    			include("modules/arvex/racefallenangel/racefallenangel_pvpadjust.php");
			break;
    		}
    	return $args;
}

function racefallenangel_checkcity(){
    	global $session;
    	$race="Gefallener Engel";
    	include("modules/arvex/racefallenangel/racefallenangel_checkcity.php");
    	return true;
}

function racefallenangel_run(){
}
?>