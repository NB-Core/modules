<?php
if ($session['user']['race']==$race){
            		racefallenangel_checkcity();
            		$exp = (100 + $creaturexp)/100;
            		$args['creatureexp']=round($args['creatureexp']*$exp,0);
            		$loss = (100 - $creaturegold)/100;
	    		$args['creaturegold']=round($args['creaturegold']*$loss,0);
        		}
?>