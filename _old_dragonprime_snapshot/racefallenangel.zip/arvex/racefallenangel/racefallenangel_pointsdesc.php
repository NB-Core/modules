<?php
if ($mindk > 0 || $cost > 0)
			{
			$args['count']++;
			$format = $args['format'];
			$str = translate_inline("`)Die Rasse `\$Gefallener Engel`) ist ab %s DKs und %s Donationpoints verf�gbar.");
			$str = sprintf($str, $mindk, $cost);
			output($format, $str, true);
			}
?>