<?php
$amnt = $session['user']['donation']-$session['user']['donationspent'];
			if ($session['user']['dragonkills'] >= $mindk && $amnt >= $cost)
			{
        		output("<a href='newday.php?setrace=$race$resline'>In der Umgebung von %s</a>`), ist die verborgene Heimat der `\$gefallenen Engel`). Von den G�ttern abstammend, sich gegen diese auflehnend wurden die ehemaligen Engel versto�en und auf Ewig aus dem Himmelreich verbannt.`n`n",$city,true);
        		addnav("`\$Gefallener Engel`0","newday.php?setrace=$race$resline");
        		addnav("","newday.php?setrace=$race$resline");
        	}
?>