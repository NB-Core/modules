<?php
if (!is_module_installed("racevamp")) {
			output("Die Gefallenen Engel leben nur mit den Vampiren zusammen. Du mu�t dieses Rassen Modul installieren.");
		return false;
		}
		if (is_module_active("alignment"))
		{
		if (!is_module_active("racefallenangel"))
		{
			output("Installiere Rasse - Gefallener Engel Modul.`n");
		}
		else
		{
			output("Aktualisiere Rasse - Gefallener Engel Modul.`n");
		}
		}
		else
		{
		output("Alignment Modul nicht installiert - Rasse Gefallener Engel wurde nicht installiert!`n");
		return false;
		}
		module_addhook("battle-victory");
		module_addhook("battle-defeat");
    		module_addhook("chooserace"); 
    		module_addhook("creatureencounter"); 
		module_addhook("setrace"); 
		module_addhook("newday"); 
		module_addhook("charstats"); 
		module_addhook("raceminedeath"); 
		module_addhook("pvpadjust"); 
		module_addhook("racenames"); 
		module_addhook("pointsdesc");
    	return true;
?>