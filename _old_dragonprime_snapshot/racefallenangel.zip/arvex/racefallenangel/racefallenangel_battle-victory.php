<?php
if ($session['user']['race'] == $race) {
				if ($session['user']['hitpoints'] < ($session['user']['maxhitpoints']*0.75)) {
				$heal = round($session['user']['maxhitpoints']/100*$hpheal);
				$session['user']['hitpoints']+=$heal;
				output("`)Deine Lebenspunkte regenerieren sich um `\$%s`).`n",$heal); 
				}
			}
?>