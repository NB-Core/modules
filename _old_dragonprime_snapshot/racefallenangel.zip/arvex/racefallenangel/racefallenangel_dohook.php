<?php
    	$cost = get_module_setting("cost");
    	$mindk = get_module_setting("mindk");
    	$minedeath = get_module_setting("minedeathchance");
    	$hpheal = get_module_setting("hpheal");
    	$gemchance = get_module_setting("gemchance");
	$message = get_module_setting("gemmessage");
	$creaturexp = get_module_setting("creaturexp");
	$creaturegold = get_module_setting("goldloss");
	$creaturehp = get_module_setting("creaturehp");
	$align = get_module_setting("align");
	$tmphp = get_module_setting("randhp");
?>