<?php
if ($session['user']['race'] == $race) {
            		$args['chance'] = $minedeath;
            		$args['racesave'] = "`)Gl�cklicherweise lassen dich deine verk�mmerten engelhaften Sinne unverletzt entkommen.`n";
            		$args['schema'] = "module-racefallenangel";
        		}
?>