<?php
if ($session['user']['race']==$race){
            		addcharstat("Dein Profil");
            		addcharstat("Rasse", $race);
        		}
?>