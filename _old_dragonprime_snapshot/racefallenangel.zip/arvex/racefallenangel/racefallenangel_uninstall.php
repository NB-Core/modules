<?php
global $session;
		$sql = "UPDATE  " . db_prefix("accounts") . " SET race='" . RACE_UNKNOWN . "' WHERE race='Gefallener Engel'";
		db_query($sql);
		if ($session['user']['race'] == 'Gefallener Engel')
		    $session['user']['race'] = RACE_UNKNOWN;
	return true;
?>