<?php
if ($args['race'] == $race) {
			$args['creaturedefense']+=(1+floor($args['creaturelevel']/5));
			$args['creatureattack']+=(1+floor($args['creaturelevel']/3));
			$creathit = $creaturehp/100;
			$args['creaturehealth']-= round($args['creaturehealth']*$creathit, 0);
			}
?>