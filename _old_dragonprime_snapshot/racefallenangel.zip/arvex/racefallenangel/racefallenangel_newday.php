<?php
if ($session['user']['race']==$race){
				racefallenangel_checkcity();
				apply_buff("racialbenefit",array(
					"name"=>"`)Engelhafte Sinne`0",
					"defmod"=>"(<defense>?(1+((1+floor(<level>/5))/<defense>)):0)",
                        		"atkmod"=>"(<attack>?(1+((1+floor(<level>/3))/<attack>)):0)",
					"allowinpvp"=>1,
					"allowintrain"=>1,
					"rounds"=>-1,
					"schema"=>"module-racefallenangel",
					)
				);
			if ($session['user']['level'] < 15 && e_rand(1,100) <= $gemchance ) {
			output("`)%s`n`0", $message);
			$session['user']['gems']++;
			debuglog("erhielt einen Edelstein von den G�ttern.");
			}
			if ($al > $align) {
				$hpbonus = round($session['user']['maxhitpoints']*$tmphp)/100;
				$session['user']['hitpoints']+=$hpbonus;
				output("`n`)Du bist Ehrbar genug, um von den G�ttern einen Segen zu erhalten.`n");
			}
			else {
			output("`n`)Du bist zu `4B�se`) um einen g�ttlichen Segen zu erhalten.`n");
			output("`)Deswegen strafen dich die G�tter f�r deine Vergehen.`n");
			$hpbonus = round($session['user']['maxhitpoints']*$tmphp)/100;
				$session['user']['hitpoints']-=$hpbonus;
			}			
			}
?>