<?php
if ($session['user']['race']==$race){
            		output("`)Als `\$Gefallener Engel`), hast du noch verk�mmerte engelhafte Sinne.`n`)Du erahnst die Bewegungen deiner Gegner im Vorraus!");
            		if (is_module_active("cities")) {
                		if ($session['user']['dragonkills']==0 && $session['user']['age']==0){
                    			set_module_setting("newest-$city",
                        		$session['user']['acctid'],"cities");
                		}
                		set_module_pref("homecity",$city,"cities");
                			if ($session['user']['age'] == 0)
                				$session['user']['location']=$city;
            		}
        		}
?>