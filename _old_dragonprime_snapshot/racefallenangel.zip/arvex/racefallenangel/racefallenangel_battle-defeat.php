<?php
if ($session['user']['race'] == $race) {
			$session['user']['alive']=false;
			output("`)Als `\$Gefallener Engel`), versto�en in das Totenreich, mu�t du dort bis zum n�chsten Tage verharren.`n");
			$session['user']['gravefights']=0;
			$session['user']['soulpoints']=0;
			$session['user']['deathpower']=0;
			}
?>