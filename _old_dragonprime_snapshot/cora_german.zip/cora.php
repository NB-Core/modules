<?php

function cora_getmoduleinfo()
{
 $info = array(
	"name"=>"Cora im Wald",
	"author"=>"`@Nightborn",
	"version"=>"1.0",
	"category"=>"Forest Specials",
	"download"=>"http://dragonprime.net/dls/cora_german.zip",
	"settings"=>array(
	"Coramodul - Einstellungen, title",
	"loss"=>"Erfahrungsverlust bei Coras Behandlung in Prozent,range,1,20,1|5",
	"fightexp"=>"Erfahrungsgewinn/verlust bei Kampf,range,1,20,1|8"
	"coraname"=>"Name von Cora (auch mit Farben m�glich),text|Cora",
	"Notiz: Sollte weiblich sein... ansonsten m�ssen per �bersetzungstool Texte evtl angepa�t werden,note",
  ),
  );
 return $info;
}
function cora_install()
{
 module_addeventhook("forest", "return 100;");
 if (is_module_active("cora")) output_notl("`c`bModul Cora geupdated`b`c`n`n");
 return true;
}
function cora_uninstall()
{
 return true;
}
function cora_dohook($hookname,$args)
{
return $args;
}
function cora_runevent($type,$link)
{
 global $session;
 $cora=get_module_setting('coraname');
 $from = "forest.php?";
 $session['user']['specialinc'] = "module:cora";
 $op = httpget('op');

 switch ($op)
 {
  case "":
	output("`@ Du vernimmst aus einiger Entfernung wildes Gebrabbel und entschlie�t dich, dem auf den Grund zu gehen.");
	output(" Du trittst n�her und erkennst eine wild wuselnde und schimpfende `^%s`0 an einem Ast festh�ngen.",$cora);
	output(" Sie schickt dir einen Wortschwall entgegen, du erahnst, dass zwischen den ganzen Worten ein \"Bitte hilf mir hier runter\" vorkommt.");
	output_notl("`n`n");
	output("Was wirst du tun? ");
	output_notl("`n`n");
	output("`v-> Klettere auf den Baum, nat�rlich erst nachdem du dich mit Ohrensch�tzern vor ihrer Waffe Wortschwall ausreichend gesch�tzt hast");
	output_notl("`n");
	output("-> Nutze die Gunst der Stunde und bewirf das hilflose Gesch�pf mit Adminzitaten");
	output_notl("`n");
	output("-> Verhau sie ein wenig und befreie die Welt!");
	output_notl("`n");
	output("->Weggehen mit einem Grinsen im Gesicht");
	addnav("Klettern+Ohrensch�tzer",$link."op=climb");
    addnav("Gunst der Stunde",$link."op=chance");
	addnav("Verhau sie ein wenig",$link."op=prefight");
   addnav("Weggehen+Grinsen",$link."op=walk");
   break;
  case "climb":
   output("`@Du fl�chtest gut ger�stet auf einen nahen Baum und schaust ein wenig zu.");
   output_notl("`n");
   $randomchance=e_rand(0,5);
   switch ($randomchance) {
		case 0:
			output("Aber leider hast Du Pech, und der Ast unter Dir gibt nach, als du dir den Bauch h�ltst.");
			output_notl("`n");
			$damage=e_rand(0,$session['user']['hitpoints']/2);
			if ($session['user']['hitpoints']-$damage>0) {
				output("Du f�llst runter und erleidest %s Schaden!",$damage);
				$session['user']['hitpoints']-=$damage;
				}
			break;
		case 1:
			output("`kOh Nein! Deine Ohrensch�tzer sind runtergefallen, jetzt schlackern Dir die Ohren!`n");
			output("Du kannst nur hilfslos dasitzen, und wirst mit Spam eingedeckt!");
			output_notl("`n`n");
			output("Letztendlich fliehst Du mit einem Klingeln in den Ohren");
			addnews("%s`p wurde von `^%s`0 im Wald `\$eingespammt`p!!!",$session['user']['name'],$cora);
			apply_buff('coraspam',
				array(
				"name"=>"`)$cora's Gejammer", //no, this is not tl-ready... but in 1.0.7 you can change this to "name"=>array("`)%s`0's Gejammer",$cora), and it's ok
				"rounds"=>30,
				"wearoff"=>"Du kannst wieder normal h�ren.",
				"atkmod"=>0.8,
				"defmod"=>0.8,
				"minioncount"=>1,
				"roundmsg"=>"$cora's Worte bimmeln in Deinen Ohren!",
				"schema"=>"module-cora",
				));
			break;
		case 2:
			output("`@Nach einer Weile hast du Erbarmen und rettest sie. Sie ist so dankbar, da� sie sich stundenlang bei dir bedankt.");
			output_notl("`n`n");
			$loss=e_rand(0,$session['user']['turns']/2);
			if ($session['user']['turns']>0) {
				output("Du verlierst Zeit f�r %s Waldk�mpfe!",$loss);
				$session['user']['turns']-=$loss;
				}
			break;
		case 3:
			output("`kOh Nein! Der Ast bricht und du f�llst volle M�hre in ein Stachelgeb�sch.`n");
			output("Was ist schlimmer, das Gezeter oder der Schmerz...`n`n");
			$loss=e_rand(1,3);
			output("Du zerkratzt dein Gesicht und verlierst %s Charmepunkte!",$loss);
			$session['user']['charm']-=$loss;
			break;
		case 4:
			output("`pOha, sie hat ihre Goldb�rse fallen lassen.... ^^ na die braucht einen besseren Besitzer.");
			output_notl("`n`n");
			$gain=e_rand(1,($session['user']['turns']+$session['user']['level'])*50);
			output("Du bereicherst dich um `^%s Goldst�cke`p.",$gain);
			$session['user']['gold']+=$gain;
		case 5:
			output("`^Du am�sierst dich so k�stlich, da� du mit einem strahlenden L�cheln ins Dorf zur�ckkehrst.");
			output_notl("`n`n");
			output("`^Du f�hlst Dich `%charmant`^!");
			$session['user']['charm']+=e_rand(1,3);
			break;
		}
		$session['user']['specialinc'] = "";
		break;
	case "chance":
		output("`@Du nutzt nat�rlich die Gunst der Stunde.");
		output("`n`nAus dem `Q\"Wie qu�le ich meine User - Handbuch f�r Admins\"`@ zitierst Du einige heilige Verse.");
		output_notl("`n`n");
		output("Die Wirkung bleibt nicht aus... bald ist das Gejammer riesig.");
		$randomchance=e_rand(0,2);
		switch ($randomchance)
		{
		case 0:
			output("`n`n`@Oh, das hat gesessen, sie windet sich unter Todesqualen.");
			output_notl("`n`n");
			output("Das hat so gesessen, da� du `%charmant`@ von dannen ziehst.");
			$session['user']['charm']++;
			break;
		case 1:
			output("`k`n`nUps, das ging in die Hose, sie konnte sich l�sen und f�llt gerade �ber dich her.`@");
			output_notl("`n`n");
			output("Nach einigen Stunden entl��t sie dich aus ihrer \"Obhut\".`n");
			output("Was auch immer passiert ist, `\$niemand`@ wird es je erfahren... Du hast einen Teil deiner Erinnerung willentlich gel�scht.");
			output_notl("`n`n");
			$loss=get_module_setting('loss');
			output("Du verlierst %s Prozent Deiner Erfahrung!",$loss);
			$loss/=100;
			$session['user']['experience']*=(1-$loss);
			break;
		case 2:
			output("`@Hmm.... nach deinem Sieg trabst du gem�tlich von dannen!");
			output_notl("`n`n");
			output("Gut gelaunt st�rzt du dich in das n�chste Abenteuer.");
			apply_buff('corasstrafe',
			array(
			"name"=>"`^Hochgef�hl",
			"rounds"=>30,
			"wearoff"=>"Das tolle Gef�hl ist weg, $cora vergessen.", //change this like in the comment above
			"atkmod"=>1.2,
			"defmod"=>1.2,
			"minioncount"=>1,
			"roundmsg"=>"Ihre Qualen lassen dich aufleben!",
			"schema"=>"module-cora",
			));
			break;
		}
		$session['user']['specialinc'] = "";
		break;
	case "walk":
		output("`@Du entscheidest dich so schnell wie m�glich vor dieser unheimlichen Kreatur zu fliehen und suchst das Weite.");
		output_notl("`n`n");
		switch (e_rand(0,2)) {
			case 0:
				output("Als sie au�er deiner Reichweite ist, atmest du tief durch und bist so erleichtert, dass du die Energie f�r einen weiteren Waldkampf sp�rst");
				$session['user']['turns']++;
				break;
			case 1:
				output("Als sie au�er deiner Reichweite ist, findest Du etwas Gold!");
				$session['user']['gold']+=e_rand(1,100);
				break;
			case 2:
				output("Oh weh, Du bist echt tollpatschig. Du bist �ber %s`0s Sachen gestolpert.",$cora);
				output_notl("`n`n");
				$damage=e_rand(1,$session['user']['hitpoints']/3);
				if ($session['user']['hitpoints']-$damage>0) {
					output("Du verlierst %s Lebenspunkte!",$damage);
					$session['user']['hitpoints']-=$damage;
				}
				break;
			}
		$session['user']['specialinc'] = "";
		break;
	case "prefight":
		output("`@Du willst es wissen, und n�herst dich ihr mit gez�ckter Waffe!");
		require_once("lib/battle-skills.php");
	 	$badguy = array(
		"creaturename"=>"`%$cora`0", //change this like in the comment above
        "creaturelevel"=>$session['user']['level']+1,
        "creatureweapon"=>"Mega-Spam",
		"creatureattack"=>$session['user']['level']+$session['user']['dragonkills']+1,
		"creaturedefense"=>e_rand($session['user']['defense']/2,$session['user']['defense']+e_rand(1,5)),
		"creaturehealth"=>($session['user']['level']*5+round(e_rand($session['user']['level'],($session['user']['maxhitpoints']-$session['user']['level']*5)))),
		"diddamage"=>0,);
		if ($session['user']['level']<5) {
			$badguy['creaturename']="`%kleine $cora"; //change this like in the comment above
			$badguy['creatureweapon']="`%Babyspam";
		} else if ($session['user']['level']>9) {
			$badguy['creaturename']="`\$gewaltige $cora"; //change this like in the comment above
			$badguy['creatureweapon']="`%M�rderspam aus den 7 H�llen";
		}
   	$battle=true;
	$session['user']['badguy'] = createstring($badguy);
	$op = "combat";
	httpset('op', $op);
	case "combat": case "fight":
	include("battle.php");
	$exp=get_module_setting("fightexp");
	if ($victory){
		//output("`b`n`#Kommentarlose L�schung entf�nde der gesamte Verein als geschmacklos und niveaulos. MFG`b");
		//output("`n`@...r�chelt sie...");
		output("`n`n`@...%s`@ stirbt durch deine Hand, irgendwie hast du sie �berlebt..",$badguy['creaturename']);
		addnews("%s`^ hat eine Begegnung mit %s`^ �berlebt! Gl�ckwunsch!",$session['user']['name'],$badguy['creaturename']);
		$session['user']['specialinc'] = "";
		if ($exploss>0) output("Du erh�ltst `^%s Prozent`@ an Erfahrung!",$exp);
		$exploss = $session['user']['experience']*$exp/100;
		$session['user']['experience']+=$exploss;
		$badguy=array();
		$session['user']['badguy']="";
    }elseif ($defeat){
		$exploss = $session['user']['experience']*$exp/100;
		output("`n`n`@Du bist tot, get�tet von %s`@.`n",$badguy['creaturename']);
		if ($exploss>0) output(" Du verlierst `^%s Prozent`@ an Erfahrung und dein ganzes Gold.",$exp);
		$session['user']['experience']-=$exploss;
		$session['user']['gold']=0;
		debuglog("verloren $exp Erfahrungspunkte an $cora im Wald.");
		addnews("%s`^ wurde im Wald von %s`^ get�tet, man sagt, es war ein grausamer Anblick.",$session['user']['name'],$badguy['creaturename']);
		addnav("Zur�ck");
		addnav("Zur�ck zu den Schatten","shades.php");
		$session['user']['specialinc'] = "";
		$badguy=array();
		$session['user']['badguy']="";
    }else{
		require_once("lib/fightnav.php");
		$allow = true;
		fightnav($allow,false);
		if ($session['user']['superuser'] & SU_DEVELOPER) addnav("Flieh ins Dorf","village.php");
    }
 }

}

function cora_run(){
}

?>