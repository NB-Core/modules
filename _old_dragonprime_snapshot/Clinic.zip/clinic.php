<?php

require_once("lib/villagenav.php");
function clinic_getmoduleinfo(){
        $info = array(
                "name"=>"Apothecary/Clinic",
                "version"=>"0.8",
                "author"=>"`)ShadowRaven",
                "category"=>"Village",
                "download"=>"",
                "settings"=>array(
                        "Apothecary,title",
                        "clinicname"=>"What is the clinic called?,|Apothecary",
                        "aploc"=>"Where does this appear,location|".getsetting("villagename",LOCATION_FIELDS),
                        "cost"=>"What currency to use,enum,0,Gold,1,Gems,2,Both",
                        "If cost is gold or both-set this,note",
                        "gold"=>"How much gold does a visit cost per level,int|5",
                        "If cost is gems or both-set this,note",
                        "gems"=>"How many gems does a visit cost,int|2",
                        "If below is set to no- users will be healed imediately,note",
                        "cure"=>"Make users find ingredients for cure?,bool|1",
                        "chance"=>"Chance of finding ingredients in the forest,range, 0, 100, 1|12",
                        "random"=>"Chance of user getting poison ivy in forest?,range, 0, 100, 1|5",
                        "days"=>"How many days will poinson ivy last if not cured?,range, 0,10, 1|5",
                ),
                "prefs"=>array(
                         "Inflictions,title",
                         "sick"=>"Does this user have an infliction?,bool|0",
                         "what"=>"What infliction does this user have?,text|",
                         "Ingredients,title",
                         "user_showpouch"=>"Show pouch in character info?,bool|1",
                        "have"=>"Does this user have any ingredients?,bool|0",
                        "amount1"=>"How many Angelica stems?,int|",
                        "amount2"=>"How many Arrowleaf clover?,int|",
                        "amount3"=>"How many Mandrake root?,int|",
                        "amount4"=>"How many Mugwort?,int|",
                        "amount5"=>"How many Ragwort?,int|",
                        "amount6"=>"How many Patchouli?,int|",
                        "amount7"=>"How many Nux oil?,int|",
                        "amount8"=>"How many Comfrey root?,int|",
                        "amount9"=>"How many Castor root?,int|",
                        "amount10"=>"How many Charcoal?,int|",
                        "amount11"=>"How many Burdock Root?,int|",
                        "amount12"=>"How many Blood root?,int|",
                        "amount13"=>"How many Anise seeds?,int|",
                        "amount14"=>"How many Balm of Gilead?,int|",
                        "amount15"=>"How many Lavender?,int|",
                        "amount16"=>"How many Bat guano?,int|",
                        "target1"=>"Current ingredient needed,text|",
                        "target2"=>"Current ingredient needed,text|",
                        "target3"=>"Current ingredient needed,text|",
                        "got"=>"How many of needed ingredients have been found?,int|",
                        "daysleft"=>"Days left till automtically cured,viewonly|",
                        )
        );
        return $info;
}

function clinic_install(){
        module_addhook("changesetting");
        module_addhook("village");
        module_addhook("battle-victory");
        module_addhook("charstats");
        module_addhook("battle-defeat");
        module_addhook("newday");
        module_addhook("dragonkill");
return true;
}

function clinic_uninstall(){
return true;
}

function clinic_dohook($hookname,$args){
        global $session;
        $id = $session['user']['userid'];
        switch($hookname){
                case "battle-victory":
                $cure = get_module_setting("cure");
                $got = get_module_pref("got");
                $sick = get_module_pref("sick");
        if ($sick == 0){
                $random = e_rand(1,100);
                if ($random <= get_module_setting("random")) {
                    output("`n`n`^`bOh no! You must have brushed up against something during the fight! You start to itch.....alot.`n You had better go get that checked out. eww.`b`n`n");

   //thanks DaveS for this :)
   apply_buff('poisonivy',array(
   "name"=>"`@Poison Ivy",
   "rounds"=>-1,
   "wearoff"=>"The anti-itch cream finally kicks in",
   "atkmod"=>.98,
   "defmod"=>.98,
   "roundmsg"=>"`@You stop to scratch an itch",
   "survivenewday"=>1,
   "newdaymessage"=>"`n`@The poison ivy itch didn't clear up yet.`n",
));
                set_module_pref("sick",1);
                $po = ("Poison Ivy");
                set_module_pref("what",$po);
                $days = get_module_setting("days");
                set_module_pref("daysleft",$days);
                }
                }
        if ($cure == 1){
                $chance = e_rand(1,100);
                if ($chance <= get_module_setting("chance")) {
                        $n = e_rand(1,14);
                        $ingredients = array(
                                1=>"Angelica stems",
                                2=>"Arrowleaf clover ",
                                3=>"Mandrake root",
                                4=>"Mugwort",
                                5=>"Ragwort",
                                6=>"Patchouli",
                                7=>"Nux oil",
                                8=>"Comfrey root",
                                9=>"Castor root",
                                10=>"Charcoal",
                                11=>"Burdock Root",
                                12=>"Blood root",
                                13=>"Anise seeds",
                                14=>"Balm of Gilead",
                                );
                        $k = e_rand(1,10);
                        $ingredient = array(
                                1=>"As you start to continue you notice some pretty flowers growing along side of the path. you stop to pick some.`^You found `5Lavender`^! ",
                                2=>"You see a cave to the right and look inside. There are bats everywhere! `^You found bat guano!",
                                3=>"You happen to look down and see something. `^You found ".$ingredients[$n]." !",
                                4=>"You happen to look down and see something. `^You found ".$ingredients[$n]." !",
                                5=>"You happen to look down and see something. `^You found ".$ingredients[$n]." !",
                                6=>"You happen to look down and see something. `^You found ".$ingredients[$n]." !",
                                7=>"You happen to look down and see something. `^You found ".$ingredients[$n]." !",
                                8=>"You happen to look down and see something. `^You found ".$ingredients[$n]." !",
                                9=>"You happen to look down and see something. `^You found ".$ingredients[$n]." !",
                                10=>"You happen to look down and see something. `^You found ".$ingredients[$n]." !",
                                );

                set_module_pref("have",1);
                output("`n`n`# %s`n`n",$ingredient[$k]);
                $target1 =  get_module_pref("target1");
                $target2 =  get_module_pref("target2");
                $target3 =  get_module_pref("target3");
                $got = get_module_pref("got");
                if ($k == 1){
                increment_module_pref("amount15",1);
                    $ingredient15 = "Lavender";
                if ($ingredient15 == $target1 || $ingredient15 == $target2 || $ingredient15 == $target3){
                   if($got < 3){
                  increment_module_pref("got",1);
                  }
                  }
                }
                if ($k == 2){
                increment_module_pref("amount16",1);
                $ingredient16 = "Bat guano";
                if ($ingredient16 == $target1 || $ingredient16 == $target2 || $ingredient16 == $target3){
                  if($got < 3){
                  increment_module_pref("got",1);
                  }
                  }
                }
                if ($k == 3 or $k == 4 or $k == 5 or $k == 6 or $k == 7 or $k == 8 or $k == 9 or $k == 10){
                 if($n == 1){
                increment_module_pref("amount1",1);
                if ($ingredients[$n] == $target1 || $ingredients[$n] == $target2 || $ingredients[$n] == $target3){
                  if($got < 3){
                  increment_module_pref("got",1);
                  }
                  }
                }
                if($n == 2){
                increment_module_pref("amount2",1);
                if ($ingredients[$n] == $target1 || $ingredients[$n] == $target2 || $ingredients[$n] == $target3){
                  if($got < 3){
                  increment_module_pref("got",1);
                  }                  }
                }
                if($n == 3){
                increment_module_pref("amount3",1);
                if ($ingredients[$n] == $target1 || $ingredients[$n] == $target2 || $ingredients[$n] == $target3){
                  if($got < 3){
                  increment_module_pref("got",1);
                  }                  }
                }
                if($n == 4){
                increment_module_pref("amount4",1);
                if ($ingredients[$n] == $target1 || $ingredients[$n] == $target2 || $ingredients[$n] == $target3){
                  if($got < 3){
                  increment_module_pref("got",1);
                  }                  }
                }
                if($n == 5){
                increment_module_pref("amount5",1);
                if ($ingredients[$n] == $target1 || $ingredients[$n] == $target2 || $ingredients[$n] == $target3){
                   if($got < 3){
                  increment_module_pref("got",1);
                  }                 }
                }
                if($n == 6){
                increment_module_pref("amount6",1);
                if ($ingredients[$n] == $target1 || $ingredients[$n] == $target2 || $ingredients[$n] == $target3){
                  if($got < 3){
                  increment_module_pref("got",1);
                  }                  }
                }
                if($n == 7){
                increment_module_pref("amount7",1);
                if ($ingredients[$n] == $target1 || $ingredients[$n] == $target2 || $ingredients[$n] == $target3){
                  if($got < 3){
                  increment_module_pref("got",1);
                  }                  }
                }
                if($n == 8){
                increment_module_pref("amount8",1);
                if ($ingredients[$n] == $target1 || $ingredients[$n] == $target2 || $ingredients[$n] == $target3){
                  if($got < 3){
                  increment_module_pref("got",1);
                  }                  }
                }
                if($n == 9){
                increment_module_pref("amount9",1);
                if ($ingredients[$n] == $target1 || $ingredients[$n] == $target2 || $ingredients[$n] == $target3){
                   if($got < 3){
                  increment_module_pref("got",1);
                  }                 }
                }
                if($n == 10){
                increment_module_pref("amount10",1);
                if ($ingredients[$n] == $target1 || $ingredients[$n] == $target2 || $ingredients[$n] == $target3){
                  if($got < 3){
                  increment_module_pref("got",1);
                  }                  }
                }
                if($n == 11){
                increment_module_pref("amount11",1);
                if ($ingredients[$n] == $target1 || $ingredients[$n] == $target2 || $ingredients[$n] == $target3){
                  if($got < 3){
                  increment_module_pref("got",1);
                  }                  }
                }
                if($n == 12){
                increment_module_pref("amount12",1);
                if ($ingredients[$n] == $target1 || $ingredients[$n] == $target2 || $ingredients[$n] == $target3){
                  if($got < 3){
                  increment_module_pref("got",1);
                  }                  }
                  }
                if($n == 13){
                increment_module_pref("amount13",1);
                if ($ingredients[$n] == $target1 || $ingredients[$n] == $target2 || $ingredients[$n] == $target3){
                  increment_module_pref("got",1);
                  }
                }
                if($n == 14){
                increment_module_pref("amount14",1);
                if ($ingredients[$n] == $target1 || $ingredients[$n] == $target2 || $ingredients[$n] == $target3){
                  if($got < 3){
                  increment_module_pref("got",1);
                  }
                  }
                }

                }
}
}
break;
                 case "charstats":
                 $have = get_module_pref("have");
                        if (get_module_pref("user_showpouch") == 1 && $have>0){
                        $vc=translate_inline("`#View Contents");
                        //modified slightly from backpack module by Webpixie
                        $pouch="<a href='runmodule.php?module=clinic&op=pouch' onClick=\"".popup("runmodule.php?module=clinic&op=pouch").";return false;\" target='_blank' align='center' class=\"charinfo\" style=\"font-size:12px\">".$vc."</a>";
                addcharstat("Pouch");
                addcharstat("Pouch", $pouch);
                addnav("","runmodule.php?module=clinic&op=pouch");
                }
                break;
                case "village":
                $clinicname = get_module_setting("clinicname");
                if(($session['user']['location'] == get_module_setting("aploc"))){
                        tlschema($args['schemas']['gatenav']);
                        addnav($args['gatenav']);
                        tlschema();
                        addnav("$clinicname","runmodule.php?module=clinic");
}
break;
                case "newday":
                         $sick = get_module_pref("sick");
                        $days = get_module_setting("days");
                        $daysleft = get_module_pref("daysleft");
                        $daysleft1 = $daysleft-1;
                        if ($days>0 && $sick == 1){
                        set_module_pref("daysleft",$daysleft1);
                        }
                        if ($daysleft == 0 && $sick == 1){
                       strip_buff("poison oak");
                       output("Your itch is gone!");
                       set_module_pref("sick",0);
                       clear_module_pref("what");
                       clear_module_pref("target1");
                       clear_module_pref("target2");
                       clear_module_pref("target3");
                       clear_module_pref("got");
                       }
break;
                case "dragonkill":
                $what = get_module_pref("what");
                 $sick = get_module_pref("sick");
                       if ($what == "Poison Ivy" && $sick == 1){
        apply_buff('poisonivy',array(
   "name"=>"`@Poison Ivy",
   "rounds"=>-1,
   "wearoff"=>"The anti-itch cream finally kicks in",
   "atkmod"=>.98,
   "defmod"=>.98,
   "roundmsg"=>"`@You stop to scratch an itch",
   "survivenewday"=>1,
   "newdaymessage"=>"`n`@The poison ivy itch didn't clear up yet.`n",
));
}
break;
                
                
                case "changesetting":
                        if ($args['setting'] == "villagename") {
                                if ($args['old'] == get_module_setting("aploc")) {
                                set_module_setting("hutloc", $args['new']);
}
}
break;
}
return $args;
}

function clinic_run(){
       global $SCRIPT_NAME;
        if ($SCRIPT_NAME == "runmodule.php"){
                $module=httpget("module");
                if ($module == "clinic") {
                        include("modules/clinic/clinic.php");
                }
        }
}
?>
