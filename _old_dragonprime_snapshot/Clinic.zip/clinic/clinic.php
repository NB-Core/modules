<?php
global $session;
                $clinicname = get_module_setting("clinicname");
                $cost = get_module_setting("cost");
                $op = httpget("op");
                $loc = get_module_setting("aploc");
                $gold = get_module_setting("gold");
              $gems = get_module_setting("gems");
              $what = get_module_pref("what");
              $cure = get_module_setting("cure");
              $sick = get_module_pref("sick");
              $got = get_module_pref("got");
if ($op==""){
               page_header(array("%s",color_sanitize($clinicname)));
                output("`#`n`n`c`b%s %s`b`c",$loc,$clinicname);
                //Thanks Kala for the entrance description! :)
                output("You walk into a musty, dank room, there are many herbs and various items hanging from the ceilings, in pots and jars, littering the shelves.`n  You decide not to look closer upon spying something that looks suspiciously like a Goblins shrunken head.");
                output("`nA slight change in the rooms air, makes you turn to be confronted with an aged man, he looks you up and down before rasping out..`n \"Welcome to my small Apothecary, perhaps you have an appointment?\"`n He shakes his head slightly before continueing \"No you don't, well as I'm not very busy today, step through and I'll take a look at you.\" `n A small smile appears on his lips as he utters \"For a small fee of course\"");
                output("`nYou eye the curtain he is holding open for you, trying to see through the dimness beyond, shrugging you make your mind up");
                //end
        if($sick == 0){
                    output("`n`n`^You feel healthy enough that getting checked would be a waste of money");

        }else{
               if ($got >0 && $got <= 2){
               $need = (3-$got);
                output("`n`n`^You still need %s more ingredients!",$need);
                }elseif ($cost == 0 && $got <=0){
           addnav(array("Go Through the curtain (`^%s gold`0)",$gold),"runmodule.php?module=clinic&op=check");
                  }elseif ($cost == 0 && $got == 3){
                        addnav("Give your Ingredients","runmodule.php?module=clinic&op=give");
}
if($cost == 1 && $got <=0){
              addnav(array("Go Through the curtain (`^%s gems`0)",$gems),"runmodule.php?module=clinic&op=check");
              }elseif ($cost == 1 && $got == 3){
                        addnav("Give your Ingredients","runmodule.php?module=clinic&op=give");
}
if($cost == 2 && $got <=0){
              addnav(array("Go Through the curtain (`^%s gems and %s gold)",$gems,$gold),"runmodule.php?module=clinic&op=check");
             }elseif ($cost == 2 && $got == 3){
                        addnav("Give your Ingredients","runmodule.php?module=clinic&op=give");
        }

        }
villagenav();
page_footer();
}
if ($op=="check"){

               page_header(array("%s",color_sanitize($clinicname)));
                output("`#`n`n`c`b%s %s`b`c",$loc,$clinicname);

        if (($session['user']['gold']<$gold)or($session['user']['gems']<$gems)){

                  output("Sorry, you don't seem to have enough for this visit!");
        }else {
                if ($cost == 0){
                $session['user']['gold']-=$gold;
                }
                if ($cost == 1){
                $session['user']['gems']-=$gems;
                }
                if ($cost == 2){
                $session['user']['gold']-=$gold;
                $session['user']['gems']-=$gems;
                }

        output("You enter a private room, and told to take a seat. You are then put through various tests(some of them you prefer not to remember...ever).`n`n After what seems like hours, you find out that you have %s.`n`n",$what);
        if ($cure == 1){
        output("You are also told that because the ingredients for the medicine you need is running low, you need to find these ingredients in the forest and bring them back here to be cured: ");
                $ingredients = array("Angelica stems","Arrowleaf clover","Mandrake root","Mugwort","Ragwort","Patchouli",
                                "Nux oil","Comfrey root","Castor root","Charcoal","Burdock Root","Blood root","Anise seeds",
                                "Balm of Gilead","Lavender","Bat guano",
                                );
                            $pick = array_rand($ingredients, 3);
                            output("`c`n`n`@ %s`n`n`c",$ingredients[$pick[0]]);
                            output("`c`n`@ %s`n`n`c",$ingredients[$pick[1]]);
                            output("`c`n`@ %s`n`n`c",$ingredients[$pick[2]]);
                            set_module_pref("target1",$ingredients[$pick[0]]);
                            set_module_pref("target2",$ingredients[$pick[1]]);
                            set_module_pref("target3",$ingredients[$pick[2]]);
        $amount1 = get_module_pref("amount1");
        $amount2 = get_module_pref("amount2");
        $amount3 = get_module_pref("amount3");
        $amount4 = get_module_pref("amount4");
        $amount5 = get_module_pref("amount5");
        $amount6 = get_module_pref("amount6");
        $amount7 = get_module_pref("amount7");
        $amount8 = get_module_pref("amount8");
        $amount9 = get_module_pref("amount9");
        $amount10 = get_module_pref("amount10");
        $amount11 = get_module_pref("amount11");
        $amount12 = get_module_pref("amount12");
        $amount13 = get_module_pref("amount13");
        $amount14 = get_module_pref("amount14");
        $amount15 = get_module_pref("amount15");
        $amount16 = get_module_pref("amount16");
        $target1 =  get_module_pref("target1");
        $target2 =  get_module_pref("target2");
        $target3 =  get_module_pref("target3");
                if ($amount1 > 0){
                        $name1 = "Angelica stems";
                                if ($name1 == $target1 || $name1 == $target2 || $name1 == $target3 && $got < 3){
                             increment_module_pref("got",1);
                             output("`n`nYou've already got %s!`n",$name1);
                       }
                       }
                if ($amount2 > 0){
                        $name2 = "Arrowleaf clover";
                                if ($name2 == $target1 || $name2 == $target2 || $name2 == $target3 && $got < 3){
                             increment_module_pref("got",1);
                              output("`n`nYou've already got %s!`n",$name2);
                       }
                       }
                if ($amount3 > 0){
                        $name3 = "Mandrake root";
                                if ($name3 == $target1 || $name3 == $target2 || $name3 == $target3 && $got < 3){
                             increment_module_pref("got",1);
                              output("`n`nYou've already got %s!`n",$name3);
                       }
                       }
                if ($amount4 > 0){
                        $name4 = "Mugwort";
                                if ($name4 == $target1 || $name4 == $target2 || $name4 == $target3 && $got < 3){
                             increment_module_pref("got",1);
                              output("`n`nYou've already got %s!`n",$name4);
                       }
                       }
                if ($amount5 > 0){
                        $name5 = "Ragwort";
                                if ($name5 == $target1 || $name5 == $target2 || $name5 == $target3 && $got < 3){
                             increment_module_pref("got",1);
                              output("`n`nYou've already got %s!`n",$name5);
                       }
                       }
                if ($amount6 > 0){
                        $name6 = "Patchouli";
                                if ($name6 == $target1 || $name6 == $target2 || $name6 == $target3 && $got < 3){
                             increment_module_pref("got",1);
                              output("`n`nYou've already got %s!`n",$name6);
                       }
                       }
                if ($amount7 > 0){
                        $name7 = "Nux oil";
                                if ($name7 == $target1 || $name7 == $target2 || $name7 == $target3 && $got < 3){
                             increment_module_pref("got",1);
                              output("`n`nYou've already got %s!`n",$name7);
                       }
                       }
                if ($amount8 > 0){
                        $name8 = "Comfrey root";
                                if ($name8 == $target1 || $name8 == $target2 || $name8 == $target3 && $got < 3){
                             increment_module_pref("got",1);
                              output("`n`nYou've already got %s!`n",$name8);
                       }
                       }
                if ($amount9 > 0){
                        $name9 = "Castor root";
                                if ($name9 == $target1 || $name9 == $target2 || $name9 == $target3 && $got < 3){
                             increment_module_pref("got",1);
                              output("`n`nYou've already got %s!`n",$name9);
                       }
                       }
                if ($amount10 > 0){
                        $name10 = "Charcoal";
                                if ($name10 == $target1 || $name10 == $target2 || $name10 == $target3 && $got < 3){
                             increment_module_pref("got",1);
                              output("`n`nYou've already got %s!`n",$name10);
                       }
                       }
               if ($amount11 > 0){
                        $name11 = "Burdock Root";
                                if ($name11 == $target1 || $name11 == $target2 || $name11 == $target3 && $got < 3){
                             increment_module_pref("got",1);
                              output("`n`nYou've already got %s!`n",$name11);
                       }
                       }
               if ($amount12 > 0){
                        $name12 = "Blood root";
                                if ($name12 == $target1 || $name12 == $target2 || $name12 == $target3 && $got < 3){
                             increment_module_pref("got",1);
                              output("`n`nYou've already got %s!`n",$name12);
                       }
                       }
               if ($amount13 > 0){
                        $name13 = "Anise seeds";
                                if ($name13 == $target1 || $name13 == $target2 || $name13 == $target3 && $got < 3){
                             increment_module_pref("got",1);
                              output("`n`nYou've already got %s!`n",$name13);
                       }
                       }
               if ($amount14 > 0){
                        $name14 = "Balm of Gilead";
                                if ($name14 == $target1 || $name14 == $target2 || $name14 == $target3 && $got < 3){
                             increment_module_pref("got",1);
                              output("`n`nYou've already got %s!`n",$name14);
                       }
                       }
               if ($amount15 > 0){
                        $name15 = "Lavender";
                                if ($name15 == $target1 || $name15 == $target2 || $name15 == $target3 && $got < 3){
                             increment_module_pref("got",1);
                              output("`n`nYou've already got %s!`n",$name15);
                       }
                       }
               if ($amount16 > 0){
                        $name16 = "Bat guano";
                                if ($name16 == $target1 || $name16 == $target2 || $name16 == $target3 && $got < 3){
                             increment_module_pref("got",1);
                              output("`n`nYou've already got %s!`n",$name16);
                       }
                       }
                  }elseif ($cure == 0){
                       $id = $session['user']['userid'];
                       output("You are given a vial with a very nasty smelling liquid in it. You plug your nose, and hold your breath and...down the hatch! `n`nYou manage to swallow the vile concoction without gagging, and you feel great!");
                       if($what == "Poison Oak"){
                       strip_buff("poison oak");
                       }
                       if($what == "Poison Ivy"){
                       strip_buff("poisonivy");
                       }
                       if($what == "Pnemonia"){
                       strip_buff("pnemonia");
                       }
                       if($what == "Food Poisoning"){
                       strip_buff("food poisoning");
                       }
                       if($what == "Dysentary"){
                       strip_buff("dysentary");
                       }
                       if($what == "Small Pox"){
                       strip_buff("small pox");
                       }
                       if($what == "Influenza"){
                       strip_buff("influenza");
                       }
                       if($what == "Black Plague"){
                       strip_buff("black plague");
                       }
                       if($what == "Bubonic Plague"){
                       strip_buff("bubonic plague");
                       }
                       set_module_pref("sick",0);
                       clear_module_pref("what");
                       clear_module_pref("daysleft");

                 }
                }
                addnav("Back","runmodule.php?module=clinic");
        villagenav();
        page_footer();
}
if ($op == "give"){
               page_header("Giving Ingredients");
               output("You hand over the ingredients you found and take a seat to wait for the elixir to be made.`n`nYou wait..`n`n.....and wait..`n`n..........and wait..`n`n................and wait..`n`n Finally you are brought a vile smelling liquid to drink.");
               addnav("Drink Elixir","runmodule.php?module=clinic&op=drink");

            page_footer();
              }
if ($op =="drink"){
                page_header("Drink Elixir");
           output("`n`n You plug your nose, and hold your breath and...down the hatch! `n`nYou manage to swallow the vile concoction without gagging, and you feel great!");
                       if($what == "Poison Oak"){
                       strip_buff("poison oak");
                       }
                       if($what == "Poison Ivy"){
                       strip_buff("poisonivy");
                       }
                       if($what == "Pnemonia"){
                       strip_buff("pnemonia");
                       }
                       if($what == "Food Poisoning"){
                       strip_buff("food poisoning");
                       }
                       if($what == "Dysentary"){
                       strip_buff("dysentary");
                       }
                       if($what == "Small Pox"){
                       strip_buff("small pox");
                       }
                       if($what == "Influenza"){
                       strip_buff("influenza");
                       }
                       if($what == "Black Plague"){
                       strip_buff("black plague");
                       }
                       if($what == "Bubonic Plague"){
                       strip_buff("bubonic plague");
                       }

        $amount1 = get_module_pref("amount1");
        $amount2 = get_module_pref("amount2");
        $amount3 = get_module_pref("amount3");
        $amount4 = get_module_pref("amount4");
        $amount5 = get_module_pref("amount5");
        $amount6 = get_module_pref("amount6");
        $amount7 = get_module_pref("amount7");
        $amount8 = get_module_pref("amount8");
        $amount9 = get_module_pref("amount9");
        $amount10 = get_module_pref("amount10");
        $amount11 = get_module_pref("amount11");
        $amount12 = get_module_pref("amount12");
        $amount13 = get_module_pref("amount13");
        $amount14 = get_module_pref("amount14");
        $amount15 = get_module_pref("amount15");
        $amount16 = get_module_pref("amount16");
        $target1 =  get_module_pref("target1");
        $target2 =  get_module_pref("target2");
        $target3 =  get_module_pref("target3");
        $amount1s = $amount1-1;
        $amount2s = $amount2-1;
        $amount3s = $amount3-1;
        $amount4s = $amount4-1;
        $amount5s = $amount5-1;
        $amount6s = $amount6-1;
        $amount7s = $amount7-1;
        $amount8s = $amount8-1;
        $amount9s = $amount9-1;
        $amount10s = $amount10-1;
        $amount11s = $amount11-1;
        $amount12s = $amount12-1;
        $amount13s = $amount13-1;
        $amount14s = $amount14-1;
        $amount15s = $amount15-1;
        $amount16s = $amount16-1;

                        $name1 = "Angelica stems";
                                if ($name1 == $target1 || $name1 == $target2 || $name1 == $target3){

                                    set_module_pref("amount1",$amount1s);
                       }
                        $name2 = "Arrowleaf clover";
                                if ($name2 == $target1 || $name2 == $target2 || $name2 == $target3){

                                    set_module_pref("amount2",$amount2s);
                      }
                        $name3 = "Mandrake root";
                                if ($name3 == $target1 || $name3 == $target2 || $name3 == $target3){

                                     set_module_pref("amount3",$amount3s);
                       }
                        $name4 = "Mugwort";
                                if ($name4 == $target1 || $name4 == $target2 || $name4 == $target3 ){

                                     set_module_pref("amount4",$amount4s);
                       }
                        $name5 = "Ragwort";
                                if ($name5 == $target1 || $name5 == $target2 || $name5 == $target3){

                                     set_module_pref("amount5",$amount5s);
                      }
                        $name6 = "Patchouli";
                                if ($name6 == $target1 || $name6 == $target2 || $name6 == $target3){

                                     set_module_pref("amount6",$amount6s);
                      }
                        $name7 = "Nux oil";
                                if ($name7 == $target1 || $name7 == $target2 || $name7 == $target3){

                                     set_module_pref("amount7",$amount7s);
                       }
                        $name8 = "Comfrey root";
                                if ($name8 == $target1 || $name8 == $target2 || $name8 == $target3){

                                     set_module_pref("amount8",$amount8s);
                      }
                        $name9 = "Castor root";
                                if ($name9 == $target1 || $name9 == $target2 || $name9 == $target3){

                                     set_module_pref("amount9",$amount9s);
                      }
                        $name10 = "Charcoal";
                                if ($name10 == $target1 || $name10 == $target2 || $name10 == $target3){

                                     set_module_pref("amount10",$amount10s);
                       }
                        $name11 = "Burdock Root";
                                if ($name11 == $target1 || $name11 == $target2 || $name11 == $target3){

                                     set_module_pref("amount11",$amount11s);
                       }
                        $name12 = "Blood root";
                                if ($name12 == $target1 || $name12 == $target2 || $name12 == $target3){

                                     set_module_pref("amount12",$amount12s);
                       }
                        $name13 = "Anise seeds";
                                if ($name13 == $target1 || $name13 == $target2 || $name13 == $target3){

                                     set_module_pref("amount13",$amount13s);
                       }
                        $name14 = "Balm of Gilead";
                                if ($name14 == $target1 || $name14 == $target2 || $name14 == $target3){

                                     set_module_pref("amount14",$amount14s);
                       }
                        $name15 = "Lavender";
                                if ($name15 == $target1 || $name15 == $target2 || $name15 == $target3){

                                     set_module_pref("amount15",$amount15s);
                       }
                        $name16 = "Bat guano";
                                if ($name16 == $target1 || $name16 == $target2 || $name16 == $target3){

                                     set_module_pref("amount16",$amount16s);
                      }
                set_module_pref("sick",0);
                       clear_module_pref("what");
                       clear_module_pref("target1");
                       clear_module_pref("target2");
                       clear_module_pref("target3");
                       clear_module_pref("got");
                       clear_module_pref("daysleft");
        villagenav();
        page_footer();
 }
if ($op=="pouch"){
                popup_header("Ingredients inventory");
                output("`0The Ingredients in your pouch are:`n`n");
        $amount1 = get_module_pref("amount1");
        $amount2 = get_module_pref("amount2");
        $amount3 = get_module_pref("amount3");
        $amount4 = get_module_pref("amount4");
        $amount5 = get_module_pref("amount5");
        $amount6 = get_module_pref("amount6");
        $amount7 = get_module_pref("amount7");
        $amount8 = get_module_pref("amount8");
        $amount9 = get_module_pref("amount9");
        $amount10 = get_module_pref("amount10");
        $amount11 = get_module_pref("amount11");
        $amount12 = get_module_pref("amount12");
        $amount13 = get_module_pref("amount13");
        $amount14 = get_module_pref("amount14");
        $amount15 = get_module_pref("amount15");
        $amount16 = get_module_pref("amount16");
        $sick = get_module_pref("sick");
        $target1 =  get_module_pref("target1");
        $target2 =  get_module_pref("target2");
        $target3 =  get_module_pref("target3");
        $name1 = "Angelica stems";
        $name2 = "Arrowleaf clover";
        $name3 = "Mandrake root";
        $name4 = "Mugwort";
        $name5 = "Ragwort";
        $name6 = "Patchouli";
        $name7 = "Nux oil";
        $name8 = "Comfrey root";
        $name9 = "Castor root";
        $name10 = "Charcoal";
        $name11 = "Burdock Root";
        $name12 = "Blood root";
        $name13 = "Anise seeds";
        $name14 = "Balm of Gilead";
        $name15 = "Lavender";
        $name16 = "Bat guano";

                        if ($amount1 > 0) output("`^%s - `@%s `n",$name1,$amount1);
                        if ($amount2 > 0) output("`^%s - `@%s `n",$name2,$amount2);
                        if ($amount3 > 0) output("`^%s - `@%s `n",$name3,$amount3);
                        if ($amount4 > 0) output("`^%s - `@%s `n",$name4,$amount4);
                        if ($amount5 > 0) output("`^%s - `@%s `n",$name5,$amount5);
                        if ($amount6 > 0) output("`^%s - `@%s `n",$name6,$amount6);
                        if ($amount7 > 0) output("`^%s - `@%s `n",$name7,$amount7);
                        if ($amount8 > 0) output("`^%s - `@%s `n",$name8,$amount8);
                        if ($amount9 > 0) output("`^%s - `@%s `n",$name9,$amount9);
                        if ($amount10 > 0) output("`^%s - `@%s `n",$name10,$amount10);
                        if ($amount11 > 0) output("`^%s - `@%s `n",$name11,$amount11);
                        if ($amount12 > 0) output("`^%s - `@%s `n",$name12,$amount12);
                        if ($amount13 > 0) output("`^%s - `@%s `n",$name13,$amount13);
                        if ($amount14 > 0) output("`^%s - `@%s `n",$name14,$amount14);
                        if ($amount15 > 0) output("`^%s - `@%s `n",$name15,$amount15);
                        if ($amount16 > 0) output("`^%s - `@%s `n",$name16,$amount16);
                        if ($sick == 1 && $cure== 1) output("Ingredients needed for cure:`n `#%s`n %s`n %s",$target1,$target2,$target3);

    popup_footer();
    }


?>
