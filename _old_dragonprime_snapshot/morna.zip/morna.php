<?php
function morna_getmoduleinfo(){
	$info = array(
		"name"=>"Morna, a Sandeman W'woman",
		"author"=>"Coding by Silverfox<br>Text & Sandeman race by Ann Wilson",
		"version"=>"1.0",
		"category"=>"Forest Specials",
		"download"=>"http://dragonprime.net/users/ladymari/morna.zip",
		"vertxtloc"=>"http://dragonprime.net/users/ladymari/",
		"prefs"=>array(
			)
		);
	return $info;
}
function morna_install(){
	module_addeventhook("forest", "return 100;");
	return true;
}
function morna_uninstall(){
	return true;
}
function morna_dohook($hookname,$args){
return $args;
}
function morna_runevent(){
	global $session;
	$from = "forest.php?";
	$session['user']['specialinc'] = "module:morna";
	

	$op = httpget('op');
	if ($op=="" || $op=="search"){
		output("`n`n`6You happen across a small, young-looking woman with dark bronze skin and light blond hair twisted into a thick braid.");
		output("She is grooming what looks like a black unicorn with white mane, tail, and beard; neither seem to have noticed your approach.");
		output("Dressed in buckskins, with her braid definiing a line of gold the length of her spine, she looks entirely too young and innocent to be in the forest alone.");
		output("What do you do?");
		$session['user']['specialinc'] = "module:morna";
		addnav("Leave");
		addnav("Depart, leaving her to her chore",$from."op=depart");
		addnav("Attack her!",$from."op=attack");
		addnav("Make an admiring remark about the unicorn.","forest.php?op=admire");
		}
		if ($op==depart){
			output("Deciding discretion is the better part of valor, you leave the woman to her task.");
			output("After all, just because she doesn't look dangerous, you've learned that looks can be deceiving in the forest.");
			$session['user']['specialinc']="";
		}
		if ($op=="attack"){
        	output("You miss, astonished by the blinding speed of her reactions as she draws a dagger and the unicorn rears.");
        	output("The woman gets to you first, but not by much, and the last thing you hear as death claims you is a wry comment.");
        	output("\"Another one who didn�t get the word about that form of suicide, Calumet.\" ");
        	output("`4You are dead. All gold on hand has been lost.");
        	$session['user']['gold']=0;
        	$session['user']['hitpoints']=0;
        	$session['user']['alive']=false;
        	addnav("Daily news","news.php");
        	addnews("%s found out it was a really bad idea to attack a Sandeman W'woman in the forest.",$session['user']['name']);
        	$session['user']['specialinc']="";
		}
		if ($op=="admire"){
			output("She smiles, \"Calumet here isn�t a real unicorn; he�s a modified horse.");
			output("And yes, my people agree they�re beautiful.");
			output("But I forget my manners; I am Morna, a w'woman of Clan Leras.");
			output("And you are a fighter yourself, or you wouldn�t be here in the forest; would you care to test your skill?\"");
			addnav("Test your skill",$from."op=spar");
			addnav("No, thank you",$from."op=heckno");
		}
		if ($op=="spar") {
			output("You are dubious, but you agree, after introducing yourself.");
			output("You end up getting a strenuous hour-long workout, picking up some new moves and tactics � and you know she was holding back, that she could have defeated you easily in the first minute.");
			output("So you are surprised when she steps back and sheathes her weapon, smiling.");
			output("\"Not bad for a non-Sandeman, congratulations.\"");
			output("`n`n");
			$reward = round($session['user']['experience'] * 0.25, 0);
			output("`^You have gained `7%s`^ experience from sparring!", $reward);
			$session['user']['experience'] += $reward;
			$session['user']['turns']--;
		}
		if ($op=="heckno"){
			output("She chuckles, \"No guts, no glory � but I can�t fault your discretion.\"");
			$mornagold=50*$session['user']['level'];
            $mornagems=1+round($session['user']['level']*.5);
            output("`^She tosses you a small pouch, and you find %s gold and %s gems!",$mornagold,$mornagems);
            $session['user']['gold']+=$mornagold;
            $session['user']['gems']+=$mornagems;
            $session['user']['turns']--;
		}
	}

function morna_run(){
}
?>