<?
require_once "common.php"; 
output("<span style='color: #000000'>",true);
checkday(); 

$session[user][celmov]--;
$cm =$session[user][celmov];
output("you have  `6$cm `^moves left before you are too tired `n`n");
if ($session[user][celmov]<1){
output("you are too tired to continue `n`n");
redirect ("shades.php");
}
else{
page_header("The  Cellar"); 
addcommentary(); 
addnav("Search the cellar","cellar.php");
addnav("Retreat to the inn","inn2.php");

}
switch(e_rand(1,50)){ 
case 1:
output("`%You find nothing of interest"); 
break;  
case 2: 
output("`%You find nothing of interest"); 
break; 
case 3:
output("You find a bag of gold on the shelf");
$session[user][gold]+=10;
break; 
case 4:
output("`%You find nothing of interest"); 
break; 
case 5:
output("`%You find nothing of interest"); 
break; 
case 6:
output("You are attacked by a Giant Rat!`n");
$FR= e_rand(1,6);
  switch ($FR){
  case 1:
  output("You manage to get away unscathed");
  break;
  case 2:
  output("You fight a bloody battle and take 5 points damage");
  $session[user][hitpoints]-=10;
  break;
  case 3:
  
  case 4:
  case 5:
  output("you barely make it out alive");
  $session[user][hitpoints]=2;
  break;
  case 6:
  }
case 7:
$fg= e_rand(1,4);
output("you find a bag of gems");
$session[user][gems]+= $fg;
break;
case 8:
output("`%You find nothing of interest"); 
break; 
case 9:
output("`%You find nothing of interest"); 
break; 

case 10:
output("`%You find nothing of interest"); 
break; 
case 11:
output(" you fall into a pit in the floor!!! `n");
output("you manage to escape, but you  lose hitpoints and gold");
$session[user][gold]=0;
$session[user][gems]=0;
$session[user][hitpoints]=3;
break; 
case 12:
output("`%You find nothing of interest"); 
break; 
case 13:
output("`%You find nothing of interest"); 
break; 
case 14:
output("`%You find nothing of interest"); 
break; 
case 15:
output("`%You find nothing of interest"); 
break; 
case 16:
output("`%You find Thor's Hammer !!"); 
output(" instead of smashing it.. you slip it into your belt");
$session[user][attack]+=20;
$session[user][weapon]="Thor's Hammer!";
$session[user][weaponvalue]=1500;
$session[user][weapondmg]+=25;
break; 
case 17:
output("`%You find nothing of interest"); 
break; 
case 18:
output("`%You the bottle of champaign"); 
break; 
case 19:
output("`%You are attacked by a bat! `n");
$dg= e_rand(0,5);
$session[user][hitpoints]-= $dg;
output("you lose  $dg  hit points"); 
break; 
case 20:
output("`%You find nothing of interest"); 
break; 
case 21:
output("`%You find nothing of interest"); 
break; 
 case 22:
 output("`%You find nothing of interest"); 
break; 
  case 23:
  output("`%You find nothing of interest"); 
break; 
   case 24:
   output("`%You find nothing of interest"); 
break; 
   case 25:
   output("`%You find nothing of interest"); 
break; 
 case 26: 
 output(" you trip over a pole leaning against the wall`n");
 output("a beam falls from the rafters and kills you!!!");
 redirect ("shades.php");
 break;
 case 27:
 $bts = e_rand(1,10);
 output("you are attacked by  $bts  bats@!!!");
 output("you manage to fight them off but they take a toll...");
 $session[user][hitpoints]-= ($bts *2);
 break;
  
  case 28: 
 output("`%You find nothing of interest"); 
break; 
 case 29:
 output("`%You find nothing of interest"); 
break; 
  case 30:
output("you find some bread and decide you are hungry");
output("your attack improves");
$session[user][attack]+=2;
break;
case 31:
output("you find some bread and decide you are hungry");
output("oooo that bread was mouldy!!!");
output("your attack decreases");
$session[user][attack]-=2;
break;
 case 32: 
output("`%You find nothing of interest"); 
break; 
case 33: 
output("you find a small vial of liquid..");
$session[user][hitpoints]=$session[user][maxhitpoints];
output(" your hitpoints are restored to full health");
break;

case 34:
 $sx= e_rand(0,1);
 $session[user][sex]= $sx;
 output("you feel a bit different");
 break;
 
 case 35:
output("you find a small vial of liquid..");
$session[user][hitpoints]-=5;
output(" it was poison!!!");
output("you lose some hitpoints");
break;

 case 36: 
 output("`%You find nothing of interest"); 
break; 
 case 37: 
 output("`%You find nothing of interest"); 
break; 
 case 38:
 output("you step through a doorway and find yourself outside");
 redirect ("forest.php");
 break;
  case 39:
  output("`%You find nothing of interest"); 
break; 
case 40: 
output("`%You find nothing of interest"); 
break; 
case 41: 
output("`%You find nothing of interest"); 
break; 
case 42:
output("you find a small shield lying against a wall");
output("you slip it under your cape");
$session[user][armor]="Small Shield";
$session[user][armorvalue]=500;
$session[user][armordef]+=10;
break;
 case 43: 
output("`%You find nothing of interest"); 
break; 
case 44:
output("you find a keg of ale and drink way too much!!!");
output(" you pass out for a time");
output(" when you wake up you realize that too much time has passed!!!");
$session[user][celmov]=6;
Output(" you have only 5 moves left before you die!!!");
 case 45: 
 output("`%You find nothing of interest"); 
break; 
 case 46:
 output("`%You find nothing of interest"); 
break; 
  case 47:
 output(" you have spent far too much time down by the casks");
 $session[user][drunkeness]=85;
 break;
 
  case 48:
  output("`%You find nothing of interest"); 
break; 
   case 49:
   output("`%You find nothing of interest"); 
break; 
case 50:
output("`%You find nothing of interest"); 
break; 
}

page_footer();
?>