<?php
/*
Kirby's Cave - v1.2
Heroes of Ironthorne Keep
LotGD Conversion
http://hoik.ironthornekeep.com
Created by Eternal Rain
02/2005

NOTE: This mod also contains things specific to a certain guild in my game.  Please rem those lines out for your game or add/modify to fit your game.  Please keep the above information intact, but you may add your own info beneath it.  Thanks.

INSTALL:  
1. Copy/Move kirbycave1.php and kirbycave2.php into your main game folder
2. Create a link in your village.php (or where you would like it) - eg: addnav("Kirby's Cave","kirbycave1.php");
3. Open up PHPMyAdmin (or whatever you use), and create the following entries in your accounts table (Field, Type, Length, Attr, Null, Default, Extra):
			a) kirbyhp, INT, 11, [blank], not null, 0, [blank]
			b) kirbywt, INT, 11, [blank], not null, 0, [blank]
4. In newday.php, look for the following line around 308/309:
			output("`n`&You strap your `%".$session['user']['weapon']."`& to your back and head out for some adventure.`0");
			}
	Insert after:
		if ($session[user][spirits]==0){ $session[user][kirbyhp]-=1; $session[user][kirbywt]-=10;}
		if ($session[user][spirits]==1){ $session[user][kirbyhp]-=2; $session[user][kirbywt]-=15;}
		if ($session[user][spirits]==2){ $session[user][kirbyhp]-=3; $session[user][kirbywt]-=20;}
		if ($session[user][kirbyhp]<=0){$session[user][kirbyhp]=0;}
		if ($session[user][kirbywt]<=0){$session[user][kirbywt]=0;}
		if ($session[user][spirits]==0){ output("`n`n`@Starting the new day with normal spirits, you are allowed to buy an additional health potion and 10 stamina potions today!`n`n"); }
		if ($session[user][spirits]==1){ output("`n`n`@Starting the new day with high spirits, you are allowed to buy two additional health potions and 15 stamina potions today!`n`n"); }
		if ($session[user][spirits]==2){ output("`n`n`@Starting the new day with very high spirits, you are allowed to buy three additional health potions and 20 stamina potions today!`n`n"); }
*/

require_once "common.php";
page_header("Kirby's Cave");
checkday();

//Start - Edit This Part Out As This Was Specific To My Game
if($session[user][guildID]>0){
	
	$turncosta=200+($session[user][dragonkills]*21)+($session[user][level])+($session[user][level]);
	$turncostb=500+($session[user][dragonkills]*63)+($session[user][level])+($session[user][level]);
	$turncostc=950+($session[user][dragonkills]*105)+($session[user][level])+($session[user][level]);
	$turncostd=1800+($session[user][dragonkills]*210)+($session[user][level])+($session[user][level]);
	$turncoste=3900+($session[user][dragonkills]*462)+($session[user][level])+($session[user][level]);
	
	$mhpcosta=7500+($session[user][dragonkills]*31)+($session[user][level]);
	$mhpcostb=14000+($session[user][dragonkills]*62)+($session[user][level]);
	$mhpcostc=21000+($session[user][dragonkills]*93)+($session[user][level]);
				
}else{

	$turncosta=150+($session[user][dragonkills]*15)+($session[user][level])+($session[user][level]);
	$turncostb=420+($session[user][dragonkills]*45)+($session[user][level])+($session[user][level]);
	$turncostc=710+($session[user][dragonkills]*60)+($session[user][level])+($session[user][level]);
	$turncostd=1300+($session[user][dragonkills]*150)+($session[user][level])+($session[user][level]);
	$turncoste=2900+($session[user][dragonkills]*330)+($session[user][level])+($session[user][level]);
	
	$mhpcosta=5000+($session[user][dragonkills]*25)+($session[user][level]);
	$mhpcostb=9500+($session[user][dragonkills]*50)+($session[user][level]);
	$mhpcostc=14000+($session[user][dragonkills]*75)+($session[user][level]);
		
}

if($session[user][guildID]==11){

	$turncosta=round($turncosta*.97);
	$turncostb=round($turncostb*.97);
	$turncostc=round($turncostc*.97);
	$turncostd=round($turncostd*.97);
	$turncoste=round($turncoste*.97);
	
	$mhpcosta=round($turncosta*.97);
	$mhpcostb=round($turncostb*.97);
	$mhpcostc=round($turncostc*.97);

}

if($session[user][acctid]==168){

	$turncosta=round($turncosta*.95);
	$turncostb=round($turncostb*.95);
	$turncostc=round($turncostc*.95);
	$turncostd=round($turncostd*.95);
	$turncoste=round($turncoste*.95);
	
	$mhpcosta=round($turncosta*.95);
	$mhpcostb=round($turncostb*.95);
	$mhpcostc=round($turncostc*.95);

}

if($session[user][superuser]==2){

	$turncosta=round($turncosta*.75);
	$turncostb=round($turncostb*.75);
	$turncostc=round($turncostc*.75);
	$turncostd=round($turncostd*.75);
	$turncoste=round($turncoste*.75);
	
	$mhpcosta=round($turncosta*.75);
	$mhpcostb=round($turncostb*.75);
	$mhpcostc=round($turncostc*.75);

}

if($session[user][superuser]==3){

	$turncosta=round($turncosta*.50);
	$turncostb=round($turncostb*.50);
	$turncostc=round($turncostc*.50);
	$turncostd=round($turncostd*.50);
	$turncoste=round($turncoste*.50);
	
	$mhpcosta=round($turncosta*.50);
	$mhpcostb=round($turncostb*.50);
	$mhpcostc=round($turncostc*.50);

}
//End - Edit This Part Out As This Was Specific To My Game

if ($HTTP_GET_VARS[op]==""){ 

output("`b`%Kirby's Cave`b`n`n");
output("`8v1.1b - 02052005`n`n");

//Start - Edit This Part Out As This Was Specific To My Game
if($session[user][acctid]!=168){

//You may still want to keep this part in though *****
output("`!Entering the only cave in this side of the city adorned with glittering pink and violet coloured sparkles, a bulbulous looking thing shaped like a stuffed toy, floats around with a feather duster.  It manuevers in and out of the shelves and shelves and shelves of multi-coloured bottles and vials, filled with various bubbling liquids and goo.`n`n");
// *****

}else{
output("`!Floating into your uncle's shop, you manuevre in and out of the shelves and shelves and shelves of multi-coloured bottles and vials, filled with various bubbling liquids and goo, checking to see if everything is in order.  A moglin caretaker hops down and tells you that your uncle has given you `@5% off `!everything in the store.`n`n");
}
if($session[user][guildID]==11){
output("The moglin caretaker tells you that because you are a member of `%C:DOS United`!, you receive `#3% off`! everything in the store!`n`n");
}
if($session[user][superuser]==3){
output("`#Eternal Rain `2appears on your shoulder wearing angel clothes and tells you that you get `@50% off `2of everything here for all admin, and disappears afterwards!`n`n");
}
if($session[user][superuser]==2){
output("`#Eternal Rain `2appears on your shoulder wearing angel clothes and tells you that you get `@25% off `2of everything here for all moderators, and disappears afterwards!`n`n");
}
//End - Edit This Part Out As This Was Specific To My Game

output("`qA plastic sign hangs nearby listing... `n`n
`2`bPotions of Stamina (`^Resets at new day`2)`b`n
`51. One Extra Wilderness Turn - ".$turncosta."`n
`%2. Three Extra Wilderness Turns - ".$turncostb."`n
`53. Five Extra Wilderness Turns - ".$turncostc."`n
`%4. Ten Wilderness Turns - ".$turncostd."`n
`55. Twenty Two Extra Wilderness Turns - ".$turncoste."`n`n
`2`bPotions of Health (`^Carries over at BWMK`2)`b`n
`55. One Extra Max HP - ".$mhpcosta."`n
`%6. Two Extra Max HP - ".$mhpcostb."`n
`57. Three Extra Max HP - ".$mhpcostc."`n`n
");
$kirbyowt=30-$session[user][kirbywt];
$kirbyohp=4-$session[user][kirbyhp];
output("`6You have `^".$kirbyowt." `6stamina potions and `^".$kirbyohp." `6health potions left today.");

}

addnav("Potions of Stamina");
addnav("1?An Extra WT","kirbycave2.php?op=onewt");
addnav("2?3 Extra WT","kirbycave2.php?op=threewt");
addnav("3?5 Extra WT","kirbycave2.php?op=fivewt");
addnav("4?10 Extra WT","kirbycave2.php?op=tenwt");
addnav("5?22 Extra WT","kirbycave2.php?op=twentytwowt");
addnav("Potions of Health");
addnav("7?An Extra Max HP","kirbycave2.php?op=onemhp");
addnav("8?2 Extra Max HP","kirbycave2.php?op=twomhp");
addnav("9?3 Extra Max HP","kirbycave2.php?op=threemhp");

addnav("Other");
if($session[user][superuser]>=3){
addnav("New Day","newday.php"); }
addnav("Display Prices","kirbycave2.php");
addnav("Back to City","village.php");

if ($HTTP_GET_VARS[op]=="onewt"){ 

if($session[user][gold]<$turncosta){
output("`b`%Not enough gold!`b`n`n");
output("Kirby frowns at you and goes back to dusting the place.");

}else{

if (($session[user][kirbywt]+1)>30){
output("`6Unfortunately, Kirby can no longer sell you any more potions today.  Come back tomorrow.");

}else{

output("`!Kirby shoves his little hand inside his mouth and pulls out a vial of orange liquid.  He shakes it a bit before handing it to you.  A quick surge of energy coarses through your body.  You gain ONE TEMPORARY WILDERNESS TURN!  ".$turncosta." gold was taken from you.");
$session[user][gold]-=$turncosta;
$session[user][turns]++;
$session[user][kirbywt]++;
}
}
}

if ($HTTP_GET_VARS[op]=="threewt"){ 

if($session[user][gold]<$turncostb){
output("`b`%Not enough gold!`b`n`n");
output("Kirby frowns at you and goes back to dusting the place.");

}else{

if (($session[user][kirbywt]+3)>30){
output("`6Unfortunately, Kirby can no longer sell you any more potions today.  Come back tomorrow.");

}else{

output("`!Kirby shoves his little hand inside his mouth and pulls out a vial of red fizzly liquid.  He shakes it a bit before handing it to you.  A quick surge of energy coarses through your body.  You gain THREE TEMPORARY WILDERNESS TURNS!  ".$turncostb." gold was taken from you.");
$session[user][gold]-=$turncostb;
$session[user][turns]+=3;
$session[user][kirbywt]+=3;
}
}
}

if ($HTTP_GET_VARS[op]=="fivewt"){ 

if($session[user][gold]<$turncostc){
output("`b`%Not enough gold!`b`n`n");
output("Kirby frowns at you and goes back to dusting the place.");

}else{

if (($session[user][kirbywt]+5)>30){
output("`6Unfortunately, Kirby can no longer sell you any more potions today.  Come back tomorrow.");

}else{

output("`!Kirby shoves his little hand inside his mouth and pulls out a vial of purple bubbly liquid.  He shakes it a bit before handing it to you.  A quick surge of energy coarses through your body.  You gain FIVE TEMPORARY WILDERNESS TURNS!  ".$turncostc." gold was taken from you.");
$session[user][gold]-=$turncostc;
$session[user][turns]+=5;
$session[user][kirbywt]+=5;
}
}
}

if ($HTTP_GET_VARS[op]=="tenwt"){ 

if($session[user][gold]<$turncostd){
output("`b`%Not enough gold!`b`n`n");
output("Kirby frowns at you and goes back to dusting the place.");

}else{

if (($session[user][kirbywt]+10)>30){
output("`6Unfortunately, Kirby can no longer sell you any more potions today.  Come back tomorrow.");

}else{

output("`!Kirby shoves his little hand inside his mouth and pulls out a vial of yellow syrup.  He sniffs it a bit before handing it to you.  A quick surge of energy coarses through your body.  You gain TEN TEMPORARY WILDERNESS TURNS!  ".$turncostd." gold was taken from you.");
$session[user][gold]-=$turncostd;
$session[user][turns]+=10;
$session[user][kirbywt]+=10;
}
}
}

if ($HTTP_GET_VARS[op]=="twentytwowt"){ 

if($session[user][gold]<$turncoste){
output("`b`%Not enough gold!`b`n`n");
output("Kirby frowns at you and goes back to dusting the place.");

}else{

if (($session[user][kirbywt]+22)>30){
output("`6Unfortunately, Kirby can no longer sell you any more potions today.  Come back tomorrow.");

}else{

output("`!Kirby shoves his little hand inside his mouth and pulls out a vial of yellow syrup.  He sniffs it a bit before handing it to you.  A quick surge of energy coarses through your body.  You gain TWENTY TWO TEMPORARY WILDERNESS TURNS!  ".$turncoste." gold was taken from you.");
$session[user][gold]-=$turncoste;
$session[user][turns]+=22;
$session[user][kirbywt]+=22;
}
}
}

if ($HTTP_GET_VARS[op]=="onemhp"){ 

if($session[user][gold]<$mhpcosta){
output("`b`%Not enough gold!`b`n`n");
output("Kirby frowns at you and goes back to dusting the place.");

}else{

if (($session[user][kirbyhp]+1)>4){
output("`6Unfortunately, Kirby can no longer sell you any more potions today.  Come back tomorrow.");

}else{

output("`!Kirby shoots a thimble of green liquid at you.  You catch it in your mouth and you feel healthier.  You gain ONE Max HP!  ".$mhpcosta." gold was taken from you.");
$session[user][gold]-=$mhpcosta;
$session[user][maxhitpoints]++;
$session[user][hitpoints]++;
$session[user][kirbyhp]++;
}
}
}

if ($HTTP_GET_VARS[op]=="twomhp"){ 

if($session[user][gold]<$mhpcostb){
output("`b`%Not enough gold!`b`n`n");
output("Kirby frowns at you and goes back to dusting the place.");

}else{

if (($session[user][kirbyhp]+2)>4){
output("`6Unfortunately, Kirby can no longer sell you any more potions today.  Come back tomorrow.");

}else{

output("`!Kirby shoots a thimble of green liquid at you.  You catch it in your mouth and you feel healthier.  You gain TWO Max HP!  ".$mhpcostb." gold was taken from you.");
$session[user][gold]-=$mhpcostb;
$session[user][maxhitpoints]+=2;
$session[user][hitpoints]+=2;
$session[user][kirbyhp]+=2;
}
}
}

if ($HTTP_GET_VARS[op]=="threemhp"){ 

if($session[user][gold]<$mhpcostc){
output("`b`%Not enough gold!`b`n`n");
output("Kirby frowns at you and goes back to dusting the place.");

}else{

if (($session[user][kirbyhp]+3)>4){
output("`6Unfortunately, Kirby can no longer sell you any more potions today.  Come back tomorrow.");

}else{

output("`!Kirby shoots a thimble of green liquid at you.  You catch it in your mouth and you feel healthier.  You gain THREE Max HP!  ".$mhpcostc." gold was taken from you.");
$session[user][gold]-=$mhpcostc;
$session[user][maxhitpoints]+=3;
$session[user][hitpoints]+=3;
$session[user][kirbyhp]+=3;
}
}
}

page_footer();

?>