<?php
/*
Kirby's Cave - v1.2
Heroes of Ironthorne Keep
LotGD Conversion
http://hoik.ironthornekeep.com
Created by Eternal Rain
02/2005

NOTE: This mod also contains things specific to a certain guild in my game.  Please rem those lines out for your game or add/modify to fit your game.  Please keep the above information intact, but you may add your own info beneath it.  Thanks.

INSTALL:  
1. Copy/Move kirbycave1.php and kirbycave2.php into your main game folder
2. Create a link in your village.php (or where you would like it) - eg: addnav("Kirby's Cave","kirbycave1.php");
3. Open up PHPMyAdmin (or whatever you use), and create the following entries in your accounts table (Field, Type, Length, Attr, Null, Default, Extra):
			a) kirbyhp, INT, 11, [blank], not null, 0, [blank]
			b) kirbywt, INT, 11, [blank], not null, 0, [blank]
4. In newday.php, look for the following line around 308/309:
			output("`n`&You strap your `%".$session['user']['weapon']."`& to your back and head out for some adventure.`0");
			}
	Insert after:
		if ($session[user][spirits]==0){ $session[user][kirbyhp]-=1; $session[user][kirbywt]-=10;}
		if ($session[user][spirits]==1){ $session[user][kirbyhp]-=2; $session[user][kirbywt]-=15;}
		if ($session[user][spirits]==2){ $session[user][kirbyhp]-=3; $session[user][kirbywt]-=20;}
		if ($session[user][kirbyhp]<=0){$session[user][kirbyhp]=0;}
		if ($session[user][kirbywt]<=0){$session[user][kirbywt]=0;}
		if ($session[user][spirits]==0){ output("`n`n`@Starting the new day with normal spirits, you are allowed to buy an additional health potion and 10 stamina potions today!`n`n"); }
		if ($session[user][spirits]==1){ output("`n`n`@Starting the new day with high spirits, you are allowed to buy two additional health potions and 15 stamina potions today!`n`n"); }
		if ($session[user][spirits]==2){ output("`n`n`@Starting the new day with very high spirits, you are allowed to buy three additional health potions and 20 stamina potions today!`n`n"); }
*/

require_once "common.php";
page_header("Kirby's Cave");
checkday();


if($session[user][gems]<1){
output("`!As you enter, a sign falls down and smacks you out of the cave.  A kid walks by and stops to read the words imprinted on your body, `#One gem to enter Kirby's`!, then hops away playfully.");
addnav("Get Up","village.php");

}else{
$session[user][gems]--;
output("`!You toss a gem into the hole in the wall and continue into the cave...");
addnav("Continue to cave","kirbycave2.php");
}

page_footer();

?>