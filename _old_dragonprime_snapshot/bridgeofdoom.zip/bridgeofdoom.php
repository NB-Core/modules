<?
/*bridge of doom by Nick Puleo
http://www.happyapplefarm.net */
require_once "common.php";
checkday();

page_header("Bridge of Doom");
output("`c`b`&Bridge of DOOOOOOOOM!`0`b`c");
	
if ($HTTP_GET_VARS[op]==""){
        addnav("Return to the village","village.php");
	addnav("Jump off the Bridge","bridgeofdoom.php?op=jump");
	output("`!On the other edge of town there is a bridge the crosses a huge casm.  Looking down you see a VERY fast moving river.`n`n");
	}
	
//die
else if ($HTTP_GET_VARS[op]=="jump"){
      $chanceofsurvival=e_rand(0,100);
      if ($chanceofsurvival>1){
      output("`!You jump......`n`nYou fall........`n`nYou`$ DIE!`n`n");
      $session[user][alive]=false;
      $session[user][hitpoints]=0;
      output("`!Because you braved the jump, and, because you were incredibly stupid, have some EXPIERENCE!`n`n");
      $xp=$session[user][level]*50;
       output("`@You gain `^$xp `@expierence.");
       $session[user][ experience]+=$xp;
       output("`n`n of course, you are dead now....");
      addnav("Daily News","news.php");
      addnews("`%".$session[user][name]."`3 decided life wasn't worth living, and jumped off a bridge.");
      }
      else{
      output("`!You jump......`n`nYou fall........`n`nYou`@ LIVE!`n`n");
      $session[user][hitpoints]+=250;
      output("`!Because you braved the jump, and, because you were incredibly stupid and SURVIVED, have some EXPIERENCE!`n`n");
      $xp=$session[user][level]*50;
       output("`@You gain `^$xp `@expierence.");
       $session[user][ experience]+=$xp;
       $session[user][gems]+=10;
       output("`@You climb back up the side of the cliff, on your way you find `$10 GEMS!!! `@in the rocks`n`n");
        addnav("Daily News","news.php");
	addnav("Return to Village","village.php");
      addnews("`%".$session[user][name]."`3 jumped off the bridge, and lived to tell his tale!");
      }
 }
page_footer();
?>
