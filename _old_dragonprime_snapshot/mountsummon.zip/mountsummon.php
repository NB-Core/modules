<?php
/*
1.0 lets you switch your mount_buff on-off - it is deliberate that you need to be wounded to summon/unsommon....
*/

function mountsummon_getmoduleinfo()
{
	$info = array
		(
		"name"=>"Mount Summoning",
		"version"=>"1.0",
		"author"=>"`2Oliver Brendel",
		"description"=>"This module grants the user the power to switch his mount buff on/off at the healer",
		"category"=>"Forest",
		"download"=>"http://dragonprime.net/dls/mountsummon.zip",
		);
	return $info;
}

function mountsummon_install(){
	module_addhook("potion");
	return true;
}

function mountsummon_uninstall(){
	return true;
}

function mountsummon_dohook($hookname,$args){
	global $session;
	switch ($hookname)
	{
	case "potion":
		addnav("Special Services");
		if (has_buff('mount')) {
			if ($session['bufflist']['mount']['suspended']) {
				$sw=1;
				$action=translate_inline("Summon");
			} else {
				$sw=0;
				$action=translate_inline("Unsummon");
			}
			addnav(array("%s your mount",$action),"runmodule.php?module=mountsummon&op=$sw");
		}
		output("`n`n`3You can also let me summon or unsummon your mount for you... this is a free service.");
		break;
	}
	return $args;
}

function mountsummon_run()
{
	global $session;
	page_header("Healer's Hut");	
	addnav("Back to the Healer","healer.php");
	output("`#`b`cHealer's Hut`c`b`n");
	require_once("lib/battle-skills.php");
	$op = httpget('op');
	switch ($op) {
	case 1:
		output("`3The small bizzare creature intonates some strange syllables... and you see that at your side your beloved companion appears...");
		output_notl("`n`n");
		unsuspend_buff_by_name('mount','`3You feel full of new inspiration along with your mount.');
		break;
	case 0:
		output("`3The small bizzare creature intonates some strange syllables... and you see your beloved companion disappearing...");
		output_notl("`n`n");
		suspend_buff_by_name('mount','`3You will certainly miss your fellow comrade...');
		break;
	}	
	page_footer();
}


?>