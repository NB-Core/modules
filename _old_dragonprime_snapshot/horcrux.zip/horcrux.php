<?php
require_once("lib/http.php");
require_once("lib/villagenav.php");

function horcrux_getmoduleinfo() {
	$info = array(
		"name"		=>	"Horcrux",
		"version"	=>	"1.01",
		"category"	=>	"PvP",
		"download"	=>	"http://cap.portalkeeper.info/lotgd/horcrux.zip",
		"vertxtloc"	=>	"http://cap.portalkeeper.info/lotgd/",
		"author"		=> "<a href='http://cap.portalkeeper.info/'>Nicholas Moline</a>",
		"settings"	=>	Array(
			"Horcrux - Main Settings,title",
			"maxhorcri"		=>	"Maximum number of Horcruxes a person can have?,int|10",
			"minimumali"	=>	"Alignment must be at least how low to get/have horcrux?,int|0",
			"loseali"		=> "Alignment player will lose with each new horcrux,int|100",
			"killnum"		=> "Number of players player must kill sequentially to gain a horcrux,int|5",
		),
		"prefs"		=> Array(
			"Horcrux - User Settings,title",
			"num"		=> "Number of horcruxes player has,int|0",
			"killed"	=>	"Number of players killed in this sequence,int|0",
		),
		"requires"	=>	Array(
			"alignment"	=>	"Alignment Mod http://dragonprime.net/users/Sichae/alignment.zip",
		),
	);
	return $info;
}

function horcrux_install() {
	module_addhook("footer-shades");
	module_addhook("footer-graveyard");	
	module_addhook("biostat");
	module_addhook("battle-victory");
	module_addhook("charstats");
	return true;
}

function horcrux_uninstall() {
	return true;
}

function horcrux_dohook($hookname,$args) {
  	global $session;
   $uid = $session['user']['acctid']; 
	switch ($hookname) {
		case "footer-shades":
		case "footer-graveyard":
			if (get_module_pref("num") > 0) {
				redirect("runmodule.php?module=horcrux&op=rebirth");
			}
			break;
		case "biostat":
			$horcri = get_module_pref("num","horcrux",$args['acctid']);
			if ($horcri > 0) {
			  	output("`$Has a Horcrux available`0`n");
			}
			break;
		case "battle-victory":
			if ($args['type'] == "pvp") {
				$align = get_module_pref("alignment","alignment");
				if ($align <= get_module_setting("minimumali")) {
					set_module_pref("killed",get_module_pref("killed") + 1);
					if (get_module_setting("killnum") <= get_module_pref("killed")) {
					  	$horcri = get_module_pref("num");
						if ($horcri < get_module_setting("maxhorcri")) {
							output("`n`nWith this murder you utter the spell to split your soul.  You now have a horcrux to save you from death");
							
							$horcri++;
							set_module_pref("num",$horcri);
							set_module_pref("killed",0);
							output("`nYou now have %s Horcruxes available!`n",$horcri);
							$align = $align - get_module_setting("loseali");
							set_module_pref("alignment",$align,"alignment");
							output("`nYou find yourself significantly more evil for creating a horcrux.");
						}
					}
				}
			}
			break;
		case "charstats": 
			if (get_module_pref("alignment","alignment") <= get_module_setting("minimumali")) {
				setcharstat("Equipment Info","Horcruxes",get_module_pref("num"));
			}
			break;
	}
	return $args;
}

function horcrux_run (){
	global $session;
	$op = httpget("op");
	if ($op == "rebirth") {
		$horcri = get_module_pref("num");
		if ($horcri > 0) {
         $horcri--;
         set_module_pref("num",$horcri);
			page_header("Horcrux Revival");
			if ($horcri == 1) { $text = "1 horcrux"; } else { $text = $horcri . " horcruxes."; }
         output ("`n`nYou call upon the power of the horcrux to save yourself from death!`n`nYou have" . $text . " left.  You feel you should slay some more mortals in order to increase your available horcruxes.");
			addnav("Continue","newday.php?resurrection=true");	
			page_footer();		
		}
	}
}
?>
