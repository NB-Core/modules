<?php
// translator ready
// mail ready
// addnews ready
function pitofdoom_getmoduleinfo(){
	$info = array(
		"name"=>"Pit Of Doom?",
		"version"=>"1.2.1",
		"author"=>"Peter Corcoran - Spell Check by Lee Thomas",
		"category"=>"Forest Specials",
		"download"=>"http://dragonprime.net/users/R4000/pitofdoom-sc.txt",
	);
	return $info;
}

function pitofdoom_install(){
	module_addeventhook("forest", "return 100;");
	return true;
}

function pitofdoom_uninstall(){
	return true;
}

function pitofdoom_dohook($hookname,$args){
	return $args;
}

function pitofdoom_runevent($type,$link) {
	global $session;
	$from = $link;
	$op = httpget('op');
	$session['user']['specialinc'] = "module:pitofdoom";
	$rand = e_rand(1,15);
	$op = httpget('op');
	if($op != "getupandwalkaway"){
		output("`2As you walk along casually you fall down a pit with tons of spikes laid in the bottom.`n`n");	
		switch ($rand){
			case 1:
			case 2:
			case 3:
			case 5:
			case 6:
			case 7:
			case 8:
			case 9:
			case 10:
			case 11:
			case 12:
			case 13:
				output("`2You quickly scramble up and wonder, \"what the...?!???!!\"`nSuddenly you notice you fell on top of somebody else's body!`n");
				output("`2Ewwwww.`n`n");
				switch(e_rand(1,4)){
					case 1:
						output("`2Although you may have been saved. You have managed to spike your toe on a spike.`n`n`^You lose 10 hitpoints!`n`n");
						$session['user']['hitpoints'] -= 10;
						break;
					case 2:
						output("`2Although you may have been saved. You have managed to spike your toe on a spike.`n`n`^Bad luck. The tips where poisoned. Your performance has been affected.`n`n");
                      				$poisonrounds = e_rand(20,30);
                       				$atkresult1 = e_rand(20,30);
                       				$defresult1 = e_rand(20,30);
			     			$poisonbuff = array(
								"name"=>"`5Poison Spike",
								"rounds"=>$poisonrounds,
								"wearoff"=>"`7You feel slightly better after you recover from the poison.",
								"atkmod"=>$atkresult1 / 100,
								"defmod"=>$atkresult1 / 100,
                        					"survivenewday"=>1,
								"roundmsg"=>"`7The poison in your blood spoils your attack!",
								"schema"=>"module-pitofdoom"
			      					);
			      			apply_buff("poisonbuff",$poisonbuff);
						break;
					case 3:
					case 4:
						break;
				}
				$possable = array("gems","gold","potion","forestf","lodge");
				if(is_module_active("coins")){
					$possable[] = "magicalcoin";
				}
				$len = count($possable);
				$got = array();
				for ($i = 1; $i <= 5; $i++) {
					$rand1 = e_rand(1,10);
					$rand2 = e_rand(1,10);
					if($rand1 == $rand2){
						$rand3 = e_rand(1,$len);
						$got[] = $possable[$rand3];
					}
				}
				output("`^You think it would be wise to search the dead body for valuables. You find...`n");
				if(count($got) <= 0){
					output("`^...Nothing at all!");
				} else {
					foreach($got as $key=>$val){
						switch($val){
							case "gems":
								$amt = e_rand(1,10);
								output("`^...%s gems.`n",$amt);
								debuglog("found $amt gems on dead body.");
								$session['user']['gems'] += $amt;
								break;
							case "gold":
								$amt = e_rand(1,($session['user']['gold']/2)+2);
								output("`^...%s gold coins.`n",$amt);
								debuglog("found $amt gold on dead body.");
								$session['user']['gold'] += $amt;
								break;			
							case "potion":
								output("`^...A potion, You quickly chug it down and gain 30 hitpoints!`n");
								$session['user']['hitpoints'] += 30;
								break;
							case "forestf":
								output("`^...A magical scroll, You recite it and gain 2 forest fights!`n");
								$session['user']['turns']+=2;
								break;	
							case "lodge":
								output("`^...A membership card for the Hunters Lodge. With 50 points on it!`n");			
								$session['user']['donation'] += 50;
								break;
							case "magicalcoin":
								output("`^...A weird looking magical coin`n");
								set_module_pref("magicalcoin",1,"coins");
								break;
						}
					}
				}
			break;
			case 4:
			case 15:
				output("`2You fall screaming into the pit of doom.`n");
				output("`^You are DEAD!`n");
				output("You lose 5% of your experience.`n");
				output("You may continue playing again tomorrow.");
				$session['user']['alive']=false;
				$session['user']['hitpoints']=0;
				$session['user']['experience']*=0.95;
				$session['user']['gold'] = 0;
				addnav("Daily News","news.php");
				$session['user']['specialinc'] = "";
				addnews("%s was last seen along a rugged trail deep in the forest.",$session['user']['name']);	
				break;			
		}
		if($session['user']['alive'] == TRUE){
			addnav("Get up and walk away","forest.php?op=getupandwalkaway");
		}
	} else {
		$session['user']['specialinc'] = "";
		output("`2You scramble out of the pit and walk off looking unsatisfied.");
	}
}

function pitofdoom_run(){
}
?>