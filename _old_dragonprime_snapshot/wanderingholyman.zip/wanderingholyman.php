<?php
/*
History Log:
 v1.
	5/17/05
 o Navs complete, tested
*/


//Code will switch based on choice and amount donated, and change alignment
function wanderingholyman_getmoduleinfo(){
	$info = array(
		"name"=>"The Wandering Holy Man",
		"version"=>"1.",
		"author"=>"`2Jon Jagan, Six",
		"category"=>"Forest Specials",
		"download"=>"",
		"settings"=>array(
			"Wandering Holy Man - Preferences,title",
			"aligngood"=>"Gain how many alignment points for small donation?,int|5",
			"alignbetter"=>"Gain how many alignment points for medium donation?,int|10",
			"alignbest"=>"Gain how many alignment points for large donation?,int|15",	
			"alignbad"=>"Lose how many alignment points for stealing?,int|5",				
		),			
		"prefs"=>array(
			"holyman"=>"Seen the Holy Man this newday?,bool|0",
			),
	);
	return $info;
}

function wanderingholyman_chance() {
	global $session;
	return 100;
}

function wanderingholyman_install(){
	module_addeventhook("forest","require_once(\"modules/wanderingholyman.php\"); 
	return wanderingholyman_chance();");
	module_addhook("newday");
	return true;
}

function wanderingholyman_uninstall(){
	return true;
}

function wanderingholyman_dohook($hookname,$args){
	global $session;
	switch ($hookname) {
		case "newday":
			set_module_pref("holyman",0);
			break;
	}
	return $args;
}

function wanderingholyman_runevent($type) {
	global $session;
	$session['user']['specialinc']="module:wanderingholyman";
	$op = httpget('op');
	$smallcashonhand = $session['user']['gold']*.1;
	$halfcashonhand = $session['user']['gold']*.5;
	$allcashonhand = $session['user']['gold'];

	if ($op==""){

		output("`n`7As you search around the shrubbery looking for your next victim, a flash of deja vu causes you to stumble");
		output("and pause. Shaking your head you try to remember what you were thinking just before.... what was it?");
		output("Some deep insight seemed to be moments away from enlightening you, but you fear it may be lost. ");
		output("You decide to retrace your steps from your last forest battle.`n`n");
		output("Walking back, you see the last creature lying dead. Standing over it is an old man in tattered burlap.");
		output("He looks at you with bright blue eyes as you approach, his pale wrinkled hands grasping a staff. ");
		output("Around his waist is a simple rope belt and a small leather pouch hangs from it. An old varnished cross");
		output("on a chain adorns his neck and you notice rosary beads around his left wrist. As he pulls back his hood");
		output("and reveals his sparse white hair, you hear a distinctive jingle from the pouch.`n`n");
		output("`&My child, glad I am to meet you, `7he says.`n");
		output("`&I am in great need of donations, which I am using to purchase land for a school further south. There are many");
		output("orphans created by warriors in these parts, orphans who have no food, clothes, or education. Please");
		output("find it in your heart to spare whatever you may, and I give you my oath that every single piece of gold");
		output("will be used to help the poor children.`n`n");
		output("`7He looks at you with pleading eyes and awaits your response`n`n");

		if ($session['user']['gold'] != 0) {
		addnav("Tell me more","forest.php?op=moreholyman");
		addnav(array("Give %s gold",$smallcashonhand),"forest.php?op=smalldonation");
		addnav(array("Give %s gold",$halfcashonhand),"forest.php?op=mediumdonation");
		addnav(array("Give %s gold",$allcashonhand),"forest.php?op=largedonation");
		addnav("Steal his pouch","forest.php?op=stealfromholyman");
		addnav("Leave", "forest.php?op=leaveholyman");
		}

		else {
		output("`n`7You reach for your money and realize you have none. The old man's face falls, and you shrug.");
		output("You turn from the wandering holy man and remember you were supposed to be remembering something...`n");
		output("What was it? Something enlightening...");
		$session['user']['specialinc']="";
		addnav("To the forest","forest.php");
		}

		
	}

	elseif ($op=='leaveholyman') { 
			global $session;
		output("`n`7You turn from the wandering holy man and remember you were supposed to be remembering something...`n");
		output("What was it? Something enlightening...");
		$session['user']['specialinc']="";
		addnav("To the forest","forest.php");
	}

	elseif ($op=='moreholyman') {
			global $session;
			output("`n`7Wanting some more information before you decide whether to donate to the poor needy children,");
			output("you ask the decrepit old man for a description of the school and the orphans.`n`n");
			output("`&My child, the school is currently a one room facility barely suited to their needs");
			output("and horribly overcrowded. We have a dozen orphans right now with only a single");
			output("change of clothes, and a simple stream on the property for washing. With the money");
			output("I raise on this trip I will be able to complete a double privy with heated seats. Any");
			output("extra donations I receive I can use to purchase materials needed to fashion clothing for");
			output("the poor children. We have also been negotiating with a local church to procure mortar and");
			output("plaster, which we will use to seal the cracks in the buildings. Anything you can find in your");
			output("heart to donate will greatly be appreciated.`n`n");
			output("`7The old man jingles his pouch excitedly as he talks, and you wonder how much gold it contains.");
	
		addnav(array("Give %s gold",$smallcashonhand),"forest.php?op=smalldonation");
		addnav(array("Give %s gold",$halfcashonhand),"forest.php?op=mediumdonation");
		addnav(array("Give %s gold",$allcashonhand),"forest.php?op=largedonation");
		addnav("Steal his pouch","forest.php?op=stealfromholyman");
		addnav("Leave", "forest.php?op=leaveholyman");


	}

		elseif ($op=='smalldonation') {
			global $session;
		$session['user']['gold'] -= $smallcashonhand;
			output("`n`7You think to yourself you'd like to help, but not much, and reach into your own money pouch. ");
			output("Your fingers expertly bypass the large coins and settle on the small. ");
			output("Pulling the small change out you are careful not to let the rest of your funds jingle and ");
			output("betray your thriftiness. You hand over your contribution and the old holy man's eyes light up.`n`n");
			output("`&Oh thank the heavens for kind souls like you! `7he says.`n");
			output("`&Every bit of donations helps, and the children back home will certainly be more");
			output("receptive to my religious teachings and attempts to educate them when they are able to"); 
			output("wear new clothes and sit in a heated privy. God bless you my child.`n`n");
			output("`7The old man smiles kindly at you and you feel better.");
		// increase alignment
		$align = get_module_setting("aligngood");
		set_module_pref("alignment",get_module_pref("alignment","alignment")+$align,"alignment");
		addnav("Leave", "forest.php?op=leaveholyman");
		}

		elseif ($op=='mediumdonation'){
		global $session;
		$session['user']['gold'] -= $halfcashonhand;
			output("`n`7You think to yourself you'd like to help, and reach into your own money pouch. Your fingers grab half of the gold coins and you pull them out. When you hand over the donation to the old man, his face beams.`n`n");
			output("`&Oh thank the heavens for kind souls like you! `7he says.`n`&Every bit of donations helps, and the children back home will certainly be more receptive to my religious teachings and attempts to educate them when they are able to wear new clothes and sit in a heated privy. God bless you my child.`n`n");
			output("`7The old man smiles warmly at you and you feel much better.");
		// increase alignment
		$align = get_module_setting("alignbetter");
		set_module_pref("alignment",get_module_pref("alignment","alignment")+$align,"alignment");
		addnav("Leave", "forest.php?op=leaveholyman");
		}

		elseif ($op=='largedonation') {
		global $session;
		$session['user']['gold'] -= $allcashonhand;
			output("`n`7The old holy man's story and personal sacrifice moves you greatly, and you hand over your entire money pouch. The look of joy and wonder on his old face almost brings tears to your eyes. `n`n");
			output("`&Oh thank the heavens for kind souls like you! `7he says.`n`&God bless you my child.`n`n`7The old man smiles warmly at you and you feel your heart lighten.");
		// increase alignment
		$align = get_module_setting("alignbest");
		set_module_pref("alignment",get_module_pref("alignment","alignment")+$align,"alignment");
		addnav("Leave", "forest.php?op=leaveholyman");
		}

		elseif ($op=='stealfromholyman') {
		global $session;
			output("`n`7You pretend like you are considering, then suddenly snatch the money pouch from the old man's waist. The old rope belt breaks and his tattered robes fall open. `n`n`&My poor child! `7he exclaims.`n");
			output("`&There are more needy people in this world than you, and you are so quick to steal from them? I have only just begun my travels, in search of funds for my orphans. May God have mercy on your poor soul. I will pray for you.`n`n");
			output("`7The old man drops to kis knees in prayer, oblivious to the fact that his body is partially revealed. You open the pouch and see that there are only a few shiny bits of foreign coin,");
			output("completely unusable in this realm. You throw the pouch to the ground in disgust and feel your heart grow heavy as the old holy man's prayers penetrate.");
		// decrease alignment
		$align = get_module_setting("alignbad");
		set_module_pref("alignment",get_module_pref("alignment","alignment")-$align,"alignment");
		addnav("Leave", "forest.php?op=leaveholyman");
		}
		
}

//function added by sixf00t4
function wanderingholyman_leave(){
//lets them leave
}

?>
