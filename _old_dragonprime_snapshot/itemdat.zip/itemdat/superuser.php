<?php
if (is_module_active('itemdat_editor')) {
	addnav('Module Configurations');
	if ($session['user']['superuser'] & SU_EDIT_MOUNTS)	addnav('Item Editor','runmodule.php?module=itemdat_editor');
}
?>
