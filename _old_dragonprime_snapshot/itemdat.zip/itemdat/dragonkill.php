<?php
$sql = "SELECT iclass FROM ".db_prefix('itemclass')." WHERE dk=1 ORDER BY iclass";
$result = db_query($sql);
for ($i=0;$i<db_num_rows($result);$i++){
	$row = db_fetch_assoc($result);
		if (!$iclass) $iclass = "itemclass='{$row['iclass']}' ";
		elseif (!$row['iclass']=='') $iclass.="OR itemclass='{$row['iclass']}' ";
}
if ($iclass){
   	$sql = "DELETE FROM ".db_prefix('itemdat')." WHERE ($iclass) AND ownerid={$session['user']['acctid']} AND activate=1";
   	db_query($sql);
}
?>
