<?php
if (!db_table_exists(db_prefix('itemdat'))){
	$sql="CREATE TABLE ".db_prefix('itemdat')." (
		itemid int(11) unsigned NOT NULL auto_increment,
        itemname varchar(100) NOT NULL default '',
        itemclass varchar(100) NOT NULL default '',
		ownerid int(11) unsigned NOT NULL default '0',
        ownername varchar(100) NOT NULL default '',
		itemdesc text NOT NULL,
		activate tinyint(1) NOT NULL default '0',
		itemv1 varchar(100) NOT NULL default '0',
		itemv2 varchar(100) NOT NULL default '0',
		itemv3 varchar(100) NOT NULL default '0',
		itemcost1 varchar(100) NOT NULL default '0',
		itemcost2 varchar(100) NOT NULL default '0',
		itemcost3 varchar(100) NOT NULL default '0',
		itembuff text NOT NULL,
		PRIMARY KEY (itemid)
		) TYPE=MyISAM AUTO_INCREMENT=2210" ;
	db_query($sql);
}
if (!db_table_exists(db_prefix('itemclass'))){
	$sql="CREATE TABLE ".db_prefix('itemclass')." (
        iclass varchar(100) NOT NULL default '',
        dk tinyint(1) NOT NULL default '0',
		buff tinyint(1) NOT NULL default '0',
		rate tinyint(3) NOT NULL default '0',
		pvp tinyint(3) NOT NULL default '0',
		death tinyint(3) NOT NULL default '0',
		trade tinyint(1) NOT NULL default '0',
        dort varchar(100) NOT NULL default '',
        loc varchar(100) NOT NULL default '',
        mob varchar(100) NOT NULL default '',
		mindk tinyint(4) NOT NULL default '0',
		maxdk tinyint(4) NOT NULL default '0',
		minlvl tinyint(2) NOT NULL default '0',
		maxlvl tinyint(2) NOT NULL default '0',
		nclass varchar(100) NOT NULL,
		dv1 varchar(100) NOT NULL default '0',
		dv2 varchar(100) NOT NULL default '0',
		dv3 varchar(100) NOT NULL default '0',
		count tinyint(1) NOT NULL default '0',
		ac tinyint(1) NOT NULL default '0',
		act tinyint(1) NOT NULL default '0',
		PRIMARY KEY (iclass)
		) TYPE=MyISAM AUTO_INCREMENT=2210" ;
	db_query($sql);
}
	global $session;
	module_addhook('superuser');
	module_addhook('pvpwin');
	module_addhook('pvploss');
	module_addhook('battle-victory');
	module_addhook('battle-defeat');
	module_addhook('dragonkill');
	module_addhook('newday');
	module_addhook('newday-runonce');
?>
