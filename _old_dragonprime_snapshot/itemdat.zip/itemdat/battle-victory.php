<?php
if (is_module_active('rsequip') && get_module_pref('inhalt','rsequip')>=get_module_pref('groesse','rsequip')){
	output("`n`#Dein Rucksack ist voll, deshalb kannst du nichts mehr aufnehmen!`n`n");
	return $args;
}
$sql = "SELECT mob,iclass FROM ".db_prefix('itemclass')." WHERE mob!='' ORDER BY iclass";
$result1=db_query($sql);
for ($i=0;$i<db_num_rows($result1);$i++){
   	$row1 = db_fetch_assoc($result1);

	$mlist=explode(",",$row1['mob']);
	for($j=0;$j<=count($mlist);$j++){
		if (strstr($args['creaturename'], $mlist[$j])){
			if (!$iclass) $iclass = "".db_prefix('itemdat').".itemclass='{$row1['iclass']}' ";
				elseif (!$row1['iclass']=='') $iclass.="OR ".db_prefix('itemdat').".itemclass='{$row1['iclass']}' ";
		}
	}
}
if ($iclass){
	$sql = "SELECT ".db_prefix('itemdat').".*,".db_prefix('itemclass').".nclass
		FROM ".db_prefix('itemdat')." LEFT JOIN ".db_prefix('itemclass')."
		ON ".db_prefix('itemdat').".itemclass=".db_prefix('itemclass').".iclass
		WHERE ".db_prefix('itemclass').".rate>=".e_rand(1,100)."
		AND (".db_prefix('itemclass').".dort='' OR ".db_prefix('itemclass').".dort LIKE '%".substr($args['type'], 0, 2)."%')
		AND (".db_prefix('itemclass').".loc='' OR ".db_prefix('itemclass').".loc LIKE '%".substr($session['user']['location'], 0, 2)."%')
		AND ".db_prefix('itemclass').".mindk<={$session['user']['dragonkills']}
		AND (".db_prefix('itemclass').".maxdk>={$session['user']['dragonkills']} OR ".db_prefix('itemclass').".maxdk=(-1))
		AND ".db_prefix('itemclass').".minlvl<={$session['user']['level']}
		AND ".db_prefix('itemclass').".maxlvl>={$session['user']['level']}
		AND ($iclass)
		AND ".db_prefix('itemdat').".ownerid=0
		AND ".db_prefix('itemdat').".activate=1
  		ORDER BY rand(".e_rand().") LIMIT 1";
}else{
	$sql = "SELECT ".db_prefix('itemdat').".*,".db_prefix('itemclass').".nclass
		FROM ".db_prefix('itemdat')." LEFT JOIN ".db_prefix('itemclass')."
		ON ".db_prefix('itemdat').".itemclass=".db_prefix('itemclass').".iclass
		WHERE ".db_prefix('itemclass').".rate>=".e_rand(1,100)."
		AND (".db_prefix('itemclass').".dort='' OR ".db_prefix('itemclass').".dort LIKE '%".$args['type']."%')
		AND (".db_prefix('itemclass').".loc='' OR ".db_prefix('itemclass').".loc LIKE '%".$session['user']['location']."%')
		AND ".db_prefix('itemclass').".mob=''
		AND ".db_prefix('itemclass').".mindk<={$session['user']['dragonkills']}
		AND (".db_prefix('itemclass').".maxdk>={$session['user']['dragonkills']} OR ".db_prefix('itemclass').".maxdk=(-1))
		AND ".db_prefix('itemclass').".minlvl<={$session['user']['level']}
		AND ".db_prefix('itemclass').".maxlvl>={$session['user']['level']}
		AND ".db_prefix('itemdat').".itemclass=".db_prefix('itemclass').".iclass
		AND ".db_prefix('itemdat').".ownerid=0
		AND ".db_prefix('itemdat').".activate=1
  		ORDER BY rand(".e_rand().") LIMIT 1";
}
$result=db_query($sql);
$row = db_fetch_assoc($result);

if ($row['nclass']){
	$sql="INSERT INTO ".db_prefix('itemdat')."(itemname,itemclass,ownerid,ownername,itemdesc,activate,itemv1,itemv2,itemv3,itemcost1,itemcost2,itemcost3,itembuff)
		VALUES ('{$row['itemname']}'
				,'{$row['nclass']}'
				,{$session['user']['acctid']}
				,'{$session['user']['name']}'
				,'".addslashes($row['itemdesc'])."'
				,1
				,'".($row['itemv1']?$row['itemv1']:0)."'
				,'".($row['itemv2']?$row['itemv2']:0)."'
				,'".($row['itemv3']?$row['itemv3']:0)."'
				,'".($row['itemcost1']?$row['itemcost1']:0)."'
				,'".($row['itemcost2']?$row['itemcost2']:0)."'
				,'".($row['itemcost3']?$row['itemcost3']:0)."'
				,'{$row['itembuff']}')";
   	db_query($sql);
}elseif ($row['itemid']){
	$sql="UPDATE ".db_prefix('itemdat')." SET ownerid={$session['user']['acctid']}, ownername='{$session['user']['name']}' WHERE itemid={$row['itemid']}";
	db_query($sql);
}
if ($row['itemid'] && get_module_pref('inhalt','rsequip')<get_module_pref('groesse','rsequip')){
		output("`n`#Beim Durchsuchen von %s `#findest du `&%s`#! (%s)`n`n`#", $args['creaturename'], $row['itemname'], $row['itemdesc']);
}elseif (!is_module_active('rsequip') && $row['itemid']){
	output("`n`#Beim Durchsuchen von %s `#findest du `&%s`#! (%s)`n`n`#", $args['creaturename'], $row['itemname'], $row['itemdesc']);
}
?>
