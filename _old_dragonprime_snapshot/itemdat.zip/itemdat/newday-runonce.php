<?php
$sql = "SELECT iclass FROM ".db_prefix('itemclass')." WHERE act=1 ORDER BY iclass";
$result = db_query($sql);
for ($i=0;$i<db_num_rows($result);$i++){
	$row = db_fetch_assoc($result);
		if (!$iclass) $iclass = "itemclass='{$row['iclass']}' ";
		elseif (!$row['iclass']=='') $iclass.="OR itemclass='{$row['iclass']}' ";
}
if ($iclass){
	$sql="SELECT itemid,activate FROM ".db_prefix('itemdat')." WHERE ($iclass)";
	$result1=db_query($sql);
	for ($j=0;$j<db_num_rows($result1);$j++){
		$row1 = db_fetch_assoc($result1);
		$rand=e_rand(0,1);
		if (!$rand==$row1['activate']){
			$sql="UPDATE ".db_prefix('itemdat')." SET activate=$rand WHERE itemid={$row1['itemid']}";
			db_query($sql);
		}
	}
}
$sql="SELECT ".db_prefix('itemdat').".ownerid,".db_prefix('itemdat').".itemclass,".db_prefix('itemclass').".ac
	FROM ".db_prefix('itemdat')." LEFT JOIN ".db_prefix('itemclass')."
	ON ".db_prefix('itemdat').".itemclass=".db_prefix('itemclass').".iclass
	WHERE ".db_prefix('itemdat').".ownerid>0
	AND ".db_prefix('itemdat').".itemclass=".db_prefix('itemclass').".iclass
	ORDER BY ownerid";
$result2=db_query($sql);
for ($k=0;$k<db_num_rows($result2);$k++){
$row2 = db_fetch_assoc($result2);
	$sql = "SELECT acctid FROM ".db_prefix("accounts")." WHERE acctid={$row2['ownerid']}";
	$result3 = db_query($sql);
	if (db_num_rows($result3)==0){
   		if ($row2['ac']==0){
       		$sql="DELETE FROM ".db_prefix('itemdat')."
				WHERE itemclass='{$row2['itemclass']}'
				AND ownerid={$row2['ownerid']}";
			db_query($sql);
		}else{
			$sql = "UPDATE ".db_prefix('itemdat')."
		   	SET ownerid=0
			   ,ownername=''
			   ,activate=1
		   	WHERE itemclass='{$row2['itemclass']}'
		   	AND ownerid={$row2['ownerid']}";
			db_query($sql);
		}
	}
}
?>
