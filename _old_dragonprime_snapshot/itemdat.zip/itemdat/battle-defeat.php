<?php
$sql = "SELECT ".db_prefix('itemdat').".*,".db_prefix('itemclass').".ac
	FROM ".db_prefix('itemdat')." LEFT JOIN ".db_prefix('itemclass')."
	ON ".db_prefix('itemdat').".itemclass=".db_prefix('itemclass').".iclass
	WHERE ".db_prefix('itemclass').".death>=".e_rand(1,100)."
	AND ".db_prefix('itemdat').".itemclass=".db_prefix('itemclass').".iclass
	AND ".db_prefix('itemdat').".ownerid={$session['user']['acctid']}
	AND ".db_prefix('itemdat').".activate=1
	ORDER BY rand(".e_rand().") LIMIT 1";
$result=db_query($sql);
$row = db_fetch_assoc($result);
if ($row['itemid']){
	output("`n`#Bei deinem Tod verlierst du ausserdem noch `&%s`#! (%s)`n`n`#", $row['itemname'], $row['itemdesc']);
	if (!$row['ac']){
		$sql="DELETE FROM ".db_prefix("itemdat")."	WHERE itemid={$row['itemid']}";
	}else{
		$sql = "UPDATE ".db_prefix("itemdat")."
			SET ownerid=0
				,ownername=''
			   	,activate=1
			WHERE itemid={$row['itemid']}";
	}
	db_query($sql);
}
?>
