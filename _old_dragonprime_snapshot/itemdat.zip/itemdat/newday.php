<?php
$sql = "SELECT iclass FROM ".db_prefix('itemclass')."
	WHERE (count=1 OR buff=1)
	ORDER BY iclass";
$result = db_query($sql);
for ($i=0;$i<db_num_rows($result);$i++){
	$row = db_fetch_assoc($result);
		if (!$iclass) $iclass = "itemclass='{$row['iclass']}' ";
		elseif (!$row['iclass']=='') $iclass.="OR itemclass='{$row['iclass']}' ";
}

if ($iclass){
   	$sql="SELECT itemname,itemdesc,itemv3,itembuff FROM ".db_prefix('itemdat')."
		WHERE ($iclass)
		AND ownerid={$session['user']['acctid']}
		AND activate=1
		ORDER BY itemclass";
      	$result1=db_query($sql);
   	for ($j=0;$j<db_num_rows($result1);$j++){
       	$row1 = db_fetch_assoc($result1);
       	if (strlen($row1['itembuff'])>8){
           	$row1['itembuff']=unserialize($row1['itembuff']);
           	$session['bufflist'][$row1['itembuff']['name']]=$row1['itembuff'];
           	output_notl("`n`^{$row1['itemname']}`@: {$row1['itemdesc']}");
       	}
       	if ($row1['itemv3']>0){
			$row1['itemv3']--;
           	if ($row1['itemv3']<=0){
	    	    output(" Aber nur noch heute.");
            }
        }
   	}
}
if ($iclass){
	$sql = "UPDATE ".db_prefix('itemdat')."
		SET itemv3=itemv3-1
		WHERE ($iclass)
		AND ownerid={$session['user']['acctid']}
		AND itemv3>0
   		AND activate=1";
   		db_query($sql);
}
$sql = "SELECT iclass,ac FROM ".db_prefix('itemclass')."
	WHERE count=1
	AND buff=1
	ORDER BY iclass";
  	$result2 = db_query($sql);
   	for ($k=0;$k<db_num_rows($result2);$k++){
		$row2 = db_fetch_assoc($result2);
		if ($row2['ac']==0){
			$sql = "DELETE FROM ".db_prefix('itemdat')."
			   	WHERE itemclass='{$row2['iclass']}'
			   	AND ownerid={$session['user']['acctid']}
			   	AND itemv3<=1
			   	AND activate=1";
   			db_query($sql);
		}else{
   			$sql = "UPDATE ".db_prefix('itemdat')."
			   	SET ownerid=0,ownername=''
			   	WHERE itemclass='{$row2['iclass']}'
			   	AND ownerid={$session['user']['acctid']}
			   	AND itemv3<=1
			   	AND activate=1";
   			db_query($sql);
		}
	}
?>
