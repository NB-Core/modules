<?php
	require_once('common.php');
	require_once('lib/http.php');
	require_once('lib/showform.php');
	require_once('lib/superusernav.php');

	global $session;

	$op = httpget('op');
	$act = httpget('act');
	$del = httpget('del');
	$class = httpget('class');
	$limit = httpget('limit');
	$itemid = httpget('itemid');
	$block = '';

	page_header('Itemdat Editor');

	$itemdatarray=array(
		"Grundwerte,title",
		"itemid"=>"Item ID,viewonly",
		"itemname"=>"Item Name:,".($op=="item"?"viewonly":""),
		"itemclass"=>"Itemklasse:,".($op=="item"?"viewonly":""),
		"ownerid"=>"Besitzer ID:,".($op=="item"?"viewonly":"int"),
		"ownername"=>"Besitzername:,viewonly",
		"itemdesc"=>"Item Beschreibung:,".($op=="item"?"viewonly":"textarea"),
		"activate"=>"Item aktiv,".($op=="item"?"viewonly":"bool"),
		"itemv1"=>"Itemwert 1:,".($op=="item"?"viewonly":""),
		"itemv2"=>"Itemwert 2:,".($op=="item"?"viewonly":""),
		"itemv3"=>"Itemwert 3:,".($op=="item"?"viewonly":""),
		"itemcost1"=>"Itempreis 1:,".($op=="item"?"viewonly":""),
		"itemcost2"=>"Itempreis 2:,".($op=="item"?"viewonly":""),
		"itemcost3"=>"Itempreis 3:,".($op=="item"?"viewonly":""),
		);

	$itembuffarray=array(
		"Meldungen,title",
		"name"=>"Buffname:,".($op=="item"?"viewonly":""),
		"newday"=>"Meldung beim neuen Tag:,".($op=="item"?"viewonly":""),
		"startmsg"=>"Meldung beim Buffstart:,".($op=="item"?"viewonly":""),
		"roundmsg"=>"Meldung jede Runde:,".($op=="item"?"viewonly":""),
		"wearoff"=>"Ablaufmeldung:,".($op=="item"?"viewonly":""),
		"effectmsg"=>"Effektmeldung:,".($op=="item"?"viewonly":""),
		"effectnodmgmsg"=>"Kein Schaden Meldung:,".($op=="item"?"viewonly":""),
		"effectfailmsg"=>"Fehlgeschlagen Meldung:,".($op=="item"?"viewonly":""),

		"Effekte,title",
		"rounds"=>"H�lt Runden (nach Aktivierung):,".($op=="item"?"viewonly":""),
		"atkmod"=>"Angriffsfaktor Spieler:,".($op=="item"?"viewonly":""),
		"defmod"=>"Verteidigungsfaktor Spieler:,".($op=="item"?"viewonly":""),
		"regen"=>"Regeneration:,".($op=="item"?"viewonly":""),
		"minioncount"=>"Helfer Anzahl:,".($op=="item"?"viewonly":""),
		"minbadguydamage"=>"Helfer min Schaden:,".($op=="item"?"viewonly":""),
		"maxbadguydamage"=>"Helfer max Schaden:,".($op=="item"?"viewonly":""),
		"mingoodguydamage"=>"Gegner min Schaden:,".($op=="item"?"viewonly":""),
		"maxgoodguydamage"=>"Gegner max Schaden:,".($op=="item"?"viewonly":""),
		"lifetap"=>"Lebensentzug Faktor:,".($op=="item"?"viewonly":""),
		"damageshield"=>"Schadensschild Faktor:,".($op=="item"?"viewonly":""),
		"badguydmgmod"=>"Gegenerschaden Faktor:,".($op=="item"?"viewonly":""),
		"badguyatkmod"=>"Angriffsfaktor Gegner:,".($op=="item"?"viewonly":""),
		"badguydefmod"=>"Verteidigungsfaktor Gegner:,".($op=="item"?"viewonly":""),

		"Spezialfunktionen,title",
		"invulnerable"=>"Spieler ist unverwundbar:,".($op=="item"?"viewonly":"bool"),
		"suspended"=>"L�uft weiter am neuen Tag:,".($op=="item"?"viewonly":"bool"),
		"allowinpvp"=>"Bei PVP erlaubt:,".($op=="item"?"viewonly":"bool"),
		"allowintrain"=>"Beim Meister erlaubt:,".($op=="item"?"viewonly":"bool"),
		"expireafterfight"=>"Buff nach Kampf beenden:,".($op=="item"?"viewonly":"bool"),
		"schema"=>"Itemschema,".($op=="item"?"viewonly":""),
		);

	$itemhelparray=array(
		"Hilfe Grundwerte,title",
		"`n`i`&`bItem ID`b - `8Wert zur Datenbankverwaltung (`6Nicht zu �ndern`8),note",
		"`&`bItem Name`b - `8Name des Items (`6Doppelte Namen erlaubt`8),note",
		"`&`bItemklasse`b - `8Die zugewiesene Klasse (`6bestehende oder neue Klasse eintragen`8),note",
		"`&`bBesitzer ID`b - `8Accountid des Besitzers (`6Bei Prototypen immer 0`8),note",
		"`&`bBesitzername`b - `8Wird nur zum Datenbankabgleich ben�tigt,note",
		"`&`bItem Beschreibung`b - `8Beschreibung des Items,note",
		"`&`bItem aktiv`b - `8Freigabe zur Verwendung im Spiel (`6Erst wenn gesetzt wird das Item vom Spiel verwendet!`8),note",
		"`&`bItemwert 1`b - `8Zur internen Verwaltung (`6z.B. um H�usern zuzuweisen`8),note",
		"`&`bItemwert 2`b - `8Zur internen Verwaltung (`6z.B. um Wohnmodule zuzuweisen`8),note",
		"`&`bItemwert 3`b - `8Laufzeitcounter (`6Nach wieviel Spielz�gen soll das Item gel�scht werden?`8),note",
		"`&`bItempreis 1`b - `8Itempreis (`6Im Normalfall der Goldpreis`8),note",
		"`&`bItempreis 2`b - `8Itempreis (`6Im Normalfall der Edelsteinpreis`8),note",
		"`&`bItempreis 3`b - `8Itempreis (`6Keine Zuweisung!`8),note",
		"`n`\$`bItemwert und Itempreis k�nnen aus Zahlen als auch aus Text bestehen. Dies ist immer von der Verwendung des Items abh�ngig.`b,note",

		"Hilfe Meldungen,title",
		"`n`&`bBuffname`b - `8Name des Buffs (`6taucht dann im Statusfenster auf`8),note",
		"`&`bMeldung beim neuen Tag`b - `8Meldung die beim neuen Tag ausgegeben wird,note",
		"`&`bMeldung beim Buffstart`b - `8Meldung die beim Start ausgegeben wird,note",
		"`&`bMeldung jede Runde`b - `8Meldung die jede Runde ausgegeben wird,note",
		"`&`bAblaufmeldung`b - `8Meldung die bei Ablauf des Buffs ausgegeben wird,note",
		"`&`bEffektmeldung`b - `8Meldung die bei erfolgreichem Versuch ausgegeben wird,note",
		"`&`bKein Schaden Meldung`b - `8Meldung die bei erfolgreichem Versuch aber 0 Schaden ausgegeben wird,note",
		"`&`bFehlgeschlagen Meldung`b - `8Meldung die bei Missererfolg ausgegeben wird,note",
		"`n`&M�gliche Platzhalter sind: `n`n`&{badguy} - `\$Name des Gegners `n`&{goodguy} - `\$Name des Spielers `n`&{weapon} - `\$Deine Waffe `n`&{armor} - `\$Deine R�stung `n`&{creatureweapon} - `\$Waffe des Gegners `n`&{damage} - `\$Die Schadenspunkte die erzielt wurden,note",

		"Hilfe Effekte,title",
		"`n`&`bH�lt Runden (nach Aktivierung)`b - `8Laufzeit des Buffs! Die Runden gehen bei Angriff oder Verteidigung runter,note",
		"`&`bAngriffsfaktor Spieler`b - `82 z.B. verdoppelt oder 0.5 halbiert den Spielerangriff,note",
		"`&`bVerteidigungsfaktor Spieler`b - `82 z.B. verdoppelt oder 0.5 halbiert die Spielerverteidigung,note",
		"`&`bRegeneration`b - `8Ein Wert von z.B. 2 heilt den Spieler f�r 2 Lebenspunkte,note",
		"`&`bHelfer Anzahl`b - `8Anzahl der Helfer jede Runde,note",
		"`&`bHelfer min Schaden`b - `8Mininmalschaden den ein Helfer jede Runde machen kann,note",
		"`&`bHelfer max Schaden`b - `8Maximalschaden den ein Helfer jede Runde machen kann,note",
		"`&`bGegner min Schaden`b - `8Mininmalschaden den der Gegner jede Runde machen kann,note",
		"`&`bGegner max Schaden`b - `8Maximalschaden den der Gegner jede Runde machen kann,note",
		"`&`bLebensentzug Faktor`b - `8Bei Faktor 2 z.B. wird der Spieler um den doppelten Schadenswert geheilt,note",
		"`&`bSchadensschild Faktor`b - `8Bei Faktor 2 z.B. bekommt der Gegner den doppelten Spielerschaden zur�ck,note",
		"`&`bGegenerschaden Faktor`b - `8Bei Faktor 2 z.B. macht der Gegner doppelten bei 0.5 halben Schaden,note",
		"`&`bAngriffsfaktor Gegner`b - `82 z.B. verdoppelt oder 0.5 halbiert den Gegnerangriff,note",
		"`&`bVerteidigungsfaktor Gegner`b - `82 z.B. verdoppelt oder 0.5 halbiert die Gegnerverteidigung,note",

		"Hilfe Spezialfunktionen,title",
		"`n`&`bSpieler ist unverwundbar`b - `8�ber die gesamte Laufzeit des Buffs werden dem Spieler im Kampf keine Lebenspunkte abgezogen,note",
		"`&`bL�uft weiter am neuen Tag`b - `8Der Buff l�uft auch nach einem neuen Spielzug an der gleichen Stelle weiter,note",
		"`&`bBei PVP erlaubt`b - `8Der Buff kann auch im PVP genutzt werden,note",
		"`&`bBeim Meister erlaubt`b - `8Der Buff kann auch beim Meister genutzt werden,note",
		"`&`bBuff nach Kampf beenden`b - `8Den Buff nach einem Kampf beenden,note",
		"`&`bItemschema`b - `8Systemeinstellung f�r den Translator >Automatisch<,note",

		);

	$classdatarray=array(
		"Klassenregel,title",
		"iclass"=>"Klasse,viewonly",
		"dk"=>"Bei DK loeschen,bool",
		"buff"=>"Bei Newday reaktivieren,bool",
		"rate"=>"Monsterdroprate 0-100%,range,0,100,1",
		"pvp"=>"PVP Droprate 0-100%,range,0,100,1",
		"death"=>"Tod Droprate 0-100%,range,0,100,1",
		"trade"=>"Handel,bool",
		"dort"=>"Ort des Drops,",
		"loc"=>"Lokation,",
		"mob"=>"Zielmonster,",
		"mindk"=>"min DK fuer Drop,",
		"maxdk"=>"max DK fuer Drop,",
		"minlvl"=>"min LVL fuer Drop,range,1,15,1",
		"maxlvl"=>"max LVL fuer Drop,range,1,15,1",
		"nclass"=>"Neue Klasse,",
		"dv1"=>"Value (itemcost1),",
		"dv2"=>"Value (itemcost2),",
		"dv3"=>"Value (itemcost3),",
		"count"=>"Counterabfrage (itemv3),bool",
		"ac"=>"Gel�schte Accounts/Counter,bool",
		"`\$nein=l�schen ja=zur�cksetzen`0,note",
		"act"=>"Aktivierung auswuerfeln,bool",

		"Hilfe Regeln,title",
		"`&`bKlasse`b - `8Name der Klasse,note",
		"`&`bBei DK loeschen`b - `8Sollen die Items dieser Klasse nach einem Drachenkill des Spielers gel�scht werden?,note",
		"`&`bBei Newday reaktivieren`b - `8Itembuffs oder Zauberspr�che beim neuen Tag reaktivieren,note",
		"`&`bMonsterdroprate 0-100%`b - `8H�ufigkeit des Drops dieser Klasse am vorgegebenen Ort (0%=kein Drop),note",
		"`&`bPVP Droprate 0-100%`b - `8H�ufigkeit des Drops dieser Klasse im PVP Kampf (0%=kein Drop),note",
		"`&`bTod Droprate 0-100%`b - `8H�ufigkeit ein Item dieser Klasse bei Tod zu verlieren (0%=kein Verlust),note",
		"`&`bHandelbar`b - `8Die Items dieser Klasse k�nnen �ber den Rucksack weitergegeben werden!,note",
		"`&`bOrt des Drops`b - `8An welchem Ort wird die Klasse gedroppt (forest[komma]travel .... ect.),note",
		"`&`bLokation`b - `8Die Klasse droppt nur wenn Spielerlokation dieser Ort ist(Wenn keine Angabe dann �berall),note",
		"`&`bZielmonster`b - `8Die Klasse droppt nur von diesem Monster/dieser Monstergruppe (Wenn keine Angabe dann auf allen),note",
		"`&`bmin DK fuer Drop`b - `8Wieviel Drachenkills muss der Spieler minimal haben,note",
		"`&`bmax DK fuer Drop`b - `8Wieviel Drachenkills darf der Spieler maximal haben (bei -1 keine Grenze),note",
		"`&`bmin LVL fuer Drop`b - `8Welches Level muss der Spieler minimal haben,note",
		"`&`bmax LVL fuer Drop`b - `8Welches Level darf der Spieler maximal haben (nur bei Questitems �ber Lvl 14 gehen),note",
		"`&`bNeue Klasse`b - `8Das Item wird in dieser Klasse neu erstellt (Neue Regel nicht vergessen!),note",
		"`&`bValue (itemcost1-2-3)`b - `8Faktor des Preises den ein Item beim Verkauf noch bringen soll,note",
		"`&`bCounterabfrage (itemv3)`b - `8Besitzt das Item einen Counter der beim neuen Tag runterz�hlt,note",
		"`&`bGel�schte Accounts oder Counter`b - `8Von Spieler genutzte Items werden beim neuen Tag gel�scht/zur�ckgesetzt,note",
		"`&`bAktivierung auswuerfeln`b - `8Alle Itemaktivierungen dieser Klasse werden beim neuen Tag ausgew�rfelt,note",
		"`n`\$`bAlle diese Regeln betreffen generell immer nur aktivierte Items!`b,note",
		"`\$`bNur die Regel f�r gel�schte Accounts ber�cksichtigt auch deaktivierte Items!`b,note",
		"`\$`bWird keine Regel aufgestellt wird die Klasse auch nicht ber�cksichtigt!`b,note",
		"`\$`bDie Hauptklasse lautet z.B. `@xxx`^.Prot`\$. Die neue Klasse dann `@xxx`\$!`b,note",
	);

	$tbefehle = translate_inline("Befehle");
	$tklasse = translate_inline("Klasse");
	$titemsg = translate_inline("Items gesamt");
	$titemsa = translate_inline("Items aktiv");
	$taktiv = translate_inline("Aktiv");
	$tdeaktiv = translate_inline("Deaktiv");
	$tloeschen = translate_inline("Loeschen");
	$tname = translate_inline("Name");
	$tbesitz = translate_inline("Besitzer");
	$tpreis = translate_inline("Preis");
	$tlauf = translate_inline("Laufzeit");
	$tedit = translate_inline("Edit");
	$teditieren = translate_inline("Editieren");
	$tregel = translate_inline("Regel");
	$tneu = translate_inline("Neu");

if ($op==''){

	rawoutput("<table border=0 align='center' cellpadding=2 cellspacing=1 bgcolor='#999999'>");
	output_notl("<tr style=\"background-color:#339999;\"><td>`b`c`&$tbefehle`c`b</td><td>`b`c`&$tklasse`c`b</td><td>`b`c`&$titemsg`c`b</td><td>`b`c`&$titemsa`c`b</td></tr>",true);

    $sql = "SELECT itemclass FROM ".db_prefix('itemdat')." ORDER BY itemclass";
    $result = db_query($sql);
    for ($i=0;$i<db_num_rows($result);$i++){
		$row = db_fetch_assoc($result);

		if ($block!=$row['itemclass']){
			$block=$row['itemclass'];
			rawoutput("<tr class='".($i%2?"trdark":"trlight")."'>",true);

			$sql = "SELECT count(itemid) as c FROM ".db_prefix('itemdat')." WHERE activate=0 AND itemclass='{$row['itemclass']}'";
			$result1 = db_query($sql);
			$row1 = db_fetch_assoc($result1);

			if ($row1['c']==0){
			output("<td>`&[ $taktiv |",true);
			}else{
			$confaktiv = sprintf_translate("Willst du wirklich alle Items der Klasse %s aktivieren?", $row['itemclass']);
			output("<td>`&[ <a href='runmodule.php?module=itemdat_editor&act=1&class={$row['itemclass']}' onClick=\"return confirm('$confaktiv');\">$taktiv</a> `&|",true);
			addnav("","runmodule.php?module=itemdat_editor&act=1&class={$row['itemclass']}");
			}

			$sql = "SELECT count(itemid) as c FROM ".db_prefix('itemdat')." WHERE activate=1 AND itemclass='{$row['itemclass']}'";
			$result2 = db_query($sql);
			$row2 = db_fetch_assoc($result2);

			if ($row2['c']==0){
			output("`& $tdeaktiv |",true);
			}else{
			$confdeaktiv = sprintf_translate("Willst du wirklich alle Items der Klasse %s deaktivieren?", $row['itemclass']);
			output_notl(" <a href='runmodule.php?module=itemdat_editor&act=2&class={$row['itemclass']}' onClick=\"return confirm('$confdeaktiv');\">$tdeaktiv</a> `&|",true);
			addnav("","runmodule.php?module=itemdat_editor&act=2&class={$row['itemclass']}");
			}

			output_notl(" <a href='runmodule.php?module=itemdat_editor&op=class&class={$row['itemclass']}'>`#`Q$tregel</a> `&|",true);
			addnav("","runmodule.php?module=itemdat_editor&op=class&class={$row['itemclass']}");

			output_notl(" <a href='runmodule.php?module=itemdat_editor&op=edit&class={$row['itemclass']}'>`#$tneu</a> `&|",true);
			addnav("","runmodule.php?module=itemdat_editor&op=edit&class={$row['itemclass']}");

			$confloeschen = sprintf_translate("WARNUNG!!!! Du bist gerade dabei alle Items der Klasse %s zu l�schen! Willst du das wirklich?", $row['itemclass']);
			output_notl("`& <a href='runmodule.php?module=itemdat_editor&del=ja&class={$row['itemclass']}' onClick=\"return confirm('$confloeschen');\">`\$$tloeschen</a> `&]",true);
			addnav("","runmodule.php?module=itemdat_editor&del=ja&class={$row['itemclass']}");
			rawoutput("</td><td>");

			output_notl("<a href='runmodule.php?module=itemdat_editor&op=show&class={$row['itemclass']}'>`c{$row['itemclass']}`c</a>",true);
			addnav("","runmodule.php?module=itemdat_editor&op=show&class={$row['itemclass']}");
			rawoutput("</td><td align='right'>");
			output_notl($row1['c']+$row2['c']);
			rawoutput("</td><td align='right'>");
			output_notl($row2['c']==0?0:$row2['c']);
			rawoutput("</td></tr>");
    	}
    }
    rawoutput("</table>");
    addnav("Neues Item erstellen","runmodule.php?module=itemdat_editor&op=edit");

	if ($act){
		$sql = "UPDATE ".db_prefix('itemdat')." SET activate=".($act==1?1:0)." WHERE itemclass='$class'";
   		db_query($sql);
    	redirect("runmodule.php?module=itemdat_editor");
	}
	if ($del=="ja"){
		$sql = "DELETE FROM ".db_prefix('itemdat')." WHERE itemclass='$class'";
   		db_query($sql);
    	redirect("runmodule.php?module=itemdat_editor");
	}

}elseif ($op=='show'){

	$ppp=25;
    if (!$limit){
    	$page=0;
    }else{
        $page=(int)$limit;
        addnav("Vorherige Seite","runmodule.php?module=itemdat_editor&op=show&class=$class&limit=".($page-1)."");
    }
    $lim="".($page*$ppp).",".($ppp+1);

	rawoutput("<table width=\"100%\" border=0 align='center' cellpadding=2 cellspacing=1 bgcolor='#999999'>");
	output_notl("<tr style=\"background-color:#339999;\"><td>`b`c`&$tbefehle`c`b</td><td>`b`c`&ID`c`b</td><td>`b`c`&$tname`c`b</td><td>`b`c`&$tbesitz`c`b</td><td>`b`c`&$tpreis 1`c`b</td><td>`b`c`&$tpreis 2`c`b</td><td>`b`c`&$tpreis 3`c`b</td><td>`b`c`&$tlauf`c`b</td></tr>",true);

    $sql = "SELECT * FROM ".db_prefix('itemdat')." WHERE itemclass='$class' ORDER BY itemname LIMIT $lim";
    $result = db_query($sql);
    if (db_num_rows($result)>$ppp) addnav("N�chste Seite","runmodule.php?module=itemdat_editor&op=show&class=$class&limit=".($page+1)."");
    for ($i=0;$i<db_num_rows($result);$i++){
    	$row = db_fetch_assoc($result);
		rawoutput("<tr class='".($i%2?"trdark":"trlight")."'>");

		if ($row['activate']==1){
		output_notl("<td>`c`&[ $taktiv |",true);
		}else{
		output_notl("<td>`c`&[ <a href='runmodule.php?module=itemdat_editor&op=show&act=1&itemid={$row['itemid']}&class={$row['itemclass']}&limit=$page'>$taktiv</a> `&|",true);
		addnav("","runmodule.php?module=itemdat_editor&op=show&act=1&itemid={$row['itemid']}&class={$row['itemclass']}&limit=$page");
		}

		if ($row['activate']==0){
		output_notl("`& $tdeaktiv |",true);
		}else{
		output_notl(" <a href='runmodule.php?module=itemdat_editor&op=show&act=2&itemid={$row['itemid']}&class={$row['itemclass']}&limit=$page'>$tdeaktiv</a> `&|",true);
		addnav("","runmodule.php?module=itemdat_editor&op=show&act=2&itemid={$row['itemid']}&class={$row['itemclass']}&limit=$page");
		}

		output_notl(" <a href='runmodule.php?module=itemdat_editor&op=edit&itemid={$row['itemid']}'>`@$tedit</a> `&|",true);
		addnav("","runmodule.php?module=itemdat_editor&op=edit&itemid={$row['itemid']}");

		$confloeschen = translate_inline("Willst du das Item wirklich l�schen?");
		output_notl("`& <a href='runmodule.php?module=itemdat_editor&op=show&del=ja&itemid={$row['itemid']}&class={$row['itemclass']}&limit=$page' onClick=\"return confirm('$confloeschen');\">`\$$tloeschen</a> `&]`c",true);
		addnav("","runmodule.php?module=itemdat_editor&op=show&del=ja&itemid={$row['itemid']}&class={$row['itemclass']}&limit=$page");

		rawoutput("</td><td align='right'>");
		output_notl($row['itemid']);
		rawoutput("</td><td>");
		output_notl("<a href='runmodule.php?module=itemdat_editor&op=item&itemid={$row['itemid']}&class={$row['itemclass']}&limit=$page'>`c{$row['itemname']}`c</a>",true);
		addnav("","runmodule.php?module=itemdat_editor&op=item&itemid={$row['itemid']}&class={$row['itemclass']}&limit=$page");
		rawoutput("</td><td align='center'>");
		output_notl($row['ownername']==''?"-":$row['ownername']);
		rawoutput("</td><td align='right'>");
		output_notl($row['itemcost1']==''?"`c-`c":$row['itemcost1']);
		rawoutput("</td><td align='right'>");
		output_notl($row['itemcost2']==''?"`c-`c":$row['itemcost2']);
		rawoutput("</td><td align='right'>");
		output_notl($row['itemcost3']==''?"`c-`c":$row['itemcost3']);
		rawoutput("</td><td align='right'>");
		output_notl($row['itemv3']==''?"`c-`c":$row['itemv3']);
		rawoutput("</td></tr>");
    }

    rawoutput("</table>");
    addnav("K?Zur Klassen�bersicht","runmodule.php?module=itemdat_editor");
    addnav("Item hinzuf�gen","runmodule.php?module=itemdat_editor&op=edit&class=$class");

	if ($act){
		$sql = "UPDATE ".db_prefix('itemdat')." SET activate=".($act==1?1:0)." WHERE itemid=$itemid";
   		db_query($sql);
    	redirect("runmodule.php?module=itemdat_editor&op=show&class=$class&limit=$limit");
	}
	if ($del=="ja"){
		$sql = "DELETE FROM ".db_prefix('itemdat')." WHERE itemid=$itemid";
   		db_query($sql);

		$sql = "SELECT count(itemid) as c FROM ".db_prefix('itemdat')." WHERE itemclass='$class'";
		$result1 = db_query($sql);
		$row1 = db_fetch_assoc($result1);
		if ($row1['c']==0) redirect("runmodule.php?module=itemdat_editor");
    	redirect("runmodule.php?module=itemdat_editor&op=show&class=$class&limit=$limit");
	}

}elseif ($op=='item'){

	$data=array();

	$array=array_merge($itemdatarray,$itembuffarray);
	$array=array_merge($array,$itemhelparray);

   	$sql = "SELECT * FROM ".db_prefix('itemdat')." WHERE itemid=$itemid";
   	$result = db_query($sql);
	$row = db_fetch_assoc($result);

	$iarray=unserialize($row['itembuff']);
	$data=array_merge($row,$iarray);

	rawoutput("<table width=\"100%\" border=0 align='center' cellpadding=2 cellspacing=1 bgcolor='#999999'>");
   	rawoutput("<td colspan=4 style=\"background-color:#339999;\"><form>");
	showform($array, $data, true);
	rawoutput("</form><form action='runmodule.php?module=itemdat_editor&op=edit&itemid=$itemid' method='POST'>");
	addnav("","runmodule.php?module=itemdat_editor&op=edit&itemid=$itemid");
	rawoutput("<input type='submit' class='button' value='$teditieren'>");
	rawoutput("</form></table>");

    addnav("K?Zur Klassen�bersicht","runmodule.php?module=itemdat_editor");
    addnav("I?Zur Itemliste","runmodule.php?module=itemdat_editor&op=show&class=$class&limit=$limit");

}elseif ($op=='edit'){

	$data=array();

	$array=array_merge($itemdatarray,$itembuffarray);
	$array=array_merge($array,$itemhelparray);

	if ($class) $data=array("itemclass"=>$class);

	if ($itemid){
    	$sql = "SELECT * FROM ".db_prefix('itemdat')." WHERE itemid=$itemid";
    	$result = db_query($sql);
		$row = db_fetch_assoc($result);

		$iarray=unserialize($row['itembuff']);
		$data=array_merge($row,$iarray);
	}

	rawoutput("<table width=\"100%\" border=0 align='center' cellpadding=2 cellspacing=1 bgcolor='#999999'>");
   	rawoutput("<td colspan=4 style=\"background-color:#339999;\">");
	rawoutput("<form action='runmodule.php?module=itemdat_editor&op=save&itemid=$itemid' method='POST'>");
	addnav("","runmodule.php?module=itemdat_editor&op=save&itemid=$itemid");
	showform($array, $data);
	rawoutput("</form></table>");
    addnav("K?Zur Klassen�bersicht","runmodule.php?module=itemdat_editor");

}elseif ($op=='save'){

		$item = array();
		$data = $_POST;
		$data1= $_POST;
   		while (list($key,$val)=each($data)){
			if ($itembuffarray[$key]>""){
			    if ($key=="name" && $val=='') break;
			    if ($key=="name") $schema=$val;
			    if ($key=="schema" && $val==''){
					$data2 = array("$key"=>stripslashes("$schema"));
			    }elseif ($val>"" && !$val==0) {
						$data2 = array("$key"=>stripslashes("$val"));
			    }
				$item=array_merge($item,$data2);
			}
   		}
		$item=serialize($item);

   		while (list($key,$val)=each($data1)){
			if ($itemdatarray[$key]>""){
				$sql.=($key."='".$val."',");

                $keys.=($key.",");
                $vals.=("'".$val."',");
			}
   		}
		$sql.=("itembuff='".addslashes($item)."'");	$keys.=("itembuff"); $vals.=("'".addslashes($item)."'");

            if ($itemid>""){
                $sql="UPDATE ".db_prefix('itemdat')." SET $sql WHERE itemid=$itemid";
            }else{
                $sql="INSERT INTO ".db_prefix('itemdat')." ($keys) VALUES ($vals)";
            }
        	db_query($sql);

    	redirect("runmodule.php?module=itemdat_editor");

}elseif ($op=='class'){

	if (!$act){
    $sql = "SELECT * FROM ".db_prefix("itemclass")." WHERE iclass='$class'";
    $result = db_query($sql);
	$row = db_fetch_assoc($result);

	$dataarray=array("iclass"=>$class,);
	$data = array_merge($dataarray, $row);

	rawoutput("<table width=\"75%\" border=0 align='center' cellpadding=2 cellspacing=1 bgcolor='#999999'>");
   	rawoutput("<td colspan=4 style=\"background-color:#339999;\">");

	$delclass = sprintf_translate("Willst du die Regel f�r die Klasse %s wirklich l�schen?", $class);
	$delclassconf = translate_inline("Regel l�schen");

	rawoutput("<form action='runmodule.php?module=itemdat_editor&op=class&act=del&class=$class' onClick=\"return confirm('$delclass');\" method='POST'>");
	addnav("","runmodule.php?module=itemdat_editor&op=class&act=del&class=$class");
	rawoutput("<input type='submit' class='button' value='$delclassconf'></form>");

	rawoutput("<form action='runmodule.php?module=itemdat_editor&op=class&act=save&class=$class' method='POST'>");
	addnav("","runmodule.php?module=itemdat_editor&op=class&act=save&class=$class");
	showform($classdatarray, $data);
	rawoutput("</form></table>");
    addnav("K?Zur Klassen�bersicht","runmodule.php?module=itemdat_editor");
	}

	if ($act=="save"){

	$dataarray=array("iclass"=>$class,);
	$data = array_merge($dataarray, $_POST);

   		while (list($key,$val)=each($data)){
			if ($classdatarray[$key]>""){
				if (!$sql){
					$sql.=($key."='".$val."'");
				}else{
					$sql.=(",".$key."='".$val."'");
				}

				if ($val){
				    if (!$keys){
                		$keys.=($key);
                		$vals.=("'".$val."'");
				    }else{
                		$keys.=(",".$key);
                		$vals.=(",'".$val."'");
				    }
				}
			}
   		}
    	$sql1 = "SELECT iclass FROM ".db_prefix("itemclass")." WHERE iclass='$class'";
    	$result = db_query($sql1);
		if (db_num_rows($result)){
        	$sql="UPDATE ".db_prefix("itemclass")." SET $sql WHERE iclass='$class'";
        }else{
            $sql="INSERT INTO ".db_prefix("itemclass")." ($keys) VALUES ($vals)";
        }
        db_query($sql);

    	redirect("runmodule.php?module=itemdat_editor");
	}

	if ($act=="del"){
        $sql="DELETE FROM ".db_prefix("itemclass")." WHERE iclass='$class'";
        db_query($sql);
    	redirect("runmodule.php?module=itemdat_editor");
	}
}
superusernav();
page_footer();
?>
