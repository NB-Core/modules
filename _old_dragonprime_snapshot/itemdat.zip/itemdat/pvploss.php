<?php
$sql = "SELECT ".db_prefix('itemdat').".*
	FROM ".db_prefix('itemdat')." LEFT JOIN ".db_prefix('itemclass')."
	ON ".db_prefix('itemdat').".itemclass=".db_prefix('itemclass').".iclass
	WHERE ".db_prefix('itemclass').".pvp>=".e_rand(1,100)."
	AND ".db_prefix('itemdat').".itemclass=".db_prefix('itemclass').".iclass
	AND ".db_prefix('itemdat').".ownerid={$session['user']['acctid']}
	AND ".db_prefix('itemdat').".activate=1
	ORDER BY rand(".e_rand().") LIMIT 1";
$result=db_query($sql);
$row = db_fetch_assoc($result);
	if ($row['itemid']){
		if (is_module_active("rsequip")) set_module_pref('inhalt',get_module_pref('inhalt','rsequip')-1,'rsequip');
		output("`n`#Bei deinem Tod verlierst du ausserdem noch `&%s`#! (%s)`n`n`#", $row['itemname'], $row['itemdesc']);
	   	if (is_module_active('rsequip') && get_module_pref("inhalt",'rsequip',$args['badguy']['acctid'])>=get_module_pref('groesse','rsequip',$args['badguy']['acctid'])){
	   		$args['pvpmessageadd'] .= sprintf_translate("`nDein Rucksack ist voll, deshalb konntest du `&%s`0 leider nicht aufnehmen!`n", $row['itemname']);
	   	}else{
			$args['pvpmessageadd'] .= sprintf_translate("`nBeim Durchsuchen der Leiche findest du ausserdem `&%s`0! (`&%s`0).`n", $row['itemname'], $row['itemdesc']);
			$sql="UPDATE ".db_prefix('itemdat')." SET ownerid=".$args['badguy']['acctid'].", ownername='".$args['creaturename']."' WHERE itemid={$row['itemid']}";
			db_query($sql);
	   	}
    }
?>
