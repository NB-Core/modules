<?php
if (is_module_active('rsequip') && get_module_pref('inhalt','rsequip')>=get_module_pref('groesse','rsequip')){
	output("`n`#Dein Rucksack ist voll, deshalb kannst du nichts mehr aufnehmen!`n`n");
	return $args;
}
$sql = "SELECT ".db_prefix('itemdat').".*
	FROM ".db_prefix('itemdat')." LEFT JOIN ".db_prefix('itemclass')."
	ON ".db_prefix('itemdat').".itemclass=".db_prefix('itemclass').".iclass
	WHERE ".db_prefix('itemclass').".pvp>=".e_rand(1,100)."
	AND ".db_prefix('itemdat').".itemclass=".db_prefix('itemclass').".iclass
	AND ".db_prefix('itemdat').".ownerid=".$args['badguy']['acctid']."
	AND ".db_prefix('itemdat').".activate=1
	ORDER BY rand(".e_rand().") LIMIT 1";
$result=db_query($sql);
$row = db_fetch_assoc($result);
	if ($row['itemid']){
		output("`n`#Beim Durchsuchen von %s `#findest du `&%s`#! (%s)`n`n`#", $args['creaturename'], $row['itemname'], $row['itemdesc']);
		$args['pvpmessageadd'] .= sprintf_translate("`nAusserdem entwendete %s dir `&%s`0! (`&%s`0).`n", $session['user']['name'], $row['itemname'], $row['itemdesc']);
		$sql="UPDATE ".db_prefix('itemdat')." SET ownerid={$session['user']['acctid']}, ownername='{$session['user']['name']}' WHERE itemid={$row['itemid']}";
		db_query($sql);
	}
?>
