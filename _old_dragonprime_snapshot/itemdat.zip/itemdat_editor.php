<?php
/*
Geschrieben fuer lotgd.eq-gildenhaus.de, Antic �2004-2005
Bugmeldungen bitte an antic@eq-gildenhaus.de
Vorschlaege zur Verbesserung sind jederzeit willkommen!
*/

function itemdat_editor_getmoduleinfo(){
	$info = array(
		"name"=>"Itemdat Editor",
		"author"=>"`3Antic`0",
		"version"=>"0.6.04",
		"category"=>"Administrative",
		"download"=>"http://dragonprime.net/users/Antic/itemdat.zip",
	);
	return $info;
}

function itemdat_editor_install(){
	include("modules/itemdat/install.php");
	return true;
}

function itemdat_editor_uninstall(){
	return true;
}

function itemdat_editor_dohook($hookname, $args){
	global $session;
	switch($hookname){

	case 'superuser':
		include("modules/itemdat/superuser.php");
		break;

	case 'pvpwin':
		include("modules/itemdat/pvpwin.php");
		break;

	case 'pvploss':
		include("modules/itemdat/pvploss.php");
		break;

	case 'newday-runonce':
		include("modules/itemdat/newday-runonce.php");
		break;

	case 'newday':
		include("modules/itemdat/newday.php");
		break;

	case 'dragonkill':
		include("modules/itemdat/dragonkill.php");
		break;

	case 'battle-victory':
		include("modules/itemdat/battle-victory.php");
		break;

	case 'battle-defeat':
		include("modules/itemdat/battle-defeat.php");
		break;
	}
	return $args;
}
function itemdat_editor_run(){
  include("modules/itemdat/run.php");
}
?>
