<?php
// translator ready
// addnews ready
// mail ready

function mouseover_getmoduleinfo(){
		$info = array(
		"name"=>"Mouse Over Script",
		"author"=>"`#TeMpTeD`3, with modifications by `@CortalUX`3.",
		"category"=>"General",
		"download"=>"",
		"version"=>"1.1",
		"prefs"=>array(
			"Mouse Over,title",
			"user_weapon"=>"Show weapon with mouseover?,bool|1",
			"user_armor"=>"Show armor with mouseover?,bool|1",
		),
	);
	return $info;
}

function mouseover_install(){
	if (!is_module_active('mouseover')){
		output("`c`b`QInstalling Mouse Over Module.`b`n`c");
	}else{
		output("`c`b`QUpdating Mouse Over Module.`b`n`c");
	}
	module_addhook("everyfooter");
	module_addhook("charstats");
	return true;
}

function mouseover_uninstall(){
	output("`n`c`b`QMouse Over Module Uninstalled`0`b`c");
	return true;
}

function mouseover_dohook($hookname, $args){
	global $session;
	switch ($hookname){
		case "everyfooter":
			$style="p.small {\n    font-family: Verdana, sans-serif; \n    font-size: 10px;\n}\n div.title {\n    color: #000000;\n    padding-left: 1px;\n    font-family: monospace;\n    letter-spacing: 2px;\n    font-size: 12px;\n    line-height: 9px;\n    height: 9px;\n    margin-bottom: 1px;\n}\n div.main {\n    border: 1px solid #ffffff;\n	color: #000000;\n\n}\n \n/* Overlib Style */\ndiv.domTTOverlib {\n    border: 1px solid #333333;\n    background-color: #006400;\n}\n div.domTTOverlibCaption {\n    font-family: serif;\n    font-size: 12px;\n    font-weight: bold;\n    padding: 1px 2px;\n    color: #FFFFFF;\n}\n div.domTTOverlibContent {\n    font-size: 10px;\n    font-family: Verdana, Helvetica;\n    padding: 2px;\n    background-color: #ffffff;\n	color: #000000;\n}\n div.domTTMenu {\n  width: 150px;\n  border: 2px outset #ffffff;\n}\n div.domTTMenuCaption {\n  font-size: 12px;\n  font-family: sans-serif;\n  background-color: #006400;\n}\n div.domTTMenuContent {\n  padding: 1px 0;\n  background-color: #ffffff;\n}\n ";
			$script="\n <style type='text/css'><!--\n$style\n--></style>\n <script type='text/javascript' language='javascript' src='modules/mouseover/domLib.js'></script>\n <script type='text/javascript' language='javascript' src='modules/mouseover/domTT.js'></script>\n <script type='text/javascript' language='javascript'>\n var domTT_classPrefix = 'domTTOverlib';\n </script>\n ";
			if (!isset($args['headscript'])) {
				$args['headscript'] = array();
			} elseif (!is_array($args['headscript'])) {
				$args['headscript'] = array($args['headscript']);
			}
			array_push($args['headscript'], $script);
		break;
		case "charstats":
			$b=translate_inline("Value:");
			if (get_module_pref('user_weapon')==1) {
				$weapon=appoencode($session['user']['weapon'],true);
				$a=translate_inline("Attack:");
				$a2=$session['user']['weapondmg'];
				$b2=$session['user']['weaponvalue'];
				$t=translate_inline("Weapon Details");
				$new="<a href=\"#\" onmouseover=\"return makeTrue(domTT_activate(this, event, 'statusText', '$t', 'caption', '$t', 'content', '$a $a2 | $b $b2', 'trail', true));\">$weapon</a>";
				setcharstat("Equipment Info", "Weapon", $new);
			}
			if (get_module_pref('user_armor')==1) {
				$armor=appoencode($session['user']['armor'],true);
				$a=translate_inline("Defense:");
				$a2=$session['user']['armordef'];
				$b2=$session['user']['armorvalue'];
				$t=translate_inline("Armor Details");
				$new="<a href=\"#\" onmouseover=\"return makeTrue(domTT_activate(this, event, 'statusText', '$t', 'caption', '$t', 'content', '$a $a2 | $b $b2', 'trail', true));\">$armor</a>";
				setcharstat("Equipment Info", "Armor", $new);
			}
		break;
	}
	return $args;
}

function mouseover_run(){
}
?>