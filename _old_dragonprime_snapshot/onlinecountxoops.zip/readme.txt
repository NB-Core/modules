Xoops code for adding online count for LOGD to a block....
Uses an I frame to call the php code to display the online count.

Block Code (editing yoursite to match your URL):
<iframe marginwidth="0" marginheight="0" frameborder="0"
 scrolling="no" width="100%" height="18"
 src="http://www.yoursite.com/lotgd/onlinecountxoops.php"></iframe><br>
 
add this code to a custom block -  I have all my game navs hidden in main and
reproduced in an online games block.  I simply added this code after the link 
to the game.  You could also make a block for the online count only.  

You will want to edit the onlinecountxoops.php file's color code 
<body bgcolor="#D6DFF7"> to match your theme's block background color.  
Default font color is blue <font color=\"#0000FF\"> edit this to fit your needs
Upload the onlinecountzoops.php to your MAIN lotgd folder
(this is not a 98 module).

That should be all there is to it.

Although this was made for Xoops, I do believe there would be no problem 
using it from other CMS systems etc....

Copyright 2005 - Lonny Luberts
www.pqcomp.com