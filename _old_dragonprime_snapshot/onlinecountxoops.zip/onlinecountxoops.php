<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<meta name="GENERATOR" content="Lonny Luberts">
<meta name="ProgId" content="Notepad">
<title>Lotgd Online Count</title>
</head>
<body bgcolor="#D6DFF7">
<?php
	/*
	online count code by Lonny Luberts - Copyright 2005 - www.pqcomp.com
	download - http://www.pqcomp.com/modules/mydownloads/
	version - 1.0
	Xoops Block Code (editing yoursite to match your URL):
	<iframe marginwidth="0" marginheight="0" frameborder="0"
 	scrolling="no" width="100%" height="18"
 	src="http://www.yoursite.com/lotgd/onlinecountxoops.php"></iframe><br>
	*/
	include("dbconnect.php");
	$dblink = mysql_connect($DB_HOST,$DB_USER,$DB_PASS);
	mysql_select_db($DB_NAME,$dblink);
	$sql="SELECT name FROM accounts WHERE locked=0 AND loggedin=1 AND laston>'".date("Y-m-d H:i:s",strtotime("-900 seconds"))."' ORDER BY level DESC";
	$result = mysql_query($sql);
	$onlinecount = mysql_num_rows($result);
	print("<center><font color=\"#0000FF\">".$onlinecount." players online.</font></center>");
?>
</body>
</html>

