<? 
/* The House of Sin
** By Phudgee - phudgee@oldschoolpunk.com
** Written Aug. 10, 2004 in about 3 hours.
** Website: http://www.worldwidepunks.com
** Green Dragon Game: http://www.worldwidepunks.com/logd
**
**
** Installation:
** Create a column: bordello => tinyint(4) not null
** In Table: accounts
**
** in newday.php:
**
**  find:  $session[user][seenmaster]=0;
**
** after, add: $session[user][bordello]=0;
**
** Modify the prices for the different services below, along with the name of the madam.
** Set your return village by setting the $returnvillage variable on line 29
**
** I pounded this together in about 3 hours. Let me know if there are any bugs!
**
*/


require_once "common.php";
addcommentary();
checkday();
$madam = "Butterfly";
$returnvillage = "eldor.php";
page_header("Madam ".$madam."'s House of Sin");
output("<span style='color: #9900FF'>",true);
output("`c`bThe House of Sin`b`c");
$costone = 100;
$costtwo = 250;
$costthree = 500;
$costfour = 750;
$costfive = 1000;

if ($HTTP_GET_VARS[op]==""){
	output("`c`b`%Madam ".$madam." greets you at the door.`0`b`c");
	if ($session[user][bordello] == 1)	{
		output("`n`n`^The bordello is closed for the rest of the day!!`n");
		output("`^Try again tomorrow!!`n`n");
		addnav("Return to the village",$returnvillage);
		page_footer (); 
	}	
	if ($session[user][gold] < $costone)	{
		output("`n`n`^'What do you think!?!?' Madam ".$madam." exclaims!`n");
		output("`^'My ".($session[user][sex]?"`5boys`^ ":"`5girls`^ ")." are not cheap, nor free! Begone!!!'`n`n");
	} else {
	output("`n`nShe offers some of her ".($session[user][sex]?"`^boys`0 ":"`5girls`0 ")." up for your pleasure:`n`n");
	}		
	if ($session[user][gold] >= $costone)	{
		addnav(($session[user][sex]?"`^Tor`0 ":"`5Tiri`0 ")." (".$costone."gp)","bordello.php?op=one");
	}
	if ($session[user][gold] >= $costtwo)	{
	addnav(($session[user][sex]?"`^Sandar`0 ":"`5Sephya`0 ")." (".$costtwo."gp)","bordello.php?op=two");
	}
	if ($session[user][gold] >= $costthree)	{
	addnav(($session[user][sex]?"`^Derris`0 ":"`5Glynna`0 ")." (".$costthree."gp)","bordello.php?op=three");
	}
	if ($session[user][gold] >= $costfour)	{
	addnav(($session[user][sex]?"`^Kierst`0 ":"`5Kyale`0 ")." (".$costfour."gp)","bordello.php?op=four");
	}
	if ($session[user][gold] >= $costfive)	{
	addnav(($session[user][sex]?"`^Travys`0 ":"`5Mora`0 ")." (".$costfive."gp)","bordello.php?op=five");	
	}
}else if ($HTTP_GET_VARS[op]=="one"){
	$session[user][gold]-=$costone;
	$session[user][bordello]=1;
	output("`n`%You hand Madam ".$madam." your `6".$costone."`0gold, and head upstairs with ".($session[user][sex]?"`^Tor`0 ":"`5Tiri`0 ").".`n`n");
	if (e_rand(0,1)==0){ 
		output("`n`%".($session[user][sex]?"`^He`0 ":"`5She`0 ")." is obviously having a bad day, and doesn't come close to pleasuring you.`n");
		output(($session[user][sex]?"`^He`0 ":"`5She`0 ")." gets frustrated and tells you to leave.`n`n");
		output("You demand your money back from Madam ".$madam."!`n");
		output("She tells you that is is behind you on the table... as you turn to gather it,");
		output("she bashes you over the head with a pole.`n`n");
		output("You awake later in the alley with a very sore knot on the back of your head.`n`n");
		switch (e_rand(1,3)){
			case 1:
				output("`n`b`^(You are the laughing stock of the village! You lose two (2) charm)`n");
				addnews("`%".$session[user][name]."`@ was beaten and left in an alley by `%Madam ".$madam."`@");
				$session[user][charm]-=2;
				break;
			case 2:
				output("`n`b`^(You have lost many hitpoints)`n");
				addnews("`%".$session[user][name]."`@ was beaten and left in an alley by `%Madam ".$madam."`@");
				$session[user][hitpoints]-=round($session[user][hitpoints]*.5);
				break;
			case 3:
				output("`n`b`^(You realize you were lying in the alley for quite sometime! You lose 2 turns!)`n");
				addnews("`%".$session[user][name]."`@ was beaten and left in an alley by `%Madam ".$madam."`@");
				$session[user][turns]-=2;
		}
	} else {
		output("`n`%This is the best money you've spent!!`n");
		output(($session[user][sex]?"`^Tor`0 ":"`5Tiri`0 ")." obviously knows what you like.`n`n");
		output(($session[user][sex]?"`^He`0 ":"`5She`0 ")." does things to you you've never imagined!!`n");
		output("After several moments of ecstacy, you leave the building with the biggest grin");
		output("you've had in years!!`n`n");
		switch (e_rand(1,3)){
			case 1:
				output("`n`b`^(You now have a soft \'Glow\'! You gain one (1) charm)`n");
				addnews("`%".$session[user][name]."`@ left the Bordello with a smile on ".($session[user][sex]?"`^her`0 ":"`5his`0 ")." face!!`@");
				$session[user][charm]+=1;
				break;
			case 2:
				output("`n`b`^(You feel like you could take on the world! You gain two (2) turns)`n");
				addnews("`%".$session[user][name]."`@ left the Bordello with a smile on ".($session[user][sex]?"`^her`0 ":"`5his`0 ")." face!!`@");
				$session[user][turns]+=2;
				break;
			case 3:
				output("`n`b`^(You feel fully refreshed! You are completely healed!)`n");
				addnews("`%".$session[user][name]."`@ left the Bordello with a smile on ".($session[user][sex]?"`^her`0 ":"`5his`0 ")." face!!`@");
				$session[user][hitpoints]=$session[user][maxhitpoints];
		}
	}
}else if ($HTTP_GET_VARS[op]=="two"){
	$session[user][bordello]=1;
	$session[user][gold]-=$costtwo;
	output("`n`%You hand Madam ".$madam." your `6".$costtwo."`0gold, and head upstairs with ".($session[user][sex]?"`^Sandar`0 ":"`5Sephya`0 ").".`n`n");
	if (e_rand(0,1)==0){ 
		output("`n`%".($session[user][sex]?"`^He`0 ":"`5She`0 ")." obviously knows how to pleasure a ".($session[user][sex]?"`^woman`0 ":"`5man`0 ").".`n");
		output(($session[user][sex]?"`^He`0 ":"`5She`0 ")." does wonderful things to you for several minutes.....`n`n");
		output("Fully satisfied, you leave with a smile!`n");
		output("Three days later, you're not smiling so big....`n`n");
		switch (e_rand(1,3)){
			case 1:
				output("`n`b`^(You have contracted a disease!!)`n");
				$buff = array("name"=>"`4Disease`0","rounds"=>60,"wearoff"=>"`5`bYour disease subsides!.`b`0","atkmod"=>.95,"roundmsg"=>"Your disease hinders your fighting abilities!","activate"=>"offense");
				$session['bufflist']['bordello']=$buff;
				addnews("`%".$session[user][name]."`@ contracted a disease from a prostitute!`@");
				break;
			case 2:
				output("`n`b`^(You have contracted a disease!!)`n");
				$buff = array("name"=>"`4Disease`0","rounds"=>60,"wearoff"=>"`5`bYour disease subsides!.`b`0","defmod"=>.95,"roundmsg"=>"Your disease hinders your fighting abilities!","activate"=>"defense");
				$session['bufflist']['bordello']=$buff;
				addnews("`%".$session[user][name]."`@ contracted a disease from a prostitute!`@");
				break;
			case 3:
				output("`n`b`^(You have contracted a disease!!)`n");
				$buff = array("name"=>"`4Disease`0","rounds"=>60,"wearoff"=>"`5`bYour disease subsides!.`b`0","atkmod"=>.95,"defmod"=>.95,"roundmsg"=>"Your disease hinders your fighting abilities!","activate"=>"offense");
				$session['bufflist']['bordello']=$buff;
				addnews("`%".$session[user][name]."`@ contracted a disease from a prostitute!`@");
		}
	} else {
		output("`n`%This is the best money you've spent!!`n");
		output(($session[user][sex]?"`^Sandar`0 ":"`5Sephya`0 ")." obviously knows what you like.`n`n");
		output(($session[user][sex]?"`^He`0 ":"`5She`0 ")." does things to you you've never imagined!!`n");
		output("After several moments of ecstacy, you leave the building with a newfound vigor!!`n`n");
		switch (e_rand(1,3)){
			case 1:
				output("`n`b`^(You newfound vigor gains you an added attack bonus plus 10 hitpoints!)`n");
				addnews("`%".$session[user][name]."`@ left the Bordello with a spring in ".($session[user][sex]?"`^her`0 ":"`5his`0 ")." step!!`@");
				$buff = array("name"=>"`!Satisfaction`0","rounds"=>60,"wearoff"=>"`5`bYou're no longer satisfied!.`b`0","atkmod"=>1.05,"roundmsg"=>"Your recent satisfaction enhances your fighting abilities!","activate"=>"offense");
				$session['bufflist']['bordello']=$buff;
				$session[user][hitpoints] += 10;
				break;
			case 2:
				output("`n`b`^(You newfound vigor gains you an added defense bonus plus 2 turns!)`n");
				addnews("`%".$session[user][name]."`@ left the Bordello with a spring in ".($session[user][sex]?"`^her`0 ":"`5his`0 ")." step!!`@");
				$buff = array("name"=>"`!Satisfaction`0","rounds"=>60,"wearoff"=>"`5`bYou're no longer satisfied!.`b`0","defmod"=>1.05,"roundmsg"=>"Your recent satisfaction enhances your fighting abilities!","activate"=>"defense");
				$session['bufflist']['bordello']=$buff;
				$session[user][turns] += 2;
				break;
			case 3:
				output("`n`b`^(You newfound vigor gains you an added attack and defense bonus, 10 additional hitpoints, and a turn!)`n");
				addnews("`%".$session[user][name]."`@ left the Bordello with a spring in ".($session[user][sex]?"`^her`0 ":"`5his`0 ")." step!!`@");
				$buff = array("name"=>"`!Satisfaction`0","rounds"=>60,"wearoff"=>"`5`bYou're no longer satisfied!.`b`0","atkmod"=>1.05,"defmod"=>1.05,"roundmsg"=>"Your recent satisfaction enhances your fighting abilities!","activate"=>"offense");
				$session['bufflist']['bordello']=$buff;
				$session[user][hitpoints] += 10;
				$session[user][turns] += 1;
		}
	}
} else if ($HTTP_GET_VARS[op]=="three"){
	$session[user][bordello]=1;
	$session[user][gold]-=$costthree;
	output("`n`%You hand Madam ".$madam." your `6".$costthree."`0gold, and head upstairs with ".($session[user][sex]?"`^Derris`0 ":"`5Glynna`0 ").".`n`n");
	if (e_rand(0,1)==0){ 
		output("`n`%".($session[user][sex]?"`^He`0 ":"`5She`0 ")." obviously has no clue how to pleasure a ".($session[user][sex]?"`^woman`0 ":"`5man`0 ").".`n");
		output(($session[user][sex]?"`^He`0 ":"`5She`0 ")." tries to do things unheard of!!`n`n");
		output("You head downstairs to complain to the Madam!`n");
		output(($session[user][sex]?"`^Derris`0 ":"`5Glynna`0 ")." bashes you over the head...`n`n");
		output("You wake up in an alley, with a little lighter purse...`n");
		switch (e_rand(1,3)){
			case 1:
				output("`n`b`^(You have been robbed!! News of your predicament spreads fast. You are not able to defend yourself as well!)`n");
				$buff = array("name"=>"`4Humiliation`0","rounds"=>60,"wearoff"=>"`5`bYou regain your pride!.`b`0","defmod"=>.95,"roundmsg"=>"You are too humiliated to defend yourself fully!","activate"=>"defense");
				$session['bufflist']['bordello']=$buff;
				$session[user][gold] = round($session[user][gold] * .5);		
				addnews("`%".$session[user][name]."`@ was robbed by a prostitute!!`@");
				break;
			case 2:
				output("`n`b`^(You have been robbed!! News of your predicament spreads fast. You are not able to attack as well!)`n");
				$buff = array("name"=>"`4Humiliation`0","rounds"=>60,"wearoff"=>"`5`bYou regain your pride!.`b`0","atkmod"=>.95,"roundmsg"=>"You are too humiliated to defend yourself fully!","activate"=>"offense");
				$session['bufflist']['bordello']=$buff;
				$session[user][gold] = round($session[user][gold] * .5);		
				addnews("`%".$session[user][name]."`@ was robbed by a prostitute!!`@");
				break;
			case 3:
				output("`n`b`^(You have been robbed!! News of your predicament spreads fast. You are not able to fight as well!)`n");
				$buff = array("name"=>"`4Humiliation`0","rounds"=>60,"wearoff"=>"`5`bYou regain your pride!.`b`0","defmod"=>.95,"atkmod"=>.95,"roundmsg"=>"You are too humiliated to defend yourself fully!","activate"=>"offense");
				$session['bufflist']['bordello']=$buff;
				$session[user][gold] = round($session[user][gold] * .5);		
				$session[user][gems] = round($session[user][gems] * .5);						
				addnews("`%".$session[user][name]."`@ was robbed by a prostitute!!`@");
		}
	} else {
		output("`n`%This is the best money you've spent!!`n");
		output(($session[user][sex]?"`^Sandar`0 ":"`5Sephya`0 ")." obviously knows what you like.`n`n");
		output(($session[user][sex]?"`^He`0 ":"`5She`0 ")." does things to you you've never imagined!!`n");
		output("After several moments of ecstacy, you leave the building feeling like never before!!`n`n");
		switch (e_rand(1,3)){
			case 1:
				addnews("`%".$session[user][name]."`@ was satisfied at the bordello!!`@");
				output("`n`b`^(This experience refreshed you totally! Your senses are at peak performance. Your defense increases, and you gain a turn!)`n");
				$buff = array("name"=>"`4Refreshed`0","rounds"=>60,"wearoff"=>"`5`bYou no longer feel refreshed!.`b`0","defmod"=>1.5,"roundmsg"=>"Your senses are at peak!!","activate"=>"defense");
				$session['bufflist']['bordello']=$buff;
				$session[user][turns] += 1;
				break;
			case 2:
				addnews("`%".$session[user][name]."`@ was satisfied at the bordello!!`@");
				output("`n`b`^(This experience refreshed you totally! Your senses are at peak performance. Your attack increases, and you gain a turn!)`n");
				$buff = array("name"=>"`4Refreshed`0","rounds"=>60,"wearoff"=>"`5`bYou no longer feel refreshed!.`b`0","atkmod"=>1.5,"roundmsg"=>"Your senses are at peak!!","activate"=>"offense");
				$session['bufflist']['bordello']=$buff;
				$session[user][turns] += 1;
				break;
			case 3:
				addnews("`%".$session[user][name]."`@ was satisfied at the bordello!!`@");
				output("`n`b`^(This experience refreshed you totally! Your senses are at peak performance. Your attack and defense increases!)`n");
				$buff = array("name"=>"`4Refreshed`0","rounds"=>60,"wearoff"=>"`5`bYou no longer feel refreshed!.`b`0","defmod"=>1.5,"atkmod"=>1.5,"roundmsg"=>"Your senses are at peak!!","activate"=>"offense");
				$session['bufflist']['bordello']=$buff;
		}
	}
} else if ($HTTP_GET_VARS[op]=="four"){
	$session[user][bordello]=1;
	$session[user][gold]-=$costfour;
	output("`n`%You hand Madam ".$madam." your `6".$costfour."`0gold, and head upstairs with ".($session[user][sex]?"`^Kierst`0 ":"`5Kyale`0 ").".`n`n");
	if (e_rand(0,1)==0){ 
		output("`n`%".($session[user][sex]?"`^He`0 ":"`5She`0 ")." obviously hasn't been feeling like ".($session[user][sex]?"`^himself`0 ":"`5herself`0 ")."lately.`n");
		output(($session[user][sex]?"`^He`0 ":"`5She`0 ")." sits in the corner and refuses to touch you!!`n`n");
		output("She says you are repulsive, and leaves the room...`n");
		output("Annoyed, you down your drink, gather your things and leave the bordello....`n");
		output("A crowd of people outside gather and point at you laughing....`n");
		output("You are not sure why they are laughing, but ".($session[user][sex]?"`^Kierst`0 ":"`5Kyale`0 ")." leads the crowd.`n");
		switch (e_rand(1,3)){
			case 1:
				output("`n`b`^(You were drugged in the bordello. Your attack and defense are a bit lower.)`n");
				$buff = array("name"=>"`4Drugged`0","rounds"=>60,"wearoff"=>"`5`bThe drugs wear off!.`b`0","defmod"=>.95,"atkmod"=>.95,"roundmsg"=>"You are drugged. It's hard to fight!","activate"=>"offense");
				$session['bufflist']['bordello']=$buff;
				addnews("`%".$session[user][name]."`@ was drugged by a prostitute!!`@");
				break;
			case 2:
				output("`n`b`^(You were drugged in the bordello. Your attack and defense are quite lower.)`n");
				$buff = array("name"=>"`4Drugged`0","rounds"=>60,"wearoff"=>"`5`bThe drugs wear off!.`b`0","defmod"=>.85,"atkmod"=>.85,"roundmsg"=>"You are drugged. It's hard to fight!","activate"=>"offense");
				$session['bufflist']['bordello']=$buff;
				addnews("`%".$session[user][name]."`@ was drugged by a prostitute!!`@");
				break;
			case 3:
				output("`n`b`^(You were drugged in the bordello. Your attack and defense are much lower.)`n");
				$buff = array("name"=>"`4Drugged`0","rounds"=>60,"wearoff"=>"`5`bThe drugs wear off!.`b`0","defmod"=>.75,"atkmod"=>.75,"roundmsg"=>"You are drugged. It's hard to fight!","activate"=>"offense");
				$session['bufflist']['bordello']=$buff;
				addnews("`%".$session[user][name]."`@ was drugged by a prostitute!!`@");
		}
	} else {
		output("`n`%This is the best money you've spent!!`n");
		output(($session[user][sex]?"`^Kierst`0 ":"`5Kyale`0 ")." obviously knows what you like.`n`n");
		output(($session[user][sex]?"`^He`0 ":"`5She`0 ")." treats you right!!!`n");
		output("After several moments of ecstacy, you leave the building in sheer ecstacy!!`n`n");
		switch (e_rand(1,3)){
			case 1:
				output("`n`b`^(You are in ecstacy. Your attack and defense are higher.)`n");			
				$buff = array("name"=>"`4Ecstacy`0","rounds"=>60,"wearoff"=>"`5`bYou no longer feel euphoric!.`b`0","defmod"=>1.05,"atkmod"=>1.05,"roundmsg"=>"Your body is filled with ecstacy!","activate"=>"offense");
				$session['bufflist']['bordello']=$buff;
				addnews("`%".$session[user][name]."`@ found ecstacy at the bordello!!`@");
				break;
			case 2:
				output("`n`b`^(You are in ecstacy. Your attack and defense are quite higher.)`n");			
				$buff = array("name"=>"`4Ecstacy`0","rounds"=>60,"wearoff"=>"`5`bYou no longer feel euphoric!.`b`0","defmod"=>1.15,"atkmod"=>1.15,"roundmsg"=>"Your body is filled with ecstacy!","activate"=>"offense");
				$session['bufflist']['bordello']=$buff;
				addnews("`%".$session[user][name]."`@ found ecstacy at the bordello!!`@");
				break;
			case 3:
				output("`n`b`^(You are in ecstacy. Your attack and defense are quite higher and you gain a turn.)`n");			
				$buff = array("name"=>"`4Ecstacy`0","rounds"=>60,"wearoff"=>"`5`bYou no longer feel euphoric!.`b`0","defmod"=>1.15,"atkmod"=>1.15,"roundmsg"=>"Your body is filled with ecstacy!","activate"=>"offense");
				$session['bufflist']['bordello']=$buff;
				$session[user][turns] += 1;
				addnews("`%".$session[user][name]."`@ found ecstacy at the bordello!!`@");
		}
	}
} else if ($HTTP_GET_VARS[op]=="five"){
	$session[user][bordello]=1;
	$session[user][gold]-=$costfive;
	output("`n`%You hand Madam ".$madam." your `6".$costfive."`0gold, and head upstairs with ".($session[user][sex]?"`^Travys`0 ":"`5Mora`0 ").".`n`n");
	if (e_rand(0,1)==0){ 
		output("`n`%".($session[user][sex]?"`^He`0 ":"`5She`0 ")." starts to pleasure you....`n");
		output(($session[user][sex]?"`^He`0 ":"`5She`0 ")." has you laid back with your eyes closed...`n`n");
		output("You have never felt more pleasure at one time in your life!!!!`n");
		output("You begin to feel up ".($session[user][sex]?"`^Travys`0 ":"`5Mora`0 ")." when you notice something strange.....`n");
		output(($session[user][sex]?"`^Travys`0 ":"`5Mora`0 ")." is really a ".($session[user][sex]?"`^WOMAN`0 ":"`5MAN`0 ")."!!!`n");
		switch (e_rand(1,3)){
			case 1:
				output("`n`b`^(You are too embarassed to show your face around town. You lose turns!!)`n");
				$buff = array("name"=>"`4Embarasment`0","rounds"=>60,"wearoff"=>"`5`bYou have overcome your embarasment!.`b`0","defmod"=>.65,"atkmod"=>.65,"roundmsg"=>"You are too embarassed to fight fully!","activate"=>"offense");
				$session['bufflist']['bordello']=$buff;
				$session[user][turns] -= round($session[user][turns]*.5);
				addnews("`%".$session[user][name]."`@ tried to get with a ".($session[user][sex]?"`^female`0 ":"`5male`0 ")." prostitute!!`@");
				break;
			case 2:
				output("`n`b`^(You are too embarassed to show your face around town. You lose turns!!)`n");
				$buff = array("name"=>"`4Embarasment`0","rounds"=>60,"wearoff"=>"`5`bYou have overcome your embarasment!.`b`0","defmod"=>.55,"atkmod"=>.55,"roundmsg"=>"You are too embarassed to fight fully!","activate"=>"offense");
				$session['bufflist']['bordello']=$buff;
				$session[user][turns] -= round($session[user][turns]*.5);
				addnews("`%".$session[user][name]."`@ tried to get with a ".($session[user][sex]?"`^female`0 ":"`5male`0 ")." prostitute!!`@");
				break;
			case 3:
				output("`n`b`^(You are too embarassed to show your face around town. You lose turns!!)`n");
				$buff = array("name"=>"`4Embarasment`0","rounds"=>60,"wearoff"=>"`5`bYou have overcome your embarasment!.`b`0","defmod"=>.45,"atkmod"=>.45,"roundmsg"=>"You are too embarassed to fight fully!","activate"=>"offense");
				$session['bufflist']['bordello']=$buff;
				$session[user][turns] -= round($session[user][turns]*.5);
				addnews("`%".$session[user][name]."`@ tried to get with a ".($session[user][sex]?"`^female`0 ":"`5male`0 ")." prostitute!!`@");
		}
	} else {
		output("`n`%You are the ".($session[user][sex]?"`^WOMAN`0 ":"`5MAN`0 ")."!!`n");
		output(($session[user][sex]?"`^Travys`0 ":"`5Mora`0 ")." has experienced nothing like you in ".($session[user][sex]?"`^his`0 ":"`5her`0 ")." life!!!`n`n");
		output(($session[user][sex]?"`^He`0 ":"`5She`0 ")." tells the entire village what a great lover you are!!!`n");
		output("You leave the bordello holding your head high!!!`n`n");
		switch (e_rand(1,3)){
			case 1:
				output("`n`b`^(You are the most revered person in the village!! You gain additional turns!!)`n");
				$buff = array("name"=>"`4Greatest Lover`0","rounds"=>60,"wearoff"=>"`5`bYou no longer feel so proud!.`b`0","defmod"=>1.35,"atkmod"=>1.35,"roundmsg"=>"Your pride courses through your veins!!","activate"=>"offense");
				$session['bufflist']['bordello']=$buff;
				$session[user][turns] += 5;
				addnews("`%".$session[user][name]."`@ is the `#Worlds Greatest Lover!!!!`@");
				break;
			case 2:
				output("`n`b`^(You are the most revered person in the village!! You gain additional turns!!)`n");
				$buff = array("name"=>"`4Greatest Lover`0","rounds"=>60,"wearoff"=>"`5`bYou no longer feel so proud!.`b`0","defmod"=>1.45,"atkmod"=>1.45,"roundmsg"=>"Your pride courses through your veins!!","activate"=>"offense");
				$session['bufflist']['bordello']=$buff;
				$session[user][turns] += 5;
				addnews("`%".$session[user][name]."`@ is the `#Worlds Greatest Lover!!!!`@");
				break;
			case 3:
				output("`n`b`^(You are the most revered person in the village!! You gain additional turns!!)`n");
				$buff = array("name"=>"`4Greatest Lover`0","rounds"=>60,"wearoff"=>"`5`bYou no longer feel so proud!.`b`0","defmod"=>1.55,"atkmod"=>1.55,"roundmsg"=>"Your pride courses through your veins!!","activate"=>"offense");
				$session['bufflist']['bordello']=$buff;
				$session[user][turns] += 5;
				addnews("`%".$session[user][name]."`@ is the `#Worlds Greatest Lover!!!!`@");
		}
	}
}
addnav("Return to the village",$returnvillage);
page_footer (); 
?> 