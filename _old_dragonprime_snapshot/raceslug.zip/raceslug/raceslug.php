<?php
function raceslug_getmoduleinfo(){
$info = array(
"name"=>"Race - Slug",
"version"=>"1.0",
"author"=>"Lonny Luberts - Built with Module Builder by `3Lonny Luberts`0",
"category"=>"Races",
"download" => "http://www.pqcomp.com/modules/mydownloads/visit.php?cid=3&lid=177",
"vertxtloc"=>"http://www.pqcomp.com/",
"settings"=>array(
"Slug Race Settings,title",
"minedeathchance"=>"Percent chance for Slugs to die in the mine,range,0,100,1|40",
"goldgemchance"=>"Percent chance for Slugs to find extra gold on battle victory,range,0,100,1|5",
"goldgemmessage"=>"Message to display when finding gold|`&Your Slug senses tingle, and you notice a bag of gold`&!",
"mindk"=>"How many DKs do you need before the race is available?,int|0",
),
);
return $info;
}

function raceslug_install(){
if (!is_module_installed("racehuman")) {
output("The Slug choose to live with humans. You must install that race module.");
return false;
}

module_addhook("chooserace");
module_addhook("setrace");
module_addhook("newday");
module_addhook("charstats");
module_addhook("raceminedeath");
module_addhook("battle-victory");
module_addhook("creatureencounter");
module_addhook("pvpadjust");
module_addhook("adjuststats");
module_addhook("racenames");
return true;
}

function raceslug_uninstall(){
global $session;
$sql = "UPDATE " . db_prefix("accounts") . " SET race='" . RACE_UNKNOWN . "' WHERE race='Slug'";
db_query($sql);
if ($session['user']['race'] == 'Slug')
$session['user']['race'] = RACE_UNKNOWN;
return true;
}

function raceslug_dohook($hookname,$args){
global $session,$resline;

if (is_module_active("racehuman")) {
$city = get_module_setting("villagename", "racehuman");
} else {
$city = getsetting("villagename", LOCATION_FIELDS);
}
$race = "Slug";
switch($hookname){
case "racenames":
$args[$race] = $race;
break;
case "pvpadjust":
if ($args['race'] == $race) {
$args['creaturedefense']+=(2+floor($args['creaturelevel']/5));
}
break;
case"adjuststats":
if ($args['race'] == $race) {
}
break;
case "raceminedeath":
if ($session['user']['race'] == $race) {
$args['chance'] = get_module_setting("minedeathchance");
$args['racesave'] = "Fortunately your Slug skills let you escape unscathed.`n";
$args['schema']="module-raceslug";
}
break;
case "charstats":
if ($session['user']['race']==$race){
addcharstat("Vital Info");
addcharstat("Race", translate_inline($race));
}
break;
case "chooserace":
if ($session['user']['dragonkills'] < get_module_setting("mindk"))
break;
output("In the city of %s, your race of `5Slugs`0, ", true);
addnav("`5Slug`0","newday.php?setrace=$race$resline");
addnav("","newday.php?setrace=$race$resline");
break;
case "setrace":
if ($session['user']['race']==$race){
output("Being low to the ground you see bags of gold that no one else would see!`n");
if (is_module_active("cities")) {
if ($session['user']['dragonkills']==0 &&
$session['user']['age']==0){
set_module_setting("newest-$city",
$session['user']['acctid'],"cities");
}
set_module_pref("homecity",$city,"cities");
if ($session['user']['age'] == 0)
$session['user']['location']=$city;
}
}
break;
case "battle-victory":
if ($session['user']['race'] != $race) break;
if ($args['type'] != "forest") break;
if ($session['user']['level'] < 15 &&
e_rand(1,100) <= get_module_setting("goldgemchance")) {
output(get_module_setting("goldgemmessage")."`n`0");
$session['user']['gold']+= e_rand(1,100);
//debuglog("found extra gold when slaying a monster, for being a Slug.");
}
break;

case "creatureencounter":
if ($session['user']['race']==$race){

raceslug_checkcity();
$loss = (100 - get_module_setting("goldloss"))/100;
$args['creaturegold']=round($args['creaturegold']*$loss,0);
}
break;
case "newday":
if ($session['user']['race']==$race){
raceslug_checkcity();
apply_buff("racialbenefit",array(
"name"=>"`@Slug Healing`0",
"regen"=>"(<defense>?(1+((2+floor(<level>/5))/<defense>)):0)",
"badguydmgmod"=>1.05,
"allowinpvp"=>1,
"allowintrain"=>1,
"rounds"=>-1,
"schema"=>"module-raceslug",
)
);
}
break;
}

return $args;
}

function raceslug_checkcity(){
global $session;
$race="Slug";
if (is_module_active("racehuman")) {
$city = get_module_setting("villagename", "racehuman");
} else {
$city = getsetting("villagename", LOCATION_FIELDS);
}

if ($session['user']['race']==$race && is_module_active("cities")){
if (get_module_pref("homecity","cities")!=$city){
set_module_pref("homecity",$city,"cities");
}
}
return true;
}

function raceslug_run(){
}

?> 