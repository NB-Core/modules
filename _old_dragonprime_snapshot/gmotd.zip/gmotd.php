<?php

function gmotd_getmoduleinfo(){
    $info = array(
        "name"=>"Staff MotD/To-Do List",
        "author"=>"Chris Vorndran",
        "version"=>"0.2",
        "category"=>"Administrative",
		"download"=>"http://dragonprime.net/index.php?module=Downloads;sa=dlview;id=54",
		"vertxtloc"=>"http://dragonprime.net/users/Sichae/",
		"description"=>"Allows for Megausers to set up an MotD in the Grotto, so that only Staff Members can see certain tasks and such.",
        "settings"=>array(
			"Superuser Grotto MotD Settings,title",
            "gmotd"=>"Message to be Displayed in the Grotto,textarea|Standard MotD",
			"id"=>"Acctid of user that wrote it,int|1",
			"date"=>"Date that last MotD was written,text|",
        ),
		"prefs"=>array(
			"seen"=>"Has user seen the Grotto MotD,bool|0",
		),
    );
    return $info;
}
function gmotd_install(){
    module_addhook("header-superuser");
    return true;
}
function gmotd_uninstall(){
    return true;
}
function gmotd_dohook($hookname,$args){
    global $session;
	$seen = get_module_pref("seen");
	$a = "";
	if ($seen == 0) $a = "- `\$NEW";
    switch ($hookname){
        case "header-superuser":
            addnav("*Check Often*");
			addnav(array("`b`^Staff MotD %s`b`0",$a),"runmodule.php?module=gmotd&op=start");
        break;
    }
    return $args;
}
function gmotd_run(){
	global $session;
	$a = translate_inline("Make New MotD");
	$b = translate_inline("Return to Staff MotD");
	$motd = httppost('motd');
	$ch = httppost('change');
	$gmotd = get_module_setting("gmotd");
	$date = get_module_setting("date");
	$id = get_module_setting("id");
	$sql = "SELECT name FROM ".db_prefix("accounts")." WHERE acctid=$id";
	$res = db_query($sql);
	$row = db_fetch_assoc($res);
	$name = $row['name'];
	page_header("Staff MotD/ToDo List");
	$op = httpget('op');
	
	switch ($op){
		case "start":
		require_once("lib/nltoappon.php");
			output("`c`^%s`c`0",nltoappon(stripslashes(get_module_setting("gmotd"))));
			if ($session['user']['superuser'] & SU_EDIT_CONFIG) addnav("Setup MotD","runmodule.php?module=gmotd&op=setup");
			output_notl("`n`n");
			output("`c`#Written by: %s `#on `^%s`c`0",$name,$date);
			set_module_pref("seen",1);
			break;
		case "setup":
			if ($motd == ""){
			require_once("lib/nltoappon.php");
				output("`@Your current MotD reads as:`n`c`^%s`c`0",nltoappon(stripslashes(get_module_setting("gmotd"))));
				output_notl("`n");
				output("`@Would you care to create a new one?");
                rawoutput("<form action='runmodule.php?module=gmotd&op=setup' method='POST'>");
                rawoutput("<textarea name='motd' rows='10' cols='60' class='input'>".stripslashes(htmlentities($gmotd))."</textarea>");
				output("`n`@Which type of Edit is this:`n %s Minor: No change of Author or `b`\$NEW`b`n
%s `@Major: Change of Author and reset of `b`\$NEW`b`0`n", "<input type='radio' name='change' value='0'>", "<input type='radio' name='change' value='1' checked>",true);
                rawoutput("<br><input type='submit' class='button' value='".translate_inline("Change")."'></form>");
			}else{
				rawoutput("<big><center>");
				output("MotD Successfully Changed.");
				rawoutput("</big></center>");
				if ($ch == 1){
					$sql = "UPDATE ".db_prefix("module_userprefs")." SET value=0 WHERE modulename='gmotd' AND setting='seen'";
					db_query($sql);
					set_module_setting("id",$session['user']['acctid']);
				}
				$motd = stripslashes($motd);
				set_module_setting("gmotd",$motd);
				set_module_setting("date",date("Y-m-d H:i:s"));
			}
			addnav("","runmodule.php?module=gmotd&op=setup");
			addnav("Return to Staff MotD","runmodule.php?module=gmotd&op=start");
			break;
		}
	addnav("Return to the Grotto","superuser.php");		
	page_footer();
}
?> 