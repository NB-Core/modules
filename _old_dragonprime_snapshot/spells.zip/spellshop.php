<?php

// 25072004

/*
Part of the spell mod by anpera
available at www.dragonprime.net
*/

require_once("common.php");

page_header("Spells & Special Moves");

$shopowner="Hatetepe";

output("`b`c`VInstant-Spells of all kind`c`b`0`n");
if ($_GET[action]=="sell"){ // Zauberladen (written on a cassiopeia while taking a bath)
	if (isset($_GET[id])){
		$sql="SELECT * FROM items WHERE id=$_GET[id]";
		$result=db_query($sql);
  		$row = db_fetch_assoc($result);
		output("`2$shopowner takes $row[name]`2 and gives you ".($row[gold]?"`^$row[gold] `2gold":"")." ".($row[gems]?"`#$row[gems]`2 gems":"").". ");
		addnav("Sell more","spellshop.php?action=sell");
		$sql="DELETE FROM items WHERE id=$_GET[id]";
		$session[user][gold]+=$row[gold];
		$session[user][gems]+=$row[gems];
		db_query($sql);
	}else{
		$sql="SELECT * FROM items WHERE owner=".$session[user][acctid]." AND (gold>0 OR gems>0) AND class='Spell' ORDER BY name ASC";
		$result=db_query($sql);
		if (db_num_rows($result)){
			output("`2 You show $shopowner your spells and he tells you what he's willing to pay.`n`n");
			output("<table border='0' cellpadding='1' cellspacing='3'>",true);
			output("<tr class='trhead'><td>`bName`b</td><td>`bPreis`b</td></tr>",true);
			for ($i=0;$i<db_num_rows($result);$i++){
			  	$row = db_fetch_assoc($result);
				$bgcolor=($i%2==1?"trlight":"trdark");
				output("<tr class='$bgcolor'><td><a href='spellshop.php?action=sell&id=$row[id]'>$row[name]</a></td><td align='right'>`^$row[gold]`0 Gold, `#$row[gems]`0 Edelsteine</td></tr><tr class='$bgcolor'><td colspan='2'>$row[description]</td></tr>",true);
				addnav("","spellshop.php?action=sell&id=$row[id]");
			}
				output("</table>",true);
		} else {
			output("`2You don't have any interesting spells.");
		}
	}
	addnav("To Shop","spellshop.php");
}else if ($_GET[action]=="buy"){ // ok, water's getting cold ^^
	if (isset($_GET[id])){
		$sql="SELECT * FROM items WHERE id=$_GET[id]";
		$result=db_query($sql);
	  	$row = db_fetch_assoc($result);
		if ($session[user][gems]<$row[gems] || $session[user][gold]<$row[gold]){
			output("`2You can't afford this.");
			addnav("Buy something else","spellshop.php?action=buy");
		}else if (db_num_rows(db_query("SELECT id FROM items WHERE name='$row[name]' AND owner=".$session[user][acctid]." AND class='Spell'"))>0){
			output("`2You have this spell already. Use it or sell it.");
			addnav("Buy something else","spellshop.php?action=buy");
		}else{
			output("`2You point on \"`3$row[name]`2\". $shopowner gives it to you and you hand him ".($row[gold]?"`^$row[gold] `2gold":"")." ".($row[gems]?"`#$row[gems]`2 gems":"")." over. ");
			addnav("Buy more","spellshop.php?action=buy");
			$sql="INSERT INTO items(name,class,owner,value1,value2,hvalue,gold,gems,description,buff) VALUES ('$row[name]','Spell',".$session[user][acctid].",$row[value1],$row[value2],$row[hvalue],$row[gold],$row[gems],'".addslashes($row[description])."','".addslashes($row[buff])."')";
			$session[user][gold]-=$row[gold];
			$session[user][gems]-=$row[gems];
			db_query($sql);
		}
	}else{
		output("`2What do you want?`n`n");
		$ppp=25; // Parts Per Page to display
		if (!$_GET[limit]){
			$page=0;
		}else{
			$page=(int)$_GET[limit];
			addnav("Previos Page","spellshop.php?action=buy&limit=".($page-1));
		}
		$limit="".($page*$ppp).",".($ppp+1);
		$sql="SELECT * FROM items WHERE (owner=0 AND class='Spell') OR class='Spell.Prot' AND gold<=".$session[user][gold]." AND gems<=".$session[user][gems]." ORDER BY class,name ASC LIMIT $limit";
		$result=db_query($sql);
		if (db_num_rows($result)>$ppp) addnav("More Spells","spellshop.php?actino=buy&limit=".($page+1));
		if (db_num_rows($result)){
			output("<table border='0' cellpadding='2' cellspacing='2'>",true);
			output("<tr class='trhead'><td>`bName`b</td><td>`bPrice`b</td></tr>",true);
			for ($i=0;$i<db_num_rows($result);$i++){
			  	$row = db_fetch_assoc($result);
				$bgcolor=($i%2==1?"trlight":"trdark");
				output("<tr class='$bgcolor'><td><a href='spellshop.php?action=buy&id=$row[id]'>$row[name]</a></td><td align='right'>`^$row[gold]`0 Gold, `#$row[gems]`0 Edelsteine</td></tr><tr class='$bgcolor'><td colspan='2'>$row[description]</td></tr>",true);
				addnav("","spellshop.php?action=buy&id=$row[id]");
			}
			output("</table>",true);
	
		} else {
			output("`2\"`3We don't have any spells for you that you can afford`2\"");
		}
	}
	addnav("Got to Shop","spellshop.php");
}else{ 
	output("`2You enter the spellshop of $shopowner.");
	// put your story in here!
	addnav("Sell spell","spellshop.php?action=sell");
	addnav("Buy spell","spellshop.php?action=buy");
}
addnav("Back to village","village.php");

page_footer();
?>