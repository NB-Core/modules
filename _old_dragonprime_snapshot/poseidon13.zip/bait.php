<?
/*********************************************
Lots of Code from: lonnyl69 - Thanks Lonny !
Also Thanks to Excalibur @ dragonprime for your help.
By: Kevin Hatfield - Arune v1.0
06-19-04 - Public Release
Written for Fishing Add-On - Poseidon Pool
ALTER TABLE accounts ADD wormprice int(11) unsigned not null default '0';
ALTER TABLE accounts ADD minnowprice int(11) unsigned not null default '0';
ALTER TABLE accounts ADD wormavail int(11) unsigned not null default '0';
ALTER TABLE accounts ADD minnowavail int(11) unsigned not null default '0';
ALTER TABLE accounts ADD trades int(11) unsigned not null default '0';
ALTER TABLE accounts ADD worms int(11) unsigned not null default '0';
ALTER TABLE accounts ADD minnows int(11) unsigned not null default '0';
ALTER TABLE accounts ADD fishturn int(11) unsigned not null default '0';
add to newday.php
$session['user']['trades'] = 10;
if ($session[user][dragonkills]>1)$session[user][fishturn] = 3;
if ($session[user][dragonkills]>3)$session[user][fishturn] = 4;
if ($session[user][dragonkills]>5)$session[user][fishturn] = 5;

Now in village.php:
addnav("Poseidon Pool","pool.php");
********************************************/
require_once "common.php";
checkday();
page_header("Kerra's Baitshop");
output("`@`c`bKerra's Baitshop`b`c`n");
//
$myname=$session[user][name];
//
//check and display inventory
output("`2You have in your pack.`n");
//Worms
$worms=$session[user][worms];
output("`1bait worms - $worms`n");
$inventory=$session[user][worms];
//Minnows
$minnow=$session[user][minnows];
output("`!Minnows - $minnow`n");
$inventory+=$session[user][minnows];
//Trades
$trades=$session[user][trades];
output("`7You have $trades transactions left.`n");
//Inventory Checking//
$space=(50 - $inventory);
if ($inventory < 50) output("`2You have space left for $space more items.`n`n");
if ($inventory > 49) output("`4You notice that your Pack is full.`n`n");
//
//built first time navigation
	if ($HTTP_GET_VARS[op]==""){
	if ($session[user][trades] > 0) 
	$wormgold = e_rand(1,4);
	$session[user][wormprice]=$wormgold;
	$minnowgold = e_rand(5,9);
	$session[user][minnowprice]=$minnowgold;
	$wormavail = e_rand(5,25);
	$session[user][wormavail]=$wormavail;
	$minnowavail= e_rand(5,25);
	$session[user][minnowavail]=$minnowavail;
    }
//cancelled buy or sell navigation
if ($HTTP_GET_VARS[op]=="" or $HTTP_GET_VARS[op]=="trade"){
if ($session[user][trades] > 0){
if ($HTTP_GET_VARS[op]==""){
 if ($session[user][dragonkills]>1){
 output("`5Kerra is behind the counter, she says \"`6What is it you would like today?`5\"`n");
}else{
 output("Kerra walks up to the counter, she says \"`6I'm sorry but you are not experienced enough to have use of this area yet!`0\"`n`n");
}
}
if ($HTTP_GET_VARS[op]=="trade") output("`5Kerra says \"`6What else?`5\"`n");$wormgold=$session[user][wormprice];

$wormgold=$session[user][wormprice];
$minnowgold=$session[user][minnowprice];

if ($session[user][wormavail] > 1 and $session[user][dragonkills]>6) addnav("`!bait worms `^($wormgold gold)","bait.php?op=worms");
if ($session[user][minnowavail] > 1 and $session[user][dragonkills]>2) addnav("`!Minnows `^($minnowgold gold)","bait.php?op=minnow");
addnav("`@Return to Pool","pool.php");
}
else{
        output("`4You Cannot Trade anymore today.`n");
        addnav("`@Return to Pool","pool.php");
}
}
//Selections
if ($HTTP_GET_VARS[op]=="worms"){
        $wormgold=$session[user][wormprice];
        output("`3Bait worms are going for $wormgold gold, would you like to buy or sell?`n");
        addnav("`2Buy","bait.php?op=wormbuy");
        addnav("`4Sell","bait.php?op=wormsell");
        addnav("`!Buy Something Else","bait.php?op=trade");
        addnav("`@Return to Pool","pool.php");
    }
if ($HTTP_GET_VARS[op]=="minnow"){
        $minnowgold=$session[user][minnowprice];
        output("`3Minnows are going for $minnowgold gold, would you like to buy or sell?`n");
        addnav("`2Buy","bait.php?op=minnowbuy");
        addnav("`4Sell","bait.php?op=minnowsell");
        addnav("`!Buy Something Else","bait.php?op=trade");
        addnav("`@Return to Pool","pool.php");
    }
//buy products
if ($HTTP_GET_VARS[op]=="wormbuy"){
        if ($inventory>49){
                output("`!You cannot carry any more in your pack.  You need to sell something first.`n");
            }
        else{
        output("`%How many Bait worms would you like to buy?`n");
    output("<form action='bait.php?op=wormbuy2' method='POST'><input name='buy' id='buy'><input type='submit' class='button' value='buy'></form>",true);
    output("<script language='JavaScript'>document.getElementById('buy').focus();</script>",true);
    addnav("","bait.php?op=wormbuy2");
    }
    addnav("`!Buy Something Else","bait.php?op=trade");
        addnav("`@Return to Pool","pool.php");
}
if ($HTTP_GET_VARS[op]=="wormbuy2"){
	$buy = $HTTP_POST_VARS[buy];
	if ($buy > (50 - $inventory)) $buy = (50 - $inventory);
        if ($session[user][gold] < ($buy * $session[user][wormprice])) output("You can't afford that!");
        else{
                output("`!The man takes your money and hands you $buy bait worms.");
                $cost=($buy * $session[user][wormprice]);
                $session[user][gold]-=$cost;
                $session[user][worms]+=$buy;
                $session[user][trades]-=1;
            }
	addnav("`!Buy Something Else","bait.php?op=trade");
	addnav("`@Return to Pool","pool.php"); 
    }

if ($HTTP_GET_VARS[op]=="minnowbuy"){
        if ($inventory>49){
                output("`!You cannot carry any more in your pack.  You need to sell something first.`n");
            }
        else{
        output("`%How many minnows would you like to buy?`n");
    output("<form action='bait.php?op=minnowbuy2' method='POST'><input name='buy' id='buy'><input type='submit' class='button' value='buy'></form>",true);
    output("<script language='JavaScript'>document.getElementById('buy').focus();</script>",true);
    addnav("","bait.php?op=minnowbuy2");
    }
    addnav("`!Buy Something Else","bait.php?op=trade");
        addnav("`@Return to Pool","pool.php");
}
if ($HTTP_GET_VARS[op]=="minnowbuy2"){
	$buy = $HTTP_POST_VARS[buy];
	if ($buy > (50 - $inventory)) $buy = (50 - $inventory);
        if ($session[user][gold] < ($buy * $session[user][wormprice])) output("You can't afford that!");
        else{
                output("`!The man takes your money and hands you $buy bait worms.");
                $cost=($buy * $session[user][wormprice]);
                $session[user][gold]-=$cost;
                $session[user][minnows]+=$buy;
                $session[user][trades]-=1;
		}
	        addnav("`!Buy Something Else","bait.php?op=trade");
        addnav("`@Return to Pool","pool.php");
    }

//sell
if ($HTTP_GET_VARS[op]=="wormsell"){
        if ($session[user][worms]<1){
                output("`!You don't have any bait worms to sell.`n");
            }
        else{
        output("You have $worms bait worms to sell.`n");
    output("`%How many bait worms would you like to sell?`n");
    output("<form action='bait.php?op=wormsell2' method='POST'><input name='sell' id='sell'><input type='submit' class='button' value='sell'></form>",true);
    output("<script language='JavaScript'>document.getElementById('bet').focus();</script>",true);
    addnav("","bait.php?op=wormsell2");
    }
    addnav("`!Buy Something Else","bait.php?op=trade");
        addnav("`@Return to Pool","pool.php");
}

if ($HTTP_GET_VARS[op]=="wormsell2"){
        if ($session[user][worms] < $sell) output("`%You don't have that many!`n");
        else{
                $cost=($sell * $session[user][wormprice]);
                output("`!The man takes your $sell bait worms and hands you $cost gold.`n");
                $session[user][gold]+=$cost;
                $session[user][worms]-=$sell;
                $session[user][trades]-=1;
            }
        addnav("`!Buy Something Else","bait.php?op=trade");
        addnav("`@Return to Pool","pool.php");
    }
if ($HTTP_GET_VARS[op]=="minnowsell"){
        if ($session[user][minnows]<1){
                output("`!You don't have any minnows to sell.`n");
            }
        else{
        output("You have $minnow minnows to sell.`n");
    output("`%How many bait worms would you like to sell?`n");
    output("<form action='bait.php?op=minnowsell2' method='POST'><input name='sell' id='sell'><input type='submit' class='button' value='sell'></form>",true);
    output("<script language='JavaScript'>document.getElementById('bet').focus();</script>",true);
    addnav("","bait.php?op=minnowsell2");
    }
    addnav("`!Buy Something Else","bait.php?op=trade");
        addnav("`@Return to Pool","pool.php");
}

if ($HTTP_GET_VARS[op]=="minnowsell2"){
        if ($session[user][minnows] < $sell) output("`%You don't have that many!`n");
        else{
                $cost=($sell * $session[user][minnowprice]);
                output("`!The man takes your $sell minnows and hands you $cost gold.`n");
                $session[user][gold]+=$cost;
                $session[user][minnows]-=$sell;
                $session[user][trades]-=1;
            }
        addnav("`!Buy Something Else","bait.php?op=trade");
        addnav("`@Return to Pool","pool.php");


    }
page_footer();
?>
