<?
/*********************************************
Lots of Code from: lonnyl69 - Big thanks for help!
By: Kevin Hatfield - Arune v1.0
Written for Fishing Add-On - Poseidon Pool
06-19-04 - Public Release
ALTER TABLE accounts ADD wormprice int(11) unsigned not null default '0';
ALTER TABLE accounts ADD minnowprice int(11) unsigned not null default '0';
ALTER TABLE accounts ADD wormavail int(11) unsigned not null default '0';
ALTER TABLE accounts ADD minnowavail int(11) unsigned not null default '0';
ALTER TABLE accounts ADD trades int(11) unsigned not null default '0';
ALTER TABLE accounts ADD worms int(11) unsigned not null default '0';
ALTER TABLE accounts ADD minnows int(11) unsigned not null default '0';
ALTER TABLE accounts ADD fishturn int(11) unsigned not null default '0';
add to newday.php
$session['user']['trades'] = 10;
if ($session[user][dragonkills]>1)$session[user][fishturn] = 3;
if ($session[user][dragonkills]>3)$session[user][fishturn] = 4;
if ($session[user][dragonkills]>5)$session[user][fishturn] = 5;
Now in village.php:
addnav("Poseidon Pool","pool.php");
********************************************/

require_once "common.php";
checkday();
addcommentary();
page_header("Poseidon Pool");
output("`c`b`&Poseidon Pool`0`b`c`n`n");
if ($HTTP_GET_VARS[op] == "" ){
	redirect("pool.php?op=chat");
}
if ($HTTP_GET_VARS[op] == "quit" ){
	redirect("kiosk.php");	
}
if ($HTTP_GET_VARS[op] == "chat" ){
output("`7This is a dark place, almost magically dim. Unlike other areas in the grounds this area seems to always have fog seemingly reaching from the ground to the skies above. You can see the edge of the water and on around near the main fishing spot, light shines down from the sun beaming off the water.`n Everytime you come here, it always amazes you how the lighting never changes...Even the weather rarely changes in this area, despite the changes elsewhere..`n`n"); 
output("As unusual and truly dangerous this area can be, the possibilities of treasure found in the waters before you, keep you returning..`n`n");
}
output("`n`2-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-`n");
viewcommentary("pool", "Chat here", 100, "says");
addnav("Return to Village","village.php");
addnav("Bait Shop","bait.php");
if ($session['user']['dragonkills']>1) addnav("Fishing Hole","fish.php");
output("`n`7Page needs to be Refreshed to see recent commentary.`n");
addnav("Refresh Page","pool.php?op=chat");
page_footer();
?>
