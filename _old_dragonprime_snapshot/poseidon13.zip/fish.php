<? 
/*********************************************
Lots of Code from: lonnyl69 - Big thanks for the help.
By: Kevin Hatfield - Arune v1.0
06-19-04 - Public Release
Written for Fishing Add-On - Poseidon Pool
ALTER TABLE accounts ADD wormprice int(11) unsigned not null default '0';
ALTER TABLE accounts ADD minnowprice int(11) unsigned not null default '0';
ALTER TABLE accounts ADD wormavail int(11) unsigned not null default '0';
ALTER TABLE accounts ADD minnowavail int(11) unsigned not null default '0';
ALTER TABLE accounts ADD trades int(11) unsigned not null default '0';
ALTER TABLE accounts ADD worms int(11) unsigned not null default '0';
ALTER TABLE accounts ADD minnows int(11) unsigned not null default '0';
ALTER TABLE accounts ADD fishturn int(11) unsigned not null default '0';
add to newday.php
$session['user']['trades'] = 10;
if ($session[user][dragonkills]>1)$session[user][fishturn] = 3;
if ($session[user][dragonkills]>3)$session[user][fishturn] = 4;
if ($session[user][dragonkills]>5)$session[user][fishturn] = 5;
Now in village.php:
addnav("Poseidon Pool","pool.php");
********************************************/
require_once "common.php"; 
checkday(); 
addcommentary();
page_header("The Fishing Hole"); 
//check and display inventory
output("`2You have in your pack.`n");
//Worms
$worms=$session[user][worms];
if ($session[user][worms]>0){ //These were added due to counters going into negative.
output("`!bait worms - $worms`n");
}else{
output("`!bait worms - 0`n");
}
$inventory=$session[user][worms];
//Minnows
$minnow=$session[user][minnows];
if ($session[user][minnows]>0){ //These were added due to counters going into negative.
output("`!Minnows - $minnow`n");
}else{
output("`!Minnows - 0`n");
}
$inventory+=$session[user][minnows];
$fishturns=$session[user][fishturn];
if ($session[user][fishturn]>0){ //These were added due to counters going into negative.
output("`!Fishing Turns - $fishturns`n");
}else{
output("`!Fishing Turns - 0`n");
}
if ($HTTP_GET_VARS[op] == "" ){
}
//output("`c<img src='images/fishing.jpg''>`c", true);
addnav("To do"); 
if ($session[user][minnows] > 0 and $session[user][fishturn] > 0) addnav("`!Cast Minnow","fish.php?op=check1");
if ($session[user][worms] > 0 and $session[user][fishturn] > 0) addnav("`!Cast Worm","fish.php?op=check2");
addnav("R?Return to Pool","pool.php");
addnav("B?Bait Shop","bait.php");
output("`n`n`7You follow the path around to the large fishing area...`n");
output("Looking around you see other villagers lounging on the weathered benches, with a sunny day like this");
output("the fishing should be excellent.`n`n");
if ($HTTP_GET_VARS[op]=="check1"){
	output("`n`nYou cast your line...`n`n");
        $session[user][minnows]-=1;
	$session[user][fishturn]-=1;
              check1();
}
if ($HTTP_GET_VARS[op]=="check2"){
	output("`n`nYou cast your line...`n`n");
        $session[user][worms]-=1;
	$session[user][fishturn]-=1;
              check2();
}
output("`n`2-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-`n");
viewcommentary("fishing", "Chat here", 1000, "says");
 
/*******************
Fishing With Minnows
*******************/
function check1(){ 
global $session; 
switch (e_rand(1,25)){ 
case 1: 
output("A boot?!`n"); 
output("You spend 10 minutes trying to get the boot off your hook...`n"); 
output("Taking so long.`n`n"); 
output("`bYou lose 1 Fishing Turn`n`n"); 
$session[user][fishturn]-=1;

break; 

case 2: 
output("`@ You reel in a small pouch... `n`n"); 
$a=e_rand(2,75); 
output("`^Inside you find",$a,"gold !!`^`n`n"); 
$session[user][gold]+= $a; 
$session[user][fishturn]-=1; 

break; 

case 3: 
output("You throw out your line, sitting down you have been bitten by a `!Rattle Snake`!!!! `n`n"); 
$b=e_rand(10,20); 
output("You Lose ", $b ," hitpoints"); 
$session[user][hitpoints] -= $b; 
output("`!You are about to pass out!`!`n"); 
output("`4You decide you have had enough fishing for today..`n`n"); 
$session[user][fishturn]=0; 


break; 

case 4: 
output("You have came up empty! `n`n"); 
$session[user][fishturn]-=1; 

break; 

case 5: 
output("`@You have caught a branch!!!`n`n"); 
$session[user][fishturn]-=1; 


break; 

case 6: 
output("`2Your hook gets caught in your hand!! `nYou lose 12 Hitpoints. `n`n"); 
$session[user][hitpoints]-=12; 
$session[user][fishturn]-=1; 

break; 

case 7: 
output("You have came up empty!`n`n"); 
$session[user][fishturn]-=1; 

break; 

case 8: 
$number = e_rand(1,5); 
output("As you were reeling in your line you notice something shining beside you...`n");
output("`^`bYou find 1 gem !!! `^`b`n`n"); 
$session[user][gems]+=1; 
$session[user][fishturn]-=1; 

break; 

case 9: 
output("`@You have snagged something.. `n`n");
output("`!Reeling it in you find a small pouch of worms... `n`n");
output("`&`bYou gain 3 worms!`n Free bait!`b`n`n"); 
$session[user][worms]+=3; 
$session[user][fishturn]-=1; 

break; 

case 10: 
output("`!You have caught a shiny gem! `n`n"); 
output("`7As you hold the gem in your hands..`n"); 
output("A bright flash of light illuminates the area!!!`n`n"); 
        if    (strchr($session[user][weapon],"Glowing")){
	output("`b`4Your weapon continues to glow!");
	break;
	}else{	
output(" You feel stronger"); 
debuglog("Weapon - Glowing enhancement from pool");
$session[user][hitpoints]+=20; 
$session[user][attack]+=10; 
$session[user][defence]+=10; 
$session[user][fishturn]-=1;
$newweapon = "Glowing ".$session[user][weapon];
$session[user][weapon]=$newweapon;
$session[user][weapondmg]+2;
}
break; 

case 11: 
output("`4The wind catches your line and it wraps around your neck...hooking into your throat!`n`n");
output("`3You are choking to death!`n");
output("`7You have fallen unconscious!`n");
addnews("`@".$session[user][name]."`@ has `5hung`@ themselves on the banks fishing."); 
$session[user][alive]=false; 

break; 

case 12: 
output("`3You lost your bait!`3 `n`n"); 
$session[user][fishturn]-=1; 

break; 

case 13:
output("You have came up empty!`n`n");
$session[user][fishturn]-=1;

break;

case 14: 
output("`7You fall into the water!`n"); 
output("Swimming for your like you pull yourself on the bank, soaking wet.`n");
output("`^You have lost 5 charm!"); 
$session[user][charm]-=5; 

break; 

case 15: 
output("`3Your minnow flies off your hook!`3 `n`n"); 
$session[user][fishturn]-=1; 

break; 

case 16: 
output("You catch an enormous bass !`n`n");
output("`7Onlookers gather around you to see your catch!`n"); 
output("`^You gain 3 charm!!`^`n`n"); 
$session[user][charm]+=3; 
$session[user][fishturn]-=1; 

break; 

case 17: 
output("`@You get a bite! `n`n");
output("`6Unfortunately it catches you off-guard...You snatch your rod, stumbling back you kick over your pail`n");
output("of minnows!`n");
output("`4You lost all your minnows!`n`n"); 
$session[user][minnows]--; 
$session[user][fishturn]-=1;
break; 

case 18: 
output("`@You get a bite!`n`n"); 
output("You jump back and reel furiously!`n");
output("`7TOO Much Pressure! You broke your line!`n"); 
output("`4Your pole flies back hitting you in the face!`n");
output("`4You lose 40 hitpoints!`n`n");
$session[user][hitpoints]-=40; 
$session[user][fishturn]-=1; 

break; 

case 19: 
output("`2You catch a rotten corpse! `2`n`n"); 
output("`7........`n");
output("You decide to check its pockets.`n");
output("`^You have found 250 gold and lose 2 turns!`n`n");
$session[user][gold]+=250; 
$session[user][fishturn]-=2;

break; 

case 20:
output("You have came up empty!`n`n");
$session[user][fishturn]-=1;

break;

case 21: 
output("`2Casting out you notice a box of worms near you!`2`n`n");
output("`^You have found 3 worms!`n`n"); 
$session[user][worms]+=3; 

break; 

case 22: 
output("You have caught a small pouch! `n`n"); 
output("Inside you find 2 gems !`n");
output("`^You Gain 2 Gems!`^ `n`n"); 
$session[user][gems]+=2;  
$session[user][fishturn]-=1; 

break; 

case 23:
output("You have came up empty!`n`n");
$session[user][fishturn]-=1;

break;

case 24:
output("You have came up empty!`n`n");
$session[user][fishturn]-=1;

break;

case 25:
output("As your minnow hits the water you feel a huge surge of energy!`n`n");
output("The god's are looking after you today!`n");
output("`^You feel strong!");
$session[user][attack]+=15;
$session[user][fishturn]-=1;

break;

case 26:
output("`4You stumble over a rock and fall into the water! `0!`n`n");
output("Undoubtedly you hit your head and washed back onto the shore..`n");
output("Upon waking...You notice all your gold and gems are missing!`n`n");
$session[user][hitpoints]=1;
$session[user][fishturn]=0;
$session[user][gold]=0;
$session[user][gems]=0;

break;
} 
} 
/************************
Fishing with worms
************************/
function check2(){
global $session;
switch (e_rand(1,21)){
case 1:

output("You have came up empty! `n`n");
$session[user][fishturn]-=1;

break;

case 2:

output("You have came up empty! `n`n");
$session[user][fishturn]-=1;

break;

case 3:

output("Reeling in your line you have caught a large heavy bag...`n");
output("Looking inside the bag you find.`n");
output("`^3 Gems!`0`n`n");
$session[user][fishturn]-=1;
$session[user][gems]+=3;

break;

case 4:

output("You reel in a monstrous catch!`n");
output("Many fishermen look at you in total disgust!`n");
output("`^You have lost 10 Charm!`0`n`n");
$session[user][charm]-=10;
$session[user][fishturn]-=1;

break;

case 5:

output("You have snagged your line!`n");
output("You lost your bait..`n`n");

break;

case 6:

output("Reeling in your line, you snag a small bucket..`n");
output("Inside you find `^15 minnows`0!`n`n");
output("`4Emptying the bucket into your pail you find `12 gems`4 buried inside!`n`n");
$session[user][fishturn]-=1;
$session[user][minnows]+=15;
$session[user][gems]+=2;

break;

case 7:

output("You have came up empty! `n`n");
$session[user][fishturn]-=1;

break;

case 8:

output("You have came up empty! `n`n");
$session[user][fishturn]-=1;

break;

case 9:

output("You have came up empty! `n`n");
$session[user][fishturn]-=1;

break;

case 10:

output("You have came up empty! `n`n");
$session[user][fishturn]-=1;

break;

case 11:

output("You have came up empty! `n`n");
$session[user][fishturn]-=1;

break;

case 12:

output("You have came up empty! `n`n");
$session[user][fishturn]-=1;

break;

case 13:
output("As your reeling your line in your hook snags something shiny..`n");
output("A sharp jolt of energy streams throughout your body!`n`n");
output("`^You gain 10 defense today!`0`n`n");
$session[user][fishturn]-=1;
$session[user][defence]+=10;

break;

case 14:
output("`!You have caught a gleaming crytal! `n`n");
output("`7As you hold the crystal in your hands..`n");
output("A bright flash of light illuminates the area!!!`n`n");
        if    (strchr($session[user][weapon],"Crystalized")){
        output("`b`4Your weapon continues to crystalize!");
        break;
        }else{
output(" Your weapon changes its form..`n`n");
debuglog("Weapon - Crystalized enhancement from pool");
$session[user][hitpoints]+=20;
$session[user][attack]+=15;
$session[user][defence]+=15;
$session[user][fishturn]-=1;
$newweapon = "Crystalized ".$session[user][weapon];
$session[user][weapon]=$newweapon;
$session[user][weapondmg]+3;
}
break;

case 15:

output("You hook an extremely large fish...`n");
output("With fear of losing your pole you wrap your weapon strap around the handle and your belt!`n");
output("The fish begins to struggle and flip out of the water...Realizing this maybe more than you can handle!`n");
output("You have lost your step and drug into the water face first..`n");
output("Struggling to get your belt lose you are running out of air quickly!`n");
if ($session[user][attack]<30){
 output("`4The line is held too tight, you cannot break free and begin to slowly drown`n`n");
 $session[user][alive]=false;
 }else{
 output("`!You have broken free! Swimming to the shore...You decide thats enough of this for today!`n`n");
 $session[user][fishturn]=0;
 $session[user][hitpoints]=1;
}

break;

case 16:

output("You have came up empty! `n`n");
$session[user][fishturn]-=1;

break;

case 17:

output("You have came up empty! `n`n");
$session[user][fishturn]-=1;

break;

case 18:

output("You have came up empty! `n`n");
$session[user][fishturn]-=1;

break;

case 19:

output("You have came up empty! `n`n");
$session[user][fishturn]-=1;

break;

case 20:

output("`0You have caught a bag full of `^gold`0!`n");
output("Greedily counting your gold you do not notice another fisherman running over to you!`n");
output("`4BOOM! `0You have been hit by something blunt...You are knocked unconscious!`n`n");
output("Upon waking...You notice all your gold and gems are missing!`n`n");
$session[user][hitpoints]=1;
$session[user][fishturn]=0;
$session[user][gold]=0;
$session[user][gems]=0;

break;

case 21:

output("You have caught ....`n");
output("`^a chisel!`n");
output("`&Thinking over the many uses...`0You decide to touch up your armor.`n");
output("`0Wow..Your armor sure has taken a beaten lately!`n");
if    (strchr($session[user][armor],"Modified")){
        output("`b`4Your armor is already modified!`n`n");
        break;
        }else{
output(" Your armor smooths out and looks much better!`n");
debuglog("Armor - Chisel enhancement from pool");
$session[user][defence]+=5;
$session[user][fishturn]-=1;
$newarmor = "Modified ".$session[user][armor];
$session[user][armor]=$newarmor;
$session[user][charm]+=5;
output("Hey! You even look better!`n");
output("`^You gain 5 charm!`n`n");
}

break;
}
}
page_footer(); 
?>