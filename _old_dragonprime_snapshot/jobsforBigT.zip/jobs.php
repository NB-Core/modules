<?
/*Created by BiG T, Modified by Jnfoot

IN YOUR DB:
accounts table change:
	ALTER TABLE `dbname`.`accounts` ADD `jobname` TEXT NOT NULL;
	ALTER TABLE `dbname`.`accounts` ADD `nextpaycheck` INT DEFAULT '3' NOT NULL;
create a table called jobs:
	CREATE TABLE `jobs` (`id` INT NOT NULL AUTO_INCREMENT, `jobname` TEXT NOT NULL, `joblevel` INT DEFAULT '1' NOT NULL, `jobdesc` TEXT NOT NULL, `pay` TEXT NOT NULL,INDEX (`id`));

IN NEWDAY.PHP:
just before: if ($session['user']['hashorse']){
add this:
if ($session['user']['jobname']!="") {
			output("`n`&Your current job is ".$session['user']['jobname']);
			if ($session['user']['nextpaycheck']!=0) {
				output("`n`&You have ".$session['user']['nextpaycheck']." working days until you get your next paycheck.`n");
			} else {
				output("`n`&You have worked hard. So here is your paycheck.");
				$sql = "SELECT pay FROM jobs WHERE jobname='".$session['user']['jobname']."'";
				$result = db_query($sql);
				$row = db_fetch_assoc($result);
				$paycheck = explode(" ", $row['pay']);
				if ($paycheck[1]=="gold") {
					$session['user']['gold']=$session['user']['gold']+$paycheck[0];
				} else if ($paycheck[1]=="gems") {
					$session['user']['gems']=$session['user']['gems']+$paycheck[0];
				}
				output("`n`&You have been payed ".$row['pay']."`n");
				$session['user']['nextpaycheck']=3;
			}
		}

To test a job:
in the table jobs, just create a job with: jobname = Test job 1 | joblevel = 0 | jobdesc = This is just a test job. | pay = 100 gold
*/


require_once "common.php";
checkday();
if ($HTTP_GET_VARS[op]=="") {
page_Header("Jobs");
	addnav("Jobs");
	output("`c`b`&Jobs`b`c");
    	output("You walk in and see alot of people with job applications");

	if ($session['user']['jobname']=="") {
		addnav("Apply for Job","jobs.php?op=apply");
	} else {
		output("Your current job is ".$session['user']['jobname']);
		addnav("Go to work","jobs.php?op=work");
	}
	addnav("Village");
    addnav("Return to Village","village.php");
} else if ($HTTP_GET_VARS[op]=="apply") {
page_Header("Apply for Job");

   output("`!`bApply`b\n");
	output("Here is a list of all the jobs that you qualify for:`n");
	$sql = "SELECT * FROM jobs WHERE joblevel <= ".$session['user']['dragonkills']." ORDER BY joblevel DESC,jobname";
	$result = db_query($sql);
	addnav("Jobs Open");
	if(db_num_rows($result)<1) {
		addnav("No jobs available");
		output("You don't qualify for any jobs. You need to kill the dragon before we will hire you.`n");
	} else {
		for ($i=0;$i<db_num_rows($result);$i++){
    			$row = db_fetch_assoc($result);
			output($row['jobname'].": ".$row['jobdesc']."`n");
			output("Pay: ".$row['pay']."\n");
			addnav("Apply for ".$row['jobname'],"jobs.php?op=".$row['id']);
		}
	}
	addnav("Village");
	addnav("Return to Village","village.php");
} else if ($HTTP_GET_VARS[op]=="work") {
	page_header("On the Job");
	if ($session['user']['turns']>9) {
		output("You spend most your day working at your job.");
		$session['user']['nextpaycheck']--;
		if ($session['user']['nextpaycheck']==0) {
			output("`nTomorrow is payday!");
		} else {
		output("`nOnly ".$session['user']['nextpaycheck']." working days until your next paycheck.");
		}
		$session['user']['turns'] -= 10;
	} else {
		output("You came to work late ".$session['user']['name']."!");
		output("`nYou must come to work with at least 10 turns remaining.");
	}
	addnav("Village");
	addnav("Return to Village","village.php");
	
} else {
	page_header("Job Acceptance");
	$sql = "SELECT * FROM jobs WHERE id = ".$HTTP_GET_VARS[op]." LIMIT 1";
	$result = db_query($sql);
	$row = db_fetch_assoc($result);
	if($session['user']['dragonkills']<$row['joblevel']) {
		output("You don't qualify for this job!!!`n");
		addnav("Job Desk");
		addnav("Search Jobs","jobs.php?op=apply");
	} else {
		output("Great. Your job is now".$row['jobname'].".`n");
		output("I hope you like this job because there isn't any way to quit yet :)");
		$session['user']['jobname']=$row['jobname'];
		$session['user']['nextpaycheck']=3;
		addnav("Village");
		addnav("Return to Village","village.php");
	}
}
page_footer();
?>