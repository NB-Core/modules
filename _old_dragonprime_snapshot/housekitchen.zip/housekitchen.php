<?php
/*
		House Kitchen...
			,,,we all get the munchies now and again,
				it's nice to have our own place to snack.

		~~ History ~~
		
		1.0.0
			Initial Release
*/

require_once("common.php");

function housekitchen_getmoduleinfo() {
	$info = array(
		"name"=>"House Rooms - Kitchen",
		"author"=>"Rowne-Wuff Mastaile",
		"version"=>"1.0.0",
		"category"=>"Village",
		"settings"=>array(
			"pcookieon"=>"Are the Power Cookies (tm) enabled?,bool|1",
			"pcookiedie"=>"The player has a 1 in ? chance of dying:,int|3",
			"pcookieturn"=>"The player gains ? turns from a cookie:,int|8",
		),
		"requires"=>array(
			"usechow"=>"1.3|By `#Lonny Luberts",
			"houserooms"=>"1.0.0|By Rowne-Wuff Mastaile",
		),
	);
	return $info;
}

function housekitchen_install() {
	set_module_pref ("kitchenon", 1, "houserooms");
	set_module_pref ("kitchenempty", 0, "houserooms");
	module_addhook("kitchencontents");
	return true;
}

function housekitchen_uninstall() {
	set_module_pref ("kitchenon", 0, "houserooms");
	set_module_pref ("kitchenempty", 1, "houserooms");
	return true;
}

function housekitchen_dohook($hookname, $args) {
	global $session;
	
	switch ($hookname){
	case "kitchencontents":
		$pcookie	=	get_module_setting	("pcookieon");
		output ("`7");
		output ("An incredibly clean Kitchen is laid out before you.");
		output ("All the appliances you'd need to fix up a nice snack");
		output ("before heading back out into the World.");
		output ("Face it with a full stomach, you would. The Kitchen,");
		output ("is well stocked and catered for aswell. You're not quite");
		output ("sure by who as there doesn't seem to be anyone `ihere`i ...");
		output ("but there are certainly many forms of fresh foodstuffs about.");
		output ("`n`n");
		addnav ("Fix a Snack", "runmodule.php?module=housekitchen&op=snack");
		if ($pcookie) {
			output ("The other oddity you happen to spot is a jar of cookies on the table.");
			output ("They're labelled `b`^Power Cookies`b`7 but their jar also has an");
			output ("ominous Skull and Crossbones on it, right next to a smiley-faced Sun.");
			output ("You can't help but wonder `iwhat the hell`i is up with those cookies.");
			output ("`n`n");
			addnav ("Eat a Cookie", "runmodule.php?module=housekitchen&op=cookie");
		}
		break;
	}

	return $args;
}

function housekitchen_run() {
	global $session;
	
	$op			= httpget			("op");
	$subop		= httpget			("subop");
	$cookturn	= get_module_pref	("pcookieturn");
	$cdiebase	= get_module_pref	("pcookiedie");
	$cookdie		= e_rand				(1, $cdiebase);

	if ($op == "snack") {
		page_header ();
		output ("`^`b`cSizzle, fry, bake 'n' shake!`b");
		output ("`c");
		output ("`n");
		output ("`7");
		
		if ($subop == "") {
			output ("You cast your gaze around the Kitchen and prepare to rustle up some grub.");
			output ("You could make everything from a sandwich to a real meal.  Question is ...");
			output ("what to make?");
			output ("`n`n");
			addnav ("Sandwich", "runmodule.php?module=housekitchen&op=snack&subop=sandwich");
			addnav ("Brunch", "runmodule.php?module=housekitchen&op=snack&subop=brunch");
			addnav ("Dinner", "runmodule.php?module=housekitchen&op=snack&subop=dinner");
		}
		
		if ($subop == "sandwich") {
			output ("You spend a little while slapping together a masterwork of a sandwich.");
			output ("A triple-decker with ingrediants set to counterbalance each other.");
			output ("All towards a sublime taste capturing the true art of the sandwich.");
			output ("`n`n");
			set_module_pref ('hunger', get_module_pref('hunger', 'usechow') - 20, 'usechow');
			set_module_pref ('bladder', get_module_pref('bladder', 'bladder') + 2, 'bladder');
			$session['user']['turns']--;
			output ("`&");
			output ("`cYou feel slightly less hungry.");
			output ("`n`n");
			output ("The time involved making a sandwich however cost you a Forest Fight!`c");
			output ("`n`n");
		}
			
		if ($subop == "brunch") {
			output ("You gather together various things from around the Kitchen.");
			output ("You crack some eggs into a pan and start frying them up along with some bacon.");
			output ("You drop a few pieces of toast under the grill and peel a few Oranges.");
			output ("Grabbing a little garnish, you sprinkle it in with the eggs and side the whole");
			output ("thing off with the fruit. Of course, the bread gets serviced with");
			output ("your best butter. By the time you've finished, your mouth is watering.");
			output ("So you waste no time and dig in!");
			output ("`n`n");
			set_module_pref ('hunger', get_module_pref('hunger', 'usechow') - 45, 'usechow');
			set_module_pref ('bladder', get_module_pref('bladder', 'bladder') + 3, 'bladder');
			$session['user']['turns'] = $session['user']['turns'] - 2;
			output ("`&");
			output ("`cYou're less hungry now.");
			output ("`n`n");
			output ("The time involved making brunch however cost you two Forest Fights!`c");
			output ("`n`n");
		}

		if ($subop == "dinner") {
			output ("You set about making dinner, hunting around the cupboards for the things you'll need.");
			output ("Within minutes you have something being refridgerated, numerous pots and pans boiling");
			output ("and a Chicken in the oven. You can smell the sauces boiling and the rice is almost ready.");
			output ("The whole thing comes together as an amazing meal with the side order of trifle you refridgerated.");
			output ("It's too much, your stomach is rumbling! You ravenously Wolf down the huge meal.");
			output ("The lemon sauce on the Chicken is divine and with the egg-fried rice,");
			output ("the flavour is really brought out. What a wonderful meal!");
			set_module_pref ('hunger', 0, 'usechow');
			set_module_pref ('bladder', get_module_pref('bladder', 'bladder') + 5, 'bladder');
			$session['user']['turns'] = $session['user']['turns'] - 4;
			output ("`&");
			output ("`cYou feel totally stuffed!");
			output ("`n`n");
			output ("The time involved making dinner however cost you four Forest Fights!`c");
			output ("`n`n");
		}

		addnav ("Go Back", "runmodule.php?module=house&lo=house&id=".$session['user']['acctid']);
		page_footer ();
	}

	if ($op == "cookie") {
		page_header ();
		output ("`^`b`cSuch a strange cookie ...`b");
		output ("`c");
		output ("`n");
		output ("`7");
		
		if ($subop == "") {
			output ("You wander suspiciously over to the jar");
			output ("and peer inside. The cookies look normal enough.");
			output ("There is a slight glow to them however, if you");
			output ("tip the cookie away from the light, this strange");
			output ("glow becomes quite obvious. The question is ...");
			output ("`n`n");
			output ("Are you daring enough to eat the cookie?");
			output ("`n`n");
			addnav ("Eat the Cookie!", "runmodule.php?module=housekitchen&op=cookie&subop=eatcookie");
			addnav ("Go Back", "runmodule.php?module=house&lo=house&id=".$session['user']['acctid']);
		}
		
		if ($subop == "eatcookie") {
			output ("You eagerly snarf the cookie ...");
			if ($cookdie < 2) {
				output ("and you find yourself choking, your throat closes and cuts off your air.");
				output ("You reach up and with your last act of life, you try to swat the evil jar into oblivion.");
				output ("With your last breaths, you gasp \"...why...\".");
				output ("`n`n");
				output ("Though still, you feel as though this is only half of the scret of the cookies.");
				output ("`n`n");
				output ("`You are dead!");
				$session['user']['hitpoints']=0;
				$session['user']['alive']=0;
				addnav ("Land of the Shades", "shades.php");
			}
			
			else {
				output ("and you feel strangely revitalized! Ready for anything in fact.");
				output ("You could almost run out of the house and do five or ten laps of the nearby");
				output ("Forest. Wow! What was in that cookie?!");
				output ("`n`n");
				output ("`&");
				output ("`c");
				output ("You gain `2%s `&Forest Fights!", $cookturn);
				$session['user']['turns']+=$cookturn;
				addnav ("Go Back", "runmodule.php?module=house&lo=house&id=".$session['user']['acctid']);
			}
		}
		
		page_footer ();
	}
}

?>