A small little add-on to stables.php

Offers more comments when a mount is selected for examine by player.

open stables.php
find:
output("`7\"`&Aye, tha' be a foyne beestie indeed!`7\" comments the dwarf.`n`n");

replace with:

switch(e_rand(1,8)){
          case 1:
                output("Thar be a fine beastie indeed! says the dwarf.`n");
                break;
            case 2:
                output("Ye have an eye for quality! says the dwarf.`n");
                break;           
            case 3:
                output("This beast will serve you well! says the dwarf.`n"); 
                break;
            case 4:
                output("This is one of me finest! says the dwarf.`n"); 
                break;           
            case 5:
                output("A finer choice you could not make! says the dwarf.`n");
                break;
            case 6:
                output("A good selection and a wise choice! says the dwarf.`n");
                break;             
            case 7:
                output("A wise choice, Ye have an eye for good mounts! says the dwarf.`n");
                break;
            case 8:
                output("Thar is one of me best! says the dwarf.`n");
                break;
        } 


//save and upload!