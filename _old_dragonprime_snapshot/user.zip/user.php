<?php

/*
Umsetzung und Idee von Sir Arvex
Erstmalig auf Anagromataf.de erschienen
Anregungen, Bugs und Fehler an arvex@anagromataf.de

	V0.03 - Nutzung auf eigene Gefahr ->>Betastadium<<-
*/

require_once("lib/http.php");

function user_getmoduleinfo() {
	$info = array(
		"name"=>"User",
		"author"=>"`)Arvex",
		"version"=>"0.03",
		"category"=>"Administrative",
		"download"=>"http://www.arvex.de/index.php?showforum=3",
		"settings"=>array(
			"Diverse Usereinstellungen, title",
				"ort"=>"In welcher Stadt wird ein Aktualisieren Link hinzugef�gt?,location|".getsetting("villagename", LOCATION_FIELDS)
				),
		"prefs"=>array(
			"Bestrafungen,title",
			"on"=>"Bestrafungen anschalten,bool|0",
			"txt"=>"Text der gro� angezeigt werden soll?,text|",
			"Tage,title",
			"wrp"=>"Runden des Spielers um X% verringern?,int|0",
			"wrt"=>"Runden des Spielers X Spieltage lang verringern?,int|5",
			"wrc"=>"Dies dauert noch X Spieltage an!,viewonly|",
			"Schattenreich,title",
			"sr"=>"Spieler ins Schattenreich verbannen?,bool|0",
			"srg"=>"Gefallen auf 0 setzen?,bool|0",
			"srr"=>"Runden im Schattenreich auf 0 setzen?,bool|0",
			"srs"=>"Seelenpunkte auf 0 setzen?,bool|0",
			"DonationPoints,title",
			"dp"=>"Dem Spieler X DonationPoints wegnehmen?,int|0",
			"dpall"=>"Dem Spieler ALLE DonationPoints wegnehmen?,bool|0",
			),
		);
       return $info;
}
function user_install() {
		include("modules/arvex/user/user_install.php");
    	return true;
}

function user_uninstall() {
    	return true;
}

function user_dohook($hookname,$args) {
	global $session;
	switch ($hookname){
	case "changesetting":
		include("modules/arvex/user/user_changesetting.php");
		break;
		
	case "newday":
		include("modules/arvex/user/user_newday.php");
		break;
		
         case "shades":
         	include("modules/arvex/user/user_shades.php");
		break;               
                        
	case "village":
		include("modules/arvex/user/user_village.php");
		break;
	}
	return $args;
}

function user_run(){
        }
?>