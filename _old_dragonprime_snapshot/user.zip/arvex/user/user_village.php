<?php
require_once("lib/villagenav.php");
		if ($session['user']['location'] == get_module_setting("ort")){
			tlschema($args['schemas']['infonav']); 
			addnav($args["infonav"]);
			tlschema(); 
			addnav("Q?Aktualisieren", "village.php?refresh=1");
		}
?>