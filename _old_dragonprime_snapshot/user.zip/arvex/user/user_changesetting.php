<?php
if ($args['setting'] == "villagename") {
			if ($args['old'] == get_module_setting("ort")) {
				set_module_setting("ort", $args['new']);
			}
		}
?>