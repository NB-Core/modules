<?php
module_addhook("village");
		module_addhook("changesetting");
		module_addhook("shades");
		module_addhook("newday");
?>