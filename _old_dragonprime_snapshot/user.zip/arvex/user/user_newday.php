<?php
if (get_module_pref('on')==1) {
			$txt = get_module_pref("txt");
			rawoutput("<big>");
                        output("`c`7`b%s`b`c`n`0",$txt);
                        rawoutput("</big>");
                        if (get_module_pref("wrp") > 0 && get_module_pref("wrt") > 0) {
                        	$wrp = round($session['user']['turns']*(get_module_pref("wrp")/100));
                        	$session['user']['turns'] -=$wrp;
                        	$wrt = get_module_pref("wrt");
                        	set_module_pref("wrc", $wrt-1);
                        	set_module_pref("wrt", $wrt-1);
                        	output("`7Du verlierst bei jedem neuen Tag %s Runden!`n",$wrp);
                        	debuglog("verliert durch Bestrafungen $wrp Runden pro Tag");
                        	output("`7Dies dauert noch die n�chsten `$%s`7 Spieltage �ber an, lacht `&Scharf`7rich`)ter `)My`7then`&metz`7.", $wrt);
                        	if (get_module_pref("wrc") == 0) {
                        		output("`7Deine Strafe ist abgelaufen ... !");
                        		set_module_pref("on", 0);
                        	}
                        }
                        if (get_module_pref("sr") == true) {
                        	blocknav("village");
                        	$session['user']['alive']=false;
				output("`&Scharf`7rich`)ter `)My`7then`&metz `7 hat dich in sein Reich verbannt. Willkommen im Reich der Qualen und Schmerzen!");
				debuglog("wurde durch Bestrafungen ins Schattenreich verbannt");
				$session['user']['turns']=0;
				$session['user']['hitpoints']=0;
				addnews("`7%s wurde von `&Scharf`7rich`)ter `)My`7then`&metz `7 ins Schattenreich verbannt.",$session['user']['name']);
				addnav("Optionen");
				addnav("T�gliche News","news.php");
			}	
		}
		if (get_module_pref("dp") != 0) {
			$dp = get_module_pref("dp");
			$session['user']['donation']-=$dp;
			output("`7Dir wurden von `&Scharf`7rich`)ter `)My`7then`&metz `)%s `7DonationPoints wieder aberkannt!`n",$dp);
			debuglog("wurde durch Bestrafungen $dp DonationPoints aberkannt");
			set_module_pref("dp", 0);
		}
		if (get_module_pref("dpall") == true) {
			$dpall = $session['user']['donation'];
			$session['user']['donation']=0;
			output("`7Dir wurden von `&Scharf`7rich`)ter `)My`7then`&metz `)ALLE (%s) `7DonationPoints wieder aberkannt!`n",$dpall);
			debuglog("wurde durch Bestrafungen ALLE ($dpall) DonationPoints aberkannt");
			set_module_pref("dpall", 0);
		}
?>