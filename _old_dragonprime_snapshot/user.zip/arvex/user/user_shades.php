<?php
if (get_module_pref("sr") == true) {
			if (get_module_pref("srr") == true) {
				$session['user']['gravefights']=0;
				output("`n`&Scharf`7rich`)ter `)My`7then`&metz `7hat dir alle Runden genommen.");
				debuglog("wurde durch Bestrafungen alle Grabk�mpfe genommen");
			}
			if (get_module_pref("srg") == true) {
				$session['user']['deathpower']=0;
				output("`n`&Scharf`7rich`)ter `)My`7then`&metz `7hat dir alle Gefallen genommen.");
				debuglog("wurde durch Bestrafungen alle Gefallen genommen");
			}
			if (get_module_pref("srs") == true) {
				$session['user']['soulpoints']=0;
				output("`n`&Scharf`7rich`)ter `)My`7then`&metz `7hat dir alle Seelenpunkte genommen.`n");
				debuglog("wurde durch Bestrafungen alle Seelenpunkte genommen");
			}
		}
?>