<?php
function supersix_getmoduleinfo(){
	$info = array(
		"name"=>"Six's Super Six",
		"version"=>"20050404",
		"author"=>"Sixf00t4",
		"category"=>"Inn",
		"download"=>"http://dragonprime.net/users/sixf00t4/supersix98.zip",
		"vertxtloc"=>"http://dragonprime.net/users/sixf00t4/",
		"settings"=>array(
			"Super Six Settings - Main,title",
			"maxplays"=>"How plays per day? (0 for infinite),int|0",
			"cost"=>"How much gold does it cost?,int|100",
		),
		"prefs"=>array(
			"Super Six preferences - Main,title",
			"totalplays"=>"How plays per day?,int|1",
			"scratch1"=>"First scratch,int|0",
			"scratch2"=>"Second scratch,int|0",
			"scratch3"=>"Third scratch,int|0",
			"scratch4"=>"Fourth scratch,int|0",
			"scratch5"=>"Fifth scratch,int|0",
			"scratch6"=>"Sixth scratch,int|0",
			"scratchwin1"=>"First scratch win?,int|0",
			"scratchwin2"=>"Second scratch win?,int|0",
			"scratchwin3"=>"Third scratch win?,int|0",
			"scratchwin4"=>"Fourth scratch win?,int|0",
			"scratchwin5"=>"Fifth scratch win?,int|0",
			"scratchwin6"=>"Sixth scratch win?,int|0",
		),
	);	
	return $info;
}

function supersix_install(){
	if (!is_module_active('supersix')){
		output("`4Installing Super Six Module.`n");
	}else{
		output("`4Updating Supersix Module.`n");
	}
	module_addhook("Inn");
	module_addhook("newday");
	return true;
}

function supersix_uninstall(){
	output("`4Un-Installing Super Six Module.`n");
	return true;
}

function supersix_dohook($hookname,$args){
	global $session;
	switch($hookname){
	case "inn":
		addnav("Play Six's Super Six","runmodule.php?module=supersix");
	break;
	case "newday":
		set_module_pref("totalplays",0,"supersix");
	break;
	}
return $args;  
}

function supersix_run(){
global $session;
$op = httpget('op');
page_header("Six's Super Six");
if ($op==""){
if( ((get_module_setting("maxplays")) > 0) && ((get_module_pref("totalplays")) >= (get_module_setting("maxplays")))){
output("Seeing that you have some sort of lottery addiction, Cedrick refers you to gambler's anonymous and tells you to come back tomorrow");  
addnav("Back to the Inn","inn.php");
}else{
addnav("Try It Out?");
addnav("Yes","runmodule.php?module=supersix&op=yes");
addnav("No","runmodule.php?module=supersix&op=no");
output("You see Cedrik just got the new scratch off gamecards in for `^Six's Super Six�.`n`n");
}
}

if ($op=="no"){
page_header("Six's Super Six");
addnav("Back to the Inn","inn.php");
output("`@`cYou trudge home, unaware of what you've missed.`@`c`n`n");

}

if ($op=="yes"){
if($session['user']['gold']<(get_module_setting("cost"))){
addnav("Back to the Inn","inn.php");
output("`@`cHowever, you don't seem to have the kind of money you need for a card.`@`c`n`n");
output("`c`^`bIt costs ". (get_module_setting("cost")) ."Gold To play`c`b`^");
	}else{
addnav("Take the card","runmodule.php?module=supersix&op=scratch");
output("`b`n`n`c`bSix's Super Six`b`c`n`n");
output("You ask Cedrik for a scratch-off card.  He reaches under the counter and pulls out a sheet of scratch-off games, and tears you off one.`n`n");
output("`@`cYou give him the ". (get_module_setting("cost")) ." gold and read the directions.`n`n");
output("`#Just scratch off the hidden numbers, and see if the match up with the printed numbers on the card.`n");
output(" If you match one or more numbers, you will win some gold!`@`c");
$session['user']['gold']-=(get_module_setting("cost"));

}
}

if ($op=="scratch"){
addnav("Scratch away","runmodule.php?module=supersix&op=match");
output("`@Here are the numbers you are trying to match.`@`n`n");
set_module_pref("scratch1",(e_rand(1,6)),"supersix");
set_module_pref("scratch2",(e_rand(1,6)),"supersix");
set_module_pref("scratch3",(e_rand(1,6)),"supersix");
set_module_pref("scratch4",(e_rand(1,6)),"supersix");
set_module_pref("scratch5",(e_rand(1,6)),"supersix");
set_module_pref("scratch6",(e_rand(1,6)),"supersix");


output("`@Your First Number: %s`n",get_module_pref(scratch1));
output("Your Second Number: %s`n",get_module_pref(scratch2));
output("Your Third Number: %s`n",get_module_pref(scratch3));
output("Your Fourth Number: %s`n",get_module_pref(scratch4));
output("Your Fifth Number: %s`n",get_module_pref(scratch5));
output("Your Sixth Number: %s`n`n",get_module_pref(scratch6));
}


if ($op=="match"){
output("`@Your First Number: %s`n",get_module_pref(scratch1));
output("Your Second Number: %s`n",get_module_pref(scratch2));
output("Your Third Number: %s`n",get_module_pref(scratch3));
output("Your Fourth Number: %s`n",get_module_pref(scratch4));
output("Your Fifth Number: %s`n",get_module_pref(scratch5));
output("Your Sixth Number: %s`n`n",get_module_pref(scratch6));

set_module_pref("scratchwin1",(e_rand(1,6)),"supersix");
set_module_pref("scratchwin2",(e_rand(1,6)),"supersix");
set_module_pref("scratchwin3",(e_rand(1,6)),"supersix");
set_module_pref("scratchwin4",(e_rand(1,6)),"supersix");
set_module_pref("scratchwin5",(e_rand(1,6)),"supersix");
set_module_pref("scratchwin6",(e_rand(1,6)),"supersix");

output("`@You pull out a coin and scratch the card to reveal the numbers.`@`n`n");
output("`@First Number: %s`n",get_module_pref(scratchwin1));
output("Second Number: %s`n",get_module_pref(scratchwin2));
output("Third Number: %s`n",get_module_pref(scratchwin3));
output("Fourth Number: %s`n",get_module_pref(scratchwin4));
output("Fifth Number: %s`n",get_module_pref(scratchwin5));
output("Sixth Number: %s`n`n",get_module_pref(scratchwin6));

if((get_module_pref(scratchwin1))==(get_module_pref(scratch1))){
output("`^`bYour First Number is a perfect match!`^`b`n`n");
$scratchmatches+=1;
}
if((get_module_pref(scratchwin2))==(get_module_pref(scratch2))){
output("`^`bYour Second Number is a perfect match!`^`b`n`n");
$scratchmatches+=1;
}
if((get_module_pref(scratchwin3))==(get_module_pref(scratch3))){
output("`^`bYour Third Number is a perfect match!`^`b`n`n");
$scratchmatches+=1;
}
if((get_module_pref(scratchwin4))==(get_module_pref(scratch4))){
output("`^`bYour Fourth Number is a perfect match!`^`b`n`n");
$scratchmatches+=1;
}
if((get_module_pref(scratchwin5))==(get_module_pref(scratch5))){
output("`^`bYour Fifth Number is a perfect match!`^`b`n`n");
$scratchmatches+=1;
}
if((get_module_pref(scratchwin6))==(get_module_pref(scratch6))){
output("`^`bYour Sixth Number is a perfect match!`^`b`n`n");
$scratchmatches+=1;
}
if($scratchmatches==0){output("`^`bNone of your numbers matched!`^`b`n`n");
addnav("Back to inn","inn.php");
}
if($scratchmatches>0){
addnav("Collect winnings","runmodule.php?module=supersix&op=win&matches=$scratchmatches");}
}

if ($op=="win"){
$matches=httpget('matches');
addnav("Return To inn","inn.php");
if($matches==0){
output("`@`cBlasted! you didn't win anything.  You crumble up the card and throw it away.`@`c`n`n");
output("`^`cSorry You Didn't Win!`^`c");
	}else{
if($matches==1){
output("`^`cYou matched 1 number! You turn your card back into Cedrik for ". (get_module_setting("cost"))*.5 ." Gold!`^`c");
$session['user']['gold']+=(get_module_setting("cost"))*.5;
	}else{
if($matches==2){
output("`^`cYou matched 2 numbers!  You turn your card back into Cedrik for ". (get_module_setting("cost")) ." Gold!`^`c");
$session['user']['gold']+=(get_module_setting("cost"));
	}else{
if($matches==3){
output("`^`cYou matched 3 numbers! You turn your card back into Cedrik for ". (get_module_setting("cost"))*3 ." Gold!`^`c");
$session['user']['gold']+=(get_module_setting("cost"))*3;
	}else{
if($matches==4){
output("`^`cYou matched 4 numbers! You turn your card back into Cedrik for ". (get_module_setting("cost"))*5 ." Gold!`^`c");
$session['user']['gold']+=(get_module_setting("cost"))*5;
	}else{
if($matches==5){
output("`^`cYou matched 5 numbers! You turn your card back into Cedrik for ". (get_module_setting("cost"))*10 ." Gold!`^`c");
$session['user']['gold']+=(get_module_setting("cost"))*10;
	}else{
if($matches==6){
output("`^`cYou HIT THE JACKPOT! You turn your card back into Cedrik for ". (get_module_setting("cost"))*50 ." Gold!`^`c");
$session['user']['gold']+=(get_module_setting("cost"))*50;
}
}
}
}
}
}
}
}

page_footer();
}
?>