<?php
function advertisingtracker_getmoduleinfo(){
	$info = array(
		"name"=>"Advertising Tracker (inGame)",
		"version"=>"1.0",
		"author"=>"`2Oliver Brendel",
		"category"=>"Administrative",
		"download"=>"",
		"settings"=>array(
					"Ad Tracker - Preferences, title",
					"who"=>"Enter here seperated by comma the acctid of the admins who should be excluded (secure mail), text|1,7",
					),
	);
	return $info;
}

function advertisingtracker_install(){
	module_addhook("superuser");
	return true;
}

function advertisingtracker_uninstall(){
	return true;
}

function advertisingtracker_dohook($hookname,$args){
	global $session;
	switch ($hookname) {
	case "superuser":
		if (($session['user']['superuser'] & SU_EDIT_COMMENTS)== SU_EDIT_COMMENTS) {
			addnav("Mechanics");
			addnav("Advertising Tracker","runmodule.php?module=advertisingtracker&op=commentary");
		}

	break;
	}
	return $args;
}

function advertisingtracker_run(){
	global $session;
	$op=httpget('op');
	require_once("lib/superusernav.php");
	superusernav();
	page_header("Advertising Tracker");
	if (($session['user']['superuser'] & SU_EDIT_USERS)== SU_EDIT_USERS) {
		addnav("Mechanics");
		addnav("Commentary Tracker","runmodule.php?module=advertisingtracker&op=commentary");
		addnav("Mail Tracker","runmodule.php?module=advertisingtracker&op=mail");
		addnav("Mail Tracker (<50 chars)","runmodule.php?module=advertisingtracker&op=mail&length=50");
		addnav("Mail Tracker (<100 chars)","runmodule.php?module=advertisingtracker&op=mail&length=100");
		addnav("Mail Tracker (<150 chars)","runmodule.php?module=advertisingtracker&op=mail&length=150");
		addnav("Mail Tracker (<200 chars)","runmodule.php?module=advertisingtracker&op=mail&length=200");
		addnav("Mail Tracker (<250 chars)","runmodule.php?module=advertisingtracker&op=mail&length=250");
		addnav("Mail Tracker (Lotgd)","runmodule.php?module=advertisingtracker&op=mail&track=lotgd");
		addnav("Mail Tracker (Logd)","runmodule.php?module=advertisingtracker&op=mail&track=logd");
		addnav("Searches");
		addnav("Search Comments for User","runmodule.php?module=advertisingtracker&op=presearch&track=user");
		addnav("Search Comments by String","runmodule.php?module=advertisingtracker&op=presearch&track=string");
	}
	switch ($op) {
		case "mail":
			$track=httpget('track');
			$length=httpget('length');
			addnav("Actions");
			addnav("Refresh","runmodule.php?module=advertisingtracker&op=mail&track=$track");
			$ac=db_prefix("accounts");
			$mail=db_prefix("mail");
			if (get_module_setting('who')!='') {
				$cond=" AND $mail.msgfrom NOT IN (".get_module_setting('who').") ";
				$cond.=" AND $mail.msgto NOT IN (".get_module_setting('who').") ";
			} else $cond='';
			if ($track!='') $cond.=" AND body LIKE '%$track%'";
			if ($length!='') $cond.= " AND LENGTH(body)<=$length";
			$sql="SELECT $ac.name AS name,$mail.body AS body,$mail.sent AS date FROM $mail INNER JOIN $ac ON $mail.msgfrom=$ac.acctid WHERE (body like '%http://%' OR body like '%www.%' OR body like '%.com%') $cond ORDER BY $mail.messageid DESC LIMIT 200"; //acctid 7 = neji
			$result = db_query ($sql);
			$date=translate_inline("Postdate");
			$author=translate_inline("Author");
			$body=translate_inline("Message");
			rawoutput("<table border=0 cellpadding=2 cellspacing=1 bgcolor='#999999' align=center>");
			rawoutput("<tr class='trhead' height=30px><td><b>$date</b></td><td><b>$author</b></td><td><b>$body</b></td></tr>");
			$class="trlight";
			$col="`&"; //not used
			output("Since bans here should be done either permanently or people normally only warned, no ban options are offered here`n`n");
			while ($row=db_fetch_assoc($result)) {
				$class=($class=='trlight'?'trdark':'trlight');
				rawoutput("<tr height=30px class='$class'>");
				rawoutput("<td>");
				output_notl($row['date']);
				rawoutput("</td><td>");
				output_notl($row['name']);
				rawoutput("</td><td>");
				output_notl($row['body']);
				rawoutput("</td></tr>");

			}
			rawoutput("</table>");
			break;
		case "commentary":
			addnav("Actions");
			addnav("Refresh","runmodule.php?module=advertisingtracker&op=commentary");
			$ac=db_prefix("accounts");
			$cm=db_prefix("commentary");
			$sql="SELECT $ac.name AS name,$cm.section AS section, $cm.postdate AS postdate, $cm.comment AS comment FROM $cm INNER JOIN $ac ON $cm.author=$ac.acctid WHERE comment like '%http://%' OR comment like '%www.%'  OR comment like '%.com%' ORDER BY $cm.commentid DESC LIMIT 50";
			$result = db_query ($sql);
			$date=translate_inline("Postdate");
			$author=translate_inline("Author");
			$section=translate_inline("Section");
			$comment=translate_inline("Comment");
			rawoutput("<table border=0 cellpadding=2 cellspacing=1 bgcolor='#999999' align=center>");
			rawoutput("<tr class='trhead' height=30px><td><b>$date</b></td><td><b>$author</b></td><td><b>$section</b></td><td><b>$comment</b></td></tr>");
			$class="trlight";
			$col="`&";
			output("Since bans here should be done either permanently or people normally only warned, no ban options are offered here`n`n");
			while ($row=db_fetch_assoc($result)) {
				$class=($class=='trlight'?'trdark':'trlight');
				rawoutput("<tr height=30px class='$class'>");
				rawoutput("<td>");
				output_notl($row['postdate']);
				rawoutput("</td><td>");
				output_notl($row['name']);
				rawoutput("</td><td>");
				output_notl($row['section']);
				rawoutput("</td><td>");
				output_notl($row['comment']);
				rawoutput("</td></tr>");

			}
			rawoutput("</table>");
			break;
		case "presearch":
			$track=httpget('track');
			output("`2Remember to use % as placeholders for any amount of symbols! Else it gets exact matches!`n`n");
			output("`2Please enter what you look for:`n`n");
			rawoutput("<form action='runmodule.php?module=advertisingtracker&op=search&track=$track' method='post'>");
			addnav("","runmodule.php?module=advertisingtracker&op=search&track=$track");
			switch($track) {
				case "user":
					output("Loginname:`n");
					break;
				case "string":
					output("Commentcontent:`n");
					break;
			}
			rawoutput("<input type='input' name='target'>");
			output("`n`nHow many results (limit clause):`n");
			rawoutput("<input type='input' name='limit' value='50'>");
			output("`n`nIn what commentary section (if left empty, all will be displayed):`n");
			rawoutput("<input type='input' name='section'>");
			rawoutput("<br><br><input type='submit'>");
			rawoutput("</form>");
			break;
		case "search":
			$track=httpget('track');
			$target=httppost('target');
			$limit=httppost('limit');
			$section=httppost('section');
			$ac=db_prefix("accounts");
			$cm=db_prefix("commentary");
			if ($section=='') $searchsection='';
				else $searchsection="AND $cm.section LIKE '$section'";
			if ($limit=='') $limit=50;
			addnav("Actions");
			addnav("Clear Mask","runmodule.php?module=advertisingtracker&op=search&track=$track&target=$target");
			switch ($track) {
				case "user":
					$sql="SELECT $ac.name AS name,$cm.section AS section, $cm.postdate AS postdate, $cm.comment AS comment FROM $cm INNER JOIN $ac ON $cm.author=$ac.acctid WHERE $ac.login like '$target' $searchsection ORDER BY $cm.commentid DESC LIMIT $limit";
					break;
				case "string":
					$sql="SELECT $ac.name AS name,$cm.section AS section, $cm.postdate AS postdate, $cm.comment AS comment FROM $cm INNER JOIN $ac ON $cm.author=$ac.acctid WHERE $cm.body like '$search' $searchsection ORDER BY $cm.commentid DESC LIMIT $limit";
					break;
			}

			$result = db_query ($sql);
			$date=translate_inline("Postdate");
			$author=translate_inline("Author");
			$section=translate_inline("Section");
			$comment=translate_inline("Comment");
			rawoutput("<table border=0 cellpadding=2 cellspacing=1 bgcolor='#999999' align=center>");
			rawoutput("<tr class='trhead' height=30px><td><b>$date</b></td><td><b>$author</b></td><td><b>$section</b></td><td><b>$comment</b></td></tr>");
			$class="trlight";
			$col="`&";
			output("Since bans here should be done either permanently or people normally only warned, no ban options are offered here`n`n");
			while ($row=db_fetch_assoc($result)) {
				$class=($class=='trlight'?'trdark':'trlight');
				rawoutput("<tr height=30px class='$class'>");
				rawoutput("<td>");
				output_notl($row['postdate']);
				rawoutput("</td><td>");
				output_notl($row['name']);
				rawoutput("</td><td>");
				output_notl($row['section']);
				rawoutput("</td><td>");
				output_notl($row['comment']);
				rawoutput("</td></tr>");

			}
			rawoutput("</table>");
		default:
	}
	page_footer();
}


?>
