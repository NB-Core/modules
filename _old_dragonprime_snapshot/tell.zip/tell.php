<?php
/*

Modul: tell.php

Aufgefriemelt von der ollen Helpdeskschlampe Landfloh. 

Version-Infos:
 	V0.1 - Erster Versuchsballon
 	V0.2 - Korrigierte Version, Gold sollte nicht mehr auf null gesetzt werden.
 		   >if Schleife um ein "=" erg�nzt, mit 1 "=" w�re es eine zuweisung, weshalb Gold auf 0 gesetzt wurde.
 		   >zuweisung "+=" bei Goldverteilung ge�ndert auf $session['user']['gold']=$session + round($session['user']['level']*30
 		   >Zeilenumbr�che nach event eingef�hrt. Darstellung sollte jetzt korrekt sein.
 	V1.0 - Bugs sind beseitigt. 
 	
 		   
In hingebungsvoller Andacht, f�r's Schweizervolke :-))
 	
 	*/


function tell_getmoduleinfo(){
	$info = array(
		"name"=>"Mieser kleiner Heckensch�tze",
		"author"=>"`)Landfloh",
		"version"=>"1.0",
		"category"=>"Forest Specials",
		"download"=>"hier gibts nix zu downloaden",
	);
	return $info;
}

function tell_install(){
	module_addeventhook("forest", "return 100;");
	return true;
}
function tell_uninstall(){
	return true;
}

function tell_runevent($type){
	global $session;
	require_once("lib/http.php");
	require_once('lib/e_rand.php');
	$op = httpget('op');

	$session['user']['specialinc'] = "module:tell";
	$from = "forest.php?";

	page_header("Mieser kleiner Heckensch�tze");

	switch ($op) {
		case "":
		output("<embed src=\"media/win.mid\" width=10 height=10 autostart=true loop=false hidden=true volume=100>",true);
		output("`cMieser kleiner Heckensch�tze`c`n`n");
		output("`#Du spazierst so gem�tlich durch den Wald, denkst nichts b�seres als du sonst tust, 
		und f�hlst dich richtig wohl, so inmitten dieser abartigen Kreaturen, die dir ab und zu �ber'n Weg laufen.");
		output("Du siehst eine kleine hohle Gasse, mit Vertiefungen auf der Seite, die wohl von Karrenr�dern stammen m�ssen.`n");
		output("Irgendwie erinnert dich das an eine Geschichte.... aber sie f�llt dir leider nicht ein. Doch deine Neugier
		ist geweckt.");
		output("Einerseits h�ttest du jetzt noch Bock auf ein paar Gegner, um diese niederzumetzeln, andererseits... 
		diese verdammte Gasse l�sst dich nicht los, irgendwie muss das untersucht werden...`n`n");
		output("`&`nWillst durch die hohle Gasse gehen oder weiter nach Kreaturen Ausschau halten?");
		addnav("Hohle Gasse");

		addnav("Au ja!", $from."op=gasse");
		addnav("Och n���...", $from."op=nichts");
		break;
	}
	
	
	
	if ($op=="gasse"){
		switch(e_rand(1,10)){
			case 1:
			case 2: 
        	case 3:
        	case 4:
        	case 5:
			output("`c`b`#Durch diese hohle Gasse wirst du gehen...`b`c`n`n");
			output("`@`n`nDie Neugier ist st�rker, und du befindest dich schon auf halbem Wege durch die hohle Gasse.`n
			Die V�gel zwitschern, vertraute Waldger�usche lassen dich abschweifen, in vergangenen Tagen schwelgen. ");
			output("`n`nPl�tzlich bemerkst du ein Ger�usch. Es h�rt sich wie ein Flirren an, da muss irgendwoher etwas schnelles 
			unterwegs sein.`n");
			output("Du sp�rst einen Schmerz in der Bauchgegend. Wie du herunterschaust, steckt da ein kleiner Pfeil einer Armbrust.`n
			Im Geb�sche raschelt's ein bl�des Gekicher ist zu h�ren, und eilige Schritte entfernen sich.`n`n");
			output("`n`nDu machst dir gar keine M�he, diesen miesen Heckensch�tzen zu verfolgen, 
			`n es ist klar wer das war: Der kleine, unterbelichtete Wilhelm Tell, der seit seiner Begegnung mit einem gewissen Gessler
			`ndie W�lder unsicher macht. Scheinbar ist er irgendwie h�ngen geblieben der arme...`n`n");
			
			//Falls Spieler nur noch 1 Lebenspunkt hat (also fast tot ist)
			
			if ($session['user']['hitpoints']==1) {
				output("`6Die Wunde brennt. Doch hat er dich nicht wirklich tief erwischt, gottseidank. Du gehst zur�ck in den 
				dir bekannten Wald. Den Tell wirst du irgendwann mal dann zur Rede stellen.. oder gleich die Schlucht hinunter werfen.`n`n`n");
				$session['user']['hitpoints']=1;
				$session['user']['specialinc']="";
			}
			
			
			//Falls spieler mehr als 1 Lebenspunkt hat.(also noch welche verlieren kann);-))
			
			else {
			output("`2Der Pfeil trifft dich mitten in die Brust. Blut spritzt aus der Wunde, wie du den Pfeil rausziehst, und es tut h�llisch weh.`n");
			output("`nDer Schmerz ist fast unertr�glich... du `4verlierst `2fast alle Lebenspunkte.`n`n`n");
			$session['user']['hitpoints']=1;
			$session['user']['specialinc']="";
			}
			
			break;
			case 6:
			case 7:
			case 8:
			case 9:
			output("`c`b`#Du gehst durch die hohle Gasse`b`c`n`n");
			output("`@Gegner scheinen hier keine zu sein. Aber da war mal ein Kampf. Zumindest findest du einen abgebrochenen,
			blutverschmierten Pfeil am Boden, es ist ein Pfeil einer Armbrust, wie ihn Wilhelm Tell verwendet, wenn er wieder mal");
			output(" feige hinter einem Geb�sch lauert, bis sich ein geeignetes Opfer findet, f�r einen Heckenschuss.`n`n");
			
			//Falls Spieler kein Gold hat
			if ($session['user']['gold']==0) {
				output("`2Tell war sogar zu bl�de, den Goldbeutel zu entdecken, den sein Opfer fallen lassen hat. Du 
				findest ganze `4%s `2Goldst�ckchen.`n`n`n",round($session['user']['level']*30));
				$session['user']['gold']= $session['user']['gold']+round($session['user']['level']*30);
				$session['user']['specialinc']="";
			}
			
			//Falls Spieler Gold hat
			else {
			output("`2Tell war sogar zu bl�de, den Goldbeutel zu entdecken, den sein Opfer fallen lassen hat. Du
			findest `4%s `2Goldst�ckchen.`n`n`n",round($session['user']['gold']*0.15));
			$session['user']['gold']=$session['user']['gold']+round($session['user']['gold']*1.15);
			$session['user']['specialinc']="";
			}
			break;
			case 10:
			output("`c`b`#Du gehst durch die Gasse`b`c`n`n");
			output("`@Hier scheint lange niemand mehr gewesen zu sein, fr�her war das ein wichtiger Handelsweg. Vor dir am Boden
			siehst du etwas zwischen den Bl�ttern hervorglitzern.`n`n");
			output("`2Du findest `4einen `2Edelstein.`n`n`n");
			$session['user']['gems']++;
			$session['user']['specialinc']="";
			break;
			}
		}
	if ($op=="nichts"){
		output("`n`&Du hast jetzt echt keinen Bock darauf, irgendwelche hohlen Gassen zu untersuchen, ausserdem k�nnte dort
		der durchgeknallte Wilhelm Tell auflauern. Dir ist, als habe sowas letzthin jemand erz�hlt, und du machst dich vom Acker.`n`n`n");
		$session['user']['specialinc']="";
	}
	return $args;
}
	
function tell_run(){
}

?>
