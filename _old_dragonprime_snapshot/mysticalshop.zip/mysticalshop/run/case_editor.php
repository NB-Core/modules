<?php
	$id = httpget('id');
	$cat = httpget('cat');
	$itemarray = array(
		"Item Properties,title",
			"id"=>"Item ID,hidden",
			"category"=>"Item Category,enum,0,Ring,1,Amulet,2,Weapon,3,Armor,4,Cloak,5,Helmet,6,Gloves,7,Boots,8,Miscellaneous",
			"name"=>"Item Name,Name|",
			"description"=>"Short Description,Desc|",
			"gold"=>"Item Cost in Gold,int|0",
			"gems"=>"Item Cost in Gems,int|0",
			"dk"=>"Dragon Kills Needed to Own,int|0",
		"Item Stats,title",	
			"Values can be positive or negative; 1 or -1 for example. Only numeric values are accepted.,note",
			"Use this feature with caution.,note",
			"attack"=>"Bonus/Penalty to Attack,int|0",
			"defense"=>"Bonus/Penalty to Defense,int|0",
			"charm"=>"Bonus/Penalty to Charm,int|0",
			"hitpoints"=>"Bonus/Penalty to Hitpoints,int|0",
			"turns"=>"Bonus/Penalty to Turns,int|0",
			"favor"=>"Bonus/Penalty to Favor,int|0",
		"Verbose Description,title",
			"Add a longer description here for when examining the item in the shop. You may you use formating and line breaks and color codes as well. This part is optional.,note",
			"bigdesc"=>",textarea",	
		"Rare Item Stats,title",
			"This part is optional and will allow you to sell a limited number of items.,note",	
			"rare"=>"Is this item Rare or Limited?,enum,0,No,1,Yes",
			"rarenum"=>"How Many of These Items are There for Sale?,int|0",
	);
	require_once("modules/mysticalshop/run/editor_what/$what.php");
	//here's a module hook, if anyone ever needs it
	modulehook("mysticalshop-editor", array());
    addnav("Functions");
    //let's just display items that are actually available.
	$sql = "SELECT * FROM ".db_prefix("magicitems")." ORDER BY category";
	$result = db_query_cached($sql,"module-mysticalshop-selectall-ordercat");
	$category = "";
	while($row = db_fetch_assoc($result)){
		if ($category!=$row['category']){
			addnav(array("Examine %s`0", $names[$row['category']]),$from."op=editor&what=view&cat={$row['category']}");
			$category = $row['category'];
		}
	}
	addnav("Admin Tools");
	addnav("Add an Item", $from."op=editor&what=add&cat=0");
	addnav("Refresh List", $from."op=editor&what=view&cat=$cat");
	addnav("Other");
	addnav("Return to the Grotto", "superuser.php");
?>