<?php
	$giftid = get_module_pref("giftid");
	$cat = get_module_pref("giftcat");
	$sql = "SELECT * FROM " . db_prefix("magicitems") . " WHERE id='$giftid'";
	$result = db_query($sql);
	$row = db_fetch_assoc($result);
	$gift = $row['name'];
	$verbose = $row['bigdesc'];
	output("`2%s `2 sets out the `^%s `2for you to see.`n`n", $shopkeep, $gift);
	output("`2Viewing the %s.`n`n", $row['name']);
	//display that nice big description you typed out here
	if ($verbose>""){
		output("`3%s`n`n",$row['bigdesc']);
	//otherwise, let's display a default one in it's place
	}else{
		output("`3No extended description for this item is available.`n`n");
	}
	if (get_module_setting("showstats")){
		if ($row['attack']<>0) { 
			output("`&This item's enchantments will alter your attack by `^%s `&points.`n",$row['attack']);
		}
		if ($row['defense']<>0) {
			output("`&This item's enchantments will alter your defense by `^%s `&points.`n",$row['defense']);
		}
		if ($row['charm']<>0) {
			output("`&This item's enchantments will alter your charm by `^%s `&points.`n",$row['charm']);
		}
		if ($row['hitpoints']<>0) {
			output("`&This item's enchantments will alter your maximum hitpoints by `^%s `&points.`n",$row['hitpoints']);
		}
		if ($row['turns']<>0) {
			output("`&This item's enchantments will grant `^%s `&extra turns.`n",$row['turns']);
		}
		if ($row['favor']<>0) {
			output("`&This item's enchantments will alter your favor with Ramius by `^%s `&points.`n",$row['favor']);
		}
	}
	addnav("Keep It", $from."op=gift&what=pickup");
	addnav("Decline", $from."op=gift&what=decline");
?>