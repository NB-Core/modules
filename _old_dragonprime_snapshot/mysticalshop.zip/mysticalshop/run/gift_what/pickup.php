<?php
	$giftid = get_module_pref("giftid");
	$cat = get_module_pref("giftcat");
	$sql = "SELECT * FROM " . db_prefix("magicitems") . " WHERE id='$giftid'";
	$result = db_query($sql);
	$row = db_fetch_assoc($result);
	output("`2%s compliments you on your gift.`n`n", $shopkeep,$what);
	output("`2\"It suits you quite well, %s`2. Do enjoy it\", %s `2says.`n`n", $session['user']['login'],$shopkeep);
	//First, let's determine just what the item is, and record it thusly
	if ($cat == 0){
		set_module_pref("ringid",$giftid);
		set_module_pref("ring",1);
		set_module_pref("ringname",$row['name']);
	}else if ($cat == 1){
		set_module_pref("amuletid",$giftid);
		set_module_pref("amulet",1);
		set_module_pref("amuletname",$row['name']);
	}else if ($cat == 2){
		$value = $row['gold'];
		if ($session['user']['weapon']!="Fists"){
		$session['user']['attack']-=$session['user']['weapondmg'];
		}				
		$session['user']['weapon'] = $row['name'];
		$session['user']['weaponvalue'] = $value;
		$session['user']['weapondmg']=$session['user']['level'];
		$session['user']['attack']+=$session['user']['weapondmg'];
		//
		set_module_pref("weaponid",$giftid);
		set_module_pref("weapon",1);
		set_module_pref("weaponname",$row['name']);
	}else if ($cat == 3){
		//for the sake of compatibility with the armor shop
		$value = $row['gold'];				
		set_module_pref("armorid",$giftid);
		set_module_pref("armor",1);
		set_module_pref("armorname",$row['name']);
		//magical armor, adjusts as you level
		if ($session['user']['armor']!="T-Shirt"){
			$session['user']['defense']-=$session['user']['armordef'];
		}
		$session['user']['armor'] = $row['name'];
		$session['user']['armorvalue'] = $value;
		$session['user']['armordef'] = $session['user']['level'];
		$session['user']['defense']+=$session['user']['level'];
	}else if ($cat == 4){
		set_module_pref("cloakid",$giftid);
		set_module_pref("cloak",1);
		set_module_pref("cloakname",$row['name']);
	}else if ($cat == 5){
		set_module_pref("helmid",$giftid);
		set_module_pref("helm",1);
		set_module_pref("helmname",$row['name']);
	}else if ($cat == 6){
		set_module_pref("gloveid",$giftid);
		set_module_pref("glove",1);
		set_module_pref("glovename",$row['name']);
	}else if ($cat == 7){
		set_module_pref("bootid",$giftid);
		set_module_pref("boots",1);
		set_module_pref("bootname",$row['name']);
	}else if ($cat == 8){
		set_module_pref("miscid",$giftid);
		set_module_pref("misc",1);
		set_module_pref("miscname",$row['name']);
	}	
	if ($row['attack']<>0) { 
		$session['user']['attack']+=$row['attack'];
		output("`&This item's enchantments have altered your attack by `^%s `&points.`n",$row['attack']);
	}
	if ($row['defense']<>0) { 
		$session['user']['defense']+=$row['defense'];
		output("`&This item's enchantments have altered your defense by `^%s `&points.`n",$row['defense']);
	}
	if ($row['charm']<>0) {			
		$session['user']['charm']=$session['user']['charm']+$row['charm'];
		output("`&This item's enchantments have altered your charm by `^%s `&points.`n",$row['charm']);
	}
	if ($row['hitpoints']<>0) {
		$session['user']['maxhitpoints']+=$row['hitpoints'];
		//adjust to fit
		$session['user']['hitpoints']=$session['user']['maxhitpoints'];
		output("`&This item's enchantments have altered your maximum hitpoints by `^%s `&points.`n",$row['hitpoints']);
	}
	//this needs to be adjusted at newday as well.
	if ($row['turns']<>0) {
		$session['user']['turns']+=$row['turns'];
		output("`&This item's enchantments have altered your turns by `^%s `&points.`n",$row['turns']);
		set_module_pref("turnadd",get_module_pref("turnadd")+$row['turns']);
	}	
	//items that grant favor are a little trickier, since they have to be restored upon each resurrection
	//So, extra additions are needed. See newday above to see how this is done.
	if ($row['favor']<>0) {
		//grant one-time automatic favor
		$session['user']['deathpower']+=$row['favor'];
		//store favor granted to be restored upon resurrection
		set_module_pref("res",$session['user']['resurrections']);
		set_module_pref("favor",1);
		set_module_pref("favoradd",get_module_pref("favoradd")+$row['favor']);
		output("`&This item's enchantments have altered your favor with Ramius by `^%s `&points.`n",$row['favor']);
	}
	//It's done!
	modulehook("mysticalshop-gift", array());
	set_module_pref("gifted",0);
?>