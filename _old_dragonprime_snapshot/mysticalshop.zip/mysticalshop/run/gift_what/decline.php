<?php
	output("`2After deciding you don't wish to keep the gift, %s `2nods and sets it behind the counter.`n`n", $shopkeep);
	output("`2\"A pity, it's such a handsome item...\" %s `2says.", $shopkeep);
	set_module_pref("gifted",0);
?>