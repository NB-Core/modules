<?php
	$id = httpget('id');
	$sql = "SELECT * FROM " . db_prefix("magicitems") . " WHERE id='$id'";
	$result = db_query($sql);
	$row = db_fetch_assoc($result);
	$dk = $row['dk'];
	$itemid = $row['id'];
	$disnum = get_module_setting("discountnum");
	if ($disnum == 0) $disnum = 1;
	//set_module_pref("giftid", $id);
	//run some checks first to see if the player can afford the item in question
	output("`2The cost of the `3%s `2is `^%s gold `2and `%%s gems`2.`n`n" ,$row['name'],$row['gold'],$row['gems']);
	if (get_module_setting("discount")){
		$row['gold'] = ceil($row['gold']*(1 - ($session['user']['charm']/$disnum)));
		$row['gems'] = ceil($row['gems']*(1 - ($session['user']['charm']/$disnum)));
		output("`&However, after some haggling, you convince %s to lower the price to `^%s gold `&and `%%s gems`&!`n`n", $shopkeep,$row['gold'],$row['gems']);
	}
	if($session['user']['gold']<$row['gold'] && $session['user']['gems']<$row['gems']){
		output("`2Sorry, but you have neither enough gold or gems to purchase a `6%s `2as a gift.`n`n", $row['name']);
	}else if ($session['user']['gold']<$row['gold']){
		output("`2Sorry, you don't have enough gold to purchase a `^%s `2as a gift.`n`n", $row['name']);
	}else if ($session['user']['gems']<$row['gems']){
		output("`2Sorry, you don't have enough gems to purchase a `^%s `2as a gift.`n`n", $row['name']);
	}else{
		//if the player can afford to, let's allow them to search
		output("`2\"Ah, how thoughtful of you %s`2,\" %s `2says with a smile. \"Now, who would you like to give this too?\"`n`n", $session['user']['login'],$shopkeep);
		output("`3`iYou have chosen to give a `^%s `3as a gift to another player.`i`n`n",$row['name']);
		rawoutput("<form action='runmodule.php?module=mysticalshop&op=gift&what=search-done&dk=$dk&id=$itemid&cat=$cat' method='POST'>");
		rawoutput("<input type='text' name='whom' id='gift' size='25'><br>");
		rawoutput("<input type='submit' value='Search Players'>");
		rawoutput("</form>");
		addnav("","runmodule.php?module=mysticalshop&op=gift&what=search-done&dk=$dk&id=$itemid&cat=$cat");
	}
?>