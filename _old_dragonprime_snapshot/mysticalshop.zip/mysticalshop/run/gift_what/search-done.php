<?php
	//so, let's find the player, and determine if they can actually receive the item
	$dkreq = httpget('dk');
	$id = httpget('id');
	//&cat=$cat		
	$sql = "SELECT acctid,login,name,level,dragonkills,sex FROM ".db_prefix("accounts")." WHERE name OR login LIKE '%".$_POST['whom']."%' AND acctid <> ".$session['user']['acctid']." AND locked=0 ORDER BY level,login";
	$result = db_query($sql);
	$count = db_num_rows($result); 
	rawoutput("<table cellpadding='3' width='500' cellspacing='0' border='0'><tr class='trhead'>");
	//Well, I was unable to find player. Let's tell the giftee...
	if ($count == 0){
		rawoutput("<td>");
		output("`3Couldn't find a user by that name. Try again.");
		rawoutput("</td>");
	}
	$i = 0;
	$name = translate_inline("Name");
	$lev = translate_inline("Level");
	$met_dk = translate_inline("Meets DK Requirement?");
	$donator = translate_inline("Donator");
	while($row = db_fetch_assoc($result)){
		//now onto checking to see if the player owns and item of that category, or if they've already received a gift
		$ring = get_module_pref("ring","mysticalshop",$row['acctid']);
		$amulet = get_module_pref("amulet","mysticalshop",$row['acctid']);
		$weapon = get_module_pref("weapon","mysticalshop",$row['acctid']);
		$armor = get_module_pref("armor","mysticalshop",$row['acctid']);
		$cloak = get_module_pref("cloak","mysticalshop",$row['acctid']);
		$glove = get_module_pref("glove","mysticalshop",$row['acctid']);
		$boot = get_module_pref("boots","mysticalshop",$row['acctid']);
		$helm = get_module_pref("helm","mysticalshop",$row['acctid']);
		$misc = get_module_pref("misc","mysticalshop",$row['acctid']);  
		$givengift = get_module_pref("gifted","mysticalshop",$row['acctid']);
		if ($row['dragonkills']>=$dkreq){
			$dkmet ="Yes"; 
		}else{
			$dkmet = "No"; 
		}
		$playerid = $row['acctid'];
		$playername = $row['name'];
		//a whole lot of checks, eh?
		if ($cat == 0 and $ring == 0) { $giveme = 1; 
		}else if ($cat == 1 and $amulet == 0) { $giveme = 1; 
		}else if ($cat == 2 and $weapon == 0) { $giveme = 1;
		}else if ($cat == 3 and $armor == 0) { $giveme = 1; 
		}else if ($cat == 4 and $cloak == 0) { $giveme = 1;
		}else if ($cat == 5 and $glove == 0) { $giveme = 1;
		}else if ($cat == 6 and $boot == 0) { $giveme = 1;
		}else if ($cat == 7 and $helm == 0) { $giveme = 1;
		}else if ($cat == 8 and $misc == 0) { $giveme = 1;
		}else{ $giveme = 0; }
		//if selected player(s) meet the requirements, let's find 'em and list 'em 
		//now includes checks to see if the player carries a pass from the hunting lodge
		if ($giveme == 1 && $dkmet == "Yes" && $givengift == 0){
			if (get_module_setting("shopappear") == 1){
				rawoutput("<td>$name</td><td>$level</td><td>$met_dk</td><td>$donator</td></tr>");
			}else{
				rawoutput("<td>$name</td><td>$level</td><td>$met_dk</td></tr>");
			}
			rawoutput("<tr class='".($i%2?"trlight":"trdark")."'>");
			$link = "runmodule.php?module=mysticalshop&op=gift&what=done&playerid=$playerid&id=$id&cat=$cat";
			rawoutput("<td><a href='$link'>");
			output_notl($playername);
			rawoutput("</a></td><td>");
			output_notl("%s",$row['level']);
			rawoutput("</td><td>");
			//output("<td>%s</td>",$own,true);
			output_notl("%s",$dkmet);
			rawoutput("</td>");
			if (get_module_setting("shopappear") == 1){ 
				$ownpass = get_module_pref("pass","mysticalshop",$row['acctid']);
				$havepass = translate_inline($ownpass?"Yes":"No");
				rawoutput("<td>");
				output_notl("%s",$havepass);
				rawoutput("</td>");
			}
			rawoutput("</tr><tr colspan='5'><td colspan='5'>");
			output("`3Click on player's name to confirm the sale of the item.");
			rawoutput("</td>");
			rawoutput("</tr><tr colspan='5'><td colspan='5'>");
			output("`6A sign by the counter reads: \"No refunds given on purchased gifts.\"");
			rawoutput("</td>");
			if (get_module_setting("shopappear") == 1){
				rawoutput("</tr><tr colspan='5'><td colspan='5'>");
				output("`^Remember: If a player doesn't have a pass (from donating), they can't claim their item!");
				rawoutput("</td>");
			}
			addnav("",$link);
		}else{
			//now, in case they can't be gifted, let's tell them possible reasons why...
			rawoutput("<tr class='".($i%2?"trlight":"trdark")."'>");
			if (httppost('whom')==""){
				rawoutput("<td>");
				output("`3No name selected!");
				rawoutput("</td>");
			}else if ( $dkmet == "No"){
				rawoutput("<td>");
				output("`3Sorry, %s doesn't meet the dragon kill requirements for this item.",$playername);
				rawoutput("</td>");
			}else if ($giveme == 0){
				rawoutput("<td>");
				output("`3Sorry, `2%s `3already owns an item of this type.",$playername);
				rawoutput("</td>");
			}else if ($givengift == 1){
				rawoutput("<td>");
				output("`3Sorry, `2%s `3has already received a gift, and it is awaiting pickup.",$playername);
				rawoutput("</td>");
			} 
		}
		$i++;
	}
	rawoutput("</tr></table>");
?>