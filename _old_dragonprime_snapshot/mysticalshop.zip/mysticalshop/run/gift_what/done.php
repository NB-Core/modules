<?php
	$playerid = httpget('playerid');
	$id = httpget('id');
	$giftid = get_module_pref("giftid");
	$sql = "SELECT * FROM " . db_prefix("magicitems") . " WHERE id='$id'";
	$result = db_query($sql);
	$row = db_fetch_assoc($result);	
	$gifteditem = $row['name'];	
	$disnum = get_module_setting("discountnum");
	if ($disnum == 0) $disnum = 1; // $disnum = 0 => $disnum == 0
	if (get_module_setting("discount")){
		$row['gold'] = ceil($row['gold']*(1 - ($session['user']['charm']/$disnum)));
		$row['gems'] = ceil($row['gems']*(1 - ($session['user']['charm']/$disnum)));
	}
	$giftgold = $row['gold'];
	$giftgems = $row['gems'];
	//We've bought the player the gift, let's subtract the cost now. 
	$session['user']['gold']-=$giftgold;
	$session['user']['gems']-=$giftgems;
	//now, let's set their item data up
	$sql = "SELECT acctid,login,name,level,sex FROM ".db_prefix("accounts")." WHERE acctid='$playerid'";
	$result = db_query($sql);
	$row = db_fetch_assoc($result);
	$pname = $row['name'];
	$usersex = translate_inline($row['sex']?"She":"He");
	output("`2You have bought `6%s `2a `^%s `2as a gift!",$pname,$gifteditem);
	output(" %s will receive a mail with details on how to pick it up.`n`n",$usersex);
	set_module_pref("gifted",1,"mysticalshop",$row['acctid']);
	set_module_pref("giftid",$id,"mysticalshop",$row['acctid']);
	set_module_pref("giftcat",$cat,"mysticalshop",$row['acctid']);
	//send a mail with name of item, shop, and location (for the clueless)
	$subject = translate_inline("Someone Bought you an Item!");
	$shop = get_module_setting("shopname");
	$loc = get_module_setting("shoploc");
	$message = sprintf_translate("%s `2has bought you a `^%s`2!`n`nYou may pick it up at `^%s `2in `^%s`2.",$session['user']['name'],$gifteditem,$shop,$loc);			
	require_once("lib/systemmail.php");
	systemmail($row['acctid'],$subject,$message);
?>