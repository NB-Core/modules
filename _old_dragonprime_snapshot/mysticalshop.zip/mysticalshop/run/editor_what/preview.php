<?php
	$sql = "SELECT * FROM " . db_prefix("magicitems") . " WHERE id='$id' AND category='$cat'";
	$result = db_query($sql);
	$row = db_fetch_assoc($result);
	output("`2`b`c<u>Preview of %s</u>`b`c`n`n",$row['name'],true);
	output("`2Cost Gold: `^%s`n",$row['gold']);
	output("`2Cost Gems: `%%s`n",$row['gems']);
	output("`2Dragon Kill Requirement: `^%s`n`n",$row['dk']);
	output("`2Short Description:`n");
	if ($row['description']>""){
		output("`3`i%s`i`n`n",$row['description']);
	}else{
		output("`3`iThis item has no short description.`i`n`n");
	}
	output("`2Verbose Description:`n");
	if ($row['bigdesc']>""){
		output("`3%s`n`n",$row['bigdesc']);
	}else{
		output("`2This Item has no Verbose Description.`n`n");
	}
	output("`2Stats:`n");
	if ($row['rare']>0) {
		output("`&This item is rare and only a limited amount exist.`n");
	}
	if ($row['attack']<>0) { 
		output("`&This item's enchantments will alter attack by `^%s `&points.`n",$row['attack']);
	}
	if ($row['defense']<>0) { 
		output("`&This item's enchantments will alter defense by `^%s `&points.`n",$row['defense']);
	}
	if ($row['charm']<>0) {
		output("`&This item's enchantments will alter charm by `^%s `&points.`n",$row['charm']);
	}
	if ($row['hitpoints']<>0) {
		output("`&This item's enchantments will alter maximum hitpoints by `^%s `&points.`n",$row['hitpoints']);
	}
	if ($row['turns']<>0) {
		output("`&This item's enchantments will alter turns by `^%s `&points.`n",$row['turns']);
	}
	if ($row['favor']<>0) {
		output("`&This item's enchantments will alter favor with Ramius by `^%s `&points.`n",$row['favor']);
	}
	output("`n`3Click `iRefresh List`i to return to the category you were just viewing.`n`n");
?>