<?php
	$sql = "DELETE FROM " . db_prefix("magicitems") . " WHERE id='$id'";
	db_query($sql);
	output("Item deleted!`n`n");
	redirect($from."op=editor&what=view&cat=$cat");
	$op = "";
	httpset("op", $op);
?>