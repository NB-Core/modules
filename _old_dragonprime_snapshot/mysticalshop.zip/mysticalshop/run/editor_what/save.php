<?php
	$itemid = httppost('id');
	$category = httppost('category');
	$name = stripslashes(httppost('name'));
	$describe = stripslashes(httppost('description'));
	//catch the submitted value, check to see if it's empty. if it is, declare it as 0 and move on
	//if it isn't, use original value instead
	$gold = httppost('gold');
	if ($gold == "") $gold = 0;
	else $gold = httppost('gold');
	$gems = httppost('gems');
	if ($gems == "") $gems = 0;
	else $gems = httppost('gems');
	$dk = httppost('dk');
	if ($dk == "") $dk = 0;
	else $dk = httppost('dk');
	$attack = httppost('attack');
	if ($attack == "") $attack = 0;
	else $attack = httppost('attack');
	$defense = httppost('defense');
	if ($defense == "") $defense = 0;
	else $$defense = httppost('defense');
	$charm = httppost('charm');
	if ($charm == "") $charm = 0;
	else $charm = httppost('charm');
	$hitpoints = httppost('hitpoints');
	if ($hitpoints == "") $hitpoints = 0;
	else $hitpoints = httppost('hitpoints');
	$turns = httppost('turns');
	if ($turns == "") $turns = 0;
	else $turns = httppost('turns');
	$favor = httppost('favor');	
	if ($favor == "") $favor = 0;
	else $favor = httppost('favor');
	$bigdesc = stripslashes(httppost('bigdesc'));
	$rare = httppost('rare');
	if ($rare == "") $rare = 0;
	else $rare = httppost('rare');
	$rarenum = httppost('rarenum');
	if ($rarenum == "") $rarenum = 0;
	else $rarenum = httppost('rarenum');
	//
	if ($itemid>0){
		$sql = "UPDATE ".db_prefix("magicitems")." 
			SET category=$category,
			name=\"$name\",
			description=\"$describe\",
			gold=$gold,
			gems=$gems,
			dk=$dk,
			attack=$attack,
			defense=$defense,
			charm=$charm,
			hitpoints=$hitpoints,
			turns=$turns,
			favor=$favor,
			bigdesc=\"$bigdesc\",
			rare=$rare, 
			rarenum=$rarenum 
			WHERE id=$itemid";
		output("`6The item \"`^%s`6\" has been successfully edited.`n`n",$name);
		output("Would you like to <a href='runmodule.php?module=mysticalshop&op=editor&what=preview&id=$id&cat=$cat'>[ Review ]</a> this item?",true);
		addnav("",$from."op=editor&what=preview&id=$id&cat=$cat"); 
	}else{
		$sql = "INSERT INTO ".db_prefix("magicitems")." 										
		(category,name,description,gold,gems,dk,attack,defense,charm,hitpoints,turns,favor,bigdesc,rare,rarenum) 
		VALUES ($category,\"$name\", \"$describe\",$gold,$gems,$dk,$attack,$defense,$charm,$hitpoints,$turns,$favor,\"$bigdesc\",$rare,$rarenum)";
		output("`6The item \"`^$name`6\" has been saved to the database.`n`n");
	}
	db_query($sql);
	invalidatedatacache("modules-mysticalshop-viewgoods");
	invalidatedatacache("modules-mysticalshop-enter");
	$op = "";
	httpset("op", $op);
?>