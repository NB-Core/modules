<?php
	$row = array(
		"id"=>"","category"=>"","name"=>"","description"=>"","gold"=>"","gems"=>"","dk"=>"",
		"attack"=>"","defense"=>"","charm"=>"","hitpoints"=>"","turns"=>"","favor"=>"",
		"bigdesc"=>"","rare"=>"","rarenum"=>"",
	);
	rawoutput("<form action='runmodule.php?module=mysticalshop&op=editor&what=save&id=$id&cat=$cat' method='POST'>");
	addnav("","runmodule.php?module=mysticalshop&op=editor&what=save&id=$id&cat=$cat");
	require_once("lib/showform.php");
	showform($itemarray,$row);
	rawoutput("</form>");
?>