<?php
	$sql = "SELECT * FROM " . db_prefix("magicitems") . " WHERE id='$id'";
	$result = db_query($sql);
	$row = db_fetch_assoc($result);
	rawoutput("<form action='runmodule.php?module=mysticalshop&op=editor&what=save&id=$id&cat=$cat' method='POST'>");
	addnav("","runmodule.php?module=mysticalshop&op=editor&what=save&id=$id&cat=$cat");
	require_once("lib/showform.php");
	showform($itemarray,$row);
	rawoutput("</form>");
?>