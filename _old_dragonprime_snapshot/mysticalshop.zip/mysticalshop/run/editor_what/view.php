<?php
	$edit = translate_inline("Edit");
	$del = translate_inline("Delete");
	$give = translate_inline("Preview");
	$cat = httpget('cat');
	$delconfirm = translate_inline("Are you sure you wish to delete this item?");
	$sql = "SELECT * FROM " . db_prefix("magicitems") . " WHERE id>=0 AND category='$cat' ORDER BY gold";
	$result = db_query($sql);
	$count = db_num_rows($result);
	if ($count == 0){
		output("`6No Items on record yet.");
	}else{
		$ops = translate_inline("Ops");
		$itemid = translate_inline("Item ID");
		$name = translate_inline("Name");
		$goldc = translate_inline("Cost Gold");
		$gemc = translate_inline("Cost Gems");
		$cate = translate_inline("Category");
		rawoutput("<table cellspacing=0 cellpadding=2 width='100%' align='center'>");
		rawoutput("<tr><td>$ops</td><td>$itemid</td><td>$name</td><td>$goldc</td><td>$gemc</td><td>$cate</td></tr>");
		$i = 0;
		while($row = db_fetch_assoc($result)){
			rawoutput("<tr class='".($i%2?"trlight":"trdark")."'>"); 
			rawoutput("<td>[<a href='runmodule.php?module=mysticalshop&op=editor&what=edit&id={$row['id']}&cat={$row['category']}'>$edit</a>|<a href='runmodule.php?module=mysticalshop&op=editor&what=delete&id={$row['id']}&cat={$row['category']}' onClick='return confirm(\"$delconfirm\");'>$del</a>|<a href='runmodule.php?module=mysticalshop&op=editor&what=preview&id={$row['id']}&cat={$row['category']}'>$give</a>]</td>");   
			addnav("","runmodule.php?module=mysticalshop&op=editor&what=edit&id={$row['id']}&cat={$row['category']}");
			addnav("","runmodule.php?module=mysticalshop&op=editor&what=delete&id={$row['id']}&cat={$row['category']}");
			addnav("","runmodule.php?module=mysticalshop&op=editor&what=preview&id={$row['id']}&cat={$row['category']}");
			rawoutput("<td>");
			output_notl($row['id']);
			rawoutput("</td><td>");
			output_notl($row['name']);
			rawoutput("</td><td>");
			output_notl($row['gold']);
			rawoutput("</td><td>");
			output_notl($row['gems']);
			rawoutput("</td><td>");
			output_notl($names[$row['category']]);
			rawoutput("</td></tr>");
			rawoutput("<tr><td colspan='6'>");
			output_notl($row['description']);
			rawoutput("</td></tr>");
			$i++;
		}
		rawoutput("</table>");
	}
?>