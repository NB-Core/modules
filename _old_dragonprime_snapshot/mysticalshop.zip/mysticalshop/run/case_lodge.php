<?php
	$passcost = get_module_setting("pointsreq");
	$shopname = get_module_setting("shopname");
	$loc = get_module_setting("shoploc");
	$pointsavailable = $session['user']['donation'] - $session['user']['donationspent'];
	switch(httpget('what')){
		case "buypass":
			output("`7J. C. Petersen glances at you for a moment, sizing you up. After a moment, he nods.`n`n");
			output("`&\"A pass to visit `3%s `&costs `^%s `&donation points.", $shopname,$passcost);
			if ($pointsavailable<$passcost){
				output(" `&I'm afraid however, you don't have enough to afford it,\" he says.`n`n");
				addnav("L?Return to the Lodge","lodge.php");
			}else{
				output(" `&Interested?\" `7he asks you, holding up a shimmering green token.`n`n");
				addnav("Yes",$from."op=lodge&what=bought");
				addnav("No","lodge.php");
			}
			break;
		case "bought":
			$session['user']['donationspent']+=$passcost;
			set_module_pref("pass",1);
			output("`7J.C. makes a note on a ledger and then hands you the shimmering green token.`n`n");
			output("`&\"The pass is good for however long you have it,\" `7he says.");
			output(" `&\"You'll find `3%s `&in `^%s`&, by the way.\"`n`n",$shopname,$loc);
			addnav("L?Return to the Lodge","lodge.php");
			break;
	}
?>