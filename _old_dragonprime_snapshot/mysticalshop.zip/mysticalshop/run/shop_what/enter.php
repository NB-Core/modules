<?php
	if (get_module_setting("shopappear") == 1 AND get_module_pref("pass")==1){
		output("`2%s nods as you hold up your token upon entering.`n`n", $shopkeep);
	}
	if ($shopdesc>""){
		output("%s`n`n",$shopdesc);
		//default message for the lazy admin
	}else{
		output("`2Coming in from the alleyway, your eyes take a moment to adjust to the dark atmosphere inside the shop.");
		output(" `2Looking about, you are amazed to see a wide range of items and equipment that line the walls on racks and in display cases.`n`n");
		output("\"Greetings, friend,\" says %s, \"Welcome to my shop\"`n`n",$shopkeep);
	}
	if ($hasgift == 1){
		output("`^%s `^notes you have a gift waiting for pickup.`n", $shopkeep);
		output("`^\"Perhaps you'll want to see it?\"`2`n`n");
	}
	//Note to self: STOP removing this
	modulehook("mysticalshop", array());
	addnav("Merchandise");
	$extra = "";
	if ($session['user']['specialty'] == 'MN') $extra = "WHERE category!='2' AND category!='3'";
	$sql = "SELECT * FROM " . db_prefix("magicitems") .  " $extra ORDER BY category";
	$result = db_query_cached($sql,"modules-mysticalshop-enter");
	$category="";
	while($row = db_fetch_assoc($result)){
		if ($category!=$row['category']){
			addnav(array("Examine %s`0", $names[$row['category']]),$from."op=shop&what=viewgoods&cat={$row['category']}");
			$category = $row['category'];
		}
	}
	if ($hasgift == 1) {
		addnav("Special");
		addnav("Pick Up Gift",$from."op=gift&what=examinegift");
	}
	addnav("Other");
	//addnav("Refresh Screen",$from."op=shop&what=enter");
	villagenav();
?>