<?php
	$sql = "SELECT * FROM " . db_prefix("magicitems") . " WHERE id=$id";
	$result = db_query($sql);
	$row = db_fetch_assoc($result);
	$what = $row['name'];
	$thisid = $row['id'];
	$cat = $row['category'];
	$verbose = $row['bigdesc'];
	$ring = get_module_pref("ring");
	$amulet = get_module_pref("amulet");
	$weapon = get_module_pref("weapon");
	$armor = get_module_pref("armor");
	$cloak = get_module_pref("cloak");
	$glove = get_module_pref("glove");
	$boot = get_module_pref("boots");
	$helm = get_module_pref("helm");
	$misc = get_module_pref("misc");
	$rare = $row['rare'];
	$rarenum = $row['rarenum']; 

	$desc_names = array(0=>"a ring",1=>"an amulet",2=>"a weapon",3=>"some armor",4=>"a cloak",5=>"a helmet",6=>"pair of gloves",7=>"pair of boots",8=>"a miscellaneous item");	
	output("`2You have chosen to view the %s.`n`n", $row['name']);
	//display that nice big description you typed out here
	if ($verbose>""){
		output("`3%s`n`n",$row['bigdesc']);
	//otherwise, let's display a default one in it's place
	}else{
		output("`3No extended description for this item is available.`n`n");
	}
	if (get_module_setting("showstats")){
		$sql = "SELECT * FROM " . db_prefix("magicitems") . " WHERE id='$id'";
		$result = db_query($sql);
		$row = db_fetch_assoc($result);
		if ($row['attack']<>0) { 
			output("`&This item's enchantments will alter your attack by `^%s `&points.`n",$row['attack']);
		}
		if ($row['defense']<>0) { 
			output("`&This item's enchantments will alter your defense by `^%s `&points.`n",$row['defense']);
		}
		if ($row['charm']<>0) {
			output("`&This item's enchantments will alter your charm by `^%s `&points.`n",$row['charm']);
		}
		if ($row['hitpoints']<>0) {
			output("`&This item's enchantments will alter your maximum hitpoints by `^%s `&points.`n",$row['hitpoints']);
		}
		if ($row['turns']<>0) {
			output("`&This item's enchantments will grant `^%s `&extra turns.`n",$row['turns']);
		}
		if ($row['favor']<>0) {
			output("`&This item's enchantments will alter your favor with Ramius by `^%s `&points.`n`n",$row['favor']);
		}
	}
	//Now let's check if they're buying or selling an item. 
	output("`@The %s `@costs `^%s gold `@and `5%s gems`@.`n`n", $row['name'],$row['gold'],$row['gems']);
	if (get_module_setting("discount")){
		$row['gold'] = ceil($row['gold']*(1 - ($session['user']['charm']/$disnum)));
		$row['gems'] = ceil($row['gems']*(1 - ($session['user']['charm']/$disnum)));
		output("`&However, you manage to haggle the price down to `^%s gold `&and `%%s gems`&.`n`n", $row['gold'],$row['gems']);
	}
	//check to see if they can afford it first; saves from having to add extra checks. Bleh.
	if ($ring == 1 && $cat == 0 OR $amulet==1 AND $cat == 1 OR $weapon==1 AND $cat == 2 OR $armor==1 AND $cat == 3 OR $cloak == 1 AND $cat == 4 OR $helm == 1 AND $cat ==5 OR $glove == 1 AND $cat==6 OR $boot==1 AND $cat==7 OR $misc==1 AND $cat==8){
		output("However, realizing you already own %s, you're forced to merely look at it until you decide to sell your current item.`n`n", $names[$cat]);
	}else if ($session['user']['gold']<$row['gold'] or $session['user']['gems']<$row['gems']){
		output("`3However, checking your funds, you realize you can't afford to purchase this item at the moment.`n`n");		   
	//a quick check to make sure there are enough rare items instock for the player 
	}else if ($rare == 1 && $rarenum<1){
		output("`2%s `2suddenly realizes that the `3%s `2you were about to purchase has been sold out.`n`n", $shopkeep,$row['name']);
		output("`2\"Things go fast around here...much too fast sometimes,\" the shopkeeper notes.");
	//otherwise, display the purchase nav
	}else{   
		addnav("Sales");
		addnav("Purchase $what",$from."op=shop&what=purchase&id=$id&cat=$cat");
	}
	if ($cat == 2 || $cat == 3){
		output("`6Be aware that magical blades and armor are adaptive.");
		output(" `6Precluding any extra magical properties, their attack and defensive properties are equal to your level.");
		output(" `6As you grow in strength (gain a level), so too do they.`n`n");
	}
	modulehook("mysticalshop-preview", array());
	addnav("Go Back",$from."op=shop&what=viewgoods&cat=$cat");
?>