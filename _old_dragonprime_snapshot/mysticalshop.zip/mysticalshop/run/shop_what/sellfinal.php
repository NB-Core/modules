<?php
	$sql = "SELECT * FROM " . db_prefix("magicitems") . " WHERE id=$id";    
	$result = db_query($sql);
	$row = db_fetch_assoc($result);	
	if (get_module_setting("discount")){
		$row['gold'] = ceil($row['gold']*(1 - ($session['user']['charm']/$disnum)));
		$row['gems'] = ceil($row['gems']*(1 - ($session['user']['charm']/$disnum)));
	}
	$sellgold = round(($row['gold']*.75),0);
	$sellgems = round(($row['gems']*.25),0);
	$rare = $row['rare'];
	//if this is a limited item, let's add back to the total available
	if ($rare == 1){
		$sql = "UPDATE ".db_prefix("magicitems")." SET rarenum=rarenum+1 WHERE id=$id";
		db_query($sql);
		invalidatedatacache("modules-mysticalshop-viewgoods");
		invalidatedatacache("modules-mysticalshop-enter");
	}		   		   
	output("`2You have chosen to sell your %s`2.", $row['name']);
	output(" `2%s `2hands you your `^%s gold `2and `%%s gems `2and bids you a good day.`n`n", $shopkeep,$sellgold,$sellgems);		  
	output("`3Any magic enchantments the %s `3possessed have now been removed.", $row['name']);
	//The hook is up here to catch the ID of the item before it's reset
	modulehook("mysticalshop-sell", array("itemid"=>$id));
	$rare = FALSE;
	if ($row['rare']) $rare = $id;
	require_once("modules/mysticalshop/lib.php");
	if ($cat == 0){
		mysticalshop_destroyitem("ring",$rare);
	}else if ($cat == 1){
		mysticalshop_destroyitem("amulet",$rare);
	}else if ($cat == 2){
		mysticalshop_destroyitem("weapon",$rare);
		//unset weapon
		$session['user']['weapon']="Fists";
		$session['user']['attack']-=$session['user']['weapondmg'];
		$session['user']['weapondmg']=0;
		$session['user']['weaponvalue']=0;
	}else if ($cat == 3){
		mysticalshop_destroyitem("armor",$rare);
		//unset armor
		$session['user']['armor']="T-Shirt";
		$session['user']['defense']-=$session['user']['armordef'];
		$session['user']['armordef']=0;
		$session['user']['armorvalue']=0;
	}else if ($cat == 4){ 
		mysticalshop_destroyitem("cloak",$rare);
	}else if ($cat == 5){
		mysticalshop_destroyitem("helm",$rare);
	}else if ($cat == 6){
		mysticalshop_destroyitem("glove",$rare);
	}else if ($cat == 7){
		mysticalshop_destroyitem("boot",$rare);
	}else if ($cat == 8){
		mysticalshop_destroyitem("misc",$rare);
	} 
	//Undo any altered stats
	if ($row['attack']<>0) {
		$session['user']['attack']-=$row['attack'];
	}
	if ($row['defense']<>0) {
		$session['user']['defense']-=$row['defense'];
	}
	if ($row['charm']<>0) { 
		$session['user']['charm']-=$row['charm'];
	}
	if ($row['hitpoints']<>0) {
		//note, add a check in to prevent any possible permadead situation after dk
		$session['user']['maxhitpoints']-=$row['hitpoints'];
		$session['user']['hitpoints']=$session['user']['maxhitpoints'];
	}
	if ($row['turns']<>0) {
		if( $session['user']['turns'] > $row['turns'] )
			$session['user']['turns']-=$row['turns'];
		else
			$session['user']['turns'] = 0;
	/*	if (get_module_pref("turnadd")<$diff){ // per-item stats shouldn't shouldn't affect other items
			set_module_pref("turnadd",0); // assuming negatives are allowed (as turn penalty); $diff is undefined
		}else{
	*/
		set_module_pref("turnadd",get_module_pref("turnadd")-$row['turns']);
	//	} // end if
	}
	//Undo favor
	if ($row['favor']<>0) {
		if ($session['user']['deathpower']<=$row['favor']){
			$session['user']['deathpower']=0;
		}else{
			$session['user']['deathpower']-=$row['favor'];
		}
		set_module_pref("res",0);
		$favoradd = get_module_pref("favoradd")-$row['favor'];
		set_module_pref("favoradd", $favoradd);
		if( $favoradd == 0 ) // if it's not 0, assuming that other items are still affecting it
			set_module_pref("favor",0);
	}
	//now, refund gold and gems
	$session['user']['gold']+=$sellgold;
	$session['user']['gems']+=$sellgems;
	modulehook("mysticalshop-sell-after", array());
	addnav("Go Back",$from."op=shop&what=enter");
?>