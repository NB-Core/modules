<?php
	$sql = "SELECT * FROM " . db_prefix("magicitems") . " WHERE id=$id";
	$result = db_query($sql);
	$row = db_fetch_assoc($result);
	if (get_module_setting("discount")){
		$row['gold'] = ceil($row['gold']*(1 - ($session['user']['charm']/$disnum)));
		$row['gems'] = ceil($row['gems']*(1 - ($session['user']['charm']/$disnum)));
	}	
	$sellgold = round(($row['gold']*.75),0);
	$sellgems = round(($row['gems']*.25),0);
	output("`2%s `2contemplates for a moment, then offers you a deal of `^%s gold `2and `%%s gems `2for your `3%s`2.`n`n",$shopkeep,$sellgold,$sellgems,$row['name']);		  	
	if (get_module_setting("discount")){
		output("`3Thinking that price is much too low, %s reminds you the item was sold at a discounted price, thus your refund is set to match.`n`n", $shopkeep);
	}
	addnav("Yes",$from."op=shop&what=sellfinal&id=$id&cat=$cat");
	addnav("No",$from."op=shop&what=enter");
?>