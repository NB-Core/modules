<?php
	$subop = httpget('subop');
	$type = httpget("type");
	$cangift = get_module_setting("givegift");
	$userdk = $session['user']['dragonkills'];
	$show = get_module_setting("shownum");
	//pages
	$perpage = $show;
	if ($subop=="") $subop=1;
	$min = ($subop-1)*$perpage;
	//pages display
	$limit = "LIMIT $min,$perpage";
	$sql = "SELECT COUNT(*) AS c FROM " . db_prefix("magicitems") . " WHERE $userdk>=dk and category=$cat ORDER BY category";
	$result = db_query_cached($sql,"modules-mysticalshop-viewgoods");
	$row = db_fetch_assoc($result);
	$total = $row['c'];
	addnav("Pages");
	for($i = 0; $i < $total; $i+= $perpage) {
		$pnum = ($i/$perpage+1);
		$min = ($i+1);
		$max = min($i+$perpage,$total);
		addnav(array("Page %s (%s-%s)", $pnum, $min, $max), "runmodule.php?module=mysticalshop&op=shop&what=viewgoods&cat=$cat&subop=$pnum");
	}
	//
	$sql = "SELECT * FROM " . db_prefix("magicitems") . " WHERE $userdk>=dk and category=$cat ORDER BY category DESC $LIMIT";
	$items = array();
	$ops = translate_inline("Choices");
	$name = translate_inline("Item Name");
	$cost = translate_inline("Item Cost");
	$gift = translate_inline("Gift");
	$ring = get_module_pref("ring");
	$amulet = get_module_pref("amulet");
	$weapon = get_module_pref("weapon");
	$armor = get_module_pref("armor");
	$cloak = get_module_pref("cloak");
	$glove = get_module_pref("glove");
	$boot = get_module_pref("boots");
	$helm = get_module_pref("helm"); 
	$misc = get_module_pref("misc");
	//$itemid = $row['id'];
	$sell = translate_inline("Sell First");
	$buy = translate_inline("Examine");
	$quantity = translate_inline("Quantity");
	$viewbuy = translate_inline("Examine or Buy");
	$result = db_query($sql);
	$count = db_num_rows($result);
	if ($count == 0){
		output("`6No Items on record yet.");
	}else{
		rawoutput("<table cellspacing=0 cellpadding=2 width='100%' align='center'>");
		rawoutput("<tr><td>$ops</td><td>$name</td><td>$cost</td><td>$quantity</td></tr>");      		
		$i = 0;
		while($row = db_fetch_assoc($result)){
			$rare = $row['rare'];
			$rarenum = $row['rarenum'];
			if ($rare == 0){ $instock = translate_inline("`3Many"); }
			else if ($rarenum<1) { $instock = translate_inline("`\$Sold Out"); }
			else {$instock = $rarenum; }
			if ($cat == 0) $sellid = get_module_pref("ringid");
			else if ($cat == 1) $sellid = get_module_pref("amuletid");
			else if ($cat == 2) $sellid = get_module_pref("weaponid");
			else if ($cat == 3) $sellid = get_module_pref("armorid");
			else if ($cat == 4) $sellid = get_module_pref("cloakid");
			else if ($cat == 5) $sellid = get_module_pref("helmid");
			else if ($cat == 6) $sellid = get_module_pref("gloveid");
			else if ($cat == 7) $sellid = get_module_pref("bootid");
			else if ($cat == 8) $sellid = get_module_pref("miscid");
			output("<tr class='".($i%2?"trlight":"trdark")."'>",true); 
			//if player owns an item, then they have to sell first
			if ($ring == 1 && $cat == 0 OR $amulet==1 AND $cat == 1 OR $weapon==1 AND $cat == 2 OR $armor==1 AND $cat == 3 OR $cloak == 1 AND $cat == 4 OR $helm == 1 AND $cat ==5 OR $glove == 1 AND $cat==6 OR $boot==1 AND $cat==7 OR $misc == 1 AND $cat == 8){
				rawoutput("<td>[<a href='runmodule.php?module=mysticalshop&op=shop&what=preview&id={$row['id']}'>$buy</a>] [<a href='runmodule.php?module=mysticalshop&op=shop&what=sell&id=$sellid&cat=$cat'>$sell</a>]");					
				addnav("","runmodule.php?module=mysticalshop&op=shop&what=preview&id={$row['id']}");
				addnav("","runmodule.php?module=mysticalshop&op=shop&what=sell&id={$row['id']}&cat=$cat");
			//otherwise...	
			}else{
				rawoutput("<td>[<a href='runmodule.php?module=mysticalshop&op=shop&what=preview&id={$row['id']}'>$viewbuy</a>]");
				addnav("","runmodule.php?module=mysticalshop&op=shop&what=preview&id={$row['id']}");
			}
			if ($cangift == 1){
				rawoutput(" [<a href='runmodule.php?module=mysticalshop&op=gift&what=search&id={$row['id']}&cat=$cat'>$gift</a>]</td>");
				addnav("","runmodule.php?module=mysticalshop&op=gift&what=search&id={$row['id']}&cat=$cat");
			}else{
				rawoutput("</td>");
			}
			rawoutput("<td>");
			output_notl("`&%s`0", $row['name']);
			rawoutput("</td><td>");
			output("`^%s Gold`0 and `%%s Gems`0",$row['gold'],$row['gems']);
			rawoutput("</td><td>");
			output("`Q%s",$instock);
			rawoutput("</td>");
			rawoutput("</tr>");
			if (get_module_setting("displaydesc")){
				if ($row['description']>""){
					rawoutput("<tr><td colspan='5'>");
					output("`i`3Description: %s`i", $row['description']);
					rawoutput("</td></tr>");
				}else{
					rawoutput("<tr><td colspan='5'>");
					output("`i`3No description available");
					rawoutput("</td></tr>");
				}
			}
			$i++;
		}
	}
	rawoutput("</table>");
	addnav("Other");
	addnav("Go Back",$from."op=shop&what=enter");
?>