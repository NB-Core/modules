<?php
	$shopkeep = get_module_setting("shopkeepname");
	require_once("modules/mysticalshop/run/gift_what/$what.php");
	addnav("Go Back",$from."op=shop&what=enter");
	//lodge module
?>