<?php
// Holy shit, heavy load.
if (get_module_pref("user_display")){
	$amulet = get_module_pref("amuletname");
	$ring = get_module_pref("ringname");
	$cloak = get_module_pref("cloakname");
	$glove = get_module_pref("glovename");
	$boot = get_module_pref("bootname");
	$helm = get_module_pref("helmname");
	$misc = get_module_pref("miscname");
	addcharstat("Vital Info");
	addcharstat("Equipment Info");
	if ($helm != 'None' && $helm != "") addcharstat("Helm:", $helm);
	if ($cloak != 'None' && $cloak != "") addcharstat("Cloak:", $cloak);
	if ($amulet != 'None' && $amulet != "") addcharstat("Amulet:", $amulet);
	if ($glove != 'None' && $glove != "") addcharstat("Gloves:", $glove);
	if ($ring != 'None' && $ring != "") addcharstat("Ring:", $ring);
	if ($boot != 'None' && $boot != "") addcharstat("Boots:", $boot);
	if ($misc != 'None' && $misc != "") addcharstat("Extra Item:", $misc);
}
?>