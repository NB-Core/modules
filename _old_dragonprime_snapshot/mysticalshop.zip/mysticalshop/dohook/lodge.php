<?php
$points = get_module_setting("pointsreq");
if (get_module_setting("shopappear") == 1 && get_module_pref("pass") == 0){
	addnav(array("Buy Pass to Equipment Shop (%s Points)",$points),$from."op=lodge&what=buypass"); 
}
?>