<?php
if( isset( $args['applyall'] ) )
if( $args['applyall'] ){
   	$buffs = array( 'attack'=>'attack', 'defense'=>'defense', 'charm'=>'charm', 'hitpoints'=>'maxhitpoints', 'turns'=>'turns', 'favor'=>'deathpower' );
	require_once("modules/mysticalshop/lib.php");
   	$args = applyenh( $buffs, $args );
   	$args['applyall'] = false;
}
?>