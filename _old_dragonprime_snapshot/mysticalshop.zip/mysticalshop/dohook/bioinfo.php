<?php
$amulet = get_module_pref("amuletname","mysticalshop",$args['acctid']);
$ring = get_module_pref("ringname","mysticalshop",$args['acctid']);
$cloak = get_module_pref("cloakname","mysticalshop",$args['acctid']);
$glove = get_module_pref("glovename","mysticalshop",$args['acctid']);
$boot = get_module_pref("bootname","mysticalshop",$args['acctid']);
$helm = get_module_pref("helmname","mysticalshop",$args['acctid']);
$weapon = get_module_pref("weaponname","mysticalshop",$args['acctid']);
$armor = get_module_pref("armorname","mysticalshop",$args['acctid']);
if (get_module_pref("helm","mysticalshop",$args['acctid'])) output("`^%s `2is wearing a `3%s`2.`n",$args['name'],$helm); // helm, not helmet!
if (get_module_pref("amulet","mysticalshop",$args['acctid'])) output("`^%s `2is wearing a `3%s`2.`n",$args['name'],$amulet);
if (get_module_pref("cloak","mysticalshop",$args['acctid'])) output("`^%s `2is wearing a `3%s`2.`n",$args['name'],$cloak);
if (get_module_pref("ring","mysticalshop",$args['acctid'])) output("`^%s `2is wearing a `3%s`2.`n",$args['name'],$ring);
if (get_module_pref("glove","mysticalshop",$args['acctid'])) output("`^%s `2is wearing a pair of `3%s`2.`n",$args['name'],$glove);
if (get_module_pref("boots","mysticalshop",$args['acctid'])) output("`^%s `2is wearing a pair of `3%s`2.`n",$args['name'],$boot);
if (get_module_pref("weapon","mysticalshop",$args['acctid'])) output("`^%s `2is wielding a `3%s`2.`n",$args['name'],$weapon);
if (get_module_pref("armor","mysticalshop",$args['acctid'])) output("`^%s `2is equipped with a `3%s`2.`n",$args['name'],$armor);
?>