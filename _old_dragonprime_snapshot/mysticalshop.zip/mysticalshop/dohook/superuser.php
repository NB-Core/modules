<?php
$edit = translate_inline("Editors");
$link = translate_inline("Equipment Editor");
if ($session['user']['superuser'] & SU_EDIT_MOUNTS)addnav("$edit");
if ($session['user']['superuser'] & SU_EDIT_MOUNTS)addnav("$link", $from."op=editor&what=view&cat=0");
?>