<?php
			$chance = get_module_setting("losechance");
			$roll = e_rand(1,100);
			//say bye bye to all your junk. Gah, I really kicked myself in the ass with this one...
				if (get_module_pref("ring") && get_module_setting("losering")) {
					$chance = get_module_setting("losechance");
					$roll = e_rand(1,100);
					if ($roll<$chance) {
						$id = get_module_pref("ringid");
						$sql = "SELECT * FROM " . db_prefix("magicitems") . " WHERE id=$id";
				    	$result = db_query($sql);
				   		$row = db_fetch_assoc($result);
				   		/*if ($row['attack']<>0) $session['user']['attack']-=$row['attack']; // No, you don't take away what's already
				   		if ($row['defense']<>0) $session['user']['defense']-=$row['defense'];*/ // taken away by the system! DK'd, remember?
				   		if ($row['charm']<>0) $session['user']['charm']-=$row['charm'];
				   		if( is_module_active( 'globalhp' ) && get_module_setting( 'carrydk', 'globalhp') )
				   			if ($row['hitpoints']<0) $session['user']['maxhitpoints']-=$row['hitpoints'];
				   		if ($row['turns']<>0) { 
					   		$session['user']['turns']-=$row['turns'];
				   			if (get_module_pref("turnadd")>0) {
					   		set_module_pref("turnadd",get_module_pref("turnadd")-$row['turns']);
							}	
						}
						if (get_module_pref("favor")<>0){
							set_module_pref("res",0);
							set_module_pref("favor",0);
							set_module_pref("favoradd",0);
						}
						$rare = FALSE;
						if ($row['rare']) $rare = $id;
						require_once("modules/mysticalshop/lib.php");
				   		mysticalshop_destroyitem("ring",$rare);
				   		output("`3You don't seem to be wearing a ring anymore.`n");
		   			}
		   		}
				if (get_module_pref("amulet") && get_module_setting("loseamulet")) {
					$chance = get_module_setting("losechance");
					$roll = e_rand(1,100);
					if ($roll<$chance){
						$id = get_module_pref("amuletid");
						$sql = "SELECT * FROM " . db_prefix("magicitems") . " WHERE id=$id";
				    	$result = db_query($sql);
				   		$row = db_fetch_assoc($result);
				   		/*if ($row['attack']<>0) $session['user']['attack']-=$row['attack'];
				   		if ($row['defense']<>0) $session['user']['defense']-=$row['defense'];*/
				   		if ($row['charm']<>0) $session['user']['charm']-=$row['charm'];
				   		if( is_module_active( 'globalhp' ) && get_module_setting( 'carrydk', 'globalhp') )
				   			if ($row['hitpoints']<0) $session['user']['maxhitpoints']-=$row['hitpoints'];
				   		if ($row['turns']<>0) { 
					   		$session['user']['turns']-=$row['turns'];
				   			if (get_module_pref("turnadd")>0) {
					   		set_module_pref("turnadd",get_module_pref("turnadd")-$row['turns']);
							}
						}
						if (get_module_pref("favor")<>0){
							set_module_pref("res",0);
							set_module_pref("favor",0);
							set_module_pref("favoradd",0);
						}
						$rare = FALSE;
						if ($row['rare']) $rare = $id;
						require_once("modules/mysticalshop/lib.php");
				   		mysticalshop_destroyitem("amulet",$rare);
				   		output("`3You notice you've lost your amulet.`n");
		   			}
				}
				if (get_module_pref("glove") && get_module_setting("loseglove")) {
					$chance = get_module_setting("losechance");
					$roll = e_rand(1,100);
					if ($roll<$chance){
						$id = get_module_pref("gloveid");
						$sql = "SELECT * FROM " . db_prefix("magicitems") . " WHERE id=$id";
				    	$result = db_query($sql);
				   		$row = db_fetch_assoc($result);
				   		/*if ($row['attack']<>0) $session['user']['attack']-=$row['attack'];
				   		if ($row['defense']<>0) $session['user']['defense']-=$row['defense'];*/
				   		if ($row['charm']<>0) $session['user']['charm']-=$row['charm'];
				   		if( is_module_active( 'globalhp' ) && get_module_setting( 'carrydk', 'globalhp') )
				   			if ($row['hitpoints']<0) $session['user']['maxhitpoints']-=$row['hitpoints'];
				   		if ($row['turns']<>0) { 
					   		$session['user']['turns']-=$row['turns'];
				   			if (get_module_pref("turnadd")>0) {
					   		set_module_pref("turnadd",get_module_pref("turnadd")-$row['turns']);
							}	
						}
						if (get_module_pref("favor")<>0){
							set_module_pref("res",0);
							set_module_pref("favor",0);
							set_module_pref("favoradd",0);
						}
						$rare = FALSE;
						if ($row['rare']) $rare = $id;
						require_once("modules/mysticalshop/lib.php");
				   		mysticalshop_destroyitem("glove",$rare);
				   		output("`3Your gloves have gone missing.`n");
			   		}
				}
				if (get_module_pref("cloak") && get_module_setting("losecloak")) {
					$chance = get_module_setting("losechance");
					$roll = e_rand(1,100);
					if ($roll<$chance){
						$id = get_module_pref("cloakid");
						$sql = "SELECT * FROM " . db_prefix("magicitems") . " WHERE id=$id";
				    	$result = db_query($sql);
				   		$row = db_fetch_assoc($result);
				   		/*if ($row['attack']<>0) $session['user']['attack']-=$row['attack'];
				   		if ($row['defense']<>0) $session['user']['defense']-=$row['defense'];*/
				   		if ($row['charm']<>0) $session['user']['charm']-=$row['charm'];
				   		if( is_module_active( 'globalhp' ) && get_module_setting( 'carrydk', 'globalhp') )
				   			if ($row['hitpoints']<0) $session['user']['maxhitpoints']-=$row['hitpoints'];
				   		if ($row['turns']<>0) { 
					   		$session['user']['turns']-=$row['turns'];
				   			if (get_module_pref("turnadd")>0) {
					   		set_module_pref("turnadd",get_module_pref("turnadd")-$row['turns']);
							}
						}
						if (get_module_pref("favor")<>0){
							set_module_pref("res",0);
							set_module_pref("favor",0);
							set_module_pref("favoradd",0);
						}
						$rare = FALSE;
						if ($row['rare']) $rare = $id;
						require_once("modules/mysticalshop/lib.php");
				   		mysticalshop_destroyitem("cloak",$rare);
				   		output("`3Your cloak has been shredded beyond repair.`n");
			   		}
				}
				if (get_module_pref("boots") && get_module_setting("loseboot")) {
					$chance = get_module_setting("losechance");
					$roll = e_rand(1,100);
					if ($roll<$chance){
						$id = get_module_pref("bootid");
						$sql = "SELECT * FROM " . db_prefix("magicitems") . " WHERE id=$id";
				    	$result = db_query($sql);
				   		$row = db_fetch_assoc($result);
				   		/*if ($row['attack']<>0) $session['user']['attack']-=$row['attack'];
				   		if ($row['defense']<>0) $session['user']['defense']-=$row['defense'];*/
				   		if ($row['charm']<>0) $session['user']['charm']-=$row['charm'];
				   		if( is_module_active( 'globalhp' ) && get_module_setting( 'carrydk', 'globalhp') )
				   			if ($row['hitpoints']<0) $session['user']['maxhitpoints']-=$row['hitpoints'];
				   		if ($row['turns']<>0) { 
					   		$session['user']['turns']-=$row['turns'];
				   			if (get_module_pref("turnadd")>0) {
					   		set_module_pref("turnadd",get_module_pref("turnadd")-$row['turns']);
							}	
						}
						if (get_module_pref("favor")<>0){
							set_module_pref("res",0);
							set_module_pref("favor",0);
							set_module_pref("favoradd",0);
						}
						$rare = FALSE;
						if ($row['rare']) $rare = $id;
						require_once("modules/mysticalshop/lib.php");
				   		mysticalshop_destroyitem("boot",$rare);
				   		output("`3You were sure you were wearing boots once.`n");
			   		}
		   		}
				if (get_module_pref("helm") && get_module_setting("losehelm")) {
					$chance = get_module_setting("losechance");
					$roll = e_rand(1,100);
					if ($roll<$chance){
						$id = get_module_pref("helmid");
						$sql = "SELECT * FROM " . db_prefix("magicitems") . " WHERE id=$id";
						$result = db_query($sql);
						$row = db_fetch_assoc($result);
						/*if ($row['attack']<>0) $session['user']['attack']-=$row['attack'];
						if ($row['defense']<>0) $session['user']['defense']-=$row['defense'];*/
						if ($row['charm']<>0) $session['user']['charm']-=$row['charm'];
						if( is_module_active( 'globalhp' ) && get_module_setting( 'carrydk', 'globalhp') )
							if ($row['hitpoints']<0) $session['user']['maxhitpoints']-=$row['hitpoints'];
						if ($row['turns']<>0) { 
							$session['user']['turns']-=$row['turns'];
							if (get_module_pref("turnadd")>0) {
							set_module_pref("turnadd",get_module_pref("turnadd")-$row['turns']);
							}	
						}
						if (get_module_pref("favor")<>0){
							set_module_pref("res",0);
							set_module_pref("favor",0);	
							set_module_pref("favoradd",0);		
						}
						$rare = FALSE;
						if ($row['rare']) $rare = $id;
						require_once("modules/mysticalshop/lib.php");
				   		mysticalshop_destroyitem("helm",$rare);
						output("`3You seem to have misplaced your helmet.`n");
					}
				}
				//you automatically lose your weapon/armor after a dragonkill anyways. 
				//so unset any stat-altering modifications here. No, I won't change this
				if (get_module_pref("weapon") == 1) {
					$id = get_module_pref("weaponid");
					$sql = "SELECT * FROM " . db_prefix("magicitems") . " WHERE id=$id";
					$result = db_query($sql);
					$row = db_fetch_assoc($result);
					if ($row['charm']<>0) $session['user']['charm']-=$row['charm'];
					if( is_module_active( 'globalhp' ) && get_module_setting( 'carrydk', 'globalhp') )
						if ($row['hitpoints']<0) $session['user']['maxhitpoints']-=$row['hitpoints'];
					if ($row['turns']<>0) { 
						$session['user']['turns']-=$row['turns'];
						if (get_module_pref("turnadd")>0) {
							set_module_pref("turnadd",get_module_pref("turnadd")-$row['turns']);
						}	
					}
					if (get_module_pref("favor")<>0){
							set_module_pref("res",0);
							set_module_pref("favor",0);
							set_module_pref("favoradd",0);
					}		
					$rare = FALSE;
					if ($row['rare']) $rare = $id;
					require_once("modules/mysticalshop/lib.php");
				   	mysticalshop_destroyitem("weapon",$rare);
				}
				if (get_module_pref("armor") == 1) {
					$id = get_module_pref("ringid");
					$sql = "SELECT * FROM " . db_prefix("magicitems") . " WHERE id=$id";
					$result = db_query($sql);
					$row = db_fetch_assoc($result);
					if ($row['charm']<>0) $session['user']['charm']-=$row['charm'];
					if( is_module_active( 'globalhp' ) && get_module_setting( 'carrydk', 'globalhp') )
						if ($row['hitpoints']<0) $session['user']['maxhitpoints']-=$row['hitpoints'];
					if ($row['turns']<>0) { 
						$session['user']['turns']-=$row['turns'];
						if (get_module_pref("turnadd")>0) {
							set_module_pref("turnadd",get_module_pref("turnadd")-$row['turns']);
						}	
					}
					if (get_module_pref("favor")<>0){
						set_module_pref("res",0);
						set_module_pref("favor",0);
						set_module_pref("favoradd",0);
					}
						$rare = FALSE;
						if ($row['rare']) $rare = $id;
						require_once("modules/mysticalshop/lib.php");
				   		mysticalshop_destroyitem("armor",$rare);
				}
				if (get_module_pref("misc") && get_module_setting("losemisc")) {
					$chance = get_module_setting("losechance");
					$roll = e_rand(1,100);
					if ($roll<$chance) {
						$id = get_module_pref("miscid");
						$sql = "SELECT * FROM " . db_prefix("magicitems") . " WHERE id=$id";
						$result = db_query($sql);
						$row = db_fetch_assoc($result);
						/*if ($row['attack']<>0) $session['user']['attack']-=$row['attack'];
						if ($row['defense']<>0) $session['user']['defense']-=$row['defense'];*/
						if ($row['charm']<>0) $session['user']['charm']-=$row['charm'];
						if( is_module_active( 'globalhp' ) && get_module_setting( 'carrydk', 'globalhp') )
							if ($row['hitpoints']<0) $session['user']['maxhitpoints']-=$row['hitpoints'];
						if ($row['turns']<>0) {
							$session['user']['turns']-=$row['turns'];
							if (get_module_pref("turnadd")>0) {
							set_module_pref("turnadd",get_module_pref("turnadd")-$row['turns']);
							}	
						}
						if (get_module_pref("favor")<>0){
							set_module_pref("res",0);
							set_module_pref("favor",0);
							set_module_pref("favoradd",0);
						}
						$rare = FALSE;
						if ($row['rare']) $rare = $id;
						require_once("modules/mysticalshop/lib.php");
				   		mysticalshop_destroyitem("misc",$rare);
						output("`3You seem to have lost the extra item you were carrying.`n");
					}
				}

// --------------------------------Restore Stats--------------------------------
			if( ( get_module_setting( 'restoreAll' ) && get_module_pref( 'restoreIndiv' ) == 0 )
				|| get_module_pref( 'restoreIndiv' ) == 1 ) // User setting overrides global
			{
				$buffs = array( 'attack'=>'attack', 'defense'=>'defense', 'turns'=>'turns', 'favor'=>'deathpower' );
				if( !is_module_active( 'globalhp' ) || !get_module_setting( 'carrydk', 'globalhp') )
					$buffs['hitpoints'] = 'maxhitpoints'; // don't re-add hitpoints if they are not reset at DK
				// Charm doesn't get reset at DK, no need to restore it.
			  require_once("modules/mysticalshop/lib.php");
			  applyenh( $buffs, false );
			}
//------------------------------------------------------------------------------
				
			if (get_module_pref("turnadd")<0) set_module_pref("turnadd",0);
			if ($session['user']['hitpoints'] < 1) $session['user']['hitpoints']=1; // really... checking for <0 and setting to 1?
?>