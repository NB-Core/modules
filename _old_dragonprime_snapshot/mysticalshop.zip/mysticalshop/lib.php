<?php
function applyenh( $buffs, $args = false )
{
	global $session;
	$userid = httpget( 'userid' );

  $favor = 0;
  $turns = 0;

	$sql = 'SELECT * FROM '.db_prefix( 'magicitems' );
	if( !$args )
		$sql .= ( $session['user']['specialty'] == 'MN' ? " WHERE category!='2' AND category!='3'" : '' );
 	else
		output( '`n`&Applying enhancements for all items named below (if any):`n' );
	$items = db_query( $sql );

	$itemcats = array( 'ring', 'amulet', 'weapon', 'armor', 'cloak', 'helm', 'glove', 'boot', 'misc' );

	while( $values = db_fetch_assoc( $items ) )
	{
		$cat = $itemcats[ $values['category'] ];
		$plural = ($cat == 'boot') ? 's' : ''; // inconsistent naming... sigh

		$isOwned = $args ? $args[ $cat.$plural ] && ( $args[$cat.'id'] == $values['id'] )
				: get_module_pref( $cat.$plural )	&& ( get_module_pref( $cat.'id' ) == $values['id'] );
		if( $isOwned )
		{
			output( "`n`!The magic in your `^%s`! begins to affect some of your abilities...`n", $values['name'] );

			if( !$args )
				set_module_pref( $cat.'name', $values['name'] );
			else
				$args[$cat.'name'] = $values['name'];

			foreach( $buffs as $buffInPrefs=>$buff )
			{
				if( $values[$buffInPrefs] != 0 )
				{
					if( !$args )
						$session['user'][$buff] += $values[$buffInPrefs];
					else
					{
						output( "...%s change: %s`n", $buffInPrefs, $values[$buffInPrefs] );
						$sql = "UPDATE ".db_prefix( 'accounts' )." SET $buff=$buff+{$values[$buffInPrefs]} WHERE acctid=$userid";
						db_query($sql);
					}
					
					if( $buffInPrefs == 'favor' )
						$favor += $values[$buffInPrefs];
					else if( $buffInPrefs == 'turns' )
					  $turns += $values[$buffInPrefs];
				}
			}

		  if( !$args )
		  {
				if( $favor != 0 )
				{
					set_module_pref( 'favor', true );
					set_module_pref( 'res', 0 );
				}
				else
					set_module_pref( 'favor', false );

				set_module_pref( 'turnadd',  $turns );
				set_module_pref( 'favoradd',  $favor );
			}
			else
			{
				if( $favor != 0 )
				{
					$args['favor'] = true;
					$args['res'] = 0;
				}
				else
					$args['favor'] = false;

				$args['turnadd'] = $turns;
				$args['favoradd'] = $favor;
			}
		}
	}
	return $args;
}
function mysticalshop_destroyitem($item_type,$rare_id = FALSE, $userid = FALSE){
	global $session;
	$id = "";
	if ($userid === FALSE){
		$userid = $session['user']['acctid'];
		$id = get_module_pref($item_type."id","mysticalshop",$userid);
	}
	modulehook("mysticalshop-destroyitem",array("itemid"=>$id));
	if ($rare_id){
		$sql = "UPDATE ".db_prefix("magicitems")." SET rarenum=rarenum+1 WHERE id='$rare_id'";
		db_query($sql);
	}
	
	$item_has = $item_type;
	if ($item_type == "boot") $item_has = "boots";
	
	$id = FALSE;
	set_module_pref($item_type,0,"mysticalshop",$userid);
	set_module_pref($item_type."id",0,"mysticalshop",$userid);
	set_module_pref($item_type."name","None","mysticalshop",$userid);
}
?>