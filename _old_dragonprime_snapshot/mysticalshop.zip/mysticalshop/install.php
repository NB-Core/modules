<?php
	$magic_items = array(
		'id'=>array('name'=>'id', 'type'=>'int(11) unsigned',	'extra'=>'not null auto_increment'),
		'category'=>array('name'=>'category', 'type'=>'int unsigned', 'default'=>'0', 'extra'=>'not null'),
		'name'=>array('name'=>'name', 'type'=>'varchar(50)','default'=>'None', 'extra'=>'not null'),
		'description'=>array('name'=>'description', 'type'=>'text', 'extra'=>'not null'),
		'gold'=>array('name'=>'gold', 'default'=>'0', 'type'=>'int(11) unsigned', 'extra'=>'not null'),
		'gems'=>array('name'=>'gems', 'default'=>'0', 'type'=>'int(11) unsigned', 'extra'=>'not null'),
		'dk'=>array('name'=>'dk', 'type'=>'int(11)', 'default'=>'0', 'extra'=>'not null'),
		'attack'=>array('name'=>'attack', 'type'=>'varchar(11)', 'default'=>'0', 'extra'=>'not null'),
		'defense'=>array('name'=>'defense', 'type'=>'varchar(11)', 'default'=>'0', 'extra'=>'not null'),
		'charm'=>array('name'=>'charm', 'type'=>'varchar(11)', 'default'=>'0', 'extra'=>'not null'),
		'hitpoints'=>array('name'=>'hitpoints', 'type'=>'varchar(11)', 'default'=>'0', 'extra'=>'not null'),
		'turns'=>array('name'=>'turns', 'type'=>'varchar(11)', 'default'=>'0', 'extra'=>'not null'),
		'favor'=>array('name'=>'favor', 'type'=>'varchar(11)', 'default'=>'0', 'extra'=>'not null'),
		'bigdesc'=>array('name'=>'bigdesc', 'type'=>'text', 'extra'=>'not null'),
		'align'=>array('name'=>'align', 'type'=>'varchar(11)', 'default'=>'0', 'extra'=>'not null'),
		'odor'=>array('name'=>'odor', 'type'=>'varchar(11)', 'default'=>'0', 'extra'=>'not null'),
		'hunger'=>array('name'=>'hunger', 'type'=>'varchar(11)', 'default'=>'0', 'extra'=>'not null'),
		'rare'=>array('name'=>'rare', 'type'=>'tinyint(3)', 'default'=>'0', 'extra'=>'not null'),
		'rarenum'=>array('name'=>'rarenum', 'type'=>'int(11)', 'default'=>'0', 'extra'=>'not null'),
		'key-PRIMARY'=>array('name'=>'PRIMARY', 'type'=>'primary key',	'unique'=>'1', 'columns'=>'id'),
		'index-id'=>array('name'=>'id', 'type'=>'index', 'columns'=>'id'),
		'index-category'=>array('name'=>'category', 'type'=>'index', 'columns'=>'category'),
	);
	require_once("lib/tabledescriptor.php");
	synctable(db_prefix('magicitems'), $magic_items, true);
	module_addhook("superuser");
	module_addhook("village");
	module_addhook("dragonkill");
	module_addhook("newday");
	module_addhook("lodge");
	module_addhook("charstats");
	module_addhook("changesetting");
	module_addhook("training-victory");
	module_addhook("bioinfo");
	module_addhook("validateprefs");
?>