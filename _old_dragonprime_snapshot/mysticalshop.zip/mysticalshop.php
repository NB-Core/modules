<?php
/**************
Name: Equipment Shop
Author: Eth - ethstavern(at)gmail(dot)com 
Version: 3.5
Re-Release Date: 03-26-2006
About: A shop that sells a wide array of different items.
       Complete with editor and separate table in db.
Translation compatible. Mostly.
*****************/

function mysticalshop_getmoduleinfo(){
	require_once("modules/mysticalshop/getmoduleinfo.php");
	return $info;
}
function mysticalshop_install(){
	require_once("modules/mysticalshop/install.php");
	return true;
}
function mysticalshop_uninstall(){
	$sql = "DROP TABLE IF EXISTS " . db_prefix("magicitems");
	db_query($sql);
	return true;
}
function mysticalshop_dohook($hookname,$args){
	global $session;
	$from = "runmodule.php?module=mysticalshop&";
	require("modules/mysticalshop/dohook/$hookname.php");
	return $args;
}
function mysticalshop_run(){
	global $session;
	$shop = get_module_setting("shopname");
	$op = httpget('op');
	$from = "runmodule.php?module=mysticalshop&";
	page_header("$shop");
	$what = httpget('what');
	$cat = httpget('cat');
	$names = array(0=>'Ring',1=>'Amulet',2=>'Weapon',3=>'Armor',4=>'Cloak',5=>'Helmet',6=>'Gloves',7=>'Boots',8=>'Miscellaneous');
	require_once("modules/mysticalshop/run/case_$op.php");
	page_footer();
}
?>