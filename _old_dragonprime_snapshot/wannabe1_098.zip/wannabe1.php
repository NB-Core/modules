<?php
/* 
Wannabe Knight 
Written by Robert of MaddRio dot com
-> If you want the debuglog entry to show exp, you need to uncomment it.
*/
function wannabe1_getmoduleinfo(){
	$info = array(
	"name"=>"Wannabe Knight 1",
	"version"=>"1.1",
	"author"=>"`2Robert",
	"category"=>"Forest Specials",
	"download"=>"http://dragonprime.net/users/robert/wannabe1_098.zip",
	);
	return $info;
}

function wannabe1_install(){
	module_addeventhook("forest","return 100;");
	return true;
}

function wannabe1_uninstall(){
	return true;
}

function wannabe1_dohook($hookname,$args){
	return $args;
}

function wannabe1_runevent($type){
	global $session;
	$exp = round($session['user']['experience']*.02);
	output("`n`n`2 You have come across a `b`4Wannabe Knight`b `2who attack's you with his Battle Axe. `n`n");
    output(" `iYou are quick!`i Your `b%s`b `2protects you and are not injured. `n`n",$session['user']['armor']);
    output(" You fight with the `b`4Wannabe Knight`b `2until he turns and runs away! `n`n");
    output("`& You think to yourself there must be a clan of wannabe near here. `n");
    output("` ^You have gained %s experience for this encounter. ",$exp);
    $session['user']['alive']=true;
    $session['user']['experience']+=$exp;
//  debuglog("encountered the Wannabe Knight and got $val experience");
}

function wannabe1_run(){
}
?>