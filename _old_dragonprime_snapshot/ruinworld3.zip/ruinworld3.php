<?php
/*
Module Name:  ruinworld3.php
Category:  Forest/LostRuins Addon
Worktitle:  Ruin World 3: The Pyramid
Author:  DaveS
Date:  July 29, 2006
Based on the code for Abandoned Castle by Lonnyl. If you�ve ever played the game �Temple of Apshai�, 
you may notice where I got my inspiration for this module from.

Works as one of the locations that can be discovered in the Lost Ruins.  Also, can be encountered in the forest.

Description:
You�ve discovered a pyramid! Will you dare to enter and explore?
The final installment of the Ruin World modules to supplement the Lost Ruins is here!

This is a graphics based module where the character wanders around a pyramid.  After finding the entrance, 
they can travel into the Deep Chamber to an altar.  Receive different blessings based on your sacrifice.

This is a no-risk module (no monsters, no negative consequences) so consider lowering the chance of it 
happening randomly in the forest in addition to adjusting the minimum dks needed for the module.
*/
function ruinworld3_getmoduleinfo(){
	$info = array(
		"name"=>"Ruin World 3: The Pyramid",
		"version"=>"3.0",
		"author"=>"DaveS and MaryAnn",
		"category"=>"Forest Specials",
		"download"=>"",
		"settings"=>array(
			"Ruin world 3: The Pyramid,title",
			"mindk"=>"Minimum dks for player to find the Pyramid in the forest:,int|11",
			"forest"=>"Chance to encounter in the forest:,range,5,100,5|50",
		),
		"prefs"=>array(
			"Ruin World 3: The Pyramid,title",
			"encountered"=>"Has player been to the Pyramid today?,bool|0",
			"Map Notes,title",
			"enter"=>"Where is the entrance to the pyramid?,int|0",
			"return"=>"Is player ready to return?,bool|0",
			"loc8"=>"Has player approached the altar?,bool|0",
			"sacrifice"=>"Has the player made a sacrifice?,bool|0",
			"loc1"=>"Has player been to the urn?,enum,0,No,1,Kept Rags,2,Kept Gold,3,Kept Gem,4,Seen It|0",
			"maze"=>"Pyramid Maze,viewonly|",
			"mazeturn"=>"Pyramid Turns,viewonly|0",
			"pqtemp"=>"Temporary Information,int|",
		),
	);
	return $info;
}
function ruinworld3_chance() {
	global $session;
	$ret= get_module_setting('forest','ruinworld3');
	if ($session['user']['dragonkills']<get_module_setting("mindk","ruinworld3")||get_module_pref("encountered","ruinworld3",$session['user']['acctid'])==1) $ret=0;
	return $ret;
}
function ruinworld3_install(){
	module_addeventhook("forest","require_once(\"modules/ruinworld3.php\");
	return ruinworld3_chance();");
	module_addhook("newday");	
	return true;
}
function ruinworld3_uninstall(){
	return true;
}
function ruinworld3_dohook($hookname,$args){
	global $session;
	switch($hookname){
		case "newday":
			set_module_pref("encountered",0);
		break;
	}
	return $args;
}
function ruinworld3_runevent($type) {
	redirect("runmodule.php?module=ruinworld3&op=enter1");
}
function ruinworld3_run(){
	global $SCRIPT_NAME;
	if ($SCRIPT_NAME == "runmodule.php"){
		$module=httpget("module");
		if ($module == "ruinworld3"){
			include("modules/ruinworld3/ruinworld3.php");
		}
	}
}
?>