<?php
	global $session;
	$op = httpget('op');
	$op2 = httpget('op2');
	$op3 = httpget('op3');
	page_header("The Pyramid");
	output("`^`c`bThe Pyramid`c`b`0`n");
	$enter=get_module_pref("enter");

if ($op=="enter"){
	set_module_setting("ruin3found",0,"lostruins");
	redirect("runmodule.php?module=ruinworld3&op=enter1");
}

if ($op=="enter1"){
	output("You step into an opening and a blast of heat hits you.  It seems you've been transported to a desert-like environment.");
	output("`n`nYou take a couple of steps and feel a little unsteady on your feet.  Looking down, you see that you're walking on sand.");
	output("`n`nLooking up, you suddenly see a huge pyramid before you.");
	$session['user']['specialinc']="module:ruinworld3";
	set_module_pref("encountered",1);
	addnav("Continue","runmodule.php?module=ruinworld3&op=pyramid");	
}

$knownmonsters = array('trap','mummy','miner','bear','player','cavetroll','toothy','welltroll');
if (in_array($op, $knownmonsters) || $op == "fight") {
	ruinworld3_fight($op);
	die;
}
if ($op=="entrance"){
	output("You find a secret entrance to the pyramid!");
	output("Will you brave the unknown?");
	addnav("Enter the Pyramid","runmodule.php?module=ruinworld3&op=pyramid2");	
	addnav("Leave","runmodule.php?module=ruinworld3&op=pyramid");
}
if ($op=="chamber"){
	output("You've found the Deep Chamber of the Pyramid.");
	set_module_pref("return",1);
	addnav("Continue","runmodule.php?module=ruinworld3&op=pyramid3");
	addnav("Turn Back","runmodule.php?module=ruinworld3&op=pyramid2");
}
if ($op=="leavepyramid4"){
	output("Are you ready to Leave the Pyramid?");
	set_module_pref("return",1);
	addnav("Leave","runmodule.php?module=ruinworld3&op=pyramid2");
	addnav("Go Back","runmodule.php?module=ruinworld3&op=pyramid3");
}
if ($op=="leavepyramid"){
	output("You turn to leave and suddenly you're enveloped in a thick mist. You take another step and realize that you're");
	$session['user']['specialinc']="";
	clear_module_pref("maze");
	clear_module_pref("mazeturn");
	clear_module_pref("pqtemp");
	set_module_pref("enter",0);
	set_module_pref("loc1",0);
	set_module_pref("loc8",0);
	set_module_pref("return",0);
	set_module_pref("sacrifice",0);
	if (is_module_active("metalmine")){
		output("just outside of the `&Metal `)Mine`0!");
		addnav("Continue","runmodule.php?module=metalmine&op=enter");
	}else{
		output("back in the `@Forest`3.");
		addnav("To the Forest","forest.php");
	}
}
if ($op=="loc8"){
	set_module_pref("loc8",1);
	output("You find yourself standing before an altar.");
	output("`n`nYou have several options at this time:");
	output("`n`n1. Leave the Altar");
	output("`n`^2.  Make an offering of gold");
	output("`n`%3. Make an offering of a gem");
	addnav("The Altar");
	addnav("Leave","runmodule.php?module=ruinworld3&op=pyramid3&loc=8");
	addnav("Offer `^Gold","runmodule.php?module=ruinworld3&op=altar&op2=gold");
	addnav("Offer a `%Gem","runmodule.php?module=ruinworld3&op=altar&op2=gem");
	if (get_module_pref("loc1")==1){
		output("`n`#4. Offer the Urn Contents");
		addnav("Offer `#Rags","runmodule.php?module=ruinworld3&op=altar&op2=rags");
	}
}
if ($op=="loc1"){
	set_module_pref("loc1",4);
	output("You find an `\$U`6r`\$n`0 in the corner.  What would you like to do?");
	addnav("Break the `\$U`6r`\$n","runmodule.php?module=ruinworld3&op=break");
	addnav("Leave the `\$U`6r`\$n","runmodule.php?module=ruinworld3&op=pyramid3&loc=1");
}
if ($op=="break"){
	output("You break the `\$U`6r`\$n`0 and notice a bunch of `#rags`0.  A glimmer of `^gold`0 catches your eye and then you also see a `%gem`0.");
	output("`n`nUnfortunately, the contents of the `\$U`6r`\$n`0 are falling into the sand and you only have a chance to grab one of them. What will you do?");
	addnav("The Urn");
	addnav("Grab `^Gold","runmodule.php?module=ruinworld3&op=urngrab&op2=gold");
	addnav("Grab the `%Gem","runmodule.php?module=ruinworld3&op=urngrab&op2=gem");
	addnav("Grab the `#Rags","runmodule.php?module=ruinworld3&op=urngrab&op2=rags");
}
if ($op=="urngrab"){
	output("You make a grab for the");
	if ($op2=="gold"){
		set_module_pref("loc1",2);
		$gold=e_rand(250,350);
		$session['user']['gold']+=$gold;
		output("`^gold.`0`n`nYou've managed to grab `^%s gold`0",$gold);
	}
	if($op2=="gem"){
		set_module_pref("loc1",3);
		$session['user']['gems']++;
		output("`%gem`0.`n`nYou catch the `%gem`0");
	}
	if ($op2=="rags"){
		set_module_pref("loc1",1);
		output("rags and find yourself holding a bunch of useless old `#rags`0.`n`nYou suddenly have deep regrets for not grabbing the `^gold`0 or `%gem`0.  You stand there holding your `#rags`0");
	}
	output("and watch as everything else sinks into the sand.");
	addnav("Continue","runmodule.php?module=ruinworld3&op=pyramid3&loc=1");
}
if ($op=="altar"){
	output("You place");
	if ($op2=="gold"){
		if ($session['user']['gold']<250) redirect("runmodule.php?module=ruinworld3&op=altar2&op2=gold");
		else {
			output("`^250 gold pieces");
			$session['user']['gold']-=250;
			$low=2;
			$high=11;
			set_module_pref("sacrifice",1);
		}
	}
	if ($op2=="gem"){
		if ($session['user']['gems']<1) redirect("runmodule.php?module=ruinworld3&op=altar2&op2=gem");
		else {
			output("a `%gem"); 
			$session['user']['gems']--;
			$low=1;
			$high=10;
			set_module_pref("sacrifice",1);
		}
	}
	if ($op2=="rags"){
		output("the `#rags");
		$low=6;
		$high=15;
		set_module_pref("sacrifice",1);
	}
	output("`0on the altar and wait for something to happen.`n`nYour sacrifice is consumed in a huge ball of flame.");
	switch(e_rand($low,$high)){
		case 1: case 2: case 3:	case 4: case 5:
			output("You look up, waiting for a blessing to come upon you, but nothing happens.");
		break;
		case 6:
		case 7:
		case 8:
		case 9:
		case 10:
			output("You feel that the Gods have blessed you.");
			apply_buff('altarblessing',array(
				"name"=>"`^High Blessing",
				"rounds"=>30,
				"atkmod"=>1.1,
				"defmod"=>1.1,
				"roundmsg"=>"The Power of the Blessing gives you strength.",
			));
		break;
		case 11:
		case 12:
		case 13:
		case 14:
		case 15:
			$gold=e_rand(500,700);
			$session['user']['gold']+=$gold;
			$session['user']['gems']+=2;
			output("You feel that the Gods have blessed you. Not only have you received a new buff, but you also notice treasure on the altar.");
			output("You collect `^%s gold`0 and `%2 gems`0!",$gold);
			apply_buff('altarblessing',array(
				"name"=>"`^High Blessing",
				"rounds"=>30,
				"atkmod"=>1.1,
				"defmod"=>1.1,
				"roundmsg"=>"`^The Power of the Blessing gives you strength.",
			));
		break;
	}
	addnav("Continue","runmodule.php?module=ruinworld3&op=pyramid3&loc=8");
}
if ($op=="altar2"){
	output("You don't have");
	if ($op2=="gold") output("enough `^gold");
	else output("a `%gem");
	output("`0 to sacrifice to the altar.");
	if ($op2=="gold") output("You would need at least `^250 gold`0 for something to happen.");
	addnav("Continue","runmodule.php?module=ruinworld3&op=pyramid3&loc=8");
}
if ($op=="pyramid"){
	$locale = httpget('loc');
	if ($session['user']['hitpoints'] <= 0) redirect("shades.php");
	$umaze = get_module_pref('maze');
	$umazeturn = get_module_pref('mazeturn');
	$upqtemp = get_module_pref('pqtemp');
	if ($op2 == "" && $locale == "") {
		//Make the entrance:
		set_module_pref("return",0);
		if (get_module_pref("enter")==0){
			$locale=43;
			$chance=e_rand(1,4);
			if ($chance==1) set_module_pref('enter',46);
			elseif ($chance==2) set_module_pref('enter',28);
			elseif ($chance==3) set_module_pref('enter',22);
			else set_module_pref('enter',4);
		}else $locale=get_module_pref("enter");
		$umazeturn = 0;
		set_module_pref("mazeturn", 0);
		if (!isset($maze)){
			$maze = array(6,10,10,10,10,10,7,5,56,53,53,53,57,5,5,51,56,53,57,52,5,5,51,51,58,52,52,5,5,51,54,50,55,52,5,5,54,50,50,50,55,5,8,10,10,10,10,10,9);
			$umaze = implode($maze,",");
			set_module_pref("maze", $umaze);
		}
	}
	if ($op2 <> ""){
		if ($op2 == "n") {
			$locale+=7;
			redirect("runmodule.php?module=ruinworld3&op=pyramid&loc=$locale");
		}
		if ($op2 == "s"){
			$locale-=7;
			redirect("runmodule.php?module=ruinworld3&op=pyramid&loc=$locale");
		}
		if ($op2 == "w"){
			$locale-=1;
			redirect("runmodule.php?module=ruinworld3&op=pyramid&loc=$locale");
		}
		if ($op2 == "e"){
			$locale+=1;
			redirect("runmodule.php?module=ruinworld3&op=pyramid&loc=$locale");
		}
	}else{
		if ($locale <> ""){
			$maze=explode(",", $umaze);
			if ($locale=="") $locale = $upqtemp;
			$upqtemp = $locale;
			set_module_pref("pqtemp", $upqtemp);
			for ($i=0;$i<$locale-1;$i++){
			}
			$navigate=ltrim($maze[$i]);
			output("`7");
			if ($session['user']['hitpoints'] > 0){
				addnav("Leave the pyramid","runmodule.php?module=ruinworld3&op=leavepyramid");

				if($locale=="27" || $locale=="23" || $locale=="11" || $locale=="39") redirect("runmodule.php?module=ruinworld3&op=entrance");

				output("`cYou may go");
				$umazeturn++;
				set_module_pref('mazeturn', $umazeturn);
				$navcount = 0;
				$north=translate_inline("North");
				$south=translate_inline("South");
				$east=translate_inline("East");
				$west=translate_inline("West");
				$directions="";
				if ($navigate=="5" or $navigate=="6"or $navigate=="7" or ($locale==get_module_pref("enter") && $locale==4)) {
					addnav("North","runmodule.php?module=ruinworld3&op=pyramid&op2=n&loc=$locale");
					$directions.=" $north";
					$navcount++;
				}
				if ($navigate=="5" or $navigate=="8"or $navigate=="9" or ($locale==get_module_pref("enter") && $locale==46)) {
					addnav("South","runmodule.php?module=ruinworld3&op=pyramid&op2=s&loc=$locale");
					$navcount++;
					if ($navcount > 1) $directions.=",";
					$directions.=" $south";
				}
				if ($navigate=="7" or $navigate=="9"or $navigate=="10" or ($locale==get_module_pref("enter") && $locale==28)) {
					addnav("West","runmodule.php?module=ruinworld3&op=pyramid&op2=w&loc=$locale");
					$navcount++;
					if ($navcount > 1) $directions.=",";
					$directions.=" $west";
				}
				if ($navigate=="6" or $navigate=="8"or $navigate=="10" or ($locale==get_module_pref("enter") && $locale==22)) {
						addnav("East","runmodule.php?module=ruinworld3&op=pyramid&op2=e&loc=$locale");
					$navcount++;
					if ($navcount > 1) $directions.=",";
					$directions.=" $east";
				}
				output_notl(" %s.`c",$directions);				
			}else{
				addnav("Continue","shades.php");
			}
			$mazemap=$navigate;
			$mazemap.="maze.gif";
			output_notl("`n`c");
			rawoutput("<small>");
			$mapkey2="<table style=\"height: 230px; width: 210px; text-align: left;\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\"><tbody><tr><td style=\"vertical-align: top;\">";
			$mapkey="";
			for ($i=0;$i<49;$i++){
				$keymap=ltrim($maze[$i]);
				$mazemap=$keymap;
				$mazemap.="maze.gif";
				if ($i==$locale-1){
					$mapkey.="<img src=\"./modules/ruinworld3img/mcyan.gif\" title=\"\" alt=\"\" style=\"width: 50px; height: 50px;\">";
				}else{
					$mapkey.="<img src=\"./modules/ruinworld3img/$mazemap\" title=\"\" alt=\"\" style=\"width: 50px; height: 50px;\">";
				}
				if ($i==6 or $i==13 or $i==20 or $i==27 or $i==34 or $i==41 or $i==48){
					$mapkey="`n".$mapkey;
					$mapkey2=$mapkey.$mapkey2;
					$mapkey="";
				}
			}
			$mapkey2.="</td></tr></tbody></table>";
			output_notl($mapkey2,true);
			output_notl("`c");
		}
	}
}
if ($op=="pyramid2"){
	$locale = httpget('loc');
	if ($session['user']['hitpoints'] <= 0) redirect("shades.php");
	$umaze = get_module_pref('maze');
	$umazeturn = get_module_pref('mazeturn');
	$upqtemp = get_module_pref('pqtemp');
	if ($op2 == "" && $locale == "") {
		//Going North/South
		if ($enter==46 || $enter==4){
			if (get_module_pref("return")==1){
				if ($enter==46) $enter=4;
				else $enter=46;
			}
			$umazeturn = 0;
			set_module_pref("mazeturn", 0);
			if ($enter==4) $locale=2;
			if ($enter==46) $locale=14;
			if (!isset($maze)){
				$maze = array(16,5,16,16,5,16,16,5,16,16,5,16,16,5,16);
				$umaze = implode($maze,",");
				set_module_pref("maze", $umaze);
			}
		}
		//Going East/West
		if ($enter==28 || $enter==22){
			if (get_module_pref("return")==1){
				if ($enter==28) $enter=22;
				else $enter=28;
			}
			$umazeturn = 0;
			set_module_pref("mazeturn", 0);
			if ($enter==22) $locale=6;
			if ($enter==28) $locale=10;
			if (!isset($maze)){
				$maze = array(16,16,16,16,16,10,10,10,10,10,16,16,16,16,16);
				$umaze = implode($maze,",");
				set_module_pref("maze", $umaze);
			}
		}
	}
	if ($op2 <> ""){
		if ($op2 == "n") {
			$locale+=3;
			redirect("runmodule.php?module=ruinworld3&op=pyramid2&loc=$locale");
		}
		if ($op2 == "s"){
			$locale-=3;
			redirect("runmodule.php?module=ruinworld3&op=pyramid2&loc=$locale");
		}
		if ($op2 == "w"){
			$locale--;
			redirect("runmodule.php?module=ruinworld3&op=pyramid2&loc=$locale");
		}
		if ($op2 == "e"){
			$locale++;
			redirect("runmodule.php?module=ruinworld3&op=pyramid2&loc=$locale");
		}
	}else{
		if ($locale <> ""){
			$maze=explode(",", $umaze);
			if ($locale=="") $locale = $upqtemp;
			$upqtemp = $locale;
			set_module_pref("pqtemp", $upqtemp);
			for ($i=0;$i<$locale-1;$i++){
			}
			$navigate=ltrim($maze[$i]);
			output("`7");
			if ($session['user']['hitpoints'] > 0){
				addnav("The Pyramid");
				if ($enter==46 && $locale=="14" || $enter==4 && $locale=="2" || $enter==22 && $locale=="6" || $enter==28 && $locale=="10") addnav("Leave the pyramid","runmodule.php?module=ruinworld3&op=pyramid");

				if($enter==46 && $locale=="-1" || $enter==4 && $locale=="17" || $enter==22 && $locale=="11" || $enter==28 && $locale=="5") redirect("runmodule.php?module=ruinworld3&op=chamber");
				if ($navigate=="5") {
					if ($enter==46 && $locale==14){
					}else{
						addnav("North","runmodule.php?module=ruinworld3&op=pyramid2&op2=n&loc=$locale");
					}
					if ($enter==4 && $locale==2){
					}else{
						addnav("South","runmodule.php?module=ruinworld3&op=pyramid2&op2=s&loc=$locale");
					}
				}
				if ($navigate=="10") {
					if ($enter==22 && $locale==6){
					}else{
						addnav("West","runmodule.php?module=ruinworld3&op=pyramid2&op2=w&loc=$locale");
					}
					if ($enter==28 && $locale==10){
					}else{
						addnav("East","runmodule.php?module=ruinworld3&op=pyramid2&op2=e&loc=$locale");
					}
				}			
			}else{
				addnav("Continue","shades.php");
			}
			$mazemap=$navigate;
			$mazemap.="maze.gif";
			output_notl("`n`c");
			rawoutput("<small>");
			$mapkey2="<table style=\"height: 230px; width: 230px; text-align: left;\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\"><tbody><tr><td style=\"vertical-align: top;\">";
			$mapkey="";
			
			for ($i=0;$i<15;$i++){
				$keymap=ltrim($maze[$i]);
				$mazemap=$keymap;
				$mazemap.="maze.gif";
				if ($i==$locale-1){
					$mapkey.="<img src=\"./modules/ruinworld3img/mcyan.gif\" title=\"\" alt=\"\" style=\"width: 50px; height: 50px;\">";
				}else{
					$mapkey.="<img src=\"./modules/ruinworld3img/$mazemap\" title=\"\" alt=\"\" style=\"width: 50px; height: 50px;\">";
				}
				if ((($enter==46 || $enter==4) && ($i==2 or $i==5 or $i==8 or $i==11 or $i==14))||(($enter==22 || $enter==28) && ($i==4 or $i==9 or $i==14))) {
					$mapkey="`n".$mapkey;
					$mapkey2=$mapkey.$mapkey2;
					$mapkey="";
				}
			}
			$mapkey2.="</td></tr></tbody></table>";
			output_notl($mapkey2,true);
			output_notl("`c");
		}
	}
}
if ($op=="pyramid3"){
	$locale = httpget('loc');
	if ($session['user']['hitpoints'] <= 0) redirect("shades.php");
	$umaze = get_module_pref('maze');
	$umazeturn = get_module_pref('mazeturn');
	$upqtemp = get_module_pref('pqtemp');
	if ($op2 == "" && $locale == "") {
		$locale=14;
		$umazeturn = 0;
		set_module_pref("mazeturn", 0);
		if (!isset($maze)){
			$maze = array(60,68,62,71,69,72,66,73,67,64,70,63,16,65,16);
			$umaze = implode($maze,",");
			set_module_pref("maze", $umaze);
		}
	}
	if ($op2 <> ""){
		if ($op2 == "n") {
			$locale+=3;
			redirect("runmodule.php?module=ruinworld3&op=pyramid3&loc=$locale");
		}
		if ($op2 == "s"){
			$locale-=3;
			redirect("runmodule.php?module=ruinworld3&op=pyramid3&loc=$locale");
		}
		if ($op2 == "w"){
			$locale-=1;
			redirect("runmodule.php?module=ruinworld3&op=pyramid3&loc=$locale");
		}
		if ($op2 == "e"){
			$locale+=1;
			redirect("runmodule.php?module=ruinworld3&op=pyramid3&loc=$locale");
		}
	}else{
		if ($locale <> ""){
			$maze=explode(",", $umaze);
			if ($locale=="") $locale = $upqtemp;
			$upqtemp = $locale;
			set_module_pref("pqtemp", $upqtemp);
			for ($i=0;$i<$locale-1;$i++){
			}
			$navigate=ltrim($maze[$i]);
			output("`7");
			if ($session['user']['hitpoints'] > 0){
				if ($locale=="14") addnav("Leave the Chamber","runmodule.php?module=ruinworld3&op=leavepyramid4");
				if ($locale=="8"){
					if (get_module_pref("loc8")==0) redirect("runmodule.php?module=ruinworld3&op=loc8");
					elseif (get_module_pref("sacrifice")==0){
						addnav("The Altar");
						addnav("Offer `^Gold","runmodule.php?module=ruinworld3&op=altar&op2=gold");
						addnav("Offer a `%Gem","runmodule.php?module=ruinworld3&op=altar&op2=gem");
						if (get_module_pref("loc1")==1) addnav("Offer `#Rags","runmodule.php?module=ruinworld3&op=altar&op2=rags");
						addnav("Directions");
					}
				}
				if ($locale=="1"){
					if (get_module_pref("loc1")==0) redirect("runmodule.php?module=ruinworld3&op=loc1");
					if (get_module_pref("loc1")==4){
						addnav("The Urn");
						addnav("Break the `\$U`6r`\$n","runmodule.php?module=ruinworld3&op=break");
						addnav("Directions");
					}
				}
				output("`cYou may go");
				$umazeturn++;
				set_module_pref('mazeturn', $umazeturn);
				$navcount = 0;
				$north=translate_inline("North");
				$south=translate_inline("South");
				$east=translate_inline("East");
				$west=translate_inline("West");
				$directions="";
				if ($navigate=="61" || $navigate=="66" ||$navigate=="60" || $navigate=="67" ||$navigate=="72" || $navigate=="62" || $navigate=="70" ||$navigate=="73" ||$navigate=="71") {
					addnav("North","runmodule.php?module=ruinworld3&op=pyramid3&op2=n&loc=$locale");
					$directions.=" $north";
					$navcount++;
				}
				if ($navigate=="64" || $navigate=="66" || $navigate=="71" || $navigate=="70" || $navigate=="65" || $navigate=="63" || $navigate=="67" || $navigate=="72") {
					addnav("South","runmodule.php?module=ruinworld3&op=pyramid3&op2=s&loc=$locale");
					$navcount++;
					if ($navcount > 1) $directions.=",";
					$directions.=" $south";
				}
				if ($navigate=="63" || $navigate=="70" || $navigate=="67" || $navigate=="73" || $navigate=="68" ||$navigate=="62") {
					addnav("West","runmodule.php?module=ruinworld3&op=pyramid3&op2=w&loc=$locale");
					$navcount++;
					if ($navcount > 1) $directions.=",";
					$directions.=" $west";
				}
				if ($navigate=="64" || $navigate=="70" || $navigate=="66" || $navigate=="73" || $navigate=="60" || $navigate=="68") {
						addnav("East","runmodule.php?module=ruinworld3&op=pyramid3&op2=e&loc=$locale");
					$navcount++;
					if ($navcount > 1) $directions.=",";
					$directions.=" $east";
				}
				output_notl(" %s.`c",$directions);				
			}else{
				addnav("Continue","shades.php");
			}
			$mazemap=$navigate;
			$mazemap.="maze.gif";
			output_notl("`n`c");
			rawoutput("<small>");
			$mapkey2="<table style=\"height: 350px; width: 350px; text-align: left;\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\"><tbody><tr><td style=\"vertical-align: top;\">";
			$mapkey="";
			for ($i=0;$i<15;$i++){
				$keymap=ltrim($maze[$i]);
				$mazemap=$keymap;
				$mazemap.="maze.gif";
				if ($i==$locale-1){
					$mapkey.="<img src=\"./modules/ruinworld3img/mcyan.gif\" title=\"\" alt=\"\" style=\"width: 75px; height: 75px;\">";
				}else{
					if ($i==0 && get_module_pref("loc1")>0 && get_module_pref("loc1")<4){
						$mapkey.="<img src=\"./modules/ruinworld3img/61maze.gif\" title=\"\" alt=\"\" style=\"width: 75px; height: 75px;\">";
					}else{
						$mapkey.="<img src=\"./modules/ruinworld3img/$mazemap\" title=\"\" alt=\"\" style=\"width: 75px; height: 75px;\">";
					}
				}
				if ($i==2 or $i==5 or $i==8 or $i==11 or $i==14){
					$mapkey="`n".$mapkey;
					$mapkey2=$mapkey.$mapkey2;
					$mapkey="";
				}
			}
			$mapkey2.="</td></tr></tbody></table>";
			output_notl($mapkey2,true);
			output_notl("`c");
		}
	}
}
page_footer();
?>