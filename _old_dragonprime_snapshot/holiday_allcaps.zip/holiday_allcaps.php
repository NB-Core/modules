<?php
//http://www.derekarnold.net/capslockday/
function holiday_allcaps_getmoduleinfo(){
	$info = array(
		"name"=>"Holiday - ALL CAPS day",
		"version"=>"20051022",
		"author"=>"sixf00t4",
		"category"=>"Holiday Texts",
		"download"=>"http://dragonprime.net/users/sixf00t4/holiday_allcaps.zip",
		"settings"=>array(
			"ALL CAPS Day Settings,title",
			"activate"=>"Activation date (mm-dd)|10-22",
		),
		"prefs"=>array(
			"ALL CAPS Day User Preferences,title",
			"user_ignore"=>"Ignore ALL CAPS DAY text,bool|0",
		),
	);
	return $info;
}

function holiday_allcaps_install(){
	module_addhook("holiday");
	return true;
}

function holiday_allcaps_uninstall(){
	return true;
}

function holiday_allcaps_munge($in) {
	$out = $in;
	$out = strtoupper($out);
	$out = str_replace("`N","`n",$out);
	$out = str_replace("`B","`b",$out);
	$out = str_replace("`C","`c",$out);
	$out = str_replace("`I","`i",$out);
	$out = str_replace("`Q","`q",$out);	
	$out = str_replace("/ME","/me",$out);	
	return $out;
}

function holiday_allcaps_dohook($hookname,$args){
	switch($hookname){
	case "holiday":
		if(get_module_pref("user_ignore")) break;
		$mytime = get_module_setting("activate");
		list($amonth,$aday) = split("-", $mytime);
		$amonth = (int)$amonth;
		$aday = (int)$aday;
		$month = (int)date("m");
		$day = (int)date("d");
		if ($month == $amonth && $day == $aday) {
			$args['text'] = holiday_allcaps_munge($args['text']);
		}
		break;
	}
	return $args;
}

function holiday_allcaps_run(){

}
?>
