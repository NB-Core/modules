<?php
/*
* Change Filename To "racerobot.php"
* Modded From "Race -Troll" Written By "Eric Stevens"
* Buffs = +10 Attack
*/

function racerobot_getmoduleinfo(){
	$info = array(
		"name"=>"Race - Robot",
		"version"=>"1.0",
		"author"=>"Chris Thomas",
		"category"=>"Races",
		"download"=>"Http://www.scatinthehat.co.uk",
		"settings"=>array(
			"Robot Race Settings,title",
			"villagename"=>"Name for the robot village|01001010001",
			"minedeathchance"=>"Chance for Robots to die in the mine,range,0,100,1|90",
		),
	);
	return $info;
}

function racerobot_install(){
	module_addhook("chooserace");
	module_addhook("setrace");
	module_addhook("newday");
	module_addhook("villagetext");
	module_addhook("travel");
	module_addhook("charstats");
	module_addhook("validlocation");
	module_addhook("moderate");
	module_addhook("changesetting");
	module_addhook("raceminedeath");
	module_addhook("pvpadjust");
	// Update from commentary sections using village-$city to village-$race;
	// This is pretty much a one-time thing
	$sql = "UPDATE " . db_prefix("commentary") . " SET section='village-Robot' WHERE section='village-01001010001'";
	db_query($sql);
	return true;
}

function racerobot_uninstall(){
	return true;
}

function racerobot_dohook($hookname,$args){
	//yeah, the $resline thing is a hack.  Sorry, not sure of a better way
	// to handle this.
	// Pass it in via args?
	global $session,$resline;
	$city = get_module_setting("villagename");
	$race = "Robot";
	switch($hookname){
	case "pvpadjust":
		if ($args['race'] == $race) {
			$args['creatureattack']++;
		}
		break;
	case "raceminedeath":
		if ($session['user']['race'] == $race) {
			$args['chance'] = get_module_setting("minedeathchance");
		}
		break;
	case "changesetting":
		// Ignore anything other than villagename setting changes
		if ($args['setting'] == "villagename") {
			if ($session['user']['location'] == $args['old'])
				$session['user']['location'] = $args['new'];
			$sql = "UPDATE " . db_prefix("accounts") .
				" SET location='" . $args['new'] .
				"' WHERE location='" . $args['old'] . "'";
			db_query($sql);
			if (is_module_active("cities")) {
				$sql = "UPDATE " . db_prefix("module_userprefs") .
					" SET value='" . $args['new'] .
					"' WHERE modulename='cities' AND setting='homecity'" .
					"AND value='" . $args['old'] . "'";
				db_query($sql);
			}
		}
		break;
	case "charstats":
		if ($session['user']['race']==$race){
			addcharstat("Vital Info");
			addcharstat("Race", $race);
		}
		break;
	case "chooserace":
		output("<a href='newday.php?setrace=Robot$resline'>In the factories of $city</a>`2 as a `@robot`2, you have been programmed to kick.. so do it. n`n",true);
		addnav("`@Robot`0","newday.php?setrace=Robot$resline");
		addnav("","newday.php?setrace=Robot$resline");
		break;
	case "setrace":
		if ($session['user']['race']==$race){
			output("`@As a robot, you were created pefectly in a factory in the city of $city, as a direct result of this you gain an attack bonus !");
			if (is_module_active("cities")) {
				if ($session['user']['dragonkills']==0 &&
						$session['user']['age']==0){
					//new farmthing, set them to wandering around this city.
					set_module_setting("newest-$city",
							$session['user']['acctid'],"cities");
				}
				set_module_pref("homecity",$city,"cities");
				$session['user']['location']=$city;
			}
		}
		break;
	case "validlocation":
		if (is_module_active("cities"))
			$args[$city] = 1;
		break;
	case "moderate":
		if (is_module_active("cities"))
			$args["village-$race"]="City of $city";
		break;
	case "newday":
		if ($session['user']['race']=="Robot"){
			racerobot_checkcity();
			apply_buff("racialbenefit",array(
				"name"=>"`@Robot Strength`0",
	 			"atkmod"=>"1+10/<attack>",
				"allowinpvp"=>1,
				"allowintrain"=>1,
				"rounds"=>-1,
				)
			);
		}
		break;
	case "travel":
		$capital = getsetting("villagename", LOCATION_FIELDS);
		if ($session['user']['location']==$capital){
			addnav("Safer Travel");
			addnav(substr($city,0,1)."?Go to $city","runmodule.php?module=cities&op=travel&city=$city");
		}elseif ($session['user']['location']!=$city){
			addnav("More Dangerous Travel");
			addnav(substr($city,0,1)."?Go to $city","runmodule.php?module=cities&op=travel&city=$city&d=1");
		}
		if ($session['user']['superuser'] & SU_EDIT_USERS){
			addnav("Superuser");
			addnav("Go to $city","runmodule.php?module=cities&op=travel&city=$city&su=1");
		}
		break;	
	case "villagetext":
		racerobot_checkcity();
		if ($session['user']['location'] == $city){
			$args['text']="`@`b`c$city, Home of the Robots`c`b`n`2 you are standing on cold hard steel, infact most of the city seems to be created from steal, alot of confusing beeps and buzes can be heard all around clouding your judgement of the city and its inhabients, are they good or evil? do you even want to find out?.`n";
			$args['clock']="`n`2There is a large casio wrist watch draped over the side of a building reading `@%s`2.`n";
			$args['title']="The Factories Of $city";
			$args['sayline']="beeps";
			$args['talk']="`n`@Nearby some robots interact:`n";
            $new = get_module_setting("newest-$city", "cities");
			if ($new != 0) {
				$sql =  "SELECT name FROM " . db_prefix("accounts") .
					" WHERE acctid='$new'";
				$result = db_query_cached($sql, "newest-$city");
				$row = db_fetch_assoc($result);
				$args['newestplayer'] = $row['name'];
				$args['newestid']=$new;
			} else {
				$args['newestplayer'] = $new;
				$args['newestid']="";
			}
			if ($new == $session['user']['acctid']) {
				$args['newest']="`n`6You stare around in wonder at the excessively tall buildings and feel just a bit queasy at the prospect of looking down from those heights.";
			} else {
				$args['newest']="`n`6Looking at the buildings high above, and looking a little queasy at the prospect of such heights is `^%s`6.";
			}
			$args['fightnav']="Combat";
			$args['marketnav']="Hardware Specialists";
			$args['tavernnav']="Beepertrons";
			$args['infonav']="Information";
			$args['section']="village-$race";
		}
		break;
	}
	return $args;
}

function racerobot_checkcity(){
	global $session;
	$race="Robot";
	$city=get_module_setting("villagename");
	
	if ($session['user']['race']==$race && is_module_active("cities")){
		//if they're this race and their home city isn't right, set it up.
		if (get_module_pref("homecity","cities")!=$city){ //home city is wrong
			set_module_pref("homecity",$city,"cities");
		}
	}	
	return true;
}

function racerobot_run(){

}
?>
