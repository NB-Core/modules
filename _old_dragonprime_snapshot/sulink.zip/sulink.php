<?php

function sulink_getmoduleinfo(){
	$info = array(
		"name"=>"Superuser Link",
		"author"=>"Chris Vorndran",
		"version"=>"0.11",
		"category"=>"Administrative",
		"download"=>"http://dragonprime.net/users/Sichae/sulink.zip",
		"vertxtloc"=>"http://dragonprime.net/users/Sichae/",
		"description"=>"Places a link to the Grotto at the bottom of MOST of the nav areas.",
		);
	return $info;
}
function sulink_install(){
	module_addhook("everyfooter");
	module_addhook("superuser");
	return true;
	}
function sulink_uninstall(){
	return true;
}
function sulink_dohook($hookname,$args){
	global $session;
	switch ($hookname){
		case "everyfooter":
			if ($args['__scriptfile__'] == "village" || $args['__scriptfile__'] == "news" || $args['__scriptfile__'] == "superuser" || $args['__scriptfile__'] == "shades") break;
			if ($session['user']['superuser'] &~ SU_DOESNT_GIVE_GROTTO){
				addnav("Superuser");
				addnav("X?`bSuperuser Grotto`b","superuser.php");
			}
			break;
		case "superuser":
			if ($session['user']['specialinc'] <> "") $session['user']['specialinc'] = 0;
			break;
		}
	return $args;
}
function sulink_run(){
}
?>