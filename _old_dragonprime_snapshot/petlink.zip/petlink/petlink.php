<?php
/*
Details:
 * This allows you to show the View Petitions Link on any page
History Log:
 v1.0:
 o Seems to be Stable
 v1.1:
 o Uses the new 'check_' preferences code
*/
require_once("lib/commentary.php");
require_once("lib/sanitize.php");
require_once("lib/http.php");
require_once("lib/villagenav.php");

function petlink_getmoduleinfo(){
	$info = array(
		"name"=>"Petition Link",
		"version"=>"1.1",
		"author"=>"`@CortalUX",
		"override_forced_nav"=>true,
		"category"=>"Administrative",
		"vertxtloc"=>"http://dragonprime.net/users/CortalUX/",
		"download"=>"http://dragonprime.net/users/CortalUX/petlink.zip",
		"prefs"=>array(
			"Petition Link - Preferences,title",
			"check_link"=>"Show petition link?,bool|1",
		),
	);
	return $info;
}

function petlink_install(){
	if (!is_module_active('petlink')){
		output("`n`c`b`QPetition Link Module - Installed`0`b`c");
	}else{
		output("`n`c`b`QPetition Link Module - Updated`0`b`c");
	}
	module_addhook("everyfooter");
	module_addhook("checkuserpref");
	return true;
}

function petlink_uninstall(){
	output("`n`c`b`QPetition Link Module - Uninstalled`0`b`c");
	return true;
}
	
function petlink_dohook($hookname,$args){
	global $session,$SCRIPT_NAME;
	$script = substr($SCRIPT_NAME,0,strrpos($SCRIPT_NAME,"."));
	if ($script!='superuser'&&$script!='viewpetition') {
		switch ($hookname) {
			case "everyfooter":
				if (get_module_pref('check_link')==1&&$session['user']['superuser']&SU_EDIT_PETITIONS) {
					addnav("Superuser");
					addnav("#?Petition Viewer","viewpetition.php");
				}
			break;
			case "checkuserpref":
				if ($session['user']['superuser'] & SU_EDIT_PETITIONS) {
					$args['allow']=true;
				} else {
					$args['allow']=false;
				}
			break;
		}
	}
	return $args;
}

function petlink_run(){
}
?>